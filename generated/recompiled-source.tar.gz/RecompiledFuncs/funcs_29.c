#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_8037F07C_79072C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037F07C: addiu       $sp, $sp, -0x90
    ctx->r29 = ADD32(ctx->r29, -0X90);
    // 0x8037F080: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8037F084: addiu       $t3, $a1, 0x40
    ctx->r11 = ADD32(ctx->r5, 0X40);
    // 0x8037F088: addiu       $v1, $v1, 0x2C78
    ctx->r3 = ADD32(ctx->r3, 0X2C78);
    // 0x8037F08C: andi        $t8, $a1, 0xFF
    ctx->r24 = ctx->r5 & 0XFF;
    // 0x8037F090: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8037F094: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8037F098: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x8037F09C: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x8037F0A0: addu        $t0, $v1, $t9
    ctx->r8 = ADD32(ctx->r3, ctx->r25);
    // 0x8037F0A4: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x8037F0A8: lh          $t1, 0x0($t0)
    ctx->r9 = MEM_H(ctx->r8, 0X0);
    // 0x8037F0AC: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x8037F0B0: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x8037F0B4: addiu       $s7, $s7, 0x5530
    ctx->r23 = ADD32(ctx->r23, 0X5530);
    // 0x8037F0B8: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    // 0x8037F0BC: sra         $t2, $t1, 7
    ctx->r10 = S32(SIGNED(ctx->r9) >> 7);
    // 0x8037F0C0: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8037F0C4: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8037F0C8: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x8037F0CC: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x8037F0D0: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x8037F0D4: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x8037F0D8: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x8037F0DC: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x8037F0E0: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x8037F0E4: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8037F0E8: sw          $a0, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r4;
    // 0x8037F0EC: sw          $a1, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r5;
    // 0x8037F0F0: sh          $t2, 0x88($sp)
    MEM_H(0X88, ctx->r29) = ctx->r10;
    // 0x8037F0F4: sh          $t8, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r24;
    // 0x8037F0F8: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x8037F0FC: lh          $t1, 0x92($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X92);
    // 0x8037F100: lh          $fp, 0x4($v0)
    ctx->r30 = MEM_H(ctx->r2, 0X4);
    // 0x8037F104: sh          $t9, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r25;
    // 0x8037F108: lh          $t0, 0xC($v0)
    ctx->r8 = MEM_H(ctx->r2, 0XC);
    // 0x8037F10C: slti        $at, $t1, 0x21
    ctx->r1 = SIGNED(ctx->r9) < 0X21 ? 1 : 0;
    // 0x8037F110: addiu       $s5, $zero, 0x20
    ctx->r21 = ADD32(0, 0X20);
    // 0x8037F114: bne         $at, $zero, L_8037F474
    if (ctx->r1 != 0) {
        // 0x8037F118: sh          $t0, 0x7A($sp)
        MEM_H(0X7A, ctx->r29) = ctx->r8;
            goto L_8037F474;
    }
    // 0x8037F118: sh          $t0, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r8;
    // 0x8037F11C: addiu       $s6, $zero, 0x1
    ctx->r22 = ADD32(0, 0X1);
    // 0x8037F120: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
L_8037F124:
    // 0x8037F124: lh          $t3, 0x88($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X88);
    // 0x8037F128: lbu         $t2, 0x162($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X162);
    // 0x8037F12C: beql        $s6, $t2, L_8037F1D4
    if (ctx->r22 == ctx->r10) {
        // 0x8037F130: lbu         $v1, 0x160($v0)
        ctx->r3 = MEM_BU(ctx->r2, 0X160);
            goto L_8037F1D4;
    }
    goto skip_0;
    // 0x8037F130: lbu         $v1, 0x160($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X160);
    skip_0:
    // 0x8037F134: multu       $t3, $s5
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F138: lh          $t0, 0x86($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X86);
    // 0x8037F13C: lh          $t9, 0x7C($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X7C);
    // 0x8037F140: mflo        $t4
    ctx->r12 = lo;
    // 0x8037F144: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x8037F148: addu        $s3, $fp, $t5
    ctx->r19 = ADD32(ctx->r30, ctx->r13);
    // 0x8037F14C: multu       $t0, $s5
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F150: sll         $t6, $s3, 16
    ctx->r14 = S32(ctx->r19 << 16);
    // 0x8037F154: sra         $s3, $t6, 16
    ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8037F158: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F15C: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F160: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x8037F164: mflo        $t1
    ctx->r9 = lo;
    // 0x8037F168: sra         $t2, $t1, 8
    ctx->r10 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8037F16C: addu        $s4, $t9, $t2
    ctx->r20 = ADD32(ctx->r25, ctx->r10);
    // 0x8037F170: sll         $t3, $s4, 16
    ctx->r11 = S32(ctx->r20 << 16);
    // 0x8037F174: sra         $s4, $t3, 16
    ctx->r20 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8037F178: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F17C: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F180: jal         0x8031124C
    // 0x8037F184: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_0;
    // 0x8037F184: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    after_0:
    // 0x8037F188: lh          $t7, 0x7A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F18C: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8037F190: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F194: slt         $at, $t6, $t7
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x8037F198: beq         $at, $zero, L_8037F1A8
    if (ctx->r1 == 0) {
        // 0x8037F19C: sra         $t8, $a0, 16
        ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
            goto L_8037F1A8;
    }
    // 0x8037F19C: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F1A0: b           L_8037F1C0
    // 0x8037F1A4: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
        goto L_8037F1C0;
    // 0x8037F1A4: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
L_8037F1A8:
    // 0x8037F1A8: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F1AC: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F1B0: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x8037F1B4: jal         0x8031124C
    // 0x8037F1B8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_1;
    // 0x8037F1B8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    after_1:
    // 0x8037F1BC: sra         $a3, $v0, 16
    ctx->r7 = S32(SIGNED(ctx->r2) >> 16);
L_8037F1C0:
    // 0x8037F1C0: addiu       $s0, $a3, 0x8
    ctx->r16 = ADD32(ctx->r7, 0X8);
    // 0x8037F1C4: sll         $t1, $s0, 16
    ctx->r9 = S32(ctx->r16 << 16);
    // 0x8037F1C8: b           L_8037F2F4
    // 0x8037F1CC: sra         $s0, $t1, 16
    ctx->r16 = S32(SIGNED(ctx->r9) >> 16);
        goto L_8037F2F4;
    // 0x8037F1CC: sra         $s0, $t1, 16
    ctx->r16 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8037F1D0: lbu         $v1, 0x160($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X160);
L_8037F1D4:
    // 0x8037F1D4: lh          $t2, 0x88($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X88);
    // 0x8037F1D8: beq         $v1, $zero, L_8037F1E8
    if (ctx->r3 == 0) {
        // 0x8037F1DC: nop
    
            goto L_8037F1E8;
    }
    // 0x8037F1DC: nop

    // 0x8037F1E0: bne         $s6, $v1, L_8037F250
    if (ctx->r22 != ctx->r3) {
        // 0x8037F1E4: lh          $t0, 0x88($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X88);
            goto L_8037F250;
    }
    // 0x8037F1E4: lh          $t0, 0x88($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X88);
L_8037F1E8:
    // 0x8037F1E8: multu       $t2, $s5
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F1EC: lh          $t0, 0x86($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X86);
    // 0x8037F1F0: lh          $t8, 0x7C($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X7C);
    // 0x8037F1F4: mflo        $t3
    ctx->r11 = lo;
    // 0x8037F1F8: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x8037F1FC: addu        $s3, $fp, $t4
    ctx->r19 = ADD32(ctx->r30, ctx->r12);
    // 0x8037F200: multu       $t0, $s5
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F204: sll         $t5, $s3, 16
    ctx->r13 = S32(ctx->r19 << 16);
    // 0x8037F208: sra         $s3, $t5, 16
    ctx->r19 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8037F20C: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F210: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F214: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8037F218: mflo        $t1
    ctx->r9 = lo;
    // 0x8037F21C: sra         $t9, $t1, 8
    ctx->r25 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8037F220: addu        $s4, $t8, $t9
    ctx->r20 = ADD32(ctx->r24, ctx->r25);
    // 0x8037F224: sll         $t2, $s4, 16
    ctx->r10 = S32(ctx->r20 << 16);
    // 0x8037F228: sra         $s4, $t2, 16
    ctx->r20 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8037F22C: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F230: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F234: jal         0x8031124C
    // 0x8037F238: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_2;
    // 0x8037F238: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    after_2:
    // 0x8037F23C: addiu       $s0, $v0, 0x8
    ctx->r16 = ADD32(ctx->r2, 0X8);
    // 0x8037F240: sra         $t5, $s0, 16
    ctx->r13 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8037F244: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8037F248: b           L_8037F2F4
    // 0x8037F24C: sra         $s0, $t6, 16
    ctx->r16 = S32(SIGNED(ctx->r14) >> 16);
        goto L_8037F2F4;
    // 0x8037F24C: sra         $s0, $t6, 16
    ctx->r16 = S32(SIGNED(ctx->r14) >> 16);
L_8037F250:
    // 0x8037F250: multu       $t0, $s5
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F254: lh          $t5, 0x86($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X86);
    // 0x8037F258: lh          $t4, 0x7C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X7C);
    // 0x8037F25C: mflo        $t1
    ctx->r9 = lo;
    // 0x8037F260: sra         $t8, $t1, 8
    ctx->r24 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8037F264: addu        $s3, $fp, $t8
    ctx->r19 = ADD32(ctx->r30, ctx->r24);
    // 0x8037F268: multu       $t5, $s5
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F26C: sll         $t9, $s3, 16
    ctx->r25 = S32(ctx->r19 << 16);
    // 0x8037F270: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8037F274: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F278: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F27C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x8037F280: mflo        $t6
    ctx->r14 = lo;
    // 0x8037F284: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x8037F288: addu        $s4, $t4, $t7
    ctx->r20 = ADD32(ctx->r12, ctx->r15);
    // 0x8037F28C: sll         $t0, $s4, 16
    ctx->r8 = S32(ctx->r20 << 16);
    // 0x8037F290: sra         $s4, $t0, 16
    ctx->r20 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8037F294: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F298: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F29C: jal         0x80310F58
    // 0x8037F2A0: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_80310F58_722608(rdram, ctx);
        goto after_3;
    // 0x8037F2A0: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_3:
    // 0x8037F2A4: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8037F2A8: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x8037F2AC: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8037F2B0: addiu       $at, $zero, 0x4000
    ctx->r1 = ADD32(0, 0X4000);
    // 0x8037F2B4: bne         $v1, $at, L_8037F2EC
    if (ctx->r3 != ctx->r1) {
        // 0x8037F2B8: addiu       $s0, $v1, 0x8
        ctx->r16 = ADD32(ctx->r3, 0X8);
            goto L_8037F2EC;
    }
    // 0x8037F2B8: addiu       $s0, $v1, 0x8
    ctx->r16 = ADD32(ctx->r3, 0X8);
    // 0x8037F2BC: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F2C0: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F2C4: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F2C8: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F2CC: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x8037F2D0: jal         0x8031124C
    // 0x8037F2D4: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_4;
    // 0x8037F2D4: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    after_4:
    // 0x8037F2D8: addiu       $s0, $v0, 0x8
    ctx->r16 = ADD32(ctx->r2, 0X8);
    // 0x8037F2DC: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8037F2E0: sll         $t4, $t6, 16
    ctx->r12 = S32(ctx->r14 << 16);
    // 0x8037F2E4: b           L_8037F2F4
    // 0x8037F2E8: sra         $s0, $t4, 16
    ctx->r16 = S32(SIGNED(ctx->r12) >> 16);
        goto L_8037F2F4;
    // 0x8037F2E8: sra         $s0, $t4, 16
    ctx->r16 = S32(SIGNED(ctx->r12) >> 16);
L_8037F2EC:
    // 0x8037F2EC: sll         $t0, $s0, 16
    ctx->r8 = S32(ctx->r16 << 16);
    // 0x8037F2F0: sra         $s0, $t0, 16
    ctx->r16 = S32(SIGNED(ctx->r8) >> 16);
L_8037F2F4:
    // 0x8037F2F4: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F2F8: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F2FC: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x8037F300: sra         $t2, $a2, 16
    ctx->r10 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8037F304: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F308: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F30C: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x8037F310: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x8037F314: jal         0x803136FC
    // 0x8037F318: or          $a2, $t2, $zero
    ctx->r6 = ctx->r10 | 0;
    func_803136FC_724DAC(rdram, ctx);
        goto after_5;
    // 0x8037F318: or          $a2, $t2, $zero
    ctx->r6 = ctx->r10 | 0;
    after_5:
    // 0x8037F31C: bne         $s6, $v0, L_8037F334
    if (ctx->r22 != ctx->r2) {
        // 0x8037F320: andi        $s1, $v0, 0xFF
        ctx->r17 = ctx->r2 & 0XFF;
            goto L_8037F334;
    }
    // 0x8037F320: andi        $s1, $v0, 0xFF
    ctx->r17 = ctx->r2 & 0XFF;
    // 0x8037F324: lw          $t3, 0x0($s7)
    ctx->r11 = MEM_W(ctx->r23, 0X0);
    // 0x8037F328: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8037F32C: lbu         $t5, 0x160($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X160);
    // 0x8037F330: beq         $t5, $at, L_8037F474
    if (ctx->r13 == ctx->r1) {
        // 0x8037F334: andi        $t6, $v0, 0xFF
        ctx->r14 = ctx->r2 & 0XFF;
            goto L_8037F474;
    }
L_8037F334:
    // 0x8037F334: andi        $t6, $v0, 0xFF
    ctx->r14 = ctx->r2 & 0XFF;
    // 0x8037F338: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8037F33C: bne         $t6, $at, L_8037F354
    if (ctx->r14 != ctx->r1) {
        // 0x8037F340: sll         $a0, $s3, 16
        ctx->r4 = S32(ctx->r19 << 16);
            goto L_8037F354;
    }
    // 0x8037F340: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F344: lw          $t4, 0x0($s7)
    ctx->r12 = MEM_W(ctx->r23, 0X0);
    // 0x8037F348: lbu         $t7, 0x160($t4)
    ctx->r15 = MEM_BU(ctx->r12, 0X160);
    // 0x8037F34C: beql        $s6, $t7, L_8037F478
    if (ctx->r22 == ctx->r15) {
        // 0x8037F350: lh          $t2, 0x92($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X92);
            goto L_8037F478;
    }
    goto skip_1;
    // 0x8037F350: lh          $t2, 0x92($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X92);
    skip_1:
L_8037F354:
    // 0x8037F354: lh          $s2, 0x7A($sp)
    ctx->r18 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F358: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F35C: sra         $t1, $a1, 16
    ctx->r9 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F360: addiu       $s2, $s2, 0x10
    ctx->r18 = ADD32(ctx->r18, 0X10);
    // 0x8037F364: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x8037F368: sra         $t0, $a0, 16
    ctx->r8 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F36C: or          $a0, $t0, $zero
    ctx->r4 = ctx->r8 | 0;
    // 0x8037F370: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8037F374: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x8037F378: addiu       $a2, $sp, 0x76
    ctx->r6 = ADD32(ctx->r29, 0X76);
    // 0x8037F37C: addiu       $a3, $sp, 0x74
    ctx->r7 = ADD32(ctx->r29, 0X74);
    // 0x8037F380: jal         0x80311A2C
    // 0x8037F384: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_6;
    // 0x8037F384: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    after_6:
    // 0x8037F388: lw          $t5, 0x0($s7)
    ctx->r13 = MEM_W(ctx->r23, 0X0);
    // 0x8037F38C: sll         $a0, $fp, 16
    ctx->r4 = S32(ctx->r30 << 16);
    // 0x8037F390: sll         $a2, $s2, 16
    ctx->r6 = S32(ctx->r18 << 16);
    // 0x8037F394: lbu         $a3, 0x160($t5)
    ctx->r7 = MEM_BU(ctx->r13, 0X160);
    // 0x8037F398: sra         $t3, $a2, 16
    ctx->r11 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8037F39C: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F3A0: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x8037F3A4: or          $a2, $t3, $zero
    ctx->r6 = ctx->r11 | 0;
    // 0x8037F3A8: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8037F3AC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8037F3B0: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8037F3B4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8037F3B8: sw          $s4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r20;
    // 0x8037F3BC: sw          $s3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r19;
    // 0x8037F3C0: jal         0x8033C9CC
    // 0x8037F3C4: lh          $a1, 0x7C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X7C);
    func_8033C9CC_74E07C(rdram, ctx);
        goto after_7;
    // 0x8037F3C4: lh          $a1, 0x7C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X7C);
    after_7:
    // 0x8037F3C8: bne         $v0, $zero, L_8037F474
    if (ctx->r2 != 0) {
        // 0x8037F3CC: lh          $t6, 0x7A($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X7A);
            goto L_8037F474;
    }
    // 0x8037F3CC: lh          $t6, 0x7A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F3D0: subu        $v0, $s0, $t6
    ctx->r2 = SUB32(ctx->r16, ctx->r14);
    // 0x8037F3D4: bgez        $v0, L_8037F3E4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8037F3D8: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_8037F3E4;
    }
    // 0x8037F3D8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8037F3DC: b           L_8037F3E8
    // 0x8037F3E0: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
        goto L_8037F3E8;
    // 0x8037F3E0: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
L_8037F3E4:
    // 0x8037F3E4: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
L_8037F3E8:
    // 0x8037F3E8: slti        $at, $a3, 0x50
    ctx->r1 = SIGNED(ctx->r7) < 0X50 ? 1 : 0;
    // 0x8037F3EC: beq         $at, $zero, L_8037F474
    if (ctx->r1 == 0) {
        // 0x8037F3F0: sll         $a2, $s3, 16
        ctx->r6 = S32(ctx->r19 << 16);
            goto L_8037F474;
    }
    // 0x8037F3F0: sll         $a2, $s3, 16
    ctx->r6 = S32(ctx->r19 << 16);
    // 0x8037F3F4: sll         $t4, $s0, 16
    ctx->r12 = S32(ctx->r16 << 16);
    // 0x8037F3F8: addiu       $t7, $sp, 0x72
    ctx->r15 = ADD32(ctx->r29, 0X72);
    // 0x8037F3FC: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x8037F400: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x8037F404: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8037F408: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8037F40C: lw          $a0, 0x0($s7)
    ctx->r4 = MEM_W(ctx->r23, 0X0);
    // 0x8037F410: jal         0x802B75CC
    // 0x8037F414: sll         $a3, $s4, 16
    ctx->r7 = S32(ctx->r20 << 16);
    check_collision_against_animals_6C8C7C(rdram, ctx);
        goto after_8;
    // 0x8037F414: sll         $a3, $s4, 16
    ctx->r7 = S32(ctx->r20 << 16);
    after_8:
    // 0x8037F418: bne         $v0, $zero, L_8037F474
    if (ctx->r2 != 0) {
        // 0x8037F41C: lh          $v1, 0x76($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X76);
            goto L_8037F474;
    }
    // 0x8037F41C: lh          $v1, 0x76($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X76);
    // 0x8037F420: bgez        $v1, L_8037F430
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8037F424: lh          $t9, 0x92($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X92);
            goto L_8037F430;
    }
    // 0x8037F424: lh          $t9, 0x92($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X92);
    // 0x8037F428: b           L_8037F434
    // 0x8037F42C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_8037F434;
    // 0x8037F42C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_8037F430:
    // 0x8037F430: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_8037F434:
    // 0x8037F434: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x8037F438: beq         $at, $zero, L_8037F474
    if (ctx->r1 == 0) {
        // 0x8037F43C: lh          $v1, 0x74($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X74);
            goto L_8037F474;
    }
    // 0x8037F43C: lh          $v1, 0x74($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X74);
    // 0x8037F440: bgez        $v1, L_8037F450
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8037F444: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_8037F450;
    }
    // 0x8037F444: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8037F448: b           L_8037F450
    // 0x8037F44C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_8037F450;
    // 0x8037F44C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_8037F450:
    // 0x8037F450: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x8037F454: beql        $at, $zero, L_8037F478
    if (ctx->r1 == 0) {
        // 0x8037F458: lh          $t2, 0x92($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X92);
            goto L_8037F478;
    }
    goto skip_2;
    // 0x8037F458: lh          $t2, 0x92($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X92);
    skip_2:
    // 0x8037F45C: addiu       $s5, $s5, 0x20
    ctx->r21 = ADD32(ctx->r21, 0X20);
    // 0x8037F460: sll         $t1, $s5, 16
    ctx->r9 = S32(ctx->r21 << 16);
    // 0x8037F464: sra         $s5, $t1, 16
    ctx->r21 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8037F468: slt         $at, $s5, $t9
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8037F46C: bnel        $at, $zero, L_8037F124
    if (ctx->r1 != 0) {
        // 0x8037F470: lw          $v0, 0x0($s7)
        ctx->r2 = MEM_W(ctx->r23, 0X0);
            goto L_8037F124;
    }
    goto skip_3;
    // 0x8037F470: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    skip_3:
L_8037F474:
    // 0x8037F474: lh          $t2, 0x92($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X92);
L_8037F478:
    // 0x8037F478: addiu       $v0, $s5, -0x30
    ctx->r2 = ADD32(ctx->r21, -0X30);
    // 0x8037F47C: lh          $s5, 0x92($sp)
    ctx->r21 = MEM_H(ctx->r29, 0X92);
    // 0x8037F480: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x8037F484: beq         $at, $zero, L_8037F49C
    if (ctx->r1 == 0) {
        // 0x8037F488: nop
    
            goto L_8037F49C;
    }
    // 0x8037F488: nop

    // 0x8037F48C: sll         $s5, $v0, 16
    ctx->r21 = S32(ctx->r2 << 16);
    // 0x8037F490: sra         $t3, $s5, 16
    ctx->r11 = S32(SIGNED(ctx->r21) >> 16);
    // 0x8037F494: b           L_8037F49C
    // 0x8037F498: or          $s5, $t3, $zero
    ctx->r21 = ctx->r11 | 0;
        goto L_8037F49C;
    // 0x8037F498: or          $s5, $t3, $zero
    ctx->r21 = ctx->r11 | 0;
L_8037F49C:
    // 0x8037F49C: slti        $at, $s5, 0x11
    ctx->r1 = SIGNED(ctx->r21) < 0X11 ? 1 : 0;
    // 0x8037F4A0: bnel        $at, $zero, L_8037F69C
    if (ctx->r1 != 0) {
        // 0x8037F4A4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8037F69C;
    }
    goto skip_4;
    // 0x8037F4A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_4:
    // 0x8037F4A8: lw          $t5, 0x0($s7)
    ctx->r13 = MEM_W(ctx->r23, 0X0);
    // 0x8037F4AC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8037F4B0: lh          $t4, 0x88($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X88);
    // 0x8037F4B4: lbu         $t6, 0x160($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X160);
    // 0x8037F4B8: lh          $t0, 0x88($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X88);
    // 0x8037F4BC: bne         $t6, $at, L_8037F5A4
    if (ctx->r14 != ctx->r1) {
        // 0x8037F4C0: nop
    
            goto L_8037F5A4;
    }
    // 0x8037F4C0: nop

    // 0x8037F4C4: multu       $t4, $s5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F4C8: lh          $t3, 0x86($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X86);
    // 0x8037F4CC: lh          $t2, 0x7C($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X7C);
    // 0x8037F4D0: mflo        $t7
    ctx->r15 = lo;
    // 0x8037F4D4: sra         $t0, $t7, 8
    ctx->r8 = S32(SIGNED(ctx->r15) >> 8);
    // 0x8037F4D8: addu        $s3, $fp, $t0
    ctx->r19 = ADD32(ctx->r30, ctx->r8);
    // 0x8037F4DC: multu       $t3, $s5
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F4E0: sll         $t1, $s3, 16
    ctx->r9 = S32(ctx->r19 << 16);
    // 0x8037F4E4: sra         $s3, $t1, 16
    ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8037F4E8: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F4EC: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F4F0: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x8037F4F4: mflo        $t5
    ctx->r13 = lo;
    // 0x8037F4F8: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x8037F4FC: addu        $s4, $t2, $t6
    ctx->r20 = ADD32(ctx->r10, ctx->r14);
    // 0x8037F500: sll         $t4, $s4, 16
    ctx->r12 = S32(ctx->r20 << 16);
    // 0x8037F504: sra         $s4, $t4, 16
    ctx->r20 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8037F508: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F50C: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F510: jal         0x80310F58
    // 0x8037F514: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    func_80310F58_722608(rdram, ctx);
        goto after_9;
    // 0x8037F514: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    after_9:
    // 0x8037F518: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8037F51C: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x8037F520: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8037F524: addiu       $at, $zero, 0x4000
    ctx->r1 = ADD32(0, 0X4000);
    // 0x8037F528: bne         $v1, $at, L_8037F588
    if (ctx->r3 != ctx->r1) {
        // 0x8037F52C: lh          $t7, 0x7A($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X7A);
            goto L_8037F588;
    }
    // 0x8037F52C: lh          $t7, 0x7A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F530: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F534: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F538: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F53C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F540: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x8037F544: jal         0x8031124C
    // 0x8037F548: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_10;
    // 0x8037F548: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    after_10:
    // 0x8037F54C: lh          $t2, 0x7A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F550: sra         $t5, $v0, 16
    ctx->r13 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8037F554: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F558: slt         $at, $t5, $t2
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x8037F55C: beq         $at, $zero, L_8037F56C
    if (ctx->r1 == 0) {
        // 0x8037F560: sra         $t6, $a0, 16
        ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
            goto L_8037F56C;
    }
    // 0x8037F560: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F564: b           L_8037F630
    // 0x8037F568: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
        goto L_8037F630;
    // 0x8037F568: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
L_8037F56C:
    // 0x8037F56C: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F570: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F574: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x8037F578: jal         0x8031124C
    // 0x8037F57C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_11;
    // 0x8037F57C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_11:
    // 0x8037F580: b           L_8037F630
    // 0x8037F584: sra         $a3, $v0, 16
    ctx->r7 = S32(SIGNED(ctx->r2) >> 16);
        goto L_8037F630;
    // 0x8037F584: sra         $a3, $v0, 16
    ctx->r7 = S32(SIGNED(ctx->r2) >> 16);
L_8037F588:
    // 0x8037F588: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x8037F58C: beq         $at, $zero, L_8037F59C
    if (ctx->r1 == 0) {
        // 0x8037F590: nop
    
            goto L_8037F59C;
    }
    // 0x8037F590: nop

    // 0x8037F594: b           L_8037F630
    // 0x8037F598: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
        goto L_8037F630;
    // 0x8037F598: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
L_8037F59C:
    // 0x8037F59C: b           L_8037F630
    // 0x8037F5A0: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
        goto L_8037F630;
    // 0x8037F5A0: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
L_8037F5A4:
    // 0x8037F5A4: multu       $t0, $s5
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F5A8: lh          $t6, 0x86($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X86);
    // 0x8037F5AC: lh          $t2, 0x7C($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X7C);
    // 0x8037F5B0: mflo        $t1
    ctx->r9 = lo;
    // 0x8037F5B4: sra         $t8, $t1, 8
    ctx->r24 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8037F5B8: addu        $s3, $fp, $t8
    ctx->r19 = ADD32(ctx->r30, ctx->r24);
    // 0x8037F5BC: multu       $t6, $s5
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8037F5C0: sll         $t9, $s3, 16
    ctx->r25 = S32(ctx->r19 << 16);
    // 0x8037F5C4: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8037F5C8: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F5CC: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F5D0: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x8037F5D4: mflo        $t4
    ctx->r12 = lo;
    // 0x8037F5D8: sra         $t7, $t4, 8
    ctx->r15 = S32(SIGNED(ctx->r12) >> 8);
    // 0x8037F5DC: addu        $s4, $t2, $t7
    ctx->r20 = ADD32(ctx->r10, ctx->r15);
    // 0x8037F5E0: sll         $t0, $s4, 16
    ctx->r8 = S32(ctx->r20 << 16);
    // 0x8037F5E4: sra         $s4, $t0, 16
    ctx->r20 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8037F5E8: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F5EC: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F5F0: jal         0x8031124C
    // 0x8037F5F4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_12;
    // 0x8037F5F4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_12:
    // 0x8037F5F8: lh          $t3, 0x7A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X7A);
    // 0x8037F5FC: sra         $t9, $v0, 16
    ctx->r25 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8037F600: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F604: slt         $at, $t9, $t3
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x8037F608: beq         $at, $zero, L_8037F618
    if (ctx->r1 == 0) {
        // 0x8037F60C: sra         $t5, $a0, 16
        ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
            goto L_8037F618;
    }
    // 0x8037F60C: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F610: b           L_8037F630
    // 0x8037F614: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
        goto L_8037F630;
    // 0x8037F614: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
L_8037F618:
    // 0x8037F618: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F61C: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F620: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8037F624: jal         0x8031124C
    // 0x8037F628: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_13;
    // 0x8037F628: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    after_13:
    // 0x8037F62C: sra         $a3, $v0, 16
    ctx->r7 = S32(SIGNED(ctx->r2) >> 16);
L_8037F630:
    // 0x8037F630: lw          $t4, 0x0($s7)
    ctx->r12 = MEM_W(ctx->r23, 0X0);
    // 0x8037F634: addiu       $a2, $a3, 0x10
    ctx->r6 = ADD32(ctx->r7, 0X10);
    // 0x8037F638: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x8037F63C: sh          $s3, 0x4($t4)
    MEM_H(0X4, ctx->r12) = ctx->r19;
    // 0x8037F640: lw          $t2, 0x0($s7)
    ctx->r10 = MEM_W(ctx->r23, 0X0);
    // 0x8037F644: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8037F648: sll         $a0, $s3, 16
    ctx->r4 = S32(ctx->r19 << 16);
    // 0x8037F64C: sh          $s4, 0x8($t2)
    MEM_H(0X8, ctx->r10) = ctx->r20;
    // 0x8037F650: lw          $t1, 0x0($s7)
    ctx->r9 = MEM_W(ctx->r23, 0X0);
    // 0x8037F654: sll         $a1, $s4, 16
    ctx->r5 = S32(ctx->r20 << 16);
    // 0x8037F658: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037F65C: sh          $a2, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r6;
    // 0x8037F660: lw          $t8, 0x0($s7)
    ctx->r24 = MEM_W(ctx->r23, 0X0);
    // 0x8037F664: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F668: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x8037F66C: sw          $zero, 0x1C($t8)
    MEM_W(0X1C, ctx->r24) = 0;
    // 0x8037F670: lw          $t9, 0x0($s7)
    ctx->r25 = MEM_W(ctx->r23, 0X0);
    // 0x8037F674: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8037F678: sw          $zero, 0x20($t9)
    MEM_W(0X20, ctx->r25) = 0;
    // 0x8037F67C: lw          $t3, 0x0($s7)
    ctx->r11 = MEM_W(ctx->r23, 0X0);
    // 0x8037F680: jal         0x803136FC
    // 0x8037F684: sw          $zero, 0x24($t3)
    MEM_W(0X24, ctx->r11) = 0;
    func_803136FC_724DAC(rdram, ctx);
        goto after_14;
    // 0x8037F684: sw          $zero, 0x24($t3)
    MEM_W(0X24, ctx->r11) = 0;
    after_14:
    // 0x8037F688: lw          $t4, 0x0($s7)
    ctx->r12 = MEM_W(ctx->r23, 0X0);
    // 0x8037F68C: sb          $v0, 0x160($t4)
    MEM_B(0X160, ctx->r12) = ctx->r2;
    // 0x8037F690: b           L_8037F69C
    // 0x8037F694: or          $v0, $s5, $zero
    ctx->r2 = ctx->r21 | 0;
        goto L_8037F69C;
    // 0x8037F694: or          $v0, $s5, $zero
    ctx->r2 = ctx->r21 | 0;
    // 0x8037F698: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8037F69C:
    // 0x8037F69C: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x8037F6A0: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8037F6A4: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x8037F6A8: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x8037F6AC: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x8037F6B0: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x8037F6B4: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x8037F6B8: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x8037F6BC: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x8037F6C0: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x8037F6C4: jr          $ra
    // 0x8037F6C8: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
    return;
    // 0x8037F6C8: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
;}
RECOMP_FUNC void func_8037F6CC_790D7C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037F6CC: addiu       $sp, $sp, -0xA0
    ctx->r29 = ADD32(ctx->r29, -0XA0);
    // 0x8037F6D0: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8037F6D4: lui         $s6, 0x803D
    ctx->r22 = S32(0X803D << 16);
    // 0x8037F6D8: addiu       $s6, $s6, 0x5530
    ctx->r22 = ADD32(ctx->r22, 0X5530);
    // 0x8037F6DC: lw          $t0, 0x0($s6)
    ctx->r8 = MEM_W(ctx->r22, 0X0);
    // 0x8037F6E0: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8037F6E4: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8037F6E8: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x8037F6EC: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8037F6F0: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8037F6F4: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8037F6F8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8037F6FC: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8037F700: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8037F704: sw          $a0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r4;
    // 0x8037F708: sw          $a1, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r5;
    // 0x8037F70C: sw          $a2, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->r6;
    // 0x8037F710: lh          $t1, 0x4($t0)
    ctx->r9 = MEM_H(ctx->r8, 0X4);
    // 0x8037F714: sll         $s4, $a1, 16
    ctx->r20 = S32(ctx->r5 << 16);
    // 0x8037F718: sra         $t6, $s4, 16
    ctx->r14 = S32(SIGNED(ctx->r20) >> 16);
    // 0x8037F71C: sll         $s5, $a2, 16
    ctx->r21 = S32(ctx->r6 << 16);
    // 0x8037F720: sra         $v0, $t1, 10
    ctx->r2 = S32(SIGNED(ctx->r9) >> 10);
    // 0x8037F724: lh          $t2, 0x8($t0)
    ctx->r10 = MEM_H(ctx->r8, 0X8);
    // 0x8037F728: sra         $t7, $s5, 16
    ctx->r15 = S32(SIGNED(ctx->r21) >> 16);
    // 0x8037F72C: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
    // 0x8037F730: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x8037F734: or          $s5, $t7, $zero
    ctx->r21 = ctx->r15 | 0;
    // 0x8037F738: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8037F73C: sll         $ra, $v0, 16
    ctx->r31 = S32(ctx->r2 << 16);
    // 0x8037F740: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8037F744: sra         $t8, $ra, 16
    ctx->r24 = S32(SIGNED(ctx->r31) >> 16);
    // 0x8037F748: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8037F74C: slti        $at, $t7, 0x5
    ctx->r1 = SIGNED(ctx->r15) < 0X5 ? 1 : 0;
    // 0x8037F750: sra         $a3, $t2, 10
    ctx->r7 = S32(SIGNED(ctx->r10) >> 10);
    // 0x8037F754: or          $ra, $t8, $zero
    ctx->r31 = ctx->r24 | 0;
    // 0x8037F758: sh          $a3, 0x9C($sp)
    MEM_H(0X9C, ctx->r29) = ctx->r7;
    // 0x8037F75C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x8037F760: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
    // 0x8037F764: sh          $t9, 0x90($sp)
    MEM_H(0X90, ctx->r29) = ctx->r25;
    // 0x8037F768: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8037F76C: bne         $at, $zero, L_8037F778
    if (ctx->r1 != 0) {
        // 0x8037F770: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_8037F778;
    }
    // 0x8037F770: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x8037F774: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
L_8037F778:
    // 0x8037F778: bgtz        $v1, L_8037F784
    if (SIGNED(ctx->r3) > 0) {
        // 0x8037F77C: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_8037F784;
    }
    // 0x8037F77C: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x8037F780: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
L_8037F784:
    // 0x8037F784: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F788: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8037F78C: slti        $at, $t9, 0x8
    ctx->r1 = SIGNED(ctx->r25) < 0X8 ? 1 : 0;
    // 0x8037F790: bne         $at, $zero, L_8037F79C
    if (ctx->r1 != 0) {
        // 0x8037F794: or          $a0, $t8, $zero
        ctx->r4 = ctx->r24 | 0;
            goto L_8037F79C;
    }
    // 0x8037F794: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x8037F798: sh          $zero, 0x90($sp)
    MEM_H(0X90, ctx->r29) = 0;
L_8037F79C:
    // 0x8037F79C: bgtz        $a0, L_8037F7A8
    if (SIGNED(ctx->r4) > 0) {
        // 0x8037F7A0: addu        $v0, $v1, $t3
        ctx->r2 = ADD32(ctx->r3, ctx->r11);
            goto L_8037F7A8;
    }
    // 0x8037F7A0: addu        $v0, $v1, $t3
    ctx->r2 = ADD32(ctx->r3, ctx->r11);
    // 0x8037F7A4: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
L_8037F7A8:
    // 0x8037F7A8: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8037F7AC: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8037F7B0: addu        $t6, $v1, $t4
    ctx->r14 = ADD32(ctx->r3, ctx->r12);
    // 0x8037F7B4: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x8037F7B8: bne         $at, $zero, L_8037FB8C
    if (ctx->r1 != 0) {
        // 0x8037F7BC: sh          $v0, 0x9A($sp)
        MEM_H(0X9A, ctx->r29) = ctx->r2;
            goto L_8037FB8C;
    }
    // 0x8037F7BC: sh          $v0, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r2;
    // 0x8037F7C0: addu        $t9, $ra, $t4
    ctx->r25 = ADD32(ctx->r31, ctx->r12);
    // 0x8037F7C4: addu        $t7, $a0, $t5
    ctx->r15 = ADD32(ctx->r4, ctx->r13);
    // 0x8037F7C8: lh          $t6, 0x90($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X90);
    // 0x8037F7CC: sw          $t7, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r15;
    // 0x8037F7D0: sw          $t9, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r25;
    // 0x8037F7D4: lh          $t9, 0x4A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X4A);
    // 0x8037F7D8: addu        $t8, $a0, $t6
    ctx->r24 = ADD32(ctx->r4, ctx->r14);
    // 0x8037F7DC: sw          $t8, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r24;
    // 0x8037F7E0: addiu       $fp, $zero, 0xD
    ctx->r30 = ADD32(0, 0XD);
    // 0x8037F7E4: addiu       $s7, $zero, 0x3E
    ctx->r23 = ADD32(0, 0X3E);
    // 0x8037F7E8: sw          $t9, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r25;
L_8037F7EC:
    // 0x8037F7EC: lw          $t6, 0x44($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X44);
    // 0x8037F7F0: lw          $t8, 0x40($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X40);
    // 0x8037F7F4: lw          $t7, 0x48($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X48);
    // 0x8037F7F8: lh          $t9, 0x9C($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X9C);
    // 0x8037F7FC: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x8037F800: bne         $at, $zero, L_8037FB6C
    if (ctx->r1 != 0) {
        // 0x8037F804: sh          $t7, 0x98($sp)
        MEM_H(0X98, ctx->r29) = ctx->r15;
            goto L_8037FB6C;
    }
    // 0x8037F804: sh          $t7, 0x98($sp)
    MEM_H(0X98, ctx->r29) = ctx->r15;
    // 0x8037F808: lh          $t7, 0x90($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X90);
    // 0x8037F80C: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x8037F810: sw          $t6, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r14;
L_8037F814:
    // 0x8037F814: lh          $t9, 0x98($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X98);
    // 0x8037F818: lh          $t8, 0x9A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X9A);
    // 0x8037F81C: lui         $s2, 0x803E
    ctx->r18 = S32(0X803E << 16);
    // 0x8037F820: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x8037F824: addu        $t7, $t7, $t9
    ctx->r15 = ADD32(ctx->r15, ctx->r25);
    // 0x8037F828: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x8037F82C: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8037F830: sra         $t8, $t9, 16
    ctx->r24 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8037F834: sll         $t7, $t8, 2
    ctx->r15 = S32(ctx->r24 << 2);
    // 0x8037F838: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x8037F83C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8037F840: addu        $s2, $s2, $t7
    ctx->r18 = ADD32(ctx->r18, ctx->r15);
    // 0x8037F844: lw          $s2, -0x5EF0($s2)
    ctx->r18 = MEM_W(ctx->r18, -0X5EF0);
    // 0x8037F848: beql        $s2, $zero, L_8037FB50
    if (ctx->r18 == 0) {
        // 0x8037F84C: lh          $t6, 0x98($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X98);
            goto L_8037FB50;
    }
    goto skip_0;
    // 0x8037F84C: lh          $t6, 0x98($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X98);
    skip_0:
    // 0x8037F850: lw          $v0, 0x8($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X8);
L_8037F854:
    // 0x8037F854: addiu       $t6, $v0, 0x11C
    ctx->r14 = ADD32(ctx->r2, 0X11C);
    // 0x8037F858: bnel        $s2, $t6, L_8037FB44
    if (ctx->r18 != ctx->r14) {
        // 0x8037F85C: lw          $s2, 0x0($s2)
        ctx->r18 = MEM_W(ctx->r18, 0X0);
            goto L_8037FB44;
    }
    goto skip_1;
    // 0x8037F85C: lw          $s2, 0x0($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X0);
    skip_1:
    // 0x8037F860: lw          $t0, 0x0($s6)
    ctx->r8 = MEM_W(ctx->r22, 0X0);
    // 0x8037F864: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x8037F868: beql        $t0, $v0, L_8037FB44
    if (ctx->r8 == ctx->r2) {
        // 0x8037F86C: lw          $s2, 0x0($s2)
        ctx->r18 = MEM_W(ctx->r18, 0X0);
            goto L_8037FB44;
    }
    goto skip_2;
    // 0x8037F86C: lw          $s2, 0x0($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X0);
    skip_2:
    // 0x8037F870: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    // 0x8037F874: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    // 0x8037F878: sll         $s3, $s4, 1
    ctx->r19 = S32(ctx->r20 << 1);
    // 0x8037F87C: subu        $a2, $t1, $t9
    ctx->r6 = SUB32(ctx->r9, ctx->r25);
    // 0x8037F880: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8037F884: subu        $a3, $t2, $t6
    ctx->r7 = SUB32(ctx->r10, ctx->r14);
    // 0x8037F888: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8037F88C: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x8037F890: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8037F894: bgez        $t7, L_8037F8AC
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8037F898: sra         $a3, $t9, 16
        ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8037F8AC;
    }
    // 0x8037F898: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8037F89C: negu        $a0, $t7
    ctx->r4 = SUB32(0, ctx->r15);
    // 0x8037F8A0: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x8037F8A4: b           L_8037F8B8
    // 0x8037F8A8: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
        goto L_8037F8B8;
    // 0x8037F8A8: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
L_8037F8AC:
    // 0x8037F8AC: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
    // 0x8037F8B0: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8037F8B4: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_8037F8B8:
    // 0x8037F8B8: bgez        $a3, L_8037F8D0
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8037F8BC: sll         $v1, $a3, 16
        ctx->r3 = S32(ctx->r7 << 16);
            goto L_8037F8D0;
    }
    // 0x8037F8BC: sll         $v1, $a3, 16
    ctx->r3 = S32(ctx->r7 << 16);
    // 0x8037F8C0: negu        $v1, $a3
    ctx->r3 = SUB32(0, ctx->r7);
    // 0x8037F8C4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8037F8C8: b           L_8037F8D8
    // 0x8037F8CC: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
        goto L_8037F8D8;
    // 0x8037F8CC: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_8037F8D0:
    // 0x8037F8D0: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8037F8D4: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_8037F8D8:
    // 0x8037F8D8: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x8037F8DC: beq         $at, $zero, L_8037F8EC
    if (ctx->r1 == 0) {
        // 0x8037F8E0: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_8037F8EC;
    }
    // 0x8037F8E0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8037F8E4: b           L_8037F8EC
    // 0x8037F8E8: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_8037F8EC;
    // 0x8037F8E8: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_8037F8EC:
    // 0x8037F8EC: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8037F8F0: beq         $at, $zero, L_8037F900
    if (ctx->r1 == 0) {
        // 0x8037F8F4: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_8037F900;
    }
    // 0x8037F8F4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8037F8F8: b           L_8037F900
    // 0x8037F8FC: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
        goto L_8037F900;
    // 0x8037F8FC: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_8037F900:
    // 0x8037F900: lw          $a0, 0x16C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X16C);
    // 0x8037F904: sra         $t9, $v0, 1
    ctx->r25 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8037F908: addu        $v1, $t9, $a1
    ctx->r3 = ADD32(ctx->r25, ctx->r5);
    // 0x8037F90C: lw          $t7, 0x80($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X80);
    // 0x8037F910: sll         $s1, $v1, 16
    ctx->r17 = S32(ctx->r3 << 16);
    // 0x8037F914: sra         $t8, $s1, 16
    ctx->r24 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8037F918: sll         $t9, $t7, 18
    ctx->r25 = S32(ctx->r15 << 18);
    // 0x8037F91C: bgez        $t9, L_8037FB00
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8037F920: or          $s1, $t8, $zero
        ctx->r17 = ctx->r24 | 0;
            goto L_8037FB00;
    }
    // 0x8037F920: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x8037F924: lhu         $v0, 0x9C($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X9C);
    // 0x8037F928: beql        $s7, $v0, L_8037FB04
    if (ctx->r23 == ctx->r2) {
        // 0x8037F92C: slt         $at, $s1, $s3
        ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_8037FB04;
    }
    goto skip_3;
    // 0x8037F92C: slt         $at, $s1, $s3
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r19) ? 1 : 0;
    skip_3:
    // 0x8037F930: beq         $fp, $v0, L_8037FB00
    if (ctx->r30 == ctx->r2) {
        // 0x8037F934: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_8037FB00;
    }
    // 0x8037F934: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8037F938: beq         $v0, $at, L_8037FB00
    if (ctx->r2 == ctx->r1) {
        // 0x8037F93C: sll         $t8, $v1, 16
        ctx->r24 = S32(ctx->r3 << 16);
            goto L_8037FB00;
    }
    // 0x8037F93C: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8037F940: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8037F944: slt         $at, $t7, $s3
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8037F948: beql        $at, $zero, L_8037FB04
    if (ctx->r1 == 0) {
        // 0x8037F94C: slt         $at, $s1, $s3
        ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_8037FB04;
    }
    goto skip_4;
    // 0x8037F94C: slt         $at, $s1, $s3
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r19) ? 1 : 0;
    skip_4:
    // 0x8037F950: lh          $t6, 0xC($t0)
    ctx->r14 = MEM_H(ctx->r8, 0XC);
    // 0x8037F954: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x8037F958: subu        $v1, $t6, $t9
    ctx->r3 = SUB32(ctx->r14, ctx->r25);
    // 0x8037F95C: bgez        $v1, L_8037F96C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8037F960: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_8037F96C;
    }
    // 0x8037F960: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8037F964: b           L_8037F96C
    // 0x8037F968: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_8037F96C;
    // 0x8037F968: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_8037F96C:
    // 0x8037F96C: slt         $at, $v0, $s4
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8037F970: beq         $at, $zero, L_8037FB00
    if (ctx->r1 == 0) {
        // 0x8037F974: slt         $at, $s1, $s4
        ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
            goto L_8037FB00;
    }
    // 0x8037F974: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8037F978: beql        $at, $zero, L_8037FA8C
    if (ctx->r1 == 0) {
        // 0x8037F97C: sll         $t9, $a2, 15
        ctx->r25 = S32(ctx->r6 << 15);
            goto L_8037FA8C;
    }
    goto skip_5;
    // 0x8037F97C: sll         $t9, $a2, 15
    ctx->r25 = S32(ctx->r6 << 15);
    skip_5:
    // 0x8037F980: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x8037F984: div         $zero, $t7, $s1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r17))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r17)));
    // 0x8037F988: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x8037F98C: mflo        $t6
    ctx->r14 = lo;
    // 0x8037F990: sll         $a1, $s5, 16
    ctx->r5 = S32(ctx->r21 << 16);
    // 0x8037F994: subu        $t9, $t8, $t6
    ctx->r25 = SUB32(ctx->r24, ctx->r14);
    // 0x8037F998: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x8037F99C: div         $zero, $t8, $s1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r17))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r17)));
    // 0x8037F9A0: bne         $s1, $zero, L_8037F9AC
    if (ctx->r17 != 0) {
        // 0x8037F9A4: nop
    
            goto L_8037F9AC;
    }
    // 0x8037F9A4: nop

    // 0x8037F9A8: break       7
    do_break(2151152040);
L_8037F9AC:
    // 0x8037F9AC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037F9B0: bne         $s1, $at, L_8037F9C4
    if (ctx->r17 != ctx->r1) {
        // 0x8037F9B4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037F9C4;
    }
    // 0x8037F9B4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037F9B8: bne         $t7, $at, L_8037F9C4
    if (ctx->r15 != ctx->r1) {
        // 0x8037F9BC: nop
    
            goto L_8037F9C4;
    }
    // 0x8037F9BC: nop

    // 0x8037F9C0: break       6
    do_break(2151152064);
L_8037F9C4:
    // 0x8037F9C4: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x8037F9C8: sw          $t9, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r25;
    // 0x8037F9CC: mflo        $t6
    ctx->r14 = lo;
    // 0x8037F9D0: subu        $t9, $t7, $t6
    ctx->r25 = SUB32(ctx->r15, ctx->r14);
    // 0x8037F9D4: bne         $s1, $zero, L_8037F9E0
    if (ctx->r17 != 0) {
        // 0x8037F9D8: nop
    
            goto L_8037F9E0;
    }
    // 0x8037F9D8: nop

    // 0x8037F9DC: break       7
    do_break(2151152092);
L_8037F9E0:
    // 0x8037F9E0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037F9E4: bne         $s1, $at, L_8037F9F8
    if (ctx->r17 != ctx->r1) {
        // 0x8037F9E8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037F9F8;
    }
    // 0x8037F9E8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037F9EC: bne         $t8, $at, L_8037F9F8
    if (ctx->r24 != ctx->r1) {
        // 0x8037F9F0: nop
    
            goto L_8037F9F8;
    }
    // 0x8037F9F0: nop

    // 0x8037F9F4: break       6
    do_break(2151152116);
L_8037F9F8:
    // 0x8037F9F8: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
    // 0x8037F9FC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8037FA00: lhu         $t8, 0x5544($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X5544);
    // 0x8037FA04: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8037FA08: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x8037FA0C: andi        $t7, $t8, 0x3
    ctx->r15 = ctx->r24 & 0X3;
    // 0x8037FA10: bne         $t7, $zero, L_8037FB00
    if (ctx->r15 != 0) {
        // 0x8037FA14: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_8037FB00;
    }
    // 0x8037FA14: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8037FA18: lh          $t6, 0x14C($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X14C);
    // 0x8037FA1C: subu        $v0, $t6, $s5
    ctx->r2 = SUB32(ctx->r14, ctx->r21);
    // 0x8037FA20: blezl       $v0, L_8037FA34
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8037FA24: sh          $zero, 0x14C($s0)
        MEM_H(0X14C, ctx->r16) = 0;
            goto L_8037FA34;
    }
    goto skip_6;
    // 0x8037FA24: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    skip_6:
    // 0x8037FA28: b           L_8037FA34
    // 0x8037FA2C: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
        goto L_8037FA34;
    // 0x8037FA2C: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
    // 0x8037FA30: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
L_8037FA34:
    // 0x8037FA34: sh          $t1, 0x8C($sp)
    MEM_H(0X8C, ctx->r29) = ctx->r9;
    // 0x8037FA38: jal         0x80349280
    // 0x8037FA3C: sh          $t2, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r10;
    func_80349280_75A930(rdram, ctx);
        goto after_0;
    // 0x8037FA3C: sh          $t2, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r10;
    after_0:
    // 0x8037FA40: lh          $v0, 0x348($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X348);
    // 0x8037FA44: lh          $t1, 0x8C($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X8C);
    // 0x8037FA48: lh          $t2, 0x8A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X8A);
    // 0x8037FA4C: slti        $at, $v0, 0x64
    ctx->r1 = SIGNED(ctx->r2) < 0X64 ? 1 : 0;
    // 0x8037FA50: beq         $at, $zero, L_8037FA60
    if (ctx->r1 == 0) {
        // 0x8037FA54: addiu       $t8, $zero, 0x64
        ctx->r24 = ADD32(0, 0X64);
            goto L_8037FA60;
    }
    // 0x8037FA54: addiu       $t8, $zero, 0x64
    ctx->r24 = ADD32(0, 0X64);
    // 0x8037FA58: b           L_8037FA64
    // 0x8037FA5C: sh          $t8, 0x348($s0)
    MEM_H(0X348, ctx->r16) = ctx->r24;
        goto L_8037FA64;
    // 0x8037FA5C: sh          $t8, 0x348($s0)
    MEM_H(0X348, ctx->r16) = ctx->r24;
L_8037FA60:
    // 0x8037FA60: sh          $v0, 0x348($s0)
    MEM_H(0X348, ctx->r16) = ctx->r2;
L_8037FA64:
    // 0x8037FA64: lh          $v0, 0x34A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X34A);
    // 0x8037FA68: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x8037FA6C: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    // 0x8037FA70: beq         $at, $zero, L_8037FA80
    if (ctx->r1 == 0) {
        // 0x8037FA74: nop
    
            goto L_8037FA80;
    }
    // 0x8037FA74: nop

    // 0x8037FA78: b           L_8037FB00
    // 0x8037FA7C: sh          $t7, 0x34A($s0)
    MEM_H(0X34A, ctx->r16) = ctx->r15;
        goto L_8037FB00;
    // 0x8037FA7C: sh          $t7, 0x34A($s0)
    MEM_H(0X34A, ctx->r16) = ctx->r15;
L_8037FA80:
    // 0x8037FA80: b           L_8037FB00
    // 0x8037FA84: sh          $v0, 0x34A($s0)
    MEM_H(0X34A, ctx->r16) = ctx->r2;
        goto L_8037FB00;
    // 0x8037FA84: sh          $v0, 0x34A($s0)
    MEM_H(0X34A, ctx->r16) = ctx->r2;
    // 0x8037FA88: sll         $t9, $a2, 15
    ctx->r25 = S32(ctx->r6 << 15);
L_8037FA8C:
    // 0x8037FA8C: div         $zero, $t9, $s1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r17))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r17)));
    // 0x8037FA90: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x8037FA94: mflo        $t8
    ctx->r24 = lo;
    // 0x8037FA98: subu        $t7, $t6, $t8
    ctx->r15 = SUB32(ctx->r14, ctx->r24);
    // 0x8037FA9C: sll         $t6, $a3, 15
    ctx->r14 = S32(ctx->r7 << 15);
    // 0x8037FAA0: div         $zero, $t6, $s1
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r17))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r17)));
    // 0x8037FAA4: bne         $s1, $zero, L_8037FAB0
    if (ctx->r17 != 0) {
        // 0x8037FAA8: nop
    
            goto L_8037FAB0;
    }
    // 0x8037FAA8: nop

    // 0x8037FAAC: break       7
    do_break(2151152300);
L_8037FAB0:
    // 0x8037FAB0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037FAB4: bne         $s1, $at, L_8037FAC8
    if (ctx->r17 != ctx->r1) {
        // 0x8037FAB8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037FAC8;
    }
    // 0x8037FAB8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037FABC: bne         $t9, $at, L_8037FAC8
    if (ctx->r25 != ctx->r1) {
        // 0x8037FAC0: nop
    
            goto L_8037FAC8;
    }
    // 0x8037FAC0: nop

    // 0x8037FAC4: break       6
    do_break(2151152324);
L_8037FAC8:
    // 0x8037FAC8: lw          $t9, 0x20($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X20);
    // 0x8037FACC: sw          $t7, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r15;
    // 0x8037FAD0: mflo        $t8
    ctx->r24 = lo;
    // 0x8037FAD4: subu        $t7, $t9, $t8
    ctx->r15 = SUB32(ctx->r25, ctx->r24);
    // 0x8037FAD8: sw          $t7, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r15;
    // 0x8037FADC: bne         $s1, $zero, L_8037FAE8
    if (ctx->r17 != 0) {
        // 0x8037FAE0: nop
    
            goto L_8037FAE8;
    }
    // 0x8037FAE0: nop

    // 0x8037FAE4: break       7
    do_break(2151152356);
L_8037FAE8:
    // 0x8037FAE8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037FAEC: bne         $s1, $at, L_8037FB00
    if (ctx->r17 != ctx->r1) {
        // 0x8037FAF0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037FB00;
    }
    // 0x8037FAF0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037FAF4: bne         $t6, $at, L_8037FB00
    if (ctx->r14 != ctx->r1) {
        // 0x8037FAF8: nop
    
            goto L_8037FB00;
    }
    // 0x8037FAF8: nop

    // 0x8037FAFC: break       6
    do_break(2151152380);
L_8037FB00:
    // 0x8037FB00: slt         $at, $s1, $s3
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r19) ? 1 : 0;
L_8037FB04:
    // 0x8037FB04: beql        $at, $zero, L_8037FB44
    if (ctx->r1 == 0) {
        // 0x8037FB08: lw          $s2, 0x0($s2)
        ctx->r18 = MEM_W(ctx->r18, 0X0);
            goto L_8037FB44;
    }
    goto skip_7;
    // 0x8037FB08: lw          $s2, 0x0($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X0);
    skip_7:
    // 0x8037FB0C: lw          $t6, 0x0($s6)
    ctx->r14 = MEM_W(ctx->r22, 0X0);
    // 0x8037FB10: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x8037FB14: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x8037FB18: lh          $t9, 0xC($t6)
    ctx->r25 = MEM_H(ctx->r14, 0XC);
    // 0x8037FB1C: subu        $v1, $t9, $t8
    ctx->r3 = SUB32(ctx->r25, ctx->r24);
    // 0x8037FB20: bgez        $v1, L_8037FB30
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8037FB24: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_8037FB30;
    }
    // 0x8037FB24: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8037FB28: b           L_8037FB30
    // 0x8037FB2C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_8037FB30;
    // 0x8037FB2C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_8037FB30:
    // 0x8037FB30: slt         $at, $v0, $s4
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8037FB34: beql        $at, $zero, L_8037FB44
    if (ctx->r1 == 0) {
        // 0x8037FB38: lw          $s2, 0x0($s2)
        ctx->r18 = MEM_W(ctx->r18, 0X0);
            goto L_8037FB44;
    }
    goto skip_8;
    // 0x8037FB38: lw          $s2, 0x0($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X0);
    skip_8:
    // 0x8037FB3C: sb          $t7, 0x57($s0)
    MEM_B(0X57, ctx->r16) = ctx->r15;
    // 0x8037FB40: lw          $s2, 0x0($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X0);
L_8037FB44:
    // 0x8037FB44: bnel        $s2, $zero, L_8037F854
    if (ctx->r18 != 0) {
        // 0x8037FB48: lw          $v0, 0x8($s2)
        ctx->r2 = MEM_W(ctx->r18, 0X8);
            goto L_8037F854;
    }
    goto skip_9;
    // 0x8037FB48: lw          $v0, 0x8($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X8);
    skip_9:
    // 0x8037FB4C: lh          $t6, 0x98($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X98);
L_8037FB50:
    // 0x8037FB50: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    // 0x8037FB54: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x8037FB58: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8037FB5C: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8037FB60: slt         $at, $t8, $t6
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x8037FB64: beq         $at, $zero, L_8037F814
    if (ctx->r1 == 0) {
        // 0x8037FB68: sh          $t9, 0x98($sp)
        MEM_H(0X98, ctx->r29) = ctx->r25;
            goto L_8037F814;
    }
    // 0x8037FB68: sh          $t9, 0x98($sp)
    MEM_H(0X98, ctx->r29) = ctx->r25;
L_8037FB6C:
    // 0x8037FB6C: lh          $t9, 0x9A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X9A);
    // 0x8037FB70: lw          $t8, 0x60($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X60);
    // 0x8037FB74: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x8037FB78: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x8037FB7C: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8037FB80: slt         $at, $t8, $t9
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8037FB84: beq         $at, $zero, L_8037F7EC
    if (ctx->r1 == 0) {
        // 0x8037FB88: sh          $t7, 0x9A($sp)
        MEM_H(0X9A, ctx->r29) = ctx->r15;
            goto L_8037F7EC;
    }
    // 0x8037FB88: sh          $t7, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r15;
L_8037FB8C:
    // 0x8037FB8C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8037FB90: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8037FB94: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8037FB98: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8037FB9C: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8037FBA0: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8037FBA4: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8037FBA8: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8037FBAC: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x8037FBB0: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x8037FBB4: jr          $ra
    // 0x8037FBB8: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
    return;
    // 0x8037FBB8: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
;}
RECOMP_FUNC void get_missile_side(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037FBBC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8037FBC0: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x8037FBC4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8037FBC8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8037FBCC: lhu         $v0, 0x9C($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9C);
    // 0x8037FBD0: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x8037FBD4: beq         $v0, $at, L_8037FC08
    if (ctx->r2 == ctx->r1) {
        // 0x8037FBD8: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_8037FC08;
    }
    // 0x8037FBD8: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x8037FBDC: beq         $v0, $at, L_8037FC8C
    if (ctx->r2 == ctx->r1) {
        // 0x8037FBE0: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_8037FC8C;
    }
    // 0x8037FBE0: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x8037FBE4: beq         $v0, $at, L_8037FC08
    if (ctx->r2 == ctx->r1) {
        // 0x8037FBE8: addiu       $at, $zero, 0x2C
        ctx->r1 = ADD32(0, 0X2C);
            goto L_8037FC08;
    }
    // 0x8037FBE8: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x8037FBEC: beq         $v0, $at, L_8037FC08
    if (ctx->r2 == ctx->r1) {
        // 0x8037FBF0: addiu       $at, $zero, 0x3A
        ctx->r1 = ADD32(0, 0X3A);
            goto L_8037FC08;
    }
    // 0x8037FBF0: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x8037FBF4: beql        $v0, $at, L_8037FC0C
    if (ctx->r2 == ctx->r1) {
        // 0x8037FBF8: lw          $v0, 0x0($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X0);
            goto L_8037FC0C;
    }
    goto skip_0;
    // 0x8037FBF8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    skip_0:
    // 0x8037FBFC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8037FC00: b           L_8037FC9C
    // 0x8037FC04: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
        goto L_8037FC9C;
    // 0x8037FC04: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
L_8037FC08:
    // 0x8037FC08: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
L_8037FC0C:
    // 0x8037FC0C: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x8037FC10: lbu         $v1, 0x2E8($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FC14: bnel        $a1, $v1, L_8037FC5C
    if (ctx->r5 != ctx->r3) {
        // 0x8037FC18: lbu         $t2, 0x2E9($v0)
        ctx->r10 = MEM_BU(ctx->r2, 0X2E9);
            goto L_8037FC5C;
    }
    goto skip_1;
    // 0x8037FC18: lbu         $t2, 0x2E9($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2E9);
    skip_1:
    // 0x8037FC1C: lbu         $t7, 0x2E9($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2E9);
    // 0x8037FC20: bnel        $a1, $t7, L_8037FC5C
    if (ctx->r5 != ctx->r15) {
        // 0x8037FC24: lbu         $t2, 0x2E9($v0)
        ctx->r10 = MEM_BU(ctx->r2, 0X2E9);
            goto L_8037FC5C;
    }
    goto skip_2;
    // 0x8037FC24: lbu         $t2, 0x2E9($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2E9);
    skip_2:
    // 0x8037FC28: lbu         $t8, 0x2EA($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2EA);
    // 0x8037FC2C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x8037FC30: beql        $t8, $zero, L_8037FC4C
    if (ctx->r24 == 0) {
        // 0x8037FC34: sb          $t0, 0x2EA($v0)
        MEM_B(0X2EA, ctx->r2) = ctx->r8;
            goto L_8037FC4C;
    }
    goto skip_3;
    // 0x8037FC34: sb          $t0, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = ctx->r8;
    skip_3:
    // 0x8037FC38: sb          $zero, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = 0;
    // 0x8037FC3C: lw          $t9, 0x0($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X0);
    // 0x8037FC40: b           L_8037FC9C
    // 0x8037FC44: sb          $zero, 0x2E8($t9)
    MEM_B(0X2E8, ctx->r25) = 0;
        goto L_8037FC9C;
    // 0x8037FC44: sb          $zero, 0x2E8($t9)
    MEM_B(0X2E8, ctx->r25) = 0;
    // 0x8037FC48: sb          $t0, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = ctx->r8;
L_8037FC4C:
    // 0x8037FC4C: lw          $t1, 0x0($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X0);
    // 0x8037FC50: b           L_8037FC9C
    // 0x8037FC54: sb          $zero, 0x2E9($t1)
    MEM_B(0X2E9, ctx->r9) = 0;
        goto L_8037FC9C;
    // 0x8037FC54: sb          $zero, 0x2E9($t1)
    MEM_B(0X2E9, ctx->r9) = 0;
    // 0x8037FC58: lbu         $t2, 0x2E9($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2E9);
L_8037FC5C:
    // 0x8037FC5C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8037FC60: slt         $at, $t2, $v1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8037FC64: beql        $at, $zero, L_8037FC80
    if (ctx->r1 == 0) {
        // 0x8037FC68: sb          $t4, 0x2EA($v0)
        MEM_B(0X2EA, ctx->r2) = ctx->r12;
            goto L_8037FC80;
    }
    goto skip_4;
    // 0x8037FC68: sb          $t4, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = ctx->r12;
    skip_4:
    // 0x8037FC6C: sb          $zero, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = 0;
    // 0x8037FC70: lw          $t3, 0x0($a0)
    ctx->r11 = MEM_W(ctx->r4, 0X0);
    // 0x8037FC74: b           L_8037FC9C
    // 0x8037FC78: sb          $zero, 0x2E8($t3)
    MEM_B(0X2E8, ctx->r11) = 0;
        goto L_8037FC9C;
    // 0x8037FC78: sb          $zero, 0x2E8($t3)
    MEM_B(0X2E8, ctx->r11) = 0;
    // 0x8037FC7C: sb          $t4, 0x2EA($v0)
    MEM_B(0X2EA, ctx->r2) = ctx->r12;
L_8037FC80:
    // 0x8037FC80: lw          $t5, 0x0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X0);
    // 0x8037FC84: b           L_8037FC9C
    // 0x8037FC88: sb          $zero, 0x2E9($t5)
    MEM_B(0X2E9, ctx->r13) = 0;
        goto L_8037FC9C;
    // 0x8037FC88: sb          $zero, 0x2E9($t5)
    MEM_B(0X2E9, ctx->r13) = 0;
L_8037FC8C:
    // 0x8037FC8C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8037FC90: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x8037FC94: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x8037FC98: sb          $zero, 0x2E8($t6)
    MEM_B(0X2E8, ctx->r14) = 0;
L_8037FC9C:
    // 0x8037FC9C: lw          $t7, 0x0($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X0);
    // 0x8037FCA0: jr          $ra
    // 0x8037FCA4: lbu         $v0, 0x2EA($t7)
    ctx->r2 = MEM_BU(ctx->r15, 0X2EA);
    return;
    // 0x8037FCA4: lbu         $v0, 0x2EA($t7)
    ctx->r2 = MEM_BU(ctx->r15, 0X2EA);
;}
RECOMP_FUNC void func_8037FCA8_791358(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037FCA8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FCAC: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8037FCB0: lbu         $v1, 0x2E8($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FCB4: beq         $v1, $zero, L_8037FCE4
    if (ctx->r3 == 0) {
        // 0x8037FCB8: addiu       $a0, $v1, 0x1
        ctx->r4 = ADD32(ctx->r3, 0X1);
            goto L_8037FCE4;
    }
    // 0x8037FCB8: addiu       $a0, $v1, 0x1
    ctx->r4 = ADD32(ctx->r3, 0X1);
    // 0x8037FCBC: slti        $at, $a0, 0x8
    ctx->r1 = SIGNED(ctx->r4) < 0X8 ? 1 : 0;
    // 0x8037FCC0: beq         $at, $zero, L_8037FCD8
    if (ctx->r1 == 0) {
        // 0x8037FCC4: addiu       $t6, $zero, 0x8
        ctx->r14 = ADD32(0, 0X8);
            goto L_8037FCD8;
    }
    // 0x8037FCC4: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    // 0x8037FCC8: sb          $a0, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r4;
    // 0x8037FCCC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FCD0: b           L_8037FCE4
    // 0x8037FCD4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8037FCE4;
    // 0x8037FCD4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8037FCD8:
    // 0x8037FCD8: sb          $t6, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r14;
    // 0x8037FCDC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FCE0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8037FCE4:
    // 0x8037FCE4: lbu         $v1, 0x2E9($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E9);
    // 0x8037FCE8: beq         $v1, $zero, L_8037FD1C
    if (ctx->r3 == 0) {
        // 0x8037FCEC: addiu       $a0, $v1, 0x1
        ctx->r4 = ADD32(ctx->r3, 0X1);
            goto L_8037FD1C;
    }
    // 0x8037FCEC: addiu       $a0, $v1, 0x1
    ctx->r4 = ADD32(ctx->r3, 0X1);
    // 0x8037FCF0: slti        $at, $a0, 0x8
    ctx->r1 = SIGNED(ctx->r4) < 0X8 ? 1 : 0;
    // 0x8037FCF4: beql        $at, $zero, L_8037FD10
    if (ctx->r1 == 0) {
        // 0x8037FCF8: addiu       $t7, $zero, 0x8
        ctx->r15 = ADD32(0, 0X8);
            goto L_8037FD10;
    }
    goto skip_0;
    // 0x8037FCF8: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    skip_0:
    // 0x8037FCFC: sb          $a0, 0x2E9($v0)
    MEM_B(0X2E9, ctx->r2) = ctx->r4;
    // 0x8037FD00: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FD04: b           L_8037FD1C
    // 0x8037FD08: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8037FD1C;
    // 0x8037FD08: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8037FD0C: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
L_8037FD10:
    // 0x8037FD10: sb          $t7, 0x2E9($v0)
    MEM_B(0X2E9, ctx->r2) = ctx->r15;
    // 0x8037FD14: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FD18: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8037FD1C:
    // 0x8037FD1C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8037FD20: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x8037FD24: addiu       $at, $zero, 0x27
    ctx->r1 = ADD32(0, 0X27);
    // 0x8037FD28: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8037FD2C: lhu         $t8, 0x9C($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X9C);
    // 0x8037FD30: bne         $t8, $at, L_8037FD40
    if (ctx->r24 != ctx->r1) {
        // 0x8037FD34: nop
    
            goto L_8037FD40;
    }
    // 0x8037FD34: nop

    // 0x8037FD38: b           L_8037FD40
    // 0x8037FD3C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
        goto L_8037FD40;
    // 0x8037FD3C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_8037FD40:
    // 0x8037FD40: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x8037FD44: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x8037FD48: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x8037FD4C: addu        $a2, $v1, $t9
    ctx->r6 = ADD32(ctx->r3, ctx->r25);
    // 0x8037FD50: sll         $t0, $a0, 2
    ctx->r8 = S32(ctx->r4 << 2);
    // 0x8037FD54: lh          $t3, 0xDC($a2)
    ctx->r11 = MEM_H(ctx->r6, 0XDC);
    // 0x8037FD58: addu        $t1, $v0, $t0
    ctx->r9 = ADD32(ctx->r2, ctx->r8);
    // 0x8037FD5C: lh          $t2, 0x2E0($t1)
    ctx->r10 = MEM_H(ctx->r9, 0X2E0);
    // 0x8037FD60: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x8037FD64: lh          $t6, 0xDA($a2)
    ctx->r14 = MEM_H(ctx->r6, 0XDA);
    // 0x8037FD68: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x8037FD6C: div         $zero, $t5, $t6
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r14))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r14)));
    // 0x8037FD70: bne         $t6, $zero, L_8037FD7C
    if (ctx->r14 != 0) {
        // 0x8037FD74: nop
    
            goto L_8037FD7C;
    }
    // 0x8037FD74: nop

    // 0x8037FD78: break       7
    do_break(2151153016);
L_8037FD7C:
    // 0x8037FD7C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037FD80: bne         $t6, $at, L_8037FD94
    if (ctx->r14 != ctx->r1) {
        // 0x8037FD84: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037FD94;
    }
    // 0x8037FD84: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037FD88: bne         $t5, $at, L_8037FD94
    if (ctx->r13 != ctx->r1) {
        // 0x8037FD8C: nop
    
            goto L_8037FD94;
    }
    // 0x8037FD8C: nop

    // 0x8037FD90: break       6
    do_break(2151153040);
L_8037FD94:
    // 0x8037FD94: mflo        $a1
    ctx->r5 = lo;
    // 0x8037FD98: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x8037FD9C: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8037FDA0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8037FDA4: bne         $t8, $at, L_8037FDE8
    if (ctx->r24 != ctx->r1) {
        // 0x8037FDA8: or          $a1, $t8, $zero
        ctx->r5 = ctx->r24 | 0;
            goto L_8037FDE8;
    }
    // 0x8037FDA8: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x8037FDAC: lbu         $t9, 0x2E8($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FDB0: bne         $t9, $zero, L_8037FE1C
    if (ctx->r25 != 0) {
        // 0x8037FDB4: nop
    
            goto L_8037FE1C;
    }
    // 0x8037FDB4: nop

    // 0x8037FDB8: lbu         $t0, 0x2E9($v0)
    ctx->r8 = MEM_BU(ctx->r2, 0X2E9);
    // 0x8037FDBC: bne         $t0, $zero, L_8037FE1C
    if (ctx->r8 != 0) {
        // 0x8037FDC0: nop
    
            goto L_8037FE1C;
    }
    // 0x8037FDC0: nop

    // 0x8037FDC4: lbu         $t1, 0x2EA($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2EA);
    // 0x8037FDC8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8037FDCC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8037FDD0: bne         $t1, $zero, L_8037FDE0
    if (ctx->r9 != 0) {
        // 0x8037FDD4: nop
    
            goto L_8037FDE0;
    }
    // 0x8037FDD4: nop

    // 0x8037FDD8: jr          $ra
    // 0x8037FDDC: sb          $t3, 0x2E9($v0)
    MEM_B(0X2E9, ctx->r2) = ctx->r11;
    return;
    // 0x8037FDDC: sb          $t3, 0x2E9($v0)
    MEM_B(0X2E9, ctx->r2) = ctx->r11;
L_8037FDE0:
    // 0x8037FDE0: jr          $ra
    // 0x8037FDE4: sb          $t2, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r10;
    return;
    // 0x8037FDE4: sb          $t2, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r10;
L_8037FDE8:
    // 0x8037FDE8: slti        $at, $a1, 0x2
    ctx->r1 = SIGNED(ctx->r5) < 0X2 ? 1 : 0;
    // 0x8037FDEC: bne         $at, $zero, L_8037FE1C
    if (ctx->r1 != 0) {
        // 0x8037FDF0: nop
    
            goto L_8037FE1C;
    }
    // 0x8037FDF0: nop

    // 0x8037FDF4: lbu         $v1, 0x2E8($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FDF8: bne         $v1, $zero, L_8037FE0C
    if (ctx->r3 != 0) {
        // 0x8037FDFC: addiu       $t4, $v1, 0x1
        ctx->r12 = ADD32(ctx->r3, 0X1);
            goto L_8037FE0C;
    }
    // 0x8037FDFC: addiu       $t4, $v1, 0x1
    ctx->r12 = ADD32(ctx->r3, 0X1);
    // 0x8037FE00: sb          $t4, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r12;
    // 0x8037FE04: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FE08: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8037FE0C:
    // 0x8037FE0C: lbu         $v1, 0x2E9($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E9);
    // 0x8037FE10: bne         $v1, $zero, L_8037FE1C
    if (ctx->r3 != 0) {
        // 0x8037FE14: addiu       $t5, $v1, 0x1
        ctx->r13 = ADD32(ctx->r3, 0X1);
            goto L_8037FE1C;
    }
    // 0x8037FE14: addiu       $t5, $v1, 0x1
    ctx->r13 = ADD32(ctx->r3, 0X1);
    // 0x8037FE18: sb          $t5, 0x2E9($v0)
    MEM_B(0X2E9, ctx->r2) = ctx->r13;
L_8037FE1C:
    // 0x8037FE1C: jr          $ra
    // 0x8037FE20: nop

    return;
    // 0x8037FE20: nop

;}
RECOMP_FUNC void func_8037FE24_7914D4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037FE24: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FE28: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8037FE2C: lbu         $v1, 0x2E8($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FE30: beq         $v1, $zero, L_8037FE64
    if (ctx->r3 == 0) {
        // 0x8037FE34: addiu       $a0, $v1, 0x1
        ctx->r4 = ADD32(ctx->r3, 0X1);
            goto L_8037FE64;
    }
    // 0x8037FE34: addiu       $a0, $v1, 0x1
    ctx->r4 = ADD32(ctx->r3, 0X1);
    // 0x8037FE38: slti        $at, $a0, 0x8
    ctx->r1 = SIGNED(ctx->r4) < 0X8 ? 1 : 0;
    // 0x8037FE3C: beql        $at, $zero, L_8037FE58
    if (ctx->r1 == 0) {
        // 0x8037FE40: addiu       $t6, $zero, 0x8
        ctx->r14 = ADD32(0, 0X8);
            goto L_8037FE58;
    }
    goto skip_0;
    // 0x8037FE40: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    skip_0:
    // 0x8037FE44: sb          $a0, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r4;
    // 0x8037FE48: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FE4C: b           L_8037FE64
    // 0x8037FE50: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8037FE64;
    // 0x8037FE50: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8037FE54: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
L_8037FE58:
    // 0x8037FE58: sb          $t6, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r14;
    // 0x8037FE5C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8037FE60: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8037FE64:
    // 0x8037FE64: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8037FE68: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
    // 0x8037FE6C: lh          $t7, 0x2E4($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2E4);
    // 0x8037FE70: lh          $t8, 0xE2($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XE2);
    // 0x8037FE74: lh          $t1, 0xE0($a0)
    ctx->r9 = MEM_H(ctx->r4, 0XE0);
    // 0x8037FE78: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x8037FE7C: addu        $t0, $t7, $t9
    ctx->r8 = ADD32(ctx->r15, ctx->r25);
    // 0x8037FE80: div         $zero, $t0, $t1
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r9))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r9)));
    // 0x8037FE84: mflo        $v1
    ctx->r3 = lo;
    // 0x8037FE88: sll         $t2, $v1, 16
    ctx->r10 = S32(ctx->r3 << 16);
    // 0x8037FE8C: sra         $t3, $t2, 16
    ctx->r11 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8037FE90: bne         $t1, $zero, L_8037FE9C
    if (ctx->r9 != 0) {
        // 0x8037FE94: nop
    
            goto L_8037FE9C;
    }
    // 0x8037FE94: nop

    // 0x8037FE98: break       7
    do_break(2151153304);
L_8037FE9C:
    // 0x8037FE9C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8037FEA0: bne         $t1, $at, L_8037FEB4
    if (ctx->r9 != ctx->r1) {
        // 0x8037FEA4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8037FEB4;
    }
    // 0x8037FEA4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8037FEA8: bne         $t0, $at, L_8037FEB4
    if (ctx->r8 != ctx->r1) {
        // 0x8037FEAC: nop
    
            goto L_8037FEB4;
    }
    // 0x8037FEAC: nop

    // 0x8037FEB0: break       6
    do_break(2151153328);
L_8037FEB4:
    // 0x8037FEB4: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
    // 0x8037FEB8: blez        $t3, L_8037FED4
    if (SIGNED(ctx->r11) <= 0) {
        // 0x8037FEBC: nop
    
            goto L_8037FED4;
    }
    // 0x8037FEBC: nop

    // 0x8037FEC0: lbu         $t4, 0x2E8($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2E8);
    // 0x8037FEC4: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8037FEC8: bne         $t4, $zero, L_8037FED4
    if (ctx->r12 != 0) {
        // 0x8037FECC: nop
    
            goto L_8037FED4;
    }
    // 0x8037FECC: nop

    // 0x8037FED0: sb          $t5, 0x2E8($v0)
    MEM_B(0X2E8, ctx->r2) = ctx->r13;
L_8037FED4:
    // 0x8037FED4: jr          $ra
    // 0x8037FED8: nop

    return;
    // 0x8037FED8: nop

;}
RECOMP_FUNC void sheep_follow_leader(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8037FEDC: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x8037FEE0: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8037FEE4: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x8037FEE8: addiu       $s1, $s1, 0x5530
    ctx->r17 = ADD32(ctx->r17, 0X5530);
    // 0x8037FEEC: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8037FEF0: sw          $ra, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r31;
    // 0x8037FEF4: sw          $fp, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r30;
    // 0x8037FEF8: sw          $s7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r23;
    // 0x8037FEFC: sw          $s6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r22;
    // 0x8037FF00: sw          $s5, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r21;
    // 0x8037FF04: sw          $s4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r20;
    // 0x8037FF08: sw          $s3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r19;
    // 0x8037FF0C: sw          $s2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r18;
    // 0x8037FF10: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x8037FF14: lh          $t6, 0x8($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X8);
    // 0x8037FF18: lh          $a3, 0x4($t0)
    ctx->r7 = MEM_H(ctx->r8, 0X4);
    // 0x8037FF1C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8037FF20: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8037FF24: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8037FF28: lh          $t7, 0xC($t0)
    ctx->r15 = MEM_H(ctx->r8, 0XC);
    // 0x8037FF2C: addiu       $a0, $zero, 0x6A
    ctx->r4 = ADD32(0, 0X6A);
    // 0x8037FF30: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8037FF34: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8037FF38: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8037FF3C: jal         0x8032C360
    // 0x8037FF40: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8037FF40: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_0:
    // 0x8037FF44: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8037FF48: lh          $a0, 0x553E($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X553E);
    // 0x8037FF4C: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x8037FF50: addiu       $s7, $s7, 0x552C
    ctx->r23 = ADD32(ctx->r23, 0X552C);
    // 0x8037FF54: blez        $a0, L_8038009C
    if (SIGNED(ctx->r4) <= 0) {
        // 0x8037FF58: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_8038009C;
    }
    // 0x8037FF58: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8037FF5C: lui         $s2, 0x801E
    ctx->r18 = S32(0X801E << 16);
    // 0x8037FF60: addiu       $s2, $s2, -0x6128
    ctx->r18 = ADD32(ctx->r18, -0X6128);
    // 0x8037FF64: addiu       $fp, $zero, 0x1
    ctx->r30 = ADD32(0, 0X1);
    // 0x8037FF68: addiu       $s6, $zero, 0x23
    ctx->r22 = ADD32(0, 0X23);
    // 0x8037FF6C: addiu       $s5, $zero, 0x21
    ctx->r21 = ADD32(0, 0X21);
    // 0x8037FF70: addiu       $s4, $zero, 0x6
    ctx->r20 = ADD32(0, 0X6);
    // 0x8037FF74: addiu       $s3, $zero, 0x3E
    ctx->r19 = ADD32(0, 0X3E);
    // 0x8037FF78: sll         $t8, $s0, 3
    ctx->r24 = S32(ctx->r16 << 3);
L_8037FF7C:
    // 0x8037FF7C: addu        $t1, $s2, $t8
    ctx->r9 = ADD32(ctx->r18, ctx->r24);
    // 0x8037FF80: lw          $v1, 0x3EB4($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X3EB4);
    // 0x8037FF84: beql        $v1, $zero, L_80380088
    if (ctx->r3 == 0) {
        // 0x8037FF88: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_0;
    // 0x8037FF88: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x8037FF8C: lw          $t9, 0x3EB0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X3EB0);
    // 0x8037FF90: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
    // 0x8037FF94: beql        $s3, $v0, L_80380088
    if (ctx->r19 == ctx->r2) {
        // 0x8037FF98: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_1;
    // 0x8037FF98: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_1:
    // 0x8037FF9C: lbu         $t2, 0x366($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X366);
    // 0x8037FFA0: beql        $s4, $t2, L_80380088
    if (ctx->r20 == ctx->r10) {
        // 0x8037FFA4: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_2;
    // 0x8037FFA4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_2:
    // 0x8037FFA8: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8037FFAC: beql        $t0, $v1, L_80380088
    if (ctx->r8 == ctx->r3) {
        // 0x8037FFB0: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_3;
    // 0x8037FFB0: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_3:
    // 0x8037FFB4: lbu         $t3, 0x2A0($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X2A0);
    // 0x8037FFB8: bnel        $t3, $zero, L_80380088
    if (ctx->r11 != 0) {
        // 0x8037FFBC: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_4;
    // 0x8037FFBC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_4:
    // 0x8037FFC0: beql        $s5, $v0, L_8037FFD4
    if (ctx->r21 == ctx->r2) {
        // 0x8037FFC4: lh          $t4, 0x4($v1)
        ctx->r12 = MEM_H(ctx->r3, 0X4);
            goto L_8037FFD4;
    }
    goto skip_5;
    // 0x8037FFC4: lh          $t4, 0x4($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X4);
    skip_5:
    // 0x8037FFC8: bnel        $s6, $v0, L_80380088
    if (ctx->r22 != ctx->r2) {
        // 0x8037FFCC: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_6;
    // 0x8037FFCC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_6:
    // 0x8037FFD0: lh          $t4, 0x4($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X4);
L_8037FFD4:
    // 0x8037FFD4: lh          $t5, 0x4($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X4);
    // 0x8037FFD8: subu        $v0, $t4, $t5
    ctx->r2 = SUB32(ctx->r12, ctx->r13);
    // 0x8037FFDC: bgez        $v0, L_8037FFF4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8037FFE0: sll         $a3, $v0, 16
        ctx->r7 = S32(ctx->r2 << 16);
            goto L_8037FFF4;
    }
    // 0x8037FFE0: sll         $a3, $v0, 16
    ctx->r7 = S32(ctx->r2 << 16);
    // 0x8037FFE4: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
    // 0x8037FFE8: sll         $t6, $a3, 16
    ctx->r14 = S32(ctx->r7 << 16);
    // 0x8037FFEC: b           L_8037FFFC
    // 0x8037FFF0: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
        goto L_8037FFFC;
    // 0x8037FFF0: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
L_8037FFF4:
    // 0x8037FFF4: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8037FFF8: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
L_8037FFFC:
    // 0x8037FFFC: slti        $at, $a3, 0xC8
    ctx->r1 = SIGNED(ctx->r7) < 0XC8 ? 1 : 0;
    // 0x80380000: beql        $at, $zero, L_80380088
    if (ctx->r1 == 0) {
        // 0x80380004: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_7;
    // 0x80380004: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_7:
    // 0x80380008: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x8038000C: lh          $t2, 0x8($t0)
    ctx->r10 = MEM_H(ctx->r8, 0X8);
    // 0x80380010: subu        $v0, $t9, $t2
    ctx->r2 = SUB32(ctx->r25, ctx->r10);
    // 0x80380014: bgez        $v0, L_8038002C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80380018: sll         $a2, $v0, 16
        ctx->r6 = S32(ctx->r2 << 16);
            goto L_8038002C;
    }
    // 0x80380018: sll         $a2, $v0, 16
    ctx->r6 = S32(ctx->r2 << 16);
    // 0x8038001C: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
    // 0x80380020: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x80380024: b           L_80380034
    // 0x80380028: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
        goto L_80380034;
    // 0x80380028: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
L_8038002C:
    // 0x8038002C: sra         $t5, $a2, 16
    ctx->r13 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80380030: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
L_80380034:
    // 0x80380034: slti        $at, $a2, 0xC8
    ctx->r1 = SIGNED(ctx->r6) < 0XC8 ? 1 : 0;
    // 0x80380038: beql        $at, $zero, L_80380088
    if (ctx->r1 == 0) {
        // 0x8038003C: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_8;
    // 0x8038003C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_8:
    // 0x80380040: lbu         $t6, 0x287($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X287);
    // 0x80380044: bnel        $t6, $zero, L_80380088
    if (ctx->r14 != 0) {
        // 0x80380048: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_9;
    // 0x80380048: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_9:
    // 0x8038004C: lw          $t7, 0x0($s7)
    ctx->r15 = MEM_W(ctx->r23, 0X0);
    // 0x80380050: lbu         $t8, 0x28A($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X28A);
    // 0x80380054: bnel        $t8, $zero, L_80380088
    if (ctx->r24 != 0) {
        // 0x80380058: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80380088;
    }
    goto skip_10;
    // 0x80380058: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_10:
    // 0x8038005C: sb          $fp, 0x287($v1)
    MEM_B(0X287, ctx->r3) = ctx->r30;
    // 0x80380060: lw          $t3, 0x3EB4($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X3EB4);
    // 0x80380064: addu        $t9, $a3, $a2
    ctx->r25 = ADD32(ctx->r7, ctx->r6);
    // 0x80380068: sra         $t2, $t9, 3
    ctx->r10 = S32(SIGNED(ctx->r25) >> 3);
    // 0x8038006C: sh          $t2, 0x288($t3)
    MEM_H(0X288, ctx->r11) = ctx->r10;
    // 0x80380070: lw          $a1, 0x0($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X0);
    // 0x80380074: jal         0x80363E88
    // 0x80380078: lw          $a0, 0x3EB4($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X3EB4);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80380078: lw          $a0, 0x3EB4($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X3EB4);
    after_1:
    // 0x8038007C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80380080: lh          $a0, 0x553E($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X553E);
    // 0x80380084: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80380088:
    // 0x80380088: sll         $t4, $s0, 16
    ctx->r12 = S32(ctx->r16 << 16);
    // 0x8038008C: sra         $s0, $t4, 16
    ctx->r16 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80380090: slt         $at, $s0, $a0
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80380094: bnel        $at, $zero, L_8037FF7C
    if (ctx->r1 != 0) {
        // 0x80380098: sll         $t8, $s0, 3
        ctx->r24 = S32(ctx->r16 << 3);
            goto L_8037FF7C;
    }
    goto skip_11;
    // 0x80380098: sll         $t8, $s0, 3
    ctx->r24 = S32(ctx->r16 << 3);
    skip_11:
L_8038009C:
    // 0x8038009C: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x803800A0: addiu       $t6, $zero, 0xF
    ctx->r14 = ADD32(0, 0XF);
    // 0x803800A4: addiu       $a3, $zero, 0xC8
    ctx->r7 = ADD32(0, 0XC8);
    // 0x803800A8: lh          $a0, 0x4($t0)
    ctx->r4 = MEM_H(ctx->r8, 0X4);
    // 0x803800AC: lh          $a1, 0x8($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X8);
    // 0x803800B0: lh          $a2, 0xC($t0)
    ctx->r6 = MEM_H(ctx->r8, 0XC);
    // 0x803800B4: jal         0x8037E6DC
    // 0x803800B8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_8037E6DC_78FD8C(rdram, ctx);
        goto after_2;
    // 0x803800B8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_2:
    // 0x803800BC: lw          $ra, 0x4C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X4C);
    // 0x803800C0: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x803800C4: lw          $s1, 0x2C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X2C);
    // 0x803800C8: lw          $s2, 0x30($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X30);
    // 0x803800CC: lw          $s3, 0x34($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X34);
    // 0x803800D0: lw          $s4, 0x38($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X38);
    // 0x803800D4: lw          $s5, 0x3C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X3C);
    // 0x803800D8: lw          $s6, 0x40($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X40);
    // 0x803800DC: lw          $s7, 0x44($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X44);
    // 0x803800E0: lw          $fp, 0x48($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X48);
    // 0x803800E4: jr          $ra
    // 0x803800E8: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    return;
    // 0x803800E8: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
;}
RECOMP_FUNC void load_data_section(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803800F0: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x803800F4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803800F8: jal         0x80137EB0
    // 0x803800FC: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_0;
    // 0x803800FC: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    after_0:
    // 0x80380100: lui         $a0, 0x800A
    ctx->r4 = S32(0X800A << 16);
    // 0x80380104: lui         $t6, 0x800B
    ctx->r14 = S32(0X800B << 16);
    // 0x80380108: addiu       $a0, $a0, -0x6A00
    ctx->r4 = ADD32(ctx->r4, -0X6A00);
    // 0x8038010C: addiu       $t6, $t6, 0xB20
    ctx->r14 = ADD32(ctx->r14, 0XB20);
    // 0x80380110: subu        $a3, $t6, $a0
    ctx->r7 = SUB32(ctx->r14, ctx->r4);
    // 0x80380114: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x80380118: jal         0x80128FB4
    // 0x8038011C: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    bzero_sssv(rdram, ctx);
        goto after_1;
    // 0x8038011C: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    after_1:
    // 0x80380120: lbu         $t7, 0x43($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X43);
    // 0x80380124: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x80380128: sltiu       $at, $t7, 0x7
    ctx->r1 = ctx->r15 < 0X7 ? 1 : 0;
    // 0x8038012C: beq         $at, $zero, L_80380480
    if (ctx->r1 == 0) {
        // 0x80380130: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_80380480;
    }
    // 0x80380130: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80380134: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80380138: addu        $at, $at, $t7
    gpr jr_addend_80380140 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x8038013C: lw          $t7, -0xC7C($at)
    ctx->r15 = ADD32(ctx->r1, -0XC7C);
    // 0x80380140: jr          $t7
    // 0x80380144: nop

    switch (jr_addend_80380140 >> 2) {
        case 0: goto L_803801BC; break;
        case 1: goto L_80380230; break;
        case 2: goto L_803802A4; break;
        case 3: goto L_80380318; break;
        case 4: goto L_80380480; break;
        case 5: goto L_80380148; break;
        case 6: goto L_8038038C; break;
        default: switch_error(__func__, 0x80380140, 0x803BF384);
    }
    // 0x80380144: nop

L_80380148:
    // 0x80380148: lui         $t8, 0x11
    ctx->r24 = S32(0X11 << 16);
    // 0x8038014C: lui         $t9, 0x10
    ctx->r25 = S32(0X10 << 16);
    // 0x80380150: addiu       $t9, $t9, -0x2B0
    ctx->r25 = ADD32(ctx->r25, -0X2B0);
    // 0x80380154: addiu       $t8, $t8, 0x6BD0
    ctx->r24 = ADD32(ctx->r24, 0X6BD0);
    // 0x80380158: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x8038015C: sltu        $at, $t0, $a3
    ctx->r1 = ctx->r8 < ctx->r7 ? 1 : 0;
    // 0x80380160: bne         $at, $zero, L_80380184
    if (ctx->r1 != 0) {
        // 0x80380164: sw          $t0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r8;
            goto L_80380184;
    }
    // 0x80380164: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x80380168: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8038016C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80380170: addiu       $a1, $a1, -0xEDC
    ctx->r5 = ADD32(ctx->r5, -0XEDC);
    // 0x80380174: addiu       $a0, $a0, -0xF20
    ctx->r4 = ADD32(ctx->r4, -0XF20);
    // 0x80380178: jal         0x8013966C
    // 0x8038017C: addiu       $a2, $zero, 0x72
    ctx->r6 = ADD32(0, 0X72);
    osSyncPrintf(rdram, ctx);
        goto after_2;
    // 0x8038017C: addiu       $a2, $zero, 0x72
    ctx->r6 = ADD32(0, 0X72);
    after_2:
    // 0x80380180: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_80380184:
    // 0x80380184: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80380188: lui         $t1, 0x800A
    ctx->r9 = S32(0X800A << 16);
    // 0x8038018C: addiu       $v0, $v0, -0x61A4
    ctx->r2 = ADD32(ctx->r2, -0X61A4);
    // 0x80380190: addiu       $a1, $t1, -0x6A00
    ctx->r5 = ADD32(ctx->r9, -0X6A00);
    // 0x80380194: lui         $a0, 0x10
    ctx->r4 = S32(0X10 << 16);
    // 0x80380198: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x8038019C: addiu       $a0, $a0, -0x2B0
    ctx->r4 = ADD32(ctx->r4, -0X2B0);
    // 0x803801A0: jal         0x80129290
    // 0x803801A4: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_3;
    // 0x803801A4: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_3:
    // 0x803801A8: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x803801AC: lw          $t2, -0x61A4($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X61A4);
    // 0x803801B0: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x803801B4: b           L_80380480
    // 0x803801B8: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
        goto L_80380480;
    // 0x803801B8: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
L_803801BC:
    // 0x803801BC: lui         $t3, 0xE
    ctx->r11 = S32(0XE << 16);
    // 0x803801C0: lui         $t4, 0xC
    ctx->r12 = S32(0XC << 16);
    // 0x803801C4: addiu       $t4, $t4, 0x7A30
    ctx->r12 = ADD32(ctx->r12, 0X7A30);
    // 0x803801C8: addiu       $t3, $t3, -0x2A40
    ctx->r11 = ADD32(ctx->r11, -0X2A40);
    // 0x803801CC: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x803801D0: sltu        $at, $t5, $a3
    ctx->r1 = ctx->r13 < ctx->r7 ? 1 : 0;
    // 0x803801D4: bne         $at, $zero, L_803801F8
    if (ctx->r1 != 0) {
        // 0x803801D8: sw          $t5, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r13;
            goto L_803801F8;
    }
    // 0x803801D8: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x803801DC: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x803801E0: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803801E4: addiu       $a1, $a1, -0xE84
    ctx->r5 = ADD32(ctx->r5, -0XE84);
    // 0x803801E8: addiu       $a0, $a0, -0xEC8
    ctx->r4 = ADD32(ctx->r4, -0XEC8);
    // 0x803801EC: jal         0x8013966C
    // 0x803801F0: addiu       $a2, $zero, 0x84
    ctx->r6 = ADD32(0, 0X84);
    osSyncPrintf(rdram, ctx);
        goto after_4;
    // 0x803801F0: addiu       $a2, $zero, 0x84
    ctx->r6 = ADD32(0, 0X84);
    after_4:
    // 0x803801F4: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_803801F8:
    // 0x803801F8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x803801FC: lui         $t6, 0x800A
    ctx->r14 = S32(0X800A << 16);
    // 0x80380200: addiu       $v0, $v0, -0x61A8
    ctx->r2 = ADD32(ctx->r2, -0X61A8);
    // 0x80380204: addiu       $a1, $t6, -0x6A00
    ctx->r5 = ADD32(ctx->r14, -0X6A00);
    // 0x80380208: lui         $a0, 0xC
    ctx->r4 = S32(0XC << 16);
    // 0x8038020C: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x80380210: addiu       $a0, $a0, 0x7A30
    ctx->r4 = ADD32(ctx->r4, 0X7A30);
    // 0x80380214: jal         0x80129290
    // 0x80380218: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_5;
    // 0x80380218: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_5:
    // 0x8038021C: lui         $t7, 0x801E
    ctx->r15 = S32(0X801E << 16);
    // 0x80380220: lw          $t7, -0x61A8($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X61A8);
    // 0x80380224: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80380228: b           L_80380480
    // 0x8038022C: sw          $t7, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r15;
        goto L_80380480;
    // 0x8038022C: sw          $t7, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r15;
L_80380230:
    // 0x80380230: lui         $t8, 0xE
    ctx->r24 = S32(0XE << 16);
    // 0x80380234: lui         $t9, 0xE
    ctx->r25 = S32(0XE << 16);
    // 0x80380238: addiu       $t9, $t9, -0x2A40
    ctx->r25 = ADD32(ctx->r25, -0X2A40);
    // 0x8038023C: addiu       $t8, $t8, 0x75B0
    ctx->r24 = ADD32(ctx->r24, 0X75B0);
    // 0x80380240: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x80380244: sltu        $at, $a3, $t0
    ctx->r1 = ctx->r7 < ctx->r8 ? 1 : 0;
    // 0x80380248: beq         $at, $zero, L_8038026C
    if (ctx->r1 == 0) {
        // 0x8038024C: sw          $t0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r8;
            goto L_8038026C;
    }
    // 0x8038024C: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x80380250: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x80380254: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80380258: addiu       $a1, $a1, -0xE28
    ctx->r5 = ADD32(ctx->r5, -0XE28);
    // 0x8038025C: addiu       $a0, $a0, -0xE70
    ctx->r4 = ADD32(ctx->r4, -0XE70);
    // 0x80380260: jal         0x8013966C
    // 0x80380264: addiu       $a2, $zero, 0x96
    ctx->r6 = ADD32(0, 0X96);
    osSyncPrintf(rdram, ctx);
        goto after_6;
    // 0x80380264: addiu       $a2, $zero, 0x96
    ctx->r6 = ADD32(0, 0X96);
    after_6:
    // 0x80380268: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_8038026C:
    // 0x8038026C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80380270: lui         $t1, 0x800A
    ctx->r9 = S32(0X800A << 16);
    // 0x80380274: addiu       $v0, $v0, -0x61A0
    ctx->r2 = ADD32(ctx->r2, -0X61A0);
    // 0x80380278: addiu       $a1, $t1, -0x6A00
    ctx->r5 = ADD32(ctx->r9, -0X6A00);
    // 0x8038027C: lui         $a0, 0xE
    ctx->r4 = S32(0XE << 16);
    // 0x80380280: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x80380284: addiu       $a0, $a0, -0x2A40
    ctx->r4 = ADD32(ctx->r4, -0X2A40);
    // 0x80380288: jal         0x80129290
    // 0x8038028C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_7;
    // 0x8038028C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_7:
    // 0x80380290: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x80380294: lw          $t2, -0x61A0($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X61A0);
    // 0x80380298: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038029C: b           L_80380480
    // 0x803802A0: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
        goto L_80380480;
    // 0x803802A0: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
L_803802A4:
    // 0x803802A4: lui         $t3, 0xF
    ctx->r11 = S32(0XF << 16);
    // 0x803802A8: lui         $t4, 0xE
    ctx->r12 = S32(0XE << 16);
    // 0x803802AC: addiu       $t4, $t4, 0x75B0
    ctx->r12 = ADD32(ctx->r12, 0X75B0);
    // 0x803802B0: addiu       $t3, $t3, 0x1060
    ctx->r11 = ADD32(ctx->r11, 0X1060);
    // 0x803802B4: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x803802B8: sltu        $at, $a3, $t5
    ctx->r1 = ctx->r7 < ctx->r13 ? 1 : 0;
    // 0x803802BC: beq         $at, $zero, L_803802E0
    if (ctx->r1 == 0) {
        // 0x803802C0: sw          $t5, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r13;
            goto L_803802E0;
    }
    // 0x803802C0: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x803802C4: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x803802C8: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803802CC: addiu       $a1, $a1, -0xDCC
    ctx->r5 = ADD32(ctx->r5, -0XDCC);
    // 0x803802D0: addiu       $a0, $a0, -0xE14
    ctx->r4 = ADD32(ctx->r4, -0XE14);
    // 0x803802D4: jal         0x8013966C
    // 0x803802D8: addiu       $a2, $zero, 0xA8
    ctx->r6 = ADD32(0, 0XA8);
    osSyncPrintf(rdram, ctx);
        goto after_8;
    // 0x803802D8: addiu       $a2, $zero, 0xA8
    ctx->r6 = ADD32(0, 0XA8);
    after_8:
    // 0x803802DC: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_803802E0:
    // 0x803802E0: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x803802E4: lui         $t6, 0x800A
    ctx->r14 = S32(0X800A << 16);
    // 0x803802E8: addiu       $v0, $v0, -0x619C
    ctx->r2 = ADD32(ctx->r2, -0X619C);
    // 0x803802EC: addiu       $a1, $t6, -0x6A00
    ctx->r5 = ADD32(ctx->r14, -0X6A00);
    // 0x803802F0: lui         $a0, 0xE
    ctx->r4 = S32(0XE << 16);
    // 0x803802F4: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x803802F8: addiu       $a0, $a0, 0x75B0
    ctx->r4 = ADD32(ctx->r4, 0X75B0);
    // 0x803802FC: jal         0x80129290
    // 0x80380300: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_9;
    // 0x80380300: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_9:
    // 0x80380304: lui         $t7, 0x801E
    ctx->r15 = S32(0X801E << 16);
    // 0x80380308: lw          $t7, -0x619C($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X619C);
    // 0x8038030C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80380310: b           L_80380480
    // 0x80380314: sw          $t7, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r15;
        goto L_80380480;
    // 0x80380314: sw          $t7, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r15;
L_80380318:
    // 0x80380318: lui         $t8, 0x10
    ctx->r24 = S32(0X10 << 16);
    // 0x8038031C: lui         $t9, 0xF
    ctx->r25 = S32(0XF << 16);
    // 0x80380320: addiu       $t9, $t9, 0x1060
    ctx->r25 = ADD32(ctx->r25, 0X1060);
    // 0x80380324: addiu       $t8, $t8, -0x2B0
    ctx->r24 = ADD32(ctx->r24, -0X2B0);
    // 0x80380328: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x8038032C: sltu        $at, $a3, $t0
    ctx->r1 = ctx->r7 < ctx->r8 ? 1 : 0;
    // 0x80380330: beq         $at, $zero, L_80380354
    if (ctx->r1 == 0) {
        // 0x80380334: sw          $t0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r8;
            goto L_80380354;
    }
    // 0x80380334: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x80380338: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8038033C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80380340: addiu       $a1, $a1, -0xD70
    ctx->r5 = ADD32(ctx->r5, -0XD70);
    // 0x80380344: addiu       $a0, $a0, -0xDB8
    ctx->r4 = ADD32(ctx->r4, -0XDB8);
    // 0x80380348: jal         0x8013966C
    // 0x8038034C: addiu       $a2, $zero, 0xBA
    ctx->r6 = ADD32(0, 0XBA);
    osSyncPrintf(rdram, ctx);
        goto after_10;
    // 0x8038034C: addiu       $a2, $zero, 0xBA
    ctx->r6 = ADD32(0, 0XBA);
    after_10:
    // 0x80380350: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_80380354:
    // 0x80380354: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80380358: lui         $t1, 0x800A
    ctx->r9 = S32(0X800A << 16);
    // 0x8038035C: addiu       $v0, $v0, -0x6198
    ctx->r2 = ADD32(ctx->r2, -0X6198);
    // 0x80380360: addiu       $a1, $t1, -0x6A00
    ctx->r5 = ADD32(ctx->r9, -0X6A00);
    // 0x80380364: lui         $a0, 0xF
    ctx->r4 = S32(0XF << 16);
    // 0x80380368: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x8038036C: addiu       $a0, $a0, 0x1060
    ctx->r4 = ADD32(ctx->r4, 0X1060);
    // 0x80380370: jal         0x80129290
    // 0x80380374: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_11;
    // 0x80380374: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_11:
    // 0x80380378: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x8038037C: lw          $t2, -0x6198($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X6198);
    // 0x80380380: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80380384: b           L_80380480
    // 0x80380388: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
        goto L_80380480;
    // 0x80380388: sw          $t2, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r10;
L_8038038C:
    // 0x8038038C: lui         $t3, 0x8
    ctx->r11 = S32(0X8 << 16);
    // 0x80380390: lui         $t4, 0x8
    ctx->r12 = S32(0X8 << 16);
    // 0x80380394: lui         $t6, 0x800C
    ctx->r14 = S32(0X800C << 16);
    // 0x80380398: lui         $t7, 0x800B
    ctx->r15 = S32(0X800B << 16);
    // 0x8038039C: addiu       $t7, $t7, 0xB20
    ctx->r15 = ADD32(ctx->r15, 0XB20);
    // 0x803803A0: addiu       $t6, $t6, -0x58A0
    ctx->r14 = ADD32(ctx->r14, -0X58A0);
    // 0x803803A4: addiu       $t4, $t4, -0x870
    ctx->r12 = ADD32(ctx->r12, -0X870);
    // 0x803803A8: addiu       $t3, $t3, 0x5790
    ctx->r11 = ADD32(ctx->r11, 0X5790);
    // 0x803803AC: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x803803B0: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x803803B4: sltu        $at, $t8, $t5
    ctx->r1 = ctx->r24 < ctx->r13 ? 1 : 0;
    // 0x803803B8: beq         $at, $zero, L_803803E4
    if (ctx->r1 == 0) {
        // 0x803803BC: sw          $t5, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r13;
            goto L_803803E4;
    }
    // 0x803803BC: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x803803C0: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x803803C4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803803C8: addiu       $a1, $a1, -0xD0C
    ctx->r5 = ADD32(ctx->r5, -0XD0C);
    // 0x803803CC: addiu       $a0, $a0, -0xD5C
    ctx->r4 = ADD32(ctx->r4, -0XD5C);
    // 0x803803D0: addiu       $a2, $zero, 0xCE
    ctx->r6 = ADD32(0, 0XCE);
    // 0x803803D4: jal         0x8013966C
    // 0x803803D8: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    osSyncPrintf(rdram, ctx);
        goto after_12;
    // 0x803803D8: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    after_12:
    // 0x803803DC: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x803803E0: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_803803E4:
    // 0x803803E4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x803803E8: lui         $t9, 0x800B
    ctx->r25 = S32(0X800B << 16);
    // 0x803803EC: addiu       $v0, $v0, -0x6188
    ctx->r2 = ADD32(ctx->r2, -0X6188);
    // 0x803803F0: addiu       $a1, $t9, 0xB20
    ctx->r5 = ADD32(ctx->r25, 0XB20);
    // 0x803803F4: lui         $a0, 0x8
    ctx->r4 = S32(0X8 << 16);
    // 0x803803F8: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x803803FC: addiu       $a0, $a0, -0x870
    ctx->r4 = ADD32(ctx->r4, -0X870);
    // 0x80380400: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x80380404: jal         0x80129290
    // 0x80380408: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    dma_read(rdram, ctx);
        goto after_13;
    // 0x80380408: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    after_13:
    // 0x8038040C: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x80380410: lui         $t0, 0x13
    ctx->r8 = S32(0X13 << 16);
    // 0x80380414: lui         $t1, 0x11
    ctx->r9 = S32(0X11 << 16);
    // 0x80380418: addiu       $t1, $t1, 0x6BD0
    ctx->r9 = ADD32(ctx->r9, 0X6BD0);
    // 0x8038041C: addiu       $t0, $t0, -0x5C70
    ctx->r8 = ADD32(ctx->r8, -0X5C70);
    // 0x80380420: subu        $t2, $t0, $t1
    ctx->r10 = SUB32(ctx->r8, ctx->r9);
    // 0x80380424: sltu        $at, $a3, $t2
    ctx->r1 = ctx->r7 < ctx->r10 ? 1 : 0;
    // 0x80380428: beq         $at, $zero, L_8038044C
    if (ctx->r1 == 0) {
        // 0x8038042C: sw          $t2, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r10;
            goto L_8038044C;
    }
    // 0x8038042C: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x80380430: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x80380434: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80380438: addiu       $a1, $a1, -0xCB0
    ctx->r5 = ADD32(ctx->r5, -0XCB0);
    // 0x8038043C: addiu       $a0, $a0, -0xCF8
    ctx->r4 = ADD32(ctx->r4, -0XCF8);
    // 0x80380440: jal         0x8013966C
    // 0x80380444: addiu       $a2, $zero, 0xDA
    ctx->r6 = ADD32(0, 0XDA);
    osSyncPrintf(rdram, ctx);
        goto after_14;
    // 0x80380444: addiu       $a2, $zero, 0xDA
    ctx->r6 = ADD32(0, 0XDA);
    after_14:
    // 0x80380448: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_8038044C:
    // 0x8038044C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80380450: lui         $t3, 0x800A
    ctx->r11 = S32(0X800A << 16);
    // 0x80380454: addiu       $v0, $v0, -0x6194
    ctx->r2 = ADD32(ctx->r2, -0X6194);
    // 0x80380458: addiu       $a1, $t3, -0x6A00
    ctx->r5 = ADD32(ctx->r11, -0X6A00);
    // 0x8038045C: lui         $a0, 0x11
    ctx->r4 = S32(0X11 << 16);
    // 0x80380460: sw          $a1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r5;
    // 0x80380464: addiu       $a0, $a0, 0x6BD0
    ctx->r4 = ADD32(ctx->r4, 0X6BD0);
    // 0x80380468: jal         0x80129290
    // 0x8038046C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    dma_read(rdram, ctx);
        goto after_15;
    // 0x8038046C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    after_15:
    // 0x80380470: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x80380474: lw          $t4, -0x6194($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X6194);
    // 0x80380478: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038047C: sw          $t4, -0x613C($at)
    MEM_W(-0X613C, ctx->r1) = ctx->r12;
L_80380480:
    // 0x80380480: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80380484: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x80380488: jr          $ra
    // 0x8038048C: nop

    return;
    // 0x8038048C: nop

;}
RECOMP_FUNC void switch_to_current_segment(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80380490: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80380494: lhu         $t6, 0x2D70($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X2D70);
    // 0x80380498: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8038049C: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x803804A0: sltiu       $at, $t6, 0x7
    ctx->r1 = ctx->r14 < 0X7 ? 1 : 0;
    // 0x803804A4: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x803804A8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803804AC: beq         $at, $zero, L_80380604
    if (ctx->r1 == 0) {
        // 0x803804B0: sw          $a0, 0x30($sp)
        MEM_W(0X30, ctx->r29) = ctx->r4;
            goto L_80380604;
    }
    // 0x803804B0: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x803804B4: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x803804B8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803804BC: addu        $at, $at, $t6
    gpr jr_addend_803804C4 = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x803804C0: lw          $t6, -0xC60($at)
    ctx->r14 = ADD32(ctx->r1, -0XC60);
    // 0x803804C4: jr          $t6
    // 0x803804C8: nop

    switch (jr_addend_803804C4 >> 2) {
        case 0: goto L_80380500; break;
        case 1: goto L_80380534; break;
        case 2: goto L_80380568; break;
        case 3: goto L_8038059C; break;
        case 4: goto L_80380604; break;
        case 5: goto L_803804CC; break;
        case 6: goto L_803805D0; break;
        default: switch_error(__func__, 0x803804C4, 0x803BF3A0);
    }
    // 0x803804C8: nop

L_803804CC:
    // 0x803804CC: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x803804D0: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x803804D4: ori         $t8, $t8, 0x1006
    ctx->r24 = ctx->r24 | 0X1006;
    // 0x803804D8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803804DC: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x803804E0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803804E4: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803804E8: lw          $a0, -0x61A4($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X61A4);
    // 0x803804EC: jal         0x80138130
    // 0x803804F0: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_0;
    // 0x803804F0: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    after_0:
    // 0x803804F4: lw          $v1, 0x2C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X2C);
    // 0x803804F8: b           L_80380610
    // 0x803804FC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x803804FC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_80380500:
    // 0x80380500: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80380504: lui         $t0, 0xBC00
    ctx->r8 = S32(0XBC00 << 16);
    // 0x80380508: ori         $t0, $t0, 0x1006
    ctx->r8 = ctx->r8 | 0X1006;
    // 0x8038050C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80380510: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x80380514: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80380518: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x8038051C: lw          $a0, -0x61A8($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X61A8);
    // 0x80380520: jal         0x80138130
    // 0x80380524: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x80380524: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    after_1:
    // 0x80380528: lw          $v1, 0x28($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X28);
    // 0x8038052C: b           L_80380610
    // 0x80380530: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x80380530: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_80380534:
    // 0x80380534: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80380538: lui         $t2, 0xBC00
    ctx->r10 = S32(0XBC00 << 16);
    // 0x8038053C: ori         $t2, $t2, 0x1006
    ctx->r10 = ctx->r10 | 0X1006;
    // 0x80380540: addiu       $t1, $v0, 0x8
    ctx->r9 = ADD32(ctx->r2, 0X8);
    // 0x80380544: sw          $t1, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r9;
    // 0x80380548: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038054C: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x80380550: lw          $a0, -0x61A0($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X61A0);
    // 0x80380554: jal         0x80138130
    // 0x80380558: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_2;
    // 0x80380558: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    after_2:
    // 0x8038055C: lw          $v1, 0x24($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X24);
    // 0x80380560: b           L_80380610
    // 0x80380564: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x80380564: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_80380568:
    // 0x80380568: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038056C: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x80380570: ori         $t4, $t4, 0x1006
    ctx->r12 = ctx->r12 | 0X1006;
    // 0x80380574: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80380578: sw          $t3, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r11;
    // 0x8038057C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80380580: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80380584: lw          $a0, -0x619C($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X619C);
    // 0x80380588: jal         0x80138130
    // 0x8038058C: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_3;
    // 0x8038058C: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    after_3:
    // 0x80380590: lw          $v1, 0x20($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X20);
    // 0x80380594: b           L_80380610
    // 0x80380598: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x80380598: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_8038059C:
    // 0x8038059C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x803805A0: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x803805A4: ori         $t6, $t6, 0x1006
    ctx->r14 = ctx->r14 | 0X1006;
    // 0x803805A8: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x803805AC: sw          $t5, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r13;
    // 0x803805B0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803805B4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803805B8: lw          $a0, -0x6198($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6198);
    // 0x803805BC: jal         0x80138130
    // 0x803805C0: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_4;
    // 0x803805C0: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    after_4:
    // 0x803805C4: lw          $v1, 0x1C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X1C);
    // 0x803805C8: b           L_80380610
    // 0x803805CC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x803805CC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_803805D0:
    // 0x803805D0: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x803805D4: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x803805D8: ori         $t8, $t8, 0x1006
    ctx->r24 = ctx->r24 | 0X1006;
    // 0x803805DC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803805E0: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x803805E4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803805E8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803805EC: lw          $a0, -0x6194($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6194);
    // 0x803805F0: jal         0x80138130
    // 0x803805F4: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_5;
    // 0x803805F4: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    after_5:
    // 0x803805F8: lw          $v1, 0x18($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X18);
    // 0x803805FC: b           L_80380610
    // 0x80380600: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
        goto L_80380610;
    // 0x80380600: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
L_80380604:
    // 0x80380604: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x80380608: jal         0x8013966C
    // 0x8038060C: addiu       $a0, $a0, -0xC9C
    ctx->r4 = ADD32(ctx->r4, -0XC9C);
    osSyncPrintf(rdram, ctx);
        goto after_6;
    // 0x8038060C: addiu       $a0, $a0, -0xC9C
    ctx->r4 = ADD32(ctx->r4, -0XC9C);
    after_6:
L_80380610:
    // 0x80380610: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80380614: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80380618: jr          $ra
    // 0x8038061C: nop

    return;
    // 0x8038061C: nop

;}
RECOMP_FUNC void func_80380620_791CD0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80380620: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80380624: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80380628: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x8038062C: sh          $a1, 0x34C($a0)
    MEM_H(0X34C, ctx->r4) = ctx->r5;
    // 0x80380630: sh          $a2, 0x352($a0)
    MEM_H(0X352, ctx->r4) = ctx->r6;
    // 0x80380634: sh          $a3, 0x356($a0)
    MEM_H(0X356, ctx->r4) = ctx->r7;
    // 0x80380638: lbu         $t2, 0x13($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X13);
    // 0x8038063C: jr          $ra
    // 0x80380640: sb          $t2, 0x362($a0)
    MEM_B(0X362, ctx->r4) = ctx->r10;
    return;
    // 0x80380640: sb          $t2, 0x362($a0)
    MEM_B(0X362, ctx->r4) = ctx->r10;
;}
RECOMP_FUNC void func_80380644_791CF4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80380644: jr          $ra
    // 0x80380648: sh          $zero, 0x34C($a0)
    MEM_H(0X34C, ctx->r4) = 0;
    return;
    // 0x80380648: sh          $zero, 0x34C($a0)
    MEM_H(0X34C, ctx->r4) = 0;
;}
RECOMP_FUNC void func_8038064C_791CFC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038064C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80380650: lb          $t6, 0x2D10($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X2D10);
    // 0x80380654: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80380658: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038065C: bne         $t6, $zero, L_8038069C
    if (ctx->r14 != 0) {
        // 0x80380660: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_8038069C;
    }
    // 0x80380660: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80380664: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80380668: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038066C: lh          $v0, 0x358($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X358);
    // 0x80380670: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x80380674: bgezl       $v0, L_80380688
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80380678: sh          $v0, 0x358($a0)
        MEM_H(0X358, ctx->r4) = ctx->r2;
            goto L_80380688;
    }
    goto skip_0;
    // 0x80380678: sh          $v0, 0x358($a0)
    MEM_H(0X358, ctx->r4) = ctx->r2;
    skip_0:
    // 0x8038067C: b           L_80380688
    // 0x80380680: sh          $zero, 0x358($a0)
    MEM_H(0X358, ctx->r4) = 0;
        goto L_80380688;
    // 0x80380680: sh          $zero, 0x358($a0)
    MEM_H(0X358, ctx->r4) = 0;
    // 0x80380684: sh          $v0, 0x358($a0)
    MEM_H(0X358, ctx->r4) = ctx->r2;
L_80380688:
    // 0x80380688: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038068C: lh          $t7, 0x358($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X358);
    // 0x80380690: bgtz        $t7, L_8038069C
    if (SIGNED(ctx->r15) > 0) {
        // 0x80380694: nop
    
            goto L_8038069C;
    }
    // 0x80380694: nop

    // 0x80380698: sb          $zero, 0x363($a0)
    MEM_B(0X363, ctx->r4) = 0;
L_8038069C:
    // 0x8038069C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803806A0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803806A4: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x803806A8: addiu       $a1, $zero, 0x96
    ctx->r5 = ADD32(0, 0X96);
    // 0x803806AC: addiu       $a2, $zero, 0xF
    ctx->r6 = ADD32(0, 0XF);
    // 0x803806B0: lbu         $t8, 0x363($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X363);
    // 0x803806B4: beql        $t8, $zero, L_80380700
    if (ctx->r24 == 0) {
        // 0x803806B8: lw          $a0, 0x0($t0)
        ctx->r4 = MEM_W(ctx->r8, 0X0);
            goto L_80380700;
    }
    goto skip_1;
    // 0x803806B8: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    skip_1:
    // 0x803806BC: lh          $v0, 0x358($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X358);
    // 0x803806C0: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x803806C4: sra         $t9, $v0, 1
    ctx->r25 = S32(SIGNED(ctx->r2) >> 1);
    // 0x803806C8: slti        $at, $t9, 0x33
    ctx->r1 = SIGNED(ctx->r25) < 0X33 ? 1 : 0;
    // 0x803806CC: bne         $at, $zero, L_803806DC
    if (ctx->r1 != 0) {
        // 0x803806D0: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_803806DC;
    }
    // 0x803806D0: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x803806D4: b           L_803806E0
    // 0x803806D8: addiu       $v1, $zero, 0x32
    ctx->r3 = ADD32(0, 0X32);
        goto L_803806E0;
    // 0x803806D8: addiu       $v1, $zero, 0x32
    ctx->r3 = ADD32(0, 0X32);
L_803806DC:
    // 0x803806DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803806E0:
    // 0x803806E0: sll         $a3, $v1, 16
    ctx->r7 = S32(ctx->r3 << 16);
    // 0x803806E4: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803806E8: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
    // 0x803806EC: jal         0x80380620
    // 0x803806F0: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_80380620_791CD0(rdram, ctx);
        goto after_0;
    // 0x803806F0: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_0:
    // 0x803806F4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803806F8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803806FC: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_80380700:
    // 0x80380700: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x80380704: addiu       $t2, $t2, 0x63E0
    ctx->r10 = ADD32(ctx->r10, 0X63E0);
    // 0x80380708: sh          $zero, 0x0($t2)
    MEM_H(0X0, ctx->r10) = 0;
    // 0x8038070C: lh          $t5, 0x34C($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X34C);
    // 0x80380710: bnel        $t5, $zero, L_80380728
    if (ctx->r13 != 0) {
        // 0x80380714: lh          $v1, 0x34E($a0)
        ctx->r3 = MEM_H(ctx->r4, 0X34E);
            goto L_80380728;
    }
    goto skip_2;
    // 0x80380714: lh          $v1, 0x34E($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X34E);
    skip_2:
    // 0x80380718: lh          $t6, 0x34E($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X34E);
    // 0x8038071C: beql        $t6, $zero, L_80380914
    if (ctx->r14 == 0) {
        // 0x80380720: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80380914;
    }
    goto skip_3;
    // 0x80380720: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80380724: lh          $v1, 0x34E($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X34E);
L_80380728:
    // 0x80380728: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x8038072C: addiu       $a1, $a1, 0x2C78
    ctx->r5 = ADD32(ctx->r5, 0X2C78);
    // 0x80380730: beq         $v1, $zero, L_80380864
    if (ctx->r3 == 0) {
        // 0x80380734: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_80380864;
    }
    // 0x80380734: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80380738: addiu       $t7, $v1, -0x1
    ctx->r15 = ADD32(ctx->r3, -0X1);
    // 0x8038073C: sh          $t7, 0x34E($a0)
    MEM_H(0X34E, ctx->r4) = ctx->r15;
    // 0x80380740: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x80380744: addiu       $a2, $a2, 0x2EB0
    ctx->r6 = ADD32(ctx->r6, 0X2EB0);
    // 0x80380748: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8038074C: lh          $t8, 0x34E($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X34E);
    // 0x80380750: lh          $t3, 0x354($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X354);
    // 0x80380754: addiu       $a3, $a3, 0x2EB4
    ctx->r7 = ADD32(ctx->r7, 0X2EB4);
    // 0x80380758: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x8038075C: div         $zero, $t9, $t3
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r11)));
    // 0x80380760: mflo        $t6
    ctx->r14 = lo;
    // 0x80380764: addiu       $t7, $t6, 0x40
    ctx->r15 = ADD32(ctx->r14, 0X40);
    // 0x80380768: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x8038076C: addiu       $t6, $zero, 0x100
    ctx->r14 = ADD32(0, 0X100);
    // 0x80380770: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80380774: addiu       $t1, $t1, 0x2EB8
    ctx->r9 = ADD32(ctx->r9, 0X2EB8);
    // 0x80380778: bne         $t3, $zero, L_80380784
    if (ctx->r11 != 0) {
        // 0x8038077C: nop
    
            goto L_80380784;
    }
    // 0x8038077C: nop

    // 0x80380780: break       7
    do_break(2151155584);
L_80380784:
    // 0x80380784: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80380788: bne         $t3, $at, L_8038079C
    if (ctx->r11 != ctx->r1) {
        // 0x8038078C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8038079C;
    }
    // 0x8038078C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80380790: bne         $t9, $at, L_8038079C
    if (ctx->r25 != ctx->r1) {
        // 0x80380794: nop
    
            goto L_8038079C;
    }
    // 0x80380794: nop

    // 0x80380798: break       6
    do_break(2151155608);
L_8038079C:
    // 0x8038079C: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x803807A0: addu        $t3, $a1, $t9
    ctx->r11 = ADD32(ctx->r5, ctx->r25);
    // 0x803807A4: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x803807A8: lh          $t8, 0x350($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X350);
    // 0x803807AC: lw          $t3, 0x0($a2)
    ctx->r11 = MEM_W(ctx->r6, 0X0);
    // 0x803807B0: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x803807B4: subu        $t7, $t6, $t5
    ctx->r15 = SUB32(ctx->r14, ctx->r13);
    // 0x803807B8: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803807BC: lw          $t5, 0x0($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X0);
    // 0x803807C0: mflo        $v0
    ctx->r2 = lo;
    // 0x803807C4: sra         $t9, $v0, 9
    ctx->r25 = S32(SIGNED(ctx->r2) >> 9);
    // 0x803807C8: addiu       $v0, $t9, 0x100
    ctx->r2 = ADD32(ctx->r25, 0X100);
    // 0x803807CC: multu       $t3, $v0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803807D0: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x803807D4: mflo        $t4
    ctx->r12 = lo;
    // 0x803807D8: sra         $t6, $t4, 8
    ctx->r14 = S32(SIGNED(ctx->r12) >> 8);
    // 0x803807DC: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x803807E0: multu       $t5, $v0
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803807E4: mflo        $t7
    ctx->r15 = lo;
    // 0x803807E8: sra         $t8, $t7, 8
    ctx->r24 = S32(SIGNED(ctx->r15) >> 8);
    // 0x803807EC: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x803807F0: multu       $t9, $v0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803807F4: mflo        $t3
    ctx->r11 = lo;
    // 0x803807F8: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x803807FC: sw          $t4, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r12;
    // 0x80380800: lh          $t6, 0x34E($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X34E);
    // 0x80380804: lh          $t7, 0x354($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X354);
    // 0x80380808: lh          $t9, 0x350($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X350);
    // 0x8038080C: sll         $t5, $t6, 8
    ctx->r13 = S32(ctx->r14 << 8);
    // 0x80380810: div         $zero, $t5, $t7
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r15))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r15)));
    // 0x80380814: mflo        $t3
    ctx->r11 = lo;
    // 0x80380818: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8038081C: sll         $t6, $t4, 1
    ctx->r14 = S32(ctx->r12 << 1);
    // 0x80380820: bne         $t7, $zero, L_8038082C
    if (ctx->r15 != 0) {
        // 0x80380824: nop
    
            goto L_8038082C;
    }
    // 0x80380824: nop

    // 0x80380828: break       7
    do_break(2151155752);
L_8038082C:
    // 0x8038082C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80380830: bne         $t7, $at, L_80380844
    if (ctx->r15 != ctx->r1) {
        // 0x80380834: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80380844;
    }
    // 0x80380834: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80380838: bne         $t5, $at, L_80380844
    if (ctx->r13 != ctx->r1) {
        // 0x8038083C: nop
    
            goto L_80380844;
    }
    // 0x8038083C: nop

    // 0x80380840: break       6
    do_break(2151155776);
L_80380844:
    // 0x80380844: addu        $t5, $a1, $t6
    ctx->r13 = ADD32(ctx->r5, ctx->r14);
    // 0x80380848: lh          $t7, 0x0($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X0);
    // 0x8038084C: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80380850: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380854: mflo        $t3
    ctx->r11 = lo;
    // 0x80380858: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x8038085C: b           L_80380900
    // 0x80380860: sh          $t4, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r12;
        goto L_80380900;
    // 0x80380860: sh          $t4, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r12;
L_80380864:
    // 0x80380864: jal         0x8012826C
    // 0x80380868: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x80380868: nop

    after_1:
    // 0x8038086C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80380870: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80380874: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x80380878: andi        $t6, $v0, 0x7F
    ctx->r14 = ctx->r2 & 0X7F;
    // 0x8038087C: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x80380880: lbu         $t8, 0x362($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X362);
    // 0x80380884: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x80380888: lh          $t5, 0x352($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X352);
    // 0x8038088C: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380890: mflo        $t9
    ctx->r25 = lo;
    // 0x80380894: sra         $t3, $t9, 6
    ctx->r11 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80380898: addiu       $t4, $t3, 0x40
    ctx->r12 = ADD32(ctx->r11, 0X40);
    // 0x8038089C: multu       $t4, $t5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803808A0: mflo        $t6
    ctx->r14 = lo;
    // 0x803808A4: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x803808A8: sh          $t7, 0x354($a0)
    MEM_H(0X354, ctx->r4) = ctx->r15;
    // 0x803808AC: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x803808B0: lh          $t8, 0x354($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X354);
    // 0x803808B4: jal         0x8012826C
    // 0x803808B8: sh          $t8, 0x34E($a0)
    MEM_H(0X34E, ctx->r4) = ctx->r24;
    advance_random_seed(rdram, ctx);
        goto after_2;
    // 0x803808B8: sh          $t8, 0x34E($a0)
    MEM_H(0X34E, ctx->r4) = ctx->r24;
    after_2:
    // 0x803808BC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803808C0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803808C4: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x803808C8: andi        $t9, $v0, 0x7F
    ctx->r25 = ctx->r2 & 0X7F;
    // 0x803808CC: addiu       $t3, $zero, 0x40
    ctx->r11 = ADD32(0, 0X40);
    // 0x803808D0: lbu         $t5, 0x362($a0)
    ctx->r13 = MEM_BU(ctx->r4, 0X362);
    // 0x803808D4: subu        $t4, $t3, $t9
    ctx->r12 = SUB32(ctx->r11, ctx->r25);
    // 0x803808D8: lh          $t3, 0x356($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X356);
    // 0x803808DC: multu       $t4, $t5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803808E0: mflo        $t6
    ctx->r14 = lo;
    // 0x803808E4: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x803808E8: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x803808EC: multu       $t8, $t3
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803808F0: mflo        $t9
    ctx->r25 = lo;
    // 0x803808F4: sra         $t4, $t9, 6
    ctx->r12 = S32(SIGNED(ctx->r25) >> 6);
    // 0x803808F8: sh          $t4, 0x350($a0)
    MEM_H(0X350, ctx->r4) = ctx->r12;
    // 0x803808FC: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_80380900:
    // 0x80380900: lh          $v0, 0x34C($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X34C);
    // 0x80380904: blez        $v0, L_80380910
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80380908: addiu       $t5, $v0, -0x1
        ctx->r13 = ADD32(ctx->r2, -0X1);
            goto L_80380910;
    }
    // 0x80380908: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x8038090C: sh          $t5, 0x34C($a0)
    MEM_H(0X34C, ctx->r4) = ctx->r13;
L_80380910:
    // 0x80380910: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80380914:
    // 0x80380914: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80380918: jr          $ra
    // 0x8038091C: nop

    return;
    // 0x8038091C: nop

;}
RECOMP_FUNC void func_80380920_791FD0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80380920: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80380924: lh          $t6, 0x553A($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X553A);
    // 0x80380928: addiu       $sp, $sp, -0x98
    ctx->r29 = ADD32(ctx->r29, -0X98);
    // 0x8038092C: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x80380930: addiu       $s0, $zero, 0x4
    ctx->r16 = ADD32(0, 0X4);
    // 0x80380934: bne         $s0, $t6, L_803809C8
    if (ctx->r16 != ctx->r14) {
        // 0x80380938: sw          $ra, 0x44($sp)
        MEM_W(0X44, ctx->r29) = ctx->r31;
            goto L_803809C8;
    }
    // 0x80380938: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8038093C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80380940: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x80380944: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x80380948: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038094C: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x80380950: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80380954: addiu       $a1, $zero, 0x3700
    ctx->r5 = ADD32(0, 0X3700);
    // 0x80380958: bne         $t8, $at, L_8038099C
    if (ctx->r24 != ctx->r1) {
        // 0x8038095C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8038099C;
    }
    // 0x8038095C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80380960: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80380964: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80380968: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038096C: lwc1        $f4, -0xC40($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0XC40);
    // 0x80380970: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x80380974: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80380978: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8038097C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80380980: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x80380984: addiu       $a1, $zero, 0x3700
    ctx->r5 = ADD32(0, 0X3700);
    // 0x80380988: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8038098C: jal         0x8032C360
    // 0x80380990: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80380990: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_0:
    // 0x80380994: b           L_803809C8
    // 0x80380998: nop

        goto L_803809C8;
    // 0x80380998: nop

L_8038099C:
    // 0x8038099C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x803809A0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803809A4: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803809A8: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x803809AC: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x803809B0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803809B4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x803809B8: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x803809BC: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x803809C0: jal         0x8032C360
    // 0x803809C4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x803809C4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_1:
L_803809C8:
    // 0x803809C8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803809CC: lbu         $t9, 0x5538($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X5538);
    // 0x803809D0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803809D4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803809D8: beq         $t9, $zero, L_80380A30
    if (ctx->r25 == 0) {
        // 0x803809DC: addiu       $a3, $zero, 0xA00
        ctx->r7 = ADD32(0, 0XA00);
            goto L_80380A30;
    }
    // 0x803809DC: addiu       $a3, $zero, 0xA00
    ctx->r7 = ADD32(0, 0XA00);
    // 0x803809E0: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x803809E4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803809E8: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x803809EC: lh          $v0, 0xD6($t6)
    ctx->r2 = MEM_H(ctx->r14, 0XD6);
    // 0x803809F0: beq         $v1, $v0, L_80380A10
    if (ctx->r3 == ctx->r2) {
        // 0x803809F4: nop
    
            goto L_80380A10;
    }
    // 0x803809F4: nop

    // 0x803809F8: bnel        $v0, $zero, L_80380A1C
    if (ctx->r2 != 0) {
        // 0x803809FC: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80380A1C;
    }
    goto skip_0;
    // 0x803809FC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80380A00: beq         $s0, $v1, L_80380A10
    if (ctx->r16 == ctx->r3) {
        // 0x80380A04: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80380A10;
    }
    // 0x80380A04: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80380A08: bnel        $v1, $at, L_80380A1C
    if (ctx->r3 != ctx->r1) {
        // 0x80380A0C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80380A1C;
    }
    goto skip_1;
    // 0x80380A0C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
L_80380A10:
    // 0x80380A10: b           L_80380A1C
    // 0x80380A14: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80380A1C;
    // 0x80380A14: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80380A18: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80380A1C:
    // 0x80380A1C: beq         $v0, $zero, L_80380A30
    if (ctx->r2 == 0) {
        // 0x80380A20: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_80380A30;
    }
    // 0x80380A20: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80380A24: sh          $zero, 0x82($sp)
    MEM_H(0X82, ctx->r29) = 0;
    // 0x80380A28: b           L_80380AC0
    // 0x80380A2C: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_80380AC0;
    // 0x80380A2C: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_80380A30:
    // 0x80380A30: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x80380A34: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80380A38: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x80380A3C: lh          $v0, 0xD6($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XD6);
    // 0x80380A40: beq         $v1, $v0, L_80380A60
    if (ctx->r3 == ctx->r2) {
        // 0x80380A44: nop
    
            goto L_80380A60;
    }
    // 0x80380A44: nop

    // 0x80380A48: bnel        $v0, $zero, L_80380A6C
    if (ctx->r2 != 0) {
        // 0x80380A4C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80380A6C;
    }
    goto skip_2;
    // 0x80380A4C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x80380A50: beq         $s0, $v1, L_80380A60
    if (ctx->r16 == ctx->r3) {
        // 0x80380A54: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80380A60;
    }
    // 0x80380A54: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80380A58: bnel        $v1, $at, L_80380A6C
    if (ctx->r3 != ctx->r1) {
        // 0x80380A5C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80380A6C;
    }
    goto skip_3;
    // 0x80380A5C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_3:
L_80380A60:
    // 0x80380A60: b           L_80380A6C
    // 0x80380A64: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80380A6C;
    // 0x80380A64: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80380A68: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80380A6C:
    // 0x80380A6C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80380A70: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80380A74: lhu         $t8, 0xBA($t0)
    ctx->r24 = MEM_HU(ctx->r8, 0XBA);
    // 0x80380A78: addiu       $t6, $zero, 0x14
    ctx->r14 = ADD32(0, 0X14);
    // 0x80380A7C: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x80380A80: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
    // 0x80380A84: lw          $a1, 0x8($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X8);
    // 0x80380A88: sll         $t9, $t8, 15
    ctx->r25 = S32(ctx->r24 << 15);
    // 0x80380A8C: addu        $a2, $t7, $t9
    ctx->r6 = ADD32(ctx->r15, ctx->r25);
    // 0x80380A90: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80380A94: sltiu       $t6, $v0, 0x1
    ctx->r14 = ctx->r2 < 0X1 ? 1 : 0;
    // 0x80380A98: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80380A9C: addiu       $t7, $zero, 0x14
    ctx->r15 = ADD32(0, 0X14);
    // 0x80380AA0: addiu       $t8, $zero, 0x14
    ctx->r24 = ADD32(0, 0X14);
    // 0x80380AA4: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80380AA8: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80380AAC: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x80380AB0: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80380AB4: jal         0x802E89F0
    // 0x80380AB8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_2;
    // 0x80380AB8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_2:
    // 0x80380ABC: sh          $v0, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r2;
L_80380AC0:
    // 0x80380AC0: lh          $t8, 0x82($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X82);
    // 0x80380AC4: bne         $t8, $zero, L_80381A6C
    if (ctx->r24 != 0) {
        // 0x80380AC8: nop
    
            goto L_80381A6C;
    }
    // 0x80380AC8: nop

    // 0x80380ACC: jal         0x8038C98C
    // 0x80380AD0: nop

    func_8038C98C_79E03C(rdram, ctx);
        goto after_3;
    // 0x80380AD0: nop

    after_3:
    // 0x80380AD4: jal         0x8035D120
    // 0x80380AD8: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_4;
    // 0x80380AD8: nop

    after_4:
    // 0x80380ADC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80380AE0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x80380AE4: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x80380AE8: lhu         $t9, 0x9C($t7)
    ctx->r25 = MEM_HU(ctx->r15, 0X9C);
    // 0x80380AEC: bne         $t9, $at, L_80380B8C
    if (ctx->r25 != ctx->r1) {
        // 0x80380AF0: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_80380B8C;
    }
    // 0x80380AF0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80380AF4: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80380AF8: addiu       $a0, $zero, 0x63
    ctx->r4 = ADD32(0, 0X63);
    // 0x80380AFC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80380B00: lw          $v0, 0x320($t6)
    ctx->r2 = MEM_W(ctx->r14, 0X320);
    // 0x80380B04: beq         $v0, $zero, L_80380B1C
    if (ctx->r2 == 0) {
        // 0x80380B08: nop
    
            goto L_80380B1C;
    }
    // 0x80380B08: nop

    // 0x80380B0C: beq         $v0, $zero, L_80380B8C
    if (ctx->r2 == 0) {
        // 0x80380B10: nop
    
            goto L_80380B8C;
    }
    // 0x80380B10: nop

    // 0x80380B14: lbu         $t8, 0x26C($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X26C);
    // 0x80380B18: beq         $t8, $zero, L_80380B8C
    if (ctx->r24 == 0) {
        // 0x80380B1C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_80380B8C;
    }
L_80380B1C:
    // 0x80380B1C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80380B20: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80380B24: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80380B28: lwc1        $f8, -0xC3C($at)
    ctx->f8.u32l = MEM_W(ctx->r1, -0XC3C);
    // 0x80380B2C: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x80380B30: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80380B34: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80380B38: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80380B3C: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80380B40: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x80380B44: jal         0x8032C360
    // 0x80380B48: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_5;
    // 0x80380B48: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_5:
    // 0x80380B4C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80380B50: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x80380B54: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80380B58: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80380B5C: sw          $zero, 0x320($t6)
    MEM_W(0X320, ctx->r14) = 0;
    // 0x80380B60: lw          $s0, 0x0($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X0);
    // 0x80380B64: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x80380B68: lh          $t7, 0x308($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X308);
    // 0x80380B6C: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x80380B70: sh          $t9, 0xC($s0)
    MEM_H(0XC, ctx->r16) = ctx->r25;
    // 0x80380B74: lw          $s0, 0x0($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X0);
    // 0x80380B78: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80380B7C: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380B80: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x80380B84: jal         0x8032AAF0
    // 0x80380B88: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    load_animal(rdram, ctx);
        goto after_6;
    // 0x80380B88: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    after_6:
L_80380B8C:
    // 0x80380B8C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80380B90: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80380B94: lbu         $v0, 0x365($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X365);
    // 0x80380B98: beq         $v0, $zero, L_80380BCC
    if (ctx->r2 == 0) {
        // 0x80380B9C: addiu       $at, $zero, 0x12
        ctx->r1 = ADD32(0, 0X12);
            goto L_80380BCC;
    }
    // 0x80380B9C: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x80380BA0: beq         $v0, $at, L_80380BB0
    if (ctx->r2 == ctx->r1) {
        // 0x80380BA4: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80380BB0;
    }
    // 0x80380BA4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80380BA8: b           L_80380BCC
    // 0x80380BAC: sb          $zero, 0x365($s0)
    MEM_B(0X365, ctx->r16) = 0;
        goto L_80380BCC;
    // 0x80380BAC: sb          $zero, 0x365($s0)
    MEM_B(0X365, ctx->r16) = 0;
L_80380BB0:
    // 0x80380BB0: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x80380BB4: lhu         $t6, 0x32A($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X32A);
    // 0x80380BB8: subu        $t8, $t9, $t6
    ctx->r24 = SUB32(ctx->r25, ctx->r14);
    // 0x80380BBC: slti        $at, $t8, 0x9
    ctx->r1 = SIGNED(ctx->r24) < 0X9 ? 1 : 0;
    // 0x80380BC0: bne         $at, $zero, L_80380BCC
    if (ctx->r1 != 0) {
        // 0x80380BC4: nop
    
            goto L_80380BCC;
    }
    // 0x80380BC4: nop

    // 0x80380BC8: sb          $zero, 0x365($s0)
    MEM_B(0X365, ctx->r16) = 0;
L_80380BCC:
    // 0x80380BCC: jal         0x8035DA60
    // 0x80380BD0: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_7;
    // 0x80380BD0: nop

    after_7:
    // 0x80380BD4: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    // 0x80380BD8: addiu       $a1, $zero, 0x19
    ctx->r5 = ADD32(0, 0X19);
    // 0x80380BDC: jal         0x8034B64C
    // 0x80380BE0: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    func_8034B64C_75CCFC(rdram, ctx);
        goto after_8;
    // 0x80380BE0: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    after_8:
    // 0x80380BE4: jal         0x8035D734
    // 0x80380BE8: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_9;
    // 0x80380BE8: nop

    after_9:
    // 0x80380BEC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80380BF0: lw          $v0, 0x5528($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5528);
    // 0x80380BF4: addiu       $at, $zero, 0xC
    ctx->r1 = ADD32(0, 0XC);
    // 0x80380BF8: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x80380BFC: lhu         $t7, 0x3C4($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X3C4);
    // 0x80380C00: addiu       $s0, $s0, 0x2ECE
    ctx->r16 = ADD32(ctx->r16, 0X2ECE);
    // 0x80380C04: lui         $t6, 0x1
    ctx->r14 = S32(0X1 << 16);
    // 0x80380C08: bne         $t7, $at, L_80380C34
    if (ctx->r15 != ctx->r1) {
        // 0x80380C0C: lui         $t3, 0x803F
        ctx->r11 = S32(0X803F << 16);
            goto L_80380C34;
    }
    // 0x80380C0C: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x80380C10: lh          $t9, 0x3C6($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X3C6);
    // 0x80380C14: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80380C18: lui         $t7, 0x1
    ctx->r15 = S32(0X1 << 16);
    // 0x80380C1C: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80380C20: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x80380C24: mflo        $t8
    ctx->r24 = lo;
    // 0x80380C28: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x80380C2C: b           L_80380C38
    // 0x80380C30: sw          $t9, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r25;
        goto L_80380C38;
    // 0x80380C30: sw          $t9, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r25;
L_80380C34:
    // 0x80380C34: sw          $t6, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r14;
L_80380C38:
    // 0x80380C38: lhu         $t7, 0x0($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X0);
    // 0x80380C3C: addiu       $a0, $zero, 0x138
    ctx->r4 = ADD32(0, 0X138);
    // 0x80380C40: beq         $t7, $zero, L_80380C58
    if (ctx->r15 == 0) {
        // 0x80380C44: nop
    
            goto L_80380C58;
    }
    // 0x80380C44: nop

    // 0x80380C48: lhu         $t3, 0x2ECC($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X2ECC);
    // 0x80380C4C: slti        $at, $t3, 0x1F
    ctx->r1 = SIGNED(ctx->r11) < 0X1F ? 1 : 0;
    // 0x80380C50: beq         $at, $zero, L_80380D8C
    if (ctx->r1 == 0) {
        // 0x80380C54: nop
    
            goto L_80380D8C;
    }
    // 0x80380C54: nop

L_80380C58:
    // 0x80380C58: jal         0x802BAD60
    // 0x80380C5C: addiu       $a1, $zero, 0x32C
    ctx->r5 = ADD32(0, 0X32C);
    func_802BAD60_6CC410(rdram, ctx);
        goto after_10;
    // 0x80380C5C: addiu       $a1, $zero, 0x32C
    ctx->r5 = ADD32(0, 0X32C);
    after_10:
    // 0x80380C60: addiu       $a0, $zero, 0x232
    ctx->r4 = ADD32(0, 0X232);
    // 0x80380C64: addiu       $a1, $zero, 0x177
    ctx->r5 = ADD32(0, 0X177);
    // 0x80380C68: jal         0x802C5F34
    // 0x80380C6C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_802C5F34_6D75E4(rdram, ctx);
        goto after_11;
    // 0x80380C6C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_11:
    // 0x80380C70: addiu       $a0, $zero, 0x465
    ctx->r4 = ADD32(0, 0X465);
    // 0x80380C74: jal         0x802BB1F0
    // 0x80380C78: addiu       $a1, $zero, 0x7D
    ctx->r5 = ADD32(0, 0X7D);
    func_802BB1F0_6CC8A0(rdram, ctx);
        goto after_12;
    // 0x80380C78: addiu       $a1, $zero, 0x7D
    ctx->r5 = ADD32(0, 0X7D);
    after_12:
    // 0x80380C7C: jal         0x802BC1F4
    // 0x80380C80: addiu       $a0, $zero, 0x2EE
    ctx->r4 = ADD32(0, 0X2EE);
    func_802BC1F4_6CD8A4(rdram, ctx);
        goto after_13;
    // 0x80380C80: addiu       $a0, $zero, 0x2EE
    ctx->r4 = ADD32(0, 0X2EE);
    after_13:
    // 0x80380C84: addiu       $a0, $zero, 0x32C
    ctx->r4 = ADD32(0, 0X32C);
    // 0x80380C88: addiu       $a1, $zero, 0xFA
    ctx->r5 = ADD32(0, 0XFA);
    // 0x80380C8C: addiu       $a2, $zero, 0x138
    ctx->r6 = ADD32(0, 0X138);
    // 0x80380C90: jal         0x802C44E8
    // 0x80380C94: addiu       $a3, $zero, 0x138
    ctx->r7 = ADD32(0, 0X138);
    func_802C44E8_6D5B98(rdram, ctx);
        goto after_14;
    // 0x80380C94: addiu       $a3, $zero, 0x138
    ctx->r7 = ADD32(0, 0X138);
    after_14:
    // 0x80380C98: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x80380C9C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x80380CA0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80380CA4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80380CA8: addiu       $a0, $zero, 0x5D
    ctx->r4 = ADD32(0, 0X5D);
    // 0x80380CAC: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80380CB0: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    // 0x80380CB4: jal         0x8038CCF0
    // 0x80380CB8: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    func_8038CCF0_79E3A0(rdram, ctx);
        goto after_15;
    // 0x80380CB8: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_15:
    // 0x80380CBC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x80380CC0: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80380CC4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80380CC8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80380CCC: addiu       $a0, $zero, -0x5E
    ctx->r4 = ADD32(0, -0X5E);
    // 0x80380CD0: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x80380CD4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80380CD8: jal         0x8038CCF0
    // 0x80380CDC: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    func_8038CCF0_79E3A0(rdram, ctx);
        goto after_16;
    // 0x80380CDC: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_16:
    // 0x80380CE0: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80380CE4: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80380CE8: lh          $a1, 0x98($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X98);
    // 0x80380CEC: lh          $t8, 0xA0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XA0);
    // 0x80380CF0: lh          $a3, 0x9A($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X9A);
    // 0x80380CF4: lh          $t7, 0xA2($v1)
    ctx->r15 = MEM_H(ctx->r3, 0XA2);
    // 0x80380CF8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80380CFC: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80380D00: subu        $a0, $t8, $a1
    ctx->r4 = SUB32(ctx->r24, ctx->r5);
    // 0x80380D04: subu        $a2, $t7, $a3
    ctx->r6 = SUB32(ctx->r15, ctx->r7);
    // 0x80380D08: lh          $t7, 0x316($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X316);
    // 0x80380D0C: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80380D10: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80380D14: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x80380D18: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80380D1C: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x80380D20: addiu       $t9, $t9, 0x2350
    ctx->r25 = ADD32(ctx->r25, 0X2350);
    // 0x80380D24: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80380D28: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x80380D2C: lh          $t1, 0x2D0($t0)
    ctx->r9 = MEM_H(ctx->r8, 0X2D0);
    // 0x80380D30: lh          $t2, 0x384($t0)
    ctx->r10 = MEM_H(ctx->r8, 0X384);
    // 0x80380D34: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x80380D38: multu       $t1, $a2
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380D3C: mflo        $t6
    ctx->r14 = lo;
    // 0x80380D40: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x80380D44: nop

    // 0x80380D48: multu       $a0, $t2
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380D4C: mflo        $t8
    ctx->r24 = lo;
    // 0x80380D50: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x80380D54: addu        $t4, $t7, $t9
    ctx->r12 = ADD32(ctx->r15, ctx->r25);
    // 0x80380D58: multu       $a2, $t2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380D5C: mflo        $t7
    ctx->r15 = lo;
    // 0x80380D60: sra         $t9, $t7, 8
    ctx->r25 = S32(SIGNED(ctx->r15) >> 8);
    // 0x80380D64: nop

    // 0x80380D68: multu       $t1, $a0
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80380D6C: mflo        $t6
    ctx->r14 = lo;
    // 0x80380D70: sra         $t8, $t6, 8
    ctx->r24 = S32(SIGNED(ctx->r14) >> 8);
    // 0x80380D74: subu        $t6, $t9, $t8
    ctx->r14 = SUB32(ctx->r25, ctx->r24);
    // 0x80380D78: addu        $t9, $a1, $t4
    ctx->r25 = ADD32(ctx->r5, ctx->r12);
    // 0x80380D7C: addu        $t8, $a3, $t6
    ctx->r24 = ADD32(ctx->r7, ctx->r14);
    // 0x80380D80: sh          $t9, 0xA0($v1)
    MEM_H(0XA0, ctx->r3) = ctx->r25;
    // 0x80380D84: sh          $t8, 0xA2($v1)
    MEM_H(0XA2, ctx->r3) = ctx->r24;
    // 0x80380D88: lhu         $t3, 0x2ECC($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X2ECC);
L_80380D8C:
    // 0x80380D8C: beq         $t3, $zero, L_80380E08
    if (ctx->r11 == 0) {
        // 0x80380D90: nop
    
            goto L_80380E08;
    }
    // 0x80380D90: nop

    // 0x80380D94: jal         0x802DB8DC
    // 0x80380D98: nop

    backup_joint_positions(rdram, ctx);
        goto after_17;
    // 0x80380D98: nop

    after_17:
    // 0x80380D9C: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x80380DA0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80380DA4: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80380DA8: beq         $v0, $at, L_80380DC4
    if (ctx->r2 == ctx->r1) {
        // 0x80380DAC: addiu       $a0, $a0, 0x5770
        ctx->r4 = ADD32(ctx->r4, 0X5770);
            goto L_80380DC4;
    }
    // 0x80380DAC: addiu       $a0, $a0, 0x5770
    ctx->r4 = ADD32(ctx->r4, 0X5770);
    // 0x80380DB0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80380DB4: beq         $v0, $at, L_80380DE8
    if (ctx->r2 == ctx->r1) {
        // 0x80380DB8: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_80380DE8;
    }
    // 0x80380DB8: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80380DBC: b           L_80380E08
    // 0x80380DC0: nop

        goto L_80380E08;
    // 0x80380DC0: nop

L_80380DC4:
    // 0x80380DC4: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80380DC8: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80380DCC: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80380DD0: addiu       $a3, $a3, 0x57BC
    ctx->r7 = ADD32(ctx->r7, 0X57BC);
    // 0x80380DD4: addiu       $a2, $a2, 0x5798
    ctx->r6 = ADD32(ctx->r6, 0X5798);
    // 0x80380DD8: jal         0x802DB670
    // 0x80380DDC: addiu       $a1, $a1, 0x5784
    ctx->r5 = ADD32(ctx->r5, 0X5784);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_18;
    // 0x80380DDC: addiu       $a1, $a1, 0x5784
    ctx->r5 = ADD32(ctx->r5, 0X5784);
    after_18:
    // 0x80380DE0: b           L_80380E08
    // 0x80380DE4: nop

        goto L_80380E08;
    // 0x80380DE4: nop

L_80380DE8:
    // 0x80380DE8: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80380DEC: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80380DF0: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80380DF4: addiu       $a3, $a3, 0x580C
    ctx->r7 = ADD32(ctx->r7, 0X580C);
    // 0x80380DF8: addiu       $a2, $a2, 0x5798
    ctx->r6 = ADD32(ctx->r6, 0X5798);
    // 0x80380DFC: addiu       $a1, $a1, 0x5784
    ctx->r5 = ADD32(ctx->r5, 0X5784);
    // 0x80380E00: jal         0x802DB670
    // 0x80380E04: addiu       $a0, $a0, 0x5770
    ctx->r4 = ADD32(ctx->r4, 0X5770);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_19;
    // 0x80380E04: addiu       $a0, $a0, 0x5770
    ctx->r4 = ADD32(ctx->r4, 0X5770);
    after_19:
L_80380E08:
    // 0x80380E08: jal         0x8038064C
    // 0x80380E0C: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_20;
    // 0x80380E0C: nop

    after_20:
    // 0x80380E10: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80380E14: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x80380E18: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80380E1C: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x80380E20: lhu         $t6, 0x9C($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X9C);
    // 0x80380E24: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80380E28: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80380E2C: bne         $t6, $at, L_80381030
    if (ctx->r14 != ctx->r1) {
        // 0x80380E30: addiu       $t2, $t2, 0x4278
        ctx->r10 = ADD32(ctx->r10, 0X4278);
            goto L_80381030;
    }
    // 0x80380E30: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x80380E34: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80380E38: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80380E3C: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x80380E40: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380E44: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380E48: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380E4C: sh          $t6, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r14;
    // 0x80380E50: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380E54: lh          $t8, 0xC($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XC);
    // 0x80380E58: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380E5C: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380E60: sh          $t6, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r14;
    // 0x80380E64: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380E68: lh          $t9, 0x14($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X14);
    // 0x80380E6C: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380E70: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380E74: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
    // 0x80380E78: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380E7C: lh          $t8, 0x9C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X9C);
    // 0x80380E80: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380E84: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380E88: sh          $t6, 0x9C($v1)
    MEM_H(0X9C, ctx->r3) = ctx->r14;
    // 0x80380E8C: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380E90: lh          $t9, 0xA4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XA4);
    // 0x80380E94: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380E98: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380E9C: sh          $t6, 0xA4($v1)
    MEM_H(0XA4, ctx->r3) = ctx->r14;
    // 0x80380EA0: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380EA4: lh          $t8, 0xD4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XD4);
    // 0x80380EA8: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380EAC: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380EB0: sh          $t6, 0xD4($v1)
    MEM_H(0XD4, ctx->r3) = ctx->r14;
    // 0x80380EB4: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380EB8: lh          $t9, 0xDC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XDC);
    // 0x80380EBC: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380EC0: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380EC4: sh          $t6, 0xDC($v1)
    MEM_H(0XDC, ctx->r3) = ctx->r14;
    // 0x80380EC8: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380ECC: lh          $t8, 0xB4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XB4);
    // 0x80380ED0: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380ED4: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380ED8: sh          $t6, 0xB4($v1)
    MEM_H(0XB4, ctx->r3) = ctx->r14;
    // 0x80380EDC: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380EE0: lh          $t9, 0xC4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC4);
    // 0x80380EE4: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380EE8: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380EEC: sh          $t6, 0xC4($v1)
    MEM_H(0XC4, ctx->r3) = ctx->r14;
    // 0x80380EF0: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380EF4: lh          $t8, 0x1C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X1C);
    // 0x80380EF8: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380EFC: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380F00: sh          $t6, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r14;
    // 0x80380F04: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380F08: lh          $t9, 0x24($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X24);
    // 0x80380F0C: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380F10: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380F14: sh          $t6, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r14;
    // 0x80380F18: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380F1C: lh          $t8, 0x3C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X3C);
    // 0x80380F20: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380F24: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380F28: sh          $t6, 0x3C($v1)
    MEM_H(0X3C, ctx->r3) = ctx->r14;
    // 0x80380F2C: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380F30: lh          $t9, 0x44($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X44);
    // 0x80380F34: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380F38: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380F3C: sh          $t6, 0x44($v1)
    MEM_H(0X44, ctx->r3) = ctx->r14;
    // 0x80380F40: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380F44: lh          $t8, 0x4C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4C);
    // 0x80380F48: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380F4C: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380F50: sh          $t6, 0x4C($v1)
    MEM_H(0X4C, ctx->r3) = ctx->r14;
    // 0x80380F54: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380F58: lh          $t9, 0x6C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X6C);
    // 0x80380F5C: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380F60: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380F64: sh          $t6, 0x6C($v1)
    MEM_H(0X6C, ctx->r3) = ctx->r14;
    // 0x80380F68: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380F6C: lh          $t8, 0x54($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X54);
    // 0x80380F70: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380F74: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380F78: sh          $t6, 0x54($v1)
    MEM_H(0X54, ctx->r3) = ctx->r14;
    // 0x80380F7C: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380F80: lh          $t9, 0x5C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X5C);
    // 0x80380F84: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380F88: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380F8C: sh          $t6, 0x5C($v1)
    MEM_H(0X5C, ctx->r3) = ctx->r14;
    // 0x80380F90: lh          $t9, 0x308($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X308);
    // 0x80380F94: lh          $t8, 0x64($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X64);
    // 0x80380F98: sll         $t7, $t9, 5
    ctx->r15 = S32(ctx->r25 << 5);
    // 0x80380F9C: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80380FA0: sh          $t6, 0x64($v1)
    MEM_H(0X64, ctx->r3) = ctx->r14;
    // 0x80380FA4: lh          $t8, 0x308($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X308);
    // 0x80380FA8: lh          $t9, 0x74($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X74);
    // 0x80380FAC: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x80380FB0: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x80380FB4: lh          $t8, 0x1C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X1C);
    // 0x80380FB8: lh          $t7, 0x3C($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X3C);
    // 0x80380FBC: sh          $t6, 0x74($v1)
    MEM_H(0X74, ctx->r3) = ctx->r14;
    // 0x80380FC0: addiu       $t9, $t8, -0x130
    ctx->r25 = ADD32(ctx->r24, -0X130);
    // 0x80380FC4: addiu       $t6, $t7, -0x130
    ctx->r14 = ADD32(ctx->r15, -0X130);
    // 0x80380FC8: lh          $t8, 0x44($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X44);
    // 0x80380FCC: lh          $t7, 0x4C($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4C);
    // 0x80380FD0: sh          $t9, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r25;
    // 0x80380FD4: sh          $t6, 0x3C($v1)
    MEM_H(0X3C, ctx->r3) = ctx->r14;
    // 0x80380FD8: addiu       $t9, $t8, -0x130
    ctx->r25 = ADD32(ctx->r24, -0X130);
    // 0x80380FDC: addiu       $t6, $t7, -0x130
    ctx->r14 = ADD32(ctx->r15, -0X130);
    // 0x80380FE0: lh          $t8, 0x6C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X6C);
    // 0x80380FE4: lh          $t7, 0x24($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X24);
    // 0x80380FE8: sh          $t9, 0x44($v1)
    MEM_H(0X44, ctx->r3) = ctx->r25;
    // 0x80380FEC: sh          $t6, 0x4C($v1)
    MEM_H(0X4C, ctx->r3) = ctx->r14;
    // 0x80380FF0: addiu       $t9, $t8, -0x130
    ctx->r25 = ADD32(ctx->r24, -0X130);
    // 0x80380FF4: addiu       $t6, $t7, -0x130
    ctx->r14 = ADD32(ctx->r15, -0X130);
    // 0x80380FF8: lh          $t8, 0x54($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X54);
    // 0x80380FFC: lh          $t7, 0x5C($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X5C);
    // 0x80381000: sh          $t9, 0x6C($v1)
    MEM_H(0X6C, ctx->r3) = ctx->r25;
    // 0x80381004: sh          $t6, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r14;
    // 0x80381008: addiu       $t9, $t8, -0x130
    ctx->r25 = ADD32(ctx->r24, -0X130);
    // 0x8038100C: addiu       $t6, $t7, -0x130
    ctx->r14 = ADD32(ctx->r15, -0X130);
    // 0x80381010: lh          $t8, 0x64($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X64);
    // 0x80381014: lh          $t7, 0x74($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X74);
    // 0x80381018: sh          $t9, 0x54($v1)
    MEM_H(0X54, ctx->r3) = ctx->r25;
    // 0x8038101C: sh          $t6, 0x5C($v1)
    MEM_H(0X5C, ctx->r3) = ctx->r14;
    // 0x80381020: addiu       $t9, $t8, -0x130
    ctx->r25 = ADD32(ctx->r24, -0X130);
    // 0x80381024: addiu       $t6, $t7, -0x130
    ctx->r14 = ADD32(ctx->r15, -0X130);
    // 0x80381028: sh          $t9, 0x64($v1)
    MEM_H(0X64, ctx->r3) = ctx->r25;
    // 0x8038102C: sh          $t6, 0x74($v1)
    MEM_H(0X74, ctx->r3) = ctx->r14;
L_80381030:
    // 0x80381030: lw          $s0, 0x0($t2)
    ctx->r16 = MEM_W(ctx->r10, 0X0);
    // 0x80381034: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x80381038: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x8038103C: addu        $t8, $s0, $t3
    ctx->r24 = ADD32(ctx->r16, ctx->r11);
    // 0x80381040: lw          $t0, 0x918($t8)
    ctx->r8 = MEM_W(ctx->r24, 0X918);
    // 0x80381044: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80381048: addiu       $t9, $t0, 0x1E
    ctx->r25 = ADD32(ctx->r8, 0X1E);
    // 0x8038104C: slti        $at, $t9, 0xFA
    ctx->r1 = SIGNED(ctx->r25) < 0XFA ? 1 : 0;
    // 0x80381050: beq         $at, $zero, L_80381A5C
    if (ctx->r1 == 0) {
        // 0x80381054: nop
    
            goto L_80381A5C;
    }
    // 0x80381054: nop

    // 0x80381058: lbu         $t7, 0x2EDA($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDA);
    // 0x8038105C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80381060: beq         $t7, $zero, L_80381A5C
    if (ctx->r15 == 0) {
        // 0x80381064: nop
    
            goto L_80381A5C;
    }
    // 0x80381064: nop

    // 0x80381068: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
    // 0x8038106C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80381070: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80381074: bne         $a1, $zero, L_803810AC
    if (ctx->r5 != 0) {
        // 0x80381078: nop
    
            goto L_803810AC;
    }
    // 0x80381078: nop

    // 0x8038107C: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x80381080: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80381084: beq         $v0, $zero, L_803810AC
    if (ctx->r2 == 0) {
        // 0x80381088: nop
    
            goto L_803810AC;
    }
    // 0x80381088: nop

    // 0x8038108C: beq         $v0, $at, L_803810AC
    if (ctx->r2 == ctx->r1) {
        // 0x80381090: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803810AC;
    }
    // 0x80381090: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80381094: bne         $v0, $at, L_80381A5C
    if (ctx->r2 != ctx->r1) {
        // 0x80381098: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_80381A5C;
    }
    // 0x80381098: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038109C: lbu         $t6, 0x2AA3($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2AA3);
    // 0x803810A0: slti        $at, $t6, 0xB
    ctx->r1 = SIGNED(ctx->r14) < 0XB ? 1 : 0;
    // 0x803810A4: bne         $at, $zero, L_80381A5C
    if (ctx->r1 != 0) {
        // 0x803810A8: nop
    
            goto L_80381A5C;
    }
    // 0x803810A8: nop

L_803810AC:
    // 0x803810AC: lh          $t8, 0x2C18($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C18);
    // 0x803810B0: bne         $t8, $zero, L_80381108
    if (ctx->r24 != 0) {
        // 0x803810B4: nop
    
            goto L_80381108;
    }
    // 0x803810B4: nop

    // 0x803810B8: beq         $a1, $zero, L_80381108
    if (ctx->r5 == 0) {
        // 0x803810BC: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_80381108;
    }
    // 0x803810BC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803810C0: lh          $t9, 0x2A98($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2A98);
    // 0x803810C4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803810C8: addiu       $t6, $t6, 0x28E0
    ctx->r14 = ADD32(ctx->r14, 0X28E0);
    // 0x803810CC: sll         $t7, $t9, 3
    ctx->r15 = S32(ctx->r25 << 3);
    // 0x803810D0: subu        $t7, $t7, $t9
    ctx->r15 = SUB32(ctx->r15, ctx->r25);
    // 0x803810D4: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x803810D8: subu        $t7, $t7, $t9
    ctx->r15 = SUB32(ctx->r15, ctx->r25);
    // 0x803810DC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803810E0: addu        $v0, $t7, $t6
    ctx->r2 = ADD32(ctx->r15, ctx->r14);
    // 0x803810E4: lh          $a0, 0x0($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X0);
    // 0x803810E8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803810EC: beq         $a0, $at, L_803810FC
    if (ctx->r4 == ctx->r1) {
        // 0x803810F0: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803810FC;
    }
    // 0x803810F0: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803810F4: bne         $a0, $at, L_80381108
    if (ctx->r4 != ctx->r1) {
        // 0x803810F8: nop
    
            goto L_80381108;
    }
    // 0x803810F8: nop

L_803810FC:
    // 0x803810FC: lb          $t8, 0x64($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X64);
    // 0x80381100: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80381104: beq         $t8, $at, L_80381A5C
    if (ctx->r24 == ctx->r1) {
        // 0x80381108: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_80381A5C;
    }
L_80381108:
    // 0x80381108: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038110C: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80381110: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
    // 0x80381114: addu        $a0, $s0, $t9
    ctx->r4 = ADD32(ctx->r16, ctx->r25);
    // 0x80381118: lh          $t6, 0x302($t7)
    ctx->r14 = MEM_H(ctx->r15, 0X302);
    // 0x8038111C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381120: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381124: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80381128: lw          $t9, 0x2EB0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB0);
    // 0x8038112C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80381130: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80381134: negu        $t8, $t6
    ctx->r24 = SUB32(0, ctx->r14);
    // 0x80381138: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038113C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80381140: lw          $t6, 0x2EB4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB4);
    // 0x80381144: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x80381148: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x8038114C: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x80381150: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80381154: bgez        $t9, L_80381164
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80381158: sra         $t7, $t9, 2
        ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
            goto L_80381164;
    }
    // 0x80381158: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8038115C: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x80381160: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_80381164:
    // 0x80381164: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80381168: lw          $t9, 0x2EB8($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB8);
    // 0x8038116C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80381170: bgez        $t6, L_80381180
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80381174: sra         $t8, $t6, 2
        ctx->r24 = S32(SIGNED(ctx->r14) >> 2);
            goto L_80381180;
    }
    // 0x80381174: sra         $t8, $t6, 2
    ctx->r24 = S32(SIGNED(ctx->r14) >> 2);
    // 0x80381178: addiu       $at, $t6, 0x3
    ctx->r1 = ADD32(ctx->r14, 0X3);
    // 0x8038117C: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_80381180:
    // 0x80381180: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80381184: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80381188: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038118C: lh          $t6, 0x2ED2($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED2);
    // 0x80381190: lw          $t8, 0x2ED4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2ED4);
    // 0x80381194: bgez        $t9, L_803811A4
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80381198: sra         $t7, $t9, 2
        ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
            goto L_803811A4;
    }
    // 0x80381198: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8038119C: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x803811A0: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_803811A4:
    // 0x803811A4: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x803811A8: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x803811AC: jal         0x80127640
    // 0x803811B0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    func_80127640(rdram, ctx);
        goto after_21;
    // 0x803811B0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    after_21:
    // 0x803811B4: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x803811B8: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x803811BC: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x803811C0: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x803811C4: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x803811C8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803811CC: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x803811D0: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x803811D4: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x803811D8: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803811DC: lw          $s0, 0x0($t2)
    ctx->r16 = MEM_W(ctx->r10, 0X0);
    // 0x803811E0: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803811E4: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x803811E8: addu        $t6, $s0, $t3
    ctx->r14 = ADD32(ctx->r16, ctx->r11);
    // 0x803811EC: lw          $t8, 0x918($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X918);
    // 0x803811F0: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803811F4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803811F8: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x803811FC: addu        $t7, $s0, $t9
    ctx->r15 = ADD32(ctx->r16, ctx->r25);
    // 0x80381200: addu        $t6, $t7, $at
    ctx->r14 = ADD32(ctx->r15, ctx->r1);
    // 0x80381204: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80381208: lw          $s0, 0x0($t2)
    ctx->r16 = MEM_W(ctx->r10, 0X0);
    // 0x8038120C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80381210: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80381214: addu        $t8, $s0, $t3
    ctx->r24 = ADD32(ctx->r16, ctx->r11);
    // 0x80381218: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8038121C: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80381220: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80381224: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x80381228: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8038122C: lhu         $t6, 0x9C($t0)
    ctx->r14 = MEM_HU(ctx->r8, 0X9C);
    // 0x80381230: bnel        $t6, $zero, L_8038127C
    if (ctx->r14 != 0) {
        // 0x80381234: lhu         $a0, 0xBA($t0)
        ctx->r4 = MEM_HU(ctx->r8, 0XBA);
            goto L_8038127C;
    }
    goto skip_4;
    // 0x80381234: lhu         $a0, 0xBA($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0XBA);
    skip_4:
    // 0x80381238: lhu         $a0, 0xBA($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0XBA);
    // 0x8038123C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80381240: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80381244: sll         $t8, $a0, 3
    ctx->r24 = S32(ctx->r4 << 3);
    // 0x80381248: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x8038124C: lui         $at, 0x3E80
    ctx->r1 = S32(0X3E80 << 16);
    // 0x80381250: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80381254: mflo        $t9
    ctx->r25 = lo;
    // 0x80381258: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8038125C: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80381260: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80381264: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x80381268: jal         0x8038C230
    // 0x8038126C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_22;
    // 0x8038126C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    after_22:
    // 0x80381270: b           L_803812B0
    // 0x80381274: nop

        goto L_803812B0;
    // 0x80381274: nop

    // 0x80381278: lhu         $a0, 0xBA($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0XBA);
L_8038127C:
    // 0x8038127C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80381280: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80381284: sll         $t8, $a0, 4
    ctx->r24 = S32(ctx->r4 << 4);
    // 0x80381288: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x8038128C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80381290: lwc1        $f16, -0xC38($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0XC38);
    // 0x80381294: mflo        $t9
    ctx->r25 = lo;
    // 0x80381298: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8038129C: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803812A0: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x803812A4: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x803812A8: jal         0x8038C230
    // 0x803812AC: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_23;
    // 0x803812AC: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    after_23:
L_803812B0:
    // 0x803812B0: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803812B4: lw          $t8, 0x2EBC($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EBC);
    // 0x803812B8: addiu       $v0, $zero, 0x50
    ctx->r2 = ADD32(0, 0X50);
    // 0x803812BC: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803812C0: multu       $t8, $v0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803812C4: lw          $t7, 0x2EC0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EC0);
    // 0x803812C8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803812CC: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x803812D0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803812D4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803812D8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803812DC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803812E0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803812E4: mflo        $a2
    ctx->r6 = lo;
    // 0x803812E8: sra         $t9, $a2, 6
    ctx->r25 = S32(SIGNED(ctx->r6) >> 6);
    // 0x803812EC: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x803812F0: multu       $t7, $v0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803812F4: mflo        $a3
    ctx->r7 = lo;
    // 0x803812F8: sra         $t6, $a3, 6
    ctx->r14 = S32(SIGNED(ctx->r7) >> 6);
    // 0x803812FC: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80381300: multu       $t8, $v0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80381304: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381308: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038130C: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80381310: addiu       $t8, $t8, 0x1D70
    ctx->r24 = ADD32(ctx->r24, 0X1D70);
    // 0x80381314: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80381318: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8038131C: mflo        $t9
    ctx->r25 = lo;
    // 0x80381320: sra         $t7, $t9, 6
    ctx->r15 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80381324: jal         0x802C78B0
    // 0x80381328: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_24;
    // 0x80381328: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    after_24:
    // 0x8038132C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80381330: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80381334: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80381338: lui         $t6, 0x7D33
    ctx->r14 = S32(0X7D33 << 16);
    // 0x8038133C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80381340: sw          $t9, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r25;
    // 0x80381344: ori         $t6, $t6, 0xFFFF
    ctx->r14 = ctx->r14 | 0XFFFF;
    // 0x80381348: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8038134C: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80381350: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80381354: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80381358: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x8038135C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80381360: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80381364: bne         $a1, $zero, L_803813C8
    if (ctx->r5 != 0) {
        // 0x80381368: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_803813C8;
    }
    // 0x80381368: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038136C: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80381370: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80381374: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80381378: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x8038137C: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x80381380: sll         $t8, $t8, 4
    ctx->r24 = S32(ctx->r24 << 4);
    // 0x80381384: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80381388: addiu       $t6, $t6, 0x1F80
    ctx->r14 = ADD32(ctx->r14, 0X1F80);
    // 0x8038138C: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80381390: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80381394: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80381398: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8038139C: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    // 0x803813A0: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x803813A4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803813A8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803813AC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803813B0: jal         0x802C78B0
    // 0x803813B4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_25;
    // 0x803813B4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_25:
    // 0x803813B8: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803813BC: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803813C0: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x803813C4: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
L_803813C8:
    // 0x803813C8: bne         $a1, $zero, L_80381414
    if (ctx->r5 != 0) {
        // 0x803813CC: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_80381414;
    }
    // 0x803813CC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803813D0: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x803813D4: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803813D8: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803813DC: addiu       $t9, $t9, 0x21C0
    ctx->r25 = ADD32(ctx->r25, 0X21C0);
    // 0x803813E0: ori         $a2, $a2, 0x4000
    ctx->r6 = ctx->r6 | 0X4000;
    // 0x803813E4: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803813E8: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803813EC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803813F0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x803813F4: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x803813F8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803813FC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381400: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381404: jal         0x802C78B0
    // 0x80381408: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_26;
    // 0x80381408: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_26:
    // 0x8038140C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80381410: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
L_80381414:
    // 0x80381414: lw          $t7, 0x94($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X94);
    // 0x80381418: beq         $t7, $zero, L_803814C8
    if (ctx->r15 == 0) {
        // 0x8038141C: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_803814C8;
    }
    // 0x8038141C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381420: lbu         $t6, 0x2EDD($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2EDD);
    // 0x80381424: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80381428: addiu       $a1, $zero, 0x16
    ctx->r5 = ADD32(0, 0X16);
    // 0x8038142C: bne         $t6, $zero, L_80381470
    if (ctx->r14 != 0) {
        // 0x80381430: sll         $a2, $t7, 2
        ctx->r6 = S32(ctx->r15 << 2);
            goto L_80381470;
    }
    // 0x80381430: sll         $a2, $t7, 2
    ctx->r6 = S32(ctx->r15 << 2);
    // 0x80381434: addu        $a2, $a2, $t7
    ctx->r6 = ADD32(ctx->r6, ctx->r15);
    // 0x80381438: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038143C: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80381440: sll         $a2, $a2, 4
    ctx->r6 = S32(ctx->r6 << 4);
    // 0x80381444: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80381448: addiu       $t6, $t6, 0x2320
    ctx->r14 = ADD32(ctx->r14, 0X2320);
    // 0x8038144C: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80381450: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80381454: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80381458: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8038145C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381460: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381464: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381468: jal         0x802C78B0
    // 0x8038146C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_27;
    // 0x8038146C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_27:
L_80381470:
    // 0x80381470: lw          $a2, 0x94($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X94);
    // 0x80381474: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80381478: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x8038147C: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x80381480: addu        $t7, $t7, $a2
    ctx->r15 = ADD32(ctx->r15, ctx->r6);
    // 0x80381484: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x80381488: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x8038148C: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80381490: addiu       $t7, $t7, 0x2320
    ctx->r15 = ADD32(ctx->r15, 0X2320);
    // 0x80381494: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80381498: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8038149C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803814A0: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x803814A4: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x803814A8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803814AC: addiu       $a1, $zero, 0x18
    ctx->r5 = ADD32(0, 0X18);
    // 0x803814B0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803814B4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803814B8: jal         0x802C78B0
    // 0x803814BC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_28;
    // 0x803814BC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_28:
    // 0x803814C0: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803814C4: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
L_803814C8:
    // 0x803814C8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803814CC: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x803814D0: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x803814D4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803814D8: lhu         $t9, 0x9C($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X9C);
    // 0x803814DC: bnel        $t9, $at, L_803814F0
    if (ctx->r25 != ctx->r1) {
        // 0x803814E0: lui         $t0, 0x1
        ctx->r8 = S32(0X1 << 16);
            goto L_803814F0;
    }
    goto skip_5;
    // 0x803814E0: lui         $t0, 0x1
    ctx->r8 = S32(0X1 << 16);
    skip_5:
    // 0x803814E4: b           L_803814F0
    // 0x803814E8: lui         $t0, 0x2
    ctx->r8 = S32(0X2 << 16);
        goto L_803814F0;
    // 0x803814E8: lui         $t0, 0x2
    ctx->r8 = S32(0X2 << 16);
    // 0x803814EC: lui         $t0, 0x1
    ctx->r8 = S32(0X1 << 16);
L_803814F0:
    // 0x803814F0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x803814F4: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x803814F8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803814FC: lbu         $t6, 0x365($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X365);
    // 0x80381500: bne         $t6, $at, L_8038155C
    if (ctx->r14 != ctx->r1) {
        // 0x80381504: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_8038155C;
    }
    // 0x80381504: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80381508: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x8038150C: lhu         $t8, 0x32A($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X32A);
    // 0x80381510: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x80381514: addiu       $t6, $t9, -0x1
    ctx->r14 = ADD32(ctx->r25, -0X1);
    // 0x80381518: sltiu       $at, $t6, 0x5
    ctx->r1 = ctx->r14 < 0X5 ? 1 : 0;
    // 0x8038151C: beq         $at, $zero, L_8038155C
    if (ctx->r1 == 0) {
        // 0x80381520: sll         $t6, $t6, 2
        ctx->r14 = S32(ctx->r14 << 2);
            goto L_8038155C;
    }
    // 0x80381520: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80381524: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80381528: addu        $at, $at, $t6
    gpr jr_addend_80381530 = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x8038152C: lw          $t6, -0xC34($at)
    ctx->r14 = ADD32(ctx->r1, -0XC34);
    // 0x80381530: jr          $t6
    // 0x80381534: nop

    switch (jr_addend_80381530 >> 2) {
        case 0: goto L_80381538; break;
        case 1: goto L_80381544; break;
        case 2: goto L_80381554; break;
        case 3: goto L_80381544; break;
        case 4: goto L_80381538; break;
        default: switch_error(__func__, 0x80381530, 0x803BF3CC);
    }
    // 0x80381534: nop

L_80381538:
    // 0x80381538: lui         $t0, 0x2
    ctx->r8 = S32(0X2 << 16);
    // 0x8038153C: b           L_8038155C
    // 0x80381540: addiu       $a0, $zero, 0x1D4
    ctx->r4 = ADD32(0, 0X1D4);
        goto L_8038155C;
    // 0x80381540: addiu       $a0, $zero, 0x1D4
    ctx->r4 = ADD32(0, 0X1D4);
L_80381544:
    // 0x80381544: lui         $t0, 0x2
    ctx->r8 = S32(0X2 << 16);
    // 0x80381548: ori         $t0, $t0, 0x8000
    ctx->r8 = ctx->r8 | 0X8000;
    // 0x8038154C: b           L_8038155C
    // 0x80381550: addiu       $a0, $zero, 0x30D
    ctx->r4 = ADD32(0, 0X30D);
        goto L_8038155C;
    // 0x80381550: addiu       $a0, $zero, 0x30D
    ctx->r4 = ADD32(0, 0X30D);
L_80381554:
    // 0x80381554: lui         $t0, 0x3
    ctx->r8 = S32(0X3 << 16);
    // 0x80381558: addiu       $a0, $zero, 0x3A9
    ctx->r4 = ADD32(0, 0X3A9);
L_8038155C:
    // 0x8038155C: lh          $t7, 0x1C($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X1C);
    // 0x80381560: lh          $t9, 0x3C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X3C);
    // 0x80381564: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80381568: subu        $t8, $t7, $a0
    ctx->r24 = SUB32(ctx->r15, ctx->r4);
    // 0x8038156C: subu        $t6, $t9, $a0
    ctx->r14 = SUB32(ctx->r25, ctx->r4);
    // 0x80381570: lh          $t7, 0x44($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X44);
    // 0x80381574: lh          $t9, 0x4C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4C);
    // 0x80381578: sh          $t8, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r24;
    // 0x8038157C: sh          $t6, 0x3C($v1)
    MEM_H(0X3C, ctx->r3) = ctx->r14;
    // 0x80381580: subu        $t8, $t7, $a0
    ctx->r24 = SUB32(ctx->r15, ctx->r4);
    // 0x80381584: subu        $t6, $t9, $a0
    ctx->r14 = SUB32(ctx->r25, ctx->r4);
    // 0x80381588: lh          $t7, 0x6C($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X6C);
    // 0x8038158C: lh          $t9, 0x24($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X24);
    // 0x80381590: sh          $t8, 0x44($v1)
    MEM_H(0X44, ctx->r3) = ctx->r24;
    // 0x80381594: sh          $t6, 0x4C($v1)
    MEM_H(0X4C, ctx->r3) = ctx->r14;
    // 0x80381598: subu        $t8, $t7, $a0
    ctx->r24 = SUB32(ctx->r15, ctx->r4);
    // 0x8038159C: subu        $t6, $t9, $a0
    ctx->r14 = SUB32(ctx->r25, ctx->r4);
    // 0x803815A0: lh          $t7, 0x54($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X54);
    // 0x803815A4: lh          $t9, 0x5C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X5C);
    // 0x803815A8: sh          $t8, 0x6C($v1)
    MEM_H(0X6C, ctx->r3) = ctx->r24;
    // 0x803815AC: sh          $t6, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r14;
    // 0x803815B0: subu        $t8, $t7, $a0
    ctx->r24 = SUB32(ctx->r15, ctx->r4);
    // 0x803815B4: subu        $t6, $t9, $a0
    ctx->r14 = SUB32(ctx->r25, ctx->r4);
    // 0x803815B8: lh          $t7, 0x64($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X64);
    // 0x803815BC: lh          $t9, 0x74($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X74);
    // 0x803815C0: sh          $t8, 0x54($v1)
    MEM_H(0X54, ctx->r3) = ctx->r24;
    // 0x803815C4: sh          $t6, 0x5C($v1)
    MEM_H(0X5C, ctx->r3) = ctx->r14;
    // 0x803815C8: subu        $t8, $t7, $a0
    ctx->r24 = SUB32(ctx->r15, ctx->r4);
    // 0x803815CC: subu        $t6, $t9, $a0
    ctx->r14 = SUB32(ctx->r25, ctx->r4);
    // 0x803815D0: sh          $t8, 0x64($v1)
    MEM_H(0X64, ctx->r3) = ctx->r24;
    // 0x803815D4: sh          $t6, 0x74($v1)
    MEM_H(0X74, ctx->r3) = ctx->r14;
    // 0x803815D8: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x803815DC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x803815E0: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x803815E4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803815E8: sw          $t7, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r15;
    // 0x803815EC: addiu       $t9, $t9, 0x3548
    ctx->r25 = ADD32(ctx->r25, 0X3548);
    // 0x803815F0: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x803815F4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803815F8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803815FC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80381600: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x80381604: sll         $s0, $t0, 2
    ctx->r16 = S32(ctx->r8 << 2);
    // 0x80381608: addu        $s0, $s0, $t0
    ctx->r16 = ADD32(ctx->r16, ctx->r8);
    // 0x8038160C: bne         $a1, $zero, L_80381664
    if (ctx->r5 != 0) {
        // 0x80381610: addiu       $a0, $zero, 0x3
        ctx->r4 = ADD32(0, 0X3);
            goto L_80381664;
    }
    // 0x80381610: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80381614: sll         $s0, $s0, 4
    ctx->r16 = S32(ctx->r16 << 4);
    // 0x80381618: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038161C: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80381620: sra         $a3, $s0, 6
    ctx->r7 = S32(SIGNED(ctx->r16) >> 6);
    // 0x80381624: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80381628: addiu       $t8, $t8, 0x25D0
    ctx->r24 = ADD32(ctx->r24, 0X25D0);
    // 0x8038162C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80381630: or          $s0, $a3, $zero
    ctx->r16 = ctx->r7 | 0;
    // 0x80381634: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80381638: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x8038163C: addiu       $a1, $zero, 0xD
    ctx->r5 = ADD32(0, 0XD);
    // 0x80381640: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381644: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381648: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038164C: sw          $t0, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r8;
    // 0x80381650: jal         0x802C78B0
    // 0x80381654: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x80381654: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_29:
    // 0x80381658: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8038165C: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x80381660: lw          $t0, 0x90($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X90);
L_80381664:
    // 0x80381664: sll         $s0, $t0, 2
    ctx->r16 = S32(ctx->r8 << 2);
    // 0x80381668: addu        $s0, $s0, $t0
    ctx->r16 = ADD32(ctx->r16, ctx->r8);
    // 0x8038166C: sll         $s0, $s0, 4
    ctx->r16 = S32(ctx->r16 << 4);
    // 0x80381670: sra         $t9, $s0, 6
    ctx->r25 = S32(SIGNED(ctx->r16) >> 6);
    // 0x80381674: bne         $a1, $zero, L_803816B8
    if (ctx->r5 != 0) {
        // 0x80381678: or          $s0, $t9, $zero
        ctx->r16 = ctx->r25 | 0;
            goto L_803816B8;
    }
    // 0x80381678: or          $s0, $t9, $zero
    ctx->r16 = ctx->r25 | 0;
    // 0x8038167C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381680: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80381684: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80381688: addiu       $t7, $t7, 0x2410
    ctx->r15 = ADD32(ctx->r15, 0X2410);
    // 0x8038168C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80381690: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80381694: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x80381698: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x8038169C: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x803816A0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803816A4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803816A8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803816AC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803816B0: jal         0x802C78B0
    // 0x803816B4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_30;
    // 0x803816B4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_30:
L_803816B8:
    // 0x803816B8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803816BC: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x803816C0: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803816C4: addiu       $t9, $t9, 0x2410
    ctx->r25 = ADD32(ctx->r25, 0X2410);
    // 0x803816C8: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803816CC: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x803816D0: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x803816D4: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x803816D8: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x803816DC: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x803816E0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803816E4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803816E8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803816EC: jal         0x802C78B0
    // 0x803816F0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x803816F0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_31:
    // 0x803816F4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803816F8: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x803816FC: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80381700: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80381704: bne         $a1, $zero, L_80381744
    if (ctx->r5 != 0) {
        // 0x80381708: or          $a3, $s0, $zero
        ctx->r7 = ctx->r16 | 0;
            goto L_80381744;
    }
    // 0x80381708: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x8038170C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381710: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80381714: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80381718: addiu       $t7, $t7, 0x2410
    ctx->r15 = ADD32(ctx->r15, 0X2410);
    // 0x8038171C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80381720: addiu       $a1, $zero, 0x9
    ctx->r5 = ADD32(0, 0X9);
    // 0x80381724: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x80381728: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038172C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381730: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381734: jal         0x802C78B0
    // 0x80381738: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_32;
    // 0x80381738: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_32:
    // 0x8038173C: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80381740: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_80381744:
    // 0x80381744: bne         $a1, $zero, L_8038178C
    if (ctx->r5 != 0) {
        // 0x80381748: addiu       $a0, $zero, 0x4
        ctx->r4 = ADD32(0, 0X4);
            goto L_8038178C;
    }
    // 0x80381748: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x8038174C: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80381750: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80381754: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80381758: addiu       $t9, $t9, 0x25D0
    ctx->r25 = ADD32(ctx->r25, 0X25D0);
    // 0x8038175C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80381760: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x80381764: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80381768: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x8038176C: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x80381770: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381774: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381778: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038177C: jal         0x802C78B0
    // 0x80381780: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_33;
    // 0x80381780: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_33:
    // 0x80381784: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80381788: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_8038178C:
    // 0x8038178C: bne         $a1, $zero, L_803817CC
    if (ctx->r5 != 0) {
        // 0x80381790: addiu       $a0, $zero, 0x4
        ctx->r4 = ADD32(0, 0X4);
            goto L_803817CC;
    }
    // 0x80381790: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x80381794: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381798: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038179C: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x803817A0: addiu       $t7, $t7, 0x2410
    ctx->r15 = ADD32(ctx->r15, 0X2410);
    // 0x803817A4: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803817A8: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x803817AC: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x803817B0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x803817B4: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x803817B8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803817BC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803817C0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803817C4: jal         0x802C78B0
    // 0x803817C8: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_34;
    // 0x803817C8: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_34:
L_803817CC:
    // 0x803817CC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803817D0: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x803817D4: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803817D8: addiu       $t9, $t9, 0x2410
    ctx->r25 = ADD32(ctx->r25, 0X2410);
    // 0x803817DC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803817E0: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x803817E4: addiu       $a1, $zero, 0xB
    ctx->r5 = ADD32(0, 0XB);
    // 0x803817E8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x803817EC: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x803817F0: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x803817F4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803817F8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803817FC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381800: jal         0x802C78B0
    // 0x80381804: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_35;
    // 0x80381804: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_35:
    // 0x80381808: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8038180C: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x80381810: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x80381814: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80381818: bne         $a1, $zero, L_80381858
    if (ctx->r5 != 0) {
        // 0x8038181C: or          $a3, $s0, $zero
        ctx->r7 = ctx->r16 | 0;
            goto L_80381858;
    }
    // 0x8038181C: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x80381820: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381824: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80381828: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x8038182C: addiu       $t7, $t7, 0x2410
    ctx->r15 = ADD32(ctx->r15, 0X2410);
    // 0x80381830: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80381834: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x80381838: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x8038183C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381840: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381844: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381848: jal         0x802C78B0
    // 0x8038184C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_36;
    // 0x8038184C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_36:
    // 0x80381850: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80381854: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_80381858:
    // 0x80381858: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8038185C: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x80381860: lhu         $t9, 0x9C($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X9C);
    // 0x80381864: bne         $t9, $zero, L_80381904
    if (ctx->r25 != 0) {
        // 0x80381868: nop
    
            goto L_80381904;
    }
    // 0x80381868: nop

    // 0x8038186C: bne         $a1, $zero, L_803818B8
    if (ctx->r5 != 0) {
        // 0x80381870: lui         $a2, 0x1
        ctx->r6 = S32(0X1 << 16);
            goto L_803818B8;
    }
    // 0x80381870: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80381874: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381878: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038187C: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80381880: addiu       $t7, $t7, 0x2090
    ctx->r15 = ADD32(ctx->r15, 0X2090);
    // 0x80381884: ori         $a2, $a2, 0x4000
    ctx->r6 = ctx->r6 | 0X4000;
    // 0x80381888: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038188C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80381890: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80381894: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80381898: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    // 0x8038189C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803818A0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803818A4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803818A8: jal         0x802C78B0
    // 0x803818AC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_37;
    // 0x803818AC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_37:
    // 0x803818B0: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803818B4: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_803818B8:
    // 0x803818B8: bne         $a1, $zero, L_80381904
    if (ctx->r5 != 0) {
        // 0x803818BC: addiu       $a0, $zero, 0x4
        ctx->r4 = ADD32(0, 0X4);
            goto L_80381904;
    }
    // 0x803818BC: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x803818C0: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803818C4: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x803818C8: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803818CC: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x803818D0: addiu       $t6, $t6, 0x2090
    ctx->r14 = ADD32(ctx->r14, 0X2090);
    // 0x803818D4: ori         $a2, $a2, 0x4000
    ctx->r6 = ctx->r6 | 0X4000;
    // 0x803818D8: addu        $a3, $a2, $zero
    ctx->r7 = ADD32(ctx->r6, 0);
    // 0x803818DC: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803818E0: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x803818E4: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x803818E8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803818EC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803818F0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803818F4: jal         0x802C78B0
    // 0x803818F8: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_38;
    // 0x803818F8: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_38:
    // 0x803818FC: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80381900: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_80381904:
    // 0x80381904: bne         $a1, $zero, L_80381A3C
    if (ctx->r5 != 0) {
        // 0x80381908: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_80381A3C;
    }
    // 0x80381908: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038190C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80381910: addiu       $a1, $sp, 0x86
    ctx->r5 = ADD32(ctx->r29, 0X86);
    // 0x80381914: addiu       $a2, $sp, 0x84
    ctx->r6 = ADD32(ctx->r29, 0X84);
    // 0x80381918: lh          $a0, 0x326($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X326);
    // 0x8038191C: addiu       $t7, $a0, 0x1
    ctx->r15 = ADD32(ctx->r4, 0X1);
    // 0x80381920: jal         0x8031A150
    // 0x80381924: sh          $t7, 0x326($s0)
    MEM_H(0X326, ctx->r16) = ctx->r15;
    func_8031A150_72B800(rdram, ctx);
        goto after_39;
    // 0x80381924: sh          $t7, 0x326($s0)
    MEM_H(0X326, ctx->r16) = ctx->r15;
    after_39:
    // 0x80381928: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038192C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80381930: addiu       $a1, $sp, 0x86
    ctx->r5 = ADD32(ctx->r29, 0X86);
    // 0x80381934: addiu       $a2, $sp, 0x84
    ctx->r6 = ADD32(ctx->r29, 0X84);
    // 0x80381938: jal         0x8031A278
    // 0x8038193C: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_40;
    // 0x8038193C: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_40:
    // 0x80381940: lh          $a2, 0x86($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X86);
    // 0x80381944: lh          $t9, 0x84($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X84);
    // 0x80381948: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x8038194C: sll         $t8, $a2, 1
    ctx->r24 = S32(ctx->r6 << 1);
    // 0x80381950: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80381954: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x80381958: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8038195C: addu        $a2, $a2, $t8
    ctx->r6 = ADD32(ctx->r6, ctx->r24);
    // 0x80381960: lh          $a2, -0x2AB6($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2AB6);
    // 0x80381964: lh          $t7, -0x29FE($t7)
    ctx->r15 = MEM_H(ctx->r15, -0X29FE);
    // 0x80381968: lui         $s0, 0x100
    ctx->r16 = S32(0X100 << 16);
    // 0x8038196C: addiu       $s0, $s0, 0xCA0
    ctx->r16 = ADD32(ctx->r16, 0XCA0);
    // 0x80381970: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80381974: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80381978: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8038197C: sh          $a2, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r6;
    // 0x80381980: jal         0x80356BD8
    // 0x80381984: sh          $t7, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r15;
    func_80356BD8_768288(rdram, ctx);
        goto after_41;
    // 0x80381984: sh          $t7, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r15;
    after_41:
    // 0x80381988: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038198C: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80381990: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80381994: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80381998: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x8038199C: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x803819A0: sll         $t8, $t8, 4
    ctx->r24 = S32(ctx->r24 << 4);
    // 0x803819A4: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x803819A8: addiu       $t7, $t7, 0x24F0
    ctx->r15 = ADD32(ctx->r15, 0X24F0);
    // 0x803819AC: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x803819B0: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x803819B4: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x803819B8: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803819BC: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    // 0x803819C0: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x803819C4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803819C8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803819CC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803819D0: jal         0x802C78B0
    // 0x803819D4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_42;
    // 0x803819D4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_42:
    // 0x803819D8: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x803819DC: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x803819E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803819E4: jal         0x80356BD8
    // 0x803819E8: lh          $a2, 0x84($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X84);
    func_80356BD8_768288(rdram, ctx);
        goto after_43;
    // 0x803819E8: lh          $a2, 0x84($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X84);
    after_43:
    // 0x803819EC: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803819F0: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x803819F4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803819F8: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x803819FC: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x80381A00: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x80381A04: sll         $t8, $t8, 4
    ctx->r24 = S32(ctx->r24 << 4);
    // 0x80381A08: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80381A0C: addiu       $t7, $t7, 0x2510
    ctx->r15 = ADD32(ctx->r15, 0X2510);
    // 0x80381A10: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80381A14: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80381A18: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80381A1C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80381A20: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    // 0x80381A24: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x80381A28: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381A2C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80381A30: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381A34: jal         0x802C78B0
    // 0x80381A38: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_44;
    // 0x80381A38: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_44:
L_80381A3C:
    // 0x80381A3C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80381A40: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80381A44: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80381A48: lui         $t9, 0xBD00
    ctx->r25 = S32(0XBD00 << 16);
    // 0x80381A4C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80381A50: sw          $t8, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r24;
    // 0x80381A54: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80381A58: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
L_80381A5C:
    // 0x80381A5C: jal         0x8035D6A0
    // 0x80381A60: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_45;
    // 0x80381A60: nop

    after_45:
    // 0x80381A64: b           L_80381A74
    // 0x80381A68: nop

        goto L_80381A74;
    // 0x80381A68: nop

L_80381A6C:
    // 0x80381A6C: jal         0x8035D6D0
    // 0x80381A70: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_46;
    // 0x80381A70: nop

    after_46:
L_80381A74:
    // 0x80381A74: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80381A78: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80381A7C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80381A80: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80381A84: lw          $t6, 0x320($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X320);
    // 0x80381A88: beq         $t6, $zero, L_80381AD4
    if (ctx->r14 == 0) {
        // 0x80381A8C: nop
    
            goto L_80381AD4;
    }
    // 0x80381A8C: nop

    // 0x80381A90: jal         0x80321B70
    // 0x80381A94: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_80321B70_733220(rdram, ctx);
        goto after_47;
    // 0x80381A94: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_47:
    // 0x80381A98: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80381A9C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80381AA0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80381AA4: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x80381AA8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80381AAC: lw          $t6, 0x320($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X320);
    // 0x80381AB0: lw          $t8, 0x68($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X68);
    // 0x80381AB4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80381AB8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80381ABC: sw          $t8, 0x68($t6)
    MEM_W(0X68, ctx->r14) = ctx->r24;
    // 0x80381AC0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80381AC4: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x80381AC8: lw          $t8, 0x320($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X320);
    // 0x80381ACC: sw          $t7, 0x70($t8)
    MEM_W(0X70, ctx->r24) = ctx->r15;
    // 0x80381AD0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80381AD4:
    // 0x80381AD4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80381AD8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80381ADC: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x80381AE0: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x80381AE4: lhu         $t7, 0xBA($t9)
    ctx->r15 = MEM_HU(ctx->r25, 0XBA);
    // 0x80381AE8: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x80381AEC: lh          $a3, 0x302($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X302);
    // 0x80381AF0: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x80381AF4: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    // 0x80381AF8: lui         $t6, 0x103
    ctx->r14 = S32(0X103 << 16);
    // 0x80381AFC: addiu       $t6, $t6, 0x3190
    ctx->r14 = ADD32(ctx->r14, 0X3190);
    // 0x80381B00: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80381B04: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80381B08: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x80381B0C: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80381B10: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80381B14: addiu       $t9, $zero, 0x12
    ctx->r25 = ADD32(0, 0X12);
    // 0x80381B18: addiu       $t8, $zero, 0x12
    ctx->r24 = ADD32(0, 0X12);
    // 0x80381B1C: addiu       $t7, $zero, 0x9B
    ctx->r15 = ADD32(0, 0X9B);
    // 0x80381B20: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80381B24: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80381B28: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80381B2C: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80381B30: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80381B34: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80381B38: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80381B3C: jal         0x8034BD20
    // 0x80381B40: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_48;
    // 0x80381B40: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    after_48:
    // 0x80381B44: lh          $t8, 0x82($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X82);
    // 0x80381B48: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80381B4C: addiu       $a1, $zero, 0x3A9
    ctx->r5 = ADD32(0, 0X3A9);
    // 0x80381B50: bne         $t8, $zero, L_80381C04
    if (ctx->r24 != 0) {
        // 0x80381B54: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_80381C04;
    }
    // 0x80381B54: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381B58: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80381B5C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80381B60: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80381B64: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80381B68: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80381B6C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80381B70: jal         0x80303820
    // 0x80381B74: addiu       $a3, $zero, 0x3A9
    ctx->r7 = ADD32(0, 0X3A9);
    func_80303820_714ED0(rdram, ctx);
        goto after_49;
    // 0x80381B74: addiu       $a3, $zero, 0x3A9
    ctx->r7 = ADD32(0, 0X3A9);
    after_49:
    // 0x80381B78: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80381B7C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80381B80: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80381B84: addiu       $a2, $zero, 0x13
    ctx->r6 = ADD32(0, 0X13);
    // 0x80381B88: addiu       $a3, $zero, 0x119
    ctx->r7 = ADD32(0, 0X119);
    // 0x80381B8C: jal         0x80303820
    // 0x80381B90: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_50;
    // 0x80381B90: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_50:
    // 0x80381B94: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80381B98: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80381B9C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80381BA0: lw          $t7, 0x320($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X320);
    // 0x80381BA4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80381BA8: beq         $t7, $zero, L_80381BF4
    if (ctx->r15 == 0) {
        // 0x80381BAC: nop
    
            goto L_80381BF4;
    }
    // 0x80381BAC: nop

    // 0x80381BB0: lh          $a3, 0x308($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X308);
    // 0x80381BB4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80381BB8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381BBC: negu        $a3, $a3
    ctx->r7 = SUB32(0, ctx->r7);
    // 0x80381BC0: bgez        $a3, L_80381BD0
    if (SIGNED(ctx->r7) >= 0) {
        // 0x80381BC4: sra         $t6, $a3, 6
        ctx->r14 = S32(SIGNED(ctx->r7) >> 6);
            goto L_80381BD0;
    }
    // 0x80381BC4: sra         $t6, $a3, 6
    ctx->r14 = S32(SIGNED(ctx->r7) >> 6);
    // 0x80381BC8: addiu       $at, $a3, 0x3F
    ctx->r1 = ADD32(ctx->r7, 0X3F);
    // 0x80381BCC: sra         $t6, $at, 6
    ctx->r14 = S32(SIGNED(ctx->r1) >> 6);
L_80381BD0:
    // 0x80381BD0: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x80381BD4: jal         0x80303C44
    // 0x80381BD8: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    func_80303C44_7152F4(rdram, ctx);
        goto after_51;
    // 0x80381BD8: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    after_51:
    // 0x80381BDC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80381BE0: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80381BE4: jal         0x80303D50
    // 0x80381BE8: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    func_80303D50_715400(rdram, ctx);
        goto after_52;
    // 0x80381BE8: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    after_52:
    // 0x80381BEC: b           L_80381C0C
    // 0x80381BF0: nop

        goto L_80381C0C;
    // 0x80381BF0: nop

L_80381BF4:
    // 0x80381BF4: jal         0x80303D50
    // 0x80381BF8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    func_80303D50_715400(rdram, ctx);
        goto after_53;
    // 0x80381BF8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    after_53:
    // 0x80381BFC: b           L_80381C0C
    // 0x80381C00: nop

        goto L_80381C0C;
    // 0x80381C00: nop

L_80381C04:
    // 0x80381C04: jal         0x80303D00
    // 0x80381C08: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    func_80303D00_7153B0(rdram, ctx);
        goto after_54;
    // 0x80381C08: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    after_54:
L_80381C0C:
    // 0x80381C0C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80381C10: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x80381C14: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x80381C18: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80381C1C: lhu         $t6, 0x9C($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X9C);
    // 0x80381C20: bnel        $t6, $at, L_80381C50
    if (ctx->r14 != ctx->r1) {
        // 0x80381C24: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_80381C50;
    }
    goto skip_6;
    // 0x80381C24: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_6:
    // 0x80381C28: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80381C2C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80381C30: lbu         $v0, 0x366($t8)
    ctx->r2 = MEM_BU(ctx->r24, 0X366);
    // 0x80381C34: beq         $v0, $at, L_80381C44
    if (ctx->r2 == ctx->r1) {
        // 0x80381C38: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80381C44;
    }
    // 0x80381C38: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80381C3C: bnel        $v0, $at, L_80381C50
    if (ctx->r2 != ctx->r1) {
        // 0x80381C40: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_80381C50;
    }
    goto skip_7;
    // 0x80381C40: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_7:
L_80381C44:
    // 0x80381C44: jal         0x8032AAF0
    // 0x80381C48: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    load_animal(rdram, ctx);
        goto after_55;
    // 0x80381C48: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_55:
    // 0x80381C4C: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
L_80381C50:
    // 0x80381C50: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x80381C54: addiu       $sp, $sp, 0x98
    ctx->r29 = ADD32(ctx->r29, 0X98);
    // 0x80381C58: jr          $ra
    // 0x80381C5C: nop

    return;
    // 0x80381C5C: nop

;}
RECOMP_FUNC void func_80381C60_793310(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80381C60: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80381C64: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x80381C68: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80381C6C: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80381C70: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x80381C74: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80381C78: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80381C7C: lw          $a3, 0x320($t6)
    ctx->r7 = MEM_W(ctx->r14, 0X320);
    // 0x80381C80: bne         $a3, $zero, L_80381E90
    if (ctx->r7 != 0) {
        // 0x80381C84: or          $a0, $a3, $zero
        ctx->r4 = ctx->r7 | 0;
            goto L_80381E90;
    }
    // 0x80381C84: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x80381C88: jal         0x803213B0
    // 0x80381C8C: nop

    try_pickup_animal(rdram, ctx);
        goto after_0;
    // 0x80381C8C: nop

    after_0:
    // 0x80381C90: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x80381C94: sw          $v0, 0x320($t7)
    MEM_W(0X320, ctx->r15) = ctx->r2;
    // 0x80381C98: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381C9C: lw          $a3, 0x320($v1)
    ctx->r7 = MEM_W(ctx->r3, 0X320);
    // 0x80381CA0: beq         $a3, $zero, L_80381D78
    if (ctx->r7 == 0) {
        // 0x80381CA4: nop
    
            goto L_80381D78;
    }
    // 0x80381CA4: nop

    // 0x80381CA8: lhu         $t8, 0x42($a3)
    ctx->r24 = MEM_HU(ctx->r7, 0X42);
    // 0x80381CAC: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    // 0x80381CB0: jal         0x8032AAF0
    // 0x80381CB4: sh          $t8, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r24;
    load_animal(rdram, ctx);
        goto after_1;
    // 0x80381CB4: sh          $t8, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r24;
    after_1:
    // 0x80381CB8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381CBC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80381CC0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80381CC4: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x80381CC8: lh          $t0, 0x308($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X308);
    // 0x80381CCC: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x80381CD0: sh          $t1, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r9;
    // 0x80381CD4: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x80381CD8: lbu         $t3, 0x160($t2)
    ctx->r11 = MEM_BU(ctx->r10, 0X160);
    // 0x80381CDC: bnel        $t3, $at, L_80381D34
    if (ctx->r11 != ctx->r1) {
        // 0x80381CE0: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_80381D34;
    }
    goto skip_0;
    // 0x80381CE0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_0:
    // 0x80381CE4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381CE8: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x80381CEC: jal         0x80310F58
    // 0x80381CF0: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    func_80310F58_722608(rdram, ctx);
        goto after_2;
    // 0x80381CF0: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    after_2:
    // 0x80381CF4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381CF8: sra         $t4, $v0, 16
    ctx->r12 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80381CFC: lh          $a0, 0xC($v1)
    ctx->r4 = MEM_H(ctx->r3, 0XC);
    // 0x80381D00: slt         $at, $t4, $a0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80381D04: beql        $at, $zero, L_80381D18
    if (ctx->r1 == 0) {
        // 0x80381D08: lh          $a0, 0x4($v1)
        ctx->r4 = MEM_H(ctx->r3, 0X4);
            goto L_80381D18;
    }
    goto skip_1;
    // 0x80381D08: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    skip_1:
    // 0x80381D0C: b           L_80381D78
    // 0x80381D10: sh          $a0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r4;
        goto L_80381D78;
    // 0x80381D10: sh          $a0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r4;
    // 0x80381D14: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
L_80381D18:
    // 0x80381D18: jal         0x80310F58
    // 0x80381D1C: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    func_80310F58_722608(rdram, ctx);
        goto after_3;
    // 0x80381D1C: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    after_3:
    // 0x80381D20: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x80381D24: sra         $t5, $v0, 16
    ctx->r13 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80381D28: b           L_80381D78
    // 0x80381D2C: sh          $t5, 0xC($t6)
    MEM_H(0XC, ctx->r14) = ctx->r13;
        goto L_80381D78;
    // 0x80381D2C: sh          $t5, 0xC($t6)
    MEM_H(0XC, ctx->r14) = ctx->r13;
    // 0x80381D30: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80381D34:
    // 0x80381D34: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x80381D38: jal         0x8031124C
    // 0x80381D3C: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_4;
    // 0x80381D3C: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    after_4:
    // 0x80381D40: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381D44: sra         $t7, $v0, 16
    ctx->r15 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80381D48: lh          $a0, 0xC($v1)
    ctx->r4 = MEM_H(ctx->r3, 0XC);
    // 0x80381D4C: slt         $at, $t7, $a0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80381D50: beql        $at, $zero, L_80381D64
    if (ctx->r1 == 0) {
        // 0x80381D54: lh          $a0, 0x4($v1)
        ctx->r4 = MEM_H(ctx->r3, 0X4);
            goto L_80381D64;
    }
    goto skip_2;
    // 0x80381D54: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    skip_2:
    // 0x80381D58: b           L_80381D78
    // 0x80381D5C: sh          $a0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r4;
        goto L_80381D78;
    // 0x80381D5C: sh          $a0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r4;
    // 0x80381D60: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
L_80381D64:
    // 0x80381D64: jal         0x8031124C
    // 0x80381D68: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_5;
    // 0x80381D68: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    after_5:
    // 0x80381D6C: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x80381D70: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80381D74: sh          $t8, 0xC($t9)
    MEM_H(0XC, ctx->r25) = ctx->r24;
L_80381D78:
    // 0x80381D78: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80381D7C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80381D80: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80381D84: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381D88: lbu         $t1, 0x162($t0)
    ctx->r9 = MEM_BU(ctx->r8, 0X162);
    // 0x80381D8C: bnel        $t1, $at, L_80381F04
    if (ctx->r9 != ctx->r1) {
        // 0x80381D90: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_80381F04;
    }
    goto skip_3;
    // 0x80381D90: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_3:
    // 0x80381D94: lw          $v0, 0x5528($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5528);
    // 0x80381D98: addiu       $a0, $zero, -0x3A
    ctx->r4 = ADD32(0, -0X3A);
    // 0x80381D9C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80381DA0: lh          $v1, 0x2E4($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E4);
    // 0x80381DA4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381DA8: addiu       $a3, $zero, 0x1D
    ctx->r7 = ADD32(0, 0X1D);
    // 0x80381DAC: slti        $at, $v1, 0x191
    ctx->r1 = SIGNED(ctx->r3) < 0X191 ? 1 : 0;
    // 0x80381DB0: bne         $at, $zero, L_80381F00
    if (ctx->r1 != 0) {
        // 0x80381DB4: addiu       $t2, $v1, -0x190
        ctx->r10 = ADD32(ctx->r3, -0X190);
            goto L_80381F00;
    }
    // 0x80381DB4: addiu       $t2, $v1, -0x190
    ctx->r10 = ADD32(ctx->r3, -0X190);
    // 0x80381DB8: sh          $t2, 0x2E4($v0)
    MEM_H(0X2E4, ctx->r2) = ctx->r10;
    // 0x80381DBC: addiu       $t3, $zero, 0x14
    ctx->r11 = ADD32(0, 0X14);
    // 0x80381DC0: addiu       $t4, $zero, 0xB
    ctx->r12 = ADD32(0, 0XB);
    // 0x80381DC4: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80381DC8: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80381DCC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80381DD0: jal         0x803224C4
    // 0x80381DD4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_6;
    // 0x80381DD4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_6:
    // 0x80381DD8: beq         $v0, $zero, L_80381E30
    if (ctx->r2 == 0) {
        // 0x80381DDC: addiu       $a0, $zero, 0x4F
        ctx->r4 = ADD32(0, 0X4F);
            goto L_80381E30;
    }
    // 0x80381DDC: addiu       $a0, $zero, 0x4F
    ctx->r4 = ADD32(0, 0X4F);
    // 0x80381DE0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381DE4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381DE8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80381DEC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80381DF0: lh          $t5, 0x8($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X8);
    // 0x80381DF4: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80381DF8: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
    // 0x80381DFC: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80381E00: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x80381E04: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80381E08: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381E0C: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80381E10: jal         0x8032C360
    // 0x80381E14: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_7;
    // 0x80381E14: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_7:
    // 0x80381E18: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381E1C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381E20: lh          $t7, 0x24($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X24);
    // 0x80381E24: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x80381E28: b           L_80381E64
    // 0x80381E2C: sh          $t8, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r24;
        goto L_80381E64;
    // 0x80381E2C: sh          $t8, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r24;
L_80381E30:
    // 0x80381E30: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381E34: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381E38: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80381E3C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80381E40: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x80381E44: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80381E48: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80381E4C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80381E50: lh          $t0, 0xC($v0)
    ctx->r8 = MEM_H(ctx->r2, 0XC);
    // 0x80381E54: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381E58: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80381E5C: jal         0x8032C360
    // 0x80381E60: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    play_sound_effect_at_location(rdram, ctx);
        goto after_8;
    // 0x80381E60: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    after_8:
L_80381E64:
    // 0x80381E64: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381E68: addiu       $t2, $zero, 0x12
    ctx->r10 = ADD32(0, 0X12);
    // 0x80381E6C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80381E70: lbu         $t1, 0x365($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X365);
    // 0x80381E74: bnel        $t1, $zero, L_80381F04
    if (ctx->r9 != 0) {
        // 0x80381E78: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_80381F04;
    }
    goto skip_4;
    // 0x80381E78: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_4:
    // 0x80381E7C: sb          $t2, 0x365($v1)
    MEM_B(0X365, ctx->r3) = ctx->r10;
    // 0x80381E80: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80381E84: lhu         $t3, 0x5544($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X5544);
    // 0x80381E88: b           L_80381F00
    // 0x80381E8C: sh          $t3, 0x32A($t4)
    MEM_H(0X32A, ctx->r12) = ctx->r11;
        goto L_80381F00;
    // 0x80381E8C: sh          $t3, 0x32A($t4)
    MEM_H(0X32A, ctx->r12) = ctx->r11;
L_80381E90:
    // 0x80381E90: jal         0x80321920
    // 0x80381E94: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_80321920_732FD0(rdram, ctx);
        goto after_9;
    // 0x80381E94: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_9:
    // 0x80381E98: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381E9C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381EA0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80381EA4: lwc1        $f8, -0xC20($at)
    ctx->f8.u32l = MEM_W(ctx->r1, -0XC20);
    // 0x80381EA8: lh          $t5, 0x8($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X8);
    // 0x80381EAC: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80381EB0: addiu       $a0, $zero, 0x63
    ctx->r4 = ADD32(0, 0X63);
    // 0x80381EB4: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80381EB8: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x80381EBC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80381EC0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381EC4: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x80381EC8: jal         0x8032C360
    // 0x80381ECC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_10;
    // 0x80381ECC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_10:
    // 0x80381ED0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381ED4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80381ED8: lh          $t7, 0xC($v1)
    ctx->r15 = MEM_H(ctx->r3, 0XC);
    // 0x80381EDC: lh          $t8, 0x308($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X308);
    // 0x80381EE0: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x80381EE4: sh          $t9, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r25;
    // 0x80381EE8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80381EEC: lh          $t0, 0x18($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X18);
    // 0x80381EF0: lh          $t1, 0x308($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X308);
    // 0x80381EF4: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x80381EF8: jal         0x8032AAF0
    // 0x80381EFC: sh          $t2, 0x18($v1)
    MEM_H(0X18, ctx->r3) = ctx->r10;
    load_animal(rdram, ctx);
        goto after_11;
    // 0x80381EFC: sh          $t2, 0x18($v1)
    MEM_H(0X18, ctx->r3) = ctx->r10;
    after_11:
L_80381F00:
    // 0x80381F00: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_80381F04:
    // 0x80381F04: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x80381F08: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80381F0C: jr          $ra
    // 0x80381F10: nop

    return;
    // 0x80381F10: nop

;}
RECOMP_FUNC void func_80381F14_7935C4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80381F14: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381F18: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381F1C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80381F20: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80381F24: lbu         $t6, 0x162($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X162);
    // 0x80381F28: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80381F2C: addiu       $a0, $zero, -0x4E
    ctx->r4 = ADD32(0, -0X4E);
    // 0x80381F30: beq         $t6, $at, L_80381F54
    if (ctx->r14 == ctx->r1) {
        // 0x80381F34: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_80381F54;
    }
    // 0x80381F34: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80381F38: lw          $v1, 0x6C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X6C);
    // 0x80381F3C: beql        $v1, $zero, L_80382038
    if (ctx->r3 == 0) {
        // 0x80381F40: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_80382038;
    }
    goto skip_0;
    // 0x80381F40: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x80381F44: lw          $t7, 0x16C($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X16C);
    // 0x80381F48: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x80381F4C: slti        $at, $t8, 0x100
    ctx->r1 = SIGNED(ctx->r24) < 0X100 ? 1 : 0;
    // 0x80381F50: bne         $at, $zero, L_80382034
    if (ctx->r1 != 0) {
        // 0x80381F54: addiu       $t9, $zero, 0x14
        ctx->r25 = ADD32(0, 0X14);
            goto L_80382034;
    }
L_80381F54:
    // 0x80381F54: addiu       $t9, $zero, 0x14
    ctx->r25 = ADD32(0, 0X14);
    // 0x80381F58: addiu       $t0, $zero, 0x13
    ctx->r8 = ADD32(0, 0X13);
    // 0x80381F5C: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x80381F60: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80381F64: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381F68: addiu       $a3, $zero, 0x3A
    ctx->r7 = ADD32(0, 0X3A);
    // 0x80381F6C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80381F70: jal         0x803224C4
    // 0x80381F74: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_0;
    // 0x80381F74: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_0:
    // 0x80381F78: beq         $v0, $zero, L_80381FD0
    if (ctx->r2 == 0) {
        // 0x80381F7C: addiu       $a0, $zero, 0x4F
        ctx->r4 = ADD32(0, 0X4F);
            goto L_80381FD0;
    }
    // 0x80381F7C: addiu       $a0, $zero, 0x4F
    ctx->r4 = ADD32(0, 0X4F);
    // 0x80381F80: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381F84: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381F88: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80381F8C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80381F90: lh          $t1, 0x8($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X8);
    // 0x80381F94: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80381F98: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
    // 0x80381F9C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80381FA0: lh          $t2, 0xC($v0)
    ctx->r10 = MEM_H(ctx->r2, 0XC);
    // 0x80381FA4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80381FA8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381FAC: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80381FB0: jal         0x8032C360
    // 0x80381FB4: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x80381FB4: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_1:
    // 0x80381FB8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381FBC: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381FC0: lh          $t3, 0x24($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X24);
    // 0x80381FC4: addiu       $t4, $t3, 0x2
    ctx->r12 = ADD32(ctx->r11, 0X2);
    // 0x80381FC8: b           L_80382004
    // 0x80381FCC: sh          $t4, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r12;
        goto L_80382004;
    // 0x80381FCC: sh          $t4, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r12;
L_80381FD0:
    // 0x80381FD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80381FD4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80381FD8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80381FDC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80381FE0: lh          $t5, 0x8($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X8);
    // 0x80381FE4: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80381FE8: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80381FEC: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80381FF0: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x80381FF4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80381FF8: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80381FFC: jal         0x8032C360
    // 0x80382000: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x80382000: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_2:
L_80382004:
    // 0x80382004: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382008: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8038200C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80382010: addiu       $t8, $zero, 0x12
    ctx->r24 = ADD32(0, 0X12);
    // 0x80382014: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80382018: lbu         $t7, 0x365($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X365);
    // 0x8038201C: bnel        $t7, $zero, L_80382038
    if (ctx->r15 != 0) {
        // 0x80382020: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_80382038;
    }
    goto skip_1;
    // 0x80382020: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_1:
    // 0x80382024: sb          $t8, 0x365($v0)
    MEM_B(0X365, ctx->r2) = ctx->r24;
    // 0x80382028: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x8038202C: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x80382030: sh          $t9, 0x32A($t0)
    MEM_H(0X32A, ctx->r8) = ctx->r25;
L_80382034:
    // 0x80382034: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80382038:
    // 0x80382038: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8038203C: jr          $ra
    // 0x80382040: nop

    return;
    // 0x80382040: nop

;}
RECOMP_FUNC void func_80382050_793700(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382050: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382054: lh          $v0, 0x553A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X553A);
    // 0x80382058: addiu       $sp, $sp, -0x88
    ctx->r29 = ADD32(ctx->r29, -0X88);
    // 0x8038205C: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x80382060: bne         $v0, $at, L_803820A8
    if (ctx->r2 != ctx->r1) {
        // 0x80382064: sw          $ra, 0x3C($sp)
        MEM_W(0X3C, ctx->r29) = ctx->r31;
            goto L_803820A8;
    }
    // 0x80382064: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80382068: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038206C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80382070: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382074: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80382078: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    // 0x8038207C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80382080: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x80382084: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80382088: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x8038208C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382090: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80382094: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80382098: jal         0x8032C360
    // 0x8038209C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8038209C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_0:
    // 0x803820A0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803820A4: lh          $v0, 0x553A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X553A);
L_803820A8:
    // 0x803820A8: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x803820AC: bne         $v0, $at, L_803820E8
    if (ctx->r2 != ctx->r1) {
        // 0x803820B0: addiu       $a0, $zero, 0xA
        ctx->r4 = ADD32(0, 0XA);
            goto L_803820E8;
    }
    // 0x803820B0: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x803820B4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803820B8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x803820BC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803820C0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803820C4: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x803820C8: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x803820CC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x803820D0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803820D4: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x803820D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803820DC: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x803820E0: jal         0x8032C360
    // 0x803820E4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x803820E4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_1:
L_803820E8:
    // 0x803820E8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x803820EC: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x803820F0: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x803820F4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803820F8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x803820FC: lbu         $t6, 0x162($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X162);
    // 0x80382100: bne         $t6, $at, L_80382264
    if (ctx->r14 != ctx->r1) {
        // 0x80382104: nop
    
            goto L_80382264;
    }
    // 0x80382104: nop

    // 0x80382108: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x8038210C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80382110: addiu       $t3, $t3, 0x552C
    ctx->r11 = ADD32(ctx->r11, 0X552C);
    // 0x80382114: beq         $t7, $zero, L_80382264
    if (ctx->r15 == 0) {
        // 0x80382118: nop
    
            goto L_80382264;
    }
    // 0x80382118: nop

    // 0x8038211C: lw          $v1, 0x0($t3)
    ctx->r3 = MEM_W(ctx->r11, 0X0);
    // 0x80382120: lui         $t8, 0x801F
    ctx->r24 = S32(0X801F << 16);
    // 0x80382124: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80382128: lbu         $a0, 0x369($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X369);
    // 0x8038212C: bne         $a0, $zero, L_8038214C
    if (ctx->r4 != 0) {
        // 0x80382130: nop
    
            goto L_8038214C;
    }
    // 0x80382130: nop

    // 0x80382134: lhu         $t8, -0x6172($t8)
    ctx->r24 = MEM_HU(ctx->r24, -0X6172);
    // 0x80382138: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038213C: bne         $t8, $zero, L_80382264
    if (ctx->r24 != 0) {
        // 0x80382140: nop
    
            goto L_80382264;
    }
    // 0x80382140: nop

    // 0x80382144: b           L_80382264
    // 0x80382148: sb          $t9, 0x369($v1)
    MEM_B(0X369, ctx->r3) = ctx->r25;
        goto L_80382264;
    // 0x80382148: sb          $t9, 0x369($v1)
    MEM_B(0X369, ctx->r3) = ctx->r25;
L_8038214C:
    // 0x8038214C: bne         $a0, $at, L_80382264
    if (ctx->r4 != ctx->r1) {
        // 0x80382150: lui         $t6, 0x801F
        ctx->r14 = S32(0X801F << 16);
            goto L_80382264;
    }
    // 0x80382150: lui         $t6, 0x801F
    ctx->r14 = S32(0X801F << 16);
    // 0x80382154: lhu         $t6, -0x6172($t6)
    ctx->r14 = MEM_HU(ctx->r14, -0X6172);
    // 0x80382158: beq         $t6, $zero, L_80382264
    if (ctx->r14 == 0) {
        // 0x8038215C: nop
    
            goto L_80382264;
    }
    // 0x8038215C: nop

    // 0x80382160: lh          $t7, 0x24($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X24);
    // 0x80382164: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80382168: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038216C: slti        $at, $t7, 0x5
    ctx->r1 = SIGNED(ctx->r15) < 0X5 ? 1 : 0;
    // 0x80382170: beq         $at, $zero, L_80382264
    if (ctx->r1 == 0) {
        // 0x80382174: nop
    
            goto L_80382264;
    }
    // 0x80382174: nop

    // 0x80382178: sb          $t8, 0x369($v1)
    MEM_B(0X369, ctx->r3) = ctx->r24;
    // 0x8038217C: lw          $t6, 0x0($t3)
    ctx->r14 = MEM_W(ctx->r11, 0X0);
    // 0x80382180: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80382184: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x80382188: lh          $t7, 0x302($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X302);
    // 0x8038218C: lw          $t9, 0x1C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X1C);
    // 0x80382190: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x80382194: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x80382198: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x8038219C: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x803821A0: lh          $t7, 0x2C78($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C78);
    // 0x803821A4: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803821A8: mflo        $t8
    ctx->r24 = lo;
    // 0x803821AC: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x803821B0: sw          $t6, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r14;
    // 0x803821B4: lw          $t9, 0x0($t3)
    ctx->r25 = MEM_W(ctx->r11, 0X0);
    // 0x803821B8: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x803821BC: lh          $t8, 0x302($t9)
    ctx->r24 = MEM_H(ctx->r25, 0X302);
    // 0x803821C0: lw          $t7, 0x20($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X20);
    // 0x803821C4: addiu       $t6, $t8, 0x40
    ctx->r14 = ADD32(ctx->r24, 0X40);
    // 0x803821C8: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x803821CC: sll         $t8, $t9, 1
    ctx->r24 = S32(ctx->r25 << 1);
    // 0x803821D0: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x803821D4: addu        $t6, $t6, $t8
    ctx->r14 = ADD32(ctx->r14, ctx->r24);
    // 0x803821D8: lh          $t6, 0x2C78($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C78);
    // 0x803821DC: multu       $t6, $a1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803821E0: addiu       $t6, $zero, 0x7
    ctx->r14 = ADD32(0, 0X7);
    // 0x803821E4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x803821E8: mflo        $t9
    ctx->r25 = lo;
    // 0x803821EC: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x803821F0: sw          $t8, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r24;
    // 0x803821F4: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x803821F8: lh          $a0, 0x24($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X24);
    // 0x803821FC: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
    // 0x80382200: slti        $at, $a0, 0x7
    ctx->r1 = SIGNED(ctx->r4) < 0X7 ? 1 : 0;
    // 0x80382204: beql        $at, $zero, L_80382218
    if (ctx->r1 == 0) {
        // 0x80382208: sh          $a0, 0x24($v0)
        MEM_H(0X24, ctx->r2) = ctx->r4;
            goto L_80382218;
    }
    goto skip_0;
    // 0x80382208: sh          $a0, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r4;
    skip_0:
    // 0x8038220C: b           L_80382218
    // 0x80382210: sh          $t6, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r14;
        goto L_80382218;
    // 0x80382210: sh          $t6, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r14;
    // 0x80382214: sh          $a0, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r4;
L_80382218:
    // 0x80382218: lw          $v1, 0x0($t3)
    ctx->r3 = MEM_W(ctx->r11, 0X0);
    // 0x8038221C: lh          $v0, 0x308($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X308);
    // 0x80382220: addiu       $v0, $v0, -0x19
    ctx->r2 = ADD32(ctx->r2, -0X19);
    // 0x80382224: bgezl       $v0, L_80382238
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80382228: sh          $v0, 0x308($v1)
        MEM_H(0X308, ctx->r3) = ctx->r2;
            goto L_80382238;
    }
    goto skip_1;
    // 0x80382228: sh          $v0, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r2;
    skip_1:
    // 0x8038222C: b           L_80382238
    // 0x80382230: sh          $zero, 0x308($v1)
    MEM_H(0X308, ctx->r3) = 0;
        goto L_80382238;
    // 0x80382230: sh          $zero, 0x308($v1)
    MEM_H(0X308, ctx->r3) = 0;
    // 0x80382234: sh          $v0, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r2;
L_80382238:
    // 0x80382238: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x8038223C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382240: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80382244: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x80382248: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8038224C: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    // 0x80382250: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80382254: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80382258: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x8038225C: jal         0x8032C360
    // 0x80382260: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x80382260: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_2:
L_80382264:
    // 0x80382264: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80382268: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x8038226C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80382270: addiu       $t3, $t3, 0x552C
    ctx->r11 = ADD32(ctx->r11, 0X552C);
    // 0x80382274: beq         $t8, $zero, L_803822CC
    if (ctx->r24 == 0) {
        // 0x80382278: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_803822CC;
    }
    // 0x80382278: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038227C: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80382280: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80382284: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x80382288: lh          $v0, 0xD6($t6)
    ctx->r2 = MEM_H(ctx->r14, 0XD6);
    // 0x8038228C: beq         $a0, $v0, L_803822AC
    if (ctx->r4 == ctx->r2) {
        // 0x80382290: nop
    
            goto L_803822AC;
    }
    // 0x80382290: nop

    // 0x80382294: bne         $v0, $zero, L_803822B4
    if (ctx->r2 != 0) {
        // 0x80382298: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803822B4;
    }
    // 0x80382298: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038229C: beq         $a0, $at, L_803822AC
    if (ctx->r4 == ctx->r1) {
        // 0x803822A0: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803822AC;
    }
    // 0x803822A0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803822A4: bnel        $a0, $at, L_803822B8
    if (ctx->r4 != ctx->r1) {
        // 0x803822A8: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_803822B8;
    }
    goto skip_2;
    // 0x803822A8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    skip_2:
L_803822AC:
    // 0x803822AC: b           L_803822B8
    // 0x803822B0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
        goto L_803822B8;
    // 0x803822B0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
L_803822B4:
    // 0x803822B4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_803822B8:
    // 0x803822B8: beq         $a2, $zero, L_803822CC
    if (ctx->r6 == 0) {
        // 0x803822BC: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_803822CC;
    }
    // 0x803822BC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803822C0: sh          $zero, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = 0;
    // 0x803822C4: b           L_8038235C
    // 0x803822C8: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_8038235C;
    // 0x803822C8: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_803822CC:
    // 0x803822CC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x803822D0: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x803822D4: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803822D8: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x803822DC: lh          $v0, 0xD6($t1)
    ctx->r2 = MEM_H(ctx->r9, 0XD6);
    // 0x803822E0: lw          $v1, 0x0($t3)
    ctx->r3 = MEM_W(ctx->r11, 0X0);
    // 0x803822E4: addiu       $a3, $zero, 0x800
    ctx->r7 = ADD32(0, 0X800);
    // 0x803822E8: beq         $a0, $v0, L_80382308
    if (ctx->r4 == ctx->r2) {
        // 0x803822EC: addiu       $t6, $zero, 0x3E
        ctx->r14 = ADD32(0, 0X3E);
            goto L_80382308;
    }
    // 0x803822EC: addiu       $t6, $zero, 0x3E
    ctx->r14 = ADD32(0, 0X3E);
    // 0x803822F0: bne         $v0, $zero, L_80382310
    if (ctx->r2 != 0) {
        // 0x803822F4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80382310;
    }
    // 0x803822F4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803822F8: beq         $a0, $at, L_80382308
    if (ctx->r4 == ctx->r1) {
        // 0x803822FC: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80382308;
    }
    // 0x803822FC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80382300: bnel        $a0, $at, L_80382314
    if (ctx->r4 != ctx->r1) {
        // 0x80382304: or          $t0, $zero, $zero
        ctx->r8 = 0 | 0;
            goto L_80382314;
    }
    goto skip_3;
    // 0x80382304: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    skip_3:
L_80382308:
    // 0x80382308: b           L_80382314
    // 0x8038230C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
        goto L_80382314;
    // 0x8038230C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
L_80382310:
    // 0x80382310: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_80382314:
    // 0x80382314: lw          $t7, 0xC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0XC);
    // 0x80382318: lhu         $t9, 0xBA($t1)
    ctx->r25 = MEM_HU(ctx->r9, 0XBA);
    // 0x8038231C: lw          $a0, 0x4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X4);
    // 0x80382320: lw          $a1, 0x8($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X8);
    // 0x80382324: sll         $t8, $t9, 15
    ctx->r24 = S32(ctx->r25 << 15);
    // 0x80382328: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x8038232C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80382330: sltiu       $t6, $t0, 0x1
    ctx->r14 = ctx->r8 < 0X1 ? 1 : 0;
    // 0x80382334: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80382338: addiu       $t7, $zero, 0x7C
    ctx->r15 = ADD32(0, 0X7C);
    // 0x8038233C: addiu       $t9, $zero, 0x3E
    ctx->r25 = ADD32(0, 0X3E);
    // 0x80382340: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80382344: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80382348: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8038234C: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80382350: jal         0x802E89F0
    // 0x80382354: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_3;
    // 0x80382354: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_3:
    // 0x80382358: sh          $v0, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r2;
L_8038235C:
    // 0x8038235C: lh          $t9, 0x7A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X7A);
    // 0x80382360: bne         $t9, $zero, L_80382BA0
    if (ctx->r25 != 0) {
        // 0x80382364: nop
    
            goto L_80382BA0;
    }
    // 0x80382364: nop

    // 0x80382368: jal         0x8034B45C
    // 0x8038236C: nop

    func_8034B45C_75CB0C(rdram, ctx);
        goto after_4;
    // 0x8038236C: nop

    after_4:
    // 0x80382370: jal         0x8035D120
    // 0x80382374: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_5;
    // 0x80382374: nop

    after_5:
    // 0x80382378: jal         0x8035DA60
    // 0x8038237C: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_6;
    // 0x8038237C: nop

    after_6:
    // 0x80382380: jal         0x8035D734
    // 0x80382384: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_7;
    // 0x80382384: nop

    after_7:
    // 0x80382388: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038238C: lhu         $t7, 0x2ECE($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X2ECE);
    // 0x80382390: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80382394: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x80382398: beq         $t7, $zero, L_803823B0
    if (ctx->r15 == 0) {
        // 0x8038239C: addiu       $a1, $zero, 0x3E8
        ctx->r5 = ADD32(0, 0X3E8);
            goto L_803823B0;
    }
    // 0x8038239C: addiu       $a1, $zero, 0x3E8
    ctx->r5 = ADD32(0, 0X3E8);
    // 0x803823A0: lhu         $t8, 0x2ECC($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X2ECC);
    // 0x803823A4: slti        $at, $t8, 0x1F
    ctx->r1 = SIGNED(ctx->r24) < 0X1F ? 1 : 0;
    // 0x803823A8: beq         $at, $zero, L_80382450
    if (ctx->r1 == 0) {
        // 0x803823AC: nop
    
            goto L_80382450;
    }
    // 0x803823AC: nop

L_803823B0:
    // 0x803823B0: jal         0x80302E50
    // 0x803823B4: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    func_80302E50_714500(rdram, ctx);
        goto after_8;
    // 0x803823B4: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    after_8:
    // 0x803823B8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803823BC: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x803823C0: addiu       $at, $zero, 0x3F
    ctx->r1 = ADD32(0, 0X3F);
    // 0x803823C4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x803823C8: lhu         $t9, 0x0($t6)
    ctx->r25 = MEM_HU(ctx->r14, 0X0);
    // 0x803823CC: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x803823D0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803823D4: bne         $t9, $at, L_80382450
    if (ctx->r25 != ctx->r1) {
        // 0x803823D8: nop
    
            goto L_80382450;
    }
    // 0x803823D8: nop

    // 0x803823DC: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x803823E0: addiu       $t9, $zero, 0x28
    ctx->r25 = ADD32(0, 0X28);
    // 0x803823E4: lh          $v0, 0x308($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X308);
    // 0x803823E8: slti        $t0, $v0, 0x29
    ctx->r8 = SIGNED(ctx->r2) < 0X29 ? 1 : 0;
    // 0x803823EC: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x803823F0: bne         $t0, $zero, L_80382400
    if (ctx->r8 != 0) {
        // 0x803823F4: sh          $t7, 0x308($v1)
        MEM_H(0X308, ctx->r3) = ctx->r15;
            goto L_80382400;
    }
    // 0x803823F4: sh          $t7, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r15;
    // 0x803823F8: b           L_80382410
    // 0x803823FC: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
        goto L_80382410;
    // 0x803823FC: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
L_80382400:
    // 0x80382400: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x80382404: lh          $a2, 0x308($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X308);
    // 0x80382408: addiu       $t8, $a2, 0x1
    ctx->r24 = ADD32(ctx->r6, 0X1);
    // 0x8038240C: sh          $t8, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r24;
L_80382410:
    // 0x80382410: sll         $t6, $a2, 1
    ctx->r14 = S32(ctx->r6 << 1);
    // 0x80382414: subu        $t8, $t9, $t6
    ctx->r24 = SUB32(ctx->r25, ctx->r14);
    // 0x80382418: negu        $a1, $t8
    ctx->r5 = SUB32(0, ctx->r24);
    // 0x8038241C: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80382420: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80382424: jal         0x8030322C
    // 0x80382428: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    func_8030322C_7148DC(rdram, ctx);
        goto after_9;
    // 0x80382428: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    after_9:
    // 0x8038242C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80382430: jal         0x8030322C
    // 0x80382434: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    func_8030322C_7148DC(rdram, ctx);
        goto after_10;
    // 0x80382434: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    after_10:
    // 0x80382438: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8038243C: jal         0x8030322C
    // 0x80382440: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    func_8030322C_7148DC(rdram, ctx);
        goto after_11;
    // 0x80382440: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    after_11:
    // 0x80382444: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80382448: jal         0x8030322C
    // 0x8038244C: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    func_8030322C_7148DC(rdram, ctx);
        goto after_12;
    // 0x8038244C: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    after_12:
L_80382450:
    // 0x80382450: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382454: lh          $v0, 0x5540($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5540);
    // 0x80382458: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x8038245C: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x80382460: sll         $t9, $v0, 4
    ctx->r25 = S32(ctx->r2 << 4);
    // 0x80382464: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x80382468: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8038246C: addu        $t8, $a0, $t7
    ctx->r24 = ADD32(ctx->r4, ctx->r15);
    // 0x80382470: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x80382474: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382478: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8038247C: sra         $t6, $t9, 7
    ctx->r14 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80382480: addiu       $t7, $t6, 0x100
    ctx->r15 = ADD32(ctx->r14, 0X100);
    // 0x80382484: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80382488: sh          $t8, 0x76($sp)
    MEM_H(0X76, ctx->r29) = ctx->r24;
    // 0x8038248C: lbu         $t9, 0x365($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X365);
    // 0x80382490: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x80382494: sll         $t8, $v0, 5
    ctx->r24 = S32(ctx->r2 << 5);
    // 0x80382498: bne         $t9, $at, L_80382578
    if (ctx->r25 != ctx->r1) {
        // 0x8038249C: andi        $t9, $t8, 0xFF
        ctx->r25 = ctx->r24 & 0XFF;
            goto L_80382578;
    }
    // 0x8038249C: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x803824A0: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x803824A4: addu        $t7, $a0, $t6
    ctx->r15 = ADD32(ctx->r4, ctx->r14);
    // 0x803824A8: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x803824AC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803824B0: addiu       $a1, $zero, 0x1F
    ctx->r5 = ADD32(0, 0X1F);
    // 0x803824B4: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x803824B8: addiu       $t6, $t9, 0x100
    ctx->r14 = ADD32(ctx->r25, 0X100);
    // 0x803824BC: sra         $t7, $t6, 3
    ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
    // 0x803824C0: andi        $t8, $v0, 0x7
    ctx->r24 = ctx->r2 & 0X7;
    // 0x803824C4: bne         $t8, $zero, L_8038256C
    if (ctx->r24 != 0) {
        // 0x803824C8: sh          $t7, 0x76($sp)
        MEM_H(0X76, ctx->r29) = ctx->r15;
            goto L_8038256C;
    }
    // 0x803824C8: sh          $t7, 0x76($sp)
    MEM_H(0X76, ctx->r29) = ctx->r15;
    // 0x803824CC: addiu       $t9, $zero, 0x6
    ctx->r25 = ADD32(0, 0X6);
    // 0x803824D0: addiu       $t6, $zero, 0xD
    ctx->r14 = ADD32(0, 0XD);
    // 0x803824D4: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x803824D8: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803824DC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803824E0: addiu       $a3, $zero, 0x1F
    ctx->r7 = ADD32(0, 0X1F);
    // 0x803824E4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803824E8: jal         0x803224C4
    // 0x803824EC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_13;
    // 0x803824EC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_13:
    // 0x803824F0: beq         $v0, $zero, L_80382538
    if (ctx->r2 == 0) {
        // 0x803824F4: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_80382538;
    }
    // 0x803824F4: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x803824F8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803824FC: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80382500: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382504: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80382508: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x8038250C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80382510: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x80382514: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80382518: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x8038251C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382520: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80382524: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
    // 0x80382528: jal         0x8032C360
    // 0x8038252C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_14;
    // 0x8038252C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_14:
    // 0x80382530: b           L_8038256C
    // 0x80382534: nop

        goto L_8038256C;
    // 0x80382534: nop

L_80382538:
    // 0x80382538: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038253C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80382540: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382544: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80382548: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x8038254C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80382550: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382554: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80382558: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x8038255C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80382560: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    // 0x80382564: jal         0x8032C360
    // 0x80382568: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_15;
    // 0x80382568: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_15:
L_8038256C:
    // 0x8038256C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80382570: b           L_80382584
    // 0x80382574: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
        goto L_80382584;
    // 0x80382574: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_80382578:
    // 0x80382578: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
    // 0x8038257C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80382580: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_80382584:
    // 0x80382584: beq         $v0, $zero, L_80382604
    if (ctx->r2 == 0) {
        // 0x80382588: nop
    
            goto L_80382604;
    }
    // 0x80382588: nop

    // 0x8038258C: jal         0x802DB8DC
    // 0x80382590: nop

    backup_joint_positions(rdram, ctx);
        goto after_16;
    // 0x80382590: nop

    after_16:
    // 0x80382594: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80382598: lhu         $a2, 0x2ECE($a2)
    ctx->r6 = MEM_HU(ctx->r6, 0X2ECE);
    // 0x8038259C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803825A0: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803825A4: beq         $a2, $at, L_803825C0
    if (ctx->r6 == ctx->r1) {
        // 0x803825A8: addiu       $a0, $a0, 0x5860
        ctx->r4 = ADD32(ctx->r4, 0X5860);
            goto L_803825C0;
    }
    // 0x803825A8: addiu       $a0, $a0, 0x5860
    ctx->r4 = ADD32(ctx->r4, 0X5860);
    // 0x803825AC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803825B0: beq         $a2, $at, L_803825E4
    if (ctx->r6 == ctx->r1) {
        // 0x803825B4: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_803825E4;
    }
    // 0x803825B4: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803825B8: b           L_80382604
    // 0x803825BC: nop

        goto L_80382604;
    // 0x803825BC: nop

L_803825C0:
    // 0x803825C0: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x803825C4: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x803825C8: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x803825CC: addiu       $a3, $a3, 0x5870
    ctx->r7 = ADD32(ctx->r7, 0X5870);
    // 0x803825D0: addiu       $a2, $a2, 0x5868
    ctx->r6 = ADD32(ctx->r6, 0X5868);
    // 0x803825D4: jal         0x802DB670
    // 0x803825D8: addiu       $a1, $a1, 0x5864
    ctx->r5 = ADD32(ctx->r5, 0X5864);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_17;
    // 0x803825D8: addiu       $a1, $a1, 0x5864
    ctx->r5 = ADD32(ctx->r5, 0X5864);
    after_17:
    // 0x803825DC: b           L_80382604
    // 0x803825E0: nop

        goto L_80382604;
    // 0x803825E0: nop

L_803825E4:
    // 0x803825E4: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x803825E8: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x803825EC: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x803825F0: addiu       $a3, $a3, 0x5884
    ctx->r7 = ADD32(ctx->r7, 0X5884);
    // 0x803825F4: addiu       $a2, $a2, 0x5868
    ctx->r6 = ADD32(ctx->r6, 0X5868);
    // 0x803825F8: addiu       $a1, $a1, 0x5864
    ctx->r5 = ADD32(ctx->r5, 0X5864);
    // 0x803825FC: jal         0x802DB670
    // 0x80382600: addiu       $a0, $a0, 0x5860
    ctx->r4 = ADD32(ctx->r4, 0X5860);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_18;
    // 0x80382600: addiu       $a0, $a0, 0x5860
    ctx->r4 = ADD32(ctx->r4, 0X5860);
    after_18:
L_80382604:
    // 0x80382604: jal         0x8038064C
    // 0x80382608: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_19;
    // 0x80382608: nop

    after_19:
    // 0x8038260C: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80382610: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x80382614: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x80382618: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x8038261C: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x80382620: addu        $t7, $t0, $t3
    ctx->r15 = ADD32(ctx->r8, ctx->r11);
    // 0x80382624: lw          $t1, 0x918($t7)
    ctx->r9 = MEM_W(ctx->r15, 0X918);
    // 0x80382628: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038262C: addiu       $t8, $t1, 0x1E
    ctx->r24 = ADD32(ctx->r9, 0X1E);
    // 0x80382630: slti        $at, $t8, 0xFA
    ctx->r1 = SIGNED(ctx->r24) < 0XFA ? 1 : 0;
    // 0x80382634: beq         $at, $zero, L_80382B90
    if (ctx->r1 == 0) {
        // 0x80382638: nop
    
            goto L_80382B90;
    }
    // 0x80382638: nop

    // 0x8038263C: lbu         $t9, 0x2EDA($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2EDA);
    // 0x80382640: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80382644: beq         $t9, $zero, L_80382B90
    if (ctx->r25 == 0) {
        // 0x80382648: nop
    
            goto L_80382B90;
    }
    // 0x80382648: nop

    // 0x8038264C: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80382650: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80382654: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80382658: bne         $a0, $zero, L_80382690
    if (ctx->r4 != 0) {
        // 0x8038265C: nop
    
            goto L_80382690;
    }
    // 0x8038265C: nop

    // 0x80382660: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x80382664: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80382668: beq         $v0, $zero, L_80382690
    if (ctx->r2 == 0) {
        // 0x8038266C: nop
    
            goto L_80382690;
    }
    // 0x8038266C: nop

    // 0x80382670: beq         $v0, $at, L_80382690
    if (ctx->r2 == ctx->r1) {
        // 0x80382674: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80382690;
    }
    // 0x80382674: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80382678: bne         $v0, $at, L_80382B90
    if (ctx->r2 != ctx->r1) {
        // 0x8038267C: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_80382B90;
    }
    // 0x8038267C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80382680: lbu         $t6, 0x2AA3($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2AA3);
    // 0x80382684: slti        $at, $t6, 0xB
    ctx->r1 = SIGNED(ctx->r14) < 0XB ? 1 : 0;
    // 0x80382688: bne         $at, $zero, L_80382B90
    if (ctx->r1 != 0) {
        // 0x8038268C: nop
    
            goto L_80382B90;
    }
    // 0x8038268C: nop

L_80382690:
    // 0x80382690: lh          $t7, 0x2C18($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C18);
    // 0x80382694: bne         $t7, $zero, L_803826EC
    if (ctx->r15 != 0) {
        // 0x80382698: nop
    
            goto L_803826EC;
    }
    // 0x80382698: nop

    // 0x8038269C: beq         $a0, $zero, L_803826EC
    if (ctx->r4 == 0) {
        // 0x803826A0: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_803826EC;
    }
    // 0x803826A0: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803826A4: lh          $t8, 0x2A98($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2A98);
    // 0x803826A8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803826AC: addiu       $t6, $t6, 0x28E0
    ctx->r14 = ADD32(ctx->r14, 0X28E0);
    // 0x803826B0: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x803826B4: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x803826B8: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x803826BC: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x803826C0: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x803826C4: addu        $v0, $t9, $t6
    ctx->r2 = ADD32(ctx->r25, ctx->r14);
    // 0x803826C8: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x803826CC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803826D0: beq         $v1, $at, L_803826E0
    if (ctx->r3 == ctx->r1) {
        // 0x803826D4: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803826E0;
    }
    // 0x803826D4: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803826D8: bne         $v1, $at, L_803826EC
    if (ctx->r3 != ctx->r1) {
        // 0x803826DC: nop
    
            goto L_803826EC;
    }
    // 0x803826DC: nop

L_803826E0:
    // 0x803826E0: lb          $t7, 0x64($v0)
    ctx->r15 = MEM_B(ctx->r2, 0X64);
    // 0x803826E4: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x803826E8: beq         $t7, $at, L_80382B90
    if (ctx->r15 == ctx->r1) {
        // 0x803826EC: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80382B90;
    }
L_803826EC:
    // 0x803826EC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803826F0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x803826F4: sll         $t8, $t1, 6
    ctx->r24 = S32(ctx->r9 << 6);
    // 0x803826F8: addu        $a0, $t0, $t8
    ctx->r4 = ADD32(ctx->r8, ctx->r24);
    // 0x803826FC: lh          $t6, 0x302($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X302);
    // 0x80382700: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382704: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80382708: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038270C: lw          $t8, 0x2EB0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB0);
    // 0x80382710: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80382714: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80382718: negu        $t7, $t6
    ctx->r15 = SUB32(0, ctx->r14);
    // 0x8038271C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80382720: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80382724: lw          $t6, 0x2EB4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB4);
    // 0x80382728: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x8038272C: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x80382730: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x80382734: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80382738: bgez        $t8, L_80382748
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8038273C: sra         $t9, $t8, 2
        ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
            goto L_80382748;
    }
    // 0x8038273C: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80382740: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x80382744: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_80382748:
    // 0x80382748: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038274C: lw          $t8, 0x2EB8($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB8);
    // 0x80382750: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80382754: bgez        $t6, L_80382764
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80382758: sra         $t7, $t6, 2
        ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
            goto L_80382764;
    }
    // 0x80382758: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x8038275C: addiu       $at, $t6, 0x3
    ctx->r1 = ADD32(ctx->r14, 0X3);
    // 0x80382760: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_80382764:
    // 0x80382764: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80382768: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038276C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80382770: lh          $t6, 0x2ED2($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED2);
    // 0x80382774: lw          $t7, 0x2ED4($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2ED4);
    // 0x80382778: bgez        $t8, L_80382788
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8038277C: sra         $t9, $t8, 2
        ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
            goto L_80382788;
    }
    // 0x8038277C: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80382780: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x80382784: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_80382788:
    // 0x80382788: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8038278C: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x80382790: jal         0x80127640
    // 0x80382794: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    func_80127640(rdram, ctx);
        goto after_20;
    // 0x80382794: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    after_20:
    // 0x80382798: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x8038279C: addiu       $a3, $a3, -0x6178
    ctx->r7 = ADD32(ctx->r7, -0X6178);
    // 0x803827A0: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x803827A4: lui         $t9, 0x104
    ctx->r25 = S32(0X104 << 16);
    // 0x803827A8: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x803827AC: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x803827B0: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x803827B4: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x803827B8: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x803827BC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x803827C0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x803827C4: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803827C8: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x803827CC: addu        $t6, $t0, $t3
    ctx->r14 = ADD32(ctx->r8, ctx->r11);
    // 0x803827D0: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x803827D4: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803827D8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803827DC: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x803827E0: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x803827E4: addu        $t6, $t9, $at
    ctx->r14 = ADD32(ctx->r25, ctx->r1);
    // 0x803827E8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x803827EC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x803827F0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803827F4: lui         $a0, 0x401
    ctx->r4 = S32(0X401 << 16);
    // 0x803827F8: addu        $t7, $t0, $t3
    ctx->r15 = ADD32(ctx->r8, ctx->r11);
    // 0x803827FC: lw          $t8, 0x918($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X918);
    // 0x80382800: lui         $a1, 0x401
    ctx->r5 = S32(0X401 << 16);
    // 0x80382804: lui         $a2, 0x401
    ctx->r6 = S32(0X401 << 16);
    // 0x80382808: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8038280C: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80382810: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
    // 0x80382814: addiu       $a2, $a2, -0x3D80
    ctx->r6 = ADD32(ctx->r6, -0X3D80);
    // 0x80382818: addiu       $a1, $a1, -0x3960
    ctx->r5 = ADD32(ctx->r5, -0X3960);
    // 0x8038281C: jal         0x803565D4
    // 0x80382820: addiu       $a0, $a0, -0x3B80
    ctx->r4 = ADD32(ctx->r4, -0X3B80);
    load_2_tiles(rdram, ctx);
        goto after_21;
    // 0x80382820: addiu       $a0, $a0, -0x3B80
    ctx->r4 = ADD32(ctx->r4, -0X3B80);
    after_21:
    // 0x80382824: lh          $t0, 0x76($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X76);
    // 0x80382828: lh          $t3, 0x76($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X76);
    // 0x8038282C: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x80382830: sll         $t6, $t0, 5
    ctx->r14 = S32(ctx->r8 << 5);
    // 0x80382834: subu        $t6, $t6, $t0
    ctx->r14 = SUB32(ctx->r14, ctx->r8);
    // 0x80382838: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x8038283C: addu        $t6, $t6, $t0
    ctx->r14 = ADD32(ctx->r14, ctx->r8);
    // 0x80382840: sll         $t0, $t6, 3
    ctx->r8 = S32(ctx->r14 << 3);
    // 0x80382844: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x80382848: sll         $t6, $t3, 2
    ctx->r14 = S32(ctx->r11 << 2);
    // 0x8038284C: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x80382850: subu        $t6, $t6, $t3
    ctx->r14 = SUB32(ctx->r14, ctx->r11);
    // 0x80382854: sll         $t6, $t6, 4
    ctx->r14 = S32(ctx->r14 << 4);
    // 0x80382858: sra         $t2, $t0, 9
    ctx->r10 = S32(SIGNED(ctx->r8) >> 9);
    // 0x8038285C: subu        $t6, $t6, $t3
    ctx->r14 = SUB32(ctx->r14, ctx->r11);
    // 0x80382860: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80382864: addu        $t8, $t7, $t2
    ctx->r24 = ADD32(ctx->r15, ctx->r10);
    // 0x80382868: lh          $t7, 0x14($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X14);
    // 0x8038286C: sra         $t1, $t0, 12
    ctx->r9 = S32(SIGNED(ctx->r8) >> 12);
    // 0x80382870: subu        $t6, $t6, $t3
    ctx->r14 = SUB32(ctx->r14, ctx->r11);
    // 0x80382874: addu        $t9, $t8, $t1
    ctx->r25 = ADD32(ctx->r24, ctx->r9);
    // 0x80382878: sll         $t3, $t6, 3
    ctx->r11 = S32(ctx->r14 << 3);
    // 0x8038287C: sra         $t4, $t3, 11
    ctx->r12 = S32(SIGNED(ctx->r11) >> 11);
    // 0x80382880: sh          $t9, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r25;
    // 0x80382884: subu        $t8, $t7, $t4
    ctx->r24 = SUB32(ctx->r15, ctx->r12);
    // 0x80382888: subu        $t9, $t8, $t1
    ctx->r25 = SUB32(ctx->r24, ctx->r9);
    // 0x8038288C: sh          $t9, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r25;
    // 0x80382890: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80382894: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80382898: lui         $t7, 0x401
    ctx->r15 = S32(0X401 << 16);
    // 0x8038289C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803828A0: addiu       $t7, $t7, -0x4300
    ctx->r15 = ADD32(ctx->r15, -0X4300);
    // 0x803828A4: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803828A8: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803828AC: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803828B0: sw          $t4, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r12;
    // 0x803828B4: sw          $t3, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r11;
    // 0x803828B8: sw          $t1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r9;
    // 0x803828BC: sw          $t2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r10;
    // 0x803828C0: sw          $t0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r8;
    // 0x803828C4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803828C8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803828CC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803828D0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803828D4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803828D8: jal         0x802C78B0
    // 0x803828DC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_22;
    // 0x803828DC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_22:
    // 0x803828E0: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x803828E4: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x803828E8: lw          $t2, 0x58($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X58);
    // 0x803828EC: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x803828F0: lw          $t1, 0x54($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X54);
    // 0x803828F4: lw          $t4, 0x4C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X4C);
    // 0x803828F8: lh          $t7, 0x14($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X14);
    // 0x803828FC: subu        $t9, $t8, $t2
    ctx->r25 = SUB32(ctx->r24, ctx->r10);
    // 0x80382900: subu        $t6, $t9, $t1
    ctx->r14 = SUB32(ctx->r25, ctx->r9);
    // 0x80382904: lw          $t0, 0x5C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X5C);
    // 0x80382908: sh          $t6, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r14;
    // 0x8038290C: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x80382910: addu        $t8, $t7, $t4
    ctx->r24 = ADD32(ctx->r15, ctx->r12);
    // 0x80382914: addu        $t9, $t8, $t1
    ctx->r25 = ADD32(ctx->r24, ctx->r9);
    // 0x80382918: lw          $t3, 0x50($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X50);
    // 0x8038291C: sh          $t9, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r25;
    // 0x80382920: sra         $t5, $t0, 6
    ctx->r13 = S32(SIGNED(ctx->r8) >> 6);
    // 0x80382924: lh          $t9, 0x14($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X14);
    // 0x80382928: sra         $v1, $t0, 8
    ctx->r3 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8038292C: subu        $t7, $t6, $t5
    ctx->r15 = SUB32(ctx->r14, ctx->r13);
    // 0x80382930: subu        $t8, $t7, $v1
    ctx->r24 = SUB32(ctx->r15, ctx->r3);
    // 0x80382934: sra         $ra, $t3, 8
    ctx->r31 = S32(SIGNED(ctx->r11) >> 8);
    // 0x80382938: sh          $t8, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r24;
    // 0x8038293C: addu        $t6, $t9, $ra
    ctx->r14 = ADD32(ctx->r25, ctx->r31);
    // 0x80382940: lh          $t8, 0xA($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XA);
    // 0x80382944: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80382948: lh          $t6, 0x12($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X12);
    // 0x8038294C: sh          $t7, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r15;
    // 0x80382950: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x80382954: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80382958: sh          $t9, 0xA($v0)
    MEM_H(0XA, ctx->r2) = ctx->r25;
    // 0x8038295C: sh          $t7, 0x12($v0)
    MEM_H(0X12, ctx->r2) = ctx->r15;
    // 0x80382960: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80382964: lbu         $t8, 0x2EDD($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X2EDD);
    // 0x80382968: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038296C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80382970: bne         $t8, $zero, L_803829C8
    if (ctx->r24 != 0) {
        // 0x80382974: addiu       $a1, $zero, 0x2
        ctx->r5 = ADD32(0, 0X2);
            goto L_803829C8;
    }
    // 0x80382974: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80382978: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038297C: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80382980: lui         $t6, 0x401
    ctx->r14 = S32(0X401 << 16);
    // 0x80382984: addiu       $t6, $t6, -0x3FF0
    ctx->r14 = ADD32(ctx->r14, -0X3FF0);
    // 0x80382988: sw          $ra, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r31;
    // 0x8038298C: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80382990: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80382994: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80382998: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038299C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803829A0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803829A4: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x803829A8: sw          $t5, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r13;
    // 0x803829AC: jal         0x802C78B0
    // 0x803829B0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_23;
    // 0x803829B0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_23:
    // 0x803829B4: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x803829B8: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x803829BC: lw          $v1, 0x44($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X44);
    // 0x803829C0: lw          $t5, 0x48($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X48);
    // 0x803829C4: lw          $ra, 0x40($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X40);
L_803829C8:
    // 0x803829C8: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x803829CC: lh          $t6, 0x14($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X14);
    // 0x803829D0: lui         $a0, 0x401
    ctx->r4 = S32(0X401 << 16);
    // 0x803829D4: addu        $t8, $t7, $t5
    ctx->r24 = ADD32(ctx->r15, ctx->r13);
    // 0x803829D8: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x803829DC: subu        $t7, $t6, $ra
    ctx->r15 = SUB32(ctx->r14, ctx->r31);
    // 0x803829E0: sh          $t9, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r25;
    // 0x803829E4: subu        $t8, $t7, $v1
    ctx->r24 = SUB32(ctx->r15, ctx->r3);
    // 0x803829E8: lh          $t9, 0xA($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XA);
    // 0x803829EC: lh          $t7, 0x12($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X12);
    // 0x803829F0: sh          $t8, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r24;
    // 0x803829F4: lui         $a1, 0x401
    ctx->r5 = S32(0X401 << 16);
    // 0x803829F8: subu        $t6, $t9, $v1
    ctx->r14 = SUB32(ctx->r25, ctx->r3);
    // 0x803829FC: subu        $t8, $t7, $v1
    ctx->r24 = SUB32(ctx->r15, ctx->r3);
    // 0x80382A00: sh          $t6, 0xA($v0)
    MEM_H(0XA, ctx->r2) = ctx->r14;
    // 0x80382A04: sh          $t8, 0x12($v0)
    MEM_H(0X12, ctx->r2) = ctx->r24;
    // 0x80382A08: addiu       $a1, $a1, -0x3940
    ctx->r5 = ADD32(ctx->r5, -0X3940);
    // 0x80382A0C: jal         0x80356410
    // 0x80382A10: addiu       $a0, $a0, -0x3740
    ctx->r4 = ADD32(ctx->r4, -0X3740);
    load_1_tile(rdram, ctx);
        goto after_24;
    // 0x80382A10: addiu       $a0, $a0, -0x3740
    ctx->r4 = ADD32(ctx->r4, -0X3740);
    after_24:
    // 0x80382A14: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80382A18: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80382A1C: lui         $t6, 0x401
    ctx->r14 = S32(0X401 << 16);
    // 0x80382A20: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80382A24: addiu       $t6, $t6, -0x3E90
    ctx->r14 = ADD32(ctx->r14, -0X3E90);
    // 0x80382A28: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80382A2C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80382A30: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80382A34: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80382A38: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x80382A3C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80382A40: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80382A44: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80382A48: jal         0x802C78B0
    // 0x80382A4C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_25;
    // 0x80382A4C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_25:
    // 0x80382A50: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80382A54: lbu         $t7, 0x2EDD($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDD);
    // 0x80382A58: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382A5C: bne         $t7, $zero, L_80382B70
    if (ctx->r15 != 0) {
        // 0x80382A60: nop
    
            goto L_80382B70;
    }
    // 0x80382A60: nop

    // 0x80382A64: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80382A68: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    // 0x80382A6C: addiu       $a2, $sp, 0x72
    ctx->r6 = ADD32(ctx->r29, 0X72);
    // 0x80382A70: lh          $a0, 0x326($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X326);
    // 0x80382A74: addiu       $t8, $a0, 0x1
    ctx->r24 = ADD32(ctx->r4, 0X1);
    // 0x80382A78: jal         0x8031A150
    // 0x80382A7C: sh          $t8, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r24;
    func_8031A150_72B800(rdram, ctx);
        goto after_26;
    // 0x80382A7C: sh          $t8, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r24;
    after_26:
    // 0x80382A80: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80382A84: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80382A88: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    // 0x80382A8C: addiu       $a2, $sp, 0x72
    ctx->r6 = ADD32(ctx->r29, 0X72);
    // 0x80382A90: jal         0x8031A278
    // 0x80382A94: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_27;
    // 0x80382A94: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_27:
    // 0x80382A98: lh          $a2, 0x74($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X74);
    // 0x80382A9C: lh          $t6, 0x72($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X72);
    // 0x80382AA0: lui         $t8, 0x803C
    ctx->r24 = S32(0X803C << 16);
    // 0x80382AA4: sll         $t9, $a2, 1
    ctx->r25 = S32(ctx->r6 << 1);
    // 0x80382AA8: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80382AAC: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80382AB0: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x80382AB4: addu        $a2, $a2, $t9
    ctx->r6 = ADD32(ctx->r6, ctx->r25);
    // 0x80382AB8: lh          $a2, -0x2AB6($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2AB6);
    // 0x80382ABC: lh          $t8, -0x29FE($t8)
    ctx->r24 = MEM_H(ctx->r24, -0X29FE);
    // 0x80382AC0: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80382AC4: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80382AC8: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80382ACC: addiu       $a0, $a0, 0xCC0
    ctx->r4 = ADD32(ctx->r4, 0XCC0);
    // 0x80382AD0: sh          $a2, 0x74($sp)
    MEM_H(0X74, ctx->r29) = ctx->r6;
    // 0x80382AD4: jal         0x80356BD8
    // 0x80382AD8: sh          $t8, 0x72($sp)
    MEM_H(0X72, ctx->r29) = ctx->r24;
    func_80356BD8_768288(rdram, ctx);
        goto after_28;
    // 0x80382AD8: sh          $t8, 0x72($sp)
    MEM_H(0X72, ctx->r29) = ctx->r24;
    after_28:
    // 0x80382ADC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80382AE0: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80382AE4: lui         $t6, 0x401
    ctx->r14 = S32(0X401 << 16);
    // 0x80382AE8: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80382AEC: addiu       $t6, $t6, -0x3DC0
    ctx->r14 = ADD32(ctx->r14, -0X3DC0);
    // 0x80382AF0: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80382AF4: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80382AF8: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80382AFC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80382B00: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80382B04: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80382B08: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80382B0C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80382B10: jal         0x802C78B0
    // 0x80382B14: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x80382B14: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_29:
    // 0x80382B18: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80382B1C: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80382B20: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80382B24: addiu       $a0, $a0, 0xCC0
    ctx->r4 = ADD32(ctx->r4, 0XCC0);
    // 0x80382B28: jal         0x80356BD8
    // 0x80382B2C: lh          $a2, 0x72($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X72);
    func_80356BD8_768288(rdram, ctx);
        goto after_30;
    // 0x80382B2C: lh          $a2, 0x72($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X72);
    after_30:
    // 0x80382B30: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80382B34: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80382B38: lui         $t9, 0x401
    ctx->r25 = S32(0X401 << 16);
    // 0x80382B3C: addiu       $t9, $t9, -0x3DA0
    ctx->r25 = ADD32(ctx->r25, -0X3DA0);
    // 0x80382B40: lui         $t7, 0x1
    ctx->r15 = S32(0X1 << 16);
    // 0x80382B44: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80382B48: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80382B4C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80382B50: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80382B54: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80382B58: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    // 0x80382B5C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80382B60: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80382B64: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80382B68: jal         0x802C78B0
    // 0x80382B6C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x80382B6C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_31:
L_80382B70:
    // 0x80382B70: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80382B74: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x80382B78: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80382B7C: lui         $t7, 0xBD00
    ctx->r15 = S32(0XBD00 << 16);
    // 0x80382B80: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80382B84: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80382B88: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80382B8C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
L_80382B90:
    // 0x80382B90: jal         0x8035D6A0
    // 0x80382B94: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_32;
    // 0x80382B94: nop

    after_32:
    // 0x80382B98: b           L_80382BAC
    // 0x80382B9C: lh          $t8, 0x7A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X7A);
        goto L_80382BAC;
    // 0x80382B9C: lh          $t8, 0x7A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X7A);
L_80382BA0:
    // 0x80382BA0: jal         0x8035D6D0
    // 0x80382BA4: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_33;
    // 0x80382BA4: nop

    after_33:
    // 0x80382BA8: lh          $t8, 0x7A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X7A);
L_80382BAC:
    // 0x80382BAC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80382BB0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382BB4: beq         $t8, $zero, L_80382BC4
    if (ctx->r24 == 0) {
        // 0x80382BB8: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_80382BC4;
    }
    // 0x80382BB8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80382BBC: bne         $t8, $at, L_80382C3C
    if (ctx->r24 != ctx->r1) {
        // 0x80382BC0: nop
    
            goto L_80382C3C;
    }
    // 0x80382BC0: nop

L_80382BC4:
    // 0x80382BC4: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80382BC8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80382BCC: lhu         $t7, 0xBA($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XBA);
    // 0x80382BD0: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x80382BD4: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x80382BD8: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x80382BDC: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x80382BE0: sra         $t6, $t8, 2
    ctx->r14 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80382BE4: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x80382BE8: lh          $a3, 0x302($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X302);
    // 0x80382BEC: addu        $a2, $t9, $t6
    ctx->r6 = ADD32(ctx->r25, ctx->r14);
    // 0x80382BF0: lui         $t9, 0x103
    ctx->r25 = S32(0X103 << 16);
    // 0x80382BF4: addiu       $t9, $t9, 0x3190
    ctx->r25 = ADD32(ctx->r25, 0X3190);
    // 0x80382BF8: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80382BFC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80382C00: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x80382C04: lbu         $t9, 0x5538($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X5538);
    // 0x80382C08: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80382C0C: addiu       $t7, $zero, 0x9
    ctx->r15 = ADD32(0, 0X9);
    // 0x80382C10: addiu       $t6, $zero, 0x1C
    ctx->r14 = ADD32(0, 0X1C);
    // 0x80382C14: addiu       $t8, $zero, 0x9B
    ctx->r24 = ADD32(0, 0X9B);
    // 0x80382C18: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80382C1C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80382C20: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80382C24: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80382C28: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80382C2C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80382C30: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80382C34: jal         0x8034BD20
    // 0x80382C38: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_34;
    // 0x80382C38: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    after_34:
L_80382C3C:
    // 0x80382C3C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80382C40: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80382C44: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80382C48: addiu       $a1, $zero, 0x271
    ctx->r5 = ADD32(0, 0X271);
    // 0x80382C4C: bne         $t6, $zero, L_80382C84
    if (ctx->r14 != 0) {
        // 0x80382C50: addiu       $a2, $zero, 0x271
        ctx->r6 = ADD32(0, 0X271);
            goto L_80382C84;
    }
    // 0x80382C50: addiu       $a2, $zero, 0x271
    ctx->r6 = ADD32(0, 0X271);
    // 0x80382C54: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382C58: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80382C5C: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x80382C60: lbu         $t7, 0x365($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X365);
    // 0x80382C64: bne         $t7, $at, L_80382C84
    if (ctx->r15 != ctx->r1) {
        // 0x80382C68: nop
    
            goto L_80382C84;
    }
    // 0x80382C68: nop

    // 0x80382C6C: lh          $v0, 0x2EC($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2EC);
    // 0x80382C70: blez        $v0, L_80382C80
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80382C74: addiu       $t8, $v0, -0x1
        ctx->r24 = ADD32(ctx->r2, -0X1);
            goto L_80382C80;
    }
    // 0x80382C74: addiu       $t8, $v0, -0x1
    ctx->r24 = ADD32(ctx->r2, -0X1);
    // 0x80382C78: b           L_80382C84
    // 0x80382C7C: sh          $t8, 0x2EC($v1)
    MEM_H(0X2EC, ctx->r3) = ctx->r24;
        goto L_80382C84;
    // 0x80382C7C: sh          $t8, 0x2EC($v1)
    MEM_H(0X2EC, ctx->r3) = ctx->r24;
L_80382C80:
    // 0x80382C80: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_80382C84:
    // 0x80382C84: jal         0x80303D00
    // 0x80382C88: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    func_80303D00_7153B0(rdram, ctx);
        goto after_35;
    // 0x80382C88: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    after_35:
    // 0x80382C8C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80382C90: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
    // 0x80382C94: jr          $ra
    // 0x80382C98: nop

    return;
    // 0x80382C98: nop

;}
RECOMP_FUNC void func_80382C9C_79434C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382C9C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80382CA0: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80382CA4: addiu       $t6, $zero, 0x12
    ctx->r14 = ADD32(0, 0X12);
    // 0x80382CA8: jr          $ra
    // 0x80382CAC: sb          $t6, 0x365($t7)
    MEM_B(0X365, ctx->r15) = ctx->r14;
    return;
    // 0x80382CAC: sb          $t6, 0x365($t7)
    MEM_B(0X365, ctx->r15) = ctx->r14;
;}
RECOMP_FUNC void func_80382CB0_794360(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382CB0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80382CB4: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80382CB8: jr          $ra
    // 0x80382CBC: sb          $zero, 0x365($t6)
    MEM_B(0X365, ctx->r14) = 0;
    return;
    // 0x80382CBC: sb          $zero, 0x365($t6)
    MEM_B(0X365, ctx->r14) = 0;
;}
RECOMP_FUNC void func_80382CC0_794370(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382CC0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382CC4: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x80382CC8: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80382CCC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80382CD0: addiu       $t9, $zero, 0x12
    ctx->r25 = ADD32(0, 0X12);
    // 0x80382CD4: sh          $a0, 0x2EC($t8)
    MEM_H(0X2EC, ctx->r24) = ctx->r4;
    // 0x80382CD8: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x80382CDC: jr          $ra
    // 0x80382CE0: sb          $t9, 0x365($t0)
    MEM_B(0X365, ctx->r8) = ctx->r25;
    return;
    // 0x80382CE0: sb          $t9, 0x365($t0)
    MEM_B(0X365, ctx->r8) = ctx->r25;
;}
RECOMP_FUNC void func_80382CE4_794394(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382CE4: jr          $ra
    // 0x80382CE8: nop

    return;
    // 0x80382CE8: nop

;}
RECOMP_FUNC void func_80382CF0_7943A0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80382CF0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80382CF4: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80382CF8: addiu       $sp, $sp, -0x98
    ctx->r29 = ADD32(ctx->r29, -0X98);
    // 0x80382CFC: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80382D00: beq         $t6, $zero, L_80382DE0
    if (ctx->r14 == 0) {
        // 0x80382D04: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_80382DE0;
    }
    // 0x80382D04: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382D08: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382D0C: lh          $a3, 0x1C($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X1C);
    // 0x80382D10: bgez        $a3, L_80382D20
    if (SIGNED(ctx->r7) >= 0) {
        // 0x80382D14: or          $t0, $a3, $zero
        ctx->r8 = ctx->r7 | 0;
            goto L_80382D20;
    }
    // 0x80382D14: or          $t0, $a3, $zero
    ctx->r8 = ctx->r7 | 0;
    // 0x80382D18: b           L_80382D20
    // 0x80382D1C: negu        $t0, $a3
    ctx->r8 = SUB32(0, ctx->r7);
        goto L_80382D20;
    // 0x80382D1C: negu        $t0, $a3
    ctx->r8 = SUB32(0, ctx->r7);
L_80382D20:
    // 0x80382D20: lh          $v0, 0x20($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X20);
    // 0x80382D24: bgez        $v0, L_80382D34
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80382D28: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_80382D34;
    }
    // 0x80382D28: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80382D2C: b           L_80382D34
    // 0x80382D30: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_80382D34;
    // 0x80382D30: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_80382D34:
    // 0x80382D34: addu        $t7, $a2, $t0
    ctx->r15 = ADD32(ctx->r6, ctx->r8);
    // 0x80382D38: slti        $at, $t7, 0xB
    ctx->r1 = SIGNED(ctx->r15) < 0XB ? 1 : 0;
    // 0x80382D3C: bne         $at, $zero, L_80382DE0
    if (ctx->r1 != 0) {
        // 0x80382D40: addiu       $a2, $zero, 0x3
        ctx->r6 = ADD32(0, 0X3);
            goto L_80382DE0;
    }
    // 0x80382D40: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80382D44: multu       $a3, $a2
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80382D48: lh          $t8, 0x4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4);
    // 0x80382D4C: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x80382D50: mflo        $t9
    ctx->r25 = lo;
    // 0x80382D54: sra         $t4, $t9, 1
    ctx->r12 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80382D58: addu        $a0, $t8, $t4
    ctx->r4 = ADD32(ctx->r24, ctx->r12);
    // 0x80382D5C: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80382D60: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80382D64: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80382D68: mflo        $t9
    ctx->r25 = lo;
    // 0x80382D6C: sra         $t8, $t9, 1
    ctx->r24 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80382D70: addu        $a1, $t7, $t8
    ctx->r5 = ADD32(ctx->r15, ctx->r24);
    // 0x80382D74: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x80382D78: jal         0x8031124C
    // 0x80382D7C: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_0;
    // 0x80382D7C: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    after_0:
    // 0x80382D80: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80382D84: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x80382D88: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80382D8C: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80382D90: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x80382D94: addiu       $t7, $t9, 0x60
    ctx->r15 = ADD32(ctx->r25, 0X60);
    // 0x80382D98: slt         $at, $t7, $t6
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80382D9C: beq         $at, $zero, L_80382DE0
    if (ctx->r1 == 0) {
        // 0x80382DA0: nop
    
            goto L_80382DE0;
    }
    // 0x80382DA0: nop

    // 0x80382DA4: lh          $t8, 0x1C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X1C);
    // 0x80382DA8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80382DAC: addiu       $a1, $zero, 0xD
    ctx->r5 = ADD32(0, 0XD);
    // 0x80382DB0: negu        $t4, $t8
    ctx->r12 = SUB32(0, ctx->r24);
    // 0x80382DB4: sra         $t5, $t4, 1
    ctx->r13 = S32(SIGNED(ctx->r12) >> 1);
    // 0x80382DB8: sh          $t5, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r13;
    // 0x80382DBC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80382DC0: addiu       $a2, $zero, 0x19
    ctx->r6 = ADD32(0, 0X19);
    // 0x80382DC4: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x80382DC8: lh          $t9, 0x20($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X20);
    // 0x80382DCC: negu        $t6, $t9
    ctx->r14 = SUB32(0, ctx->r25);
    // 0x80382DD0: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80382DD4: sh          $t7, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r15;
    // 0x80382DD8: jal         0x801373CC
    // 0x80382DDC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_1;
    // 0x80382DDC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_1:
L_80382DE0:
    // 0x80382DE0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382DE4: lh          $v0, 0x553A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X553A);
    // 0x80382DE8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382DEC: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x80382DF0: bne         $v0, $at, L_80382E38
    if (ctx->r2 != ctx->r1) {
        // 0x80382DF4: lw          $v1, 0x5530($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X5530);
            goto L_80382E38;
    }
    // 0x80382DF4: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382DF8: lh          $t8, 0x8($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X8);
    // 0x80382DFC: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x80382E00: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382E04: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80382E08: lh          $t4, 0xC($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XC);
    // 0x80382E0C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80382E10: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x80382E14: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382E18: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80382E1C: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x80382E20: jal         0x8032C360
    // 0x80382E24: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x80382E24: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_2:
    // 0x80382E28: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382E2C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382E30: lh          $v0, 0x553A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X553A);
    // 0x80382E34: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
L_80382E38:
    // 0x80382E38: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x80382E3C: bne         $v0, $at, L_80382E78
    if (ctx->r2 != ctx->r1) {
        // 0x80382E40: addiu       $a0, $zero, 0xA
        ctx->r4 = ADD32(0, 0XA);
            goto L_80382E78;
    }
    // 0x80382E40: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x80382E44: lh          $t5, 0x8($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X8);
    // 0x80382E48: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x80382E4C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80382E50: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80382E54: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x80382E58: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80382E5C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382E60: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80382E64: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80382E68: jal         0x8032C360
    // 0x80382E6C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_3;
    // 0x80382E6C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_3:
    // 0x80382E70: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382E74: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
L_80382E78:
    // 0x80382E78: lbu         $t6, 0x162($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X162);
    // 0x80382E7C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80382E80: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80382E84: bne         $t6, $at, L_803830C0
    if (ctx->r14 != ctx->r1) {
        // 0x80382E88: lbu         $a1, 0x5538($a1)
        ctx->r5 = MEM_BU(ctx->r5, 0X5538);
            goto L_803830C0;
    }
    // 0x80382E88: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
    // 0x80382E8C: beq         $a1, $zero, L_803830C0
    if (ctx->r5 == 0) {
        // 0x80382E90: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_803830C0;
    }
    // 0x80382E90: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80382E94: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80382E98: lui         $t7, 0x801F
    ctx->r15 = S32(0X801F << 16);
    // 0x80382E9C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80382EA0: lbu         $a0, 0x369($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X369);
    // 0x80382EA4: bne         $a0, $zero, L_80382ECC
    if (ctx->r4 != 0) {
        // 0x80382EA8: nop
    
            goto L_80382ECC;
    }
    // 0x80382EA8: nop

    // 0x80382EAC: lhu         $t7, -0x6172($t7)
    ctx->r15 = MEM_HU(ctx->r15, -0X6172);
    // 0x80382EB0: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80382EB4: bne         $t7, $zero, L_803830C0
    if (ctx->r15 != 0) {
        // 0x80382EB8: nop
    
            goto L_803830C0;
    }
    // 0x80382EB8: nop

    // 0x80382EBC: sb          $t8, 0x369($v0)
    MEM_B(0X369, ctx->r2) = ctx->r24;
    // 0x80382EC0: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80382EC4: b           L_803830C0
    // 0x80382EC8: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
        goto L_803830C0;
    // 0x80382EC8: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
L_80382ECC:
    // 0x80382ECC: bne         $a0, $at, L_803830C0
    if (ctx->r4 != ctx->r1) {
        // 0x80382ED0: lui         $t4, 0x801F
        ctx->r12 = S32(0X801F << 16);
            goto L_803830C0;
    }
    // 0x80382ED0: lui         $t4, 0x801F
    ctx->r12 = S32(0X801F << 16);
    // 0x80382ED4: lhu         $t4, -0x6172($t4)
    ctx->r12 = MEM_HU(ctx->r12, -0X6172);
    // 0x80382ED8: beq         $t4, $zero, L_803830C0
    if (ctx->r12 == 0) {
        // 0x80382EDC: nop
    
            goto L_803830C0;
    }
    // 0x80382EDC: nop

    // 0x80382EE0: lh          $t5, 0x24($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X24);
    // 0x80382EE4: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x80382EE8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80382EEC: slti        $at, $t5, 0x5
    ctx->r1 = SIGNED(ctx->r13) < 0X5 ? 1 : 0;
    // 0x80382EF0: beq         $at, $zero, L_803830C0
    if (ctx->r1 == 0) {
        // 0x80382EF4: nop
    
            goto L_803830C0;
    }
    // 0x80382EF4: nop

    // 0x80382EF8: sb          $t9, 0x369($v0)
    MEM_B(0X369, ctx->r2) = ctx->r25;
    // 0x80382EFC: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80382F00: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x80382F04: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x80382F08: lh          $t8, 0x302($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X302);
    // 0x80382F0C: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80382F10: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382F14: andi        $t4, $t8, 0xFF
    ctx->r12 = ctx->r24 & 0XFF;
    // 0x80382F18: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x80382F1C: addu        $t9, $a0, $t5
    ctx->r25 = ADD32(ctx->r4, ctx->r13);
    // 0x80382F20: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x80382F24: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382F28: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80382F2C: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80382F30: lw          $t6, 0x1C($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X1C);
    // 0x80382F34: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x80382F38: mtc1        $at, $f15
    ctx->f_odd[(15 - 1) * 2] = ctx->r1;
    // 0x80382F3C: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80382F40: mflo        $t8
    ctx->r24 = lo;
    // 0x80382F44: addu        $t4, $t6, $t8
    ctx->r12 = ADD32(ctx->r14, ctx->r24);
    // 0x80382F48: sw          $t4, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r12;
    // 0x80382F4C: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80382F50: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382F54: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382F58: lh          $t7, 0x302($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X302);
    // 0x80382F5C: lw          $t5, 0x20($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X20);
    // 0x80382F60: addiu       $t6, $t7, 0x40
    ctx->r14 = ADD32(ctx->r15, 0X40);
    // 0x80382F64: andi        $t8, $t6, 0xFF
    ctx->r24 = ctx->r14 & 0XFF;
    // 0x80382F68: sll         $t4, $t8, 1
    ctx->r12 = S32(ctx->r24 << 1);
    // 0x80382F6C: addu        $t9, $a0, $t4
    ctx->r25 = ADD32(ctx->r4, ctx->r12);
    // 0x80382F70: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x80382F74: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80382F78: mflo        $t6
    ctx->r14 = lo;
    // 0x80382F7C: addu        $t8, $t5, $t6
    ctx->r24 = ADD32(ctx->r13, ctx->r14);
    // 0x80382F80: sw          $t8, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r24;
    // 0x80382F84: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382F88: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382F8C: lw          $t4, 0x1C($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X1C);
    // 0x80382F90: lw          $t9, 0x20($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X20);
    // 0x80382F94: mtc1        $t4, $f8
    ctx->f8.u32l = ctx->r12;
    // 0x80382F98: mtc1        $t9, $f16
    ctx->f16.u32l = ctx->r25;
    // 0x80382F9C: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80382FA0: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x80382FA4: div.d       $f0, $f10, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f14.d); 
    ctx->f0.d = DIV_D(ctx->f10.d, ctx->f14.d);
    // 0x80382FA8: div.d       $f2, $f18, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f14.d); 
    ctx->f2.d = DIV_D(ctx->f18.d, ctx->f14.d);
    // 0x80382FAC: mul.d       $f4, $f0, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f0.d);
    // 0x80382FB0: nop

    // 0x80382FB4: mul.d       $f6, $f2, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = MUL_D(ctx->f2.d, ctx->f2.d);
    // 0x80382FB8: add.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d + ctx->f6.d;
    // 0x80382FBC: jal         0x80137E10
    // 0x80382FC0: cvt.s.d     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f12.fl = CVT_S_D(ctx->f8.d);
    sqrtf_recomp(rdram, ctx);
        goto after_4;
    // 0x80382FC0: cvt.s.d     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f12.fl = CVT_S_D(ctx->f8.d);
    after_4:
    // 0x80382FC4: lui         $at, 0x4034
    ctx->r1 = S32(0X4034 << 16);
    // 0x80382FC8: mtc1        $at, $f13
    ctx->f_odd[(13 - 1) * 2] = ctx->r1;
    // 0x80382FCC: mtc1        $zero, $f12
    ctx->f12.u32l = 0;
    // 0x80382FD0: cvt.d.s     $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f2.d = CVT_D_S(ctx->f0.fl);
    // 0x80382FD4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80382FD8: c.lt.d      $f12, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f12.d < ctx->f2.d;
    // 0x80382FDC: addiu       $t4, $zero, 0x7
    ctx->r12 = ADD32(0, 0X7);
    // 0x80382FE0: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    // 0x80382FE4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80382FE8: bc1f        L_8038303C
    if (!c1cs) {
        // 0x80382FEC: nop
    
            goto L_8038303C;
    }
    // 0x80382FEC: nop

    // 0x80382FF0: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80382FF4: lw          $t7, 0x1C($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X1C);
    // 0x80382FF8: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x80382FFC: nop

    // 0x80383000: cvt.d.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.d = CVT_D_W(ctx->f10.u32l);
    // 0x80383004: mul.d       $f18, $f16, $f12
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f12.d); 
    ctx->f18.d = MUL_D(ctx->f16.d, ctx->f12.d);
    // 0x80383008: div.d       $f4, $f18, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f2.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f2.d);
    // 0x8038300C: trunc.w.d   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_D(ctx->f4.d);
    // 0x80383010: swc1        $f6, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->f6.u32l;
    // 0x80383014: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80383018: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8038301C: lw          $t6, 0x20($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X20);
    // 0x80383020: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80383024: nop

    // 0x80383028: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x8038302C: mul.d       $f16, $f10, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f12.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f12.d);
    // 0x80383030: div.d       $f18, $f16, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f2.d); 
    ctx->f18.d = DIV_D(ctx->f16.d, ctx->f2.d);
    // 0x80383034: trunc.w.d   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x80383038: swc1        $f4, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->f4.u32l;
L_8038303C:
    // 0x8038303C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80383040: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80383044: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
    // 0x80383048: addiu       $v0, $v0, 0x4
    ctx->r2 = ADD32(ctx->r2, 0X4);
    // 0x8038304C: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x80383050: beql        $at, $zero, L_80383064
    if (ctx->r1 == 0) {
        // 0x80383054: sh          $v0, 0x24($v1)
        MEM_H(0X24, ctx->r3) = ctx->r2;
            goto L_80383064;
    }
    goto skip_0;
    // 0x80383054: sh          $v0, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r2;
    skip_0:
    // 0x80383058: b           L_80383064
    // 0x8038305C: sh          $t4, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r12;
        goto L_80383064;
    // 0x8038305C: sh          $t4, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r12;
    // 0x80383060: sh          $v0, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r2;
L_80383064:
    // 0x80383064: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80383068: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8038306C: lh          $v1, 0x308($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X308);
    // 0x80383070: addiu       $v1, $v1, -0x19
    ctx->r3 = ADD32(ctx->r3, -0X19);
    // 0x80383074: bgezl       $v1, L_80383088
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80383078: sh          $v1, 0x308($v0)
        MEM_H(0X308, ctx->r2) = ctx->r3;
            goto L_80383088;
    }
    goto skip_1;
    // 0x80383078: sh          $v1, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r3;
    skip_1:
    // 0x8038307C: b           L_80383088
    // 0x80383080: sh          $zero, 0x308($v0)
    MEM_H(0X308, ctx->r2) = 0;
        goto L_80383088;
    // 0x80383080: sh          $zero, 0x308($v0)
    MEM_H(0X308, ctx->r2) = 0;
    // 0x80383084: sh          $v1, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r3;
L_80383088:
    // 0x80383088: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038308C: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80383090: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80383094: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80383098: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x8038309C: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x803830A0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803830A4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803830A8: lh          $t7, 0xC($v1)
    ctx->r15 = MEM_H(ctx->r3, 0XC);
    // 0x803830AC: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x803830B0: jal         0x8032C360
    // 0x803830B4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    play_sound_effect_at_location(rdram, ctx);
        goto after_5;
    // 0x803830B4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_5:
    // 0x803830B8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x803830BC: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
L_803830C0:
    // 0x803830C0: beq         $a1, $zero, L_80383118
    if (ctx->r5 == 0) {
        // 0x803830C4: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_80383118;
    }
    // 0x803830C4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803830C8: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x803830CC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803830D0: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x803830D4: lh          $v1, 0xD6($t5)
    ctx->r3 = MEM_H(ctx->r13, 0XD6);
    // 0x803830D8: beq         $a0, $v1, L_803830F8
    if (ctx->r4 == ctx->r3) {
        // 0x803830DC: nop
    
            goto L_803830F8;
    }
    // 0x803830DC: nop

    // 0x803830E0: bne         $v1, $zero, L_80383100
    if (ctx->r3 != 0) {
        // 0x803830E4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80383100;
    }
    // 0x803830E4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803830E8: beq         $a0, $at, L_803830F8
    if (ctx->r4 == ctx->r1) {
        // 0x803830EC: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803830F8;
    }
    // 0x803830EC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803830F0: bnel        $a0, $at, L_80383104
    if (ctx->r4 != ctx->r1) {
        // 0x803830F4: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_80383104;
    }
    goto skip_2;
    // 0x803830F4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    skip_2:
L_803830F8:
    // 0x803830F8: b           L_80383104
    // 0x803830FC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
        goto L_80383104;
    // 0x803830FC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
L_80383100:
    // 0x80383100: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_80383104:
    // 0x80383104: beq         $a2, $zero, L_80383118
    if (ctx->r6 == 0) {
        // 0x80383108: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_80383118;
    }
    // 0x80383108: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038310C: sh          $zero, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = 0;
    // 0x80383110: b           L_803831AC
    // 0x80383114: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_803831AC;
    // 0x80383114: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_80383118:
    // 0x80383118: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038311C: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x80383120: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80383124: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x80383128: lh          $v1, 0xD6($t1)
    ctx->r3 = MEM_H(ctx->r9, 0XD6);
    // 0x8038312C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80383130: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80383134: beq         $a0, $v1, L_80383154
    if (ctx->r4 == ctx->r3) {
        // 0x80383138: addiu       $a3, $zero, 0x800
        ctx->r7 = ADD32(0, 0X800);
            goto L_80383154;
    }
    // 0x80383138: addiu       $a3, $zero, 0x800
    ctx->r7 = ADD32(0, 0X800);
    // 0x8038313C: bne         $v1, $zero, L_8038315C
    if (ctx->r3 != 0) {
        // 0x80383140: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8038315C;
    }
    // 0x80383140: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80383144: beq         $a0, $at, L_80383154
    if (ctx->r4 == ctx->r1) {
        // 0x80383148: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80383154;
    }
    // 0x80383148: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038314C: bnel        $a0, $at, L_80383160
    if (ctx->r4 != ctx->r1) {
        // 0x80383150: or          $t0, $zero, $zero
        ctx->r8 = 0 | 0;
            goto L_80383160;
    }
    goto skip_3;
    // 0x80383150: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    skip_3:
L_80383154:
    // 0x80383154: b           L_80383160
    // 0x80383158: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
        goto L_80383160;
    // 0x80383158: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
L_8038315C:
    // 0x8038315C: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_80383160:
    // 0x80383160: lw          $t6, 0xC($v0)
    ctx->r14 = MEM_W(ctx->r2, 0XC);
    // 0x80383164: lhu         $t8, 0xBA($t1)
    ctx->r24 = MEM_HU(ctx->r9, 0XBA);
    // 0x80383168: lw          $a0, 0x4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X4);
    // 0x8038316C: lw          $a1, 0x8($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X8);
    // 0x80383170: sll         $t4, $t8, 15
    ctx->r12 = S32(ctx->r24 << 15);
    // 0x80383174: addu        $a2, $t6, $t4
    ctx->r6 = ADD32(ctx->r14, ctx->r12);
    // 0x80383178: sltiu       $t6, $t0, 0x1
    ctx->r14 = ctx->r8 < 0X1 ? 1 : 0;
    // 0x8038317C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80383180: addiu       $t9, $zero, 0x3C
    ctx->r25 = ADD32(0, 0X3C);
    // 0x80383184: addiu       $t7, $zero, 0x3C
    ctx->r15 = ADD32(0, 0X3C);
    // 0x80383188: addiu       $t5, $zero, 0x78
    ctx->r13 = ADD32(0, 0X78);
    // 0x8038318C: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x80383190: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80383194: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80383198: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8038319C: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x803831A0: jal         0x802E89F0
    // 0x803831A4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_6;
    // 0x803831A4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_6:
    // 0x803831A8: sh          $v0, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r2;
L_803831AC:
    // 0x803831AC: lh          $t4, 0x8A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X8A);
    // 0x803831B0: bne         $t4, $zero, L_80383750
    if (ctx->r12 != 0) {
        // 0x803831B4: nop
    
            goto L_80383750;
    }
    // 0x803831B4: nop

    // 0x803831B8: jal         0x8034B45C
    // 0x803831BC: nop

    func_8034B45C_75CB0C(rdram, ctx);
        goto after_7;
    // 0x803831BC: nop

    after_7:
    // 0x803831C0: jal         0x8035D120
    // 0x803831C4: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_8;
    // 0x803831C4: nop

    after_8:
    // 0x803831C8: jal         0x8035DA60
    // 0x803831CC: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_9;
    // 0x803831CC: nop

    after_9:
    // 0x803831D0: jal         0x8035D734
    // 0x803831D4: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_10;
    // 0x803831D4: nop

    after_10:
    // 0x803831D8: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803831DC: lhu         $t9, 0x2ECE($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X2ECE);
    // 0x803831E0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803831E4: addiu       $a0, $zero, 0x1F4
    ctx->r4 = ADD32(0, 0X1F4);
    // 0x803831E8: beq         $t9, $zero, L_80383200
    if (ctx->r25 == 0) {
        // 0x803831EC: addiu       $a1, $zero, 0x1F4
        ctx->r5 = ADD32(0, 0X1F4);
            goto L_80383200;
    }
    // 0x803831EC: addiu       $a1, $zero, 0x1F4
    ctx->r5 = ADD32(0, 0X1F4);
    // 0x803831F0: lhu         $t7, 0x2ECC($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X2ECC);
    // 0x803831F4: slti        $at, $t7, 0x1F
    ctx->r1 = SIGNED(ctx->r15) < 0X1F ? 1 : 0;
    // 0x803831F8: beq         $at, $zero, L_8038329C
    if (ctx->r1 == 0) {
        // 0x803831FC: nop
    
            goto L_8038329C;
    }
    // 0x803831FC: nop

L_80383200:
    // 0x80383200: jal         0x80302E50
    // 0x80383204: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    func_80302E50_714500(rdram, ctx);
        goto after_11;
    // 0x80383204: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    after_11:
    // 0x80383208: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8038320C: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x80383210: addiu       $at, $zero, 0x3F
    ctx->r1 = ADD32(0, 0X3F);
    // 0x80383214: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80383218: lhu         $t8, 0x0($t5)
    ctx->r24 = MEM_HU(ctx->r13, 0X0);
    // 0x8038321C: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80383220: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80383224: bne         $t8, $at, L_8038329C
    if (ctx->r24 != ctx->r1) {
        // 0x80383228: addiu       $t7, $zero, 0x28
        ctx->r15 = ADD32(0, 0X28);
            goto L_8038329C;
    }
    // 0x80383228: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x8038322C: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80383230: lh          $v1, 0x308($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X308);
    // 0x80383234: slti        $t0, $v1, 0x29
    ctx->r8 = SIGNED(ctx->r3) < 0X29 ? 1 : 0;
    // 0x80383238: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x8038323C: bne         $t0, $zero, L_8038324C
    if (ctx->r8 != 0) {
        // 0x80383240: sh          $t6, 0x308($v0)
        MEM_H(0X308, ctx->r2) = ctx->r14;
            goto L_8038324C;
    }
    // 0x80383240: sh          $t6, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r14;
    // 0x80383244: b           L_8038325C
    // 0x80383248: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
        goto L_8038325C;
    // 0x80383248: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
L_8038324C:
    // 0x8038324C: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80383250: lh          $a2, 0x308($v0)
    ctx->r6 = MEM_H(ctx->r2, 0X308);
    // 0x80383254: addiu       $t4, $a2, 0x1
    ctx->r12 = ADD32(ctx->r6, 0X1);
    // 0x80383258: sh          $t4, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r12;
L_8038325C:
    // 0x8038325C: sll         $t9, $a2, 1
    ctx->r25 = S32(ctx->r6 << 1);
    // 0x80383260: subu        $t8, $t7, $t9
    ctx->r24 = SUB32(ctx->r15, ctx->r25);
    // 0x80383264: negu        $a1, $t8
    ctx->r5 = SUB32(0, ctx->r24);
    // 0x80383268: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8038326C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80383270: jal         0x8030322C
    // 0x80383274: sw          $a1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r5;
    func_8030322C_7148DC(rdram, ctx);
        goto after_12;
    // 0x80383274: sw          $a1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r5;
    after_12:
    // 0x80383278: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8038327C: jal         0x8030322C
    // 0x80383280: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    func_8030322C_7148DC(rdram, ctx);
        goto after_13;
    // 0x80383280: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    after_13:
    // 0x80383284: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80383288: jal         0x8030322C
    // 0x8038328C: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    func_8030322C_7148DC(rdram, ctx);
        goto after_14;
    // 0x8038328C: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    after_14:
    // 0x80383290: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80383294: jal         0x8030322C
    // 0x80383298: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    func_8030322C_7148DC(rdram, ctx);
        goto after_15;
    // 0x80383298: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    after_15:
L_8038329C:
    // 0x8038329C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803832A0: lhu         $t7, 0x2ECC($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X2ECC);
    // 0x803832A4: beq         $t7, $zero, L_80383324
    if (ctx->r15 == 0) {
        // 0x803832A8: nop
    
            goto L_80383324;
    }
    // 0x803832A8: nop

    // 0x803832AC: jal         0x802DB8DC
    // 0x803832B0: nop

    backup_joint_positions(rdram, ctx);
        goto after_16;
    // 0x803832B0: nop

    after_16:
    // 0x803832B4: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803832B8: lhu         $a2, 0x2ECE($a2)
    ctx->r6 = MEM_HU(ctx->r6, 0X2ECE);
    // 0x803832BC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803832C0: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803832C4: beq         $a2, $at, L_803832E0
    if (ctx->r6 == ctx->r1) {
        // 0x803832C8: addiu       $a0, $a0, 0x58A0
        ctx->r4 = ADD32(ctx->r4, 0X58A0);
            goto L_803832E0;
    }
    // 0x803832C8: addiu       $a0, $a0, 0x58A0
    ctx->r4 = ADD32(ctx->r4, 0X58A0);
    // 0x803832CC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803832D0: beq         $a2, $at, L_80383304
    if (ctx->r6 == ctx->r1) {
        // 0x803832D4: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_80383304;
    }
    // 0x803832D4: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803832D8: b           L_80383324
    // 0x803832DC: nop

        goto L_80383324;
    // 0x803832DC: nop

L_803832E0:
    // 0x803832E0: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x803832E4: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x803832E8: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x803832EC: addiu       $a3, $a3, 0x58B0
    ctx->r7 = ADD32(ctx->r7, 0X58B0);
    // 0x803832F0: addiu       $a2, $a2, 0x58A8
    ctx->r6 = ADD32(ctx->r6, 0X58A8);
    // 0x803832F4: jal         0x802DB670
    // 0x803832F8: addiu       $a1, $a1, 0x58A4
    ctx->r5 = ADD32(ctx->r5, 0X58A4);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_17;
    // 0x803832F8: addiu       $a1, $a1, 0x58A4
    ctx->r5 = ADD32(ctx->r5, 0X58A4);
    after_17:
    // 0x803832FC: b           L_80383324
    // 0x80383300: nop

        goto L_80383324;
    // 0x80383300: nop

L_80383304:
    // 0x80383304: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80383308: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x8038330C: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80383310: addiu       $a3, $a3, 0x58C4
    ctx->r7 = ADD32(ctx->r7, 0X58C4);
    // 0x80383314: addiu       $a2, $a2, 0x58A8
    ctx->r6 = ADD32(ctx->r6, 0X58A8);
    // 0x80383318: addiu       $a1, $a1, 0x58A4
    ctx->r5 = ADD32(ctx->r5, 0X58A4);
    // 0x8038331C: jal         0x802DB670
    // 0x80383320: addiu       $a0, $a0, 0x58A0
    ctx->r4 = ADD32(ctx->r4, 0X58A0);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_18;
    // 0x80383320: addiu       $a0, $a0, 0x58A0
    ctx->r4 = ADD32(ctx->r4, 0X58A0);
    after_18:
L_80383324:
    // 0x80383324: jal         0x8038064C
    // 0x80383328: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_19;
    // 0x80383328: nop

    after_19:
    // 0x8038332C: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80383330: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x80383334: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x80383338: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x8038333C: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x80383340: addu        $t9, $t0, $t3
    ctx->r25 = ADD32(ctx->r8, ctx->r11);
    // 0x80383344: lw          $t1, 0x918($t9)
    ctx->r9 = MEM_W(ctx->r25, 0X918);
    // 0x80383348: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038334C: addiu       $t5, $t1, 0x1E
    ctx->r13 = ADD32(ctx->r9, 0X1E);
    // 0x80383350: slti        $at, $t5, 0xFA
    ctx->r1 = SIGNED(ctx->r13) < 0XFA ? 1 : 0;
    // 0x80383354: beq         $at, $zero, L_80383740
    if (ctx->r1 == 0) {
        // 0x80383358: nop
    
            goto L_80383740;
    }
    // 0x80383358: nop

    // 0x8038335C: lbu         $t8, 0x2EDA($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X2EDA);
    // 0x80383360: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80383364: beq         $t8, $zero, L_80383740
    if (ctx->r24 == 0) {
        // 0x80383368: nop
    
            goto L_80383740;
    }
    // 0x80383368: nop

    // 0x8038336C: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
    // 0x80383370: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80383374: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80383378: bne         $a1, $zero, L_803833B0
    if (ctx->r5 != 0) {
        // 0x8038337C: nop
    
            goto L_803833B0;
    }
    // 0x8038337C: nop

    // 0x80383380: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x80383384: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80383388: beq         $v0, $zero, L_803833B0
    if (ctx->r2 == 0) {
        // 0x8038338C: nop
    
            goto L_803833B0;
    }
    // 0x8038338C: nop

    // 0x80383390: beq         $v0, $at, L_803833B0
    if (ctx->r2 == ctx->r1) {
        // 0x80383394: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803833B0;
    }
    // 0x80383394: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80383398: bne         $v0, $at, L_80383740
    if (ctx->r2 != ctx->r1) {
        // 0x8038339C: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_80383740;
    }
    // 0x8038339C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803833A0: lbu         $t6, 0x2AA3($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2AA3);
    // 0x803833A4: slti        $at, $t6, 0xB
    ctx->r1 = SIGNED(ctx->r14) < 0XB ? 1 : 0;
    // 0x803833A8: bne         $at, $zero, L_80383740
    if (ctx->r1 != 0) {
        // 0x803833AC: nop
    
            goto L_80383740;
    }
    // 0x803833AC: nop

L_803833B0:
    // 0x803833B0: lh          $t4, 0x2C18($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C18);
    // 0x803833B4: sll         $t6, $t1, 6
    ctx->r14 = S32(ctx->r9 << 6);
    // 0x803833B8: addu        $a0, $t0, $t6
    ctx->r4 = ADD32(ctx->r8, ctx->r14);
    // 0x803833BC: bne         $t4, $zero, L_80383414
    if (ctx->r12 != 0) {
        // 0x803833C0: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_80383414;
    }
    // 0x803833C0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803833C4: beq         $a1, $zero, L_80383414
    if (ctx->r5 == 0) {
        // 0x803833C8: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_80383414;
    }
    // 0x803833C8: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803833CC: lh          $t7, 0x2A98($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2A98);
    // 0x803833D0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803833D4: addiu       $t5, $t5, 0x28E0
    ctx->r13 = ADD32(ctx->r13, 0X28E0);
    // 0x803833D8: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x803833DC: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x803833E0: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x803833E4: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x803833E8: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x803833EC: addu        $v0, $t9, $t5
    ctx->r2 = ADD32(ctx->r25, ctx->r13);
    // 0x803833F0: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x803833F4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803833F8: beq         $v1, $at, L_80383408
    if (ctx->r3 == ctx->r1) {
        // 0x803833FC: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80383408;
    }
    // 0x803833FC: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80383400: bne         $v1, $at, L_80383414
    if (ctx->r3 != ctx->r1) {
        // 0x80383404: nop
    
            goto L_80383414;
    }
    // 0x80383404: nop

L_80383408:
    // 0x80383408: lb          $t8, 0x64($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X64);
    // 0x8038340C: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80383410: beq         $t8, $at, L_80383740
    if (ctx->r24 == ctx->r1) {
        // 0x80383414: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_80383740;
    }
L_80383414:
    // 0x80383414: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80383418: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x8038341C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80383420: lw          $t5, 0x2EB0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EB0);
    // 0x80383424: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80383428: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038342C: lh          $t7, 0x302($t4)
    ctx->r15 = MEM_H(ctx->r12, 0X302);
    // 0x80383430: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80383434: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80383438: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8038343C: lw          $t6, 0x2EB4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB4);
    // 0x80383440: negu        $t9, $t7
    ctx->r25 = SUB32(0, ctx->r15);
    // 0x80383444: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80383448: lw          $a1, 0x4($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X4);
    // 0x8038344C: lw          $a2, 0x8($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X8);
    // 0x80383450: lw          $a3, 0xC($v1)
    ctx->r7 = MEM_W(ctx->r3, 0XC);
    // 0x80383454: lw          $t7, 0x2EB8($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EB8);
    // 0x80383458: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038345C: bgez        $t5, L_8038346C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80383460: sra         $t8, $t5, 2
        ctx->r24 = S32(SIGNED(ctx->r13) >> 2);
            goto L_8038346C;
    }
    // 0x80383460: sra         $t8, $t5, 2
    ctx->r24 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80383464: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x80383468: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_8038346C:
    // 0x8038346C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80383470: bgez        $t6, L_80383480
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80383474: sra         $t4, $t6, 2
        ctx->r12 = S32(SIGNED(ctx->r14) >> 2);
            goto L_80383480;
    }
    // 0x80383474: sra         $t4, $t6, 2
    ctx->r12 = S32(SIGNED(ctx->r14) >> 2);
    // 0x80383478: addiu       $at, $t6, 0x3
    ctx->r1 = ADD32(ctx->r14, 0X3);
    // 0x8038347C: sra         $t4, $at, 2
    ctx->r12 = S32(SIGNED(ctx->r1) >> 2);
L_80383480:
    // 0x80383480: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80383484: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80383488: lh          $t5, 0x2ED2($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED2);
    // 0x8038348C: lw          $t8, 0x2ED4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2ED4);
    // 0x80383490: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x80383494: bgez        $t7, L_803834A4
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80383498: sra         $t9, $t7, 2
        ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
            goto L_803834A4;
    }
    // 0x80383498: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x8038349C: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x803834A0: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_803834A4:
    // 0x803834A4: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x803834A8: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x803834AC: jal         0x80127640
    // 0x803834B0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    func_80127640(rdram, ctx);
        goto after_20;
    // 0x803834B0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    after_20:
    // 0x803834B4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x803834B8: addiu       $a2, $a2, -0x6178
    ctx->r6 = ADD32(ctx->r6, -0X6178);
    // 0x803834BC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x803834C0: lui         $t4, 0x104
    ctx->r12 = S32(0X104 << 16);
    // 0x803834C4: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x803834C8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x803834CC: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x803834D0: ori         $t4, $t4, 0x40
    ctx->r12 = ctx->r12 | 0X40;
    // 0x803834D4: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x803834D8: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x803834DC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x803834E0: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803834E4: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x803834E8: addu        $t7, $t0, $t3
    ctx->r15 = ADD32(ctx->r8, ctx->r11);
    // 0x803834EC: lw          $t9, 0x918($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X918);
    // 0x803834F0: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803834F4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803834F8: sll         $t5, $t9, 6
    ctx->r13 = S32(ctx->r25 << 6);
    // 0x803834FC: addu        $t8, $t0, $t5
    ctx->r24 = ADD32(ctx->r8, ctx->r13);
    // 0x80383500: addu        $t6, $t8, $at
    ctx->r14 = ADD32(ctx->r24, ctx->r1);
    // 0x80383504: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80383508: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x8038350C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80383510: lui         $a0, 0x400
    ctx->r4 = S32(0X400 << 16);
    // 0x80383514: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x80383518: lw          $t7, 0x918($t4)
    ctx->r15 = MEM_W(ctx->r12, 0X918);
    // 0x8038351C: lui         $a1, 0x400
    ctx->r5 = S32(0X400 << 16);
    // 0x80383520: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x80383524: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x80383528: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
    // 0x8038352C: addiu       $a1, $a1, 0x7BD0
    ctx->r5 = ADD32(ctx->r5, 0X7BD0);
    // 0x80383530: jal         0x80356410
    // 0x80383534: addiu       $a0, $a0, 0x7DD0
    ctx->r4 = ADD32(ctx->r4, 0X7DD0);
    load_1_tile(rdram, ctx);
        goto after_21;
    // 0x80383534: addiu       $a0, $a0, 0x7DD0
    ctx->r4 = ADD32(ctx->r4, 0X7DD0);
    after_21:
    // 0x80383538: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x8038353C: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x80383540: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80383544: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80383548: addiu       $t8, $t8, 0x7500
    ctx->r24 = ADD32(ctx->r24, 0X7500);
    // 0x8038354C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80383550: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80383554: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80383558: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038355C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80383560: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80383564: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80383568: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038356C: jal         0x802C78B0
    // 0x80383570: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_22;
    // 0x80383570: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_22:
    // 0x80383574: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80383578: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038357C: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80383580: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80383584: addiu       $t4, $t4, 0x77E0
    ctx->r12 = ADD32(ctx->r12, 0X77E0);
    // 0x80383588: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x8038358C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80383590: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80383594: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80383598: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038359C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803835A0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803835A4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803835A8: jal         0x802C78B0
    // 0x803835AC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_23;
    // 0x803835AC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_23:
    // 0x803835B0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803835B4: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x803835B8: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803835BC: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803835C0: addiu       $t9, $t9, 0x7AE0
    ctx->r25 = ADD32(ctx->r25, 0X7AE0);
    // 0x803835C4: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803835C8: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803835CC: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803835D0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x803835D4: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x803835D8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803835DC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803835E0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803835E4: jal         0x802C78B0
    // 0x803835E8: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_24;
    // 0x803835E8: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_24:
    // 0x803835EC: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803835F0: lbu         $t5, 0x2EDD($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X2EDD);
    // 0x803835F4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803835F8: bne         $t5, $zero, L_80383720
    if (ctx->r13 != 0) {
        // 0x803835FC: nop
    
            goto L_80383720;
    }
    // 0x803835FC: nop

    // 0x80383600: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80383604: addiu       $a1, $sp, 0x86
    ctx->r5 = ADD32(ctx->r29, 0X86);
    // 0x80383608: addiu       $a2, $sp, 0x84
    ctx->r6 = ADD32(ctx->r29, 0X84);
    // 0x8038360C: lh          $a0, 0x326($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X326);
    // 0x80383610: addiu       $t8, $a0, 0x1
    ctx->r24 = ADD32(ctx->r4, 0X1);
    // 0x80383614: jal         0x8031A150
    // 0x80383618: sh          $t8, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r24;
    func_8031A150_72B800(rdram, ctx);
        goto after_25;
    // 0x80383618: sh          $t8, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r24;
    after_25:
    // 0x8038361C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383620: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80383624: addiu       $a1, $sp, 0x86
    ctx->r5 = ADD32(ctx->r29, 0X86);
    // 0x80383628: addiu       $a2, $sp, 0x84
    ctx->r6 = ADD32(ctx->r29, 0X84);
    // 0x8038362C: jal         0x8031A278
    // 0x80383630: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_26;
    // 0x80383630: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_26:
    // 0x80383634: lh          $a2, 0x86($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X86);
    // 0x80383638: lh          $t4, 0x84($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X84);
    // 0x8038363C: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x80383640: sll         $t6, $a2, 1
    ctx->r14 = S32(ctx->r6 << 1);
    // 0x80383644: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80383648: sll         $t7, $t4, 1
    ctx->r15 = S32(ctx->r12 << 1);
    // 0x8038364C: addu        $t9, $t9, $t7
    ctx->r25 = ADD32(ctx->r25, ctx->r15);
    // 0x80383650: addu        $a2, $a2, $t6
    ctx->r6 = ADD32(ctx->r6, ctx->r14);
    // 0x80383654: lh          $a2, -0x2AB6($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2AB6);
    // 0x80383658: lh          $t9, -0x29FE($t9)
    ctx->r25 = MEM_H(ctx->r25, -0X29FE);
    // 0x8038365C: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80383660: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80383664: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80383668: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x8038366C: sh          $a2, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r6;
    // 0x80383670: jal         0x80356BD8
    // 0x80383674: sh          $t9, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r25;
    func_80356BD8_768288(rdram, ctx);
        goto after_27;
    // 0x80383674: sh          $t9, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r25;
    after_27:
    // 0x80383678: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038367C: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80383680: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80383684: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80383688: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x8038368C: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80383690: sra         $a3, $t5, 6
    ctx->r7 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80383694: addiu       $t4, $t4, 0x7E70
    ctx->r12 = ADD32(ctx->r12, 0X7E70);
    // 0x80383698: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x8038369C: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x803836A0: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x803836A4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803836A8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803836AC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803836B0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803836B4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803836B8: jal         0x802C78B0
    // 0x803836BC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_28;
    // 0x803836BC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_28:
    // 0x803836C0: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x803836C4: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x803836C8: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x803836CC: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x803836D0: jal         0x80356BD8
    // 0x803836D4: lh          $a2, 0x84($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X84);
    func_80356BD8_768288(rdram, ctx);
        goto after_29;
    // 0x803836D4: lh          $a2, 0x84($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X84);
    after_29:
    // 0x803836D8: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803836DC: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x803836E0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803836E4: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x803836E8: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x803836EC: sll         $t7, $a2, 6
    ctx->r15 = S32(ctx->r6 << 6);
    // 0x803836F0: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x803836F4: addiu       $t8, $t8, 0x7E90
    ctx->r24 = ADD32(ctx->r24, 0X7E90);
    // 0x803836F8: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x803836FC: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80383700: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80383704: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80383708: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038370C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80383710: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80383714: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80383718: jal         0x802C78B0
    // 0x8038371C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_30;
    // 0x8038371C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_30:
L_80383720:
    // 0x80383720: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80383724: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x80383728: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8038372C: lui         $t4, 0xBD00
    ctx->r12 = S32(0XBD00 << 16);
    // 0x80383730: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80383734: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80383738: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8038373C: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
L_80383740:
    // 0x80383740: jal         0x8035D6A0
    // 0x80383744: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_31;
    // 0x80383744: nop

    after_31:
    // 0x80383748: b           L_8038375C
    // 0x8038374C: lh          $t7, 0x8A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X8A);
        goto L_8038375C;
    // 0x8038374C: lh          $t7, 0x8A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X8A);
L_80383750:
    // 0x80383750: jal         0x8035D6D0
    // 0x80383754: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_32;
    // 0x80383754: nop

    after_32:
    // 0x80383758: lh          $t7, 0x8A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X8A);
L_8038375C:
    // 0x8038375C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80383760: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80383764: beq         $t7, $zero, L_80383774
    if (ctx->r15 == 0) {
        // 0x80383768: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_80383774;
    }
    // 0x80383768: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8038376C: bne         $t7, $at, L_803837E0
    if (ctx->r15 != ctx->r1) {
        // 0x80383770: nop
    
            goto L_803837E0;
    }
    // 0x80383770: nop

L_80383774:
    // 0x80383774: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80383778: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x8038377C: lui         $t7, 0x103
    ctx->r15 = S32(0X103 << 16);
    // 0x80383780: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80383784: lhu         $t8, 0xBA($t5)
    ctx->r24 = MEM_HU(ctx->r13, 0XBA);
    // 0x80383788: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8038378C: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x80383790: lh          $a3, 0x302($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X302);
    // 0x80383794: addu        $a2, $t9, $t8
    ctx->r6 = ADD32(ctx->r25, ctx->r24);
    // 0x80383798: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x8038379C: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803837A0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803837A4: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x803837A8: addiu       $t8, $zero, 0x9B
    ctx->r24 = ADD32(0, 0X9B);
    // 0x803837AC: addiu       $t9, $zero, 0x9
    ctx->r25 = ADD32(0, 0X9);
    // 0x803837B0: addiu       $t5, $zero, 0x15
    ctx->r13 = ADD32(0, 0X15);
    // 0x803837B4: addiu       $t7, $t7, 0x3190
    ctx->r15 = ADD32(ctx->r15, 0X3190);
    // 0x803837B8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x803837BC: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x803837C0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x803837C4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x803837C8: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x803837CC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x803837D0: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x803837D4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803837D8: jal         0x8034BD20
    // 0x803837DC: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_33;
    // 0x803837DC: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    after_33:
L_803837E0:
    // 0x803837E0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803837E4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x803837E8: addiu       $a1, $zero, 0x1F4
    ctx->r5 = ADD32(0, 0X1F4);
    // 0x803837EC: jal         0x80303D00
    // 0x803837F0: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    func_80303D00_7153B0(rdram, ctx);
        goto after_34;
    // 0x803837F0: addiu       $a2, $zero, 0x1F4
    ctx->r6 = ADD32(0, 0X1F4);
    after_34:
    // 0x803837F4: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x803837F8: addiu       $sp, $sp, 0x98
    ctx->r29 = ADD32(ctx->r29, 0X98);
    // 0x803837FC: jr          $ra
    // 0x80383800: nop

    return;
    // 0x80383800: nop

;}
RECOMP_FUNC void func_80383804_794EB4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80383804: jr          $ra
    // 0x80383808: nop

    return;
    // 0x80383808: nop

;}
RECOMP_FUNC void func_8038380C_794EBC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038380C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80383810: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80383814: jr          $ra
    // 0x80383818: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    return;
    // 0x80383818: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
;}
RECOMP_FUNC void func_8038381C_794ECC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038381C: jr          $ra
    // 0x80383820: nop

    return;
    // 0x80383820: nop

;}
RECOMP_FUNC void target_within_current_fov(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80383830: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80383834: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80383838: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038383C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80383840: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80383844: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80383848: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8038384C: lw          $v0, 0x2CC($t6)
    ctx->r2 = MEM_W(ctx->r14, 0X2CC);
    // 0x80383850: lh          $t8, 0x4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4);
    // 0x80383854: lh          $t2, 0x8($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X8);
    // 0x80383858: lh          $t7, 0x4($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X4);
    // 0x8038385C: lh          $t1, 0x8($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X8);
    // 0x80383860: subu        $a0, $t7, $t8
    ctx->r4 = SUB32(ctx->r15, ctx->r24);
    // 0x80383864: subu        $a1, $t1, $t2
    ctx->r5 = SUB32(ctx->r9, ctx->r10);
    // 0x80383868: sll         $t3, $a1, 16
    ctx->r11 = S32(ctx->r5 << 16);
    // 0x8038386C: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80383870: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80383874: jal         0x801284B8
    // 0x80383878: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    func_801284B8(rdram, ctx);
        goto after_0;
    // 0x80383878: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    after_0:
    // 0x8038387C: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x80383880: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80383884: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80383888: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8038388C: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x80383890: mflo        $t5
    ctx->r13 = lo;
    // 0x80383894: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80383898: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038389C: jal         0x803051F0
    // 0x803838A0: lh          $a1, 0x2C($t8)
    ctx->r5 = MEM_H(ctx->r24, 0X2C);
    func_803051F0_7168A0(rdram, ctx);
        goto after_1;
    // 0x803838A0: lh          $a1, 0x2C($t8)
    ctx->r5 = MEM_H(ctx->r24, 0X2C);
    after_1:
    // 0x803838A4: lhu         $t9, 0x1A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X1A);
    // 0x803838A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803838AC: slt         $at, $t9, $v0
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x803838B0: beq         $at, $zero, L_803838C0
    if (ctx->r1 == 0) {
        // 0x803838B4: addiu       $v0, $zero, 0x1
        ctx->r2 = ADD32(0, 0X1);
            goto L_803838C0;
    }
    // 0x803838B4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x803838B8: b           L_803838C0
    // 0x803838BC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803838C0;
    // 0x803838BC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803838C0:
    // 0x803838C0: jr          $ra
    // 0x803838C4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x803838C4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void target_within_custom_fov(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803838C8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803838CC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803838D0: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x803838D4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803838D8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x803838DC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x803838E0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803838E4: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x803838E8: lw          $v0, 0x2CC($t6)
    ctx->r2 = MEM_W(ctx->r14, 0X2CC);
    // 0x803838EC: lh          $t8, 0x4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4);
    // 0x803838F0: lh          $t2, 0x8($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X8);
    // 0x803838F4: lh          $t7, 0x4($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X4);
    // 0x803838F8: lh          $t1, 0x8($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X8);
    // 0x803838FC: subu        $a0, $t7, $t8
    ctx->r4 = SUB32(ctx->r15, ctx->r24);
    // 0x80383900: subu        $a1, $t1, $t2
    ctx->r5 = SUB32(ctx->r9, ctx->r10);
    // 0x80383904: sll         $t3, $a1, 16
    ctx->r11 = S32(ctx->r5 << 16);
    // 0x80383908: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x8038390C: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80383910: jal         0x801284B8
    // 0x80383914: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    func_801284B8(rdram, ctx);
        goto after_0;
    // 0x80383914: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    after_0:
    // 0x80383918: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x8038391C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80383920: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80383924: mflo        $t5
    ctx->r13 = lo;
    // 0x80383928: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8038392C: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80383930: jal         0x803051F0
    // 0x80383934: lh          $a1, 0x1A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1A);
    func_803051F0_7168A0(rdram, ctx);
        goto after_1;
    // 0x80383934: lh          $a1, 0x1A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1A);
    after_1:
    // 0x80383938: lhu         $t8, 0x1E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X1E);
    // 0x8038393C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80383940: slt         $at, $t8, $v0
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80383944: beq         $at, $zero, L_80383954
    if (ctx->r1 == 0) {
        // 0x80383948: addiu       $v0, $zero, 0x1
        ctx->r2 = ADD32(0, 0X1);
            goto L_80383954;
    }
    // 0x80383948: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8038394C: b           L_80383954
    // 0x80383950: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80383954;
    // 0x80383950: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80383954:
    // 0x80383954: jr          $ra
    // 0x80383958: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x80383958: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void func_8038395C_79500C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038395C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80383960: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80383964: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80383968: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038396C: lw          $t6, 0x1C($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X1C);
    // 0x80383970: lw          $t7, 0x20($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X20);
    // 0x80383974: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x80383978: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8038397C: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x80383980: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80383984: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80383988: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8038398C: div.s       $f0, $f6, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f14.fl);
    // 0x80383990: div.s       $f2, $f10, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f2.fl = DIV_S(ctx->f10.fl, ctx->f14.fl);
    // 0x80383994: mul.s       $f16, $f0, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x80383998: nop

    // 0x8038399C: mul.s       $f18, $f2, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x803839A0: jal         0x80137E10
    // 0x803839A4: add.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f16.fl + ctx->f18.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x803839A4: add.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f16.fl + ctx->f18.fl;
    after_0:
    // 0x803839A8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803839AC: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x803839B0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x803839B4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x803839B8: lhu         $t9, 0xA4($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0XA4);
    // 0x803839BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803839C0: mul.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x803839C4: sra         $t0, $t9, 6
    ctx->r8 = S32(SIGNED(ctx->r25) >> 6);
    // 0x803839C8: mtc1        $t0, $f8
    ctx->f8.u32l = ctx->r8;
    // 0x803839CC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803839D0: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x803839D4: div.s       $f2, $f6, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f10.fl);
    // 0x803839D8: trunc.w.s   $f16, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    ctx->f16.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x803839DC: mfc1        $v0, $f16
    ctx->r2 = (int32_t)ctx->f16.u32l;
    // 0x803839E0: nop

    // 0x803839E4: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x803839E8: jr          $ra
    // 0x803839EC: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    return;
    // 0x803839EC: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
;}
RECOMP_FUNC void perform_behavior_lion(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803839F0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x803839F4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x803839F8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803839FC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80383A00: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80383A04: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80383A08: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80383A0C: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80383A10: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383A14: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80383A18: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80383A1C: beq         $t6, $zero, L_80383A3C
    if (ctx->r14 == 0) {
        // 0x80383A20: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80383A3C;
    }
    // 0x80383A20: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383A24: beq         $t6, $at, L_80383A60
    if (ctx->r14 == ctx->r1) {
        // 0x80383A28: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80383A60;
    }
    // 0x80383A28: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80383A2C: beql        $t6, $at, L_80383B78
    if (ctx->r14 == ctx->r1) {
        // 0x80383A30: lh          $t5, 0x2D0($v0)
        ctx->r13 = MEM_H(ctx->r2, 0X2D0);
            goto L_80383B78;
    }
    goto skip_0;
    // 0x80383A30: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80383A34: b           L_80383BD4
    // 0x80383A38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80383BD4;
    // 0x80383A38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80383A3C:
    // 0x80383A3C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383A40: jal         0x80363CE0
    // 0x80383A44: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80383A44: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80383A48: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80383A4C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80383A50: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80383A54: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80383A58: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80383A5C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_80383A60:
    // 0x80383A60: lh          $v1, 0x2D0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2D0);
    // 0x80383A64: slti        $at, $v1, 0x64
    ctx->r1 = SIGNED(ctx->r3) < 0X64 ? 1 : 0;
    // 0x80383A68: beql        $at, $zero, L_80383AA4
    if (ctx->r1 == 0) {
        // 0x80383A6C: slti        $at, $v1, 0x6F
        ctx->r1 = SIGNED(ctx->r3) < 0X6F ? 1 : 0;
            goto L_80383AA4;
    }
    goto skip_1;
    // 0x80383A6C: slti        $at, $v1, 0x6F
    ctx->r1 = SIGNED(ctx->r3) < 0X6F ? 1 : 0;
    skip_1:
    // 0x80383A70: lw          $t0, 0x2C0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C0);
    // 0x80383A74: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80383A78: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383A7C: bnel        $t0, $zero, L_80383AA4
    if (ctx->r8 != 0) {
        // 0x80383A80: slti        $at, $v1, 0x6F
        ctx->r1 = SIGNED(ctx->r3) < 0X6F ? 1 : 0;
            goto L_80383AA4;
    }
    goto skip_2;
    // 0x80383A80: slti        $at, $v1, 0x6F
    ctx->r1 = SIGNED(ctx->r3) < 0X6F ? 1 : 0;
    skip_2:
    // 0x80383A84: sw          $t1, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r9;
    // 0x80383A88: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80383A8C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383A90: jal         0x80363E88
    // 0x80383A94: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80383A94: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_1:
    // 0x80383A98: b           L_80383AD8
    // 0x80383A9C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
        goto L_80383AD8;
    // 0x80383A9C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80383AA0: slti        $at, $v1, 0x6F
    ctx->r1 = SIGNED(ctx->r3) < 0X6F ? 1 : 0;
L_80383AA4:
    // 0x80383AA4: bnel        $at, $zero, L_80383ADC
    if (ctx->r1 != 0) {
        // 0x80383AA8: lw          $t5, 0x2C4($v0)
        ctx->r13 = MEM_W(ctx->r2, 0X2C4);
            goto L_80383ADC;
    }
    goto skip_3;
    // 0x80383AA8: lw          $t5, 0x2C4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X2C4);
    skip_3:
    // 0x80383AAC: lw          $t3, 0x2C0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X2C0);
    // 0x80383AB0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383AB4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80383AB8: beq         $t3, $zero, L_80383AD8
    if (ctx->r11 == 0) {
        // 0x80383ABC: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80383AD8;
    }
    // 0x80383ABC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383AC0: sw          $zero, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = 0;
    // 0x80383AC4: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80383AC8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383ACC: jal         0x80363CE0
    // 0x80383AD0: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80383AD0: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    after_2:
    // 0x80383AD4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_80383AD8:
    // 0x80383AD8: lw          $t5, 0x2C4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X2C4);
L_80383ADC:
    // 0x80383ADC: bgtzl       $t5, L_80383B34
    if (SIGNED(ctx->r13) > 0) {
        // 0x80383AE0: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_80383B34;
    }
    goto skip_4;
    // 0x80383AE0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_4:
    // 0x80383AE4: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    // 0x80383AE8: slti        $at, $t6, 0x65
    ctx->r1 = SIGNED(ctx->r14) < 0X65 ? 1 : 0;
    // 0x80383AEC: beql        $at, $zero, L_80383B34
    if (ctx->r1 == 0) {
        // 0x80383AF0: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_80383B34;
    }
    goto skip_5;
    // 0x80383AF0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_5:
    // 0x80383AF4: jal         0x80383830
    // 0x80383AF8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80383AF8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x80383AFC: beql        $v0, $zero, L_80383B34
    if (ctx->r2 == 0) {
        // 0x80383B00: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_80383B34;
    }
    goto skip_6;
    // 0x80383B00: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_6:
    // 0x80383B04: jal         0x802F2AA0
    // 0x80383B08: nop

    lion_roar(rdram, ctx);
        goto after_4;
    // 0x80383B08: nop

    after_4:
    // 0x80383B0C: jal         0x8012826C
    // 0x80383B10: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x80383B10: nop

    after_5:
    // 0x80383B14: addiu       $at, $zero, 0x28
    ctx->r1 = ADD32(0, 0X28);
    // 0x80383B18: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80383B1C: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x80383B20: mfhi        $t7
    ctx->r15 = hi;
    // 0x80383B24: addiu       $t8, $t7, 0x32
    ctx->r24 = ADD32(ctx->r15, 0X32);
    // 0x80383B28: b           L_80383BD0
    // 0x80383B2C: sw          $t8, 0x2C4($t9)
    MEM_W(0X2C4, ctx->r25) = ctx->r24;
        goto L_80383BD0;
    // 0x80383B2C: sw          $t8, 0x2C4($t9)
    MEM_W(0X2C4, ctx->r25) = ctx->r24;
    // 0x80383B30: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_80383B34:
    // 0x80383B34: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383B38: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80383B3C: lw          $t0, 0x2C4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C4);
    // 0x80383B40: bgtzl       $t0, L_80383BD4
    if (SIGNED(ctx->r8) > 0) {
        // 0x80383B44: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80383BD4;
    }
    goto skip_7;
    // 0x80383B44: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80383B48: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383B4C: jal         0x80363EDC
    // 0x80383B50: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80383B50: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_6:
    // 0x80383B54: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80383B58: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80383B5C: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80383B60: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80383B64: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
    // 0x80383B68: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80383B6C: b           L_80383BD0
    // 0x80383B70: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
        goto L_80383BD0;
    // 0x80383B70: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
    // 0x80383B74: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
L_80383B78:
    // 0x80383B78: slti        $at, $t5, 0xC8
    ctx->r1 = SIGNED(ctx->r13) < 0XC8 ? 1 : 0;
    // 0x80383B7C: beql        $at, $zero, L_80383BA0
    if (ctx->r1 == 0) {
        // 0x80383B80: lbu         $t7, 0x2B4($v0)
        ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80383BA0;
    }
    goto skip_8;
    // 0x80383B80: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    skip_8:
    // 0x80383B84: lw          $a0, 0x2B8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2B8);
    // 0x80383B88: slti        $v1, $a0, 0x3D
    ctx->r3 = SIGNED(ctx->r4) < 0X3D ? 1 : 0;
    // 0x80383B8C: addiu       $t6, $a0, 0x1
    ctx->r14 = ADD32(ctx->r4, 0X1);
    // 0x80383B90: bne         $v1, $zero, L_80383BD0
    if (ctx->r3 != 0) {
        // 0x80383B94: sw          $t6, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r14;
            goto L_80383BD0;
    }
    // 0x80383B94: sw          $t6, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r14;
    // 0x80383B98: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80383B9C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
L_80383BA0:
    // 0x80383BA0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383BA4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80383BA8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80383BAC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80383BB0: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80383BB4: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x80383BB8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383BBC: sw          $zero, 0x2C0($t0)
    MEM_W(0X2C0, ctx->r8) = 0;
    // 0x80383BC0: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80383BC4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383BC8: jal         0x80363CE0
    // 0x80383BCC: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x80383BCC: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_7:
L_80383BD0:
    // 0x80383BD0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80383BD4:
    // 0x80383BD4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80383BD8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80383BDC: jr          $ra
    // 0x80383BE0: nop

    return;
    // 0x80383BE0: nop

;}
RECOMP_FUNC void perform_behavior_hippo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80383BE4: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80383BE8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80383BEC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383BF0: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80383BF4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383BF8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80383BFC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80383C00: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80383C04: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383C08: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80383C0C: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80383C10: beq         $t6, $zero, L_80383C30
    if (ctx->r14 == 0) {
        // 0x80383C14: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80383C30;
    }
    // 0x80383C14: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383C18: beq         $t6, $at, L_80383C5C
    if (ctx->r14 == ctx->r1) {
        // 0x80383C1C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80383C5C;
    }
    // 0x80383C1C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80383C20: beq         $t6, $at, L_80383D88
    if (ctx->r14 == ctx->r1) {
        // 0x80383C24: nop
    
            goto L_80383D88;
    }
    // 0x80383C24: nop

    // 0x80383C28: b           L_80383E28
    // 0x80383C2C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80383E28;
    // 0x80383C2C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80383C30:
    // 0x80383C30: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383C34: jal         0x80363CE0
    // 0x80383C38: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80383C38: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x80383C3C: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x80383C40: sw          $zero, 0x2C0($t7)
    MEM_W(0X2C0, ctx->r15) = 0;
    // 0x80383C44: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383C48: lbu         $t8, 0x2B4($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80383C4C: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80383C50: ori         $t0, $t9, 0x10
    ctx->r8 = ctx->r25 | 0X10;
    // 0x80383C54: sb          $t0, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r8;
    // 0x80383C58: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80383C5C:
    // 0x80383C5C: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80383C60: slti        $at, $v0, 0x64
    ctx->r1 = SIGNED(ctx->r2) < 0X64 ? 1 : 0;
    // 0x80383C64: beql        $at, $zero, L_80383C9C
    if (ctx->r1 == 0) {
        // 0x80383C68: slti        $at, $v0, 0x79
        ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
            goto L_80383C9C;
    }
    goto skip_0;
    // 0x80383C68: slti        $at, $v0, 0x79
    ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
    skip_0:
    // 0x80383C6C: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    // 0x80383C70: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383C74: bnel        $t1, $zero, L_80383C9C
    if (ctx->r9 != 0) {
        // 0x80383C78: slti        $at, $v0, 0x79
        ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
            goto L_80383C9C;
    }
    goto skip_1;
    // 0x80383C78: slti        $at, $v0, 0x79
    ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
    skip_1:
    // 0x80383C7C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383C80: jal         0x80363E88
    // 0x80383C84: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80383C84: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_1:
    // 0x80383C88: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x80383C8C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80383C90: b           L_80383CD0
    // 0x80383C94: sw          $t2, 0x2C0($t3)
    MEM_W(0X2C0, ctx->r11) = ctx->r10;
        goto L_80383CD0;
    // 0x80383C94: sw          $t2, 0x2C0($t3)
    MEM_W(0X2C0, ctx->r11) = ctx->r10;
    // 0x80383C98: slti        $at, $v0, 0x79
    ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
L_80383C9C:
    // 0x80383C9C: bne         $at, $zero, L_80383CD0
    if (ctx->r1 != 0) {
        // 0x80383CA0: nop
    
            goto L_80383CD0;
    }
    // 0x80383CA0: nop

    // 0x80383CA4: lw          $t4, 0x2C0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2C0);
    // 0x80383CA8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80383CAC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383CB0: bne         $t4, $at, L_80383CD0
    if (ctx->r12 != ctx->r1) {
        // 0x80383CB4: addiu       $a2, $zero, -0x1
        ctx->r6 = ADD32(0, -0X1);
            goto L_80383CD0;
    }
    // 0x80383CB4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80383CB8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383CBC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    // 0x80383CC0: jal         0x80363CE0
    // 0x80383CC4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80383CC4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_2:
    // 0x80383CC8: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x80383CCC: sw          $zero, 0x2C0($t5)
    MEM_W(0X2C0, ctx->r13) = 0;
L_80383CD0:
    // 0x80383CD0: jal         0x80383830
    // 0x80383CD4: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80383CD4: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x80383CD8: beql        $v0, $zero, L_80383E28
    if (ctx->r2 == 0) {
        // 0x80383CDC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80383E28;
    }
    goto skip_2;
    // 0x80383CDC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x80383CE0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383CE4: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
    // 0x80383CE8: slti        $at, $t6, 0x15E
    ctx->r1 = SIGNED(ctx->r14) < 0X15E ? 1 : 0;
    // 0x80383CEC: beql        $at, $zero, L_80383E28
    if (ctx->r1 == 0) {
        // 0x80383CF0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80383E28;
    }
    goto skip_3;
    // 0x80383CF0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80383CF4: lw          $t7, 0x2C4($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2C4);
    // 0x80383CF8: bgtzl       $t7, L_80383E28
    if (SIGNED(ctx->r15) > 0) {
        // 0x80383CFC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80383E28;
    }
    goto skip_4;
    // 0x80383CFC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80383D00: lw          $t8, 0x2B8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X2B8);
    // 0x80383D04: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80383D08: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80383D0C: slti        $at, $t8, 0x2
    ctx->r1 = SIGNED(ctx->r24) < 0X2 ? 1 : 0;
    // 0x80383D10: bne         $at, $zero, L_80383D4C
    if (ctx->r1 != 0) {
        // 0x80383D14: nop
    
            goto L_80383D4C;
    }
    // 0x80383D14: nop

    // 0x80383D18: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383D1C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383D20: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80383D24: jal         0x80363EDC
    // 0x80383D28: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x80383D28: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_4:
    // 0x80383D2C: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x80383D30: sw          $zero, 0x2B8($t9)
    MEM_W(0X2B8, ctx->r25) = 0;
    // 0x80383D34: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383D38: lbu         $t0, 0x2B4($v1)
    ctx->r8 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80383D3C: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80383D40: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x80383D44: b           L_80383E24
    // 0x80383D48: sb          $t2, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r10;
        goto L_80383E24;
    // 0x80383D48: sb          $t2, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r10;
L_80383D4C:
    // 0x80383D4C: jal         0x802F0780
    // 0x80383D50: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    hippo_spit(rdram, ctx);
        goto after_5;
    // 0x80383D50: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_5:
    // 0x80383D54: jal         0x80140D20
    // 0x80383D58: nop

    guRandom(rdram, ctx);
        goto after_6;
    // 0x80383D58: nop

    after_6:
    // 0x80383D5C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80383D60: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80383D64: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x80383D68: mfhi        $t3
    ctx->r11 = hi;
    // 0x80383D6C: addiu       $t4, $t3, 0x1E
    ctx->r12 = ADD32(ctx->r11, 0X1E);
    // 0x80383D70: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x80383D74: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383D78: lw          $t6, 0x2B8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2B8);
    // 0x80383D7C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80383D80: b           L_80383E24
    // 0x80383D84: sw          $t7, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r15;
        goto L_80383E24;
    // 0x80383D84: sw          $t7, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r15;
L_80383D88:
    // 0x80383D88: jal         0x80383830
    // 0x80383D8C: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    target_within_current_fov(rdram, ctx);
        goto after_7;
    // 0x80383D8C: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    after_7:
    // 0x80383D90: bnel        $v0, $zero, L_80383DC0
    if (ctx->r2 != 0) {
        // 0x80383D94: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_80383DC0;
    }
    goto skip_5;
    // 0x80383D94: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_5:
    // 0x80383D98: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80383D9C: lw          $t9, 0x2C4($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X2C4);
    // 0x80383DA0: bgtzl       $t9, L_80383DC0
    if (SIGNED(ctx->r25) > 0) {
        // 0x80383DA4: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_80383DC0;
    }
    goto skip_6;
    // 0x80383DA4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_6:
    // 0x80383DA8: jal         0x802F05A4
    // 0x80383DAC: nop

    drop_sticky_mine(rdram, ctx);
        goto after_8;
    // 0x80383DAC: nop

    after_8:
    // 0x80383DB0: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80383DB4: addiu       $t0, $zero, 0x3C
    ctx->r8 = ADD32(0, 0X3C);
    // 0x80383DB8: sw          $t0, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r8;
    // 0x80383DBC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80383DC0:
    // 0x80383DC0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80383DC4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383DC8: lh          $t2, 0x2D0($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X2D0);
    // 0x80383DCC: slti        $at, $t2, 0x191
    ctx->r1 = SIGNED(ctx->r10) < 0X191 ? 1 : 0;
    // 0x80383DD0: beq         $at, $zero, L_80383DF0
    if (ctx->r1 == 0) {
        // 0x80383DD4: nop
    
            goto L_80383DF0;
    }
    // 0x80383DD4: nop

    // 0x80383DD8: lw          $a0, 0x2B8($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2B8);
    // 0x80383DDC: slti        $v0, $a0, 0x3C
    ctx->r2 = SIGNED(ctx->r4) < 0X3C ? 1 : 0;
    // 0x80383DE0: addiu       $t3, $a0, 0x1
    ctx->r11 = ADD32(ctx->r4, 0X1);
    // 0x80383DE4: bne         $v0, $zero, L_80383E24
    if (ctx->r2 != 0) {
        // 0x80383DE8: sw          $t3, 0x2B8($v1)
        MEM_W(0X2B8, ctx->r3) = ctx->r11;
            goto L_80383E24;
    }
    // 0x80383DE8: sw          $t3, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r11;
    // 0x80383DEC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80383DF0:
    // 0x80383DF0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383DF4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383DF8: jal         0x80363CE0
    // 0x80383DFC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_9;
    // 0x80383DFC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_9:
    // 0x80383E00: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80383E04: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
    // 0x80383E08: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80383E0C: lbu         $t5, 0x2B4($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80383E10: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80383E14: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x80383E18: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
    // 0x80383E1C: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80383E20: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
L_80383E24:
    // 0x80383E24: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80383E28:
    // 0x80383E28: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80383E2C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80383E30: jr          $ra
    // 0x80383E34: nop

    return;
    // 0x80383E34: nop

;}
RECOMP_FUNC void perform_behavior_racing_hippo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80383E38: jr          $ra
    // 0x80383E3C: nop

    return;
    // 0x80383E3C: nop

;}
RECOMP_FUNC void perform_behavior_racing_dog(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80383E40: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80383E44: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80383E48: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383E4C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80383E50: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80383E54: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80383E58: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80383E5C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383E60: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80383E64: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80383E68: beq         $t6, $zero, L_80383E90
    if (ctx->r14 == 0) {
        // 0x80383E6C: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80383E90;
    }
    // 0x80383E6C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80383E70: beq         $t6, $at, L_80383EBC
    if (ctx->r14 == ctx->r1) {
        // 0x80383E74: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80383EBC;
    }
    // 0x80383E74: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80383E78: beq         $t6, $at, L_80383EF8
    if (ctx->r14 == ctx->r1) {
        // 0x80383E7C: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80383EF8;
    }
    // 0x80383E7C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80383E80: beql        $t6, $at, L_80383FFC
    if (ctx->r14 == ctx->r1) {
        // 0x80383E84: lh          $t8, 0x2D0($s0)
        ctx->r24 = MEM_H(ctx->r16, 0X2D0);
            goto L_80383FFC;
    }
    goto skip_0;
    // 0x80383E84: lh          $t8, 0x2D0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80383E88: b           L_80384050
    // 0x80383E8C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80384050;
    // 0x80383E8C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80383E90:
    // 0x80383E90: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383E94: jal         0x80363CE0
    // 0x80383E98: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80383E98: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80383E9C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383EA0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80383EA4: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80383EA8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80383EAC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80383EB0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80383EB4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383EB8: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80383EBC:
    // 0x80383EBC: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80383EC0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383EC4: slti        $at, $t0, 0x191
    ctx->r1 = SIGNED(ctx->r8) < 0X191 ? 1 : 0;
    // 0x80383EC8: beql        $at, $zero, L_80384050
    if (ctx->r1 == 0) {
        // 0x80383ECC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384050;
    }
    goto skip_1;
    // 0x80383ECC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80383ED0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383ED4: jal         0x80363E88
    // 0x80383ED8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80383ED8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80383EDC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383EE0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80383EE4: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80383EE8: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80383EEC: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80383EF0: b           L_8038404C
    // 0x80383EF4: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_8038404C;
    // 0x80383EF4: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
L_80383EF8:
    // 0x80383EF8: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80383EFC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383F00: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80383F04: blez        $v1, L_80383F18
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80383F08: addiu       $t4, $v1, -0x1
        ctx->r12 = ADD32(ctx->r3, -0X1);
            goto L_80383F18;
    }
    // 0x80383F08: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x80383F0C: sw          $t4, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r12;
    // 0x80383F10: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383F14: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80383F18:
    // 0x80383F18: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80383F1C: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80383F20: slti        $at, $v0, 0x1B9
    ctx->r1 = SIGNED(ctx->r2) < 0X1B9 ? 1 : 0;
    // 0x80383F24: bnel        $at, $zero, L_80383F58
    if (ctx->r1 != 0) {
        // 0x80383F28: slti        $at, $v0, 0x12C
        ctx->r1 = SIGNED(ctx->r2) < 0X12C ? 1 : 0;
            goto L_80383F58;
    }
    goto skip_2;
    // 0x80383F28: slti        $at, $v0, 0x12C
    ctx->r1 = SIGNED(ctx->r2) < 0X12C ? 1 : 0;
    skip_2:
    // 0x80383F2C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383F30: jal         0x80363CE0
    // 0x80383F34: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80383F34: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80383F38: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383F3C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80383F40: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80383F44: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80383F48: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x80383F4C: b           L_8038404C
    // 0x80383F50: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
        goto L_8038404C;
    // 0x80383F50: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x80383F54: slti        $at, $v0, 0x12C
    ctx->r1 = SIGNED(ctx->r2) < 0X12C ? 1 : 0;
L_80383F58:
    // 0x80383F58: beql        $at, $zero, L_80383FA0
    if (ctx->r1 == 0) {
        // 0x80383F5C: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80383FA0;
    }
    goto skip_3;
    // 0x80383F5C: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80383F60: lw          $t8, 0x2C0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C0);
    // 0x80383F64: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80383F68: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80383F6C: bgtzl       $t8, L_80383FA0
    if (SIGNED(ctx->r24) > 0) {
        // 0x80383F70: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80383FA0;
    }
    goto skip_4;
    // 0x80383F70: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80383F74: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80383F78: jal         0x80363EDC
    // 0x80383F7C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80383F7C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80383F80: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80383F84: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80383F88: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80383F8C: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80383F90: ori         $t1, $t0, 0x30
    ctx->r9 = ctx->r8 | 0X30;
    // 0x80383F94: b           L_8038404C
    // 0x80383F98: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
        goto L_8038404C;
    // 0x80383F98: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
    // 0x80383F9C: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
L_80383FA0:
    // 0x80383FA0: bgtzl       $t2, L_80384050
    if (SIGNED(ctx->r10) > 0) {
        // 0x80383FA4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384050;
    }
    goto skip_5;
    // 0x80383FA4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80383FA8: jal         0x80383830
    // 0x80383FAC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80383FAC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80383FB0: beql        $v0, $zero, L_80384050
    if (ctx->r2 == 0) {
        // 0x80383FB4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384050;
    }
    goto skip_6;
    // 0x80383FB4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80383FB8: jal         0x80140D20
    // 0x80383FBC: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x80383FBC: nop

    after_5:
    // 0x80383FC0: sra         $t3, $v0, 8
    ctx->r11 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80383FC4: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80383FC8: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80383FCC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80383FD0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80383FD4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80383FD8: mfhi        $t4
    ctx->r12 = hi;
    // 0x80383FDC: addiu       $t5, $t4, 0x14
    ctx->r13 = ADD32(ctx->r12, 0X14);
    // 0x80383FE0: sw          $t5, 0x2C4($t6)
    MEM_W(0X2C4, ctx->r14) = ctx->r13;
    // 0x80383FE4: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80383FE8: jal         0x802EEDE0
    // 0x80383FEC: lw          $a0, 0x2CC($t7)
    ctx->r4 = MEM_W(ctx->r15, 0X2CC);
    racing_dog_fire_missile(rdram, ctx);
        goto after_6;
    // 0x80383FEC: lw          $a0, 0x2CC($t7)
    ctx->r4 = MEM_W(ctx->r15, 0X2CC);
    after_6:
    // 0x80383FF0: b           L_80384050
    // 0x80383FF4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80384050;
    // 0x80383FF4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80383FF8: lh          $t8, 0x2D0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X2D0);
L_80383FFC:
    // 0x80383FFC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384000: slti        $at, $t8, 0x15F
    ctx->r1 = SIGNED(ctx->r24) < 0X15F ? 1 : 0;
    // 0x80384004: beq         $at, $zero, L_80384028
    if (ctx->r1 == 0) {
        // 0x80384008: nop
    
            goto L_80384028;
    }
    // 0x80384008: nop

    // 0x8038400C: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80384010: slti        $v0, $v1, 0x3D
    ctx->r2 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
    // 0x80384014: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x80384018: bne         $v0, $zero, L_8038404C
    if (ctx->r2 != 0) {
        // 0x8038401C: sw          $t9, 0x2C0($s0)
        MEM_W(0X2C0, ctx->r16) = ctx->r25;
            goto L_8038404C;
    }
    // 0x8038401C: sw          $t9, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r25;
    // 0x80384020: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384024: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80384028:
    // 0x80384028: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038402C: jal         0x80363E88
    // 0x80384030: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80384030: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80384034: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384038: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x8038403C: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384040: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80384044: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x80384048: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
L_8038404C:
    // 0x8038404C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80384050:
    // 0x80384050: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80384054: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80384058: jr          $ra
    // 0x8038405C: nop

    return;
    // 0x8038405C: nop

;}
RECOMP_FUNC void perform_behavior_flying_dog(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384060: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384064: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384068: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038406C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80384070: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80384074: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    // 0x80384078: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x8038407C: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x80384080: lw          $t6, 0x16C($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X16C);
    // 0x80384084: lhu         $v1, 0x9E($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9E);
    // 0x80384088: beq         $v1, $at, L_803840A0
    if (ctx->r3 == ctx->r1) {
        // 0x8038408C: addiu       $at, $zero, 0x80
        ctx->r1 = ADD32(0, 0X80);
            goto L_803840A0;
    }
    // 0x8038408C: addiu       $at, $zero, 0x80
    ctx->r1 = ADD32(0, 0X80);
    // 0x80384090: beq         $v1, $at, L_803840A0
    if (ctx->r3 == ctx->r1) {
        // 0x80384094: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_803840A0;
    }
    // 0x80384094: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x80384098: bnel        $v1, $at, L_80384240
    if (ctx->r3 != ctx->r1) {
        // 0x8038409C: lw          $v1, 0x2B4($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X2B4);
            goto L_80384240;
    }
    goto skip_0;
    // 0x8038409C: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    skip_0:
L_803840A0:
    // 0x803840A0: lw          $a1, 0x2B4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2B4);
    // 0x803840A4: addiu       $a0, $a0, -0xC10
    ctx->r4 = ADD32(ctx->r4, -0XC10);
    // 0x803840A8: lw          $a2, 0x2C4($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2C4);
    // 0x803840AC: srl         $t7, $a1, 28
    ctx->r15 = S32(U32(ctx->r5) >> 28);
    // 0x803840B0: jal         0x8013966C
    // 0x803840B4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    osSyncPrintf(rdram, ctx);
        goto after_0;
    // 0x803840B4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_0:
    // 0x803840B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803840BC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803840C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803840C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803840C8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803840CC: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x803840D0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803840D4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803840D8: srl         $t8, $v1, 28
    ctx->r24 = S32(U32(ctx->r3) >> 28);
    // 0x803840DC: beq         $t8, $zero, L_803840FC
    if (ctx->r24 == 0) {
        // 0x803840E0: nop
    
            goto L_803840FC;
    }
    // 0x803840E0: nop

    // 0x803840E4: beq         $t8, $at, L_80384128
    if (ctx->r24 == ctx->r1) {
        // 0x803840E8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384128;
    }
    // 0x803840E8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803840EC: beql        $t8, $at, L_803841E8
    if (ctx->r24 == ctx->r1) {
        // 0x803840F0: lw          $t4, 0x2C4($v0)
        ctx->r12 = MEM_W(ctx->r2, 0X2C4);
            goto L_803841E8;
    }
    goto skip_1;
    // 0x803840F0: lw          $t4, 0x2C4($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X2C4);
    skip_1:
    // 0x803840F4: b           L_80384480
    // 0x803840F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x803840F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803840FC:
    // 0x803840FC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384100: jal         0x80363CE0
    // 0x80384104: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_1;
    // 0x80384104: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_1:
    // 0x80384108: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038410C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384110: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384114: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384118: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x8038411C: ori         $t2, $t1, 0x10
    ctx->r10 = ctx->r9 | 0X10;
    // 0x80384120: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80384124: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80384128:
    // 0x80384128: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
    // 0x8038412C: slti        $at, $t3, 0x64
    ctx->r1 = SIGNED(ctx->r11) < 0X64 ? 1 : 0;
    // 0x80384130: beq         $at, $zero, L_80384174
    if (ctx->r1 == 0) {
        // 0x80384134: nop
    
            goto L_80384174;
    }
    // 0x80384134: nop

    // 0x80384138: sw          $zero, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = 0;
    // 0x8038413C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384140: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384144: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80384148: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8038414C: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80384150: ori         $t6, $t5, 0x20
    ctx->r14 = ctx->r13 | 0X20;
    // 0x80384154: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x80384158: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8038415C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384160: jal         0x80363EDC
    // 0x80384164: lw          $a2, 0x2CC($t7)
    ctx->r6 = MEM_W(ctx->r15, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_2;
    // 0x80384164: lw          $a2, 0x2CC($t7)
    ctx->r6 = MEM_W(ctx->r15, 0X2CC);
    after_2:
    // 0x80384168: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038416C: b           L_803841B0
    // 0x80384170: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
        goto L_803841B0;
    // 0x80384170: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
L_80384174:
    // 0x80384174: jal         0x80383830
    // 0x80384178: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80384178: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x8038417C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384180: beq         $v0, $zero, L_803841B0
    if (ctx->r2 == 0) {
        // 0x80384184: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_803841B0;
    }
    // 0x80384184: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384188: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038418C: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384190: slti        $at, $t8, 0xDC
    ctx->r1 = SIGNED(ctx->r24) < 0XDC ? 1 : 0;
    // 0x80384194: beql        $at, $zero, L_803841B4
    if (ctx->r1 == 0) {
        // 0x80384198: lw          $t2, 0x0($t0)
        ctx->r10 = MEM_W(ctx->r8, 0X0);
            goto L_803841B4;
    }
    goto skip_2;
    // 0x80384198: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    skip_2:
    // 0x8038419C: lw          $t9, 0x2C4($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X2C4);
    // 0x803841A0: addiu       $t1, $zero, 0x8C
    ctx->r9 = ADD32(0, 0X8C);
    // 0x803841A4: bnel        $t9, $zero, L_803841B4
    if (ctx->r25 != 0) {
        // 0x803841A8: lw          $t2, 0x0($t0)
        ctx->r10 = MEM_W(ctx->r8, 0X0);
            goto L_803841B4;
    }
    goto skip_3;
    // 0x803841A8: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    skip_3:
    // 0x803841AC: sw          $t1, 0x2C4($v0)
    MEM_W(0X2C4, ctx->r2) = ctx->r9;
L_803841B0:
    // 0x803841B0: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
L_803841B4:
    // 0x803841B4: lw          $v1, 0x2C4($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X2C4);
    // 0x803841B8: blez        $v1, L_8038447C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x803841BC: slti        $at, $v1, 0x64
        ctx->r1 = SIGNED(ctx->r3) < 0X64 ? 1 : 0;
            goto L_8038447C;
    }
    // 0x803841BC: slti        $at, $v1, 0x64
    ctx->r1 = SIGNED(ctx->r3) < 0X64 ? 1 : 0;
    // 0x803841C0: bne         $at, $zero, L_8038447C
    if (ctx->r1 != 0) {
        // 0x803841C4: andi        $t3, $v1, 0x3
        ctx->r11 = ctx->r3 & 0X3;
            goto L_8038447C;
    }
    // 0x803841C4: andi        $t3, $v1, 0x3
    ctx->r11 = ctx->r3 & 0X3;
    // 0x803841C8: bne         $t3, $zero, L_8038447C
    if (ctx->r11 != 0) {
        // 0x803841CC: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_8038447C;
    }
    // 0x803841CC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803841D0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803841D4: jal         0x802EEF9C
    // 0x803841D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    flying_dog_fire_gun(rdram, ctx);
        goto after_4;
    // 0x803841D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_4:
    // 0x803841DC: b           L_80384480
    // 0x803841E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x803841E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803841E4: lw          $t4, 0x2C4($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X2C4);
L_803841E8:
    // 0x803841E8: bnel        $t4, $zero, L_80384480
    if (ctx->r12 != 0) {
        // 0x803841EC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_4;
    // 0x803841EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803841F0: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
    // 0x803841F4: slti        $at, $t5, 0xFB
    ctx->r1 = SIGNED(ctx->r13) < 0XFB ? 1 : 0;
    // 0x803841F8: bnel        $at, $zero, L_80384480
    if (ctx->r1 != 0) {
        // 0x803841FC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_5;
    // 0x803841FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x80384200: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384204: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384208: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038420C: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x80384210: ori         $t8, $t7, 0x10
    ctx->r24 = ctx->r15 | 0X10;
    // 0x80384214: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    // 0x80384218: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8038421C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384220: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
    // 0x80384224: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80384228: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038422C: jal         0x80363CE0
    // 0x80384230: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x80384230: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_5:
    // 0x80384234: b           L_80384480
    // 0x80384238: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x80384238: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038423C: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
L_80384240:
    // 0x80384240: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384244: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x80384248: srl         $t2, $v1, 28
    ctx->r10 = S32(U32(ctx->r3) >> 28);
    // 0x8038424C: beq         $t2, $zero, L_80384278
    if (ctx->r10 == 0) {
        // 0x80384250: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384278;
    }
    // 0x80384250: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384254: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80384258: beq         $t2, $at, L_803842A0
    if (ctx->r10 == ctx->r1) {
        // 0x8038425C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803842A0;
    }
    // 0x8038425C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80384260: beq         $t2, $at, L_80384398
    if (ctx->r10 == ctx->r1) {
        // 0x80384264: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80384398;
    }
    // 0x80384264: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80384268: beql        $t2, $at, L_80384430
    if (ctx->r10 == ctx->r1) {
        // 0x8038426C: lh          $t2, 0x2D0($v0)
        ctx->r10 = MEM_H(ctx->r2, 0X2D0);
            goto L_80384430;
    }
    goto skip_6;
    // 0x8038426C: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
    skip_6:
    // 0x80384270: b           L_80384480
    // 0x80384274: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x80384274: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384278:
    // 0x80384278: jal         0x80363CE0
    // 0x8038427C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_chase_target(rdram, ctx);
        goto after_6;
    // 0x8038427C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_6:
    // 0x80384280: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384284: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384288: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038428C: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384290: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80384294: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x80384298: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x8038429C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803842A0:
    // 0x803842A0: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    // 0x803842A4: slti        $at, $t6, 0x40
    ctx->r1 = SIGNED(ctx->r14) < 0X40 ? 1 : 0;
    // 0x803842A8: beql        $at, $zero, L_80384308
    if (ctx->r1 == 0) {
        // 0x803842AC: lw          $t4, 0x2C4($v0)
        ctx->r12 = MEM_W(ctx->r2, 0X2C4);
            goto L_80384308;
    }
    goto skip_7;
    // 0x803842AC: lw          $t4, 0x2C4($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X2C4);
    skip_7:
    // 0x803842B0: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803842B4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803842B8: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x803842BC: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803842C0: ori         $t9, $t8, 0x30
    ctx->r25 = ctx->r24 | 0X30;
    // 0x803842C4: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x803842C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803842CC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803842D0: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x803842D4: sll         $t1, $a1, 2
    ctx->r9 = S32(ctx->r5 << 2);
    // 0x803842D8: subu        $t1, $t1, $a1
    ctx->r9 = SUB32(ctx->r9, ctx->r5);
    // 0x803842DC: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x803842E0: subu        $t1, $t1, $a1
    ctx->r9 = SUB32(ctx->r9, ctx->r5);
    // 0x803842E4: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x803842E8: addu        $t1, $t1, $a1
    ctx->r9 = ADD32(ctx->r9, ctx->r5);
    // 0x803842EC: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x803842F0: sra         $t2, $t1, 8
    ctx->r10 = S32(SIGNED(ctx->r9) >> 8);
    // 0x803842F4: jal         0x80363FB8
    // 0x803842F8: andi        $a1, $t2, 0xFFFF
    ctx->r5 = ctx->r10 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_7;
    // 0x803842F8: andi        $a1, $t2, 0xFFFF
    ctx->r5 = ctx->r10 & 0XFFFF;
    after_7:
    // 0x803842FC: b           L_80384480
    // 0x80384300: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x80384300: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80384304: lw          $t4, 0x2C4($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X2C4);
L_80384308:
    // 0x80384308: bnel        $t4, $zero, L_80384480
    if (ctx->r12 != 0) {
        // 0x8038430C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_8;
    // 0x8038430C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x80384310: jal         0x80383830
    // 0x80384314: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    target_within_current_fov(rdram, ctx);
        goto after_8;
    // 0x80384314: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_8:
    // 0x80384318: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038431C: beq         $v0, $zero, L_8038447C
    if (ctx->r2 == 0) {
        // 0x80384320: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8038447C;
    }
    // 0x80384320: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384324: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384328: addiu       $t6, $zero, 0x50
    ctx->r14 = ADD32(0, 0X50);
    // 0x8038432C: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384330: slti        $at, $t5, 0xC8
    ctx->r1 = SIGNED(ctx->r13) < 0XC8 ? 1 : 0;
    // 0x80384334: beql        $at, $zero, L_80384480
    if (ctx->r1 == 0) {
        // 0x80384338: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_9;
    // 0x80384338: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x8038433C: sw          $t6, 0x2C4($v0)
    MEM_W(0X2C4, ctx->r2) = ctx->r14;
    // 0x80384340: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384344: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384348: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x8038434C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384350: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384354: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384358: ori         $t9, $t8, 0x20
    ctx->r25 = ctx->r24 | 0X20;
    // 0x8038435C: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80384360: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384364: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x80384368: sll         $t1, $a1, 2
    ctx->r9 = S32(ctx->r5 << 2);
    // 0x8038436C: subu        $t1, $t1, $a1
    ctx->r9 = SUB32(ctx->r9, ctx->r5);
    // 0x80384370: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x80384374: subu        $t1, $t1, $a1
    ctx->r9 = SUB32(ctx->r9, ctx->r5);
    // 0x80384378: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x8038437C: addu        $t1, $t1, $a1
    ctx->r9 = ADD32(ctx->r9, ctx->r5);
    // 0x80384380: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x80384384: sra         $t2, $t1, 8
    ctx->r10 = S32(SIGNED(ctx->r9) >> 8);
    // 0x80384388: jal         0x80363FB8
    // 0x8038438C: andi        $a1, $t2, 0xFFFF
    ctx->r5 = ctx->r10 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_9;
    // 0x8038438C: andi        $a1, $t2, 0xFFFF
    ctx->r5 = ctx->r10 & 0XFFFF;
    after_9:
    // 0x80384390: b           L_80384480
    // 0x80384394: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x80384394: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384398:
    // 0x80384398: lw          $v1, 0x2C4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C4);
    // 0x8038439C: slti        $at, $v1, 0x3C
    ctx->r1 = SIGNED(ctx->r3) < 0X3C ? 1 : 0;
    // 0x803843A0: bne         $at, $zero, L_803843CC
    if (ctx->r1 != 0) {
        // 0x803843A4: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803843CC;
    }
    // 0x803843A4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803843A8: div         $zero, $v1, $at
    lo = S32(S64(S32(ctx->r3)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r3)) % S64(S32(ctx->r1)));
    // 0x803843AC: mfhi        $t4
    ctx->r12 = hi;
    // 0x803843B0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803843B4: bne         $t4, $zero, L_803843CC
    if (ctx->r12 != 0) {
        // 0x803843B8: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_803843CC;
    }
    // 0x803843B8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803843BC: jal         0x802EEFEC
    // 0x803843C0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    flying_dog_drop_bomb(rdram, ctx);
        goto after_10;
    // 0x803843C0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_10:
    // 0x803843C4: b           L_80384480
    // 0x803843C8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x803843C8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803843CC:
    // 0x803843CC: slti        $at, $v1, 0x3C
    ctx->r1 = SIGNED(ctx->r3) < 0X3C ? 1 : 0;
    // 0x803843D0: beql        $at, $zero, L_80384480
    if (ctx->r1 == 0) {
        // 0x803843D4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_10;
    // 0x803843D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_10:
    // 0x803843D8: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803843DC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803843E0: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x803843E4: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x803843E8: ori         $t7, $t6, 0x30
    ctx->r15 = ctx->r14 | 0X30;
    // 0x803843EC: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x803843F0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803843F4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803843F8: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x803843FC: sll         $t8, $a1, 2
    ctx->r24 = S32(ctx->r5 << 2);
    // 0x80384400: subu        $t8, $t8, $a1
    ctx->r24 = SUB32(ctx->r24, ctx->r5);
    // 0x80384404: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80384408: subu        $t8, $t8, $a1
    ctx->r24 = SUB32(ctx->r24, ctx->r5);
    // 0x8038440C: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80384410: addu        $t8, $t8, $a1
    ctx->r24 = ADD32(ctx->r24, ctx->r5);
    // 0x80384414: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x80384418: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x8038441C: jal         0x80363FB8
    // 0x80384420: andi        $a1, $t9, 0xFFFF
    ctx->r5 = ctx->r25 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_11;
    // 0x80384420: andi        $a1, $t9, 0xFFFF
    ctx->r5 = ctx->r25 & 0XFFFF;
    after_11:
    // 0x80384424: b           L_80384480
    // 0x80384428: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384480;
    // 0x80384428: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038442C: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
L_80384430:
    // 0x80384430: slti        $at, $t2, 0x119
    ctx->r1 = SIGNED(ctx->r10) < 0X119 ? 1 : 0;
    // 0x80384434: beql        $at, $zero, L_8038444C
    if (ctx->r1 == 0) {
        // 0x80384438: lbu         $t4, 0x2B4($v0)
        ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
            goto L_8038444C;
    }
    goto skip_11;
    // 0x80384438: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
    skip_11:
    // 0x8038443C: lw          $t3, 0x2C4($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X2C4);
    // 0x80384440: bnel        $t3, $zero, L_80384480
    if (ctx->r11 != 0) {
        // 0x80384444: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384480;
    }
    goto skip_12;
    // 0x80384444: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_12:
    // 0x80384448: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
L_8038444C:
    // 0x8038444C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384450: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x80384454: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80384458: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x8038445C: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x80384460: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x80384464: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384468: sw          $zero, 0x2C0($t7)
    MEM_W(0X2C0, ctx->r15) = 0;
    // 0x8038446C: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80384470: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384474: jal         0x80363CE0
    // 0x80384478: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_12;
    // 0x80384478: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_12:
L_8038447C:
    // 0x8038447C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384480:
    // 0x80384480: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80384484: jr          $ra
    // 0x80384488: nop

    return;
    // 0x80384488: nop

;}
RECOMP_FUNC void perform_behavior_fox(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038448C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384490: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384494: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384498: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038449C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803844A0: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803844A4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803844A8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803844AC: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803844B0: beq         $t6, $zero, L_803844D4
    if (ctx->r14 == 0) {
        // 0x803844B4: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803844D4;
    }
    // 0x803844B4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803844B8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803844BC: beq         $t6, $at, L_80384500
    if (ctx->r14 == ctx->r1) {
        // 0x803844C0: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384500;
    }
    // 0x803844C0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803844C4: beql        $t6, $at, L_80384654
    if (ctx->r14 == ctx->r1) {
        // 0x803844C8: lh          $t3, 0x2D0($v1)
        ctx->r11 = MEM_H(ctx->r3, 0X2D0);
            goto L_80384654;
    }
    goto skip_0;
    // 0x803844C8: lh          $t3, 0x2D0($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x803844CC: b           L_803846B0
    // 0x803844D0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803846B0;
    // 0x803844D0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803844D4:
    // 0x803844D4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803844D8: jal         0x80363CE0
    // 0x803844DC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803844DC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x803844E0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803844E4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803844E8: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803844EC: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803844F0: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803844F4: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803844F8: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x803844FC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80384500:
    // 0x80384500: lw          $v0, 0x2C0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384504: blez        $v0, L_80384548
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80384508: addiu       $t1, $v0, -0x1
        ctx->r9 = ADD32(ctx->r2, -0X1);
            goto L_80384548;
    }
    // 0x80384508: addiu       $t1, $v0, -0x1
    ctx->r9 = ADD32(ctx->r2, -0X1);
    // 0x8038450C: sw          $t1, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r9;
    // 0x80384510: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384514: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384518: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038451C: lw          $t2, 0x2C0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384520: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384524: bnel        $t2, $zero, L_803845A0
    if (ctx->r10 != 0) {
        // 0x80384528: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803845A0;
    }
    goto skip_1;
    // 0x80384528: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_1:
    // 0x8038452C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384530: jal         0x80363CE0
    // 0x80384534: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_1;
    // 0x80384534: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_1:
    // 0x80384538: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038453C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384540: b           L_8038459C
    // 0x80384544: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
        goto L_8038459C;
    // 0x80384544: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80384548:
    // 0x80384548: bne         $v0, $zero, L_8038459C
    if (ctx->r2 != 0) {
        // 0x8038454C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8038459C;
    }
    // 0x8038454C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80384550: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80384554: lbu         $t3, 0x5C($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X5C);
    // 0x80384558: andi        $t4, $t3, 0x4
    ctx->r12 = ctx->r11 & 0X4;
    // 0x8038455C: beql        $t4, $zero, L_803845A0
    if (ctx->r12 == 0) {
        // 0x80384560: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803845A0;
    }
    goto skip_2;
    // 0x80384560: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_2:
    // 0x80384564: lw          $t5, 0x2CC($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2CC);
    // 0x80384568: lw          $t6, 0x60($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X60);
    // 0x8038456C: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x80384570: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384574: bnel        $t5, $t6, L_803845A0
    if (ctx->r13 != ctx->r14) {
        // 0x80384578: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803845A0;
    }
    goto skip_3;
    // 0x80384578: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x8038457C: sw          $t7, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r15;
    // 0x80384580: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80384584: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384588: jal         0x80363E88
    // 0x8038458C: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x8038458C: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_2:
    // 0x80384590: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384594: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384598: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_8038459C:
    // 0x8038459C: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
L_803845A0:
    // 0x803845A0: bgtzl       $t9, L_803846B0
    if (SIGNED(ctx->r25) > 0) {
        // 0x803845A4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803846B0;
    }
    goto skip_4;
    // 0x803845A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803845A8: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    // 0x803845AC: slti        $at, $t1, 0x33
    ctx->r1 = SIGNED(ctx->r9) < 0X33 ? 1 : 0;
    // 0x803845B0: beql        $at, $zero, L_803846B0
    if (ctx->r1 == 0) {
        // 0x803845B4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803846B0;
    }
    goto skip_5;
    // 0x803845B4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x803845B8: jal         0x80383830
    // 0x803845BC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x803845BC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x803845C0: beql        $v0, $zero, L_803846B0
    if (ctx->r2 == 0) {
        // 0x803845C4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803846B0;
    }
    goto skip_6;
    // 0x803845C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x803845C8: jal         0x802E88C0
    // 0x803845CC: addiu       $a0, $zero, 0x64
    ctx->r4 = ADD32(0, 0X64);
    func_802E88C0_6F9F70(rdram, ctx);
        goto after_4;
    // 0x803845CC: addiu       $a0, $zero, 0x64
    ctx->r4 = ADD32(0, 0X64);
    after_4:
    // 0x803845D0: jal         0x8012826C
    // 0x803845D4: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x803845D4: nop

    after_5:
    // 0x803845D8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803845DC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803845E0: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x803845E4: andi        $t2, $v0, 0x7
    ctx->r10 = ctx->r2 & 0X7;
    // 0x803845E8: addiu       $t3, $t2, 0x19
    ctx->r11 = ADD32(ctx->r10, 0X19);
    // 0x803845EC: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    // 0x803845F0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803845F4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803845F8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803845FC: lw          $t5, 0x2BC($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2BC);
    // 0x80384600: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x80384604: sw          $t6, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r14;
    // 0x80384608: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8038460C: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x80384610: slti        $at, $t7, 0x3
    ctx->r1 = SIGNED(ctx->r15) < 0X3 ? 1 : 0;
    // 0x80384614: bnel        $at, $zero, L_803846B0
    if (ctx->r1 != 0) {
        // 0x80384618: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803846B0;
    }
    goto skip_7;
    // 0x80384618: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x8038461C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384620: jal         0x80363EDC
    // 0x80384624: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80384624: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80384628: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038462C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384630: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384634: lbu         $t8, 0x2B4($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80384638: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x8038463C: ori         $t1, $t9, 0x20
    ctx->r9 = ctx->r25 | 0X20;
    // 0x80384640: sb          $t1, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r9;
    // 0x80384644: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80384648: b           L_803846AC
    // 0x8038464C: sw          $zero, 0x2BC($t2)
    MEM_W(0X2BC, ctx->r10) = 0;
        goto L_803846AC;
    // 0x8038464C: sw          $zero, 0x2BC($t2)
    MEM_W(0X2BC, ctx->r10) = 0;
    // 0x80384650: lh          $t3, 0x2D0($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2D0);
L_80384654:
    // 0x80384654: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384658: slti        $at, $t3, 0x64
    ctx->r1 = SIGNED(ctx->r11) < 0X64 ? 1 : 0;
    // 0x8038465C: beql        $at, $zero, L_80384688
    if (ctx->r1 == 0) {
        // 0x80384660: lbu         $t7, 0x2B4($v1)
        ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80384688;
    }
    goto skip_8;
    // 0x80384660: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    skip_8:
    // 0x80384664: lw          $t4, 0x2C0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384668: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8038466C: sw          $t5, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r13;
    // 0x80384670: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384674: lw          $t6, 0x2C0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384678: slti        $at, $t6, 0x1F
    ctx->r1 = SIGNED(ctx->r14) < 0X1F ? 1 : 0;
    // 0x8038467C: bnel        $at, $zero, L_803846B0
    if (ctx->r1 != 0) {
        // 0x80384680: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803846B0;
    }
    goto skip_9;
    // 0x80384680: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x80384684: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
L_80384688:
    // 0x80384688: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038468C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384690: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384694: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384698: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x8038469C: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x803846A0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803846A4: jal         0x80363CE0
    // 0x803846A8: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x803846A8: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_7:
L_803846AC:
    // 0x803846AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803846B0:
    // 0x803846B0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803846B4: jr          $ra
    // 0x803846B8: nop

    return;
    // 0x803846B8: nop

;}
RECOMP_FUNC void perform_behavior_fire_fox(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803846BC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803846C0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803846C4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803846C8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803846CC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803846D0: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x803846D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803846D8: addiu       $a2, $zero, -0x46
    ctx->r6 = ADD32(0, -0X46);
    // 0x803846DC: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x803846E0: beq         $t6, $zero, L_80384704
    if (ctx->r14 == 0) {
        // 0x803846E4: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384704;
    }
    // 0x803846E4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803846E8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803846EC: beq         $t6, $at, L_80384730
    if (ctx->r14 == ctx->r1) {
        // 0x803846F0: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384730;
    }
    // 0x803846F0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803846F4: beql        $t6, $at, L_803847FC
    if (ctx->r14 == ctx->r1) {
        // 0x803846F8: lw          $t6, 0x2C4($v0)
        ctx->r14 = MEM_W(ctx->r2, 0X2C4);
            goto L_803847FC;
    }
    goto skip_0;
    // 0x803846F8: lw          $t6, 0x2C4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2C4);
    skip_0:
    // 0x803846FC: b           L_8038484C
    // 0x80384700: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038484C;
    // 0x80384700: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384704:
    // 0x80384704: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384708: jal         0x80363CE0
    // 0x8038470C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x8038470C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80384710: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384714: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384718: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038471C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384720: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384724: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384728: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x8038472C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80384730:
    // 0x80384730: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384734: slti        $at, $t1, 0x78
    ctx->r1 = SIGNED(ctx->r9) < 0X78 ? 1 : 0;
    // 0x80384738: beql        $at, $zero, L_80384778
    if (ctx->r1 == 0) {
        // 0x8038473C: lw          $t6, 0x2C4($v0)
        ctx->r14 = MEM_W(ctx->r2, 0X2C4);
            goto L_80384778;
    }
    goto skip_1;
    // 0x8038473C: lw          $t6, 0x2C4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2C4);
    skip_1:
    // 0x80384740: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384744: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384748: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038474C: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80384750: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x80384754: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x80384758: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8038475C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384760: jal         0x80363EDC
    // 0x80384764: lw          $a2, 0x2CC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80384764: lw          $a2, 0x2CC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0X2CC);
    after_1:
    // 0x80384768: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038476C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384770: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384774: lw          $t6, 0x2C4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2C4);
L_80384778:
    // 0x80384778: bnel        $t6, $zero, L_8038484C
    if (ctx->r14 != 0) {
        // 0x8038477C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038484C;
    }
    goto skip_2;
    // 0x8038477C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x80384780: lh          $t7, 0x2D0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384784: slti        $at, $t7, 0xC8
    ctx->r1 = SIGNED(ctx->r15) < 0XC8 ? 1 : 0;
    // 0x80384788: beql        $at, $zero, L_8038484C
    if (ctx->r1 == 0) {
        // 0x8038478C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038484C;
    }
    goto skip_3;
    // 0x8038478C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x80384790: jal         0x80383830
    // 0x80384794: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    target_within_current_fov(rdram, ctx);
        goto after_2;
    // 0x80384794: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_2:
    // 0x80384798: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038479C: beq         $v0, $zero, L_80384848
    if (ctx->r2 == 0) {
        // 0x803847A0: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80384848;
    }
    // 0x803847A0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803847A4: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x803847A8: jal         0x802E87B8
    // 0x803847AC: lw          $a0, 0x2CC($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X2CC);
    fire_fox_fire_missile(rdram, ctx);
        goto after_3;
    // 0x803847AC: lw          $a0, 0x2CC($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X2CC);
    after_3:
    // 0x803847B0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803847B4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803847B8: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x803847BC: addiu       $t9, $zero, 0x96
    ctx->r25 = ADD32(0, 0X96);
    // 0x803847C0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803847C4: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
    // 0x803847C8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803847CC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803847D0: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803847D4: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x803847D8: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x803847DC: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x803847E0: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x803847E4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803847E8: jal         0x80363EDC
    // 0x803847EC: lw          $a2, 0x2CC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x803847EC: lw          $a2, 0x2CC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0X2CC);
    after_4:
    // 0x803847F0: b           L_8038484C
    // 0x803847F4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038484C;
    // 0x803847F4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803847F8: lw          $t6, 0x2C4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2C4);
L_803847FC:
    // 0x803847FC: bnel        $t6, $zero, L_8038484C
    if (ctx->r14 != 0) {
        // 0x80384800: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038484C;
    }
    goto skip_4;
    // 0x80384800: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x80384804: lh          $t7, 0x2D0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384808: slti        $at, $t7, 0xF1
    ctx->r1 = SIGNED(ctx->r15) < 0XF1 ? 1 : 0;
    // 0x8038480C: bnel        $at, $zero, L_8038484C
    if (ctx->r1 != 0) {
        // 0x80384810: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038484C;
    }
    goto skip_5;
    // 0x80384810: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x80384814: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384818: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038481C: addiu       $a2, $zero, -0x46
    ctx->r6 = ADD32(0, -0X46);
    // 0x80384820: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80384824: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x80384828: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x8038482C: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80384830: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384834: sw          $zero, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = 0;
    // 0x80384838: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8038483C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384840: jal         0x80363CE0
    // 0x80384844: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x80384844: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_5:
L_80384848:
    // 0x80384848: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038484C:
    // 0x8038484C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80384850: jr          $ra
    // 0x80384854: nop

    return;
    // 0x80384854: nop

;}
RECOMP_FUNC void perform_behavior_frog(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384858: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038485C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384860: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384864: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80384868: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038486C: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80384870: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384874: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80384878: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x8038487C: beq         $t6, $zero, L_803848A8
    if (ctx->r14 == 0) {
        // 0x80384880: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803848A8;
    }
    // 0x80384880: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384884: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80384888: beq         $t6, $at, L_803848D4
    if (ctx->r14 == ctx->r1) {
        // 0x8038488C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803848D4;
    }
    // 0x8038488C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80384890: beq         $t6, $at, L_80384910
    if (ctx->r14 == ctx->r1) {
        // 0x80384894: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80384910;
    }
    // 0x80384894: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80384898: beql        $t6, $at, L_80384A24
    if (ctx->r14 == ctx->r1) {
        // 0x8038489C: lh          $t7, 0x2D0($v1)
        ctx->r15 = MEM_H(ctx->r3, 0X2D0);
            goto L_80384A24;
    }
    goto skip_0;
    // 0x8038489C: lh          $t7, 0x2D0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x803848A0: b           L_80384A80
    // 0x803848A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384A80;
    // 0x803848A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803848A8:
    // 0x803848A8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803848AC: jal         0x80363CE0
    // 0x803848B0: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803848B0: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x803848B4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803848B8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803848BC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803848C0: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803848C4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803848C8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803848CC: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x803848D0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_803848D4:
    // 0x803848D4: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    // 0x803848D8: slti        $at, $t1, 0x3D
    ctx->r1 = SIGNED(ctx->r9) < 0X3D ? 1 : 0;
    // 0x803848DC: beql        $at, $zero, L_80384A80
    if (ctx->r1 == 0) {
        // 0x803848E0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384A80;
    }
    goto skip_1;
    // 0x803848E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x803848E4: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803848E8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803848EC: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x803848F0: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x803848F4: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x803848F8: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x803848FC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384900: jal         0x80363E88
    // 0x80384904: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80384904: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_1:
    // 0x80384908: b           L_80384A80
    // 0x8038490C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384A80;
    // 0x8038490C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384910:
    // 0x80384910: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
    // 0x80384914: slti        $at, $t6, 0x3D
    ctx->r1 = SIGNED(ctx->r14) < 0X3D ? 1 : 0;
    // 0x80384918: bnel        $at, $zero, L_80384968
    if (ctx->r1 != 0) {
        // 0x8038491C: lw          $t3, 0x2C4($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X2C4);
            goto L_80384968;
    }
    goto skip_2;
    // 0x8038491C: lw          $t3, 0x2C4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C4);
    skip_2:
    // 0x80384920: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x80384924: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384928: slti        $at, $t7, 0x4
    ctx->r1 = SIGNED(ctx->r15) < 0X4 ? 1 : 0;
    // 0x8038492C: beql        $at, $zero, L_80384968
    if (ctx->r1 == 0) {
        // 0x80384930: lw          $t3, 0x2C4($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X2C4);
            goto L_80384968;
    }
    goto skip_3;
    // 0x80384930: lw          $t3, 0x2C4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x80384934: lbu         $t8, 0x2B4($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80384938: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x8038493C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384940: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80384944: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x80384948: sb          $t1, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r9;
    // 0x8038494C: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80384950: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384954: jal         0x80363CE0
    // 0x80384958: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80384958: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_2:
    // 0x8038495C: b           L_80384A80
    // 0x80384960: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384A80;
    // 0x80384960: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80384964: lw          $t3, 0x2C4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C4);
L_80384968:
    // 0x80384968: bgtzl       $t3, L_80384A80
    if (SIGNED(ctx->r11) > 0) {
        // 0x8038496C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384A80;
    }
    goto skip_4;
    // 0x8038496C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x80384970: jal         0x80383830
    // 0x80384974: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80384974: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x80384978: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038497C: beq         $v0, $zero, L_80384A7C
    if (ctx->r2 == 0) {
        // 0x80384980: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80384A7C;
    }
    // 0x80384980: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384984: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384988: lw          $t4, 0x2BC($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2BC);
    // 0x8038498C: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x80384990: sw          $t5, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r13;
    // 0x80384994: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80384998: lw          $t7, 0x2BC($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X2BC);
    // 0x8038499C: slti        $at, $t7, 0x4
    ctx->r1 = SIGNED(ctx->r15) < 0X4 ? 1 : 0;
    // 0x803849A0: beq         $at, $zero, L_803849B0
    if (ctx->r1 == 0) {
        // 0x803849A4: nop
    
            goto L_803849B0;
    }
    // 0x803849A4: nop

    // 0x803849A8: jal         0x80302DD0
    // 0x803849AC: nop

    frog_croak(rdram, ctx);
        goto after_4;
    // 0x803849AC: nop

    after_4:
L_803849B0:
    // 0x803849B0: jal         0x8012826C
    // 0x803849B4: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x803849B4: nop

    after_5:
    // 0x803849B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803849BC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803849C0: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x803849C4: andi        $t8, $v0, 0x7
    ctx->r24 = ctx->r2 & 0X7;
    // 0x803849C8: addiu       $t9, $t8, 0xA
    ctx->r25 = ADD32(ctx->r24, 0XA);
    // 0x803849CC: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
    // 0x803849D0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803849D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803849D8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803849DC: lw          $t2, 0x2BC($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2BC);
    // 0x803849E0: slti        $at, $t2, 0x5
    ctx->r1 = SIGNED(ctx->r10) < 0X5 ? 1 : 0;
    // 0x803849E4: bnel        $at, $zero, L_80384A80
    if (ctx->r1 != 0) {
        // 0x803849E8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384A80;
    }
    goto skip_5;
    // 0x803849E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x803849EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803849F0: jal         0x80363EDC
    // 0x803849F4: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x803849F4: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x803849F8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803849FC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384A00: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384A04: lbu         $t3, 0x2B4($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80384A08: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80384A0C: ori         $t5, $t4, 0x30
    ctx->r13 = ctx->r12 | 0X30;
    // 0x80384A10: sb          $t5, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r13;
    // 0x80384A14: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80384A18: b           L_80384A7C
    // 0x80384A1C: sw          $zero, 0x2BC($t6)
    MEM_W(0X2BC, ctx->r14) = 0;
        goto L_80384A7C;
    // 0x80384A1C: sw          $zero, 0x2BC($t6)
    MEM_W(0X2BC, ctx->r14) = 0;
    // 0x80384A20: lh          $t7, 0x2D0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X2D0);
L_80384A24:
    // 0x80384A24: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384A28: slti        $at, $t7, 0xFA
    ctx->r1 = SIGNED(ctx->r15) < 0XFA ? 1 : 0;
    // 0x80384A2C: beql        $at, $zero, L_80384A58
    if (ctx->r1 == 0) {
        // 0x80384A30: lbu         $t2, 0x2B4($v1)
        ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80384A58;
    }
    goto skip_6;
    // 0x80384A30: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    skip_6:
    // 0x80384A34: lw          $t8, 0x2C0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384A38: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80384A3C: sw          $t9, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r25;
    // 0x80384A40: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80384A44: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    // 0x80384A48: slti        $at, $t1, 0x29
    ctx->r1 = SIGNED(ctx->r9) < 0X29 ? 1 : 0;
    // 0x80384A4C: bnel        $at, $zero, L_80384A80
    if (ctx->r1 != 0) {
        // 0x80384A50: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384A80;
    }
    goto skip_7;
    // 0x80384A50: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x80384A54: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
L_80384A58:
    // 0x80384A58: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80384A5C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384A60: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80384A64: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x80384A68: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x80384A6C: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x80384A70: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384A74: jal         0x80363CE0
    // 0x80384A78: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x80384A78: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_7:
L_80384A7C:
    // 0x80384A7C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384A80:
    // 0x80384A80: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80384A84: jr          $ra
    // 0x80384A88: nop

    return;
    // 0x80384A88: nop

;}
RECOMP_FUNC void perform_behavior_rabbit(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384A8C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80384A90: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80384A94: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384A98: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384A9C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80384AA0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80384AA4: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80384AA8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384AAC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80384AB0: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80384AB4: beq         $t6, $zero, L_80384ADC
    if (ctx->r14 == 0) {
        // 0x80384AB8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384ADC;
    }
    // 0x80384AB8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384ABC: beq         $t6, $at, L_80384B14
    if (ctx->r14 == ctx->r1) {
        // 0x80384AC0: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384B14;
    }
    // 0x80384AC0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80384AC4: beq         $t6, $at, L_80384B50
    if (ctx->r14 == ctx->r1) {
        // 0x80384AC8: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80384B50;
    }
    // 0x80384AC8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80384ACC: beql        $t6, $at, L_80384C44
    if (ctx->r14 == ctx->r1) {
        // 0x80384AD0: lh          $t8, 0x2D0($s0)
        ctx->r24 = MEM_H(ctx->r16, 0X2D0);
            goto L_80384C44;
    }
    goto skip_0;
    // 0x80384AD0: lh          $t8, 0x2D0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80384AD4: b           L_80384CA8
    // 0x80384AD8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80384CA8;
    // 0x80384AD8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80384ADC:
    // 0x80384ADC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384AE0: jal         0x80363CE0
    // 0x80384AE4: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80384AE4: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80384AE8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384AEC: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384AF0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384AF4: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384AF8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384AFC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384B00: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80384B04: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x80384B08: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384B0C: sw          $zero, 0x2C0($t0)
    MEM_W(0X2C0, ctx->r8) = 0;
    // 0x80384B10: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80384B14:
    // 0x80384B14: lh          $t1, 0x2D0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2D0);
    // 0x80384B18: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384B1C: slti        $at, $t1, 0xC9
    ctx->r1 = SIGNED(ctx->r9) < 0XC9 ? 1 : 0;
    // 0x80384B20: beql        $at, $zero, L_80384CA8
    if (ctx->r1 == 0) {
        // 0x80384B24: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384CA8;
    }
    goto skip_1;
    // 0x80384B24: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80384B28: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384B2C: jal         0x80363E88
    // 0x80384B30: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80384B30: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80384B34: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384B38: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384B3C: lbu         $t2, 0x2B4($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384B40: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80384B44: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x80384B48: b           L_80384CA4
    // 0x80384B4C: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
        goto L_80384CA4;
    // 0x80384B4C: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
L_80384B50:
    // 0x80384B50: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80384B54: blez        $v1, L_80384B6C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80384B58: addiu       $t5, $v1, -0x1
        ctx->r13 = ADD32(ctx->r3, -0X1);
            goto L_80384B6C;
    }
    // 0x80384B58: addiu       $t5, $v1, -0x1
    ctx->r13 = ADD32(ctx->r3, -0X1);
    // 0x80384B5C: sw          $t5, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r13;
    // 0x80384B60: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384B64: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384B68: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
L_80384B6C:
    // 0x80384B6C: bne         $v1, $zero, L_80384BB4
    if (ctx->r3 != 0) {
        // 0x80384B70: nop
    
            goto L_80384BB4;
    }
    // 0x80384B70: nop

    // 0x80384B74: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
    // 0x80384B78: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384B7C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80384B80: slti        $at, $t6, 0xFB
    ctx->r1 = SIGNED(ctx->r14) < 0XFB ? 1 : 0;
    // 0x80384B84: bne         $at, $zero, L_80384BB4
    if (ctx->r1 != 0) {
        // 0x80384B88: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384BB4;
    }
    // 0x80384B88: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384B8C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384B90: jal         0x80363CE0
    // 0x80384B94: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80384B94: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80384B98: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384B9C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384BA0: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384BA4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384BA8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384BAC: b           L_80384CA4
    // 0x80384BB0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
        goto L_80384CA4;
    // 0x80384BB0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
L_80384BB4:
    // 0x80384BB4: bnel        $v1, $zero, L_80384C00
    if (ctx->r3 != 0) {
        // 0x80384BB8: lw          $t4, 0x2C4($s0)
        ctx->r12 = MEM_W(ctx->r16, 0X2C4);
            goto L_80384C00;
    }
    goto skip_2;
    // 0x80384BB8: lw          $t4, 0x2C4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C4);
    skip_2:
    // 0x80384BBC: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80384BC0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384BC4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80384BC8: slti        $at, $t0, 0x64
    ctx->r1 = SIGNED(ctx->r8) < 0X64 ? 1 : 0;
    // 0x80384BCC: beql        $at, $zero, L_80384C00
    if (ctx->r1 == 0) {
        // 0x80384BD0: lw          $t4, 0x2C4($s0)
        ctx->r12 = MEM_W(ctx->r16, 0X2C4);
            goto L_80384C00;
    }
    goto skip_3;
    // 0x80384BD0: lw          $t4, 0x2C4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80384BD4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384BD8: jal         0x80363EDC
    // 0x80384BDC: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80384BDC: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80384BE0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384BE4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80384BE8: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384BEC: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80384BF0: ori         $t3, $t2, 0x30
    ctx->r11 = ctx->r10 | 0X30;
    // 0x80384BF4: b           L_80384CA4
    // 0x80384BF8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_80384CA4;
    // 0x80384BF8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
    // 0x80384BFC: lw          $t4, 0x2C4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C4);
L_80384C00:
    // 0x80384C00: bgtzl       $t4, L_80384CA8
    if (SIGNED(ctx->r12) > 0) {
        // 0x80384C04: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384CA8;
    }
    goto skip_4;
    // 0x80384C04: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80384C08: jal         0x80383830
    // 0x80384C0C: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80384C0C: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80384C10: beql        $v0, $zero, L_80384CA8
    if (ctx->r2 == 0) {
        // 0x80384C14: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80384CA8;
    }
    goto skip_5;
    // 0x80384C14: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80384C18: jal         0x803021A8
    // 0x80384C1C: nop

    func_803021A8_713858(rdram, ctx);
        goto after_5;
    // 0x80384C1C: nop

    after_5:
    // 0x80384C20: jal         0x8012826C
    // 0x80384C24: nop

    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x80384C24: nop

    after_6:
    // 0x80384C28: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80384C2C: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80384C30: andi        $t5, $v0, 0x1F
    ctx->r13 = ctx->r2 & 0X1F;
    // 0x80384C34: addiu       $t6, $t5, 0x28
    ctx->r14 = ADD32(ctx->r13, 0X28);
    // 0x80384C38: b           L_80384CA4
    // 0x80384C3C: sw          $t6, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r14;
        goto L_80384CA4;
    // 0x80384C3C: sw          $t6, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r14;
    // 0x80384C40: lh          $t8, 0x2D0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X2D0);
L_80384C44:
    // 0x80384C44: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384C48: slti        $at, $t8, 0x12D
    ctx->r1 = SIGNED(ctx->r24) < 0X12D ? 1 : 0;
    // 0x80384C4C: beq         $at, $zero, L_80384C70
    if (ctx->r1 == 0) {
        // 0x80384C50: nop
    
            goto L_80384C70;
    }
    // 0x80384C50: nop

    // 0x80384C54: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80384C58: slti        $v0, $v1, 0x65
    ctx->r2 = SIGNED(ctx->r3) < 0X65 ? 1 : 0;
    // 0x80384C5C: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x80384C60: bne         $v0, $zero, L_80384CA4
    if (ctx->r2 != 0) {
        // 0x80384C64: sw          $t9, 0x2C0($s0)
        MEM_W(0X2C0, ctx->r16) = ctx->r25;
            goto L_80384CA4;
    }
    // 0x80384C64: sw          $t9, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r25;
    // 0x80384C68: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80384C6C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80384C70:
    // 0x80384C70: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384C74: jal         0x80363E88
    // 0x80384C78: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80384C78: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80384C7C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80384C80: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x80384C84: lw          $s0, 0x0($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X0);
    // 0x80384C88: addiu       $t3, $zero, 0x64
    ctx->r11 = ADD32(0, 0X64);
    // 0x80384C8C: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80384C90: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80384C94: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x80384C98: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
    // 0x80384C9C: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x80384CA0: sw          $t3, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = ctx->r11;
L_80384CA4:
    // 0x80384CA4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80384CA8:
    // 0x80384CA8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80384CAC: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80384CB0: jr          $ra
    // 0x80384CB4: nop

    return;
    // 0x80384CB4: nop

;}
RECOMP_FUNC void perform_behavior_heli_rabbit(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384CB8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384CBC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384CC0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384CC4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80384CC8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80384CCC: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80384CD0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384CD4: addiu       $a2, $zero, -0xC8
    ctx->r6 = ADD32(0, -0XC8);
    // 0x80384CD8: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80384CDC: beq         $t6, $zero, L_80384D08
    if (ctx->r14 == 0) {
        // 0x80384CE0: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384D08;
    }
    // 0x80384CE0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384CE4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80384CE8: beq         $t6, $at, L_80384D34
    if (ctx->r14 == ctx->r1) {
        // 0x80384CEC: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384D34;
    }
    // 0x80384CEC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80384CF0: beq         $t6, $at, L_80384E20
    if (ctx->r14 == ctx->r1) {
        // 0x80384CF4: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80384E20;
    }
    // 0x80384CF4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80384CF8: beql        $t6, $at, L_80384EB8
    if (ctx->r14 == ctx->r1) {
        // 0x80384CFC: lh          $t6, 0x2D0($v0)
        ctx->r14 = MEM_H(ctx->r2, 0X2D0);
            goto L_80384EB8;
    }
    goto skip_0;
    // 0x80384CFC: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80384D00: b           L_80384F08
    // 0x80384D04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384F08;
    // 0x80384D04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384D08:
    // 0x80384D08: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384D0C: jal         0x80363CE0
    // 0x80384D10: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80384D10: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80384D14: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384D18: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384D1C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384D20: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384D24: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384D28: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384D2C: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80384D30: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80384D34:
    // 0x80384D34: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384D38: slti        $at, $t1, 0x40
    ctx->r1 = SIGNED(ctx->r9) < 0X40 ? 1 : 0;
    // 0x80384D3C: beq         $at, $zero, L_80384D98
    if (ctx->r1 == 0) {
        // 0x80384D40: nop
    
            goto L_80384D98;
    }
    // 0x80384D40: nop

    // 0x80384D44: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384D48: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384D4C: addiu       $a2, $zero, -0xC8
    ctx->r6 = ADD32(0, -0XC8);
    // 0x80384D50: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80384D54: ori         $t4, $t3, 0x30
    ctx->r12 = ctx->r11 | 0X30;
    // 0x80384D58: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x80384D5C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384D60: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384D64: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x80384D68: sll         $t5, $a1, 2
    ctx->r13 = S32(ctx->r5 << 2);
    // 0x80384D6C: subu        $t5, $t5, $a1
    ctx->r13 = SUB32(ctx->r13, ctx->r5);
    // 0x80384D70: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80384D74: subu        $t5, $t5, $a1
    ctx->r13 = SUB32(ctx->r13, ctx->r5);
    // 0x80384D78: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80384D7C: addu        $t5, $t5, $a1
    ctx->r13 = ADD32(ctx->r13, ctx->r5);
    // 0x80384D80: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x80384D84: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80384D88: jal         0x80363FB8
    // 0x80384D8C: andi        $a1, $t6, 0xFFFF
    ctx->r5 = ctx->r14 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_1;
    // 0x80384D8C: andi        $a1, $t6, 0xFFFF
    ctx->r5 = ctx->r14 & 0XFFFF;
    after_1:
    // 0x80384D90: b           L_80384F08
    // 0x80384D94: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384F08;
    // 0x80384D94: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384D98:
    // 0x80384D98: jal         0x80383830
    // 0x80384D9C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    target_within_current_fov(rdram, ctx);
        goto after_2;
    // 0x80384D9C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_2:
    // 0x80384DA0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384DA4: beq         $v0, $zero, L_80384F04
    if (ctx->r2 == 0) {
        // 0x80384DA8: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80384F04;
    }
    // 0x80384DA8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384DAC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384DB0: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384DB4: slti        $at, $t8, 0xB4
    ctx->r1 = SIGNED(ctx->r24) < 0XB4 ? 1 : 0;
    // 0x80384DB8: beql        $at, $zero, L_80384F08
    if (ctx->r1 == 0) {
        // 0x80384DBC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384F08;
    }
    goto skip_1;
    // 0x80384DBC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80384DC0: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384DC4: addiu       $t3, $zero, 0x50
    ctx->r11 = ADD32(0, 0X50);
    // 0x80384DC8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384DCC: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x80384DD0: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x80384DD4: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80384DD8: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80384DDC: addiu       $a2, $zero, -0xC8
    ctx->r6 = ADD32(0, -0XC8);
    // 0x80384DE0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384DE4: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    // 0x80384DE8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384DEC: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x80384DF0: sll         $t5, $a1, 2
    ctx->r13 = S32(ctx->r5 << 2);
    // 0x80384DF4: subu        $t5, $t5, $a1
    ctx->r13 = SUB32(ctx->r13, ctx->r5);
    // 0x80384DF8: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80384DFC: subu        $t5, $t5, $a1
    ctx->r13 = SUB32(ctx->r13, ctx->r5);
    // 0x80384E00: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80384E04: addu        $t5, $t5, $a1
    ctx->r13 = ADD32(ctx->r13, ctx->r5);
    // 0x80384E08: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x80384E0C: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80384E10: jal         0x80363FB8
    // 0x80384E14: andi        $a1, $t6, 0xFFFF
    ctx->r5 = ctx->r14 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_3;
    // 0x80384E14: andi        $a1, $t6, 0xFFFF
    ctx->r5 = ctx->r14 & 0XFFFF;
    after_3:
    // 0x80384E18: b           L_80384F08
    // 0x80384E1C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384F08;
    // 0x80384E1C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384E20:
    // 0x80384E20: lw          $v1, 0x2C4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C4);
    // 0x80384E24: slti        $at, $v1, 0x3C
    ctx->r1 = SIGNED(ctx->r3) < 0X3C ? 1 : 0;
    // 0x80384E28: bne         $at, $zero, L_80384E54
    if (ctx->r1 != 0) {
        // 0x80384E2C: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80384E54;
    }
    // 0x80384E2C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80384E30: div         $zero, $v1, $at
    lo = S32(S64(S32(ctx->r3)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r3)) % S64(S32(ctx->r1)));
    // 0x80384E34: mfhi        $t8
    ctx->r24 = hi;
    // 0x80384E38: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80384E3C: bne         $t8, $zero, L_80384E54
    if (ctx->r24 != 0) {
        // 0x80384E40: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_80384E54;
    }
    // 0x80384E40: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80384E44: jal         0x80302120
    // 0x80384E48: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    heli_rabbit_drop_bomb(rdram, ctx);
        goto after_4;
    // 0x80384E48: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_4:
    // 0x80384E4C: b           L_80384F08
    // 0x80384E50: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384F08;
    // 0x80384E50: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384E54:
    // 0x80384E54: slti        $at, $v1, 0x3C
    ctx->r1 = SIGNED(ctx->r3) < 0X3C ? 1 : 0;
    // 0x80384E58: beql        $at, $zero, L_80384F08
    if (ctx->r1 == 0) {
        // 0x80384E5C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384F08;
    }
    goto skip_2;
    // 0x80384E5C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x80384E60: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384E64: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384E68: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x80384E6C: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x80384E70: ori         $t2, $t1, 0x30
    ctx->r10 = ctx->r9 | 0X30;
    // 0x80384E74: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80384E78: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384E7C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384E80: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x80384E84: sll         $t3, $a1, 2
    ctx->r11 = S32(ctx->r5 << 2);
    // 0x80384E88: subu        $t3, $t3, $a1
    ctx->r11 = SUB32(ctx->r11, ctx->r5);
    // 0x80384E8C: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x80384E90: subu        $t3, $t3, $a1
    ctx->r11 = SUB32(ctx->r11, ctx->r5);
    // 0x80384E94: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x80384E98: addu        $t3, $t3, $a1
    ctx->r11 = ADD32(ctx->r11, ctx->r5);
    // 0x80384E9C: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x80384EA0: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x80384EA4: jal         0x80363FB8
    // 0x80384EA8: andi        $a1, $t4, 0xFFFF
    ctx->r5 = ctx->r12 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_5;
    // 0x80384EA8: andi        $a1, $t4, 0xFFFF
    ctx->r5 = ctx->r12 & 0XFFFF;
    after_5:
    // 0x80384EAC: b           L_80384F08
    // 0x80384EB0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80384F08;
    // 0x80384EB0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80384EB4: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
L_80384EB8:
    // 0x80384EB8: slti        $at, $t6, 0xC9
    ctx->r1 = SIGNED(ctx->r14) < 0XC9 ? 1 : 0;
    // 0x80384EBC: beql        $at, $zero, L_80384ED4
    if (ctx->r1 == 0) {
        // 0x80384EC0: lbu         $t8, 0x2B4($v0)
        ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80384ED4;
    }
    goto skip_3;
    // 0x80384EC0: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    skip_3:
    // 0x80384EC4: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
    // 0x80384EC8: bnel        $t7, $zero, L_80384F08
    if (ctx->r15 != 0) {
        // 0x80384ECC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80384F08;
    }
    goto skip_4;
    // 0x80384ECC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x80384ED0: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
L_80384ED4:
    // 0x80384ED4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384ED8: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    // 0x80384EDC: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80384EE0: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x80384EE4: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x80384EE8: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80384EEC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384EF0: sw          $zero, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = 0;
    // 0x80384EF4: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x80384EF8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384EFC: jal         0x80363CE0
    // 0x80384F00: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_6;
    // 0x80384F00: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_6:
L_80384F04:
    // 0x80384F04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384F08:
    // 0x80384F08: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80384F0C: jr          $ra
    // 0x80384F10: nop

    return;
    // 0x80384F10: nop

;}
RECOMP_FUNC void perform_behavior_cod(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384F14: jr          $ra
    // 0x80384F18: nop

    return;
    // 0x80384F18: nop

;}
RECOMP_FUNC void perform_behavior_parrot(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80384F1C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384F20: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384F24: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384F28: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80384F2C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80384F30: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80384F34: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384F38: addiu       $a2, $zero, -0xF0
    ctx->r6 = ADD32(0, -0XF0);
    // 0x80384F3C: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80384F40: beq         $t6, $zero, L_80384F64
    if (ctx->r14 == 0) {
        // 0x80384F44: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80384F64;
    }
    // 0x80384F44: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384F48: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80384F4C: beq         $t6, $at, L_80384F90
    if (ctx->r14 == ctx->r1) {
        // 0x80384F50: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80384F90;
    }
    // 0x80384F50: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80384F54: beql        $t6, $at, L_80385008
    if (ctx->r14 == ctx->r1) {
        // 0x80384F58: lh          $t8, 0x2D0($v0)
        ctx->r24 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385008;
    }
    goto skip_0;
    // 0x80384F58: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80384F5C: b           L_8038506C
    // 0x80384F60: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038506C;
    // 0x80384F60: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80384F64:
    // 0x80384F64: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384F68: jal         0x80363CE0
    // 0x80384F6C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80384F6C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80384F70: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384F74: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384F78: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384F7C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384F80: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80384F84: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80384F88: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80384F8C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80384F90:
    // 0x80384F90: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x80384F94: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80384F98: slti        $at, $t1, 0x5
    ctx->r1 = SIGNED(ctx->r9) < 0X5 ? 1 : 0;
    // 0x80384F9C: beql        $at, $zero, L_8038506C
    if (ctx->r1 == 0) {
        // 0x80384FA0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038506C;
    }
    goto skip_1;
    // 0x80384FA0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80384FA4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80384FA8: addiu       $a2, $zero, -0xF0
    ctx->r6 = ADD32(0, -0XF0);
    // 0x80384FAC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80384FB0: lh          $a1, 0x2C($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2C);
    // 0x80384FB4: sll         $t2, $a1, 2
    ctx->r10 = S32(ctx->r5 << 2);
    // 0x80384FB8: subu        $t2, $t2, $a1
    ctx->r10 = SUB32(ctx->r10, ctx->r5);
    // 0x80384FBC: sll         $t2, $t2, 2
    ctx->r10 = S32(ctx->r10 << 2);
    // 0x80384FC0: subu        $t2, $t2, $a1
    ctx->r10 = SUB32(ctx->r10, ctx->r5);
    // 0x80384FC4: sll         $t2, $t2, 2
    ctx->r10 = S32(ctx->r10 << 2);
    // 0x80384FC8: addu        $t2, $t2, $a1
    ctx->r10 = ADD32(ctx->r10, ctx->r5);
    // 0x80384FCC: sll         $t2, $t2, 3
    ctx->r10 = S32(ctx->r10 << 3);
    // 0x80384FD0: sra         $t3, $t2, 8
    ctx->r11 = S32(SIGNED(ctx->r10) >> 8);
    // 0x80384FD4: jal         0x80363FB8
    // 0x80384FD8: andi        $a1, $t3, 0xFFFF
    ctx->r5 = ctx->r11 & 0XFFFF;
    set_nav_state_scripted(rdram, ctx);
        goto after_1;
    // 0x80384FD8: andi        $a1, $t3, 0xFFFF
    ctx->r5 = ctx->r11 & 0XFFFF;
    after_1:
    // 0x80384FDC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80384FE0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80384FE4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80384FE8: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80384FEC: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80384FF0: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80384FF4: jal         0x80314600
    // 0x80384FF8: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    parrot_fly(rdram, ctx);
        goto after_2;
    // 0x80384FF8: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    after_2:
    // 0x80384FFC: b           L_8038506C
    // 0x80385000: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038506C;
    // 0x80385000: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80385004: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
L_80385008:
    // 0x80385008: slti        $at, $t8, 0x15F
    ctx->r1 = SIGNED(ctx->r24) < 0X15F ? 1 : 0;
    // 0x8038500C: beql        $at, $zero, L_80385038
    if (ctx->r1 == 0) {
        // 0x80385010: lbu         $t3, 0x2B4($v0)
        ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80385038;
    }
    goto skip_2;
    // 0x80385010: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    skip_2:
    // 0x80385014: lw          $t9, 0x2C0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X2C0);
    // 0x80385018: addiu       $t1, $t9, 0x1
    ctx->r9 = ADD32(ctx->r25, 0X1);
    // 0x8038501C: sw          $t1, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r9;
    // 0x80385020: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385024: lw          $t2, 0x2C0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2C0);
    // 0x80385028: slti        $at, $t2, 0x97
    ctx->r1 = SIGNED(ctx->r10) < 0X97 ? 1 : 0;
    // 0x8038502C: bnel        $at, $zero, L_8038506C
    if (ctx->r1 != 0) {
        // 0x80385030: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038506C;
    }
    goto skip_3;
    // 0x80385030: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x80385034: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
L_80385038:
    // 0x80385038: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038503C: addiu       $a2, $zero, -0xF0
    ctx->r6 = ADD32(0, -0XF0);
    // 0x80385040: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80385044: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x80385048: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x8038504C: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80385050: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385054: sw          $zero, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = 0;
    // 0x80385058: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8038505C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385060: jal         0x80363CE0
    // 0x80385064: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x80385064: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_3:
    // 0x80385068: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038506C:
    // 0x8038506C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80385070: jr          $ra
    // 0x80385074: nop

    return;
    // 0x80385074: nop

;}
RECOMP_FUNC void perform_behavior_parrot_attacking(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385078: jr          $ra
    // 0x8038507C: nop

    return;
    // 0x8038507C: nop

;}
RECOMP_FUNC void perform_behavior_mouse(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385080: jr          $ra
    // 0x80385084: nop

    return;
    // 0x80385084: nop

;}
RECOMP_FUNC void perform_behavior_racing_mouse(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385088: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038508C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385090: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385094: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80385098: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038509C: lw          $t6, 0x2B4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B4);
    // 0x803850A0: srl         $t7, $t6, 28
    ctx->r15 = S32(U32(ctx->r14) >> 28);
    // 0x803850A4: sltiu       $at, $t7, 0x5
    ctx->r1 = ctx->r15 < 0X5 ? 1 : 0;
    // 0x803850A8: beq         $at, $zero, L_803852A8
    if (ctx->r1 == 0) {
        // 0x803850AC: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_803852A8;
    }
    // 0x803850AC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803850B0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803850B4: addu        $at, $at, $t7
    gpr jr_addend_803850BC = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x803850B8: lw          $t7, -0xBF4($at)
    ctx->r15 = ADD32(ctx->r1, -0XBF4);
    // 0x803850BC: jr          $t7
    // 0x803850C0: nop

    switch (jr_addend_803850BC >> 2) {
        case 0: goto L_803850C4; break;
        case 1: goto L_803850F4; break;
        case 2: goto L_803851AC; break;
        case 3: goto L_80385210; break;
        case 4: goto L_8038524C; break;
        default: switch_error(__func__, 0x803850BC, 0x803BF40C);
    }
    // 0x803850C0: nop

L_803850C4:
    // 0x803850C4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803850C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803850CC: jal         0x80363E88
    // 0x803850D0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_0;
    // 0x803850D0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x803850D4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803850D8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803850DC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803850E0: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803850E4: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x803850E8: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x803850EC: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x803850F0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803850F4:
    // 0x803850F4: lw          $t2, 0x2C4($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2C4);
    // 0x803850F8: bnel        $t2, $zero, L_80385154
    if (ctx->r10 != 0) {
        // 0x803850FC: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_80385154;
    }
    goto skip_0;
    // 0x803850FC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_0:
    // 0x80385100: jal         0x80383830
    // 0x80385104: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    target_within_current_fov(rdram, ctx);
        goto after_1;
    // 0x80385104: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_1:
    // 0x80385108: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038510C: beq         $v0, $zero, L_80385150
    if (ctx->r2 == 0) {
        // 0x80385110: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80385150;
    }
    // 0x80385110: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385114: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x80385118: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038511C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385120: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385124: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385128: jal         0x80363CE0
    // 0x8038512C: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x8038512C: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_2:
    // 0x80385130: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385134: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385138: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038513C: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385140: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80385144: ori         $t6, $t5, 0x20
    ctx->r14 = ctx->r13 | 0X20;
    // 0x80385148: b           L_803852A8
    // 0x8038514C: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
        goto L_803852A8;
    // 0x8038514C: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
L_80385150:
    // 0x80385150: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80385154:
    // 0x80385154: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
    // 0x80385158: beql        $t7, $zero, L_803852AC
    if (ctx->r15 == 0) {
        // 0x8038515C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803852AC;
    }
    goto skip_1;
    // 0x8038515C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80385160: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385164: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385168: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038516C: slti        $at, $t8, 0x46
    ctx->r1 = SIGNED(ctx->r24) < 0X46 ? 1 : 0;
    // 0x80385170: beql        $at, $zero, L_803852AC
    if (ctx->r1 == 0) {
        // 0x80385174: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803852AC;
    }
    goto skip_2;
    // 0x80385174: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x80385178: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038517C: jal         0x80363EDC
    // 0x80385180: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80385180: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_3:
    // 0x80385184: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385188: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038518C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385190: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385194: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x80385198: ori         $t2, $t1, 0x40
    ctx->r10 = ctx->r9 | 0X40;
    // 0x8038519C: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x803851A0: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x803851A4: b           L_803852A8
    // 0x803851A8: sw          $zero, 0x2B8($t3)
    MEM_W(0X2B8, ctx->r11) = 0;
        goto L_803852A8;
    // 0x803851A8: sw          $zero, 0x2B8($t3)
    MEM_W(0X2B8, ctx->r11) = 0;
L_803851AC:
    // 0x803851AC: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
    // 0x803851B0: slti        $at, $t4, 0x46
    ctx->r1 = SIGNED(ctx->r12) < 0X46 ? 1 : 0;
    // 0x803851B4: beql        $at, $zero, L_803852AC
    if (ctx->r1 == 0) {
        // 0x803851B8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803852AC;
    }
    goto skip_3;
    // 0x803851B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x803851BC: lw          $t5, 0x2C4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X2C4);
    // 0x803851C0: bnel        $t5, $zero, L_803852AC
    if (ctx->r13 != 0) {
        // 0x803851C4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803852AC;
    }
    goto skip_4;
    // 0x803851C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803851C8: jal         0x8038395C
    // 0x803851CC: nop

    func_8038395C_79500C(rdram, ctx);
        goto after_4;
    // 0x803851CC: nop

    after_4:
    // 0x803851D0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803851D4: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x803851D8: bne         $at, $zero, L_803852A8
    if (ctx->r1 != 0) {
        // 0x803851DC: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_803852A8;
    }
    // 0x803851DC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803851E0: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x803851E4: addiu       $t6, $zero, 0x46
    ctx->r14 = ADD32(0, 0X46);
    // 0x803851E8: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    // 0x803851EC: sw          $t6, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r14;
    // 0x803851F0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803851F4: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803851F8: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x803851FC: ori         $t1, $t9, 0x30
    ctx->r9 = ctx->r25 | 0X30;
    // 0x80385200: jal         0x8031FB78
    // 0x80385204: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    func_8031FB78_731228(rdram, ctx);
        goto after_5;
    // 0x80385204: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    after_5:
    // 0x80385208: b           L_803852AC
    // 0x8038520C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803852AC;
    // 0x8038520C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80385210:
    // 0x80385210: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385214: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385218: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038521C: jal         0x80363EDC
    // 0x80385220: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80385220: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_6:
    // 0x80385224: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385228: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038522C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385230: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385234: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80385238: ori         $t4, $t3, 0x40
    ctx->r12 = ctx->r11 | 0X40;
    // 0x8038523C: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x80385240: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x80385244: b           L_803852A8
    // 0x80385248: sw          $zero, 0x2B8($t5)
    MEM_W(0X2B8, ctx->r13) = 0;
        goto L_803852A8;
    // 0x80385248: sw          $zero, 0x2B8($t5)
    MEM_W(0X2B8, ctx->r13) = 0;
L_8038524C:
    // 0x8038524C: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385250: slti        $at, $t6, 0xFA
    ctx->r1 = SIGNED(ctx->r14) < 0XFA ? 1 : 0;
    // 0x80385254: beql        $at, $zero, L_80385284
    if (ctx->r1 == 0) {
        // 0x80385258: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_80385284;
    }
    goto skip_5;
    // 0x80385258: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_5:
    // 0x8038525C: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385260: slti        $a0, $v1, 0x1F
    ctx->r4 = SIGNED(ctx->r3) < 0X1F ? 1 : 0;
    // 0x80385264: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80385268: beq         $a0, $zero, L_80385280
    if (ctx->r4 == 0) {
        // 0x8038526C: sw          $t7, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r15;
            goto L_80385280;
    }
    // 0x8038526C: sw          $t7, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r15;
    // 0x80385270: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80385274: lw          $t9, 0x2C4($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X2C4);
    // 0x80385278: bnel        $t9, $zero, L_803852AC
    if (ctx->r25 != 0) {
        // 0x8038527C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_803852AC;
    }
    goto skip_6;
    // 0x8038527C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
L_80385280:
    // 0x80385280: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80385284:
    // 0x80385284: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385288: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8038528C: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80385290: ori         $t3, $t2, 0x10
    ctx->r11 = ctx->r10 | 0X10;
    // 0x80385294: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
    // 0x80385298: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8038529C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803852A0: jal         0x80363E88
    // 0x803852A4: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x803852A4: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    after_7:
L_803852A8:
    // 0x803852A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803852AC:
    // 0x803852AC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803852B0: jr          $ra
    // 0x803852B4: nop

    return;
    // 0x803852B4: nop

;}
RECOMP_FUNC void perform_behavior_mouse2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803852B8: jr          $ra
    // 0x803852BC: nop

    return;
    // 0x803852BC: nop

;}
RECOMP_FUNC void perform_behavior_heli_mouse(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803852C0: jr          $ra
    // 0x803852C4: nop

    return;
    // 0x803852C4: nop

;}
RECOMP_FUNC void perform_behavior_bear(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803852C8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803852CC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803852D0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803852D4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803852D8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803852DC: lw          $t6, 0x2B4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B4);
    // 0x803852E0: srl         $t7, $t6, 28
    ctx->r15 = S32(U32(ctx->r14) >> 28);
    // 0x803852E4: sltiu       $at, $t7, 0x5
    ctx->r1 = ctx->r15 < 0X5 ? 1 : 0;
    // 0x803852E8: beq         $at, $zero, L_80385470
    if (ctx->r1 == 0) {
        // 0x803852EC: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_80385470;
    }
    // 0x803852EC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803852F0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803852F4: addu        $at, $at, $t7
    gpr jr_addend_803852FC = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x803852F8: lw          $t7, -0xBE0($at)
    ctx->r15 = ADD32(ctx->r1, -0XBE0);
    // 0x803852FC: jr          $t7
    // 0x80385300: nop

    switch (jr_addend_803852FC >> 2) {
        case 0: goto L_80385304; break;
        case 1: goto L_80385338; break;
        case 2: goto L_80385374; break;
        case 3: goto L_803853E8; break;
        case 4: goto L_8038541C; break;
        default: switch_error(__func__, 0x803852FC, 0x803BF420);
    }
    // 0x80385300: nop

L_80385304:
    // 0x80385304: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385308: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038530C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    // 0x80385310: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385314: jal         0x80363CE0
    // 0x80385318: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80385318: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    after_0:
    // 0x8038531C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385320: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385324: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385328: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8038532C: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80385330: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x80385334: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
L_80385338:
    // 0x80385338: jal         0x80383830
    // 0x8038533C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    target_within_current_fov(rdram, ctx);
        goto after_1;
    // 0x8038533C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_1:
    // 0x80385340: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385344: beq         $v0, $zero, L_80385470
    if (ctx->r2 == 0) {
        // 0x80385348: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80385470;
    }
    // 0x80385348: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038534C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385350: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385354: slti        $at, $t2, 0x2E
    ctx->r1 = SIGNED(ctx->r10) < 0X2E ? 1 : 0;
    // 0x80385358: beql        $at, $zero, L_80385474
    if (ctx->r1 == 0) {
        // 0x8038535C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385474;
    }
    goto skip_0;
    // 0x8038535C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x80385360: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385364: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80385368: ori         $t5, $t4, 0x20
    ctx->r13 = ctx->r12 | 0X20;
    // 0x8038536C: b           L_80385470
    // 0x80385370: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
        goto L_80385470;
    // 0x80385370: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
L_80385374:
    // 0x80385374: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385378: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038537C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385380: slti        $at, $t6, 0x38
    ctx->r1 = SIGNED(ctx->r14) < 0X38 ? 1 : 0;
    // 0x80385384: bne         $at, $zero, L_803853B8
    if (ctx->r1 != 0) {
        // 0x80385388: addiu       $a3, $zero, 0x14
        ctx->r7 = ADD32(0, 0X14);
            goto L_803853B8;
    }
    // 0x80385388: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x8038538C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385390: jal         0x80363CE0
    // 0x80385394: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80385394: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_2:
    // 0x80385398: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038539C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803853A0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803853A4: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803853A8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803853AC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803853B0: b           L_80385470
    // 0x803853B4: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
        goto L_80385470;
    // 0x803853B4: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
L_803853B8:
    // 0x803853B8: jal         0x80327B94
    // 0x803853BC: addiu       $a0, $zero, 0x46
    ctx->r4 = ADD32(0, 0X46);
    func_80327B94_739244(rdram, ctx);
        goto after_3;
    // 0x803853BC: addiu       $a0, $zero, 0x46
    ctx->r4 = ADD32(0, 0X46);
    after_3:
    // 0x803853C0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803853C4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803853C8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803853CC: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803853D0: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803853D4: ori         $t3, $t2, 0x30
    ctx->r11 = ctx->r10 | 0X30;
    // 0x803853D8: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
    // 0x803853DC: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x803853E0: b           L_80385470
    // 0x803853E4: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
        goto L_80385470;
    // 0x803853E4: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
L_803853E8:
    // 0x803853E8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803853EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803853F0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803853F4: jal         0x80363EDC
    // 0x803853F8: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x803853F8: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_4:
    // 0x803853FC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385400: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385404: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385408: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8038540C: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80385410: ori         $t7, $t6, 0x40
    ctx->r15 = ctx->r14 | 0X40;
    // 0x80385414: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x80385418: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8038541C:
    // 0x8038541C: lh          $t8, 0x2D0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385420: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385424: slti        $at, $t8, 0xC8
    ctx->r1 = SIGNED(ctx->r24) < 0XC8 ? 1 : 0;
    // 0x80385428: beql        $at, $zero, L_8038544C
    if (ctx->r1 == 0) {
        // 0x8038542C: lbu         $t1, 0x2B4($v0)
        ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
            goto L_8038544C;
    }
    goto skip_1;
    // 0x8038542C: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    skip_1:
    // 0x80385430: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385434: slti        $a0, $v1, 0x3D
    ctx->r4 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
    // 0x80385438: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x8038543C: bne         $a0, $zero, L_80385470
    if (ctx->r4 != 0) {
        // 0x80385440: sw          $t9, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r25;
            goto L_80385470;
    }
    // 0x80385440: sw          $t9, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r25;
    // 0x80385444: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385448: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
L_8038544C:
    // 0x8038544C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385450: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x80385454: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80385458: ori         $t3, $t2, 0x10
    ctx->r11 = ctx->r10 | 0X10;
    // 0x8038545C: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
    // 0x80385460: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80385464: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385468: jal         0x80363CE0
    // 0x8038546C: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x8038546C: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    after_5:
L_80385470:
    // 0x80385470: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80385474:
    // 0x80385474: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80385478: jr          $ra
    // 0x8038547C: nop

    return;
    // 0x8038547C: nop

;}
RECOMP_FUNC void perform_behavior_bear_attacking(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385480: jr          $ra
    // 0x80385484: nop

    return;
    // 0x80385484: nop

;}
RECOMP_FUNC void perform_behavior_mystery_bear(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385488: jr          $ra
    // 0x8038548C: nop

    return;
    // 0x8038548C: nop

;}
RECOMP_FUNC void perform_behavior_racing_fox(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385490: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385494: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385498: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8038549C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803854A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803854A4: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803854A8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803854AC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803854B0: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803854B4: beq         $t6, $zero, L_803854D8
    if (ctx->r14 == 0) {
        // 0x803854B8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803854D8;
    }
    // 0x803854B8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803854BC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803854C0: beq         $t6, $at, L_80385504
    if (ctx->r14 == ctx->r1) {
        // 0x803854C4: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80385504;
    }
    // 0x803854C4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803854C8: beql        $t6, $at, L_80385678
    if (ctx->r14 == ctx->r1) {
        // 0x803854CC: lw          $t6, 0x2B8($v1)
        ctx->r14 = MEM_W(ctx->r3, 0X2B8);
            goto L_80385678;
    }
    goto skip_0;
    // 0x803854CC: lw          $t6, 0x2B8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2B8);
    skip_0:
    // 0x803854D0: b           L_80385704
    // 0x803854D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80385704;
    // 0x803854D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803854D8:
    // 0x803854D8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803854DC: jal         0x80363CE0
    // 0x803854E0: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803854E0: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x803854E4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803854E8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803854EC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803854F0: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803854F4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803854F8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803854FC: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80385500: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80385504:
    // 0x80385504: lw          $v0, 0x2C0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2C0);
    // 0x80385508: blez        $v0, L_8038554C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038550C: addiu       $t1, $v0, -0x1
        ctx->r9 = ADD32(ctx->r2, -0X1);
            goto L_8038554C;
    }
    // 0x8038550C: addiu       $t1, $v0, -0x1
    ctx->r9 = ADD32(ctx->r2, -0X1);
    // 0x80385510: sw          $t1, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r9;
    // 0x80385514: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80385518: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038551C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80385520: lw          $t2, 0x2C0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C0);
    // 0x80385524: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385528: bnel        $t2, $zero, L_803855A4
    if (ctx->r10 != 0) {
        // 0x8038552C: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803855A4;
    }
    goto skip_1;
    // 0x8038552C: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_1:
    // 0x80385530: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385534: jal         0x80363CE0
    // 0x80385538: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_1;
    // 0x80385538: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_1:
    // 0x8038553C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385540: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385544: b           L_803855A0
    // 0x80385548: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
        goto L_803855A0;
    // 0x80385548: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_8038554C:
    // 0x8038554C: bne         $v0, $zero, L_803855A0
    if (ctx->r2 != 0) {
        // 0x80385550: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_803855A0;
    }
    // 0x80385550: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80385554: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80385558: lbu         $t3, 0x5C($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X5C);
    // 0x8038555C: andi        $t4, $t3, 0x4
    ctx->r12 = ctx->r11 & 0X4;
    // 0x80385560: beql        $t4, $zero, L_803855A4
    if (ctx->r12 == 0) {
        // 0x80385564: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803855A4;
    }
    goto skip_2;
    // 0x80385564: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_2:
    // 0x80385568: lw          $t5, 0x2CC($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2CC);
    // 0x8038556C: lw          $t6, 0x60($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X60);
    // 0x80385570: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x80385574: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385578: bnel        $t5, $t6, L_803855A4
    if (ctx->r13 != ctx->r14) {
        // 0x8038557C: lw          $t9, 0x2C4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2C4);
            goto L_803855A4;
    }
    goto skip_3;
    // 0x8038557C: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x80385580: sw          $t7, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r15;
    // 0x80385584: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80385588: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038558C: jal         0x80363E88
    // 0x80385590: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80385590: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_2:
    // 0x80385594: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385598: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038559C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_803855A0:
    // 0x803855A0: lw          $t9, 0x2C4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C4);
L_803855A4:
    // 0x803855A4: bgtzl       $t9, L_80385704
    if (SIGNED(ctx->r25) > 0) {
        // 0x803855A8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385704;
    }
    goto skip_4;
    // 0x803855A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803855AC: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    // 0x803855B0: slti        $at, $t1, 0x33
    ctx->r1 = SIGNED(ctx->r9) < 0X33 ? 1 : 0;
    // 0x803855B4: beql        $at, $zero, L_80385704
    if (ctx->r1 == 0) {
        // 0x803855B8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385704;
    }
    goto skip_5;
    // 0x803855B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x803855BC: jal         0x80383830
    // 0x803855C0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x803855C0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x803855C4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803855C8: beq         $v0, $zero, L_80385700
    if (ctx->r2 == 0) {
        // 0x803855CC: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80385700;
    }
    // 0x803855CC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803855D0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803855D4: lw          $t2, 0x2BC($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2BC);
    // 0x803855D8: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x803855DC: sw          $t3, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r11;
    // 0x803855E0: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x803855E4: lw          $t5, 0x2BC($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X2BC);
    // 0x803855E8: slti        $at, $t5, 0x4
    ctx->r1 = SIGNED(ctx->r13) < 0X4 ? 1 : 0;
    // 0x803855EC: beq         $at, $zero, L_803855FC
    if (ctx->r1 == 0) {
        // 0x803855F0: nop
    
            goto L_803855FC;
    }
    // 0x803855F0: nop

    // 0x803855F4: jal         0x802E88C0
    // 0x803855F8: addiu       $a0, $zero, 0x64
    ctx->r4 = ADD32(0, 0X64);
    func_802E88C0_6F9F70(rdram, ctx);
        goto after_4;
    // 0x803855F8: addiu       $a0, $zero, 0x64
    ctx->r4 = ADD32(0, 0X64);
    after_4:
L_803855FC:
    // 0x803855FC: jal         0x8012826C
    // 0x80385600: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x80385600: nop

    after_5:
    // 0x80385604: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385608: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038560C: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80385610: andi        $t6, $v0, 0x7
    ctx->r14 = ctx->r2 & 0X7;
    // 0x80385614: addiu       $t7, $t6, 0xA
    ctx->r15 = ADD32(ctx->r14, 0XA);
    // 0x80385618: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
    // 0x8038561C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80385620: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385624: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80385628: lw          $t9, 0x2BC($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2BC);
    // 0x8038562C: slti        $at, $t9, 0x4
    ctx->r1 = SIGNED(ctx->r25) < 0X4 ? 1 : 0;
    // 0x80385630: bnel        $at, $zero, L_80385704
    if (ctx->r1 != 0) {
        // 0x80385634: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385704;
    }
    goto skip_6;
    // 0x80385634: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x80385638: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038563C: jal         0x80363EDC
    // 0x80385640: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80385640: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80385644: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385648: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038564C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80385650: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80385654: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80385658: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x8038565C: sb          $t3, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r11;
    // 0x80385660: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80385664: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
    // 0x80385668: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8038566C: b           L_80385700
    // 0x80385670: sw          $zero, 0x2BC($t5)
    MEM_W(0X2BC, ctx->r13) = 0;
        goto L_80385700;
    // 0x80385670: sw          $zero, 0x2BC($t5)
    MEM_W(0X2BC, ctx->r13) = 0;
    // 0x80385674: lw          $t6, 0x2B8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2B8);
L_80385678:
    // 0x80385678: bnel        $t6, $zero, L_803856C4
    if (ctx->r14 != 0) {
        // 0x8038567C: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_803856C4;
    }
    goto skip_7;
    // 0x8038567C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_7:
    // 0x80385680: jal         0x80383830
    // 0x80385684: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    target_within_current_fov(rdram, ctx);
        goto after_7;
    // 0x80385684: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    after_7:
    // 0x80385688: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038568C: bne         $v0, $zero, L_803856C0
    if (ctx->r2 != 0) {
        // 0x80385690: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_803856C0;
    }
    // 0x80385690: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385694: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80385698: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8038569C: jal         0x80140D20
    // 0x803856A0: sw          $t7, 0x2B8($t8)
    MEM_W(0X2B8, ctx->r24) = ctx->r15;
    guRandom(rdram, ctx);
        goto after_8;
    // 0x803856A0: sw          $t7, 0x2B8($t8)
    MEM_W(0X2B8, ctx->r24) = ctx->r15;
    after_8:
    // 0x803856A4: andi        $t9, $v0, 0x3
    ctx->r25 = ctx->r2 & 0X3;
    // 0x803856A8: bnel        $t9, $zero, L_80385704
    if (ctx->r25 != 0) {
        // 0x803856AC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385704;
    }
    goto skip_8;
    // 0x803856AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x803856B0: jal         0x802E89AC
    // 0x803856B4: nop

    fox_warp(rdram, ctx);
        goto after_9;
    // 0x803856B4: nop

    after_9:
    // 0x803856B8: b           L_80385704
    // 0x803856BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80385704;
    // 0x803856BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803856C0:
    // 0x803856C0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_803856C4:
    // 0x803856C4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803856C8: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    // 0x803856CC: slti        $at, $t1, 0xFA
    ctx->r1 = SIGNED(ctx->r9) < 0XFA ? 1 : 0;
    // 0x803856D0: bnel        $at, $zero, L_80385704
    if (ctx->r1 != 0) {
        // 0x803856D4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385704;
    }
    goto skip_9;
    // 0x803856D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x803856D8: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803856DC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803856E0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803856E4: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x803856E8: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x803856EC: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x803856F0: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x803856F4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803856F8: jal         0x80363CE0
    // 0x803856FC: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_10;
    // 0x803856FC: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_10:
L_80385700:
    // 0x80385700: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80385704:
    // 0x80385704: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80385708: jr          $ra
    // 0x8038570C: nop

    return;
    // 0x8038570C: nop

;}
RECOMP_FUNC void perform_behavior_tortoise_tank(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385710: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385714: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385718: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x8038571C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80385720: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80385724: lw          $a1, 0x2B4($t6)
    ctx->r5 = MEM_W(ctx->r14, 0X2B4);
    // 0x80385728: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8038572C: addiu       $a0, $a0, -0xC00
    ctx->r4 = ADD32(ctx->r4, -0XC00);
    // 0x80385730: srl         $t7, $a1, 28
    ctx->r15 = S32(U32(ctx->r5) >> 28);
    // 0x80385734: jal         0x8013966C
    // 0x80385738: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    osSyncPrintf(rdram, ctx);
        goto after_0;
    // 0x80385738: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_0:
    // 0x8038573C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385740: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80385744: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385748: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038574C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385750: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80385754: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385758: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x8038575C: srl         $t8, $v1, 28
    ctx->r24 = S32(U32(ctx->r3) >> 28);
    // 0x80385760: beq         $t8, $zero, L_80385788
    if (ctx->r24 == 0) {
        // 0x80385764: nop
    
            goto L_80385788;
    }
    // 0x80385764: nop

    // 0x80385768: beq         $t8, $at, L_803857B4
    if (ctx->r24 == ctx->r1) {
        // 0x8038576C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803857B4;
    }
    // 0x8038576C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80385770: beq         $t8, $at, L_803857F8
    if (ctx->r24 == ctx->r1) {
        // 0x80385774: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_803857F8;
    }
    // 0x80385774: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80385778: beql        $t8, $at, L_80385910
    if (ctx->r24 == ctx->r1) {
        // 0x8038577C: lh          $t4, 0x2D0($v0)
        ctx->r12 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385910;
    }
    goto skip_0;
    // 0x8038577C: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80385780: b           L_803859B8
    // 0x80385784: lw          $v1, 0x2C0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C0);
        goto L_803859B8;
    // 0x80385784: lw          $v1, 0x2C0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C0);
L_80385788:
    // 0x80385788: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038578C: jal         0x80363CE0
    // 0x80385790: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_1;
    // 0x80385790: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_1:
    // 0x80385794: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385798: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038579C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803857A0: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803857A4: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x803857A8: ori         $t2, $t1, 0x10
    ctx->r10 = ctx->r9 | 0X10;
    // 0x803857AC: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x803857B0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803857B4:
    // 0x803857B4: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
    // 0x803857B8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803857BC: slti        $at, $t3, 0x1F5
    ctx->r1 = SIGNED(ctx->r11) < 0X1F5 ? 1 : 0;
    // 0x803857C0: beql        $at, $zero, L_803859B8
    if (ctx->r1 == 0) {
        // 0x803857C4: lw          $v1, 0x2C0($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X2C0);
            goto L_803859B8;
    }
    goto skip_1;
    // 0x803857C4: lw          $v1, 0x2C0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C0);
    skip_1:
    // 0x803857C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803857CC: jal         0x80363E88
    // 0x803857D0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x803857D0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_2:
    // 0x803857D4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803857D8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803857DC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803857E0: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803857E4: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x803857E8: ori         $t6, $t5, 0x20
    ctx->r14 = ctx->r13 | 0X20;
    // 0x803857EC: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x803857F0: b           L_803859B4
    // 0x803857F4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_803859B4;
    // 0x803857F4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803857F8:
    // 0x803857F8: lw          $a0, 0x2B8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2B8);
    // 0x803857FC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80385800: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80385804: blez        $a0, L_80385814
    if (SIGNED(ctx->r4) <= 0) {
        // 0x80385808: addiu       $t7, $a0, -0x1
        ctx->r15 = ADD32(ctx->r4, -0X1);
            goto L_80385814;
    }
    // 0x80385808: addiu       $t7, $a0, -0x1
    ctx->r15 = ADD32(ctx->r4, -0X1);
    // 0x8038580C: sw          $t7, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r15;
    // 0x80385810: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80385814:
    // 0x80385814: lh          $v1, 0x2D0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385818: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038581C: slti        $at, $v1, 0x1B9
    ctx->r1 = SIGNED(ctx->r3) < 0X1B9 ? 1 : 0;
    // 0x80385820: bnel        $at, $zero, L_80385858
    if (ctx->r1 != 0) {
        // 0x80385824: slti        $at, $v1, 0x118
        ctx->r1 = SIGNED(ctx->r3) < 0X118 ? 1 : 0;
            goto L_80385858;
    }
    goto skip_2;
    // 0x80385824: slti        $at, $v1, 0x118
    ctx->r1 = SIGNED(ctx->r3) < 0X118 ? 1 : 0;
    skip_2:
    // 0x80385828: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038582C: jal         0x80363CE0
    // 0x80385830: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x80385830: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_3:
    // 0x80385834: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385838: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038583C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385840: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385844: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80385848: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x8038584C: b           L_80385900
    // 0x80385850: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
        goto L_80385900;
    // 0x80385850: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x80385854: slti        $at, $v1, 0x118
    ctx->r1 = SIGNED(ctx->r3) < 0X118 ? 1 : 0;
L_80385858:
    // 0x80385858: beql        $at, $zero, L_8038586C
    if (ctx->r1 == 0) {
        // 0x8038585C: slti        $at, $v1, 0x78
        ctx->r1 = SIGNED(ctx->r3) < 0X78 ? 1 : 0;
            goto L_8038586C;
    }
    goto skip_3;
    // 0x8038585C: slti        $at, $v1, 0x78
    ctx->r1 = SIGNED(ctx->r3) < 0X78 ? 1 : 0;
    skip_3:
    // 0x80385860: lw          $t2, 0x2B8($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385864: blez        $t2, L_80385870
    if (SIGNED(ctx->r10) <= 0) {
        // 0x80385868: slti        $at, $v1, 0x78
        ctx->r1 = SIGNED(ctx->r3) < 0X78 ? 1 : 0;
            goto L_80385870;
    }
    // 0x80385868: slti        $at, $v1, 0x78
    ctx->r1 = SIGNED(ctx->r3) < 0X78 ? 1 : 0;
L_8038586C:
    // 0x8038586C: beq         $at, $zero, L_803858AC
    if (ctx->r1 == 0) {
        // 0x80385870: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_803858AC;
    }
L_80385870:
    // 0x80385870: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385874: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385878: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038587C: jal         0x80363EDC
    // 0x80385880: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x80385880: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_4:
    // 0x80385884: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385888: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038588C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385890: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385894: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80385898: ori         $t5, $t4, 0x30
    ctx->r13 = ctx->r12 | 0X30;
    // 0x8038589C: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x803858A0: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x803858A4: b           L_80385900
    // 0x803858A8: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
        goto L_80385900;
    // 0x803858A8: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
L_803858AC:
    // 0x803858AC: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
    // 0x803858B0: bgtz        $t7, L_80385900
    if (SIGNED(ctx->r15) > 0) {
        // 0x803858B4: nop
    
            goto L_80385900;
    }
    // 0x803858B4: nop

    // 0x803858B8: jal         0x80383830
    // 0x803858BC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_5;
    // 0x803858BC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_5:
    // 0x803858C0: beq         $v0, $zero, L_80385900
    if (ctx->r2 == 0) {
        // 0x803858C4: nop
    
            goto L_80385900;
    }
    // 0x803858C4: nop

    // 0x803858C8: jal         0x80140D20
    // 0x803858CC: nop

    guRandom(rdram, ctx);
        goto after_6;
    // 0x803858CC: nop

    after_6:
    // 0x803858D0: sra         $t8, $v0, 8
    ctx->r24 = S32(SIGNED(ctx->r2) >> 8);
    // 0x803858D4: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x803858D8: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x803858DC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803858E0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803858E4: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x803858E8: mfhi        $t9
    ctx->r25 = hi;
    // 0x803858EC: addiu       $t1, $t9, 0x14
    ctx->r9 = ADD32(ctx->r25, 0X14);
    // 0x803858F0: sw          $t1, 0x2C4($t2)
    MEM_W(0X2C4, ctx->r10) = ctx->r9;
    // 0x803858F4: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x803858F8: jal         0x80356134
    // 0x803858FC: lw          $a0, 0x2CC($t3)
    ctx->r4 = MEM_W(ctx->r11, 0X2CC);
    tortoise_tank_attack(rdram, ctx);
        goto after_7;
    // 0x803858FC: lw          $a0, 0x2CC($t3)
    ctx->r4 = MEM_W(ctx->r11, 0X2CC);
    after_7:
L_80385900:
    // 0x80385900: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80385904: b           L_803859B4
    // 0x80385908: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_803859B4;
    // 0x80385908: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8038590C: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
L_80385910:
    // 0x80385910: slti        $at, $t4, 0x15F
    ctx->r1 = SIGNED(ctx->r12) < 0X15F ? 1 : 0;
    // 0x80385914: beq         $at, $zero, L_80385934
    if (ctx->r1 == 0) {
        // 0x80385918: nop
    
            goto L_80385934;
    }
    // 0x80385918: nop

    // 0x8038591C: lw          $a0, 0x2B8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385920: slti        $v1, $a0, 0x64
    ctx->r3 = SIGNED(ctx->r4) < 0X64 ? 1 : 0;
    // 0x80385924: addiu       $t5, $a0, 0x1
    ctx->r13 = ADD32(ctx->r4, 0X1);
    // 0x80385928: bne         $v1, $zero, L_80385990
    if (ctx->r3 != 0) {
        // 0x8038592C: sw          $t5, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r13;
            goto L_80385990;
    }
    // 0x8038592C: sw          $t5, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r13;
    // 0x80385930: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80385934:
    // 0x80385934: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385938: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038593C: jal         0x80363E88
    // 0x80385940: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_8;
    // 0x80385940: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_8:
    // 0x80385944: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80385948: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038594C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385950: addiu       $t1, $zero, 0x64
    ctx->r9 = ADD32(0, 0X64);
    // 0x80385954: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385958: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x8038595C: ori         $t8, $t7, 0x20
    ctx->r24 = ctx->r15 | 0X20;
    // 0x80385960: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    // 0x80385964: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385968: lw          $t9, 0x2B8($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X2B8);
    // 0x8038596C: slti        $at, $t9, 0x5A
    ctx->r1 = SIGNED(ctx->r25) < 0X5A ? 1 : 0;
    // 0x80385970: bnel        $at, $zero, L_80385984
    if (ctx->r1 != 0) {
        // 0x80385974: sw          $zero, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = 0;
            goto L_80385984;
    }
    goto skip_4;
    // 0x80385974: sw          $zero, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = 0;
    skip_4:
    // 0x80385978: b           L_80385984
    // 0x8038597C: sw          $t1, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r9;
        goto L_80385984;
    // 0x8038597C: sw          $t1, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r9;
    // 0x80385980: sw          $zero, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = 0;
L_80385984:
    // 0x80385984: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80385988: b           L_803859B4
    // 0x8038598C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_803859B4;
    // 0x8038598C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80385990:
    // 0x80385990: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80385994: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385998: slti        $at, $t2, 0x78
    ctx->r1 = SIGNED(ctx->r10) < 0X78 ? 1 : 0;
    // 0x8038599C: beql        $at, $zero, L_803859B8
    if (ctx->r1 == 0) {
        // 0x803859A0: lw          $v1, 0x2C0($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X2C0);
            goto L_803859B8;
    }
    goto skip_5;
    // 0x803859A0: lw          $v1, 0x2C0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C0);
    skip_5:
    // 0x803859A4: jal         0x803562C8
    // 0x803859A8: addiu       $a0, $zero, 0x7D00
    ctx->r4 = ADD32(0, 0X7D00);
    tortoise_tank_defend(rdram, ctx);
        goto after_9;
    // 0x803859A8: addiu       $a0, $zero, 0x7D00
    ctx->r4 = ADD32(0, 0X7D00);
    after_9:
    // 0x803859AC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803859B0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_803859B4:
    // 0x803859B4: lw          $v1, 0x2C0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C0);
L_803859B8:
    // 0x803859B8: blez        $v1, L_803859C4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x803859BC: addiu       $t3, $v1, -0x1
        ctx->r11 = ADD32(ctx->r3, -0X1);
            goto L_803859C4;
    }
    // 0x803859BC: addiu       $t3, $v1, -0x1
    ctx->r11 = ADD32(ctx->r3, -0X1);
    // 0x803859C0: sw          $t3, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r11;
L_803859C4:
    // 0x803859C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803859C8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803859CC: jr          $ra
    // 0x803859D0: nop

    return;
    // 0x803859D0: nop

;}
RECOMP_FUNC void perform_behavior_tortoise_tank_defending(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803859D4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803859D8: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x803859DC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803859E0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803859E4: lh          $t7, 0x2D0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X2D0);
    // 0x803859E8: slti        $at, $t7, 0x83
    ctx->r1 = SIGNED(ctx->r15) < 0X83 ? 1 : 0;
    // 0x803859EC: bnel        $at, $zero, L_80385A00
    if (ctx->r1 != 0) {
        // 0x803859F0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80385A00;
    }
    goto skip_0;
    // 0x803859F0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x803859F4: jal         0x803562C8
    // 0x803859F8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    tortoise_tank_defend(rdram, ctx);
        goto after_0;
    // 0x803859F8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_0:
    // 0x803859FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80385A00:
    // 0x80385A00: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80385A04: jr          $ra
    // 0x80385A08: nop

    return;
    // 0x80385A08: nop

;}
RECOMP_FUNC void perform_behavior_racing_tortoise(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385A0C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80385A10: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80385A14: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80385A18: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80385A1C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385A20: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80385A24: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80385A28: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80385A2C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385A30: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80385A34: beq         $t6, $zero, L_80385A60
    if (ctx->r14 == 0) {
        // 0x80385A38: nop
    
            goto L_80385A60;
    }
    // 0x80385A38: nop

    // 0x80385A3C: beq         $t6, $at, L_80385A80
    if (ctx->r14 == ctx->r1) {
        // 0x80385A40: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80385A80;
    }
    // 0x80385A40: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80385A44: beq         $t6, $at, L_80385AC0
    if (ctx->r14 == ctx->r1) {
        // 0x80385A48: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80385AC0;
    }
    // 0x80385A48: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385A4C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80385A50: beql        $t6, $at, L_80385B84
    if (ctx->r14 == ctx->r1) {
        // 0x80385A54: lh          $t7, 0x2D0($v0)
        ctx->r15 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385B84;
    }
    goto skip_0;
    // 0x80385A54: lh          $t7, 0x2D0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80385A58: b           L_80385BD0
    // 0x80385A5C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80385BD0;
    // 0x80385A5C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80385A60:
    // 0x80385A60: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385A64: jal         0x80363E88
    // 0x80385A68: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_0;
    // 0x80385A68: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80385A6C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385A70: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385A74: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80385A78: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80385A7C: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
L_80385A80:
    // 0x80385A80: jal         0x80383830
    // 0x80385A84: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    target_within_current_fov(rdram, ctx);
        goto after_1;
    // 0x80385A84: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_1:
    // 0x80385A88: beq         $v0, $zero, L_80385BCC
    if (ctx->r2 == 0) {
        // 0x80385A8C: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80385BCC;
    }
    // 0x80385A8C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385A90: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x80385A94: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385A98: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385A9C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385AA0: jal         0x80363CE0
    // 0x80385AA4: lw          $a1, 0x2CC($t0)
    ctx->r5 = MEM_W(ctx->r8, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80385AA4: lw          $a1, 0x2CC($t0)
    ctx->r5 = MEM_W(ctx->r8, 0X2CC);
    after_2:
    // 0x80385AA8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385AAC: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385AB0: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80385AB4: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80385AB8: b           L_80385BCC
    // 0x80385ABC: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
        goto L_80385BCC;
    // 0x80385ABC: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
L_80385AC0:
    // 0x80385AC0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385AC4: lbu         $t4, 0x5C($a0)
    ctx->r12 = MEM_BU(ctx->r4, 0X5C);
    // 0x80385AC8: andi        $t5, $t4, 0x4
    ctx->r13 = ctx->r12 & 0X4;
    // 0x80385ACC: beql        $t5, $zero, L_80385B10
    if (ctx->r13 == 0) {
        // 0x80385AD0: lh          $t1, 0x2D0($v0)
        ctx->r9 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385B10;
    }
    goto skip_1;
    // 0x80385AD0: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    skip_1:
    // 0x80385AD4: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    // 0x80385AD8: lw          $t6, 0x60($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X60);
    // 0x80385ADC: bnel        $a2, $t6, L_80385B10
    if (ctx->r6 != ctx->r14) {
        // 0x80385AE0: lh          $t1, 0x2D0($v0)
        ctx->r9 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385B10;
    }
    goto skip_2;
    // 0x80385AE0: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    skip_2:
    // 0x80385AE4: jal         0x80363EDC
    // 0x80385AE8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80385AE8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_3:
    // 0x80385AEC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385AF0: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385AF4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80385AF8: ori         $t9, $t8, 0x30
    ctx->r25 = ctx->r24 | 0X30;
    // 0x80385AFC: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80385B00: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x80385B04: sw          $zero, 0x2B8($t0)
    MEM_W(0X2B8, ctx->r8) = 0;
    // 0x80385B08: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385B0C: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
L_80385B10:
    // 0x80385B10: slti        $at, $t1, 0x46
    ctx->r1 = SIGNED(ctx->r9) < 0X46 ? 1 : 0;
    // 0x80385B14: beql        $at, $zero, L_80385BD0
    if (ctx->r1 == 0) {
        // 0x80385B18: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385BD0;
    }
    goto skip_3;
    // 0x80385B18: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80385B1C: jal         0x80383830
    // 0x80385B20: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80385B20: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80385B24: beql        $v0, $zero, L_80385BD0
    if (ctx->r2 == 0) {
        // 0x80385B28: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385BD0;
    }
    goto skip_4;
    // 0x80385B28: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80385B2C: jal         0x8038395C
    // 0x80385B30: nop

    func_8038395C_79500C(rdram, ctx);
        goto after_5;
    // 0x80385B30: nop

    after_5:
    // 0x80385B34: slti        $at, $v0, 0xC
    ctx->r1 = SIGNED(ctx->r2) < 0XC ? 1 : 0;
    // 0x80385B38: bnel        $at, $zero, L_80385BD0
    if (ctx->r1 != 0) {
        // 0x80385B3C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385BD0;
    }
    goto skip_5;
    // 0x80385B3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80385B40: jal         0x80356348
    // 0x80385B44: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    racing_tortoise_defend(rdram, ctx);
        goto after_6;
    // 0x80385B44: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_6:
    // 0x80385B48: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80385B4C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385B50: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385B54: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80385B58: jal         0x80363EDC
    // 0x80385B5C: lw          $a2, 0x2CC($t2)
    ctx->r6 = MEM_W(ctx->r10, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_7;
    // 0x80385B5C: lw          $a2, 0x2CC($t2)
    ctx->r6 = MEM_W(ctx->r10, 0X2CC);
    after_7:
    // 0x80385B60: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385B64: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385B68: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80385B6C: ori         $t5, $t4, 0x30
    ctx->r13 = ctx->r12 | 0X30;
    // 0x80385B70: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x80385B74: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x80385B78: b           L_80385BCC
    // 0x80385B7C: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
        goto L_80385BCC;
    // 0x80385B7C: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
    // 0x80385B80: lh          $t7, 0x2D0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2D0);
L_80385B84:
    // 0x80385B84: slti        $at, $t7, 0x12C
    ctx->r1 = SIGNED(ctx->r15) < 0X12C ? 1 : 0;
    // 0x80385B88: beql        $at, $zero, L_80385BAC
    if (ctx->r1 == 0) {
        // 0x80385B8C: lbu         $t9, 0x2B4($v0)
        ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80385BAC;
    }
    goto skip_6;
    // 0x80385B8C: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    skip_6:
    // 0x80385B90: lw          $a0, 0x2B8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385B94: slti        $v1, $a0, 0x5B
    ctx->r3 = SIGNED(ctx->r4) < 0X5B ? 1 : 0;
    // 0x80385B98: addiu       $t8, $a0, 0x1
    ctx->r24 = ADD32(ctx->r4, 0X1);
    // 0x80385B9C: bne         $v1, $zero, L_80385BCC
    if (ctx->r3 != 0) {
        // 0x80385BA0: sw          $t8, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r24;
            goto L_80385BCC;
    }
    // 0x80385BA0: sw          $t8, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r24;
    // 0x80385BA4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80385BA8: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
L_80385BAC:
    // 0x80385BAC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385BB0: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80385BB4: ori         $t1, $t0, 0x10
    ctx->r9 = ctx->r8 | 0X10;
    // 0x80385BB8: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x80385BBC: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80385BC0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385BC4: jal         0x80363E88
    // 0x80385BC8: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_8;
    // 0x80385BC8: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_8:
L_80385BCC:
    // 0x80385BCC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80385BD0:
    // 0x80385BD0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80385BD4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80385BD8: jr          $ra
    // 0x80385BDC: nop

    return;
    // 0x80385BDC: nop

;}
