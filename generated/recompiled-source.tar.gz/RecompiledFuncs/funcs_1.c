#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void end_display_lists(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A490: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x8012A494: addiu       $v1, $v1, -0x6184
    ctx->r3 = ADD32(ctx->r3, -0X6184);
    // 0x8012A498: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8012A49C: lui         $t7, 0xBB00
    ctx->r15 = S32(0XBB00 << 16);
    // 0x8012A4A0: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x8012A4A4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012A4A8: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8012A4AC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012A4B0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012A4B4: lw          $a3, -0x6170($a3)
    ctx->r7 = MEM_W(ctx->r7, -0X6170);
    // 0x8012A4B8: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A4BC: lui         $a0, 0xB800
    ctx->r4 = S32(0XB800 << 16);
    // 0x8012A4C0: addiu       $t8, $a3, 0x8
    ctx->r24 = ADD32(ctx->r7, 0X8);
    // 0x8012A4C4: sw          $t8, -0x6170($at)
    MEM_W(-0X6170, ctx->r1) = ctx->r24;
    // 0x8012A4C8: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x8012A4CC: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x8012A4D0: sw          $a0, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r4;
    // 0x8012A4D4: lw          $t1, -0x616C($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X616C);
    // 0x8012A4D8: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A4DC: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x8012A4E0: addiu       $t9, $t1, 0x8
    ctx->r25 = ADD32(ctx->r9, 0X8);
    // 0x8012A4E4: sw          $t9, -0x616C($at)
    MEM_W(-0X616C, ctx->r1) = ctx->r25;
    // 0x8012A4E8: sw          $zero, 0x4($t1)
    MEM_W(0X4, ctx->r9) = 0;
    // 0x8012A4EC: sw          $a0, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r4;
    // 0x8012A4F0: lw          $t3, -0x6178($t3)
    ctx->r11 = MEM_W(ctx->r11, -0X6178);
    // 0x8012A4F4: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A4F8: lui         $t5, 0x801E
    ctx->r13 = S32(0X801E << 16);
    // 0x8012A4FC: addiu       $t6, $t3, 0x8
    ctx->r14 = ADD32(ctx->r11, 0X8);
    // 0x8012A500: sw          $t6, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r14;
    // 0x8012A504: sw          $zero, 0x4($t3)
    MEM_W(0X4, ctx->r11) = 0;
    // 0x8012A508: sw          $a0, 0x0($t3)
    MEM_W(0X0, ctx->r11) = ctx->r4;
    // 0x8012A50C: lw          $t5, -0x6174($t5)
    ctx->r13 = MEM_W(ctx->r13, -0X6174);
    // 0x8012A510: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A514: lui         $t8, 0x801E
    ctx->r24 = S32(0X801E << 16);
    // 0x8012A518: addiu       $t7, $t5, 0x8
    ctx->r15 = ADD32(ctx->r13, 0X8);
    // 0x8012A51C: sw          $t7, -0x6174($at)
    MEM_W(-0X6174, ctx->r1) = ctx->r15;
    // 0x8012A520: sw          $zero, 0x4($t5)
    MEM_W(0X4, ctx->r13) = 0;
    // 0x8012A524: sw          $a0, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r4;
    // 0x8012A528: lw          $t8, -0x6148($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X6148);
    // 0x8012A52C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8012A530: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A534: addiu       $t9, $t8, 0x8
    ctx->r25 = ADD32(ctx->r24, 0X8);
    // 0x8012A538: sw          $t9, -0x6148($at)
    MEM_W(-0X6148, ctx->r1) = ctx->r25;
    // 0x8012A53C: sw          $t8, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r24;
    // 0x8012A540: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8012A544: sw          $zero, 0x4($t8)
    MEM_W(0X4, ctx->r24) = 0;
    // 0x8012A548: sw          $a0, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r4;
    // 0x8012A54C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8012A550: lui         $t8, 0xE900
    ctx->r24 = S32(0XE900 << 16);
    // 0x8012A554: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012A558: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8012A55C: sw          $v0, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r2;
    // 0x8012A560: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012A564: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012A568: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8012A56C: sw          $v0, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r2;
    // 0x8012A570: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012A574: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8012A578: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8012A57C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012A580: jr          $ra
    // 0x8012A584: sw          $a0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r4;
    return;
    // 0x8012A584: sw          $a0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r4;
;}
RECOMP_FUNC void func_8012A588(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A588: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8012A58C: lh          $v1, 0x2E9C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2E9C);
    // 0x8012A590: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8012A594: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x8012A598: beq         $v1, $zero, L_8012A740
    if (ctx->r3 == 0) {
        // 0x8012A59C: addiu       $v0, $zero, 0x1
        ctx->r2 = ADD32(0, 0X1);
            goto L_8012A740;
    }
    // 0x8012A59C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8012A5A0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012A5A4: bne         $v0, $v1, L_8012A63C
    if (ctx->r2 != ctx->r3) {
        // 0x8012A5A8: sh          $v0, 0x4290($at)
        MEM_H(0X4290, ctx->r1) = ctx->r2;
            goto L_8012A63C;
    }
    // 0x8012A5A8: sh          $v0, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r2;
    // 0x8012A5AC: jal         0x80137840
    // 0x8012A5B0: nop

    init_rumble_pak(rdram, ctx);
        goto after_0;
    // 0x8012A5B0: nop

    after_0:
    // 0x8012A5B4: jal         0x8012A400
    // 0x8012A5B8: nop

    func_8012A400(rdram, ctx);
        goto after_1;
    // 0x8012A5B8: nop

    after_1:
    // 0x8012A5BC: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8012A5C0: lhu         $v0, 0x2EB8($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2EB8);
    // 0x8012A5C4: lui         $v1, 0x8016
    ctx->r3 = S32(0X8016 << 16);
    // 0x8012A5C8: addiu       $v1, $v1, 0x2658
    ctx->r3 = ADD32(ctx->r3, 0X2658);
    // 0x8012A5CC: xori        $t9, $v0, 0x1
    ctx->r25 = ctx->r2 ^ 0X1;
    // 0x8012A5D0: sll         $t0, $t9, 4
    ctx->r8 = S32(ctx->r25 << 4);
    // 0x8012A5D4: sll         $t6, $v0, 4
    ctx->r14 = S32(ctx->r2 << 4);
    // 0x8012A5D8: subu        $t0, $t0, $t9
    ctx->r8 = SUB32(ctx->r8, ctx->r25);
    // 0x8012A5DC: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x8012A5E0: sll         $t6, $t6, 4
    ctx->r14 = S32(ctx->r14 << 4);
    // 0x8012A5E4: sll         $t0, $t0, 4
    ctx->r8 = S32(ctx->r8 << 4);
    // 0x8012A5E8: subu        $t0, $t0, $t9
    ctx->r8 = SUB32(ctx->r8, ctx->r25);
    // 0x8012A5EC: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x8012A5F0: sll         $t6, $t6, 6
    ctx->r14 = S32(ctx->r14 << 6);
    // 0x8012A5F4: sll         $t0, $t0, 6
    ctx->r8 = S32(ctx->r8 << 6);
    // 0x8012A5F8: lui         $a3, 0x3
    ctx->r7 = S32(0X3 << 16);
    // 0x8012A5FC: subu        $t0, $t0, $t9
    ctx->r8 = SUB32(ctx->r8, ctx->r25);
    // 0x8012A600: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x8012A604: ori         $a3, $a3, 0x8000
    ctx->r7 = ctx->r7 | 0X8000;
    // 0x8012A608: sll         $t6, $t6, 4
    ctx->r14 = S32(ctx->r14 << 4);
    // 0x8012A60C: sll         $t0, $t0, 4
    ctx->r8 = S32(ctx->r8 << 4);
    // 0x8012A610: addu        $t1, $v1, $t0
    ctx->r9 = ADD32(ctx->r3, ctx->r8);
    // 0x8012A614: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x8012A618: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x8012A61C: addu        $t2, $t1, $a3
    ctx->r10 = ADD32(ctx->r9, ctx->r7);
    // 0x8012A620: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8012A624: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8012A628: lw          $a1, 0x3BE8($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X3BE8);
    // 0x8012A62C: jal         0x80129158
    // 0x8012A630: lw          $a0, 0x3BE8($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X3BE8);
    memcpy_sssv(rdram, ctx);
        goto after_2;
    // 0x8012A630: lw          $a0, 0x3BE8($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X3BE8);
    after_2:
    // 0x8012A634: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8012A638: lh          $v1, 0x2E9C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2E9C);
L_8012A63C:
    // 0x8012A63C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012A640: bne         $v1, $at, L_8012A684
    if (ctx->r3 != ctx->r1) {
        // 0x8012A644: nop
    
            goto L_8012A684;
    }
    // 0x8012A644: nop

    // 0x8012A648: jal         0x8012AC40
    // 0x8012A64C: nop

    set_tv_mode_normal(rdram, ctx);
        goto after_3;
    // 0x8012A64C: nop

    after_3:
    // 0x8012A650: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8012A654: lui         $a1, 0x4120
    ctx->r5 = S32(0X4120 << 16);
    // 0x8012A658: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8012A65C: jal         0x801337DC
    // 0x8012A660: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_4;
    // 0x8012A660: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_4:
    // 0x8012A664: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x8012A668: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8012A66C: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x8012A670: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x8012A674: jal         0x8013385C
    // 0x8012A678: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    start_sfx_volume_fade(rdram, ctx);
        goto after_5;
    // 0x8012A678: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    after_5:
    // 0x8012A67C: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8012A680: lh          $v1, 0x2E9C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2E9C);
L_8012A684:
    // 0x8012A684: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x8012A688: addiu       $a1, $a1, -0x6184
    ctx->r5 = ADD32(ctx->r5, -0X6184);
    // 0x8012A68C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8012A690: lui         $t6, 0xFF10
    ctx->r14 = S32(0XFF10 << 16);
    // 0x8012A694: ori         $t6, $t6, 0x13F
    ctx->r14 = ctx->r14 | 0X13F;
    // 0x8012A698: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012A69C: sw          $t5, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r13;
    // 0x8012A6A0: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x8012A6A4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012A6A8: lw          $t7, 0x4274($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X4274);
    // 0x8012A6AC: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x8012A6B0: addu        $a0, $a0, $t7
    ctx->r4 = ADD32(ctx->r4, ctx->r15);
    // 0x8012A6B4: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x8012A6B8: jal         0x80138130
    // 0x8012A6BC: sw          $v0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r2;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_6;
    // 0x8012A6BC: sw          $v0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r2;
    after_6:
    // 0x8012A6C0: lw          $v1, 0x30($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X30);
    // 0x8012A6C4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8012A6C8: addiu       $t8, $zero, 0xF0
    ctx->r24 = ADD32(0, 0XF0);
    // 0x8012A6CC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
    // 0x8012A6D0: addiu       $t9, $zero, 0x78
    ctx->r25 = ADD32(0, 0X78);
    // 0x8012A6D4: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x8012A6D8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8012A6DC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8012A6E0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8012A6E4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8012A6E8: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8012A6EC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8012A6F0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8012A6F4: jal         0x8012AD30
    // 0x8012A6F8: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    draw_rectangle(rdram, ctx);
        goto after_7;
    // 0x8012A6F8: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    after_7:
    // 0x8012A6FC: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x8012A700: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x8012A704: lh          $t1, 0x4290($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X4290);
    // 0x8012A708: lh          $t0, 0x2E9C($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X2E9C);
    // 0x8012A70C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8012A710: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8012A714: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x8012A718: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x8012A71C: sh          $t2, 0x2E9C($at)
    MEM_H(0X2E9C, ctx->r1) = ctx->r10;
    // 0x8012A720: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8012A724: slti        $at, $t4, 0x10
    ctx->r1 = SIGNED(ctx->r12) < 0X10 ? 1 : 0;
    // 0x8012A728: bne         $at, $zero, L_8012A740
    if (ctx->r1 != 0) {
        // 0x8012A72C: addiu       $v0, $v0, 0x2EBC
        ctx->r2 = ADD32(ctx->r2, 0X2EBC);
            goto L_8012A740;
    }
    // 0x8012A72C: addiu       $v0, $v0, 0x2EBC
    ctx->r2 = ADD32(ctx->r2, 0X2EBC);
    // 0x8012A730: lhu         $t5, 0x0($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X0);
    // 0x8012A734: addiu       $t6, $t5, 0x64
    ctx->r14 = ADD32(ctx->r13, 0X64);
    // 0x8012A738: jal         0x8012AC8C
    // 0x8012A73C: sh          $t6, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r14;
    func_8012AC8C(rdram, ctx);
        goto after_8;
    // 0x8012A73C: sh          $t6, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r14;
    after_8:
L_8012A740:
    // 0x8012A740: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8012A744: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x8012A748: jr          $ra
    // 0x8012A74C: nop

    return;
    // 0x8012A74C: nop

;}
RECOMP_FUNC void no_controller_message(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A750: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8012A754: lh          $t6, 0x12D8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X12D8);
    // 0x8012A758: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8012A75C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8012A760: bne         $t6, $zero, L_8012A85C
    if (ctx->r14 != 0) {
        // 0x8012A764: sw          $s0, 0x30($sp)
        MEM_W(0X30, ctx->r29) = ctx->r16;
            goto L_8012A85C;
    }
    // 0x8012A764: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8012A768: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8012A76C: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8012A770: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012A774: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    // 0x8012A778: jal         0x80129300
    // 0x8012A77C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    load_segments(rdram, ctx);
        goto after_0;
    // 0x8012A77C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x8012A780: addiu       $t7, $zero, 0x24
    ctx->r15 = ADD32(0, 0X24);
    // 0x8012A784: addiu       $t8, $zero, 0x28
    ctx->r24 = ADD32(0, 0X28);
    // 0x8012A788: addiu       $t9, $zero, 0x28
    ctx->r25 = ADD32(0, 0X28);
    // 0x8012A78C: addiu       $t0, $zero, 0x28
    ctx->r8 = ADD32(0, 0X28);
    // 0x8012A790: addiu       $t1, $zero, 0x80
    ctx->r9 = ADD32(0, 0X80);
    // 0x8012A794: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x8012A798: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x8012A79C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8012A7A0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8012A7A4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8012A7A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012A7AC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8012A7B0: addiu       $a2, $zero, 0x10
    ctx->r6 = ADD32(0, 0X10);
    // 0x8012A7B4: jal         0x8012AD30
    // 0x8012A7B8: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    draw_rectangle(rdram, ctx);
        goto after_1;
    // 0x8012A7B8: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    after_1:
    // 0x8012A7BC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012A7C0: lui         $t3, 0xE700
    ctx->r11 = S32(0XE700 << 16);
    // 0x8012A7C4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012A7C8: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x8012A7CC: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x8012A7D0: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012A7D4: jal         0x8012C1F0
    // 0x8012A7D8: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    load_default_display_list(rdram, ctx);
        goto after_2;
    // 0x8012A7D8: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    after_2:
    // 0x8012A7DC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8012A7E0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8012A7E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8012A7E8: jal         0x8012C248
    // 0x8012A7EC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_3;
    // 0x8012A7EC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_3:
    // 0x8012A7F0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8012A7F4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8012A7F8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8012A7FC: jal         0x8012C214
    // 0x8012A800: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_4;
    // 0x8012A800: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_4:
    // 0x8012A804: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8012A808: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8012A80C: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8012A810: lh          $a2, 0x3FD0($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X3FD0);
    // 0x8012A814: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012A818: addiu       $a1, $a1, 0x42F0
    ctx->r5 = ADD32(ctx->r5, 0X42F0);
    // 0x8012A81C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012A820: bgez        $a2, L_8012A830
    if (SIGNED(ctx->r6) >= 0) {
        // 0x8012A824: sra         $t4, $a2, 1
        ctx->r12 = S32(SIGNED(ctx->r6) >> 1);
            goto L_8012A830;
    }
    // 0x8012A824: sra         $t4, $a2, 1
    ctx->r12 = S32(SIGNED(ctx->r6) >> 1);
    // 0x8012A828: addiu       $at, $a2, 0x1
    ctx->r1 = ADD32(ctx->r6, 0X1);
    // 0x8012A82C: sra         $t4, $at, 1
    ctx->r12 = S32(SIGNED(ctx->r1) >> 1);
L_8012A830:
    // 0x8012A830: andi        $a2, $t4, 0xFFFF
    ctx->r6 = ctx->r12 & 0XFFFF;
    // 0x8012A834: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x8012A838: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x8012A83C: jal         0x8012C978
    // 0x8012A840: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text_centered(rdram, ctx);
        goto after_5;
    // 0x8012A840: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_5:
    // 0x8012A844: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012A848: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x8012A84C: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012A850: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012A854: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012A858: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
L_8012A85C:
    // 0x8012A85C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8012A860: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8012A864: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x8012A868: jr          $ra
    // 0x8012A86C: nop

    return;
    // 0x8012A86C: nop

;}
RECOMP_FUNC void initialise_tv_mode(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A870: lui         $v0, 0x8000
    ctx->r2 = S32(0X8000 << 16);
    // 0x8012A874: lh          $v0, 0x302($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X302);
    // 0x8012A878: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8012A87C: addiu       $v1, $v1, 0x53E0
    ctx->r3 = ADD32(ctx->r3, 0X53E0);
    // 0x8012A880: beq         $v0, $zero, L_8012A8A8
    if (ctx->r2 == 0) {
        // 0x8012A884: lui         $a0, 0x8020
        ctx->r4 = S32(0X8020 << 16);
            goto L_8012A8A8;
    }
    // 0x8012A884: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8012A888: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8012A88C: beq         $v0, $t1, L_8012A94C
    if (ctx->r2 == ctx->r9) {
        // 0x8012A890: lui         $v1, 0x8020
        ctx->r3 = S32(0X8020 << 16);
            goto L_8012A94C;
    }
    // 0x8012A890: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8012A894: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012A898: beq         $v0, $at, L_8012AA00
    if (ctx->r2 == ctx->r1) {
        // 0x8012A89C: lui         $v1, 0x8020
        ctx->r3 = S32(0X8020 << 16);
            goto L_8012AA00;
    }
    // 0x8012A89C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8012A8A0: b           L_8012AAB8
    // 0x8012A8A4: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
        goto L_8012AAB8;
    // 0x8012A8A4: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
L_8012A8A8:
    // 0x8012A8A8: addiu       $t6, $zero, 0xE
    ctx->r14 = ADD32(0, 0XE);
    // 0x8012A8AC: addiu       $t7, $zero, 0x130
    ctx->r15 = ADD32(0, 0X130);
    // 0x8012A8B0: sh          $t6, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r14;
    // 0x8012A8B4: sh          $t7, 0xA($v1)
    MEM_H(0XA, ctx->r3) = ctx->r15;
    // 0x8012A8B8: addiu       $t8, $zero, 0x32
    ctx->r24 = ADD32(0, 0X32);
    // 0x8012A8BC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012A8C0: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012A8C4: sh          $t8, 0x4294($at)
    MEM_H(0X4294, ctx->r1) = ctx->r24;
    // 0x8012A8C8: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x8012A8CC: lh          $a2, 0x20($a1)
    ctx->r6 = MEM_H(ctx->r5, 0X20);
    // 0x8012A8D0: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8012A8D4: lui         $t9, 0x7A
    ctx->r25 = S32(0X7A << 16);
    // 0x8012A8D8: lui         $t3, 0x34
    ctx->r11 = S32(0X34 << 16);
    // 0x8012A8DC: addiu       $v0, $v0, 0x53F0
    ctx->r2 = ADD32(ctx->r2, 0X53F0);
    // 0x8012A8E0: addiu       $a0, $a0, 0x5400
    ctx->r4 = ADD32(ctx->r4, 0X5400);
    // 0x8012A8E4: ori         $t9, $t9, 0x210
    ctx->r25 = ctx->r25 | 0X210;
    // 0x8012A8E8: addiu       $t2, $zero, 0x4B0
    ctx->r10 = ADD32(0, 0X4B0);
    // 0x8012A8EC: ori         $t3, $t3, 0x25A
    ctx->r11 = ctx->r11 | 0X25A;
    // 0x8012A8F0: addiu       $t4, $zero, 0x36E
    ctx->r12 = ADD32(0, 0X36E);
    // 0x8012A8F4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012A8F8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012A8FC: sw          $t2, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r10;
    // 0x8012A900: sw          $t3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r11;
    // 0x8012A904: beq         $a2, $at, L_8012A914
    if (ctx->r6 == ctx->r1) {
        // 0x8012A908: sw          $t4, 0x4($a0)
        MEM_W(0X4, ctx->r4) = ctx->r12;
            goto L_8012A914;
    }
    // 0x8012A908: sw          $t4, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r12;
    // 0x8012A90C: bnel        $a2, $zero, L_8012A928
    if (ctx->r6 != 0) {
        // 0x8012A910: lh          $t6, 0x8($v1)
        ctx->r14 = MEM_H(ctx->r3, 0X8);
            goto L_8012A928;
    }
    goto skip_0;
    // 0x8012A910: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
    skip_0:
L_8012A914:
    // 0x8012A914: lbu         $t5, 0x1E($a1)
    ctx->r13 = MEM_BU(ctx->r5, 0X1E);
    // 0x8012A918: beql        $t5, $zero, L_8012A928
    if (ctx->r13 == 0) {
        // 0x8012A91C: lh          $t6, 0x8($v1)
        ctx->r14 = MEM_H(ctx->r3, 0X8);
            goto L_8012A928;
    }
    goto skip_1;
    // 0x8012A91C: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
    skip_1:
    // 0x8012A920: sh          $zero, 0x0($zero)
    MEM_H(0X0, 0) = 0;
    // 0x8012A924: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
L_8012A928:
    // 0x8012A928: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012A92C: addiu       $t8, $t8, -0x6680
    ctx->r24 = ADD32(ctx->r24, -0X6680);
    // 0x8012A930: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012A934: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8012A938: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012A93C: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x8012A940: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012A944: b           L_8012AB68
    // 0x8012A948: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
        goto L_8012AB68;
    // 0x8012A948: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
L_8012A94C:
    // 0x8012A94C: addiu       $v1, $v1, 0x53E0
    ctx->r3 = ADD32(ctx->r3, 0X53E0);
    // 0x8012A950: addiu       $t9, $zero, 0x130
    ctx->r25 = ADD32(0, 0X130);
    // 0x8012A954: sh          $zero, 0x8($v1)
    MEM_H(0X8, ctx->r3) = 0;
    // 0x8012A958: sh          $t9, 0xA($v1)
    MEM_H(0XA, ctx->r3) = ctx->r25;
    // 0x8012A95C: addiu       $t2, $zero, 0x3C
    ctx->r10 = ADD32(0, 0X3C);
    // 0x8012A960: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012A964: sh          $t2, 0x4294($at)
    MEM_H(0X4294, ctx->r1) = ctx->r10;
    // 0x8012A968: lh          $t5, 0x8($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X8);
    // 0x8012A96C: lui         $t7, 0x8016
    ctx->r15 = S32(0X8016 << 16);
    // 0x8012A970: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012A974: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8012A978: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x8012A97C: sll         $t6, $t6, 4
    ctx->r14 = S32(ctx->r14 << 4);
    // 0x8012A980: addiu       $t7, $t7, -0x6680
    ctx->r15 = ADD32(ctx->r15, -0X6680);
    // 0x8012A984: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x8012A988: addu        $a2, $t6, $t7
    ctx->r6 = ADD32(ctx->r14, ctx->r15);
    // 0x8012A98C: lh          $t8, 0x20($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X20);
    // 0x8012A990: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012A994: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
    // 0x8012A998: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8012A99C: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8012A9A0: lui         $t3, 0x65
    ctx->r11 = S32(0X65 << 16);
    // 0x8012A9A4: addiu       $a0, $a0, 0x5400
    ctx->r4 = ADD32(ctx->r4, 0X5400);
    // 0x8012A9A8: addiu       $v0, $v0, 0x53F0
    ctx->r2 = ADD32(ctx->r2, 0X53F0);
    // 0x8012A9AC: ori         $t3, $t3, 0x1BF
    ctx->r11 = ctx->r11 | 0X1BF;
    // 0x8012A9B0: addiu       $t4, $zero, 0x587
    ctx->r12 = ADD32(0, 0X587);
    // 0x8012A9B4: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x8012A9B8: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x8012A9BC: sw          $a3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r7;
    // 0x8012A9C0: bne         $t1, $t8, L_8012AB68
    if (ctx->r9 != ctx->r24) {
        // 0x8012A9C4: sw          $t0, 0x4($a0)
        MEM_W(0X4, ctx->r4) = ctx->r8;
            goto L_8012AB68;
    }
    // 0x8012A9C4: sw          $t0, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r8;
    // 0x8012A9C8: lbu         $t9, 0x1E($a1)
    ctx->r25 = MEM_BU(ctx->r5, 0X1E);
    // 0x8012A9CC: beql        $t9, $zero, L_8012AB6C
    if (ctx->r25 == 0) {
        // 0x8012A9D0: lw          $v0, 0x0($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X0);
            goto L_8012AB6C;
    }
    goto skip_2;
    // 0x8012A9D0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    skip_2:
    // 0x8012A9D4: sh          $zero, 0x0($zero)
    MEM_H(0X0, 0) = 0;
    // 0x8012A9D8: lh          $t2, 0x8($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X8);
    // 0x8012A9DC: lui         $t4, 0x8016
    ctx->r12 = S32(0X8016 << 16);
    // 0x8012A9E0: addiu       $t4, $t4, -0x6680
    ctx->r12 = ADD32(ctx->r12, -0X6680);
    // 0x8012A9E4: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x8012A9E8: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x8012A9EC: sll         $t3, $t3, 4
    ctx->r11 = S32(ctx->r11 << 4);
    // 0x8012A9F0: addu        $a2, $t3, $t4
    ctx->r6 = ADD32(ctx->r11, ctx->r12);
    // 0x8012A9F4: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012A9F8: b           L_8012AB68
    // 0x8012A9FC: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
        goto L_8012AB68;
    // 0x8012A9FC: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
L_8012AA00:
    // 0x8012AA00: addiu       $v1, $v1, 0x53E0
    ctx->r3 = ADD32(ctx->r3, 0X53E0);
    // 0x8012AA04: addiu       $t5, $zero, 0x1C
    ctx->r13 = ADD32(0, 0X1C);
    // 0x8012AA08: addiu       $t6, $zero, 0x130
    ctx->r14 = ADD32(0, 0X130);
    // 0x8012AA0C: sh          $t5, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r13;
    // 0x8012AA10: sh          $t6, 0xA($v1)
    MEM_H(0XA, ctx->r3) = ctx->r14;
    // 0x8012AA14: addiu       $t7, $zero, 0x3C
    ctx->r15 = ADD32(0, 0X3C);
    // 0x8012AA18: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012AA1C: sh          $t7, 0x4294($at)
    MEM_H(0X4294, ctx->r1) = ctx->r15;
    // 0x8012AA20: lh          $t2, 0x8($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X8);
    // 0x8012AA24: lui         $t4, 0x8016
    ctx->r12 = S32(0X8016 << 16);
    // 0x8012AA28: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012AA2C: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x8012AA30: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x8012AA34: sll         $t3, $t3, 4
    ctx->r11 = S32(ctx->r11 << 4);
    // 0x8012AA38: addiu       $t4, $t4, -0x6680
    ctx->r12 = ADD32(ctx->r12, -0X6680);
    // 0x8012AA3C: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x8012AA40: addu        $a2, $t3, $t4
    ctx->r6 = ADD32(ctx->r11, ctx->r12);
    // 0x8012AA44: lh          $t5, 0x20($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X20);
    // 0x8012AA48: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012AA4C: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
    // 0x8012AA50: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8012AA54: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8012AA58: lui         $t8, 0x65
    ctx->r24 = S32(0X65 << 16);
    // 0x8012AA5C: addiu       $a0, $a0, 0x5400
    ctx->r4 = ADD32(ctx->r4, 0X5400);
    // 0x8012AA60: addiu       $v0, $v0, 0x53F0
    ctx->r2 = ADD32(ctx->r2, 0X53F0);
    // 0x8012AA64: ori         $t8, $t8, 0x1BF
    ctx->r24 = ctx->r24 | 0X1BF;
    // 0x8012AA68: addiu       $t9, $zero, 0x587
    ctx->r25 = ADD32(0, 0X587);
    // 0x8012AA6C: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012AA70: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012AA74: sw          $a3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r7;
    // 0x8012AA78: bne         $t1, $t5, L_8012AB68
    if (ctx->r9 != ctx->r13) {
        // 0x8012AA7C: sw          $t0, 0x4($a0)
        MEM_W(0X4, ctx->r4) = ctx->r8;
            goto L_8012AB68;
    }
    // 0x8012AA7C: sw          $t0, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r8;
    // 0x8012AA80: lbu         $t6, 0x1E($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X1E);
    // 0x8012AA84: beql        $t6, $zero, L_8012AB6C
    if (ctx->r14 == 0) {
        // 0x8012AA88: lw          $v0, 0x0($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X0);
            goto L_8012AB6C;
    }
    goto skip_3;
    // 0x8012AA88: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    skip_3:
    // 0x8012AA8C: sh          $zero, 0x0($zero)
    MEM_H(0X0, 0) = 0;
    // 0x8012AA90: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x8012AA94: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x8012AA98: addiu       $t9, $t9, -0x6680
    ctx->r25 = ADD32(ctx->r25, -0X6680);
    // 0x8012AA9C: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8012AAA0: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x8012AAA4: sll         $t8, $t8, 4
    ctx->r24 = S32(ctx->r24 << 4);
    // 0x8012AAA8: addu        $a2, $t8, $t9
    ctx->r6 = ADD32(ctx->r24, ctx->r25);
    // 0x8012AAAC: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012AAB0: b           L_8012AB68
    // 0x8012AAB4: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
        goto L_8012AB68;
    // 0x8012AAB4: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
L_8012AAB8:
    // 0x8012AAB8: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8012AABC: addiu       $v1, $v1, 0x53E0
    ctx->r3 = ADD32(ctx->r3, 0X53E0);
    // 0x8012AAC0: addiu       $t2, $zero, 0x130
    ctx->r10 = ADD32(0, 0X130);
    // 0x8012AAC4: sh          $zero, 0x8($v1)
    MEM_H(0X8, ctx->r3) = 0;
    // 0x8012AAC8: sh          $t2, 0xA($v1)
    MEM_H(0XA, ctx->r3) = ctx->r10;
    // 0x8012AACC: addiu       $t3, $zero, 0x3C
    ctx->r11 = ADD32(0, 0X3C);
    // 0x8012AAD0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012AAD4: sh          $t3, 0x4294($at)
    MEM_H(0X4294, ctx->r1) = ctx->r11;
    // 0x8012AAD8: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
    // 0x8012AADC: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012AAE0: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012AAE4: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012AAE8: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8012AAEC: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012AAF0: addiu       $t8, $t8, -0x6680
    ctx->r24 = ADD32(ctx->r24, -0X6680);
    // 0x8012AAF4: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x8012AAF8: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x8012AAFC: lh          $t9, 0x20($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X20);
    // 0x8012AB00: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012AB04: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
    // 0x8012AB08: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8012AB0C: lui         $t4, 0x65
    ctx->r12 = S32(0X65 << 16);
    // 0x8012AB10: addiu       $a0, $a0, 0x5400
    ctx->r4 = ADD32(ctx->r4, 0X5400);
    // 0x8012AB14: addiu       $v0, $v0, 0x53F0
    ctx->r2 = ADD32(ctx->r2, 0X53F0);
    // 0x8012AB18: ori         $t4, $t4, 0x1BF
    ctx->r12 = ctx->r12 | 0X1BF;
    // 0x8012AB1C: addiu       $t5, $zero, 0x587
    ctx->r13 = ADD32(0, 0X587);
    // 0x8012AB20: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8012AB24: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8012AB28: sw          $a3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r7;
    // 0x8012AB2C: bne         $t1, $t9, L_8012AB68
    if (ctx->r9 != ctx->r25) {
        // 0x8012AB30: sw          $t0, 0x4($a0)
        MEM_W(0X4, ctx->r4) = ctx->r8;
            goto L_8012AB68;
    }
    // 0x8012AB30: sw          $t0, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r8;
    // 0x8012AB34: lbu         $t2, 0x1E($a1)
    ctx->r10 = MEM_BU(ctx->r5, 0X1E);
    // 0x8012AB38: beql        $t2, $zero, L_8012AB6C
    if (ctx->r10 == 0) {
        // 0x8012AB3C: lw          $v0, 0x0($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X0);
            goto L_8012AB6C;
    }
    goto skip_4;
    // 0x8012AB3C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    skip_4:
    // 0x8012AB40: sh          $zero, 0x0($zero)
    MEM_H(0X0, 0) = 0;
    // 0x8012AB44: lh          $t3, 0x8($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X8);
    // 0x8012AB48: lui         $t5, 0x8016
    ctx->r13 = S32(0X8016 << 16);
    // 0x8012AB4C: addiu       $t5, $t5, -0x6680
    ctx->r13 = ADD32(ctx->r13, -0X6680);
    // 0x8012AB50: sll         $t4, $t3, 2
    ctx->r12 = S32(ctx->r11 << 2);
    // 0x8012AB54: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x8012AB58: sll         $t4, $t4, 4
    ctx->r12 = S32(ctx->r12 << 4);
    // 0x8012AB5C: addu        $a2, $t4, $t5
    ctx->r6 = ADD32(ctx->r12, ctx->r13);
    // 0x8012AB60: lw          $a3, 0x30($a2)
    ctx->r7 = MEM_W(ctx->r6, 0X30);
    // 0x8012AB64: lw          $t0, 0x2C($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X2C);
L_8012AB68:
    // 0x8012AB68: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
L_8012AB6C:
    // 0x8012AB6C: lw          $a1, 0x4($a0)
    ctx->r5 = MEM_W(ctx->r4, 0X4);
    // 0x8012AB70: sw          $a3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r7;
    // 0x8012AB74: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x8012AB78: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012AB7C: sw          $v0, 0x30($a2)
    MEM_W(0X30, ctx->r6) = ctx->r2;
    // 0x8012AB80: sw          $v0, 0x44($a2)
    MEM_W(0X44, ctx->r6) = ctx->r2;
    // 0x8012AB84: sw          $a1, 0x2C($a2)
    MEM_W(0X2C, ctx->r6) = ctx->r5;
    // 0x8012AB88: sw          $a1, 0x40($a2)
    MEM_W(0X40, ctx->r6) = ctx->r5;
    // 0x8012AB8C: jr          $ra
    // 0x8012AB90: sh          $zero, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = 0;
    return;
    // 0x8012AB90: sh          $zero, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = 0;
;}
RECOMP_FUNC void set_screen_scaling(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012AB94: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012AB98: lh          $t6, 0x3FD0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X3FD0);
    // 0x8012AB9C: lui         $at, 0x43A0
    ctx->r1 = S32(0X43A0 << 16);
    // 0x8012ABA0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012ABA4: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8012ABA8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012ABAC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012ABB0: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012ABB4: jal         0x80139200
    // 0x8012ABB8: div.s       $f12, $f6, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    osViSetXScale_recomp(rdram, ctx);
        goto after_0;
    // 0x8012ABB8: div.s       $f12, $f6, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    after_0:
    // 0x8012ABBC: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x8012ABC0: lh          $t7, 0x3FD2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FD2);
    // 0x8012ABC4: lui         $at, 0x4370
    ctx->r1 = S32(0X4370 << 16);
    // 0x8012ABC8: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012ABCC: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x8012ABD0: nop

    // 0x8012ABD4: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8012ABD8: jal         0x80139330
    // 0x8012ABDC: div.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    osViSetYScale_recomp(rdram, ctx);
        goto after_1;
    // 0x8012ABDC: div.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    after_1:
    // 0x8012ABE0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012ABE4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012ABE8: jr          $ra
    // 0x8012ABEC: nop

    return;
    // 0x8012ABEC: nop

;}
RECOMP_FUNC void set_tv_mode_widescreen(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012ABF0: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012ABF4: lh          $t6, 0x53E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X53E8);
    // 0x8012ABF8: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012ABFC: addiu       $a1, $a1, 0x53F0
    ctx->r5 = ADD32(ctx->r5, 0X53F0);
    // 0x8012AC00: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012AC04: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012AC08: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8012AC0C: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012AC10: addiu       $t8, $t8, -0x6680
    ctx->r24 = ADD32(ctx->r24, -0X6680);
    // 0x8012AC14: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x8012AC18: lw          $a0, 0x4($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X4);
    // 0x8012AC1C: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x8012AC20: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012AC24: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012AC28: sw          $v1, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r3;
    // 0x8012AC2C: sw          $v1, 0x44($v0)
    MEM_W(0X44, ctx->r2) = ctx->r3;
    // 0x8012AC30: sw          $a0, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->r4;
    // 0x8012AC34: sw          $a0, 0x40($v0)
    MEM_W(0X40, ctx->r2) = ctx->r4;
    // 0x8012AC38: jr          $ra
    // 0x8012AC3C: sh          $t9, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = ctx->r25;
    return;
    // 0x8012AC3C: sh          $t9, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = ctx->r25;
;}
RECOMP_FUNC void set_tv_mode_normal(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012AC40: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012AC44: lh          $t6, 0x53E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X53E8);
    // 0x8012AC48: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012AC4C: addiu       $a1, $a1, 0x5400
    ctx->r5 = ADD32(ctx->r5, 0X5400);
    // 0x8012AC50: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012AC54: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012AC58: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8012AC5C: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012AC60: addiu       $t8, $t8, -0x6680
    ctx->r24 = ADD32(ctx->r24, -0X6680);
    // 0x8012AC64: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x8012AC68: lw          $a0, 0x4($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X4);
    // 0x8012AC6C: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x8012AC70: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012AC74: sw          $v1, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r3;
    // 0x8012AC78: sw          $v1, 0x44($v0)
    MEM_W(0X44, ctx->r2) = ctx->r3;
    // 0x8012AC7C: sw          $a0, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->r4;
    // 0x8012AC80: sw          $a0, 0x40($v0)
    MEM_W(0X40, ctx->r2) = ctx->r4;
    // 0x8012AC84: jr          $ra
    // 0x8012AC88: sh          $zero, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = 0;
    return;
    // 0x8012AC88: sh          $zero, 0x540C($at)
    MEM_H(0X540C, ctx->r1) = 0;
;}
RECOMP_FUNC void func_8012AC8C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012AC8C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012AC90: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8012AC94: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012AC98: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8012AC9C: jal         0x80139200
    // 0x8012ACA0: nop

    osViSetXScale_recomp(rdram, ctx);
        goto after_0;
    // 0x8012ACA0: nop

    after_0:
    // 0x8012ACA4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8012ACA8: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8012ACAC: jal         0x80139330
    // 0x8012ACB0: nop

    osViSetYScale_recomp(rdram, ctx);
        goto after_1;
    // 0x8012ACB0: nop

    after_1:
    // 0x8012ACB4: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8012ACB8: addiu       $a2, $a2, 0x53E0
    ctx->r6 = ADD32(ctx->r6, 0X53E0);
    // 0x8012ACBC: lh          $t6, 0x8($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X8);
    // 0x8012ACC0: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012ACC4: addiu       $t8, $t8, -0x6680
    ctx->r24 = ADD32(ctx->r24, -0X6680);
    // 0x8012ACC8: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012ACCC: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8012ACD0: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012ACD4: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8012ACD8: lw          $a1, 0x4($a2)
    ctx->r5 = MEM_W(ctx->r6, 0X4);
    // 0x8012ACDC: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x8012ACE0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8012ACE4: sw          $v1, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r3;
    // 0x8012ACE8: sw          $v1, 0x44($v0)
    MEM_W(0X44, ctx->r2) = ctx->r3;
    // 0x8012ACEC: sw          $a1, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->r5;
    // 0x8012ACF0: jal         0x80139390
    // 0x8012ACF4: sw          $a1, 0x40($v0)
    MEM_W(0X40, ctx->r2) = ctx->r5;
    osViBlack_recomp(rdram, ctx);
        goto after_2;
    // 0x8012ACF4: sw          $a1, 0x40($v0)
    MEM_W(0X40, ctx->r2) = ctx->r5;
    after_2:
    // 0x8012ACF8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012ACFC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012AD00: jr          $ra
    // 0x8012AD04: nop

    return;
    // 0x8012AD04: nop

;}
RECOMP_FUNC void func_8012AD08(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012AD08: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012AD0C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012AD10: jal         0x80139390
    // 0x8012AD14: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    osViBlack_recomp(rdram, ctx);
        goto after_0;
    // 0x8012AD14: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_0:
    // 0x8012AD18: jal         0x8012AC40
    // 0x8012AD1C: nop

    set_tv_mode_normal(rdram, ctx);
        goto after_1;
    // 0x8012AD1C: nop

    after_1:
    // 0x8012AD20: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012AD24: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012AD28: jr          $ra
    // 0x8012AD2C: nop

    return;
    // 0x8012AD2C: nop

;}
RECOMP_FUNC void draw_rectangle(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012AD30: lbu         $t0, 0x23($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X23);
    // 0x8012AD34: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012AD38: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8012AD3C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8012AD40: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8012AD44: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x8012AD48: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x8012AD4C: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8012AD50: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012AD54: beq         $t0, $zero, L_8012B0E0
    if (ctx->r8 == 0) {
        // 0x8012AD58: sra         $a1, $t6, 16
        ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
            goto L_8012B0E0;
    }
    // 0x8012AD58: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012AD5C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AD60: lui         $v1, 0xE700
    ctx->r3 = S32(0XE700 << 16);
    // 0x8012AD64: lui         $t5, 0x50
    ctx->r13 = S32(0X50 << 16);
    // 0x8012AD68: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012AD6C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012AD70: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012AD74: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8012AD78: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AD7C: ori         $t5, $t5, 0x3C4
    ctx->r13 = ctx->r13 | 0X3C4;
    // 0x8012AD80: lui         $t9, 0xED00
    ctx->r25 = S32(0XED00 << 16);
    // 0x8012AD84: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012AD88: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012AD8C: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8012AD90: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012AD94: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AD98: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x8012AD9C: ori         $t8, $t8, 0x2
    ctx->r24 = ctx->r24 | 0X2;
    // 0x8012ADA0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012ADA4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012ADA8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012ADAC: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8012ADB0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012ADB4: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x8012ADB8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012ADBC: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012ADC0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012ADC4: bne         $t0, $at, L_8012AED4
    if (ctx->r8 != ctx->r1) {
        // 0x8012ADC8: sw          $t8, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->r24;
            goto L_8012AED4;
    }
    // 0x8012ADC8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012ADCC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012ADD0: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x8012ADD4: ori         $t6, $t6, 0x1402
    ctx->r14 = ctx->r14 | 0X1402;
    // 0x8012ADD8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012ADDC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012ADE0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012ADE4: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8012ADE8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012ADEC: lui         $t7, 0x30
    ctx->r15 = S32(0X30 << 16);
    // 0x8012ADF0: lui         $at, 0xF600
    ctx->r1 = S32(0XF600 << 16);
    // 0x8012ADF4: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012ADF8: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012ADFC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012AE00: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012AE04: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AE08: lui         $t5, 0xB900
    ctx->r13 = S32(0XB900 << 16);
    // 0x8012AE0C: ori         $t5, $t5, 0x31D
    ctx->r13 = ctx->r13 | 0X31D;
    // 0x8012AE10: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012AE14: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012AE18: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012AE1C: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8012AE20: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AE24: lui         $t7, 0xF700
    ctx->r15 = S32(0XF700 << 16);
    // 0x8012AE28: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012AE2C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012AE30: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012AE34: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012AE38: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AE3C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012AE40: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012AE44: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012AE48: lbu         $t6, 0x1B($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X1B);
    // 0x8012AE4C: lbu         $t8, 0x17($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X17);
    // 0x8012AE50: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x8012AE54: lbu         $t6, 0x1F($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X1F);
    // 0x8012AE58: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x8012AE5C: andi        $t8, $t7, 0x7C0
    ctx->r24 = ctx->r15 & 0X7C0;
    // 0x8012AE60: andi        $t5, $t9, 0xF800
    ctx->r13 = ctx->r25 & 0XF800;
    // 0x8012AE64: or          $t9, $t5, $t8
    ctx->r25 = ctx->r13 | ctx->r24;
    // 0x8012AE68: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x8012AE6C: andi        $t5, $t7, 0x3E
    ctx->r13 = ctx->r15 & 0X3E;
    // 0x8012AE70: or          $t1, $t9, $t5
    ctx->r9 = ctx->r25 | ctx->r13;
    // 0x8012AE74: ori         $t8, $t1, 0x1
    ctx->r24 = ctx->r9 | 0X1;
    // 0x8012AE78: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x8012AE7C: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x8012AE80: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012AE84: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AE88: addiu       $t5, $a3, -0x1
    ctx->r13 = ADD32(ctx->r7, -0X1);
    // 0x8012AE8C: andi        $t8, $t5, 0x3FF
    ctx->r24 = ctx->r13 & 0X3FF;
    // 0x8012AE90: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012AE94: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012AE98: lh          $t9, 0x12($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X12);
    // 0x8012AE9C: sll         $t6, $t8, 14
    ctx->r14 = S32(ctx->r24 << 14);
    // 0x8012AEA0: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x8012AEA4: addiu       $t5, $t9, -0x1
    ctx->r13 = ADD32(ctx->r25, -0X1);
    // 0x8012AEA8: andi        $t8, $t5, 0x3FF
    ctx->r24 = ctx->r13 & 0X3FF;
    // 0x8012AEAC: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x8012AEB0: or          $t9, $t7, $t6
    ctx->r25 = ctx->r15 | ctx->r14;
    // 0x8012AEB4: andi        $t7, $a2, 0x3FF
    ctx->r15 = ctx->r6 & 0X3FF;
    // 0x8012AEB8: andi        $t5, $a1, 0x3FF
    ctx->r13 = ctx->r5 & 0X3FF;
    // 0x8012AEBC: sll         $t8, $t5, 14
    ctx->r24 = S32(ctx->r13 << 14);
    // 0x8012AEC0: sll         $t6, $t7, 2
    ctx->r14 = S32(ctx->r15 << 2);
    // 0x8012AEC4: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012AEC8: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8012AECC: b           L_8012B04C
    // 0x8012AED0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
        goto L_8012B04C;
    // 0x8012AED0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
L_8012AED4:
    // 0x8012AED4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AED8: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8012AEDC: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x8012AEE0: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012AEE4: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012AEE8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012AEEC: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8012AEF0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AEF4: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x8012AEF8: ori         $t9, $t9, 0x602
    ctx->r25 = ctx->r25 | 0X602;
    // 0x8012AEFC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012AF00: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012AF04: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012AF08: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012AF0C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AF10: addiu       $t5, $zero, 0x80
    ctx->r13 = ADD32(0, 0X80);
    // 0x8012AF14: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8012AF18: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012AF1C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012AF20: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8012AF24: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012AF28: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AF2C: addiu       $t6, $zero, 0x30
    ctx->r14 = ADD32(0, 0X30);
    // 0x8012AF30: ori         $t8, $t8, 0x402
    ctx->r24 = ctx->r24 | 0X402;
    // 0x8012AF34: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012AF38: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012AF3C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012AF40: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012AF44: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AF48: lui         $t5, 0xFA00
    ctx->r13 = S32(0XFA00 << 16);
    // 0x8012AF4C: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x8012AF50: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012AF54: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012AF58: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012AF5C: lbu         $t5, 0x1B($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X1B);
    // 0x8012AF60: lbu         $t8, 0x17($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X17);
    // 0x8012AF64: lui         $t9, 0x50
    ctx->r25 = S32(0X50 << 16);
    // 0x8012AF68: sll         $t7, $t5, 16
    ctx->r15 = S32(ctx->r13 << 16);
    // 0x8012AF6C: lbu         $t5, 0x1F($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X1F);
    // 0x8012AF70: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8012AF74: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8012AF78: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x8012AF7C: lbu         $t5, 0x23($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X23);
    // 0x8012AF80: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8012AF84: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012AF88: or          $t8, $t7, $t5
    ctx->r24 = ctx->r15 | ctx->r13;
    // 0x8012AF8C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8012AF90: lb          $t6, 0x4288($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X4288);
    // 0x8012AF94: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8012AF98: ori         $t7, $t7, 0x31D
    ctx->r15 = ctx->r15 | 0X31D;
    // 0x8012AF9C: bne         $t6, $at, L_8012AFC4
    if (ctx->r14 != ctx->r1) {
        // 0x8012AFA0: ori         $t9, $t9, 0x4240
        ctx->r25 = ctx->r25 | 0X4240;
            goto L_8012AFC4;
    }
    // 0x8012AFA0: ori         $t9, $t9, 0x4240
    ctx->r25 = ctx->r25 | 0X4240;
    // 0x8012AFA4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AFA8: lui         $t5, 0x50
    ctx->r13 = S32(0X50 << 16);
    // 0x8012AFAC: ori         $t5, $t5, 0x41C8
    ctx->r13 = ctx->r13 | 0X41C8;
    // 0x8012AFB0: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012AFB4: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012AFB8: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8012AFBC: b           L_8012AFE0
    // 0x8012AFC0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
        goto L_8012AFE0;
    // 0x8012AFC0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
L_8012AFC4:
    // 0x8012AFC4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AFC8: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x8012AFCC: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x8012AFD0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012AFD4: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012AFD8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012AFDC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
L_8012AFE0:
    // 0x8012AFE0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012AFE4: lui         $t5, 0xFCFF
    ctx->r13 = S32(0XFCFF << 16);
    // 0x8012AFE8: lui         $t8, 0xFFFD
    ctx->r24 = S32(0XFFFD << 16);
    // 0x8012AFEC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012AFF0: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012AFF4: ori         $t8, $t8, 0xF6FB
    ctx->r24 = ctx->r24 | 0XF6FB;
    // 0x8012AFF8: ori         $t5, $t5, 0xFFFF
    ctx->r13 = ctx->r13 | 0XFFFF;
    // 0x8012AFFC: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012B000: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8012B004: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012B008: andi        $t9, $a3, 0x3FF
    ctx->r25 = ctx->r7 & 0X3FF;
    // 0x8012B00C: sll         $t7, $t9, 14
    ctx->r15 = S32(ctx->r25 << 14);
    // 0x8012B010: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012B014: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012B018: lh          $t8, 0x12($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X12);
    // 0x8012B01C: lui         $at, 0xF600
    ctx->r1 = S32(0XF600 << 16);
    // 0x8012B020: or          $t5, $t7, $at
    ctx->r13 = ctx->r15 | ctx->r1;
    // 0x8012B024: andi        $t6, $t8, 0x3FF
    ctx->r14 = ctx->r24 & 0X3FF;
    // 0x8012B028: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x8012B02C: or          $t7, $t5, $t9
    ctx->r15 = ctx->r13 | ctx->r25;
    // 0x8012B030: andi        $t5, $a2, 0x3FF
    ctx->r13 = ctx->r6 & 0X3FF;
    // 0x8012B034: andi        $t8, $a1, 0x3FF
    ctx->r24 = ctx->r5 & 0X3FF;
    // 0x8012B038: sll         $t6, $t8, 14
    ctx->r14 = S32(ctx->r24 << 14);
    // 0x8012B03C: sll         $t9, $t5, 2
    ctx->r25 = S32(ctx->r13 << 2);
    // 0x8012B040: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012B044: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x8012B048: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
L_8012B04C:
    // 0x8012B04C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012B050: lui         $t5, 0xED02
    ctx->r13 = S32(0XED02 << 16);
    // 0x8012B054: ori         $t5, $t5, 0x20
    ctx->r13 = ctx->r13 | 0X20;
    // 0x8012B058: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012B05C: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012B060: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012B064: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012B068: lh          $t6, 0x3FD0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X3FD0);
    // 0x8012B06C: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8012B070: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8012B074: addiu       $t9, $t6, -0x8
    ctx->r25 = ADD32(ctx->r14, -0X8);
    // 0x8012B078: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8012B07C: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x8012B080: lh          $t9, 0x3FD2($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FD2);
    // 0x8012B084: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012B088: addiu       $t7, $t9, -0x8
    ctx->r15 = ADD32(ctx->r25, -0X8);
    // 0x8012B08C: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x8012B090: nop

    // 0x8012B094: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8012B098: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x8012B09C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012B0A0: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8012B0A4: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x8012B0A8: nop

    // 0x8012B0AC: andi        $t5, $t8, 0xFFF
    ctx->r13 = ctx->r24 & 0XFFF;
    // 0x8012B0B0: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8012B0B4: sll         $t6, $t5, 12
    ctx->r14 = S32(ctx->r13 << 12);
    // 0x8012B0B8: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x8012B0BC: nop

    // 0x8012B0C0: andi        $t9, $t5, 0xFFF
    ctx->r25 = ctx->r13 & 0XFFF;
    // 0x8012B0C4: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x8012B0C8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012B0CC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012B0D0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012B0D4: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012B0D8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012B0DC: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
L_8012B0E0:
    // 0x8012B0E0: jr          $ra
    // 0x8012B0E4: nop

    return;
    // 0x8012B0E4: nop

;}
RECOMP_FUNC void UnpackRNC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B0F0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012B0F4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012B0F8: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x8012B0FC: addiu       $at, $zero, 0x52
    ctx->r1 = ADD32(0, 0X52);
    // 0x8012B100: bne         $t6, $at, L_8012B128
    if (ctx->r14 != ctx->r1) {
        // 0x8012B104: nop
    
            goto L_8012B128;
    }
    // 0x8012B104: nop

    // 0x8012B108: lbu         $t7, 0x1($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X1);
    // 0x8012B10C: addiu       $at, $zero, 0x4E
    ctx->r1 = ADD32(0, 0X4E);
    // 0x8012B110: bne         $t7, $at, L_8012B128
    if (ctx->r15 != ctx->r1) {
        // 0x8012B114: nop
    
            goto L_8012B128;
    }
    // 0x8012B114: nop

    // 0x8012B118: lbu         $t8, 0x2($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X2);
    // 0x8012B11C: addiu       $at, $zero, 0x43
    ctx->r1 = ADD32(0, 0X43);
    // 0x8012B120: beql        $t8, $at, L_8012B134
    if (ctx->r24 == ctx->r1) {
        // 0x8012B124: lbu         $v0, 0x3($a0)
        ctx->r2 = MEM_BU(ctx->r4, 0X3);
            goto L_8012B134;
    }
    goto skip_0;
    // 0x8012B124: lbu         $v0, 0x3($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X3);
    skip_0:
L_8012B128:
    // 0x8012B128: b           L_8012B184
    // 0x8012B12C: ori         $v0, $zero, 0xFFFF
    ctx->r2 = 0 | 0XFFFF;
        goto L_8012B184;
    // 0x8012B12C: ori         $v0, $zero, 0xFFFF
    ctx->r2 = 0 | 0XFFFF;
    // 0x8012B130: lbu         $v0, 0x3($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X3);
L_8012B134:
    // 0x8012B134: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012B138: beq         $v0, $zero, L_8012B158
    if (ctx->r2 == 0) {
        // 0x8012B13C: nop
    
            goto L_8012B158;
    }
    // 0x8012B13C: nop

    // 0x8012B140: beq         $v0, $at, L_8012B160
    if (ctx->r2 == ctx->r1) {
        // 0x8012B144: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8012B160;
    }
    // 0x8012B144: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012B148: beq         $v0, $at, L_8012B170
    if (ctx->r2 == ctx->r1) {
        // 0x8012B14C: ori         $v1, $zero, 0xFFFE
        ctx->r3 = 0 | 0XFFFE;
            goto L_8012B170;
    }
    // 0x8012B14C: ori         $v1, $zero, 0xFFFE
    ctx->r3 = 0 | 0XFFFE;
    // 0x8012B150: b           L_8012B180
    // 0x8012B154: nop

        goto L_8012B180;
    // 0x8012B154: nop

L_8012B158:
    // 0x8012B158: b           L_8012B180
    // 0x8012B15C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_8012B180;
    // 0x8012B15C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8012B160:
    // 0x8012B160: jal         0x8012B194
    // 0x8012B164: nop

    UnpackMethod1(rdram, ctx);
        goto after_0;
    // 0x8012B164: nop

    after_0:
    // 0x8012B168: b           L_8012B180
    // 0x8012B16C: andi        $v1, $v0, 0xFFFF
    ctx->r3 = ctx->r2 & 0XFFFF;
        goto L_8012B180;
    // 0x8012B16C: andi        $v1, $v0, 0xFFFF
    ctx->r3 = ctx->r2 & 0XFFFF;
L_8012B170:
    // 0x8012B170: jal         0x8012B3B8
    // 0x8012B174: nop

    UnpackMethod2(rdram, ctx);
        goto after_1;
    // 0x8012B174: nop

    after_1:
    // 0x8012B178: b           L_8012B180
    // 0x8012B17C: andi        $v1, $v0, 0xFFFF
    ctx->r3 = ctx->r2 & 0XFFFF;
        goto L_8012B180;
    // 0x8012B17C: andi        $v1, $v0, 0xFFFF
    ctx->r3 = ctx->r2 & 0XFFFF;
L_8012B180:
    // 0x8012B180: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_8012B184:
    // 0x8012B184: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012B188: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012B18C: jr          $ra
    // 0x8012B190: nop

    return;
    // 0x8012B190: nop

;}
RECOMP_FUNC void UnpackMethod1(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B194: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x8012B198: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8012B19C: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8012B1A0: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x8012B1A4: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8012B1A8: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8012B1AC: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012B1B0: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012B1B4: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012B1B8: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012B1BC: jal         0x8012B648
    // 0x8012B1C0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    InitUnpack(rdram, ctx);
        goto after_0;
    // 0x8012B1C0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    after_0:
    // 0x8012B1C4: jal         0x8012B704
    // 0x8012B1C8: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    InputBitsM1(rdram, ctx);
        goto after_1;
    // 0x8012B1C8: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_1:
    // 0x8012B1CC: lui         $s1, 0x8023
    ctx->r17 = S32(0X8023 << 16);
    // 0x8012B1D0: addiu       $s1, $s1, -0x1F24
    ctx->r17 = ADD32(ctx->r17, -0X1F24);
    // 0x8012B1D4: lui         $t7, 0x8023
    ctx->r15 = S32(0X8023 << 16);
    // 0x8012B1D8: lw          $t7, -0x1F2C($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X1F2C);
    // 0x8012B1DC: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012B1E0: lui         $fp, 0x8023
    ctx->r30 = S32(0X8023 << 16);
    // 0x8012B1E4: addiu       $fp, $fp, -0x1C1C
    ctx->r30 = ADD32(ctx->r30, -0X1C1C);
    // 0x8012B1E8: sltu        $at, $t6, $t7
    ctx->r1 = ctx->r14 < ctx->r15 ? 1 : 0;
    // 0x8012B1EC: beq         $at, $zero, L_8012B384
    if (ctx->r1 == 0) {
        // 0x8012B1F0: lui         $s7, 0x8023
        ctx->r23 = S32(0X8023 << 16);
            goto L_8012B384;
    }
    // 0x8012B1F0: lui         $s7, 0x8023
    ctx->r23 = S32(0X8023 << 16);
    // 0x8012B1F4: lui         $s6, 0x8023
    ctx->r22 = S32(0X8023 << 16);
    // 0x8012B1F8: lui         $s5, 0x8023
    ctx->r21 = S32(0X8023 << 16);
    // 0x8012B1FC: lui         $s4, 0x8023
    ctx->r20 = S32(0X8023 << 16);
    // 0x8012B200: lui         $s2, 0x8023
    ctx->r18 = S32(0X8023 << 16);
    // 0x8012B204: addiu       $s2, $s2, -0x1C20
    ctx->r18 = ADD32(ctx->r18, -0X1C20);
    // 0x8012B208: addiu       $s4, $s4, -0x1F28
    ctx->r20 = ADD32(ctx->r20, -0X1F28);
    // 0x8012B20C: addiu       $s5, $s5, -0x1F20
    ctx->r21 = ADD32(ctx->r21, -0X1F20);
    // 0x8012B210: addiu       $s6, $s6, -0x1E20
    ctx->r22 = ADD32(ctx->r22, -0X1E20);
    // 0x8012B214: addiu       $s7, $s7, -0x1D20
    ctx->r23 = ADD32(ctx->r23, -0X1D20);
    // 0x8012B218: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_8012B21C:
    // 0x8012B21C: jal         0x8012B8B4
    // 0x8012B220: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    InputHuffmanTable(rdram, ctx);
        goto after_2;
    // 0x8012B220: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_2:
    // 0x8012B224: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x8012B228: jal         0x8012B8B4
    // 0x8012B22C: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    InputHuffmanTable(rdram, ctx);
        goto after_3;
    // 0x8012B22C: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x8012B230: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8012B234: jal         0x8012B8B4
    // 0x8012B238: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    InputHuffmanTable(rdram, ctx);
        goto after_4;
    // 0x8012B238: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_4:
    // 0x8012B23C: jal         0x8012B704
    // 0x8012B240: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    InputBitsM1(rdram, ctx);
        goto after_5;
    // 0x8012B240: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    after_5:
    // 0x8012B244: b           L_8012B2B0
    // 0x8012B248: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
        goto L_8012B2B0;
    // 0x8012B248: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
L_8012B24C:
    // 0x8012B24C: jal         0x8012B958
    // 0x8012B250: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    InputValue(rdram, ctx);
        goto after_6;
    // 0x8012B250: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    after_6:
    // 0x8012B254: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x8012B258: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8012B25C: subu        $s0, $t8, $v0
    ctx->r16 = SUB32(ctx->r24, ctx->r2);
    // 0x8012B260: jal         0x8012B958
    // 0x8012B264: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    InputValue(rdram, ctx);
        goto after_7;
    // 0x8012B264: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    after_7:
    // 0x8012B268: addiu       $a0, $v0, 0x2
    ctx->r4 = ADD32(ctx->r2, 0X2);
    // 0x8012B26C: andi        $t9, $a0, 0xFFFF
    ctx->r25 = ctx->r4 & 0XFFFF;
    // 0x8012B270: addiu       $v1, $t9, -0x1
    ctx->r3 = ADD32(ctx->r25, -0X1);
    // 0x8012B274: andi        $t0, $v1, 0xFFFF
    ctx->r8 = ctx->r3 & 0XFFFF;
    // 0x8012B278: beq         $t9, $zero, L_8012B2B0
    if (ctx->r25 == 0) {
        // 0x8012B27C: or          $v1, $t0, $zero
        ctx->r3 = ctx->r8 | 0;
            goto L_8012B2B0;
    }
    // 0x8012B27C: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
L_8012B280:
    // 0x8012B280: lbu         $t1, 0x0($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X0);
    // 0x8012B284: lw          $t2, 0x0($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X0);
    // 0x8012B288: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8012B28C: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x8012B290: sb          $t1, 0x0($t2)
    MEM_B(0X0, ctx->r10) = ctx->r9;
    // 0x8012B294: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x8012B298: andi        $t5, $v1, 0xFFFF
    ctx->r13 = ctx->r3 & 0XFFFF;
    // 0x8012B29C: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x8012B2A0: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8012B2A4: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x8012B2A8: bne         $v0, $zero, L_8012B280
    if (ctx->r2 != 0) {
        // 0x8012B2AC: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8012B280;
    }
    // 0x8012B2AC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8012B2B0:
    // 0x8012B2B0: jal         0x8012B958
    // 0x8012B2B4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    InputValue(rdram, ctx);
        goto after_8;
    // 0x8012B2B4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    after_8:
    // 0x8012B2B8: addiu       $v1, $v0, -0x1
    ctx->r3 = ADD32(ctx->r2, -0X1);
    // 0x8012B2BC: andi        $t6, $v1, 0xFFFF
    ctx->r14 = ctx->r3 & 0XFFFF;
    // 0x8012B2C0: beq         $v0, $zero, L_8012B304
    if (ctx->r2 == 0) {
        // 0x8012B2C4: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_8012B304;
    }
    // 0x8012B2C4: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_8012B2C8:
    // 0x8012B2C8: lw          $t7, 0x0($s2)
    ctx->r15 = MEM_W(ctx->r18, 0X0);
    // 0x8012B2CC: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x8012B2D0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8012B2D4: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x8012B2D8: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x8012B2DC: andi        $t4, $v1, 0xFFFF
    ctx->r12 = ctx->r3 & 0XFFFF;
    // 0x8012B2E0: sb          $t8, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r24;
    // 0x8012B2E4: lw          $t2, 0x0($s2)
    ctx->r10 = MEM_W(ctx->r18, 0X0);
    // 0x8012B2E8: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8012B2EC: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x8012B2F0: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x8012B2F4: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x8012B2F8: sw          $t1, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r9;
    // 0x8012B2FC: bne         $v0, $zero, L_8012B2C8
    if (ctx->r2 != 0) {
        // 0x8012B300: sw          $t3, 0x0($s2)
        MEM_W(0X0, ctx->r18) = ctx->r11;
            goto L_8012B2C8;
    }
    // 0x8012B300: sw          $t3, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r11;
L_8012B304:
    // 0x8012B304: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8012B308: jal         0x8012BB98
    // 0x8012B30C: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    ReverseWord(rdram, ctx);
        goto after_9;
    // 0x8012B30C: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    after_9:
    // 0x8012B310: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8012B314: andi        $s0, $v0, 0xFFFF
    ctx->r16 = ctx->r2 & 0XFFFF;
    // 0x8012B318: jal         0x8012BB6C
    // 0x8012B31C: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    ReverseLong(rdram, ctx);
        goto after_10;
    // 0x8012B31C: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    after_10:
    // 0x8012B320: lw          $t5, 0x0($s2)
    ctx->r13 = MEM_W(ctx->r18, 0X0);
    // 0x8012B324: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8012B328: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8012B32C: lbu         $t6, 0x0($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X0);
    // 0x8012B330: lw          $t2, 0x0($s4)
    ctx->r10 = MEM_W(ctx->r20, 0X0);
    // 0x8012B334: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8012B338: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x8012B33C: sll         $t9, $s0, 8
    ctx->r25 = S32(ctx->r16 << 8);
    // 0x8012B340: sllv        $t4, $t3, $v1
    ctx->r12 = S32(ctx->r11 << (ctx->r3 & 31));
    // 0x8012B344: addiu       $t5, $t4, -0x1
    ctx->r13 = ADD32(ctx->r12, -0X1);
    // 0x8012B348: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x8012B34C: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8012B350: sllv        $t1, $t0, $v1
    ctx->r9 = S32(ctx->r8 << (ctx->r3 & 31));
    // 0x8012B354: and         $t6, $t2, $t5
    ctx->r14 = ctx->r10 & ctx->r13;
    // 0x8012B358: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x8012B35C: andi        $t8, $s3, 0xFFFF
    ctx->r24 = ctx->r19 & 0XFFFF;
    // 0x8012B360: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x8012B364: bne         $t8, $zero, L_8012B24C
    if (ctx->r24 != 0) {
        // 0x8012B368: or          $s3, $t8, $zero
        ctx->r19 = ctx->r24 | 0;
            goto L_8012B24C;
    }
    // 0x8012B368: or          $s3, $t8, $zero
    ctx->r19 = ctx->r24 | 0;
    // 0x8012B36C: lui         $t0, 0x8023
    ctx->r8 = S32(0X8023 << 16);
    // 0x8012B370: lw          $t0, -0x1F2C($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X1F2C);
    // 0x8012B374: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x8012B378: sltu        $at, $t9, $t0
    ctx->r1 = ctx->r25 < ctx->r8 ? 1 : 0;
    // 0x8012B37C: bnel        $at, $zero, L_8012B21C
    if (ctx->r1 != 0) {
        // 0x8012B380: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8012B21C;
    }
    goto skip_0;
    // 0x8012B380: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_0:
L_8012B384:
    // 0x8012B384: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8012B388: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012B38C: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012B390: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012B394: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012B398: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012B39C: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8012B3A0: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8012B3A4: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x8012B3A8: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x8012B3AC: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x8012B3B0: jr          $ra
    // 0x8012B3B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x8012B3B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
;}
RECOMP_FUNC void UnpackMethod2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B3B8: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8012B3BC: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x8012B3C0: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012B3C4: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012B3C8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012B3CC: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012B3D0: jal         0x8012B648
    // 0x8012B3D4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    InitUnpack(rdram, ctx);
        goto after_0;
    // 0x8012B3D4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    after_0:
    // 0x8012B3D8: jal         0x8012B804
    // 0x8012B3DC: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    InputBitsM2(rdram, ctx);
        goto after_1;
    // 0x8012B3DC: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_1:
    // 0x8012B3E0: lui         $s1, 0x8023
    ctx->r17 = S32(0X8023 << 16);
    // 0x8012B3E4: addiu       $s1, $s1, -0x1F24
    ctx->r17 = ADD32(ctx->r17, -0X1F24);
    // 0x8012B3E8: lui         $t7, 0x8023
    ctx->r15 = S32(0X8023 << 16);
    // 0x8012B3EC: lw          $t7, -0x1F2C($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X1F2C);
    // 0x8012B3F0: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012B3F4: addiu       $s4, $zero, 0x9
    ctx->r20 = ADD32(0, 0X9);
    // 0x8012B3F8: addiu       $s3, $zero, 0x8
    ctx->r19 = ADD32(0, 0X8);
    // 0x8012B3FC: sltu        $at, $t6, $t7
    ctx->r1 = ctx->r14 < ctx->r15 ? 1 : 0;
    // 0x8012B400: beq         $at, $zero, L_8012B624
    if (ctx->r1 == 0) {
        // 0x8012B404: lui         $s2, 0x8023
        ctx->r18 = S32(0X8023 << 16);
            goto L_8012B624;
    }
    // 0x8012B404: lui         $s2, 0x8023
    ctx->r18 = S32(0X8023 << 16);
    // 0x8012B408: addiu       $s2, $s2, -0x1C20
    ctx->r18 = ADD32(ctx->r18, -0X1C20);
L_8012B40C:
    // 0x8012B40C: jal         0x8012B804
    // 0x8012B410: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_2;
    // 0x8012B410: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_2:
    // 0x8012B414: bne         $v0, $zero, L_8012B454
    if (ctx->r2 != 0) {
        // 0x8012B418: nop
    
            goto L_8012B454;
    }
    // 0x8012B418: nop

    // 0x8012B41C: lw          $t8, 0x0($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X0);
L_8012B420:
    // 0x8012B420: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8012B424: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8012B428: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x8012B42C: sb          $t9, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r25;
    // 0x8012B430: lw          $t3, 0x0($s2)
    ctx->r11 = MEM_W(ctx->r18, 0X0);
    // 0x8012B434: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x8012B438: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8012B43C: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x8012B440: sw          $t2, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r10;
    // 0x8012B444: jal         0x8012B804
    // 0x8012B448: sw          $t4, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r12;
    InputBitsM2(rdram, ctx);
        goto after_3;
    // 0x8012B448: sw          $t4, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r12;
    after_3:
    // 0x8012B44C: beql        $v0, $zero, L_8012B420
    if (ctx->r2 == 0) {
        // 0x8012B450: lw          $t8, 0x0($s2)
        ctx->r24 = MEM_W(ctx->r18, 0X0);
            goto L_8012B420;
    }
    goto skip_0;
    // 0x8012B450: lw          $t8, 0x0($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X0);
    skip_0:
L_8012B454:
    // 0x8012B454: jal         0x8012B804
    // 0x8012B458: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_4;
    // 0x8012B458: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_4:
    // 0x8012B45C: beq         $v0, $zero, L_8012B530
    if (ctx->r2 == 0) {
        // 0x8012B460: nop
    
            goto L_8012B530;
    }
    // 0x8012B460: nop

    // 0x8012B464: jal         0x8012B804
    // 0x8012B468: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_5;
    // 0x8012B468: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_5:
    // 0x8012B46C: bne         $v0, $zero, L_8012B498
    if (ctx->r2 != 0) {
        // 0x8012B470: nop
    
            goto L_8012B498;
    }
    // 0x8012B470: nop

    // 0x8012B474: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x8012B478: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
    // 0x8012B47C: lbu         $a1, 0x0($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X0);
    // 0x8012B480: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8012B484: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8012B488: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x8012B48C: andi        $t5, $a1, 0xFFFF
    ctx->r13 = ctx->r5 & 0XFFFF;
    // 0x8012B490: b           L_8012B4DC
    // 0x8012B494: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
        goto L_8012B4DC;
    // 0x8012B494: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
L_8012B498:
    // 0x8012B498: jal         0x8012B804
    // 0x8012B49C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_6;
    // 0x8012B49C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_6:
    // 0x8012B4A0: bnel        $v0, $zero, L_8012B4B4
    if (ctx->r2 != 0) {
        // 0x8012B4A4: lw          $v0, 0x0($s2)
        ctx->r2 = MEM_W(ctx->r18, 0X0);
            goto L_8012B4B4;
    }
    goto skip_1;
    // 0x8012B4A4: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    skip_1:
    // 0x8012B4A8: b           L_8012B4D0
    // 0x8012B4AC: addiu       $s0, $zero, 0x3
    ctx->r16 = ADD32(0, 0X3);
        goto L_8012B4D0;
    // 0x8012B4AC: addiu       $s0, $zero, 0x3
    ctx->r16 = ADD32(0, 0X3);
    // 0x8012B4B0: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
L_8012B4B4:
    // 0x8012B4B4: lbu         $s0, 0x0($v0)
    ctx->r16 = MEM_BU(ctx->r2, 0X0);
    // 0x8012B4B8: addiu       $t8, $v0, 0x1
    ctx->r24 = ADD32(ctx->r2, 0X1);
    // 0x8012B4BC: sw          $t8, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r24;
    // 0x8012B4C0: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
    // 0x8012B4C4: andi        $t7, $s0, 0xFFFF
    ctx->r15 = ctx->r16 & 0XFFFF;
    // 0x8012B4C8: beq         $s3, $t7, L_8012B604
    if (ctx->r19 == ctx->r15) {
        // 0x8012B4CC: or          $s0, $t7, $zero
        ctx->r16 = ctx->r15 | 0;
            goto L_8012B604;
    }
    // 0x8012B4CC: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
L_8012B4D0:
    // 0x8012B4D0: jal         0x8012BA98
    // 0x8012B4D4: nop

    InputPosM2(rdram, ctx);
        goto after_7;
    // 0x8012B4D4: nop

    after_7:
    // 0x8012B4D8: andi        $a1, $v0, 0xFFFF
    ctx->r5 = ctx->r2 & 0XFFFF;
L_8012B4DC:
    // 0x8012B4DC: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8012B4E0: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x8012B4E4: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B4E8: andi        $t0, $s0, 0xFFFF
    ctx->r8 = ctx->r16 & 0XFFFF;
    // 0x8012B4EC: or          $s0, $t0, $zero
    ctx->r16 = ctx->r8 | 0;
    // 0x8012B4F0: beq         $v1, $zero, L_8012B40C
    if (ctx->r3 == 0) {
        // 0x8012B4F4: subu        $a0, $t9, $a1
        ctx->r4 = SUB32(ctx->r25, ctx->r5);
            goto L_8012B40C;
    }
    // 0x8012B4F4: subu        $a0, $t9, $a1
    ctx->r4 = SUB32(ctx->r25, ctx->r5);
L_8012B4F8:
    // 0x8012B4F8: lbu         $t1, 0x0($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X0);
    // 0x8012B4FC: lw          $t2, 0x0($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X0);
    // 0x8012B500: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8012B504: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B508: sb          $t1, 0x0($t2)
    MEM_B(0X0, ctx->r10) = ctx->r9;
    // 0x8012B50C: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x8012B510: andi        $t5, $s0, 0xFFFF
    ctx->r13 = ctx->r16 & 0XFFFF;
    // 0x8012B514: or          $s0, $t5, $zero
    ctx->r16 = ctx->r13 | 0;
    // 0x8012B518: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8012B51C: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x8012B520: bne         $v1, $zero, L_8012B4F8
    if (ctx->r3 != 0) {
        // 0x8012B524: addiu       $a0, $a0, 0x1
        ctx->r4 = ADD32(ctx->r4, 0X1);
            goto L_8012B4F8;
    }
    // 0x8012B524: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x8012B528: b           L_8012B40C
    // 0x8012B52C: nop

        goto L_8012B40C;
    // 0x8012B52C: nop

L_8012B530:
    // 0x8012B530: jal         0x8012BA38
    // 0x8012B534: nop

    InputLenM2(rdram, ctx);
        goto after_8;
    // 0x8012B534: nop

    after_8:
    // 0x8012B538: bne         $s4, $v0, L_8012B5A8
    if (ctx->r20 != ctx->r2) {
        // 0x8012B53C: andi        $s0, $v0, 0xFFFF
        ctx->r16 = ctx->r2 & 0XFFFF;
            goto L_8012B5A8;
    }
    // 0x8012B53C: andi        $s0, $v0, 0xFFFF
    ctx->r16 = ctx->r2 & 0XFFFF;
    // 0x8012B540: jal         0x8012B804
    // 0x8012B544: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    InputBitsM2(rdram, ctx);
        goto after_9;
    // 0x8012B544: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_9:
    // 0x8012B548: sll         $v1, $v0, 2
    ctx->r3 = S32(ctx->r2 << 2);
    // 0x8012B54C: addiu       $v1, $v1, 0xC
    ctx->r3 = ADD32(ctx->r3, 0XC);
    // 0x8012B550: andi        $t6, $v1, 0xFFFF
    ctx->r14 = ctx->r3 & 0XFFFF;
    // 0x8012B554: addiu       $s0, $t6, -0x1
    ctx->r16 = ADD32(ctx->r14, -0X1);
    // 0x8012B558: andi        $t7, $s0, 0xFFFF
    ctx->r15 = ctx->r16 & 0XFFFF;
    // 0x8012B55C: beq         $t6, $zero, L_8012B40C
    if (ctx->r14 == 0) {
        // 0x8012B560: or          $s0, $t7, $zero
        ctx->r16 = ctx->r15 | 0;
            goto L_8012B40C;
    }
    // 0x8012B560: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
L_8012B564:
    // 0x8012B564: lw          $t8, 0x0($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X0);
    // 0x8012B568: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8012B56C: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8012B570: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x8012B574: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B578: andi        $t5, $s0, 0xFFFF
    ctx->r13 = ctx->r16 & 0XFFFF;
    // 0x8012B57C: sb          $t9, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r25;
    // 0x8012B580: lw          $t3, 0x0($s2)
    ctx->r11 = MEM_W(ctx->r18, 0X0);
    // 0x8012B584: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x8012B588: or          $s0, $t5, $zero
    ctx->r16 = ctx->r13 | 0;
    // 0x8012B58C: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8012B590: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x8012B594: sw          $t2, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r10;
    // 0x8012B598: bne         $v1, $zero, L_8012B564
    if (ctx->r3 != 0) {
        // 0x8012B59C: sw          $t4, 0x0($s2)
        MEM_W(0X0, ctx->r18) = ctx->r12;
            goto L_8012B564;
    }
    // 0x8012B59C: sw          $t4, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r12;
    // 0x8012B5A0: b           L_8012B40C
    // 0x8012B5A4: nop

        goto L_8012B40C;
    // 0x8012B5A4: nop

L_8012B5A8:
    // 0x8012B5A8: jal         0x8012BA98
    // 0x8012B5AC: nop

    InputPosM2(rdram, ctx);
        goto after_10;
    // 0x8012B5AC: nop

    after_10:
    // 0x8012B5B0: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8012B5B4: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012B5B8: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B5BC: andi        $t7, $s0, 0xFFFF
    ctx->r15 = ctx->r16 & 0XFFFF;
    // 0x8012B5C0: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
    // 0x8012B5C4: beq         $v1, $zero, L_8012B40C
    if (ctx->r3 == 0) {
        // 0x8012B5C8: subu        $a0, $t6, $v0
        ctx->r4 = SUB32(ctx->r14, ctx->r2);
            goto L_8012B40C;
    }
    // 0x8012B5C8: subu        $a0, $t6, $v0
    ctx->r4 = SUB32(ctx->r14, ctx->r2);
L_8012B5CC:
    // 0x8012B5CC: lbu         $t8, 0x0($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X0);
    // 0x8012B5D0: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x8012B5D4: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8012B5D8: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B5DC: sb          $t8, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r24;
    // 0x8012B5E0: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x8012B5E4: andi        $t2, $s0, 0xFFFF
    ctx->r10 = ctx->r16 & 0XFFFF;
    // 0x8012B5E8: or          $s0, $t2, $zero
    ctx->r16 = ctx->r10 | 0;
    // 0x8012B5EC: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x8012B5F0: sw          $t1, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r9;
    // 0x8012B5F4: bne         $v1, $zero, L_8012B5CC
    if (ctx->r3 != 0) {
        // 0x8012B5F8: addiu       $a0, $a0, 0x1
        ctx->r4 = ADD32(ctx->r4, 0X1);
            goto L_8012B5CC;
    }
    // 0x8012B5F8: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x8012B5FC: b           L_8012B40C
    // 0x8012B600: nop

        goto L_8012B40C;
    // 0x8012B600: nop

L_8012B604:
    // 0x8012B604: jal         0x8012B804
    // 0x8012B608: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_11;
    // 0x8012B608: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_11:
    // 0x8012B60C: lui         $t4, 0x8023
    ctx->r12 = S32(0X8023 << 16);
    // 0x8012B610: lw          $t4, -0x1F2C($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X1F2C);
    // 0x8012B614: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x8012B618: sltu        $at, $t3, $t4
    ctx->r1 = ctx->r11 < ctx->r12 ? 1 : 0;
    // 0x8012B61C: bne         $at, $zero, L_8012B40C
    if (ctx->r1 != 0) {
        // 0x8012B620: nop
    
            goto L_8012B40C;
    }
    // 0x8012B620: nop

L_8012B624:
    // 0x8012B624: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8012B628: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012B62C: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012B630: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012B634: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012B638: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012B63C: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x8012B640: jr          $ra
    // 0x8012B644: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x8012B644: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
;}
RECOMP_FUNC void InitUnpack(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B648: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8012B64C: addiu       $t6, $a0, 0x12
    ctx->r14 = ADD32(ctx->r4, 0X12);
    // 0x8012B650: lui         $at, 0x8023
    ctx->r1 = S32(0X8023 << 16);
    // 0x8012B654: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012B658: sw          $t6, -0x1C20($at)
    MEM_W(-0X1C20, ctx->r1) = ctx->r14;
    // 0x8012B65C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8012B660: lui         $at, 0x8023
    ctx->r1 = S32(0X8023 << 16);
    // 0x8012B664: addiu       $s0, $a0, 0x4
    ctx->r16 = ADD32(ctx->r4, 0X4);
    // 0x8012B668: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x8012B66C: sw          $a1, -0x1F24($at)
    MEM_W(-0X1F24, ctx->r1) = ctx->r5;
    // 0x8012B670: jal         0x8012BB6C
    // 0x8012B674: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    ReverseLong(rdram, ctx);
        goto after_0;
    // 0x8012B674: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x8012B678: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x8012B67C: jal         0x8012BB6C
    // 0x8012B680: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    ReverseLong(rdram, ctx);
        goto after_1;
    // 0x8012B680: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x8012B684: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x8012B688: jal         0x8012BB6C
    // 0x8012B68C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    ReverseLong(rdram, ctx);
        goto after_2;
    // 0x8012B68C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
    // 0x8012B690: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    // 0x8012B694: jal         0x8012BB6C
    // 0x8012B698: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    ReverseLong(rdram, ctx);
        goto after_3;
    // 0x8012B698: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_3:
    // 0x8012B69C: srl         $t8, $v0, 16
    ctx->r24 = S32(U32(ctx->r2) >> 16);
    // 0x8012B6A0: lw          $t1, 0x2C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X2C);
    // 0x8012B6A4: andi        $t9, $t8, 0xFF00
    ctx->r25 = ctx->r24 & 0XFF00;
    // 0x8012B6A8: srl         $t0, $t9, 8
    ctx->r8 = S32(U32(ctx->r25) >> 8);
    // 0x8012B6AC: lw          $t9, 0x24($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X24);
    // 0x8012B6B0: lw          $t7, 0x28($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X28);
    // 0x8012B6B4: srl         $t2, $t1, 16
    ctx->r10 = S32(U32(ctx->r9) >> 16);
    // 0x8012B6B8: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x8012B6BC: sll         $t4, $t3, 8
    ctx->r12 = S32(ctx->r11 << 8);
    // 0x8012B6C0: andi        $t1, $t9, 0xFF00
    ctx->r9 = ctx->r25 & 0XFF00;
    // 0x8012B6C4: srl         $t2, $t1, 8
    ctx->r10 = S32(U32(ctx->r9) >> 8);
    // 0x8012B6C8: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x8012B6CC: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x8012B6D0: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x8012B6D4: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x8012B6D8: sll         $t0, $t3, 16
    ctx->r8 = S32(ctx->r11 << 16);
    // 0x8012B6DC: addu        $t4, $t5, $t0
    ctx->r12 = ADD32(ctx->r13, ctx->r8);
    // 0x8012B6E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8012B6E4: lui         $at, 0x8023
    ctx->r1 = S32(0X8023 << 16);
    // 0x8012B6E8: addu        $t7, $t4, $t6
    ctx->r15 = ADD32(ctx->r12, ctx->r14);
    // 0x8012B6EC: sw          $t7, -0x1F2C($at)
    MEM_W(-0X1F2C, ctx->r1) = ctx->r15;
    // 0x8012B6F0: lui         $at, 0x8023
    ctx->r1 = S32(0X8023 << 16);
    // 0x8012B6F4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012B6F8: sb          $zero, -0x1C1C($at)
    MEM_B(-0X1C1C, ctx->r1) = 0;
    // 0x8012B6FC: jr          $ra
    // 0x8012B700: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x8012B700: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void InputBitsM1(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B704: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8012B708: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012B70C: andi        $s0, $a0, 0xFF
    ctx->r16 = ctx->r4 & 0XFF;
    // 0x8012B710: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8012B714: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B718: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8012B71C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012B720: andi        $t6, $s0, 0xFF
    ctx->r14 = ctx->r16 & 0XFF;
    // 0x8012B724: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8012B728: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8012B72C: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012B730: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012B734: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012B738: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x8012B73C: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x8012B740: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    // 0x8012B744: beq         $a1, $zero, L_8012B7D8
    if (ctx->r5 == 0) {
        // 0x8012B748: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_8012B7D8;
    }
    // 0x8012B748: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x8012B74C: lui         $s4, 0x8023
    ctx->r20 = S32(0X8023 << 16);
    // 0x8012B750: lui         $s3, 0x8023
    ctx->r19 = S32(0X8023 << 16);
    // 0x8012B754: lui         $s2, 0x8023
    ctx->r18 = S32(0X8023 << 16);
    // 0x8012B758: addiu       $s2, $s2, -0x1C1C
    ctx->r18 = ADD32(ctx->r18, -0X1C1C);
    // 0x8012B75C: addiu       $s3, $s3, -0x1C20
    ctx->r19 = ADD32(ctx->r19, -0X1C20);
    // 0x8012B760: addiu       $s4, $s4, -0x1F28
    ctx->r20 = ADD32(ctx->r20, -0X1F28);
    // 0x8012B764: addiu       $s6, $zero, 0x10
    ctx->r22 = ADD32(0, 0X10);
L_8012B768:
    // 0x8012B768: lbu         $v1, 0x0($s2)
    ctx->r3 = MEM_BU(ctx->r18, 0X0);
    // 0x8012B76C: bnel        $v1, $zero, L_8012B798
    if (ctx->r3 != 0) {
        // 0x8012B770: lw          $v0, 0x0($s4)
        ctx->r2 = MEM_W(ctx->r20, 0X0);
            goto L_8012B798;
    }
    goto skip_0;
    // 0x8012B770: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    skip_0:
    // 0x8012B774: jal         0x8012BB6C
    // 0x8012B778: lw          $a0, 0x0($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X0);
    ReverseLong(rdram, ctx);
        goto after_0;
    // 0x8012B778: lw          $a0, 0x0($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X0);
    after_0:
    // 0x8012B77C: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
    // 0x8012B780: sw          $v0, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r2;
    // 0x8012B784: sb          $s6, 0x0($s2)
    MEM_B(0X0, ctx->r18) = ctx->r22;
    // 0x8012B788: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x8012B78C: sw          $t8, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r24;
    // 0x8012B790: andi        $v1, $s6, 0xFF
    ctx->r3 = ctx->r22 & 0XFF;
    // 0x8012B794: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
L_8012B798:
    // 0x8012B798: sll         $t1, $s1, 1
    ctx->r9 = S32(ctx->r17 << 1);
    // 0x8012B79C: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x8012B7A0: andi        $t9, $v0, 0x1
    ctx->r25 = ctx->r2 & 0X1;
    // 0x8012B7A4: beq         $t9, $zero, L_8012B7B8
    if (ctx->r25 == 0) {
        // 0x8012B7A8: srl         $t3, $v0, 1
        ctx->r11 = S32(U32(ctx->r2) >> 1);
            goto L_8012B7B8;
    }
    // 0x8012B7A8: srl         $t3, $v0, 1
    ctx->r11 = S32(U32(ctx->r2) >> 1);
    // 0x8012B7AC: or          $s5, $s5, $s1
    ctx->r21 = ctx->r21 | ctx->r17;
    // 0x8012B7B0: andi        $t0, $s5, 0xFFFF
    ctx->r8 = ctx->r21 & 0XFFFF;
    // 0x8012B7B4: or          $s5, $t0, $zero
    ctx->r21 = ctx->r8 | 0;
L_8012B7B8:
    // 0x8012B7B8: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8012B7BC: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8012B7C0: andi        $t5, $s0, 0xFF
    ctx->r13 = ctx->r16 & 0XFF;
    // 0x8012B7C4: andi        $s1, $t1, 0xFFFF
    ctx->r17 = ctx->r9 & 0XFFFF;
    // 0x8012B7C8: sw          $t3, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r11;
    // 0x8012B7CC: or          $s0, $t5, $zero
    ctx->r16 = ctx->r13 | 0;
    // 0x8012B7D0: bne         $a1, $zero, L_8012B768
    if (ctx->r5 != 0) {
        // 0x8012B7D4: sb          $t4, 0x0($s2)
        MEM_B(0X0, ctx->r18) = ctx->r12;
            goto L_8012B768;
    }
    // 0x8012B7D4: sb          $t4, 0x0($s2)
    MEM_B(0X0, ctx->r18) = ctx->r12;
L_8012B7D8:
    // 0x8012B7D8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8012B7DC: or          $v0, $s5, $zero
    ctx->r2 = ctx->r21 | 0;
    // 0x8012B7E0: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8012B7E4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012B7E8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012B7EC: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012B7F0: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012B7F4: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012B7F8: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8012B7FC: jr          $ra
    // 0x8012B800: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x8012B800: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void InputBitsM2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B804: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8012B808: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x8012B80C: addiu       $a0, $t6, -0x1
    ctx->r4 = ADD32(ctx->r14, -0X1);
    // 0x8012B810: andi        $t7, $a0, 0xFF
    ctx->r15 = ctx->r4 & 0XFF;
    // 0x8012B814: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8012B818: beq         $t6, $zero, L_8012B8AC
    if (ctx->r14 == 0) {
        // 0x8012B81C: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_8012B8AC;
    }
    // 0x8012B81C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8012B820: lui         $t1, 0x8023
    ctx->r9 = S32(0X8023 << 16);
    // 0x8012B824: lui         $t0, 0x8023
    ctx->r8 = S32(0X8023 << 16);
    // 0x8012B828: lui         $a3, 0x8023
    ctx->r7 = S32(0X8023 << 16);
    // 0x8012B82C: addiu       $a3, $a3, -0x1C1C
    ctx->r7 = ADD32(ctx->r7, -0X1C1C);
    // 0x8012B830: addiu       $t0, $t0, -0x1F30
    ctx->r8 = ADD32(ctx->r8, -0X1F30);
    // 0x8012B834: addiu       $t1, $t1, -0x1C20
    ctx->r9 = ADD32(ctx->r9, -0X1C20);
    // 0x8012B838: addiu       $t2, $zero, 0x8
    ctx->r10 = ADD32(0, 0X8);
L_8012B83C:
    // 0x8012B83C: lbu         $a1, 0x0($a3)
    ctx->r5 = MEM_BU(ctx->r7, 0X0);
    // 0x8012B840: bnel        $a1, $zero, L_8012B868
    if (ctx->r5 != 0) {
        // 0x8012B844: lbu         $a2, 0x0($t0)
        ctx->r6 = MEM_BU(ctx->r8, 0X0);
            goto L_8012B868;
    }
    goto skip_0;
    // 0x8012B844: lbu         $a2, 0x0($t0)
    ctx->r6 = MEM_BU(ctx->r8, 0X0);
    skip_0:
    // 0x8012B848: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x8012B84C: andi        $a1, $t2, 0xFF
    ctx->r5 = ctx->r10 & 0XFF;
    // 0x8012B850: lbu         $t8, 0x0($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X0);
    // 0x8012B854: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x8012B858: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x8012B85C: sb          $t2, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r10;
    // 0x8012B860: sb          $t8, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r24;
    // 0x8012B864: lbu         $a2, 0x0($t0)
    ctx->r6 = MEM_BU(ctx->r8, 0X0);
L_8012B868:
    // 0x8012B868: sll         $t3, $v1, 1
    ctx->r11 = S32(ctx->r3 << 1);
    // 0x8012B86C: andi        $t4, $t3, 0xFFFF
    ctx->r12 = ctx->r11 & 0XFFFF;
    // 0x8012B870: andi        $t5, $a2, 0x80
    ctx->r13 = ctx->r6 & 0X80;
    // 0x8012B874: beq         $t5, $zero, L_8012B888
    if (ctx->r13 == 0) {
        // 0x8012B878: or          $v1, $t4, $zero
        ctx->r3 = ctx->r12 | 0;
            goto L_8012B888;
    }
    // 0x8012B878: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x8012B87C: addiu       $v1, $t4, 0x1
    ctx->r3 = ADD32(ctx->r12, 0X1);
    // 0x8012B880: andi        $t6, $v1, 0xFFFF
    ctx->r14 = ctx->r3 & 0XFFFF;
    // 0x8012B884: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_8012B888:
    // 0x8012B888: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x8012B88C: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x8012B890: sll         $t7, $a2, 1
    ctx->r15 = S32(ctx->r6 << 1);
    // 0x8012B894: andi        $t9, $a0, 0xFF
    ctx->r25 = ctx->r4 & 0XFF;
    // 0x8012B898: addiu       $t8, $a1, -0x1
    ctx->r24 = ADD32(ctx->r5, -0X1);
    // 0x8012B89C: sb          $t7, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r15;
    // 0x8012B8A0: sb          $t8, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r24;
    // 0x8012B8A4: bne         $v0, $zero, L_8012B83C
    if (ctx->r2 != 0) {
        // 0x8012B8A8: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_8012B83C;
    }
    // 0x8012B8A8: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_8012B8AC:
    // 0x8012B8AC: jr          $ra
    // 0x8012B8B0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x8012B8B0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void InputHuffmanTable(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B8B4: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8012B8B8: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8012B8BC: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x8012B8C0: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8012B8C4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8012B8C8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012B8CC: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012B8D0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012B8D4: jal         0x8012BBB4
    // 0x8012B8D8: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    InitHuffmanTable(rdram, ctx);
        goto after_0;
    // 0x8012B8D8: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    after_0:
    // 0x8012B8DC: jal         0x8012B704
    // 0x8012B8E0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    InputBitsM1(rdram, ctx);
        goto after_1;
    // 0x8012B8E0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_1:
    // 0x8012B8E4: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    // 0x8012B8E8: beq         $v1, $zero, L_8012B940
    if (ctx->r3 == 0) {
        // 0x8012B8EC: andi        $a1, $v0, 0xFF
        ctx->r5 = ctx->r2 & 0XFF;
            goto L_8012B940;
    }
    // 0x8012B8EC: andi        $a1, $v0, 0xFF
    ctx->r5 = ctx->r2 & 0XFF;
    // 0x8012B8F0: slti        $at, $v1, 0x11
    ctx->r1 = SIGNED(ctx->r3) < 0X11 ? 1 : 0;
    // 0x8012B8F4: bne         $at, $zero, L_8012B900
    if (ctx->r1 != 0) {
        // 0x8012B8F8: lw          $s0, 0x30($sp)
        ctx->r16 = MEM_W(ctx->r29, 0X30);
            goto L_8012B900;
    }
    // 0x8012B8F8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8012B8FC: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
L_8012B900:
    // 0x8012B900: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x8012B904: blez        $a1, L_8012B938
    if (SIGNED(ctx->r5) <= 0) {
        // 0x8012B908: or          $s2, $a1, $zero
        ctx->r18 = ctx->r5 | 0;
            goto L_8012B938;
    }
    // 0x8012B908: or          $s2, $a1, $zero
    ctx->r18 = ctx->r5 | 0;
    // 0x8012B90C: sb          $a1, 0x2F($sp)
    MEM_B(0X2F, ctx->r29) = ctx->r5;
L_8012B910:
    // 0x8012B910: jal         0x8012B704
    // 0x8012B914: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    InputBitsM1(rdram, ctx);
        goto after_2;
    // 0x8012B914: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_2:
    // 0x8012B918: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8012B91C: andi        $t7, $s1, 0xFF
    ctx->r15 = ctx->r17 & 0XFF;
    // 0x8012B920: slt         $at, $t7, $s2
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r18) ? 1 : 0;
    // 0x8012B924: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x8012B928: sh          $v0, 0xC($s0)
    MEM_H(0XC, ctx->r16) = ctx->r2;
    // 0x8012B92C: bne         $at, $zero, L_8012B910
    if (ctx->r1 != 0) {
        // 0x8012B930: addiu       $s0, $s0, 0x10
        ctx->r16 = ADD32(ctx->r16, 0X10);
            goto L_8012B910;
    }
    // 0x8012B930: addiu       $s0, $s0, 0x10
    ctx->r16 = ADD32(ctx->r16, 0X10);
    // 0x8012B934: lbu         $a1, 0x2F($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0X2F);
L_8012B938:
    // 0x8012B938: jal         0x8012BC00
    // 0x8012B93C: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    MakeHuffmanCodes(rdram, ctx);
        goto after_3;
    // 0x8012B93C: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    after_3:
L_8012B940:
    // 0x8012B940: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8012B944: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012B948: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012B94C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012B950: jr          $ra
    // 0x8012B954: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x8012B954: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void InputValue(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012B958: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8012B95C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012B960: lhu         $v0, 0xC($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0XC);
    // 0x8012B964: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x8012B968: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8012B96C: beq         $v0, $zero, L_8012B99C
    if (ctx->r2 == 0) {
        // 0x8012B970: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_8012B99C;
    }
    // 0x8012B970: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x8012B974: lui         $a0, 0x8023
    ctx->r4 = S32(0X8023 << 16);
    // 0x8012B978: addiu       $a0, $a0, -0x1F28
    ctx->r4 = ADD32(ctx->r4, -0X1F28);
    // 0x8012B97C: lw          $t0, 0x0($a0)
    ctx->r8 = MEM_W(ctx->r4, 0X0);
    // 0x8012B980: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012B984: lw          $t6, 0x8($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X8);
    // 0x8012B988: sllv        $t8, $t7, $v0
    ctx->r24 = S32(ctx->r15 << (ctx->r2 & 31));
    // 0x8012B98C: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x8012B990: and         $t1, $t9, $t0
    ctx->r9 = ctx->r25 & ctx->r8;
    // 0x8012B994: beql        $t6, $t1, L_8012B9E0
    if (ctx->r14 == ctx->r9) {
        // 0x8012B998: lbu         $a0, 0xD($v1)
        ctx->r4 = MEM_BU(ctx->r3, 0XD);
            goto L_8012B9E0;
    }
    goto skip_0;
    // 0x8012B998: lbu         $a0, 0xD($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0XD);
    skip_0:
L_8012B99C:
    // 0x8012B99C: lhu         $v0, 0x1C($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X1C);
L_8012B9A0:
    // 0x8012B9A0: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x8012B9A4: lui         $a0, 0x8023
    ctx->r4 = S32(0X8023 << 16);
    // 0x8012B9A8: andi        $t2, $a1, 0xFF
    ctx->r10 = ctx->r5 & 0XFF;
    // 0x8012B9AC: addiu       $a0, $a0, -0x1F28
    ctx->r4 = ADD32(ctx->r4, -0X1F28);
    // 0x8012B9B0: addiu       $v1, $v1, 0x10
    ctx->r3 = ADD32(ctx->r3, 0X10);
    // 0x8012B9B4: beq         $v0, $zero, L_8012B99C
    if (ctx->r2 == 0) {
        // 0x8012B9B8: or          $a1, $t2, $zero
        ctx->r5 = ctx->r10 | 0;
            goto L_8012B99C;
    }
    // 0x8012B9B8: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x8012B9BC: lw          $t8, 0x0($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X0);
    // 0x8012B9C0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8012B9C4: lw          $t3, 0x8($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X8);
    // 0x8012B9C8: sllv        $t5, $t4, $v0
    ctx->r13 = S32(ctx->r12 << (ctx->r2 & 31));
    // 0x8012B9CC: addiu       $t7, $t5, -0x1
    ctx->r15 = ADD32(ctx->r13, -0X1);
    // 0x8012B9D0: and         $t9, $t7, $t8
    ctx->r25 = ctx->r15 & ctx->r24;
    // 0x8012B9D4: bnel        $t3, $t9, L_8012B9A0
    if (ctx->r11 != ctx->r25) {
        // 0x8012B9D8: lhu         $v0, 0x1C($v1)
        ctx->r2 = MEM_HU(ctx->r3, 0X1C);
            goto L_8012B9A0;
    }
    goto skip_1;
    // 0x8012B9D8: lhu         $v0, 0x1C($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X1C);
    skip_1:
    // 0x8012B9DC: lbu         $a0, 0xD($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0XD);
L_8012B9E0:
    // 0x8012B9E0: jal         0x8012B704
    // 0x8012B9E4: sb          $a1, 0x27($sp)
    MEM_B(0X27, ctx->r29) = ctx->r5;
    InputBitsM1(rdram, ctx);
        goto after_0;
    // 0x8012B9E4: sb          $a1, 0x27($sp)
    MEM_B(0X27, ctx->r29) = ctx->r5;
    after_0:
    // 0x8012B9E8: lbu         $a1, 0x27($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0X27);
    // 0x8012B9EC: slti        $at, $a1, 0x2
    ctx->r1 = SIGNED(ctx->r5) < 0X2 ? 1 : 0;
    // 0x8012B9F0: beq         $at, $zero, L_8012BA00
    if (ctx->r1 == 0) {
        // 0x8012B9F4: or          $v1, $a1, $zero
        ctx->r3 = ctx->r5 | 0;
            goto L_8012BA00;
    }
    // 0x8012B9F4: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x8012B9F8: b           L_8012BA28
    // 0x8012B9FC: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_8012BA28;
    // 0x8012B9FC: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_8012BA00:
    // 0x8012BA00: addiu       $a1, $v1, -0x1
    ctx->r5 = ADD32(ctx->r3, -0X1);
    // 0x8012BA04: andi        $a0, $a1, 0xFF
    ctx->r4 = ctx->r5 & 0XFF;
    // 0x8012BA08: jal         0x8012B704
    // 0x8012BA0C: sw          $a1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r5;
    InputBitsM1(rdram, ctx);
        goto after_1;
    // 0x8012BA0C: sw          $a1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r5;
    after_1:
    // 0x8012BA10: lw          $a1, 0x18($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X18);
    // 0x8012BA14: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x8012BA18: sllv        $t6, $t0, $a1
    ctx->r14 = S32(ctx->r8 << (ctx->r5 & 31));
    // 0x8012BA1C: or          $v0, $v0, $t6
    ctx->r2 = ctx->r2 | ctx->r14;
    // 0x8012BA20: andi        $t1, $v0, 0xFFFF
    ctx->r9 = ctx->r2 & 0XFFFF;
    // 0x8012BA24: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
L_8012BA28:
    // 0x8012BA28: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012BA2C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8012BA30: jr          $ra
    // 0x8012BA34: nop

    return;
    // 0x8012BA34: nop

;}
RECOMP_FUNC void InputLenM2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BA38: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8012BA3C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012BA40: jal         0x8012B804
    // 0x8012BA44: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_0;
    // 0x8012BA44: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_0:
    // 0x8012BA48: addiu       $t6, $v0, 0x4
    ctx->r14 = ADD32(ctx->r2, 0X4);
    // 0x8012BA4C: sh          $t6, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r14;
    // 0x8012BA50: jal         0x8012B804
    // 0x8012BA54: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_1;
    // 0x8012BA54: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    // 0x8012BA58: bne         $v0, $zero, L_8012BA68
    if (ctx->r2 != 0) {
        // 0x8012BA5C: nop
    
            goto L_8012BA68;
    }
    // 0x8012BA5C: nop

    // 0x8012BA60: b           L_8012BA88
    // 0x8012BA64: lhu         $v0, 0x1E($sp)
    ctx->r2 = MEM_HU(ctx->r29, 0X1E);
        goto L_8012BA88;
    // 0x8012BA64: lhu         $v0, 0x1E($sp)
    ctx->r2 = MEM_HU(ctx->r29, 0X1E);
L_8012BA68:
    // 0x8012BA68: jal         0x8012B804
    // 0x8012BA6C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_2;
    // 0x8012BA6C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_2:
    // 0x8012BA70: lhu         $t7, 0x1E($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X1E);
    // 0x8012BA74: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x8012BA78: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8012BA7C: addu        $v0, $v0, $t9
    ctx->r2 = ADD32(ctx->r2, ctx->r25);
    // 0x8012BA80: andi        $t0, $v0, 0xFFFF
    ctx->r8 = ctx->r2 & 0XFFFF;
    // 0x8012BA84: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
L_8012BA88:
    // 0x8012BA88: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012BA8C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8012BA90: jr          $ra
    // 0x8012BA94: nop

    return;
    // 0x8012BA94: nop

;}
RECOMP_FUNC void InputPosM2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BA98: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8012BA9C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8012BAA0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012BAA4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8012BAA8: jal         0x8012B804
    // 0x8012BAAC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_0;
    // 0x8012BAAC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_0:
    // 0x8012BAB0: beq         $v0, $zero, L_8012BB34
    if (ctx->r2 == 0) {
        // 0x8012BAB4: nop
    
            goto L_8012BB34;
    }
    // 0x8012BAB4: nop

    // 0x8012BAB8: jal         0x8012B804
    // 0x8012BABC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_1;
    // 0x8012BABC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    // 0x8012BAC0: andi        $s0, $v0, 0xFFFF
    ctx->r16 = ctx->r2 & 0XFFFF;
    // 0x8012BAC4: jal         0x8012B804
    // 0x8012BAC8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_2;
    // 0x8012BAC8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_2:
    // 0x8012BACC: beq         $v0, $zero, L_8012BB18
    if (ctx->r2 == 0) {
        // 0x8012BAD0: nop
    
            goto L_8012BB18;
    }
    // 0x8012BAD0: nop

    // 0x8012BAD4: jal         0x8012B804
    // 0x8012BAD8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_3;
    // 0x8012BAD8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_3:
    // 0x8012BADC: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    // 0x8012BAE0: addu        $s0, $v0, $t6
    ctx->r16 = ADD32(ctx->r2, ctx->r14);
    // 0x8012BAE4: ori         $t7, $s0, 0x4
    ctx->r15 = ctx->r16 | 0X4;
    // 0x8012BAE8: andi        $s0, $t7, 0xFFFF
    ctx->r16 = ctx->r15 & 0XFFFF;
    // 0x8012BAEC: jal         0x8012B804
    // 0x8012BAF0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_4;
    // 0x8012BAF0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_4:
    // 0x8012BAF4: bne         $v0, $zero, L_8012BB34
    if (ctx->r2 != 0) {
        // 0x8012BAF8: nop
    
            goto L_8012BB34;
    }
    // 0x8012BAF8: nop

    // 0x8012BAFC: jal         0x8012B804
    // 0x8012BB00: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_5;
    // 0x8012BB00: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_5:
    // 0x8012BB04: sll         $t9, $s0, 1
    ctx->r25 = S32(ctx->r16 << 1);
    // 0x8012BB08: addu        $s0, $v0, $t9
    ctx->r16 = ADD32(ctx->r2, ctx->r25);
    // 0x8012BB0C: andi        $t0, $s0, 0xFFFF
    ctx->r8 = ctx->r16 & 0XFFFF;
    // 0x8012BB10: b           L_8012BB34
    // 0x8012BB14: or          $s0, $t0, $zero
    ctx->r16 = ctx->r8 | 0;
        goto L_8012BB34;
    // 0x8012BB14: or          $s0, $t0, $zero
    ctx->r16 = ctx->r8 | 0;
L_8012BB18:
    // 0x8012BB18: bne         $s0, $zero, L_8012BB34
    if (ctx->r16 != 0) {
        // 0x8012BB1C: nop
    
            goto L_8012BB34;
    }
    // 0x8012BB1C: nop

    // 0x8012BB20: jal         0x8012B804
    // 0x8012BB24: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    InputBitsM2(rdram, ctx);
        goto after_6;
    // 0x8012BB24: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_6:
    // 0x8012BB28: addiu       $s0, $v0, 0x2
    ctx->r16 = ADD32(ctx->r2, 0X2);
    // 0x8012BB2C: andi        $t1, $s0, 0xFFFF
    ctx->r9 = ctx->r16 & 0XFFFF;
    // 0x8012BB30: or          $s0, $t1, $zero
    ctx->r16 = ctx->r9 | 0;
L_8012BB34:
    // 0x8012BB34: lui         $a1, 0x8023
    ctx->r5 = S32(0X8023 << 16);
    // 0x8012BB38: addiu       $a1, $a1, -0x1C20
    ctx->r5 = ADD32(ctx->r5, -0X1C20);
    // 0x8012BB3C: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x8012BB40: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8012BB44: sll         $t3, $s0, 8
    ctx->r11 = S32(ctx->r16 << 8);
    // 0x8012BB48: lbu         $t2, 0x0($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X0);
    // 0x8012BB4C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012BB50: addiu       $t5, $v1, 0x1
    ctx->r13 = ADD32(ctx->r3, 0X1);
    // 0x8012BB54: addu        $a0, $t2, $t3
    ctx->r4 = ADD32(ctx->r10, ctx->r11);
    // 0x8012BB58: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x8012BB5C: andi        $v0, $a0, 0xFFFF
    ctx->r2 = ctx->r4 & 0XFFFF;
    // 0x8012BB60: sw          $t5, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r13;
    // 0x8012BB64: jr          $ra
    // 0x8012BB68: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x8012BB68: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void ReverseLong(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BB6C: lbu         $t6, 0x3($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X3);
    // 0x8012BB70: lbu         $t8, 0x0($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X0);
    // 0x8012BB74: lbu         $t0, 0x1($a0)
    ctx->r8 = MEM_BU(ctx->r4, 0X1);
    // 0x8012BB78: lbu         $t3, 0x2($a0)
    ctx->r11 = MEM_BU(ctx->r4, 0X2);
    // 0x8012BB7C: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012BB80: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8012BB84: sll         $t1, $t0, 8
    ctx->r9 = S32(ctx->r8 << 8);
    // 0x8012BB88: or          $t2, $t9, $t1
    ctx->r10 = ctx->r25 | ctx->r9;
    // 0x8012BB8C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x8012BB90: jr          $ra
    // 0x8012BB94: or          $v0, $t2, $t4
    ctx->r2 = ctx->r10 | ctx->r12;
    return;
    // 0x8012BB94: or          $v0, $t2, $t4
    ctx->r2 = ctx->r10 | ctx->r12;
;}
RECOMP_FUNC void ReverseWord(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BB98: lbu         $t6, 0x1($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X1);
    // 0x8012BB9C: lbu         $t8, 0x0($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X0);
    // 0x8012BBA0: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x8012BBA4: or          $v0, $t7, $t8
    ctx->r2 = ctx->r15 | ctx->r24;
    // 0x8012BBA8: andi        $t9, $v0, 0xFFFF
    ctx->r25 = ctx->r2 & 0XFFFF;
    // 0x8012BBAC: jr          $ra
    // 0x8012BBB0: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    return;
    // 0x8012BBB0: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
;}
RECOMP_FUNC void InitHuffmanTable(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BBB4: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012BBB8: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8012BBBC: addiu       $a1, $t6, -0x1
    ctx->r5 = ADD32(ctx->r14, -0X1);
    // 0x8012BBC0: andi        $t7, $a1, 0xFF
    ctx->r15 = ctx->r5 & 0XFF;
    // 0x8012BBC4: beq         $t6, $zero, L_8012BBF8
    if (ctx->r14 == 0) {
        // 0x8012BBC8: or          $a1, $t7, $zero
        ctx->r5 = ctx->r15 | 0;
            goto L_8012BBF8;
    }
    // 0x8012BBC8: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x8012BBCC: ori         $v1, $zero, 0xFFFF
    ctx->r3 = 0 | 0XFFFF;
L_8012BBD0:
    // 0x8012BBD0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x8012BBD4: addiu       $a1, $a1, -0x1
    ctx->r5 = ADD32(ctx->r5, -0X1);
    // 0x8012BBD8: andi        $t8, $a1, 0xFF
    ctx->r24 = ctx->r5 & 0XFF;
    // 0x8012BBDC: sw          $zero, 0x0($a0)
    MEM_W(0X0, ctx->r4) = 0;
    // 0x8012BBE0: sh          $v1, 0x4($a0)
    MEM_H(0X4, ctx->r4) = ctx->r3;
    // 0x8012BBE4: sw          $zero, 0x8($a0)
    MEM_W(0X8, ctx->r4) = 0;
    // 0x8012BBE8: sh          $zero, 0xC($a0)
    MEM_H(0XC, ctx->r4) = 0;
    // 0x8012BBEC: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x8012BBF0: bne         $v0, $zero, L_8012BBD0
    if (ctx->r2 != 0) {
        // 0x8012BBF4: addiu       $a0, $a0, 0x10
        ctx->r4 = ADD32(ctx->r4, 0X10);
            goto L_8012BBD0;
    }
    // 0x8012BBF4: addiu       $a0, $a0, 0x10
    ctx->r4 = ADD32(ctx->r4, 0X10);
L_8012BBF8:
    // 0x8012BBF8: jr          $ra
    // 0x8012BBFC: nop

    return;
    // 0x8012BBFC: nop

;}
RECOMP_FUNC void MakeHuffmanCodes(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BC00: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8012BC04: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8012BC08: sw          $s7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r23;
    // 0x8012BC0C: sw          $s6, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r22;
    // 0x8012BC10: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x8012BC14: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x8012BC18: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x8012BC1C: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x8012BC20: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8012BC24: or          $s7, $a0, $zero
    ctx->r23 = ctx->r4 | 0;
    // 0x8012BC28: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8012BC2C: sw          $s4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r20;
    // 0x8012BC30: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8012BC34: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8012BC38: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
    // 0x8012BC3C: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x8012BC40: lui         $s3, 0x8000
    ctx->r19 = S32(0X8000 << 16);
    // 0x8012BC44: or          $s6, $t6, $zero
    ctx->r22 = ctx->r14 | 0;
L_8012BC48:
    // 0x8012BC48: or          $s0, $s7, $zero
    ctx->r16 = ctx->r23 | 0;
    // 0x8012BC4C: blez        $s6, L_8012BCA4
    if (SIGNED(ctx->r22) <= 0) {
        // 0x8012BC50: or          $s1, $zero, $zero
        ctx->r17 = 0 | 0;
            goto L_8012BCA4;
    }
    // 0x8012BC50: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x8012BC54: or          $s4, $s5, $zero
    ctx->r20 = ctx->r21 | 0;
L_8012BC58:
    // 0x8012BC58: lhu         $t7, 0xC($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0XC);
    // 0x8012BC5C: bnel        $s4, $t7, L_8012BC90
    if (ctx->r20 != ctx->r15) {
        // 0x8012BC60: addiu       $s1, $s1, 0x1
        ctx->r17 = ADD32(ctx->r17, 0X1);
            goto L_8012BC90;
    }
    goto skip_0;
    // 0x8012BC60: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    skip_0:
    // 0x8012BC64: divu        $zero, $s2, $s3
    lo = S32(U32(ctx->r18) / U32(ctx->r19)); hi = S32(U32(ctx->r18) % U32(ctx->r19));
    // 0x8012BC68: mflo        $a0
    ctx->r4 = lo;
    // 0x8012BC6C: andi        $a1, $s5, 0xFF
    ctx->r5 = ctx->r21 & 0XFF;
    // 0x8012BC70: bne         $s3, $zero, L_8012BC7C
    if (ctx->r19 != 0) {
        // 0x8012BC74: nop
    
            goto L_8012BC7C;
    }
    // 0x8012BC74: nop

    // 0x8012BC78: break       7
    do_break(2148711544);
L_8012BC7C:
    // 0x8012BC7C: jal         0x8012C010
    // 0x8012BC80: nop

    SwapBits(rdram, ctx);
        goto after_0;
    // 0x8012BC80: nop

    after_0:
    // 0x8012BC84: sw          $v0, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r2;
    // 0x8012BC88: addu        $s2, $s2, $s3
    ctx->r18 = ADD32(ctx->r18, ctx->r19);
    // 0x8012BC8C: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
L_8012BC90:
    // 0x8012BC90: andi        $t8, $s1, 0xFFFF
    ctx->r24 = ctx->r17 & 0XFFFF;
    // 0x8012BC94: slt         $at, $t8, $s6
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r22) ? 1 : 0;
    // 0x8012BC98: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x8012BC9C: bne         $at, $zero, L_8012BC58
    if (ctx->r1 != 0) {
        // 0x8012BCA0: addiu       $s0, $s0, 0x10
        ctx->r16 = ADD32(ctx->r16, 0X10);
            goto L_8012BC58;
    }
    // 0x8012BCA0: addiu       $s0, $s0, 0x10
    ctx->r16 = ADD32(ctx->r16, 0X10);
L_8012BCA4:
    // 0x8012BCA4: addiu       $s5, $s5, 0x1
    ctx->r21 = ADD32(ctx->r21, 0X1);
    // 0x8012BCA8: andi        $t9, $s5, 0xFFFF
    ctx->r25 = ctx->r21 & 0XFFFF;
    // 0x8012BCAC: slti        $at, $t9, 0x11
    ctx->r1 = SIGNED(ctx->r25) < 0X11 ? 1 : 0;
    // 0x8012BCB0: srl         $t0, $s3, 1
    ctx->r8 = S32(U32(ctx->r19) >> 1);
    // 0x8012BCB4: or          $s5, $t9, $zero
    ctx->r21 = ctx->r25 | 0;
    // 0x8012BCB8: bne         $at, $zero, L_8012BC48
    if (ctx->r1 != 0) {
        // 0x8012BCBC: or          $s3, $t0, $zero
        ctx->r19 = ctx->r8 | 0;
            goto L_8012BC48;
    }
    // 0x8012BCBC: or          $s3, $t0, $zero
    ctx->r19 = ctx->r8 | 0;
    // 0x8012BCC0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8012BCC4: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x8012BCC8: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x8012BCCC: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x8012BCD0: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x8012BCD4: lw          $s4, 0x24($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X24);
    // 0x8012BCD8: lw          $s5, 0x28($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X28);
    // 0x8012BCDC: lw          $s6, 0x2C($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X2C);
    // 0x8012BCE0: lw          $s7, 0x30($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X30);
    // 0x8012BCE4: jr          $ra
    // 0x8012BCE8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x8012BCE8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void MakeHuffmanTable(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BCEC: addiu       $sp, $sp, -0x88
    ctx->r29 = ADD32(ctx->r29, -0X88);
    // 0x8012BCF0: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8012BCF4: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8012BCF8: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012BCFC: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012BD00: or          $s2, $a0, $zero
    ctx->r18 = ctx->r4 | 0;
    // 0x8012BD04: andi        $s6, $a1, 0xFF
    ctx->r22 = ctx->r5 & 0XFF;
    // 0x8012BD08: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8012BD0C: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012BD10: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012BD14: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012BD18: sw          $a1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r5;
    // 0x8012BD1C: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x8012BD20: addiu       $s5, $sp, 0x40
    ctx->r21 = ADD32(ctx->r29, 0X40);
L_8012BD24:
    // 0x8012BD24: sll         $t6, $s4, 4
    ctx->r14 = S32(ctx->r20 << 4);
    // 0x8012BD28: sll         $t9, $s4, 2
    ctx->r25 = S32(ctx->r20 << 2);
    // 0x8012BD2C: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    // 0x8012BD30: addu        $t7, $s2, $t6
    ctx->r15 = ADD32(ctx->r18, ctx->r14);
    // 0x8012BD34: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x8012BD38: andi        $t1, $s4, 0xFFFF
    ctx->r9 = ctx->r20 & 0XFFFF;
    // 0x8012BD3C: slti        $at, $t1, 0x10
    ctx->r1 = SIGNED(ctx->r9) < 0X10 ? 1 : 0;
    // 0x8012BD40: addu        $t0, $s5, $t9
    ctx->r8 = ADD32(ctx->r21, ctx->r25);
    // 0x8012BD44: or          $s4, $t1, $zero
    ctx->r20 = ctx->r9 | 0;
    // 0x8012BD48: bne         $at, $zero, L_8012BD24
    if (ctx->r1 != 0) {
        // 0x8012BD4C: sw          $t8, 0x0($t0)
        MEM_W(0X0, ctx->r8) = ctx->r24;
            goto L_8012BD24;
    }
    // 0x8012BD4C: sw          $t8, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r24;
    // 0x8012BD50: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8012BD54: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x8012BD58: blez        $s6, L_8012BD98
    if (SIGNED(ctx->r22) <= 0) {
        // 0x8012BD5C: or          $v1, $s6, $zero
        ctx->r3 = ctx->r22 | 0;
            goto L_8012BD98;
    }
    // 0x8012BD5C: or          $v1, $s6, $zero
    ctx->r3 = ctx->r22 | 0;
L_8012BD60:
    // 0x8012BD60: sll         $t2, $s4, 4
    ctx->r10 = S32(ctx->r20 << 4);
    // 0x8012BD64: addu        $t3, $s2, $t2
    ctx->r11 = ADD32(ctx->r18, ctx->r10);
    // 0x8012BD68: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x8012BD6C: beql        $t4, $zero, L_8012BD88
    if (ctx->r12 == 0) {
        // 0x8012BD70: addiu       $s4, $s4, 0x1
        ctx->r20 = ADD32(ctx->r20, 0X1);
            goto L_8012BD88;
    }
    goto skip_0;
    // 0x8012BD70: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    skip_0:
    // 0x8012BD74: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8012BD78: andi        $t5, $v0, 0xFFFF
    ctx->r13 = ctx->r2 & 0XFFFF;
    // 0x8012BD7C: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x8012BD80: sh          $s4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r20;
    // 0x8012BD84: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
L_8012BD88:
    // 0x8012BD88: andi        $t6, $s4, 0xFFFF
    ctx->r14 = ctx->r20 & 0XFFFF;
    // 0x8012BD8C: slt         $at, $t6, $v1
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8012BD90: bne         $at, $zero, L_8012BD60
    if (ctx->r1 != 0) {
        // 0x8012BD94: or          $s4, $t6, $zero
        ctx->r20 = ctx->r14 | 0;
            goto L_8012BD60;
    }
    // 0x8012BD94: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
L_8012BD98:
    // 0x8012BD98: beq         $v0, $zero, L_8012BF34
    if (ctx->r2 == 0) {
        // 0x8012BD9C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_8012BF34;
    }
    // 0x8012BD9C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012BDA0: bne         $v0, $at, L_8012BDC4
    if (ctx->r2 != ctx->r1) {
        // 0x8012BDA4: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_8012BDC4;
    }
    // 0x8012BDA4: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x8012BDA8: lhu         $t7, 0x82($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X82);
    // 0x8012BDAC: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x8012BDB0: addu        $v0, $s2, $t9
    ctx->r2 = ADD32(ctx->r18, ctx->r25);
    // 0x8012BDB4: lhu         $t8, 0xC($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XC);
    // 0x8012BDB8: addiu       $t0, $t8, 0x1
    ctx->r8 = ADD32(ctx->r24, 0X1);
    // 0x8012BDBC: b           L_8012BF34
    // 0x8012BDC0: sh          $t0, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r8;
        goto L_8012BF34;
    // 0x8012BDC0: sh          $t0, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r8;
L_8012BDC4:
    // 0x8012BDC4: andi        $a1, $s6, 0xFF
    ctx->r5 = ctx->r22 & 0XFF;
    // 0x8012BDC8: jal         0x8012BF5C
    // 0x8012BDCC: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    FindLowest(rdram, ctx);
        goto after_0;
    // 0x8012BDCC: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    after_0:
    // 0x8012BDD0: beq         $v0, $zero, L_8012BEFC
    if (ctx->r2 == 0) {
        // 0x8012BDD4: ori         $s3, $zero, 0xFFFF
        ctx->r19 = 0 | 0XFFFF;
            goto L_8012BEFC;
    }
    // 0x8012BDD4: ori         $s3, $zero, 0xFFFF
    ctx->r19 = 0 | 0XFFFF;
    // 0x8012BDD8: lui         $s1, 0x8023
    ctx->r17 = S32(0X8023 << 16);
    // 0x8012BDDC: lui         $s0, 0x8023
    ctx->r16 = S32(0X8023 << 16);
    // 0x8012BDE0: addiu       $s0, $s0, -0x1C18
    ctx->r16 = ADD32(ctx->r16, -0X1C18);
    // 0x8012BDE4: addiu       $s1, $s1, -0x1C1A
    ctx->r17 = ADD32(ctx->r17, -0X1C1A);
    // 0x8012BDE8: lhu         $t1, 0x0($s1)
    ctx->r9 = MEM_HU(ctx->r17, 0X0);
L_8012BDEC:
    // 0x8012BDEC: lhu         $t4, 0x0($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BDF0: andi        $a1, $s6, 0xFF
    ctx->r5 = ctx->r22 & 0XFF;
    // 0x8012BDF4: sll         $t2, $t1, 4
    ctx->r10 = S32(ctx->r9 << 4);
    // 0x8012BDF8: sll         $t5, $t4, 4
    ctx->r13 = S32(ctx->r12 << 4);
    // 0x8012BDFC: addu        $t6, $s2, $t5
    ctx->r14 = ADD32(ctx->r18, ctx->r13);
    // 0x8012BE00: addu        $v0, $s2, $t2
    ctx->r2 = ADD32(ctx->r18, ctx->r10);
    // 0x8012BE04: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x8012BE08: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x8012BE0C: addu        $t9, $t3, $t7
    ctx->r25 = ADD32(ctx->r11, ctx->r15);
    // 0x8012BE10: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012BE14: lhu         $t8, 0x0($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BE18: sll         $t0, $t8, 4
    ctx->r8 = S32(ctx->r24 << 4);
    // 0x8012BE1C: addu        $t1, $s2, $t0
    ctx->r9 = ADD32(ctx->r18, ctx->r8);
    // 0x8012BE20: sw          $zero, 0x0($t1)
    MEM_W(0X0, ctx->r9) = 0;
    // 0x8012BE24: lhu         $t2, 0x0($s1)
    ctx->r10 = MEM_HU(ctx->r17, 0X0);
    // 0x8012BE28: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x8012BE2C: addu        $v0, $s2, $t4
    ctx->r2 = ADD32(ctx->r18, ctx->r12);
    // 0x8012BE30: lhu         $t5, 0xC($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0XC);
    // 0x8012BE34: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x8012BE38: sh          $t6, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r14;
    // 0x8012BE3C: lhu         $t3, 0x0($s1)
    ctx->r11 = MEM_HU(ctx->r17, 0X0);
    // 0x8012BE40: sll         $t7, $t3, 4
    ctx->r15 = S32(ctx->r11 << 4);
    // 0x8012BE44: addu        $v0, $s2, $t7
    ctx->r2 = ADD32(ctx->r18, ctx->r15);
    // 0x8012BE48: lhu         $v1, 0x4($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X4);
    // 0x8012BE4C: beq         $s3, $v1, L_8012BE84
    if (ctx->r19 == ctx->r3) {
        // 0x8012BE50: andi        $t9, $v1, 0xFFFF
        ctx->r25 = ctx->r3 & 0XFFFF;
            goto L_8012BE84;
    }
    // 0x8012BE50: andi        $t9, $v1, 0xFFFF
    ctx->r25 = ctx->r3 & 0XFFFF;
L_8012BE54:
    // 0x8012BE54: sll         $t8, $t9, 4
    ctx->r24 = S32(ctx->r25 << 4);
    // 0x8012BE58: sh          $v1, 0x0($s1)
    MEM_H(0X0, ctx->r17) = ctx->r3;
    // 0x8012BE5C: addu        $v0, $s2, $t8
    ctx->r2 = ADD32(ctx->r18, ctx->r24);
    // 0x8012BE60: lhu         $t0, 0xC($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0XC);
    // 0x8012BE64: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x8012BE68: sh          $t1, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r9;
    // 0x8012BE6C: lhu         $t2, 0x0($s1)
    ctx->r10 = MEM_HU(ctx->r17, 0X0);
    // 0x8012BE70: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x8012BE74: addu        $v0, $s2, $t4
    ctx->r2 = ADD32(ctx->r18, ctx->r12);
    // 0x8012BE78: lhu         $v1, 0x4($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X4);
    // 0x8012BE7C: bnel        $s3, $v1, L_8012BE54
    if (ctx->r19 != ctx->r3) {
        // 0x8012BE80: andi        $t9, $v1, 0xFFFF
        ctx->r25 = ctx->r3 & 0XFFFF;
            goto L_8012BE54;
    }
    goto skip_1;
    // 0x8012BE80: andi        $t9, $v1, 0xFFFF
    ctx->r25 = ctx->r3 & 0XFFFF;
    skip_1:
L_8012BE84:
    // 0x8012BE84: lhu         $t5, 0x0($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BE88: sh          $t5, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r13;
    // 0x8012BE8C: lhu         $t6, 0x0($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BE90: sll         $t3, $t6, 4
    ctx->r11 = S32(ctx->r14 << 4);
    // 0x8012BE94: addu        $v1, $s2, $t3
    ctx->r3 = ADD32(ctx->r18, ctx->r11);
    // 0x8012BE98: lhu         $t7, 0xC($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0XC);
    // 0x8012BE9C: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8012BEA0: sh          $t9, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r25;
    // 0x8012BEA4: lhu         $t8, 0x0($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BEA8: sll         $t0, $t8, 4
    ctx->r8 = S32(ctx->r24 << 4);
    // 0x8012BEAC: addu        $t1, $s2, $t0
    ctx->r9 = ADD32(ctx->r18, ctx->r8);
    // 0x8012BEB0: lhu         $a0, 0x4($t1)
    ctx->r4 = MEM_HU(ctx->r9, 0X4);
    // 0x8012BEB4: beq         $s3, $a0, L_8012BEEC
    if (ctx->r19 == ctx->r4) {
        // 0x8012BEB8: andi        $t2, $a0, 0xFFFF
        ctx->r10 = ctx->r4 & 0XFFFF;
            goto L_8012BEEC;
    }
    // 0x8012BEB8: andi        $t2, $a0, 0xFFFF
    ctx->r10 = ctx->r4 & 0XFFFF;
L_8012BEBC:
    // 0x8012BEBC: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x8012BEC0: sh          $a0, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r4;
    // 0x8012BEC4: addu        $v1, $s2, $t4
    ctx->r3 = ADD32(ctx->r18, ctx->r12);
    // 0x8012BEC8: lhu         $t5, 0xC($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0XC);
    // 0x8012BECC: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x8012BED0: sh          $t6, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r14;
    // 0x8012BED4: lhu         $t3, 0x0($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X0);
    // 0x8012BED8: sll         $t7, $t3, 4
    ctx->r15 = S32(ctx->r11 << 4);
    // 0x8012BEDC: addu        $t9, $s2, $t7
    ctx->r25 = ADD32(ctx->r18, ctx->r15);
    // 0x8012BEE0: lhu         $a0, 0x4($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0X4);
    // 0x8012BEE4: bnel        $s3, $a0, L_8012BEBC
    if (ctx->r19 != ctx->r4) {
        // 0x8012BEE8: andi        $t2, $a0, 0xFFFF
        ctx->r10 = ctx->r4 & 0XFFFF;
            goto L_8012BEBC;
    }
    goto skip_2;
    // 0x8012BEE8: andi        $t2, $a0, 0xFFFF
    ctx->r10 = ctx->r4 & 0XFFFF;
    skip_2:
L_8012BEEC:
    // 0x8012BEEC: jal         0x8012BF5C
    // 0x8012BEF0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    FindLowest(rdram, ctx);
        goto after_1;
    // 0x8012BEF0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_1:
    // 0x8012BEF4: bnel        $v0, $zero, L_8012BDEC
    if (ctx->r2 != 0) {
        // 0x8012BEF8: lhu         $t1, 0x0($s1)
        ctx->r9 = MEM_HU(ctx->r17, 0X0);
            goto L_8012BDEC;
    }
    goto skip_3;
    // 0x8012BEF8: lhu         $t1, 0x0($s1)
    ctx->r9 = MEM_HU(ctx->r17, 0X0);
    skip_3:
L_8012BEFC:
    // 0x8012BEFC: sll         $t8, $s4, 2
    ctx->r24 = S32(ctx->r20 << 2);
    // 0x8012BF00: sll         $t2, $s4, 4
    ctx->r10 = S32(ctx->r20 << 4);
    // 0x8012BF04: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    // 0x8012BF08: addu        $t0, $s5, $t8
    ctx->r8 = ADD32(ctx->r21, ctx->r24);
    // 0x8012BF0C: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x8012BF10: andi        $t5, $s4, 0xFFFF
    ctx->r13 = ctx->r20 & 0XFFFF;
    // 0x8012BF14: slti        $at, $t5, 0x10
    ctx->r1 = SIGNED(ctx->r13) < 0X10 ? 1 : 0;
    // 0x8012BF18: addu        $t4, $s2, $t2
    ctx->r12 = ADD32(ctx->r18, ctx->r10);
    // 0x8012BF1C: or          $s4, $t5, $zero
    ctx->r20 = ctx->r13 | 0;
    // 0x8012BF20: bne         $at, $zero, L_8012BEFC
    if (ctx->r1 != 0) {
        // 0x8012BF24: sw          $t1, 0x0($t4)
        MEM_W(0X0, ctx->r12) = ctx->r9;
            goto L_8012BEFC;
    }
    // 0x8012BF24: sw          $t1, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r9;
    // 0x8012BF28: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x8012BF2C: jal         0x8012BC00
    // 0x8012BF30: andi        $a1, $s6, 0xFF
    ctx->r5 = ctx->r22 & 0XFF;
    MakeHuffmanCodes(rdram, ctx);
        goto after_2;
    // 0x8012BF30: andi        $a1, $s6, 0xFF
    ctx->r5 = ctx->r22 & 0XFF;
    after_2:
L_8012BF34:
    // 0x8012BF34: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8012BF38: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012BF3C: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012BF40: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012BF44: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012BF48: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012BF4C: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8012BF50: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8012BF54: jr          $ra
    // 0x8012BF58: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
    return;
    // 0x8012BF58: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
;}
RECOMP_FUNC void FindLowest(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012BF5C: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x8012BF60: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x8012BF64: andi        $a3, $a1, 0xFF
    ctx->r7 = ctx->r5 & 0XFF;
    // 0x8012BF68: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8012BF6C: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x8012BF70: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    // 0x8012BF74: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    // 0x8012BF78: blez        $a3, L_8012BFEC
    if (SIGNED(ctx->r7) <= 0) {
        // 0x8012BF7C: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8012BFEC;
    }
    // 0x8012BF7C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8012BF80: lui         $t0, 0x8023
    ctx->r8 = S32(0X8023 << 16);
    // 0x8012BF84: lui         $a1, 0x8023
    ctx->r5 = S32(0X8023 << 16);
    // 0x8012BF88: addiu       $a1, $a1, -0x1C18
    ctx->r5 = ADD32(ctx->r5, -0X1C18);
    // 0x8012BF8C: addiu       $t0, $t0, -0x1C1A
    ctx->r8 = ADD32(ctx->r8, -0X1C1A);
L_8012BF90:
    // 0x8012BF90: sll         $t7, $a2, 4
    ctx->r15 = S32(ctx->r6 << 4);
    // 0x8012BF94: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x8012BF98: lw          $a0, 0x0($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X0);
    // 0x8012BF9C: beq         $a0, $zero, L_8012BFD8
    if (ctx->r4 == 0) {
        // 0x8012BFA0: sltu        $at, $a0, $v0
        ctx->r1 = ctx->r4 < ctx->r2 ? 1 : 0;
            goto L_8012BFD8;
    }
    // 0x8012BFA0: sltu        $at, $a0, $v0
    ctx->r1 = ctx->r4 < ctx->r2 ? 1 : 0;
    // 0x8012BFA4: beql        $at, $zero, L_8012BFC8
    if (ctx->r1 == 0) {
        // 0x8012BFA8: sltu        $at, $a0, $v1
        ctx->r1 = ctx->r4 < ctx->r3 ? 1 : 0;
            goto L_8012BFC8;
    }
    goto skip_0;
    // 0x8012BFA8: sltu        $at, $a0, $v1
    ctx->r1 = ctx->r4 < ctx->r3 ? 1 : 0;
    skip_0:
    // 0x8012BFAC: lhu         $t9, 0x0($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0X0);
    // 0x8012BFB0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x8012BFB4: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x8012BFB8: sh          $a2, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r6;
    // 0x8012BFBC: b           L_8012BFD8
    // 0x8012BFC0: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
        goto L_8012BFD8;
    // 0x8012BFC0: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
    // 0x8012BFC4: sltu        $at, $a0, $v1
    ctx->r1 = ctx->r4 < ctx->r3 ? 1 : 0;
L_8012BFC8:
    // 0x8012BFC8: beql        $at, $zero, L_8012BFDC
    if (ctx->r1 == 0) {
        // 0x8012BFCC: addiu       $a2, $a2, 0x1
        ctx->r6 = ADD32(ctx->r6, 0X1);
            goto L_8012BFDC;
    }
    goto skip_1;
    // 0x8012BFCC: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
    skip_1:
    // 0x8012BFD0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x8012BFD4: sh          $a2, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r6;
L_8012BFD8:
    // 0x8012BFD8: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
L_8012BFDC:
    // 0x8012BFDC: andi        $t1, $a2, 0xFF
    ctx->r9 = ctx->r6 & 0XFF;
    // 0x8012BFE0: slt         $at, $t1, $a3
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x8012BFE4: bne         $at, $zero, L_8012BF90
    if (ctx->r1 != 0) {
        // 0x8012BFE8: or          $a2, $t1, $zero
        ctx->r6 = ctx->r9 | 0;
            goto L_8012BF90;
    }
    // 0x8012BFE8: or          $a2, $t1, $zero
    ctx->r6 = ctx->r9 | 0;
L_8012BFEC:
    // 0x8012BFEC: addiu       $a0, $zero, -0x1
    ctx->r4 = ADD32(0, -0X1);
    // 0x8012BFF0: beq         $v0, $a0, L_8012C000
    if (ctx->r2 == ctx->r4) {
        // 0x8012BFF4: lw          $s0, 0x4($sp)
        ctx->r16 = MEM_W(ctx->r29, 0X4);
            goto L_8012C000;
    }
    // 0x8012BFF4: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x8012BFF8: bne         $v1, $a0, L_8012C008
    if (ctx->r3 != ctx->r4) {
        // 0x8012BFFC: addiu       $v0, $zero, 0x1
        ctx->r2 = ADD32(0, 0X1);
            goto L_8012C008;
    }
    // 0x8012BFFC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8012C000:
    // 0x8012C000: b           L_8012C008
    // 0x8012C004: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8012C008;
    // 0x8012C004: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8012C008:
    // 0x8012C008: jr          $ra
    // 0x8012C00C: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    return;
    // 0x8012C00C: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
;}
RECOMP_FUNC void SwapBits(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C010: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012C014: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8012C018: addiu       $a1, $t6, -0x1
    ctx->r5 = ADD32(ctx->r14, -0X1);
    // 0x8012C01C: andi        $t7, $a1, 0xFF
    ctx->r15 = ctx->r5 & 0XFF;
    // 0x8012C020: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8012C024: beq         $t6, $zero, L_8012C05C
    if (ctx->r14 == 0) {
        // 0x8012C028: or          $a1, $t7, $zero
        ctx->r5 = ctx->r15 | 0;
            goto L_8012C05C;
    }
    // 0x8012C028: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
L_8012C02C:
    // 0x8012C02C: sll         $t8, $v1, 1
    ctx->r24 = S32(ctx->r3 << 1);
    // 0x8012C030: andi        $t9, $a0, 0x1
    ctx->r25 = ctx->r4 & 0X1;
    // 0x8012C034: beq         $t9, $zero, L_8012C040
    if (ctx->r25 == 0) {
        // 0x8012C038: or          $v1, $t8, $zero
        ctx->r3 = ctx->r24 | 0;
            goto L_8012C040;
    }
    // 0x8012C038: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x8012C03C: ori         $v1, $t8, 0x1
    ctx->r3 = ctx->r24 | 0X1;
L_8012C040:
    // 0x8012C040: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x8012C044: addiu       $a1, $a1, -0x1
    ctx->r5 = ADD32(ctx->r5, -0X1);
    // 0x8012C048: andi        $t2, $a1, 0xFF
    ctx->r10 = ctx->r5 & 0XFF;
    // 0x8012C04C: srl         $t1, $a0, 1
    ctx->r9 = S32(U32(ctx->r4) >> 1);
    // 0x8012C050: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    // 0x8012C054: bne         $v0, $zero, L_8012C02C
    if (ctx->r2 != 0) {
        // 0x8012C058: or          $a1, $t2, $zero
        ctx->r5 = ctx->r10 | 0;
            goto L_8012C02C;
    }
    // 0x8012C058: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
L_8012C05C:
    // 0x8012C05C: jr          $ra
    // 0x8012C060: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x8012C060: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void load_overlay(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C070: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8012C074: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012C078: jal         0x80133738
    // 0x8012C07C: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    stop_all_sounds(rdram, ctx);
        goto after_0;
    // 0x8012C07C: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    after_0:
    // 0x8012C080: lbu         $v0, 0x2B($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X2B);
    // 0x8012C084: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012C088: addiu       $a0, $a0, 0x4E50
    ctx->r4 = ADD32(ctx->r4, 0X4E50);
    // 0x8012C08C: beq         $v0, $zero, L_8012C0A8
    if (ctx->r2 == 0) {
        // 0x8012C090: lui         $t6, 0x803A
        ctx->r14 = S32(0X803A << 16);
            goto L_8012C0A8;
    }
    // 0x8012C090: lui         $t6, 0x803A
    ctx->r14 = S32(0X803A << 16);
    // 0x8012C094: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012C098: beq         $v0, $at, L_8012C110
    if (ctx->r2 == ctx->r1) {
        // 0x8012C09C: lui         $a0, 0x8029
        ctx->r4 = S32(0X8029 << 16);
            goto L_8012C110;
    }
    // 0x8012C09C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012C0A0: b           L_8012C178
    // 0x8012C0A4: nop

        goto L_8012C178;
    // 0x8012C0A4: nop

L_8012C0A8:
    // 0x8012C0A8: addiu       $t6, $t6, 0x4E0
    ctx->r14 = ADD32(ctx->r14, 0X4E0);
    // 0x8012C0AC: subu        $a1, $t6, $a0
    ctx->r5 = SUB32(ctx->r14, ctx->r4);
    // 0x8012C0B0: jal         0x80139400
    // 0x8012C0B4: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    osInvalICache_recomp(rdram, ctx);
        goto after_1;
    // 0x8012C0B4: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    after_1:
    // 0x8012C0B8: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x8012C0BC: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x8012C0C0: addiu       $a0, $a0, 0x4E0
    ctx->r4 = ADD32(ctx->r4, 0X4E0);
    // 0x8012C0C4: addiu       $t7, $t7, 0x420
    ctx->r15 = ADD32(ctx->r15, 0X420);
    // 0x8012C0C8: jal         0x80139480
    // 0x8012C0CC: subu        $a1, $t7, $a0
    ctx->r5 = SUB32(ctx->r15, ctx->r4);
    osInvalDCache_recomp(rdram, ctx);
        goto after_2;
    // 0x8012C0CC: subu        $a1, $t7, $a0
    ctx->r5 = SUB32(ctx->r15, ctx->r4);
    after_2:
    // 0x8012C0D0: lui         $a0, 0x6A
    ctx->r4 = S32(0X6A << 16);
    // 0x8012C0D4: lui         $t8, 0x7D
    ctx->r24 = S32(0X7D << 16);
    // 0x8012C0D8: addiu       $a0, $a0, 0x6500
    ctx->r4 = ADD32(ctx->r4, 0X6500);
    // 0x8012C0DC: addiu       $t8, $t8, 0x1AD0
    ctx->r24 = ADD32(ctx->r24, 0X1AD0);
    // 0x8012C0E0: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8012C0E4: addiu       $a1, $a1, 0x4E50
    ctx->r5 = ADD32(ctx->r5, 0X4E50);
    // 0x8012C0E8: jal         0x80129290
    // 0x8012C0EC: subu        $a2, $t8, $a0
    ctx->r6 = SUB32(ctx->r24, ctx->r4);
    dma_read(rdram, ctx);
        goto after_3;
    // 0x8012C0EC: subu        $a2, $t8, $a0
    ctx->r6 = SUB32(ctx->r24, ctx->r4);
    after_3:
    // 0x8012C0F0: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8012C0F4: lui         $t9, 0x8040
    ctx->r25 = S32(0X8040 << 16);
    // 0x8012C0F8: addiu       $a0, $a0, 0x420
    ctx->r4 = ADD32(ctx->r4, 0X420);
    // 0x8012C0FC: addiu       $t9, $t9, -0x2140
    ctx->r25 = ADD32(ctx->r25, -0X2140);
    // 0x8012C100: jal         0x80139530
    // 0x8012C104: subu        $a1, $t9, $a0
    ctx->r5 = SUB32(ctx->r25, ctx->r4);
    _bzero(rdram, ctx);
        goto after_4;
    // 0x8012C104: subu        $a1, $t9, $a0
    ctx->r5 = SUB32(ctx->r25, ctx->r4);
    after_4:
    // 0x8012C108: b           L_8012C178
    // 0x8012C10C: nop

        goto L_8012C178;
    // 0x8012C10C: nop

L_8012C110:
    // 0x8012C110: lui         $t0, 0x802A
    ctx->r8 = S32(0X802A << 16);
    // 0x8012C114: addiu       $a0, $a0, 0x4E50
    ctx->r4 = ADD32(ctx->r4, 0X4E50);
    // 0x8012C118: addiu       $t0, $t0, -0x68D0
    ctx->r8 = ADD32(ctx->r8, -0X68D0);
    // 0x8012C11C: subu        $a1, $t0, $a0
    ctx->r5 = SUB32(ctx->r8, ctx->r4);
    // 0x8012C120: jal         0x80139400
    // 0x8012C124: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    osInvalICache_recomp(rdram, ctx);
        goto after_5;
    // 0x8012C124: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    after_5:
    // 0x8012C128: lui         $a0, 0x802A
    ctx->r4 = S32(0X802A << 16);
    // 0x8012C12C: lui         $t1, 0x8030
    ctx->r9 = S32(0X8030 << 16);
    // 0x8012C130: addiu       $a0, $a0, -0x68D0
    ctx->r4 = ADD32(ctx->r4, -0X68D0);
    // 0x8012C134: addiu       $t1, $t1, 0x2E60
    ctx->r9 = ADD32(ctx->r9, 0X2E60);
    // 0x8012C138: jal         0x80139480
    // 0x8012C13C: subu        $a1, $t1, $a0
    ctx->r5 = SUB32(ctx->r9, ctx->r4);
    osInvalDCache_recomp(rdram, ctx);
        goto after_6;
    // 0x8012C13C: subu        $a1, $t1, $a0
    ctx->r5 = SUB32(ctx->r9, ctx->r4);
    after_6:
    // 0x8012C140: lui         $a0, 0x64
    ctx->r4 = S32(0X64 << 16);
    // 0x8012C144: lui         $t2, 0x6A
    ctx->r10 = S32(0X6A << 16);
    // 0x8012C148: addiu       $a0, $a0, -0x7B10
    ctx->r4 = ADD32(ctx->r4, -0X7B10);
    // 0x8012C14C: addiu       $t2, $t2, 0x6500
    ctx->r10 = ADD32(ctx->r10, 0X6500);
    // 0x8012C150: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8012C154: addiu       $a1, $a1, 0x4E50
    ctx->r5 = ADD32(ctx->r5, 0X4E50);
    // 0x8012C158: jal         0x80129290
    // 0x8012C15C: subu        $a2, $t2, $a0
    ctx->r6 = SUB32(ctx->r10, ctx->r4);
    dma_read(rdram, ctx);
        goto after_7;
    // 0x8012C15C: subu        $a2, $t2, $a0
    ctx->r6 = SUB32(ctx->r10, ctx->r4);
    after_7:
    // 0x8012C160: lui         $a0, 0x8030
    ctx->r4 = S32(0X8030 << 16);
    // 0x8012C164: lui         $t3, 0x803B
    ctx->r11 = S32(0X803B << 16);
    // 0x8012C168: addiu       $a0, $a0, 0x2E60
    ctx->r4 = ADD32(ctx->r4, 0X2E60);
    // 0x8012C16C: addiu       $t3, $t3, 0x5A0
    ctx->r11 = ADD32(ctx->r11, 0X5A0);
    // 0x8012C170: jal         0x80139530
    // 0x8012C174: subu        $a1, $t3, $a0
    ctx->r5 = SUB32(ctx->r11, ctx->r4);
    _bzero(rdram, ctx);
        goto after_8;
    // 0x8012C174: subu        $a1, $t3, $a0
    ctx->r5 = SUB32(ctx->r11, ctx->r4);
    after_8:
L_8012C178:
    // 0x8012C178: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012C17C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8012C180: jr          $ra
    // 0x8012C184: nop

    return;
    // 0x8012C184: nop

;}
RECOMP_FUNC void func_8012C190(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C190: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012C194: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8012C198: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x8012C19C: lbu         $v1, 0x4($a0)
    ctx->r3 = MEM_BU(ctx->r4, 0X4);
    // 0x8012C1A0: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x8012C1A4: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x8012C1A8: blez        $v1, L_8012C1E4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x8012C1AC: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8012C1E4;
    }
    // 0x8012C1AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8012C1B0: lw          $a3, 0x0($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X0);
    // 0x8012C1B4: addiu       $t1, $zero, 0xC
    ctx->r9 = ADD32(0, 0XC);
L_8012C1B8:
    // 0x8012C1B8: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012C1BC: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8012C1C0: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x8012C1C4: mflo        $t7
    ctx->r15 = lo;
    // 0x8012C1C8: addu        $a0, $a3, $t7
    ctx->r4 = ADD32(ctx->r7, ctx->r15);
    // 0x8012C1CC: lhu         $a1, 0x8($a0)
    ctx->r5 = MEM_HU(ctx->r4, 0X8);
    // 0x8012C1D0: slt         $at, $a2, $a1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x8012C1D4: bne         $at, $zero, L_8012C1D8
    if (ctx->r1 != 0) {
        // 0x8012C1D8: slt         $at, $t8, $v1
        ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_8012C1D8;
    }
L_8012C1D8:
    // 0x8012C1D8: slt         $at, $t8, $v1
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8012C1DC: bne         $at, $zero, L_8012C1B8
    if (ctx->r1 != 0) {
        // 0x8012C1E0: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_8012C1B8;
    }
    // 0x8012C1E0: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
L_8012C1E4:
    // 0x8012C1E4: jr          $ra
    // 0x8012C1E8: nop

    return;
    // 0x8012C1E8: nop

;}
RECOMP_FUNC void load_default_display_list(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C1F0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012C1F4: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8012C1F8: addiu       $t8, $t8, 0x4628
    ctx->r24 = ADD32(ctx->r24, 0X4628);
    // 0x8012C1FC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012C200: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012C204: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8012C208: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8012C20C: jr          $ra
    // 0x8012C210: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    return;
    // 0x8012C210: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
;}
RECOMP_FUNC void set_menu_text_color(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C214: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C218: sb          $a0, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r4;
    // 0x8012C21C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C220: sb          $a1, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r5;
    // 0x8012C224: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C228: sb          $a2, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r6;
    // 0x8012C22C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C230: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8012C234: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012C238: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8012C23C: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x8012C240: jr          $ra
    // 0x8012C244: sb          $a3, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r7;
    return;
    // 0x8012C244: sb          $a3, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r7;
;}
RECOMP_FUNC void select_font(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C248: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C24C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012C250: sb          $a0, -0xE0C($at)
    MEM_B(-0XE0C, ctx->r1) = ctx->r4;
    // 0x8012C254: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C258: sb          $a2, -0xE0B($at)
    MEM_B(-0XE0B, ctx->r1) = ctx->r6;
    // 0x8012C25C: andi        $t7, $a1, 0xFF
    ctx->r15 = ctx->r5 & 0XFF;
    // 0x8012C260: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012C264: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012C268: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8012C26C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8012C270: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x8012C274: bne         $t7, $at, L_8012C28C
    if (ctx->r15 != ctx->r1) {
        // 0x8012C278: sw          $a3, 0x24($sp)
        MEM_W(0X24, ctx->r29) = ctx->r7;
            goto L_8012C28C;
    }
    // 0x8012C278: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x8012C27C: jal         0x8012C2E4
    // 0x8012C280: nop

    select_lcd_font(rdram, ctx);
        goto after_0;
    // 0x8012C280: nop

    after_0:
    // 0x8012C284: b           L_8012C298
    // 0x8012C288: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8012C298;
    // 0x8012C288: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8012C28C:
    // 0x8012C28C: jal         0x8012C2A4
    // 0x8012C290: nop

    select_comic_sans_font(rdram, ctx);
        goto after_1;
    // 0x8012C290: nop

    after_1:
    // 0x8012C294: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8012C298:
    // 0x8012C298: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012C29C: jr          $ra
    // 0x8012C2A0: nop

    return;
    // 0x8012C2A0: nop

;}
RECOMP_FUNC void select_comic_sans_font(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C2A4: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8012C2A8: addiu       $v0, $v0, -0xE20
    ctx->r2 = ADD32(ctx->r2, -0XE20);
    // 0x8012C2AC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8012C2B0: lui         $t7, 0x800E
    ctx->r15 = S32(0X800E << 16);
    // 0x8012C2B4: addiu       $v1, $zero, 0x10
    ctx->r3 = ADD32(0, 0X10);
    // 0x8012C2B8: addiu       $t6, $t6, 0x4370
    ctx->r14 = ADD32(ctx->r14, 0X4370);
    // 0x8012C2BC: addiu       $t7, $t7, 0x1220
    ctx->r15 = ADD32(ctx->r15, 0X1220);
    // 0x8012C2C0: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x8012C2C4: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x8012C2C8: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012C2CC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012C2D0: sb          $v1, 0x8($v0)
    MEM_B(0X8, ctx->r2) = ctx->r3;
    // 0x8012C2D4: sb          $v1, 0x9($v0)
    MEM_B(0X9, ctx->r2) = ctx->r3;
    // 0x8012C2D8: sb          $t8, 0xA($v0)
    MEM_B(0XA, ctx->r2) = ctx->r24;
    // 0x8012C2DC: jr          $ra
    // 0x8012C2E0: sh          $t9, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r25;
    return;
    // 0x8012C2E0: sh          $t9, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r25;
;}
RECOMP_FUNC void select_lcd_font(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C2E4: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8012C2E8: addiu       $v0, $v0, -0xE20
    ctx->r2 = ADD32(ctx->r2, -0XE20);
    // 0x8012C2EC: addiu       $v1, $zero, 0x10
    ctx->r3 = ADD32(0, 0X10);
    // 0x8012C2F0: lui         $t6, 0x8016
    ctx->r14 = S32(0X8016 << 16);
    // 0x8012C2F4: addiu       $t6, $t6, -0x7AB0
    ctx->r14 = ADD32(ctx->r14, -0X7AB0);
    // 0x8012C2F8: addiu       $t7, $zero, 0x200
    ctx->r15 = ADD32(0, 0X200);
    // 0x8012C2FC: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012C300: sb          $v1, 0x8($v0)
    MEM_B(0X8, ctx->r2) = ctx->r3;
    // 0x8012C304: sb          $v1, 0x9($v0)
    MEM_B(0X9, ctx->r2) = ctx->r3;
    // 0x8012C308: sb          $v1, 0xA($v0)
    MEM_B(0XA, ctx->r2) = ctx->r3;
    // 0x8012C30C: jr          $ra
    // 0x8012C310: sh          $t7, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r15;
    return;
    // 0x8012C310: sh          $t7, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r15;
;}
RECOMP_FUNC void get_glyph_width(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C314: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8012C318: lbu         $t6, -0xE18($t6)
    ctx->r14 = MEM_BU(ctx->r14, -0XE18);
    // 0x8012C31C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012C320: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8012C324: bgez        $t6, L_8012C338
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012C328: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8012C338;
    }
    // 0x8012C328: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012C32C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012C330: nop

    // 0x8012C334: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_8012C338:
    // 0x8012C338: div.s       $f0, $f12, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = DIV_S(ctx->f12.fl, ctx->f6.fl);
    // 0x8012C33C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C340: lwc1        $f10, -0xE08($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012C344: mul.s       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x8012C348: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012C34C: mfc1        $v1, $f18
    ctx->r3 = (int32_t)ctx->f18.u32l;
    // 0x8012C350: nop

    // 0x8012C354: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8012C358: jr          $ra
    // 0x8012C35C: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    return;
    // 0x8012C35C: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
;}
RECOMP_FUNC void convert_text_to_int(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C360: lh          $a1, 0x0($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X0);
    // 0x8012C364: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8012C368: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8012C36C: slti        $at, $a1, 0x140
    ctx->r1 = SIGNED(ctx->r5) < 0X140 ? 1 : 0;
    // 0x8012C370: bne         $at, $zero, L_8012C3D0
    if (ctx->r1 != 0) {
        // 0x8012C374: slti        $at, $a1, 0x14A
        ctx->r1 = SIGNED(ctx->r5) < 0X14A ? 1 : 0;
            goto L_8012C3D0;
    }
    // 0x8012C374: slti        $at, $a1, 0x14A
    ctx->r1 = SIGNED(ctx->r5) < 0X14A ? 1 : 0;
    // 0x8012C378: beq         $at, $zero, L_8012C3D0
    if (ctx->r1 == 0) {
        // 0x8012C37C: sll         $t6, $zero, 1
        ctx->r14 = S32(0 << 1);
            goto L_8012C3D0;
    }
    // 0x8012C37C: sll         $t6, $zero, 1
    ctx->r14 = S32(0 << 1);
    // 0x8012C380: addu        $t7, $a0, $t6
    ctx->r15 = ADD32(ctx->r4, ctx->r14);
    // 0x8012C384: lh          $a1, 0x0($t7)
    ctx->r5 = MEM_H(ctx->r15, 0X0);
    // 0x8012C388: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
L_8012C38C:
    // 0x8012C38C: multu       $v1, $a2
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012C390: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8012C394: andi        $t0, $v0, 0xFF
    ctx->r8 = ctx->r2 & 0XFF;
    // 0x8012C398: sll         $t1, $t0, 1
    ctx->r9 = S32(ctx->r8 << 1);
    // 0x8012C39C: addu        $t2, $a0, $t1
    ctx->r10 = ADD32(ctx->r4, ctx->r9);
    // 0x8012C3A0: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x8012C3A4: mflo        $t8
    ctx->r24 = lo;
    // 0x8012C3A8: addu        $v1, $a1, $t8
    ctx->r3 = ADD32(ctx->r5, ctx->r24);
    // 0x8012C3AC: lh          $a1, 0x0($t2)
    ctx->r5 = MEM_H(ctx->r10, 0X0);
    // 0x8012C3B0: addiu       $v1, $v1, -0x140
    ctx->r3 = ADD32(ctx->r3, -0X140);
    // 0x8012C3B4: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    // 0x8012C3B8: slti        $at, $a1, 0x140
    ctx->r1 = SIGNED(ctx->r5) < 0X140 ? 1 : 0;
    // 0x8012C3BC: bne         $at, $zero, L_8012C3D0
    if (ctx->r1 != 0) {
        // 0x8012C3C0: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_8012C3D0;
    }
    // 0x8012C3C0: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x8012C3C4: slti        $at, $a1, 0x14A
    ctx->r1 = SIGNED(ctx->r5) < 0X14A ? 1 : 0;
    // 0x8012C3C8: bne         $at, $zero, L_8012C38C
    if (ctx->r1 != 0) {
        // 0x8012C3CC: nop
    
            goto L_8012C38C;
    }
    // 0x8012C3CC: nop

L_8012C3D0:
    // 0x8012C3D0: jr          $ra
    // 0x8012C3D4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x8012C3D4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void get_message_width(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C3D8: addiu       $sp, $sp, -0x158
    ctx->r29 = ADD32(ctx->r29, -0X158);
    // 0x8012C3DC: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8012C3E0: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x8012C3E4: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x8012C3E8: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x8012C3EC: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x8012C3F0: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x8012C3F4: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x8012C3F8: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8012C3FC: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x8012C400: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x8012C404: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012C408: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
    // 0x8012C40C: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012C410: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8012C414: beq         $v1, $at, L_8012C638
    if (ctx->r3 == ctx->r1) {
        // 0x8012C418: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_8012C638;
    }
    // 0x8012C418: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x8012C41C: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8012C420: lui         $s6, 0x8024
    ctx->r22 = S32(0X8024 << 16);
    // 0x8012C424: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x8012C428: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012C42C: addiu       $s3, $s3, -0xE20
    ctx->r19 = ADD32(ctx->r19, -0XE20);
    // 0x8012C430: addiu       $s6, $s6, -0xE08
    ctx->r22 = ADD32(ctx->r22, -0XE08);
    // 0x8012C434: addiu       $fp, $zero, 0x157
    ctx->r30 = ADD32(0, 0X157);
    // 0x8012C438: addiu       $s7, $zero, 0x150
    ctx->r23 = ADD32(0, 0X150);
    // 0x8012C43C: addiu       $s5, $sp, 0x5C
    ctx->r21 = ADD32(ctx->r29, 0X5C);
    // 0x8012C440: addiu       $s4, $sp, 0xFC
    ctx->r20 = ADD32(ctx->r29, 0XFC);
    // 0x8012C444: sll         $s1, $v1, 16
    ctx->r17 = S32(ctx->r3 << 16);
L_8012C448:
    // 0x8012C448: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8012C44C: bne         $s7, $v1, L_8012C4E8
    if (ctx->r23 != ctx->r3) {
        // 0x8012C450: or          $s1, $t6, $zero
        ctx->r17 = ctx->r14 | 0;
            goto L_8012C4E8;
    }
    // 0x8012C450: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x8012C454: lh          $v1, 0x2($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X2);
    // 0x8012C458: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8012C45C: addiu       $at, $zero, 0x153
    ctx->r1 = ADD32(0, 0X153);
    // 0x8012C460: bne         $fp, $v1, L_8012C4D4
    if (ctx->r30 != ctx->r3) {
        // 0x8012C464: nop
    
            goto L_8012C4D4;
    }
    // 0x8012C464: nop

    // 0x8012C468: lh          $t7, 0x2($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2);
    // 0x8012C46C: addiu       $t9, $zero, 0x7530
    ctx->r25 = ADD32(0, 0X7530);
    // 0x8012C470: addiu       $a0, $sp, 0x14C
    ctx->r4 = ADD32(ctx->r29, 0X14C);
    // 0x8012C474: sh          $t7, 0x14C($sp)
    MEM_H(0X14C, ctx->r29) = ctx->r15;
    // 0x8012C478: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x8012C47C: sh          $t9, 0x150($sp)
    MEM_H(0X150, ctx->r29) = ctx->r25;
    // 0x8012C480: jal         0x8012C360
    // 0x8012C484: sh          $t8, 0x14E($sp)
    MEM_H(0X14E, ctx->r29) = ctx->r24;
    convert_text_to_int(rdram, ctx);
        goto after_0;
    // 0x8012C484: sh          $t8, 0x14E($sp)
    MEM_H(0X14E, ctx->r29) = ctx->r24;
    after_0:
    // 0x8012C488: sll         $t0, $v0, 1
    ctx->r8 = S32(ctx->r2 << 1);
    // 0x8012C48C: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x8012C490: addu        $a2, $a2, $t0
    ctx->r6 = ADD32(ctx->r6, ctx->r8);
    // 0x8012C494: lui         $a1, 0x8016
    ctx->r5 = S32(0X8016 << 16);
    // 0x8012C498: addiu       $a1, $a1, -0x5360
    ctx->r5 = ADD32(ctx->r5, -0X5360);
    // 0x8012C49C: lh          $a2, -0xDFA($a2)
    ctx->r6 = MEM_H(ctx->r6, -0XDFA);
    // 0x8012C4A0: jal         0x801395F4
    // 0x8012C4A4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    sprintf_recomp(rdram, ctx);
        goto after_1;
    // 0x8012C4A4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_1:
    // 0x8012C4A8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8012C4AC: jal         0x801308B4
    // 0x8012C4B0: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    prepare_text(rdram, ctx);
        goto after_2;
    // 0x8012C4B0: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    after_2:
    // 0x8012C4B4: jal         0x8012C3D8
    // 0x8012C4B8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    get_message_width(rdram, ctx);
        goto after_3;
    // 0x8012C4B8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    after_3:
    // 0x8012C4BC: addu        $s2, $s2, $v0
    ctx->r18 = ADD32(ctx->r18, ctx->r2);
    // 0x8012C4C0: andi        $t1, $s2, 0xFFFF
    ctx->r9 = ctx->r18 & 0XFFFF;
    // 0x8012C4C4: or          $s2, $t1, $zero
    ctx->r18 = ctx->r9 | 0;
    // 0x8012C4C8: addiu       $s0, $s0, 0x6
    ctx->r16 = ADD32(ctx->r16, 0X6);
    // 0x8012C4CC: b           L_8012C62C
    // 0x8012C4D0: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
        goto L_8012C62C;
    // 0x8012C4D0: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
L_8012C4D4:
    // 0x8012C4D4: bnel        $v1, $at, L_8012C630
    if (ctx->r3 != ctx->r1) {
        // 0x8012C4D8: addiu       $at, $zero, 0x7530
        ctx->r1 = ADD32(0, 0X7530);
            goto L_8012C630;
    }
    goto skip_0;
    // 0x8012C4D8: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    skip_0:
    // 0x8012C4DC: addiu       $s0, $s0, 0x4
    ctx->r16 = ADD32(ctx->r16, 0X4);
    // 0x8012C4E0: b           L_8012C62C
    // 0x8012C4E4: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
        goto L_8012C62C;
    // 0x8012C4E4: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
L_8012C4E8:
    // 0x8012C4E8: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8012C4EC: lbu         $v0, -0xE0C($v0)
    ctx->r2 = MEM_BU(ctx->r2, -0XE0C);
    // 0x8012C4F0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012C4F4: beql        $v0, $zero, L_8012C510
    if (ctx->r2 == 0) {
        // 0x8012C4F8: lw          $t2, 0x0($s3)
        ctx->r10 = MEM_W(ctx->r19, 0X0);
            goto L_8012C510;
    }
    goto skip_1;
    // 0x8012C4F8: lw          $t2, 0x0($s3)
    ctx->r10 = MEM_W(ctx->r19, 0X0);
    skip_1:
    // 0x8012C4FC: beql        $v0, $at, L_8012C578
    if (ctx->r2 == ctx->r1) {
        // 0x8012C500: mtc1        $s2, $f10
        ctx->f10.u32l = ctx->r18;
            goto L_8012C578;
    }
    goto skip_2;
    // 0x8012C500: mtc1        $s2, $f10
    ctx->f10.u32l = ctx->r18;
    skip_2:
    // 0x8012C504: b           L_8012C628
    // 0x8012C508: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
        goto L_8012C628;
    // 0x8012C508: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8012C50C: lw          $t2, 0x0($s3)
    ctx->r10 = MEM_W(ctx->r19, 0X0);
L_8012C510:
    // 0x8012C510: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012C514: addu        $t3, $t2, $s1
    ctx->r11 = ADD32(ctx->r10, ctx->r17);
    // 0x8012C518: sw          $t3, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r11;
    // 0x8012C51C: lbu         $t5, 0x0($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X0);
    // 0x8012C520: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x8012C524: bgez        $t5, L_8012C538
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8012C528: cvt.s.w     $f12, $f4
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8012C538;
    }
    // 0x8012C528: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012C52C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012C530: nop

    // 0x8012C534: add.s       $f12, $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f6.fl;
L_8012C538:
    // 0x8012C538: jal         0x8012C314
    // 0x8012C53C: nop

    get_glyph_width(rdram, ctx);
        goto after_4;
    // 0x8012C53C: nop

    after_4:
    // 0x8012C540: lwc1        $f8, 0x0($s6)
    ctx->f8.u32l = MEM_W(ctx->r22, 0X0);
    // 0x8012C544: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
    // 0x8012C548: addu        $s2, $s2, $v0
    ctx->r18 = ADD32(ctx->r18, ctx->r2);
    // 0x8012C54C: c.lt.s      $f8, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    c1cs = ctx->f8.fl < ctx->f20.fl;
    // 0x8012C550: andi        $t6, $s2, 0xFFFF
    ctx->r14 = ctx->r18 & 0XFFFF;
    // 0x8012C554: subu        $t8, $t7, $s1
    ctx->r24 = SUB32(ctx->r15, ctx->r17);
    // 0x8012C558: or          $s2, $t6, $zero
    ctx->r18 = ctx->r14 | 0;
    // 0x8012C55C: bc1f        L_8012C624
    if (!c1cs) {
        // 0x8012C560: sw          $t8, 0x0($s3)
        MEM_W(0X0, ctx->r19) = ctx->r24;
            goto L_8012C624;
    }
    // 0x8012C560: sw          $t8, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r24;
    // 0x8012C564: addiu       $s2, $t6, 0x1
    ctx->r18 = ADD32(ctx->r14, 0X1);
    // 0x8012C568: andi        $t9, $s2, 0xFFFF
    ctx->r25 = ctx->r18 & 0XFFFF;
    // 0x8012C56C: b           L_8012C624
    // 0x8012C570: or          $s2, $t9, $zero
    ctx->r18 = ctx->r25 | 0;
        goto L_8012C624;
    // 0x8012C570: or          $s2, $t9, $zero
    ctx->r18 = ctx->r25 | 0;
    // 0x8012C574: mtc1        $s2, $f10
    ctx->f10.u32l = ctx->r18;
L_8012C578:
    // 0x8012C578: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012C57C: bgez        $s2, L_8012C590
    if (SIGNED(ctx->r18) >= 0) {
        // 0x8012C580: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8012C590;
    }
    // 0x8012C580: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8012C584: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012C588: nop

    // 0x8012C58C: add.s       $f16, $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f18.fl;
L_8012C590:
    // 0x8012C590: lwc1        $f4, 0x0($s6)
    ctx->f4.u32l = MEM_W(ctx->r22, 0X0);
    // 0x8012C594: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x8012C598: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012C59C: add.s       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x8012C5A0: cfc1        $t0, $FpcCsr
    ctx->r8 = get_cop1_cs();
    // 0x8012C5A4: ctc1        $s2, $FpcCsr
    set_cop1_cs(ctx->r18);
    // 0x8012C5A8: nop

    // 0x8012C5AC: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012C5B0: cfc1        $s2, $FpcCsr
    ctx->r18 = get_cop1_cs();
    // 0x8012C5B4: nop

    // 0x8012C5B8: andi        $s2, $s2, 0x78
    ctx->r18 = ctx->r18 & 0X78;
    // 0x8012C5BC: beql        $s2, $zero, L_8012C60C
    if (ctx->r18 == 0) {
        // 0x8012C5C0: mfc1        $s2, $f8
        ctx->r18 = (int32_t)ctx->f8.u32l;
            goto L_8012C60C;
    }
    goto skip_3;
    // 0x8012C5C0: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
    skip_3:
    // 0x8012C5C4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012C5C8: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x8012C5CC: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012C5D0: ctc1        $s2, $FpcCsr
    set_cop1_cs(ctx->r18);
    // 0x8012C5D4: nop

    // 0x8012C5D8: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012C5DC: cfc1        $s2, $FpcCsr
    ctx->r18 = get_cop1_cs();
    // 0x8012C5E0: nop

    // 0x8012C5E4: andi        $s2, $s2, 0x78
    ctx->r18 = ctx->r18 & 0X78;
    // 0x8012C5E8: bne         $s2, $zero, L_8012C600
    if (ctx->r18 != 0) {
        // 0x8012C5EC: nop
    
            goto L_8012C600;
    }
    // 0x8012C5EC: nop

    // 0x8012C5F0: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
    // 0x8012C5F4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012C5F8: b           L_8012C618
    // 0x8012C5FC: or          $s2, $s2, $at
    ctx->r18 = ctx->r18 | ctx->r1;
        goto L_8012C618;
    // 0x8012C5FC: or          $s2, $s2, $at
    ctx->r18 = ctx->r18 | ctx->r1;
L_8012C600:
    // 0x8012C600: b           L_8012C618
    // 0x8012C604: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
        goto L_8012C618;
    // 0x8012C604: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
    // 0x8012C608: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
L_8012C60C:
    // 0x8012C60C: nop

    // 0x8012C610: bltz        $s2, L_8012C600
    if (SIGNED(ctx->r18) < 0) {
        // 0x8012C614: nop
    
            goto L_8012C600;
    }
    // 0x8012C614: nop

L_8012C618:
    // 0x8012C618: ctc1        $t0, $FpcCsr
    set_cop1_cs(ctx->r8);
    // 0x8012C61C: andi        $t1, $s2, 0xFFFF
    ctx->r9 = ctx->r18 & 0XFFFF;
    // 0x8012C620: or          $s2, $t1, $zero
    ctx->r18 = ctx->r9 | 0;
L_8012C624:
    // 0x8012C624: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
L_8012C628:
    // 0x8012C628: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
L_8012C62C:
    // 0x8012C62C: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
L_8012C630:
    // 0x8012C630: bnel        $v1, $at, L_8012C448
    if (ctx->r3 != ctx->r1) {
        // 0x8012C634: sll         $s1, $v1, 16
        ctx->r17 = S32(ctx->r3 << 16);
            goto L_8012C448;
    }
    goto skip_4;
    // 0x8012C634: sll         $s1, $v1, 16
    ctx->r17 = S32(ctx->r3 << 16);
    skip_4:
L_8012C638:
    // 0x8012C638: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8012C63C: sll         $v0, $s2, 16
    ctx->r2 = S32(ctx->r18 << 16);
    // 0x8012C640: sra         $t2, $v0, 16
    ctx->r10 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8012C644: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x8012C648: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x8012C64C: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8012C650: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x8012C654: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x8012C658: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8012C65C: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x8012C660: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x8012C664: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8012C668: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x8012C66C: addiu       $sp, $sp, 0x158
    ctx->r29 = ADD32(ctx->r29, 0X158);
    // 0x8012C670: jr          $ra
    // 0x8012C674: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    return;
    // 0x8012C674: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
;}
RECOMP_FUNC void func_8012C678(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C678: addiu       $sp, $sp, -0x128
    ctx->r29 = ADD32(ctx->r29, -0X128);
    // 0x8012C67C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8012C680: sw          $a1, 0x12C($sp)
    MEM_W(0X12C, ctx->r29) = ctx->r5;
    // 0x8012C684: sw          $a2, 0x130($sp)
    MEM_W(0X130, ctx->r29) = ctx->r6;
    // 0x8012C688: lh          $v0, 0x0($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X0);
    // 0x8012C68C: addiu       $at, $zero, 0x150
    ctx->r1 = ADD32(0, 0X150);
    // 0x8012C690: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8012C694: bnel        $v0, $at, L_8012C954
    if (ctx->r2 != ctx->r1) {
        // 0x8012C698: addiu       $at, $zero, 0x4E20
        ctx->r1 = ADD32(0, 0X4E20);
            goto L_8012C954;
    }
    goto skip_0;
    // 0x8012C698: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    skip_0:
    // 0x8012C69C: lh          $v0, 0x2($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X2);
    // 0x8012C6A0: addiu       $at, $zero, 0x157
    ctx->r1 = ADD32(0, 0X157);
    // 0x8012C6A4: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8012C6A8: bne         $v0, $at, L_8012C7AC
    if (ctx->r2 != ctx->r1) {
        // 0x8012C6AC: addiu       $t8, $zero, 0x7530
        ctx->r24 = ADD32(0, 0X7530);
            goto L_8012C7AC;
    }
    // 0x8012C6AC: addiu       $t8, $zero, 0x7530
    ctx->r24 = ADD32(0, 0X7530);
    // 0x8012C6B0: lh          $t6, 0x2($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2);
    // 0x8012C6B4: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
    // 0x8012C6B8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8012C6BC: sh          $t6, 0x30($sp)
    MEM_H(0X30, ctx->r29) = ctx->r14;
    // 0x8012C6C0: lh          $t9, 0x30($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X30);
    // 0x8012C6C4: lh          $t7, 0x0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X0);
    // 0x8012C6C8: sh          $t8, 0x34($sp)
    MEM_H(0X34, ctx->r29) = ctx->r24;
    // 0x8012C6CC: slti        $at, $t9, 0x140
    ctx->r1 = SIGNED(ctx->r25) < 0X140 ? 1 : 0;
    // 0x8012C6D0: bne         $at, $zero, L_8012C738
    if (ctx->r1 != 0) {
        // 0x8012C6D4: sh          $t7, 0x32($sp)
        MEM_H(0X32, ctx->r29) = ctx->r15;
            goto L_8012C738;
    }
    // 0x8012C6D4: sh          $t7, 0x32($sp)
    MEM_H(0X32, ctx->r29) = ctx->r15;
    // 0x8012C6D8: slti        $at, $t9, 0x14A
    ctx->r1 = SIGNED(ctx->r25) < 0X14A ? 1 : 0;
    // 0x8012C6DC: beq         $at, $zero, L_8012C738
    if (ctx->r1 == 0) {
        // 0x8012C6E0: sll         $t0, $zero, 1
        ctx->r8 = S32(0 << 1);
            goto L_8012C738;
    }
    // 0x8012C6E0: sll         $t0, $zero, 1
    ctx->r8 = S32(0 << 1);
    // 0x8012C6E4: addu        $v0, $sp, $t0
    ctx->r2 = ADD32(ctx->r29, ctx->r8);
    // 0x8012C6E8: lh          $v0, 0x30($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X30);
    // 0x8012C6EC: addiu       $a1, $sp, 0x30
    ctx->r5 = ADD32(ctx->r29, 0X30);
    // 0x8012C6F0: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
L_8012C6F4:
    // 0x8012C6F4: multu       $a3, $a0
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012C6F8: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x8012C6FC: andi        $t4, $v1, 0xFF
    ctx->r12 = ctx->r3 & 0XFF;
    // 0x8012C700: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x8012C704: addu        $t6, $a1, $t5
    ctx->r14 = ADD32(ctx->r5, ctx->r13);
    // 0x8012C708: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x8012C70C: mflo        $t1
    ctx->r9 = lo;
    // 0x8012C710: addu        $a3, $v0, $t1
    ctx->r7 = ADD32(ctx->r2, ctx->r9);
    // 0x8012C714: lh          $v0, 0x0($t6)
    ctx->r2 = MEM_H(ctx->r14, 0X0);
    // 0x8012C718: addiu       $a3, $a3, -0x140
    ctx->r7 = ADD32(ctx->r7, -0X140);
    // 0x8012C71C: sll         $t2, $a3, 16
    ctx->r10 = S32(ctx->r7 << 16);
    // 0x8012C720: slti        $at, $v0, 0x140
    ctx->r1 = SIGNED(ctx->r2) < 0X140 ? 1 : 0;
    // 0x8012C724: bne         $at, $zero, L_8012C738
    if (ctx->r1 != 0) {
        // 0x8012C728: sra         $a3, $t2, 16
        ctx->r7 = S32(SIGNED(ctx->r10) >> 16);
            goto L_8012C738;
    }
    // 0x8012C728: sra         $a3, $t2, 16
    ctx->r7 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8012C72C: slti        $at, $v0, 0x14A
    ctx->r1 = SIGNED(ctx->r2) < 0X14A ? 1 : 0;
    // 0x8012C730: bne         $at, $zero, L_8012C6F4
    if (ctx->r1 != 0) {
        // 0x8012C734: nop
    
            goto L_8012C6F4;
    }
    // 0x8012C734: nop

L_8012C738:
    // 0x8012C738: sll         $t7, $a3, 1
    ctx->r15 = S32(ctx->r7 << 1);
    // 0x8012C73C: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x8012C740: addu        $a2, $a2, $t7
    ctx->r6 = ADD32(ctx->r6, ctx->r15);
    // 0x8012C744: lui         $a1, 0x8016
    ctx->r5 = S32(0X8016 << 16);
    // 0x8012C748: addiu       $a1, $a1, -0x535C
    ctx->r5 = ADD32(ctx->r5, -0X535C);
    // 0x8012C74C: lh          $a2, -0xDFA($a2)
    ctx->r6 = MEM_H(ctx->r6, -0XDFA);
    // 0x8012C750: jal         0x801395F4
    // 0x8012C754: addiu       $a0, $sp, 0xD8
    ctx->r4 = ADD32(ctx->r29, 0XD8);
    sprintf_recomp(rdram, ctx);
        goto after_0;
    // 0x8012C754: addiu       $a0, $sp, 0xD8
    ctx->r4 = ADD32(ctx->r29, 0XD8);
    after_0:
    // 0x8012C758: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x8012C75C: addiu       $a1, $a1, -0xDB8
    ctx->r5 = ADD32(ctx->r5, -0XDB8);
    // 0x8012C760: jal         0x801308B4
    // 0x8012C764: addiu       $a0, $sp, 0xD8
    ctx->r4 = ADD32(ctx->r29, 0XD8);
    prepare_text(rdram, ctx);
        goto after_1;
    // 0x8012C764: addiu       $a0, $sp, 0xD8
    ctx->r4 = ADD32(ctx->r29, 0XD8);
    after_1:
    // 0x8012C768: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C76C: lwc1        $f4, -0xE08($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012C770: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C774: lwc1        $f6, -0xE04($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012C778: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8012C77C: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x8012C780: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8012C784: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8012C788: addiu       $a1, $a1, -0xDB8
    ctx->r5 = ADD32(ctx->r5, -0XDB8);
    // 0x8012C78C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8012C790: lhu         $a2, 0x12E($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X12E);
    // 0x8012C794: lhu         $a3, 0x132($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X132);
    // 0x8012C798: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8012C79C: jal         0x8012D374
    // 0x8012C7A0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_2;
    // 0x8012C7A0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_2:
    // 0x8012C7A4: b           L_8012C968
    // 0x8012C7A8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_8012C968;
    // 0x8012C7A8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8012C7AC:
    // 0x8012C7AC: addiu       $at, $zero, 0x153
    ctx->r1 = ADD32(0, 0X153);
    // 0x8012C7B0: bnel        $v0, $at, L_8012C968
    if (ctx->r2 != ctx->r1) {
        // 0x8012C7B4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8012C968;
    }
    goto skip_1;
    // 0x8012C7B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x8012C7B8: lh          $t9, 0x2($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X2);
    // 0x8012C7BC: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8012C7C0: addiu       $t0, $t9, -0x152
    ctx->r8 = ADD32(ctx->r25, -0X152);
    // 0x8012C7C4: sltiu       $at, $t0, 0x18
    ctx->r1 = ctx->r8 < 0X18 ? 1 : 0;
    // 0x8012C7C8: beq         $at, $zero, L_8012C948
    if (ctx->r1 == 0) {
        // 0x8012C7CC: sll         $t0, $t0, 2
        ctx->r8 = S32(ctx->r8 << 2);
            goto L_8012C948;
    }
    // 0x8012C7CC: sll         $t0, $t0, 2
    ctx->r8 = S32(ctx->r8 << 2);
    // 0x8012C7D0: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x8012C7D4: addu        $at, $at, $t0
    gpr jr_addend_8012C7DC = ctx->r8;
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8012C7D8: lw          $t0, -0x5358($at)
    ctx->r8 = ADD32(ctx->r1, -0X5358);
    // 0x8012C7DC: jr          $t0
    // 0x8012C7E0: nop

    switch (jr_addend_8012C7DC >> 2) {
        case 0: goto L_8012C844; break;
        case 1: goto L_8012C924; break;
        case 2: goto L_8012C948; break;
        case 3: goto L_8012C948; break;
        case 4: goto L_8012C948; break;
        case 5: goto L_8012C818; break;
        case 6: goto L_8012C948; break;
        case 7: goto L_8012C948; break;
        case 8: goto L_8012C948; break;
        case 9: goto L_8012C948; break;
        case 10: goto L_8012C948; break;
        case 11: goto L_8012C948; break;
        case 12: goto L_8012C948; break;
        case 13: goto L_8012C948; break;
        case 14: goto L_8012C8F8; break;
        case 15: goto L_8012C948; break;
        case 16: goto L_8012C7E4; break;
        case 17: goto L_8012C948; break;
        case 18: goto L_8012C948; break;
        case 19: goto L_8012C948; break;
        case 20: goto L_8012C948; break;
        case 21: goto L_8012C8A0; break;
        case 22: goto L_8012C8CC; break;
        case 23: goto L_8012C874; break;
        default: switch_error(__func__, 0x8012C7DC, 0x8015ACA8);
    }
    // 0x8012C7E0: nop

L_8012C7E4:
    // 0x8012C7E4: addiu       $t1, $zero, 0xC8
    ctx->r9 = ADD32(0, 0XC8);
    // 0x8012C7E8: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C7EC: sb          $t1, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r9;
    // 0x8012C7F0: addiu       $v1, $zero, 0x28
    ctx->r3 = ADD32(0, 0X28);
    // 0x8012C7F4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C7F8: sb          $v1, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r3;
    // 0x8012C7FC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C800: sb          $v1, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r3;
    // 0x8012C804: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C808: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C80C: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C810: b           L_8012C968
    // 0x8012C814: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C814: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C818:
    // 0x8012C818: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C81C: sb          $zero, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = 0;
    // 0x8012C820: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C824: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C828: sb          $v0, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r2;
    // 0x8012C82C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C830: sb          $zero, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = 0;
    // 0x8012C834: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C838: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C83C: b           L_8012C968
    // 0x8012C840: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C840: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C844:
    // 0x8012C844: addiu       $v1, $zero, 0x78
    ctx->r3 = ADD32(0, 0X78);
    // 0x8012C848: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C84C: sb          $v1, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r3;
    // 0x8012C850: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C854: sb          $v1, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r3;
    // 0x8012C858: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C85C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C860: sb          $v0, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r2;
    // 0x8012C864: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C868: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C86C: b           L_8012C968
    // 0x8012C870: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C870: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C874:
    // 0x8012C874: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C878: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C87C: sb          $v0, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r2;
    // 0x8012C880: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C884: sb          $v0, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r2;
    // 0x8012C888: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C88C: sb          $zero, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = 0;
    // 0x8012C890: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C894: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C898: b           L_8012C968
    // 0x8012C89C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C89C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C8A0:
    // 0x8012C8A0: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C8A4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8A8: sb          $v0, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r2;
    // 0x8012C8AC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8B0: sb          $v0, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r2;
    // 0x8012C8B4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8B8: sb          $v0, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r2;
    // 0x8012C8BC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8C0: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C8C4: b           L_8012C968
    // 0x8012C8C8: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C8C8: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C8CC:
    // 0x8012C8CC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8D0: sb          $zero, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = 0;
    // 0x8012C8D4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8D8: sb          $zero, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = 0;
    // 0x8012C8DC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8E0: sb          $zero, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = 0;
    // 0x8012C8E4: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C8E8: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C8EC: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C8F0: b           L_8012C968
    // 0x8012C8F4: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C8F4: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C8F8:
    // 0x8012C8F8: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C8FC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C900: sb          $v0, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = ctx->r2;
    // 0x8012C904: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C908: sb          $zero, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = 0;
    // 0x8012C90C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C910: sb          $v0, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r2;
    // 0x8012C914: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C918: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
    // 0x8012C91C: b           L_8012C968
    // 0x8012C920: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C920: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012C924:
    // 0x8012C924: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C928: sb          $zero, -0xE10($at)
    MEM_B(-0XE10, ctx->r1) = 0;
    // 0x8012C92C: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x8012C930: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C934: sb          $v0, -0xE0F($at)
    MEM_B(-0XE0F, ctx->r1) = ctx->r2;
    // 0x8012C938: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C93C: sb          $v0, -0xE0E($at)
    MEM_B(-0XE0E, ctx->r1) = ctx->r2;
    // 0x8012C940: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C944: sb          $v0, -0xE0D($at)
    MEM_B(-0XE0D, ctx->r1) = ctx->r2;
L_8012C948:
    // 0x8012C948: b           L_8012C968
    // 0x8012C94C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_8012C968;
    // 0x8012C94C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
    // 0x8012C950: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
L_8012C954:
    // 0x8012C954: bnel        $v0, $at, L_8012C968
    if (ctx->r2 != ctx->r1) {
        // 0x8012C958: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8012C968;
    }
    goto skip_2;
    // 0x8012C958: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x8012C95C: b           L_8012C968
    // 0x8012C960: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
        goto L_8012C968;
    // 0x8012C960: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
    // 0x8012C964: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8012C968:
    // 0x8012C968: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8012C96C: addiu       $sp, $sp, 0x128
    ctx->r29 = ADD32(ctx->r29, 0X128);
    // 0x8012C970: jr          $ra
    // 0x8012C974: nop

    return;
    // 0x8012C974: nop

;}
RECOMP_FUNC void display_text_centered(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012C978: addiu       $sp, $sp, -0xD0
    ctx->r29 = ADD32(ctx->r29, -0XD0);
    // 0x8012C97C: sdc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X28, ctx->r29);
    // 0x8012C980: lwc1        $f24, 0xE0($sp)
    ctx->f24.u32l = MEM_W(ctx->r29, 0XE0);
    // 0x8012C984: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x8012C988: lui         $s7, 0x8024
    ctx->r23 = S32(0X8024 << 16);
    // 0x8012C98C: lwc1        $f4, 0xE4($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0XE4);
    // 0x8012C990: addiu       $s7, $s7, -0xE08
    ctx->r23 = ADD32(ctx->r23, -0XE08);
    // 0x8012C994: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8012C998: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8012C99C: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8012C9A0: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x8012C9A4: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x8012C9A8: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x8012C9AC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012C9B0: swc1        $f24, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->f24.u32l;
    // 0x8012C9B4: or          $s3, $a1, $zero
    ctx->r19 = ctx->r5 | 0;
    // 0x8012C9B8: andi        $s4, $a2, 0xFFFF
    ctx->r20 = ctx->r6 & 0XFFFF;
    // 0x8012C9BC: andi        $s5, $a3, 0xFFFF
    ctx->r21 = ctx->r7 & 0XFFFF;
    // 0x8012C9C0: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x8012C9C4: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x8012C9C8: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x8012C9CC: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x8012C9D0: sdc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X20, ctx->r29);
    // 0x8012C9D4: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012C9D8: sw          $a2, 0xD8($sp)
    MEM_W(0XD8, ctx->r29) = ctx->r6;
    // 0x8012C9DC: sw          $a3, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->r7;
    // 0x8012C9E0: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    // 0x8012C9E4: jal         0x8012C3D8
    // 0x8012C9E8: swc1        $f4, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f4.u32l;
    get_message_width(rdram, ctx);
        goto after_0;
    // 0x8012C9E8: swc1        $f4, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f4.u32l;
    after_0:
    // 0x8012C9EC: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8012C9F0: lw          $t7, -0xE20($t7)
    ctx->r15 = MEM_W(ctx->r15, -0XE20);
    // 0x8012C9F4: bgez        $v0, L_8012CA04
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8012C9F8: sra         $s2, $v0, 1
        ctx->r18 = S32(SIGNED(ctx->r2) >> 1);
            goto L_8012CA04;
    }
    // 0x8012C9F8: sra         $s2, $v0, 1
    ctx->r18 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8012C9FC: addiu       $at, $v0, 0x1
    ctx->r1 = ADD32(ctx->r2, 0X1);
    // 0x8012CA00: sra         $s2, $at, 1
    ctx->r18 = S32(SIGNED(ctx->r1) >> 1);
L_8012CA04:
    // 0x8012CA04: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x8012CA08: andi        $t6, $s2, 0xFFFF
    ctx->r14 = ctx->r18 & 0XFFFF;
    // 0x8012CA0C: or          $s2, $t6, $zero
    ctx->r18 = ctx->r14 | 0;
    // 0x8012CA10: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x8012CA14: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012CA18: bgez        $t8, L_8012CA2C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8012CA1C: cvt.s.w     $f12, $f6
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8012CA2C;
    }
    // 0x8012CA1C: cvt.s.w     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8012CA20: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012CA24: nop

    // 0x8012CA28: add.s       $f12, $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f8.fl;
L_8012CA2C:
    // 0x8012CA2C: jal         0x8012C314
    // 0x8012CA30: nop

    get_glyph_width(rdram, ctx);
        goto after_1;
    // 0x8012CA30: nop

    after_1:
    // 0x8012CA34: lwc1        $f10, 0x0($s7)
    ctx->f10.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012CA38: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8012CA3C: lbu         $t7, -0xE0C($t7)
    ctx->r15 = MEM_BU(ctx->r15, -0XE0C);
    // 0x8012CA40: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012CA44: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CA48: subu        $t9, $s4, $s2
    ctx->r25 = SUB32(ctx->r20, ctx->r18);
    // 0x8012CA4C: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012CA50: mfc1        $t5, $f16
    ctx->r13 = (int32_t)ctx->f16.u32l;
    // 0x8012CA54: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012CA58: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012CA5C: subu        $t6, $t5, $v0
    ctx->r14 = SUB32(ctx->r13, ctx->r2);
    // 0x8012CA60: multu       $t6, $t7
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012CA64: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012CA68: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012CA6C: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012CA70: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012CA74: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012CA78: or          $t0, $s2, $zero
    ctx->r8 = ctx->r18 | 0;
    // 0x8012CA7C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012CA80: mflo        $a3
    ctx->r7 = lo;
    // 0x8012CA84: andi        $t8, $a3, 0xFFFF
    ctx->r24 = ctx->r7 & 0XFFFF;
    // 0x8012CA88: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8012CA8C: bgez        $a3, L_8012CA9C
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012CA90: sra         $t5, $a3, 1
        ctx->r13 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012CA9C;
    }
    // 0x8012CA90: sra         $t5, $a3, 1
    ctx->r13 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012CA94: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012CA98: sra         $t5, $at, 1
    ctx->r13 = S32(SIGNED(ctx->r1) >> 1);
L_8012CA9C:
    // 0x8012CA9C: addu        $s1, $t9, $t5
    ctx->r17 = ADD32(ctx->r25, ctx->r13);
    // 0x8012CAA0: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012CAA4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012CAA8: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8012CAAC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012CAB0: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CAB4: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x8012CAB8: sra         $s1, $t6, 16
    ctx->r17 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012CABC: lbu         $t6, 0x0($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CAC0: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x8012CAC4: lbu         $t9, 0x0($t3)
    ctx->r25 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CAC8: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012CACC: or          $t6, $t7, $t5
    ctx->r14 = ctx->r15 | ctx->r13;
    // 0x8012CAD0: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x8012CAD4: lbu         $t9, 0x0($t4)
    ctx->r25 = MEM_BU(ctx->r12, 0X0);
    // 0x8012CAD8: or          $t5, $t6, $t7
    ctx->r13 = ctx->r14 | ctx->r15;
    // 0x8012CADC: lui         $t8, 0xFB00
    ctx->r24 = S32(0XFB00 << 16);
    // 0x8012CAE0: or          $t6, $t5, $t9
    ctx->r14 = ctx->r13 | ctx->r25;
    // 0x8012CAE4: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8012CAE8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CAEC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012CAF0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012CAF4: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012CAF8: lbu         $t8, 0x0($t2)
    ctx->r24 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CAFC: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CB00: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x8012CB04: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CB08: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x8012CB0C: or          $t9, $t6, $t5
    ctx->r25 = ctx->r14 | ctx->r13;
    // 0x8012CB10: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x8012CB14: lbu         $t8, 0x0($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X0);
    // 0x8012CB18: or          $t5, $t9, $t6
    ctx->r13 = ctx->r25 | ctx->r14;
    // 0x8012CB1C: or          $t9, $t5, $t8
    ctx->r25 = ctx->r13 | ctx->r24;
    // 0x8012CB20: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8012CB24: jal         0x8012FA78
    // 0x8012CB28: sw          $t0, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r8;
    func_8012FA78(rdram, ctx);
        goto after_2;
    // 0x8012CB28: sw          $t0, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r8;
    after_2:
    // 0x8012CB2C: lh          $t6, 0x0($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X0);
    // 0x8012CB30: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012CB34: andi        $a2, $s5, 0xFFFF
    ctx->r6 = ctx->r21 & 0XFFFF;
    // 0x8012CB38: beq         $t6, $at, L_8012D320
    if (ctx->r14 == ctx->r1) {
        // 0x8012CB3C: lui         $at, 0x4160
        ctx->r1 = S32(0X4160 << 16);
            goto L_8012D320;
    }
    // 0x8012CB3C: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8012CB40: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8012CB44: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012CB48: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012CB4C: sw          $s5, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r21;
    // 0x8012CB50: sw          $a2, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r6;
    // 0x8012CB54: lw          $a2, 0x5C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X5C);
L_8012CB58:
    // 0x8012CB58: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8012CB5C: jal         0x8012C678
    // 0x8012CB60: andi        $a1, $s1, 0xFFFF
    ctx->r5 = ctx->r17 & 0XFFFF;
    func_8012C678(rdram, ctx);
        goto after_3;
    // 0x8012CB60: andi        $a1, $s1, 0xFFFF
    ctx->r5 = ctx->r17 & 0XFFFF;
    after_3:
    // 0x8012CB64: beq         $v0, $zero, L_8012CBBC
    if (ctx->r2 == 0) {
        // 0x8012CB68: lui         $t0, 0x8024
        ctx->r8 = S32(0X8024 << 16);
            goto L_8012CBBC;
    }
    // 0x8012CB68: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012CB6C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012CB70: beq         $v0, $at, L_8012CB94
    if (ctx->r2 == ctx->r1) {
        // 0x8012CB74: lui         $a0, 0x8024
        ctx->r4 = S32(0X8024 << 16);
            goto L_8012CB94;
    }
    // 0x8012CB74: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8012CB78: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012CB7C: beq         $v0, $at, L_8012CBB4
    if (ctx->r2 == ctx->r1) {
        // 0x8012CB80: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8012CBB4;
    }
    // 0x8012CB80: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012CB84: beql        $v0, $at, L_8012D310
    if (ctx->r2 == ctx->r1) {
        // 0x8012CB88: addiu       $s3, $s3, 0x2
        ctx->r19 = ADD32(ctx->r19, 0X2);
            goto L_8012D310;
    }
    goto skip_0;
    // 0x8012CB88: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    skip_0:
    // 0x8012CB8C: b           L_8012D314
    // 0x8012CB90: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
        goto L_8012D314;
    // 0x8012CB90: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
L_8012CB94:
    // 0x8012CB94: addiu       $a0, $a0, -0xDB8
    ctx->r4 = ADD32(ctx->r4, -0XDB8);
    // 0x8012CB98: jal         0x8012C3D8
    // 0x8012CB9C: or          $s2, $s4, $zero
    ctx->r18 = ctx->r20 | 0;
    get_message_width(rdram, ctx);
        goto after_4;
    // 0x8012CB9C: or          $s2, $s4, $zero
    ctx->r18 = ctx->r20 | 0;
    after_4:
    // 0x8012CBA0: addu        $s4, $s2, $v0
    ctx->r20 = ADD32(ctx->r18, ctx->r2);
    // 0x8012CBA4: andi        $t7, $s4, 0xFFFF
    ctx->r15 = ctx->r20 & 0XFFFF;
    // 0x8012CBA8: or          $s4, $t7, $zero
    ctx->r20 = ctx->r15 | 0;
    // 0x8012CBAC: b           L_8012D310
    // 0x8012CBB0: addiu       $s3, $s3, 0x8
    ctx->r19 = ADD32(ctx->r19, 0X8);
        goto L_8012D310;
    // 0x8012CBB0: addiu       $s3, $s3, 0x8
    ctx->r19 = ADD32(ctx->r19, 0X8);
L_8012CBB4:
    // 0x8012CBB4: b           L_8012D310
    // 0x8012CBB8: addiu       $s3, $s3, 0x6
    ctx->r19 = ADD32(ctx->r19, 0X6);
        goto L_8012D310;
    // 0x8012CBB8: addiu       $s3, $s3, 0x6
    ctx->r19 = ADD32(ctx->r19, 0X6);
L_8012CBBC:
    // 0x8012CBBC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CBC0: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012CBC4: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x8012CBC8: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x8012CBCC: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012CBD0: addiu       $t1, $t1, -0xE0F
    ctx->r9 = ADD32(ctx->r9, -0XE0F);
    // 0x8012CBD4: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012CBD8: lbu         $t8, 0x0($t1)
    ctx->r24 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CBDC: addiu       $t0, $t0, -0xE10
    ctx->r8 = ADD32(ctx->r8, -0XE10);
    // 0x8012CBE0: lbu         $t6, 0x0($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X0);
    // 0x8012CBE4: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012CBE8: addiu       $t2, $t2, -0xE0E
    ctx->r10 = ADD32(ctx->r10, -0XE0E);
    // 0x8012CBEC: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8012CBF0: lbu         $t8, 0x0($t2)
    ctx->r24 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CBF4: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012CBF8: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012CBFC: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8012CC00: addiu       $t3, $t3, -0xE0D
    ctx->r11 = ADD32(ctx->r11, -0XE0D);
    // 0x8012CC04: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8012CC08: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CC0C: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8012CC10: lui         $t5, 0xFB00
    ctx->r13 = S32(0XFB00 << 16);
    // 0x8012CC14: or          $t6, $t9, $t8
    ctx->r14 = ctx->r25 | ctx->r24;
    // 0x8012CC18: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8012CC1C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CC20: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8012CC24: addiu       $a3, $a3, -0xE20
    ctx->r7 = ADD32(ctx->r7, -0XE20);
    // 0x8012CC28: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012CC2C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012CC30: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8012CC34: lbu         $t5, 0x0($t1)
    ctx->r13 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CC38: lbu         $t8, 0x0($t0)
    ctx->r24 = MEM_BU(ctx->r8, 0X0);
    // 0x8012CC3C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012CC40: sll         $t9, $t5, 16
    ctx->r25 = S32(ctx->r13 << 16);
    // 0x8012CC44: lbu         $t5, 0x0($t2)
    ctx->r13 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CC48: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8012CC4C: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8012CC50: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x8012CC54: lbu         $t5, 0x0($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CC58: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8012CC5C: or          $s2, $s4, $zero
    ctx->r18 = ctx->r20 | 0;
    // 0x8012CC60: or          $t8, $t9, $t5
    ctx->r24 = ctx->r25 | ctx->r13;
    // 0x8012CC64: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8012CC68: lh          $s6, 0x0($s3)
    ctx->r22 = MEM_H(ctx->r19, 0X0);
    // 0x8012CC6C: lw          $t6, 0x0($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X0);
    // 0x8012CC70: lw          $fp, 0x64($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X64);
    // 0x8012CC74: lw          $t5, 0x74($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X74);
    // 0x8012CC78: sll         $a1, $s6, 16
    ctx->r5 = S32(ctx->r22 << 16);
    // 0x8012CC7C: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8012CC80: addu        $t7, $t6, $s6
    ctx->r15 = ADD32(ctx->r14, ctx->r22);
    // 0x8012CC84: sll         $t8, $fp, 2
    ctx->r24 = S32(ctx->r30 << 2);
    // 0x8012CC88: sw          $t7, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r15;
    // 0x8012CC8C: andi        $fp, $t8, 0xFFF
    ctx->r30 = ctx->r24 & 0XFFF;
    // 0x8012CC90: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x8012CC94: jal         0x8012FB4C
    // 0x8012CC98: subu        $s5, $s4, $t5
    ctx->r21 = SUB32(ctx->r20, ctx->r13);
    load_glyph(rdram, ctx);
        goto after_5;
    // 0x8012CC98: subu        $s5, $s4, $t5
    ctx->r21 = SUB32(ctx->r20, ctx->r13);
    after_5:
    // 0x8012CC9C: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8012CCA0: lw          $t7, -0xE20($t7)
    ctx->r15 = MEM_W(ctx->r15, -0XE20);
    // 0x8012CCA4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012CCA8: lbu         $t9, 0x0($t7)
    ctx->r25 = MEM_BU(ctx->r15, 0X0);
    // 0x8012CCAC: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8012CCB0: bgez        $t9, L_8012CCC4
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8012CCB4: cvt.s.w     $f12, $f18
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
            goto L_8012CCC4;
    }
    // 0x8012CCB4: cvt.s.w     $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8012CCB8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012CCBC: nop

    // 0x8012CCC0: add.s       $f12, $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f4.fl;
L_8012CCC4:
    // 0x8012CCC4: jal         0x8012C314
    // 0x8012CCC8: nop

    get_glyph_width(rdram, ctx);
        goto after_6;
    // 0x8012CCC8: nop

    after_6:
    // 0x8012CCCC: lwc1        $f6, 0x0($s7)
    ctx->f6.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012CCD0: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8012CCD4: lbu         $t7, -0xE0C($t7)
    ctx->r15 = MEM_BU(ctx->r15, -0XE0C);
    // 0x8012CCD8: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8012CCDC: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8012CCE0: lbu         $t5, -0xE0B($t5)
    ctx->r13 = MEM_BU(ctx->r13, -0XE0B);
    // 0x8012CCE4: lw          $t0, 0x64($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X64);
    // 0x8012CCE8: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x8012CCEC: nop

    // 0x8012CCF0: subu        $t6, $t8, $v0
    ctx->r14 = SUB32(ctx->r24, ctx->r2);
    // 0x8012CCF4: multu       $t6, $t7
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012CCF8: mflo        $a3
    ctx->r7 = lo;
    // 0x8012CCFC: andi        $t9, $a3, 0xFFFF
    ctx->r25 = ctx->r7 & 0XFFFF;
    // 0x8012CD00: beq         $t5, $zero, L_8012CFD0
    if (ctx->r13 == 0) {
        // 0x8012CD04: or          $a3, $t9, $zero
        ctx->r7 = ctx->r25 | 0;
            goto L_8012CFD0;
    }
    // 0x8012CD04: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8012CD08: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012CD0C: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x8012CD10: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8012CD14: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x8012CD18: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012CD1C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012CD20: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x8012CD24: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x8012CD28: lui         $t5, 0xFB00
    ctx->r13 = S32(0XFB00 << 16);
    // 0x8012CD2C: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012CD30: addiu       $t9, $a1, 0x8
    ctx->r25 = ADD32(ctx->r5, 0X8);
    // 0x8012CD34: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012CD38: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x8012CD3C: sw          $t5, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r13;
    // 0x8012CD40: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CD44: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012CD48: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012CD4C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012CD50: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012CD54: lwc1        $f10, 0x0($s7)
    ctx->f10.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012CD58: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x8012CD5C: bgez        $a3, L_8012CD6C
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012CD60: sra         $t6, $a3, 1
        ctx->r14 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012CD6C;
    }
    // 0x8012CD60: sra         $t6, $a3, 1
    ctx->r14 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012CD64: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012CD68: sra         $t6, $at, 1
    ctx->r14 = S32(SIGNED(ctx->r1) >> 1);
L_8012CD6C:
    // 0x8012CD6C: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012CD70: addu        $v0, $s5, $t6
    ctx->r2 = ADD32(ctx->r21, ctx->r14);
    // 0x8012CD74: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012CD78: addiu       $t3, $t3, -0xE0D
    ctx->r11 = ADD32(ctx->r11, -0XE0D);
    // 0x8012CD7C: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
    // 0x8012CD80: addiu       $t2, $t2, -0xE0E
    ctx->r10 = ADD32(ctx->r10, -0XE0E);
    // 0x8012CD84: addiu       $t1, $t1, -0xE0F
    ctx->r9 = ADD32(ctx->r9, -0XE0F);
    // 0x8012CD88: addu        $t5, $v0, $t9
    ctx->r13 = ADD32(ctx->r2, ctx->r25);
    // 0x8012CD8C: addiu       $t8, $t5, 0x1
    ctx->r24 = ADD32(ctx->r13, 0X1);
    // 0x8012CD90: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x8012CD94: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x8012CD98: sll         $t9, $t7, 12
    ctx->r25 = S32(ctx->r15 << 12);
    // 0x8012CD9C: or          $t5, $t9, $at
    ctx->r13 = ctx->r25 | ctx->r1;
    // 0x8012CDA0: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012CDA4: lwc1        $f18, -0xE04($at)
    ctx->f18.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012CDA8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012CDAC: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x8012CDB0: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    // 0x8012CDB4: nop

    // 0x8012CDB8: addu        $t7, $t0, $t6
    ctx->r15 = ADD32(ctx->r8, ctx->r14);
    // 0x8012CDBC: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8012CDC0: sll         $t8, $t9, 2
    ctx->r24 = S32(ctx->r25 << 2);
    // 0x8012CDC4: andi        $t6, $t8, 0xFFF
    ctx->r14 = ctx->r24 & 0XFFF;
    // 0x8012CDC8: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x8012CDCC: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x8012CDD0: sll         $t8, $t9, 2
    ctx->r24 = S32(ctx->r25 << 2);
    // 0x8012CDD4: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x8012CDD8: addiu       $t7, $t0, 0x1
    ctx->r15 = ADD32(ctx->r8, 0X1);
    // 0x8012CDDC: andi        $t5, $t8, 0xFFF
    ctx->r13 = ctx->r24 & 0XFFF;
    // 0x8012CDE0: sll         $t9, $t7, 2
    ctx->r25 = S32(ctx->r15 << 2);
    // 0x8012CDE4: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x8012CDE8: sll         $t6, $t5, 12
    ctx->r14 = S32(ctx->r13 << 12);
    // 0x8012CDEC: or          $t5, $t6, $t8
    ctx->r13 = ctx->r14 | ctx->r24;
    // 0x8012CDF0: sw          $t5, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r13;
    // 0x8012CDF4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CDF8: lui         $t9, 0xB400
    ctx->r25 = S32(0XB400 << 16);
    // 0x8012CDFC: lui         $t8, 0xB300
    ctx->r24 = S32(0XB300 << 16);
    // 0x8012CE00: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012CE04: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012CE08: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012CE0C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012CE10: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012CE14: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012CE18: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012CE1C: addiu       $t6, $a0, 0x8
    ctx->r14 = ADD32(ctx->r4, 0X8);
    // 0x8012CE20: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012CE24: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012CE28: lwc1        $f6, 0x0($s7)
    ctx->f6.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012CE2C: addiu       $t0, $t0, -0xE10
    ctx->r8 = ADD32(ctx->r8, -0XE10);
    // 0x8012CE30: div.s       $f8, $f20, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f20.fl, ctx->f6.fl);
    // 0x8012CE34: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012CE38: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012CE3C: nop

    // 0x8012CE40: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012CE44: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012CE48: nop

    // 0x8012CE4C: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012CE50: beql        $t7, $zero, L_8012CEA0
    if (ctx->r15 == 0) {
        // 0x8012CE54: mfc1        $t7, $f10
        ctx->r15 = (int32_t)ctx->f10.u32l;
            goto L_8012CEA0;
    }
    goto skip_1;
    // 0x8012CE54: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    skip_1:
    // 0x8012CE58: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012CE5C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012CE60: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x8012CE64: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012CE68: nop

    // 0x8012CE6C: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012CE70: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012CE74: nop

    // 0x8012CE78: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012CE7C: bne         $t7, $zero, L_8012CE94
    if (ctx->r15 != 0) {
        // 0x8012CE80: nop
    
            goto L_8012CE94;
    }
    // 0x8012CE80: nop

    // 0x8012CE84: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x8012CE88: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012CE8C: b           L_8012CEAC
    // 0x8012CE90: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012CEAC;
    // 0x8012CE90: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012CE94:
    // 0x8012CE94: b           L_8012CEAC
    // 0x8012CE98: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012CEAC;
    // 0x8012CE98: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012CE9C: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
L_8012CEA0:
    // 0x8012CEA0: nop

    // 0x8012CEA4: bltz        $t7, L_8012CE94
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012CEA8: nop
    
            goto L_8012CE94;
    }
    // 0x8012CEA8: nop

L_8012CEAC:
    // 0x8012CEAC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012CEB0: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012CEB4: lwc1        $f16, -0xE04($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012CEB8: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8012CEBC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012CEC0: div.s       $f18, $f20, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f20.fl, ctx->f16.fl);
    // 0x8012CEC4: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x8012CEC8: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012CECC: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012CED0: nop

    // 0x8012CED4: cvt.w.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012CED8: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012CEDC: nop

    // 0x8012CEE0: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x8012CEE4: beql        $t5, $zero, L_8012CF34
    if (ctx->r13 == 0) {
        // 0x8012CEE8: mfc1        $t5, $f4
        ctx->r13 = (int32_t)ctx->f4.u32l;
            goto L_8012CF34;
    }
    goto skip_2;
    // 0x8012CEE8: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    skip_2:
    // 0x8012CEEC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012CEF0: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8012CEF4: sub.s       $f4, $f18, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x8012CEF8: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012CEFC: nop

    // 0x8012CF00: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012CF04: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012CF08: nop

    // 0x8012CF0C: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x8012CF10: bne         $t5, $zero, L_8012CF28
    if (ctx->r13 != 0) {
        // 0x8012CF14: nop
    
            goto L_8012CF28;
    }
    // 0x8012CF14: nop

    // 0x8012CF18: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    // 0x8012CF1C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012CF20: b           L_8012CF40
    // 0x8012CF24: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
        goto L_8012CF40;
    // 0x8012CF24: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
L_8012CF28:
    // 0x8012CF28: b           L_8012CF40
    // 0x8012CF2C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
        goto L_8012CF40;
    // 0x8012CF2C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x8012CF30: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
L_8012CF34:
    // 0x8012CF34: nop

    // 0x8012CF38: bltz        $t5, L_8012CF28
    if (SIGNED(ctx->r13) < 0) {
        // 0x8012CF3C: nop
    
            goto L_8012CF28;
    }
    // 0x8012CF3C: nop

L_8012CF40:
    // 0x8012CF40: andi        $t7, $t5, 0xFFFF
    ctx->r15 = ctx->r13 & 0XFFFF;
    // 0x8012CF44: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8012CF48: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x8012CF4C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CF50: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012CF54: lui         $t5, 0xFA00
    ctx->r13 = S32(0XFA00 << 16);
    // 0x8012CF58: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012CF5C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012CF60: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8012CF64: lbu         $t5, 0x0($t1)
    ctx->r13 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CF68: lbu         $t7, 0x0($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X0);
    // 0x8012CF6C: lui         $t8, 0xFB00
    ctx->r24 = S32(0XFB00 << 16);
    // 0x8012CF70: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8012CF74: lbu         $t5, 0x0($t2)
    ctx->r13 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CF78: sll         $t9, $t7, 24
    ctx->r25 = S32(ctx->r15 << 24);
    // 0x8012CF7C: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8012CF80: sll         $t9, $t5, 8
    ctx->r25 = S32(ctx->r13 << 8);
    // 0x8012CF84: lbu         $t5, 0x0($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CF88: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8012CF8C: or          $t7, $t6, $t5
    ctx->r15 = ctx->r14 | ctx->r13;
    // 0x8012CF90: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8012CF94: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CF98: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012CF9C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012CFA0: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012CFA4: lbu         $t8, 0x0($t1)
    ctx->r24 = MEM_BU(ctx->r9, 0X0);
    // 0x8012CFA8: lbu         $t5, 0x0($t0)
    ctx->r13 = MEM_BU(ctx->r8, 0X0);
    // 0x8012CFAC: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x8012CFB0: lbu         $t8, 0x0($t2)
    ctx->r24 = MEM_BU(ctx->r10, 0X0);
    // 0x8012CFB4: sll         $t7, $t5, 24
    ctx->r15 = S32(ctx->r13 << 24);
    // 0x8012CFB8: or          $t5, $t7, $t6
    ctx->r13 = ctx->r15 | ctx->r14;
    // 0x8012CFBC: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8012CFC0: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012CFC4: or          $t6, $t5, $t7
    ctx->r14 = ctx->r13 | ctx->r15;
    // 0x8012CFC8: or          $t5, $t6, $t8
    ctx->r13 = ctx->r14 | ctx->r24;
    // 0x8012CFCC: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
L_8012CFD0:
    // 0x8012CFD0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012CFD4: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x8012CFD8: addiu       $a2, $a2, -0xE04
    ctx->r6 = ADD32(ctx->r6, -0XE04);
    // 0x8012CFDC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012CFE0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012CFE4: lwc1        $f6, 0x0($a2)
    ctx->f6.u32l = MEM_W(ctx->r6, 0X0);
    // 0x8012CFE8: lwc1        $f10, 0x0($s7)
    ctx->f10.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012CFEC: lw          $t9, 0x64($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X64);
    // 0x8012CFF0: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8012CFF4: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x8012CFF8: bgez        $a3, L_8012D008
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012CFFC: sra         $s1, $a3, 1
        ctx->r17 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012D008;
    }
    // 0x8012CFFC: sra         $s1, $a3, 1
    ctx->r17 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012D000: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012D004: sra         $s1, $at, 1
    ctx->r17 = S32(SIGNED(ctx->r1) >> 1);
L_8012D008:
    // 0x8012D008: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012D00C: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x8012D010: addu        $v0, $s5, $s1
    ctx->r2 = ADD32(ctx->r21, ctx->r17);
    // 0x8012D014: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012D018: addu        $t5, $t9, $t8
    ctx->r13 = ADD32(ctx->r25, ctx->r24);
    // 0x8012D01C: mfc1        $t8, $f16
    ctx->r24 = (int32_t)ctx->f16.u32l;
    // 0x8012D020: sll         $t7, $t5, 2
    ctx->r15 = S32(ctx->r13 << 2);
    // 0x8012D024: andi        $t6, $t7, 0xFFF
    ctx->r14 = ctx->r15 & 0XFFF;
    // 0x8012D028: addu        $t5, $v0, $t8
    ctx->r13 = ADD32(ctx->r2, ctx->r24);
    // 0x8012D02C: sll         $t7, $t5, 2
    ctx->r15 = S32(ctx->r13 << 2);
    // 0x8012D030: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x8012D034: sll         $t8, $t9, 12
    ctx->r24 = S32(ctx->r25 << 12);
    // 0x8012D038: or          $t5, $t8, $at
    ctx->r13 = ctx->r24 | ctx->r1;
    // 0x8012D03C: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x8012D040: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x8012D044: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x8012D048: sll         $t5, $t8, 12
    ctx->r13 = S32(ctx->r24 << 12);
    // 0x8012D04C: or          $t6, $t5, $fp
    ctx->r14 = ctx->r13 | ctx->r30;
    // 0x8012D050: sw          $t6, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r14;
    // 0x8012D054: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012D058: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012D05C: lui         $t9, 0xB400
    ctx->r25 = S32(0XB400 << 16);
    // 0x8012D060: lui         $t5, 0xB300
    ctx->r13 = S32(0XB300 << 16);
    // 0x8012D064: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012D068: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012D06C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012D070: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012D074: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012D078: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D07C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D080: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x8012D084: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012D088: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012D08C: lwc1        $f18, 0x0($s7)
    ctx->f18.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D090: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x8012D094: div.s       $f4, $f20, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f20.fl, ctx->f18.fl);
    // 0x8012D098: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012D09C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D0A0: nop

    // 0x8012D0A4: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012D0A8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D0AC: nop

    // 0x8012D0B0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012D0B4: beql        $t7, $zero, L_8012D104
    if (ctx->r15 == 0) {
        // 0x8012D0B8: mfc1        $t7, $f6
        ctx->r15 = (int32_t)ctx->f6.u32l;
            goto L_8012D104;
    }
    goto skip_3;
    // 0x8012D0B8: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    skip_3:
    // 0x8012D0BC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012D0C0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D0C4: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x8012D0C8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D0CC: nop

    // 0x8012D0D0: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012D0D4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D0D8: nop

    // 0x8012D0DC: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012D0E0: bne         $t7, $zero, L_8012D0F8
    if (ctx->r15 != 0) {
        // 0x8012D0E4: nop
    
            goto L_8012D0F8;
    }
    // 0x8012D0E4: nop

    // 0x8012D0E8: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8012D0EC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012D0F0: b           L_8012D110
    // 0x8012D0F4: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012D110;
    // 0x8012D0F4: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012D0F8:
    // 0x8012D0F8: b           L_8012D110
    // 0x8012D0FC: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012D110;
    // 0x8012D0FC: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012D100: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
L_8012D104:
    // 0x8012D104: nop

    // 0x8012D108: bltz        $t7, L_8012D0F8
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012D10C: nop
    
            goto L_8012D0F8;
    }
    // 0x8012D10C: nop

L_8012D110:
    // 0x8012D110: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012D114: lwc1        $f8, 0x0($a2)
    ctx->f8.u32l = MEM_W(ctx->r6, 0X0);
    // 0x8012D118: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012D11C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8012D120: div.s       $f10, $f20, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f20.fl, ctx->f8.fl);
    // 0x8012D124: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D128: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012D12C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012D130: nop

    // 0x8012D134: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012D138: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012D13C: nop

    // 0x8012D140: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012D144: beql        $t6, $zero, L_8012D194
    if (ctx->r14 == 0) {
        // 0x8012D148: mfc1        $t6, $f16
        ctx->r14 = (int32_t)ctx->f16.u32l;
            goto L_8012D194;
    }
    goto skip_4;
    // 0x8012D148: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    skip_4:
    // 0x8012D14C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8012D150: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012D154: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x8012D158: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012D15C: nop

    // 0x8012D160: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012D164: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012D168: nop

    // 0x8012D16C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012D170: bne         $t6, $zero, L_8012D188
    if (ctx->r14 != 0) {
        // 0x8012D174: nop
    
            goto L_8012D188;
    }
    // 0x8012D174: nop

    // 0x8012D178: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    // 0x8012D17C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012D180: b           L_8012D1A0
    // 0x8012D184: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_8012D1A0;
    // 0x8012D184: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_8012D188:
    // 0x8012D188: b           L_8012D1A0
    // 0x8012D18C: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_8012D1A0;
    // 0x8012D18C: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8012D190: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
L_8012D194:
    // 0x8012D194: nop

    // 0x8012D198: bltz        $t6, L_8012D188
    if (SIGNED(ctx->r14) < 0) {
        // 0x8012D19C: nop
    
            goto L_8012D188;
    }
    // 0x8012D19C: nop

L_8012D1A0:
    // 0x8012D1A0: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x8012D1A4: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012D1A8: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x8012D1AC: lbu         $a1, -0xE0C($a1)
    ctx->r5 = MEM_BU(ctx->r5, -0XE0C);
    // 0x8012D1B0: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012D1B4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012D1B8: beq         $a1, $zero, L_8012D1D0
    if (ctx->r5 == 0) {
        // 0x8012D1BC: lui         $t5, 0x8024
        ctx->r13 = S32(0X8024 << 16);
            goto L_8012D1D0;
    }
    // 0x8012D1BC: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8012D1C0: beq         $a1, $at, L_8012D22C
    if (ctx->r5 == ctx->r1) {
        // 0x8012D1C4: lw          $t7, 0x74($sp)
        ctx->r15 = MEM_W(ctx->r29, 0X74);
            goto L_8012D22C;
    }
    // 0x8012D1C4: lw          $t7, 0x74($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X74);
    // 0x8012D1C8: b           L_8012D2E4
    // 0x8012D1CC: nop

        goto L_8012D2E4;
    // 0x8012D1CC: nop

L_8012D1D0:
    // 0x8012D1D0: lw          $t5, -0xE20($t5)
    ctx->r13 = MEM_W(ctx->r13, -0XE20);
    // 0x8012D1D4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012D1D8: lbu         $t6, 0x0($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X0);
    // 0x8012D1DC: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x8012D1E0: bgez        $t6, L_8012D1F4
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012D1E4: cvt.s.w     $f12, $f18
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
            goto L_8012D1F4;
    }
    // 0x8012D1E4: cvt.s.w     $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8012D1E8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012D1EC: nop

    // 0x8012D1F0: add.s       $f12, $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f4.fl;
L_8012D1F4:
    // 0x8012D1F4: jal         0x8012C314
    // 0x8012D1F8: nop

    get_glyph_width(rdram, ctx);
        goto after_7;
    // 0x8012D1F8: nop

    after_7:
    // 0x8012D1FC: c.lt.s      $f24, $f22
    CHECK_FR(ctx, 24);
    CHECK_FR(ctx, 22);
    c1cs = ctx->f24.fl < ctx->f22.fl;
    // 0x8012D200: addu        $s4, $s2, $v0
    ctx->r20 = ADD32(ctx->r18, ctx->r2);
    // 0x8012D204: andi        $t8, $s4, 0xFFFF
    ctx->r24 = ctx->r20 & 0XFFFF;
    // 0x8012D208: or          $s4, $t8, $zero
    ctx->r20 = ctx->r24 | 0;
    // 0x8012D20C: bc1f        L_8012D220
    if (!c1cs) {
        // 0x8012D210: lw          $t9, 0x74($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X74);
            goto L_8012D220;
    }
    // 0x8012D210: lw          $t9, 0x74($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X74);
    // 0x8012D214: addiu       $s4, $t8, 0x1
    ctx->r20 = ADD32(ctx->r24, 0X1);
    // 0x8012D218: andi        $t7, $s4, 0xFFFF
    ctx->r15 = ctx->r20 & 0XFFFF;
    // 0x8012D21C: or          $s4, $t7, $zero
    ctx->r20 = ctx->r15 | 0;
L_8012D220:
    // 0x8012D220: subu        $t5, $s4, $t9
    ctx->r13 = SUB32(ctx->r20, ctx->r25);
    // 0x8012D224: b           L_8012D2E4
    // 0x8012D228: addu        $v0, $t5, $s1
    ctx->r2 = ADD32(ctx->r13, ctx->r17);
        goto L_8012D2E4;
    // 0x8012D228: addu        $v0, $t5, $s1
    ctx->r2 = ADD32(ctx->r13, ctx->r17);
L_8012D22C:
    // 0x8012D22C: mtc1        $s4, $f6
    ctx->f6.u32l = ctx->r20;
    // 0x8012D230: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012D234: bgez        $s4, L_8012D248
    if (SIGNED(ctx->r20) >= 0) {
        // 0x8012D238: cvt.s.w     $f8, $f6
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8012D248;
    }
    // 0x8012D238: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8012D23C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012D240: nop

    // 0x8012D244: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_8012D248:
    // 0x8012D248: lwc1        $f16, 0x0($s7)
    ctx->f16.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D24C: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8012D250: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D254: add.s       $f18, $f8, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f8.fl + ctx->f16.fl;
    // 0x8012D258: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012D25C: ctc1        $s4, $FpcCsr
    set_cop1_cs(ctx->r20);
    // 0x8012D260: nop

    // 0x8012D264: cvt.w.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012D268: cfc1        $s4, $FpcCsr
    ctx->r20 = get_cop1_cs();
    // 0x8012D26C: nop

    // 0x8012D270: andi        $s4, $s4, 0x78
    ctx->r20 = ctx->r20 & 0X78;
    // 0x8012D274: beql        $s4, $zero, L_8012D2C4
    if (ctx->r20 == 0) {
        // 0x8012D278: mfc1        $s4, $f4
        ctx->r20 = (int32_t)ctx->f4.u32l;
            goto L_8012D2C4;
    }
    goto skip_5;
    // 0x8012D278: mfc1        $s4, $f4
    ctx->r20 = (int32_t)ctx->f4.u32l;
    skip_5:
    // 0x8012D27C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012D280: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8012D284: sub.s       $f4, $f18, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x8012D288: ctc1        $s4, $FpcCsr
    set_cop1_cs(ctx->r20);
    // 0x8012D28C: nop

    // 0x8012D290: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012D294: cfc1        $s4, $FpcCsr
    ctx->r20 = get_cop1_cs();
    // 0x8012D298: nop

    // 0x8012D29C: andi        $s4, $s4, 0x78
    ctx->r20 = ctx->r20 & 0X78;
    // 0x8012D2A0: bne         $s4, $zero, L_8012D2B8
    if (ctx->r20 != 0) {
        // 0x8012D2A4: nop
    
            goto L_8012D2B8;
    }
    // 0x8012D2A4: nop

    // 0x8012D2A8: mfc1        $s4, $f4
    ctx->r20 = (int32_t)ctx->f4.u32l;
    // 0x8012D2AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012D2B0: b           L_8012D2D0
    // 0x8012D2B4: or          $s4, $s4, $at
    ctx->r20 = ctx->r20 | ctx->r1;
        goto L_8012D2D0;
    // 0x8012D2B4: or          $s4, $s4, $at
    ctx->r20 = ctx->r20 | ctx->r1;
L_8012D2B8:
    // 0x8012D2B8: b           L_8012D2D0
    // 0x8012D2BC: addiu       $s4, $zero, -0x1
    ctx->r20 = ADD32(0, -0X1);
        goto L_8012D2D0;
    // 0x8012D2BC: addiu       $s4, $zero, -0x1
    ctx->r20 = ADD32(0, -0X1);
    // 0x8012D2C0: mfc1        $s4, $f4
    ctx->r20 = (int32_t)ctx->f4.u32l;
L_8012D2C4:
    // 0x8012D2C4: nop

    // 0x8012D2C8: bltz        $s4, L_8012D2B8
    if (SIGNED(ctx->r20) < 0) {
        // 0x8012D2CC: nop
    
            goto L_8012D2B8;
    }
    // 0x8012D2CC: nop

L_8012D2D0:
    // 0x8012D2D0: andi        $t8, $s4, 0xFFFF
    ctx->r24 = ctx->r20 & 0XFFFF;
    // 0x8012D2D4: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012D2D8: subu        $t9, $t8, $t7
    ctx->r25 = SUB32(ctx->r24, ctx->r15);
    // 0x8012D2DC: or          $s4, $t8, $zero
    ctx->r20 = ctx->r24 | 0;
    // 0x8012D2E0: addu        $v0, $t9, $s1
    ctx->r2 = ADD32(ctx->r25, ctx->r17);
L_8012D2E4:
    // 0x8012D2E4: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8012D2E8: lw          $t6, -0xE20($t6)
    ctx->r14 = MEM_W(ctx->r14, -0XE20);
    // 0x8012D2EC: sll         $s1, $v0, 16
    ctx->r17 = S32(ctx->r2 << 16);
    // 0x8012D2F0: sra         $t5, $s1, 16
    ctx->r13 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8012D2F4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012D2F8: subu        $t8, $t6, $s6
    ctx->r24 = SUB32(ctx->r14, ctx->r22);
    // 0x8012D2FC: or          $s1, $t5, $zero
    ctx->r17 = ctx->r13 | 0;
    // 0x8012D300: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012D304: b           L_8012D310
    // 0x8012D308: sw          $t8, -0xE20($at)
    MEM_W(-0XE20, ctx->r1) = ctx->r24;
        goto L_8012D310;
    // 0x8012D308: sw          $t8, -0xE20($at)
    MEM_W(-0XE20, ctx->r1) = ctx->r24;
    // 0x8012D30C: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
L_8012D310:
    // 0x8012D310: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
L_8012D314:
    // 0x8012D314: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012D318: bnel        $t7, $at, L_8012CB58
    if (ctx->r15 != ctx->r1) {
        // 0x8012D31C: lw          $a2, 0x5C($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X5C);
            goto L_8012CB58;
    }
    goto skip_6;
    // 0x8012D31C: lw          $a2, 0x5C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X5C);
    skip_6:
L_8012D320:
    // 0x8012D320: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012D324: lui         $t5, 0xE700
    ctx->r13 = S32(0XE700 << 16);
    // 0x8012D328: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012D32C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012D330: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012D334: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8012D338: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x8012D33C: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x8012D340: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x8012D344: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x8012D348: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x8012D34C: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x8012D350: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x8012D354: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x8012D358: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x8012D35C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8012D360: ldc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X28);
    // 0x8012D364: ldc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X20);
    // 0x8012D368: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x8012D36C: jr          $ra
    // 0x8012D370: addiu       $sp, $sp, 0xD0
    ctx->r29 = ADD32(ctx->r29, 0XD0);
    return;
    // 0x8012D370: addiu       $sp, $sp, 0xD0
    ctx->r29 = ADD32(ctx->r29, 0XD0);
;}
RECOMP_FUNC void func_8012D374(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012D374: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x8012D378: lwc1        $f4, 0x58($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X58);
    // 0x8012D37C: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x8012D380: lwc1        $f6, 0x5C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X5C);
    // 0x8012D384: lui         $s7, 0x8024
    ctx->r23 = S32(0X8024 << 16);
    // 0x8012D388: addiu       $s7, $s7, -0xE08
    ctx->r23 = ADD32(ctx->r23, -0XE08);
    // 0x8012D38C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012D390: swc1        $f4, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->f4.u32l;
    // 0x8012D394: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8012D398: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x8012D39C: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x8012D3A0: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x8012D3A4: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x8012D3A8: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x8012D3AC: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8012D3B0: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x8012D3B4: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x8012D3B8: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012D3BC: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x8012D3C0: sw          $a3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r7;
    // 0x8012D3C4: swc1        $f6, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f6.u32l;
    // 0x8012D3C8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012D3CC: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012D3D0: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8012D3D4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012D3D8: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012D3DC: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012D3E0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012D3E4: lbu         $t7, 0x0($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X0);
    // 0x8012D3E8: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012D3EC: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012D3F0: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012D3F4: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012D3F8: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012D3FC: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8012D400: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012D404: sll         $t5, $t9, 24
    ctx->r13 = S32(ctx->r25 << 24);
    // 0x8012D408: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012D40C: or          $t9, $t5, $t8
    ctx->r25 = ctx->r13 | ctx->r24;
    // 0x8012D410: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012D414: sll         $t5, $t7, 8
    ctx->r13 = S32(ctx->r15 << 8);
    // 0x8012D418: lbu         $t7, 0x0($t4)
    ctx->r15 = MEM_BU(ctx->r12, 0X0);
    // 0x8012D41C: or          $t8, $t9, $t5
    ctx->r24 = ctx->r25 | ctx->r13;
    // 0x8012D420: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012D424: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012D428: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012D42C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012D430: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8012D434: andi        $s4, $a2, 0xFFFF
    ctx->r20 = ctx->r6 & 0XFFFF;
    // 0x8012D438: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012D43C: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012D440: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012D444: lbu         $t6, 0x0($t2)
    ctx->r14 = MEM_BU(ctx->r10, 0X0);
    // 0x8012D448: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x8012D44C: or          $s5, $a1, $zero
    ctx->r21 = ctx->r5 | 0;
    // 0x8012D450: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8012D454: lbu         $t6, 0x0($t3)
    ctx->r14 = MEM_BU(ctx->r11, 0X0);
    // 0x8012D458: sll         $t9, $t7, 24
    ctx->r25 = S32(ctx->r15 << 24);
    // 0x8012D45C: or          $t7, $t9, $t8
    ctx->r15 = ctx->r25 | ctx->r24;
    // 0x8012D460: sll         $t9, $t6, 8
    ctx->r25 = S32(ctx->r14 << 8);
    // 0x8012D464: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012D468: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8012D46C: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x8012D470: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8012D474: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012D478: lw          $t9, -0xE20($t9)
    ctx->r25 = MEM_W(ctx->r25, -0XE20);
    // 0x8012D47C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012D480: lbu         $t5, 0x0($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X0);
    // 0x8012D484: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x8012D488: bgez        $t5, L_8012D49C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8012D48C: cvt.s.w     $f12, $f8
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
            goto L_8012D49C;
    }
    // 0x8012D48C: cvt.s.w     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8012D490: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012D494: nop

    // 0x8012D498: add.s       $f12, $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f10.fl;
L_8012D49C:
    // 0x8012D49C: jal         0x8012C314
    // 0x8012D4A0: nop

    get_glyph_width(rdram, ctx);
        goto after_0;
    // 0x8012D4A0: nop

    after_0:
    // 0x8012D4A4: lwc1        $f16, 0x0($s7)
    ctx->f16.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D4A8: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x8012D4AC: lbu         $t9, -0xE0C($t9)
    ctx->r25 = MEM_BU(ctx->r25, -0XE0C);
    // 0x8012D4B0: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012D4B4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012D4B8: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x8012D4BC: nop

    // 0x8012D4C0: subu        $t7, $t6, $v0
    ctx->r15 = SUB32(ctx->r14, ctx->r2);
    // 0x8012D4C4: multu       $t7, $t9
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012D4C8: mflo        $a3
    ctx->r7 = lo;
    // 0x8012D4CC: andi        $t5, $a3, 0xFFFF
    ctx->r13 = ctx->r7 & 0XFFFF;
    // 0x8012D4D0: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x8012D4D4: bgez        $a3, L_8012D4E4
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012D4D8: sra         $fp, $a3, 1
        ctx->r30 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012D4E4;
    }
    // 0x8012D4D8: sra         $fp, $a3, 1
    ctx->r30 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012D4DC: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012D4E0: sra         $fp, $at, 1
    ctx->r30 = S32(SIGNED(ctx->r1) >> 1);
L_8012D4E4:
    // 0x8012D4E4: addu        $s2, $s4, $fp
    ctx->r18 = ADD32(ctx->r20, ctx->r30);
    // 0x8012D4E8: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x8012D4EC: jal         0x8012FA78
    // 0x8012D4F0: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    func_8012FA78(rdram, ctx);
        goto after_1;
    // 0x8012D4F0: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    after_1:
    // 0x8012D4F4: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
    // 0x8012D4F8: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012D4FC: lh          $t9, 0x62($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X62);
    // 0x8012D500: beql        $t7, $at, L_8012DC60
    if (ctx->r15 == ctx->r1) {
        // 0x8012D504: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8012DC60;
    }
    goto skip_0;
    // 0x8012D504: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_0:
    // 0x8012D508: beq         $t9, $zero, L_8012DC5C
    if (ctx->r25 == 0) {
        // 0x8012D50C: lui         $at, 0x4680
        ctx->r1 = S32(0X4680 << 16);
            goto L_8012DC5C;
    }
    // 0x8012D50C: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012D510: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012D514: nop

    // 0x8012D518: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_8012D51C:
    // 0x8012D51C: andi        $a1, $s2, 0xFFFF
    ctx->r5 = ctx->r18 & 0XFFFF;
    // 0x8012D520: jal         0x8012C678
    // 0x8012D524: lhu         $a2, 0x56($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X56);
    func_8012C678(rdram, ctx);
        goto after_2;
    // 0x8012D524: lhu         $a2, 0x56($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X56);
    after_2:
    // 0x8012D528: beq         $v0, $zero, L_8012D580
    if (ctx->r2 == 0) {
        // 0x8012D52C: lh          $t8, 0x62($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X62);
            goto L_8012D580;
    }
    // 0x8012D52C: lh          $t8, 0x62($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X62);
    // 0x8012D530: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012D534: beq         $v0, $at, L_8012D558
    if (ctx->r2 == ctx->r1) {
        // 0x8012D538: lui         $a0, 0x8024
        ctx->r4 = S32(0X8024 << 16);
            goto L_8012D558;
    }
    // 0x8012D538: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8012D53C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012D540: beq         $v0, $at, L_8012D578
    if (ctx->r2 == ctx->r1) {
        // 0x8012D544: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8012D578;
    }
    // 0x8012D544: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012D548: beql        $v0, $at, L_8012DC40
    if (ctx->r2 == ctx->r1) {
        // 0x8012D54C: addiu       $s5, $s5, 0x2
        ctx->r21 = ADD32(ctx->r21, 0X2);
            goto L_8012DC40;
    }
    goto skip_1;
    // 0x8012D54C: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    skip_1:
    // 0x8012D550: b           L_8012DC44
    // 0x8012D554: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
        goto L_8012DC44;
    // 0x8012D554: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
L_8012D558:
    // 0x8012D558: addiu       $a0, $a0, -0xDB8
    ctx->r4 = ADD32(ctx->r4, -0XDB8);
    // 0x8012D55C: jal         0x8012C3D8
    // 0x8012D560: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    get_message_width(rdram, ctx);
        goto after_3;
    // 0x8012D560: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    after_3:
    // 0x8012D564: addu        $s4, $s1, $v0
    ctx->r20 = ADD32(ctx->r17, ctx->r2);
    // 0x8012D568: andi        $t5, $s4, 0xFFFF
    ctx->r13 = ctx->r20 & 0XFFFF;
    // 0x8012D56C: or          $s4, $t5, $zero
    ctx->r20 = ctx->r13 | 0;
    // 0x8012D570: b           L_8012DC40
    // 0x8012D574: addiu       $s5, $s5, 0x8
    ctx->r21 = ADD32(ctx->r21, 0X8);
        goto L_8012DC40;
    // 0x8012D574: addiu       $s5, $s5, 0x8
    ctx->r21 = ADD32(ctx->r21, 0X8);
L_8012D578:
    // 0x8012D578: b           L_8012DC40
    // 0x8012D57C: addiu       $s5, $s5, 0x6
    ctx->r21 = ADD32(ctx->r21, 0X6);
        goto L_8012DC40;
    // 0x8012D57C: addiu       $s5, $s5, 0x6
    ctx->r21 = ADD32(ctx->r21, 0X6);
L_8012D580:
    // 0x8012D580: blez        $t8, L_8012D58C
    if (SIGNED(ctx->r24) <= 0) {
        // 0x8012D584: addiu       $t6, $t8, -0x1
        ctx->r14 = ADD32(ctx->r24, -0X1);
            goto L_8012D58C;
    }
    // 0x8012D584: addiu       $t6, $t8, -0x1
    ctx->r14 = ADD32(ctx->r24, -0X1);
    // 0x8012D588: sh          $t6, 0x62($sp)
    MEM_H(0X62, ctx->r29) = ctx->r14;
L_8012D58C:
    // 0x8012D58C: lh          $s3, 0x0($s5)
    ctx->r19 = MEM_H(ctx->r21, 0X0);
    // 0x8012D590: addiu       $at, $zero, 0x130
    ctx->r1 = ADD32(0, 0X130);
    // 0x8012D594: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012D598: beq         $s3, $at, L_8012DAD4
    if (ctx->r19 == ctx->r1) {
        // 0x8012D59C: sll         $a1, $s3, 16
        ctx->r5 = S32(ctx->r19 << 16);
            goto L_8012DAD4;
    }
    // 0x8012D59C: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x8012D5A0: lhu         $s2, 0x56($sp)
    ctx->r18 = MEM_HU(ctx->r29, 0X56);
    // 0x8012D5A4: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8012D5A8: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x8012D5AC: sll         $s6, $s2, 2
    ctx->r22 = S32(ctx->r18 << 2);
    // 0x8012D5B0: andi        $t9, $s6, 0xFFF
    ctx->r25 = ctx->r22 & 0XFFF;
    // 0x8012D5B4: or          $s6, $t9, $zero
    ctx->r22 = ctx->r25 | 0;
    // 0x8012D5B8: jal         0x8012FB4C
    // 0x8012D5BC: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    load_glyph(rdram, ctx);
        goto after_4;
    // 0x8012D5BC: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    after_4:
    // 0x8012D5C0: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8012D5C4: lw          $t5, -0xE20($t5)
    ctx->r13 = MEM_W(ctx->r13, -0XE20);
    // 0x8012D5C8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012D5CC: addu        $t8, $s3, $t5
    ctx->r24 = ADD32(ctx->r19, ctx->r13);
    // 0x8012D5D0: lbu         $t6, 0x0($t8)
    ctx->r14 = MEM_BU(ctx->r24, 0X0);
    // 0x8012D5D4: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8012D5D8: bgez        $t6, L_8012D5EC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012D5DC: cvt.s.w     $f12, $f4
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8012D5EC;
    }
    // 0x8012D5DC: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012D5E0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012D5E4: nop

    // 0x8012D5E8: add.s       $f12, $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f6.fl;
L_8012D5EC:
    // 0x8012D5EC: jal         0x8012C314
    // 0x8012D5F0: nop

    get_glyph_width(rdram, ctx);
        goto after_5;
    // 0x8012D5F0: nop

    after_5:
    // 0x8012D5F4: lwc1        $f8, 0x0($s7)
    ctx->f8.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D5F8: lui         $t8, 0x8024
    ctx->r24 = S32(0X8024 << 16);
    // 0x8012D5FC: lbu         $t8, -0xE0C($t8)
    ctx->r24 = MEM_BU(ctx->r24, -0XE0C);
    // 0x8012D600: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012D604: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8012D608: lbu         $t7, -0xE0B($t7)
    ctx->r15 = MEM_BU(ctx->r15, -0XE0B);
    // 0x8012D60C: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x8012D610: nop

    // 0x8012D614: subu        $t5, $t9, $v0
    ctx->r13 = SUB32(ctx->r25, ctx->r2);
    // 0x8012D618: multu       $t5, $t8
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012D61C: mflo        $a3
    ctx->r7 = lo;
    // 0x8012D620: andi        $t6, $a3, 0xFFFF
    ctx->r14 = ctx->r7 & 0XFFFF;
    // 0x8012D624: beq         $t7, $zero, L_8012D8F4
    if (ctx->r15 == 0) {
        // 0x8012D628: or          $a3, $t6, $zero
        ctx->r7 = ctx->r14 | 0;
            goto L_8012D8F4;
    }
    // 0x8012D628: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8012D62C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012D630: lui         $t5, 0xFA00
    ctx->r13 = S32(0XFA00 << 16);
    // 0x8012D634: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x8012D638: addiu       $t9, $a0, 0x8
    ctx->r25 = ADD32(ctx->r4, 0X8);
    // 0x8012D63C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012D640: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012D644: sw          $t8, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r24;
    // 0x8012D648: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x8012D64C: lui         $t7, 0xFB00
    ctx->r15 = S32(0XFB00 << 16);
    // 0x8012D650: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012D654: addiu       $t6, $a1, 0x8
    ctx->r14 = ADD32(ctx->r5, 0X8);
    // 0x8012D658: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012D65C: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x8012D660: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x8012D664: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D668: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012D66C: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012D670: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012D674: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012D678: lwc1        $f16, 0x0($s7)
    ctx->f16.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D67C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x8012D680: bgez        $a3, L_8012D690
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012D684: sra         $t5, $a3, 1
        ctx->r13 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012D690;
    }
    // 0x8012D684: sra         $t5, $a3, 1
    ctx->r13 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012D688: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012D68C: sra         $t5, $at, 1
    ctx->r13 = S32(SIGNED(ctx->r1) >> 1);
L_8012D690:
    // 0x8012D690: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012D694: addu        $v1, $s1, $t5
    ctx->r3 = ADD32(ctx->r17, ctx->r13);
    // 0x8012D698: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012D69C: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012D6A0: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x8012D6A4: addiu       $t3, $t3, -0xE0D
    ctx->r11 = ADD32(ctx->r11, -0XE0D);
    // 0x8012D6A8: addiu       $t2, $t2, -0xE0E
    ctx->r10 = ADD32(ctx->r10, -0XE0E);
    // 0x8012D6AC: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x8012D6B0: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8012D6B4: sll         $t5, $t9, 2
    ctx->r13 = S32(ctx->r25 << 2);
    // 0x8012D6B8: andi        $t8, $t5, 0xFFF
    ctx->r24 = ctx->r13 & 0XFFF;
    // 0x8012D6BC: sll         $t6, $t8, 12
    ctx->r14 = S32(ctx->r24 << 12);
    // 0x8012D6C0: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x8012D6C4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012D6C8: lwc1        $f4, -0xE04($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012D6CC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D6D0: addiu       $t1, $t1, -0xE0F
    ctx->r9 = ADD32(ctx->r9, -0XE0F);
    // 0x8012D6D4: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8012D6D8: addiu       $t0, $t0, -0xE10
    ctx->r8 = ADD32(ctx->r8, -0XE10);
    // 0x8012D6DC: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x8012D6E0: nop

    // 0x8012D6E4: addu        $t8, $s2, $t5
    ctx->r24 = ADD32(ctx->r18, ctx->r13);
    // 0x8012D6E8: addiu       $t6, $t8, 0x1
    ctx->r14 = ADD32(ctx->r24, 0X1);
    // 0x8012D6EC: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x8012D6F0: andi        $t5, $t9, 0xFFF
    ctx->r13 = ctx->r25 & 0XFFF;
    // 0x8012D6F4: or          $t8, $t7, $t5
    ctx->r24 = ctx->r15 | ctx->r13;
    // 0x8012D6F8: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x8012D6FC: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x8012D700: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x8012D704: addiu       $t8, $s2, 0x1
    ctx->r24 = ADD32(ctx->r18, 0X1);
    // 0x8012D708: andi        $t7, $t9, 0xFFF
    ctx->r15 = ctx->r25 & 0XFFF;
    // 0x8012D70C: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x8012D710: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x8012D714: sll         $t5, $t7, 12
    ctx->r13 = S32(ctx->r15 << 12);
    // 0x8012D718: or          $t7, $t5, $t9
    ctx->r15 = ctx->r13 | ctx->r25;
    // 0x8012D71C: sw          $t7, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r15;
    // 0x8012D720: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D724: lui         $t6, 0xB400
    ctx->r14 = S32(0XB400 << 16);
    // 0x8012D728: lui         $t9, 0xB300
    ctx->r25 = S32(0XB300 << 16);
    // 0x8012D72C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012D730: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012D734: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012D738: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012D73C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012D740: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012D744: addiu       $t5, $a0, 0x8
    ctx->r13 = ADD32(ctx->r4, 0X8);
    // 0x8012D748: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012D74C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012D750: lwc1        $f8, 0x0($s7)
    ctx->f8.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D754: div.s       $f10, $f20, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f20.fl, ctx->f8.fl);
    // 0x8012D758: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D75C: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012D760: nop

    // 0x8012D764: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012D768: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012D76C: nop

    // 0x8012D770: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012D774: beql        $t8, $zero, L_8012D7C4
    if (ctx->r24 == 0) {
        // 0x8012D778: mfc1        $t8, $f16
        ctx->r24 = (int32_t)ctx->f16.u32l;
            goto L_8012D7C4;
    }
    goto skip_2;
    // 0x8012D778: mfc1        $t8, $f16
    ctx->r24 = (int32_t)ctx->f16.u32l;
    skip_2:
    // 0x8012D77C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8012D780: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012D784: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x8012D788: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012D78C: nop

    // 0x8012D790: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012D794: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012D798: nop

    // 0x8012D79C: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012D7A0: bne         $t8, $zero, L_8012D7B8
    if (ctx->r24 != 0) {
        // 0x8012D7A4: nop
    
            goto L_8012D7B8;
    }
    // 0x8012D7A4: nop

    // 0x8012D7A8: mfc1        $t8, $f16
    ctx->r24 = (int32_t)ctx->f16.u32l;
    // 0x8012D7AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012D7B0: b           L_8012D7D0
    // 0x8012D7B4: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_8012D7D0;
    // 0x8012D7B4: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_8012D7B8:
    // 0x8012D7B8: b           L_8012D7D0
    // 0x8012D7BC: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_8012D7D0;
    // 0x8012D7BC: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8012D7C0: mfc1        $t8, $f16
    ctx->r24 = (int32_t)ctx->f16.u32l;
L_8012D7C4:
    // 0x8012D7C4: nop

    // 0x8012D7C8: bltz        $t8, L_8012D7B8
    if (SIGNED(ctx->r24) < 0) {
        // 0x8012D7CC: nop
    
            goto L_8012D7B8;
    }
    // 0x8012D7CC: nop

L_8012D7D0:
    // 0x8012D7D0: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012D7D4: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D7D8: lwc1        $f18, -0xE04($at)
    ctx->f18.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012D7DC: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D7E0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D7E4: div.s       $f4, $f20, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f20.fl, ctx->f18.fl);
    // 0x8012D7E8: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x8012D7EC: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012D7F0: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D7F4: nop

    // 0x8012D7F8: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012D7FC: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D800: nop

    // 0x8012D804: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012D808: beql        $t7, $zero, L_8012D858
    if (ctx->r15 == 0) {
        // 0x8012D80C: mfc1        $t7, $f6
        ctx->r15 = (int32_t)ctx->f6.u32l;
            goto L_8012D858;
    }
    goto skip_3;
    // 0x8012D80C: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    skip_3:
    // 0x8012D810: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012D814: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D818: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x8012D81C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D820: nop

    // 0x8012D824: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012D828: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D82C: nop

    // 0x8012D830: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012D834: bne         $t7, $zero, L_8012D84C
    if (ctx->r15 != 0) {
        // 0x8012D838: nop
    
            goto L_8012D84C;
    }
    // 0x8012D838: nop

    // 0x8012D83C: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8012D840: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012D844: b           L_8012D864
    // 0x8012D848: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012D864;
    // 0x8012D848: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012D84C:
    // 0x8012D84C: b           L_8012D864
    // 0x8012D850: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012D864;
    // 0x8012D850: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012D854: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
L_8012D858:
    // 0x8012D858: nop

    // 0x8012D85C: bltz        $t7, L_8012D84C
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012D860: nop
    
            goto L_8012D84C;
    }
    // 0x8012D860: nop

L_8012D864:
    // 0x8012D864: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x8012D868: or          $t6, $t5, $t8
    ctx->r14 = ctx->r13 | ctx->r24;
    // 0x8012D86C: sw          $t6, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r14;
    // 0x8012D870: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D874: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012D878: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8012D87C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012D880: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8012D884: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012D888: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x8012D88C: lbu         $t8, 0x0($t0)
    ctx->r24 = MEM_BU(ctx->r8, 0X0);
    // 0x8012D890: lui         $t9, 0xFB00
    ctx->r25 = S32(0XFB00 << 16);
    // 0x8012D894: sll         $t5, $t7, 16
    ctx->r13 = S32(ctx->r15 << 16);
    // 0x8012D898: lbu         $t7, 0x0($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X0);
    // 0x8012D89C: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8012D8A0: or          $t8, $t6, $t5
    ctx->r24 = ctx->r14 | ctx->r13;
    // 0x8012D8A4: sll         $t6, $t7, 8
    ctx->r14 = S32(ctx->r15 << 8);
    // 0x8012D8A8: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012D8AC: or          $t5, $t8, $t6
    ctx->r13 = ctx->r24 | ctx->r14;
    // 0x8012D8B0: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x8012D8B4: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8012D8B8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D8BC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012D8C0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012D8C4: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012D8C8: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012D8CC: lbu         $t7, 0x0($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X0);
    // 0x8012D8D0: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x8012D8D4: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012D8D8: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x8012D8DC: or          $t7, $t8, $t5
    ctx->r15 = ctx->r24 | ctx->r13;
    // 0x8012D8E0: sll         $t8, $t9, 8
    ctx->r24 = S32(ctx->r25 << 8);
    // 0x8012D8E4: lbu         $t9, 0x0($t3)
    ctx->r25 = MEM_BU(ctx->r11, 0X0);
    // 0x8012D8E8: or          $t5, $t7, $t8
    ctx->r13 = ctx->r15 | ctx->r24;
    // 0x8012D8EC: or          $t7, $t5, $t9
    ctx->r15 = ctx->r13 | ctx->r25;
    // 0x8012D8F0: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
L_8012D8F4:
    // 0x8012D8F4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D8F8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012D8FC: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012D900: lwc1        $f8, 0x0($s7)
    ctx->f8.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D904: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012D908: bgez        $a3, L_8012D918
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012D90C: sra         $fp, $a3, 1
        ctx->r30 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012D918;
    }
    // 0x8012D90C: sra         $fp, $a3, 1
    ctx->r30 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012D910: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012D914: sra         $fp, $at, 1
    ctx->r30 = S32(SIGNED(ctx->r1) >> 1);
L_8012D918:
    // 0x8012D918: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012D91C: addu        $v1, $s1, $fp
    ctx->r3 = ADD32(ctx->r17, ctx->r30);
    // 0x8012D920: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012D924: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x8012D928: nop

    // 0x8012D92C: addu        $t9, $v1, $t5
    ctx->r25 = ADD32(ctx->r3, ctx->r13);
    // 0x8012D930: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x8012D934: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8012D938: sll         $t6, $t8, 12
    ctx->r14 = S32(ctx->r24 << 12);
    // 0x8012D93C: or          $t5, $t6, $at
    ctx->r13 = ctx->r14 | ctx->r1;
    // 0x8012D940: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012D944: lwc1        $f16, -0xE04($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012D948: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012D94C: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012D950: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x8012D954: nop

    // 0x8012D958: addu        $t8, $s2, $t7
    ctx->r24 = ADD32(ctx->r18, ctx->r15);
    // 0x8012D95C: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x8012D960: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x8012D964: sll         $t8, $v1, 2
    ctx->r24 = S32(ctx->r3 << 2);
    // 0x8012D968: andi        $t6, $t8, 0xFFF
    ctx->r14 = ctx->r24 & 0XFFF;
    // 0x8012D96C: or          $t7, $t5, $t9
    ctx->r15 = ctx->r13 | ctx->r25;
    // 0x8012D970: sll         $t5, $t6, 12
    ctx->r13 = S32(ctx->r14 << 12);
    // 0x8012D974: or          $t9, $t5, $s6
    ctx->r25 = ctx->r13 | ctx->r22;
    // 0x8012D978: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x8012D97C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012D980: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012D984: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x8012D988: lui         $t5, 0xB300
    ctx->r13 = S32(0XB300 << 16);
    // 0x8012D98C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012D990: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012D994: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012D998: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012D99C: lw          $a2, 0x0($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X0);
    // 0x8012D9A0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D9A4: addiu       $t6, $a2, 0x8
    ctx->r14 = ADD32(ctx->r6, 0X8);
    // 0x8012D9A8: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012D9AC: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x8012D9B0: lwc1        $f4, 0x0($s7)
    ctx->f4.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012D9B4: div.s       $f6, $f20, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f20.fl, ctx->f4.fl);
    // 0x8012D9B8: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012D9BC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D9C0: nop

    // 0x8012D9C4: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012D9C8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D9CC: nop

    // 0x8012D9D0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012D9D4: beql        $t7, $zero, L_8012DA24
    if (ctx->r15 == 0) {
        // 0x8012D9D8: mfc1        $t7, $f8
        ctx->r15 = (int32_t)ctx->f8.u32l;
            goto L_8012DA24;
    }
    goto skip_4;
    // 0x8012D9D8: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    skip_4:
    // 0x8012D9DC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012D9E0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012D9E4: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012D9E8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012D9EC: nop

    // 0x8012D9F0: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012D9F4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012D9F8: nop

    // 0x8012D9FC: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012DA00: bne         $t7, $zero, L_8012DA18
    if (ctx->r15 != 0) {
        // 0x8012DA04: nop
    
            goto L_8012DA18;
    }
    // 0x8012DA04: nop

    // 0x8012DA08: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x8012DA0C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012DA10: b           L_8012DA30
    // 0x8012DA14: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012DA30;
    // 0x8012DA14: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012DA18:
    // 0x8012DA18: b           L_8012DA30
    // 0x8012DA1C: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012DA30;
    // 0x8012DA1C: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012DA20: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
L_8012DA24:
    // 0x8012DA24: nop

    // 0x8012DA28: bltz        $t7, L_8012DA18
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012DA2C: nop
    
            goto L_8012DA18;
    }
    // 0x8012DA2C: nop

L_8012DA30:
    // 0x8012DA30: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012DA34: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012DA38: lwc1        $f10, -0xE04($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012DA3C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012DA40: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012DA44: div.s       $f16, $f20, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f20.fl, ctx->f10.fl);
    // 0x8012DA48: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x8012DA4C: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012DA50: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012DA54: nop

    // 0x8012DA58: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012DA5C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012DA60: nop

    // 0x8012DA64: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012DA68: beql        $t9, $zero, L_8012DAB8
    if (ctx->r25 == 0) {
        // 0x8012DA6C: mfc1        $t9, $f18
        ctx->r25 = (int32_t)ctx->f18.u32l;
            goto L_8012DAB8;
    }
    goto skip_5;
    // 0x8012DA6C: mfc1        $t9, $f18
    ctx->r25 = (int32_t)ctx->f18.u32l;
    skip_5:
    // 0x8012DA70: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012DA74: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012DA78: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x8012DA7C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012DA80: nop

    // 0x8012DA84: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012DA88: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012DA8C: nop

    // 0x8012DA90: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012DA94: bne         $t9, $zero, L_8012DAAC
    if (ctx->r25 != 0) {
        // 0x8012DA98: nop
    
            goto L_8012DAAC;
    }
    // 0x8012DA98: nop

    // 0x8012DA9C: mfc1        $t9, $f18
    ctx->r25 = (int32_t)ctx->f18.u32l;
    // 0x8012DAA0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012DAA4: b           L_8012DAC4
    // 0x8012DAA8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8012DAC4;
    // 0x8012DAA8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8012DAAC:
    // 0x8012DAAC: b           L_8012DAC4
    // 0x8012DAB0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8012DAC4;
    // 0x8012DAB0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8012DAB4: mfc1        $t9, $f18
    ctx->r25 = (int32_t)ctx->f18.u32l;
L_8012DAB8:
    // 0x8012DAB8: nop

    // 0x8012DABC: bltz        $t9, L_8012DAAC
    if (SIGNED(ctx->r25) < 0) {
        // 0x8012DAC0: nop
    
            goto L_8012DAAC;
    }
    // 0x8012DAC0: nop

L_8012DAC4:
    // 0x8012DAC4: andi        $t7, $t9, 0xFFFF
    ctx->r15 = ctx->r25 & 0XFFFF;
    // 0x8012DAC8: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012DACC: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8012DAD0: sw          $t8, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r24;
L_8012DAD4:
    // 0x8012DAD4: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8012DAD8: lbu         $v0, -0xE0C($v0)
    ctx->r2 = MEM_BU(ctx->r2, -0XE0C);
    // 0x8012DADC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012DAE0: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8012DAE4: beq         $v0, $zero, L_8012DB04
    if (ctx->r2 == 0) {
        // 0x8012DAE8: nop
    
            goto L_8012DB04;
    }
    // 0x8012DAE8: nop

    // 0x8012DAEC: beq         $v0, $at, L_8012DB78
    if (ctx->r2 == ctx->r1) {
        // 0x8012DAF0: addu        $s2, $s4, $fp
        ctx->r18 = ADD32(ctx->r20, ctx->r30);
            goto L_8012DB78;
    }
    // 0x8012DAF0: addu        $s2, $s4, $fp
    ctx->r18 = ADD32(ctx->r20, ctx->r30);
    // 0x8012DAF4: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x8012DAF8: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8012DAFC: b           L_8012DC40
    // 0x8012DB00: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
        goto L_8012DC40;
    // 0x8012DB00: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
L_8012DB04:
    // 0x8012DB04: lw          $t6, -0xE20($t6)
    ctx->r14 = MEM_W(ctx->r14, -0XE20);
    // 0x8012DB08: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012DB0C: addu        $t7, $s3, $t6
    ctx->r15 = ADD32(ctx->r19, ctx->r14);
    // 0x8012DB10: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x8012DB14: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x8012DB18: bgez        $t8, L_8012DB2C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8012DB1C: cvt.s.w     $f12, $f4
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8012DB2C;
    }
    // 0x8012DB1C: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012DB20: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012DB24: nop

    // 0x8012DB28: add.s       $f12, $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f6.fl;
L_8012DB2C:
    // 0x8012DB2C: jal         0x8012C314
    // 0x8012DB30: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    get_glyph_width(rdram, ctx);
        goto after_6;
    // 0x8012DB30: or          $s1, $s4, $zero
    ctx->r17 = ctx->r20 | 0;
    after_6:
    // 0x8012DB34: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8012DB38: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012DB3C: lwc1        $f8, 0x58($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X58);
    // 0x8012DB40: addu        $s4, $s1, $v0
    ctx->r20 = ADD32(ctx->r17, ctx->r2);
    // 0x8012DB44: andi        $t5, $s4, 0xFFFF
    ctx->r13 = ctx->r20 & 0XFFFF;
    // 0x8012DB48: c.lt.s      $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f8.fl < ctx->f10.fl;
    // 0x8012DB4C: or          $s4, $t5, $zero
    ctx->r20 = ctx->r13 | 0;
    // 0x8012DB50: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    // 0x8012DB54: bc1fl       L_8012DB6C
    if (!c1cs) {
        // 0x8012DB58: addu        $s2, $s4, $fp
        ctx->r18 = ADD32(ctx->r20, ctx->r30);
            goto L_8012DB6C;
    }
    goto skip_6;
    // 0x8012DB58: addu        $s2, $s4, $fp
    ctx->r18 = ADD32(ctx->r20, ctx->r30);
    skip_6:
    // 0x8012DB5C: addiu       $s4, $t5, 0x1
    ctx->r20 = ADD32(ctx->r13, 0X1);
    // 0x8012DB60: andi        $t9, $s4, 0xFFFF
    ctx->r25 = ctx->r20 & 0XFFFF;
    // 0x8012DB64: or          $s4, $t9, $zero
    ctx->r20 = ctx->r25 | 0;
    // 0x8012DB68: addu        $s2, $s4, $fp
    ctx->r18 = ADD32(ctx->r20, ctx->r30);
L_8012DB6C:
    // 0x8012DB6C: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8012DB70: b           L_8012DC40
    // 0x8012DB74: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
        goto L_8012DC40;
    // 0x8012DB74: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
L_8012DB78:
    // 0x8012DB78: mtc1        $s4, $f16
    ctx->f16.u32l = ctx->r20;
    // 0x8012DB7C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012DB80: bgez        $s4, L_8012DB94
    if (SIGNED(ctx->r20) >= 0) {
        // 0x8012DB84: cvt.s.w     $f18, $f16
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
            goto L_8012DB94;
    }
    // 0x8012DB84: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8012DB88: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012DB8C: nop

    // 0x8012DB90: add.s       $f18, $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f4.fl;
L_8012DB94:
    // 0x8012DB94: lwc1        $f6, 0x0($s7)
    ctx->f6.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012DB98: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8012DB9C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012DBA0: add.s       $f8, $f18, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f18.fl + ctx->f6.fl;
    // 0x8012DBA4: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012DBA8: ctc1        $s4, $FpcCsr
    set_cop1_cs(ctx->r20);
    // 0x8012DBAC: nop

    // 0x8012DBB0: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012DBB4: cfc1        $s4, $FpcCsr
    ctx->r20 = get_cop1_cs();
    // 0x8012DBB8: nop

    // 0x8012DBBC: andi        $s4, $s4, 0x78
    ctx->r20 = ctx->r20 & 0X78;
    // 0x8012DBC0: beql        $s4, $zero, L_8012DC10
    if (ctx->r20 == 0) {
        // 0x8012DBC4: mfc1        $s4, $f10
        ctx->r20 = (int32_t)ctx->f10.u32l;
            goto L_8012DC10;
    }
    goto skip_7;
    // 0x8012DBC4: mfc1        $s4, $f10
    ctx->r20 = (int32_t)ctx->f10.u32l;
    skip_7:
    // 0x8012DBC8: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012DBCC: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8012DBD0: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x8012DBD4: ctc1        $s4, $FpcCsr
    set_cop1_cs(ctx->r20);
    // 0x8012DBD8: nop

    // 0x8012DBDC: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012DBE0: cfc1        $s4, $FpcCsr
    ctx->r20 = get_cop1_cs();
    // 0x8012DBE4: nop

    // 0x8012DBE8: andi        $s4, $s4, 0x78
    ctx->r20 = ctx->r20 & 0X78;
    // 0x8012DBEC: bne         $s4, $zero, L_8012DC04
    if (ctx->r20 != 0) {
        // 0x8012DBF0: nop
    
            goto L_8012DC04;
    }
    // 0x8012DBF0: nop

    // 0x8012DBF4: mfc1        $s4, $f10
    ctx->r20 = (int32_t)ctx->f10.u32l;
    // 0x8012DBF8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012DBFC: b           L_8012DC1C
    // 0x8012DC00: or          $s4, $s4, $at
    ctx->r20 = ctx->r20 | ctx->r1;
        goto L_8012DC1C;
    // 0x8012DC00: or          $s4, $s4, $at
    ctx->r20 = ctx->r20 | ctx->r1;
L_8012DC04:
    // 0x8012DC04: b           L_8012DC1C
    // 0x8012DC08: addiu       $s4, $zero, -0x1
    ctx->r20 = ADD32(0, -0X1);
        goto L_8012DC1C;
    // 0x8012DC08: addiu       $s4, $zero, -0x1
    ctx->r20 = ADD32(0, -0X1);
    // 0x8012DC0C: mfc1        $s4, $f10
    ctx->r20 = (int32_t)ctx->f10.u32l;
L_8012DC10:
    // 0x8012DC10: nop

    // 0x8012DC14: bltz        $s4, L_8012DC04
    if (SIGNED(ctx->r20) < 0) {
        // 0x8012DC18: nop
    
            goto L_8012DC04;
    }
    // 0x8012DC18: nop

L_8012DC1C:
    // 0x8012DC1C: andi        $t5, $s4, 0xFFFF
    ctx->r13 = ctx->r20 & 0XFFFF;
    // 0x8012DC20: addu        $s2, $t5, $fp
    ctx->r18 = ADD32(ctx->r13, ctx->r30);
    // 0x8012DC24: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012DC28: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x8012DC2C: or          $s4, $t5, $zero
    ctx->r20 = ctx->r13 | 0;
    // 0x8012DC30: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012DC34: b           L_8012DC40
    // 0x8012DC38: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
        goto L_8012DC40;
    // 0x8012DC38: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    // 0x8012DC3C: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
L_8012DC40:
    // 0x8012DC40: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
L_8012DC44:
    // 0x8012DC44: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012DC48: lh          $t8, 0x62($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X62);
    // 0x8012DC4C: beql        $t7, $at, L_8012DC60
    if (ctx->r15 == ctx->r1) {
        // 0x8012DC50: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8012DC60;
    }
    goto skip_8;
    // 0x8012DC50: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_8:
    // 0x8012DC54: bnel        $t8, $zero, L_8012D51C
    if (ctx->r24 != 0) {
        // 0x8012DC58: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8012D51C;
    }
    goto skip_9;
    // 0x8012DC58: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_9:
L_8012DC5C:
    // 0x8012DC5C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_8012DC60:
    // 0x8012DC60: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x8012DC64: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012DC68: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012DC6C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012DC70: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012DC74: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8012DC78: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x8012DC7C: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8012DC80: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x8012DC84: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x8012DC88: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8012DC8C: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x8012DC90: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x8012DC94: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x8012DC98: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8012DC9C: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x8012DCA0: jr          $ra
    // 0x8012DCA4: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x8012DCA4: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void draw_glyph(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012DCA8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8012DCAC: lwc1        $f4, 0x28($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X28);
    // 0x8012DCB0: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012DCB4: lwc1        $f6, 0x2C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X2C);
    // 0x8012DCB8: swc1        $f4, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f4.u32l;
    // 0x8012DCBC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012DCC0: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012DCC4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8012DCC8: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x8012DCCC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x8012DCD0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8012DCD4: jal         0x8012FA78
    // 0x8012DCD8: swc1        $f6, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f6.u32l;
    func_8012FA78(rdram, ctx);
        goto after_0;
    // 0x8012DCD8: swc1        $f6, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f6.u32l;
    after_0:
    // 0x8012DCDC: lw          $t6, 0x1C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X1C);
    // 0x8012DCE0: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x8012DCE4: jal         0x8012FB4C
    // 0x8012DCE8: lh          $a1, 0x0($t6)
    ctx->r5 = MEM_H(ctx->r14, 0X0);
    load_glyph(rdram, ctx);
        goto after_1;
    // 0x8012DCE8: lh          $a1, 0x0($t6)
    ctx->r5 = MEM_H(ctx->r14, 0X0);
    after_1:
    // 0x8012DCEC: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x8012DCF0: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012DCF4: addiu       $t2, $t2, -0xE08
    ctx->r10 = ADD32(ctx->r10, -0XE08);
    // 0x8012DCF8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012DCFC: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012DD00: addiu       $t3, $t3, -0xE04
    ctx->r11 = ADD32(ctx->r11, -0XE04);
    // 0x8012DD04: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012DD08: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012DD0C: lwc1        $f8, 0x0($t2)
    ctx->f8.u32l = MEM_W(ctx->r10, 0X0);
    // 0x8012DD10: lwc1        $f16, 0x0($t3)
    ctx->f16.u32l = MEM_W(ctx->r11, 0X0);
    // 0x8012DD14: lhu         $a1, 0x22($sp)
    ctx->r5 = MEM_HU(ctx->r29, 0X22);
    // 0x8012DD18: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012DD1C: lhu         $a2, 0x26($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X26);
    // 0x8012DD20: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012DD24: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012DD28: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x8012DD2C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8012DD30: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012DD34: addu        $t4, $a1, $t9
    ctx->r12 = ADD32(ctx->r5, ctx->r25);
    // 0x8012DD38: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x8012DD3C: mfc1        $t4, $f18
    ctx->r12 = (int32_t)ctx->f18.u32l;
    // 0x8012DD40: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x8012DD44: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x8012DD48: addu        $t5, $a2, $t4
    ctx->r13 = ADD32(ctx->r6, ctx->r12);
    // 0x8012DD4C: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8012DD50: or          $t8, $t7, $at
    ctx->r24 = ctx->r15 | ctx->r1;
    // 0x8012DD54: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x8012DD58: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012DD5C: sll         $t4, $a1, 2
    ctx->r12 = S32(ctx->r5 << 2);
    // 0x8012DD60: andi        $t5, $t4, 0xFFF
    ctx->r13 = ctx->r12 & 0XFFF;
    // 0x8012DD64: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x8012DD68: andi        $t7, $t8, 0xFFF
    ctx->r15 = ctx->r24 & 0XFFF;
    // 0x8012DD6C: sll         $t6, $t5, 12
    ctx->r14 = S32(ctx->r13 << 12);
    // 0x8012DD70: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012DD74: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8012DD78: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012DD7C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012DD80: lui         $t5, 0xB400
    ctx->r13 = S32(0XB400 << 16);
    // 0x8012DD84: lui         $t6, 0xB300
    ctx->r14 = S32(0XB300 << 16);
    // 0x8012DD88: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x8012DD8C: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x8012DD90: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012DD94: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012DD98: lw          $t0, 0x0($a0)
    ctx->r8 = MEM_W(ctx->r4, 0X0);
    // 0x8012DD9C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012DDA0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012DDA4: addiu       $t8, $t0, 0x8
    ctx->r24 = ADD32(ctx->r8, 0X8);
    // 0x8012DDA8: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012DDAC: sw          $t6, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r14;
    // 0x8012DDB0: lwc1        $f4, 0x0($t2)
    ctx->f4.u32l = MEM_W(ctx->r10, 0X0);
    // 0x8012DDB4: div.s       $f6, $f0, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f0.fl, ctx->f4.fl);
    // 0x8012DDB8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012DDBC: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012DDC0: nop

    // 0x8012DDC4: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012DDC8: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012DDCC: nop

    // 0x8012DDD0: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012DDD4: beql        $t9, $zero, L_8012DE24
    if (ctx->r25 == 0) {
        // 0x8012DDD8: mfc1        $t9, $f8
        ctx->r25 = (int32_t)ctx->f8.u32l;
            goto L_8012DE24;
    }
    goto skip_0;
    // 0x8012DDD8: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    skip_0:
    // 0x8012DDDC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012DDE0: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012DDE4: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012DDE8: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012DDEC: nop

    // 0x8012DDF0: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012DDF4: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012DDF8: nop

    // 0x8012DDFC: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012DE00: bne         $t9, $zero, L_8012DE18
    if (ctx->r25 != 0) {
        // 0x8012DE04: nop
    
            goto L_8012DE18;
    }
    // 0x8012DE04: nop

    // 0x8012DE08: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x8012DE0C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012DE10: b           L_8012DE30
    // 0x8012DE14: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8012DE30;
    // 0x8012DE14: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8012DE18:
    // 0x8012DE18: b           L_8012DE30
    // 0x8012DE1C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8012DE30;
    // 0x8012DE1C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8012DE20: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
L_8012DE24:
    // 0x8012DE24: nop

    // 0x8012DE28: bltz        $t9, L_8012DE18
    if (SIGNED(ctx->r25) < 0) {
        // 0x8012DE2C: nop
    
            goto L_8012DE18;
    }
    // 0x8012DE2C: nop

L_8012DE30:
    // 0x8012DE30: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012DE34: lwc1        $f10, 0x0($t3)
    ctx->f10.u32l = MEM_W(ctx->r11, 0X0);
    // 0x8012DE38: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012DE3C: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x8012DE40: div.s       $f16, $f0, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f0.fl, ctx->f10.fl);
    // 0x8012DE44: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012DE48: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012DE4C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012DE50: nop

    // 0x8012DE54: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012DE58: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012DE5C: nop

    // 0x8012DE60: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012DE64: beql        $t6, $zero, L_8012DEB4
    if (ctx->r14 == 0) {
        // 0x8012DE68: mfc1        $t6, $f18
        ctx->r14 = (int32_t)ctx->f18.u32l;
            goto L_8012DEB4;
    }
    goto skip_1;
    // 0x8012DE68: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    skip_1:
    // 0x8012DE6C: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012DE70: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012DE74: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x8012DE78: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012DE7C: nop

    // 0x8012DE80: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012DE84: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012DE88: nop

    // 0x8012DE8C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012DE90: bne         $t6, $zero, L_8012DEA8
    if (ctx->r14 != 0) {
        // 0x8012DE94: nop
    
            goto L_8012DEA8;
    }
    // 0x8012DE94: nop

    // 0x8012DE98: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x8012DE9C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012DEA0: b           L_8012DEC0
    // 0x8012DEA4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_8012DEC0;
    // 0x8012DEA4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_8012DEA8:
    // 0x8012DEA8: b           L_8012DEC0
    // 0x8012DEAC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_8012DEC0;
    // 0x8012DEAC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8012DEB0: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
L_8012DEB4:
    // 0x8012DEB4: nop

    // 0x8012DEB8: bltz        $t6, L_8012DEA8
    if (SIGNED(ctx->r14) < 0) {
        // 0x8012DEBC: nop
    
            goto L_8012DEA8;
    }
    // 0x8012DEBC: nop

L_8012DEC0:
    // 0x8012DEC0: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x8012DEC4: or          $t9, $t5, $t7
    ctx->r25 = ctx->r13 | ctx->r15;
    // 0x8012DEC8: sw          $t9, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r25;
    // 0x8012DECC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012DED0: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012DED4: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x8012DED8: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x8012DEDC: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x8012DEE0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012DEE4: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012DEE8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012DEEC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8012DEF0: jr          $ra
    // 0x8012DEF4: nop

    return;
    // 0x8012DEF4: nop

;}
RECOMP_FUNC void display_text(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012DEF8: addiu       $sp, $sp, -0xB0
    ctx->r29 = ADD32(ctx->r29, -0XB0);
    // 0x8012DEFC: sdc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X28, ctx->r29);
    // 0x8012DF00: lwc1        $f24, 0xC0($sp)
    ctx->f24.u32l = MEM_W(ctx->r29, 0XC0);
    // 0x8012DF04: lwc1        $f4, 0xC4($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0XC4);
    // 0x8012DF08: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x8012DF0C: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x8012DF10: lui         $s4, 0x8024
    ctx->r20 = S32(0X8024 << 16);
    // 0x8012DF14: lui         $s7, 0x8024
    ctx->r23 = S32(0X8024 << 16);
    // 0x8012DF18: addiu       $s7, $s7, -0xE04
    ctx->r23 = ADD32(ctx->r23, -0XE04);
    // 0x8012DF1C: addiu       $s4, $s4, -0xE08
    ctx->r20 = ADD32(ctx->r20, -0XE08);
    // 0x8012DF20: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8012DF24: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x8012DF28: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x8012DF2C: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x8012DF30: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x8012DF34: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x8012DF38: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x8012DF3C: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8012DF40: sdc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X20, ctx->r29);
    // 0x8012DF44: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012DF48: sw          $a1, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->r5;
    // 0x8012DF4C: sw          $a2, 0xB8($sp)
    MEM_W(0XB8, ctx->r29) = ctx->r6;
    // 0x8012DF50: sw          $a3, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r7;
    // 0x8012DF54: swc1        $f24, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->f24.u32l;
    // 0x8012DF58: swc1        $f4, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->f4.u32l;
    // 0x8012DF5C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012DF60: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012DF64: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8012DF68: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012DF6C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012DF70: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012DF74: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012DF78: lbu         $t7, 0x0($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X0);
    // 0x8012DF7C: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012DF80: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012DF84: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012DF88: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012DF8C: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012DF90: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8012DF94: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012DF98: sll         $t5, $t9, 24
    ctx->r13 = S32(ctx->r25 << 24);
    // 0x8012DF9C: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012DFA0: or          $t9, $t5, $t8
    ctx->r25 = ctx->r13 | ctx->r24;
    // 0x8012DFA4: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012DFA8: sll         $t5, $t7, 8
    ctx->r13 = S32(ctx->r15 << 8);
    // 0x8012DFAC: lbu         $t7, 0x0($t4)
    ctx->r15 = MEM_BU(ctx->r12, 0X0);
    // 0x8012DFB0: or          $t8, $t9, $t5
    ctx->r24 = ctx->r25 | ctx->r13;
    // 0x8012DFB4: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012DFB8: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012DFBC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012DFC0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012DFC4: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8012DFC8: andi        $s1, $a3, 0xFFFF
    ctx->r17 = ctx->r7 & 0XFFFF;
    // 0x8012DFCC: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012DFD0: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012DFD4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012DFD8: lbu         $t6, 0x0($t2)
    ctx->r14 = MEM_BU(ctx->r10, 0X0);
    // 0x8012DFDC: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x8012DFE0: andi        $s2, $a2, 0xFFFF
    ctx->r18 = ctx->r6 & 0XFFFF;
    // 0x8012DFE4: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8012DFE8: lbu         $t6, 0x0($t3)
    ctx->r14 = MEM_BU(ctx->r11, 0X0);
    // 0x8012DFEC: sll         $t9, $t7, 24
    ctx->r25 = S32(ctx->r15 << 24);
    // 0x8012DFF0: or          $t7, $t9, $t8
    ctx->r15 = ctx->r25 | ctx->r24;
    // 0x8012DFF4: sll         $t9, $t6, 8
    ctx->r25 = S32(ctx->r14 << 8);
    // 0x8012DFF8: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012DFFC: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8012E000: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8012E004: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012E008: jal         0x8012C3D8
    // 0x8012E00C: lw          $a0, 0xB4($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB4);
    get_message_width(rdram, ctx);
        goto after_0;
    // 0x8012E00C: lw          $a0, 0xB4($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB4);
    after_0:
    // 0x8012E010: sh          $v0, 0xAC($sp)
    MEM_H(0XAC, ctx->r29) = ctx->r2;
    // 0x8012E014: jal         0x8012FA78
    // 0x8012E018: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8012FA78(rdram, ctx);
        goto after_1;
    // 0x8012E018: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x8012E01C: lw          $t9, 0xB4($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XB4);
    // 0x8012E020: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012E024: or          $fp, $s1, $zero
    ctx->r30 = ctx->r17 | 0;
    // 0x8012E028: lh          $v0, 0x0($t9)
    ctx->r2 = MEM_H(ctx->r25, 0X0);
    // 0x8012E02C: sll         $t5, $s1, 2
    ctx->r13 = S32(ctx->r17 << 2);
    // 0x8012E030: andi        $t8, $t5, 0xFFF
    ctx->r24 = ctx->r13 & 0XFFF;
    // 0x8012E034: beq         $v0, $at, L_8012E6D0
    if (ctx->r2 == ctx->r1) {
        // 0x8012E038: lui         $s1, 0x8024
        ctx->r17 = S32(0X8024 << 16);
            goto L_8012E6D0;
    }
    // 0x8012E038: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x8012E03C: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8012E040: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8012E044: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012E048: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012E04C: sw          $t8, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r24;
    // 0x8012E050: addiu       $s1, $s1, -0xE20
    ctx->r17 = ADD32(ctx->r17, -0XE20);
    // 0x8012E054: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
L_8012E058:
    // 0x8012E058: sll         $s5, $v0, 16
    ctx->r21 = S32(ctx->r2 << 16);
    // 0x8012E05C: sra         $t6, $s5, 16
    ctx->r14 = S32(SIGNED(ctx->r21) >> 16);
    // 0x8012E060: lh          $t8, 0xAC($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XAC);
    // 0x8012E064: sll         $a1, $t6, 16
    ctx->r5 = S32(ctx->r14 << 16);
    // 0x8012E068: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8012E06C: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x8012E070: or          $s5, $t6, $zero
    ctx->r21 = ctx->r14 | 0;
    // 0x8012E074: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8012E078: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x8012E07C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8012E080: or          $s6, $s2, $zero
    ctx->r22 = ctx->r18 | 0;
    // 0x8012E084: jal         0x8012FB4C
    // 0x8012E088: subu        $s3, $s2, $t8
    ctx->r19 = SUB32(ctx->r18, ctx->r24);
    load_glyph(rdram, ctx);
        goto after_2;
    // 0x8012E088: subu        $s3, $s2, $t8
    ctx->r19 = SUB32(ctx->r18, ctx->r24);
    after_2:
    // 0x8012E08C: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012E090: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012E094: lbu         $t7, 0x0($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X0);
    // 0x8012E098: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x8012E09C: bgez        $t7, L_8012E0B0
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8012E0A0: cvt.s.w     $f12, $f6
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8012E0B0;
    }
    // 0x8012E0A0: cvt.s.w     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8012E0A4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012E0A8: nop

    // 0x8012E0AC: add.s       $f12, $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f8.fl;
L_8012E0B0:
    // 0x8012E0B0: jal         0x8012C314
    // 0x8012E0B4: nop

    get_glyph_width(rdram, ctx);
        goto after_3;
    // 0x8012E0B4: nop

    after_3:
    // 0x8012E0B8: lwc1        $f10, 0x0($s4)
    ctx->f10.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E0BC: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8012E0C0: lbu         $t6, -0xE0C($t6)
    ctx->r14 = MEM_BU(ctx->r14, -0XE0C);
    // 0x8012E0C4: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012E0C8: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x8012E0CC: lbu         $t9, -0xE0B($t9)
    ctx->r25 = MEM_BU(ctx->r25, -0XE0B);
    // 0x8012E0D0: mfc1        $t5, $f16
    ctx->r13 = (int32_t)ctx->f16.u32l;
    // 0x8012E0D4: nop

    // 0x8012E0D8: subu        $t8, $t5, $v0
    ctx->r24 = SUB32(ctx->r13, ctx->r2);
    // 0x8012E0DC: multu       $t8, $t6
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012E0E0: mflo        $a3
    ctx->r7 = lo;
    // 0x8012E0E4: andi        $t7, $a3, 0xFFFF
    ctx->r15 = ctx->r7 & 0XFFFF;
    // 0x8012E0E8: beq         $t9, $zero, L_8012E3AC
    if (ctx->r25 == 0) {
        // 0x8012E0EC: or          $a3, $t7, $zero
        ctx->r7 = ctx->r15 | 0;
            goto L_8012E3AC;
    }
    // 0x8012E0EC: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x8012E0F0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8012E0F4: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x8012E0F8: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x8012E0FC: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x8012E100: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012E104: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8012E108: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012E10C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012E110: lui         $t9, 0xFB00
    ctx->r25 = S32(0XFB00 << 16);
    // 0x8012E114: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012E118: addiu       $t7, $a0, 0x8
    ctx->r15 = ADD32(ctx->r4, 0X8);
    // 0x8012E11C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012E120: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012E124: sw          $zero, 0x4($a0)
    MEM_W(0X4, ctx->r4) = 0;
    // 0x8012E128: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E12C: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012E130: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012E134: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012E138: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012E13C: lwc1        $f18, 0x0($s4)
    ctx->f18.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E140: lwc1        $f6, 0x0($s7)
    ctx->f6.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012E144: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8012E148: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x8012E14C: bgez        $a3, L_8012E15C
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012E150: sra         $t8, $a3, 1
        ctx->r24 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012E15C;
    }
    // 0x8012E150: sra         $t8, $a3, 1
    ctx->r24 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012E154: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012E158: sra         $t8, $at, 1
    ctx->r24 = S32(SIGNED(ctx->r1) >> 1);
L_8012E15C:
    // 0x8012E15C: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    // 0x8012E160: addu        $a2, $s3, $t8
    ctx->r6 = ADD32(ctx->r19, ctx->r24);
    // 0x8012E164: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8012E168: addu        $t9, $a2, $t7
    ctx->r25 = ADD32(ctx->r6, ctx->r15);
    // 0x8012E16C: addiu       $t5, $t9, 0x1
    ctx->r13 = ADD32(ctx->r25, 0X1);
    // 0x8012E170: sll         $t8, $t5, 2
    ctx->r24 = S32(ctx->r13 << 2);
    // 0x8012E174: andi        $t6, $t8, 0xFFF
    ctx->r14 = ctx->r24 & 0XFFF;
    // 0x8012E178: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x8012E17C: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x8012E180: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012E184: or          $t9, $t7, $at
    ctx->r25 = ctx->r15 | ctx->r1;
    // 0x8012E188: addu        $t6, $fp, $t8
    ctx->r14 = ADD32(ctx->r30, ctx->r24);
    // 0x8012E18C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8012E190: sll         $t5, $t7, 2
    ctx->r13 = S32(ctx->r15 << 2);
    // 0x8012E194: andi        $t8, $t5, 0xFFF
    ctx->r24 = ctx->r13 & 0XFFF;
    // 0x8012E198: or          $t6, $t9, $t8
    ctx->r14 = ctx->r25 | ctx->r24;
    // 0x8012E19C: addiu       $t7, $a2, 0x1
    ctx->r15 = ADD32(ctx->r6, 0X1);
    // 0x8012E1A0: sll         $t5, $t7, 2
    ctx->r13 = S32(ctx->r15 << 2);
    // 0x8012E1A4: sw          $t6, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r14;
    // 0x8012E1A8: addiu       $t6, $fp, 0x1
    ctx->r14 = ADD32(ctx->r30, 0X1);
    // 0x8012E1AC: andi        $t9, $t5, 0xFFF
    ctx->r25 = ctx->r13 & 0XFFF;
    // 0x8012E1B0: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8012E1B4: andi        $t5, $t7, 0xFFF
    ctx->r13 = ctx->r15 & 0XFFF;
    // 0x8012E1B8: sll         $t8, $t9, 12
    ctx->r24 = S32(ctx->r25 << 12);
    // 0x8012E1BC: or          $t9, $t8, $t5
    ctx->r25 = ctx->r24 | ctx->r13;
    // 0x8012E1C0: sw          $t9, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r25;
    // 0x8012E1C4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E1C8: lui         $t7, 0xB400
    ctx->r15 = S32(0XB400 << 16);
    // 0x8012E1CC: lui         $t5, 0xB300
    ctx->r13 = S32(0XB300 << 16);
    // 0x8012E1D0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012E1D4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012E1D8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012E1DC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012E1E0: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x8012E1E4: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012E1E8: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012E1EC: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x8012E1F0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8012E1F4: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012E1F8: lwc1        $f10, 0x0($s4)
    ctx->f10.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E1FC: addiu       $t3, $t3, -0xE0D
    ctx->r11 = ADD32(ctx->r11, -0XE0D);
    // 0x8012E200: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012E204: div.s       $f16, $f20, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f20.fl, ctx->f10.fl);
    // 0x8012E208: addiu       $t2, $t2, -0xE0E
    ctx->r10 = ADD32(ctx->r10, -0XE0E);
    // 0x8012E20C: addiu       $t1, $t1, -0xE0F
    ctx->r9 = ADD32(ctx->r9, -0XE0F);
    // 0x8012E210: addiu       $t0, $t0, -0xE10
    ctx->r8 = ADD32(ctx->r8, -0XE10);
    // 0x8012E214: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012E218: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012E21C: nop

    // 0x8012E220: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012E224: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012E228: nop

    // 0x8012E22C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012E230: beql        $t6, $zero, L_8012E280
    if (ctx->r14 == 0) {
        // 0x8012E234: mfc1        $t6, $f18
        ctx->r14 = (int32_t)ctx->f18.u32l;
            goto L_8012E280;
    }
    goto skip_0;
    // 0x8012E234: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    skip_0:
    // 0x8012E238: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012E23C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012E240: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x8012E244: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012E248: nop

    // 0x8012E24C: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012E250: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012E254: nop

    // 0x8012E258: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012E25C: bne         $t6, $zero, L_8012E274
    if (ctx->r14 != 0) {
        // 0x8012E260: nop
    
            goto L_8012E274;
    }
    // 0x8012E260: nop

    // 0x8012E264: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x8012E268: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012E26C: b           L_8012E28C
    // 0x8012E270: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_8012E28C;
    // 0x8012E270: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_8012E274:
    // 0x8012E274: b           L_8012E28C
    // 0x8012E278: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_8012E28C;
    // 0x8012E278: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8012E27C: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
L_8012E280:
    // 0x8012E280: nop

    // 0x8012E284: bltz        $t6, L_8012E274
    if (SIGNED(ctx->r14) < 0) {
        // 0x8012E288: nop
    
            goto L_8012E274;
    }
    // 0x8012E288: nop

L_8012E28C:
    // 0x8012E28C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012E290: lwc1        $f4, 0x0($s7)
    ctx->f4.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012E294: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012E298: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8012E29C: div.s       $f6, $f20, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f20.fl, ctx->f4.fl);
    // 0x8012E2A0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012E2A4: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8012E2A8: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012E2AC: nop

    // 0x8012E2B0: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012E2B4: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012E2B8: nop

    // 0x8012E2BC: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012E2C0: beql        $t9, $zero, L_8012E310
    if (ctx->r25 == 0) {
        // 0x8012E2C4: mfc1        $t9, $f8
        ctx->r25 = (int32_t)ctx->f8.u32l;
            goto L_8012E310;
    }
    goto skip_1;
    // 0x8012E2C4: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    skip_1:
    // 0x8012E2C8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012E2CC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8012E2D0: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012E2D4: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012E2D8: nop

    // 0x8012E2DC: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012E2E0: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012E2E4: nop

    // 0x8012E2E8: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8012E2EC: bne         $t9, $zero, L_8012E304
    if (ctx->r25 != 0) {
        // 0x8012E2F0: nop
    
            goto L_8012E304;
    }
    // 0x8012E2F0: nop

    // 0x8012E2F4: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x8012E2F8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012E2FC: b           L_8012E31C
    // 0x8012E300: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8012E31C;
    // 0x8012E300: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8012E304:
    // 0x8012E304: b           L_8012E31C
    // 0x8012E308: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8012E31C;
    // 0x8012E308: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8012E30C: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
L_8012E310:
    // 0x8012E310: nop

    // 0x8012E314: bltz        $t9, L_8012E304
    if (SIGNED(ctx->r25) < 0) {
        // 0x8012E318: nop
    
            goto L_8012E304;
    }
    // 0x8012E318: nop

L_8012E31C:
    // 0x8012E31C: andi        $t6, $t9, 0xFFFF
    ctx->r14 = ctx->r25 & 0XFFFF;
    // 0x8012E320: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8012E324: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x8012E328: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E32C: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8012E330: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8012E334: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8012E338: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012E33C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012E340: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012E344: lbu         $t6, 0x0($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X0);
    // 0x8012E348: lui         $t5, 0xFB00
    ctx->r13 = S32(0XFB00 << 16);
    // 0x8012E34C: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x8012E350: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012E354: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012E358: or          $t6, $t7, $t8
    ctx->r14 = ctx->r15 | ctx->r24;
    // 0x8012E35C: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x8012E360: lbu         $t9, 0x0($t3)
    ctx->r25 = MEM_BU(ctx->r11, 0X0);
    // 0x8012E364: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8012E368: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x8012E36C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012E370: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E374: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012E378: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012E37C: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8012E380: lbu         $t5, 0x0($t1)
    ctx->r13 = MEM_BU(ctx->r9, 0X0);
    // 0x8012E384: lbu         $t9, 0x0($t0)
    ctx->r25 = MEM_BU(ctx->r8, 0X0);
    // 0x8012E388: sll         $t8, $t5, 16
    ctx->r24 = S32(ctx->r13 << 16);
    // 0x8012E38C: lbu         $t5, 0x0($t2)
    ctx->r13 = MEM_BU(ctx->r10, 0X0);
    // 0x8012E390: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x8012E394: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x8012E398: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x8012E39C: lbu         $t5, 0x0($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X0);
    // 0x8012E3A0: or          $t8, $t9, $t6
    ctx->r24 = ctx->r25 | ctx->r14;
    // 0x8012E3A4: or          $t9, $t8, $t5
    ctx->r25 = ctx->r24 | ctx->r13;
    // 0x8012E3A8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
L_8012E3AC:
    // 0x8012E3AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E3B0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012E3B4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8012E3B8: lwc1        $f10, 0x0($s4)
    ctx->f10.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E3BC: lwc1        $f18, 0x0($s7)
    ctx->f18.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012E3C0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x8012E3C4: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012E3C8: bgez        $a3, L_8012E3D8
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8012E3CC: sra         $t7, $a3, 1
        ctx->r15 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8012E3D8;
    }
    // 0x8012E3CC: sra         $t7, $a3, 1
    ctx->r15 = S32(SIGNED(ctx->r7) >> 1);
    // 0x8012E3D0: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x8012E3D4: sra         $t7, $at, 1
    ctx->r15 = S32(SIGNED(ctx->r1) >> 1);
L_8012E3D8:
    // 0x8012E3D8: mfc1        $t5, $f16
    ctx->r13 = (int32_t)ctx->f16.u32l;
    // 0x8012E3DC: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x8012E3E0: addu        $a2, $s3, $t7
    ctx->r6 = ADD32(ctx->r19, ctx->r15);
    // 0x8012E3E4: addu        $t9, $a2, $t5
    ctx->r25 = ADD32(ctx->r6, ctx->r13);
    // 0x8012E3E8: sll         $t6, $t9, 2
    ctx->r14 = S32(ctx->r25 << 2);
    // 0x8012E3EC: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x8012E3F0: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    // 0x8012E3F4: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x8012E3F8: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012E3FC: or          $t5, $t8, $at
    ctx->r13 = ctx->r24 | ctx->r1;
    // 0x8012E400: addu        $t7, $fp, $t6
    ctx->r15 = ADD32(ctx->r30, ctx->r14);
    // 0x8012E404: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8012E408: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8012E40C: or          $t6, $t5, $t9
    ctx->r14 = ctx->r13 | ctx->r25;
    // 0x8012E410: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8012E414: lw          $t9, 0x58($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X58);
    // 0x8012E418: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x8012E41C: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8012E420: sll         $t5, $t8, 12
    ctx->r13 = S32(ctx->r24 << 12);
    // 0x8012E424: or          $t6, $t5, $t9
    ctx->r14 = ctx->r13 | ctx->r25;
    // 0x8012E428: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8012E42C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E430: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x8012E434: lui         $t9, 0xB300
    ctx->r25 = S32(0XB300 << 16);
    // 0x8012E438: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012E43C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012E440: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012E444: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012E448: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x8012E44C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012E450: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012E454: addiu       $t5, $a1, 0x8
    ctx->r13 = ADD32(ctx->r5, 0X8);
    // 0x8012E458: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8012E45C: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x8012E460: lwc1        $f6, 0x0($s4)
    ctx->f6.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E464: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8012E468: div.s       $f8, $f20, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f20.fl, ctx->f6.fl);
    // 0x8012E46C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012E470: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012E474: nop

    // 0x8012E478: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012E47C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012E480: nop

    // 0x8012E484: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012E488: beql        $t7, $zero, L_8012E4D8
    if (ctx->r15 == 0) {
        // 0x8012E48C: mfc1        $t7, $f10
        ctx->r15 = (int32_t)ctx->f10.u32l;
            goto L_8012E4D8;
    }
    goto skip_2;
    // 0x8012E48C: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    skip_2:
    // 0x8012E490: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012E494: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012E498: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x8012E49C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012E4A0: nop

    // 0x8012E4A4: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012E4A8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012E4AC: nop

    // 0x8012E4B0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012E4B4: bne         $t7, $zero, L_8012E4CC
    if (ctx->r15 != 0) {
        // 0x8012E4B8: nop
    
            goto L_8012E4CC;
    }
    // 0x8012E4B8: nop

    // 0x8012E4BC: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x8012E4C0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012E4C4: b           L_8012E4E4
    // 0x8012E4C8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012E4E4;
    // 0x8012E4C8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012E4CC:
    // 0x8012E4CC: b           L_8012E4E4
    // 0x8012E4D0: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012E4E4;
    // 0x8012E4D0: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012E4D4: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
L_8012E4D8:
    // 0x8012E4D8: nop

    // 0x8012E4DC: bltz        $t7, L_8012E4CC
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012E4E0: nop
    
            goto L_8012E4CC;
    }
    // 0x8012E4E0: nop

L_8012E4E4:
    // 0x8012E4E4: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012E4E8: lwc1        $f16, 0x0($s7)
    ctx->f16.u32l = MEM_W(ctx->r23, 0X0);
    // 0x8012E4EC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012E4F0: sll         $t5, $t7, 16
    ctx->r13 = S32(ctx->r15 << 16);
    // 0x8012E4F4: div.s       $f18, $f20, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f20.fl, ctx->f16.fl);
    // 0x8012E4F8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012E4FC: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8012E500: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012E504: nop

    // 0x8012E508: cvt.w.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012E50C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012E510: nop

    // 0x8012E514: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012E518: beql        $t6, $zero, L_8012E568
    if (ctx->r14 == 0) {
        // 0x8012E51C: mfc1        $t6, $f4
        ctx->r14 = (int32_t)ctx->f4.u32l;
            goto L_8012E568;
    }
    goto skip_3;
    // 0x8012E51C: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    skip_3:
    // 0x8012E520: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012E524: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012E528: sub.s       $f4, $f18, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x8012E52C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8012E530: nop

    // 0x8012E534: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012E538: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8012E53C: nop

    // 0x8012E540: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x8012E544: bne         $t6, $zero, L_8012E55C
    if (ctx->r14 != 0) {
        // 0x8012E548: nop
    
            goto L_8012E55C;
    }
    // 0x8012E548: nop

    // 0x8012E54C: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    // 0x8012E550: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012E554: b           L_8012E574
    // 0x8012E558: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_8012E574;
    // 0x8012E558: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_8012E55C:
    // 0x8012E55C: b           L_8012E574
    // 0x8012E560: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_8012E574;
    // 0x8012E560: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8012E564: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
L_8012E568:
    // 0x8012E568: nop

    // 0x8012E56C: bltz        $t6, L_8012E55C
    if (SIGNED(ctx->r14) < 0) {
        // 0x8012E570: nop
    
            goto L_8012E55C;
    }
    // 0x8012E570: nop

L_8012E574:
    // 0x8012E574: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x8012E578: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x8012E57C: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x8012E580: lbu         $v0, -0xE0C($v0)
    ctx->r2 = MEM_BU(ctx->r2, -0XE0C);
    // 0x8012E584: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8012E588: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012E58C: beql        $v0, $zero, L_8012E5A8
    if (ctx->r2 == 0) {
        // 0x8012E590: lw          $t9, 0x0($s1)
        ctx->r25 = MEM_W(ctx->r17, 0X0);
            goto L_8012E5A8;
    }
    goto skip_4;
    // 0x8012E590: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    skip_4:
    // 0x8012E594: beql        $v0, $at, L_8012E5FC
    if (ctx->r2 == ctx->r1) {
        // 0x8012E598: mtc1        $s2, $f10
        ctx->f10.u32l = ctx->r18;
            goto L_8012E5FC;
    }
    goto skip_5;
    // 0x8012E598: mtc1        $s2, $f10
    ctx->f10.u32l = ctx->r18;
    skip_5:
    // 0x8012E59C: b           L_8012E6AC
    // 0x8012E5A0: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
        goto L_8012E6AC;
    // 0x8012E5A0: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012E5A4: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
L_8012E5A8:
    // 0x8012E5A8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012E5AC: lbu         $t6, 0x0($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X0);
    // 0x8012E5B0: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x8012E5B4: bgez        $t6, L_8012E5C8
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012E5B8: cvt.s.w     $f12, $f6
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8012E5C8;
    }
    // 0x8012E5B8: cvt.s.w     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8012E5BC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012E5C0: nop

    // 0x8012E5C4: add.s       $f12, $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f8.fl;
L_8012E5C8:
    // 0x8012E5C8: jal         0x8012C314
    // 0x8012E5CC: nop

    get_glyph_width(rdram, ctx);
        goto after_4;
    // 0x8012E5CC: nop

    after_4:
    // 0x8012E5D0: c.lt.s      $f24, $f22
    CHECK_FR(ctx, 24);
    CHECK_FR(ctx, 22);
    c1cs = ctx->f24.fl < ctx->f22.fl;
    // 0x8012E5D4: addu        $s2, $s6, $v0
    ctx->r18 = ADD32(ctx->r22, ctx->r2);
    // 0x8012E5D8: andi        $t5, $s2, 0xFFFF
    ctx->r13 = ctx->r18 & 0XFFFF;
    // 0x8012E5DC: or          $s2, $t5, $zero
    ctx->r18 = ctx->r13 | 0;
    // 0x8012E5E0: bc1fl       L_8012E6AC
    if (!c1cs) {
        // 0x8012E5E4: lw          $t6, 0x0($s1)
        ctx->r14 = MEM_W(ctx->r17, 0X0);
            goto L_8012E6AC;
    }
    goto skip_6;
    // 0x8012E5E4: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    skip_6:
    // 0x8012E5E8: addiu       $s2, $t5, 0x1
    ctx->r18 = ADD32(ctx->r13, 0X1);
    // 0x8012E5EC: andi        $t7, $s2, 0xFFFF
    ctx->r15 = ctx->r18 & 0XFFFF;
    // 0x8012E5F0: b           L_8012E6A8
    // 0x8012E5F4: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
        goto L_8012E6A8;
    // 0x8012E5F4: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
    // 0x8012E5F8: mtc1        $s2, $f10
    ctx->f10.u32l = ctx->r18;
L_8012E5FC:
    // 0x8012E5FC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012E600: bgez        $s2, L_8012E614
    if (SIGNED(ctx->r18) >= 0) {
        // 0x8012E604: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8012E614;
    }
    // 0x8012E604: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8012E608: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012E60C: nop

    // 0x8012E610: add.s       $f16, $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f18.fl;
L_8012E614:
    // 0x8012E614: lwc1        $f4, 0x0($s4)
    ctx->f4.u32l = MEM_W(ctx->r20, 0X0);
    // 0x8012E618: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x8012E61C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012E620: add.s       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x8012E624: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012E628: ctc1        $s2, $FpcCsr
    set_cop1_cs(ctx->r18);
    // 0x8012E62C: nop

    // 0x8012E630: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012E634: cfc1        $s2, $FpcCsr
    ctx->r18 = get_cop1_cs();
    // 0x8012E638: nop

    // 0x8012E63C: andi        $s2, $s2, 0x78
    ctx->r18 = ctx->r18 & 0X78;
    // 0x8012E640: beql        $s2, $zero, L_8012E690
    if (ctx->r18 == 0) {
        // 0x8012E644: mfc1        $s2, $f8
        ctx->r18 = (int32_t)ctx->f8.u32l;
            goto L_8012E690;
    }
    goto skip_7;
    // 0x8012E644: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
    skip_7:
    // 0x8012E648: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012E64C: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x8012E650: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012E654: ctc1        $s2, $FpcCsr
    set_cop1_cs(ctx->r18);
    // 0x8012E658: nop

    // 0x8012E65C: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012E660: cfc1        $s2, $FpcCsr
    ctx->r18 = get_cop1_cs();
    // 0x8012E664: nop

    // 0x8012E668: andi        $s2, $s2, 0x78
    ctx->r18 = ctx->r18 & 0X78;
    // 0x8012E66C: bne         $s2, $zero, L_8012E684
    if (ctx->r18 != 0) {
        // 0x8012E670: nop
    
            goto L_8012E684;
    }
    // 0x8012E670: nop

    // 0x8012E674: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
    // 0x8012E678: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012E67C: b           L_8012E69C
    // 0x8012E680: or          $s2, $s2, $at
    ctx->r18 = ctx->r18 | ctx->r1;
        goto L_8012E69C;
    // 0x8012E680: or          $s2, $s2, $at
    ctx->r18 = ctx->r18 | ctx->r1;
L_8012E684:
    // 0x8012E684: b           L_8012E69C
    // 0x8012E688: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
        goto L_8012E69C;
    // 0x8012E688: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
    // 0x8012E68C: mfc1        $s2, $f8
    ctx->r18 = (int32_t)ctx->f8.u32l;
L_8012E690:
    // 0x8012E690: nop

    // 0x8012E694: bltz        $s2, L_8012E684
    if (SIGNED(ctx->r18) < 0) {
        // 0x8012E698: nop
    
            goto L_8012E684;
    }
    // 0x8012E698: nop

L_8012E69C:
    // 0x8012E69C: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012E6A0: andi        $t9, $s2, 0xFFFF
    ctx->r25 = ctx->r18 & 0XFFFF;
    // 0x8012E6A4: or          $s2, $t9, $zero
    ctx->r18 = ctx->r25 | 0;
L_8012E6A8:
    // 0x8012E6A8: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
L_8012E6AC:
    // 0x8012E6AC: lw          $v1, 0xB4($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XB4);
    // 0x8012E6B0: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012E6B4: subu        $t5, $t6, $s5
    ctx->r13 = SUB32(ctx->r14, ctx->r21);
    // 0x8012E6B8: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x8012E6BC: lh          $v0, 0x2($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2);
    // 0x8012E6C0: addiu       $v1, $v1, 0x2
    ctx->r3 = ADD32(ctx->r3, 0X2);
    // 0x8012E6C4: sw          $v1, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->r3;
    // 0x8012E6C8: bnel        $v0, $at, L_8012E058
    if (ctx->r2 != ctx->r1) {
        // 0x8012E6CC: lw          $t7, 0x0($s1)
        ctx->r15 = MEM_W(ctx->r17, 0X0);
            goto L_8012E058;
    }
    goto skip_8;
    // 0x8012E6CC: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    skip_8:
L_8012E6D0:
    // 0x8012E6D0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8012E6D4: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x8012E6D8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012E6DC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012E6E0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012E6E4: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012E6E8: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x8012E6EC: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x8012E6F0: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x8012E6F4: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x8012E6F8: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x8012E6FC: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x8012E700: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x8012E704: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x8012E708: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x8012E70C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8012E710: ldc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X28);
    // 0x8012E714: ldc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X20);
    // 0x8012E718: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x8012E71C: jr          $ra
    // 0x8012E720: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
    return;
    // 0x8012E720: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
;}
RECOMP_FUNC void get_char_type(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012E724: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012E728: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8012E72C: lh          $v0, 0x0($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X0);
    // 0x8012E730: addiu       $at, $zero, 0x150
    ctx->r1 = ADD32(0, 0X150);
    // 0x8012E734: bne         $v0, $at, L_8012E76C
    if (ctx->r2 != ctx->r1) {
        // 0x8012E738: andi        $t6, $v0, 0xFFFF
        ctx->r14 = ctx->r2 & 0XFFFF;
            goto L_8012E76C;
    }
    // 0x8012E738: andi        $t6, $v0, 0xFFFF
    ctx->r14 = ctx->r2 & 0XFFFF;
    // 0x8012E73C: lh          $v0, 0x2($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X2);
    // 0x8012E740: addiu       $at, $zero, 0x157
    ctx->r1 = ADD32(0, 0X157);
    // 0x8012E744: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8012E748: bnel        $v0, $at, L_8012E75C
    if (ctx->r2 != ctx->r1) {
        // 0x8012E74C: addiu       $at, $zero, 0x153
        ctx->r1 = ADD32(0, 0X153);
            goto L_8012E75C;
    }
    goto skip_0;
    // 0x8012E74C: addiu       $at, $zero, 0x153
    ctx->r1 = ADD32(0, 0X153);
    skip_0:
    // 0x8012E750: jr          $ra
    // 0x8012E754: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x8012E754: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8012E758: addiu       $at, $zero, 0x153
    ctx->r1 = ADD32(0, 0X153);
L_8012E75C:
    // 0x8012E75C: bnel        $v0, $at, L_8012E784
    if (ctx->r2 != ctx->r1) {
        // 0x8012E760: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8012E784;
    }
    goto skip_1;
    // 0x8012E760: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x8012E764: jr          $ra
    // 0x8012E768: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
    return;
    // 0x8012E768: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8012E76C:
    // 0x8012E76C: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    // 0x8012E770: bnel        $t6, $at, L_8012E784
    if (ctx->r14 != ctx->r1) {
        // 0x8012E774: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8012E784;
    }
    goto skip_2;
    // 0x8012E774: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x8012E778: jr          $ra
    // 0x8012E77C: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
    return;
    // 0x8012E77C: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
    // 0x8012E780: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8012E784:
    // 0x8012E784: jr          $ra
    // 0x8012E788: nop

    return;
    // 0x8012E788: nop

;}
RECOMP_FUNC void func_8012E78C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012E78C: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8012E790: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x8012E794: lwc1        $f4, 0x64($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X64);
    // 0x8012E798: mtc1        $a2, $f12
    ctx->f12.u32l = ctx->r6;
    // 0x8012E79C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012E7A0: swc1        $f4, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f4.u32l;
    // 0x8012E7A4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012E7A8: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8012E7AC: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8012E7B0: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x8012E7B4: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8012E7B8: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8012E7BC: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012E7C0: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012E7C4: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012E7C8: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012E7CC: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012E7D0: sw          $a3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r7;
    // 0x8012E7D4: swc1        $f12, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f12.u32l;
    // 0x8012E7D8: lh          $t7, 0x0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X0);
    // 0x8012E7DC: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x8012E7E0: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012E7E4: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8012E7E8: or          $s3, $a0, $zero
    ctx->r19 = ctx->r4 | 0;
    // 0x8012E7EC: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x8012E7F0: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x8012E7F4: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
    // 0x8012E7F8: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x8012E7FC: beq         $t7, $at, L_8012EB00
    if (ctx->r15 == ctx->r1) {
        // 0x8012E800: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_8012EB00;
    }
    // 0x8012E800: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8012E804: lui         $s4, 0x8024
    ctx->r20 = S32(0X8024 << 16);
    // 0x8012E808: addiu       $s4, $s4, -0xE20
    ctx->r20 = ADD32(ctx->r20, -0XE20);
    // 0x8012E80C: addiu       $s7, $zero, 0x130
    ctx->r23 = ADD32(0, 0X130);
    // 0x8012E810: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
L_8012E814:
    // 0x8012E814: andi        $a1, $s0, 0xFFFF
    ctx->r5 = ctx->r16 & 0XFFFF;
    // 0x8012E818: andi        $a2, $t0, 0xFFFF
    ctx->r6 = ctx->r8 & 0XFFFF;
    // 0x8012E81C: sb          $a3, 0x6F($sp)
    MEM_B(0X6F, ctx->r29) = ctx->r7;
    // 0x8012E820: sh          $t0, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r8;
    // 0x8012E824: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    // 0x8012E828: jal         0x8012E724
    // 0x8012E82C: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    get_char_type(rdram, ctx);
        goto after_0;
    // 0x8012E82C: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    after_0:
    // 0x8012E830: lbu         $a3, 0x6F($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X6F);
    // 0x8012E834: lh          $t0, 0x48($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X48);
    // 0x8012E838: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x8012E83C: beq         $v0, $zero, L_8012E88C
    if (ctx->r2 == 0) {
        // 0x8012E840: lhu         $t2, 0x58($sp)
        ctx->r10 = MEM_HU(ctx->r29, 0X58);
            goto L_8012E88C;
    }
    // 0x8012E840: lhu         $t2, 0x58($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X58);
    // 0x8012E844: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012E848: beq         $v0, $at, L_8012E868
    if (ctx->r2 == ctx->r1) {
        // 0x8012E84C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8012E868;
    }
    // 0x8012E84C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012E850: beq         $v0, $at, L_8012E880
    if (ctx->r2 == ctx->r1) {
        // 0x8012E854: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8012E880;
    }
    // 0x8012E854: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012E858: beql        $v0, $at, L_8012EAB8
    if (ctx->r2 == ctx->r1) {
        // 0x8012E85C: lh          $v0, 0x2($s3)
        ctx->r2 = MEM_H(ctx->r19, 0X2);
            goto L_8012EAB8;
    }
    goto skip_0;
    // 0x8012E85C: lh          $v0, 0x2($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X2);
    skip_0:
    // 0x8012E860: b           L_8012EAF4
    // 0x8012E864: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
        goto L_8012EAF4;
    // 0x8012E864: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
L_8012E868:
    // 0x8012E868: addiu       $s6, $s6, 0x14
    ctx->r22 = ADD32(ctx->r22, 0X14);
    // 0x8012E86C: sll         $t8, $s6, 16
    ctx->r24 = S32(ctx->r22 << 16);
    // 0x8012E870: sra         $s6, $t8, 16
    ctx->r22 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012E874: addiu       $s3, $s3, 0x8
    ctx->r19 = ADD32(ctx->r19, 0X8);
    // 0x8012E878: b           L_8012EAF4
    // 0x8012E87C: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
        goto L_8012EAF4;
    // 0x8012E87C: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
L_8012E880:
    // 0x8012E880: addiu       $s3, $s3, 0x6
    ctx->r19 = ADD32(ctx->r19, 0X6);
    // 0x8012E884: b           L_8012EAF4
    // 0x8012E888: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
        goto L_8012EAF4;
    // 0x8012E888: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
L_8012E88C:
    // 0x8012E88C: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
    // 0x8012E890: lw          $t3, 0x0($s4)
    ctx->r11 = MEM_W(ctx->r20, 0X0);
    // 0x8012E894: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x8012E898: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012E89C: addu        $t4, $t3, $v0
    ctx->r12 = ADD32(ctx->r11, ctx->r2);
    // 0x8012E8A0: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8012E8A4: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012E8A8: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x8012E8AC: bgez        $t6, L_8012E8C0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012E8B0: cvt.s.w     $f12, $f6
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8012E8C0;
    }
    // 0x8012E8B0: cvt.s.w     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    ctx->f12.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8012E8B4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012E8B8: nop

    // 0x8012E8BC: add.s       $f12, $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f8.fl;
L_8012E8C0:
    // 0x8012E8C0: sh          $v0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r2;
    // 0x8012E8C4: sb          $a3, 0x6F($sp)
    MEM_B(0X6F, ctx->r29) = ctx->r7;
    // 0x8012E8C8: sh          $t0, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r8;
    // 0x8012E8CC: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    // 0x8012E8D0: jal         0x8012C314
    // 0x8012E8D4: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    get_glyph_width(rdram, ctx);
        goto after_1;
    // 0x8012E8D4: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    after_1:
    // 0x8012E8D8: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8012E8DC: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8012E8E0: lwc1        $f10, 0x64($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X64);
    // 0x8012E8E4: addu        $s6, $s6, $v0
    ctx->r22 = ADD32(ctx->r22, ctx->r2);
    // 0x8012E8E8: sll         $t7, $s6, 16
    ctx->r15 = S32(ctx->r22 << 16);
    // 0x8012E8EC: c.lt.s      $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f10.fl < ctx->f16.fl;
    // 0x8012E8F0: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012E8F4: or          $s6, $t8, $zero
    ctx->r22 = ctx->r24 | 0;
    // 0x8012E8F8: lbu         $a3, 0x6F($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X6F);
    // 0x8012E8FC: lh          $t0, 0x48($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X48);
    // 0x8012E900: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x8012E904: bc1f        L_8012E918
    if (!c1cs) {
        // 0x8012E908: lhu         $t2, 0x58($sp)
        ctx->r10 = MEM_HU(ctx->r29, 0X58);
            goto L_8012E918;
    }
    // 0x8012E908: lhu         $t2, 0x58($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X58);
    // 0x8012E90C: addiu       $s6, $t8, 0x1
    ctx->r22 = ADD32(ctx->r24, 0X1);
    // 0x8012E910: sll         $t9, $s6, 16
    ctx->r25 = S32(ctx->r22 << 16);
    // 0x8012E914: sra         $s6, $t9, 16
    ctx->r22 = S32(SIGNED(ctx->r25) >> 16);
L_8012E918:
    // 0x8012E918: lh          $t4, 0x0($s3)
    ctx->r12 = MEM_H(ctx->r19, 0X0);
    // 0x8012E91C: addiu       $a0, $s6, -0x1
    ctx->r4 = ADD32(ctx->r22, -0X1);
    // 0x8012E920: andi        $fp, $a0, 0xFFFF
    ctx->r30 = ctx->r4 & 0XFFFF;
    // 0x8012E924: bne         $s7, $t4, L_8012EA28
    if (ctx->r23 != ctx->r12) {
        // 0x8012E928: nop
    
            goto L_8012EA28;
    }
    // 0x8012E928: nop

    // 0x8012E92C: lh          $t5, 0x2($s3)
    ctx->r13 = MEM_H(ctx->r19, 0X2);
    // 0x8012E930: addiu       $v0, $s3, 0x2
    ctx->r2 = ADD32(ctx->r19, 0X2);
    // 0x8012E934: andi        $v1, $a0, 0xFFFF
    ctx->r3 = ctx->r4 & 0XFFFF;
    // 0x8012E938: beq         $s7, $t5, L_8012EA28
    if (ctx->r23 == ctx->r13) {
        // 0x8012E93C: or          $s2, $v0, $zero
        ctx->r18 = ctx->r2 | 0;
            goto L_8012EA28;
    }
    // 0x8012E93C: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
    // 0x8012E940: lh          $a0, 0x0($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X0);
    // 0x8012E944: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012E948: beq         $a0, $at, L_8012EA28
    if (ctx->r4 == ctx->r1) {
        // 0x8012E94C: addiu       $at, $zero, 0x4E20
        ctx->r1 = ADD32(0, 0X4E20);
            goto L_8012EA28;
    }
    // 0x8012E94C: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    // 0x8012E950: beq         $a0, $at, L_8012EA28
    if (ctx->r4 == ctx->r1) {
        // 0x8012E954: or          $s1, $v1, $zero
        ctx->r17 = ctx->r3 | 0;
            goto L_8012EA28;
    }
    // 0x8012E954: or          $s1, $v1, $zero
    ctx->r17 = ctx->r3 | 0;
    // 0x8012E958: lh          $v0, 0x0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X0);
    // 0x8012E95C: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
L_8012E960:
    // 0x8012E960: andi        $s0, $v0, 0xFF
    ctx->r16 = ctx->r2 & 0XFF;
    // 0x8012E964: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012E968: addu        $t7, $t6, $s0
    ctx->r15 = ADD32(ctx->r14, ctx->r16);
    // 0x8012E96C: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x8012E970: lbu         $t9, 0x0($t7)
    ctx->r25 = MEM_BU(ctx->r15, 0X0);
    // 0x8012E974: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8012E978: bgez        $t9, L_8012E98C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8012E97C: cvt.s.w     $f12, $f18
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
            goto L_8012E98C;
    }
    // 0x8012E97C: cvt.s.w     $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8012E980: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012E984: nop

    // 0x8012E988: add.s       $f12, $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f4.fl;
L_8012E98C:
    // 0x8012E98C: sb          $a3, 0x6F($sp)
    MEM_B(0X6F, ctx->r29) = ctx->r7;
    // 0x8012E990: sh          $t0, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r8;
    // 0x8012E994: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    // 0x8012E998: jal         0x8012C314
    // 0x8012E99C: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    get_glyph_width(rdram, ctx);
        goto after_2;
    // 0x8012E99C: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    after_2:
    // 0x8012E9A0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x8012E9A4: lh          $t4, 0x3FD0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD0);
    // 0x8012E9A8: addu        $v1, $s1, $v0
    ctx->r3 = ADD32(ctx->r17, ctx->r2);
    // 0x8012E9AC: andi        $s1, $v1, 0xFFFF
    ctx->r17 = ctx->r3 & 0XFFFF;
    // 0x8012E9B0: addiu       $t5, $t4, -0x32
    ctx->r13 = ADD32(ctx->r12, -0X32);
    // 0x8012E9B4: slt         $at, $s1, $t5
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x8012E9B8: lbu         $a3, 0x6F($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X6F);
    // 0x8012E9BC: lh          $t0, 0x48($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X48);
    // 0x8012E9C0: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x8012E9C4: bne         $at, $zero, L_8012E9F0
    if (ctx->r1 != 0) {
        // 0x8012E9C8: lhu         $t2, 0x58($sp)
        ctx->r10 = MEM_HU(ctx->r29, 0X58);
            goto L_8012E9F0;
    }
    // 0x8012E9C8: lhu         $t2, 0x58($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X58);
    // 0x8012E9CC: addu        $t0, $t0, $a3
    ctx->r8 = ADD32(ctx->r8, ctx->r7);
    // 0x8012E9D0: addiu       $t1, $t1, 0x1
    ctx->r9 = ADD32(ctx->r9, 0X1);
    // 0x8012E9D4: sll         $t6, $t0, 16
    ctx->r14 = S32(ctx->r8 << 16);
    // 0x8012E9D8: sll         $t8, $t1, 16
    ctx->r24 = S32(ctx->r9 << 16);
    // 0x8012E9DC: or          $fp, $zero, $zero
    ctx->r30 = 0 | 0;
    // 0x8012E9E0: sra         $t0, $t6, 16
    ctx->r8 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012E9E4: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x8012E9E8: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
    // 0x8012E9EC: sra         $t1, $t8, 16
    ctx->r9 = S32(SIGNED(ctx->r24) >> 16);
L_8012E9F0:
    // 0x8012E9F0: lw          $t3, 0x0($s4)
    ctx->r11 = MEM_W(ctx->r20, 0X0);
    // 0x8012E9F4: addiu       $s2, $s2, 0x2
    ctx->r18 = ADD32(ctx->r18, 0X2);
    // 0x8012E9F8: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012E9FC: subu        $t4, $t3, $s0
    ctx->r12 = SUB32(ctx->r11, ctx->r16);
    // 0x8012EA00: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8012EA04: lh          $v0, 0x0($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X0);
    // 0x8012EA08: beq         $s7, $v0, L_8012EA28
    if (ctx->r23 == ctx->r2) {
        // 0x8012EA0C: nop
    
            goto L_8012EA28;
    }
    // 0x8012EA0C: nop

    // 0x8012EA10: beq         $v0, $at, L_8012EA28
    if (ctx->r2 == ctx->r1) {
        // 0x8012EA14: nop
    
            goto L_8012EA28;
    }
    // 0x8012EA14: nop

    // 0x8012EA18: bne         $s5, $zero, L_8012EA28
    if (ctx->r21 != 0) {
        // 0x8012EA1C: addiu       $at, $zero, 0x4E20
        ctx->r1 = ADD32(0, 0X4E20);
            goto L_8012EA28;
    }
    // 0x8012EA1C: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    // 0x8012EA20: bnel        $v0, $at, L_8012E960
    if (ctx->r2 != ctx->r1) {
        // 0x8012EA24: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012E960;
    }
    goto skip_1;
    // 0x8012EA24: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_1:
L_8012EA28:
    // 0x8012EA28: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8012EA2C: lb          $t5, -0xD52($t5)
    ctx->r13 = MEM_B(ctx->r13, -0XD52);
    // 0x8012EA30: addiu       $v0, $s3, 0x2
    ctx->r2 = ADD32(ctx->r19, 0X2);
    // 0x8012EA34: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8012EA38: bne         $t5, $at, L_8012EA68
    if (ctx->r13 != ctx->r1) {
        // 0x8012EA3C: or          $s3, $v0, $zero
        ctx->r19 = ctx->r2 | 0;
            goto L_8012EA68;
    }
    // 0x8012EA3C: or          $s3, $v0, $zero
    ctx->r19 = ctx->r2 | 0;
    // 0x8012EA40: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8012EA44: lh          $t6, 0x3FD0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X3FD0);
    // 0x8012EA48: addiu       $t7, $t6, -0x3C
    ctx->r15 = ADD32(ctx->r14, -0X3C);
    // 0x8012EA4C: slt         $at, $fp, $t7
    ctx->r1 = SIGNED(ctx->r30) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x8012EA50: bnel        $at, $zero, L_8012EA6C
    if (ctx->r1 != 0) {
        // 0x8012EA54: lh          $t4, 0x0($v0)
        ctx->r12 = MEM_H(ctx->r2, 0X0);
            goto L_8012EA6C;
    }
    goto skip_2;
    // 0x8012EA54: lh          $t4, 0x0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X0);
    skip_2:
    // 0x8012EA58: addu        $t0, $t0, $a3
    ctx->r8 = ADD32(ctx->r8, ctx->r7);
    // 0x8012EA5C: sll         $t8, $t0, 16
    ctx->r24 = S32(ctx->r8 << 16);
    // 0x8012EA60: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012EA64: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
L_8012EA68:
    // 0x8012EA68: lh          $t4, 0x0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X0);
L_8012EA6C:
    // 0x8012EA6C: sll         $s0, $s6, 16
    ctx->r16 = S32(ctx->r22 << 16);
    // 0x8012EA70: sra         $t3, $s0, 16
    ctx->r11 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8012EA74: bne         $s7, $t4, L_8012EA9C
    if (ctx->r23 != ctx->r12) {
        // 0x8012EA78: or          $s0, $t3, $zero
        ctx->r16 = ctx->r11 | 0;
            goto L_8012EA9C;
    }
    // 0x8012EA78: or          $s0, $t3, $zero
    ctx->r16 = ctx->r11 | 0;
    // 0x8012EA7C: bnel        $s6, $zero, L_8012EAA0
    if (ctx->r22 != 0) {
        // 0x8012EA80: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EAA0;
    }
    goto skip_3;
    // 0x8012EA80: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_3:
    // 0x8012EA84: lh          $t5, 0x2($s3)
    ctx->r13 = MEM_H(ctx->r19, 0X2);
L_8012EA88:
    // 0x8012EA88: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EA8C: bnel        $s7, $t5, L_8012EAA0
    if (ctx->r23 != ctx->r13) {
        // 0x8012EA90: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EAA0;
    }
    goto skip_4;
    // 0x8012EA90: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_4:
    // 0x8012EA94: beql        $s6, $t2, L_8012EA88
    if (ctx->r22 == ctx->r10) {
        // 0x8012EA98: lh          $t5, 0x2($s3)
        ctx->r13 = MEM_H(ctx->r19, 0X2);
            goto L_8012EA88;
    }
    goto skip_5;
    // 0x8012EA98: lh          $t5, 0x2($s3)
    ctx->r13 = MEM_H(ctx->r19, 0X2);
    skip_5:
L_8012EA9C:
    // 0x8012EA9C: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
L_8012EAA0:
    // 0x8012EAA0: lh          $t7, 0x5E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X5E);
    // 0x8012EAA4: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x8012EAA8: sw          $t8, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r24;
    // 0x8012EAAC: b           L_8012EAF4
    // 0x8012EAB0: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
        goto L_8012EAF4;
    // 0x8012EAB0: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
    // 0x8012EAB4: lh          $v0, 0x2($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X2);
L_8012EAB8:
    // 0x8012EAB8: addu        $t0, $t0, $a3
    ctx->r8 = ADD32(ctx->r8, ctx->r7);
    // 0x8012EABC: addiu       $t1, $t1, 0x1
    ctx->r9 = ADD32(ctx->r9, 0X1);
    // 0x8012EAC0: sll         $t9, $t0, 16
    ctx->r25 = S32(ctx->r8 << 16);
    // 0x8012EAC4: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x8012EAC8: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012EACC: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x8012EAD0: sra         $t1, $t4, 16
    ctx->r9 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8012EAD4: bne         $s7, $v0, L_8012EAF4
    if (ctx->r23 != ctx->r2) {
        // 0x8012EAD8: addiu       $s3, $s3, 0x2
        ctx->r19 = ADD32(ctx->r19, 0X2);
            goto L_8012EAF4;
    }
    // 0x8012EAD8: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EADC: lh          $v0, 0x2($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X2);
L_8012EAE0:
    // 0x8012EAE0: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EAE4: bnel        $s7, $v0, L_8012EAF8
    if (ctx->r23 != ctx->r2) {
        // 0x8012EAE8: addiu       $at, $zero, 0x7530
        ctx->r1 = ADD32(0, 0X7530);
            goto L_8012EAF8;
    }
    goto skip_6;
    // 0x8012EAE8: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    skip_6:
    // 0x8012EAEC: beql        $s6, $t2, L_8012EAE0
    if (ctx->r22 == ctx->r10) {
        // 0x8012EAF0: lh          $v0, 0x2($s3)
        ctx->r2 = MEM_H(ctx->r19, 0X2);
            goto L_8012EAE0;
    }
    goto skip_7;
    // 0x8012EAF0: lh          $v0, 0x2($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X2);
    skip_7:
L_8012EAF4:
    // 0x8012EAF4: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
L_8012EAF8:
    // 0x8012EAF8: bnel        $v0, $at, L_8012E814
    if (ctx->r2 != ctx->r1) {
        // 0x8012EAFC: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_8012E814;
    }
    goto skip_8;
    // 0x8012EAFC: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    skip_8:
L_8012EB00:
    // 0x8012EB00: addiu       $t1, $t1, 0x1
    ctx->r9 = ADD32(ctx->r9, 0X1);
    // 0x8012EB04: sll         $t6, $t1, 16
    ctx->r14 = S32(ctx->r9 << 16);
    // 0x8012EB08: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012EB0C: multu       $t7, $a3
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012EB10: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8012EB14: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012EB18: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012EB1C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012EB20: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012EB24: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012EB28: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8012EB2C: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8012EB30: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x8012EB34: mflo        $v0
    ctx->r2 = lo;
    // 0x8012EB38: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8012EB3C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x8012EB40: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x8012EB44: jr          $ra
    // 0x8012EB48: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    return;
    // 0x8012EB48: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
;}
RECOMP_FUNC void display_text_word_wrapped(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012EB4C: addiu       $sp, $sp, -0x258
    ctx->r29 = ADD32(ctx->r29, -0X258);
    // 0x8012EB50: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x8012EB54: or          $s3, $a1, $zero
    ctx->r19 = ctx->r5 | 0;
    // 0x8012EB58: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8012EB5C: sw          $a0, 0x258($sp)
    MEM_W(0X258, ctx->r29) = ctx->r4;
    // 0x8012EB60: sw          $a1, 0x148($sp)
    MEM_W(0X148, ctx->r29) = ctx->r5;
    // 0x8012EB64: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x8012EB68: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x8012EB6C: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x8012EB70: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x8012EB74: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x8012EB78: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8012EB7C: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x8012EB80: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x8012EB84: sw          $a2, 0x260($sp)
    MEM_W(0X260, ctx->r29) = ctx->r6;
    // 0x8012EB88: sw          $a3, 0x264($sp)
    MEM_W(0X264, ctx->r29) = ctx->r7;
    // 0x8012EB8C: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x8012EB90: addiu       $a0, $sp, 0x124
    ctx->r4 = ADD32(ctx->r29, 0X124);
    // 0x8012EB94: sh          $zero, 0x13C($sp)
    MEM_H(0X13C, ctx->r29) = 0;
    // 0x8012EB98: jal         0x80128FB4
    // 0x8012EB9C: sh          $zero, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = 0;
    bzero_sssv(rdram, ctx);
        goto after_0;
    // 0x8012EB9C: sh          $zero, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = 0;
    after_0:
    // 0x8012EBA0: addiu       $a0, $sp, 0x110
    ctx->r4 = ADD32(ctx->r29, 0X110);
    // 0x8012EBA4: jal         0x80128FB4
    // 0x8012EBA8: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    bzero_sssv(rdram, ctx);
        goto after_1;
    // 0x8012EBA8: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    after_1:
    // 0x8012EBAC: lwc1        $f4, 0x268($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X268);
    // 0x8012EBB0: lwc1        $f6, 0x26C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X26C);
    // 0x8012EBB4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012EBB8: swc1        $f4, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f4.u32l;
    // 0x8012EBBC: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012EBC0: sh          $zero, 0x150($sp)
    MEM_H(0X150, ctx->r29) = 0;
    // 0x8012EBC4: swc1        $f6, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f6.u32l;
    // 0x8012EBC8: lh          $t6, 0x0($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X0);
    // 0x8012EBCC: addiu       $t3, $zero, 0x7530
    ctx->r11 = ADD32(0, 0X7530);
    // 0x8012EBD0: lh          $t0, 0x13C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X13C);
    // 0x8012EBD4: lh          $t1, 0x13A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X13A);
    // 0x8012EBD8: or          $s7, $zero, $zero
    ctx->r23 = 0 | 0;
    // 0x8012EBDC: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x8012EBE0: beq         $t3, $t6, L_8012EFCC
    if (ctx->r11 == ctx->r14) {
        // 0x8012EBE4: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_8012EFCC;
    }
    // 0x8012EBE4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8012EBE8: lui         $s4, 0x8024
    ctx->r20 = S32(0X8024 << 16);
    // 0x8012EBEC: addiu       $s4, $s4, -0xE20
    ctx->r20 = ADD32(ctx->r20, -0XE20);
    // 0x8012EBF0: addiu       $fp, $zero, 0x130
    ctx->r30 = ADD32(0, 0X130);
    // 0x8012EBF4: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
L_8012EBF8:
    // 0x8012EBF8: andi        $a1, $s0, 0xFFFF
    ctx->r5 = ctx->r16 & 0XFFFF;
    // 0x8012EBFC: andi        $a2, $t1, 0xFFFF
    ctx->r6 = ctx->r9 & 0XFFFF;
    // 0x8012EC00: sh          $t0, 0x13C($sp)
    MEM_H(0X13C, ctx->r29) = ctx->r8;
    // 0x8012EC04: sh          $t1, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = ctx->r9;
    // 0x8012EC08: jal         0x8012E724
    // 0x8012EC0C: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    get_char_type(rdram, ctx);
        goto after_2;
    // 0x8012EC0C: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    after_2:
    // 0x8012EC10: lh          $t0, 0x13C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X13C);
    // 0x8012EC14: lh          $t1, 0x13A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X13A);
    // 0x8012EC18: lh          $t2, 0x10E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X10E);
    // 0x8012EC1C: beq         $v0, $zero, L_8012ECAC
    if (ctx->r2 == 0) {
        // 0x8012EC20: addiu       $t3, $zero, 0x7530
        ctx->r11 = ADD32(0, 0X7530);
            goto L_8012ECAC;
    }
    // 0x8012EC20: addiu       $t3, $zero, 0x7530
    ctx->r11 = ADD32(0, 0X7530);
    // 0x8012EC24: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012EC28: beq         $v0, $at, L_8012EC50
    if (ctx->r2 == ctx->r1) {
        // 0x8012EC2C: sll         $t5, $t2, 1
        ctx->r13 = S32(ctx->r10 << 1);
            goto L_8012EC50;
    }
    // 0x8012EC2C: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
    // 0x8012EC30: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012EC34: beq         $v0, $at, L_8012EC84
    if (ctx->r2 == ctx->r1) {
        // 0x8012EC38: sll         $t5, $t2, 1
        ctx->r13 = S32(ctx->r10 << 1);
            goto L_8012EC84;
    }
    // 0x8012EC38: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
    // 0x8012EC3C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012EC40: beq         $v0, $at, L_8012EF44
    if (ctx->r2 == ctx->r1) {
        // 0x8012EC44: lbu         $t9, 0x273($sp)
        ctx->r25 = MEM_BU(ctx->r29, 0X273);
            goto L_8012EF44;
    }
    // 0x8012EC44: lbu         $t9, 0x273($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X273);
    // 0x8012EC48: b           L_8012EFC4
    // 0x8012EC4C: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
        goto L_8012EFC4;
    // 0x8012EC4C: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
L_8012EC50:
    // 0x8012EC50: addiu       $t0, $t0, 0x14
    ctx->r8 = ADD32(ctx->r8, 0X14);
    // 0x8012EC54: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x8012EC58: addiu       $t6, $sp, 0x124
    ctx->r14 = ADD32(ctx->r29, 0X124);
    // 0x8012EC5C: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012EC60: addu        $v0, $t5, $t6
    ctx->r2 = ADD32(ctx->r13, ctx->r14);
    // 0x8012EC64: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x8012EC68: addiu       $s7, $s7, 0x4
    ctx->r23 = ADD32(ctx->r23, 0X4);
    // 0x8012EC6C: sll         $t9, $s7, 16
    ctx->r25 = S32(ctx->r23 << 16);
    // 0x8012EC70: addiu       $t8, $t7, 0x4
    ctx->r24 = ADD32(ctx->r15, 0X4);
    // 0x8012EC74: sra         $s7, $t9, 16
    ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012EC78: addiu       $s3, $s3, 0x8
    ctx->r19 = ADD32(ctx->r19, 0X8);
    // 0x8012EC7C: b           L_8012EFC0
    // 0x8012EC80: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
        goto L_8012EFC0;
    // 0x8012EC80: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
L_8012EC84:
    // 0x8012EC84: addiu       $t6, $sp, 0x124
    ctx->r14 = ADD32(ctx->r29, 0X124);
    // 0x8012EC88: addu        $v0, $t5, $t6
    ctx->r2 = ADD32(ctx->r13, ctx->r14);
    // 0x8012EC8C: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x8012EC90: addiu       $s7, $s7, 0x3
    ctx->r23 = ADD32(ctx->r23, 0X3);
    // 0x8012EC94: sll         $t9, $s7, 16
    ctx->r25 = S32(ctx->r23 << 16);
    // 0x8012EC98: addiu       $t8, $t7, 0x3
    ctx->r24 = ADD32(ctx->r15, 0X3);
    // 0x8012EC9C: sra         $s7, $t9, 16
    ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012ECA0: addiu       $s3, $s3, 0x6
    ctx->r19 = ADD32(ctx->r19, 0X6);
    // 0x8012ECA4: b           L_8012EFC0
    // 0x8012ECA8: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
        goto L_8012EFC0;
    // 0x8012ECA8: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
L_8012ECAC:
    // 0x8012ECAC: lh          $v0, 0x0($s3)
    ctx->r2 = MEM_H(ctx->r19, 0X0);
    // 0x8012ECB0: lw          $t9, 0x0($s4)
    ctx->r25 = MEM_W(ctx->r20, 0X0);
    // 0x8012ECB4: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x8012ECB8: addu        $t4, $t9, $v0
    ctx->r12 = ADD32(ctx->r25, ctx->r2);
    // 0x8012ECBC: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8012ECC0: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012ECC4: lhu         $s5, 0x150($sp)
    ctx->r21 = MEM_HU(ctx->r29, 0X150);
    // 0x8012ECC8: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x8012ECCC: bgez        $t6, L_8012ECE4
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012ECD0: cvt.s.w     $f12, $f8
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
            goto L_8012ECE4;
    }
    // 0x8012ECD0: cvt.s.w     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8012ECD4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012ECD8: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012ECDC: nop

    // 0x8012ECE0: add.s       $f12, $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f10.fl;
L_8012ECE4:
    // 0x8012ECE4: sh          $v0, 0x256($sp)
    MEM_H(0X256, ctx->r29) = ctx->r2;
    // 0x8012ECE8: sh          $t0, 0x13C($sp)
    MEM_H(0X13C, ctx->r29) = ctx->r8;
    // 0x8012ECEC: sh          $t1, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = ctx->r9;
    // 0x8012ECF0: jal         0x8012C314
    // 0x8012ECF4: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    get_glyph_width(rdram, ctx);
        goto after_3;
    // 0x8012ECF4: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    after_3:
    // 0x8012ECF8: lh          $t0, 0x13C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X13C);
    // 0x8012ECFC: lh          $t9, 0x0($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X0);
    // 0x8012ED00: lh          $t1, 0x13A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X13A);
    // 0x8012ED04: addu        $t0, $t0, $v0
    ctx->r8 = ADD32(ctx->r8, ctx->r2);
    // 0x8012ED08: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x8012ED0C: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012ED10: addiu       $a2, $t0, -0x1
    ctx->r6 = ADD32(ctx->r8, -0X1);
    // 0x8012ED14: lh          $t2, 0x10E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X10E);
    // 0x8012ED18: addiu       $t3, $zero, 0x7530
    ctx->r11 = ADD32(0, 0X7530);
    // 0x8012ED1C: bne         $fp, $t9, L_8012EE5C
    if (ctx->r30 != ctx->r25) {
        // 0x8012ED20: andi        $a0, $a2, 0xFFFF
        ctx->r4 = ctx->r6 & 0XFFFF;
            goto L_8012EE5C;
    }
    // 0x8012ED20: andi        $a0, $a2, 0xFFFF
    ctx->r4 = ctx->r6 & 0XFFFF;
    // 0x8012ED24: lw          $t4, 0x0($s4)
    ctx->r12 = MEM_W(ctx->r20, 0X0);
    // 0x8012ED28: lh          $t5, 0x256($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X256);
    // 0x8012ED2C: addiu       $a1, $s3, 0x2
    ctx->r5 = ADD32(ctx->r19, 0X2);
    // 0x8012ED30: andi        $v1, $a2, 0xFFFF
    ctx->r3 = ctx->r6 & 0XFFFF;
    // 0x8012ED34: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x8012ED38: sw          $t6, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r14;
    // 0x8012ED3C: lh          $t7, 0x2($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X2);
    // 0x8012ED40: or          $s2, $a1, $zero
    ctx->r18 = ctx->r5 | 0;
    // 0x8012ED44: beql        $fp, $t7, L_8012EE50
    if (ctx->r30 == ctx->r15) {
        // 0x8012ED48: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EE50;
    }
    goto skip_0;
    // 0x8012ED48: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_0:
    // 0x8012ED4C: lh          $v0, 0x0($a1)
    ctx->r2 = MEM_H(ctx->r5, 0X0);
    // 0x8012ED50: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    // 0x8012ED54: beql        $t3, $v0, L_8012EE50
    if (ctx->r11 == ctx->r2) {
        // 0x8012ED58: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EE50;
    }
    goto skip_1;
    // 0x8012ED58: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_1:
    // 0x8012ED5C: beq         $v0, $at, L_8012EE4C
    if (ctx->r2 == ctx->r1) {
        // 0x8012ED60: or          $s1, $v1, $zero
        ctx->r17 = ctx->r3 | 0;
            goto L_8012EE4C;
    }
    // 0x8012ED60: or          $s1, $v1, $zero
    ctx->r17 = ctx->r3 | 0;
    // 0x8012ED64: lh          $v0, 0x0($a1)
    ctx->r2 = MEM_H(ctx->r5, 0X0);
    // 0x8012ED68: lw          $t9, 0x0($s4)
    ctx->r25 = MEM_W(ctx->r20, 0X0);
L_8012ED6C:
    // 0x8012ED6C: sll         $s0, $v0, 16
    ctx->r16 = S32(ctx->r2 << 16);
    // 0x8012ED70: sra         $t8, $s0, 16
    ctx->r24 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8012ED74: addu        $t4, $t9, $t8
    ctx->r12 = ADD32(ctx->r25, ctx->r24);
    // 0x8012ED78: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8012ED7C: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012ED80: or          $s0, $t8, $zero
    ctx->r16 = ctx->r24 | 0;
    // 0x8012ED84: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012ED88: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x8012ED8C: bgez        $t6, L_8012EDA0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012ED90: cvt.s.w     $f12, $f16
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    ctx->f12.fl = CVT_S_W(ctx->f16.u32l);
            goto L_8012EDA0;
    }
    // 0x8012ED90: cvt.s.w     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    ctx->f12.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8012ED94: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012ED98: nop

    // 0x8012ED9C: add.s       $f12, $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f18.fl;
L_8012EDA0:
    // 0x8012EDA0: sh          $a0, 0x152($sp)
    MEM_H(0X152, ctx->r29) = ctx->r4;
    // 0x8012EDA4: sh          $t0, 0x13C($sp)
    MEM_H(0X13C, ctx->r29) = ctx->r8;
    // 0x8012EDA8: sh          $t1, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = ctx->r9;
    // 0x8012EDAC: jal         0x8012C314
    // 0x8012EDB0: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    get_glyph_width(rdram, ctx);
        goto after_4;
    // 0x8012EDB0: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    after_4:
    // 0x8012EDB4: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x8012EDB8: lh          $t8, 0x3FD0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD0);
    // 0x8012EDBC: addu        $v1, $s1, $v0
    ctx->r3 = ADD32(ctx->r17, ctx->r2);
    // 0x8012EDC0: andi        $s1, $v1, 0xFFFF
    ctx->r17 = ctx->r3 & 0XFFFF;
    // 0x8012EDC4: addiu       $t9, $t8, -0x32
    ctx->r25 = ADD32(ctx->r24, -0X32);
    // 0x8012EDC8: slt         $at, $s1, $t9
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8012EDCC: lhu         $a0, 0x152($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X152);
    // 0x8012EDD0: lh          $t0, 0x13C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X13C);
    // 0x8012EDD4: lh          $t1, 0x13A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X13A);
    // 0x8012EDD8: lh          $t2, 0x10E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X10E);
    // 0x8012EDDC: bne         $at, $zero, L_8012EE14
    if (ctx->r1 != 0) {
        // 0x8012EDE0: addiu       $t3, $zero, 0x7530
        ctx->r11 = ADD32(0, 0X7530);
            goto L_8012EE14;
    }
    // 0x8012EDE0: addiu       $t3, $zero, 0x7530
    ctx->r11 = ADD32(0, 0X7530);
    // 0x8012EDE4: lbu         $t4, 0x273($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X273);
    // 0x8012EDE8: sll         $t0, $s5, 16
    ctx->r8 = S32(ctx->r21 << 16);
    // 0x8012EDEC: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x8012EDF0: addu        $t1, $t1, $t4
    ctx->r9 = ADD32(ctx->r9, ctx->r12);
    // 0x8012EDF4: sll         $t5, $t1, 16
    ctx->r13 = S32(ctx->r9 << 16);
    // 0x8012EDF8: sra         $t7, $t0, 16
    ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8012EDFC: sll         $t8, $t2, 16
    ctx->r24 = S32(ctx->r10 << 16);
    // 0x8012EE00: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8012EE04: sra         $t1, $t5, 16
    ctx->r9 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8012EE08: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x8012EE0C: addiu       $s6, $zero, 0x1
    ctx->r22 = ADD32(0, 0X1);
    // 0x8012EE10: sra         $t2, $t8, 16
    ctx->r10 = S32(SIGNED(ctx->r24) >> 16);
L_8012EE14:
    // 0x8012EE14: lw          $t4, 0x0($s4)
    ctx->r12 = MEM_W(ctx->r20, 0X0);
    // 0x8012EE18: addiu       $s2, $s2, 0x2
    ctx->r18 = ADD32(ctx->r18, 0X2);
    // 0x8012EE1C: addiu       $at, $zero, 0x4E20
    ctx->r1 = ADD32(0, 0X4E20);
    // 0x8012EE20: subu        $t5, $t4, $s0
    ctx->r13 = SUB32(ctx->r12, ctx->r16);
    // 0x8012EE24: sw          $t5, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r13;
    // 0x8012EE28: lh          $v0, 0x0($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X0);
    // 0x8012EE2C: beql        $fp, $v0, L_8012EE50
    if (ctx->r30 == ctx->r2) {
        // 0x8012EE30: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EE50;
    }
    goto skip_2;
    // 0x8012EE30: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_2:
    // 0x8012EE34: beql        $t3, $v0, L_8012EE50
    if (ctx->r11 == ctx->r2) {
        // 0x8012EE38: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EE50;
    }
    goto skip_3;
    // 0x8012EE38: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_3:
    // 0x8012EE3C: bnel        $s6, $zero, L_8012EE50
    if (ctx->r22 != 0) {
        // 0x8012EE40: lw          $t6, 0x0($s4)
        ctx->r14 = MEM_W(ctx->r20, 0X0);
            goto L_8012EE50;
    }
    goto skip_4;
    // 0x8012EE40: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
    skip_4:
    // 0x8012EE44: bnel        $v0, $at, L_8012ED6C
    if (ctx->r2 != ctx->r1) {
        // 0x8012EE48: lw          $t9, 0x0($s4)
        ctx->r25 = MEM_W(ctx->r20, 0X0);
            goto L_8012ED6C;
    }
    goto skip_5;
    // 0x8012EE48: lw          $t9, 0x0($s4)
    ctx->r25 = MEM_W(ctx->r20, 0X0);
    skip_5:
L_8012EE4C:
    // 0x8012EE4C: lw          $t6, 0x0($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X0);
L_8012EE50:
    // 0x8012EE50: lh          $t7, 0x256($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X256);
    // 0x8012EE54: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x8012EE58: sw          $t8, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r24;
L_8012EE5C:
    // 0x8012EE5C: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012EE60: lb          $t4, -0xD52($t4)
    ctx->r12 = MEM_B(ctx->r12, -0XD52);
    // 0x8012EE64: sll         $v1, $t2, 1
    ctx->r3 = S32(ctx->r10 << 1);
    // 0x8012EE68: addiu       $t9, $sp, 0x124
    ctx->r25 = ADD32(ctx->r29, 0X124);
    // 0x8012EE6C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8012EE70: addu        $v0, $v1, $t9
    ctx->r2 = ADD32(ctx->r3, ctx->r25);
    // 0x8012EE74: bne         $t4, $at, L_8012EEBC
    if (ctx->r12 != ctx->r1) {
        // 0x8012EE78: addiu       $a1, $s3, 0x2
        ctx->r5 = ADD32(ctx->r19, 0X2);
            goto L_8012EEBC;
    }
    // 0x8012EE78: addiu       $a1, $s3, 0x2
    ctx->r5 = ADD32(ctx->r19, 0X2);
    // 0x8012EE7C: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8012EE80: lh          $t5, 0x3FD0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD0);
    // 0x8012EE84: addiu       $t6, $t5, -0x3A
    ctx->r14 = ADD32(ctx->r13, -0X3A);
    // 0x8012EE88: slt         $at, $a0, $t6
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x8012EE8C: bnel        $at, $zero, L_8012EEC0
    if (ctx->r1 != 0) {
        // 0x8012EE90: lh          $t9, 0x0($v0)
        ctx->r25 = MEM_H(ctx->r2, 0X0);
            goto L_8012EEC0;
    }
    goto skip_6;
    // 0x8012EE90: lh          $t9, 0x0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X0);
    skip_6:
    // 0x8012EE94: lh          $t7, 0x0($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X0);
    // 0x8012EE98: lbu         $t8, 0x273($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X273);
    // 0x8012EE9C: beql        $t3, $t7, L_8012EEC0
    if (ctx->r11 == ctx->r15) {
        // 0x8012EEA0: lh          $t9, 0x0($v0)
        ctx->r25 = MEM_H(ctx->r2, 0X0);
            goto L_8012EEC0;
    }
    goto skip_7;
    // 0x8012EEA0: lh          $t9, 0x0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X0);
    skip_7:
    // 0x8012EEA4: addu        $t1, $t1, $t8
    ctx->r9 = ADD32(ctx->r9, ctx->r24);
    // 0x8012EEA8: sll         $t0, $s5, 16
    ctx->r8 = S32(ctx->r21 << 16);
    // 0x8012EEAC: sll         $t9, $t1, 16
    ctx->r25 = S32(ctx->r9 << 16);
    // 0x8012EEB0: sra         $t5, $t0, 16
    ctx->r13 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8012EEB4: sra         $t1, $t9, 16
    ctx->r9 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012EEB8: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
L_8012EEBC:
    // 0x8012EEBC: lh          $t9, 0x0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X0);
L_8012EEC0:
    // 0x8012EEC0: sll         $s0, $t0, 16
    ctx->r16 = S32(ctx->r8 << 16);
    // 0x8012EEC4: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
    // 0x8012EEC8: addiu       $t4, $t9, 0x1
    ctx->r12 = ADD32(ctx->r25, 0X1);
    // 0x8012EECC: sh          $t4, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r12;
    // 0x8012EED0: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x8012EED4: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8012EED8: sll         $t7, $s7, 16
    ctx->r15 = S32(ctx->r23 << 16);
    // 0x8012EEDC: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x8012EEE0: sra         $s7, $t7, 16
    ctx->r23 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012EEE4: bne         $fp, $t5, L_8012EF24
    if (ctx->r30 != ctx->r13) {
        // 0x8012EEE8: or          $s3, $a1, $zero
        ctx->r19 = ctx->r5 | 0;
            goto L_8012EF24;
    }
    // 0x8012EEE8: or          $s3, $a1, $zero
    ctx->r19 = ctx->r5 | 0;
    // 0x8012EEEC: bnel        $t0, $s5, L_8012EF28
    if (ctx->r8 != ctx->r21) {
        // 0x8012EEF0: lw          $t5, 0x0($s4)
        ctx->r13 = MEM_W(ctx->r20, 0X0);
            goto L_8012EF28;
    }
    goto skip_8;
    // 0x8012EEF0: lw          $t5, 0x0($s4)
    ctx->r13 = MEM_W(ctx->r20, 0X0);
    skip_8:
    // 0x8012EEF4: lh          $t8, 0x0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X0);
L_8012EEF8:
    // 0x8012EEF8: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
    // 0x8012EEFC: sll         $t6, $s7, 16
    ctx->r14 = S32(ctx->r23 << 16);
    // 0x8012EF00: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8012EF04: sh          $t9, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r25;
    // 0x8012EF08: lh          $t4, 0x2($s3)
    ctx->r12 = MEM_H(ctx->r19, 0X2);
    // 0x8012EF0C: sra         $s7, $t6, 16
    ctx->r23 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012EF10: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EF14: bnel        $fp, $t4, L_8012EF28
    if (ctx->r30 != ctx->r12) {
        // 0x8012EF18: lw          $t5, 0x0($s4)
        ctx->r13 = MEM_W(ctx->r20, 0X0);
            goto L_8012EF28;
    }
    goto skip_9;
    // 0x8012EF18: lw          $t5, 0x0($s4)
    ctx->r13 = MEM_W(ctx->r20, 0X0);
    skip_9:
    // 0x8012EF1C: beql        $t0, $s5, L_8012EEF8
    if (ctx->r8 == ctx->r21) {
        // 0x8012EF20: lh          $t8, 0x0($v0)
        ctx->r24 = MEM_H(ctx->r2, 0X0);
            goto L_8012EEF8;
    }
    goto skip_10;
    // 0x8012EF20: lh          $t8, 0x0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X0);
    skip_10:
L_8012EF24:
    // 0x8012EF24: lw          $t5, 0x0($s4)
    ctx->r13 = MEM_W(ctx->r20, 0X0);
L_8012EF28:
    // 0x8012EF28: lh          $t6, 0x256($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X256);
    // 0x8012EF2C: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x8012EF30: bne         $t0, $s5, L_8012EFC0
    if (ctx->r8 != ctx->r21) {
        // 0x8012EF34: sw          $t7, 0x0($s4)
        MEM_W(0X0, ctx->r20) = ctx->r15;
            goto L_8012EFC0;
    }
    // 0x8012EF34: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x8012EF38: addu        $t8, $sp, $v1
    ctx->r24 = ADD32(ctx->r29, ctx->r3);
    // 0x8012EF3C: b           L_8012EFC0
    // 0x8012EF40: sh          $s7, 0x110($t8)
    MEM_H(0X110, ctx->r24) = ctx->r23;
        goto L_8012EFC0;
    // 0x8012EF40: sh          $s7, 0x110($t8)
    MEM_H(0X110, ctx->r24) = ctx->r23;
L_8012EF44:
    // 0x8012EF44: lhu         $s5, 0x150($sp)
    ctx->r21 = MEM_HU(ctx->r29, 0X150);
    // 0x8012EF48: lh          $t5, 0x2($s3)
    ctx->r13 = MEM_H(ctx->r19, 0X2);
    // 0x8012EF4C: addu        $t1, $t1, $t9
    ctx->r9 = ADD32(ctx->r9, ctx->r25);
    // 0x8012EF50: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x8012EF54: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
    // 0x8012EF58: sll         $t0, $s5, 16
    ctx->r8 = S32(ctx->r21 << 16);
    // 0x8012EF5C: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x8012EF60: sra         $t6, $t0, 16
    ctx->r14 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8012EF64: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x8012EF68: sll         $t9, $s7, 16
    ctx->r25 = S32(ctx->r23 << 16);
    // 0x8012EF6C: sra         $t1, $t4, 16
    ctx->r9 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8012EF70: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x8012EF74: sra         $t2, $t7, 16
    ctx->r10 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012EF78: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EF7C: bne         $fp, $t5, L_8012EFB4
    if (ctx->r30 != ctx->r13) {
        // 0x8012EF80: sra         $s7, $t9, 16
        ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8012EFB4;
    }
    // 0x8012EF80: sra         $s7, $t9, 16
    ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012EF84: sll         $t6, $s5, 16
    ctx->r14 = S32(ctx->r21 << 16);
    // 0x8012EF88: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012EF8C: bnel        $t7, $s5, L_8012EFB8
    if (ctx->r15 != ctx->r21) {
        // 0x8012EF90: sll         $t5, $t2, 1
        ctx->r13 = S32(ctx->r10 << 1);
            goto L_8012EFB8;
    }
    goto skip_11;
    // 0x8012EF90: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
    skip_11:
    // 0x8012EF94: lh          $t4, 0x2($s3)
    ctx->r12 = MEM_H(ctx->r19, 0X2);
L_8012EF98:
    // 0x8012EF98: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
    // 0x8012EF9C: sll         $t8, $s7, 16
    ctx->r24 = S32(ctx->r23 << 16);
    // 0x8012EFA0: addiu       $s3, $s3, 0x2
    ctx->r19 = ADD32(ctx->r19, 0X2);
    // 0x8012EFA4: bne         $fp, $t4, L_8012EFB4
    if (ctx->r30 != ctx->r12) {
        // 0x8012EFA8: sra         $s7, $t8, 16
        ctx->r23 = S32(SIGNED(ctx->r24) >> 16);
            goto L_8012EFB4;
    }
    // 0x8012EFA8: sra         $s7, $t8, 16
    ctx->r23 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012EFAC: beql        $t0, $s5, L_8012EF98
    if (ctx->r8 == ctx->r21) {
        // 0x8012EFB0: lh          $t4, 0x2($s3)
        ctx->r12 = MEM_H(ctx->r19, 0X2);
            goto L_8012EF98;
    }
    goto skip_12;
    // 0x8012EFB0: lh          $t4, 0x2($s3)
    ctx->r12 = MEM_H(ctx->r19, 0X2);
    skip_12:
L_8012EFB4:
    // 0x8012EFB4: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
L_8012EFB8:
    // 0x8012EFB8: addu        $t6, $sp, $t5
    ctx->r14 = ADD32(ctx->r29, ctx->r13);
    // 0x8012EFBC: sh          $s7, 0x110($t6)
    MEM_H(0X110, ctx->r14) = ctx->r23;
L_8012EFC0:
    // 0x8012EFC0: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
L_8012EFC4:
    // 0x8012EFC4: bnel        $t3, $t7, L_8012EBF8
    if (ctx->r11 != ctx->r15) {
        // 0x8012EFC8: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_8012EBF8;
    }
    goto skip_13;
    // 0x8012EFC8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    skip_13:
L_8012EFCC:
    // 0x8012EFCC: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x8012EFD0: lbu         $s5, 0x273($sp)
    ctx->r21 = MEM_BU(ctx->r29, 0X273);
    // 0x8012EFD4: sll         $t8, $t2, 16
    ctx->r24 = S32(ctx->r10 << 16);
    // 0x8012EFD8: sra         $t2, $t8, 16
    ctx->r10 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012EFDC: addiu       $t5, $t2, -0x1
    ctx->r13 = ADD32(ctx->r10, -0X1);
    // 0x8012EFE0: multu       $t5, $s5
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012EFE4: lhu         $t4, 0x266($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X266);
    // 0x8012EFE8: addiu       $fp, $zero, 0x130
    ctx->r30 = ADD32(0, 0X130);
    // 0x8012EFEC: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    // 0x8012EFF0: mflo        $t6
    ctx->r14 = lo;
    // 0x8012EFF4: subu        $s4, $t4, $t6
    ctx->r20 = SUB32(ctx->r12, ctx->r14);
    // 0x8012EFF8: sll         $t7, $s4, 16
    ctx->r15 = S32(ctx->r20 << 16);
    // 0x8012EFFC: blez        $t2, L_8012F130
    if (SIGNED(ctx->r10) <= 0) {
        // 0x8012F000: sra         $s4, $t7, 16
        ctx->r20 = S32(SIGNED(ctx->r15) >> 16);
            goto L_8012F130;
    }
    // 0x8012F000: sra         $s4, $t7, 16
    ctx->r20 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012F004: addiu       $s1, $sp, 0x68
    ctx->r17 = ADD32(ctx->r29, 0X68);
L_8012F008:
    // 0x8012F008: sll         $v0, $s3, 1
    ctx->r2 = S32(ctx->r19 << 1);
    // 0x8012F00C: addiu       $t6, $sp, 0x124
    ctx->r14 = ADD32(ctx->r29, 0X124);
    // 0x8012F010: addu        $s2, $v0, $t6
    ctx->r18 = ADD32(ctx->r2, ctx->r14);
    // 0x8012F014: addu        $t9, $sp, $v0
    ctx->r25 = ADD32(ctx->r29, ctx->r2);
    // 0x8012F018: lh          $t9, 0x110($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X110);
    // 0x8012F01C: lh          $a2, 0x0($s2)
    ctx->r6 = MEM_H(ctx->r18, 0X0);
    // 0x8012F020: lw          $t4, 0x148($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X148);
    // 0x8012F024: sll         $t5, $t9, 1
    ctx->r13 = S32(ctx->r25 << 1);
    // 0x8012F028: sll         $t7, $a2, 1
    ctx->r15 = S32(ctx->r6 << 1);
    // 0x8012F02C: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8012F030: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    // 0x8012F034: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8012F038: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8012F03C: jal         0x80129158
    // 0x8012F040: addu        $a0, $t5, $t4
    ctx->r4 = ADD32(ctx->r13, ctx->r12);
    memcpy_sssv(rdram, ctx);
        goto after_5;
    // 0x8012F040: addu        $a0, $t5, $t4
    ctx->r4 = ADD32(ctx->r13, ctx->r12);
    after_5:
    // 0x8012F044: lh          $v1, 0x0($s2)
    ctx->r3 = MEM_H(ctx->r18, 0X0);
    // 0x8012F048: lh          $t2, 0x10E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X10E);
    // 0x8012F04C: addiu       $t3, $zero, 0x7530
    ctx->r11 = ADD32(0, 0X7530);
    // 0x8012F050: sll         $t8, $v1, 1
    ctx->r24 = S32(ctx->r3 << 1);
    // 0x8012F054: addu        $t9, $s1, $t8
    ctx->r25 = ADD32(ctx->r17, ctx->r24);
    // 0x8012F058: sh          $t3, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r11;
    // 0x8012F05C: lh          $t5, 0x68($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X68);
    // 0x8012F060: andi        $a3, $s4, 0xFFFF
    ctx->r7 = ctx->r20 & 0XFFFF;
    // 0x8012F064: addiu       $v0, $v1, -0x1
    ctx->r2 = ADD32(ctx->r3, -0X1);
    // 0x8012F068: bnel        $fp, $t5, L_8012F094
    if (ctx->r30 != ctx->r13) {
        // 0x8012F06C: sll         $t5, $v0, 16
        ctx->r13 = S32(ctx->r2 << 16);
            goto L_8012F094;
    }
    goto skip_14;
    // 0x8012F06C: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    skip_14:
    // 0x8012F070: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8012F074:
    // 0x8012F074: sll         $t4, $s0, 16
    ctx->r12 = S32(ctx->r16 << 16);
    // 0x8012F078: sra         $s0, $t4, 16
    ctx->r16 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8012F07C: sll         $t7, $s0, 1
    ctx->r15 = S32(ctx->r16 << 1);
    // 0x8012F080: addu        $t8, $s1, $t7
    ctx->r24 = ADD32(ctx->r17, ctx->r15);
    // 0x8012F084: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x8012F088: beql        $fp, $t9, L_8012F074
    if (ctx->r30 == ctx->r25) {
        // 0x8012F08C: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8012F074;
    }
    goto skip_15;
    // 0x8012F08C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_15:
    // 0x8012F090: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
L_8012F094:
    // 0x8012F094: sra         $t4, $t5, 16
    ctx->r12 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8012F098: slt         $at, $s0, $t4
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x8012F09C: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    // 0x8012F0A0: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
    // 0x8012F0A4: beq         $at, $zero, L_8012F0EC
    if (ctx->r1 == 0) {
        // 0x8012F0A8: addu        $a1, $s1, $t6
        ctx->r5 = ADD32(ctx->r17, ctx->r14);
            goto L_8012F0EC;
    }
    // 0x8012F0A8: addu        $a1, $s1, $t6
    ctx->r5 = ADD32(ctx->r17, ctx->r14);
    // 0x8012F0AC: sll         $t7, $t4, 1
    ctx->r15 = S32(ctx->r12 << 1);
    // 0x8012F0B0: addu        $v1, $s1, $t7
    ctx->r3 = ADD32(ctx->r17, ctx->r15);
    // 0x8012F0B4: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x8012F0B8: bne         $fp, $t8, L_8012F0EC
    if (ctx->r30 != ctx->r24) {
        // 0x8012F0BC: addiu       $v0, $v0, -0x1
        ctx->r2 = ADD32(ctx->r2, -0X1);
            goto L_8012F0EC;
    }
    // 0x8012F0BC: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
L_8012F0C0:
    // 0x8012F0C0: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x8012F0C4: sra         $t5, $t9, 16
    ctx->r13 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012F0C8: slt         $at, $s0, $t5
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x8012F0CC: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x8012F0D0: beq         $at, $zero, L_8012F0EC
    if (ctx->r1 == 0) {
        // 0x8012F0D4: sh          $t3, 0x0($v1)
        MEM_H(0X0, ctx->r3) = ctx->r11;
            goto L_8012F0EC;
    }
    // 0x8012F0D4: sh          $t3, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r11;
    // 0x8012F0D8: sll         $t4, $t5, 1
    ctx->r12 = S32(ctx->r13 << 1);
    // 0x8012F0DC: addu        $v1, $s1, $t4
    ctx->r3 = ADD32(ctx->r17, ctx->r12);
    // 0x8012F0E0: lh          $t6, 0x0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X0);
    // 0x8012F0E4: beql        $fp, $t6, L_8012F0C0
    if (ctx->r30 == ctx->r14) {
        // 0x8012F0E8: addiu       $v0, $v0, -0x1
        ctx->r2 = ADD32(ctx->r2, -0X1);
            goto L_8012F0C0;
    }
    goto skip_16;
    // 0x8012F0E8: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    skip_16:
L_8012F0EC:
    // 0x8012F0EC: lwc1        $f4, 0x268($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X268);
    // 0x8012F0F0: lwc1        $f6, 0x26C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X26C);
    // 0x8012F0F4: lw          $a0, 0x258($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X258);
    // 0x8012F0F8: lhu         $a2, 0x262($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X262);
    // 0x8012F0FC: sh          $t2, 0x10E($sp)
    MEM_H(0X10E, ctx->r29) = ctx->r10;
    // 0x8012F100: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8012F104: jal         0x8012C978
    // 0x8012F108: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text_centered(rdram, ctx);
        goto after_6;
    // 0x8012F108: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_6:
    // 0x8012F10C: lh          $t2, 0x10E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X10E);
    // 0x8012F110: addiu       $s3, $s3, 0x1
    ctx->r19 = ADD32(ctx->r19, 0X1);
    // 0x8012F114: sll         $t9, $s3, 16
    ctx->r25 = S32(ctx->r19 << 16);
    // 0x8012F118: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8012F11C: addu        $s4, $s4, $s5
    ctx->r20 = ADD32(ctx->r20, ctx->r21);
    // 0x8012F120: sll         $t7, $s4, 16
    ctx->r15 = S32(ctx->r20 << 16);
    // 0x8012F124: slt         $at, $s3, $t2
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x8012F128: bne         $at, $zero, L_8012F008
    if (ctx->r1 != 0) {
        // 0x8012F12C: sra         $s4, $t7, 16
        ctx->r20 = S32(SIGNED(ctx->r15) >> 16);
            goto L_8012F008;
    }
    // 0x8012F12C: sra         $s4, $t7, 16
    ctx->r20 = S32(SIGNED(ctx->r15) >> 16);
L_8012F130:
    // 0x8012F130: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8012F134: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8012F138: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x8012F13C: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x8012F140: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x8012F144: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8012F148: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x8012F14C: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x8012F150: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8012F154: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x8012F158: jr          $ra
    // 0x8012F15C: addiu       $sp, $sp, 0x258
    ctx->r29 = ADD32(ctx->r29, 0X258);
    return;
    // 0x8012F15C: addiu       $sp, $sp, 0x258
    ctx->r29 = ADD32(ctx->r29, 0X258);
;}
RECOMP_FUNC void func_8012F160(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012F160: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x8012F164: lwc1        $f4, 0x60($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X60);
    // 0x8012F168: lwc1        $f6, 0x64($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X64);
    // 0x8012F16C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F170: swc1        $f4, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f4.u32l;
    // 0x8012F174: or          $t6, $a2, $zero
    ctx->r14 = ctx->r6 | 0;
    // 0x8012F178: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F17C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8012F180: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x8012F184: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x8012F188: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x8012F18C: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x8012F190: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x8012F194: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x8012F198: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8012F19C: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x8012F1A0: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x8012F1A4: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012F1A8: sw          $a2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r6;
    // 0x8012F1AC: sw          $a3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r7;
    // 0x8012F1B0: sh          $t6, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r14;
    // 0x8012F1B4: swc1        $f6, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f6.u32l;
    // 0x8012F1B8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012F1BC: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012F1C0: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x8012F1C4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012F1C8: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012F1CC: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012F1D0: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x8012F1D4: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012F1D8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012F1DC: lbu         $t6, 0x0($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X0);
    // 0x8012F1E0: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012F1E4: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F1E8: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012F1EC: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012F1F0: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x8012F1F4: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012F1F8: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x8012F1FC: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F200: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012F204: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012F208: sll         $t6, $t7, 8
    ctx->r14 = S32(ctx->r15 << 8);
    // 0x8012F20C: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8012F210: lbu         $t8, 0x0($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F214: sll         $s1, $a2, 16
    ctx->r17 = S32(ctx->r6 << 16);
    // 0x8012F218: or          $s5, $a1, $zero
    ctx->r21 = ctx->r5 | 0;
    // 0x8012F21C: or          $t6, $t9, $t8
    ctx->r14 = ctx->r25 | ctx->r24;
    // 0x8012F220: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012F224: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8012F228: lui         $t9, 0xFB00
    ctx->r25 = S32(0XFB00 << 16);
    // 0x8012F22C: or          $fp, $a0, $zero
    ctx->r30 = ctx->r4 | 0;
    // 0x8012F230: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012F234: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012F238: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012F23C: lbu         $t6, 0x0($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X0);
    // 0x8012F240: lbu         $t8, 0x0($t2)
    ctx->r24 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F244: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8012F248: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x8012F24C: or          $t9, $t7, $t6
    ctx->r25 = ctx->r15 | ctx->r14;
    // 0x8012F250: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F254: sll         $t6, $t7, 8
    ctx->r14 = S32(ctx->r15 << 8);
    // 0x8012F258: or          $t8, $t9, $t6
    ctx->r24 = ctx->r25 | ctx->r14;
    // 0x8012F25C: lbu         $t9, 0x0($t4)
    ctx->r25 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F260: sra         $t7, $s1, 16
    ctx->r15 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8012F264: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x8012F268: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x8012F26C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012F270: jal         0x8012FA78
    // 0x8012F274: sh          $a2, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r6;
    func_8012FA78(rdram, ctx);
        goto after_0;
    // 0x8012F274: sh          $a2, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r6;
    after_0:
    // 0x8012F278: lh          $t8, 0x0($s5)
    ctx->r24 = MEM_H(ctx->r21, 0X0);
    // 0x8012F27C: addiu       $a3, $zero, 0x7530
    ctx->r7 = ADD32(0, 0X7530);
    // 0x8012F280: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F284: beq         $a3, $t8, L_8012FA2C
    if (ctx->r7 == ctx->r24) {
        // 0x8012F288: lhu         $t1, 0x5A($sp)
        ctx->r9 = MEM_HU(ctx->r29, 0X5A);
            goto L_8012FA2C;
    }
    // 0x8012F288: lhu         $t1, 0x5A($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X5A);
    // 0x8012F28C: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012F290: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x8012F294: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012F298: addiu       $s3, $s3, -0xE20
    ctx->r19 = ADD32(ctx->r19, -0XE20);
    // 0x8012F29C: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    // 0x8012F2A0: addiu       $s7, $zero, 0x130
    ctx->r23 = ADD32(0, 0X130);
    // 0x8012F2A4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_8012F2A8:
    // 0x8012F2A8: andi        $a1, $s1, 0xFFFF
    ctx->r5 = ctx->r17 & 0XFFFF;
    // 0x8012F2AC: lhu         $a2, 0x5E($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F2B0: jal         0x8012C678
    // 0x8012F2B4: sh          $t1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r9;
    func_8012C678(rdram, ctx);
        goto after_1;
    // 0x8012F2B4: sh          $t1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r9;
    after_1:
    // 0x8012F2B8: addiu       $a3, $zero, 0x7530
    ctx->r7 = ADD32(0, 0X7530);
    // 0x8012F2BC: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F2C0: beq         $v0, $zero, L_8012F324
    if (ctx->r2 == 0) {
        // 0x8012F2C4: lhu         $t1, 0x5A($sp)
        ctx->r9 = MEM_HU(ctx->r29, 0X5A);
            goto L_8012F324;
    }
    // 0x8012F2C4: lhu         $t1, 0x5A($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X5A);
    // 0x8012F2C8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8012F2CC: beq         $v0, $at, L_8012F2F0
    if (ctx->r2 == ctx->r1) {
        // 0x8012F2D0: lui         $a0, 0x8024
        ctx->r4 = S32(0X8024 << 16);
            goto L_8012F2F0;
    }
    // 0x8012F2D0: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8012F2D4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012F2D8: beq         $v0, $at, L_8012F31C
    if (ctx->r2 == ctx->r1) {
        // 0x8012F2DC: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8012F31C;
    }
    // 0x8012F2DC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012F2E0: beql        $v0, $at, L_8012FA1C
    if (ctx->r2 == ctx->r1) {
        // 0x8012F2E4: addiu       $s5, $s5, 0x2
        ctx->r21 = ADD32(ctx->r21, 0X2);
            goto L_8012FA1C;
    }
    goto skip_0;
    // 0x8012F2E4: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    skip_0:
    // 0x8012F2E8: b           L_8012FA20
    // 0x8012F2EC: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
        goto L_8012FA20;
    // 0x8012F2EC: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
L_8012F2F0:
    // 0x8012F2F0: addiu       $a0, $a0, -0xDB8
    ctx->r4 = ADD32(ctx->r4, -0XDB8);
    // 0x8012F2F4: or          $s0, $t1, $zero
    ctx->r16 = ctx->r9 | 0;
    // 0x8012F2F8: jal         0x8012C3D8
    // 0x8012F2FC: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    get_message_width(rdram, ctx);
        goto after_2;
    // 0x8012F2FC: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    after_2:
    // 0x8012F300: addu        $t1, $s0, $v0
    ctx->r9 = ADD32(ctx->r16, ctx->r2);
    // 0x8012F304: andi        $t9, $t1, 0xFFFF
    ctx->r25 = ctx->r9 & 0XFFFF;
    // 0x8012F308: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x8012F30C: addiu       $a3, $zero, 0x7530
    ctx->r7 = ADD32(0, 0X7530);
    // 0x8012F310: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F314: b           L_8012FA1C
    // 0x8012F318: addiu       $s5, $s5, 0x8
    ctx->r21 = ADD32(ctx->r21, 0X8);
        goto L_8012FA1C;
    // 0x8012F318: addiu       $s5, $s5, 0x8
    ctx->r21 = ADD32(ctx->r21, 0X8);
L_8012F31C:
    // 0x8012F31C: b           L_8012FA1C
    // 0x8012F320: addiu       $s5, $s5, 0x6
    ctx->r21 = ADD32(ctx->r21, 0X6);
        goto L_8012FA1C;
    // 0x8012F320: addiu       $s5, $s5, 0x6
    ctx->r21 = ADD32(ctx->r21, 0X6);
L_8012F324:
    // 0x8012F324: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F328: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012F32C: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8012F330: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012F334: sw          $t6, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r14;
    // 0x8012F338: addiu       $t2, $t2, -0xE10
    ctx->r10 = ADD32(ctx->r10, -0XE10);
    // 0x8012F33C: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012F340: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012F344: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F348: addiu       $t3, $t3, -0xE0F
    ctx->r11 = ADD32(ctx->r11, -0XE0F);
    // 0x8012F34C: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F350: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x8012F354: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012F358: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8012F35C: addiu       $t4, $t4, -0xE0E
    ctx->r12 = ADD32(ctx->r12, -0XE0E);
    // 0x8012F360: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x8012F364: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F368: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8012F36C: addiu       $t5, $t5, -0xE0D
    ctx->r13 = ADD32(ctx->r13, -0XE0D);
    // 0x8012F370: sll         $t9, $t6, 8
    ctx->r25 = S32(ctx->r14 << 8);
    // 0x8012F374: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8012F378: lbu         $t7, 0x0($t5)
    ctx->r15 = MEM_BU(ctx->r13, 0X0);
    // 0x8012F37C: sll         $s2, $t0, 2
    ctx->r18 = S32(ctx->r8 << 2);
    // 0x8012F380: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x8012F384: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012F388: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012F38C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F390: lui         $t8, 0xFB00
    ctx->r24 = S32(0XFB00 << 16);
    // 0x8012F394: or          $a0, $fp, $zero
    ctx->r4 = ctx->r30 | 0;
    // 0x8012F398: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012F39C: sw          $t6, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r14;
    // 0x8012F3A0: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012F3A4: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F3A8: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F3AC: or          $s0, $t1, $zero
    ctx->r16 = ctx->r9 | 0;
    // 0x8012F3B0: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x8012F3B4: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8012F3B8: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8012F3BC: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F3C0: or          $s1, $t0, $zero
    ctx->r17 = ctx->r8 | 0;
    // 0x8012F3C4: sll         $t9, $t6, 8
    ctx->r25 = S32(ctx->r14 << 8);
    // 0x8012F3C8: or          $t7, $t8, $t9
    ctx->r15 = ctx->r24 | ctx->r25;
    // 0x8012F3CC: lbu         $t8, 0x0($t5)
    ctx->r24 = MEM_BU(ctx->r13, 0X0);
    // 0x8012F3D0: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8012F3D4: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012F3D8: lh          $a1, 0x0($s5)
    ctx->r5 = MEM_H(ctx->r21, 0X0);
    // 0x8012F3DC: lw          $t6, 0x0($s3)
    ctx->r14 = MEM_W(ctx->r19, 0X0);
    // 0x8012F3E0: andi        $t8, $s2, 0xFFF
    ctx->r24 = ctx->r18 & 0XFFF;
    // 0x8012F3E4: or          $s2, $t8, $zero
    ctx->r18 = ctx->r24 | 0;
    // 0x8012F3E8: addu        $t7, $t6, $a1
    ctx->r15 = ADD32(ctx->r14, ctx->r5);
    // 0x8012F3EC: sw          $t7, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r15;
    // 0x8012F3F0: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    // 0x8012F3F4: jal         0x8012FB4C
    // 0x8012F3F8: sh          $a1, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r5;
    load_glyph(rdram, ctx);
        goto after_3;
    // 0x8012F3F8: sh          $a1, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r5;
    after_3:
    // 0x8012F3FC: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x8012F400: lbu         $t9, -0xE0B($t9)
    ctx->r25 = MEM_BU(ctx->r25, -0XE0B);
    // 0x8012F404: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F408: beql        $t9, $zero, L_8012F6D0
    if (ctx->r25 == 0) {
        // 0x8012F40C: lw          $v0, 0x0($fp)
        ctx->r2 = MEM_W(ctx->r30, 0X0);
            goto L_8012F6D0;
    }
    goto skip_1;
    // 0x8012F40C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    skip_1:
    // 0x8012F410: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F414: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8012F418: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x8012F41C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8012F420: sw          $t6, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r14;
    // 0x8012F424: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8012F428: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012F42C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F430: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012F434: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F438: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012F43C: sw          $t9, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r25;
    // 0x8012F440: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012F444: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012F448: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F44C: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012F450: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012F454: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012F458: sw          $t7, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r15;
    // 0x8012F45C: lwc1        $f8, -0xE08($at)
    ctx->f8.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012F460: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012F464: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012F468: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012F46C: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012F470: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012F474: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012F478: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x8012F47C: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012F480: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012F484: addu        $t6, $s0, $t9
    ctx->r14 = ADD32(ctx->r16, ctx->r25);
    // 0x8012F488: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8012F48C: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8012F490: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8012F494: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x8012F498: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x8012F49C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F4A0: lwc1        $f16, -0xE04($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012F4A4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F4A8: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8012F4AC: mfc1        $t9, $f18
    ctx->r25 = (int32_t)ctx->f18.u32l;
    // 0x8012F4B0: nop

    // 0x8012F4B4: addu        $t6, $s1, $t9
    ctx->r14 = ADD32(ctx->r17, ctx->r25);
    // 0x8012F4B8: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x8012F4BC: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x8012F4C0: andi        $t6, $t9, 0xFFF
    ctx->r14 = ctx->r25 & 0XFFF;
    // 0x8012F4C4: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x8012F4C8: addiu       $t9, $s0, 0x1
    ctx->r25 = ADD32(ctx->r16, 0X1);
    // 0x8012F4CC: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x8012F4D0: andi        $t6, $t7, 0xFFF
    ctx->r14 = ctx->r15 & 0XFFF;
    // 0x8012F4D4: addiu       $t9, $s1, 0x1
    ctx->r25 = ADD32(ctx->r17, 0X1);
    // 0x8012F4D8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012F4DC: sll         $t8, $t6, 12
    ctx->r24 = S32(ctx->r14 << 12);
    // 0x8012F4E0: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x8012F4E4: andi        $t6, $t7, 0xFFF
    ctx->r14 = ctx->r15 & 0XFFF;
    // 0x8012F4E8: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8012F4EC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8012F4F0: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F4F4: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x8012F4F8: lui         $t9, 0xB300
    ctx->r25 = S32(0XB300 << 16);
    // 0x8012F4FC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8012F500: sw          $t7, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r15;
    // 0x8012F504: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012F508: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012F50C: lw          $v1, 0x0($fp)
    ctx->r3 = MEM_W(ctx->r30, 0X0);
    // 0x8012F510: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012F514: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012F518: sw          $t6, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r14;
    // 0x8012F51C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012F520: lwc1        $f4, -0xE08($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012F524: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012F528: div.s       $f6, $f20, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f20.fl, ctx->f4.fl);
    // 0x8012F52C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F530: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F534: nop

    // 0x8012F538: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012F53C: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F540: nop

    // 0x8012F544: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012F548: beql        $t8, $zero, L_8012F598
    if (ctx->r24 == 0) {
        // 0x8012F54C: mfc1        $t8, $f8
        ctx->r24 = (int32_t)ctx->f8.u32l;
            goto L_8012F598;
    }
    goto skip_2;
    // 0x8012F54C: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    skip_2:
    // 0x8012F550: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8012F554: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012F558: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8012F55C: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F560: nop

    // 0x8012F564: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012F568: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F56C: nop

    // 0x8012F570: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012F574: bne         $t8, $zero, L_8012F58C
    if (ctx->r24 != 0) {
        // 0x8012F578: nop
    
            goto L_8012F58C;
    }
    // 0x8012F578: nop

    // 0x8012F57C: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x8012F580: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012F584: b           L_8012F5A4
    // 0x8012F588: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_8012F5A4;
    // 0x8012F588: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_8012F58C:
    // 0x8012F58C: b           L_8012F5A4
    // 0x8012F590: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_8012F5A4;
    // 0x8012F590: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8012F594: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
L_8012F598:
    // 0x8012F598: nop

    // 0x8012F59C: bltz        $t8, L_8012F58C
    if (SIGNED(ctx->r24) < 0) {
        // 0x8012F5A0: nop
    
            goto L_8012F58C;
    }
    // 0x8012F5A0: nop

L_8012F5A4:
    // 0x8012F5A4: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012F5A8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F5AC: lwc1        $f10, -0xE04($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012F5B0: or          $t6, $t8, $zero
    ctx->r14 = ctx->r24 | 0;
    // 0x8012F5B4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012F5B8: div.s       $f16, $f20, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f20.fl, ctx->f10.fl);
    // 0x8012F5BC: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8012F5C0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012F5C4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F5C8: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F5CC: nop

    // 0x8012F5D0: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8012F5D4: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F5D8: nop

    // 0x8012F5DC: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012F5E0: beql        $t8, $zero, L_8012F630
    if (ctx->r24 == 0) {
        // 0x8012F5E4: mfc1        $t8, $f18
        ctx->r24 = (int32_t)ctx->f18.u32l;
            goto L_8012F630;
    }
    goto skip_3;
    // 0x8012F5E4: mfc1        $t8, $f18
    ctx->r24 = (int32_t)ctx->f18.u32l;
    skip_3:
    // 0x8012F5E8: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012F5EC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012F5F0: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x8012F5F4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F5F8: nop

    // 0x8012F5FC: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012F600: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F604: nop

    // 0x8012F608: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012F60C: bne         $t8, $zero, L_8012F624
    if (ctx->r24 != 0) {
        // 0x8012F610: nop
    
            goto L_8012F624;
    }
    // 0x8012F610: nop

    // 0x8012F614: mfc1        $t8, $f18
    ctx->r24 = (int32_t)ctx->f18.u32l;
    // 0x8012F618: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012F61C: b           L_8012F63C
    // 0x8012F620: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_8012F63C;
    // 0x8012F620: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_8012F624:
    // 0x8012F624: b           L_8012F63C
    // 0x8012F628: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_8012F63C;
    // 0x8012F628: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8012F62C: mfc1        $t8, $f18
    ctx->r24 = (int32_t)ctx->f18.u32l;
L_8012F630:
    // 0x8012F630: nop

    // 0x8012F634: bltz        $t8, L_8012F624
    if (SIGNED(ctx->r24) < 0) {
        // 0x8012F638: nop
    
            goto L_8012F624;
    }
    // 0x8012F638: nop

L_8012F63C:
    // 0x8012F63C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F640: andi        $t6, $t8, 0xFFFF
    ctx->r14 = ctx->r24 & 0XFFFF;
    // 0x8012F644: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8012F648: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8012F64C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F650: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8012F654: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012F658: sw          $t8, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r24;
    // 0x8012F65C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8012F660: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x8012F664: lbu         $t6, 0x0($t2)
    ctx->r14 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F668: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x8012F66C: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x8012F670: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012F674: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F678: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8012F67C: or          $t6, $t9, $t7
    ctx->r14 = ctx->r25 | ctx->r15;
    // 0x8012F680: lbu         $t9, 0x0($t4)
    ctx->r25 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F684: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x8012F688: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012F68C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F690: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012F694: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012F698: sw          $t8, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r24;
    // 0x8012F69C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012F6A0: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x8012F6A4: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012F6A8: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x8012F6AC: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8012F6B0: or          $t6, $t8, $t7
    ctx->r14 = ctx->r24 | ctx->r15;
    // 0x8012F6B4: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012F6B8: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8012F6BC: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8012F6C0: lbu         $t6, 0x0($t4)
    ctx->r14 = MEM_BU(ctx->r12, 0X0);
    // 0x8012F6C4: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8012F6C8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8012F6CC: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
L_8012F6D0:
    // 0x8012F6D0: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x8012F6D4: addiu       $a2, $a2, -0xE08
    ctx->r6 = ADD32(ctx->r6, -0XE08);
    // 0x8012F6D8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012F6DC: sw          $t8, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r24;
    // 0x8012F6E0: lwc1        $f4, 0x0($a2)
    ctx->f4.u32l = MEM_W(ctx->r6, 0X0);
    // 0x8012F6E4: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012F6E8: addiu       $t1, $t1, -0xE04
    ctx->r9 = ADD32(ctx->r9, -0XE04);
    // 0x8012F6EC: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8012F6F0: lwc1        $f8, 0x0($t1)
    ctx->f8.u32l = MEM_W(ctx->r9, 0X0);
    // 0x8012F6F4: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012F6F8: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x8012F6FC: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012F700: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x8012F704: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8012F708: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8012F70C: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x8012F710: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x8012F714: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x8012F718: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012F71C: addu        $t6, $s1, $t9
    ctx->r14 = ADD32(ctx->r17, ctx->r25);
    // 0x8012F720: sll         $t8, $t6, 2
    ctx->r24 = S32(ctx->r14 << 2);
    // 0x8012F724: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8012F728: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8012F72C: sll         $t8, $s0, 2
    ctx->r24 = S32(ctx->r16 << 2);
    // 0x8012F730: andi        $t7, $t8, 0xFFF
    ctx->r15 = ctx->r24 & 0XFFF;
    // 0x8012F734: sll         $t9, $t7, 12
    ctx->r25 = S32(ctx->r15 << 12);
    // 0x8012F738: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012F73C: or          $t6, $t9, $s2
    ctx->r14 = ctx->r25 | ctx->r18;
    // 0x8012F740: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8012F744: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012F748: lui         $t7, 0xB400
    ctx->r15 = S32(0XB400 << 16);
    // 0x8012F74C: lui         $t6, 0xB300
    ctx->r14 = S32(0XB300 << 16);
    // 0x8012F750: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8012F754: sw          $t8, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r24;
    // 0x8012F758: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012F75C: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8012F760: lw          $a1, 0x0($fp)
    ctx->r5 = MEM_W(ctx->r30, 0X0);
    // 0x8012F764: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012F768: addiu       $t9, $a1, 0x8
    ctx->r25 = ADD32(ctx->r5, 0X8);
    // 0x8012F76C: sw          $t9, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r25;
    // 0x8012F770: sw          $t6, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r14;
    // 0x8012F774: lwc1        $f16, 0x0($a2)
    ctx->f16.u32l = MEM_W(ctx->r6, 0X0);
    // 0x8012F778: div.s       $f18, $f20, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f20.fl, ctx->f16.fl);
    // 0x8012F77C: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F780: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F784: nop

    // 0x8012F788: cvt.w.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8012F78C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F790: nop

    // 0x8012F794: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012F798: beql        $t7, $zero, L_8012F7E8
    if (ctx->r15 == 0) {
        // 0x8012F79C: mfc1        $t7, $f4
        ctx->r15 = (int32_t)ctx->f4.u32l;
            goto L_8012F7E8;
    }
    goto skip_4;
    // 0x8012F79C: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    skip_4:
    // 0x8012F7A0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8012F7A4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012F7A8: sub.s       $f4, $f18, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x8012F7AC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F7B0: nop

    // 0x8012F7B4: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012F7B8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F7BC: nop

    // 0x8012F7C0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012F7C4: bne         $t7, $zero, L_8012F7DC
    if (ctx->r15 != 0) {
        // 0x8012F7C8: nop
    
            goto L_8012F7DC;
    }
    // 0x8012F7C8: nop

    // 0x8012F7CC: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    // 0x8012F7D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012F7D4: b           L_8012F7F4
    // 0x8012F7D8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012F7F4;
    // 0x8012F7D8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012F7DC:
    // 0x8012F7DC: b           L_8012F7F4
    // 0x8012F7E0: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012F7F4;
    // 0x8012F7E0: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012F7E4: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
L_8012F7E8:
    // 0x8012F7E8: nop

    // 0x8012F7EC: bltz        $t7, L_8012F7DC
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012F7F0: nop
    
            goto L_8012F7DC;
    }
    // 0x8012F7F0: nop

L_8012F7F4:
    // 0x8012F7F4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F7F8: lwc1        $f6, 0x0($t1)
    ctx->f6.u32l = MEM_W(ctx->r9, 0X0);
    // 0x8012F7FC: or          $t9, $t7, $zero
    ctx->r25 = ctx->r15 | 0;
    // 0x8012F800: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012F804: div.s       $f8, $f20, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f20.fl, ctx->f6.fl);
    // 0x8012F808: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x8012F80C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012F810: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012F814: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F818: nop

    // 0x8012F81C: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8012F820: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F824: nop

    // 0x8012F828: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012F82C: beql        $t7, $zero, L_8012F87C
    if (ctx->r15 == 0) {
        // 0x8012F830: mfc1        $t7, $f10
        ctx->r15 = (int32_t)ctx->f10.u32l;
            goto L_8012F87C;
    }
    goto skip_5;
    // 0x8012F830: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    skip_5:
    // 0x8012F834: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8012F838: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012F83C: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x8012F840: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012F844: nop

    // 0x8012F848: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8012F84C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012F850: nop

    // 0x8012F854: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8012F858: bne         $t7, $zero, L_8012F870
    if (ctx->r15 != 0) {
        // 0x8012F85C: nop
    
            goto L_8012F870;
    }
    // 0x8012F85C: nop

    // 0x8012F860: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x8012F864: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012F868: b           L_8012F888
    // 0x8012F86C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8012F888;
    // 0x8012F86C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8012F870:
    // 0x8012F870: b           L_8012F888
    // 0x8012F874: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8012F888;
    // 0x8012F874: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8012F878: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
L_8012F87C:
    // 0x8012F87C: nop

    // 0x8012F880: bltz        $t7, L_8012F870
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012F884: nop
    
            goto L_8012F870;
    }
    // 0x8012F884: nop

L_8012F888:
    // 0x8012F888: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012F88C: andi        $t9, $t7, 0xFFFF
    ctx->r25 = ctx->r15 & 0XFFFF;
    // 0x8012F890: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8012F894: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x8012F898: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
    // 0x8012F89C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012F8A0: lbu         $t6, 0x0($t7)
    ctx->r14 = MEM_BU(ctx->r15, 0X0);
    // 0x8012F8A4: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x8012F8A8: bgez        $t6, L_8012F8BC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8012F8AC: cvt.s.w     $f12, $f16
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    ctx->f12.fl = CVT_S_W(ctx->f16.u32l);
            goto L_8012F8BC;
    }
    // 0x8012F8AC: cvt.s.w     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    ctx->f12.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8012F8B0: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8012F8B4: nop

    // 0x8012F8B8: add.s       $f12, $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f18.fl;
L_8012F8BC:
    // 0x8012F8BC: jal         0x8012C314
    // 0x8012F8C0: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    get_glyph_width(rdram, ctx);
        goto after_4;
    // 0x8012F8C0: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    after_4:
    // 0x8012F8C4: lh          $t8, 0x0($s5)
    ctx->r24 = MEM_H(ctx->r21, 0X0);
    // 0x8012F8C8: addu        $t1, $s0, $v0
    ctx->r9 = ADD32(ctx->r16, ctx->r2);
    // 0x8012F8CC: andi        $t9, $t1, 0xFFFF
    ctx->r25 = ctx->r9 & 0XFFFF;
    // 0x8012F8D0: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x8012F8D4: addiu       $a3, $zero, 0x7530
    ctx->r7 = ADD32(0, 0X7530);
    // 0x8012F8D8: bne         $s7, $t8, L_8012F9B4
    if (ctx->r23 != ctx->r24) {
        // 0x8012F8DC: lhu         $t0, 0x5E($sp)
        ctx->r8 = MEM_HU(ctx->r29, 0X5E);
            goto L_8012F9B4;
    }
    // 0x8012F8DC: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F8E0: lh          $t6, 0x2($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X2);
    // 0x8012F8E4: addiu       $v1, $t9, -0x1
    ctx->r3 = ADD32(ctx->r25, -0X1);
    // 0x8012F8E8: addiu       $v0, $s5, 0x2
    ctx->r2 = ADD32(ctx->r21, 0X2);
    // 0x8012F8EC: andi        $t7, $v1, 0xFFFF
    ctx->r15 = ctx->r3 & 0XFFFF;
    // 0x8012F8F0: beq         $s7, $t6, L_8012F9B4
    if (ctx->r23 == ctx->r14) {
        // 0x8012F8F4: or          $s2, $v0, $zero
        ctx->r18 = ctx->r2 | 0;
            goto L_8012F9B4;
    }
    // 0x8012F8F4: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
    // 0x8012F8F8: lh          $t9, 0x0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X0);
    // 0x8012F8FC: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x8012F900: lhu         $s6, 0x6A($sp)
    ctx->r22 = MEM_HU(ctx->r29, 0X6A);
    // 0x8012F904: beql        $a3, $t9, L_8012F9B8
    if (ctx->r7 == ctx->r25) {
        // 0x8012F908: lh          $v0, 0x2($s5)
        ctx->r2 = MEM_H(ctx->r21, 0X2);
            goto L_8012F9B8;
    }
    goto skip_6;
    // 0x8012F908: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
    skip_6:
    // 0x8012F90C: lh          $v0, 0x0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X0);
    // 0x8012F910: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
L_8012F914:
    // 0x8012F914: sll         $s0, $v0, 16
    ctx->r16 = S32(ctx->r2 << 16);
    // 0x8012F918: sra         $t8, $s0, 16
    ctx->r24 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8012F91C: addu        $t6, $t7, $t8
    ctx->r14 = ADD32(ctx->r15, ctx->r24);
    // 0x8012F920: or          $s0, $t8, $zero
    ctx->r16 = ctx->r24 | 0;
    // 0x8012F924: sw          $t6, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r14;
    // 0x8012F928: lbu         $t8, 0x0($t6)
    ctx->r24 = MEM_BU(ctx->r14, 0X0);
    // 0x8012F92C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8012F930: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x8012F934: bgez        $t8, L_8012F948
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8012F938: cvt.s.w     $f12, $f4
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8012F948;
    }
    // 0x8012F938: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012F93C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012F940: nop

    // 0x8012F944: add.s       $f12, $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f6.fl;
L_8012F948:
    // 0x8012F948: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
    // 0x8012F94C: jal         0x8012C314
    // 0x8012F950: sh          $t1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r9;
    get_glyph_width(rdram, ctx);
        goto after_5;
    // 0x8012F950: sh          $t1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r9;
    after_5:
    // 0x8012F954: addu        $v1, $s1, $v0
    ctx->r3 = ADD32(ctx->r17, ctx->r2);
    // 0x8012F958: andi        $s1, $v1, 0xFFFF
    ctx->r17 = ctx->r3 & 0XFFFF;
    // 0x8012F95C: slt         $at, $s1, $s6
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r22) ? 1 : 0;
    // 0x8012F960: addiu       $a3, $zero, 0x7530
    ctx->r7 = ADD32(0, 0X7530);
    // 0x8012F964: lhu         $t0, 0x5E($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X5E);
    // 0x8012F968: bne         $at, $zero, L_8012F988
    if (ctx->r1 != 0) {
        // 0x8012F96C: lhu         $t1, 0x5A($sp)
        ctx->r9 = MEM_HU(ctx->r29, 0X5A);
            goto L_8012F988;
    }
    // 0x8012F96C: lhu         $t1, 0x5A($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X5A);
    // 0x8012F970: lbu         $t6, 0x6F($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X6F);
    // 0x8012F974: lhu         $t1, 0x48($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X48);
    // 0x8012F978: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8012F97C: addu        $t0, $t0, $t6
    ctx->r8 = ADD32(ctx->r8, ctx->r14);
    // 0x8012F980: andi        $t9, $t0, 0xFFFF
    ctx->r25 = ctx->r8 & 0XFFFF;
    // 0x8012F984: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
L_8012F988:
    // 0x8012F988: lw          $t8, 0x0($s3)
    ctx->r24 = MEM_W(ctx->r19, 0X0);
    // 0x8012F98C: addiu       $s2, $s2, 0x2
    ctx->r18 = ADD32(ctx->r18, 0X2);
    // 0x8012F990: subu        $t7, $t8, $s0
    ctx->r15 = SUB32(ctx->r24, ctx->r16);
    // 0x8012F994: sw          $t7, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r15;
    // 0x8012F998: lh          $v0, 0x0($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X0);
    // 0x8012F99C: beql        $s7, $v0, L_8012F9B8
    if (ctx->r23 == ctx->r2) {
        // 0x8012F9A0: lh          $v0, 0x2($s5)
        ctx->r2 = MEM_H(ctx->r21, 0X2);
            goto L_8012F9B8;
    }
    goto skip_7;
    // 0x8012F9A0: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
    skip_7:
    // 0x8012F9A4: beql        $a3, $v0, L_8012F9B8
    if (ctx->r7 == ctx->r2) {
        // 0x8012F9A8: lh          $v0, 0x2($s5)
        ctx->r2 = MEM_H(ctx->r21, 0X2);
            goto L_8012F9B8;
    }
    goto skip_8;
    // 0x8012F9A8: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
    skip_8:
    // 0x8012F9AC: beql        $s4, $zero, L_8012F914
    if (ctx->r20 == 0) {
        // 0x8012F9B0: lw          $t7, 0x0($s3)
        ctx->r15 = MEM_W(ctx->r19, 0X0);
            goto L_8012F914;
    }
    goto skip_9;
    // 0x8012F9B0: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
    skip_9:
L_8012F9B4:
    // 0x8012F9B4: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
L_8012F9B8:
    // 0x8012F9B8: sll         $s1, $t1, 16
    ctx->r17 = S32(ctx->r9 << 16);
    // 0x8012F9BC: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8012F9C0: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x8012F9C4: or          $s0, $t1, $zero
    ctx->r16 = ctx->r9 | 0;
    // 0x8012F9C8: bne         $s7, $v0, L_8012FA04
    if (ctx->r23 != ctx->r2) {
        // 0x8012F9CC: addiu       $s5, $s5, 0x2
        ctx->r21 = ADD32(ctx->r21, 0X2);
            goto L_8012FA04;
    }
    // 0x8012F9CC: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    // 0x8012F9D0: lhu         $v1, 0x48($sp)
    ctx->r3 = MEM_HU(ctx->r29, 0X48);
    // 0x8012F9D4: bnel        $v1, $s0, L_8012FA08
    if (ctx->r3 != ctx->r16) {
        // 0x8012F9D8: lw          $t9, 0x0($s3)
        ctx->r25 = MEM_W(ctx->r19, 0X0);
            goto L_8012FA08;
    }
    goto skip_10;
    // 0x8012F9D8: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    skip_10:
    // 0x8012F9DC: beql        $a3, $v0, L_8012FA08
    if (ctx->r7 == ctx->r2) {
        // 0x8012F9E0: lw          $t9, 0x0($s3)
        ctx->r25 = MEM_W(ctx->r19, 0X0);
            goto L_8012FA08;
    }
    goto skip_11;
    // 0x8012F9E0: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    skip_11:
    // 0x8012F9E4: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
L_8012F9E8:
    // 0x8012F9E8: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
    // 0x8012F9EC: bnel        $s7, $v0, L_8012FA08
    if (ctx->r23 != ctx->r2) {
        // 0x8012F9F0: lw          $t9, 0x0($s3)
        ctx->r25 = MEM_W(ctx->r19, 0X0);
            goto L_8012FA08;
    }
    goto skip_12;
    // 0x8012F9F0: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    skip_12:
    // 0x8012F9F4: bnel        $v1, $s0, L_8012FA08
    if (ctx->r3 != ctx->r16) {
        // 0x8012F9F8: lw          $t9, 0x0($s3)
        ctx->r25 = MEM_W(ctx->r19, 0X0);
            goto L_8012FA08;
    }
    goto skip_13;
    // 0x8012F9F8: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    skip_13:
    // 0x8012F9FC: bnel        $a3, $v0, L_8012F9E8
    if (ctx->r7 != ctx->r2) {
        // 0x8012FA00: lh          $v0, 0x2($s5)
        ctx->r2 = MEM_H(ctx->r21, 0X2);
            goto L_8012F9E8;
    }
    goto skip_14;
    // 0x8012FA00: lh          $v0, 0x2($s5)
    ctx->r2 = MEM_H(ctx->r21, 0X2);
    skip_14:
L_8012FA04:
    // 0x8012FA04: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
L_8012FA08:
    // 0x8012FA08: lh          $t8, 0x4E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X4E);
    // 0x8012FA0C: subu        $t7, $t9, $t8
    ctx->r15 = SUB32(ctx->r25, ctx->r24);
    // 0x8012FA10: b           L_8012FA1C
    // 0x8012FA14: sw          $t7, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r15;
        goto L_8012FA1C;
    // 0x8012FA14: sw          $t7, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r15;
    // 0x8012FA18: addiu       $s5, $s5, 0x2
    ctx->r21 = ADD32(ctx->r21, 0X2);
L_8012FA1C:
    // 0x8012FA1C: sh          $t0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r8;
L_8012FA20:
    // 0x8012FA20: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
    // 0x8012FA24: bnel        $a3, $t6, L_8012F2A8
    if (ctx->r7 != ctx->r14) {
        // 0x8012FA28: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8012F2A8;
    }
    goto skip_15;
    // 0x8012FA28: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_15:
L_8012FA2C:
    // 0x8012FA2C: lw          $v0, 0x0($fp)
    ctx->r2 = MEM_W(ctx->r30, 0X0);
    // 0x8012FA30: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x8012FA34: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012FA38: sw          $t9, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r25;
    // 0x8012FA3C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8012FA40: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8012FA44: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8012FA48: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x8012FA4C: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8012FA50: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x8012FA54: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x8012FA58: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8012FA5C: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x8012FA60: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x8012FA64: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x8012FA68: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8012FA6C: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x8012FA70: jr          $ra
    // 0x8012FA74: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    return;
    // 0x8012FA74: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
;}
RECOMP_FUNC void func_8012FA78(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012FA78: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FA7C: lui         $t7, 0xF590
    ctx->r15 = S32(0XF590 << 16);
    // 0x8012FA80: lui         $t8, 0x700
    ctx->r24 = S32(0X700 << 16);
    // 0x8012FA84: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012FA88: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012FA8C: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8012FA90: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8012FA94: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FA98: lui         $t0, 0xF580
    ctx->r8 = S32(0XF580 << 16);
    // 0x8012FA9C: ori         $t0, $t0, 0x200
    ctx->r8 = ctx->r8 | 0X200;
    // 0x8012FAA0: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012FAA4: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012FAA8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FAAC: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8012FAB0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FAB4: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x8012FAB8: ori         $t3, $t3, 0xC03C
    ctx->r11 = ctx->r11 | 0XC03C;
    // 0x8012FABC: addiu       $t1, $v1, 0x8
    ctx->r9 = ADD32(ctx->r3, 0X8);
    // 0x8012FAC0: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
    // 0x8012FAC4: lui         $t2, 0xF200
    ctx->r10 = S32(0XF200 << 16);
    // 0x8012FAC8: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x8012FACC: jr          $ra
    // 0x8012FAD0: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
    return;
    // 0x8012FAD0: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
;}
RECOMP_FUNC void func_8012FAD4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012FAD4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FAD8: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x8012FADC: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x8012FAE0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012FAE4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012FAE8: and         $t8, $a1, $at
    ctx->r24 = ctx->r5 & ctx->r1;
    // 0x8012FAEC: lui         $t7, 0xFD90
    ctx->r15 = S32(0XFD90 << 16);
    // 0x8012FAF0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8012FAF4: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8012FAF8: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FAFC: lui         $t1, 0xE600
    ctx->r9 = S32(0XE600 << 16);
    // 0x8012FB00: lui         $t4, 0x703
    ctx->r12 = S32(0X703 << 16);
    // 0x8012FB04: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012FB08: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012FB0C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FB10: sw          $t1, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r9;
    // 0x8012FB14: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FB18: ori         $t4, $t4, 0xF800
    ctx->r12 = ctx->r12 | 0XF800;
    // 0x8012FB1C: lui         $t3, 0xF300
    ctx->r11 = S32(0XF300 << 16);
    // 0x8012FB20: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x8012FB24: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x8012FB28: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    // 0x8012FB2C: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x8012FB30: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FB34: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x8012FB38: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x8012FB3C: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8012FB40: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FB44: jr          $ra
    // 0x8012FB48: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    return;
    // 0x8012FB48: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
;}
RECOMP_FUNC void load_glyph(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012FB4C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8012FB50: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FB54: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012FB58: lui         $t9, 0xFD90
    ctx->r25 = S32(0XFD90 << 16);
    // 0x8012FB5C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012FB60: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8012FB64: addiu       $t1, $t1, -0xE20
    ctx->r9 = ADD32(ctx->r9, -0XE20);
    // 0x8012FB68: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012FB6C: lhu         $t2, 0xC($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XC);
    // 0x8012FB70: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8012FB74: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012FB78: multu       $t7, $t2
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012FB7C: lw          $t4, 0x4($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X4);
    // 0x8012FB80: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x8012FB84: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x8012FB88: lui         $t8, 0xE600
    ctx->r24 = S32(0XE600 << 16);
    // 0x8012FB8C: lui         $t2, 0xF300
    ctx->r10 = S32(0XF300 << 16);
    // 0x8012FB90: mflo        $t3
    ctx->r11 = lo;
    // 0x8012FB94: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x8012FB98: and         $t6, $t5, $at
    ctx->r14 = ctx->r13 & ctx->r1;
    // 0x8012FB9C: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8012FBA0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FBA4: lui         $t3, 0x703
    ctx->r11 = S32(0X703 << 16);
    // 0x8012FBA8: ori         $t3, $t3, 0xF800
    ctx->r11 = ctx->r11 | 0XF800;
    // 0x8012FBAC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012FBB0: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012FBB4: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FBB8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012FBBC: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FBC0: lui         $t5, 0xE700
    ctx->r13 = S32(0XE700 << 16);
    // 0x8012FBC4: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012FBC8: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8012FBCC: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
    // 0x8012FBD0: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x8012FBD4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FBD8: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x8012FBDC: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x8012FBE0: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FBE4: jr          $ra
    // 0x8012FBE8: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    return;
    // 0x8012FBE8: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
;}
RECOMP_FUNC void display_text_wrapped(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012FBEC: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8012FBF0: sdc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X28, ctx->r29);
    // 0x8012FBF4: lwc1        $f24, 0x70($sp)
    ctx->f24.u32l = MEM_W(ctx->r29, 0X70);
    // 0x8012FBF8: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x8012FBFC: lhu         $t6, 0x6A($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X6A);
    // 0x8012FC00: lwc1        $f4, 0x74($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X74);
    // 0x8012FC04: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FC08: swc1        $f24, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f24.u32l;
    // 0x8012FC0C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FC10: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8012FC14: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x8012FC18: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x8012FC1C: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x8012FC20: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x8012FC24: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x8012FC28: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x8012FC2C: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x8012FC30: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x8012FC34: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8012FC38: sdc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X20, ctx->r29);
    // 0x8012FC3C: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x8012FC40: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x8012FC44: sw          $a3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r7;
    // 0x8012FC48: sh          $t6, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r14;
    // 0x8012FC4C: swc1        $f4, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f4.u32l;
    // 0x8012FC50: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FC54: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012FC58: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x8012FC5C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012FC60: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8012FC64: addiu       $t2, $t2, -0xE0F
    ctx->r10 = ADD32(ctx->r10, -0XE0F);
    // 0x8012FC68: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012FC6C: lbu         $t8, 0x0($t2)
    ctx->r24 = MEM_BU(ctx->r10, 0X0);
    // 0x8012FC70: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012FC74: addiu       $t1, $t1, -0xE10
    ctx->r9 = ADD32(ctx->r9, -0XE10);
    // 0x8012FC78: lbu         $t5, 0x0($t1)
    ctx->r13 = MEM_BU(ctx->r9, 0X0);
    // 0x8012FC7C: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x8012FC80: addiu       $t3, $t3, -0xE0E
    ctx->r11 = ADD32(ctx->r11, -0XE0E);
    // 0x8012FC84: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8012FC88: lbu         $t8, 0x0($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X0);
    // 0x8012FC8C: sll         $t6, $t5, 24
    ctx->r14 = S32(ctx->r13 << 24);
    // 0x8012FC90: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8012FC94: or          $t5, $t6, $t9
    ctx->r13 = ctx->r14 | ctx->r25;
    // 0x8012FC98: addiu       $t4, $t4, -0xE0D
    ctx->r12 = ADD32(ctx->r12, -0XE0D);
    // 0x8012FC9C: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x8012FCA0: lbu         $t8, 0x0($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X0);
    // 0x8012FCA4: or          $t9, $t5, $t6
    ctx->r25 = ctx->r13 | ctx->r14;
    // 0x8012FCA8: lui         $t7, 0xFB00
    ctx->r15 = S32(0XFB00 << 16);
    // 0x8012FCAC: or          $t5, $t9, $t8
    ctx->r13 = ctx->r25 | ctx->r24;
    // 0x8012FCB0: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x8012FCB4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012FCB8: or          $s7, $a0, $zero
    ctx->r23 = ctx->r4 | 0;
    // 0x8012FCBC: andi        $fp, $a3, 0xFFFF
    ctx->r30 = ctx->r7 & 0XFFFF;
    // 0x8012FCC0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012FCC4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012FCC8: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8012FCCC: lbu         $t7, 0x0($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X0);
    // 0x8012FCD0: lbu         $t8, 0x0($t1)
    ctx->r24 = MEM_BU(ctx->r9, 0X0);
    // 0x8012FCD4: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8012FCD8: lbu         $t7, 0x0($t3)
    ctx->r15 = MEM_BU(ctx->r11, 0X0);
    // 0x8012FCDC: sll         $t5, $t8, 24
    ctx->r13 = S32(ctx->r24 << 24);
    // 0x8012FCE0: or          $t8, $t5, $t9
    ctx->r24 = ctx->r13 | ctx->r25;
    // 0x8012FCE4: sll         $t5, $t7, 8
    ctx->r13 = S32(ctx->r15 << 8);
    // 0x8012FCE8: lbu         $t7, 0x0($t4)
    ctx->r15 = MEM_BU(ctx->r12, 0X0);
    // 0x8012FCEC: or          $t9, $t8, $t5
    ctx->r25 = ctx->r24 | ctx->r13;
    // 0x8012FCF0: or          $t8, $t9, $t7
    ctx->r24 = ctx->r25 | ctx->r15;
    // 0x8012FCF4: jal         0x8012FA78
    // 0x8012FCF8: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    func_8012FA78(rdram, ctx);
        goto after_0;
    // 0x8012FCF8: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    after_0:
    // 0x8012FCFC: lw          $t5, 0x64($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X64);
    // 0x8012FD00: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8012FD04: lhu         $a3, 0x6A($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X6A);
    // 0x8012FD08: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x8012FD0C: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x8012FD10: beq         $t6, $at, L_8013048C
    if (ctx->r14 == ctx->r1) {
        // 0x8012FD14: lui         $at, 0x4150
        ctx->r1 = S32(0X4150 << 16);
            goto L_8013048C;
    }
    // 0x8012FD14: lui         $at, 0x4150
    ctx->r1 = S32(0X4150 << 16);
    // 0x8012FD18: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8012FD1C: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x8012FD20: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8012FD24: addiu       $s3, $s3, -0xE20
    ctx->r19 = ADD32(ctx->r19, -0XE20);
    // 0x8012FD28: lw          $a0, 0x64($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X64);
L_8012FD2C:
    // 0x8012FD2C: or          $s1, $a3, $zero
    ctx->r17 = ctx->r7 | 0;
    // 0x8012FD30: andi        $a1, $a3, 0xFFFF
    ctx->r5 = ctx->r7 & 0XFFFF;
    // 0x8012FD34: andi        $a2, $fp, 0xFFFF
    ctx->r6 = ctx->r30 & 0XFFFF;
    // 0x8012FD38: jal         0x8012C678
    // 0x8012FD3C: sh          $a3, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r7;
    func_8012C678(rdram, ctx);
        goto after_1;
    // 0x8012FD3C: sh          $a3, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r7;
    after_1:
    // 0x8012FD40: beq         $v0, $zero, L_8012FD74
    if (ctx->r2 == 0) {
        // 0x8012FD44: lhu         $a3, 0x6A($sp)
        ctx->r7 = MEM_HU(ctx->r29, 0X6A);
            goto L_8012FD74;
    }
    // 0x8012FD44: lhu         $a3, 0x6A($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X6A);
    // 0x8012FD48: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8012FD4C: beq         $v0, $at, L_8012FD68
    if (ctx->r2 == ctx->r1) {
        // 0x8012FD50: lw          $t8, 0x64($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X64);
            goto L_8012FD68;
    }
    // 0x8012FD50: lw          $t8, 0x64($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X64);
    // 0x8012FD54: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8012FD58: beq         $v0, $at, L_80130470
    if (ctx->r2 == ctx->r1) {
        // 0x8012FD5C: lw          $t5, 0x64($sp)
        ctx->r13 = MEM_W(ctx->r29, 0X64);
            goto L_80130470;
    }
    // 0x8012FD5C: lw          $t5, 0x64($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X64);
    // 0x8012FD60: b           L_8013047C
    // 0x8012FD64: lw          $a0, 0x64($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X64);
        goto L_8013047C;
    // 0x8012FD64: lw          $a0, 0x64($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X64);
L_8012FD68:
    // 0x8012FD68: addiu       $t5, $t8, 0x6
    ctx->r13 = ADD32(ctx->r24, 0X6);
    // 0x8012FD6C: b           L_80130478
    // 0x8012FD70: sw          $t5, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r13;
        goto L_80130478;
    // 0x8012FD70: sw          $t5, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r13;
L_8012FD74:
    // 0x8012FD74: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FD78: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012FD7C: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8012FD80: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8012FD84: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8012FD88: addiu       $t0, $t0, -0xE0F
    ctx->r8 = ADD32(ctx->r8, -0XE0F);
    // 0x8012FD8C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012FD90: lbu         $t9, 0x0($t0)
    ctx->r25 = MEM_BU(ctx->r8, 0X0);
    // 0x8012FD94: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8012FD98: addiu       $a3, $a3, -0xE10
    ctx->r7 = ADD32(ctx->r7, -0XE10);
    // 0x8012FD9C: lbu         $t8, 0x0($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X0);
    // 0x8012FDA0: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012FDA4: addiu       $t1, $t1, -0xE0E
    ctx->r9 = ADD32(ctx->r9, -0XE0E);
    // 0x8012FDA8: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8012FDAC: lbu         $t9, 0x0($t1)
    ctx->r25 = MEM_BU(ctx->r9, 0X0);
    // 0x8012FDB0: sll         $t5, $t8, 24
    ctx->r13 = S32(ctx->r24 << 24);
    // 0x8012FDB4: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012FDB8: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x8012FDBC: addiu       $t2, $t2, -0xE0D
    ctx->r10 = ADD32(ctx->r10, -0XE0D);
    // 0x8012FDC0: sll         $t5, $t9, 8
    ctx->r13 = S32(ctx->r25 << 8);
    // 0x8012FDC4: lbu         $t9, 0x0($t2)
    ctx->r25 = MEM_BU(ctx->r10, 0X0);
    // 0x8012FDC8: or          $t7, $t8, $t5
    ctx->r15 = ctx->r24 | ctx->r13;
    // 0x8012FDCC: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012FDD0: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8012FDD4: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8012FDD8: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FDDC: sll         $s4, $fp, 2
    ctx->r20 = S32(ctx->r30 << 2);
    // 0x8012FDE0: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x8012FDE4: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x8012FDE8: sw          $t5, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r13;
    // 0x8012FDEC: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8012FDF0: lbu         $t6, 0x0($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X0);
    // 0x8012FDF4: lbu         $t9, 0x0($a3)
    ctx->r25 = MEM_BU(ctx->r7, 0X0);
    // 0x8012FDF8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8012FDFC: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x8012FE00: lbu         $t6, 0x0($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X0);
    // 0x8012FE04: sll         $t8, $t9, 24
    ctx->r24 = S32(ctx->r25 << 24);
    // 0x8012FE08: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x8012FE0C: sll         $t8, $t6, 8
    ctx->r24 = S32(ctx->r14 << 8);
    // 0x8012FE10: lbu         $t6, 0x0($t2)
    ctx->r14 = MEM_BU(ctx->r10, 0X0);
    // 0x8012FE14: or          $t7, $t9, $t8
    ctx->r15 = ctx->r25 | ctx->r24;
    // 0x8012FE18: or          $s0, $fp, $zero
    ctx->r16 = ctx->r30 | 0;
    // 0x8012FE1C: or          $t9, $t7, $t6
    ctx->r25 = ctx->r15 | ctx->r14;
    // 0x8012FE20: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8012FE24: lw          $t8, 0x64($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X64);
    // 0x8012FE28: andi        $t7, $s4, 0xFFF
    ctx->r15 = ctx->r20 & 0XFFF;
    // 0x8012FE2C: or          $s4, $t7, $zero
    ctx->r20 = ctx->r15 | 0;
    // 0x8012FE30: lh          $s2, 0x0($t8)
    ctx->r18 = MEM_H(ctx->r24, 0X0);
    // 0x8012FE34: sll         $a1, $s2, 16
    ctx->r5 = S32(ctx->r18 << 16);
    // 0x8012FE38: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8012FE3C: jal         0x8012FB4C
    // 0x8012FE40: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    load_glyph(rdram, ctx);
        goto after_2;
    // 0x8012FE40: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    after_2:
    // 0x8012FE44: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8012FE48: lbu         $t6, -0xE0B($t6)
    ctx->r14 = MEM_BU(ctx->r14, -0XE0B);
    // 0x8012FE4C: beql        $t6, $zero, L_80130110
    if (ctx->r14 == 0) {
        // 0x8012FE50: lw          $v1, 0x0($s7)
        ctx->r3 = MEM_W(ctx->r23, 0X0);
            goto L_80130110;
    }
    goto skip_0;
    // 0x8012FE50: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    skip_0:
    // 0x8012FE54: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FE58: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x8012FE5C: addiu       $t5, $zero, 0xFF
    ctx->r13 = ADD32(0, 0XFF);
    // 0x8012FE60: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012FE64: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8012FE68: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x8012FE6C: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012FE70: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FE74: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8012FE78: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FE7C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012FE80: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8012FE84: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FE88: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8012FE8C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FE90: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8012FE94: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x8012FE98: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8012FE9C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8012FEA0: lwc1        $f6, -0xE08($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012FEA4: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x8012FEA8: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8012FEAC: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8012FEB0: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x8012FEB4: addiu       $t2, $t2, -0xE0D
    ctx->r10 = ADD32(ctx->r10, -0XE0D);
    // 0x8012FEB8: addiu       $t1, $t1, -0xE0E
    ctx->r9 = ADD32(ctx->r9, -0XE0E);
    // 0x8012FEBC: mfc1        $t5, $f8
    ctx->r13 = (int32_t)ctx->f8.u32l;
    // 0x8012FEC0: addiu       $t0, $t0, -0xE0F
    ctx->r8 = ADD32(ctx->r8, -0XE0F);
    // 0x8012FEC4: addiu       $a3, $a3, -0xE10
    ctx->r7 = ADD32(ctx->r7, -0XE10);
    // 0x8012FEC8: addu        $t7, $s1, $t5
    ctx->r15 = ADD32(ctx->r17, ctx->r13);
    // 0x8012FECC: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x8012FED0: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x8012FED4: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x8012FED8: sll         $t5, $t8, 12
    ctx->r13 = S32(ctx->r24 << 12);
    // 0x8012FEDC: or          $t7, $t5, $at
    ctx->r15 = ctx->r13 | ctx->r1;
    // 0x8012FEE0: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FEE4: lwc1        $f10, -0xE04($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012FEE8: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FEEC: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8012FEF0: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
    // 0x8012FEF4: nop

    // 0x8012FEF8: addu        $t8, $s0, $t9
    ctx->r24 = ADD32(ctx->r16, ctx->r25);
    // 0x8012FEFC: addiu       $t5, $t8, 0x1
    ctx->r13 = ADD32(ctx->r24, 0X1);
    // 0x8012FF00: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8012FF04: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x8012FF08: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8012FF0C: addiu       $t5, $s1, 0x1
    ctx->r13 = ADD32(ctx->r17, 0X1);
    // 0x8012FF10: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8012FF14: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8012FF18: addiu       $t8, $s0, 0x1
    ctx->r24 = ADD32(ctx->r16, 0X1);
    // 0x8012FF1C: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x8012FF20: sll         $t5, $t8, 2
    ctx->r13 = S32(ctx->r24 << 2);
    // 0x8012FF24: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x8012FF28: sll         $t9, $t7, 12
    ctx->r25 = S32(ctx->r15 << 12);
    // 0x8012FF2C: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8012FF30: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8012FF34: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8012FF38: lui         $t5, 0xB400
    ctx->r13 = S32(0XB400 << 16);
    // 0x8012FF3C: lui         $t6, 0xB300
    ctx->r14 = S32(0XB300 << 16);
    // 0x8012FF40: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012FF44: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8012FF48: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012FF4C: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8012FF50: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    // 0x8012FF54: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012FF58: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8012FF5C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8012FF60: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8012FF64: lwc1        $f18, -0xE08($at)
    ctx->f18.u32l = MEM_W(ctx->r1, -0XE08);
    // 0x8012FF68: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012FF6C: div.s       $f4, $f20, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f20.fl, ctx->f18.fl);
    // 0x8012FF70: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8012FF74: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012FF78: nop

    // 0x8012FF7C: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8012FF80: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012FF84: nop

    // 0x8012FF88: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012FF8C: beql        $t8, $zero, L_8012FFDC
    if (ctx->r24 == 0) {
        // 0x8012FF90: mfc1        $t8, $f6
        ctx->r24 = (int32_t)ctx->f6.u32l;
            goto L_8012FFDC;
    }
    goto skip_1;
    // 0x8012FF90: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    skip_1:
    // 0x8012FF94: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8012FF98: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8012FF9C: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x8012FFA0: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8012FFA4: nop

    // 0x8012FFA8: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8012FFAC: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8012FFB0: nop

    // 0x8012FFB4: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8012FFB8: bne         $t8, $zero, L_8012FFD0
    if (ctx->r24 != 0) {
        // 0x8012FFBC: nop
    
            goto L_8012FFD0;
    }
    // 0x8012FFBC: nop

    // 0x8012FFC0: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x8012FFC4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012FFC8: b           L_8012FFE8
    // 0x8012FFCC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_8012FFE8;
    // 0x8012FFCC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_8012FFD0:
    // 0x8012FFD0: b           L_8012FFE8
    // 0x8012FFD4: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_8012FFE8;
    // 0x8012FFD4: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8012FFD8: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
L_8012FFDC:
    // 0x8012FFDC: nop

    // 0x8012FFE0: bltz        $t8, L_8012FFD0
    if (SIGNED(ctx->r24) < 0) {
        // 0x8012FFE4: nop
    
            goto L_8012FFD0;
    }
    // 0x8012FFE4: nop

L_8012FFE8:
    // 0x8012FFE8: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8012FFEC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8012FFF0: lwc1        $f8, -0xE04($at)
    ctx->f8.u32l = MEM_W(ctx->r1, -0XE04);
    // 0x8012FFF4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8012FFF8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8012FFFC: div.s       $f10, $f20, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f20.fl, ctx->f8.fl);
    // 0x80130000: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80130004: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80130008: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8013000C: nop

    // 0x80130010: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x80130014: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80130018: nop

    // 0x8013001C: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80130020: beql        $t7, $zero, L_80130070
    if (ctx->r15 == 0) {
        // 0x80130024: mfc1        $t7, $f16
        ctx->r15 = (int32_t)ctx->f16.u32l;
            goto L_80130070;
    }
    goto skip_2;
    // 0x80130024: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
    skip_2:
    // 0x80130028: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8013002C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80130030: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x80130034: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80130038: nop

    // 0x8013003C: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80130040: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80130044: nop

    // 0x80130048: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8013004C: bne         $t7, $zero, L_80130064
    if (ctx->r15 != 0) {
        // 0x80130050: nop
    
            goto L_80130064;
    }
    // 0x80130050: nop

    // 0x80130054: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
    // 0x80130058: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8013005C: b           L_8013007C
    // 0x80130060: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8013007C;
    // 0x80130060: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_80130064:
    // 0x80130064: b           L_8013007C
    // 0x80130068: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8013007C;
    // 0x80130068: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8013006C: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
L_80130070:
    // 0x80130070: nop

    // 0x80130074: bltz        $t7, L_80130064
    if (SIGNED(ctx->r15) < 0) {
        // 0x80130078: nop
    
            goto L_80130064;
    }
    // 0x80130078: nop

L_8013007C:
    // 0x8013007C: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x80130080: or          $t5, $t9, $t8
    ctx->r13 = ctx->r25 | ctx->r24;
    // 0x80130084: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80130088: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8013008C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80130090: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x80130094: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80130098: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8013009C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x801300A0: lbu         $t7, 0x0($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X0);
    // 0x801300A4: lbu         $t8, 0x0($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X0);
    // 0x801300A8: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x801300AC: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x801300B0: lbu         $t7, 0x0($t1)
    ctx->r15 = MEM_BU(ctx->r9, 0X0);
    // 0x801300B4: sll         $t5, $t8, 24
    ctx->r13 = S32(ctx->r24 << 24);
    // 0x801300B8: or          $t8, $t5, $t9
    ctx->r24 = ctx->r13 | ctx->r25;
    // 0x801300BC: sll         $t5, $t7, 8
    ctx->r13 = S32(ctx->r15 << 8);
    // 0x801300C0: lbu         $t7, 0x0($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X0);
    // 0x801300C4: or          $t9, $t8, $t5
    ctx->r25 = ctx->r24 | ctx->r13;
    // 0x801300C8: or          $t8, $t9, $t7
    ctx->r24 = ctx->r25 | ctx->r15;
    // 0x801300CC: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x801300D0: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x801300D4: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x801300D8: sw          $t5, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r13;
    // 0x801300DC: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x801300E0: lbu         $t6, 0x0($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X0);
    // 0x801300E4: lbu         $t7, 0x0($a3)
    ctx->r15 = MEM_BU(ctx->r7, 0X0);
    // 0x801300E8: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x801300EC: lbu         $t6, 0x0($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X0);
    // 0x801300F0: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x801300F4: or          $t7, $t8, $t9
    ctx->r15 = ctx->r24 | ctx->r25;
    // 0x801300F8: sll         $t8, $t6, 8
    ctx->r24 = S32(ctx->r14 << 8);
    // 0x801300FC: lbu         $t6, 0x0($t2)
    ctx->r14 = MEM_BU(ctx->r10, 0X0);
    // 0x80130100: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80130104: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80130108: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8013010C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
L_80130110:
    // 0x80130110: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x80130114: addiu       $a2, $a2, -0xE08
    ctx->r6 = ADD32(ctx->r6, -0XE08);
    // 0x80130118: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8013011C: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80130120: lwc1        $f18, 0x0($a2)
    ctx->f18.u32l = MEM_W(ctx->r6, 0X0);
    // 0x80130124: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x80130128: addiu       $a3, $a3, -0xE04
    ctx->r7 = ADD32(ctx->r7, -0XE04);
    // 0x8013012C: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80130130: lwc1        $f6, 0x0($a3)
    ctx->f6.u32l = MEM_W(ctx->r7, 0X0);
    // 0x80130134: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x80130138: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x8013013C: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80130140: addu        $t6, $s1, $t9
    ctx->r14 = ADD32(ctx->r17, ctx->r25);
    // 0x80130144: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80130148: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8013014C: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x80130150: sll         $t5, $t8, 12
    ctx->r13 = S32(ctx->r24 << 12);
    // 0x80130154: or          $t9, $t5, $at
    ctx->r25 = ctx->r13 | ctx->r1;
    // 0x80130158: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x8013015C: sll         $t5, $t8, 2
    ctx->r13 = S32(ctx->r24 << 2);
    // 0x80130160: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x80130164: sll         $t8, $s1, 2
    ctx->r24 = S32(ctx->r17 << 2);
    // 0x80130168: andi        $t5, $t8, 0xFFF
    ctx->r13 = ctx->r24 & 0XFFF;
    // 0x8013016C: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80130170: sll         $t9, $t5, 12
    ctx->r25 = S32(ctx->r13 << 12);
    // 0x80130174: or          $t6, $t9, $s4
    ctx->r14 = ctx->r25 | ctx->r20;
    // 0x80130178: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x8013017C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80130180: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80130184: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x80130188: lui         $t9, 0xB300
    ctx->r25 = S32(0XB300 << 16);
    // 0x8013018C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80130190: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80130194: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80130198: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8013019C: lw          $a1, 0x0($s7)
    ctx->r5 = MEM_W(ctx->r23, 0X0);
    // 0x801301A0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x801301A4: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x801301A8: addiu       $t5, $a1, 0x8
    ctx->r13 = ADD32(ctx->r5, 0X8);
    // 0x801301AC: sw          $t5, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r13;
    // 0x801301B0: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x801301B4: lwc1        $f10, 0x0($a2)
    ctx->f10.u32l = MEM_W(ctx->r6, 0X0);
    // 0x801301B8: div.s       $f16, $f20, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f20.fl, ctx->f10.fl);
    // 0x801301BC: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x801301C0: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x801301C4: nop

    // 0x801301C8: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x801301CC: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x801301D0: nop

    // 0x801301D4: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x801301D8: beql        $t7, $zero, L_80130228
    if (ctx->r15 == 0) {
        // 0x801301DC: mfc1        $t7, $f18
        ctx->r15 = (int32_t)ctx->f18.u32l;
            goto L_80130228;
    }
    goto skip_3;
    // 0x801301DC: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    skip_3:
    // 0x801301E0: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x801301E4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x801301E8: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x801301EC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x801301F0: nop

    // 0x801301F4: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x801301F8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x801301FC: nop

    // 0x80130200: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80130204: bne         $t7, $zero, L_8013021C
    if (ctx->r15 != 0) {
        // 0x80130208: nop
    
            goto L_8013021C;
    }
    // 0x80130208: nop

    // 0x8013020C: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x80130210: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80130214: b           L_80130234
    // 0x80130218: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_80130234;
    // 0x80130218: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8013021C:
    // 0x8013021C: b           L_80130234
    // 0x80130220: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_80130234;
    // 0x80130220: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80130224: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
L_80130228:
    // 0x80130228: nop

    // 0x8013022C: bltz        $t7, L_8013021C
    if (SIGNED(ctx->r15) < 0) {
        // 0x80130230: nop
    
            goto L_8013021C;
    }
    // 0x80130230: nop

L_80130234:
    // 0x80130234: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80130238: lwc1        $f4, 0x0($a3)
    ctx->f4.u32l = MEM_W(ctx->r7, 0X0);
    // 0x8013023C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80130240: sll         $t5, $t7, 16
    ctx->r13 = S32(ctx->r15 << 16);
    // 0x80130244: div.s       $f6, $f20, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f20.fl, ctx->f4.fl);
    // 0x80130248: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8013024C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x80130250: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80130254: nop

    // 0x80130258: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8013025C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80130260: nop

    // 0x80130264: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80130268: beql        $t6, $zero, L_801302B8
    if (ctx->r14 == 0) {
        // 0x8013026C: mfc1        $t6, $f8
        ctx->r14 = (int32_t)ctx->f8.u32l;
            goto L_801302B8;
    }
    goto skip_4;
    // 0x8013026C: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
    skip_4:
    // 0x80130270: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80130274: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80130278: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8013027C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80130280: nop

    // 0x80130284: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80130288: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8013028C: nop

    // 0x80130290: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80130294: bne         $t6, $zero, L_801302AC
    if (ctx->r14 != 0) {
        // 0x80130298: nop
    
            goto L_801302AC;
    }
    // 0x80130298: nop

    // 0x8013029C: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
    // 0x801302A0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801302A4: b           L_801302C4
    // 0x801302A8: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_801302C4;
    // 0x801302A8: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_801302AC:
    // 0x801302AC: b           L_801302C4
    // 0x801302B0: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_801302C4;
    // 0x801302B0: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x801302B4: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
L_801302B8:
    // 0x801302B8: nop

    // 0x801302BC: bltz        $t6, L_801302AC
    if (SIGNED(ctx->r14) < 0) {
        // 0x801302C0: nop
    
            goto L_801302AC;
    }
    // 0x801302C0: nop

L_801302C4:
    // 0x801302C4: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x801302C8: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x801302CC: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x801302D0: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x801302D4: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    // 0x801302D8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x801302DC: addu        $t6, $t9, $s2
    ctx->r14 = ADD32(ctx->r25, ctx->r18);
    // 0x801302E0: sw          $t6, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r14;
    // 0x801302E4: lbu         $t7, 0x0($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X0);
    // 0x801302E8: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x801302EC: bgez        $t7, L_80130300
    if (SIGNED(ctx->r15) >= 0) {
        // 0x801302F0: cvt.s.w     $f12, $f10
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    ctx->f12.fl = CVT_S_W(ctx->f10.u32l);
            goto L_80130300;
    }
    // 0x801302F0: cvt.s.w     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    ctx->f12.fl = CVT_S_W(ctx->f10.u32l);
    // 0x801302F4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x801302F8: nop

    // 0x801302FC: add.s       $f12, $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f16.fl;
L_80130300:
    // 0x80130300: jal         0x8012C314
    // 0x80130304: nop

    get_glyph_width(rdram, ctx);
        goto after_3;
    // 0x80130304: nop

    after_3:
    // 0x80130308: c.lt.s      $f24, $f22
    CHECK_FR(ctx, 24);
    CHECK_FR(ctx, 22);
    c1cs = ctx->f24.fl < ctx->f22.fl;
    // 0x8013030C: lw          $t9, 0x0($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X0);
    // 0x80130310: addu        $a3, $s1, $v0
    ctx->r7 = ADD32(ctx->r17, ctx->r2);
    // 0x80130314: andi        $t8, $a3, 0xFFFF
    ctx->r24 = ctx->r7 & 0XFFFF;
    // 0x80130318: subu        $t6, $t9, $s2
    ctx->r14 = SUB32(ctx->r25, ctx->r18);
    // 0x8013031C: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80130320: bc1f        L_80130334
    if (!c1cs) {
        // 0x80130324: sw          $t6, 0x0($s3)
        MEM_W(0X0, ctx->r19) = ctx->r14;
            goto L_80130334;
    }
    // 0x80130324: sw          $t6, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r14;
    // 0x80130328: addiu       $a3, $t8, 0x1
    ctx->r7 = ADD32(ctx->r24, 0X1);
    // 0x8013032C: andi        $t5, $a3, 0xFFFF
    ctx->r13 = ctx->r7 & 0XFFFF;
    // 0x80130330: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
L_80130334:
    // 0x80130334: lw          $t7, 0x64($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X64);
    // 0x80130338: addiu       $a0, $a3, -0x1
    ctx->r4 = ADD32(ctx->r7, -0X1);
    // 0x8013033C: addiu       $at, $zero, 0x130
    ctx->r1 = ADD32(0, 0X130);
    // 0x80130340: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x80130344: andi        $s6, $a0, 0xFFFF
    ctx->r22 = ctx->r4 & 0XFFFF;
    // 0x80130348: andi        $v1, $a0, 0xFFFF
    ctx->r3 = ctx->r4 & 0XFFFF;
    // 0x8013034C: bne         $t8, $at, L_80130418
    if (ctx->r24 != ctx->r1) {
        // 0x80130350: nop
    
            goto L_80130418;
    }
    // 0x80130350: nop

    // 0x80130354: lh          $t9, 0x2($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X2);
    // 0x80130358: addiu       $v0, $t7, 0x2
    ctx->r2 = ADD32(ctx->r15, 0X2);
    // 0x8013035C: addiu       $at, $zero, 0x130
    ctx->r1 = ADD32(0, 0X130);
    // 0x80130360: beq         $t9, $at, L_80130418
    if (ctx->r25 == ctx->r1) {
        // 0x80130364: or          $s2, $v0, $zero
        ctx->r18 = ctx->r2 | 0;
            goto L_80130418;
    }
    // 0x80130364: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
    // 0x80130368: lh          $t6, 0x0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X0);
    // 0x8013036C: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x80130370: or          $s1, $v1, $zero
    ctx->r17 = ctx->r3 | 0;
    // 0x80130374: beq         $t6, $at, L_80130418
    if (ctx->r14 == ctx->r1) {
        // 0x80130378: lhu         $s4, 0x7A($sp)
        ctx->r20 = MEM_HU(ctx->r29, 0X7A);
            goto L_80130418;
    }
    // 0x80130378: lhu         $s4, 0x7A($sp)
    ctx->r20 = MEM_HU(ctx->r29, 0X7A);
    // 0x8013037C: lh          $v0, 0x0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X0);
    // 0x80130380: lw          $t5, 0x0($s3)
    ctx->r13 = MEM_W(ctx->r19, 0X0);
L_80130384:
    // 0x80130384: andi        $s0, $v0, 0xFFFF
    ctx->r16 = ctx->r2 & 0XFFFF;
    // 0x80130388: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8013038C: addu        $t8, $t5, $s0
    ctx->r24 = ADD32(ctx->r13, ctx->r16);
    // 0x80130390: sw          $t8, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r24;
    // 0x80130394: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x80130398: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8013039C: bgez        $t9, L_801303B0
    if (SIGNED(ctx->r25) >= 0) {
        // 0x801303A0: cvt.s.w     $f12, $f18
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
            goto L_801303B0;
    }
    // 0x801303A0: cvt.s.w     $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
    // 0x801303A4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x801303A8: nop

    // 0x801303AC: add.s       $f12, $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f4.fl;
L_801303B0:
    // 0x801303B0: jal         0x8012C314
    // 0x801303B4: sh          $a3, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r7;
    get_glyph_width(rdram, ctx);
        goto after_4;
    // 0x801303B4: sh          $a3, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r7;
    after_4:
    // 0x801303B8: addu        $v1, $s1, $v0
    ctx->r3 = ADD32(ctx->r17, ctx->r2);
    // 0x801303BC: andi        $s1, $v1, 0xFFFF
    ctx->r17 = ctx->r3 & 0XFFFF;
    // 0x801303C0: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x801303C4: bne         $at, $zero, L_801303E8
    if (ctx->r1 != 0) {
        // 0x801303C8: lhu         $a3, 0x6A($sp)
        ctx->r7 = MEM_HU(ctx->r29, 0X6A);
            goto L_801303E8;
    }
    // 0x801303C8: lhu         $a3, 0x6A($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X6A);
    // 0x801303CC: lbu         $t5, 0x7F($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X7F);
    // 0x801303D0: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x801303D4: lhu         $a3, 0x58($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X58);
    // 0x801303D8: addu        $fp, $fp, $t5
    ctx->r30 = ADD32(ctx->r30, ctx->r13);
    // 0x801303DC: andi        $t8, $fp, 0xFFFF
    ctx->r24 = ctx->r30 & 0XFFFF;
    // 0x801303E0: or          $fp, $t8, $zero
    ctx->r30 = ctx->r24 | 0;
    // 0x801303E4: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
L_801303E8:
    // 0x801303E8: lw          $t7, 0x0($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X0);
    // 0x801303EC: addiu       $at, $zero, 0x130
    ctx->r1 = ADD32(0, 0X130);
    // 0x801303F0: addiu       $s2, $s2, 0x2
    ctx->r18 = ADD32(ctx->r18, 0X2);
    // 0x801303F4: subu        $t9, $t7, $s0
    ctx->r25 = SUB32(ctx->r15, ctx->r16);
    // 0x801303F8: sw          $t9, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r25;
    // 0x801303FC: lh          $v0, 0x0($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X0);
    // 0x80130400: beq         $v0, $at, L_80130418
    if (ctx->r2 == ctx->r1) {
        // 0x80130404: addiu       $at, $zero, 0x7530
        ctx->r1 = ADD32(0, 0X7530);
            goto L_80130418;
    }
    // 0x80130404: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x80130408: beq         $v0, $at, L_80130418
    if (ctx->r2 == ctx->r1) {
        // 0x8013040C: nop
    
            goto L_80130418;
    }
    // 0x8013040C: nop

    // 0x80130410: beql        $s5, $zero, L_80130384
    if (ctx->r21 == 0) {
        // 0x80130414: lw          $t5, 0x0($s3)
        ctx->r13 = MEM_W(ctx->r19, 0X0);
            goto L_80130384;
    }
    goto skip_5;
    // 0x80130414: lw          $t5, 0x0($s3)
    ctx->r13 = MEM_W(ctx->r19, 0X0);
    skip_5:
L_80130418:
    // 0x80130418: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8013041C: lb          $t6, -0xD52($t6)
    ctx->r14 = MEM_B(ctx->r14, -0XD52);
    // 0x80130420: lw          $v0, 0x64($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X64);
    // 0x80130424: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80130428: bne         $t6, $at, L_80130468
    if (ctx->r14 != ctx->r1) {
        // 0x8013042C: addiu       $v0, $v0, 0x2
        ctx->r2 = ADD32(ctx->r2, 0X2);
            goto L_80130468;
    }
    // 0x8013042C: addiu       $v0, $v0, 0x2
    ctx->r2 = ADD32(ctx->r2, 0X2);
    // 0x80130430: lhu         $t5, 0x7A($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X7A);
    // 0x80130434: addiu       $t8, $t5, -0xA
    ctx->r24 = ADD32(ctx->r13, -0XA);
    // 0x80130438: slt         $at, $s6, $t8
    ctx->r1 = SIGNED(ctx->r22) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x8013043C: bne         $at, $zero, L_80130468
    if (ctx->r1 != 0) {
        // 0x80130440: nop
    
            goto L_80130468;
    }
    // 0x80130440: nop

    // 0x80130444: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x80130448: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x8013044C: lbu         $t9, 0x7F($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X7F);
    // 0x80130450: beq         $t7, $at, L_80130468
    if (ctx->r15 == ctx->r1) {
        // 0x80130454: nop
    
            goto L_80130468;
    }
    // 0x80130454: nop

    // 0x80130458: addu        $fp, $fp, $t9
    ctx->r30 = ADD32(ctx->r30, ctx->r25);
    // 0x8013045C: andi        $t6, $fp, 0xFFFF
    ctx->r14 = ctx->r30 & 0XFFFF;
    // 0x80130460: or          $fp, $t6, $zero
    ctx->r30 = ctx->r14 | 0;
    // 0x80130464: lhu         $a3, 0x58($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X58);
L_80130468:
    // 0x80130468: b           L_80130478
    // 0x8013046C: sw          $v0, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r2;
        goto L_80130478;
    // 0x8013046C: sw          $v0, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r2;
L_80130470:
    // 0x80130470: addiu       $t8, $t5, 0x2
    ctx->r24 = ADD32(ctx->r13, 0X2);
    // 0x80130474: sw          $t8, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r24;
L_80130478:
    // 0x80130478: lw          $a0, 0x64($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X64);
L_8013047C:
    // 0x8013047C: addiu       $at, $zero, 0x7530
    ctx->r1 = ADD32(0, 0X7530);
    // 0x80130480: lh          $t7, 0x0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X0);
    // 0x80130484: bnel        $t7, $at, L_8012FD2C
    if (ctx->r15 != ctx->r1) {
        // 0x80130488: lw          $a0, 0x64($sp)
        ctx->r4 = MEM_W(ctx->r29, 0X64);
            goto L_8012FD2C;
    }
    goto skip_6;
    // 0x80130488: lw          $a0, 0x64($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X64);
    skip_6:
L_8013048C:
    // 0x8013048C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80130490: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x80130494: sll         $v0, $fp, 16
    ctx->r2 = S32(ctx->r30 << 16);
    // 0x80130498: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8013049C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x801304A0: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801304A4: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x801304A8: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x801304AC: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x801304B0: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x801304B4: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x801304B8: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x801304BC: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x801304C0: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x801304C4: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x801304C8: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x801304CC: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x801304D0: ldc1        $f24, 0x28($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X28);
    // 0x801304D4: ldc1        $f22, 0x20($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X20);
    // 0x801304D8: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x801304DC: sra         $t5, $v0, 16
    ctx->r13 = S32(SIGNED(ctx->r2) >> 16);
    // 0x801304E0: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x801304E4: jr          $ra
    // 0x801304E8: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x801304E8: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
