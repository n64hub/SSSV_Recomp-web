#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_8039E6D4_7AFD84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039E6D4: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8039E6D8: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8039E6DC: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x8039E6E0: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x8039E6E4: lw          $s1, 0x240($a0)
    ctx->r17 = MEM_W(ctx->r4, 0X240);
    // 0x8039E6E8: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8039E6EC: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x8039E6F0: lh          $t6, 0x2E($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X2E);
    // 0x8039E6F4: sh          $t6, 0x40($sp)
    MEM_H(0X40, ctx->r29) = ctx->r14;
    // 0x8039E6F8: lh          $t7, 0x2C($s1)
    ctx->r15 = MEM_H(ctx->r17, 0X2C);
    // 0x8039E6FC: sh          $t7, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r15;
    // 0x8039E700: lw          $v1, 0x1C($s1)
    ctx->r3 = MEM_W(ctx->r17, 0X1C);
    // 0x8039E704: lw          $a2, 0x20($s1)
    ctx->r6 = MEM_W(ctx->r17, 0X20);
    // 0x8039E708: sra         $t8, $v1, 8
    ctx->r24 = S32(SIGNED(ctx->r3) >> 8);
    // 0x8039E70C: sra         $t9, $a2, 8
    ctx->r25 = S32(SIGNED(ctx->r6) >> 8);
    // 0x8039E710: or          $t2, $t8, $t9
    ctx->r10 = ctx->r24 | ctx->r25;
    // 0x8039E714: beql        $t2, $zero, L_8039EA40
    if (ctx->r10 == 0) {
        // 0x8039E718: sh          $zero, 0x5E($sp)
        MEM_H(0X5E, ctx->r29) = 0;
            goto L_8039EA40;
    }
    goto skip_0;
    // 0x8039E718: sh          $zero, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = 0;
    skip_0:
    // 0x8039E71C: multu       $t8, $t8
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E720: sw          $t8, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r24;
    // 0x8039E724: sw          $t9, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r25;
    // 0x8039E728: mflo        $t3
    ctx->r11 = lo;
    // 0x8039E72C: nop

    // 0x8039E730: nop

    // 0x8039E734: multu       $t9, $t9
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E738: mflo        $t4
    ctx->r12 = lo;
    // 0x8039E73C: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x8039E740: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x8039E744: jal         0x80137E10
    // 0x8039E748: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x8039E748: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    after_0:
    // 0x8039E74C: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8039E750: lw          $a0, 0x24($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X24);
    // 0x8039E754: mfc1        $a1, $f6
    ctx->r5 = (int32_t)ctx->f6.u32l;
    // 0x8039E758: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x8039E75C: sra         $t6, $a0, 8
    ctx->r14 = S32(SIGNED(ctx->r4) >> 8);
    // 0x8039E760: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x8039E764: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x8039E768: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8039E76C: jal         0x801284B8
    // 0x8039E770: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    func_801284B8(rdram, ctx);
        goto after_1;
    // 0x8039E770: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    after_1:
    // 0x8039E774: lw          $v1, 0x38($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X38);
    // 0x8039E778: lw          $a2, 0x34($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X34);
    // 0x8039E77C: sh          $v0, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r2;
    // 0x8039E780: sll         $a0, $v1, 16
    ctx->r4 = S32(ctx->r3 << 16);
    // 0x8039E784: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
    // 0x8039E788: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8039E78C: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8039E790: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x8039E794: jal         0x801284B8
    // 0x8039E798: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    func_801284B8(rdram, ctx);
        goto after_2;
    // 0x8039E798: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    after_2:
    // 0x8039E79C: lw          $t7, 0x16C($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X16C);
    // 0x8039E7A0: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x8039E7A4: sra         $t6, $t0, 16
    ctx->r14 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8039E7A8: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x8039E7AC: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x8039E7B0: lh          $t9, 0x42($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X42);
    // 0x8039E7B4: slti        $at, $t8, 0x100
    ctx->r1 = SIGNED(ctx->r24) < 0X100 ? 1 : 0;
    // 0x8039E7B8: bne         $at, $zero, L_8039E800
    if (ctx->r1 != 0) {
        // 0x8039E7BC: sll         $t8, $v0, 1
        ctx->r24 = S32(ctx->r2 << 1);
            goto L_8039E800;
    }
    // 0x8039E7BC: sll         $t8, $v0, 1
    ctx->r24 = S32(ctx->r2 << 1);
    // 0x8039E7C0: addiu       $t1, $zero, 0x168
    ctx->r9 = ADD32(0, 0X168);
    // 0x8039E7C4: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E7C8: lh          $t4, 0x40($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X40);
    // 0x8039E7CC: mflo        $t2
    ctx->r10 = lo;
    // 0x8039E7D0: bgez        $t2, L_8039E7E0
    if (SIGNED(ctx->r10) >= 0) {
        // 0x8039E7D4: sra         $t3, $t2, 8
        ctx->r11 = S32(SIGNED(ctx->r10) >> 8);
            goto L_8039E7E0;
    }
    // 0x8039E7D4: sra         $t3, $t2, 8
    ctx->r11 = S32(SIGNED(ctx->r10) >> 8);
    // 0x8039E7D8: addiu       $at, $t2, 0xFF
    ctx->r1 = ADD32(ctx->r10, 0XFF);
    // 0x8039E7DC: sra         $t3, $at, 8
    ctx->r11 = S32(SIGNED(ctx->r1) >> 8);
L_8039E7E0:
    // 0x8039E7E0: multu       $t4, $t1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E7E4: sh          $t3, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r11;
    // 0x8039E7E8: mflo        $t5
    ctx->r13 = lo;
    // 0x8039E7EC: bgez        $t5, L_8039E7FC
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8039E7F0: sra         $t6, $t5, 8
        ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
            goto L_8039E7FC;
    }
    // 0x8039E7F0: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x8039E7F4: addiu       $at, $t5, 0xFF
    ctx->r1 = ADD32(ctx->r13, 0XFF);
    // 0x8039E7F8: sra         $t6, $at, 8
    ctx->r14 = S32(SIGNED(ctx->r1) >> 8);
L_8039E7FC:
    // 0x8039E7FC: sh          $t6, 0x40($sp)
    MEM_H(0X40, ctx->r29) = ctx->r14;
L_8039E800:
    // 0x8039E800: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039E804: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x8039E808: addiu       $t1, $zero, 0x168
    ctx->r9 = ADD32(0, 0X168);
    // 0x8039E80C: srl         $t7, $v1, 28
    ctx->r15 = S32(U32(ctx->r3) >> 28);
    // 0x8039E810: beq         $t7, $zero, L_8039E840
    if (ctx->r15 == 0) {
        // 0x8039E814: addiu       $t9, $t9, 0x2350
        ctx->r25 = ADD32(ctx->r25, 0X2350);
            goto L_8039E840;
    }
    // 0x8039E814: addiu       $t9, $t9, 0x2350
    ctx->r25 = ADD32(ctx->r25, 0X2350);
    // 0x8039E818: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039E81C: beq         $t7, $at, L_8039E880
    if (ctx->r15 == ctx->r1) {
        // 0x8039E820: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8039E880;
    }
    // 0x8039E820: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039E824: beq         $t7, $at, L_8039E8C4
    if (ctx->r15 == ctx->r1) {
        // 0x8039E828: lui         $a3, 0x8015
        ctx->r7 = S32(0X8015 << 16);
            goto L_8039E8C4;
    }
    // 0x8039E828: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x8039E82C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039E830: beql        $t7, $at, L_8039E964
    if (ctx->r15 == ctx->r1) {
        // 0x8039E834: lbu         $a1, 0x4($s0)
        ctx->r5 = MEM_BU(ctx->r16, 0X4);
            goto L_8039E964;
    }
    goto skip_1;
    // 0x8039E834: lbu         $a1, 0x4($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X4);
    skip_1:
    // 0x8039E838: b           L_8039EA44
    // 0x8039E83C: lh          $t0, 0x5C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X5C);
        goto L_8039EA44;
    // 0x8039E83C: lh          $t0, 0x5C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X5C);
L_8039E840:
    // 0x8039E840: addu        $a2, $t8, $t9
    ctx->r6 = ADD32(ctx->r24, ctx->r25);
    // 0x8039E844: lh          $t2, 0x384($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X384);
    // 0x8039E848: lbu         $v1, 0x5($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X5);
    // 0x8039E84C: lh          $t5, 0x2D0($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X2D0);
    // 0x8039E850: sh          $zero, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = 0;
    // 0x8039E854: multu       $t2, $v1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E858: negu        $t6, $t5
    ctx->r14 = SUB32(0, ctx->r13);
    // 0x8039E85C: mflo        $t3
    ctx->r11 = lo;
    // 0x8039E860: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x8039E864: sh          $t4, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r12;
    // 0x8039E868: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E86C: mflo        $t0
    ctx->r8 = lo;
    // 0x8039E870: sra         $t7, $t0, 8
    ctx->r15 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8039E874: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039E878: b           L_8039EA44
    // 0x8039E87C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_8039EA44;
    // 0x8039E87C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_8039E880:
    // 0x8039E880: lh          $t2, 0x44($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X44);
    // 0x8039E884: lbu         $a2, 0x5($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X5);
    // 0x8039E888: addiu       $t5, $sp, 0x48
    ctx->r13 = ADD32(ctx->r29, 0X48);
    // 0x8039E88C: subu        $a3, $t1, $t2
    ctx->r7 = SUB32(ctx->r9, ctx->r10);
    // 0x8039E890: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x8039E894: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8039E898: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x8039E89C: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8039E8A0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039E8A4: jal         0x802F5F44
    // 0x8039E8A8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_3;
    // 0x8039E8A8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_3:
    // 0x8039E8AC: lh          $t6, 0x48($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X48);
    // 0x8039E8B0: lh          $t7, 0x4C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X4C);
    // 0x8039E8B4: lh          $t0, 0x4A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X4A);
    // 0x8039E8B8: sh          $t6, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r14;
    // 0x8039E8BC: b           L_8039EA44
    // 0x8039E8C0: sh          $t7, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r15;
        goto L_8039EA44;
    // 0x8039E8C0: sh          $t7, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r15;
L_8039E8C4:
    // 0x8039E8C4: lbu         $a1, 0x4($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X4);
    // 0x8039E8C8: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x8039E8CC: lbu         $v1, 0x5($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X5);
    // 0x8039E8D0: addiu       $t8, $a1, 0x40
    ctx->r24 = ADD32(ctx->r5, 0X40);
    // 0x8039E8D4: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8039E8D8: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8039E8DC: addu        $t3, $a3, $t2
    ctx->r11 = ADD32(ctx->r7, ctx->r10);
    // 0x8039E8E0: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x8039E8E4: andi        $t8, $a1, 0xFF
    ctx->r24 = ctx->r5 & 0XFF;
    // 0x8039E8E8: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8039E8EC: multu       $t4, $v1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E8F0: addu        $t2, $a3, $t9
    ctx->r10 = ADD32(ctx->r7, ctx->r25);
    // 0x8039E8F4: lh          $t3, 0x0($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X0);
    // 0x8039E8F8: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8039E8FC: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x8039E900: negu        $t4, $t3
    ctx->r12 = SUB32(0, ctx->r11);
    // 0x8039E904: sll         $t7, $v0, 1
    ctx->r15 = S32(ctx->r2 << 1);
    // 0x8039E908: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x8039E90C: lh          $t9, 0x384($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X384);
    // 0x8039E910: mflo        $a0
    ctx->r4 = lo;
    // 0x8039E914: sra         $t5, $a0, 15
    ctx->r13 = S32(SIGNED(ctx->r4) >> 15);
    // 0x8039E918: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8039E91C: multu       $t4, $v1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E920: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039E924: lh          $t4, 0x2D0($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X2D0);
    // 0x8039E928: mflo        $t5
    ctx->r13 = lo;
    // 0x8039E92C: sra         $t6, $t5, 15
    ctx->r14 = S32(SIGNED(ctx->r13) >> 15);
    // 0x8039E930: negu        $t5, $a0
    ctx->r13 = SUB32(0, ctx->r4);
    // 0x8039E934: multu       $t9, $a0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E938: sh          $t6, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r14;
    // 0x8039E93C: mflo        $t2
    ctx->r10 = lo;
    // 0x8039E940: sra         $t3, $t2, 8
    ctx->r11 = S32(SIGNED(ctx->r10) >> 8);
    // 0x8039E944: sh          $t3, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r11;
    // 0x8039E948: multu       $t4, $t5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E94C: mflo        $t0
    ctx->r8 = lo;
    // 0x8039E950: sra         $t6, $t0, 8
    ctx->r14 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8039E954: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x8039E958: b           L_8039EA44
    // 0x8039E95C: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
        goto L_8039EA44;
    // 0x8039E95C: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039E960: lbu         $a1, 0x4($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X4);
L_8039E964:
    // 0x8039E964: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x8039E968: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x8039E96C: addiu       $t9, $a1, 0x40
    ctx->r25 = ADD32(ctx->r5, 0X40);
    // 0x8039E970: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x8039E974: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x8039E978: addu        $t4, $a3, $t3
    ctx->r12 = ADD32(ctx->r7, ctx->r11);
    // 0x8039E97C: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x8039E980: lbu         $v1, 0x5($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X5);
    // 0x8039E984: andi        $t9, $a1, 0xFF
    ctx->r25 = ctx->r5 & 0XFF;
    // 0x8039E988: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8039E98C: multu       $t5, $v1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E990: addu        $t3, $a3, $t2
    ctx->r11 = ADD32(ctx->r7, ctx->r10);
    // 0x8039E994: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x8039E998: negu        $t5, $t4
    ctx->r13 = SUB32(0, ctx->r12);
    // 0x8039E99C: mflo        $a0
    ctx->r4 = lo;
    // 0x8039E9A0: sra         $t8, $a0, 15
    ctx->r24 = S32(SIGNED(ctx->r4) >> 15);
    // 0x8039E9A4: sh          $t8, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r24;
    // 0x8039E9A8: multu       $t5, $v1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E9AC: mflo        $t6
    ctx->r14 = lo;
    // 0x8039E9B0: sra         $t7, $t6, 15
    ctx->r15 = S32(SIGNED(ctx->r14) >> 15);
    // 0x8039E9B4: jal         0x80128200
    // 0x8039E9B8: sh          $t7, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r15;
    func_80128200(rdram, ctx);
        goto after_4;
    // 0x8039E9B8: sh          $t7, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r15;
    after_4:
    // 0x8039E9BC: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8039E9C0: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8039E9C4: mfhi        $t8
    ctx->r24 = hi;
    // 0x8039E9C8: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8039E9CC: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039E9D0: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x8039E9D4: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x8039E9D8: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x8039E9DC: lh          $t4, 0x26D4($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X26D4);
    // 0x8039E9E0: lh          $a0, 0x58($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X58);
    // 0x8039E9E4: multu       $t4, $a0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E9E8: mflo        $t5
    ctx->r13 = lo;
    // 0x8039E9EC: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x8039E9F0: jal         0x80128200
    // 0x8039E9F4: sh          $t6, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r14;
    func_80128200(rdram, ctx);
        goto after_5;
    // 0x8039E9F4: sh          $t6, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r14;
    after_5:
    // 0x8039E9F8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8039E9FC: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8039EA00: mfhi        $t7
    ctx->r15 = hi;
    // 0x8039EA04: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039EA08: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039EA0C: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8039EA10: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x8039EA14: lh          $a0, 0x58($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X58);
    // 0x8039EA18: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x8039EA1C: lh          $t3, 0x2620($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X2620);
    // 0x8039EA20: negu        $t4, $a0
    ctx->r12 = SUB32(0, ctx->r4);
    // 0x8039EA24: multu       $t3, $t4
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039EA28: mflo        $t0
    ctx->r8 = lo;
    // 0x8039EA2C: sra         $t5, $t0, 8
    ctx->r13 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8039EA30: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8039EA34: b           L_8039EA44
    // 0x8039EA38: sra         $t0, $t6, 16
    ctx->r8 = S32(SIGNED(ctx->r14) >> 16);
        goto L_8039EA44;
    // 0x8039EA38: sra         $t0, $t6, 16
    ctx->r8 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039EA3C: sh          $zero, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = 0;
L_8039EA40:
    // 0x8039EA40: sh          $zero, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = 0;
L_8039EA44:
    // 0x8039EA44: lhu         $t9, 0x42($s1)
    ctx->r25 = MEM_HU(ctx->r17, 0X42);
    // 0x8039EA48: lh          $t8, 0x23C($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X23C);
    // 0x8039EA4C: lh          $t5, 0x42($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X42);
    // 0x8039EA50: sra         $t2, $t9, 1
    ctx->r10 = S32(SIGNED(ctx->r25) >> 1);
    // 0x8039EA54: lh          $a0, 0x238($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X238);
    // 0x8039EA58: lh          $a1, 0x23A($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X23A);
    // 0x8039EA5C: addu        $a2, $t8, $t2
    ctx->r6 = ADD32(ctx->r24, ctx->r10);
    // 0x8039EA60: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x8039EA64: addiu       $t6, $sp, 0x48
    ctx->r14 = ADD32(ctx->r29, 0X48);
    // 0x8039EA68: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8039EA6C: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8039EA70: sh          $t0, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r8;
    // 0x8039EA74: lh          $a3, 0x40($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X40);
    // 0x8039EA78: jal         0x802F5F44
    // 0x8039EA7C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_6;
    // 0x8039EA7C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_6:
    // 0x8039EA80: lh          $t7, 0x4($s1)
    ctx->r15 = MEM_H(ctx->r17, 0X4);
    // 0x8039EA84: lh          $t9, 0x5E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X5E);
    // 0x8039EA88: lbu         $t4, 0x1($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EA8C: lh          $t2, 0x48($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X48);
    // 0x8039EA90: subu        $t8, $t7, $t9
    ctx->r24 = SUB32(ctx->r15, ctx->r25);
    // 0x8039EA94: sll         $t5, $t4, 4
    ctx->r13 = S32(ctx->r12 << 4);
    // 0x8039EA98: lh          $t0, 0x5C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X5C);
    // 0x8039EA9C: addu        $t6, $s0, $t5
    ctx->r14 = ADD32(ctx->r16, ctx->r13);
    // 0x8039EAA0: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x8039EAA4: sh          $t3, 0x38($t6)
    MEM_H(0X38, ctx->r14) = ctx->r11;
    // 0x8039EAA8: lbu         $t4, 0x1($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EAAC: lh          $t7, 0x8($s1)
    ctx->r15 = MEM_H(ctx->r17, 0X8);
    // 0x8039EAB0: lh          $t8, 0x4A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X4A);
    // 0x8039EAB4: sll         $t5, $t4, 4
    ctx->r13 = S32(ctx->r12 << 4);
    // 0x8039EAB8: subu        $t9, $t7, $t0
    ctx->r25 = SUB32(ctx->r15, ctx->r8);
    // 0x8039EABC: addu        $t3, $s0, $t5
    ctx->r11 = ADD32(ctx->r16, ctx->r13);
    // 0x8039EAC0: addu        $t2, $t9, $t8
    ctx->r10 = ADD32(ctx->r25, ctx->r24);
    // 0x8039EAC4: sh          $t2, 0x3A($t3)
    MEM_H(0X3A, ctx->r11) = ctx->r10;
    // 0x8039EAC8: lbu         $t5, 0x1($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EACC: lh          $t7, 0x5A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X5A);
    // 0x8039EAD0: lh          $t6, 0xC($s1)
    ctx->r14 = MEM_H(ctx->r17, 0XC);
    // 0x8039EAD4: lh          $t8, 0x4C($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X4C);
    // 0x8039EAD8: sll         $t2, $t5, 4
    ctx->r10 = S32(ctx->r13 << 4);
    // 0x8039EADC: subu        $t9, $t6, $t7
    ctx->r25 = SUB32(ctx->r14, ctx->r15);
    // 0x8039EAE0: addu        $t3, $s0, $t2
    ctx->r11 = ADD32(ctx->r16, ctx->r10);
    // 0x8039EAE4: addu        $t4, $t9, $t8
    ctx->r12 = ADD32(ctx->r25, ctx->r24);
    // 0x8039EAE8: sh          $t4, 0x3C($t3)
    MEM_H(0X3C, ctx->r11) = ctx->r12;
    // 0x8039EAEC: lbu         $t2, 0x1($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EAF0: lh          $t7, 0x5E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X5E);
    // 0x8039EAF4: lh          $t6, 0x4($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X4);
    // 0x8039EAF8: lh          $t8, 0x48($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X48);
    // 0x8039EAFC: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x8039EB00: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x8039EB04: addu        $t3, $s0, $t4
    ctx->r11 = ADD32(ctx->r16, ctx->r12);
    // 0x8039EB08: addu        $t5, $t9, $t8
    ctx->r13 = ADD32(ctx->r25, ctx->r24);
    // 0x8039EB0C: sh          $t5, 0x48($t3)
    MEM_H(0X48, ctx->r11) = ctx->r13;
    // 0x8039EB10: lbu         $t2, 0x1($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB14: lh          $t6, 0x8($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X8);
    // 0x8039EB18: lh          $t9, 0x4A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X4A);
    // 0x8039EB1C: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x8039EB20: addu        $t7, $t6, $t0
    ctx->r15 = ADD32(ctx->r14, ctx->r8);
    // 0x8039EB24: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    // 0x8039EB28: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x8039EB2C: sh          $t8, 0x4A($t5)
    MEM_H(0X4A, ctx->r13) = ctx->r24;
    // 0x8039EB30: lbu         $t4, 0x1($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB34: lh          $t6, 0x5A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X5A);
    // 0x8039EB38: lh          $t3, 0xC($s1)
    ctx->r11 = MEM_H(ctx->r17, 0XC);
    // 0x8039EB3C: lh          $t9, 0x4C($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X4C);
    // 0x8039EB40: sll         $t8, $t4, 4
    ctx->r24 = S32(ctx->r12 << 4);
    // 0x8039EB44: addu        $t7, $t3, $t6
    ctx->r15 = ADD32(ctx->r11, ctx->r14);
    // 0x8039EB48: addu        $t5, $s0, $t8
    ctx->r13 = ADD32(ctx->r16, ctx->r24);
    // 0x8039EB4C: addu        $t2, $t7, $t9
    ctx->r10 = ADD32(ctx->r15, ctx->r25);
    // 0x8039EB50: sh          $t2, 0x4C($t5)
    MEM_H(0X4C, ctx->r13) = ctx->r10;
    // 0x8039EB54: lbu         $v0, 0x1($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB58: addiu       $v1, $zero, 0x7FF
    ctx->r3 = ADD32(0, 0X7FF);
    // 0x8039EB5C: sra         $t3, $v0, 1
    ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8039EB60: andi        $t6, $t3, 0x1
    ctx->r14 = ctx->r11 & 0X1;
    // 0x8039EB64: beq         $t6, $zero, L_8039EBAC
    if (ctx->r14 == 0) {
        // 0x8039EB68: sll         $t8, $v0, 4
        ctx->r24 = S32(ctx->r2 << 4);
            goto L_8039EBAC;
    }
    // 0x8039EB68: sll         $t8, $v0, 4
    ctx->r24 = S32(ctx->r2 << 4);
    // 0x8039EB6C: sll         $t7, $v0, 4
    ctx->r15 = S32(ctx->r2 << 4);
    // 0x8039EB70: addu        $t9, $s0, $t7
    ctx->r25 = ADD32(ctx->r16, ctx->r15);
    // 0x8039EB74: sh          $v1, 0x40($t9)
    MEM_H(0X40, ctx->r25) = ctx->r3;
    // 0x8039EB78: lbu         $t4, 0x1($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB7C: sll         $t8, $t4, 4
    ctx->r24 = S32(ctx->r12 << 4);
    // 0x8039EB80: addu        $t2, $s0, $t8
    ctx->r10 = ADD32(ctx->r16, ctx->r24);
    // 0x8039EB84: sh          $zero, 0x42($t2)
    MEM_H(0X42, ctx->r10) = 0;
    // 0x8039EB88: lbu         $t5, 0x1($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB8C: sll         $t3, $t5, 4
    ctx->r11 = S32(ctx->r13 << 4);
    // 0x8039EB90: addu        $t6, $s0, $t3
    ctx->r14 = ADD32(ctx->r16, ctx->r11);
    // 0x8039EB94: sh          $v1, 0x50($t6)
    MEM_H(0X50, ctx->r14) = ctx->r3;
    // 0x8039EB98: lbu         $t7, 0x1($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EB9C: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x8039EBA0: addu        $t4, $s0, $t9
    ctx->r12 = ADD32(ctx->r16, ctx->r25);
    // 0x8039EBA4: b           L_8039EBE8
    // 0x8039EBA8: sh          $v1, 0x52($t4)
    MEM_H(0X52, ctx->r12) = ctx->r3;
        goto L_8039EBE8;
    // 0x8039EBA8: sh          $v1, 0x52($t4)
    MEM_H(0X52, ctx->r12) = ctx->r3;
L_8039EBAC:
    // 0x8039EBAC: addu        $t2, $s0, $t8
    ctx->r10 = ADD32(ctx->r16, ctx->r24);
    // 0x8039EBB0: sh          $zero, 0x40($t2)
    MEM_H(0X40, ctx->r10) = 0;
    // 0x8039EBB4: lbu         $t5, 0x1($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EBB8: addiu       $v1, $zero, 0x7FF
    ctx->r3 = ADD32(0, 0X7FF);
    // 0x8039EBBC: sll         $t3, $t5, 4
    ctx->r11 = S32(ctx->r13 << 4);
    // 0x8039EBC0: addu        $t6, $s0, $t3
    ctx->r14 = ADD32(ctx->r16, ctx->r11);
    // 0x8039EBC4: sh          $zero, 0x42($t6)
    MEM_H(0X42, ctx->r14) = 0;
    // 0x8039EBC8: lbu         $t7, 0x1($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EBCC: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x8039EBD0: addu        $t4, $s0, $t9
    ctx->r12 = ADD32(ctx->r16, ctx->r25);
    // 0x8039EBD4: sh          $zero, 0x50($t4)
    MEM_H(0X50, ctx->r12) = 0;
    // 0x8039EBD8: lbu         $t8, 0x1($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X1);
    // 0x8039EBDC: sll         $t2, $t8, 4
    ctx->r10 = S32(ctx->r24 << 4);
    // 0x8039EBE0: addu        $t5, $s0, $t2
    ctx->r13 = ADD32(ctx->r16, ctx->r10);
    // 0x8039EBE4: sh          $v1, 0x52($t5)
    MEM_H(0X52, ctx->r13) = ctx->r3;
L_8039EBE8:
    // 0x8039EBE8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8039EBEC: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x8039EBF0: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x8039EBF4: jr          $ra
    // 0x8039EBF8: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x8039EBF8: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void display_trails(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039EBFC: addiu       $sp, $sp, -0x1A0
    ctx->r29 = ADD32(ctx->r29, -0X1A0);
    // 0x8039EC00: sw          $s7, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r23;
    // 0x8039EC04: lui         $s7, 0x801E
    ctx->r23 = S32(0X801E << 16);
    // 0x8039EC08: addiu       $s7, $s7, -0x6170
    ctx->r23 = ADD32(ctx->r23, -0X6170);
    // 0x8039EC0C: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x8039EC10: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EC14: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x8039EC18: sw          $fp, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r30;
    // 0x8039EC1C: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039EC20: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x8039EC24: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x8039EC28: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x8039EC2C: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x8039EC30: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x8039EC34: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x8039EC38: sdc1        $f24, 0x30($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X30, ctx->r29);
    // 0x8039EC3C: sdc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X28, ctx->r29);
    // 0x8039EC40: sdc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X20, ctx->r29);
    // 0x8039EC44: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039EC48: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8039EC4C: addiu       $t8, $t8, 0x4A70
    ctx->r24 = ADD32(ctx->r24, 0X4A70);
    // 0x8039EC50: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8039EC54: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039EC58: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8039EC5C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EC60: lui         $t6, 0x104
    ctx->r14 = S32(0X104 << 16);
    // 0x8039EC64: lui         $t4, 0xFD90
    ctx->r12 = S32(0XFD90 << 16);
    // 0x8039EC68: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039EC6C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039EC70: addiu       $t6, $t6, 0x4CB0
    ctx->r14 = ADD32(ctx->r14, 0X4CB0);
    // 0x8039EC74: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8039EC78: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8039EC7C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EC80: lui         $t5, 0x700
    ctx->r13 = S32(0X700 << 16);
    // 0x8039EC84: lui         $t8, 0xF590
    ctx->r24 = S32(0XF590 << 16);
    // 0x8039EC88: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039EC8C: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039EC90: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8039EC94: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039EC98: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EC9C: lui         $ra, 0xE600
    ctx->r31 = S32(0XE600 << 16);
    // 0x8039ECA0: lui         $s2, 0x73F
    ctx->r18 = S32(0X73F << 16);
    // 0x8039ECA4: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039ECA8: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039ECAC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039ECB0: sw          $ra, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r31;
    // 0x8039ECB4: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ECB8: ori         $s2, $s2, 0xF400
    ctx->r18 = ctx->r18 | 0XF400;
    // 0x8039ECBC: lui         $s1, 0xF300
    ctx->r17 = S32(0XF300 << 16);
    // 0x8039ECC0: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039ECC4: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039ECC8: sw          $s2, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r18;
    // 0x8039ECCC: sw          $s1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r17;
    // 0x8039ECD0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ECD4: lui         $s3, 0xE700
    ctx->r19 = S32(0XE700 << 16);
    // 0x8039ECD8: lui         $t9, 0xF580
    ctx->r25 = S32(0XF580 << 16);
    // 0x8039ECDC: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039ECE0: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039ECE4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039ECE8: sw          $s3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r19;
    // 0x8039ECEC: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x8039ECF0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ECF4: ori         $t9, $t9, 0x400
    ctx->r25 = ctx->r25 | 0X400;
    // 0x8039ECF8: lui         $s5, 0x7
    ctx->r21 = S32(0X7 << 16);
    // 0x8039ECFC: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8039ED00: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039ED04: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039ED08: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039ED0C: or          $t0, $s0, $zero
    ctx->r8 = ctx->r16 | 0;
    // 0x8039ED10: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ED14: ori         $s5, $s5, 0xC1FC
    ctx->r21 = ctx->r21 | 0XC1FC;
    // 0x8039ED18: lui         $s4, 0xF200
    ctx->r20 = S32(0XF200 << 16);
    // 0x8039ED1C: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039ED20: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039ED24: sw          $s5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r21;
    // 0x8039ED28: sw          $s4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r20;
    // 0x8039ED2C: or          $t1, $s0, $zero
    ctx->r9 = ctx->r16 | 0;
    // 0x8039ED30: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ED34: lui         $t8, 0x104
    ctx->r24 = S32(0X104 << 16);
    // 0x8039ED38: addiu       $t8, $t8, 0x54B0
    ctx->r24 = ADD32(ctx->r24, 0X54B0);
    // 0x8039ED3C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039ED40: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039ED44: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8039ED48: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8039ED4C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ED50: lui         $t6, 0xF590
    ctx->r14 = S32(0XF590 << 16);
    // 0x8039ED54: ori         $t6, $t6, 0x100
    ctx->r14 = ctx->r14 | 0X100;
    // 0x8039ED58: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039ED5C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039ED60: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8039ED64: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039ED68: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ED6C: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039ED70: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039ED74: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039ED78: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039ED7C: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039ED80: sw          $ra, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r31;
    // 0x8039ED84: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039ED88: lui         $t7, 0xF580
    ctx->r15 = S32(0XF580 << 16);
    // 0x8039ED8C: ori         $t7, $t7, 0x500
    ctx->r15 = ctx->r15 | 0X500;
    // 0x8039ED90: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8039ED94: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039ED98: sw          $s2, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r18;
    // 0x8039ED9C: sw          $s1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r17;
    // 0x8039EDA0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EDA4: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
    // 0x8039EDA8: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039EDAC: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039EDB0: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039EDB4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039EDB8: sw          $s3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r19;
    // 0x8039EDBC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039EDC0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EDC4: lui         $t9, 0x8040
    ctx->r25 = S32(0X8040 << 16);
    // 0x8039EDC8: lui         $at, 0x4300
    ctx->r1 = S32(0X4300 << 16);
    // 0x8039EDCC: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039EDD0: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039EDD4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039EDD8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039EDDC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8039EDE0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039EDE4: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039EDE8: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8039EDEC: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039EDF0: sw          $s5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r21;
    // 0x8039EDF4: sw          $s4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r20;
    // 0x8039EDF8: lh          $t9, -0x2160($t9)
    ctx->r25 = MEM_H(ctx->r25, -0X2160);
    // 0x8039EDFC: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x8039EE00: blezl       $t9, L_803A04A4
    if (SIGNED(ctx->r25) <= 0) {
        // 0x8039EE04: lw          $ra, 0x5C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X5C);
            goto L_803A04A4;
    }
    goto skip_0;
    // 0x8039EE04: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
    skip_0:
    // 0x8039EE08: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8039EE0C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039EE10: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8039EE14: mtc1        $zero, $f24
    ctx->f24.u32l = 0;
    // 0x8039EE18: sh          $zero, 0x19E($sp)
    MEM_H(0X19E, ctx->r29) = 0;
L_8039EE1C:
    // 0x8039EE1C: lh          $t6, 0x19E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X19E);
    // 0x8039EE20: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8039EE24: addiu       $t8, $t8, 0x7E10
    ctx->r24 = ADD32(ctx->r24, 0X7E10);
    // 0x8039EE28: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8039EE2C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8039EE30: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8039EE34: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8039EE38: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8039EE3C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8039EE40: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8039EE44: addu        $fp, $t7, $t8
    ctx->r30 = ADD32(ctx->r15, ctx->r24);
    // 0x8039EE48: lw          $v1, 0x0($fp)
    ctx->r3 = MEM_W(ctx->r30, 0X0);
    // 0x8039EE4C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039EE50: srl         $t9, $v1, 28
    ctx->r25 = S32(U32(ctx->r3) >> 28);
    // 0x8039EE54: beq         $t9, $zero, L_803A0484
    if (ctx->r25 == 0) {
        // 0x8039EE58: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_803A0484;
    }
    // 0x8039EE58: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x8039EE5C: beq         $t9, $at, L_8039EE84
    if (ctx->r25 == ctx->r1) {
        // 0x8039EE60: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_8039EE84;
    }
    // 0x8039EE60: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x8039EE64: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039EE68: beq         $t9, $at, L_8039FE54
    if (ctx->r25 == ctx->r1) {
        // 0x8039EE6C: addiu       $s3, $fp, 0x8
        ctx->r19 = ADD32(ctx->r30, 0X8);
            goto L_8039FE54;
    }
    // 0x8039EE6C: addiu       $s3, $fp, 0x8
    ctx->r19 = ADD32(ctx->r30, 0X8);
    // 0x8039EE70: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8039EE74: beql        $t9, $at, L_8039F70C
    if (ctx->r25 == ctx->r1) {
        // 0x8039EE78: lw          $s5, 0x248($fp)
        ctx->r21 = MEM_W(ctx->r30, 0X248);
            goto L_8039F70C;
    }
    goto skip_1;
    // 0x8039EE78: lw          $s5, 0x248($fp)
    ctx->r21 = MEM_W(ctx->r30, 0X248);
    skip_1:
    // 0x8039EE7C: b           L_803A0488
    // 0x8039EE80: lh          $t7, 0x19E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X19E);
        goto L_803A0488;
    // 0x8039EE80: lh          $t7, 0x19E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X19E);
L_8039EE84:
    // 0x8039EE84: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8039EE88: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
    // 0x8039EE8C: addiu       $s3, $fp, 0x8
    ctx->r19 = ADD32(ctx->r30, 0X8);
    // 0x8039EE90: andi        $t6, $v1, 0xF
    ctx->r14 = ctx->r3 & 0XF;
    // 0x8039EE94: or          $s2, $s3, $zero
    ctx->r18 = ctx->r19 | 0;
    // 0x8039EE98: beq         $s0, $t6, L_8039EED8
    if (ctx->r16 == ctx->r14) {
        // 0x8039EE9C: lw          $s5, 0x248($fp)
        ctx->r21 = MEM_W(ctx->r30, 0X248);
            goto L_8039EED8;
    }
    // 0x8039EE9C: lw          $s5, 0x248($fp)
    ctx->r21 = MEM_W(ctx->r30, 0X248);
    // 0x8039EEA0: lbu         $t7, 0x1($fp)
    ctx->r15 = MEM_BU(ctx->r30, 0X1);
    // 0x8039EEA4: srl         $t8, $t7, 4
    ctx->r24 = S32(U32(ctx->r15) >> 4);
    // 0x8039EEA8: bnel        $s0, $t8, L_8039EEC4
    if (ctx->r16 != ctx->r24) {
        // 0x8039EEAC: lbu         $t7, 0x26C($s5)
        ctx->r15 = MEM_BU(ctx->r21, 0X26C);
            goto L_8039EEC4;
    }
    goto skip_2;
    // 0x8039EEAC: lbu         $t7, 0x26C($s5)
    ctx->r15 = MEM_BU(ctx->r21, 0X26C);
    skip_2:
    // 0x8039EEB0: lhu         $t9, 0x0($fp)
    ctx->r25 = MEM_HU(ctx->r30, 0X0);
    // 0x8039EEB4: andi        $t6, $t9, 0xF
    ctx->r14 = ctx->r25 & 0XF;
    // 0x8039EEB8: beql        $t6, $zero, L_8039EECC
    if (ctx->r14 == 0) {
        // 0x8039EEBC: andi        $t8, $v1, 0xFFF0
        ctx->r24 = ctx->r3 & 0XFFF0;
            goto L_8039EECC;
    }
    goto skip_3;
    // 0x8039EEBC: andi        $t8, $v1, 0xFFF0
    ctx->r24 = ctx->r3 & 0XFFF0;
    skip_3:
    // 0x8039EEC0: lbu         $t7, 0x26C($s5)
    ctx->r15 = MEM_BU(ctx->r21, 0X26C);
L_8039EEC4:
    // 0x8039EEC4: beq         $t7, $zero, L_8039EED8
    if (ctx->r15 == 0) {
        // 0x8039EEC8: andi        $t8, $v1, 0xFFF0
        ctx->r24 = ctx->r3 & 0XFFF0;
            goto L_8039EED8;
    }
    // 0x8039EEC8: andi        $t8, $v1, 0xFFF0
    ctx->r24 = ctx->r3 & 0XFFF0;
L_8039EECC:
    // 0x8039EECC: ori         $t9, $t8, 0x2
    ctx->r25 = ctx->r24 | 0X2;
    // 0x8039EED0: sb          $t9, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r25;
    // 0x8039EED4: sw          $zero, 0x4($fp)
    MEM_W(0X4, ctx->r30) = 0;
L_8039EED8:
    // 0x8039EED8: lbu         $t6, 0x1($fp)
    ctx->r14 = MEM_BU(ctx->r30, 0X1);
    // 0x8039EEDC: andi        $t7, $t6, 0xFFF0
    ctx->r15 = ctx->r14 & 0XFFF0;
    // 0x8039EEE0: sb          $t7, 0x1($fp)
    MEM_B(0X1, ctx->r30) = ctx->r15;
    // 0x8039EEE4: lbu         $t8, 0x3($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X3);
    // 0x8039EEE8: bnel        $t8, $zero, L_8039EF7C
    if (ctx->r24 != 0) {
        // 0x8039EEEC: lbu         $t6, 0x0($fp)
        ctx->r14 = MEM_BU(ctx->r30, 0X0);
            goto L_8039EF7C;
    }
    goto skip_4;
    // 0x8039EEEC: lbu         $t6, 0x0($fp)
    ctx->r14 = MEM_BU(ctx->r30, 0X0);
    skip_4:
    // 0x8039EEF0: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8039EEF4: andi        $v0, $v1, 0xF
    ctx->r2 = ctx->r3 & 0XF;
    // 0x8039EEF8: beql        $s0, $v0, L_8039EF7C
    if (ctx->r16 == ctx->r2) {
        // 0x8039EEFC: lbu         $t6, 0x0($fp)
        ctx->r14 = MEM_BU(ctx->r30, 0X0);
            goto L_8039EF7C;
    }
    goto skip_5;
    // 0x8039EEFC: lbu         $t6, 0x0($fp)
    ctx->r14 = MEM_BU(ctx->r30, 0X0);
    skip_5:
    // 0x8039EF00: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039EF04: bne         $v0, $at, L_8039EF38
    if (ctx->r2 != ctx->r1) {
        // 0x8039EF08: andi        $t9, $v1, 0xFFF0
        ctx->r25 = ctx->r3 & 0XFFF0;
            goto L_8039EF38;
    }
    // 0x8039EF08: andi        $t9, $v1, 0xFFF0
    ctx->r25 = ctx->r3 & 0XFFF0;
    // 0x8039EF0C: sb          $t9, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r25;
    // 0x8039EF10: sb          $zero, 0x2($s3)
    MEM_B(0X2, ctx->r19) = 0;
    // 0x8039EF14: sb          $zero, 0x1($s3)
    MEM_B(0X1, ctx->r19) = 0;
    // 0x8039EF18: sh          $zero, 0x12($s3)
    MEM_H(0X12, ctx->r19) = 0;
    // 0x8039EF1C: jal         0x8039E6D4
    // 0x8039EF20: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    func_8039E6D4_7AFD84(rdram, ctx);
        goto after_0;
    // 0x8039EF20: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    after_0:
    // 0x8039EF24: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039EF28: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039EF2C: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039EF30: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039EF34: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
L_8039EF38:
    // 0x8039EF38: lbu         $t6, 0x1($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X1);
    // 0x8039EF3C: lbu         $v0, 0x2($s3)
    ctx->r2 = MEM_BU(ctx->r19, 0X2);
    // 0x8039EF40: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
    // 0x8039EF44: addiu       $t7, $t6, 0x2
    ctx->r15 = ADD32(ctx->r14, 0X2);
    // 0x8039EF48: andi        $t8, $t7, 0x1F
    ctx->r24 = ctx->r15 & 0X1F;
    // 0x8039EF4C: andi        $v1, $t8, 0xFF
    ctx->r3 = ctx->r24 & 0XFF;
    // 0x8039EF50: bne         $v0, $v1, L_8039EF68
    if (ctx->r2 != ctx->r3) {
        // 0x8039EF54: sb          $t8, 0x1($s3)
        MEM_B(0X1, ctx->r19) = ctx->r24;
            goto L_8039EF68;
    }
    // 0x8039EF54: sb          $t8, 0x1($s3)
    MEM_B(0X1, ctx->r19) = ctx->r24;
    // 0x8039EF58: addiu       $t9, $v0, 0x2
    ctx->r25 = ADD32(ctx->r2, 0X2);
    // 0x8039EF5C: andi        $t6, $t9, 0x1F
    ctx->r14 = ctx->r25 & 0X1F;
    // 0x8039EF60: sb          $t6, 0x2($s3)
    MEM_B(0X2, ctx->r19) = ctx->r14;
    // 0x8039EF64: andi        $v1, $t8, 0xFF
    ctx->r3 = ctx->r24 & 0XFF;
L_8039EF68:
    // 0x8039EF68: sra         $t7, $v1, 1
    ctx->r15 = S32(SIGNED(ctx->r3) >> 1);
    // 0x8039EF6C: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8039EF70: addu        $t9, $s3, $t8
    ctx->r25 = ADD32(ctx->r19, ctx->r24);
    // 0x8039EF74: sh          $zero, 0x12($t9)
    MEM_H(0X12, ctx->r25) = 0;
    // 0x8039EF78: lbu         $t6, 0x0($fp)
    ctx->r14 = MEM_BU(ctx->r30, 0X0);
L_8039EF7C:
    // 0x8039EF7C: andi        $t7, $t6, 0xF
    ctx->r15 = ctx->r14 & 0XF;
    // 0x8039EF80: beql        $s0, $t7, L_8039EFA8
    if (ctx->r16 == ctx->r15) {
        // 0x8039EF84: lbu         $s4, 0x2($s3)
        ctx->r20 = MEM_BU(ctx->r19, 0X2);
            goto L_8039EFA8;
    }
    goto skip_6;
    // 0x8039EF84: lbu         $s4, 0x2($s3)
    ctx->r20 = MEM_BU(ctx->r19, 0X2);
    skip_6:
    // 0x8039EF88: jal         0x8039E6D4
    // 0x8039EF8C: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    func_8039E6D4_7AFD84(rdram, ctx);
        goto after_1;
    // 0x8039EF8C: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    after_1:
    // 0x8039EF90: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039EF94: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039EF98: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039EF9C: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039EFA0: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
    // 0x8039EFA4: lbu         $s4, 0x2($s3)
    ctx->r20 = MEM_BU(ctx->r19, 0X2);
L_8039EFA8:
    // 0x8039EFA8: lbu         $t8, 0x1($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X1);
    // 0x8039EFAC: beq         $s4, $t8, L_8039F054
    if (ctx->r20 == ctx->r24) {
        // 0x8039EFB0: sra         $t9, $s4, 1
        ctx->r25 = S32(SIGNED(ctx->r20) >> 1);
            goto L_8039F054;
    }
    // 0x8039EFB0: sra         $t9, $s4, 1
    ctx->r25 = S32(SIGNED(ctx->r20) >> 1);
L_8039EFB4:
    // 0x8039EFB4: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x8039EFB8: addu        $s0, $s3, $t6
    ctx->r16 = ADD32(ctx->r19, ctx->r14);
    // 0x8039EFBC: lh          $t7, 0x12($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X12);
    // 0x8039EFC0: lbu         $t8, 0xF($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0XF);
    // 0x8039EFC4: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8039EFC8: sh          $t9, 0x12($s0)
    MEM_H(0X12, ctx->r16) = ctx->r25;
    // 0x8039EFCC: lh          $v0, 0x12($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X12);
    // 0x8039EFD0: slti        $at, $v0, 0x80
    ctx->r1 = SIGNED(ctx->r2) < 0X80 ? 1 : 0;
    // 0x8039EFD4: bnel        $at, $zero, L_8039F020
    if (ctx->r1 != 0) {
        // 0x8039EFD8: sll         $t7, $s4, 4
        ctx->r15 = S32(ctx->r20 << 4);
            goto L_8039F020;
    }
    goto skip_7;
    // 0x8039EFD8: sll         $t7, $s4, 4
    ctx->r15 = S32(ctx->r20 << 4);
    skip_7:
    // 0x8039EFDC: lbu         $t6, 0x2($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X2);
    // 0x8039EFE0: lbu         $t9, 0x1($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X1);
    // 0x8039EFE4: lui         $v0, 0x8040
    ctx->r2 = S32(0X8040 << 16);
    // 0x8039EFE8: addiu       $t7, $t6, 0x2
    ctx->r15 = ADD32(ctx->r14, 0X2);
    // 0x8039EFEC: andi        $t8, $t7, 0x1F
    ctx->r24 = ctx->r15 & 0X1F;
    // 0x8039EFF0: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x8039EFF4: bne         $t9, $t6, L_8039F038
    if (ctx->r25 != ctx->r14) {
        // 0x8039EFF8: sb          $t8, 0x2($s3)
        MEM_B(0X2, ctx->r19) = ctx->r24;
            goto L_8039F038;
    }
    // 0x8039EFF8: sb          $t8, 0x2($s3)
    MEM_B(0X2, ctx->r19) = ctx->r24;
    // 0x8039EFFC: addiu       $v0, $v0, -0x2160
    ctx->r2 = ADD32(ctx->r2, -0X2160);
    // 0x8039F000: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x8039F004: lbu         $t9, 0x0($fp)
    ctx->r25 = MEM_BU(ctx->r30, 0X0);
    // 0x8039F008: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x8039F00C: andi        $t6, $t9, 0xFF0F
    ctx->r14 = ctx->r25 & 0XFF0F;
    // 0x8039F010: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
    // 0x8039F014: b           L_8039F054
    // 0x8039F018: sb          $t6, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r14;
        goto L_8039F054;
    // 0x8039F018: sb          $t6, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r14;
    // 0x8039F01C: sll         $t7, $s4, 4
    ctx->r15 = S32(ctx->r20 << 4);
L_8039F020:
    // 0x8039F020: addu        $s1, $s3, $t7
    ctx->r17 = ADD32(ctx->r19, ctx->r15);
    // 0x8039F024: subu        $t8, $t4, $v0
    ctx->r24 = SUB32(ctx->r12, ctx->r2);
    // 0x8039F028: sb          $t8, 0x47($s1)
    MEM_B(0X47, ctx->r17) = ctx->r24;
    // 0x8039F02C: lh          $t9, 0x12($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X12);
    // 0x8039F030: subu        $t6, $t4, $t9
    ctx->r14 = SUB32(ctx->r12, ctx->r25);
    // 0x8039F034: sb          $t6, 0x57($s1)
    MEM_B(0X57, ctx->r17) = ctx->r14;
L_8039F038:
    // 0x8039F038: addiu       $s4, $s4, 0x2
    ctx->r20 = ADD32(ctx->r20, 0X2);
    // 0x8039F03C: lbu         $t6, 0x1($s2)
    ctx->r14 = MEM_BU(ctx->r18, 0X1);
    // 0x8039F040: andi        $t7, $s4, 0x1F
    ctx->r15 = ctx->r20 & 0X1F;
    // 0x8039F044: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039F048: sra         $s4, $t8, 16
    ctx->r20 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039F04C: bnel        $s4, $t6, L_8039EFB4
    if (ctx->r20 != ctx->r14) {
        // 0x8039F050: sra         $t9, $s4, 1
        ctx->r25 = S32(SIGNED(ctx->r20) >> 1);
            goto L_8039EFB4;
    }
    goto skip_8;
    // 0x8039F050: sra         $t9, $s4, 1
    ctx->r25 = S32(SIGNED(ctx->r20) >> 1);
    skip_8:
L_8039F054:
    // 0x8039F054: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F058: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x8039F05C: ori         $t8, $t8, 0x81FF
    ctx->r24 = ctx->r24 | 0X81FF;
    // 0x8039F060: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039F064: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039F068: addiu       $t9, $s3, 0x38
    ctx->r25 = ADD32(ctx->r19, 0X38);
    // 0x8039F06C: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8039F070: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039F074: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x8039F078: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F07C: lui         $t8, 0x5532
    ctx->r24 = S32(0X5532 << 16);
    // 0x8039F080: lui         $t7, 0xFC30
    ctx->r15 = S32(0XFC30 << 16);
    // 0x8039F084: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039F088: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039F08C: ori         $t7, $t7, 0x9861
    ctx->r15 = ctx->r15 | 0X9861;
    // 0x8039F090: ori         $t8, $t8, 0xFF7F
    ctx->r24 = ctx->r24 | 0XFF7F;
    // 0x8039F094: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8039F098: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039F09C: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x8039F0A0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F0A4: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x8039F0A8: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x8039F0AC: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039F0B0: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039F0B4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039F0B8: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039F0BC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039F0C0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F0C4: lui         $t8, 0xF580
    ctx->r24 = S32(0XF580 << 16);
    // 0x8039F0C8: ori         $t8, $t8, 0x400
    ctx->r24 = ctx->r24 | 0X400;
    // 0x8039F0CC: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039F0D0: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039F0D4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039F0D8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039F0DC: lbu         $t9, 0x1($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X1);
    // 0x8039F0E0: lbu         $s1, 0x2($s3)
    ctx->r17 = MEM_BU(ctx->r19, 0X2);
    // 0x8039F0E4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8039F0E8: beq         $s1, $t9, L_8039F6B4
    if (ctx->r17 == ctx->r25) {
        // 0x8039F0EC: sra         $t6, $s1, 1
        ctx->r14 = S32(SIGNED(ctx->r17) >> 1);
            goto L_8039F6B4;
    }
L_8039F0EC:
    // 0x8039F0EC: sra         $t6, $s1, 1
    ctx->r14 = S32(SIGNED(ctx->r17) >> 1);
    // 0x8039F0F0: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8039F0F4: addu        $t8, $s3, $t7
    ctx->r24 = ADD32(ctx->r19, ctx->r15);
    // 0x8039F0F8: lh          $t9, 0x12($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X12);
    // 0x8039F0FC: lbu         $t6, 0xC($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0XC);
    // 0x8039F100: sll         $v0, $s1, 1
    ctx->r2 = S32(ctx->r17 << 1);
    // 0x8039F104: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8039F108: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x8039F10C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F110: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8039F114: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    // 0x8039F118: addiu       $a2, $s1, 0x3
    ctx->r6 = ADD32(ctx->r17, 0X3);
    // 0x8039F11C: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8039F120: bgez        $t6, L_8039F134
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8039F124: div.s       $f2, $f6, $f22
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f22.fl);
            goto L_8039F134;
    }
    // 0x8039F124: div.s       $f2, $f6, $f22
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f22.fl);
    // 0x8039F128: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039F12C: nop

    // 0x8039F130: add.s       $f10, $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f16.fl;
L_8039F134:
    // 0x8039F134: mul.s       $f18, $f10, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f2.fl);
    // 0x8039F138: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F13C: swc1        $f18, 0x164($sp)
    MEM_W(0X164, ctx->r29) = ctx->f18.u32l;
    // 0x8039F140: lbu         $t7, 0xD($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0XD);
    // 0x8039F144: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x8039F148: bgez        $t7, L_8039F15C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039F14C: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_8039F15C;
    }
    // 0x8039F14C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8039F150: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039F154: nop

    // 0x8039F158: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_8039F15C:
    // 0x8039F15C: mul.s       $f16, $f6, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = MUL_S(ctx->f6.fl, ctx->f2.fl);
    // 0x8039F160: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F164: swc1        $f16, 0x168($sp)
    MEM_W(0X168, ctx->r29) = ctx->f16.u32l;
    // 0x8039F168: lbu         $t8, 0xE($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0XE);
    // 0x8039F16C: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x8039F170: bgez        $t8, L_8039F184
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8039F174: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8039F184;
    }
    // 0x8039F174: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039F178: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039F17C: nop

    // 0x8039F180: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_8039F184:
    // 0x8039F184: mul.s       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f2.fl);
    // 0x8039F188: sub.s       $f0, $f20, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f0.fl = ctx->f20.fl - ctx->f2.fl;
    // 0x8039F18C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F190: swc1        $f6, 0x16C($sp)
    MEM_W(0X16C, ctx->r29) = ctx->f6.u32l;
    // 0x8039F194: lbu         $t9, 0x6($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X6);
    // 0x8039F198: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x8039F19C: bgez        $t9, L_8039F1B0
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8039F1A0: cvt.s.w     $f8, $f10
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8039F1B0;
    }
    // 0x8039F1A0: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039F1A4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039F1A8: nop

    // 0x8039F1AC: add.s       $f8, $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f4.fl;
L_8039F1B0:
    // 0x8039F1B0: mul.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x8039F1B4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F1B8: add.s       $f4, $f18, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f18.fl + ctx->f10.fl;
    // 0x8039F1BC: swc1        $f4, 0x170($sp)
    MEM_W(0X170, ctx->r29) = ctx->f4.u32l;
    // 0x8039F1C0: lbu         $t6, 0x7($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X7);
    // 0x8039F1C4: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x8039F1C8: bgez        $t6, L_8039F1DC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8039F1CC: cvt.s.w     $f18, $f8
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    ctx->f18.fl = CVT_S_W(ctx->f8.u32l);
            goto L_8039F1DC;
    }
    // 0x8039F1CC: cvt.s.w     $f18, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    ctx->f18.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8039F1D0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039F1D4: nop

    // 0x8039F1D8: add.s       $f18, $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f10.fl;
L_8039F1DC:
    // 0x8039F1DC: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039F1E0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F1E4: add.s       $f8, $f16, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x8039F1E8: swc1        $f8, 0x174($sp)
    MEM_W(0X174, ctx->r29) = ctx->f8.u32l;
    // 0x8039F1EC: lbu         $t7, 0x8($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X8);
    // 0x8039F1F0: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x8039F1F4: bgez        $t7, L_8039F208
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039F1F8: cvt.s.w     $f18, $f10
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8039F208;
    }
    // 0x8039F1F8: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039F1FC: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039F200: nop

    // 0x8039F204: add.s       $f18, $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f16.fl;
L_8039F208:
    // 0x8039F208: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039F20C: lw          $a0, 0x0($s7)
    ctx->r4 = MEM_W(ctx->r23, 0X0);
    // 0x8039F210: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039F214: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F218: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x8039F21C: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039F220: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F224: add.s       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x8039F228: swc1        $f8, 0x178($sp)
    MEM_W(0X178, ctx->r29) = ctx->f8.u32l;
    // 0x8039F22C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8039F230: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039F234: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F238: lwc1        $f10, 0x178($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X178);
    // 0x8039F23C: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8039F240: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F244: nop

    // 0x8039F248: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F24C: beql        $t7, $zero, L_8039F29C
    if (ctx->r15 == 0) {
        // 0x8039F250: mfc1        $t7, $f16
        ctx->r15 = (int32_t)ctx->f16.u32l;
            goto L_8039F29C;
    }
    goto skip_9;
    // 0x8039F250: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
    skip_9:
    // 0x8039F254: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039F258: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F25C: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x8039F260: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F264: nop

    // 0x8039F268: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8039F26C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F270: nop

    // 0x8039F274: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F278: bne         $t7, $zero, L_8039F290
    if (ctx->r15 != 0) {
        // 0x8039F27C: nop
    
            goto L_8039F290;
    }
    // 0x8039F27C: nop

    // 0x8039F280: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
    // 0x8039F284: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F288: b           L_8039F2A8
    // 0x8039F28C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8039F2A8;
    // 0x8039F28C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8039F290:
    // 0x8039F290: b           L_8039F2A8
    // 0x8039F294: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8039F2A8;
    // 0x8039F294: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8039F298: mfc1        $t7, $f16
    ctx->r15 = (int32_t)ctx->f16.u32l;
L_8039F29C:
    // 0x8039F29C: nop

    // 0x8039F2A0: bltz        $t7, L_8039F290
    if (SIGNED(ctx->r15) < 0) {
        // 0x8039F2A4: nop
    
            goto L_8039F290;
    }
    // 0x8039F2A4: nop

L_8039F2A8:
    // 0x8039F2A8: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8039F2AC: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x8039F2B0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F2B4: lwc1        $f18, 0x170($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X170);
    // 0x8039F2B8: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8039F2BC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F2C0: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x8039F2C4: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F2C8: cvt.w.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8039F2CC: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F2D0: nop

    // 0x8039F2D4: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F2D8: beql        $t7, $zero, L_8039F328
    if (ctx->r15 == 0) {
        // 0x8039F2DC: mfc1        $t7, $f6
        ctx->r15 = (int32_t)ctx->f6.u32l;
            goto L_8039F328;
    }
    goto skip_10;
    // 0x8039F2DC: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    skip_10:
    // 0x8039F2E0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039F2E4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F2E8: sub.s       $f6, $f18, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f18.fl - ctx->f6.fl;
    // 0x8039F2EC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F2F0: nop

    // 0x8039F2F4: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8039F2F8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F2FC: nop

    // 0x8039F300: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F304: bne         $t7, $zero, L_8039F31C
    if (ctx->r15 != 0) {
        // 0x8039F308: nop
    
            goto L_8039F31C;
    }
    // 0x8039F308: nop

    // 0x8039F30C: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8039F310: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F314: b           L_8039F334
    // 0x8039F318: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8039F334;
    // 0x8039F318: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8039F31C:
    // 0x8039F31C: b           L_8039F334
    // 0x8039F320: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8039F334;
    // 0x8039F320: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8039F324: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
L_8039F328:
    // 0x8039F328: nop

    // 0x8039F32C: bltz        $t7, L_8039F31C
    if (SIGNED(ctx->r15) < 0) {
        // 0x8039F330: nop
    
            goto L_8039F31C;
    }
    // 0x8039F330: nop

L_8039F334:
    // 0x8039F334: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8039F338: or          $t8, $t7, $zero
    ctx->r24 = ctx->r15 | 0;
    // 0x8039F33C: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8039F340: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8039F344: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F348: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8039F34C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F350: lwc1        $f4, 0x174($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X174);
    // 0x8039F354: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F358: cvt.w.s     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8039F35C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F360: nop

    // 0x8039F364: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F368: beql        $t9, $zero, L_8039F3B8
    if (ctx->r25 == 0) {
        // 0x8039F36C: mfc1        $t9, $f8
        ctx->r25 = (int32_t)ctx->f8.u32l;
            goto L_8039F3B8;
    }
    goto skip_11;
    // 0x8039F36C: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    skip_11:
    // 0x8039F370: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039F374: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F378: sub.s       $f8, $f4, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x8039F37C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F380: nop

    // 0x8039F384: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8039F388: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F38C: nop

    // 0x8039F390: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F394: bne         $t9, $zero, L_8039F3AC
    if (ctx->r25 != 0) {
        // 0x8039F398: nop
    
            goto L_8039F3AC;
    }
    // 0x8039F398: nop

    // 0x8039F39C: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x8039F3A0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F3A4: b           L_8039F3C4
    // 0x8039F3A8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8039F3C4;
    // 0x8039F3A8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8039F3AC:
    // 0x8039F3AC: b           L_8039F3C4
    // 0x8039F3B0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8039F3C4;
    // 0x8039F3B0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8039F3B4: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
L_8039F3B8:
    // 0x8039F3B8: nop

    // 0x8039F3BC: bltz        $t9, L_8039F3AC
    if (SIGNED(ctx->r25) < 0) {
        // 0x8039F3C0: nop
    
            goto L_8039F3AC;
    }
    // 0x8039F3C0: nop

L_8039F3C4:
    // 0x8039F3C4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8039F3C8: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x8039F3CC: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8039F3D0: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8039F3D4: ori         $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 | 0XFF;
    // 0x8039F3D8: sw          $t6, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r14;
    // 0x8039F3DC: lbu         $t7, 0x9($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X9);
    // 0x8039F3E0: lwc1        $f10, 0x164($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X164);
    // 0x8039F3E4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F3E8: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x8039F3EC: addiu       $a0, $s1, 0x2
    ctx->r4 = ADD32(ctx->r17, 0X2);
    // 0x8039F3F0: bgez        $t7, L_8039F404
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039F3F4: cvt.s.w     $f18, $f16
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
            goto L_8039F404;
    }
    // 0x8039F3F4: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039F3F8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039F3FC: nop

    // 0x8039F400: add.s       $f18, $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f6.fl;
L_8039F404:
    // 0x8039F404: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039F408: lwc1        $f16, 0x168($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X168);
    // 0x8039F40C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F410: add.s       $f8, $f10, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f10.fl + ctx->f4.fl;
    // 0x8039F414: swc1        $f8, 0x170($sp)
    MEM_W(0X170, ctx->r29) = ctx->f8.u32l;
    // 0x8039F418: lbu         $t8, 0xA($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0XA);
    // 0x8039F41C: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x8039F420: bgez        $t8, L_8039F434
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8039F424: cvt.s.w     $f18, $f6
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8039F434;
    }
    // 0x8039F424: cvt.s.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039F428: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039F42C: nop

    // 0x8039F430: add.s       $f18, $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f10.fl;
L_8039F434:
    // 0x8039F434: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039F438: lwc1        $f6, 0x16C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X16C);
    // 0x8039F43C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039F440: add.s       $f8, $f16, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x8039F444: swc1        $f8, 0x174($sp)
    MEM_W(0X174, ctx->r29) = ctx->f8.u32l;
    // 0x8039F448: lbu         $t9, 0xB($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0XB);
    // 0x8039F44C: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x8039F450: bgez        $t9, L_8039F464
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8039F454: cvt.s.w     $f18, $f10
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
            goto L_8039F464;
    }
    // 0x8039F454: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039F458: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039F45C: nop

    // 0x8039F460: add.s       $f18, $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f16.fl;
L_8039F464:
    // 0x8039F464: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039F468: lw          $a1, 0x0($s7)
    ctx->r5 = MEM_W(ctx->r23, 0X0);
    // 0x8039F46C: lui         $t7, 0xFB00
    ctx->r15 = S32(0XFB00 << 16);
    // 0x8039F470: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F474: addiu       $t6, $a1, 0x8
    ctx->r14 = ADD32(ctx->r5, 0X8);
    // 0x8039F478: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039F47C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F480: add.s       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x8039F484: swc1        $f8, 0x178($sp)
    MEM_W(0X178, ctx->r29) = ctx->f8.u32l;
    // 0x8039F488: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8039F48C: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x8039F490: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F494: lwc1        $f10, 0x178($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X178);
    // 0x8039F498: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8039F49C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F4A0: nop

    // 0x8039F4A4: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F4A8: beql        $t9, $zero, L_8039F4F8
    if (ctx->r25 == 0) {
        // 0x8039F4AC: mfc1        $t9, $f16
        ctx->r25 = (int32_t)ctx->f16.u32l;
            goto L_8039F4F8;
    }
    goto skip_12;
    // 0x8039F4AC: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
    skip_12:
    // 0x8039F4B0: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039F4B4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F4B8: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x8039F4BC: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F4C0: nop

    // 0x8039F4C4: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8039F4C8: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F4CC: nop

    // 0x8039F4D0: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F4D4: bne         $t9, $zero, L_8039F4EC
    if (ctx->r25 != 0) {
        // 0x8039F4D8: nop
    
            goto L_8039F4EC;
    }
    // 0x8039F4D8: nop

    // 0x8039F4DC: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
    // 0x8039F4E0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F4E4: b           L_8039F504
    // 0x8039F4E8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8039F504;
    // 0x8039F4E8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8039F4EC:
    // 0x8039F4EC: b           L_8039F504
    // 0x8039F4F0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8039F504;
    // 0x8039F4F0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8039F4F4: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
L_8039F4F8:
    // 0x8039F4F8: nop

    // 0x8039F4FC: bltz        $t9, L_8039F4EC
    if (SIGNED(ctx->r25) < 0) {
        // 0x8039F500: nop
    
            goto L_8039F4EC;
    }
    // 0x8039F500: nop

L_8039F504:
    // 0x8039F504: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8039F508: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x8039F50C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F510: lwc1        $f18, 0x170($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X170);
    // 0x8039F514: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8039F518: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F51C: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x8039F520: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F524: cvt.w.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8039F528: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F52C: nop

    // 0x8039F530: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F534: beql        $t9, $zero, L_8039F584
    if (ctx->r25 == 0) {
        // 0x8039F538: mfc1        $t9, $f6
        ctx->r25 = (int32_t)ctx->f6.u32l;
            goto L_8039F584;
    }
    goto skip_13;
    // 0x8039F538: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
    skip_13:
    // 0x8039F53C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039F540: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039F544: sub.s       $f6, $f18, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f18.fl - ctx->f6.fl;
    // 0x8039F548: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039F54C: nop

    // 0x8039F550: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8039F554: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039F558: nop

    // 0x8039F55C: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039F560: bne         $t9, $zero, L_8039F578
    if (ctx->r25 != 0) {
        // 0x8039F564: nop
    
            goto L_8039F578;
    }
    // 0x8039F564: nop

    // 0x8039F568: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
    // 0x8039F56C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F570: b           L_8039F590
    // 0x8039F574: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8039F590;
    // 0x8039F574: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8039F578:
    // 0x8039F578: b           L_8039F590
    // 0x8039F57C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8039F590;
    // 0x8039F57C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8039F580: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
L_8039F584:
    // 0x8039F584: nop

    // 0x8039F588: bltz        $t9, L_8039F578
    if (SIGNED(ctx->r25) < 0) {
        // 0x8039F58C: nop
    
            goto L_8039F578;
    }
    // 0x8039F58C: nop

L_8039F590:
    // 0x8039F590: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8039F594: or          $t6, $t9, $zero
    ctx->r14 = ctx->r25 | 0;
    // 0x8039F598: sll         $t8, $t6, 24
    ctx->r24 = S32(ctx->r14 << 24);
    // 0x8039F59C: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8039F5A0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F5A4: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x8039F5A8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F5AC: lwc1        $f4, 0x174($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X174);
    // 0x8039F5B0: cvt.w.s     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = CVT_W_S(ctx->f4.fl);
    // 0x8039F5B4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F5B8: nop

    // 0x8039F5BC: andi        $at, $t7, 0x4
    ctx->r1 = ctx->r15 & 0X4;
    // 0x8039F5C0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F5C4: beql        $t7, $zero, L_8039F61C
    if (ctx->r15 == 0) {
        // 0x8039F5C8: mfc1        $t7, $f8
        ctx->r15 = (int32_t)ctx->f8.u32l;
            goto L_8039F61C;
    }
    goto skip_14;
    // 0x8039F5C8: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    skip_14:
    // 0x8039F5CC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039F5D0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039F5D4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039F5D8: sub.s       $f8, $f4, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x8039F5DC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x8039F5E0: nop

    // 0x8039F5E4: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8039F5E8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039F5EC: nop

    // 0x8039F5F0: andi        $at, $t7, 0x4
    ctx->r1 = ctx->r15 & 0X4;
    // 0x8039F5F4: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x8039F5F8: bne         $t7, $zero, L_8039F610
    if (ctx->r15 != 0) {
        // 0x8039F5FC: nop
    
            goto L_8039F610;
    }
    // 0x8039F5FC: nop

    // 0x8039F600: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x8039F604: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F608: b           L_8039F628
    // 0x8039F60C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_8039F628;
    // 0x8039F60C: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8039F610:
    // 0x8039F610: b           L_8039F628
    // 0x8039F614: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_8039F628;
    // 0x8039F614: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8039F618: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
L_8039F61C:
    // 0x8039F61C: nop

    // 0x8039F620: bltz        $t7, L_8039F610
    if (SIGNED(ctx->r15) < 0) {
        // 0x8039F624: nop
    
            goto L_8039F610;
    }
    // 0x8039F624: nop

L_8039F628:
    // 0x8039F628: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8039F62C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x8039F630: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x8039F634: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8039F638: ori         $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 | 0XFF;
    // 0x8039F63C: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x8039F640: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F644: andi        $t7, $a2, 0x1F
    ctx->r15 = ctx->r6 & 0X1F;
    // 0x8039F648: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8039F64C: andi        $a2, $t8, 0xFF
    ctx->r6 = ctx->r24 & 0XFF;
    // 0x8039F650: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x8039F654: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x8039F658: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039F65C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039F660: sll         $t6, $a2, 8
    ctx->r14 = S32(ctx->r6 << 8);
    // 0x8039F664: addiu       $t8, $v0, 0x2
    ctx->r24 = ADD32(ctx->r2, 0X2);
    // 0x8039F668: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8039F66C: or          $t7, $v1, $t6
    ctx->r15 = ctx->r3 | ctx->r14;
    // 0x8039F670: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8039F674: or          $t8, $t6, $ra
    ctx->r24 = ctx->r14 | ctx->r31;
    // 0x8039F678: andi        $t7, $a0, 0x1F
    ctx->r15 = ctx->r4 & 0X1F;
    // 0x8039F67C: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x8039F680: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x8039F684: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039F688: sll         $t8, $t6, 8
    ctx->r24 = S32(ctx->r14 << 8);
    // 0x8039F68C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8039F690: or          $t7, $v1, $t8
    ctx->r15 = ctx->r3 | ctx->r24;
    // 0x8039F694: or          $t9, $t7, $a2
    ctx->r25 = ctx->r15 | ctx->r6;
    // 0x8039F698: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8039F69C: lbu         $t8, 0x1($s2)
    ctx->r24 = MEM_BU(ctx->r18, 0X1);
    // 0x8039F6A0: sll         $s1, $a0, 16
    ctx->r17 = S32(ctx->r4 << 16);
    // 0x8039F6A4: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8039F6A8: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x8039F6AC: bne         $t6, $t8, L_8039F0EC
    if (ctx->r14 != ctx->r24) {
        // 0x8039F6B0: or          $a3, $s0, $zero
        ctx->r7 = ctx->r16 | 0;
            goto L_8039F0EC;
    }
    // 0x8039F6B0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
L_8039F6B4:
    // 0x8039F6B4: lbu         $t7, 0x3($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X3);
    // 0x8039F6B8: lbu         $t8, 0x10($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X10);
    // 0x8039F6BC: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8039F6C0: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x8039F6C4: div         $zero, $t6, $t8
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r24))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r24)));
    // 0x8039F6C8: sb          $t9, 0x3($s3)
    MEM_B(0X3, ctx->r19) = ctx->r25;
    // 0x8039F6CC: lbu         $t9, 0x4($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X4);
    // 0x8039F6D0: bne         $t8, $zero, L_8039F6DC
    if (ctx->r24 != 0) {
        // 0x8039F6D4: nop
    
            goto L_8039F6DC;
    }
    // 0x8039F6D4: nop

    // 0x8039F6D8: break       7
    do_break(2151282392);
L_8039F6DC:
    // 0x8039F6DC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039F6E0: bne         $t8, $at, L_8039F6F4
    if (ctx->r24 != ctx->r1) {
        // 0x8039F6E4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039F6F4;
    }
    // 0x8039F6E4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F6E8: bne         $t6, $at, L_8039F6F4
    if (ctx->r14 != ctx->r1) {
        // 0x8039F6EC: nop
    
            goto L_8039F6F4;
    }
    // 0x8039F6EC: nop

    // 0x8039F6F0: break       6
    do_break(2151282416);
L_8039F6F4:
    // 0x8039F6F4: mfhi        $t7
    ctx->r15 = hi;
    // 0x8039F6F8: addiu       $t6, $t9, 0x20
    ctx->r14 = ADD32(ctx->r25, 0X20);
    // 0x8039F6FC: sb          $t7, 0x3($s3)
    MEM_B(0X3, ctx->r19) = ctx->r15;
    // 0x8039F700: b           L_803A0484
    // 0x8039F704: sb          $t6, 0x4($s3)
    MEM_B(0X4, ctx->r19) = ctx->r14;
        goto L_803A0484;
    // 0x8039F704: sb          $t6, 0x4($s3)
    MEM_B(0X4, ctx->r19) = ctx->r14;
    // 0x8039F708: lw          $s5, 0x248($fp)
    ctx->r21 = MEM_W(ctx->r30, 0X248);
L_8039F70C:
    // 0x8039F70C: addiu       $s3, $fp, 0x8
    ctx->r19 = ADD32(ctx->r30, 0X8);
    // 0x8039F710: or          $s4, $s3, $zero
    ctx->r20 = ctx->r19 | 0;
    // 0x8039F714: lbu         $t8, 0x26C($s5)
    ctx->r24 = MEM_BU(ctx->r21, 0X26C);
    // 0x8039F718: beql        $t8, $zero, L_8039F740
    if (ctx->r24 == 0) {
        // 0x8039F71C: lbu         $t8, 0x0($fp)
        ctx->r24 = MEM_BU(ctx->r30, 0X0);
            goto L_8039F740;
    }
    goto skip_15;
    // 0x8039F71C: lbu         $t8, 0x0($fp)
    ctx->r24 = MEM_BU(ctx->r30, 0X0);
    skip_15:
    // 0x8039F720: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8039F724: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039F728: andi        $t7, $v1, 0xF
    ctx->r15 = ctx->r3 & 0XF;
    // 0x8039F72C: beq         $t7, $at, L_8039F73C
    if (ctx->r15 == ctx->r1) {
        // 0x8039F730: andi        $t9, $v1, 0xFFF0
        ctx->r25 = ctx->r3 & 0XFFF0;
            goto L_8039F73C;
    }
    // 0x8039F730: andi        $t9, $v1, 0xFFF0
    ctx->r25 = ctx->r3 & 0XFFF0;
    // 0x8039F734: ori         $t6, $t9, 0x2
    ctx->r14 = ctx->r25 | 0X2;
    // 0x8039F738: sb          $t6, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r14;
L_8039F73C:
    // 0x8039F73C: lbu         $t8, 0x0($fp)
    ctx->r24 = MEM_BU(ctx->r30, 0X0);
L_8039F740:
    // 0x8039F740: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039F744: andi        $t7, $t8, 0xF
    ctx->r15 = ctx->r24 & 0XF;
    // 0x8039F748: beql        $t7, $at, L_8039F77C
    if (ctx->r15 == ctx->r1) {
        // 0x8039F74C: lbu         $t7, 0x2($s3)
        ctx->r15 = MEM_BU(ctx->r19, 0X2);
            goto L_8039F77C;
    }
    goto skip_16;
    // 0x8039F74C: lbu         $t7, 0x2($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X2);
    skip_16:
    // 0x8039F750: lh          $t9, 0x4($s5)
    ctx->r25 = MEM_H(ctx->r21, 0X4);
    // 0x8039F754: sh          $t9, 0x2C($s3)
    MEM_H(0X2C, ctx->r19) = ctx->r25;
    // 0x8039F758: lh          $t6, 0x8($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X8);
    // 0x8039F75C: sh          $t6, 0x2E($s3)
    MEM_H(0X2E, ctx->r19) = ctx->r14;
    // 0x8039F760: lhu         $t7, 0x42($s5)
    ctx->r15 = MEM_HU(ctx->r21, 0X42);
    // 0x8039F764: lh          $t8, 0xC($s5)
    ctx->r24 = MEM_H(ctx->r21, 0XC);
    // 0x8039F768: sra         $t9, $t7, 1
    ctx->r25 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8039F76C: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x8039F770: b           L_8039F7A0
    // 0x8039F774: sh          $t6, 0x30($s3)
    MEM_H(0X30, ctx->r19) = ctx->r14;
        goto L_8039F7A0;
    // 0x8039F774: sh          $t6, 0x30($s3)
    MEM_H(0X30, ctx->r19) = ctx->r14;
    // 0x8039F778: lbu         $t7, 0x2($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X2);
L_8039F77C:
    // 0x8039F77C: addiu       $t8, $t7, 0x6
    ctx->r24 = ADD32(ctx->r15, 0X6);
    // 0x8039F780: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8039F784: slti        $at, $t9, 0xC0
    ctx->r1 = SIGNED(ctx->r25) < 0XC0 ? 1 : 0;
    // 0x8039F788: bne         $at, $zero, L_8039F7A0
    if (ctx->r1 != 0) {
        // 0x8039F78C: sb          $t8, 0x2($s3)
        MEM_B(0X2, ctx->r19) = ctx->r24;
            goto L_8039F7A0;
    }
    // 0x8039F78C: sb          $t8, 0x2($s3)
    MEM_B(0X2, ctx->r19) = ctx->r24;
    // 0x8039F790: lbu         $t6, 0x0($fp)
    ctx->r14 = MEM_BU(ctx->r30, 0X0);
    // 0x8039F794: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x8039F798: b           L_803A0484
    // 0x8039F79C: sb          $t7, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r15;
        goto L_803A0484;
    // 0x8039F79C: sb          $t7, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r15;
L_8039F7A0:
    // 0x8039F7A0: lbu         $t8, 0xA($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0XA);
    // 0x8039F7A4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8039F7A8: blez        $t8, L_8039F964
    if (SIGNED(ctx->r24) <= 0) {
        // 0x8039F7AC: sra         $t0, $a3, 1
        ctx->r8 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8039F964;
    }
    // 0x8039F7AC: sra         $t0, $a3, 1
    ctx->r8 = S32(SIGNED(ctx->r7) >> 1);
L_8039F7B0:
    // 0x8039F7B0: sll         $t9, $t0, 2
    ctx->r25 = S32(ctx->r8 << 2);
    // 0x8039F7B4: subu        $t9, $t9, $t0
    ctx->r25 = SUB32(ctx->r25, ctx->r8);
    // 0x8039F7B8: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039F7BC: lbu         $t6, 0xA($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0XA);
    // 0x8039F7C0: subu        $t9, $t9, $t0
    ctx->r25 = SUB32(ctx->r25, ctx->r8);
    // 0x8039F7C4: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039F7C8: addu        $t9, $t9, $t0
    ctx->r25 = ADD32(ctx->r25, ctx->r8);
    // 0x8039F7CC: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8039F7D0: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x8039F7D4: div         $zero, $t9, $t7
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r15))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r15)));
    // 0x8039F7D8: mflo        $t1
    ctx->r9 = lo;
    // 0x8039F7DC: andi        $t8, $a3, 0x2
    ctx->r24 = ctx->r7 & 0X2;
    // 0x8039F7E0: bne         $t7, $zero, L_8039F7EC
    if (ctx->r15 != 0) {
        // 0x8039F7E4: nop
    
            goto L_8039F7EC;
    }
    // 0x8039F7E4: nop

    // 0x8039F7E8: break       7
    do_break(2151282664);
L_8039F7EC:
    // 0x8039F7EC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039F7F0: bne         $t7, $at, L_8039F804
    if (ctx->r15 != ctx->r1) {
        // 0x8039F7F4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039F804;
    }
    // 0x8039F7F4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039F7F8: bne         $t9, $at, L_8039F804
    if (ctx->r25 != ctx->r1) {
        // 0x8039F7FC: nop
    
            goto L_8039F804;
    }
    // 0x8039F7FC: nop

    // 0x8039F800: break       6
    do_break(2151282688);
L_8039F804:
    // 0x8039F804: beql        $t8, $zero, L_8039F834
    if (ctx->r24 == 0) {
        // 0x8039F808: lbu         $t8, 0x1($s3)
        ctx->r24 = MEM_BU(ctx->r19, 0X1);
            goto L_8039F834;
    }
    goto skip_17;
    // 0x8039F808: lbu         $t8, 0x1($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X1);
    skip_17:
    // 0x8039F80C: lbu         $t6, 0x1($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X1);
    // 0x8039F810: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x8039F814: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x8039F818: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8039F81C: addu        $t6, $t2, $t8
    ctx->r14 = ADD32(ctx->r10, ctx->r24);
    // 0x8039F820: lh          $v1, 0x0($t6)
    ctx->r3 = MEM_H(ctx->r14, 0X0);
    // 0x8039F824: sll         $t9, $v1, 5
    ctx->r25 = S32(ctx->r3 << 5);
    // 0x8039F828: b           L_8039F858
    // 0x8039F82C: sra         $v1, $t9, 15
    ctx->r3 = S32(SIGNED(ctx->r25) >> 15);
        goto L_8039F858;
    // 0x8039F82C: sra         $v1, $t9, 15
    ctx->r3 = S32(SIGNED(ctx->r25) >> 15);
    // 0x8039F830: lbu         $t8, 0x1($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X1);
L_8039F834:
    // 0x8039F834: addiu       $t6, $t8, 0x40
    ctx->r14 = ADD32(ctx->r24, 0X40);
    // 0x8039F838: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8039F83C: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8039F840: addu        $t8, $t2, $t7
    ctx->r24 = ADD32(ctx->r10, ctx->r15);
    // 0x8039F844: lh          $v1, 0x0($t8)
    ctx->r3 = MEM_H(ctx->r24, 0X0);
    // 0x8039F848: sll         $t6, $v1, 5
    ctx->r14 = S32(ctx->r3 << 5);
    // 0x8039F84C: negu        $v1, $t6
    ctx->r3 = SUB32(0, ctx->r14);
    // 0x8039F850: sra         $t9, $v1, 15
    ctx->r25 = S32(SIGNED(ctx->r3) >> 15);
    // 0x8039F854: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
L_8039F858:
    // 0x8039F858: lhu         $a0, 0x40($s5)
    ctx->r4 = MEM_HU(ctx->r21, 0X40);
    // 0x8039F85C: addiu       $t7, $v1, 0x100
    ctx->r15 = ADD32(ctx->r3, 0X100);
    // 0x8039F860: lbu         $t6, 0x3($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X3);
    // 0x8039F864: multu       $t7, $a0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F868: sll         $t9, $t6, 3
    ctx->r25 = S32(ctx->r14 << 3);
    // 0x8039F86C: sll         $t6, $t1, 16
    ctx->r14 = S32(ctx->r9 << 16);
    // 0x8039F870: mflo        $v1
    ctx->r3 = lo;
    // 0x8039F874: sra         $t8, $v1, 11
    ctx->r24 = S32(SIGNED(ctx->r3) >> 11);
    // 0x8039F878: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x8039F87C: multu       $t9, $a0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F880: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039F884: mflo        $a1
    ctx->r5 = lo;
    // 0x8039F888: sra         $t7, $a1, 11
    ctx->r15 = S32(SIGNED(ctx->r5) >> 11);
    // 0x8039F88C: addu        $a1, $t7, $t8
    ctx->r5 = ADD32(ctx->r15, ctx->r24);
    // 0x8039F890: sll         $t8, $a3, 4
    ctx->r24 = S32(ctx->r7 << 4);
    // 0x8039F894: addu        $v0, $s3, $t8
    ctx->r2 = ADD32(ctx->r19, ctx->r24);
    // 0x8039F898: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8039F89C: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x8039F8A0: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8039F8A4: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x8039F8A8: lh          $t6, 0x384($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X384);
    // 0x8039F8AC: sh          $zero, 0x3A($v0)
    MEM_H(0X3A, ctx->r2) = 0;
    // 0x8039F8B0: addiu       $a3, $a3, 0x2
    ctx->r7 = ADD32(ctx->r7, 0X2);
    // 0x8039F8B4: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F8B8: mflo        $t9
    ctx->r25 = lo;
    // 0x8039F8BC: sra         $t7, $t9, 8
    ctx->r15 = S32(SIGNED(ctx->r25) >> 8);
    // 0x8039F8C0: sh          $t7, 0x38($v0)
    MEM_H(0X38, ctx->r2) = ctx->r15;
    // 0x8039F8C4: lh          $t8, 0x2D0($a2)
    ctx->r24 = MEM_H(ctx->r6, 0X2D0);
    // 0x8039F8C8: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F8CC: addiu       $v1, $zero, 0xC0
    ctx->r3 = ADD32(0, 0XC0);
    // 0x8039F8D0: mflo        $t6
    ctx->r14 = lo;
    // 0x8039F8D4: sra         $t9, $t6, 8
    ctx->r25 = S32(SIGNED(ctx->r14) >> 8);
    // 0x8039F8D8: sh          $t9, 0x3C($v0)
    MEM_H(0X3C, ctx->r2) = ctx->r25;
    // 0x8039F8DC: lh          $t7, 0x384($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X384);
    // 0x8039F8E0: sh          $zero, 0x4A($v0)
    MEM_H(0X4A, ctx->r2) = 0;
    // 0x8039F8E4: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F8E8: mflo        $t8
    ctx->r24 = lo;
    // 0x8039F8EC: sra         $t6, $t8, 8
    ctx->r14 = S32(SIGNED(ctx->r24) >> 8);
    // 0x8039F8F0: sh          $t6, 0x48($v0)
    MEM_H(0X48, ctx->r2) = ctx->r14;
    // 0x8039F8F4: lh          $t9, 0x2D0($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X2D0);
    // 0x8039F8F8: multu       $t9, $a1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039F8FC: mflo        $t7
    ctx->r15 = lo;
    // 0x8039F900: sra         $t8, $t7, 8
    ctx->r24 = S32(SIGNED(ctx->r15) >> 8);
    // 0x8039F904: sh          $t8, 0x4C($v0)
    MEM_H(0X4C, ctx->r2) = ctx->r24;
    // 0x8039F908: lbu         $t6, 0x2($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X2);
    // 0x8039F90C: subu        $t9, $v1, $t6
    ctx->r25 = SUB32(ctx->r3, ctx->r14);
    // 0x8039F910: sb          $t9, 0x47($v0)
    MEM_B(0X47, ctx->r2) = ctx->r25;
    // 0x8039F914: lbu         $t7, 0x2($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X2);
    // 0x8039F918: andi        $t6, $t0, 0x1
    ctx->r14 = ctx->r8 & 0X1;
    // 0x8039F91C: subu        $t8, $v1, $t7
    ctx->r24 = SUB32(ctx->r3, ctx->r15);
    // 0x8039F920: beq         $t6, $zero, L_8039F93C
    if (ctx->r14 == 0) {
        // 0x8039F924: sb          $t8, 0x57($v0)
        MEM_B(0X57, ctx->r2) = ctx->r24;
            goto L_8039F93C;
    }
    // 0x8039F924: sb          $t8, 0x57($v0)
    MEM_B(0X57, ctx->r2) = ctx->r24;
    // 0x8039F928: sh          $t3, 0x40($v0)
    MEM_H(0X40, ctx->r2) = ctx->r11;
    // 0x8039F92C: sh          $zero, 0x42($v0)
    MEM_H(0X42, ctx->r2) = 0;
    // 0x8039F930: sh          $t3, 0x50($v0)
    MEM_H(0X50, ctx->r2) = ctx->r11;
    // 0x8039F934: b           L_8039F94C
    // 0x8039F938: sh          $t3, 0x52($v0)
    MEM_H(0X52, ctx->r2) = ctx->r11;
        goto L_8039F94C;
    // 0x8039F938: sh          $t3, 0x52($v0)
    MEM_H(0X52, ctx->r2) = ctx->r11;
L_8039F93C:
    // 0x8039F93C: sh          $zero, 0x40($v0)
    MEM_H(0X40, ctx->r2) = 0;
    // 0x8039F940: sh          $zero, 0x42($v0)
    MEM_H(0X42, ctx->r2) = 0;
    // 0x8039F944: sh          $zero, 0x50($v0)
    MEM_H(0X50, ctx->r2) = 0;
    // 0x8039F948: sh          $t3, 0x52($v0)
    MEM_H(0X52, ctx->r2) = ctx->r11;
L_8039F94C:
    // 0x8039F94C: lbu         $t8, 0xA($s4)
    ctx->r24 = MEM_BU(ctx->r20, 0XA);
    // 0x8039F950: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x8039F954: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039F958: slt         $at, $a3, $t8
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x8039F95C: bnel        $at, $zero, L_8039F7B0
    if (ctx->r1 != 0) {
        // 0x8039F960: sra         $t0, $a3, 1
        ctx->r8 = S32(SIGNED(ctx->r7) >> 1);
            goto L_8039F7B0;
    }
    goto skip_18;
    // 0x8039F960: sra         $t0, $a3, 1
    ctx->r8 = S32(SIGNED(ctx->r7) >> 1);
    skip_18:
L_8039F964:
    // 0x8039F964: lh          $a0, 0x2C($s3)
    ctx->r4 = MEM_H(ctx->r19, 0X2C);
    // 0x8039F968: lh          $a1, 0x2E($s3)
    ctx->r5 = MEM_H(ctx->r19, 0X2E);
    // 0x8039F96C: jal         0x8029A334
    // 0x8039F970: lh          $a2, 0x30($s3)
    ctx->r6 = MEM_H(ctx->r19, 0X30);
    is_world_cell_loaded_6AB9E4(rdram, ctx);
        goto after_2;
    // 0x8039F970: lh          $a2, 0x30($s3)
    ctx->r6 = MEM_H(ctx->r19, 0X30);
    after_2:
    // 0x8039F974: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039F978: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039F97C: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039F980: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039F984: beq         $v0, $zero, L_8039FE44
    if (ctx->r2 == 0) {
        // 0x8039F988: lui         $ra, 0xB100
        ctx->r31 = S32(0XB100 << 16);
            goto L_8039FE44;
    }
    // 0x8039F988: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
    // 0x8039F98C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F990: lui         $t9, 0xFC30
    ctx->r25 = S32(0XFC30 << 16);
    // 0x8039F994: lui         $t7, 0x5532
    ctx->r15 = S32(0X5532 << 16);
    // 0x8039F998: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039F99C: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039F9A0: ori         $t7, $t7, 0xFF7F
    ctx->r15 = ctx->r15 | 0XFF7F;
    // 0x8039F9A4: ori         $t9, $t9, 0x9861
    ctx->r25 = ctx->r25 | 0X9861;
    // 0x8039F9A8: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039F9AC: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8039F9B0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F9B4: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x8039F9B8: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x8039F9BC: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8039F9C0: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039F9C4: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039F9C8: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039F9CC: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039F9D0: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8039F9D4: lui         $s2, 0x8020
    ctx->r18 = S32(0X8020 << 16);
    // 0x8039F9D8: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039F9DC: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039F9E0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039F9E4: lbu         $t6, 0x6($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X6);
    // 0x8039F9E8: lbu         $t8, 0x4($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X4);
    // 0x8039F9EC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039F9F0: sll         $t9, $t6, 8
    ctx->r25 = S32(ctx->r14 << 8);
    // 0x8039F9F4: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8039F9F8: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8039F9FC: lbu         $t9, 0x5($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X5);
    // 0x8039FA00: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039FA04: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x8039FA08: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x8039FA0C: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x8039FA10: ori         $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 | 0XFF;
    // 0x8039FA14: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8039FA18: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FA1C: lui         $t6, 0xFB00
    ctx->r14 = S32(0XFB00 << 16);
    // 0x8039FA20: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039FA24: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039FA28: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039FA2C: lbu         $t9, 0x9($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X9);
    // 0x8039FA30: lbu         $t8, 0x7($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X7);
    // 0x8039FA34: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x8039FA38: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x8039FA3C: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8039FA40: lbu         $t7, 0x8($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X8);
    // 0x8039FA44: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8039FA48: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8039FA4C: ori         $t7, $t8, 0xFF
    ctx->r15 = ctx->r24 | 0XFF;
    // 0x8039FA50: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8039FA54: lw          $s2, 0x4278($s2)
    ctx->r18 = MEM_W(ctx->r18, 0X4278);
    // 0x8039FA58: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x8039FA5C: lh          $t7, 0x2E($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X2E);
    // 0x8039FA60: addu        $t6, $t6, $s2
    ctx->r14 = ADD32(ctx->r14, ctx->r18);
    // 0x8039FA64: lw          $t6, -0x76E8($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76E8);
    // 0x8039FA68: lh          $t8, 0x2C($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X2C);
    // 0x8039FA6C: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x8039FA70: sll         $t9, $t6, 6
    ctx->r25 = S32(ctx->r14 << 6);
    // 0x8039FA74: lh          $t6, 0x30($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X30);
    // 0x8039FA78: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x8039FA7C: cvt.s.w     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039FA80: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x8039FA84: addu        $a0, $s2, $t9
    ctx->r4 = ADD32(ctx->r18, ctx->r25);
    // 0x8039FA88: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8039FA8C: cvt.s.w     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039FA90: mfc1        $a2, $f16
    ctx->r6 = (int32_t)ctx->f16.u32l;
    // 0x8039FA94: cvt.s.w     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039FA98: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x8039FA9C: mfc1        $a3, $f18
    ctx->r7 = (int32_t)ctx->f18.u32l;
    // 0x8039FAA0: jal         0x8013F328
    // 0x8039FAA4: nop

    guTranslate(rdram, ctx);
        goto after_3;
    // 0x8039FAA4: nop

    after_3:
    // 0x8039FAA8: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FAAC: lui         $t8, 0x104
    ctx->r24 = S32(0X104 << 16);
    // 0x8039FAB0: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8039FAB4: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039FAB8: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039FABC: ori         $t8, $t8, 0x40
    ctx->r24 = ctx->r24 | 0X40;
    // 0x8039FAC0: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x8039FAC4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039FAC8: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FACC: lui         $v1, 0x3
    ctx->r3 = S32(0X3 << 16);
    // 0x8039FAD0: ori         $v1, $v1, 0x8000
    ctx->r3 = ctx->r3 | 0X8000;
    // 0x8039FAD4: addu        $t7, $s2, $v1
    ctx->r15 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FAD8: lw          $t6, 0x918($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X918);
    // 0x8039FADC: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x8039FAE0: ori         $t1, $t1, 0x3590
    ctx->r9 = ctx->r9 | 0X3590;
    // 0x8039FAE4: sll         $t9, $t6, 6
    ctx->r25 = S32(ctx->r14 << 6);
    // 0x8039FAE8: addu        $t8, $s2, $t9
    ctx->r24 = ADD32(ctx->r18, ctx->r25);
    // 0x8039FAEC: addu        $t7, $t8, $t1
    ctx->r15 = ADD32(ctx->r24, ctx->r9);
    // 0x8039FAF0: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8039FAF4: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FAF8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039FAFC: addu        $t6, $s2, $v1
    ctx->r14 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FB00: lw          $t9, 0x918($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X918);
    // 0x8039FB04: addu        $at, $at, $s2
    ctx->r1 = ADD32(ctx->r1, ctx->r18);
    // 0x8039FB08: addiu       $t8, $t9, 0x1
    ctx->r24 = ADD32(ctx->r25, 0X1);
    // 0x8039FB0C: sw          $t8, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r24;
    // 0x8039FB10: lbu         $t7, 0x2($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X2);
    // 0x8039FB14: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8039FB18: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x8039FB1C: bgez        $t7, L_8039FB30
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039FB20: cvt.s.w     $f4, $f6
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
            goto L_8039FB30;
    }
    // 0x8039FB20: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039FB24: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039FB28: nop

    // 0x8039FB2C: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_8039FB30:
    // 0x8039FB30: lui         $at, 0x4280
    ctx->r1 = S32(0X4280 << 16);
    // 0x8039FB34: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039FB38: lui         $at, 0x4100
    ctx->r1 = S32(0X4100 << 16);
    // 0x8039FB3C: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8039FB40: div.s       $f16, $f4, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f4.fl, ctx->f10.fl);
    // 0x8039FB44: lui         $at, 0x3FC0
    ctx->r1 = S32(0X3FC0 << 16);
    // 0x8039FB48: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x8039FB4C: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x8039FB50: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FB54: addu        $t6, $s2, $v1
    ctx->r14 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FB58: lw          $t9, 0x918($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X918);
    // 0x8039FB5C: sll         $t8, $t9, 6
    ctx->r24 = S32(ctx->r25 << 6);
    // 0x8039FB60: addu        $t7, $s2, $t8
    ctx->r15 = ADD32(ctx->r18, ctx->r24);
    // 0x8039FB64: addu        $a0, $t7, $t1
    ctx->r4 = ADD32(ctx->r15, ctx->r9);
    // 0x8039FB68: div.s       $f6, $f16, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    // 0x8039FB6C: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x8039FB70: add.d       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f4.d); 
    ctx->f10.d = ctx->f8.d + ctx->f4.d;
    // 0x8039FB74: cvt.s.d     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f2.fl = CVT_S_D(ctx->f10.d);
    // 0x8039FB78: mfc1        $a1, $f2
    ctx->r5 = (int32_t)ctx->f2.u32l;
    // 0x8039FB7C: mfc1        $a2, $f2
    ctx->r6 = (int32_t)ctx->f2.u32l;
    // 0x8039FB80: mfc1        $a3, $f2
    ctx->r7 = (int32_t)ctx->f2.u32l;
    // 0x8039FB84: jal         0x8013F664
    // 0x8039FB88: nop

    guScale(rdram, ctx);
        goto after_4;
    // 0x8039FB88: nop

    after_4:
    // 0x8039FB8C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FB90: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8039FB94: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8039FB98: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039FB9C: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039FBA0: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x8039FBA4: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x8039FBA8: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039FBAC: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FBB0: lui         $v1, 0x3
    ctx->r3 = S32(0X3 << 16);
    // 0x8039FBB4: ori         $v1, $v1, 0x8000
    ctx->r3 = ctx->r3 | 0X8000;
    // 0x8039FBB8: addu        $t8, $s2, $v1
    ctx->r24 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FBBC: lw          $t7, 0x918($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X918);
    // 0x8039FBC0: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x8039FBC4: ori         $t1, $t1, 0x3590
    ctx->r9 = ctx->r9 | 0X3590;
    // 0x8039FBC8: sll         $t6, $t7, 6
    ctx->r14 = S32(ctx->r15 << 6);
    // 0x8039FBCC: addu        $t9, $s2, $t6
    ctx->r25 = ADD32(ctx->r18, ctx->r14);
    // 0x8039FBD0: addu        $t8, $t9, $t1
    ctx->r24 = ADD32(ctx->r25, ctx->r9);
    // 0x8039FBD4: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8039FBD8: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FBDC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039FBE0: mfc1        $a2, $f24
    ctx->r6 = (int32_t)ctx->f24.u32l;
    // 0x8039FBE4: addu        $t7, $s2, $v1
    ctx->r15 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FBE8: lw          $t6, 0x918($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X918);
    // 0x8039FBEC: addu        $at, $at, $s2
    ctx->r1 = ADD32(ctx->r1, ctx->r18);
    // 0x8039FBF0: mfc1        $a3, $f24
    ctx->r7 = (int32_t)ctx->f24.u32l;
    // 0x8039FBF4: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x8039FBF8: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
    // 0x8039FBFC: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FC00: addu        $t8, $s2, $v1
    ctx->r24 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FC04: lw          $t7, 0x918($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X918);
    // 0x8039FC08: lh          $t8, 0x2C($s5)
    ctx->r24 = MEM_H(ctx->r21, 0X2C);
    // 0x8039FC0C: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8039FC10: sll         $t6, $t7, 6
    ctx->r14 = S32(ctx->r15 << 6);
    // 0x8039FC14: mtc1        $t8, $f16
    ctx->f16.u32l = ctx->r24;
    // 0x8039FC18: addu        $t9, $s2, $t6
    ctx->r25 = ADD32(ctx->r18, ctx->r14);
    // 0x8039FC1C: addu        $a0, $t9, $t1
    ctx->r4 = ADD32(ctx->r25, ctx->r9);
    // 0x8039FC20: cvt.s.w     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039FC24: mfc1        $a1, $f16
    ctx->r5 = (int32_t)ctx->f16.u32l;
    // 0x8039FC28: jal         0x8013FB74
    // 0x8039FC2C: nop

    guRotate(rdram, ctx);
        goto after_5;
    // 0x8039FC2C: nop

    after_5:
    // 0x8039FC30: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FC34: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x8039FC38: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8039FC3C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039FC40: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039FC44: ori         $t6, $t6, 0x40
    ctx->r14 = ctx->r14 | 0X40;
    // 0x8039FC48: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x8039FC4C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039FC50: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FC54: lui         $v1, 0x3
    ctx->r3 = S32(0X3 << 16);
    // 0x8039FC58: ori         $v1, $v1, 0x8000
    ctx->r3 = ctx->r3 | 0X8000;
    // 0x8039FC5C: addu        $t9, $s2, $v1
    ctx->r25 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FC60: lw          $t8, 0x918($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X918);
    // 0x8039FC64: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x8039FC68: ori         $t1, $t1, 0x3590
    ctx->r9 = ctx->r9 | 0X3590;
    // 0x8039FC6C: sll         $t7, $t8, 6
    ctx->r15 = S32(ctx->r24 << 6);
    // 0x8039FC70: addu        $t6, $s2, $t7
    ctx->r14 = ADD32(ctx->r18, ctx->r15);
    // 0x8039FC74: addu        $t9, $t6, $t1
    ctx->r25 = ADD32(ctx->r14, ctx->r9);
    // 0x8039FC78: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8039FC7C: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FC80: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039FC84: mfc1        $a2, $f20
    ctx->r6 = (int32_t)ctx->f20.u32l;
    // 0x8039FC88: addu        $t8, $s2, $v1
    ctx->r24 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FC8C: lw          $t7, 0x918($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X918);
    // 0x8039FC90: addu        $at, $at, $s2
    ctx->r1 = ADD32(ctx->r1, ctx->r18);
    // 0x8039FC94: mfc1        $a3, $f24
    ctx->r7 = (int32_t)ctx->f24.u32l;
    // 0x8039FC98: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x8039FC9C: sw          $t6, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r14;
    // 0x8039FCA0: lw          $s2, 0x0($t0)
    ctx->r18 = MEM_W(ctx->r8, 0X0);
    // 0x8039FCA4: addu        $t9, $s2, $v1
    ctx->r25 = ADD32(ctx->r18, ctx->r3);
    // 0x8039FCA8: lw          $t8, 0x918($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X918);
    // 0x8039FCAC: lh          $t9, 0x2E($s5)
    ctx->r25 = MEM_H(ctx->r21, 0X2E);
    // 0x8039FCB0: swc1        $f24, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f24.u32l;
    // 0x8039FCB4: sll         $t7, $t8, 6
    ctx->r15 = S32(ctx->r24 << 6);
    // 0x8039FCB8: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8039FCBC: addu        $t6, $s2, $t7
    ctx->r14 = ADD32(ctx->r18, ctx->r15);
    // 0x8039FCC0: addu        $a0, $t6, $t1
    ctx->r4 = ADD32(ctx->r14, ctx->r9);
    // 0x8039FCC4: cvt.s.w     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039FCC8: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x8039FCCC: jal         0x8013FB74
    // 0x8039FCD0: nop

    guRotate(rdram, ctx);
        goto after_6;
    // 0x8039FCD0: nop

    after_6:
    // 0x8039FCD4: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FCD8: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8039FCDC: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x8039FCE0: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8039FCE4: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039FCE8: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x8039FCEC: addiu       $t1, $t1, 0x4278
    ctx->r9 = ADD32(ctx->r9, 0X4278);
    // 0x8039FCF0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039FCF4: lw          $s2, 0x0($t1)
    ctx->r18 = MEM_W(ctx->r9, 0X0);
    // 0x8039FCF8: lui         $t0, 0x3
    ctx->r8 = S32(0X3 << 16);
    // 0x8039FCFC: ori         $t0, $t0, 0x8000
    ctx->r8 = ctx->r8 | 0X8000;
    // 0x8039FD00: addu        $t6, $s2, $t0
    ctx->r14 = ADD32(ctx->r18, ctx->r8);
    // 0x8039FD04: lw          $t9, 0x918($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X918);
    // 0x8039FD08: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039FD0C: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039FD10: sll         $t8, $t9, 6
    ctx->r24 = S32(ctx->r25 << 6);
    // 0x8039FD14: addu        $t7, $s2, $t8
    ctx->r15 = ADD32(ctx->r18, ctx->r24);
    // 0x8039FD18: addu        $t6, $t7, $at
    ctx->r14 = ADD32(ctx->r15, ctx->r1);
    // 0x8039FD1C: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8039FD20: lw          $s2, 0x0($t1)
    ctx->r18 = MEM_W(ctx->r9, 0X0);
    // 0x8039FD24: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039FD28: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039FD2C: addu        $t9, $s2, $t0
    ctx->r25 = ADD32(ctx->r18, ctx->r8);
    // 0x8039FD30: lw          $t8, 0x918($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X918);
    // 0x8039FD34: addu        $at, $at, $s2
    ctx->r1 = ADD32(ctx->r1, ctx->r18);
    // 0x8039FD38: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x8039FD3C: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x8039FD40: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x8039FD44: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FD48: addiu       $t8, $s3, 0x38
    ctx->r24 = ADD32(ctx->r19, 0X38);
    // 0x8039FD4C: ori         $t9, $t9, 0x81FF
    ctx->r25 = ctx->r25 | 0X81FF;
    // 0x8039FD50: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039FD54: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x8039FD58: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8039FD5C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039FD60: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FD64: lui         $t6, 0xBD00
    ctx->r14 = S32(0XBD00 << 16);
    // 0x8039FD68: lui         $t8, 0xF580
    ctx->r24 = S32(0XF580 << 16);
    // 0x8039FD6C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039FD70: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x8039FD74: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039FD78: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039FD7C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039FD80: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FD84: ori         $t8, $t8, 0x400
    ctx->r24 = ctx->r24 | 0X400;
    // 0x8039FD88: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039FD8C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039FD90: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039FD94: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8039FD98: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039FD9C: lbu         $a2, 0xA($s3)
    ctx->r6 = MEM_BU(ctx->r19, 0XA);
    // 0x8039FDA0: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039FDA4: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039FDA8: addiu       $a3, $a2, -0x1
    ctx->r7 = ADD32(ctx->r6, -0X1);
    // 0x8039FDAC: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x8039FDB0: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
    // 0x8039FDB4: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039FDB8: blez        $a2, L_8039FE44
    if (SIGNED(ctx->r6) <= 0) {
        // 0x8039FDBC: or          $a1, $s0, $zero
        ctx->r5 = ctx->r16 | 0;
            goto L_8039FE44;
    }
    // 0x8039FDBC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
L_8039FDC0:
    // 0x8039FDC0: addiu       $t7, $s1, 0x3
    ctx->r15 = ADD32(ctx->r17, 0X3);
    // 0x8039FDC4: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x8039FDC8: and         $a2, $t7, $a3
    ctx->r6 = ctx->r15 & ctx->r7;
    // 0x8039FDCC: sll         $v0, $s1, 1
    ctx->r2 = S32(ctx->r17 << 1);
    // 0x8039FDD0: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    // 0x8039FDD4: sll         $t6, $a2, 1
    ctx->r14 = S32(ctx->r6 << 1);
    // 0x8039FDD8: andi        $a2, $t6, 0xFF
    ctx->r6 = ctx->r14 & 0XFF;
    // 0x8039FDDC: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8039FDE0: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x8039FDE4: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8039FDE8: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8039FDEC: sll         $t8, $a2, 8
    ctx->r24 = S32(ctx->r6 << 8);
    // 0x8039FDF0: addiu       $t6, $v0, 0x2
    ctx->r14 = ADD32(ctx->r2, 0X2);
    // 0x8039FDF4: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8039FDF8: or          $t7, $v1, $t8
    ctx->r15 = ctx->r3 | ctx->r24;
    // 0x8039FDFC: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x8039FE00: addiu       $a0, $s1, 0x2
    ctx->r4 = ADD32(ctx->r17, 0X2);
    // 0x8039FE04: and         $t7, $a0, $a3
    ctx->r15 = ctx->r4 & ctx->r7;
    // 0x8039FE08: or          $t6, $t8, $ra
    ctx->r14 = ctx->r24 | ctx->r31;
    // 0x8039FE0C: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x8039FE10: andi        $t8, $t9, 0xFF
    ctx->r24 = ctx->r25 & 0XFF;
    // 0x8039FE14: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039FE18: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x8039FE1C: or          $t7, $v1, $t6
    ctx->r15 = ctx->r3 | ctx->r14;
    // 0x8039FE20: or          $t9, $t7, $a2
    ctx->r25 = ctx->r15 | ctx->r6;
    // 0x8039FE24: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8039FE28: lbu         $t6, 0xA($s4)
    ctx->r14 = MEM_BU(ctx->r20, 0XA);
    // 0x8039FE2C: sll         $s1, $a0, 16
    ctx->r17 = S32(ctx->r4 << 16);
    // 0x8039FE30: sra         $t8, $s1, 16
    ctx->r24 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8039FE34: slt         $at, $t8, $t6
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x8039FE38: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x8039FE3C: bne         $at, $zero, L_8039FDC0
    if (ctx->r1 != 0) {
        // 0x8039FE40: or          $a1, $s0, $zero
        ctx->r5 = ctx->r16 | 0;
            goto L_8039FDC0;
    }
    // 0x8039FE40: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
L_8039FE44:
    // 0x8039FE44: lbu         $t7, 0x1($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0X1);
    // 0x8039FE48: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x8039FE4C: b           L_803A0484
    // 0x8039FE50: sb          $t8, 0x1($s3)
    MEM_B(0X1, ctx->r19) = ctx->r24;
        goto L_803A0484;
    // 0x8039FE50: sb          $t8, 0x1($s3)
    MEM_B(0X1, ctx->r19) = ctx->r24;
L_8039FE54:
    // 0x8039FE54: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8039FE58: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039FE5C: sw          $s3, 0x148($sp)
    MEM_W(0X148, ctx->r29) = ctx->r19;
    // 0x8039FE60: andi        $v0, $v1, 0xF
    ctx->r2 = ctx->r3 & 0XF;
    // 0x8039FE64: lw          $s5, 0x330($fp)
    ctx->r21 = MEM_W(ctx->r30, 0X330);
    // 0x8039FE68: beq         $v0, $at, L_8039FE94
    if (ctx->r2 == ctx->r1) {
        // 0x8039FE6C: or          $t1, $zero, $zero
        ctx->r9 = 0 | 0;
            goto L_8039FE94;
    }
    // 0x8039FE6C: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
    // 0x8039FE70: lh          $t6, 0x1C($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X1C);
    // 0x8039FE74: lh          $t7, 0x20($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X20);
    // 0x8039FE78: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8039FE7C: beq         $t9, $zero, L_8039FE8C
    if (ctx->r25 == 0) {
        // 0x8039FE80: nop
    
            goto L_8039FE8C;
    }
    // 0x8039FE80: nop

    // 0x8039FE84: b           L_8039FE98
    // 0x8039FE88: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
        goto L_8039FE98;
    // 0x8039FE88: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
L_8039FE8C:
    // 0x8039FE8C: b           L_8039FE98
    // 0x8039FE90: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
        goto L_8039FE98;
    // 0x8039FE90: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
L_8039FE94:
    // 0x8039FE94: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
L_8039FE98:
    // 0x8039FE98: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039FE9C: beql        $v0, $at, L_8039FEE4
    if (ctx->r2 == ctx->r1) {
        // 0x8039FEA0: lbu         $t9, 0x1($fp)
        ctx->r25 = MEM_BU(ctx->r30, 0X1);
            goto L_8039FEE4;
    }
    goto skip_19;
    // 0x8039FEA0: lbu         $t9, 0x1($fp)
    ctx->r25 = MEM_BU(ctx->r30, 0X1);
    skip_19:
    // 0x8039FEA4: lbu         $t8, 0x1($fp)
    ctx->r24 = MEM_BU(ctx->r30, 0X1);
    // 0x8039FEA8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039FEAC: srl         $t6, $t8, 4
    ctx->r14 = S32(U32(ctx->r24) >> 4);
    // 0x8039FEB0: bnel        $t6, $at, L_8039FECC
    if (ctx->r14 != ctx->r1) {
        // 0x8039FEB4: lbu         $t8, 0x26C($s5)
        ctx->r24 = MEM_BU(ctx->r21, 0X26C);
            goto L_8039FECC;
    }
    goto skip_20;
    // 0x8039FEB4: lbu         $t8, 0x26C($s5)
    ctx->r24 = MEM_BU(ctx->r21, 0X26C);
    skip_20:
    // 0x8039FEB8: lhu         $t7, 0x0($fp)
    ctx->r15 = MEM_HU(ctx->r30, 0X0);
    // 0x8039FEBC: andi        $t9, $t7, 0xF
    ctx->r25 = ctx->r15 & 0XF;
    // 0x8039FEC0: beql        $t9, $zero, L_8039FED4
    if (ctx->r25 == 0) {
        // 0x8039FEC4: andi        $t6, $v1, 0xFFF0
        ctx->r14 = ctx->r3 & 0XFFF0;
            goto L_8039FED4;
    }
    goto skip_21;
    // 0x8039FEC4: andi        $t6, $v1, 0xFFF0
    ctx->r14 = ctx->r3 & 0XFFF0;
    skip_21:
    // 0x8039FEC8: lbu         $t8, 0x26C($s5)
    ctx->r24 = MEM_BU(ctx->r21, 0X26C);
L_8039FECC:
    // 0x8039FECC: beq         $t8, $zero, L_8039FEE0
    if (ctx->r24 == 0) {
        // 0x8039FED0: andi        $t6, $v1, 0xFFF0
        ctx->r14 = ctx->r3 & 0XFFF0;
            goto L_8039FEE0;
    }
    // 0x8039FED0: andi        $t6, $v1, 0xFFF0
    ctx->r14 = ctx->r3 & 0XFFF0;
L_8039FED4:
    // 0x8039FED4: ori         $t7, $t6, 0x2
    ctx->r15 = ctx->r14 | 0X2;
    // 0x8039FED8: sb          $t7, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r15;
    // 0x8039FEDC: sw          $zero, 0x4($fp)
    MEM_W(0X4, ctx->r30) = 0;
L_8039FEE0:
    // 0x8039FEE0: lbu         $t9, 0x1($fp)
    ctx->r25 = MEM_BU(ctx->r30, 0X1);
L_8039FEE4:
    // 0x8039FEE4: andi        $t8, $t9, 0xFFF0
    ctx->r24 = ctx->r25 & 0XFFF0;
    // 0x8039FEE8: sb          $t8, 0x1($fp)
    MEM_B(0X1, ctx->r30) = ctx->r24;
    // 0x8039FEEC: lbu         $t6, 0x3($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X3);
    // 0x8039FEF0: bnel        $t6, $zero, L_8039FFBC
    if (ctx->r14 != 0) {
        // 0x8039FEF4: lbu         $s4, 0x2($s3)
        ctx->r20 = MEM_BU(ctx->r19, 0X2);
            goto L_8039FFBC;
    }
    goto skip_22;
    // 0x8039FEF4: lbu         $s4, 0x2($s3)
    ctx->r20 = MEM_BU(ctx->r19, 0X2);
    skip_22:
    // 0x8039FEF8: lbu         $v1, 0x0($fp)
    ctx->r3 = MEM_BU(ctx->r30, 0X0);
    // 0x8039FEFC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039FF00: andi        $v0, $v1, 0xF
    ctx->r2 = ctx->r3 & 0XF;
    // 0x8039FF04: beq         $v0, $at, L_8039FFB8
    if (ctx->r2 == ctx->r1) {
        // 0x8039FF08: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_8039FFB8;
    }
    // 0x8039FF08: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039FF0C: bne         $v0, $at, L_8039FF50
    if (ctx->r2 != ctx->r1) {
        // 0x8039FF10: andi        $t7, $v1, 0xFFF0
        ctx->r15 = ctx->r3 & 0XFFF0;
            goto L_8039FF50;
    }
    // 0x8039FF10: andi        $t7, $v1, 0xFFF0
    ctx->r15 = ctx->r3 & 0XFFF0;
    // 0x8039FF14: sb          $t7, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r15;
    // 0x8039FF18: sb          $zero, 0x2($s3)
    MEM_B(0X2, ctx->r19) = 0;
    // 0x8039FF1C: sb          $zero, 0x4($s3)
    MEM_B(0X4, ctx->r19) = 0;
    // 0x8039FF20: sb          $zero, 0x1($s3)
    MEM_B(0X1, ctx->r19) = 0;
    // 0x8039FF24: sb          $t5, 0x135($sp)
    MEM_B(0X135, ctx->r29) = ctx->r13;
    // 0x8039FF28: sb          $t1, 0x14F($sp)
    MEM_B(0X14F, ctx->r29) = ctx->r9;
    // 0x8039FF2C: jal         0x8039E33C
    // 0x8039FF30: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    func_8039E33C_7AF9EC(rdram, ctx);
        goto after_7;
    // 0x8039FF30: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    after_7:
    // 0x8039FF34: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039FF38: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039FF3C: lbu         $t1, 0x14F($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X14F);
    // 0x8039FF40: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039FF44: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039FF48: lbu         $t5, 0x135($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X135);
    // 0x8039FF4C: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
L_8039FF50:
    // 0x8039FF50: beql        $t5, $zero, L_8039FFBC
    if (ctx->r13 == 0) {
        // 0x8039FF54: lbu         $s4, 0x2($s3)
        ctx->r20 = MEM_BU(ctx->r19, 0X2);
            goto L_8039FFBC;
    }
    goto skip_23;
    // 0x8039FF54: lbu         $s4, 0x2($s3)
    ctx->r20 = MEM_BU(ctx->r19, 0X2);
    skip_23:
    // 0x8039FF58: lbu         $t9, 0x1($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X1);
    // 0x8039FF5C: lbu         $v0, 0x2($s3)
    ctx->r2 = MEM_BU(ctx->r19, 0X2);
    // 0x8039FF60: addiu       $t8, $t9, 0x2
    ctx->r24 = ADD32(ctx->r25, 0X2);
    // 0x8039FF64: andi        $t6, $t8, 0x1F
    ctx->r14 = ctx->r24 & 0X1F;
    // 0x8039FF68: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x8039FF6C: bne         $v0, $t7, L_8039FF80
    if (ctx->r2 != ctx->r15) {
        // 0x8039FF70: sb          $t6, 0x1($s3)
        MEM_B(0X1, ctx->r19) = ctx->r14;
            goto L_8039FF80;
    }
    // 0x8039FF70: sb          $t6, 0x1($s3)
    MEM_B(0X1, ctx->r19) = ctx->r14;
    // 0x8039FF74: addiu       $t9, $v0, 0x2
    ctx->r25 = ADD32(ctx->r2, 0X2);
    // 0x8039FF78: andi        $t8, $t9, 0x1F
    ctx->r24 = ctx->r25 & 0X1F;
    // 0x8039FF7C: sb          $t8, 0x2($s3)
    MEM_B(0X2, ctx->r19) = ctx->r24;
L_8039FF80:
    // 0x8039FF80: lbu         $t6, 0x4($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X4);
    // 0x8039FF84: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8039FF88: addiu       $t9, $t6, 0x28
    ctx->r25 = ADD32(ctx->r14, 0X28);
    // 0x8039FF8C: sb          $t9, 0x4($s3)
    MEM_B(0X4, ctx->r19) = ctx->r25;
    // 0x8039FF90: sb          $t5, 0x135($sp)
    MEM_B(0X135, ctx->r29) = ctx->r13;
    // 0x8039FF94: jal         0x8039E33C
    // 0x8039FF98: sb          $t1, 0x14F($sp)
    MEM_B(0X14F, ctx->r29) = ctx->r9;
    func_8039E33C_7AF9EC(rdram, ctx);
        goto after_8;
    // 0x8039FF98: sb          $t1, 0x14F($sp)
    MEM_B(0X14F, ctx->r29) = ctx->r9;
    after_8:
    // 0x8039FF9C: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8039FFA0: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8039FFA4: lbu         $t1, 0x14F($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X14F);
    // 0x8039FFA8: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x8039FFAC: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x8039FFB0: lbu         $t5, 0x135($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X135);
    // 0x8039FFB4: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
L_8039FFB8:
    // 0x8039FFB8: lbu         $s4, 0x2($s3)
    ctx->r20 = MEM_BU(ctx->r19, 0X2);
L_8039FFBC:
    // 0x8039FFBC: bne         $t5, $zero, L_8039FFE4
    if (ctx->r13 != 0) {
        // 0x8039FFC0: sra         $s2, $s4, 1
        ctx->r18 = S32(SIGNED(ctx->r20) >> 1);
            goto L_8039FFE4;
    }
    // 0x8039FFC0: sra         $s2, $s4, 1
    ctx->r18 = S32(SIGNED(ctx->r20) >> 1);
    // 0x8039FFC4: sra         $t8, $s4, 1
    ctx->r24 = S32(SIGNED(ctx->r20) >> 1);
    // 0x8039FFC8: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x8039FFCC: addu        $s0, $s3, $t6
    ctx->r16 = ADD32(ctx->r19, ctx->r14);
    // 0x8039FFD0: lh          $v0, 0xE($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XE);
    // 0x8039FFD4: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    // 0x8039FFD8: beq         $at, $zero, L_8039FFE4
    if (ctx->r1 == 0) {
        // 0x8039FFDC: subu        $t7, $t4, $v0
        ctx->r15 = SUB32(ctx->r12, ctx->r2);
            goto L_8039FFE4;
    }
    // 0x8039FFDC: subu        $t7, $t4, $v0
    ctx->r15 = SUB32(ctx->r12, ctx->r2);
    // 0x8039FFE0: sh          $t7, 0xE($s0)
    MEM_H(0XE, ctx->r16) = ctx->r15;
L_8039FFE4:
    // 0x8039FFE4: sll         $t9, $s2, 1
    ctx->r25 = S32(ctx->r18 << 1);
    // 0x8039FFE8: addu        $s0, $s3, $t9
    ctx->r16 = ADD32(ctx->r19, ctx->r25);
    // 0x8039FFEC: lh          $t8, 0xE($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XE);
    // 0x8039FFF0: lbu         $t6, 0xC($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0XC);
    // 0x8039FFF4: lh          $t9, 0x3E($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X3E);
    // 0x8039FFF8: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x8039FFFC: sh          $t7, 0xE($s0)
    MEM_H(0XE, ctx->r16) = ctx->r15;
    // 0x803A0000: lbu         $t8, 0xC($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0XC);
    // 0x803A0004: lh          $v0, 0xE($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XE);
    // 0x803A0008: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x803A000C: slti        $at, $v0, 0x80
    ctx->r1 = SIGNED(ctx->r2) < 0X80 ? 1 : 0;
    // 0x803A0010: bne         $at, $zero, L_803A0078
    if (ctx->r1 != 0) {
        // 0x803A0014: sh          $t6, 0x3E($s0)
        MEM_H(0X3E, ctx->r16) = ctx->r14;
            goto L_803A0078;
    }
    // 0x803A0014: sh          $t6, 0x3E($s0)
    MEM_H(0X3E, ctx->r16) = ctx->r14;
    // 0x803A0018: sh          $t4, 0xE($s0)
    MEM_H(0XE, ctx->r16) = ctx->r12;
    // 0x803A001C: lbu         $v0, 0x2($s3)
    ctx->r2 = MEM_BU(ctx->r19, 0X2);
    // 0x803A0020: bne         $s4, $v0, L_803A0070
    if (ctx->r20 != ctx->r2) {
        // 0x803A0024: addiu       $t7, $v0, 0x2
        ctx->r15 = ADD32(ctx->r2, 0X2);
            goto L_803A0070;
    }
    // 0x803A0024: addiu       $t7, $v0, 0x2
    ctx->r15 = ADD32(ctx->r2, 0X2);
    // 0x803A0028: lbu         $t8, 0x1($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X1);
    // 0x803A002C: andi        $t9, $t7, 0x1F
    ctx->r25 = ctx->r15 & 0X1F;
    // 0x803A0030: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x803A0034: bne         $t8, $t6, L_803A0070
    if (ctx->r24 != ctx->r14) {
        // 0x803A0038: sb          $t9, 0x2($s3)
        MEM_B(0X2, ctx->r19) = ctx->r25;
            goto L_803A0070;
    }
    // 0x803A0038: sb          $t9, 0x2($s3)
    MEM_B(0X2, ctx->r19) = ctx->r25;
    // 0x803A003C: lbu         $t7, 0x1($fp)
    ctx->r15 = MEM_BU(ctx->r30, 0X1);
    // 0x803A0040: lui         $v0, 0x8040
    ctx->r2 = S32(0X8040 << 16);
    // 0x803A0044: addiu       $v0, $v0, -0x2160
    ctx->r2 = ADD32(ctx->r2, -0X2160);
    // 0x803A0048: srl         $t9, $t7, 4
    ctx->r25 = S32(U32(ctx->r15) >> 4);
    // 0x803A004C: beq         $t9, $zero, L_803A0070
    if (ctx->r25 == 0) {
        // 0x803A0050: nop
    
            goto L_803A0070;
    }
    // 0x803A0050: nop

    // 0x803A0054: lh          $t8, 0x0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X0);
    // 0x803A0058: lbu         $t7, 0x0($fp)
    ctx->r15 = MEM_BU(ctx->r30, 0X0);
    // 0x803A005C: addiu       $t6, $t8, -0x1
    ctx->r14 = ADD32(ctx->r24, -0X1);
    // 0x803A0060: andi        $t9, $t7, 0xFF0F
    ctx->r25 = ctx->r15 & 0XFF0F;
    // 0x803A0064: sh          $t6, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r14;
    // 0x803A0068: b           L_803A029C
    // 0x803A006C: sb          $t9, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r25;
        goto L_803A029C;
    // 0x803A006C: sb          $t9, 0x0($fp)
    MEM_B(0X0, ctx->r30) = ctx->r25;
L_803A0070:
    // 0x803A0070: b           L_803A027C
    // 0x803A0074: lbu         $v1, 0x1($s3)
    ctx->r3 = MEM_BU(ctx->r19, 0X1);
        goto L_803A027C;
    // 0x803A0074: lbu         $v1, 0x1($s3)
    ctx->r3 = MEM_BU(ctx->r19, 0X1);
L_803A0078:
    // 0x803A0078: andi        $t6, $v0, 0xFF
    ctx->r14 = ctx->r2 & 0XFF;
    // 0x803A007C: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x803A0080: sll         $t8, $s4, 4
    ctx->r24 = S32(ctx->r20 << 4);
    // 0x803A0084: addu        $s1, $s3, $t8
    ctx->r17 = ADD32(ctx->r19, ctx->r24);
    // 0x803A0088: addu        $t9, $t2, $t7
    ctx->r25 = ADD32(ctx->r10, ctx->r15);
    // 0x803A008C: lh          $t8, 0x0($t9)
    ctx->r24 = MEM_H(ctx->r25, 0X0);
    // 0x803A0090: addu        $t7, $s3, $s2
    ctx->r15 = ADD32(ctx->r19, ctx->r18);
    // 0x803A0094: lbu         $t9, 0x2E($t7)
    ctx->r25 = MEM_BU(ctx->r15, 0X2E);
    // 0x803A0098: sra         $t6, $t8, 8
    ctx->r14 = S32(SIGNED(ctx->r24) >> 8);
    // 0x803A009C: multu       $t6, $t9
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A00A0: mflo        $t8
    ctx->r24 = lo;
    // 0x803A00A4: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x803A00A8: sb          $t6, 0x12F($s1)
    MEM_B(0X12F, ctx->r17) = ctx->r14;
    // 0x803A00AC: sb          $t6, 0x13F($s1)
    MEM_B(0X13F, ctx->r17) = ctx->r14;
    // 0x803A00B0: lh          $t9, 0x3E($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X3E);
    // 0x803A00B4: lbu         $v1, 0x5($s3)
    ctx->r3 = MEM_BU(ctx->r19, 0X5);
    // 0x803A00B8: lh          $t0, 0xBE($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XBE);
    // 0x803A00BC: lh          $a2, 0x324($s3)
    ctx->r6 = MEM_H(ctx->r19, 0X324);
    // 0x803A00C0: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A00C4: lh          $a1, 0x322($s3)
    ctx->r5 = MEM_H(ctx->r19, 0X322);
    // 0x803A00C8: mflo        $t8
    ctx->r24 = lo;
    // 0x803A00CC: sra         $t7, $t8, 5
    ctx->r15 = S32(SIGNED(ctx->r24) >> 5);
    // 0x803A00D0: addu        $a3, $t7, $v1
    ctx->r7 = ADD32(ctx->r15, ctx->r3);
    // 0x803A00D4: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x803A00D8: sll         $t6, $a3, 16
    ctx->r14 = S32(ctx->r7 << 16);
    // 0x803A00DC: addiu       $t7, $t7, 0x2350
    ctx->r15 = ADD32(ctx->r15, 0X2350);
    // 0x803A00E0: sll         $t8, $t0, 1
    ctx->r24 = S32(ctx->r8 << 1);
    // 0x803A00E4: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803A00E8: addu        $a0, $t8, $t7
    ctx->r4 = ADD32(ctx->r24, ctx->r15);
    // 0x803A00EC: lh          $t6, 0x384($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X384);
    // 0x803A00F0: multu       $t6, $a3
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A00F4: lh          $t6, 0x2D0($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2D0);
    // 0x803A00F8: lh          $a0, 0x320($s3)
    ctx->r4 = MEM_H(ctx->r19, 0X320);
    // 0x803A00FC: sb          $t5, 0x135($sp)
    MEM_B(0X135, ctx->r29) = ctx->r13;
    // 0x803A0100: sb          $t1, 0x14F($sp)
    MEM_B(0X14F, ctx->r29) = ctx->r9;
    // 0x803A0104: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x803A0108: mflo        $s5
    ctx->r21 = lo;
    // 0x803A010C: sra         $t9, $s5, 8
    ctx->r25 = S32(SIGNED(ctx->r21) >> 8);
    // 0x803A0110: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x803A0114: negu        $t9, $t6
    ctx->r25 = SUB32(0, ctx->r14);
    // 0x803A0118: multu       $t9, $a3
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A011C: sra         $s5, $t8, 16
    ctx->r21 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803A0120: addiu       $t9, $sp, 0x17C
    ctx->r25 = ADD32(ctx->r29, 0X17C);
    // 0x803A0124: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x803A0128: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x803A012C: mflo        $s6
    ctx->r22 = lo;
    // 0x803A0130: sra         $t8, $s6, 8
    ctx->r24 = S32(SIGNED(ctx->r22) >> 8);
    // 0x803A0134: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x803A0138: jal         0x802F5F44
    // 0x803A013C: sra         $s6, $t7, 16
    ctx->r22 = S32(SIGNED(ctx->r15) >> 16);
    func_802F5F44_7075F4(rdram, ctx);
        goto after_9;
    // 0x803A013C: sra         $s6, $t7, 16
    ctx->r22 = S32(SIGNED(ctx->r15) >> 16);
    after_9:
    // 0x803A0140: lh          $t8, 0x3E($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X3E);
    // 0x803A0144: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x803A0148: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x803A014C: andi        $t7, $t8, 0xFF
    ctx->r15 = ctx->r24 & 0XFF;
    // 0x803A0150: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x803A0154: addu        $t9, $t2, $t6
    ctx->r25 = ADD32(ctx->r10, ctx->r14);
    // 0x803A0158: sll         $t8, $s2, 2
    ctx->r24 = S32(ctx->r18 << 2);
    // 0x803A015C: addu        $v0, $s3, $t8
    ctx->r2 = ADD32(ctx->r19, ctx->r24);
    // 0x803A0160: lh          $v1, 0x0($t9)
    ctx->r3 = MEM_H(ctx->r25, 0X0);
    // 0x803A0164: lh          $t6, 0xDE($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XDE);
    // 0x803A0168: lh          $t7, 0x17C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X17C);
    // 0x803A016C: lbu         $t1, 0x14F($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X14F);
    // 0x803A0170: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A0174: lbu         $t5, 0x135($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X135);
    // 0x803A0178: addiu       $t3, $zero, 0x7FF
    ctx->r11 = ADD32(0, 0X7FF);
    // 0x803A017C: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x803A0180: lui         $ra, 0xB100
    ctx->r31 = S32(0XB100 << 16);
    // 0x803A0184: mflo        $t9
    ctx->r25 = lo;
    // 0x803A0188: sra         $t8, $t9, 17
    ctx->r24 = S32(SIGNED(ctx->r25) >> 17);
    // 0x803A018C: addu        $t6, $t7, $t8
    ctx->r14 = ADD32(ctx->r15, ctx->r24);
    // 0x803A0190: sh          $t6, 0x17C($sp)
    MEM_H(0X17C, ctx->r29) = ctx->r14;
    // 0x803A0194: lh          $t7, 0xE0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XE0);
    // 0x803A0198: lh          $t9, 0x17E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X17E);
    // 0x803A019C: multu       $t7, $v1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A01A0: mflo        $t8
    ctx->r24 = lo;
    // 0x803A01A4: sra         $t7, $t8, 17
    ctx->r15 = S32(SIGNED(ctx->r24) >> 17);
    // 0x803A01A8: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x803A01AC: sh          $t8, 0x17E($sp)
    MEM_H(0X17E, ctx->r29) = ctx->r24;
    // 0x803A01B0: lh          $t7, 0x3E($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X3E);
    // 0x803A01B4: lh          $t9, 0xDE($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XDE);
    // 0x803A01B8: multu       $t9, $t7
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A01BC: mflo        $t9
    ctx->r25 = lo;
    // 0x803A01C0: sra         $t7, $t9, 8
    ctx->r15 = S32(SIGNED(ctx->r25) >> 8);
    // 0x803A01C4: or          $t9, $t6, $zero
    ctx->r25 = ctx->r14 | 0;
    // 0x803A01C8: or          $t6, $t9, $zero
    ctx->r14 = ctx->r25 | 0;
    // 0x803A01CC: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x803A01D0: sh          $t9, 0x17C($sp)
    MEM_H(0X17C, ctx->r29) = ctx->r25;
    // 0x803A01D4: lh          $t7, 0x3E($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X3E);
    // 0x803A01D8: lh          $t6, 0xE0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XE0);
    // 0x803A01DC: multu       $t6, $t7
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803A01E0: mflo        $t6
    ctx->r14 = lo;
    // 0x803A01E4: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x803A01E8: or          $t6, $t8, $zero
    ctx->r14 = ctx->r24 | 0;
    // 0x803A01EC: or          $t8, $t6, $zero
    ctx->r24 = ctx->r14 | 0;
    // 0x803A01F0: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x803A01F4: sll         $t8, $s2, 2
    ctx->r24 = S32(ctx->r18 << 2);
    // 0x803A01F8: subu        $t8, $t8, $s2
    ctx->r24 = SUB32(ctx->r24, ctx->r18);
    // 0x803A01FC: sll         $t8, $t8, 1
    ctx->r24 = S32(ctx->r24 << 1);
    // 0x803A0200: sh          $t6, 0x17E($sp)
    MEM_H(0X17E, ctx->r29) = ctx->r14;
    // 0x803A0204: addu        $v0, $s3, $t8
    ctx->r2 = ADD32(ctx->r19, ctx->r24);
    // 0x803A0208: lh          $t7, 0x5E($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X5E);
    // 0x803A020C: addu        $t6, $t7, $s5
    ctx->r14 = ADD32(ctx->r15, ctx->r21);
    // 0x803A0210: or          $t7, $t9, $zero
    ctx->r15 = ctx->r25 | 0;
    // 0x803A0214: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x803A0218: sh          $t9, 0x120($s1)
    MEM_H(0X120, ctx->r17) = ctx->r25;
    // 0x803A021C: lh          $t8, 0x60($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X60);
    // 0x803A0220: lh          $t7, 0x17E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X17E);
    // 0x803A0224: addu        $t6, $t8, $s6
    ctx->r14 = ADD32(ctx->r24, ctx->r22);
    // 0x803A0228: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x803A022C: sh          $t9, 0x122($s1)
    MEM_H(0X122, ctx->r17) = ctx->r25;
    // 0x803A0230: lh          $t6, 0x180($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X180);
    // 0x803A0234: lh          $t8, 0x62($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X62);
    // 0x803A0238: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x803A023C: sh          $t7, 0x124($s1)
    MEM_H(0X124, ctx->r17) = ctx->r15;
    // 0x803A0240: lh          $t9, 0x5E($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X5E);
    // 0x803A0244: lh          $t6, 0x17C($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X17C);
    // 0x803A0248: subu        $t8, $t9, $s5
    ctx->r24 = SUB32(ctx->r25, ctx->r21);
    // 0x803A024C: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x803A0250: sh          $t7, 0x130($s1)
    MEM_H(0X130, ctx->r17) = ctx->r15;
    // 0x803A0254: lh          $t9, 0x60($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X60);
    // 0x803A0258: lh          $t6, 0x17E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X17E);
    // 0x803A025C: subu        $t8, $t9, $s6
    ctx->r24 = SUB32(ctx->r25, ctx->r22);
    // 0x803A0260: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x803A0264: sh          $t7, 0x132($s1)
    MEM_H(0X132, ctx->r17) = ctx->r15;
    // 0x803A0268: lh          $t8, 0x180($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X180);
    // 0x803A026C: lh          $t9, 0x62($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X62);
    // 0x803A0270: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x803A0274: sh          $t6, 0x134($s1)
    MEM_H(0X134, ctx->r17) = ctx->r14;
    // 0x803A0278: lbu         $v1, 0x1($s3)
    ctx->r3 = MEM_BU(ctx->r19, 0X1);
L_803A027C:
    // 0x803A027C: bnel        $s4, $v1, L_803A028C
    if (ctx->r20 != ctx->r3) {
        // 0x803A0280: addiu       $s4, $s4, 0x2
        ctx->r20 = ADD32(ctx->r20, 0X2);
            goto L_803A028C;
    }
    goto skip_24;
    // 0x803A0280: addiu       $s4, $s4, 0x2
    ctx->r20 = ADD32(ctx->r20, 0X2);
    skip_24:
    // 0x803A0284: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x803A0288: addiu       $s4, $s4, 0x2
    ctx->r20 = ADD32(ctx->r20, 0X2);
L_803A028C:
    // 0x803A028C: andi        $t7, $s4, 0x1F
    ctx->r15 = ctx->r20 & 0X1F;
    // 0x803A0290: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x803A0294: beq         $t1, $zero, L_8039FFBC
    if (ctx->r9 == 0) {
        // 0x803A0298: sra         $s4, $t9, 16
        ctx->r20 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8039FFBC;
    }
    // 0x803A0298: sra         $s4, $t9, 16
    ctx->r20 = S32(SIGNED(ctx->r25) >> 16);
L_803A029C:
    // 0x803A029C: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A02A0: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x803A02A4: ori         $t7, $t7, 0x81FF
    ctx->r15 = ctx->r15 | 0X81FF;
    // 0x803A02A8: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x803A02AC: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x803A02B0: addiu       $t9, $s3, 0x120
    ctx->r25 = ADD32(ctx->r19, 0X120);
    // 0x803A02B4: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x803A02B8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x803A02BC: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x803A02C0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A02C4: lui         $t7, 0x5532
    ctx->r15 = S32(0X5532 << 16);
    // 0x803A02C8: lui         $t6, 0xFC30
    ctx->r14 = S32(0XFC30 << 16);
    // 0x803A02CC: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803A02D0: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x803A02D4: ori         $t6, $t6, 0x9861
    ctx->r14 = ctx->r14 | 0X9861;
    // 0x803A02D8: ori         $t7, $t7, 0xFF7F
    ctx->r15 = ctx->r15 | 0XFF7F;
    // 0x803A02DC: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x803A02E0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803A02E4: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x803A02E8: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A02EC: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x803A02F0: ori         $t8, $t8, 0x2
    ctx->r24 = ctx->r24 | 0X2;
    // 0x803A02F4: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x803A02F8: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x803A02FC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x803A0300: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x803A0304: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803A0308: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A030C: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x803A0310: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x803A0314: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x803A0318: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x803A031C: lbu         $t8, 0x8($s3)
    ctx->r24 = MEM_BU(ctx->r19, 0X8);
    // 0x803A0320: lbu         $t9, 0x6($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X6);
    // 0x803A0324: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x803A0328: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x803A032C: sll         $t8, $t9, 24
    ctx->r24 = S32(ctx->r25 << 24);
    // 0x803A0330: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x803A0334: lbu         $t6, 0x7($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X7);
    // 0x803A0338: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x803A033C: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x803A0340: ori         $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 | 0XFF;
    // 0x803A0344: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x803A0348: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A034C: lui         $t8, 0xFB00
    ctx->r24 = S32(0XFB00 << 16);
    // 0x803A0350: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x803A0354: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x803A0358: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x803A035C: lbu         $t6, 0xB($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0XB);
    // 0x803A0360: lbu         $t9, 0x9($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X9);
    // 0x803A0364: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x803A0368: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x803A036C: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x803A0370: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x803A0374: lbu         $t7, 0xA($s3)
    ctx->r15 = MEM_BU(ctx->r19, 0XA);
    // 0x803A0378: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x803A037C: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x803A0380: ori         $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 | 0XFF;
    // 0x803A0384: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x803A0388: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A038C: lui         $t6, 0xF580
    ctx->r14 = S32(0XF580 << 16);
    // 0x803A0390: ori         $t6, $t6, 0x420
    ctx->r14 = ctx->r14 | 0X420;
    // 0x803A0394: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803A0398: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x803A039C: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x803A03A0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803A03A4: lbu         $t9, 0x1($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0X1);
    // 0x803A03A8: lbu         $s1, 0x2($s3)
    ctx->r17 = MEM_BU(ctx->r19, 0X2);
    // 0x803A03AC: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x803A03B0: beql        $s1, $t9, L_803A0444
    if (ctx->r17 == ctx->r25) {
        // 0x803A03B4: lbu         $t6, 0x3($s3)
        ctx->r14 = MEM_BU(ctx->r19, 0X3);
            goto L_803A0444;
    }
    goto skip_25;
    // 0x803A03B4: lbu         $t6, 0x3($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X3);
    skip_25:
    // 0x803A03B8: lw          $a3, 0x148($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X148);
L_803A03BC:
    // 0x803A03BC: addiu       $a2, $s1, 0x3
    ctx->r6 = ADD32(ctx->r17, 0X3);
    // 0x803A03C0: lw          $s0, 0x0($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X0);
    // 0x803A03C4: andi        $t6, $a2, 0x1F
    ctx->r14 = ctx->r6 & 0X1F;
    // 0x803A03C8: sll         $v0, $s1, 1
    ctx->r2 = S32(ctx->r17 << 1);
    // 0x803A03CC: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    // 0x803A03D0: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x803A03D4: andi        $a2, $t9, 0xFF
    ctx->r6 = ctx->r25 & 0XFF;
    // 0x803A03D8: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x803A03DC: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x803A03E0: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x803A03E4: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x803A03E8: sll         $t8, $a2, 8
    ctx->r24 = S32(ctx->r6 << 8);
    // 0x803A03EC: addiu       $t9, $v0, 0x2
    ctx->r25 = ADD32(ctx->r2, 0X2);
    // 0x803A03F0: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x803A03F4: or          $t6, $v1, $t8
    ctx->r14 = ctx->r3 | ctx->r24;
    // 0x803A03F8: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x803A03FC: addiu       $a0, $s1, 0x2
    ctx->r4 = ADD32(ctx->r17, 0X2);
    // 0x803A0400: andi        $t6, $a0, 0x1F
    ctx->r14 = ctx->r4 & 0X1F;
    // 0x803A0404: or          $t9, $t8, $ra
    ctx->r25 = ctx->r24 | ctx->r31;
    // 0x803A0408: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x803A040C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x803A0410: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803A0414: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x803A0418: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x803A041C: or          $t6, $v1, $t9
    ctx->r14 = ctx->r3 | ctx->r25;
    // 0x803A0420: or          $t7, $t6, $a2
    ctx->r15 = ctx->r14 | ctx->r6;
    // 0x803A0424: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x803A0428: lbu         $t9, 0x1($a3)
    ctx->r25 = MEM_BU(ctx->r7, 0X1);
    // 0x803A042C: sll         $s1, $a0, 16
    ctx->r17 = S32(ctx->r4 << 16);
    // 0x803A0430: sra         $t8, $s1, 16
    ctx->r24 = S32(SIGNED(ctx->r17) >> 16);
    // 0x803A0434: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x803A0438: bne         $t8, $t9, L_803A03BC
    if (ctx->r24 != ctx->r25) {
        // 0x803A043C: or          $a1, $s0, $zero
        ctx->r5 = ctx->r16 | 0;
            goto L_803A03BC;
    }
    // 0x803A043C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x803A0440: lbu         $t6, 0x3($s3)
    ctx->r14 = MEM_BU(ctx->r19, 0X3);
L_803A0444:
    // 0x803A0444: lbu         $t9, 0xD($s3)
    ctx->r25 = MEM_BU(ctx->r19, 0XD);
    // 0x803A0448: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x803A044C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x803A0450: div         $zero, $t8, $t9
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r25))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r25)));
    // 0x803A0454: mfhi        $t6
    ctx->r14 = hi;
    // 0x803A0458: sb          $t7, 0x3($s3)
    MEM_B(0X3, ctx->r19) = ctx->r15;
    // 0x803A045C: sb          $t6, 0x3($s3)
    MEM_B(0X3, ctx->r19) = ctx->r14;
    // 0x803A0460: bne         $t9, $zero, L_803A046C
    if (ctx->r25 != 0) {
        // 0x803A0464: nop
    
            goto L_803A046C;
    }
    // 0x803A0464: nop

    // 0x803A0468: break       7
    do_break(2151285864);
L_803A046C:
    // 0x803A046C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803A0470: bne         $t9, $at, L_803A0484
    if (ctx->r25 != ctx->r1) {
        // 0x803A0474: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803A0484;
    }
    // 0x803A0474: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803A0478: bne         $t8, $at, L_803A0484
    if (ctx->r24 != ctx->r1) {
        // 0x803A047C: nop
    
            goto L_803A0484;
    }
    // 0x803A047C: nop

    // 0x803A0480: break       6
    do_break(2151285888);
L_803A0484:
    // 0x803A0484: lh          $t7, 0x19E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X19E);
L_803A0488:
    // 0x803A0488: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x803A048C: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x803A0490: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803A0494: slti        $at, $t6, 0x1E
    ctx->r1 = SIGNED(ctx->r14) < 0X1E ? 1 : 0;
    // 0x803A0498: bne         $at, $zero, L_8039EE1C
    if (ctx->r1 != 0) {
        // 0x803A049C: sh          $t8, 0x19E($sp)
        MEM_H(0X19E, ctx->r29) = ctx->r24;
            goto L_8039EE1C;
    }
    // 0x803A049C: sh          $t8, 0x19E($sp)
    MEM_H(0X19E, ctx->r29) = ctx->r24;
    // 0x803A04A0: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_803A04A4:
    // 0x803A04A4: ldc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
    // 0x803A04A8: ldc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X28);
    // 0x803A04AC: ldc1        $f24, 0x30($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X30);
    // 0x803A04B0: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x803A04B4: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x803A04B8: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x803A04BC: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x803A04C0: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x803A04C4: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x803A04C8: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x803A04CC: lw          $s7, 0x54($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X54);
    // 0x803A04D0: lw          $fp, 0x58($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X58);
    // 0x803A04D4: jr          $ra
    // 0x803A04D8: addiu       $sp, $sp, 0x1A0
    ctx->r29 = ADD32(ctx->r29, 0X1A0);
    return;
    // 0x803A04D8: addiu       $sp, $sp, 0x1A0
    ctx->r29 = ADD32(ctx->r29, 0X1A0);
    // 0x803A04DC: nop

;}
RECOMP_FUNC void static_0_80138604(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138604: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80138608: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8013860C: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    // 0x80138610: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80138614: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80138618: andi        $t7, $t6, 0x3
    ctx->r15 = ctx->r14 & 0X3;
    // 0x8013861C: bne         $t7, $zero, L_80138684
    if (ctx->r15 != 0) {
        // 0x80138620: nop
    
            goto L_80138684;
    }
    // 0x80138620: nop

    // 0x80138624: lw          $a0, 0x50($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X50);
    // 0x80138628: jal         0x80139050
    // 0x8013862C: lw          $a1, 0x54($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X54);
    osSendMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x8013862C: lw          $a1, 0x54($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X54);
    after_0:
    // 0x80138630: lw          $t8, 0x10($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X10);
    // 0x80138634: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80138638: bne         $t8, $at, L_8013867C
    if (ctx->r24 != ctx->r1) {
        // 0x8013863C: nop
    
            goto L_8013867C;
    }
    // 0x8013863C: nop

    // 0x80138640: lw          $v0, 0x8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X8);
    // 0x80138644: andi        $t9, $v0, 0x40
    ctx->r25 = ctx->r2 & 0X40;
    // 0x80138648: beq         $t9, $zero, L_8013867C
    if (ctx->r25 == 0) {
        // 0x8013864C: andi        $t6, $v0, 0x20
        ctx->r14 = ctx->r2 & 0X20;
            goto L_8013867C;
    }
    // 0x8013864C: andi        $t6, $v0, 0x20
    ctx->r14 = ctx->r2 & 0X20;
    // 0x80138650: beq         $t6, $zero, L_8013867C
    if (ctx->r14 == 0) {
        // 0x80138654: lui         $t7, 0x8016
        ctx->r15 = S32(0X8016 << 16);
            goto L_8013867C;
    }
    // 0x80138654: lui         $t7, 0x8016
    ctx->r15 = S32(0X8016 << 16);
    // 0x80138658: lw          $t7, -0x6688($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X6688);
    // 0x8013865C: beq         $t7, $zero, L_80138674
    if (ctx->r15 == 0) {
        // 0x80138660: nop
    
            goto L_80138674;
    }
    // 0x80138660: nop

    // 0x80138664: jal         0x80139390
    // 0x80138668: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    osViBlack_recomp(rdram, ctx);
        goto after_1;
    // 0x80138668: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_1:
    // 0x8013866C: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80138670: sw          $zero, -0x6688($at)
    MEM_W(-0X6688, ctx->r1) = 0;
L_80138674:
    // 0x80138674: jal         0x80142490
    // 0x80138678: lw          $a0, 0xC($s0)
    ctx->r4 = MEM_W(ctx->r16, 0XC);
    osViSwapBuffer_recomp(rdram, ctx);
        goto after_2;
    // 0x80138678: lw          $a0, 0xC($s0)
    ctx->r4 = MEM_W(ctx->r16, 0XC);
    after_2:
L_8013867C:
    // 0x8013867C: b           L_80138684
    // 0x80138680: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80138684;
    // 0x80138680: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80138684:
    // 0x80138684: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80138688: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8013868C: jr          $ra
    // 0x80138690: nop

    return;
    // 0x80138690: nop

    // 0x80138694: jr          $ra
    // 0x80138698: nop

    return;
    // 0x80138698: nop

    // 0x8013869C: jr          $ra
    // 0x801386A0: nop

    return;
    // 0x801386A0: nop

    // 0x801386A4: jr          $ra
    // 0x801386A8: nop

    return;
    // 0x801386A8: nop

    // 0x801386AC: jr          $ra
    // 0x801386B0: nop

    return;
    // 0x801386B0: nop

;}
RECOMP_FUNC void static_0_801386B4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801386B4: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x801386B8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801386BC: sw          $zero, 0x34($sp)
    MEM_W(0X34, ctx->r29) = 0;
    // 0x801386C0: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x801386C4: lw          $t6, 0x27C($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X27C);
    // 0x801386C8: addiu       $s5, $sp, 0x44
    ctx->r21 = ADD32(ctx->r29, 0X44);
    // 0x801386CC: addiu       $s3, $s4, 0x78
    ctx->r19 = ADD32(ctx->r20, 0X78);
    // 0x801386D0: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x801386D4: sw          $t7, 0x27C($s4)
    MEM_W(0X27C, ctx->r20) = ctx->r15;
    // 0x801386D8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x801386DC: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x801386E0: jal         0x80137FF0
    // 0x801386E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x801386E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_0:
    // 0x801386E8: addiu       $s0, $zero, -0x1
    ctx->r16 = ADD32(0, -0X1);
    // 0x801386EC: beql        $v0, $s0, L_8013877C
    if (ctx->r2 == ctx->r16) {
        // 0x801386F0: lw          $t7, 0x280($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X280);
            goto L_8013877C;
    }
    goto skip_0;
    // 0x801386F0: lw          $t7, 0x280($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X280);
    skip_0:
    // 0x801386F4: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x801386F8: addiu       $s1, $zero, 0x2
    ctx->r17 = ADD32(0, 0X2);
    // 0x801386FC: lw          $t8, 0x44($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X44);
L_80138700:
    // 0x80138700: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80138704: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x80138708: lw          $v1, 0x10($t8)
    ctx->r3 = MEM_W(ctx->r24, 0X10);
    // 0x8013870C: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x80138710: bnel        $v1, $s1, L_80138740
    if (ctx->r3 != ctx->r17) {
        // 0x80138714: lw          $v1, 0x270($s4)
        ctx->r3 = MEM_W(ctx->r20, 0X270);
            goto L_80138740;
    }
    goto skip_1;
    // 0x80138714: lw          $v1, 0x270($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X270);
    skip_1:
    // 0x80138718: lw          $v1, 0x26C($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X26C);
    // 0x8013871C: beql        $v1, $zero, L_80138730
    if (ctx->r3 == 0) {
        // 0x80138720: sw          $v0, 0x264($s4)
        MEM_W(0X264, ctx->r20) = ctx->r2;
            goto L_80138730;
    }
    goto skip_2;
    // 0x80138720: sw          $v0, 0x264($s4)
    MEM_W(0X264, ctx->r20) = ctx->r2;
    skip_2:
    // 0x80138724: b           L_80138730
    // 0x80138728: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
        goto L_80138730;
    // 0x80138728: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8013872C: sw          $v0, 0x264($s4)
    MEM_W(0X264, ctx->r20) = ctx->r2;
L_80138730:
    // 0x80138730: sw          $v0, 0x26C($s4)
    MEM_W(0X26C, ctx->r20) = ctx->r2;
    // 0x80138734: b           L_80138758
    // 0x80138738: sw          $s2, 0x280($s4)
    MEM_W(0X280, ctx->r20) = ctx->r18;
        goto L_80138758;
    // 0x80138738: sw          $s2, 0x280($s4)
    MEM_W(0X280, ctx->r20) = ctx->r18;
    // 0x8013873C: lw          $v1, 0x270($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X270);
L_80138740:
    // 0x80138740: beql        $v1, $zero, L_80138754
    if (ctx->r3 == 0) {
        // 0x80138744: sw          $v0, 0x268($s4)
        MEM_W(0X268, ctx->r20) = ctx->r2;
            goto L_80138754;
    }
    goto skip_3;
    // 0x80138744: sw          $v0, 0x268($s4)
    MEM_W(0X268, ctx->r20) = ctx->r2;
    skip_3:
    // 0x80138748: b           L_80138754
    // 0x8013874C: sw          $v0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r2;
        goto L_80138754;
    // 0x8013874C: sw          $v0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r2;
    // 0x80138750: sw          $v0, 0x268($s4)
    MEM_W(0X268, ctx->r20) = ctx->r2;
L_80138754:
    // 0x80138754: sw          $v0, 0x270($s4)
    MEM_W(0X270, ctx->r20) = ctx->r2;
L_80138758:
    // 0x80138758: lw          $t9, 0x8($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X8);
    // 0x8013875C: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80138760: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80138764: andi        $t6, $t9, 0x3
    ctx->r14 = ctx->r25 & 0X3;
    // 0x80138768: jal         0x80137FF0
    // 0x8013876C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    osRecvMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x8013876C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    after_1:
    // 0x80138770: bnel        $v0, $s0, L_80138700
    if (ctx->r2 != ctx->r16) {
        // 0x80138774: lw          $t8, 0x44($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X44);
            goto L_80138700;
    }
    goto skip_4;
    // 0x80138774: lw          $t8, 0x44($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X44);
    skip_4:
    // 0x80138778: lw          $t7, 0x280($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X280);
L_8013877C:
    // 0x8013877C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x80138780: addiu       $a1, $sp, 0x34
    ctx->r5 = ADD32(ctx->r29, 0X34);
    // 0x80138784: beql        $t7, $zero, L_801387C4
    if (ctx->r15 == 0) {
        // 0x80138788: lw          $t7, 0x274($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X274);
            goto L_801387C4;
    }
    goto skip_5;
    // 0x80138788: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
    skip_5:
    // 0x8013878C: lw          $v0, 0x274($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X274);
    // 0x80138790: beql        $v0, $zero, L_801387C4
    if (ctx->r2 == 0) {
        // 0x80138794: lw          $t7, 0x274($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X274);
            goto L_801387C4;
    }
    goto skip_6;
    // 0x80138794: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
    skip_6:
    // 0x80138798: lw          $t8, 0x10($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X10);
    // 0x8013879C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801387A0: bnel        $t8, $at, L_80138800
    if (ctx->r24 != ctx->r1) {
        // 0x801387A4: lw          $s0, 0x260($s4)
        ctx->r16 = MEM_W(ctx->r20, 0X260);
            goto L_80138800;
    }
    goto skip_7;
    // 0x801387A4: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    skip_7:
    // 0x801387A8: lw          $t9, 0x4($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X4);
    // 0x801387AC: ori         $t6, $t9, 0x10
    ctx->r14 = ctx->r25 | 0X10;
    // 0x801387B0: jal         0x80142880
    // 0x801387B4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    osSpTaskYield_recomp(rdram, ctx);
        goto after_2;
    // 0x801387B4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    after_2:
    // 0x801387B8: b           L_80138800
    // 0x801387BC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
        goto L_80138800;
    // 0x801387BC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    // 0x801387C0: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
L_801387C4:
    // 0x801387C4: lw          $t6, 0x278($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X278);
    // 0x801387C8: addiu       $a2, $sp, 0x30
    ctx->r6 = ADD32(ctx->r29, 0X30);
    // 0x801387CC: sltiu       $t8, $t7, 0x1
    ctx->r24 = ctx->r15 < 0X1 ? 1 : 0;
    // 0x801387D0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x801387D4: sltiu       $t7, $t6, 0x1
    ctx->r15 = ctx->r14 < 0X1 ? 1 : 0;
    // 0x801387D8: or          $s0, $t9, $t7
    ctx->r16 = ctx->r25 | ctx->r15;
    // 0x801387DC: jal         0x80138420
    // 0x801387E0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    __scSchedule(rdram, ctx);
        goto after_3;
    // 0x801387E0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    after_3:
    // 0x801387E4: beql        $v0, $s0, L_80138800
    if (ctx->r2 == ctx->r16) {
        // 0x801387E8: lw          $s0, 0x260($s4)
        ctx->r16 = MEM_W(ctx->r20, 0X260);
            goto L_80138800;
    }
    goto skip_8;
    // 0x801387E8: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    skip_8:
    // 0x801387EC: or          $s3, $s4, $zero
    ctx->r19 = ctx->r20 | 0;
    // 0x801387F0: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x801387F4: jal         0x80138380
    // 0x801387F8: lw          $s1, 0x30($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X30);
    __scExec(rdram, ctx);
        goto after_4;
    // 0x801387F8: lw          $s1, 0x30($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X30);
    after_4:
    // 0x801387FC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
L_80138800:
    // 0x80138800: beql        $s0, $zero, L_80138828
    if (ctx->r16 == 0) {
        // 0x80138804: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80138828;
    }
    goto skip_9;
    // 0x80138804: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x80138808: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
L_8013880C:
    // 0x8013880C: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x80138810: jal         0x80139050
    // 0x80138814: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_5;
    // 0x80138814: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_5:
    // 0x80138818: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    // 0x8013881C: bnel        $s0, $zero, L_8013880C
    if (ctx->r16 != 0) {
        // 0x80138820: lw          $a0, 0x4($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X4);
            goto L_8013880C;
    }
    goto skip_10;
    // 0x80138820: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
    skip_10:
    // 0x80138824: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80138828:
    // 0x80138828: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x8013882C: jr          $ra
    // 0x80138830: nop

    return;
    // 0x80138830: nop

;}
RECOMP_FUNC void static_0_80142B50(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80142B50: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80142B54: sw          $a1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r5;
    // 0x80142B58: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80142B5C: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x80142B60: slti        $at, $t6, 0x26
    ctx->r1 = SIGNED(ctx->r14) < 0X26 ? 1 : 0;
    // 0x80142B64: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80142B68: sw          $zero, 0xC($s0)
    MEM_W(0XC, ctx->r16) = 0;
    // 0x80142B6C: sw          $zero, 0x10($s0)
    MEM_W(0X10, ctx->r16) = 0;
    // 0x80142B70: sw          $zero, 0x14($s0)
    MEM_W(0X14, ctx->r16) = 0;
    // 0x80142B74: sw          $zero, 0x18($s0)
    MEM_W(0X18, ctx->r16) = 0;
    // 0x80142B78: sw          $zero, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = 0;
    // 0x80142B7C: sw          $zero, 0x20($s0)
    MEM_W(0X20, ctx->r16) = 0;
    // 0x80142B80: bne         $at, $zero, L_80142BAC
    if (ctx->r1 != 0) {
        // 0x80142B84: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_80142BAC;
    }
    // 0x80142B84: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x80142B88: addiu       $t7, $t6, -0x45
    ctx->r15 = ADD32(ctx->r14, -0X45);
    // 0x80142B8C: sltiu       $at, $t7, 0x34
    ctx->r1 = ctx->r15 < 0X34 ? 1 : 0;
    // 0x80142B90: beq         $at, $zero, L_80143198
    if (ctx->r1 == 0) {
        // 0x80142B94: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_80143198;
    }
    // 0x80142B94: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80142B98: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80142B9C: addu        $at, $at, $t7
    gpr jr_addend_80142BA4 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80142BA0: lw          $t7, -0x4ADC($at)
    ctx->r15 = ADD32(ctx->r1, -0X4ADC);
    // 0x80142BA4: jr          $t7
    // 0x80142BA8: nop

    switch (jr_addend_80142BA4 >> 2) {
        case 0: goto L_80142EB8; break;
        case 1: goto L_80143198; break;
        case 2: goto L_80142EB8; break;
        case 3: goto L_80143198; break;
        case 4: goto L_80143198; break;
        case 5: goto L_80143198; break;
        case 6: goto L_80143198; break;
        case 7: goto L_80143198; break;
        case 8: goto L_80143198; break;
        case 9: goto L_80143198; break;
        case 10: goto L_80143198; break;
        case 11: goto L_80143198; break;
        case 12: goto L_80143198; break;
        case 13: goto L_80143198; break;
        case 14: goto L_80143198; break;
        case 15: goto L_80143198; break;
        case 16: goto L_80143198; break;
        case 17: goto L_80143198; break;
        case 18: goto L_80143198; break;
        case 19: goto L_80142D68; break;
        case 20: goto L_80143198; break;
        case 21: goto L_80143198; break;
        case 22: goto L_80143198; break;
        case 23: goto L_80143198; break;
        case 24: goto L_80143198; break;
        case 25: goto L_80143198; break;
        case 26: goto L_80143198; break;
        case 27: goto L_80143198; break;
        case 28: goto L_80143198; break;
        case 29: goto L_80143198; break;
        case 30: goto L_80142BC0; break;
        case 31: goto L_80142BF8; break;
        case 32: goto L_80142EB8; break;
        case 33: goto L_80142EB8; break;
        case 34: goto L_80142EB8; break;
        case 35: goto L_80143198; break;
        case 36: goto L_80142BF8; break;
        case 37: goto L_80143198; break;
        case 38: goto L_80143198; break;
        case 39: goto L_80143198; break;
        case 40: goto L_80143198; break;
        case 41: goto L_8014301C; break;
        case 42: goto L_80142D68; break;
        case 43: goto L_801430EC; break;
        case 44: goto L_80143198; break;
        case 45: goto L_80143198; break;
        case 46: goto L_80143134; break;
        case 47: goto L_80143198; break;
        case 48: goto L_80142D68; break;
        case 49: goto L_80143198; break;
        case 50: goto L_80143198; break;
        case 51: goto L_80142D68; break;
        default: switch_error(__func__, 0x80142BA4, 0x8015B524);
    }
    // 0x80142BA8: nop

L_80142BAC:
    // 0x80142BAC: addiu       $at, $zero, 0x25
    ctx->r1 = ADD32(0, 0X25);
    // 0x80142BB0: beql        $v1, $at, L_8014317C
    if (ctx->r3 == ctx->r1) {
        // 0x80142BB4: lw          $t8, 0xC($s0)
        ctx->r24 = MEM_W(ctx->r16, 0XC);
            goto L_8014317C;
    }
    goto skip_0;
    // 0x80142BB4: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    skip_0:
    // 0x80142BB8: b           L_8014319C
    // 0x80142BBC: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
        goto L_8014319C;
    // 0x80142BBC: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
L_80142BC0:
    // 0x80142BC0: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x80142BC4: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80142BC8: addiu       $t9, $t8, 0x3
    ctx->r25 = ADD32(ctx->r24, 0X3);
    // 0x80142BCC: and         $t6, $t9, $at
    ctx->r14 = ctx->r25 & ctx->r1;
    // 0x80142BD0: addiu       $t7, $t6, 0x4
    ctx->r15 = ADD32(ctx->r14, 0X4);
    // 0x80142BD4: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80142BD8: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142BDC: lw          $t9, -0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, -0X4);
    // 0x80142BE0: addu        $t7, $a3, $t6
    ctx->r15 = ADD32(ctx->r7, ctx->r14);
    // 0x80142BE4: sb          $t9, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r25;
    // 0x80142BE8: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x80142BEC: addiu       $t6, $t8, 0x1
    ctx->r14 = ADD32(ctx->r24, 0X1);
    // 0x80142BF0: b           L_801431B0
    // 0x80142BF4: sw          $t6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r14;
        goto L_801431B0;
    // 0x80142BF4: sw          $t6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r14;
L_80142BF8:
    // 0x80142BF8: lbu         $v0, 0x34($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X34);
    // 0x80142BFC: addiu       $at, $zero, 0x6C
    ctx->r1 = ADD32(0, 0X6C);
    // 0x80142C00: bnel        $v0, $at, L_80142C38
    if (ctx->r2 != ctx->r1) {
        // 0x80142C04: addiu       $at, $zero, 0x4C
        ctx->r1 = ADD32(0, 0X4C);
            goto L_80142C38;
    }
    goto skip_1;
    // 0x80142C04: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
    skip_1:
    // 0x80142C08: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x80142C0C: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80142C10: addiu       $t7, $t9, 0x3
    ctx->r15 = ADD32(ctx->r25, 0X3);
    // 0x80142C14: and         $t8, $t7, $at
    ctx->r24 = ctx->r15 & ctx->r1;
    // 0x80142C18: addiu       $t6, $t8, 0x4
    ctx->r14 = ADD32(ctx->r24, 0X4);
    // 0x80142C1C: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80142C20: lw          $t7, -0x4($t6)
    ctx->r15 = MEM_W(ctx->r14, -0X4);
    // 0x80142C24: sra         $t8, $t7, 31
    ctx->r24 = S32(SIGNED(ctx->r15) >> 31);
    // 0x80142C28: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142C2C: b           L_80142C94
    // 0x80142C30: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
        goto L_80142C94;
    // 0x80142C30: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x80142C34: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
L_80142C38:
    // 0x80142C38: bnel        $v0, $at, L_80142C70
    if (ctx->r2 != ctx->r1) {
        // 0x80142C3C: lw          $t7, 0x0($a2)
        ctx->r15 = MEM_W(ctx->r6, 0X0);
            goto L_80142C70;
    }
    goto skip_2;
    // 0x80142C3C: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    skip_2:
    // 0x80142C40: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x80142C44: addiu       $at, $zero, -0x8
    ctx->r1 = ADD32(0, -0X8);
    // 0x80142C48: addiu       $t7, $t6, 0x7
    ctx->r15 = ADD32(ctx->r14, 0X7);
    // 0x80142C4C: and         $t8, $t7, $at
    ctx->r24 = ctx->r15 & ctx->r1;
    // 0x80142C50: addiu       $t9, $t8, 0x8
    ctx->r25 = ADD32(ctx->r24, 0X8);
    // 0x80142C54: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80142C58: lw          $t8, -0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, -0X8);
    // 0x80142C5C: lw          $t9, -0x4($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X4);
    // 0x80142C60: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142C64: b           L_80142C94
    // 0x80142C68: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
        goto L_80142C94;
    // 0x80142C68: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x80142C6C: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
L_80142C70:
    // 0x80142C70: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80142C74: addiu       $t6, $t7, 0x3
    ctx->r14 = ADD32(ctx->r15, 0X3);
    // 0x80142C78: and         $t8, $t6, $at
    ctx->r24 = ctx->r14 & ctx->r1;
    // 0x80142C7C: addiu       $t9, $t8, 0x4
    ctx->r25 = ADD32(ctx->r24, 0X4);
    // 0x80142C80: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80142C84: lw          $t6, -0x4($t9)
    ctx->r14 = MEM_W(ctx->r25, -0X4);
    // 0x80142C88: sra         $t8, $t6, 31
    ctx->r24 = S32(SIGNED(ctx->r14) >> 31);
    // 0x80142C8C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142C90: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
L_80142C94:
    // 0x80142C94: lbu         $t7, 0x34($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X34);
    // 0x80142C98: addiu       $at, $zero, 0x68
    ctx->r1 = ADD32(0, 0X68);
    // 0x80142C9C: bnel        $t7, $at, L_80142CC0
    if (ctx->r15 != ctx->r1) {
        // 0x80142CA0: lw          $t6, 0x0($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X0);
            goto L_80142CC0;
    }
    goto skip_3;
    // 0x80142CA0: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    skip_3:
    // 0x80142CA4: lw          $t7, 0x4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X4);
    // 0x80142CA8: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80142CAC: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80142CB0: sra         $t8, $t6, 31
    ctx->r24 = S32(SIGNED(ctx->r14) >> 31);
    // 0x80142CB4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142CB8: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x80142CBC: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
L_80142CC0:
    // 0x80142CC0: bgtzl       $t6, L_80142CFC
    if (SIGNED(ctx->r14) > 0) {
        // 0x80142CC4: lw          $v0, 0x30($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X30);
            goto L_80142CFC;
    }
    goto skip_4;
    // 0x80142CC4: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
    skip_4:
    // 0x80142CC8: bltzl       $t6, L_80142CDC
    if (SIGNED(ctx->r14) < 0) {
        // 0x80142CCC: lw          $t9, 0xC($s0)
        ctx->r25 = MEM_W(ctx->r16, 0XC);
            goto L_80142CDC;
    }
    goto skip_5;
    // 0x80142CCC: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    skip_5:
    // 0x80142CD0: b           L_80142CFC
    // 0x80142CD4: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
        goto L_80142CFC;
    // 0x80142CD4: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
    // 0x80142CD8: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
L_80142CDC:
    // 0x80142CDC: addiu       $t8, $zero, 0x2D
    ctx->r24 = ADD32(0, 0X2D);
    // 0x80142CE0: addu        $t6, $a3, $t9
    ctx->r14 = ADD32(ctx->r7, ctx->r25);
    // 0x80142CE4: sb          $t8, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r24;
    // 0x80142CE8: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x80142CEC: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x80142CF0: b           L_80142D4C
    // 0x80142CF4: sw          $t9, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r25;
        goto L_80142D4C;
    // 0x80142CF4: sw          $t9, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r25;
    // 0x80142CF8: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
L_80142CFC:
    // 0x80142CFC: andi        $t8, $v0, 0x2
    ctx->r24 = ctx->r2 & 0X2;
    // 0x80142D00: beq         $t8, $zero, L_80142D28
    if (ctx->r24 == 0) {
        // 0x80142D04: andi        $t6, $v0, 0x1
        ctx->r14 = ctx->r2 & 0X1;
            goto L_80142D28;
    }
    // 0x80142D04: andi        $t6, $v0, 0x1
    ctx->r14 = ctx->r2 & 0X1;
    // 0x80142D08: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x80142D0C: addiu       $t6, $zero, 0x2B
    ctx->r14 = ADD32(0, 0X2B);
    // 0x80142D10: addu        $t9, $a3, $t7
    ctx->r25 = ADD32(ctx->r7, ctx->r15);
    // 0x80142D14: sb          $t6, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r14;
    // 0x80142D18: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x80142D1C: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x80142D20: b           L_80142D4C
    // 0x80142D24: sw          $t7, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r15;
        goto L_80142D4C;
    // 0x80142D24: sw          $t7, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r15;
L_80142D28:
    // 0x80142D28: beql        $t6, $zero, L_80142D50
    if (ctx->r14 == 0) {
        // 0x80142D2C: lw          $t9, 0xC($s0)
        ctx->r25 = MEM_W(ctx->r16, 0XC);
            goto L_80142D50;
    }
    goto skip_6;
    // 0x80142D2C: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    skip_6:
    // 0x80142D30: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x80142D34: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x80142D38: addu        $t7, $a3, $t8
    ctx->r15 = ADD32(ctx->r7, ctx->r24);
    // 0x80142D3C: sb          $t9, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r25;
    // 0x80142D40: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142D44: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80142D48: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
L_80142D4C:
    // 0x80142D4C: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
L_80142D50:
    // 0x80142D50: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80142D54: addu        $t7, $t9, $a3
    ctx->r15 = ADD32(ctx->r25, ctx->r7);
    // 0x80142D58: jal         0x8014B400
    // 0x80142D5C: sw          $t7, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r15;
    _Litob(rdram, ctx);
        goto after_0;
    // 0x80142D5C: sw          $t7, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r15;
    after_0:
    // 0x80142D60: b           L_801431B4
    // 0x80142D64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_801431B4;
    // 0x80142D64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80142D68:
    // 0x80142D68: lbu         $v0, 0x34($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X34);
    // 0x80142D6C: addiu       $at, $zero, 0x6C
    ctx->r1 = ADD32(0, 0X6C);
    // 0x80142D70: bnel        $v0, $at, L_80142DA8
    if (ctx->r2 != ctx->r1) {
        // 0x80142D74: addiu       $at, $zero, 0x4C
        ctx->r1 = ADD32(0, 0X4C);
            goto L_80142DA8;
    }
    goto skip_7;
    // 0x80142D74: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
    skip_7:
    // 0x80142D78: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x80142D7C: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80142D80: addiu       $t8, $t6, 0x3
    ctx->r24 = ADD32(ctx->r14, 0X3);
    // 0x80142D84: and         $t9, $t8, $at
    ctx->r25 = ctx->r24 & ctx->r1;
    // 0x80142D88: addiu       $t7, $t9, 0x4
    ctx->r15 = ADD32(ctx->r25, 0X4);
    // 0x80142D8C: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80142D90: lw          $t8, -0x4($t7)
    ctx->r24 = MEM_W(ctx->r15, -0X4);
    // 0x80142D94: sra         $t6, $t8, 31
    ctx->r14 = S32(SIGNED(ctx->r24) >> 31);
    // 0x80142D98: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80142D9C: b           L_80142E04
    // 0x80142DA0: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
        goto L_80142E04;
    // 0x80142DA0: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x80142DA4: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
L_80142DA8:
    // 0x80142DA8: bnel        $v0, $at, L_80142DE0
    if (ctx->r2 != ctx->r1) {
        // 0x80142DAC: lw          $t6, 0x0($a2)
        ctx->r14 = MEM_W(ctx->r6, 0X0);
            goto L_80142DE0;
    }
    goto skip_8;
    // 0x80142DAC: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    skip_8:
    // 0x80142DB0: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x80142DB4: addiu       $at, $zero, -0x8
    ctx->r1 = ADD32(0, -0X8);
    // 0x80142DB8: addiu       $t8, $t9, 0x7
    ctx->r24 = ADD32(ctx->r25, 0X7);
    // 0x80142DBC: and         $t6, $t8, $at
    ctx->r14 = ctx->r24 & ctx->r1;
    // 0x80142DC0: addiu       $t7, $t6, 0x8
    ctx->r15 = ADD32(ctx->r14, 0X8);
    // 0x80142DC4: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80142DC8: lw          $t9, -0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, -0X4);
    // 0x80142DCC: lw          $t8, -0x8($t7)
    ctx->r24 = MEM_W(ctx->r15, -0X8);
    // 0x80142DD0: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x80142DD4: b           L_80142E04
    // 0x80142DD8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
        goto L_80142E04;
    // 0x80142DD8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142DDC: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
L_80142DE0:
    // 0x80142DE0: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80142DE4: addiu       $t7, $t6, 0x3
    ctx->r15 = ADD32(ctx->r14, 0X3);
    // 0x80142DE8: and         $t8, $t7, $at
    ctx->r24 = ctx->r15 & ctx->r1;
    // 0x80142DEC: addiu       $t9, $t8, 0x4
    ctx->r25 = ADD32(ctx->r24, 0X4);
    // 0x80142DF0: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80142DF4: lw          $t7, -0x4($t9)
    ctx->r15 = MEM_W(ctx->r25, -0X4);
    // 0x80142DF8: sra         $t8, $t7, 31
    ctx->r24 = S32(SIGNED(ctx->r15) >> 31);
    // 0x80142DFC: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142E00: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
L_80142E04:
    // 0x80142E04: lbu         $v0, 0x34($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X34);
    // 0x80142E08: addiu       $at, $zero, 0x68
    ctx->r1 = ADD32(0, 0X68);
    // 0x80142E0C: bne         $v0, $at, L_80142E2C
    if (ctx->r2 != ctx->r1) {
        // 0x80142E10: nop
    
            goto L_80142E2C;
    }
    // 0x80142E10: nop

    // 0x80142E14: lw          $t7, 0x4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X4);
    // 0x80142E18: addiu       $t6, $zero, 0x0
    ctx->r14 = ADD32(0, 0X0);
    // 0x80142E1C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80142E20: andi        $t9, $t7, 0xFFFF
    ctx->r25 = ctx->r15 & 0XFFFF;
    // 0x80142E24: b           L_80142E44
    // 0x80142E28: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
        goto L_80142E44;
    // 0x80142E28: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
L_80142E2C:
    // 0x80142E2C: bnel        $v0, $zero, L_80142E48
    if (ctx->r2 != 0) {
        // 0x80142E30: lw          $t7, 0x30($s0)
        ctx->r15 = MEM_W(ctx->r16, 0X30);
            goto L_80142E48;
    }
    goto skip_9;
    // 0x80142E30: lw          $t7, 0x30($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X30);
    skip_9:
    // 0x80142E34: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
    // 0x80142E38: addiu       $t8, $zero, 0x0
    ctx->r24 = ADD32(0, 0X0);
    // 0x80142E3C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80142E40: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
L_80142E44:
    // 0x80142E44: lw          $t7, 0x30($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X30);
L_80142E48:
    // 0x80142E48: andi        $t6, $t7, 0x8
    ctx->r14 = ctx->r15 & 0X8;
    // 0x80142E4C: beql        $t6, $zero, L_80142EA0
    if (ctx->r14 == 0) {
        // 0x80142E50: lw          $t8, 0xC($s0)
        ctx->r24 = MEM_W(ctx->r16, 0XC);
            goto L_80142EA0;
    }
    goto skip_10;
    // 0x80142E50: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    skip_10:
    // 0x80142E54: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x80142E58: addiu       $t8, $zero, 0x30
    ctx->r24 = ADD32(0, 0X30);
    // 0x80142E5C: addiu       $at, $zero, 0x78
    ctx->r1 = ADD32(0, 0X78);
    // 0x80142E60: addu        $t7, $a3, $t9
    ctx->r15 = ADD32(ctx->r7, ctx->r25);
    // 0x80142E64: sb          $t8, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r24;
    // 0x80142E68: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142E6C: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x80142E70: beq         $v1, $at, L_80142E84
    if (ctx->r3 == ctx->r1) {
        // 0x80142E74: sw          $t9, 0xC($s0)
        MEM_W(0XC, ctx->r16) = ctx->r25;
            goto L_80142E84;
    }
    // 0x80142E74: sw          $t9, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r25;
    // 0x80142E78: addiu       $at, $zero, 0x58
    ctx->r1 = ADD32(0, 0X58);
    // 0x80142E7C: bnel        $v1, $at, L_80142EA0
    if (ctx->r3 != ctx->r1) {
        // 0x80142E80: lw          $t8, 0xC($s0)
        ctx->r24 = MEM_W(ctx->r16, 0XC);
            goto L_80142EA0;
    }
    goto skip_11;
    // 0x80142E80: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    skip_11:
L_80142E84:
    // 0x80142E84: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x80142E88: addu        $t7, $a3, $t8
    ctx->r15 = ADD32(ctx->r7, ctx->r24);
    // 0x80142E8C: sb          $a1, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r5;
    // 0x80142E90: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142E94: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x80142E98: sw          $t9, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r25;
    // 0x80142E9C: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
L_80142EA0:
    // 0x80142EA0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80142EA4: addu        $t7, $t8, $a3
    ctx->r15 = ADD32(ctx->r24, ctx->r7);
    // 0x80142EA8: jal         0x8014B400
    // 0x80142EAC: sw          $t7, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r15;
    _Litob(rdram, ctx);
        goto after_1;
    // 0x80142EAC: sw          $t7, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r15;
    after_1:
    // 0x80142EB0: b           L_801431B4
    // 0x80142EB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_801431B4;
    // 0x80142EB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80142EB8:
    // 0x80142EB8: lbu         $t6, 0x34($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X34);
    // 0x80142EBC: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
    // 0x80142EC0: bnel        $t6, $at, L_80142F28
    if (ctx->r14 != ctx->r1) {
        // 0x80142EC4: lw          $v0, 0x0($a2)
        ctx->r2 = MEM_W(ctx->r6, 0X0);
            goto L_80142F28;
    }
    goto skip_12;
    // 0x80142EC4: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    skip_12:
    // 0x80142EC8: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x80142ECC: andi        $t9, $v0, 0x1
    ctx->r25 = ctx->r2 & 0X1;
    // 0x80142ED0: beq         $t9, $zero, L_80142EE8
    if (ctx->r25 == 0) {
        // 0x80142ED4: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80142EE8;
    }
    // 0x80142ED4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80142ED8: addiu       $t8, $v1, 0x7
    ctx->r24 = ADD32(ctx->r3, 0X7);
    // 0x80142EDC: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80142EE0: b           L_80142F18
    // 0x80142EE4: addiu       $v0, $t8, -0x16
    ctx->r2 = ADD32(ctx->r24, -0X16);
        goto L_80142F18;
    // 0x80142EE4: addiu       $v0, $t8, -0x16
    ctx->r2 = ADD32(ctx->r24, -0X16);
L_80142EE8:
    // 0x80142EE8: andi        $t7, $v1, 0x2
    ctx->r15 = ctx->r3 & 0X2;
    // 0x80142EEC: beq         $t7, $zero, L_80142F04
    if (ctx->r15 == 0) {
        // 0x80142EF0: addiu       $t9, $v0, 0x7
        ctx->r25 = ADD32(ctx->r2, 0X7);
            goto L_80142F04;
    }
    // 0x80142EF0: addiu       $t9, $v0, 0x7
    ctx->r25 = ADD32(ctx->r2, 0X7);
    // 0x80142EF4: addiu       $t6, $v1, 0xA
    ctx->r14 = ADD32(ctx->r3, 0XA);
    // 0x80142EF8: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80142EFC: b           L_80142F14
    // 0x80142F00: addiu       $a0, $t6, -0x28
    ctx->r4 = ADD32(ctx->r14, -0X28);
        goto L_80142F14;
    // 0x80142F00: addiu       $a0, $t6, -0x28
    ctx->r4 = ADD32(ctx->r14, -0X28);
L_80142F04:
    // 0x80142F04: addiu       $at, $zero, -0x8
    ctx->r1 = ADD32(0, -0X8);
    // 0x80142F08: and         $t8, $t9, $at
    ctx->r24 = ctx->r25 & ctx->r1;
    // 0x80142F0C: addiu       $a0, $t8, 0x8
    ctx->r4 = ADD32(ctx->r24, 0X8);
    // 0x80142F10: sw          $a0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r4;
L_80142F14:
    // 0x80142F14: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_80142F18:
    // 0x80142F18: ldc1        $f4, -0x8($v0)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r2, -0X8);
    // 0x80142F1C: b           L_80142F7C
    // 0x80142F20: sdc1        $f4, 0x0($s0)
    CHECK_FR(ctx, 4);
    SD(ctx->f4.u64, 0X0, ctx->r16);
        goto L_80142F7C;
    // 0x80142F20: sdc1        $f4, 0x0($s0)
    CHECK_FR(ctx, 4);
    SD(ctx->f4.u64, 0X0, ctx->r16);
    // 0x80142F24: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
L_80142F28:
    // 0x80142F28: andi        $t6, $v0, 0x1
    ctx->r14 = ctx->r2 & 0X1;
    // 0x80142F2C: beq         $t6, $zero, L_80142F44
    if (ctx->r14 == 0) {
        // 0x80142F30: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80142F44;
    }
    // 0x80142F30: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80142F34: addiu       $t9, $v1, 0x7
    ctx->r25 = ADD32(ctx->r3, 0X7);
    // 0x80142F38: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80142F3C: b           L_80142F74
    // 0x80142F40: addiu       $v0, $t9, -0x16
    ctx->r2 = ADD32(ctx->r25, -0X16);
        goto L_80142F74;
    // 0x80142F40: addiu       $v0, $t9, -0x16
    ctx->r2 = ADD32(ctx->r25, -0X16);
L_80142F44:
    // 0x80142F44: andi        $t8, $v1, 0x2
    ctx->r24 = ctx->r3 & 0X2;
    // 0x80142F48: beq         $t8, $zero, L_80142F60
    if (ctx->r24 == 0) {
        // 0x80142F4C: addiu       $t6, $v0, 0x7
        ctx->r14 = ADD32(ctx->r2, 0X7);
            goto L_80142F60;
    }
    // 0x80142F4C: addiu       $t6, $v0, 0x7
    ctx->r14 = ADD32(ctx->r2, 0X7);
    // 0x80142F50: addiu       $t7, $v1, 0xA
    ctx->r15 = ADD32(ctx->r3, 0XA);
    // 0x80142F54: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80142F58: b           L_80142F70
    // 0x80142F5C: addiu       $a0, $t7, -0x28
    ctx->r4 = ADD32(ctx->r15, -0X28);
        goto L_80142F70;
    // 0x80142F5C: addiu       $a0, $t7, -0x28
    ctx->r4 = ADD32(ctx->r15, -0X28);
L_80142F60:
    // 0x80142F60: addiu       $at, $zero, -0x8
    ctx->r1 = ADD32(0, -0X8);
    // 0x80142F64: and         $t9, $t6, $at
    ctx->r25 = ctx->r14 & ctx->r1;
    // 0x80142F68: addiu       $a0, $t9, 0x8
    ctx->r4 = ADD32(ctx->r25, 0X8);
    // 0x80142F6C: sw          $a0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r4;
L_80142F70:
    // 0x80142F70: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_80142F74:
    // 0x80142F74: ldc1        $f6, -0x8($v0)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r2, -0X8);
    // 0x80142F78: sdc1        $f6, 0x0($s0)
    CHECK_FR(ctx, 6);
    SD(ctx->f6.u64, 0X0, ctx->r16);
L_80142F7C:
    // 0x80142F7C: lhu         $t7, 0x0($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X0);
    // 0x80142F80: andi        $t6, $t7, 0x8000
    ctx->r14 = ctx->r15 & 0X8000;
    // 0x80142F84: beql        $t6, $zero, L_80142FB0
    if (ctx->r14 == 0) {
        // 0x80142F88: lw          $v0, 0x30($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X30);
            goto L_80142FB0;
    }
    goto skip_13;
    // 0x80142F88: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
    skip_13:
    // 0x80142F8C: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x80142F90: addiu       $t9, $zero, 0x2D
    ctx->r25 = ADD32(0, 0X2D);
    // 0x80142F94: addu        $t7, $a3, $t8
    ctx->r15 = ADD32(ctx->r7, ctx->r24);
    // 0x80142F98: sb          $t9, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r25;
    // 0x80142F9C: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142FA0: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80142FA4: b           L_80143000
    // 0x80142FA8: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
        goto L_80143000;
    // 0x80142FA8: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
    // 0x80142FAC: lw          $v0, 0x30($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X30);
L_80142FB0:
    // 0x80142FB0: andi        $t9, $v0, 0x2
    ctx->r25 = ctx->r2 & 0X2;
    // 0x80142FB4: beq         $t9, $zero, L_80142FDC
    if (ctx->r25 == 0) {
        // 0x80142FB8: andi        $t7, $v0, 0x1
        ctx->r15 = ctx->r2 & 0X1;
            goto L_80142FDC;
    }
    // 0x80142FB8: andi        $t7, $v0, 0x1
    ctx->r15 = ctx->r2 & 0X1;
    // 0x80142FBC: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x80142FC0: addiu       $t7, $zero, 0x2B
    ctx->r15 = ADD32(0, 0X2B);
    // 0x80142FC4: addu        $t8, $a3, $t6
    ctx->r24 = ADD32(ctx->r7, ctx->r14);
    // 0x80142FC8: sb          $t7, 0x0($t8)
    MEM_B(0X0, ctx->r24) = ctx->r15;
    // 0x80142FCC: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x80142FD0: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x80142FD4: b           L_80143000
    // 0x80142FD8: sw          $t6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r14;
        goto L_80143000;
    // 0x80142FD8: sw          $t6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r14;
L_80142FDC:
    // 0x80142FDC: beql        $t7, $zero, L_80143004
    if (ctx->r15 == 0) {
        // 0x80142FE0: lw          $t8, 0xC($s0)
        ctx->r24 = MEM_W(ctx->r16, 0XC);
            goto L_80143004;
    }
    goto skip_14;
    // 0x80142FE0: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    skip_14:
    // 0x80142FE4: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x80142FE8: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x80142FEC: addu        $t6, $a3, $t9
    ctx->r14 = ADD32(ctx->r7, ctx->r25);
    // 0x80142FF0: sb          $t8, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r24;
    // 0x80142FF4: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x80142FF8: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x80142FFC: sw          $t9, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r25;
L_80143000:
    // 0x80143000: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
L_80143004:
    // 0x80143004: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80143008: addu        $t6, $t8, $a3
    ctx->r14 = ADD32(ctx->r24, ctx->r7);
    // 0x8014300C: jal         0x8014BC10
    // 0x80143010: sw          $t6, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r14;
    _Ldtob(rdram, ctx);
        goto after_2;
    // 0x80143010: sw          $t6, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r14;
    after_2:
    // 0x80143014: b           L_801431B4
    // 0x80143018: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_801431B4;
    // 0x80143018: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8014301C:
    // 0x8014301C: lbu         $v0, 0x34($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X34);
    // 0x80143020: addiu       $at, $zero, 0x68
    ctx->r1 = ADD32(0, 0X68);
    // 0x80143024: bnel        $v0, $at, L_80143058
    if (ctx->r2 != ctx->r1) {
        // 0x80143028: addiu       $at, $zero, 0x6C
        ctx->r1 = ADD32(0, 0X6C);
            goto L_80143058;
    }
    goto skip_15;
    // 0x80143028: addiu       $at, $zero, 0x6C
    ctx->r1 = ADD32(0, 0X6C);
    skip_15:
    // 0x8014302C: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    // 0x80143030: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80143034: addiu       $t9, $t7, 0x3
    ctx->r25 = ADD32(ctx->r15, 0X3);
    // 0x80143038: and         $t8, $t9, $at
    ctx->r24 = ctx->r25 & ctx->r1;
    // 0x8014303C: addiu       $t6, $t8, 0x4
    ctx->r14 = ADD32(ctx->r24, 0X4);
    // 0x80143040: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80143044: lw          $t9, -0x4($t6)
    ctx->r25 = MEM_W(ctx->r14, -0X4);
    // 0x80143048: lw          $t7, 0x2C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C);
    // 0x8014304C: b           L_801431B0
    // 0x80143050: sh          $t7, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r15;
        goto L_801431B0;
    // 0x80143050: sh          $t7, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r15;
    // 0x80143054: addiu       $at, $zero, 0x6C
    ctx->r1 = ADD32(0, 0X6C);
L_80143058:
    // 0x80143058: bnel        $v0, $at, L_8014308C
    if (ctx->r2 != ctx->r1) {
        // 0x8014305C: addiu       $at, $zero, 0x4C
        ctx->r1 = ADD32(0, 0X4C);
            goto L_8014308C;
    }
    goto skip_16;
    // 0x8014305C: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
    skip_16:
    // 0x80143060: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x80143064: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80143068: addiu       $t6, $t8, 0x3
    ctx->r14 = ADD32(ctx->r24, 0X3);
    // 0x8014306C: and         $t7, $t6, $at
    ctx->r15 = ctx->r14 & ctx->r1;
    // 0x80143070: addiu       $t9, $t7, 0x4
    ctx->r25 = ADD32(ctx->r15, 0X4);
    // 0x80143074: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80143078: lw          $t6, -0x4($t9)
    ctx->r14 = MEM_W(ctx->r25, -0X4);
    // 0x8014307C: lw          $t8, 0x2C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C);
    // 0x80143080: b           L_801431B0
    // 0x80143084: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
        goto L_801431B0;
    // 0x80143084: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
    // 0x80143088: addiu       $at, $zero, 0x4C
    ctx->r1 = ADD32(0, 0X4C);
L_8014308C:
    // 0x8014308C: bnel        $v0, $at, L_801430C8
    if (ctx->r2 != ctx->r1) {
        // 0x80143090: lw          $t7, 0x0($a2)
        ctx->r15 = MEM_W(ctx->r6, 0X0);
            goto L_801430C8;
    }
    goto skip_17;
    // 0x80143090: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    skip_17:
    // 0x80143094: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    // 0x80143098: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x8014309C: addiu       $t9, $t7, 0x3
    ctx->r25 = ADD32(ctx->r15, 0X3);
    // 0x801430A0: and         $t8, $t9, $at
    ctx->r24 = ctx->r25 & ctx->r1;
    // 0x801430A4: addiu       $t6, $t8, 0x4
    ctx->r14 = ADD32(ctx->r24, 0X4);
    // 0x801430A8: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x801430AC: lw          $t6, -0x4($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X4);
    // 0x801430B0: lw          $t7, 0x2C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C);
    // 0x801430B4: addiu       $t8, $zero, 0x0
    ctx->r24 = ADD32(0, 0X0);
    // 0x801430B8: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
    // 0x801430BC: b           L_801431B0
    // 0x801430C0: sw          $t7, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r15;
        goto L_801431B0;
    // 0x801430C0: sw          $t7, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r15;
    // 0x801430C4: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
L_801430C8:
    // 0x801430C8: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x801430CC: addiu       $t8, $t7, 0x3
    ctx->r24 = ADD32(ctx->r15, 0X3);
    // 0x801430D0: and         $t9, $t8, $at
    ctx->r25 = ctx->r24 & ctx->r1;
    // 0x801430D4: addiu       $t6, $t9, 0x4
    ctx->r14 = ADD32(ctx->r25, 0X4);
    // 0x801430D8: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x801430DC: lw          $t8, -0x4($t6)
    ctx->r24 = MEM_W(ctx->r14, -0X4);
    // 0x801430E0: lw          $t7, 0x2C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C);
    // 0x801430E4: b           L_801431B0
    // 0x801430E8: sw          $t7, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r15;
        goto L_801431B0;
    // 0x801430E8: sw          $t7, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r15;
L_801430EC:
    // 0x801430EC: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x801430F0: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x801430F4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x801430F8: addiu       $t6, $t9, 0x3
    ctx->r14 = ADD32(ctx->r25, 0X3);
    // 0x801430FC: and         $t7, $t6, $at
    ctx->r15 = ctx->r14 & ctx->r1;
    // 0x80143100: addiu       $t8, $t7, 0x4
    ctx->r24 = ADD32(ctx->r15, 0X4);
    // 0x80143104: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80143108: lw          $t6, -0x4($t8)
    ctx->r14 = MEM_W(ctx->r24, -0X4);
    // 0x8014310C: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x80143110: addiu       $a1, $zero, 0x78
    ctx->r5 = ADD32(0, 0X78);
    // 0x80143114: sra         $t8, $t6, 31
    ctx->r24 = S32(SIGNED(ctx->r14) >> 31);
    // 0x80143118: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8014311C: addu        $t6, $t7, $a3
    ctx->r14 = ADD32(ctx->r15, ctx->r7);
    // 0x80143120: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80143124: jal         0x8014B400
    // 0x80143128: sw          $t6, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r14;
    _Litob(rdram, ctx);
        goto after_3;
    // 0x80143128: sw          $t6, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r14;
    after_3:
    // 0x8014312C: b           L_801431B4
    // 0x80143130: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_801431B4;
    // 0x80143130: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80143134:
    // 0x80143134: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x80143138: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x8014313C: addiu       $t9, $t8, 0x3
    ctx->r25 = ADD32(ctx->r24, 0X3);
    // 0x80143140: and         $t7, $t9, $at
    ctx->r15 = ctx->r25 & ctx->r1;
    // 0x80143144: addiu       $t6, $t7, 0x4
    ctx->r14 = ADD32(ctx->r15, 0X4);
    // 0x80143148: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x8014314C: lw          $a0, -0x4($t6)
    ctx->r4 = MEM_W(ctx->r14, -0X4);
    // 0x80143150: jal         0x8014383C
    // 0x80143154: sw          $a0, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r4;
    strlen_recomp(rdram, ctx);
        goto after_4;
    // 0x80143154: sw          $a0, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r4;
    after_4:
    // 0x80143158: lw          $v1, 0x24($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X24);
    // 0x8014315C: sw          $v0, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r2;
    // 0x80143160: bltz        $v1, L_801431B0
    if (SIGNED(ctx->r3) < 0) {
        // 0x80143164: slt         $at, $v1, $v0
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
            goto L_801431B0;
    }
    // 0x80143164: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80143168: beql        $at, $zero, L_801431B4
    if (ctx->r1 == 0) {
        // 0x8014316C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_801431B4;
    }
    goto skip_18;
    // 0x8014316C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_18:
    // 0x80143170: b           L_801431B0
    // 0x80143174: sw          $v1, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r3;
        goto L_801431B0;
    // 0x80143174: sw          $v1, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r3;
    // 0x80143178: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
L_8014317C:
    // 0x8014317C: addiu       $t6, $zero, 0x25
    ctx->r14 = ADD32(0, 0X25);
    // 0x80143180: addu        $t9, $a3, $t8
    ctx->r25 = ADD32(ctx->r7, ctx->r24);
    // 0x80143184: sb          $t6, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r14;
    // 0x80143188: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x8014318C: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80143190: b           L_801431B0
    // 0x80143194: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
        goto L_801431B0;
    // 0x80143194: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
L_80143198:
    // 0x80143198: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
L_8014319C:
    // 0x8014319C: addu        $t9, $a3, $t6
    ctx->r25 = ADD32(ctx->r7, ctx->r14);
    // 0x801431A0: sb          $a1, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r5;
    // 0x801431A4: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x801431A8: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x801431AC: sw          $t8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r24;
L_801431B0:
    // 0x801431B0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801431B4:
    // 0x801431B4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x801431B8: jr          $ra
    // 0x801431BC: nop

    return;
    // 0x801431BC: nop

;}
RECOMP_FUNC void static_0_80145120(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80145120: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80145124: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80145128: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x8014512C: sll         $t6, $s3, 16
    ctx->r14 = S32(ctx->r19 << 16);
    // 0x80145130: sll         $t8, $s5, 16
    ctx->r24 = S32(ctx->r21 << 16);
    // 0x80145134: sra         $s5, $t8, 16
    ctx->r21 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80145138: sra         $s3, $t6, 16
    ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014513C: blez        $s1, L_801451A8
    if (SIGNED(ctx->r17) <= 0) {
        // 0x80145140: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_801451A8;
    }
    // 0x80145140: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80145144: lw          $t9, 0x30($s2)
    ctx->r25 = MEM_W(ctx->r18, 0X30);
    // 0x80145148: lw          $a0, 0x44($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X44);
    // 0x8014514C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80145150: jalr        $t9
    // 0x80145154: lw          $a2, 0x34($s2)
    ctx->r6 = MEM_W(ctx->r18, 0X34);
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_0;
    // 0x80145154: lw          $a2, 0x34($s2)
    ctx->r6 = MEM_W(ctx->r18, 0X34);
    after_0:
    // 0x80145158: andi        $a2, $v0, 0x7
    ctx->r6 = ctx->r2 & 0X7;
    // 0x8014515C: addu        $s1, $s1, $a2
    ctx->r17 = ADD32(ctx->r17, ctx->r6);
    // 0x80145160: andi        $t6, $s3, 0xFFFF
    ctx->r14 = ctx->r19 & 0XFFFF;
    // 0x80145164: lui         $at, 0x800
    ctx->r1 = S32(0X800 << 16);
    // 0x80145168: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x8014516C: andi        $t8, $s1, 0x7
    ctx->r24 = ctx->r17 & 0X7;
    // 0x80145170: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80145174: subu        $t9, $s1, $t8
    ctx->r25 = SUB32(ctx->r17, ctx->r24);
    // 0x80145178: addiu       $t6, $t9, 0x8
    ctx->r14 = ADD32(ctx->r25, 0X8);
    // 0x8014517C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80145180: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
    // 0x80145184: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x80145188: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8014518C: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80145190: subu        $t9, $v0, $a2
    ctx->r25 = SUB32(ctx->r2, ctx->r6);
    // 0x80145194: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80145198: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x8014519C: sw          $t9, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r25;
    // 0x801451A0: b           L_801451AC
    // 0x801451A4: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
        goto L_801451AC;
    // 0x801451A4: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
L_801451A8:
    // 0x801451A8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_801451AC:
    // 0x801451AC: andi        $t6, $s4, 0x2
    ctx->r14 = ctx->r20 & 0X2;
    // 0x801451B0: beq         $t6, $zero, L_801451D8
    if (ctx->r14 == 0) {
        // 0x801451B4: or          $v0, $s0, $zero
        ctx->r2 = ctx->r16 | 0;
            goto L_801451D8;
    }
    // 0x801451B4: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x801451B8: lui         $t7, 0xF00
    ctx->r15 = S32(0XF00 << 16);
    // 0x801451BC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x801451C0: lw          $t8, 0x18($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X18);
    // 0x801451C4: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x801451C8: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x801451CC: and         $t9, $t8, $at
    ctx->r25 = ctx->r24 & ctx->r1;
    // 0x801451D0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x801451D4: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
L_801451D8:
    // 0x801451D8: addu        $t6, $s3, $a2
    ctx->r14 = ADD32(ctx->r19, ctx->r6);
    // 0x801451DC: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x801451E0: lui         $at, 0x800
    ctx->r1 = S32(0X800 << 16);
    // 0x801451E4: or          $t8, $t7, $at
    ctx->r24 = ctx->r15 | ctx->r1;
    // 0x801451E8: or          $v1, $s0, $zero
    ctx->r3 = ctx->r16 | 0;
    // 0x801451EC: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x801451F0: sll         $t7, $s6, 1
    ctx->r15 = S32(ctx->r22 << 1);
    // 0x801451F4: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x801451F8: sll         $t6, $s5, 16
    ctx->r14 = S32(ctx->r21 << 16);
    // 0x801451FC: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x80145200: andi        $t7, $s4, 0xFF
    ctx->r15 = ctx->r20 & 0XFF;
    // 0x80145204: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
    // 0x80145208: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x8014520C: lui         $at, 0x100
    ctx->r1 = S32(0X100 << 16);
    // 0x80145210: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x80145214: or          $t8, $t6, $at
    ctx->r24 = ctx->r14 | ctx->r1;
    // 0x80145218: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8014521C: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80145220: lw          $t9, 0x14($s2)
    ctx->r25 = MEM_W(ctx->r18, 0X14);
    // 0x80145224: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x80145228: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x8014522C: and         $t7, $t9, $at
    ctx->r15 = ctx->r25 & ctx->r1;
    // 0x80145230: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80145234: sw          $zero, 0x40($s2)
    MEM_W(0X40, ctx->r18) = 0;
    // 0x80145238: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8014523C: addiu       $s0, $s0, 0x8
    ctx->r16 = ADD32(ctx->r16, 0X8);
    // 0x80145240: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x80145244: jr          $ra
    // 0x80145248: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x80145248: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void static_0_80145DB4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80145DB4: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80145DB8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80145DBC: lw          $t6, 0x48($s3)
    ctx->r14 = MEM_W(ctx->r19, 0X48);
    // 0x80145DC0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80145DC4: lw          $a0, 0x0($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X0);
    // 0x80145DC8: bne         $t6, $at, L_80145DD8
    if (ctx->r14 != ctx->r1) {
        // 0x80145DCC: nop
    
            goto L_80145DD8;
    }
    // 0x80145DCC: nop

    // 0x80145DD0: bnel        $s5, $zero, L_80145DE4
    if (ctx->r21 != 0) {
        // 0x80145DD4: sw          $t0, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->r8;
            goto L_80145DE4;
    }
    goto skip_0;
    // 0x80145DD4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    skip_0:
L_80145DD8:
    // 0x80145DD8: b           L_8014603C
    // 0x80145DDC: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
        goto L_8014603C;
    // 0x80145DDC: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x80145DE0: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
L_80145DE4:
    // 0x80145DE4: lw          $t9, 0x4($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X4);
    // 0x80145DE8: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    // 0x80145DEC: or          $a2, $s5, $zero
    ctx->r6 = ctx->r21 | 0;
    // 0x80145DF0: jalr        $t9
    // 0x80145DF4: nop

    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_0;
    // 0x80145DF4: nop

    after_0:
    // 0x80145DF8: lh          $t7, 0x0($s6)
    ctx->r15 = MEM_H(ctx->r22, 0X0);
    // 0x80145DFC: lui         $at, 0x800
    ctx->r1 = S32(0X800 << 16);
    // 0x80145E00: sll         $s7, $s5, 1
    ctx->r23 = S32(ctx->r21 << 1);
    // 0x80145E04: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x80145E08: or          $t6, $t8, $at
    ctx->r14 = ctx->r24 | ctx->r1;
    // 0x80145E0C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80145E10: lh          $t9, 0x0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X0);
    // 0x80145E14: lui         $at, 0x808
    ctx->r1 = S32(0X808 << 16);
    // 0x80145E18: addiu       $s4, $v0, 0x10
    ctx->r20 = ADD32(ctx->r2, 0X10);
    // 0x80145E1C: addiu       $t8, $t9, 0x440
    ctx->r24 = ADD32(ctx->r25, 0X440);
    // 0x80145E20: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80145E24: andi        $t9, $s7, 0xFFFF
    ctx->r25 = ctx->r23 & 0XFFFF;
    // 0x80145E28: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x80145E2C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80145E30: lh          $t8, 0x0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X0);
    // 0x80145E34: addiu       $t6, $t8, 0x580
    ctx->r14 = ADD32(ctx->r24, 0X580);
    // 0x80145E38: andi        $t9, $t6, 0xFFFF
    ctx->r25 = ctx->r14 & 0XFFFF;
    // 0x80145E3C: or          $t7, $t9, $at
    ctx->r15 = ctx->r25 | ctx->r1;
    // 0x80145E40: sw          $t7, 0x8($v0)
    MEM_W(0X8, ctx->r2) = ctx->r15;
    // 0x80145E44: lh          $v1, 0x0($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X0);
    // 0x80145E48: or          $s0, $s4, $zero
    ctx->r16 = ctx->r20 | 0;
    // 0x80145E4C: addiu       $t8, $v1, 0x800
    ctx->r24 = ADD32(ctx->r3, 0X800);
    // 0x80145E50: andi        $t6, $t8, 0xFFFF
    ctx->r14 = ctx->r24 & 0XFFFF;
    // 0x80145E54: addiu       $t7, $v1, 0x6C0
    ctx->r15 = ADD32(ctx->r3, 0X6C0);
    // 0x80145E58: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80145E5C: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x80145E60: sw          $t9, 0xC($v0)
    MEM_W(0XC, ctx->r2) = ctx->r25;
    // 0x80145E64: lw          $t7, 0x38($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X38);
    // 0x80145E68: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x80145E6C: beql        $t7, $zero, L_8014600C
    if (ctx->r15 == 0) {
        // 0x80145E70: lui         $t7, 0x308
        ctx->r15 = S32(0X308 << 16);
            goto L_8014600C;
    }
    goto skip_1;
    // 0x80145E70: lui         $t7, 0x308
    ctx->r15 = S32(0X308 << 16);
    skip_1:
    // 0x80145E74: lh          $t6, 0x18($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X18);
    // 0x80145E78: sw          $zero, 0x38($s3)
    MEM_W(0X38, ctx->r19) = 0;
    // 0x80145E7C: lh          $t7, 0x1A($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X1A);
    // 0x80145E80: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x80145E84: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80145E88: lh          $t9, -0x5610($t9)
    ctx->r25 = MEM_H(ctx->r25, -0X5610);
    // 0x80145E8C: lw          $a0, 0x34($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X34);
    // 0x80145E90: addiu       $s1, $s3, 0x24
    ctx->r17 = ADD32(ctx->r19, 0X24);
    // 0x80145E94: multu       $t9, $t7
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80145E98: lh          $t9, 0x1C($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X1C);
    // 0x80145E9C: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x80145EA0: nop

    // 0x80145EA4: cvt.d.w     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.d = CVT_D_W(ctx->f4.u32l);
    // 0x80145EA8: mflo        $t6
    ctx->r14 = lo;
    // 0x80145EAC: sra         $t8, $t6, 15
    ctx->r24 = S32(SIGNED(ctx->r14) >> 15);
    // 0x80145EB0: sh          $t8, 0x28($s3)
    MEM_H(0X28, ctx->r19) = ctx->r24;
    // 0x80145EB4: lh          $t7, 0x28($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X28);
    // 0x80145EB8: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x80145EBC: jal         0x80145BE4
    // 0x80145EC0: cvt.d.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.d = CVT_D_W(ctx->f6.u32l);
    static_0_80145BE4(rdram, ctx);
        goto after_1;
    // 0x80145EC0: cvt.d.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.d = CVT_D_W(ctx->f6.u32l);
    after_1:
    // 0x80145EC4: lh          $t6, 0x18($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X18);
    // 0x80145EC8: lui         $t7, 0x8016
    ctx->r15 = S32(0X8016 << 16);
    // 0x80145ECC: sh          $v0, 0x26($s3)
    MEM_H(0X26, ctx->r19) = ctx->r2;
    // 0x80145ED0: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x80145ED4: negu        $t9, $t8
    ctx->r25 = SUB32(0, ctx->r24);
    // 0x80145ED8: addu        $t7, $t7, $t9
    ctx->r15 = ADD32(ctx->r15, ctx->r25);
    // 0x80145EDC: lh          $t7, -0x5512($t7)
    ctx->r15 = MEM_H(ctx->r15, -0X5512);
    // 0x80145EE0: lh          $t6, 0x1A($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X1A);
    // 0x80145EE4: lw          $a0, 0x34($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X34);
    // 0x80145EE8: addiu       $s1, $s3, 0x2A
    ctx->r17 = ADD32(ctx->r19, 0X2A);
    // 0x80145EEC: multu       $t7, $t6
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80145EF0: lh          $t7, 0x1E($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X1E);
    // 0x80145EF4: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x80145EF8: nop

    // 0x80145EFC: cvt.d.w     $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.d = CVT_D_W(ctx->f8.u32l);
    // 0x80145F00: mflo        $t8
    ctx->r24 = lo;
    // 0x80145F04: sra         $t9, $t8, 15
    ctx->r25 = S32(SIGNED(ctx->r24) >> 15);
    // 0x80145F08: sh          $t9, 0x2E($s3)
    MEM_H(0X2E, ctx->r19) = ctx->r25;
    // 0x80145F0C: lh          $t6, 0x2E($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X2E);
    // 0x80145F10: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x80145F14: jal         0x80145BE4
    // 0x80145F18: cvt.d.w     $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    ctx->f14.d = CVT_D_W(ctx->f10.u32l);
    static_0_80145BE4(rdram, ctx);
        goto after_2;
    // 0x80145F18: cvt.d.w     $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    ctx->f14.d = CVT_D_W(ctx->f10.u32l);
    after_2:
    // 0x80145F1C: lh          $t8, 0x1C($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X1C);
    // 0x80145F20: sh          $v0, 0x2C($s3)
    MEM_H(0X2C, ctx->r19) = ctx->r2;
    // 0x80145F24: or          $v1, $s4, $zero
    ctx->r3 = ctx->r20 | 0;
    // 0x80145F28: lui         $at, 0x906
    ctx->r1 = S32(0X906 << 16);
    // 0x80145F2C: andi        $t9, $t8, 0xFFFF
    ctx->r25 = ctx->r24 & 0XFFFF;
    // 0x80145F30: or          $t7, $t9, $at
    ctx->r15 = ctx->r25 | ctx->r1;
    // 0x80145F34: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80145F38: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80145F3C: lh          $t6, 0x1E($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X1E);
    // 0x80145F40: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    // 0x80145F44: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x80145F48: lui         $at, 0x904
    ctx->r1 = S32(0X904 << 16);
    // 0x80145F4C: andi        $t8, $t6, 0xFFFF
    ctx->r24 = ctx->r14 & 0XFFFF;
    // 0x80145F50: or          $t9, $t8, $at
    ctx->r25 = ctx->r24 | ctx->r1;
    // 0x80145F54: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80145F58: sw          $zero, 0x4($a0)
    MEM_W(0X4, ctx->r4) = 0;
    // 0x80145F5C: lh          $t7, 0x28($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X28);
    // 0x80145F60: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    // 0x80145F64: lui         $at, 0x902
    ctx->r1 = S32(0X902 << 16);
    // 0x80145F68: andi        $t6, $t7, 0xFFFF
    ctx->r14 = ctx->r15 & 0XFFFF;
    // 0x80145F6C: or          $t8, $t6, $at
    ctx->r24 = ctx->r14 | ctx->r1;
    // 0x80145F70: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x80145F74: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x80145F78: lh          $t7, 0x26($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X26);
    // 0x80145F7C: lhu         $t9, 0x24($s3)
    ctx->r25 = MEM_HU(ctx->r19, 0X24);
    // 0x80145F80: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    // 0x80145F84: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x80145F88: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x80145F8C: sw          $t7, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r15;
    // 0x80145F90: lh          $t8, 0x2E($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X2E);
    // 0x80145F94: lui         $at, 0x900
    ctx->r1 = S32(0X900 << 16);
    // 0x80145F98: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    // 0x80145F9C: andi        $t6, $t8, 0xFFFF
    ctx->r14 = ctx->r24 & 0XFFFF;
    // 0x80145FA0: or          $t9, $t6, $at
    ctx->r25 = ctx->r14 | ctx->r1;
    // 0x80145FA4: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80145FA8: lh          $t8, 0x2C($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X2C);
    // 0x80145FAC: lhu         $t7, 0x2A($s3)
    ctx->r15 = MEM_HU(ctx->r19, 0X2A);
    // 0x80145FB0: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    // 0x80145FB4: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80145FB8: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80145FBC: sw          $t8, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r24;
    // 0x80145FC0: lh          $t9, 0x20($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X20);
    // 0x80145FC4: lui         $at, 0x908
    ctx->r1 = S32(0X908 << 16);
    // 0x80145FC8: or          $v0, $s4, $zero
    ctx->r2 = ctx->r20 | 0;
    // 0x80145FCC: andi        $t6, $t9, 0xFFFF
    ctx->r14 = ctx->r25 & 0XFFFF;
    // 0x80145FD0: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x80145FD4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80145FD8: lh          $t8, 0x22($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X22);
    // 0x80145FDC: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    // 0x80145FE0: or          $s0, $s4, $zero
    ctx->r16 = ctx->r20 | 0;
    // 0x80145FE4: andi        $t9, $t8, 0xFFFF
    ctx->r25 = ctx->r24 & 0XFFFF;
    // 0x80145FE8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80145FEC: lui         $t6, 0x309
    ctx->r14 = S32(0X309 << 16);
    // 0x80145FF0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80145FF4: lw          $a0, 0x14($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X14);
    // 0x80145FF8: jal         0x80138130
    // 0x80145FFC: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_3;
    // 0x80145FFC: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    after_3:
    // 0x80146000: b           L_80146020
    // 0x80146004: sw          $v0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r2;
        goto L_80146020;
    // 0x80146004: sw          $v0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r2;
    // 0x80146008: lui         $t7, 0x308
    ctx->r15 = S32(0X308 << 16);
L_8014600C:
    // 0x8014600C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80146010: lw          $a0, 0x14($s3)
    ctx->r4 = MEM_W(ctx->r19, 0X14);
    // 0x80146014: jal         0x80138130
    // 0x80146018: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_4;
    // 0x80146018: addiu       $s4, $s4, 0x8
    ctx->r20 = ADD32(ctx->r20, 0X8);
    after_4:
    // 0x8014601C: sw          $v0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r2;
L_80146020:
    // 0x80146020: lh          $t8, 0x0($s6)
    ctx->r24 = MEM_H(ctx->r22, 0X0);
    // 0x80146024: or          $v0, $s4, $zero
    ctx->r2 = ctx->r20 | 0;
    // 0x80146028: addu        $t9, $t8, $s7
    ctx->r25 = ADD32(ctx->r24, ctx->r23);
    // 0x8014602C: sh          $t9, 0x0($s6)
    MEM_H(0X0, ctx->r22) = ctx->r25;
    // 0x80146030: lw          $t6, 0x30($s3)
    ctx->r14 = MEM_W(ctx->r19, 0X30);
    // 0x80146034: addu        $t7, $t6, $s5
    ctx->r15 = ADD32(ctx->r14, ctx->r21);
    // 0x80146038: sw          $t7, 0x30($s3)
    MEM_W(0X30, ctx->r19) = ctx->r15;
L_8014603C:
    // 0x8014603C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80146040: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80146044: jr          $ra
    // 0x80146048: nop

    return;
    // 0x80146048: nop

;}
RECOMP_FUNC void static_0_8014604C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8014604C: sw          $a1, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r5;
    // 0x80146050: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80146054: sw          $a2, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r6;
    // 0x80146058: andi        $t8, $a2, 0xFFFF
    ctx->r24 = ctx->r6 & 0XFFFF;
    // 0x8014605C: sra         $t9, $a0, 3
    ctx->r25 = S32(SIGNED(ctx->r4) >> 3);
    // 0x80146060: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80146064: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80146068: bne         $t9, $zero, L_80146078
    if (ctx->r25 != 0) {
        // 0x8014606C: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_80146078;
    }
    // 0x8014606C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80146070: jr          $ra
    // 0x80146074: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
    return;
    // 0x80146074: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
L_80146078:
    // 0x80146078: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8014607C: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80146080: mtc1        $a2, $f8
    ctx->f8.u32l = ctx->r6;
    // 0x80146084: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80146088: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8014608C: bgez        $a2, L_801460A4
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80146090: cvt.s.w     $f10, $f8
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
            goto L_801460A4;
    }
    // 0x80146090: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80146094: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80146098: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8014609C: nop

    // 0x801460A0: add.s       $f10, $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f4.fl;
L_801460A4:
    // 0x801460A4: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x801460A8: add.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x801460AC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x801460B0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x801460B4: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    // 0x801460B8: addiu       $v1, $zero, 0x20
    ctx->r3 = ADD32(0, 0X20);
    // 0x801460BC: div.s       $f0, $f8, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
    // 0x801460C0: andi        $t7, $a0, 0x1
    ctx->r15 = ctx->r4 & 0X1;
L_801460C4:
    // 0x801460C4: beq         $t7, $zero, L_801460D4
    if (ctx->r15 == 0) {
        // 0x801460C8: sra         $t8, $a0, 1
        ctx->r24 = S32(SIGNED(ctx->r4) >> 1);
            goto L_801460D4;
    }
    // 0x801460C8: sra         $t8, $a0, 1
    ctx->r24 = S32(SIGNED(ctx->r4) >> 1);
    // 0x801460CC: mul.s       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = MUL_S(ctx->f2.fl, ctx->f0.fl);
    // 0x801460D0: nop

L_801460D4:
    // 0x801460D4: beq         $t8, $zero, L_801460EC
    if (ctx->r24 == 0) {
        // 0x801460D8: or          $a0, $t8, $zero
        ctx->r4 = ctx->r24 | 0;
            goto L_801460EC;
    }
    // 0x801460D8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x801460DC: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x801460E0: mul.s       $f0, $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x801460E4: bnel        $v0, $v1, L_801460C4
    if (ctx->r2 != ctx->r3) {
        // 0x801460E8: andi        $t7, $a0, 0x1
        ctx->r15 = ctx->r4 & 0X1;
            goto L_801460C4;
    }
    goto skip_0;
    // 0x801460E8: andi        $t7, $a0, 0x1
    ctx->r15 = ctx->r4 & 0X1;
    skip_0:
L_801460EC:
    // 0x801460EC: mul.s       $f0, $f12, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f0.fl = MUL_S(ctx->f12.fl, ctx->f2.fl);
    // 0x801460F0: nop

    // 0x801460F4: jr          $ra
    // 0x801460F8: nop

    return;
    // 0x801460F8: nop

;}
RECOMP_FUNC void static_0_801468F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801468F8: lw          $v1, 0x8($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X8);
    // 0x801468FC: lbu         $v0, 0x0($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X0);
    // 0x80146900: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x80146904: sw          $t6, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r14;
    // 0x80146908: andi        $t7, $v0, 0x80
    ctx->r15 = ctx->r2 & 0X80;
    // 0x8014690C: beq         $t7, $zero, L_8014693C
    if (ctx->r15 == 0) {
        // 0x80146910: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_8014693C;
    }
    // 0x80146910: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80146914: andi        $a1, $v0, 0x7F
    ctx->r5 = ctx->r2 & 0X7F;
L_80146918:
    // 0x80146918: lw          $v1, 0x8($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X8);
    // 0x8014691C: sll         $t9, $a1, 7
    ctx->r25 = S32(ctx->r5 << 7);
    // 0x80146920: lbu         $v0, 0x0($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X0);
    // 0x80146924: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x80146928: sw          $t8, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r24;
    // 0x8014692C: andi        $t6, $v0, 0x7F
    ctx->r14 = ctx->r2 & 0X7F;
    // 0x80146930: andi        $t7, $v0, 0x80
    ctx->r15 = ctx->r2 & 0X80;
    // 0x80146934: bne         $t7, $zero, L_80146918
    if (ctx->r15 != 0) {
        // 0x80146938: addu        $a1, $t9, $t6
        ctx->r5 = ADD32(ctx->r25, ctx->r14);
            goto L_80146918;
    }
    // 0x80146938: addu        $a1, $t9, $t6
    ctx->r5 = ADD32(ctx->r25, ctx->r14);
L_8014693C:
    // 0x8014693C: jr          $ra
    // 0x80146940: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    return;
    // 0x80146940: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
;}
RECOMP_FUNC void static_0_80146D78(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80146D78: lw          $a1, 0x8($a0)
    ctx->r5 = MEM_W(ctx->r4, 0X8);
    // 0x80146D7C: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80146D80: addiu       $t7, $a1, 0x1
    ctx->r15 = ADD32(ctx->r5, 0X1);
    // 0x80146D84: sw          $t7, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r15;
    // 0x80146D88: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x80146D8C: sll         $t6, $v1, 24
    ctx->r14 = S32(ctx->r3 << 24);
    // 0x80146D90: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80146D94: or          $v1, $t6, $t9
    ctx->r3 = ctx->r14 | ctx->r25;
    // 0x80146D98: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x80146D9C: sw          $t6, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r14;
    // 0x80146DA0: lbu         $t7, 0x0($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X0);
    // 0x80146DA4: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x80146DA8: sw          $t9, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r25;
    // 0x80146DAC: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x80146DB0: lbu         $t6, 0x0($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X0);
    // 0x80146DB4: or          $v1, $v1, $t8
    ctx->r3 = ctx->r3 | ctx->r24;
    // 0x80146DB8: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80146DBC: sw          $t7, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r15;
    // 0x80146DC0: jr          $ra
    // 0x80146DC4: or          $v0, $v1, $t6
    ctx->r2 = ctx->r3 | ctx->r14;
    return;
    // 0x80146DC4: or          $v0, $v1, $t6
    ctx->r2 = ctx->r3 | ctx->r14;
;}
RECOMP_FUNC void static_0_80146DC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80146DC8: lw          $a1, 0x8($a0)
    ctx->r5 = MEM_W(ctx->r4, 0X8);
    // 0x80146DCC: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80146DD0: addiu       $t9, $a1, 0x1
    ctx->r25 = ADD32(ctx->r5, 0X1);
    // 0x80146DD4: sw          $t9, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r25;
    // 0x80146DD8: lbu         $t6, 0x0($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X0);
    // 0x80146DDC: sll         $t8, $v1, 8
    ctx->r24 = S32(ctx->r3 << 8);
    // 0x80146DE0: addiu       $t9, $t9, 0x1
    ctx->r25 = ADD32(ctx->r25, 0X1);
    // 0x80146DE4: or          $v1, $t8, $t6
    ctx->r3 = ctx->r24 | ctx->r14;
    // 0x80146DE8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x80146DEC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80146DF0: jr          $ra
    // 0x80146DF4: sw          $t9, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r25;
    return;
    // 0x80146DF4: sw          $t9, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r25;
;}
RECOMP_FUNC void static_0_8014B6A0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8014B6A0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8014B6A4: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8014B6A8: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8014B6AC: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014B6B0: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8014B6B4: sll         $t8, $s3, 16
    ctx->r24 = S32(ctx->r19 << 16);
    // 0x8014B6B8: sra         $s3, $t8, 16
    ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8014B6BC: andi        $t6, $s4, 0xFF
    ctx->r14 = ctx->r20 & 0XFF;
    // 0x8014B6C0: sw          $s4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r20;
    // 0x8014B6C4: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
    // 0x8014B6C8: bgtz        $s3, L_8014B6DC
    if (SIGNED(ctx->r19) > 0) {
        // 0x8014B6CC: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_8014B6DC;
    }
    // 0x8014B6CC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8014B6D0: lui         $s1, 0x8016
    ctx->r17 = S32(0X8016 << 16);
    // 0x8014B6D4: addiu       $s1, $s1, -0x48B0
    ctx->r17 = ADD32(ctx->r17, -0X48B0);
    // 0x8014B6D8: addiu       $s3, $zero, 0x1
    ctx->r19 = ADD32(0, 0X1);
L_8014B6DC:
    // 0x8014B6DC: addiu       $v0, $zero, 0x66
    ctx->r2 = ADD32(0, 0X66);
    // 0x8014B6E0: beq         $v0, $s4, L_8014B714
    if (ctx->r2 == ctx->r20) {
        // 0x8014B6E4: or          $v1, $s4, $zero
        ctx->r3 = ctx->r20 | 0;
            goto L_8014B714;
    }
    // 0x8014B6E4: or          $v1, $s4, $zero
    ctx->r3 = ctx->r20 | 0;
    // 0x8014B6E8: addiu       $a0, $zero, 0x67
    ctx->r4 = ADD32(0, 0X67);
    // 0x8014B6EC: beq         $a0, $v1, L_8014B6F8
    if (ctx->r4 == ctx->r3) {
        // 0x8014B6F0: addiu       $at, $zero, 0x47
        ctx->r1 = ADD32(0, 0X47);
            goto L_8014B6F8;
    }
    // 0x8014B6F0: addiu       $at, $zero, 0x47
    ctx->r1 = ADD32(0, 0X47);
    // 0x8014B6F4: bne         $v1, $at, L_8014B950
    if (ctx->r3 != ctx->r1) {
        // 0x8014B6F8: slti        $at, $s2, -0x4
        ctx->r1 = SIGNED(ctx->r18) < -0X4 ? 1 : 0;
            goto L_8014B950;
    }
L_8014B6F8:
    // 0x8014B6F8: slti        $at, $s2, -0x4
    ctx->r1 = SIGNED(ctx->r18) < -0X4 ? 1 : 0;
    // 0x8014B6FC: bne         $at, $zero, L_8014B950
    if (ctx->r1 != 0) {
        // 0x8014B700: nop
    
            goto L_8014B950;
    }
    // 0x8014B700: nop

    // 0x8014B704: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x8014B708: slt         $at, $s2, $t7
    ctx->r1 = SIGNED(ctx->r18) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x8014B70C: beq         $at, $zero, L_8014B950
    if (ctx->r1 == 0) {
        // 0x8014B710: nop
    
            goto L_8014B950;
    }
    // 0x8014B710: nop

L_8014B714:
    // 0x8014B714: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x8014B718: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x8014B71C: beq         $v0, $v1, L_8014B758
    if (ctx->r2 == ctx->r3) {
        // 0x8014B720: sra         $s2, $t8, 16
        ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
            goto L_8014B758;
    }
    // 0x8014B720: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8014B724: lw          $t6, 0x30($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X30);
    // 0x8014B728: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B72C: andi        $t7, $t6, 0x8
    ctx->r15 = ctx->r14 & 0X8;
    // 0x8014B730: bne         $t7, $zero, L_8014B748
    if (ctx->r15 != 0) {
        // 0x8014B734: slt         $at, $s3, $v0
        ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r2) ? 1 : 0;
            goto L_8014B748;
    }
    // 0x8014B734: slt         $at, $s3, $v0
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8014B738: beql        $at, $zero, L_8014B74C
    if (ctx->r1 == 0) {
        // 0x8014B73C: subu        $t8, $v0, $s2
        ctx->r24 = SUB32(ctx->r2, ctx->r18);
            goto L_8014B74C;
    }
    goto skip_0;
    // 0x8014B73C: subu        $t8, $v0, $s2
    ctx->r24 = SUB32(ctx->r2, ctx->r18);
    skip_0:
    // 0x8014B740: sw          $s3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r19;
    // 0x8014B744: or          $v0, $s3, $zero
    ctx->r2 = ctx->r19 | 0;
L_8014B748:
    // 0x8014B748: subu        $t8, $v0, $s2
    ctx->r24 = SUB32(ctx->r2, ctx->r18);
L_8014B74C:
    // 0x8014B74C: bgez        $t8, L_8014B758
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8014B750: sw          $t8, 0x24($s0)
        MEM_W(0X24, ctx->r16) = ctx->r24;
            goto L_8014B758;
    }
    // 0x8014B750: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x8014B754: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
L_8014B758:
    // 0x8014B758: bgtz        $s2, L_8014B828
    if (SIGNED(ctx->r18) > 0) {
        // 0x8014B75C: slt         $at, $s3, $s2
        ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r18) ? 1 : 0;
            goto L_8014B828;
    }
    // 0x8014B75C: slt         $at, $s3, $s2
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r18) ? 1 : 0;
    // 0x8014B760: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x8014B764: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B768: addiu       $t6, $zero, 0x30
    ctx->r14 = ADD32(0, 0X30);
    // 0x8014B76C: negu        $v1, $s2
    ctx->r3 = SUB32(0, ctx->r18);
    // 0x8014B770: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8014B774: sb          $t6, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r14;
    // 0x8014B778: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B77C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B780: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8014B784: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8014B788: bgtz        $v0, L_8014B7A0
    if (SIGNED(ctx->r2) > 0) {
        // 0x8014B78C: sw          $t8, 0x14($s0)
        MEM_W(0X14, ctx->r16) = ctx->r24;
            goto L_8014B7A0;
    }
    // 0x8014B78C: sw          $t8, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r24;
    // 0x8014B790: lw          $t6, 0x30($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X30);
    // 0x8014B794: andi        $t9, $t6, 0x8
    ctx->r25 = ctx->r14 & 0X8;
    // 0x8014B798: beql        $t9, $zero, L_8014B7C8
    if (ctx->r25 == 0) {
        // 0x8014B79C: slt         $at, $v0, $v1
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_8014B7C8;
    }
    goto skip_1;
    // 0x8014B79C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    skip_1:
L_8014B7A0:
    // 0x8014B7A0: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x8014B7A4: lw          $t6, 0x14($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X14);
    // 0x8014B7A8: addiu       $t7, $zero, 0x2E
    ctx->r15 = ADD32(0, 0X2E);
    // 0x8014B7AC: addu        $t9, $t8, $t6
    ctx->r25 = ADD32(ctx->r24, ctx->r14);
    // 0x8014B7B0: sb          $t7, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r15;
    // 0x8014B7B4: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B7B8: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B7BC: addiu       $t6, $t8, 0x1
    ctx->r14 = ADD32(ctx->r24, 0X1);
    // 0x8014B7C0: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x8014B7C4: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
L_8014B7C8:
    // 0x8014B7C8: beql        $at, $zero, L_8014B7E4
    if (ctx->r1 == 0) {
        // 0x8014B7CC: addu        $t8, $v0, $s2
        ctx->r24 = ADD32(ctx->r2, ctx->r18);
            goto L_8014B7E4;
    }
    goto skip_2;
    // 0x8014B7CC: addu        $t8, $v0, $s2
    ctx->r24 = ADD32(ctx->r2, ctx->r18);
    skip_2:
    // 0x8014B7D0: negu        $s2, $v0
    ctx->r18 = SUB32(0, ctx->r2);
    // 0x8014B7D4: sll         $t7, $s2, 16
    ctx->r15 = S32(ctx->r18 << 16);
    // 0x8014B7D8: sra         $s2, $t7, 16
    ctx->r18 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8014B7DC: negu        $v1, $s2
    ctx->r3 = SUB32(0, ctx->r18);
    // 0x8014B7E0: addu        $t8, $v0, $s2
    ctx->r24 = ADD32(ctx->r2, ctx->r18);
L_8014B7E4:
    // 0x8014B7E4: slt         $at, $t8, $s3
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8014B7E8: sw          $v1, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r3;
    // 0x8014B7EC: beq         $at, $zero, L_8014B800
    if (ctx->r1 == 0) {
        // 0x8014B7F0: sw          $t8, 0x24($s0)
        MEM_W(0X24, ctx->r16) = ctx->r24;
            goto L_8014B800;
    }
    // 0x8014B7F0: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x8014B7F4: sll         $s3, $t8, 16
    ctx->r19 = S32(ctx->r24 << 16);
    // 0x8014B7F8: sra         $t6, $s3, 16
    ctx->r14 = S32(SIGNED(ctx->r19) >> 16);
    // 0x8014B7FC: or          $s3, $t6, $zero
    ctx->r19 = ctx->r14 | 0;
L_8014B800:
    // 0x8014B800: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x8014B804: lw          $t9, 0x14($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X14);
    // 0x8014B808: sw          $s3, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r19;
    // 0x8014B80C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x8014B810: jal         0x80143810
    // 0x8014B814: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    memcpy_recomp(rdram, ctx);
        goto after_0;
    // 0x8014B814: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    after_0:
    // 0x8014B818: lw          $t8, 0x24($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X24);
    // 0x8014B81C: subu        $t6, $t8, $s3
    ctx->r14 = SUB32(ctx->r24, ctx->r19);
    // 0x8014B820: b           L_8014BBAC
    // 0x8014B824: sw          $t6, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r14;
        goto L_8014BBAC;
    // 0x8014B824: sw          $t6, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r14;
L_8014B828:
    // 0x8014B828: beq         $at, $zero, L_8014B8A0
    if (ctx->r1 == 0) {
        // 0x8014B82C: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_8014B8A0;
    }
    // 0x8014B82C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8014B830: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x8014B834: lw          $t9, 0x14($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X14);
    // 0x8014B838: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8014B83C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x8014B840: jal         0x80143810
    // 0x8014B844: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    memcpy_recomp(rdram, ctx);
        goto after_1;
    // 0x8014B844: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    after_1:
    // 0x8014B848: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B84C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B850: subu        $t7, $s2, $s3
    ctx->r15 = SUB32(ctx->r18, ctx->r19);
    // 0x8014B854: addu        $t6, $t8, $s3
    ctx->r14 = ADD32(ctx->r24, ctx->r19);
    // 0x8014B858: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x8014B85C: bgtz        $v0, L_8014B874
    if (SIGNED(ctx->r2) > 0) {
        // 0x8014B860: sw          $t7, 0x18($s0)
        MEM_W(0X18, ctx->r16) = ctx->r15;
            goto L_8014B874;
    }
    // 0x8014B860: sw          $t7, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r15;
    // 0x8014B864: lw          $t9, 0x30($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X30);
    // 0x8014B868: andi        $t8, $t9, 0x8
    ctx->r24 = ctx->r25 & 0X8;
    // 0x8014B86C: beq         $t8, $zero, L_8014B898
    if (ctx->r24 == 0) {
        // 0x8014B870: nop
    
            goto L_8014B898;
    }
    // 0x8014B870: nop

L_8014B874:
    // 0x8014B874: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x8014B878: lw          $t9, 0x14($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X14);
    // 0x8014B87C: addiu       $t6, $zero, 0x2E
    ctx->r14 = ADD32(0, 0X2E);
    // 0x8014B880: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x8014B884: sb          $t6, 0x0($t8)
    MEM_B(0X0, ctx->r24) = ctx->r14;
    // 0x8014B888: lw          $t7, 0x1C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X1C);
    // 0x8014B88C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B890: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8014B894: sw          $t9, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r25;
L_8014B898:
    // 0x8014B898: b           L_8014BBAC
    // 0x8014B89C: sw          $v0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r2;
        goto L_8014BBAC;
    // 0x8014B89C: sw          $v0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r2;
L_8014B8A0:
    // 0x8014B8A0: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x8014B8A4: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B8A8: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    // 0x8014B8AC: jal         0x80143810
    // 0x8014B8B0: addu        $a0, $t6, $t8
    ctx->r4 = ADD32(ctx->r14, ctx->r24);
    memcpy_recomp(rdram, ctx);
        goto after_2;
    // 0x8014B8B0: addu        $a0, $t6, $t8
    ctx->r4 = ADD32(ctx->r14, ctx->r24);
    after_2:
    // 0x8014B8B4: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B8B8: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B8BC: subu        $s3, $s3, $s2
    ctx->r19 = SUB32(ctx->r19, ctx->r18);
    // 0x8014B8C0: sll         $t6, $s3, 16
    ctx->r14 = S32(ctx->r19 << 16);
    // 0x8014B8C4: addu        $t9, $t7, $s2
    ctx->r25 = ADD32(ctx->r15, ctx->r18);
    // 0x8014B8C8: sw          $t9, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r25;
    // 0x8014B8CC: bgtz        $v0, L_8014B8E4
    if (SIGNED(ctx->r2) > 0) {
        // 0x8014B8D0: sra         $s3, $t6, 16
        ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
            goto L_8014B8E4;
    }
    // 0x8014B8D0: sra         $s3, $t6, 16
    ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014B8D4: lw          $t7, 0x30($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X30);
    // 0x8014B8D8: andi        $t9, $t7, 0x8
    ctx->r25 = ctx->r15 & 0X8;
    // 0x8014B8DC: beql        $t9, $zero, L_8014B90C
    if (ctx->r25 == 0) {
        // 0x8014B8E0: slt         $at, $v0, $s3
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_8014B90C;
    }
    goto skip_3;
    // 0x8014B8E0: slt         $at, $v0, $s3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r19) ? 1 : 0;
    skip_3:
L_8014B8E4:
    // 0x8014B8E4: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x8014B8E8: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B8EC: addiu       $t6, $zero, 0x2E
    ctx->r14 = ADD32(0, 0X2E);
    // 0x8014B8F0: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x8014B8F4: sb          $t6, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r14;
    // 0x8014B8F8: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B8FC: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B900: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x8014B904: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x8014B908: slt         $at, $v0, $s3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r19) ? 1 : 0;
L_8014B90C:
    // 0x8014B90C: beq         $at, $zero, L_8014B920
    if (ctx->r1 == 0) {
        // 0x8014B910: addu        $a1, $s2, $s1
        ctx->r5 = ADD32(ctx->r18, ctx->r17);
            goto L_8014B920;
    }
    // 0x8014B910: addu        $a1, $s2, $s1
    ctx->r5 = ADD32(ctx->r18, ctx->r17);
    // 0x8014B914: sll         $s3, $v0, 16
    ctx->r19 = S32(ctx->r2 << 16);
    // 0x8014B918: sra         $t6, $s3, 16
    ctx->r14 = S32(SIGNED(ctx->r19) >> 16);
    // 0x8014B91C: or          $s3, $t6, $zero
    ctx->r19 = ctx->r14 | 0;
L_8014B920:
    // 0x8014B920: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x8014B924: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B928: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x8014B92C: jal         0x80143810
    // 0x8014B930: addu        $a0, $t9, $t8
    ctx->r4 = ADD32(ctx->r25, ctx->r24);
    memcpy_recomp(rdram, ctx);
        goto after_3;
    // 0x8014B930: addu        $a0, $t9, $t8
    ctx->r4 = ADD32(ctx->r25, ctx->r24);
    after_3:
    // 0x8014B934: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B938: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x8014B93C: addu        $t6, $t7, $s3
    ctx->r14 = ADD32(ctx->r15, ctx->r19);
    // 0x8014B940: subu        $t8, $t9, $s3
    ctx->r24 = SUB32(ctx->r25, ctx->r19);
    // 0x8014B944: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x8014B948: b           L_8014BBAC
    // 0x8014B94C: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
        goto L_8014BBAC;
    // 0x8014B94C: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
L_8014B950:
    // 0x8014B950: beq         $a0, $v1, L_8014B960
    if (ctx->r4 == ctx->r3) {
        // 0x8014B954: addiu       $at, $zero, 0x47
        ctx->r1 = ADD32(0, 0X47);
            goto L_8014B960;
    }
    // 0x8014B954: addiu       $at, $zero, 0x47
    ctx->r1 = ADD32(0, 0X47);
    // 0x8014B958: bnel        $v1, $at, L_8014B9A0
    if (ctx->r3 != ctx->r1) {
        // 0x8014B95C: lw          $t8, 0x8($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X8);
            goto L_8014B9A0;
    }
    goto skip_4;
    // 0x8014B95C: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    skip_4:
L_8014B960:
    // 0x8014B960: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B964: addiu       $s4, $zero, 0x45
    ctx->r20 = ADD32(0, 0X45);
    // 0x8014B968: slt         $at, $s3, $v0
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8014B96C: beql        $at, $zero, L_8014B980
    if (ctx->r1 == 0) {
        // 0x8014B970: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_8014B980;
    }
    goto skip_5;
    // 0x8014B970: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    skip_5:
    // 0x8014B974: sw          $s3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r19;
    // 0x8014B978: or          $v0, $s3, $zero
    ctx->r2 = ctx->r19 | 0;
    // 0x8014B97C: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
L_8014B980:
    // 0x8014B980: bgez        $t7, L_8014B98C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8014B984: sw          $t7, 0x24($s0)
        MEM_W(0X24, ctx->r16) = ctx->r15;
            goto L_8014B98C;
    }
    // 0x8014B984: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
    // 0x8014B988: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
L_8014B98C:
    // 0x8014B98C: bne         $a0, $v1, L_8014B99C
    if (ctx->r4 != ctx->r3) {
        // 0x8014B990: nop
    
            goto L_8014B99C;
    }
    // 0x8014B990: nop

    // 0x8014B994: b           L_8014B99C
    // 0x8014B998: addiu       $s4, $zero, 0x65
    ctx->r20 = ADD32(0, 0X65);
        goto L_8014B99C;
    // 0x8014B998: addiu       $s4, $zero, 0x65
    ctx->r20 = ADD32(0, 0X65);
L_8014B99C:
    // 0x8014B99C: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
L_8014B9A0:
    // 0x8014B9A0: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B9A4: lbu         $t9, 0x0($s1)
    ctx->r25 = MEM_BU(ctx->r17, 0X0);
    // 0x8014B9A8: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8014B9AC: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x8014B9B0: sb          $t9, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r25;
    // 0x8014B9B4: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014B9B8: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B9BC: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x8014B9C0: bgtz        $v0, L_8014B9D8
    if (SIGNED(ctx->r2) > 0) {
        // 0x8014B9C4: sw          $t7, 0x14($s0)
        MEM_W(0X14, ctx->r16) = ctx->r15;
            goto L_8014B9D8;
    }
    // 0x8014B9C4: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x8014B9C8: lw          $t9, 0x30($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X30);
    // 0x8014B9CC: andi        $t6, $t9, 0x8
    ctx->r14 = ctx->r25 & 0X8;
    // 0x8014B9D0: beq         $t6, $zero, L_8014B9FC
    if (ctx->r14 == 0) {
        // 0x8014B9D4: nop
    
            goto L_8014B9FC;
    }
    // 0x8014B9D4: nop

L_8014B9D8:
    // 0x8014B9D8: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x8014B9DC: lw          $t9, 0x14($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X14);
    // 0x8014B9E0: addiu       $t8, $zero, 0x2E
    ctx->r24 = ADD32(0, 0X2E);
    // 0x8014B9E4: addu        $t6, $t7, $t9
    ctx->r14 = ADD32(ctx->r15, ctx->r25);
    // 0x8014B9E8: sb          $t8, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r24;
    // 0x8014B9EC: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014B9F0: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x8014B9F4: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x8014B9F8: sw          $t9, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r25;
L_8014B9FC:
    // 0x8014B9FC: blezl       $v0, L_8014BA58
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8014BA00: lw          $t6, 0x8($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X8);
            goto L_8014BA58;
    }
    goto skip_6;
    // 0x8014BA00: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    skip_6:
    // 0x8014BA04: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8014BA08: sll         $t8, $s3, 16
    ctx->r24 = S32(ctx->r19 << 16);
    // 0x8014BA0C: sra         $s3, $t8, 16
    ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8014BA10: slt         $at, $v0, $s3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8014BA14: beq         $at, $zero, L_8014BA28
    if (ctx->r1 == 0) {
        // 0x8014BA18: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_8014BA28;
    }
    // 0x8014BA18: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8014BA1C: sll         $s3, $v0, 16
    ctx->r19 = S32(ctx->r2 << 16);
    // 0x8014BA20: sra         $t7, $s3, 16
    ctx->r15 = S32(SIGNED(ctx->r19) >> 16);
    // 0x8014BA24: or          $s3, $t7, $zero
    ctx->r19 = ctx->r15 | 0;
L_8014BA28:
    // 0x8014BA28: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x8014BA2C: lw          $t8, 0x14($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X14);
    // 0x8014BA30: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x8014BA34: jal         0x80143810
    // 0x8014BA38: addu        $a0, $t9, $t8
    ctx->r4 = ADD32(ctx->r25, ctx->r24);
    memcpy_recomp(rdram, ctx);
        goto after_4;
    // 0x8014BA38: addu        $a0, $t9, $t8
    ctx->r4 = ADD32(ctx->r25, ctx->r24);
    after_4:
    // 0x8014BA3C: lw          $t6, 0x14($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X14);
    // 0x8014BA40: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x8014BA44: addu        $t7, $t6, $s3
    ctx->r15 = ADD32(ctx->r14, ctx->r19);
    // 0x8014BA48: subu        $t8, $t9, $s3
    ctx->r24 = SUB32(ctx->r25, ctx->r19);
    // 0x8014BA4C: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x8014BA50: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
    // 0x8014BA54: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
L_8014BA58:
    // 0x8014BA58: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014BA5C: addu        $s1, $t6, $t7
    ctx->r17 = ADD32(ctx->r14, ctx->r15);
    // 0x8014BA60: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8014BA64: bltz        $s2, L_8014BA7C
    if (SIGNED(ctx->r18) < 0) {
        // 0x8014BA68: sb          $s4, -0x1($s1)
        MEM_B(-0X1, ctx->r17) = ctx->r20;
            goto L_8014BA7C;
    }
    // 0x8014BA68: sb          $s4, -0x1($s1)
    MEM_B(-0X1, ctx->r17) = ctx->r20;
    // 0x8014BA6C: addiu       $t9, $zero, 0x2B
    ctx->r25 = ADD32(0, 0X2B);
    // 0x8014BA70: sb          $t9, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r25;
    // 0x8014BA74: b           L_8014BA98
    // 0x8014BA78: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
        goto L_8014BA98;
    // 0x8014BA78: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
L_8014BA7C:
    // 0x8014BA7C: negu        $s2, $s2
    ctx->r18 = SUB32(0, ctx->r18);
    // 0x8014BA80: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8014BA84: addiu       $t8, $zero, 0x2D
    ctx->r24 = ADD32(0, 0X2D);
    // 0x8014BA88: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014BA8C: sb          $t8, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r24;
    // 0x8014BA90: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8014BA94: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
L_8014BA98:
    // 0x8014BA98: slti        $at, $s2, 0x64
    ctx->r1 = SIGNED(ctx->r18) < 0X64 ? 1 : 0;
    // 0x8014BA9C: bnel        $at, $zero, L_8014BB48
    if (ctx->r1 != 0) {
        // 0x8014BAA0: addiu       $v0, $zero, 0xA
        ctx->r2 = ADD32(0, 0XA);
            goto L_8014BB48;
    }
    goto skip_7;
    // 0x8014BAA0: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
    skip_7:
    // 0x8014BAA4: slti        $at, $s2, 0x3E8
    ctx->r1 = SIGNED(ctx->r18) < 0X3E8 ? 1 : 0;
    // 0x8014BAA8: bne         $at, $zero, L_8014BAF8
    if (ctx->r1 != 0) {
        // 0x8014BAAC: addiu       $v0, $zero, 0x3E8
        ctx->r2 = ADD32(0, 0X3E8);
            goto L_8014BAF8;
    }
    // 0x8014BAAC: addiu       $v0, $zero, 0x3E8
    ctx->r2 = ADD32(0, 0X3E8);
    // 0x8014BAB0: div         $zero, $s2, $v0
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r2)));
    // 0x8014BAB4: bne         $v0, $zero, L_8014BAC0
    if (ctx->r2 != 0) {
        // 0x8014BAB8: nop
    
            goto L_8014BAC0;
    }
    // 0x8014BAB8: nop

    // 0x8014BABC: break       7
    do_break(2148842172);
L_8014BAC0:
    // 0x8014BAC0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8014BAC4: bne         $v0, $at, L_8014BAD8
    if (ctx->r2 != ctx->r1) {
        // 0x8014BAC8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8014BAD8;
    }
    // 0x8014BAC8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8014BACC: bne         $s2, $at, L_8014BAD8
    if (ctx->r18 != ctx->r1) {
        // 0x8014BAD0: nop
    
            goto L_8014BAD8;
    }
    // 0x8014BAD0: nop

    // 0x8014BAD4: break       6
    do_break(2148842196);
L_8014BAD8:
    // 0x8014BAD8: mfhi        $s2
    ctx->r18 = hi;
    // 0x8014BADC: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8014BAE0: mflo        $t9
    ctx->r25 = lo;
    // 0x8014BAE4: addiu       $t8, $t9, 0x30
    ctx->r24 = ADD32(ctx->r25, 0X30);
    // 0x8014BAE8: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014BAEC: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
    // 0x8014BAF0: sb          $t8, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r24;
    // 0x8014BAF4: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
L_8014BAF8:
    // 0x8014BAF8: addiu       $v0, $zero, 0x64
    ctx->r2 = ADD32(0, 0X64);
    // 0x8014BAFC: div         $zero, $s2, $v0
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r2)));
    // 0x8014BB00: bne         $v0, $zero, L_8014BB0C
    if (ctx->r2 != 0) {
        // 0x8014BB04: nop
    
            goto L_8014BB0C;
    }
    // 0x8014BB04: nop

    // 0x8014BB08: break       7
    do_break(2148842248);
L_8014BB0C:
    // 0x8014BB0C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8014BB10: bne         $v0, $at, L_8014BB24
    if (ctx->r2 != ctx->r1) {
        // 0x8014BB14: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8014BB24;
    }
    // 0x8014BB14: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8014BB18: bne         $s2, $at, L_8014BB24
    if (ctx->r18 != ctx->r1) {
        // 0x8014BB1C: nop
    
            goto L_8014BB24;
    }
    // 0x8014BB1C: nop

    // 0x8014BB20: break       6
    do_break(2148842272);
L_8014BB24:
    // 0x8014BB24: mfhi        $s2
    ctx->r18 = hi;
    // 0x8014BB28: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8014BB2C: mflo        $t9
    ctx->r25 = lo;
    // 0x8014BB30: addiu       $t8, $t9, 0x30
    ctx->r24 = ADD32(ctx->r25, 0X30);
    // 0x8014BB34: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014BB38: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
    // 0x8014BB3C: sb          $t8, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r24;
    // 0x8014BB40: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8014BB44: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
L_8014BB48:
    // 0x8014BB48: div         $zero, $s2, $v0
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r2)));
    // 0x8014BB4C: bne         $v0, $zero, L_8014BB58
    if (ctx->r2 != 0) {
        // 0x8014BB50: nop
    
            goto L_8014BB58;
    }
    // 0x8014BB50: nop

    // 0x8014BB54: break       7
    do_break(2148842324);
L_8014BB58:
    // 0x8014BB58: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8014BB5C: bne         $v0, $at, L_8014BB70
    if (ctx->r2 != ctx->r1) {
        // 0x8014BB60: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8014BB70;
    }
    // 0x8014BB60: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8014BB64: bne         $s2, $at, L_8014BB70
    if (ctx->r18 != ctx->r1) {
        // 0x8014BB68: nop
    
            goto L_8014BB70;
    }
    // 0x8014BB68: nop

    // 0x8014BB6C: break       6
    do_break(2148842348);
L_8014BB70:
    // 0x8014BB70: mfhi        $s2
    ctx->r18 = hi;
    // 0x8014BB74: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x8014BB78: mflo        $t9
    ctx->r25 = lo;
    // 0x8014BB7C: addiu       $t8, $t9, 0x30
    ctx->r24 = ADD32(ctx->r25, 0X30);
    // 0x8014BB80: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8014BB84: addiu       $t9, $t7, 0x30
    ctx->r25 = ADD32(ctx->r15, 0X30);
    // 0x8014BB88: sb          $t8, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r24;
    // 0x8014BB8C: sb          $t9, 0x1($s1)
    MEM_B(0X1, ctx->r17) = ctx->r25;
    // 0x8014BB90: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x8014BB94: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
    // 0x8014BB98: lw          $t7, 0x14($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X14);
    // 0x8014BB9C: addiu       $s1, $s1, 0x2
    ctx->r17 = ADD32(ctx->r17, 0X2);
    // 0x8014BBA0: subu        $t6, $s1, $t8
    ctx->r14 = SUB32(ctx->r17, ctx->r24);
    // 0x8014BBA4: subu        $t9, $t6, $t7
    ctx->r25 = SUB32(ctx->r14, ctx->r15);
    // 0x8014BBA8: sw          $t9, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r25;
L_8014BBAC:
    // 0x8014BBAC: lw          $t8, 0x30($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X30);
    // 0x8014BBB0: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x8014BBB4: andi        $t6, $t8, 0x14
    ctx->r14 = ctx->r24 & 0X14;
    // 0x8014BBB8: bnel        $t6, $at, L_8014BBFC
    if (ctx->r14 != ctx->r1) {
        // 0x8014BBBC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8014BBFC;
    }
    goto skip_8;
    // 0x8014BBBC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x8014BBC0: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    // 0x8014BBC4: lw          $t9, 0x14($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X14);
    // 0x8014BBC8: lw          $t6, 0x18($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X18);
    // 0x8014BBCC: lw          $v1, 0x28($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X28);
    // 0x8014BBD0: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x8014BBD4: lw          $t9, 0x1C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X1C);
    // 0x8014BBD8: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x8014BBDC: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x8014BBE0: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x8014BBE4: addu        $v0, $t8, $t6
    ctx->r2 = ADD32(ctx->r24, ctx->r14);
    // 0x8014BBE8: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8014BBEC: beq         $at, $zero, L_8014BBF8
    if (ctx->r1 == 0) {
        // 0x8014BBF0: subu        $t7, $v1, $v0
        ctx->r15 = SUB32(ctx->r3, ctx->r2);
            goto L_8014BBF8;
    }
    // 0x8014BBF0: subu        $t7, $v1, $v0
    ctx->r15 = SUB32(ctx->r3, ctx->r2);
    // 0x8014BBF4: sw          $t7, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r15;
L_8014BBF8:
    // 0x8014BBF8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8014BBFC:
    // 0x8014BBFC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8014BC00: jr          $ra
    // 0x8014BC04: nop

    return;
    // 0x8014BC04: nop

    // 0x8014BC08: jr          $ra
    // 0x8014BC0C: nop

    return;
    // 0x8014BC0C: nop

;}
RECOMP_FUNC void static_0_80145BE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80145BE4: addiu       $sp, $sp, -0xE8
    ctx->r29 = ADD32(ctx->r29, -0XE8);
    // 0x80145BE8: bne         $a0, $zero, L_80145C18
    if (ctx->r4 != 0) {
        // 0x80145BEC: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_80145C18;
    }
    // 0x80145BEC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80145BF0: c.le.d      $f16, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.d <= ctx->f14.d;
    // 0x80145BF4: ori         $t6, $zero, 0xFFFF
    ctx->r14 = 0 | 0XFFFF;
    // 0x80145BF8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80145BFC: bc1f        L_80145C10
    if (!c1cs) {
        // 0x80145C00: nop
    
            goto L_80145C10;
    }
    // 0x80145C00: nop

    // 0x80145C04: sh          $t6, 0x0($s1)
    MEM_H(0X0, ctx->r17) = ctx->r14;
    // 0x80145C08: b           L_80145DA4
    // 0x80145C0C: addiu       $v0, $zero, 0x7FFF
    ctx->r2 = ADD32(0, 0X7FFF);
        goto L_80145DA4;
    // 0x80145C0C: addiu       $v0, $zero, 0x7FFF
    ctx->r2 = ADD32(0, 0X7FFF);
L_80145C10:
    // 0x80145C10: b           L_80145DA4
    // 0x80145C14: sh          $zero, 0x0($s1)
    MEM_H(0X0, ctx->r17) = 0;
        goto L_80145DA4;
    // 0x80145C14: sh          $zero, 0x0($s1)
    MEM_H(0X0, ctx->r17) = 0;
L_80145C18:
    // 0x80145C18: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80145C1C: mtc1        $at, $f23
    ctx->f_odd[(23 - 1) * 2] = ctx->r1;
    // 0x80145C20: mtc1        $zero, $f22
    ctx->f22.u32l = 0;
    // 0x80145C24: mtc1        $zero, $f5
    ctx->f_odd[(5 - 1) * 2] = 0;
    // 0x80145C28: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80145C2C: c.lt.d      $f14, $f22
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 22);
    c1cs = ctx->f14.d < ctx->f22.d;
    // 0x80145C30: addiu       $s2, $sp, 0x68
    ctx->r18 = ADD32(ctx->r29, 0X68);
    // 0x80145C34: lui         $t7, 0x8016
    ctx->r15 = S32(0X8016 << 16);
    // 0x80145C38: addiu       $t7, $t7, -0x5510
    ctx->r15 = ADD32(ctx->r15, -0X5510);
    // 0x80145C3C: bc1f        L_80145C48
    if (!c1cs) {
        // 0x80145C40: or          $t6, $s2, $zero
        ctx->r14 = ctx->r18 | 0;
            goto L_80145C48;
    }
    // 0x80145C40: or          $t6, $s2, $zero
    ctx->r14 = ctx->r18 | 0;
    // 0x80145C44: mov.d       $f14, $f22
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 22);
    ctx->f14.d = ctx->f22.d;
L_80145C48:
    // 0x80145C48: c.le.d      $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f16.d <= ctx->f4.d;
    // 0x80145C4C: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80145C50: addiu       $t9, $t7, 0x3C
    ctx->r25 = ADD32(ctx->r15, 0X3C);
    // 0x80145C54: bc1f        L_80145C68
    if (!c1cs) {
        // 0x80145C58: nop
    
            goto L_80145C68;
    }
    // 0x80145C58: nop

    // 0x80145C5C: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x80145C60: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x80145C64: nop

L_80145C68:
    // 0x80145C68: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x80145C6C: addiu       $t7, $t7, 0xC
    ctx->r15 = ADD32(ctx->r15, 0XC);
    // 0x80145C70: addiu       $t6, $t6, 0xC
    ctx->r14 = ADD32(ctx->r14, 0XC);
    // 0x80145C74: sw          $at, -0xC($t6)
    MEM_W(-0XC, ctx->r14) = ctx->r1;
    // 0x80145C78: lw          $at, -0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, -0X8);
    // 0x80145C7C: sw          $at, -0x8($t6)
    MEM_W(-0X8, ctx->r14) = ctx->r1;
    // 0x80145C80: lw          $at, -0x4($t7)
    ctx->r1 = MEM_W(ctx->r15, -0X4);
    // 0x80145C84: bne         $t7, $t9, L_80145C68
    if (ctx->r15 != ctx->r25) {
        // 0x80145C88: sw          $at, -0x4($t6)
        MEM_W(-0X4, ctx->r14) = ctx->r1;
            goto L_80145C68;
    }
    // 0x80145C88: sw          $at, -0x4($t6)
    MEM_W(-0X4, ctx->r14) = ctx->r1;
    // 0x80145C8C: mtc1        $a0, $f8
    ctx->f8.u32l = ctx->r4;
    // 0x80145C90: lui         $t8, 0x4000
    ctx->r24 = S32(0X4000 << 16);
    // 0x80145C94: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x80145C98: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80145C9C: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x80145CA0: addiu       $a2, $sp, 0xB0
    ctx->r6 = ADD32(ctx->r29, 0XB0);
    // 0x80145CA4: cvt.d.w     $f20, $f6
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 6);
    ctx->f20.d = CVT_D_W(ctx->f6.u32l);
    // 0x80145CA8: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x80145CAC: div.d       $f4, $f22, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f22.d); NAN_CHECK(ctx->f10.d); 
    ctx->f4.d = DIV_D(ctx->f22.d, ctx->f10.d);
    // 0x80145CB0: div.d       $f12, $f14, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f14.d); NAN_CHECK(ctx->f16.d); 
    ctx->f12.d = DIV_D(ctx->f14.d, ctx->f16.d);
    // 0x80145CB4: mul.d       $f2, $f4, $f20
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f20.d); 
    ctx->f2.d = MUL_D(ctx->f4.d, ctx->f20.d);
    // 0x80145CB8: trunc.w.d   $f6, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    ctx->f6.u32l = TRUNC_W_D(ctx->f2.d);
    // 0x80145CBC: mfc1        $s0, $f6
    ctx->r16 = (int32_t)ctx->f6.u32l;
    // 0x80145CC0: jal         0x80145A18
    // 0x80145CC4: nop

    _frexpf(rdram, ctx);
        goto after_0;
    // 0x80145CC4: nop

    after_0:
    // 0x80145CC8: addiu       $t7, $zero, 0x10
    ctx->r15 = ADD32(0, 0X10);
    // 0x80145CCC: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x80145CD0: lw          $t6, 0xB0($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XB0);
    // 0x80145CD4: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80145CD8: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80145CDC: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80145CE0: mul.d       $f2, $f0, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f10.d); 
    ctx->f2.d = MUL_D(ctx->f0.d, ctx->f10.d);
    // 0x80145CE4: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80145CE8: ldc1        $f8, -0x49A0($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, -0X49A0);
    // 0x80145CEC: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80145CF0: trunc.w.d   $f4, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    ctx->f4.u32l = TRUNC_W_D(ctx->f2.d);
    // 0x80145CF4: mov.d       $f2, $f22
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 22);
    ctx->f2.d = ctx->f22.d;
    // 0x80145CF8: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
    // 0x80145CFC: nop

    // 0x80145D00: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x80145D04: addu        $t7, $s2, $t9
    ctx->r15 = ADD32(ctx->r18, ctx->r25);
    // 0x80145D08: ldc1        $f6, -0x40($t7)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r15, -0X40);
    // 0x80145D0C: add.d       $f4, $f6, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f10.d); 
    ctx->f4.d = ctx->f6.d + ctx->f10.d;
    // 0x80145D10: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80145D14: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80145D18: mul.d       $f12, $f4, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f8.d); 
    ctx->f12.d = MUL_D(ctx->f4.d, ctx->f8.d);
    // 0x80145D1C: nop

    // 0x80145D20: mul.d       $f14, $f6, $f20
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f20.d); 
    ctx->f14.d = MUL_D(ctx->f6.d, ctx->f20.d);
    // 0x80145D24: div.d       $f12, $f12, $f14
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.d); NAN_CHECK(ctx->f14.d); 
    ctx->f12.d = DIV_D(ctx->f12.d, ctx->f14.d);
    // 0x80145D28: beq         $s0, $zero, L_80145D50
    if (ctx->r16 == 0) {
        // 0x80145D2C: add.d       $f0, $f22, $f12
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f22.d); NAN_CHECK(ctx->f12.d); 
    ctx->f0.d = ctx->f22.d + ctx->f12.d;
            goto L_80145D50;
    }
    // 0x80145D2C: add.d       $f0, $f22, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f22.d); NAN_CHECK(ctx->f12.d); 
    ctx->f0.d = ctx->f22.d + ctx->f12.d;
L_80145D30:
    // 0x80145D30: andi        $t8, $s0, 0x1
    ctx->r24 = ctx->r16 & 0X1;
    // 0x80145D34: beq         $t8, $zero, L_80145D44
    if (ctx->r24 == 0) {
        // 0x80145D38: sra         $t9, $s0, 1
        ctx->r25 = S32(SIGNED(ctx->r16) >> 1);
            goto L_80145D44;
    }
    // 0x80145D38: sra         $t9, $s0, 1
    ctx->r25 = S32(SIGNED(ctx->r16) >> 1);
    // 0x80145D3C: mul.d       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f0.d); 
    ctx->f2.d = MUL_D(ctx->f2.d, ctx->f0.d);
    // 0x80145D40: nop

L_80145D44:
    // 0x80145D44: mul.d       $f0, $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f0.d); 
    ctx->f0.d = MUL_D(ctx->f0.d, ctx->f0.d);
    // 0x80145D48: bne         $t9, $zero, L_80145D30
    if (ctx->r25 != 0) {
        // 0x80145D4C: or          $s0, $t9, $zero
        ctx->r16 = ctx->r25 | 0;
            goto L_80145D30;
    }
    // 0x80145D4C: or          $s0, $t9, $zero
    ctx->r16 = ctx->r25 | 0;
L_80145D50:
    // 0x80145D50: mul.d       $f0, $f2, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f2.d); 
    ctx->f0.d = MUL_D(ctx->f2.d, ctx->f2.d);
    // 0x80145D54: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80145D58: mul.d       $f12, $f0, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f0.d); 
    ctx->f12.d = MUL_D(ctx->f0.d, ctx->f0.d);
    // 0x80145D5C: nop

    // 0x80145D60: mul.d       $f2, $f12, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.d); NAN_CHECK(ctx->f12.d); 
    ctx->f2.d = MUL_D(ctx->f12.d, ctx->f12.d);
    // 0x80145D64: trunc.w.d   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_D(ctx->f2.d);
    // 0x80145D68: mfc1        $v1, $f10
    ctx->r3 = (int32_t)ctx->f10.u32l;
    // 0x80145D6C: nop

    // 0x80145D70: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x80145D74: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80145D78: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x80145D7C: nop

    // 0x80145D80: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80145D84: ldc1        $f4, -0x4998($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, -0X4998);
    // 0x80145D88: cvt.d.s     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f6.d = CVT_D_S(ctx->f8.fl);
    // 0x80145D8C: sub.d       $f10, $f2, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = ctx->f2.d - ctx->f6.d;
    // 0x80145D90: mul.d       $f8, $f10, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f4.d); 
    ctx->f8.d = MUL_D(ctx->f10.d, ctx->f4.d);
    // 0x80145D94: trunc.w.d   $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.u32l = TRUNC_W_D(ctx->f8.d);
    // 0x80145D98: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x80145D9C: nop

    // 0x80145DA0: sh          $t7, 0x0($s1)
    MEM_H(0X0, ctx->r17) = ctx->r15;
L_80145DA4:
    // 0x80145DA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80145DA8: addiu       $sp, $sp, 0xE8
    ctx->r29 = ADD32(ctx->r29, 0XE8);
    // 0x80145DAC: jr          $ra
    // 0x80145DB0: nop

    return;
    // 0x80145DB0: nop

;}
RECOMP_FUNC void static_2_8029B7D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8029B7D0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8029B7D4: lh          $t1, 0x5534($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5534);
    // 0x8029B7D8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8029B7DC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8029B7E0: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x8029B7E4: addu        $v0, $v0, $t2
    ctx->r2 = ADD32(ctx->r2, ctx->r10);
    // 0x8029B7E8: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8029B7EC: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8029B7F0: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8029B7F4: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x8029B7F8: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x8029B7FC: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8029B800: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x8029B804: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8029B808: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8029B80C: subu        $v1, $t8, $t3
    ctx->r3 = SUB32(ctx->r24, ctx->r11);
    // 0x8029B810: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8029B814: bgez        $v1, L_8029B824
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8029B818: or          $a3, $t6, $zero
        ctx->r7 = ctx->r14 | 0;
            goto L_8029B824;
    }
    // 0x8029B818: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8029B81C: b           L_8029B828
    // 0x8029B820: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_8029B828;
    // 0x8029B820: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_8029B824:
    // 0x8029B824: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_8029B828:
    // 0x8029B828: lh          $t4, 0x4($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X4);
    // 0x8029B82C: subu        $v1, $a3, $t4
    ctx->r3 = SUB32(ctx->r7, ctx->r12);
    // 0x8029B830: bgez        $v1, L_8029B840
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8029B834: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_8029B840;
    }
    // 0x8029B834: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8029B838: b           L_8029B840
    // 0x8029B83C: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
        goto L_8029B840;
    // 0x8029B83C: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
L_8029B840:
    // 0x8029B840: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x8029B844: subu        $v1, $a2, $t5
    ctx->r3 = SUB32(ctx->r6, ctx->r13);
    // 0x8029B848: bgez        $v1, L_8029B858
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8029B84C: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_8029B858;
    }
    // 0x8029B84C: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x8029B850: b           L_8029B858
    // 0x8029B854: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_8029B858;
    // 0x8029B854: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_8029B858:
    // 0x8029B858: addu        $t6, $a2, $a1
    ctx->r14 = ADD32(ctx->r6, ctx->r5);
    // 0x8029B85C: addu        $v0, $t6, $a0
    ctx->r2 = ADD32(ctx->r14, ctx->r4);
    // 0x8029B860: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8029B864: jr          $ra
    // 0x8029B868: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    return;
    // 0x8029B868: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8029B86C: nop

;}
RECOMP_FUNC void static_2_802C7F88(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802C7F88: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802C7F8C: addiu       $t1, $t1, 0x553E
    ctx->r9 = ADD32(ctx->r9, 0X553E);
    // 0x802C7F90: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802C7F94: lh          $v1, 0x0($t1)
    ctx->r3 = MEM_H(ctx->r9, 0X0);
    // 0x802C7F98: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802C7F9C: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802C7FA0: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x802C7FA4: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x802C7FA8: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x802C7FAC: blez        $v1, L_802C7FF0
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802C7FB0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802C7FF0;
    }
    // 0x802C7FB0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802C7FB4: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802C7FB8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802C7FBC: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802C7FC0: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
L_802C7FC4:
    // 0x802C7FC4: addu        $t7, $a3, $t6
    ctx->r15 = ADD32(ctx->r7, ctx->r14);
    // 0x802C7FC8: lw          $t8, 0x3EB4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X3EB4);
    // 0x802C7FCC: lbu         $t9, 0x366($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X366);
    // 0x802C7FD0: beq         $a0, $t9, L_802C7FF0
    if (ctx->r4 == ctx->r25) {
        // 0x802C7FD4: nop
    
            goto L_802C7FF0;
    }
    // 0x802C7FD4: nop

    // 0x802C7FD8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802C7FDC: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x802C7FE0: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802C7FE4: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802C7FE8: bnel        $at, $zero, L_802C7FC4
    if (ctx->r1 != 0) {
        // 0x802C7FEC: sll         $t6, $v0, 3
        ctx->r14 = S32(ctx->r2 << 3);
            goto L_802C7FC4;
    }
    goto skip_0;
    // 0x802C7FEC: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
    skip_0:
L_802C7FF0:
    // 0x802C7FF0: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802C7FF4: bne         $v0, $v1, L_802C8014
    if (ctx->r2 != ctx->r3) {
        // 0x802C7FF8: addiu       $a3, $a3, -0x6128
        ctx->r7 = ADD32(ctx->r7, -0X6128);
            goto L_802C8014;
    }
    // 0x802C7FF8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802C7FFC: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x802C8000: sra         $t7, $t0, 16
    ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802C8004: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x802C8008: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x802C800C: b           L_802C8020
    // 0x802C8010: sh          $t8, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r24;
        goto L_802C8020;
    // 0x802C8010: sh          $t8, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r24;
L_802C8014:
    // 0x802C8014: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802C8018: sra         $t9, $t0, 16
    ctx->r25 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802C801C: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
L_802C8020:
    // 0x802C8020: sll         $t5, $t0, 3
    ctx->r13 = S32(ctx->r8 << 3);
    // 0x802C8024: addu        $v0, $a3, $t5
    ctx->r2 = ADD32(ctx->r7, ctx->r13);
    // 0x802C8028: addiu       $a0, $v0, 0x3EB0
    ctx->r4 = ADD32(ctx->r2, 0X3EB0);
    // 0x802C802C: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802C8030: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802C8034: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802C8038: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    // 0x802C803C: jal         0x80129090
    // 0x802C8040: sh          $t0, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r8;
    memset_bytes(rdram, ctx);
        goto after_0;
    // 0x802C8040: sh          $t0, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r8;
    after_0:
    // 0x802C8044: lh          $t0, 0x2A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X2A);
    // 0x802C8048: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802C804C: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802C8050: sll         $t6, $t0, 4
    ctx->r14 = S32(ctx->r8 << 4);
    // 0x802C8054: subu        $t6, $t6, $t0
    ctx->r14 = SUB32(ctx->r14, ctx->r8);
    // 0x802C8058: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802C805C: addu        $t6, $t6, $t0
    ctx->r14 = ADD32(ctx->r14, ctx->r8);
    // 0x802C8060: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802C8064: addu        $t6, $t6, $t0
    ctx->r14 = ADD32(ctx->r14, ctx->r8);
    // 0x802C8068: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802C806C: addu        $a0, $a3, $t6
    ctx->r4 = ADD32(ctx->r7, ctx->r14);
    // 0x802C8070: addiu       $a0, $a0, 0x4040
    ctx->r4 = ADD32(ctx->r4, 0X4040);
    // 0x802C8074: sw          $a0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r4;
    // 0x802C8078: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802C807C: jal         0x80129090
    // 0x802C8080: addiu       $a2, $zero, 0x3D4
    ctx->r6 = ADD32(0, 0X3D4);
    memset_bytes(rdram, ctx);
        goto after_1;
    // 0x802C8080: addiu       $a2, $zero, 0x3D4
    ctx->r6 = ADD32(0, 0X3D4);
    after_1:
    // 0x802C8084: lh          $t7, 0x46($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X46);
    // 0x802C8088: lw          $t4, 0x24($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X24);
    // 0x802C808C: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x802C8090: sll         $t8, $t7, 4
    ctx->r24 = S32(ctx->r15 << 4);
    // 0x802C8094: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x802C8098: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802C809C: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802C80A0: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x802C80A4: lw          $t9, 0x20($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X20);
    // 0x802C80A8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802C80AC: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802C80B0: addu        $v1, $a3, $t8
    ctx->r3 = ADD32(ctx->r7, ctx->r24);
    // 0x802C80B4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802C80B8: sw          $v1, 0x3EB0($t4)
    MEM_W(0X3EB0, ctx->r12) = ctx->r3;
    // 0x802C80BC: sw          $a1, 0x3EB4($t4)
    MEM_W(0X3EB4, ctx->r12) = ctx->r5;
    // 0x802C80C0: sw          $t9, 0x5520($at)
    MEM_W(0X5520, ctx->r1) = ctx->r25;
    // 0x802C80C4: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802C80C8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802C80CC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802C80D0: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802C80D4: addiu       $t3, $t3, 0x5528
    ctx->r11 = ADD32(ctx->r11, 0X5528);
    // 0x802C80D8: addiu       $t2, $t2, 0x5524
    ctx->r10 = ADD32(ctx->r10, 0X5524);
    // 0x802C80DC: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802C80E0: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802C80E4: sw          $v1, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r3;
    // 0x802C80E8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802C80EC: sw          $a1, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r5;
    // 0x802C80F0: sw          $a1, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r5;
    // 0x802C80F4: sw          $a1, 0x0($t3)
    MEM_W(0X0, ctx->r11) = ctx->r5;
    // 0x802C80F8: lh          $t0, 0x2A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X2A);
    // 0x802C80FC: lh          $t5, 0x5534($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5534);
    // 0x802C8100: bne         $t0, $t5, L_802C8114
    if (ctx->r8 != ctx->r13) {
        // 0x802C8104: addiu       $a0, $zero, 0x1
        ctx->r4 = ADD32(0, 0X1);
            goto L_802C8114;
    }
    // 0x802C8104: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x802C8108: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802C810C: b           L_802C8120
    // 0x802C8110: sb          $a0, 0x5538($at)
    MEM_B(0X5538, ctx->r1) = ctx->r4;
        goto L_802C8120;
    // 0x802C8110: sb          $a0, 0x5538($at)
    MEM_B(0X5538, ctx->r1) = ctx->r4;
L_802C8114:
    // 0x802C8114: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802C8118: sb          $zero, 0x5538($at)
    MEM_B(0X5538, ctx->r1) = 0;
    // 0x802C811C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_802C8120:
    // 0x802C8120: lb          $t6, 0x4B($sp)
    ctx->r14 = MEM_B(ctx->r29, 0X4B);
    // 0x802C8124: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802C8128: sh          $t0, 0x553C($at)
    MEM_H(0X553C, ctx->r1) = ctx->r8;
    // 0x802C812C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802C8130: beq         $t6, $zero, L_802C8144
    if (ctx->r14 == 0) {
        // 0x802C8134: sh          $zero, 0x553A($at)
        MEM_H(0X553A, ctx->r1) = 0;
            goto L_802C8144;
    }
    // 0x802C8134: sh          $zero, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = 0;
    // 0x802C8138: sb          $a0, 0x366($a1)
    MEM_B(0X366, ctx->r5) = ctx->r4;
    // 0x802C813C: b           L_802C8164
    // 0x802C8140: lh          $v1, 0x42($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X42);
        goto L_802C8164;
    // 0x802C8140: lh          $v1, 0x42($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X42);
L_802C8144:
    // 0x802C8144: lh          $v1, 0x42($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X42);
    // 0x802C8148: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802C814C: addiu       $t8, $zero, 0x5
    ctx->r24 = ADD32(0, 0X5);
    // 0x802C8150: blezl       $v1, L_802C8164
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802C8154: sb          $t8, 0x366($a1)
        MEM_B(0X366, ctx->r5) = ctx->r24;
            goto L_802C8164;
    }
    goto skip_1;
    // 0x802C8154: sb          $t8, 0x366($a1)
    MEM_B(0X366, ctx->r5) = ctx->r24;
    skip_1:
    // 0x802C8158: b           L_802C8164
    // 0x802C815C: sb          $t7, 0x366($a1)
    MEM_B(0X366, ctx->r5) = ctx->r15;
        goto L_802C8164;
    // 0x802C815C: sb          $t7, 0x366($a1)
    MEM_B(0X366, ctx->r5) = ctx->r15;
    // 0x802C8160: sb          $t8, 0x366($a1)
    MEM_B(0X366, ctx->r5) = ctx->r24;
L_802C8164:
    // 0x802C8164: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802C8168: lh          $a1, 0x3E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X3E);
    // 0x802C816C: sh          $zero, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = 0;
    // 0x802C8170: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x802C8174: sh          $a1, 0x2C($t5)
    MEM_H(0X2C, ctx->r13) = ctx->r5;
    // 0x802C8178: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802C817C: sh          $a1, 0x302($t6)
    MEM_H(0X302, ctx->r14) = ctx->r5;
    // 0x802C8180: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802C8184: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802C8188: sh          $zero, 0x2F2($t7)
    MEM_H(0X2F2, ctx->r15) = 0;
    // 0x802C818C: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x802C8190: sh          $zero, 0x2F4($t8)
    MEM_H(0X2F4, ctx->r24) = 0;
    // 0x802C8194: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802C8198: sh          $zero, 0x2F6($t9)
    MEM_H(0X2F6, ctx->r25) = 0;
    // 0x802C819C: lw          $t5, 0x0($t1)
    ctx->r13 = MEM_W(ctx->r9, 0X0);
    // 0x802C81A0: sh          $zero, 0x2F8($t5)
    MEM_H(0X2F8, ctx->r13) = 0;
    // 0x802C81A4: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802C81A8: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802C81AC: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802C81B0: sb          $a0, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r4;
    // 0x802C81B4: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x802C81B8: sb          $zero, 0x160($t9)
    MEM_B(0X160, ctx->r25) = 0;
    // 0x802C81BC: lw          $t5, 0x0($t2)
    ctx->r13 = MEM_W(ctx->r10, 0X0);
    // 0x802C81C0: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x802C81C4: sw          $t5, 0x16C($t6)
    MEM_W(0X16C, ctx->r14) = ctx->r13;
    // 0x802C81C8: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x802C81CC: lbu         $v0, 0x8A($t7)
    ctx->r2 = MEM_BU(ctx->r15, 0X8A);
    // 0x802C81D0: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802C81D4: beql        $at, $zero, L_802C81EC
    if (ctx->r1 == 0) {
        // 0x802C81D8: lw          $t9, 0x0($a2)
        ctx->r25 = MEM_W(ctx->r6, 0X0);
            goto L_802C81EC;
    }
    goto skip_2;
    // 0x802C81D8: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    skip_2:
    // 0x802C81DC: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802C81E0: b           L_802C81F0
    // 0x802C81E4: sh          $v1, 0x14C($t8)
    MEM_H(0X14C, ctx->r24) = ctx->r3;
        goto L_802C81F0;
    // 0x802C81E4: sh          $v1, 0x14C($t8)
    MEM_H(0X14C, ctx->r24) = ctx->r3;
    // 0x802C81E8: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
L_802C81EC:
    // 0x802C81EC: sh          $v0, 0x14C($t9)
    MEM_H(0X14C, ctx->r25) = ctx->r2;
L_802C81F0:
    // 0x802C81F0: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802C81F4: lbu         $t6, 0x4F($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X4F);
    // 0x802C81F8: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x802C81FC: sb          $t7, 0x4F($v0)
    MEM_B(0X4F, ctx->r2) = ctx->r15;
    // 0x802C8200: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802C8204: lbu         $t9, 0x4F($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X4F);
    // 0x802C8208: ori         $t5, $t9, 0x8
    ctx->r13 = ctx->r25 | 0X8;
    // 0x802C820C: sb          $t5, 0x4F($v0)
    MEM_B(0X4F, ctx->r2) = ctx->r13;
    // 0x802C8210: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802C8214: lbu         $t7, 0x4F($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X4F);
    // 0x802C8218: ori         $t8, $t7, 0x4
    ctx->r24 = ctx->r15 | 0X4;
    // 0x802C821C: jal         0x801282C4
    // 0x802C8220: sb          $t8, 0x4F($v0)
    MEM_B(0X4F, ctx->r2) = ctx->r24;
    func_801282C4(rdram, ctx);
        goto after_2;
    // 0x802C8220: sb          $t8, 0x4F($v0)
    MEM_B(0X4F, ctx->r2) = ctx->r24;
    after_2:
    // 0x802C8224: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802C8228: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802C822C: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802C8230: sh          $v0, 0x31C($t9)
    MEM_H(0X31C, ctx->r25) = ctx->r2;
    // 0x802C8234: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    // 0x802C8238: jal         0x8031124C
    // 0x802C823C: lh          $a0, 0x32($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X32);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_3;
    // 0x802C823C: lh          $a0, 0x32($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X32);
    after_3:
    // 0x802C8240: lh          $t7, 0x3A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3A);
    // 0x802C8244: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802C8248: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802C824C: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802C8250: slt         $at, $t7, $t6
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802C8254: beql        $at, $zero, L_802C8264
    if (ctx->r1 == 0) {
        // 0x802C8258: lh          $a0, 0x32($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X32);
            goto L_802C8264;
    }
    goto skip_3;
    // 0x802C8258: lh          $a0, 0x32($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X32);
    skip_3:
    // 0x802C825C: sh          $t6, 0x3A($sp)
    MEM_H(0X3A, ctx->r29) = ctx->r14;
    // 0x802C8260: lh          $a0, 0x32($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X32);
L_802C8264:
    // 0x802C8264: jal         0x80310F58
    // 0x802C8268: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    func_80310F58_722608(rdram, ctx);
        goto after_4;
    // 0x802C8268: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    after_4:
    // 0x802C826C: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802C8270: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802C8274: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802C8278: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802C827C: addiu       $at, $zero, 0x4000
    ctx->r1 = ADD32(0, 0X4000);
    // 0x802C8280: bne         $v1, $at, L_802C8294
    if (ctx->r3 != ctx->r1) {
        // 0x802C8284: addiu       $a2, $a2, 0x5530
        ctx->r6 = ADD32(ctx->r6, 0X5530);
            goto L_802C8294;
    }
    // 0x802C8284: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802C8288: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x802C828C: b           L_802C82C0
    // 0x802C8290: sb          $zero, 0x160($t5)
    MEM_B(0X160, ctx->r13) = 0;
        goto L_802C82C0;
    // 0x802C8290: sb          $zero, 0x160($t5)
    MEM_B(0X160, ctx->r13) = 0;
L_802C8294:
    // 0x802C8294: lh          $t6, 0x3A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X3A);
    // 0x802C8298: slt         $at, $t6, $v1
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802C829C: bnel        $at, $zero, L_802C82B8
    if (ctx->r1 != 0) {
        // 0x802C82A0: lw          $t5, 0x0($a2)
        ctx->r13 = MEM_W(ctx->r6, 0X0);
            goto L_802C82B8;
    }
    goto skip_4;
    // 0x802C82A0: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    skip_4:
    // 0x802C82A4: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802C82A8: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x802C82AC: b           L_802C82C0
    // 0x802C82B0: sb          $t7, 0x160($t8)
    MEM_B(0X160, ctx->r24) = ctx->r15;
        goto L_802C82C0;
    // 0x802C82B0: sb          $t7, 0x160($t8)
    MEM_B(0X160, ctx->r24) = ctx->r15;
    // 0x802C82B4: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
L_802C82B8:
    // 0x802C82B8: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802C82BC: sb          $t9, 0x160($t5)
    MEM_B(0X160, ctx->r13) = ctx->r25;
L_802C82C0:
    // 0x802C82C0: jal         0x802B2EA8
    // 0x802C82C4: nop

    func_802B2EA8_6C4558(rdram, ctx);
        goto after_5;
    // 0x802C82C4: nop

    after_5:
    // 0x802C82C8: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802C82CC: lh          $t6, 0x32($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X32);
    // 0x802C82D0: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802C82D4: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802C82D8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802C82DC: sw          $t7, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r15;
    // 0x802C82E0: lh          $t9, 0x36($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X36);
    // 0x802C82E4: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x802C82E8: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x802C82EC: sw          $t5, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r13;
    // 0x802C82F0: lh          $t7, 0x3A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3A);
    // 0x802C82F4: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x802C82F8: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802C82FC: sw          $t8, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r24;
    // 0x802C8300: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x802C8304: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x802C8308: sw          $zero, 0x1C($t5)
    MEM_W(0X1C, ctx->r13) = 0;
    // 0x802C830C: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x802C8310: sw          $zero, 0x20($t6)
    MEM_W(0X20, ctx->r14) = 0;
    // 0x802C8314: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802C8318: sw          $t7, 0x24($t8)
    MEM_W(0X24, ctx->r24) = ctx->r15;
    // 0x802C831C: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802C8320: lw          $t9, 0x16C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X16C);
    // 0x802C8324: lhu         $t5, 0x7C($t9)
    ctx->r13 = MEM_HU(ctx->r25, 0X7C);
    // 0x802C8328: sh          $t5, 0x46($v0)
    MEM_H(0X46, ctx->r2) = ctx->r13;
    // 0x802C832C: lw          $t6, 0x24($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X24);
    // 0x802C8330: jal         0x802DADA0
    // 0x802C8334: lw          $a0, 0x3EB4($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X3EB4);
    func_802DADA0_6EC450(rdram, ctx);
        goto after_6;
    // 0x802C8334: lw          $a0, 0x3EB4($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X3EB4);
    after_6:
    // 0x802C8338: jal         0x802E4B0C
    // 0x802C833C: lh          $a0, 0x46($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X46);
    load_dynamic_tail(rdram, ctx);
        goto after_7;
    // 0x802C833C: lh          $a0, 0x46($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X46);
    after_7:
    // 0x802C8340: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802C8344: lw          $t7, 0x5528($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5528);
    // 0x802C8348: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802C834C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802C8350: sh          $v0, 0x3CA($t7)
    MEM_H(0X3CA, ctx->r15) = ctx->r2;
    // 0x802C8354: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802C8358: addiu       $t8, $zero, 0x43F
    ctx->r24 = ADD32(0, 0X43F);
    // 0x802C835C: sh          $t8, 0x272($t9)
    MEM_H(0X272, ctx->r25) = ctx->r24;
    // 0x802C8360: lw          $t5, 0x24($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X24);
    // 0x802C8364: jal         0x802C9BA4
    // 0x802C8368: lw          $a0, 0x3EB4($t5)
    ctx->r4 = MEM_W(ctx->r13, 0X3EB4);
    func_802C9BA4_6DB254(rdram, ctx);
        goto after_8;
    // 0x802C8368: lw          $a0, 0x3EB4($t5)
    ctx->r4 = MEM_W(ctx->r13, 0X3EB4);
    after_8:
    // 0x802C836C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802C8370: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802C8374: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802C8378: addiu       $v0, $zero, 0x3FF
    ctx->r2 = ADD32(0, 0X3FF);
    // 0x802C837C: sh          $v0, 0x2E0($t6)
    MEM_H(0X2E0, ctx->r14) = ctx->r2;
    // 0x802C8380: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802C8384: sh          $v0, 0x2E4($t7)
    MEM_H(0X2E4, ctx->r15) = ctx->r2;
    // 0x802C8388: lb          $t8, 0x4B($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X4B);
    // 0x802C838C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802C8390: beql        $t8, $zero, L_802C83BC
    if (ctx->r24 == 0) {
        // 0x802C8394: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802C83BC;
    }
    goto skip_5;
    // 0x802C8394: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802C8398: lh          $v0, 0x2A98($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2A98);
    // 0x802C839C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802C83A0: beq         $v0, $zero, L_802C83B0
    if (ctx->r2 == 0) {
        // 0x802C83A4: nop
    
            goto L_802C83B0;
    }
    // 0x802C83A4: nop

    // 0x802C83A8: bnel        $v0, $at, L_802C83BC
    if (ctx->r2 != ctx->r1) {
        // 0x802C83AC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802C83BC;
    }
    goto skip_6;
    // 0x802C83AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
L_802C83B0:
    // 0x802C83B0: jal         0x803284C4
    // 0x802C83B4: nop

    func_803284C4_739B74(rdram, ctx);
        goto after_9;
    // 0x802C83B4: nop

    after_9:
    // 0x802C83B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802C83BC:
    // 0x802C83BC: lw          $v0, 0x20($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X20);
    // 0x802C83C0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802C83C4: jr          $ra
    // 0x802C83C8: nop

    return;
    // 0x802C83C8: nop

;}
RECOMP_FUNC void static_2_802C9564(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802C9564: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802C9568: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802C956C: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802C9570: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802C9574: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802C9578: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802C957C: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802C9580: jal         0x802C9488
    // 0x802C9584: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    func_802C9488_6DAB38(rdram, ctx);
        goto after_0;
    // 0x802C9584: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    after_0:
    // 0x802C9588: lh          $a3, 0x2E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2E);
    // 0x802C958C: bne         $v0, $zero, L_802C959C
    if (ctx->r2 != 0) {
        // 0x802C9590: or          $s0, $v0, $zero
        ctx->r16 = ctx->r2 | 0;
            goto L_802C959C;
    }
    // 0x802C9590: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x802C9594: b           L_802C9820
    // 0x802C9598: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802C9820;
    // 0x802C9598: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802C959C:
    // 0x802C959C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802C95A0: addiu       $a1, $zero, 0x270
    ctx->r5 = ADD32(0, 0X270);
    // 0x802C95A4: jal         0x80128FB4
    // 0x802C95A8: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    bzero_sssv(rdram, ctx);
        goto after_1;
    // 0x802C95A8: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    after_1:
    // 0x802C95AC: lbu         $t8, 0x23($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X23);
    // 0x802C95B0: lui         $t0, 0x801F
    ctx->r8 = S32(0X801F << 16);
    // 0x802C95B4: lw          $t0, -0x6148($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X6148);
    // 0x802C95B8: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x802C95BC: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802C95C0: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802C95C4: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x802C95C8: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802C95CC: lh          $a3, 0x2E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2E);
    // 0x802C95D0: addu        $v0, $t9, $t0
    ctx->r2 = ADD32(ctx->r25, ctx->r8);
    // 0x802C95D4: sw          $v0, 0x16C($s0)
    MEM_W(0X16C, ctx->r16) = ctx->r2;
    // 0x802C95D8: lhu         $t1, 0x70($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X70);
    // 0x802C95DC: beql        $t1, $zero, L_802C95F0
    if (ctx->r9 == 0) {
        // 0x802C95E0: lhu         $t4, 0x46($sp)
        ctx->r12 = MEM_HU(ctx->r29, 0X46);
            goto L_802C95F0;
    }
    goto skip_0;
    // 0x802C95E0: lhu         $t4, 0x46($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X46);
    skip_0:
    // 0x802C95E4: lhu         $t3, 0x70($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X70);
    // 0x802C95E8: sh          $t3, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r11;
    // 0x802C95EC: lhu         $t4, 0x46($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X46);
L_802C95F0:
    // 0x802C95F0: lbu         $t1, 0x4F($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X4F);
    // 0x802C95F4: sh          $t4, 0x40($s0)
    MEM_H(0X40, ctx->r16) = ctx->r12;
    // 0x802C95F8: lw          $t5, 0x80($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X80);
    // 0x802C95FC: andi        $t2, $t1, 0xFFF7
    ctx->r10 = ctx->r9 & 0XFFF7;
    // 0x802C9600: sll         $t6, $t5, 20
    ctx->r14 = S32(ctx->r13 << 20);
    // 0x802C9604: srl         $t8, $t6, 31
    ctx->r24 = S32(U32(ctx->r14) >> 31);
    // 0x802C9608: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802C960C: andi        $t0, $t9, 0x8
    ctx->r8 = ctx->r25 & 0X8;
    // 0x802C9610: or          $t1, $t0, $t2
    ctx->r9 = ctx->r8 | ctx->r10;
    // 0x802C9614: sb          $t1, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r9;
    // 0x802C9618: lw          $t4, 0x80($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X80);
    // 0x802C961C: andi        $t0, $t1, 0xFB
    ctx->r8 = ctx->r9 & 0XFB;
    // 0x802C9620: sll         $t5, $t4, 21
    ctx->r13 = S32(ctx->r12 << 21);
    // 0x802C9624: srl         $t7, $t5, 31
    ctx->r15 = S32(U32(ctx->r13) >> 31);
    // 0x802C9628: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x802C962C: andi        $t9, $t8, 0x4
    ctx->r25 = ctx->r24 & 0X4;
    // 0x802C9630: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x802C9634: sb          $t1, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r9;
    // 0x802C9638: lw          $t3, 0x80($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X80);
    // 0x802C963C: andi        $t9, $t1, 0xEF
    ctx->r25 = ctx->r9 & 0XEF;
    // 0x802C9640: sll         $t4, $t3, 19
    ctx->r12 = S32(ctx->r11 << 19);
    // 0x802C9644: srl         $t6, $t4, 31
    ctx->r14 = S32(U32(ctx->r12) >> 31);
    // 0x802C9648: sll         $t7, $t6, 4
    ctx->r15 = S32(ctx->r14 << 4);
    // 0x802C964C: andi        $t8, $t7, 0x10
    ctx->r24 = ctx->r15 & 0X10;
    // 0x802C9650: or          $t0, $t8, $t9
    ctx->r8 = ctx->r24 | ctx->r25;
    // 0x802C9654: sb          $t0, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r8;
    // 0x802C9658: lbu         $t2, 0x8A($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X8A);
    // 0x802C965C: sh          $t2, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r10;
    // 0x802C9660: lbu         $t3, 0x89($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X89);
    // 0x802C9664: sb          $t3, 0x164($s0)
    MEM_B(0X164, ctx->r16) = ctx->r11;
    // 0x802C9668: lbu         $t4, 0x82($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X82);
    // 0x802C966C: lh          $a1, 0x2A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2A);
    // 0x802C9670: lh          $a0, 0x26($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X26);
    // 0x802C9674: andi        $t5, $t4, 0x1
    ctx->r13 = ctx->r12 & 0X1;
    // 0x802C9678: beql        $t5, $zero, L_802C96B4
    if (ctx->r13 == 0) {
        // 0x802C967C: lh          $a0, 0x26($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X26);
            goto L_802C96B4;
    }
    goto skip_1;
    // 0x802C967C: lh          $a0, 0x26($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X26);
    skip_1:
    // 0x802C9680: jal         0x8031124C
    // 0x802C9684: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_2;
    // 0x802C9684: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    after_2:
    // 0x802C9688: lh          $a3, 0x2E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2E);
    // 0x802C968C: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802C9690: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802C9694: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802C9698: slt         $at, $a3, $t7
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802C969C: beql        $at, $zero, L_802C96B4
    if (ctx->r1 == 0) {
        // 0x802C96A0: lh          $a0, 0x26($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X26);
            goto L_802C96B4;
    }
    goto skip_2;
    // 0x802C96A0: lh          $a0, 0x26($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X26);
    skip_2:
    // 0x802C96A4: sll         $a3, $t7, 16
    ctx->r7 = S32(ctx->r15 << 16);
    // 0x802C96A8: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802C96AC: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x802C96B0: lh          $a0, 0x26($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X26);
L_802C96B4:
    // 0x802C96B4: lh          $a1, 0x2A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2A);
    // 0x802C96B8: jal         0x80310F58
    // 0x802C96BC: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    func_80310F58_722608(rdram, ctx);
        goto after_3;
    // 0x802C96BC: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    after_3:
    // 0x802C96C0: sra         $v1, $v0, 16
    ctx->r3 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802C96C4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802C96C8: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802C96CC: addiu       $at, $zero, 0x4000
    ctx->r1 = ADD32(0, 0X4000);
    // 0x802C96D0: bne         $v1, $at, L_802C96E0
    if (ctx->r3 != ctx->r1) {
        // 0x802C96D4: lh          $a3, 0x2E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X2E);
            goto L_802C96E0;
    }
    // 0x802C96D4: lh          $a3, 0x2E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2E);
    // 0x802C96D8: b           L_802C96FC
    // 0x802C96DC: sb          $zero, 0x160($s0)
    MEM_B(0X160, ctx->r16) = 0;
        goto L_802C96FC;
    // 0x802C96DC: sb          $zero, 0x160($s0)
    MEM_B(0X160, ctx->r16) = 0;
L_802C96E0:
    // 0x802C96E0: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802C96E4: bne         $at, $zero, L_802C96F8
    if (ctx->r1 != 0) {
        // 0x802C96E8: addiu       $t2, $zero, 0x1
        ctx->r10 = ADD32(0, 0X1);
            goto L_802C96F8;
    }
    // 0x802C96E8: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802C96EC: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x802C96F0: b           L_802C96FC
    // 0x802C96F4: sb          $t0, 0x160($s0)
    MEM_B(0X160, ctx->r16) = ctx->r8;
        goto L_802C96FC;
    // 0x802C96F4: sb          $t0, 0x160($s0)
    MEM_B(0X160, ctx->r16) = ctx->r8;
L_802C96F8:
    // 0x802C96F8: sb          $t2, 0x160($s0)
    MEM_B(0X160, ctx->r16) = ctx->r10;
L_802C96FC:
    // 0x802C96FC: lh          $v1, 0x3E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X3E);
    // 0x802C9700: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802C9704: sh          $t3, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r11;
    // 0x802C9708: lh          $t4, 0x26($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X26);
    // 0x802C970C: lbu         $t0, 0x4F($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X4F);
    // 0x802C9710: lw          $t3, 0x16C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X16C);
    // 0x802C9714: sh          $t4, 0x17E($s0)
    MEM_H(0X17E, ctx->r16) = ctx->r12;
    // 0x802C9718: lh          $t5, 0x2A($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2A);
    // 0x802C971C: sh          $a3, 0x182($s0)
    MEM_H(0X182, ctx->r16) = ctx->r7;
    // 0x802C9720: ori         $t2, $t0, 0x40
    ctx->r10 = ctx->r8 | 0X40;
    // 0x802C9724: sh          $t5, 0x180($s0)
    MEM_H(0X180, ctx->r16) = ctx->r13;
    // 0x802C9728: lw          $t6, 0x30($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X30);
    // 0x802C972C: addiu       $v0, $zero, 0x7FFF
    ctx->r2 = ADD32(0, 0X7FFF);
    // 0x802C9730: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802C9734: sw          $t6, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r14;
    // 0x802C9738: lw          $t7, 0x34($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X34);
    // 0x802C973C: sw          $t7, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r15;
    // 0x802C9740: lw          $t1, 0x38($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X38);
    // 0x802C9744: sh          $v1, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r3;
    // 0x802C9748: sw          $t1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r9;
    // 0x802C974C: lh          $t8, 0x42($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X42);
    // 0x802C9750: sb          $t2, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r10;
    // 0x802C9754: sh          $t8, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r24;
    // 0x802C9758: lhu         $t4, 0x7C($t3)
    ctx->r12 = MEM_HU(ctx->r11, 0X7C);
    // 0x802C975C: sh          $v0, 0x114($s0)
    MEM_H(0X114, ctx->r16) = ctx->r2;
    // 0x802C9760: sh          $v0, 0x116($s0)
    MEM_H(0X116, ctx->r16) = ctx->r2;
    // 0x802C9764: sh          $v0, 0x118($s0)
    MEM_H(0X118, ctx->r16) = ctx->r2;
    // 0x802C9768: sh          $v0, 0x11A($s0)
    MEM_H(0X11A, ctx->r16) = ctx->r2;
    // 0x802C976C: sh          $t4, 0x46($s0)
    MEM_H(0X46, ctx->r16) = ctx->r12;
    // 0x802C9770: jal         0x802C9BA4
    // 0x802C9774: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    func_802C9BA4_6DB254(rdram, ctx);
        goto after_4;
    // 0x802C9774: sh          $a3, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r7;
    after_4:
    // 0x802C9778: lw          $t5, 0x16C($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X16C);
    // 0x802C977C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802C9780: lh          $v1, 0x3E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X3E);
    // 0x802C9784: lbu         $t6, 0x15($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X15);
    // 0x802C9788: lh          $a3, 0x2E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2E);
    // 0x802C978C: lh          $t3, 0x26($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X26);
    // 0x802C9790: bne         $t6, $at, L_802C97D4
    if (ctx->r14 != ctx->r1) {
        // 0x802C9794: slti        $at, $v1, 0xE1
        ctx->r1 = SIGNED(ctx->r3) < 0XE1 ? 1 : 0;
            goto L_802C97D4;
    }
    // 0x802C9794: slti        $at, $v1, 0xE1
    ctx->r1 = SIGNED(ctx->r3) < 0XE1 ? 1 : 0;
    // 0x802C9798: bne         $at, $zero, L_802C97A4
    if (ctx->r1 != 0) {
        // 0x802C979C: slti        $at, $v1, 0x13B
        ctx->r1 = SIGNED(ctx->r3) < 0X13B ? 1 : 0;
            goto L_802C97A4;
    }
    // 0x802C979C: slti        $at, $v1, 0x13B
    ctx->r1 = SIGNED(ctx->r3) < 0X13B ? 1 : 0;
    // 0x802C97A0: bne         $at, $zero, L_802C97B8
    if (ctx->r1 != 0) {
        // 0x802C97A4: slti        $at, $v1, 0x2D
        ctx->r1 = SIGNED(ctx->r3) < 0X2D ? 1 : 0;
            goto L_802C97B8;
    }
L_802C97A4:
    // 0x802C97A4: slti        $at, $v1, 0x2D
    ctx->r1 = SIGNED(ctx->r3) < 0X2D ? 1 : 0;
    // 0x802C97A8: bne         $at, $zero, L_802C97D4
    if (ctx->r1 != 0) {
        // 0x802C97AC: slti        $at, $v1, 0x87
        ctx->r1 = SIGNED(ctx->r3) < 0X87 ? 1 : 0;
            goto L_802C97D4;
    }
    // 0x802C97AC: slti        $at, $v1, 0x87
    ctx->r1 = SIGNED(ctx->r3) < 0X87 ? 1 : 0;
    // 0x802C97B0: beql        $at, $zero, L_802C97D8
    if (ctx->r1 == 0) {
        // 0x802C97B4: sh          $t3, 0x4($s0)
        MEM_H(0X4, ctx->r16) = ctx->r11;
            goto L_802C97D8;
    }
    goto skip_3;
    // 0x802C97B4: sh          $t3, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r11;
    skip_3:
L_802C97B8:
    // 0x802C97B8: lh          $t7, 0x32($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X32);
    // 0x802C97BC: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x802C97C0: addu        $t1, $a3, $t7
    ctx->r9 = ADD32(ctx->r7, ctx->r15);
    // 0x802C97C4: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802C97C8: subu        $a3, $t1, $t9
    ctx->r7 = SUB32(ctx->r9, ctx->r25);
    // 0x802C97CC: sll         $t0, $a3, 16
    ctx->r8 = S32(ctx->r7 << 16);
    // 0x802C97D0: sra         $a3, $t0, 16
    ctx->r7 = S32(SIGNED(ctx->r8) >> 16);
L_802C97D4:
    // 0x802C97D4: sh          $t3, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r11;
L_802C97D8:
    // 0x802C97D8: lh          $t4, 0x2A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X2A);
    // 0x802C97DC: sh          $a3, 0xC($s0)
    MEM_H(0XC, ctx->r16) = ctx->r7;
    // 0x802C97E0: sll         $t1, $a3, 16
    ctx->r9 = S32(ctx->r7 << 16);
    // 0x802C97E4: sh          $t4, 0x8($s0)
    MEM_H(0X8, ctx->r16) = ctx->r12;
    // 0x802C97E8: lh          $t5, 0x26($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X26);
    // 0x802C97EC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802C97F0: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802C97F4: sw          $t6, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r14;
    // 0x802C97F8: lh          $t7, 0x2A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2A);
    // 0x802C97FC: sw          $t1, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r9;
    // 0x802C9800: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802C9804: jal         0x802DADA0
    // 0x802C9808: sw          $t8, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r24;
    func_802DADA0_6EC450(rdram, ctx);
        goto after_5;
    // 0x802C9808: sw          $t8, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r24;
    after_5:
    // 0x802C980C: jal         0x802F5C60
    // 0x802C9810: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F5C60_707310(rdram, ctx);
        goto after_6;
    // 0x802C9810: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_6:
    // 0x802C9814: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x802C9818: sb          $t9, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r25;
    // 0x802C981C: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
L_802C9820:
    // 0x802C9820: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802C9824: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802C9828: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802C982C: jr          $ra
    // 0x802C9830: nop

    return;
    // 0x802C9830: nop

;}
RECOMP_FUNC void static_2_802F07D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F07D0: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802F07D4: addiu       $v0, $v0, 0x1B10
    ctx->r2 = ADD32(ctx->r2, 0X1B10);
    // 0x802F07D8: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x802F07DC: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x802F07E0: jr          $ra
    // 0x802F07E4: sh          $zero, 0x8($v0)
    MEM_H(0X8, ctx->r2) = 0;
    return;
    // 0x802F07E4: sh          $zero, 0x8($v0)
    MEM_H(0X8, ctx->r2) = 0;
;}
RECOMP_FUNC void static_2_802F07E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F07E8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802F07EC: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802F07F0: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F07F4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802F07F8: addiu       $v0, $zero, 0x17
    ctx->r2 = ADD32(0, 0X17);
    // 0x802F07FC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802F0800: beq         $t7, $v0, L_802F0814
    if (ctx->r15 == ctx->r2) {
        // 0x802F0804: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_802F0814;
    }
    // 0x802F0804: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F0808: addiu       $at, $zero, 0x18
    ctx->r1 = ADD32(0, 0X18);
    // 0x802F080C: bnel        $t7, $at, L_802F0858
    if (ctx->r15 != ctx->r1) {
        // 0x802F0810: addiu       $v0, $zero, 0x6
        ctx->r2 = ADD32(0, 0X6);
            goto L_802F0858;
    }
    goto skip_0;
    // 0x802F0810: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
    skip_0:
L_802F0814:
    // 0x802F0814: bne         $a0, $v0, L_802F0834
    if (ctx->r4 != ctx->r2) {
        // 0x802F0818: lui         $v1, 0x803E
        ctx->r3 = S32(0X803E << 16);
            goto L_802F0834;
    }
    // 0x802F0818: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802F081C: addiu       $v1, $v1, 0x1B10
    ctx->r3 = ADD32(ctx->r3, 0X1B10);
    // 0x802F0820: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802F0824: sh          $t8, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r24;
    // 0x802F0828: jal         0x80349778
    // 0x802F082C: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    hide_osd(rdram, ctx);
        goto after_0;
    // 0x802F082C: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    after_0:
    // 0x802F0830: lh          $a0, 0x1A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X1A);
L_802F0834:
    // 0x802F0834: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802F0838: addiu       $at, $zero, 0x18
    ctx->r1 = ADD32(0, 0X18);
    // 0x802F083C: bne         $a0, $at, L_802F0908
    if (ctx->r4 != ctx->r1) {
        // 0x802F0840: addiu       $v1, $v1, 0x1B10
        ctx->r3 = ADD32(ctx->r3, 0X1B10);
            goto L_802F0908;
    }
    // 0x802F0840: addiu       $v1, $v1, 0x1B10
    ctx->r3 = ADD32(ctx->r3, 0X1B10);
    // 0x802F0844: jal         0x80349748
    // 0x802F0848: sh          $zero, 0x8($v1)
    MEM_H(0X8, ctx->r3) = 0;
    show_osd(rdram, ctx);
        goto after_1;
    // 0x802F0848: sh          $zero, 0x8($v1)
    MEM_H(0X8, ctx->r3) = 0;
    after_1:
    // 0x802F084C: b           L_802F090C
    // 0x802F0850: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802F090C;
    // 0x802F0850: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802F0854: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
L_802F0858:
    // 0x802F0858: beq         $a0, $v0, L_802F0878
    if (ctx->r4 == ctx->r2) {
        // 0x802F085C: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_802F0878;
    }
    // 0x802F085C: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x802F0860: beq         $a0, $at, L_802F0878
    if (ctx->r4 == ctx->r1) {
        // 0x802F0864: addiu       $at, $zero, 0x13
        ctx->r1 = ADD32(0, 0X13);
            goto L_802F0878;
    }
    // 0x802F0864: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802F0868: beq         $a0, $at, L_802F0878
    if (ctx->r4 == ctx->r1) {
        // 0x802F086C: addiu       $at, $zero, 0x14
        ctx->r1 = ADD32(0, 0X14);
            goto L_802F0878;
    }
    // 0x802F086C: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x802F0870: bne         $a0, $at, L_802F08D8
    if (ctx->r4 != ctx->r1) {
        // 0x802F0874: lui         $v1, 0x803E
        ctx->r3 = S32(0X803E << 16);
            goto L_802F08D8;
    }
    // 0x802F0874: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
L_802F0878:
    // 0x802F0878: bnel        $a0, $v0, L_802F0890
    if (ctx->r4 != ctx->r2) {
        // 0x802F087C: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_802F0890;
    }
    goto skip_1;
    // 0x802F087C: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    skip_1:
    // 0x802F0880: jal         0x8012ABF0
    // 0x802F0884: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    set_tv_mode_widescreen(rdram, ctx);
        goto after_2;
    // 0x802F0884: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    after_2:
    // 0x802F0888: lh          $a0, 0x1A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X1A);
    // 0x802F088C: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
L_802F0890:
    // 0x802F0890: bnel        $a0, $at, L_802F08A8
    if (ctx->r4 != ctx->r1) {
        // 0x802F0894: addiu       $at, $zero, 0x13
        ctx->r1 = ADD32(0, 0X13);
            goto L_802F08A8;
    }
    goto skip_2;
    // 0x802F0894: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    skip_2:
    // 0x802F0898: jal         0x8012AC40
    // 0x802F089C: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    set_tv_mode_normal(rdram, ctx);
        goto after_3;
    // 0x802F089C: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    after_3:
    // 0x802F08A0: lh          $a0, 0x1A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X1A);
    // 0x802F08A4: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
L_802F08A8:
    // 0x802F08A8: bnel        $a0, $at, L_802F08C0
    if (ctx->r4 != ctx->r1) {
        // 0x802F08AC: addiu       $at, $zero, 0x14
        ctx->r1 = ADD32(0, 0X14);
            goto L_802F08C0;
    }
    goto skip_3;
    // 0x802F08AC: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    skip_3:
    // 0x802F08B0: jal         0x80349748
    // 0x802F08B4: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    show_osd(rdram, ctx);
        goto after_4;
    // 0x802F08B4: sh          $a0, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r4;
    after_4:
    // 0x802F08B8: lh          $a0, 0x1A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X1A);
    // 0x802F08BC: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
L_802F08C0:
    // 0x802F08C0: bnel        $a0, $at, L_802F090C
    if (ctx->r4 != ctx->r1) {
        // 0x802F08C4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802F090C;
    }
    goto skip_4;
    // 0x802F08C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802F08C8: jal         0x80349778
    // 0x802F08CC: nop

    hide_osd(rdram, ctx);
        goto after_5;
    // 0x802F08CC: nop

    after_5:
    // 0x802F08D0: b           L_802F090C
    // 0x802F08D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802F090C;
    // 0x802F08D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802F08D8:
    // 0x802F08D8: addiu       $v1, $v1, 0x1B10
    ctx->r3 = ADD32(ctx->r3, 0X1B10);
    // 0x802F08DC: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x802F08E0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F08E4: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x802F08E8: beq         $v0, $zero, L_802F08F8
    if (ctx->r2 == 0) {
        // 0x802F08EC: addiu       $t0, $zero, 0x1
        ctx->r8 = ADD32(0, 0X1);
            goto L_802F08F8;
    }
    // 0x802F08EC: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802F08F0: bnel        $v0, $at, L_802F090C
    if (ctx->r2 != ctx->r1) {
        // 0x802F08F4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802F090C;
    }
    goto skip_5;
    // 0x802F08F4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
L_802F08F8:
    // 0x802F08F8: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    // 0x802F08FC: sh          $t0, 0x2($v1)
    MEM_H(0X2, ctx->r3) = ctx->r8;
    // 0x802F0900: sh          $zero, 0x6($v1)
    MEM_H(0X6, ctx->r3) = 0;
    // 0x802F0904: sh          $a0, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r4;
L_802F0908:
    // 0x802F0908: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802F090C:
    // 0x802F090C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802F0910: jr          $ra
    // 0x802F0914: nop

    return;
    // 0x802F0914: nop

;}
RECOMP_FUNC void static_2_802F5964(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F5964: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x802F5968: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x802F596C: lui         $t8, 0x8000
    ctx->r24 = S32(0X8000 << 16);
    // 0x802F5970: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x802F5974: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x802F5978: ori         $t8, $t8, 0x40
    ctx->r24 = ctx->r24 | 0X40;
    // 0x802F597C: ori         $t7, $t7, 0x2
    ctx->r15 = ctx->r15 | 0X2;
    // 0x802F5980: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x802F5984: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x802F5988: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x802F598C: lui         $t0, 0x386
    ctx->r8 = S32(0X386 << 16);
    // 0x802F5990: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x802F5994: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x802F5998: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x802F599C: ori         $t0, $t0, 0x10
    ctx->r8 = ctx->r8 | 0X10;
    // 0x802F59A0: addiu       $a3, $a3, 0x4278
    ctx->r7 = ADD32(ctx->r7, 0X4278);
    // 0x802F59A4: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x802F59A8: lw          $t1, 0x0($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X0);
    // 0x802F59AC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x802F59B0: ori         $at, $at, 0xB640
    ctx->r1 = ctx->r1 | 0XB640;
    // 0x802F59B4: addu        $t2, $t1, $at
    ctx->r10 = ADD32(ctx->r9, ctx->r1);
    // 0x802F59B8: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x802F59BC: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x802F59C0: lui         $t4, 0x388
    ctx->r12 = S32(0X388 << 16);
    // 0x802F59C4: ori         $t4, $t4, 0x10
    ctx->r12 = ctx->r12 | 0X10;
    // 0x802F59C8: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x802F59CC: sw          $t3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r11;
    // 0x802F59D0: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x802F59D4: lw          $t5, 0x0($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X0);
    // 0x802F59D8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x802F59DC: ori         $at, $at, 0xB638
    ctx->r1 = ctx->r1 | 0XB638;
    // 0x802F59E0: addu        $t6, $t5, $at
    ctx->r14 = ADD32(ctx->r13, ctx->r1);
    // 0x802F59E4: jr          $ra
    // 0x802F59E8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    return;
    // 0x802F59E8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x802F59EC: nop

;}
RECOMP_FUNC void static_2_8031B390(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8031B390: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8031B394: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8031B398: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8031B39C: jal         0x8031C374
    // 0x8031B3A0: sb          $a0, 0x1B($sp)
    MEM_B(0X1B, ctx->r29) = ctx->r4;
    func_8031C374_72DA24(rdram, ctx);
        goto after_0;
    // 0x8031B3A0: sb          $a0, 0x1B($sp)
    MEM_B(0X1B, ctx->r29) = ctx->r4;
    after_0:
    // 0x8031B3A4: lbu         $a3, 0x1B($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X1B);
    // 0x8031B3A8: lui         $t0, 0x803A
    ctx->r8 = S32(0X803A << 16);
    // 0x8031B3AC: addiu       $t0, $t0, 0x5BF8
    ctx->r8 = ADD32(ctx->r8, 0X5BF8);
    // 0x8031B3B0: addiu       $a3, $a3, -0x1
    ctx->r7 = ADD32(ctx->r7, -0X1);
    // 0x8031B3B4: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x8031B3B8: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8031B3BC: sll         $t8, $t6, 2
    ctx->r24 = S32(ctx->r14 << 2);
    // 0x8031B3C0: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8031B3C4: addu        $v1, $t9, $t0
    ctx->r3 = ADD32(ctx->r25, ctx->r8);
    // 0x8031B3C8: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x8031B3CC: lw          $t1, 0x4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X4);
    // 0x8031B3D0: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B3D4: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B3D8: jal         0x80129290
    // 0x8031B3DC: subu        $a2, $t1, $a0
    ctx->r6 = SUB32(ctx->r9, ctx->r4);
    dma_read(rdram, ctx);
        goto after_1;
    // 0x8031B3DC: subu        $a2, $t1, $a0
    ctx->r6 = SUB32(ctx->r9, ctx->r4);
    after_1:
    // 0x8031B3E0: jal         0x8031B400
    // 0x8031B3E4: nop

    static_2_8031B400(rdram, ctx);
        goto after_2;
    // 0x8031B3E4: nop

    after_2:
    // 0x8031B3E8: jal         0x8031C48C
    // 0x8031B3EC: nop

    func_8031C48C_72DB3C(rdram, ctx);
        goto after_3;
    // 0x8031B3EC: nop

    after_3:
    // 0x8031B3F0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8031B3F4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8031B3F8: jr          $ra
    // 0x8031B3FC: nop

    return;
    // 0x8031B3FC: nop

;}
RECOMP_FUNC void static_2_8031B400(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8031B400: addiu       $sp, $sp, -0xB0
    ctx->r29 = ADD32(ctx->r29, -0XB0);
    // 0x8031B404: sw          $s0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r16;
    // 0x8031B408: lui         $s0, 0x8000
    ctx->r16 = S32(0X8000 << 16);
    // 0x8031B40C: addiu       $s0, $s0, 0x400
    ctx->r16 = ADD32(ctx->r16, 0X400);
    // 0x8031B410: sw          $ra, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r31;
    // 0x8031B414: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031B418: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B41C: sw          $fp, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r30;
    // 0x8031B420: sw          $s7, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r23;
    // 0x8031B424: sw          $s6, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r22;
    // 0x8031B428: sw          $s5, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r21;
    // 0x8031B42C: sw          $s4, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r20;
    // 0x8031B430: sw          $s3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r19;
    // 0x8031B434: sw          $s2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r18;
    // 0x8031B438: sw          $s1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r17;
    // 0x8031B43C: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B440: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8031B444: jal         0x8031B0E8
    // 0x8031B448: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    copy_or_extract(rdram, ctx);
        goto after_0;
    // 0x8031B448: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_0:
    // 0x8031B44C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8031B450: lh          $t6, 0x553E($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X553E);
    // 0x8031B454: lui         $fp, 0x801E
    ctx->r30 = S32(0X801E << 16);
    // 0x8031B458: lui         $s6, 0x803E
    ctx->r22 = S32(0X803E << 16);
    // 0x8031B45C: lui         $s5, 0x1F
    ctx->r21 = S32(0X1F << 16);
    // 0x8031B460: or          $s4, $s0, $zero
    ctx->r20 = ctx->r16 | 0;
    // 0x8031B464: sb          $zero, 0x85($sp)
    MEM_B(0X85, ctx->r29) = 0;
    // 0x8031B468: ori         $s5, $s5, 0x4000
    ctx->r21 = ctx->r21 | 0X4000;
    // 0x8031B46C: addiu       $s6, $s6, 0x4D40
    ctx->r22 = ADD32(ctx->r22, 0X4D40);
    // 0x8031B470: addiu       $fp, $fp, -0x6128
    ctx->r30 = ADD32(ctx->r30, -0X6128);
    // 0x8031B474: addiu       $s7, $zero, 0xA
    ctx->r23 = ADD32(0, 0XA);
    // 0x8031B478: sh          $t6, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r14;
    // 0x8031B47C: lbu         $v0, 0x0($s4)
    ctx->r2 = MEM_BU(ctx->r20, 0X0);
L_8031B480:
    // 0x8031B480: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    // 0x8031B484: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8031B488: sltiu       $at, $v0, 0x10
    ctx->r1 = ctx->r2 < 0X10 ? 1 : 0;
    // 0x8031B48C: beq         $at, $zero, L_8031C2C4
    if (ctx->r1 == 0) {
        // 0x8031B490: sll         $t7, $v0, 2
        ctx->r15 = S32(ctx->r2 << 2);
            goto L_8031C2C4;
    }
    // 0x8031B490: sll         $t7, $v0, 2
    ctx->r15 = S32(ctx->r2 << 2);
    // 0x8031B494: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8031B498: addu        $at, $at, $t7
    gpr jr_addend_8031B4A0 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x8031B49C: lw          $t7, -0x2720($at)
    ctx->r15 = ADD32(ctx->r1, -0X2720);
    // 0x8031B4A0: jr          $t7
    // 0x8031B4A4: nop

    switch (jr_addend_8031B4A0 >> 2) {
        case 0: goto L_8031B4A8; break;
        case 1: goto L_8031B668; break;
        case 2: goto L_8031B738; break;
        case 3: goto L_8031B814; break;
        case 4: goto L_8031B820; break;
        case 5: goto L_8031B8F8; break;
        case 6: goto L_8031B964; break;
        case 7: goto L_8031BA40; break;
        case 8: goto L_8031C01C; break;
        case 9: goto L_8031C044; break;
        case 10: goto L_8031C07C; break;
        case 11: goto L_8031C0AC; break;
        case 12: goto L_8031C104; break;
        case 13: goto L_8031C184; break;
        case 14: goto L_8031C228; break;
        case 15: goto L_8031C278; break;
        default: switch_error(__func__, 0x8031B4A0, 0x803BD8E0);
    }
    // 0x8031B4A4: nop

L_8031B4A8:
    // 0x8031B4A8: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B4AC: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B4B0: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031B4B4: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8031B4B8: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B4BC: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B4C0: jal         0x8031B0E8
    // 0x8031B4C4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_1;
    // 0x8031B4C4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_1:
    // 0x8031B4C8: jal         0x8031B058
    // 0x8031B4CC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_2;
    // 0x8031B4CC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_2:
    // 0x8031B4D0: lui         $s3, 0x8010
    ctx->r19 = S32(0X8010 << 16);
    // 0x8031B4D4: lh          $s3, 0x0($s3)
    ctx->r19 = MEM_H(ctx->r19, 0X0);
    // 0x8031B4D8: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B4DC: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031B4E0: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B4E4: sll         $t8, $s3, 16
    ctx->r24 = S32(ctx->r19 << 16);
    // 0x8031B4E8: beq         $v1, $zero, L_8031C2C8
    if (ctx->r3 == 0) {
        // 0x8031B4EC: sra         $s3, $t8, 16
        ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
            goto L_8031C2C8;
    }
    // 0x8031B4EC: sra         $s3, $t8, 16
    ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
L_8031B4F0:
    // 0x8031B4F0: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x8031B4F4: lui         $t0, 0x801F
    ctx->r8 = S32(0X801F << 16);
    // 0x8031B4F8: lw          $t0, -0x6148($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X6148);
    // 0x8031B4FC: sll         $t1, $v0, 2
    ctx->r9 = S32(ctx->r2 << 2);
    // 0x8031B500: addu        $t1, $t1, $v0
    ctx->r9 = ADD32(ctx->r9, ctx->r2);
    // 0x8031B504: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x8031B508: subu        $t1, $t1, $v0
    ctx->r9 = SUB32(ctx->r9, ctx->r2);
    // 0x8031B50C: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x8031B510: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x8031B514: lbu         $t3, 0x15($t2)
    ctx->r11 = MEM_BU(ctx->r10, 0X15);
    // 0x8031B518: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8031B51C: bnel        $t3, $at, L_8031B5B0
    if (ctx->r11 != ctx->r1) {
        // 0x8031B520: lh          $a1, 0x2($s0)
        ctx->r5 = MEM_H(ctx->r16, 0X2);
            goto L_8031B5B0;
    }
    goto skip_0;
    // 0x8031B520: lh          $a1, 0x2($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2);
    skip_0:
    // 0x8031B524: lh          $t4, 0xA($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XA);
    // 0x8031B528: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8031B52C: sh          $zero, 0x8($s0)
    MEM_H(0X8, ctx->r16) = 0;
    // 0x8031B530: addiu       $t5, $t4, 0x2D0
    ctx->r13 = ADD32(ctx->r12, 0X2D0);
    // 0x8031B534: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x8031B538: mfhi        $t6
    ctx->r14 = hi;
    // 0x8031B53C: sh          $t6, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r14;
    // 0x8031B540: lh          $v0, 0xA($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XA);
    // 0x8031B544: slti        $at, $v0, 0x2D
    ctx->r1 = SIGNED(ctx->r2) < 0X2D ? 1 : 0;
    // 0x8031B548: bne         $at, $zero, L_8031B564
    if (ctx->r1 != 0) {
        // 0x8031B54C: slti        $at, $v0, 0x87
        ctx->r1 = SIGNED(ctx->r2) < 0X87 ? 1 : 0;
            goto L_8031B564;
    }
    // 0x8031B54C: slti        $at, $v0, 0x87
    ctx->r1 = SIGNED(ctx->r2) < 0X87 ? 1 : 0;
    // 0x8031B550: beq         $at, $zero, L_8031B564
    if (ctx->r1 == 0) {
        // 0x8031B554: addiu       $t7, $zero, 0x5A
        ctx->r15 = ADD32(0, 0X5A);
            goto L_8031B564;
    }
    // 0x8031B554: addiu       $t7, $zero, 0x5A
    ctx->r15 = ADD32(0, 0X5A);
    // 0x8031B558: sh          $t7, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r15;
    // 0x8031B55C: b           L_8031B5AC
    // 0x8031B560: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
        goto L_8031B5AC;
    // 0x8031B560: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_8031B564:
    // 0x8031B564: slti        $at, $v0, 0x87
    ctx->r1 = SIGNED(ctx->r2) < 0X87 ? 1 : 0;
    // 0x8031B568: bne         $at, $zero, L_8031B584
    if (ctx->r1 != 0) {
        // 0x8031B56C: slti        $at, $v0, 0xE1
        ctx->r1 = SIGNED(ctx->r2) < 0XE1 ? 1 : 0;
            goto L_8031B584;
    }
    // 0x8031B56C: slti        $at, $v0, 0xE1
    ctx->r1 = SIGNED(ctx->r2) < 0XE1 ? 1 : 0;
    // 0x8031B570: beq         $at, $zero, L_8031B584
    if (ctx->r1 == 0) {
        // 0x8031B574: addiu       $t8, $zero, 0xB4
        ctx->r24 = ADD32(0, 0XB4);
            goto L_8031B584;
    }
    // 0x8031B574: addiu       $t8, $zero, 0xB4
    ctx->r24 = ADD32(0, 0XB4);
    // 0x8031B578: sh          $t8, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r24;
    // 0x8031B57C: b           L_8031B5AC
    // 0x8031B580: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
        goto L_8031B5AC;
    // 0x8031B580: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_8031B584:
    // 0x8031B584: slti        $at, $v0, 0xE1
    ctx->r1 = SIGNED(ctx->r2) < 0XE1 ? 1 : 0;
    // 0x8031B588: bne         $at, $zero, L_8031B5A4
    if (ctx->r1 != 0) {
        // 0x8031B58C: slti        $at, $v0, 0x13B
        ctx->r1 = SIGNED(ctx->r2) < 0X13B ? 1 : 0;
            goto L_8031B5A4;
    }
    // 0x8031B58C: slti        $at, $v0, 0x13B
    ctx->r1 = SIGNED(ctx->r2) < 0X13B ? 1 : 0;
    // 0x8031B590: beq         $at, $zero, L_8031B5A4
    if (ctx->r1 == 0) {
        // 0x8031B594: addiu       $t9, $zero, 0x10E
        ctx->r25 = ADD32(0, 0X10E);
            goto L_8031B5A4;
    }
    // 0x8031B594: addiu       $t9, $zero, 0x10E
    ctx->r25 = ADD32(0, 0X10E);
    // 0x8031B598: sh          $t9, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r25;
    // 0x8031B59C: b           L_8031B5AC
    // 0x8031B5A0: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
        goto L_8031B5AC;
    // 0x8031B5A0: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_8031B5A4:
    // 0x8031B5A4: sh          $zero, 0xA($s0)
    MEM_H(0XA, ctx->r16) = 0;
    // 0x8031B5A8: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_8031B5AC:
    // 0x8031B5AC: lh          $a1, 0x2($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2);
L_8031B5B0:
    // 0x8031B5B0: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x8031B5B4: lh          $a3, 0x6($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X6);
    // 0x8031B5B8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8031B5BC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8031B5C0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031B5C4: lh          $t0, 0x8($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X8);
    // 0x8031B5C8: andi        $a0, $v0, 0xFF
    ctx->r4 = ctx->r2 & 0XFF;
    // 0x8031B5CC: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x8031B5D0: lh          $t1, 0xA($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XA);
    // 0x8031B5D4: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x8031B5D8: lhu         $t2, 0xE($s0)
    ctx->r10 = MEM_HU(ctx->r16, 0XE);
    // 0x8031B5DC: jal         0x802C9564
    // 0x8031B5E0: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    static_2_802C9564(rdram, ctx);
        goto after_3;
    // 0x8031B5E0: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    after_3:
    // 0x8031B5E4: lhu         $v1, 0x0($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X0);
    // 0x8031B5E8: addiu       $at, $zero, 0x37
    ctx->r1 = ADD32(0, 0X37);
    // 0x8031B5EC: or          $s1, $v0, $zero
    ctx->r17 = ctx->r2 | 0;
    // 0x8031B5F0: bne         $v1, $at, L_8031B600
    if (ctx->r3 != ctx->r1) {
        // 0x8031B5F4: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8031B600;
    }
    // 0x8031B5F4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8031B5F8: b           L_8031B610
    // 0x8031B5FC: sw          $v0, 0x2E0C($at)
    MEM_W(0X2E0C, ctx->r1) = ctx->r2;
        goto L_8031B610;
    // 0x8031B5FC: sw          $v0, 0x2E0C($at)
    MEM_W(0X2E0C, ctx->r1) = ctx->r2;
L_8031B600:
    // 0x8031B600: addiu       $at, $zero, 0x38
    ctx->r1 = ADD32(0, 0X38);
    // 0x8031B604: bne         $v1, $at, L_8031B610
    if (ctx->r3 != ctx->r1) {
        // 0x8031B608: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8031B610;
    }
    // 0x8031B608: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8031B60C: sw          $v0, 0x2E10($at)
    MEM_W(0X2E10, ctx->r1) = ctx->r2;
L_8031B610:
    // 0x8031B610: lhu         $t3, 0xC($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0XC);
    // 0x8031B614: sh          $t3, 0x3E($v0)
    MEM_H(0X3E, ctx->r2) = ctx->r11;
    // 0x8031B618: lhu         $v1, 0x10($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X10);
    // 0x8031B61C: beql        $v1, $zero, L_8031B644
    if (ctx->r3 == 0) {
        // 0x8031B620: slt         $v1, $zero, $s3
        ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_8031B644;
    }
    goto skip_1;
    // 0x8031B620: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    skip_1:
    // 0x8031B624: multu       $v1, $s7
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8031B628: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8031B62C: lbu         $a2, 0x14($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X14);
    // 0x8031B630: mflo        $t4
    ctx->r12 = lo;
    // 0x8031B634: addu        $a1, $s6, $t4
    ctx->r5 = ADD32(ctx->r22, ctx->r12);
    // 0x8031B638: jal         0x803153B0
    // 0x8031B63C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    load_commands_into_object(rdram, ctx);
        goto after_4;
    // 0x8031B63C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    after_4:
    // 0x8031B640: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031B644:
    // 0x8031B644: lhu         $t5, 0x12($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X12);
    // 0x8031B648: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B64C: sll         $t6, $s3, 16
    ctx->r14 = S32(ctx->r19 << 16);
    // 0x8031B650: sra         $s3, $t6, 16
    ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8031B654: addiu       $s0, $s0, 0x16
    ctx->r16 = ADD32(ctx->r16, 0X16);
    // 0x8031B658: bne         $v1, $zero, L_8031B4F0
    if (ctx->r3 != 0) {
        // 0x8031B65C: sh          $t5, 0x246($s1)
        MEM_H(0X246, ctx->r17) = ctx->r13;
            goto L_8031B4F0;
    }
    // 0x8031B65C: sh          $t5, 0x246($s1)
    MEM_H(0X246, ctx->r17) = ctx->r13;
    // 0x8031B660: b           L_8031C2CC
    // 0x8031B664: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031B664: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031B668:
    // 0x8031B668: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B66C: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B670: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031B674: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8031B678: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B67C: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B680: jal         0x8031B0E8
    // 0x8031B684: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_5;
    // 0x8031B684: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_5:
    // 0x8031B688: jal         0x8031B058
    // 0x8031B68C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_6;
    // 0x8031B68C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_6:
    // 0x8031B690: lui         $s3, 0x8010
    ctx->r19 = S32(0X8010 << 16);
    // 0x8031B694: lh          $s3, 0x0($s3)
    ctx->r19 = MEM_H(ctx->r19, 0X0);
    // 0x8031B698: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B69C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031B6A0: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B6A4: sll         $t8, $s3, 16
    ctx->r24 = S32(ctx->r19 << 16);
    // 0x8031B6A8: beq         $v1, $zero, L_8031C2C8
    if (ctx->r3 == 0) {
        // 0x8031B6AC: sra         $s3, $t8, 16
        ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
            goto L_8031C2C8;
    }
    // 0x8031B6AC: sra         $s3, $t8, 16
    ctx->r19 = S32(SIGNED(ctx->r24) >> 16);
L_8031B6B0:
    // 0x8031B6B0: lh          $t0, 0xA($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XA);
    // 0x8031B6B4: lh          $a0, 0x2($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X2);
    // 0x8031B6B8: lh          $a1, 0x4($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X4);
    // 0x8031B6BC: lh          $a2, 0x6($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X6);
    // 0x8031B6C0: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x8031B6C4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8031B6C8: lhu         $t1, 0x0($s0)
    ctx->r9 = MEM_HU(ctx->r16, 0X0);
    // 0x8031B6CC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8031B6D0: jal         0x802C7F88
    // 0x8031B6D4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    static_2_802C7F88(rdram, ctx);
        goto after_7;
    // 0x8031B6D4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_7:
    // 0x8031B6D8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8031B6DC: lh          $t2, 0x553E($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X553E);
    // 0x8031B6E0: lhu         $v1, 0xC($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0XC);
    // 0x8031B6E4: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x8031B6E8: addu        $t4, $fp, $t3
    ctx->r12 = ADD32(ctx->r30, ctx->r11);
    // 0x8031B6EC: beq         $v1, $zero, L_8031B710
    if (ctx->r3 == 0) {
        // 0x8031B6F0: lw          $s1, 0x3EAC($t4)
        ctx->r17 = MEM_W(ctx->r12, 0X3EAC);
            goto L_8031B710;
    }
    // 0x8031B6F0: lw          $s1, 0x3EAC($t4)
    ctx->r17 = MEM_W(ctx->r12, 0X3EAC);
    // 0x8031B6F4: multu       $v1, $s7
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8031B6F8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8031B6FC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031B700: mflo        $t5
    ctx->r13 = lo;
    // 0x8031B704: addu        $a1, $s6, $t5
    ctx->r5 = ADD32(ctx->r22, ctx->r13);
    // 0x8031B708: jal         0x803153B0
    // 0x8031B70C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    load_commands_into_object(rdram, ctx);
        goto after_8;
    // 0x8031B70C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    after_8:
L_8031B710:
    // 0x8031B710: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031B714: lhu         $t6, 0xE($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0XE);
    // 0x8031B718: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B71C: sll         $t7, $s3, 16
    ctx->r15 = S32(ctx->r19 << 16);
    // 0x8031B720: sra         $s3, $t7, 16
    ctx->r19 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8031B724: addiu       $s0, $s0, 0x10
    ctx->r16 = ADD32(ctx->r16, 0X10);
    // 0x8031B728: bne         $v1, $zero, L_8031B6B0
    if (ctx->r3 != 0) {
        // 0x8031B72C: sh          $t6, 0x246($s1)
        MEM_H(0X246, ctx->r17) = ctx->r14;
            goto L_8031B6B0;
    }
    // 0x8031B72C: sh          $t6, 0x246($s1)
    MEM_H(0X246, ctx->r17) = ctx->r14;
    // 0x8031B730: b           L_8031C2CC
    // 0x8031B734: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031B734: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031B738:
    // 0x8031B738: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B73C: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B740: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031B744: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8031B748: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B74C: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B750: jal         0x8031B0E8
    // 0x8031B754: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_9;
    // 0x8031B754: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_9:
    // 0x8031B758: jal         0x8031B058
    // 0x8031B75C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_10;
    // 0x8031B75C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_10:
    // 0x8031B760: lui         $s3, 0x8010
    ctx->r19 = S32(0X8010 << 16);
    // 0x8031B764: lh          $s3, 0x0($s3)
    ctx->r19 = MEM_H(ctx->r19, 0X0);
    // 0x8031B768: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B76C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031B770: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B774: sll         $t9, $s3, 16
    ctx->r25 = S32(ctx->r19 << 16);
    // 0x8031B778: beq         $v1, $zero, L_8031C2C8
    if (ctx->r3 == 0) {
        // 0x8031B77C: sra         $s3, $t9, 16
        ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8031C2C8;
    }
    // 0x8031B77C: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
L_8031B780:
    // 0x8031B780: lhu         $a0, 0x0($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X0);
    // 0x8031B784: lhu         $t3, 0x7A($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X7A);
    // 0x8031B788: slti        $at, $a0, 0x3E8
    ctx->r1 = SIGNED(ctx->r4) < 0X3E8 ? 1 : 0;
    // 0x8031B78C: bne         $at, $zero, L_8031B7A8
    if (ctx->r1 != 0) {
        // 0x8031B790: sll         $t4, $t3, 3
        ctx->r12 = S32(ctx->r11 << 3);
            goto L_8031B7A8;
    }
    // 0x8031B790: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x8031B794: sll         $t1, $a0, 3
    ctx->r9 = S32(ctx->r4 << 3);
    // 0x8031B798: addu        $t2, $fp, $t1
    ctx->r10 = ADD32(ctx->r30, ctx->r9);
    // 0x8031B79C: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x8031B7A0: b           L_8031B7B4
    // 0x8031B7A4: lw          $s1, 0x1F74($t5)
    ctx->r17 = MEM_W(ctx->r13, 0X1F74);
        goto L_8031B7B4;
    // 0x8031B7A4: lw          $s1, 0x1F74($t5)
    ctx->r17 = MEM_W(ctx->r13, 0X1F74);
L_8031B7A8:
    // 0x8031B7A8: jal         0x802C93E8
    // 0x8031B7AC: nop

    func_802C93E8_6DAA98(rdram, ctx);
        goto after_11;
    // 0x8031B7AC: nop

    after_11:
    // 0x8031B7B0: or          $s1, $v0, $zero
    ctx->r17 = ctx->r2 | 0;
L_8031B7B4:
    // 0x8031B7B4: lhu         $a0, 0x2($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X2);
    // 0x8031B7B8: lhu         $t8, 0x7A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X7A);
    // 0x8031B7BC: slti        $at, $a0, 0x3E8
    ctx->r1 = SIGNED(ctx->r4) < 0X3E8 ? 1 : 0;
    // 0x8031B7C0: bne         $at, $zero, L_8031B7DC
    if (ctx->r1 != 0) {
        // 0x8031B7C4: sll         $t9, $t8, 3
        ctx->r25 = S32(ctx->r24 << 3);
            goto L_8031B7DC;
    }
    // 0x8031B7C4: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x8031B7C8: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x8031B7CC: addu        $t7, $fp, $t6
    ctx->r15 = ADD32(ctx->r30, ctx->r14);
    // 0x8031B7D0: addu        $t0, $t7, $t9
    ctx->r8 = ADD32(ctx->r15, ctx->r25);
    // 0x8031B7D4: b           L_8031B7E8
    // 0x8031B7D8: lw          $a1, 0x1F74($t0)
    ctx->r5 = MEM_W(ctx->r8, 0X1F74);
        goto L_8031B7E8;
    // 0x8031B7D8: lw          $a1, 0x1F74($t0)
    ctx->r5 = MEM_W(ctx->r8, 0X1F74);
L_8031B7DC:
    // 0x8031B7DC: jal         0x802C93E8
    // 0x8031B7E0: nop

    func_802C93E8_6DAA98(rdram, ctx);
        goto after_12;
    // 0x8031B7E0: nop

    after_12:
    // 0x8031B7E4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
L_8031B7E8:
    // 0x8031B7E8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8031B7EC: jal         0x802C9900
    // 0x8031B7F0: lbu         $a2, 0x5($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X5);
    func_802C9900_6DAFB0(rdram, ctx);
        goto after_13;
    // 0x8031B7F0: lbu         $a2, 0x5($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X5);
    after_13:
    // 0x8031B7F4: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031B7F8: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031B7FC: sll         $t1, $s3, 16
    ctx->r9 = S32(ctx->r19 << 16);
    // 0x8031B800: sra         $s3, $t1, 16
    ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8031B804: bne         $v1, $zero, L_8031B780
    if (ctx->r3 != 0) {
        // 0x8031B808: addiu       $s0, $s0, 0x6
        ctx->r16 = ADD32(ctx->r16, 0X6);
            goto L_8031B780;
    }
    // 0x8031B808: addiu       $s0, $s0, 0x6
    ctx->r16 = ADD32(ctx->r16, 0X6);
    // 0x8031B80C: b           L_8031C2CC
    // 0x8031B810: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031B810: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031B814:
    // 0x8031B814: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8031B818: b           L_8031C2C8
    // 0x8031B81C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
        goto L_8031C2C8;
    // 0x8031B81C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
L_8031B820:
    // 0x8031B820: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B824: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B828: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B82C: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B830: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8031B834: jal         0x8031B0E8
    // 0x8031B838: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    copy_or_extract(rdram, ctx);
        goto after_14;
    // 0x8031B838: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    after_14:
    // 0x8031B83C: jal         0x8031B058
    // 0x8031B840: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_15;
    // 0x8031B840: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_15:
    // 0x8031B844: lui         $s1, 0x8010
    ctx->r17 = S32(0X8010 << 16);
    // 0x8031B848: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B84C: jal         0x80314788
    // 0x8031B850: lhu         $s1, 0x0($s1)
    ctx->r17 = MEM_HU(ctx->r17, 0X0);
    func_80314788_725E38(rdram, ctx);
        goto after_16;
    // 0x8031B850: lhu         $s1, 0x0($s1)
    ctx->r17 = MEM_HU(ctx->r17, 0X0);
    after_16:
    // 0x8031B854: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031B858: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8031B85C: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    // 0x8031B860: jal         0x80129158
    // 0x8031B864: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_17;
    // 0x8031B864: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_17:
    // 0x8031B868: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x8031B86C: divu        $zero, $s1, $at
    lo = S32(U32(ctx->r17) / U32(ctx->r1)); hi = S32(U32(ctx->r17) % U32(ctx->r1));
    // 0x8031B870: mflo        $t4
    ctx->r12 = lo;
    // 0x8031B874: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8031B878: sh          $t4, -0x71AC($at)
    MEM_H(-0X71AC, ctx->r1) = ctx->r12;
    // 0x8031B87C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8031B880: lhu         $v1, -0x71AC($v1)
    ctx->r3 = MEM_HU(ctx->r3, -0X71AC);
    // 0x8031B884: blezl       $v1, L_8031C2CC
    if (SIGNED(ctx->r3) <= 0) {
        // 0x8031B888: lbu         $t0, 0x85($sp)
        ctx->r8 = MEM_BU(ctx->r29, 0X85);
            goto L_8031C2CC;
    }
    goto skip_2;
    // 0x8031B888: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
    skip_2:
L_8031B88C:
    // 0x8031B88C: multu       $s0, $s7
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8031B890: addiu       $at, $zero, 0x18
    ctx->r1 = ADD32(0, 0X18);
    // 0x8031B894: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8031B898: addiu       $a0, $a0, -0x2768
    ctx->r4 = ADD32(ctx->r4, -0X2768);
    // 0x8031B89C: mflo        $t5
    ctx->r13 = lo;
    // 0x8031B8A0: addu        $v0, $s6, $t5
    ctx->r2 = ADD32(ctx->r22, ctx->r13);
    // 0x8031B8A4: lhu         $t6, 0x0($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X0);
    // 0x8031B8A8: bnel        $t6, $at, L_8031B8DC
    if (ctx->r14 != ctx->r1) {
        // 0x8031B8AC: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8031B8DC;
    }
    goto skip_3;
    // 0x8031B8AC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_3:
    // 0x8031B8B0: lhu         $t8, 0x8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X8);
    // 0x8031B8B4: lbu         $t7, 0x6($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X6);
    // 0x8031B8B8: lbu         $a1, 0x4($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X4);
    // 0x8031B8BC: lhu         $a2, 0x2($v0)
    ctx->r6 = MEM_HU(ctx->r2, 0X2);
    // 0x8031B8C0: lb          $a3, 0x5($v0)
    ctx->r7 = MEM_B(ctx->r2, 0X5);
    // 0x8031B8C4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8031B8C8: jal         0x8013966C
    // 0x8031B8CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    osSyncPrintf(rdram, ctx);
        goto after_18;
    // 0x8031B8CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_18:
    // 0x8031B8D0: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8031B8D4: lhu         $v1, -0x71AC($v1)
    ctx->r3 = MEM_HU(ctx->r3, -0X71AC);
    // 0x8031B8D8: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8031B8DC:
    // 0x8031B8DC: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x8031B8E0: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8031B8E4: slt         $at, $s0, $v1
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8031B8E8: bne         $at, $zero, L_8031B88C
    if (ctx->r1 != 0) {
        // 0x8031B8EC: nop
    
            goto L_8031B88C;
    }
    // 0x8031B8EC: nop

    // 0x8031B8F0: b           L_8031C2CC
    // 0x8031B8F4: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031B8F4: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031B8F8:
    // 0x8031B8F8: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B8FC: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B900: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B904: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B908: jal         0x8031B0E8
    // 0x8031B90C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_19;
    // 0x8031B90C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_19:
    // 0x8031B910: jal         0x8031B058
    // 0x8031B914: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_20;
    // 0x8031B914: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_20:
    // 0x8031B918: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031B91C: lh          $s0, 0x0($s0)
    ctx->r16 = MEM_H(ctx->r16, 0X0);
    // 0x8031B920: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031B924: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8031B928: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B92C: addiu       $a1, $a1, -0x6C50
    ctx->r5 = ADD32(ctx->r5, -0X6C50);
    // 0x8031B930: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8031B934: jal         0x80129158
    // 0x8031B938: sll         $a2, $s0, 3
    ctx->r6 = S32(ctx->r16 << 3);
    memcpy_sssv(rdram, ctx);
        goto after_21;
    // 0x8031B938: sll         $a2, $s0, 3
    ctx->r6 = S32(ctx->r16 << 3);
    after_21:
    // 0x8031B93C: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8031B940: addiu       $t3, $t3, -0x6C50
    ctx->r11 = ADD32(ctx->r11, -0X6C50);
    // 0x8031B944: sll         $t1, $s0, 3
    ctx->r9 = S32(ctx->r16 << 3);
    // 0x8031B948: addiu       $a0, $zero, 0xF5
    ctx->r4 = ADD32(0, 0XF5);
    // 0x8031B94C: addu        $v1, $t1, $t3
    ctx->r3 = ADD32(ctx->r9, ctx->r11);
    // 0x8031B950: sb          $a0, 0x2($v1)
    MEM_B(0X2, ctx->r3) = ctx->r4;
    // 0x8031B954: jal         0x803198B0
    // 0x8031B958: sb          $a0, 0x5($v1)
    MEM_B(0X5, ctx->r3) = ctx->r4;
    func_803198B0_72AF60(rdram, ctx);
        goto after_22;
    // 0x8031B958: sb          $a0, 0x5($v1)
    MEM_B(0X5, ctx->r3) = ctx->r4;
    after_22:
    // 0x8031B95C: b           L_8031C2CC
    // 0x8031B960: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031B960: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031B964:
    // 0x8031B964: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031B968: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031B96C: lui         $s1, 0x8010
    ctx->r17 = S32(0X8010 << 16);
    // 0x8031B970: addiu       $s1, $s1, 0x2
    ctx->r17 = ADD32(ctx->r17, 0X2);
    // 0x8031B974: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031B978: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031B97C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8031B980: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8031B984: jal         0x8031B0E8
    // 0x8031B988: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    copy_or_extract(rdram, ctx);
        goto after_23;
    // 0x8031B988: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    after_23:
    // 0x8031B98C: jal         0x8031B058
    // 0x8031B990: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_24;
    // 0x8031B990: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_24:
    // 0x8031B994: lui         $s2, 0x8010
    ctx->r18 = S32(0X8010 << 16);
    // 0x8031B998: lhu         $s2, 0x0($s2)
    ctx->r18 = MEM_HU(ctx->r18, 0X0);
    // 0x8031B99C: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031B9A0: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x8031B9A4: blez        $s2, L_8031BA08
    if (SIGNED(ctx->r18) <= 0) {
        // 0x8031B9A8: or          $v1, $s2, $zero
        ctx->r3 = ctx->r18 | 0;
            goto L_8031BA08;
    }
    // 0x8031B9A8: or          $v1, $s2, $zero
    ctx->r3 = ctx->r18 | 0;
    // 0x8031B9AC: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8031B9B0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031B9B4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8031B9B8: addiu       $v0, $v0, -0x70A0
    ctx->r2 = ADD32(ctx->r2, -0X70A0);
    // 0x8031B9BC: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8031B9C0: addiu       $a1, $a1, -0x71A0
    ctx->r5 = ADD32(ctx->r5, -0X71A0);
L_8031B9C4:
    // 0x8031B9C4: sll         $t4, $s3, 2
    ctx->r12 = S32(ctx->r19 << 2);
    // 0x8031B9C8: addu        $t5, $a1, $t4
    ctx->r13 = ADD32(ctx->r5, ctx->r12);
    // 0x8031B9CC: addu        $t2, $v0, $s0
    ctx->r10 = ADD32(ctx->r2, ctx->r16);
    // 0x8031B9D0: sw          $t2, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r10;
    // 0x8031B9D4: lbu         $t6, 0x0($s1)
    ctx->r14 = MEM_BU(ctx->r17, 0X0);
    // 0x8031B9D8: addiu       $s3, $s3, 0x1
    ctx->r19 = ADD32(ctx->r19, 0X1);
    // 0x8031B9DC: sll         $t9, $s3, 16
    ctx->r25 = S32(ctx->r19 << 16);
    // 0x8031B9E0: multu       $t6, $a2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8031B9E4: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8031B9E8: slt         $at, $s3, $v1
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8031B9EC: mflo        $t8
    ctx->r24 = lo;
    // 0x8031B9F0: addu        $s0, $s0, $t8
    ctx->r16 = ADD32(ctx->r16, ctx->r24);
    // 0x8031B9F4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8031B9F8: andi        $t7, $s0, 0xFFFF
    ctx->r15 = ctx->r16 & 0XFFFF;
    // 0x8031B9FC: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
    // 0x8031BA00: bne         $at, $zero, L_8031B9C4
    if (ctx->r1 != 0) {
        // 0x8031BA04: addu        $s1, $t7, $a0
        ctx->r17 = ADD32(ctx->r15, ctx->r4);
            goto L_8031B9C4;
    }
    // 0x8031BA04: addu        $s1, $t7, $a0
    ctx->r17 = ADD32(ctx->r15, ctx->r4);
L_8031BA08:
    // 0x8031BA08: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8031BA0C: addiu       $a0, $a0, -0x273C
    ctx->r4 = ADD32(ctx->r4, -0X273C);
    // 0x8031BA10: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8031BA14: jal         0x8013966C
    // 0x8031BA18: addiu       $a2, $zero, 0x44C
    ctx->r6 = ADD32(0, 0X44C);
    osSyncPrintf(rdram, ctx);
        goto after_25;
    // 0x8031BA18: addiu       $a2, $zero, 0x44C
    ctx->r6 = ADD32(0, 0X44C);
    after_25:
    // 0x8031BA1C: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031BA20: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8031BA24: addiu       $a1, $a1, -0x70A0
    ctx->r5 = ADD32(ctx->r5, -0X70A0);
    // 0x8031BA28: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8031BA2C: jal         0x80129158
    // 0x8031BA30: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_26;
    // 0x8031BA30: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_26:
    // 0x8031BA34: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8031BA38: b           L_8031C2C8
    // 0x8031BA3C: sh          $s2, 0x5750($at)
    MEM_H(0X5750, ctx->r1) = ctx->r18;
        goto L_8031C2C8;
    // 0x8031BA3C: sh          $s2, 0x5750($at)
    MEM_H(0X5750, ctx->r1) = ctx->r18;
L_8031BA40:
    // 0x8031BA40: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031BA44: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031BA48: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031BA4C: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x8031BA50: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031BA54: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031BA58: jal         0x8031B0E8
    // 0x8031BA5C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_27;
    // 0x8031BA5C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_27:
    // 0x8031BA60: jal         0x8031B058
    // 0x8031BA64: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_28;
    // 0x8031BA64: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_28:
    // 0x8031BA68: lui         $s3, 0x8010
    ctx->r19 = S32(0X8010 << 16);
    // 0x8031BA6C: lh          $s3, 0x0($s3)
    ctx->r19 = MEM_H(ctx->r19, 0X0);
    // 0x8031BA70: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031BA74: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8031BA78: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031BA7C: sll         $t1, $s3, 16
    ctx->r9 = S32(ctx->r19 << 16);
    // 0x8031BA80: beq         $v1, $zero, L_8031C2C8
    if (ctx->r3 == 0) {
        // 0x8031BA84: sra         $s3, $t1, 16
        ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
            goto L_8031C2C8;
    }
    // 0x8031BA84: sra         $s3, $t1, 16
    ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
L_8031BA88:
    // 0x8031BA88: lh          $a0, 0xE($s0)
    ctx->r4 = MEM_H(ctx->r16, 0XE);
    // 0x8031BA8C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8031BA90: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x8031BA94: beq         $a0, $at, L_8031BAA8
    if (ctx->r4 == ctx->r1) {
        // 0x8031BA98: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_8031BAA8;
    }
    // 0x8031BA98: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x8031BA9C: jal         0x802C93E8
    // 0x8031BAA0: nop

    func_802C93E8_6DAA98(rdram, ctx);
        goto after_29;
    // 0x8031BAA0: nop

    after_29:
    // 0x8031BAA4: or          $s1, $v0, $zero
    ctx->r17 = ctx->r2 | 0;
L_8031BAA8:
    // 0x8031BAA8: lh          $a0, 0x16($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X16);
    // 0x8031BAAC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8031BAB0: beql        $a0, $at, L_8031BAC8
    if (ctx->r4 == ctx->r1) {
        // 0x8031BAB4: lhu         $v0, 0x0($s0)
        ctx->r2 = MEM_HU(ctx->r16, 0X0);
            goto L_8031BAC8;
    }
    goto skip_4;
    // 0x8031BAB4: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    skip_4:
    // 0x8031BAB8: jal         0x802C93E8
    // 0x8031BABC: nop

    func_802C93E8_6DAA98(rdram, ctx);
        goto after_30;
    // 0x8031BABC: nop

    after_30:
    // 0x8031BAC0: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
    // 0x8031BAC4: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_8031BAC8:
    // 0x8031BAC8: addiu       $t4, $v0, -0x6
    ctx->r12 = ADD32(ctx->r2, -0X6);
    // 0x8031BACC: sltiu       $at, $t4, 0x20
    ctx->r1 = ctx->r12 < 0X20 ? 1 : 0;
    // 0x8031BAD0: beq         $at, $zero, L_8031BFFC
    if (ctx->r1 == 0) {
        // 0x8031BAD4: sll         $t4, $t4, 2
        ctx->r12 = S32(ctx->r12 << 2);
            goto L_8031BFFC;
    }
    // 0x8031BAD4: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8031BAD8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8031BADC: addu        $at, $at, $t4
    gpr jr_addend_8031BAE4 = ctx->r12;
    ctx->r1 = ADD32(ctx->r1, ctx->r12);
    // 0x8031BAE0: lw          $t4, -0x26E0($at)
    ctx->r12 = ADD32(ctx->r1, -0X26E0);
    // 0x8031BAE4: jr          $t4
    // 0x8031BAE8: nop

    switch (jr_addend_8031BAE4 >> 2) {
        case 0: goto L_8031BAEC; break;
        case 1: goto L_8031BB70; break;
        case 2: goto L_8031BF74; break;
        case 3: goto L_8031BE4C; break;
        case 4: goto L_8031BEDC; break;
        case 5: goto L_8031BFFC; break;
        case 6: goto L_8031BFFC; break;
        case 7: goto L_8031BFFC; break;
        case 8: goto L_8031BFFC; break;
        case 9: goto L_8031BFFC; break;
        case 10: goto L_8031BFFC; break;
        case 11: goto L_8031BFFC; break;
        case 12: goto L_8031BFFC; break;
        case 13: goto L_8031BBF4; break;
        case 14: goto L_8031BBF4; break;
        case 15: goto L_8031BBF4; break;
        case 16: goto L_8031BC8C; break;
        case 17: goto L_8031BC8C; break;
        case 18: goto L_8031BC8C; break;
        case 19: goto L_8031BD20; break;
        case 20: goto L_8031BD20; break;
        case 21: goto L_8031BD20; break;
        case 22: goto L_8031BDB8; break;
        case 23: goto L_8031BDB8; break;
        case 24: goto L_8031BDB8; break;
        case 25: goto L_8031BFFC; break;
        case 26: goto L_8031BFFC; break;
        case 27: goto L_8031BFFC; break;
        case 28: goto L_8031BFFC; break;
        case 29: goto L_8031BFFC; break;
        case 30: goto L_8031BC8C; break;
        case 31: goto L_8031BDB8; break;
        default: switch_error(__func__, 0x8031BAE4, 0x803BD920);
    }
    // 0x8031BAE8: nop

L_8031BAEC:
    // 0x8031BAEC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BAF0: lh          $t2, 0x2($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2);
    // 0x8031BAF4: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    // 0x8031BAF8: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BAFC: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x8031BB00: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x8031BB04: lh          $t6, 0x4($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X4);
    // 0x8031BB08: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8031BB0C: addiu       $a3, $zero, 0x6
    ctx->r7 = ADD32(0, 0X6);
    // 0x8031BB10: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8031BB14: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8031BB18: lh          $t7, 0x6($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X6);
    // 0x8031BB1C: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BB20: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BB24: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8031BB28: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8031BB2C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8031BB30: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8031BB34: lh          $t0, 0x10($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X10);
    // 0x8031BB38: sw          $t0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r8;
    // 0x8031BB3C: lh          $t1, 0x12($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X12);
    // 0x8031BB40: sw          $t1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r9;
    // 0x8031BB44: lh          $t3, 0x14($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X14);
    // 0x8031BB48: sw          $t3, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r11;
    // 0x8031BB4C: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x8031BB50: sw          $t4, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r12;
    // 0x8031BB54: lh          $t2, 0xA($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XA);
    // 0x8031BB58: sw          $t2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r10;
    // 0x8031BB5C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x8031BB60: jal         0x802DD090
    // 0x8031BB64: sw          $t5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r13;
    func_802DD090_6EE740(rdram, ctx);
        goto after_31;
    // 0x8031BB64: sw          $t5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r13;
    after_31:
    // 0x8031BB68: b           L_8031C000
    // 0x8031BB6C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BB6C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BB70:
    // 0x8031BB70: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BB74: lh          $t6, 0x2($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2);
    // 0x8031BB78: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8031BB7C: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BB80: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8031BB84: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8031BB88: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x8031BB8C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8031BB90: addiu       $a3, $zero, 0x7
    ctx->r7 = ADD32(0, 0X7);
    // 0x8031BB94: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8031BB98: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8031BB9C: lh          $t0, 0x6($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X6);
    // 0x8031BBA0: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BBA4: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BBA8: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8031BBAC: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x8031BBB0: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8031BBB4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8031BBB8: lh          $t3, 0x10($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X10);
    // 0x8031BBBC: sw          $t3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r11;
    // 0x8031BBC0: lh          $t4, 0x12($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X12);
    // 0x8031BBC4: sw          $t4, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r12;
    // 0x8031BBC8: lh          $t2, 0x14($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X14);
    // 0x8031BBCC: sw          $t2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r10;
    // 0x8031BBD0: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x8031BBD4: sw          $t5, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r13;
    // 0x8031BBD8: lh          $t6, 0xA($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XA);
    // 0x8031BBDC: sw          $t6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r14;
    // 0x8031BBE0: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x8031BBE4: jal         0x802DD090
    // 0x8031BBE8: sw          $t8, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r24;
    func_802DD090_6EE740(rdram, ctx);
        goto after_32;
    // 0x8031BBE8: sw          $t8, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r24;
    after_32:
    // 0x8031BBEC: b           L_8031C000
    // 0x8031BBF0: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BBF0: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BBF4:
    // 0x8031BBF4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8031BBF8: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8031BBFC: lh          $t0, 0x2($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2);
    // 0x8031BC00: sll         $a3, $v0, 24
    ctx->r7 = S32(ctx->r2 << 24);
    // 0x8031BC04: sra         $t7, $a3, 24
    ctx->r15 = S32(SIGNED(ctx->r7) >> 24);
    // 0x8031BC08: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8031BC0C: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    // 0x8031BC10: lh          $t3, 0x4($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X4);
    // 0x8031BC14: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x8031BC18: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8031BC1C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x8031BC20: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8031BC24: lh          $t2, 0x6($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X6);
    // 0x8031BC28: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BC2C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BC30: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x8031BC34: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x8031BC38: lbu         $t6, 0x18($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BC3C: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8031BC40: lbu         $t8, 0x19($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BC44: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BC48: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BC4C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8031BC50: lh          $t7, 0x10($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X10);
    // 0x8031BC54: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    // 0x8031BC58: lh          $t9, 0x12($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X12);
    // 0x8031BC5C: sw          $t9, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r25;
    // 0x8031BC60: lh          $t0, 0x14($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X14);
    // 0x8031BC64: sw          $t0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r8;
    // 0x8031BC68: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x8031BC6C: sw          $t1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r9;
    // 0x8031BC70: lh          $t3, 0xA($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XA);
    // 0x8031BC74: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x8031BC78: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x8031BC7C: jal         0x802DD090
    // 0x8031BC80: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    func_802DD090_6EE740(rdram, ctx);
        goto after_33;
    // 0x8031BC80: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    after_33:
    // 0x8031BC84: b           L_8031C000
    // 0x8031BC88: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BC88: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BC8C:
    // 0x8031BC8C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BC90: lh          $t5, 0x2($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X2);
    // 0x8031BC94: sll         $a3, $v0, 24
    ctx->r7 = S32(ctx->r2 << 24);
    // 0x8031BC98: sra         $t2, $a3, 24
    ctx->r10 = S32(SIGNED(ctx->r7) >> 24);
    // 0x8031BC9C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8031BCA0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8031BCA4: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x8031BCA8: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x8031BCAC: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8031BCB0: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x8031BCB4: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8031BCB8: lh          $t9, 0x6($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X6);
    // 0x8031BCBC: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BCC0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BCC4: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x8031BCC8: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x8031BCCC: lbu         $t1, 0x18($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BCD0: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x8031BCD4: lbu         $t3, 0x19($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BCD8: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BCDC: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BCE0: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x8031BCE4: lh          $t4, 0x10($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X10);
    // 0x8031BCE8: sw          $t4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r12;
    // 0x8031BCEC: lh          $t2, 0x12($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X12);
    // 0x8031BCF0: sw          $t2, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r10;
    // 0x8031BCF4: lh          $t5, 0x14($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X14);
    // 0x8031BCF8: sw          $t5, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r13;
    // 0x8031BCFC: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x8031BD00: sw          $t6, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r14;
    // 0x8031BD04: lh          $t8, 0xA($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XA);
    // 0x8031BD08: sw          $t8, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r24;
    // 0x8031BD0C: lh          $t7, 0xC($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XC);
    // 0x8031BD10: jal         0x802DD090
    // 0x8031BD14: sw          $t7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r15;
    func_802DD090_6EE740(rdram, ctx);
        goto after_34;
    // 0x8031BD14: sw          $t7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r15;
    after_34:
    // 0x8031BD18: b           L_8031C000
    // 0x8031BD1C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BD1C: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BD20:
    // 0x8031BD20: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x8031BD24: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8031BD28: lh          $t1, 0x2($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2);
    // 0x8031BD2C: sll         $a3, $v0, 24
    ctx->r7 = S32(ctx->r2 << 24);
    // 0x8031BD30: sra         $t9, $a3, 24
    ctx->r25 = S32(SIGNED(ctx->r7) >> 24);
    // 0x8031BD34: sll         $t3, $t1, 16
    ctx->r11 = S32(ctx->r9 << 16);
    // 0x8031BD38: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x8031BD3C: lh          $t4, 0x4($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X4);
    // 0x8031BD40: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8031BD44: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    // 0x8031BD48: sll         $t2, $t4, 16
    ctx->r10 = S32(ctx->r12 << 16);
    // 0x8031BD4C: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x8031BD50: lh          $t5, 0x6($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X6);
    // 0x8031BD54: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BD58: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BD5C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8031BD60: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8031BD64: lbu         $t8, 0x18($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BD68: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8031BD6C: lbu         $t7, 0x19($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BD70: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BD74: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BD78: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8031BD7C: lh          $t9, 0x10($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X10);
    // 0x8031BD80: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    // 0x8031BD84: lh          $t0, 0x12($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X12);
    // 0x8031BD88: sw          $t0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r8;
    // 0x8031BD8C: lh          $t1, 0x14($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X14);
    // 0x8031BD90: sw          $t1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r9;
    // 0x8031BD94: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x8031BD98: sw          $t3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r11;
    // 0x8031BD9C: lh          $t4, 0xA($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XA);
    // 0x8031BDA0: sw          $t4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r12;
    // 0x8031BDA4: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x8031BDA8: jal         0x802DD090
    // 0x8031BDAC: sw          $t2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r10;
    func_802DD090_6EE740(rdram, ctx);
        goto after_35;
    // 0x8031BDAC: sw          $t2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r10;
    after_35:
    // 0x8031BDB0: b           L_8031C000
    // 0x8031BDB4: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BDB4: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BDB8:
    // 0x8031BDB8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BDBC: lh          $t6, 0x2($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2);
    // 0x8031BDC0: sll         $a3, $v0, 24
    ctx->r7 = S32(ctx->r2 << 24);
    // 0x8031BDC4: sra         $t5, $a3, 24
    ctx->r13 = S32(SIGNED(ctx->r7) >> 24);
    // 0x8031BDC8: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8031BDCC: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8031BDD0: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x8031BDD4: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x8031BDD8: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    // 0x8031BDDC: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8031BDE0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8031BDE4: lh          $t0, 0x6($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X6);
    // 0x8031BDE8: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8031BDEC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BDF0: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8031BDF4: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x8031BDF8: lbu         $t3, 0x18($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BDFC: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    // 0x8031BE00: lbu         $t4, 0x19($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BE04: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BE08: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BE0C: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x8031BE10: lh          $t2, 0x10($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X10);
    // 0x8031BE14: sw          $t2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r10;
    // 0x8031BE18: lh          $t5, 0x12($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X12);
    // 0x8031BE1C: sw          $t5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r13;
    // 0x8031BE20: lh          $t6, 0x14($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X14);
    // 0x8031BE24: sw          $t6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r14;
    // 0x8031BE28: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x8031BE2C: sw          $t8, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r24;
    // 0x8031BE30: lh          $t7, 0xA($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XA);
    // 0x8031BE34: sw          $t7, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r15;
    // 0x8031BE38: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x8031BE3C: jal         0x802DD090
    // 0x8031BE40: sw          $t9, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r25;
    func_802DD090_6EE740(rdram, ctx);
        goto after_36;
    // 0x8031BE40: sw          $t9, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r25;
    after_36:
    // 0x8031BE44: b           L_8031C000
    // 0x8031BE48: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BE48: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BE4C:
    // 0x8031BE4C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BE50: lh          $t0, 0x2($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2);
    // 0x8031BE54: lui         $a1, 0x9
    ctx->r5 = S32(0X9 << 16);
    // 0x8031BE58: ori         $a1, $a1, 0x6000
    ctx->r5 = ctx->r5 | 0X6000;
    // 0x8031BE5C: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8031BE60: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    // 0x8031BE64: lh          $t3, 0x4($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X4);
    // 0x8031BE68: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x8031BE6C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BE70: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x8031BE74: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8031BE78: lh          $t2, 0x6($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X6);
    // 0x8031BE7C: addiu       $a3, $zero, 0x9
    ctx->r7 = ADD32(0, 0X9);
    // 0x8031BE80: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x8031BE84: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x8031BE88: lbu         $t6, 0x18($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BE8C: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8031BE90: lbu         $t8, 0x19($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BE94: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BE98: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BE9C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8031BEA0: lh          $t7, 0x10($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X10);
    // 0x8031BEA4: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    // 0x8031BEA8: lh          $t9, 0x12($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X12);
    // 0x8031BEAC: sw          $t9, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r25;
    // 0x8031BEB0: lh          $t0, 0x14($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X14);
    // 0x8031BEB4: sw          $t0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r8;
    // 0x8031BEB8: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x8031BEBC: sw          $t1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r9;
    // 0x8031BEC0: lh          $t3, 0xA($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XA);
    // 0x8031BEC4: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x8031BEC8: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x8031BECC: jal         0x802DD090
    // 0x8031BED0: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    func_802DD090_6EE740(rdram, ctx);
        goto after_37;
    // 0x8031BED0: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    after_37:
    // 0x8031BED4: b           L_8031C000
    // 0x8031BED8: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BED8: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BEDC:
    // 0x8031BEDC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BEE0: lh          $t5, 0x2($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X2);
    // 0x8031BEE4: sll         $a3, $s7, 24
    ctx->r7 = S32(ctx->r23 << 24);
    // 0x8031BEE8: sra         $t2, $a3, 24
    ctx->r10 = S32(SIGNED(ctx->r7) >> 24);
    // 0x8031BEEC: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8031BEF0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8031BEF4: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x8031BEF8: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x8031BEFC: lui         $a1, 0x9
    ctx->r5 = S32(0X9 << 16);
    // 0x8031BF00: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x8031BF04: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8031BF08: lh          $t9, 0x6($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X6);
    // 0x8031BF0C: ori         $a1, $a1, 0x6000
    ctx->r5 = ctx->r5 | 0X6000;
    // 0x8031BF10: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x8031BF14: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x8031BF18: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x8031BF1C: lbu         $t1, 0x18($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BF20: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BF24: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x8031BF28: lbu         $t3, 0x19($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BF2C: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BF30: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BF34: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x8031BF38: lh          $t4, 0x10($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X10);
    // 0x8031BF3C: sw          $t4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r12;
    // 0x8031BF40: lh          $t2, 0x12($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X12);
    // 0x8031BF44: sw          $t2, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r10;
    // 0x8031BF48: lh          $t5, 0x14($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X14);
    // 0x8031BF4C: sw          $t5, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r13;
    // 0x8031BF50: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x8031BF54: sw          $t6, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r14;
    // 0x8031BF58: lh          $t8, 0xA($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XA);
    // 0x8031BF5C: sw          $t8, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r24;
    // 0x8031BF60: lh          $t7, 0xC($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XC);
    // 0x8031BF64: jal         0x802DD090
    // 0x8031BF68: sw          $t7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r15;
    func_802DD090_6EE740(rdram, ctx);
        goto after_38;
    // 0x8031BF68: sw          $t7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r15;
    after_38:
    // 0x8031BF6C: b           L_8031C000
    // 0x8031BF70: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
        goto L_8031C000;
    // 0x8031BF70: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031BF74:
    // 0x8031BF74: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8031BF78: lh          $t9, 0x2($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2);
    // 0x8031BF7C: lui         $a1, 0xA
    ctx->r5 = S32(0XA << 16);
    // 0x8031BF80: ori         $a1, $a1, 0xD400
    ctx->r5 = ctx->r5 | 0XD400;
    // 0x8031BF84: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x8031BF88: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x8031BF8C: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x8031BF90: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8031BF94: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8031BF98: sll         $t3, $t1, 16
    ctx->r11 = S32(ctx->r9 << 16);
    // 0x8031BF9C: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x8031BFA0: lh          $t4, 0x6($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X6);
    // 0x8031BFA4: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x8031BFA8: sll         $t2, $t4, 16
    ctx->r10 = S32(ctx->r12 << 16);
    // 0x8031BFAC: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x8031BFB0: lbu         $t5, 0x18($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X18);
    // 0x8031BFB4: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x8031BFB8: lbu         $t6, 0x19($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X19);
    // 0x8031BFBC: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8031BFC0: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x8031BFC4: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8031BFC8: lh          $t8, 0x10($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X10);
    // 0x8031BFCC: sw          $t8, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r24;
    // 0x8031BFD0: lh          $t7, 0x12($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X12);
    // 0x8031BFD4: sw          $t7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r15;
    // 0x8031BFD8: lh          $t9, 0x14($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X14);
    // 0x8031BFDC: sw          $t9, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r25;
    // 0x8031BFE0: lh          $t0, 0x8($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X8);
    // 0x8031BFE4: sw          $t0, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r8;
    // 0x8031BFE8: lh          $t1, 0xA($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XA);
    // 0x8031BFEC: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x8031BFF0: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x8031BFF4: jal         0x802DD090
    // 0x8031BFF8: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    func_802DD090_6EE740(rdram, ctx);
        goto after_39;
    // 0x8031BFF8: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    after_39:
L_8031BFFC:
    // 0x8031BFFC: slt         $v1, $zero, $s3
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r19) ? 1 : 0;
L_8031C000:
    // 0x8031C000: addiu       $s3, $s3, -0x1
    ctx->r19 = ADD32(ctx->r19, -0X1);
    // 0x8031C004: sll         $t4, $s3, 16
    ctx->r12 = S32(ctx->r19 << 16);
    // 0x8031C008: sra         $s3, $t4, 16
    ctx->r19 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8031C00C: bne         $v1, $zero, L_8031BA88
    if (ctx->r3 != 0) {
        // 0x8031C010: addiu       $s0, $s0, 0x1A
        ctx->r16 = ADD32(ctx->r16, 0X1A);
            goto L_8031BA88;
    }
    // 0x8031C010: addiu       $s0, $s0, 0x1A
    ctx->r16 = ADD32(ctx->r16, 0X1A);
    // 0x8031C014: b           L_8031C2CC
    // 0x8031C018: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C018: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C01C:
    // 0x8031C01C: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C020: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C024: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C028: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C02C: jal         0x8031B0E8
    // 0x8031C030: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_40;
    // 0x8031C030: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_40:
    // 0x8031C034: jal         0x8031B058
    // 0x8031C038: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_41;
    // 0x8031C038: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_41:
    // 0x8031C03C: b           L_8031C2C8
    // 0x8031C040: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
        goto L_8031C2C8;
    // 0x8031C040: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
L_8031C044:
    // 0x8031C044: jal         0x80296544
    // 0x8031C048: nop

    func_80296544_6A7BF4(rdram, ctx);
        goto after_42;
    // 0x8031C048: nop

    after_42:
    // 0x8031C04C: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C050: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C054: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C058: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C05C: jal         0x8031B0E8
    // 0x8031C060: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_43;
    // 0x8031C060: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_43:
    // 0x8031C064: jal         0x8031B058
    // 0x8031C068: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_44;
    // 0x8031C068: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_44:
    // 0x8031C06C: jal         0x8029ACC8
    // 0x8031C070: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    func_8029ACC8_6AC378(rdram, ctx);
        goto after_45;
    // 0x8031C070: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    after_45:
    // 0x8031C074: b           L_8031C2CC
    // 0x8031C078: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C078: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C07C:
    // 0x8031C07C: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C080: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C084: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C088: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C08C: jal         0x8031B0E8
    // 0x8031C090: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_46;
    // 0x8031C090: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_46:
    // 0x8031C094: jal         0x8031B058
    // 0x8031C098: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_47;
    // 0x8031C098: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_47:
    // 0x8031C09C: jal         0x80344240
    // 0x8031C0A0: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    func_80344240_7558F0(rdram, ctx);
        goto after_48;
    // 0x8031C0A0: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    after_48:
    // 0x8031C0A4: b           L_8031C2CC
    // 0x8031C0A8: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C0A8: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C0AC:
    // 0x8031C0AC: jal         0x80304170
    // 0x8031C0B0: nop

    func_80304170_715820(rdram, ctx);
        goto after_49;
    // 0x8031C0B0: nop

    after_49:
    // 0x8031C0B4: jal         0x8031AFD0
    // 0x8031C0B8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_uncompressed_size(rdram, ctx);
        goto after_50;
    // 0x8031C0B8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_50:
    // 0x8031C0BC: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C0C0: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C0C4: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x8031C0C8: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C0CC: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C0D0: jal         0x8031B0E8
    // 0x8031C0D4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_51;
    // 0x8031C0D4: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_51:
    // 0x8031C0D8: jal         0x8031B058
    // 0x8031C0DC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_52;
    // 0x8031C0DC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_52:
    // 0x8031C0E0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031C0E4: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x8031C0E8: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031C0EC: addiu       $a1, $a1, 0x1D30
    ctx->r5 = ADD32(ctx->r5, 0X1D30);
    // 0x8031C0F0: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8031C0F4: jal         0x80129158
    // 0x8031C0F8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_53;
    // 0x8031C0F8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_53:
    // 0x8031C0FC: b           L_8031C2CC
    // 0x8031C100: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C100: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C104:
    // 0x8031C104: jal         0x80304194
    // 0x8031C108: nop

    func_80304194_715844(rdram, ctx);
        goto after_54;
    // 0x8031C108: nop

    after_54:
    // 0x8031C10C: jal         0x8031AFD0
    // 0x8031C110: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_uncompressed_size(rdram, ctx);
        goto after_55;
    // 0x8031C110: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_55:
    // 0x8031C114: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C118: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C11C: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x8031C120: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C124: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C128: jal         0x8031B0E8
    // 0x8031C12C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_56;
    // 0x8031C12C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_56:
    // 0x8031C130: jal         0x8031B058
    // 0x8031C134: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_57;
    // 0x8031C134: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_57:
    // 0x8031C138: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031C13C: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8031C140: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031C144: addiu       $a1, $a1, 0x2D50
    ctx->r5 = ADD32(ctx->r5, 0X2D50);
    // 0x8031C148: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8031C14C: jal         0x80129158
    // 0x8031C150: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_58;
    // 0x8031C150: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_58:
    // 0x8031C154: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8031C158: addiu       $v1, $v1, 0x2D50
    ctx->r3 = ADD32(ctx->r3, 0X2D50);
    // 0x8031C15C: lh          $t5, 0x40($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X40);
    // 0x8031C160: lbu         $a0, 0x21($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X21);
    // 0x8031C164: lbu         $a1, 0x53($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0X53);
    // 0x8031C168: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x8031C16C: nop

    // 0x8031C170: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8031C174: jal         0x8031B174
    // 0x8031C178: swc1        $f6, 0xE0($v1)
    MEM_W(0XE0, ctx->r3) = ctx->f6.u32l;
    load_level_texture_data(rdram, ctx);
        goto after_59;
    // 0x8031C178: swc1        $f6, 0xE0($v1)
    MEM_W(0XE0, ctx->r3) = ctx->f6.u32l;
    after_59:
    // 0x8031C17C: b           L_8031C2CC
    // 0x8031C180: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C180: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C184:
    // 0x8031C184: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C188: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C18C: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C190: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C194: jal         0x8031B0E8
    // 0x8031C198: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_60;
    // 0x8031C198: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_60:
    // 0x8031C19C: jal         0x8031B058
    // 0x8031C1A0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_61;
    // 0x8031C1A0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_61:
    // 0x8031C1A4: lui         $s0, 0x8010
    ctx->r16 = S32(0X8010 << 16);
    // 0x8031C1A8: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x8031C1AC: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031C1B0: lh          $s0, 0x0($s0)
    ctx->r16 = MEM_H(ctx->r16, 0X0);
    // 0x8031C1B4: addiu       $a0, $a0, 0x6D14
    ctx->r4 = ADD32(ctx->r4, 0X6D14);
    // 0x8031C1B8: jal         0x80128FB4
    // 0x8031C1BC: addiu       $a1, $zero, 0x400
    ctx->r5 = ADD32(0, 0X400);
    bzero_sssv(rdram, ctx);
        goto after_62;
    // 0x8031C1BC: addiu       $a1, $zero, 0x400
    ctx->r5 = ADD32(0, 0X400);
    after_62:
    // 0x8031C1C0: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x8031C1C4: addiu       $a0, $a0, 0x7114
    ctx->r4 = ADD32(ctx->r4, 0X7114);
    // 0x8031C1C8: jal         0x80128FB4
    // 0x8031C1CC: addiu       $a1, $zero, 0xA00
    ctx->r5 = ADD32(0, 0XA00);
    bzero_sssv(rdram, ctx);
        goto after_63;
    // 0x8031C1CC: addiu       $a1, $zero, 0xA00
    ctx->r5 = ADD32(0, 0XA00);
    after_63:
    // 0x8031C1D0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031C1D4: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x8031C1D8: sll         $s1, $s0, 3
    ctx->r17 = S32(ctx->r16 << 3);
    // 0x8031C1DC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x8031C1E0: addiu       $a1, $a1, 0x6D14
    ctx->r5 = ADD32(ctx->r5, 0X6D14);
    // 0x8031C1E4: jal         0x80129158
    // 0x8031C1E8: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    memcpy_sssv(rdram, ctx);
        goto after_64;
    // 0x8031C1E8: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    after_64:
    // 0x8031C1EC: srl         $t6, $s1, 1
    ctx->r14 = S32(U32(ctx->r17) >> 1);
    // 0x8031C1F0: lui         $t7, 0x8010
    ctx->r15 = S32(0X8010 << 16);
    // 0x8031C1F4: sll         $a2, $s0, 2
    ctx->r6 = S32(ctx->r16 << 2);
    // 0x8031C1F8: addiu       $t7, $t7, 0x2
    ctx->r15 = ADD32(ctx->r15, 0X2);
    // 0x8031C1FC: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x8031C200: addu        $a2, $a2, $s0
    ctx->r6 = ADD32(ctx->r6, ctx->r16);
    // 0x8031C204: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x8031C208: addu        $a0, $t8, $t7
    ctx->r4 = ADD32(ctx->r24, ctx->r15);
    // 0x8031C20C: addiu       $a1, $a1, 0x7114
    ctx->r5 = ADD32(ctx->r5, 0X7114);
    // 0x8031C210: jal         0x80129158
    // 0x8031C214: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    memcpy_sssv(rdram, ctx);
        goto after_65;
    // 0x8031C214: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    after_65:
    // 0x8031C218: jal         0x8034401C
    // 0x8031C21C: nop

    func_8034401C_7556CC(rdram, ctx);
        goto after_66;
    // 0x8031C21C: nop

    after_66:
    // 0x8031C220: b           L_8031C2CC
    // 0x8031C224: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C224: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C228:
    // 0x8031C228: jal         0x8031AFD0
    // 0x8031C22C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_uncompressed_size(rdram, ctx);
        goto after_67;
    // 0x8031C22C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_67:
    // 0x8031C230: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C234: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C238: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x8031C23C: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C240: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C244: jal         0x8031B0E8
    // 0x8031C248: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_68;
    // 0x8031C248: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_68:
    // 0x8031C24C: jal         0x8031B058
    // 0x8031C250: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_69;
    // 0x8031C250: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_69:
    // 0x8031C254: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031C258: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x8031C25C: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031C260: addiu       $a1, $a1, 0x2930
    ctx->r5 = ADD32(ctx->r5, 0X2930);
    // 0x8031C264: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8031C268: jal         0x80129158
    // 0x8031C26C: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_70;
    // 0x8031C26C: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_70:
    // 0x8031C270: b           L_8031C2CC
    // 0x8031C274: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C274: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C278:
    // 0x8031C278: lui         $a1, 0x8010
    ctx->r5 = S32(0X8010 << 16);
    // 0x8031C27C: lui         $a2, 0x2
    ctx->r6 = S32(0X2 << 16);
    // 0x8031C280: ori         $a2, $a2, 0x5800
    ctx->r6 = ctx->r6 | 0X5800;
    // 0x8031C284: addiu       $a1, $a1, 0x0
    ctx->r5 = ADD32(ctx->r5, 0X0);
    // 0x8031C288: jal         0x8031B0E8
    // 0x8031C28C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    copy_or_extract(rdram, ctx);
        goto after_71;
    // 0x8031C28C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_71:
    // 0x8031C290: jal         0x8031B058
    // 0x8031C294: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    get_compressed_size(rdram, ctx);
        goto after_72;
    // 0x8031C294: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_72:
    // 0x8031C298: lui         $v1, 0x8010
    ctx->r3 = S32(0X8010 << 16);
    // 0x8031C29C: lh          $v1, 0x0($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X0);
    // 0x8031C2A0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8031C2A4: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8031C2A8: addu        $s4, $s4, $v0
    ctx->r20 = ADD32(ctx->r20, ctx->r2);
    // 0x8031C2AC: addiu       $a1, $a1, 0x1D20
    ctx->r5 = ADD32(ctx->r5, 0X1D20);
    // 0x8031C2B0: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8031C2B4: jal         0x80129158
    // 0x8031C2B8: sll         $a2, $v1, 3
    ctx->r6 = S32(ctx->r3 << 3);
    memcpy_sssv(rdram, ctx);
        goto after_73;
    // 0x8031C2B8: sll         $a2, $v1, 3
    ctx->r6 = S32(ctx->r3 << 3);
    after_73:
    // 0x8031C2BC: b           L_8031C2CC
    // 0x8031C2C0: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
        goto L_8031C2CC;
    // 0x8031C2C0: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C2C4:
    // 0x8031C2C4: sb          $t9, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r25;
L_8031C2C8:
    // 0x8031C2C8: lbu         $t0, 0x85($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X85);
L_8031C2CC:
    // 0x8031C2CC: beql        $t0, $zero, L_8031B480
    if (ctx->r8 == 0) {
        // 0x8031C2D0: lbu         $v0, 0x0($s4)
        ctx->r2 = MEM_BU(ctx->r20, 0X0);
            goto L_8031B480;
    }
    goto skip_5;
    // 0x8031C2D0: lbu         $v0, 0x0($s4)
    ctx->r2 = MEM_BU(ctx->r20, 0X0);
    skip_5:
    // 0x8031C2D4: lw          $ra, 0x74($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X74);
    // 0x8031C2D8: lw          $s0, 0x50($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X50);
    // 0x8031C2DC: lw          $s1, 0x54($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X54);
    // 0x8031C2E0: lw          $s2, 0x58($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X58);
    // 0x8031C2E4: lw          $s3, 0x5C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X5C);
    // 0x8031C2E8: lw          $s4, 0x60($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X60);
    // 0x8031C2EC: lw          $s5, 0x64($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X64);
    // 0x8031C2F0: lw          $s6, 0x68($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X68);
    // 0x8031C2F4: lw          $s7, 0x6C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X6C);
    // 0x8031C2F8: lw          $fp, 0x70($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X70);
    // 0x8031C2FC: jr          $ra
    // 0x8031C300: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
    return;
    // 0x8031C300: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
;}
RECOMP_FUNC void static_2_8039DBC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DBC8: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8039DBCC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8039DBD0: lh          $v0, 0x63C0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X63C0);
    // 0x8039DBD4: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8039DBD8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8039DBDC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8039DBE0: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8039DBE4: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8039DBE8: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8039DBEC: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8039DBF0: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8039DBF4: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x8039DBF8: blez        $v0, L_8039DC7C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8039DBFC: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_8039DC7C;
    }
    // 0x8039DBFC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8039DC00: lui         $s5, 0x803F
    ctx->r21 = S32(0X803F << 16);
    // 0x8039DC04: lui         $s2, 0x803F
    ctx->r18 = S32(0X803F << 16);
    // 0x8039DC08: lui         $s1, 0x803F
    ctx->r17 = S32(0X803F << 16);
    // 0x8039DC0C: addiu       $s1, $s1, 0x34C0
    ctx->r17 = ADD32(ctx->r17, 0X34C0);
    // 0x8039DC10: addiu       $s2, $s2, 0x3330
    ctx->r18 = ADD32(ctx->r18, 0X3330);
    // 0x8039DC14: addiu       $s5, $s5, 0x2E34
    ctx->r21 = ADD32(ctx->r21, 0X2E34);
    // 0x8039DC18: addiu       $s4, $zero, 0x15E
    ctx->r20 = ADD32(0, 0X15E);
    // 0x8039DC1C: addiu       $s3, $zero, 0x150
    ctx->r19 = ADD32(0, 0X150);
    // 0x8039DC20: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
L_8039DC24:
    // 0x8039DC24: addu        $t7, $s2, $t6
    ctx->r15 = ADD32(ctx->r18, ctx->r14);
    // 0x8039DC28: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8039DC2C: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8039DC30: addu        $a0, $s1, $t9
    ctx->r4 = ADD32(ctx->r17, ctx->r25);
    // 0x8039DC34: lh          $t0, 0x0($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X0);
    // 0x8039DC38: bnel        $s3, $t0, L_8039DC68
    if (ctx->r19 != ctx->r8) {
        // 0x8039DC3C: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8039DC68;
    }
    goto skip_0;
    // 0x8039DC3C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x8039DC40: lh          $t1, 0x2($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X2);
    // 0x8039DC44: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
    // 0x8039DC48: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x8039DC4C: bne         $s4, $t1, L_8039DC64
    if (ctx->r20 != ctx->r9) {
        // 0x8039DC50: addiu       $a2, $zero, 0x54
        ctx->r6 = ADD32(0, 0X54);
            goto L_8039DC64;
    }
    // 0x8039DC50: addiu       $a2, $zero, 0x54
    ctx->r6 = ADD32(0, 0X54);
    // 0x8039DC54: jal         0x80129158
    // 0x8039DC58: addiu       $s6, $zero, 0x1
    ctx->r22 = ADD32(0, 0X1);
    memcpy_sssv(rdram, ctx);
        goto after_0;
    // 0x8039DC58: addiu       $s6, $zero, 0x1
    ctx->r22 = ADD32(0, 0X1);
    after_0:
    // 0x8039DC5C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8039DC60: lh          $v0, 0x63C0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X63C0);
L_8039DC64:
    // 0x8039DC64: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8039DC68:
    // 0x8039DC68: sll         $t2, $s0, 16
    ctx->r10 = S32(ctx->r16 << 16);
    // 0x8039DC6C: sra         $s0, $t2, 16
    ctx->r16 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8039DC70: slt         $at, $s0, $v0
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8039DC74: bnel        $at, $zero, L_8039DC24
    if (ctx->r1 != 0) {
        // 0x8039DC78: sll         $t6, $s0, 1
        ctx->r14 = S32(ctx->r16 << 1);
            goto L_8039DC24;
    }
    goto skip_1;
    // 0x8039DC78: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    skip_1:
L_8039DC7C:
    // 0x8039DC7C: bne         $s6, $zero, L_8039DC98
    if (ctx->r22 != 0) {
        // 0x8039DC80: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_8039DC98;
    }
    // 0x8039DC80: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8039DC84: addiu       $v0, $v0, 0x2D50
    ctx->r2 = ADD32(ctx->r2, 0X2D50);
    // 0x8039DC88: addiu       $t4, $zero, 0x130
    ctx->r12 = ADD32(0, 0X130);
    // 0x8039DC8C: addiu       $t5, $zero, 0x7530
    ctx->r13 = ADD32(0, 0X7530);
    // 0x8039DC90: sh          $t4, 0xE4($v0)
    MEM_H(0XE4, ctx->r2) = ctx->r12;
    // 0x8039DC94: sh          $t5, 0xE6($v0)
    MEM_H(0XE6, ctx->r2) = ctx->r13;
L_8039DC98:
    // 0x8039DC98: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8039DC9C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8039DCA0: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8039DCA4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8039DCA8: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8039DCAC: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8039DCB0: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8039DCB4: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8039DCB8: jr          $ra
    // 0x8039DCBC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x8039DCBC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
