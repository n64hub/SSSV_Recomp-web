#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void reset_cheats(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038BA30: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BA34: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
    // 0x8038BA38: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BA3C: sh          $zero, 0x62B4($at)
    MEM_H(0X62B4, ctx->r1) = 0;
    // 0x8038BA40: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BA44: sh          $zero, 0x62B8($at)
    MEM_H(0X62B8, ctx->r1) = 0;
    // 0x8038BA48: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038BA4C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BA50: addiu       $v0, $v0, 0x6428
    ctx->r2 = ADD32(ctx->r2, 0X6428);
    // 0x8038BA54: sh          $zero, 0x62BC($at)
    MEM_H(0X62BC, ctx->r1) = 0;
    // 0x8038BA58: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038BA5C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038BA60: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BA64: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BA68: lui         $a2, 0x69F
    ctx->r6 = S32(0X69F << 16);
    // 0x8038BA6C: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x8038BA70: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038BA74: sh          $zero, 0x4($v0)
    MEM_H(0X4, ctx->r2) = 0;
    // 0x8038BA78: sh          $zero, 0x6($v0)
    MEM_H(0X6, ctx->r2) = 0;
    // 0x8038BA7C: sh          $zero, 0x8($v0)
    MEM_H(0X8, ctx->r2) = 0;
    // 0x8038BA80: sh          $zero, 0xA($v0)
    MEM_H(0XA, ctx->r2) = 0;
    // 0x8038BA84: sh          $zero, 0xC($v0)
    MEM_H(0XC, ctx->r2) = 0;
    // 0x8038BA88: sh          $zero, 0xE($v0)
    MEM_H(0XE, ctx->r2) = 0;
    // 0x8038BA8C: sh          $zero, 0x10($v0)
    MEM_H(0X10, ctx->r2) = 0;
    // 0x8038BA90: sh          $zero, 0x12($v0)
    MEM_H(0X12, ctx->r2) = 0;
    // 0x8038BA94: sh          $zero, 0x14($v0)
    MEM_H(0X14, ctx->r2) = 0;
    // 0x8038BA98: sh          $zero, 0x16($v0)
    MEM_H(0X16, ctx->r2) = 0;
    // 0x8038BA9C: sh          $zero, 0x18($v0)
    MEM_H(0X18, ctx->r2) = 0;
    // 0x8038BAA0: ori         $a2, $a2, 0x6BC7
    ctx->r6 = ctx->r6 | 0X6BC7;
    // 0x8038BAA4: addiu       $a1, $a1, -0x560
    ctx->r5 = ADD32(ctx->r5, -0X560);
    // 0x8038BAA8: jal         0x801395F4
    // 0x8038BAAC: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    sprintf_recomp(rdram, ctx);
        goto after_0;
    // 0x8038BAAC: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_0:
    // 0x8038BAB0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038BAB4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038BAB8: jr          $ra
    // 0x8038BABC: nop

    return;
    // 0x8038BABC: nop

;}
RECOMP_FUNC void check_cheats(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038BAC0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038BAC4: lh          $t6, 0x642E($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X642E);
    // 0x8038BAC8: addiu       $sp, $sp, -0xA8
    ctx->r29 = ADD32(ctx->r29, -0XA8);
    // 0x8038BACC: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038BAD0: beq         $t6, $zero, L_8038BC08
    if (ctx->r14 == 0) {
        // 0x8038BAD4: sw          $a0, 0xA8($sp)
        MEM_W(0XA8, ctx->r29) = ctx->r4;
            goto L_8038BC08;
    }
    // 0x8038BAD4: sw          $a0, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->r4;
    // 0x8038BAD8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038BADC: jal         0x8012C1F0
    // 0x8038BAE0: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_0;
    // 0x8038BAE0: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_0:
    // 0x8038BAE4: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8038BAE8: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8038BAEC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038BAF0: jal         0x8012C214
    // 0x8038BAF4: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_1;
    // 0x8038BAF4: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_1:
    // 0x8038BAF8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038BAFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BB00: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038BB04: jal         0x8012C248
    // 0x8038BB08: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_2;
    // 0x8038BB08: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_2:
    // 0x8038BB0C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038BB10: lh          $t7, 0x642E($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X642E);
    // 0x8038BB14: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038BB18: beq         $t7, $zero, L_8038BC08
    if (ctx->r15 == 0) {
        // 0x8038BB1C: nop
    
            goto L_8038BC08;
    }
    // 0x8038BB1C: nop

    // 0x8038BB20: lh          $t8, 0x6680($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X6680);
    // 0x8038BB24: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038BB28: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038BB2C: bne         $t8, $zero, L_8038BC08
    if (ctx->r24 != 0) {
        // 0x8038BB30: nop
    
            goto L_8038BC08;
    }
    // 0x8038BB30: nop

    // 0x8038BB34: lh          $t9, 0x5534($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5534);
    // 0x8038BB38: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038BB3C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BB40: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x8038BB44: addu        $v0, $v0, $t0
    ctx->r2 = ADD32(ctx->r2, ctx->r8);
    // 0x8038BB48: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038BB4C: addiu       $a1, $a1, -0x55C
    ctx->r5 = ADD32(ctx->r5, -0X55C);
    // 0x8038BB50: addiu       $a0, $a0, 0x42B0
    ctx->r4 = ADD32(ctx->r4, 0X42B0);
    // 0x8038BB54: lh          $a2, 0x4($v0)
    ctx->r6 = MEM_H(ctx->r2, 0X4);
    // 0x8038BB58: lh          $a3, 0x8($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X8);
    // 0x8038BB5C: lh          $t3, 0xC($v0)
    ctx->r11 = MEM_H(ctx->r2, 0XC);
    // 0x8038BB60: sra         $t1, $a2, 6
    ctx->r9 = S32(SIGNED(ctx->r6) >> 6);
    // 0x8038BB64: sra         $t2, $a3, 6
    ctx->r10 = S32(SIGNED(ctx->r7) >> 6);
    // 0x8038BB68: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x8038BB6C: or          $a2, $t1, $zero
    ctx->r6 = ctx->r9 | 0;
    // 0x8038BB70: jal         0x801395F4
    // 0x8038BB74: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    sprintf_recomp(rdram, ctx);
        goto after_3;
    // 0x8038BB74: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    after_3:
    // 0x8038BB78: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038BB7C: addiu       $a0, $a0, 0x42B0
    ctx->r4 = ADD32(ctx->r4, 0X42B0);
    // 0x8038BB80: jal         0x801308B4
    // 0x8038BB84: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    prepare_text(rdram, ctx);
        goto after_4;
    // 0x8038BB84: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    after_4:
    // 0x8038BB88: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8038BB8C: lh          $a2, 0x3FD0($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X3FD0);
    // 0x8038BB90: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038BB94: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8038BB98: addiu       $a2, $a2, -0x14
    ctx->r6 = ADD32(ctx->r6, -0X14);
    // 0x8038BB9C: andi        $t4, $a2, 0xFFFF
    ctx->r12 = ctx->r6 & 0XFFFF;
    // 0x8038BBA0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038BBA4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8038BBA8: or          $a2, $t4, $zero
    ctx->r6 = ctx->r12 | 0;
    // 0x8038BBAC: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    // 0x8038BBB0: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x8038BBB4: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x8038BBB8: jal         0x8012DEF8
    // 0x8038BBBC: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text(rdram, ctx);
        goto after_5;
    // 0x8038BBBC: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_5:
    // 0x8038BBC0: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x8038BBC4: addiu       $a0, $a0, -0x54C
    ctx->r4 = ADD32(ctx->r4, -0X54C);
    // 0x8038BBC8: jal         0x801308B4
    // 0x8038BBCC: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    prepare_text(rdram, ctx);
        goto after_6;
    // 0x8038BBCC: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    after_6:
    // 0x8038BBD0: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8038BBD4: lh          $a2, 0x3FD0($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X3FD0);
    // 0x8038BBD8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038BBDC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8038BBE0: addiu       $a2, $a2, -0x14
    ctx->r6 = ADD32(ctx->r6, -0X14);
    // 0x8038BBE4: andi        $t5, $a2, 0xFFFF
    ctx->r13 = ctx->r6 & 0XFFFF;
    // 0x8038BBE8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038BBEC: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8038BBF0: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    // 0x8038BBF4: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    // 0x8038BBF8: addiu       $a3, $zero, 0x24
    ctx->r7 = ADD32(0, 0X24);
    // 0x8038BBFC: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x8038BC00: jal         0x8012DEF8
    // 0x8038BC04: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text(rdram, ctx);
        goto after_7;
    // 0x8038BC04: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_7:
L_8038BC08:
    // 0x8038BC08: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x8038BC0C: addiu       $a2, $a2, 0x62BC
    ctx->r6 = ADD32(ctx->r6, 0X62BC);
    // 0x8038BC10: lh          $v0, 0x0($a2)
    ctx->r2 = MEM_H(ctx->r6, 0X0);
    // 0x8038BC14: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8038BC18: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038BC1C: beq         $v0, $zero, L_8038BC2C
    if (ctx->r2 == 0) {
        // 0x8038BC20: addiu       $a1, $a1, 0x62B4
        ctx->r5 = ADD32(ctx->r5, 0X62B4);
            goto L_8038BC2C;
    }
    // 0x8038BC20: addiu       $a1, $a1, 0x62B4
    ctx->r5 = ADD32(ctx->r5, 0X62B4);
    // 0x8038BC24: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x8038BC28: sh          $t6, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r14;
L_8038BC2C:
    // 0x8038BC2C: lh          $t8, 0x0($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X0);
    // 0x8038BC30: lw          $t7, 0xA8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XA8);
    // 0x8038BC34: bne         $t8, $zero, L_8038BC4C
    if (ctx->r24 != 0) {
        // 0x8038BC38: lhu         $v1, 0x0($t7)
        ctx->r3 = MEM_HU(ctx->r15, 0X0);
            goto L_8038BC4C;
    }
    // 0x8038BC38: lhu         $v1, 0x0($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X0);
    // 0x8038BC3C: bne         $v1, $zero, L_8038BC4C
    if (ctx->r3 != 0) {
        // 0x8038BC40: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_8038BC4C;
    }
    // 0x8038BC40: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038BC44: b           L_8038C12C
    // 0x8038BC48: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
        goto L_8038C12C;
    // 0x8038BC48: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
L_8038BC4C:
    // 0x8038BC4C: beq         $v1, $zero, L_8038BC58
    if (ctx->r3 == 0) {
        // 0x8038BC50: lh          $v0, 0x0($a2)
        ctx->r2 = MEM_H(ctx->r6, 0X0);
            goto L_8038BC58;
    }
    // 0x8038BC50: lh          $v0, 0x0($a2)
    ctx->r2 = MEM_H(ctx->r6, 0X0);
    // 0x8038BC54: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
L_8038BC58:
    // 0x8038BC58: bne         $v0, $zero, L_8038BD48
    if (ctx->r2 != 0) {
        // 0x8038BC5C: nop
    
            goto L_8038BD48;
    }
    // 0x8038BC5C: nop

    // 0x8038BC60: beq         $v1, $zero, L_8038BD48
    if (ctx->r3 == 0) {
        // 0x8038BC64: lui         $a1, 0x803B
        ctx->r5 = S32(0X803B << 16);
            goto L_8038BD48;
    }
    // 0x8038BC64: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8038BC68: addiu       $a1, $a1, 0x62C0
    ctx->r5 = ADD32(ctx->r5, 0X62C0);
    // 0x8038BC6C: lbu         $t0, 0x0($a1)
    ctx->r8 = MEM_BU(ctx->r5, 0X0);
    // 0x8038BC70: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8038BC74: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x8038BC78: beq         $v1, $t0, L_8038BD48
    if (ctx->r3 == ctx->r8) {
        // 0x8038BC7C: andi        $t4, $v0, 0x8000
        ctx->r12 = ctx->r2 & 0X8000;
            goto L_8038BD48;
    }
    // 0x8038BC7C: andi        $t4, $v0, 0x8000
    ctx->r12 = ctx->r2 & 0X8000;
    // 0x8038BC80: lh          $t1, 0x4290($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X4290);
    // 0x8038BC84: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038BC88: andi        $t5, $v0, 0x4000
    ctx->r13 = ctx->r2 & 0X4000;
    // 0x8038BC8C: bne         $t1, $at, L_8038BCA0
    if (ctx->r9 != ctx->r1) {
        // 0x8038BC90: andi        $t6, $v0, 0x800
        ctx->r14 = ctx->r2 & 0X800;
            goto L_8038BCA0;
    }
    // 0x8038BC90: andi        $t6, $v0, 0x800
    ctx->r14 = ctx->r2 & 0X800;
    // 0x8038BC94: addiu       $t2, $zero, 0xC
    ctx->r10 = ADD32(0, 0XC);
    // 0x8038BC98: b           L_8038BCA8
    // 0x8038BC9C: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
        goto L_8038BCA8;
    // 0x8038BC9C: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
L_8038BCA0:
    // 0x8038BCA0: addiu       $t3, $zero, 0x6
    ctx->r11 = ADD32(0, 0X6);
    // 0x8038BCA4: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
L_8038BCA8:
    // 0x8038BCA8: beq         $t4, $zero, L_8038BCB4
    if (ctx->r12 == 0) {
        // 0x8038BCAC: andi        $t7, $v0, 0x400
        ctx->r15 = ctx->r2 & 0X400;
            goto L_8038BCB4;
    }
    // 0x8038BCAC: andi        $t7, $v0, 0x400
    ctx->r15 = ctx->r2 & 0X400;
    // 0x8038BCB0: addiu       $a0, $zero, 0x41
    ctx->r4 = ADD32(0, 0X41);
L_8038BCB4:
    // 0x8038BCB4: beq         $t5, $zero, L_8038BCC0
    if (ctx->r13 == 0) {
        // 0x8038BCB8: andi        $t8, $v0, 0x200
        ctx->r24 = ctx->r2 & 0X200;
            goto L_8038BCC0;
    }
    // 0x8038BCB8: andi        $t8, $v0, 0x200
    ctx->r24 = ctx->r2 & 0X200;
    // 0x8038BCBC: addiu       $a0, $zero, 0x42
    ctx->r4 = ADD32(0, 0X42);
L_8038BCC0:
    // 0x8038BCC0: beq         $t6, $zero, L_8038BCCC
    if (ctx->r14 == 0) {
        // 0x8038BCC4: andi        $t9, $v0, 0x100
        ctx->r25 = ctx->r2 & 0X100;
            goto L_8038BCCC;
    }
    // 0x8038BCC4: andi        $t9, $v0, 0x100
    ctx->r25 = ctx->r2 & 0X100;
    // 0x8038BCC8: addiu       $a0, $zero, 0x55
    ctx->r4 = ADD32(0, 0X55);
L_8038BCCC:
    // 0x8038BCCC: beq         $t7, $zero, L_8038BCD8
    if (ctx->r15 == 0) {
        // 0x8038BCD0: andi        $t0, $v0, 0x8
        ctx->r8 = ctx->r2 & 0X8;
            goto L_8038BCD8;
    }
    // 0x8038BCD0: andi        $t0, $v0, 0x8
    ctx->r8 = ctx->r2 & 0X8;
    // 0x8038BCD4: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
L_8038BCD8:
    // 0x8038BCD8: beq         $t8, $zero, L_8038BCE4
    if (ctx->r24 == 0) {
        // 0x8038BCDC: andi        $t1, $v0, 0x4
        ctx->r9 = ctx->r2 & 0X4;
            goto L_8038BCE4;
    }
    // 0x8038BCDC: andi        $t1, $v0, 0x4
    ctx->r9 = ctx->r2 & 0X4;
    // 0x8038BCE0: addiu       $a0, $zero, 0x4C
    ctx->r4 = ADD32(0, 0X4C);
L_8038BCE4:
    // 0x8038BCE4: beq         $t9, $zero, L_8038BCF0
    if (ctx->r25 == 0) {
        // 0x8038BCE8: andi        $t2, $v0, 0x2
        ctx->r10 = ctx->r2 & 0X2;
            goto L_8038BCF0;
    }
    // 0x8038BCE8: andi        $t2, $v0, 0x2
    ctx->r10 = ctx->r2 & 0X2;
    // 0x8038BCEC: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
L_8038BCF0:
    // 0x8038BCF0: beq         $t0, $zero, L_8038BCFC
    if (ctx->r8 == 0) {
        // 0x8038BCF4: andi        $t3, $v0, 0x1
        ctx->r11 = ctx->r2 & 0X1;
            goto L_8038BCFC;
    }
    // 0x8038BCF4: andi        $t3, $v0, 0x1
    ctx->r11 = ctx->r2 & 0X1;
    // 0x8038BCF8: addiu       $a0, $zero, 0x4E
    ctx->r4 = ADD32(0, 0X4E);
L_8038BCFC:
    // 0x8038BCFC: beq         $t1, $zero, L_8038BD08
    if (ctx->r9 == 0) {
        // 0x8038BD00: andi        $t4, $v0, 0x2000
        ctx->r12 = ctx->r2 & 0X2000;
            goto L_8038BD08;
    }
    // 0x8038BD00: andi        $t4, $v0, 0x2000
    ctx->r12 = ctx->r2 & 0X2000;
    // 0x8038BD04: addiu       $a0, $zero, 0x53
    ctx->r4 = ADD32(0, 0X53);
L_8038BD08:
    // 0x8038BD08: beq         $t2, $zero, L_8038BD14
    if (ctx->r10 == 0) {
        // 0x8038BD0C: andi        $t5, $v0, 0x20
        ctx->r13 = ctx->r2 & 0X20;
            goto L_8038BD14;
    }
    // 0x8038BD0C: andi        $t5, $v0, 0x20
    ctx->r13 = ctx->r2 & 0X20;
    // 0x8038BD10: addiu       $a0, $zero, 0x57
    ctx->r4 = ADD32(0, 0X57);
L_8038BD14:
    // 0x8038BD14: beq         $t3, $zero, L_8038BD20
    if (ctx->r11 == 0) {
        // 0x8038BD18: andi        $t6, $v0, 0x10
        ctx->r14 = ctx->r2 & 0X10;
            goto L_8038BD20;
    }
    // 0x8038BD18: andi        $t6, $v0, 0x10
    ctx->r14 = ctx->r2 & 0X10;
    // 0x8038BD1C: addiu       $a0, $zero, 0x45
    ctx->r4 = ADD32(0, 0X45);
L_8038BD20:
    // 0x8038BD20: beq         $t4, $zero, L_8038BD2C
    if (ctx->r12 == 0) {
        // 0x8038BD24: nop
    
            goto L_8038BD2C;
    }
    // 0x8038BD24: nop

    // 0x8038BD28: addiu       $a0, $zero, 0x5A
    ctx->r4 = ADD32(0, 0X5A);
L_8038BD2C:
    // 0x8038BD2C: beq         $t5, $zero, L_8038BD38
    if (ctx->r13 == 0) {
        // 0x8038BD30: nop
    
            goto L_8038BD38;
    }
    // 0x8038BD30: nop

    // 0x8038BD34: addiu       $a0, $zero, 0x49
    ctx->r4 = ADD32(0, 0X49);
L_8038BD38:
    // 0x8038BD38: beql        $t6, $zero, L_8038BD48
    if (ctx->r14 == 0) {
        // 0x8038BD3C: sb          $a0, 0x0($a1)
        MEM_B(0X0, ctx->r5) = ctx->r4;
            goto L_8038BD48;
    }
    goto skip_0;
    // 0x8038BD3C: sb          $a0, 0x0($a1)
    MEM_B(0X0, ctx->r5) = ctx->r4;
    skip_0:
    // 0x8038BD40: addiu       $a0, $zero, 0x54
    ctx->r4 = ADD32(0, 0X54);
    // 0x8038BD44: sb          $a0, 0x0($a1)
    MEM_B(0X0, ctx->r5) = ctx->r4;
L_8038BD48:
    // 0x8038BD48: beq         $a0, $zero, L_8038BD88
    if (ctx->r4 == 0) {
        // 0x8038BD4C: lui         $a1, 0x803C
        ctx->r5 = S32(0X803C << 16);
            goto L_8038BD88;
    }
    // 0x8038BD4C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BD50: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x8038BD54: addiu       $v1, $v1, 0x62B0
    ctx->r3 = ADD32(ctx->r3, 0X62B0);
    // 0x8038BD58: lh          $t7, 0x0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X0);
    // 0x8038BD5C: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8038BD60: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
    // 0x8038BD64: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x8038BD68: slti        $at, $v0, 0x14
    ctx->r1 = SIGNED(ctx->r2) < 0X14 ? 1 : 0;
    // 0x8038BD6C: bne         $at, $zero, L_8038BD7C
    if (ctx->r1 != 0) {
        // 0x8038BD70: nop
    
            goto L_8038BD7C;
    }
    // 0x8038BD70: nop

    // 0x8038BD74: sh          $zero, 0x0($v1)
    MEM_H(0X0, ctx->r3) = 0;
    // 0x8038BD78: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
L_8038BD7C:
    // 0x8038BD7C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BD80: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x8038BD84: sb          $a0, 0x6410($at)
    MEM_B(0X6410, ctx->r1) = ctx->r4;
L_8038BD88:
    // 0x8038BD88: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BD8C: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    // 0x8038BD90: jal         0x8038C13C
    // 0x8038BD94: addiu       $a1, $a1, -0x540
    ctx->r5 = ADD32(ctx->r5, -0X540);
    check_cheat_code(rdram, ctx);
        goto after_8;
    // 0x8038BD94: addiu       $a1, $a1, -0x540
    ctx->r5 = ADD32(ctx->r5, -0X540);
    after_8:
    // 0x8038BD98: beq         $v0, $zero, L_8038BDE0
    if (ctx->r2 == 0) {
        // 0x8038BD9C: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_8038BDE0;
    }
    // 0x8038BD9C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038BDA0: lh          $t0, 0x5534($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X5534);
    // 0x8038BDA4: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x8038BDA8: addiu       $t9, $zero, 0x7F
    ctx->r25 = ADD32(0, 0X7F);
    // 0x8038BDAC: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x8038BDB0: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x8038BDB4: lw          $t2, -0x2274($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X2274);
    // 0x8038BDB8: addiu       $t3, $zero, 0x40
    ctx->r11 = ADD32(0, 0X40);
    // 0x8038BDBC: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BDC0: sh          $t9, 0x14C($t2)
    MEM_H(0X14C, ctx->r10) = ctx->r25;
    // 0x8038BDC4: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x8038BDC8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BDCC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BDD0: jal         0x8013307C
    // 0x8038BDD4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_9;
    // 0x8038BDD4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_9:
    // 0x8038BDD8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BDDC: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BDE0:
    // 0x8038BDE0: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BDE4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BDE8: addiu       $a1, $a1, -0x534
    ctx->r5 = ADD32(ctx->r5, -0X534);
    // 0x8038BDEC: jal         0x8038C13C
    // 0x8038BDF0: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_10;
    // 0x8038BDF0: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_10:
    // 0x8038BDF4: beq         $v0, $zero, L_8038BE34
    if (ctx->r2 == 0) {
        // 0x8038BDF8: addiu       $t4, $zero, 0x40
        ctx->r12 = ADD32(0, 0X40);
            goto L_8038BE34;
    }
    // 0x8038BDF8: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8038BDFC: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8038BE00: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BE04: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BE08: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BE0C: jal         0x8013307C
    // 0x8038BE10: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_11;
    // 0x8038BE10: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_11:
    // 0x8038BE14: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x8038BE18: lh          $t5, 0x6432($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X6432);
    // 0x8038BE1C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8038BE20: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BE24: subu        $t7, $t6, $t5
    ctx->r15 = SUB32(ctx->r14, ctx->r13);
    // 0x8038BE28: sh          $t7, 0x6432($at)
    MEM_H(0X6432, ctx->r1) = ctx->r15;
    // 0x8038BE2C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BE30: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BE34:
    // 0x8038BE34: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BE38: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BE3C: addiu       $a1, $a1, -0x528
    ctx->r5 = ADD32(ctx->r5, -0X528);
    // 0x8038BE40: jal         0x8038C13C
    // 0x8038BE44: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_12;
    // 0x8038BE44: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_12:
    // 0x8038BE48: beq         $v0, $zero, L_8038BE88
    if (ctx->r2 == 0) {
        // 0x8038BE4C: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_8038BE88;
    }
    // 0x8038BE4C: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x8038BE50: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8038BE54: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BE58: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BE5C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BE60: jal         0x8013307C
    // 0x8038BE64: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_13;
    // 0x8038BE64: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_13:
    // 0x8038BE68: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038BE6C: lh          $t0, 0x6434($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X6434);
    // 0x8038BE70: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8038BE74: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BE78: subu        $t9, $t1, $t0
    ctx->r25 = SUB32(ctx->r9, ctx->r8);
    // 0x8038BE7C: sh          $t9, 0x6434($at)
    MEM_H(0X6434, ctx->r1) = ctx->r25;
    // 0x8038BE80: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BE84: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BE88:
    // 0x8038BE88: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BE8C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BE90: addiu       $a1, $a1, -0x51C
    ctx->r5 = ADD32(ctx->r5, -0X51C);
    // 0x8038BE94: jal         0x8038C13C
    // 0x8038BE98: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_14;
    // 0x8038BE98: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_14:
    // 0x8038BE9C: beq         $v0, $zero, L_8038BEDC
    if (ctx->r2 == 0) {
        // 0x8038BEA0: addiu       $t2, $zero, 0x40
        ctx->r10 = ADD32(0, 0X40);
            goto L_8038BEDC;
    }
    // 0x8038BEA0: addiu       $t2, $zero, 0x40
    ctx->r10 = ADD32(0, 0X40);
    // 0x8038BEA4: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x8038BEA8: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BEAC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BEB0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BEB4: jal         0x8013307C
    // 0x8038BEB8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_15;
    // 0x8038BEB8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_15:
    // 0x8038BEBC: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8038BEC0: lh          $t3, 0x6436($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X6436);
    // 0x8038BEC4: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8038BEC8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BECC: subu        $t6, $t4, $t3
    ctx->r14 = SUB32(ctx->r12, ctx->r11);
    // 0x8038BED0: sh          $t6, 0x6436($at)
    MEM_H(0X6436, ctx->r1) = ctx->r14;
    // 0x8038BED4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BED8: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BEDC:
    // 0x8038BEDC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BEE0: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BEE4: addiu       $a1, $a1, -0x510
    ctx->r5 = ADD32(ctx->r5, -0X510);
    // 0x8038BEE8: jal         0x8038C13C
    // 0x8038BEEC: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_16;
    // 0x8038BEEC: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_16:
    // 0x8038BEF0: beq         $v0, $zero, L_8038BF30
    if (ctx->r2 == 0) {
        // 0x8038BEF4: addiu       $t5, $zero, 0x40
        ctx->r13 = ADD32(0, 0X40);
            goto L_8038BF30;
    }
    // 0x8038BEF4: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x8038BEF8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x8038BEFC: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BF00: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BF04: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BF08: jal         0x8013307C
    // 0x8038BF0C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_17;
    // 0x8038BF0C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_17:
    // 0x8038BF10: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038BF14: lh          $t7, 0x6438($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6438);
    // 0x8038BF18: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8038BF1C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BF20: subu        $t1, $t8, $t7
    ctx->r9 = SUB32(ctx->r24, ctx->r15);
    // 0x8038BF24: sh          $t1, 0x6438($at)
    MEM_H(0X6438, ctx->r1) = ctx->r9;
    // 0x8038BF28: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BF2C: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BF30:
    // 0x8038BF30: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BF34: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BF38: addiu       $a1, $a1, -0x504
    ctx->r5 = ADD32(ctx->r5, -0X504);
    // 0x8038BF3C: jal         0x8038C13C
    // 0x8038BF40: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_18;
    // 0x8038BF40: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_18:
    // 0x8038BF44: beq         $v0, $zero, L_8038BF84
    if (ctx->r2 == 0) {
        // 0x8038BF48: addiu       $t0, $zero, 0x40
        ctx->r8 = ADD32(0, 0X40);
            goto L_8038BF84;
    }
    // 0x8038BF48: addiu       $t0, $zero, 0x40
    ctx->r8 = ADD32(0, 0X40);
    // 0x8038BF4C: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8038BF50: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BF54: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BF58: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BF5C: jal         0x8013307C
    // 0x8038BF60: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_19;
    // 0x8038BF60: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_19:
    // 0x8038BF64: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038BF68: lh          $t9, 0x643A($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X643A);
    // 0x8038BF6C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8038BF70: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BF74: subu        $t4, $t2, $t9
    ctx->r12 = SUB32(ctx->r10, ctx->r25);
    // 0x8038BF78: sh          $t4, 0x643A($at)
    MEM_H(0X643A, ctx->r1) = ctx->r12;
    // 0x8038BF7C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BF80: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BF84:
    // 0x8038BF84: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BF88: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BF8C: addiu       $a1, $a1, -0x4F8
    ctx->r5 = ADD32(ctx->r5, -0X4F8);
    // 0x8038BF90: jal         0x8038C13C
    // 0x8038BF94: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_20;
    // 0x8038BF94: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_20:
    // 0x8038BF98: beq         $v0, $zero, L_8038BFD8
    if (ctx->r2 == 0) {
        // 0x8038BF9C: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038BFD8;
    }
    // 0x8038BF9C: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BFA0: addiu       $t3, $zero, 0x40
    ctx->r11 = ADD32(0, 0X40);
    // 0x8038BFA4: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x8038BFA8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038BFAC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038BFB0: jal         0x8013307C
    // 0x8038BFB4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_21;
    // 0x8038BFB4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_21:
    // 0x8038BFB8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038BFBC: lh          $t6, 0x643C($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X643C);
    // 0x8038BFC0: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8038BFC4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038BFC8: subu        $t8, $t5, $t6
    ctx->r24 = SUB32(ctx->r13, ctx->r14);
    // 0x8038BFCC: sh          $t8, 0x643C($at)
    MEM_H(0X643C, ctx->r1) = ctx->r24;
    // 0x8038BFD0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038BFD4: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038BFD8:
    // 0x8038BFD8: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038BFDC: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038BFE0: addiu       $a1, $a1, -0x4EC
    ctx->r5 = ADD32(ctx->r5, -0X4EC);
    // 0x8038BFE4: jal         0x8038C13C
    // 0x8038BFE8: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_22;
    // 0x8038BFE8: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_22:
    // 0x8038BFEC: beq         $v0, $zero, L_8038C01C
    if (ctx->r2 == 0) {
        // 0x8038BFF0: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038C01C;
    }
    // 0x8038BFF0: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038BFF4: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x8038BFF8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8038BFFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C000: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038C004: jal         0x8013307C
    // 0x8038C008: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_23;
    // 0x8038C008: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_23:
    // 0x8038C00C: jal         0x8032AC98
    // 0x8038C010: nop

    cheat_activate_scale_pulse_effect(rdram, ctx);
        goto after_24;
    // 0x8038C010: nop

    after_24:
    // 0x8038C014: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038C018: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038C01C:
    // 0x8038C01C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038C020: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038C024: addiu       $a1, $a1, -0x4E0
    ctx->r5 = ADD32(ctx->r5, -0X4E0);
    // 0x8038C028: jal         0x8038C13C
    // 0x8038C02C: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_25;
    // 0x8038C02C: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_25:
    // 0x8038C030: beq         $v0, $zero, L_8038C060
    if (ctx->r2 == 0) {
        // 0x8038C034: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038C060;
    }
    // 0x8038C034: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038C038: addiu       $t1, $zero, 0x40
    ctx->r9 = ADD32(0, 0X40);
    // 0x8038C03C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x8038C040: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C044: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038C048: jal         0x8013307C
    // 0x8038C04C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_26;
    // 0x8038C04C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_26:
    // 0x8038C050: jal         0x8032AE34
    // 0x8038C054: nop

    cheat_activate_energy_camera_effect(rdram, ctx);
        goto after_27;
    // 0x8038C054: nop

    after_27:
    // 0x8038C058: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038C05C: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038C060:
    // 0x8038C060: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038C064: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038C068: addiu       $a1, $a1, -0x4D4
    ctx->r5 = ADD32(ctx->r5, -0X4D4);
    // 0x8038C06C: jal         0x8038C13C
    // 0x8038C070: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_28;
    // 0x8038C070: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_28:
    // 0x8038C074: beq         $v0, $zero, L_8038C0A4
    if (ctx->r2 == 0) {
        // 0x8038C078: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038C0A4;
    }
    // 0x8038C078: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038C07C: addiu       $t0, $zero, 0x40
    ctx->r8 = ADD32(0, 0X40);
    // 0x8038C080: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8038C084: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C088: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038C08C: jal         0x8013307C
    // 0x8038C090: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_29;
    // 0x8038C090: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_29:
    // 0x8038C094: jal         0x8032AEA0
    // 0x8038C098: nop

    cheat_activate_big_head_effect(rdram, ctx);
        goto after_30;
    // 0x8038C098: nop

    after_30:
    // 0x8038C09C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038C0A0: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038C0A4:
    // 0x8038C0A4: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038C0A8: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038C0AC: addiu       $a1, $a1, -0x4C8
    ctx->r5 = ADD32(ctx->r5, -0X4C8);
    // 0x8038C0B0: jal         0x8038C13C
    // 0x8038C0B4: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_31;
    // 0x8038C0B4: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_31:
    // 0x8038C0B8: beq         $v0, $zero, L_8038C0E8
    if (ctx->r2 == 0) {
        // 0x8038C0BC: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038C0E8;
    }
    // 0x8038C0BC: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038C0C0: addiu       $t2, $zero, 0x40
    ctx->r10 = ADD32(0, 0X40);
    // 0x8038C0C4: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x8038C0C8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C0CC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038C0D0: jal         0x8013307C
    // 0x8038C0D4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_32;
    // 0x8038C0D4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_32:
    // 0x8038C0D8: jal         0x8032B084
    // 0x8038C0DC: nop

    cheat_toggle_mystery_bear(rdram, ctx);
        goto after_33;
    // 0x8038C0DC: nop

    after_33:
    // 0x8038C0E0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038C0E4: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038C0E8:
    // 0x8038C0E8: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038C0EC: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038C0F0: addiu       $a1, $a1, -0x4BC
    ctx->r5 = ADD32(ctx->r5, -0X4BC);
    // 0x8038C0F4: jal         0x8038C13C
    // 0x8038C0F8: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    check_cheat_code(rdram, ctx);
        goto after_34;
    // 0x8038C0F8: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    after_34:
    // 0x8038C0FC: beq         $v0, $zero, L_8038C12C
    if (ctx->r2 == 0) {
        // 0x8038C100: addiu       $a0, $zero, 0x56
        ctx->r4 = ADD32(0, 0X56);
            goto L_8038C12C;
    }
    // 0x8038C100: addiu       $a0, $zero, 0x56
    ctx->r4 = ADD32(0, 0X56);
    // 0x8038C104: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8038C108: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038C10C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C110: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038C114: jal         0x8013307C
    // 0x8038C118: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_35;
    // 0x8038C118: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_35:
    // 0x8038C11C: jal         0x8032B1C8
    // 0x8038C120: nop

    cheat_clear_camera_effects(rdram, ctx);
        goto after_36;
    // 0x8038C120: nop

    after_36:
    // 0x8038C124: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038C128: sh          $zero, 0x62B0($at)
    MEM_H(0X62B0, ctx->r1) = 0;
L_8038C12C:
    // 0x8038C12C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8038C130: addiu       $sp, $sp, 0xA8
    ctx->r29 = ADD32(ctx->r29, 0XA8);
    // 0x8038C134: jr          $ra
    // 0x8038C138: nop

    return;
    // 0x8038C138: nop

;}
RECOMP_FUNC void check_cheat_code(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C13C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8038C140: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038C144: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8038C148: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038C14C: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    // 0x8038C150: jal         0x80128DD0
    // 0x8038C154: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    strlen_sssv(rdram, ctx);
        goto after_0;
    // 0x8038C154: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    after_0:
    // 0x8038C158: sll         $a3, $v0, 16
    ctx->r7 = S32(ctx->r2 << 16);
    // 0x8038C15C: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x8038C160: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8038C164: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8038C168: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8038C16C: lw          $a2, 0x24($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X24);
    // 0x8038C170: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8038C174: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x8038C178: blez        $t7, L_8038C1E4
    if (SIGNED(ctx->r15) <= 0) {
        // 0x8038C17C: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_8038C1E4;
    }
    // 0x8038C17C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8038C180: lui         $t0, 0x803B
    ctx->r8 = S32(0X803B << 16);
    // 0x8038C184: lh          $t0, 0x62B0($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X62B0);
    // 0x8038C188: subu        $v0, $t0, $v1
    ctx->r2 = SUB32(ctx->r8, ctx->r3);
L_8038C18C:
    // 0x8038C18C: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8038C190: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038C194: bgez        $t9, L_8038C1A8
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8038C198: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_8038C1A8;
    }
    // 0x8038C198: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x8038C19C: addiu       $v0, $t9, 0xA
    ctx->r2 = ADD32(ctx->r25, 0XA);
    // 0x8038C1A0: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x8038C1A4: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
L_8038C1A8:
    // 0x8038C1A8: subu        $t5, $a1, $v1
    ctx->r13 = SUB32(ctx->r5, ctx->r3);
    // 0x8038C1AC: addu        $t6, $t5, $a2
    ctx->r14 = ADD32(ctx->r13, ctx->r6);
    // 0x8038C1B0: addu        $t3, $s0, $v0
    ctx->r11 = ADD32(ctx->r16, ctx->r2);
    // 0x8038C1B4: lbu         $t4, 0x0($t3)
    ctx->r12 = MEM_BU(ctx->r11, 0X0);
    // 0x8038C1B8: lbu         $t7, -0x1($t6)
    ctx->r15 = MEM_BU(ctx->r14, -0X1);
    // 0x8038C1BC: beql        $t4, $t7, L_8038C1D0
    if (ctx->r12 == ctx->r15) {
        // 0x8038C1C0: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_8038C1D0;
    }
    goto skip_0;
    // 0x8038C1C0: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    skip_0:
    // 0x8038C1C4: addiu       $v1, $zero, 0x64
    ctx->r3 = ADD32(0, 0X64);
    // 0x8038C1C8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038C1CC: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_8038C1D0:
    // 0x8038C1D0: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8038C1D4: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038C1D8: slt         $at, $v1, $a3
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x8038C1DC: bnel        $at, $zero, L_8038C18C
    if (ctx->r1 != 0) {
        // 0x8038C1E0: subu        $v0, $t0, $v1
        ctx->r2 = SUB32(ctx->r8, ctx->r3);
            goto L_8038C18C;
    }
    goto skip_1;
    // 0x8038C1E0: subu        $v0, $t0, $v1
    ctx->r2 = SUB32(ctx->r8, ctx->r3);
    skip_1:
L_8038C1E4:
    // 0x8038C1E4: bne         $a0, $zero, L_8038C1F4
    if (ctx->r4 != 0) {
        // 0x8038C1E8: lui         $a1, 0x803C
        ctx->r5 = S32(0X803C << 16);
            goto L_8038C1F4;
    }
    // 0x8038C1E8: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038C1EC: b           L_8038C210
    // 0x8038C1F0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8038C210;
    // 0x8038C1F0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8038C1F4:
    // 0x8038C1F4: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038C1F8: lui         $a2, 0x69F
    ctx->r6 = S32(0X69F << 16);
    // 0x8038C1FC: ori         $a2, $a2, 0x6BC7
    ctx->r6 = ctx->r6 | 0X6BC7;
    // 0x8038C200: addiu       $a0, $a0, 0x6410
    ctx->r4 = ADD32(ctx->r4, 0X6410);
    // 0x8038C204: jal         0x801395F4
    // 0x8038C208: addiu       $a1, $a1, -0x4B0
    ctx->r5 = ADD32(ctx->r5, -0X4B0);
    sprintf_recomp(rdram, ctx);
        goto after_1;
    // 0x8038C208: addiu       $a1, $a1, -0x4B0
    ctx->r5 = ADD32(ctx->r5, -0X4B0);
    after_1:
    // 0x8038C20C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8038C210:
    // 0x8038C210: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8038C214: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8038C218: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8038C21C: jr          $ra
    // 0x8038C220: nop

    return;
    // 0x8038C220: nop

;}
RECOMP_FUNC void func_8038C230_79D8E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C230: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038C234: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038C238: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8038C23C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038C240: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8038C244: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8038C248: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x8038C24C: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x8038C250: lbu         $t1, 0x162($t0)
    ctx->r9 = MEM_BU(ctx->r8, 0X162);
    // 0x8038C254: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8038C258: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038C25C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8038C260: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038C264: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038C268: bne         $t1, $at, L_8038C474
    if (ctx->r9 != ctx->r1) {
        // 0x8038C26C: or          $a2, $t9, $zero
        ctx->r6 = ctx->r25 | 0;
            goto L_8038C474;
    }
    // 0x8038C26C: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x8038C270: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8038C274: lb          $t2, 0x2D10($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X2D10);
    // 0x8038C278: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x8038C27C: bne         $t2, $zero, L_8038C38C
    if (ctx->r10 != 0) {
        // 0x8038C280: nop
    
            goto L_8038C38C;
    }
    // 0x8038C280: nop

    // 0x8038C284: lbu         $t3, 0x5538($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X5538);
    // 0x8038C288: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8038C28C: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x8038C290: beq         $t3, $zero, L_8038C2D0
    if (ctx->r11 == 0) {
        // 0x8038C294: lui         $a0, 0x801F
        ctx->r4 = S32(0X801F << 16);
            goto L_8038C2D0;
    }
    // 0x8038C294: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x8038C298: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x8038C29C: lb          $t4, 0x554B($t4)
    ctx->r12 = MEM_B(ctx->r12, 0X554B);
    // 0x8038C2A0: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x8038C2A4: addiu       $t7, $t9, 0x2
    ctx->r15 = ADD32(ctx->r25, 0X2);
    // 0x8038C2A8: sra         $t5, $t4, 2
    ctx->r13 = S32(SIGNED(ctx->r12) >> 2);
    // 0x8038C2AC: addu        $t6, $a0, $t5
    ctx->r14 = ADD32(ctx->r4, ctx->r13);
    // 0x8038C2B0: sllv        $v1, $t6, $t7
    ctx->r3 = S32(ctx->r14 << (ctx->r15 & 31));
    // 0x8038C2B4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8038C2B8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038C2BC: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8038C2C0: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x8038C2C4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8038C2C8: b           L_8038C2F4
    // 0x8038C2CC: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
        goto L_8038C2F4;
    // 0x8038C2CC: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_8038C2D0:
    // 0x8038C2D0: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x8038C2D4: addiu       $t2, $a2, 0x2
    ctx->r10 = ADD32(ctx->r6, 0X2);
    // 0x8038C2D8: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x8038C2DC: lb          $t0, 0x368($v0)
    ctx->r8 = MEM_B(ctx->r2, 0X368);
    // 0x8038C2E0: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x8038C2E4: sra         $t1, $t0, 2
    ctx->r9 = S32(SIGNED(ctx->r8) >> 2);
    // 0x8038C2E8: sllv        $v1, $t1, $t2
    ctx->r3 = S32(ctx->r9 << (ctx->r10 & 31));
    // 0x8038C2EC: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x8038C2F0: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
L_8038C2F4:
    // 0x8038C2F4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8038C2F8: lh          $t5, 0x5540($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5540);
    // 0x8038C2FC: lh          $t6, 0x26($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X26);
    // 0x8038C300: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8038C304: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x8038C308: sllv        $t9, $t5, $t6
    ctx->r25 = S32(ctx->r13 << (ctx->r14 & 31));
    // 0x8038C30C: andi        $t0, $t9, 0xFF
    ctx->r8 = ctx->r25 & 0XFF;
    // 0x8038C310: sll         $t1, $t0, 1
    ctx->r9 = S32(ctx->r8 << 1);
    // 0x8038C314: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x8038C318: lh          $t2, 0x2C78($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2C78);
    // 0x8038C31C: subu        $t5, $t4, $a0
    ctx->r13 = SUB32(ctx->r12, ctx->r4);
    // 0x8038C320: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    // 0x8038C324: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x8038C328: multu       $t3, $t5
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038C32C: lh          $t2, 0x35C($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C330: subu        $t8, $t7, $a1
    ctx->r24 = SUB32(ctx->r15, ctx->r5);
    // 0x8038C334: mflo        $t6
    ctx->r14 = lo;
    // 0x8038C338: srav        $t9, $t6, $t8
    ctx->r25 = S32(SIGNED(ctx->r14) >> (ctx->r24 & 31));
    // 0x8038C33C: addu        $t1, $v1, $t9
    ctx->r9 = ADD32(ctx->r3, ctx->r25);
    // 0x8038C340: addu        $t4, $t2, $t1
    ctx->r12 = ADD32(ctx->r10, ctx->r9);
    // 0x8038C344: sh          $t4, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r12;
    // 0x8038C348: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x8038C34C: lh          $t5, 0x35A($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X35A);
    // 0x8038C350: lh          $t3, 0x35C($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C354: sra         $t7, $t5, 4
    ctx->r15 = S32(SIGNED(ctx->r13) >> 4);
    // 0x8038C358: subu        $t6, $t3, $t7
    ctx->r14 = SUB32(ctx->r11, ctx->r15);
    // 0x8038C35C: sh          $t6, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r14;
    // 0x8038C360: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x8038C364: lh          $t8, 0x35C($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C368: sll         $t9, $t8, 4
    ctx->r25 = S32(ctx->r24 << 4);
    // 0x8038C36C: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x8038C370: sra         $t0, $t9, 4
    ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
    // 0x8038C374: sh          $t0, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r8;
    // 0x8038C378: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x8038C37C: lh          $t1, 0x35A($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X35A);
    // 0x8038C380: lh          $t2, 0x35C($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C384: addu        $t4, $t1, $t2
    ctx->r12 = ADD32(ctx->r9, ctx->r10);
    // 0x8038C388: sh          $t4, 0x35A($v0)
    MEM_H(0X35A, ctx->r2) = ctx->r12;
L_8038C38C:
    // 0x8038C38C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8038C390: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x8038C394: lw          $t7, 0x0($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X0);
    // 0x8038C398: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8038C39C: lw          $v0, 0x4278($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X4278);
    // 0x8038C3A0: lh          $t6, 0x35A($t7)
    ctx->r14 = MEM_H(ctx->r15, 0X35A);
    // 0x8038C3A4: lwc1        $f8, 0x28($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X28);
    // 0x8038C3A8: lui         $t5, 0x4
    ctx->r13 = S32(0X4 << 16);
    // 0x8038C3AC: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8038C3B0: addu        $t5, $t5, $v0
    ctx->r13 = ADD32(ctx->r13, ctx->r2);
    // 0x8038C3B4: lw          $t5, -0x76E8($t5)
    ctx->r13 = MEM_W(ctx->r13, -0X76E8);
    // 0x8038C3B8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038C3BC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038C3C0: sll         $t3, $t5, 6
    ctx->r11 = S32(ctx->r13 << 6);
    // 0x8038C3C4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038C3C8: addu        $a0, $v0, $t3
    ctx->r4 = ADD32(ctx->r2, ctx->r11);
    // 0x8038C3CC: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8038C3D0: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x8038C3D4: lui         $at, 0x4038
    ctx->r1 = S32(0X4038 << 16);
    // 0x8038C3D8: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x8038C3DC: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x8038C3E0: lh          $a1, 0x1A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1A);
    // 0x8038C3E4: cvt.d.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f16.d = CVT_D_S(ctx->f10.fl);
    // 0x8038C3E8: div.d       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = DIV_D(ctx->f16.d, ctx->f18.d);
    // 0x8038C3EC: trunc.w.d   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_D(ctx->f4.d);
    // 0x8038C3F0: mfc1        $a2, $f6
    ctx->r6 = (int32_t)ctx->f6.u32l;
    // 0x8038C3F4: nop

    // 0x8038C3F8: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8038C3FC: jal         0x80128078
    // 0x8038C400: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    func_80128078(rdram, ctx);
        goto after_0;
    // 0x8038C400: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    after_0:
    // 0x8038C404: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x8038C408: addiu       $a1, $a1, -0x6178
    ctx->r5 = ADD32(ctx->r5, -0X6178);
    // 0x8038C40C: lw          $a0, 0x0($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X0);
    // 0x8038C410: lui         $t2, 0x100
    ctx->r10 = S32(0X100 << 16);
    // 0x8038C414: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8038C418: addiu       $t1, $a0, 0x8
    ctx->r9 = ADD32(ctx->r4, 0X8);
    // 0x8038C41C: sw          $t1, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r9;
    // 0x8038C420: ori         $t2, $t2, 0x40
    ctx->r10 = ctx->r10 | 0X40;
    // 0x8038C424: addiu       $a2, $a2, 0x4278
    ctx->r6 = ADD32(ctx->r6, 0X4278);
    // 0x8038C428: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x8038C42C: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8038C430: lui         $a3, 0x3
    ctx->r7 = S32(0X3 << 16);
    // 0x8038C434: ori         $a3, $a3, 0x8000
    ctx->r7 = ctx->r7 | 0X8000;
    // 0x8038C438: addu        $t4, $v0, $a3
    ctx->r12 = ADD32(ctx->r2, ctx->r7);
    // 0x8038C43C: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x8038C440: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x8038C444: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038C448: sll         $t3, $t5, 6
    ctx->r11 = S32(ctx->r13 << 6);
    // 0x8038C44C: addu        $t7, $v0, $t3
    ctx->r15 = ADD32(ctx->r2, ctx->r11);
    // 0x8038C450: addu        $t6, $t7, $at
    ctx->r14 = ADD32(ctx->r15, ctx->r1);
    // 0x8038C454: sw          $t6, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r14;
    // 0x8038C458: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8038C45C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038C460: addu        $t8, $v0, $a3
    ctx->r24 = ADD32(ctx->r2, ctx->r7);
    // 0x8038C464: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8038C468: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x8038C46C: addiu       $t0, $t9, 0x1
    ctx->r8 = ADD32(ctx->r25, 0X1);
    // 0x8038C470: sw          $t0, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r8;
L_8038C474:
    // 0x8038C474: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038C478: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038C47C: jr          $ra
    // 0x8038C480: nop

    return;
    // 0x8038C480: nop

;}
RECOMP_FUNC void func_8038C484_79DB34(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C484: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038C488: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8038C48C: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x8038C490: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038C494: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8038C498: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8038C49C: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x8038C4A0: lbu         $v1, 0x162($t8)
    ctx->r3 = MEM_BU(ctx->r24, 0X162);
    // 0x8038C4A4: mtc1        $a3, $f12
    ctx->f12.u32l = ctx->r7;
    // 0x8038C4A8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x8038C4AC: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x8038C4B0: beq         $a3, $v1, L_8038C4C0
    if (ctx->r7 == ctx->r3) {
        // 0x8038C4B4: sra         $a2, $t6, 16
        ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
            goto L_8038C4C0;
    }
    // 0x8038C4B4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038C4B8: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8038C4BC: bne         $v1, $at, L_8038C718
    if (ctx->r3 != ctx->r1) {
        // 0x8038C4C0: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_8038C718;
    }
L_8038C4C0:
    // 0x8038C4C0: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8038C4C4: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x8038C4C8: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C4CC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8038C4D0: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038C4D4: lbu         $a0, 0x366($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X366);
    // 0x8038C4D8: beq         $a3, $a0, L_8038C4F0
    if (ctx->r7 == ctx->r4) {
        // 0x8038C4DC: nop
    
            goto L_8038C4F0;
    }
    // 0x8038C4DC: nop

    // 0x8038C4E0: beq         $a0, $at, L_8038C4F0
    if (ctx->r4 == ctx->r1) {
        // 0x8038C4E4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8038C4F0;
    }
    // 0x8038C4E4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038C4E8: bne         $a0, $at, L_8038C718
    if (ctx->r4 != ctx->r1) {
        // 0x8038C4EC: nop
    
            goto L_8038C718;
    }
    // 0x8038C4EC: nop

L_8038C4F0:
    // 0x8038C4F0: lb          $t9, 0x2D10($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X2D10);
    // 0x8038C4F4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038C4F8: bnel        $t9, $zero, L_8038C640
    if (ctx->r25 != 0) {
        // 0x8038C4FC: lh          $t1, 0x35A($v0)
        ctx->r9 = MEM_H(ctx->r2, 0X35A);
            goto L_8038C640;
    }
    goto skip_0;
    // 0x8038C4FC: lh          $t1, 0x35A($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X35A);
    skip_0:
    // 0x8038C500: lh          $v1, 0x35A($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X35A);
    // 0x8038C504: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038C508: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x8038C50C: slti        $at, $v1, -0x9C4
    ctx->r1 = SIGNED(ctx->r3) < -0X9C4 ? 1 : 0;
    // 0x8038C510: beq         $at, $zero, L_8038C52C
    if (ctx->r1 == 0) {
        // 0x8038C514: addiu       $t0, $v1, 0x9C4
        ctx->r8 = ADD32(ctx->r3, 0X9C4);
            goto L_8038C52C;
    }
    // 0x8038C514: addiu       $t0, $v1, 0x9C4
    ctx->r8 = ADD32(ctx->r3, 0X9C4);
    // 0x8038C518: sra         $t1, $t0, 2
    ctx->r9 = S32(SIGNED(ctx->r8) >> 2);
    // 0x8038C51C: addiu       $t2, $t1, -0x9C4
    ctx->r10 = ADD32(ctx->r9, -0X9C4);
    // 0x8038C520: sh          $t2, 0x35A($v0)
    MEM_H(0X35A, ctx->r2) = ctx->r10;
    // 0x8038C524: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C528: lh          $v1, 0x35A($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X35A);
L_8038C52C:
    // 0x8038C52C: slti        $at, $v1, 0x9C5
    ctx->r1 = SIGNED(ctx->r3) < 0X9C5 ? 1 : 0;
    // 0x8038C530: bne         $at, $zero, L_8038C548
    if (ctx->r1 != 0) {
        // 0x8038C534: addiu       $t3, $v1, -0x9C4
        ctx->r11 = ADD32(ctx->r3, -0X9C4);
            goto L_8038C548;
    }
    // 0x8038C534: addiu       $t3, $v1, -0x9C4
    ctx->r11 = ADD32(ctx->r3, -0X9C4);
    // 0x8038C538: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x8038C53C: addiu       $t5, $t4, 0x9C4
    ctx->r13 = ADD32(ctx->r12, 0X9C4);
    // 0x8038C540: sh          $t5, 0x35A($v0)
    MEM_H(0X35A, ctx->r2) = ctx->r13;
    // 0x8038C544: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
L_8038C548:
    // 0x8038C548: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x8038C54C: lh          $t0, 0x1E($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X1E);
    // 0x8038C550: beql        $t6, $zero, L_8038C584
    if (ctx->r14 == 0) {
        // 0x8038C554: lb          $t4, 0x368($v0)
        ctx->r12 = MEM_B(ctx->r2, 0X368);
            goto L_8038C584;
    }
    goto skip_1;
    // 0x8038C554: lb          $t4, 0x368($v0)
    ctx->r12 = MEM_B(ctx->r2, 0X368);
    skip_1:
    // 0x8038C558: lb          $t7, 0x554B($t7)
    ctx->r15 = MEM_B(ctx->r15, 0X554B);
    // 0x8038C55C: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x8038C560: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x8038C564: sra         $t8, $t7, 2
    ctx->r24 = S32(SIGNED(ctx->r15) >> 2);
    // 0x8038C568: addiu       $t1, $t0, 0x2
    ctx->r9 = ADD32(ctx->r8, 0X2);
    // 0x8038C56C: addu        $t9, $a0, $t8
    ctx->r25 = ADD32(ctx->r4, ctx->r24);
    // 0x8038C570: sllv        $v1, $t9, $t1
    ctx->r3 = S32(ctx->r25 << (ctx->r9 & 31));
    // 0x8038C574: sll         $t2, $v1, 16
    ctx->r10 = S32(ctx->r3 << 16);
    // 0x8038C578: b           L_8038C5A0
    // 0x8038C57C: sra         $v1, $t2, 16
    ctx->r3 = S32(SIGNED(ctx->r10) >> 16);
        goto L_8038C5A0;
    // 0x8038C57C: sra         $v1, $t2, 16
    ctx->r3 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8038C580: lb          $t4, 0x368($v0)
    ctx->r12 = MEM_B(ctx->r2, 0X368);
L_8038C584:
    // 0x8038C584: lh          $t6, 0x1E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X1E);
    // 0x8038C588: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x8038C58C: sra         $t5, $t4, 2
    ctx->r13 = S32(SIGNED(ctx->r12) >> 2);
    // 0x8038C590: addiu       $t7, $t6, 0x2
    ctx->r15 = ADD32(ctx->r14, 0X2);
    // 0x8038C594: sllv        $v1, $t5, $t7
    ctx->r3 = S32(ctx->r13 << (ctx->r15 & 31));
    // 0x8038C598: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8038C59C: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_8038C5A0:
    // 0x8038C5A0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038C5A4: lh          $t9, 0x5540($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5540);
    // 0x8038C5A8: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x8038C5AC: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x8038C5B0: sllv        $t3, $t9, $a2
    ctx->r11 = S32(ctx->r25 << (ctx->r6 & 31));
    // 0x8038C5B4: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8038C5B8: sll         $t6, $t4, 1
    ctx->r14 = S32(ctx->r12 << 1);
    // 0x8038C5BC: addu        $t5, $t5, $t6
    ctx->r13 = ADD32(ctx->r13, ctx->r14);
    // 0x8038C5C0: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x8038C5C4: subu        $t0, $t8, $a0
    ctx->r8 = SUB32(ctx->r24, ctx->r4);
    // 0x8038C5C8: lh          $t1, 0x1A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X1A);
    // 0x8038C5CC: sra         $t7, $t5, 7
    ctx->r15 = S32(SIGNED(ctx->r13) >> 7);
    // 0x8038C5D0: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038C5D4: addiu       $t2, $zero, 0x8
    ctx->r10 = ADD32(0, 0X8);
    // 0x8038C5D8: lh          $t8, 0x35C($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C5DC: subu        $t3, $t2, $t1
    ctx->r11 = SUB32(ctx->r10, ctx->r9);
    // 0x8038C5E0: mflo        $t9
    ctx->r25 = lo;
    // 0x8038C5E4: srav        $t4, $t9, $t3
    ctx->r12 = S32(SIGNED(ctx->r25) >> (ctx->r11 & 31));
    // 0x8038C5E8: addu        $t5, $v1, $t4
    ctx->r13 = ADD32(ctx->r3, ctx->r12);
    // 0x8038C5EC: addu        $t7, $t8, $t5
    ctx->r15 = ADD32(ctx->r24, ctx->r13);
    // 0x8038C5F0: sh          $t7, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r15;
    // 0x8038C5F4: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C5F8: lh          $t2, 0x35A($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X35A);
    // 0x8038C5FC: lh          $t0, 0x35C($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C600: sra         $t1, $t2, 4
    ctx->r9 = S32(SIGNED(ctx->r10) >> 4);
    // 0x8038C604: subu        $t9, $t0, $t1
    ctx->r25 = SUB32(ctx->r8, ctx->r9);
    // 0x8038C608: sh          $t9, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r25;
    // 0x8038C60C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C610: lh          $t3, 0x35C($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C614: sll         $t4, $t3, 4
    ctx->r12 = S32(ctx->r11 << 4);
    // 0x8038C618: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038C61C: sra         $t6, $t4, 4
    ctx->r14 = S32(SIGNED(ctx->r12) >> 4);
    // 0x8038C620: sh          $t6, 0x35C($v0)
    MEM_H(0X35C, ctx->r2) = ctx->r14;
    // 0x8038C624: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C628: lh          $t5, 0x35A($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X35A);
    // 0x8038C62C: lh          $t8, 0x35C($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X35C);
    // 0x8038C630: addu        $t7, $t5, $t8
    ctx->r15 = ADD32(ctx->r13, ctx->r24);
    // 0x8038C634: sh          $t7, 0x35A($v0)
    MEM_H(0X35A, ctx->r2) = ctx->r15;
    // 0x8038C638: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8038C63C: lh          $t1, 0x35A($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X35A);
L_8038C640:
    // 0x8038C640: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8038C644: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x8038C648: mtc1        $t1, $f4
    ctx->f4.u32l = ctx->r9;
    // 0x8038C64C: lui         $t2, 0x4
    ctx->r10 = S32(0X4 << 16);
    // 0x8038C650: addu        $t2, $t2, $v1
    ctx->r10 = ADD32(ctx->r10, ctx->r3);
    // 0x8038C654: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038C658: lw          $t2, -0x76E8($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X76E8);
    // 0x8038C65C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038C660: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038C664: sll         $t0, $t2, 6
    ctx->r8 = S32(ctx->r10 << 6);
    // 0x8038C668: addu        $a0, $v1, $t0
    ctx->r4 = ADD32(ctx->r3, ctx->r8);
    // 0x8038C66C: mul.s       $f8, $f6, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f12.fl);
    // 0x8038C670: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8038C674: lui         $at, 0x4038
    ctx->r1 = S32(0X4038 << 16);
    // 0x8038C678: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x8038C67C: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x8038C680: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038C684: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x8038C688: div.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x8038C68C: trunc.w.d   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x8038C690: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x8038C694: nop

    // 0x8038C698: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x8038C69C: jal         0x80128078
    // 0x8038C6A0: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    func_80128078(rdram, ctx);
        goto after_0;
    // 0x8038C6A0: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    after_0:
    // 0x8038C6A4: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x8038C6A8: addiu       $a1, $a1, -0x6178
    ctx->r5 = ADD32(ctx->r5, -0X6178);
    // 0x8038C6AC: lw          $a0, 0x0($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X0);
    // 0x8038C6B0: lui         $t5, 0x100
    ctx->r13 = S32(0X100 << 16);
    // 0x8038C6B4: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8038C6B8: addiu       $t6, $a0, 0x8
    ctx->r14 = ADD32(ctx->r4, 0X8);
    // 0x8038C6BC: sw          $t6, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r14;
    // 0x8038C6C0: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x8038C6C4: addiu       $a2, $a2, 0x4278
    ctx->r6 = ADD32(ctx->r6, 0X4278);
    // 0x8038C6C8: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8038C6CC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8038C6D0: lui         $a3, 0x3
    ctx->r7 = S32(0X3 << 16);
    // 0x8038C6D4: ori         $a3, $a3, 0x8000
    ctx->r7 = ctx->r7 | 0X8000;
    // 0x8038C6D8: addu        $t8, $v1, $a3
    ctx->r24 = ADD32(ctx->r3, ctx->r7);
    // 0x8038C6DC: lw          $t7, 0x918($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X918);
    // 0x8038C6E0: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x8038C6E4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038C6E8: sll         $t2, $t7, 6
    ctx->r10 = S32(ctx->r15 << 6);
    // 0x8038C6EC: addu        $t0, $v1, $t2
    ctx->r8 = ADD32(ctx->r3, ctx->r10);
    // 0x8038C6F0: addu        $t1, $t0, $at
    ctx->r9 = ADD32(ctx->r8, ctx->r1);
    // 0x8038C6F4: sw          $t1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r9;
    // 0x8038C6F8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8038C6FC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038C700: addu        $t9, $v1, $a3
    ctx->r25 = ADD32(ctx->r3, ctx->r7);
    // 0x8038C704: lw          $t3, 0x918($t9)
    ctx->r11 = MEM_W(ctx->r25, 0X918);
    // 0x8038C708: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x8038C70C: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8038C710: b           L_8038C744
    // 0x8038C714: sw          $t4, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r12;
        goto L_8038C744;
    // 0x8038C714: sw          $t4, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r12;
L_8038C718:
    // 0x8038C718: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8038C71C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038C720: beq         $v1, $at, L_8038C744
    if (ctx->r3 == ctx->r1) {
        // 0x8038C724: addiu       $a1, $a1, 0x552C
        ctx->r5 = ADD32(ctx->r5, 0X552C);
            goto L_8038C744;
    }
    // 0x8038C724: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x8038C728: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038C72C: beq         $v1, $at, L_8038C744
    if (ctx->r3 == ctx->r1) {
        // 0x8038C730: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_8038C744;
    }
    // 0x8038C730: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x8038C734: beq         $v1, $at, L_8038C744
    if (ctx->r3 == ctx->r1) {
        // 0x8038C738: lh          $t6, 0x2A($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X2A);
            goto L_8038C744;
    }
    // 0x8038C738: lh          $t6, 0x2A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2A);
    // 0x8038C73C: lw          $t5, 0x0($a1)
    ctx->r13 = MEM_W(ctx->r5, 0X0);
    // 0x8038C740: sh          $t6, 0x35A($t5)
    MEM_H(0X35A, ctx->r13) = ctx->r14;
L_8038C744:
    // 0x8038C744: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038C748: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038C74C: jr          $ra
    // 0x8038C750: nop

    return;
    // 0x8038C750: nop

;}
RECOMP_FUNC void func_8038C760_79DE10(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C760: jr          $ra
    // 0x8038C764: nop

    return;
    // 0x8038C764: nop

;}
RECOMP_FUNC void func_8038C768_79DE18(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C768: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038C76C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x8038C770: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038C774: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038C778: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038C77C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038C780: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x8038C784: lhu         $t7, 0x35E($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X35E);
    // 0x8038C788: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038C78C: lb          $t9, 0x2D10($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X2D10);
    // 0x8038C790: subu        $a0, $t6, $t7
    ctx->r4 = SUB32(ctx->r14, ctx->r15);
    // 0x8038C794: andi        $t8, $a0, 0xFFFF
    ctx->r24 = ctx->r4 & 0XFFFF;
    // 0x8038C798: bne         $t9, $zero, L_8038C8A0
    if (ctx->r25 != 0) {
        // 0x8038C79C: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_8038C8A0;
    }
    // 0x8038C79C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038C7A0: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8038C7A4: lb          $t2, 0x4A($t0)
    ctx->r10 = MEM_B(ctx->r8, 0X4A);
    // 0x8038C7A8: bnel        $t2, $zero, L_8038C8A4
    if (ctx->r10 != 0) {
        // 0x8038C7AC: sh          $zero, 0x314($v1)
        MEM_H(0X314, ctx->r3) = 0;
            goto L_8038C8A4;
    }
    goto skip_0;
    // 0x8038C7AC: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
    skip_0:
    // 0x8038C7B0: beq         $t8, $zero, L_8038C8A0
    if (ctx->r24 == 0) {
        // 0x8038C7B4: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_8038C8A0;
    }
    // 0x8038C7B4: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x8038C7B8: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x8038C7BC: lbu         $t3, 0x5538($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X5538);
    // 0x8038C7C0: andi        $t4, $t8, 0xFF
    ctx->r12 = ctx->r24 & 0XFF;
    // 0x8038C7C4: slti        $at, $t4, 0x96
    ctx->r1 = SIGNED(ctx->r12) < 0X96 ? 1 : 0;
    // 0x8038C7C8: beql        $t3, $zero, L_8038C828
    if (ctx->r11 == 0) {
        // 0x8038C7CC: andi        $t8, $v0, 0xFF
        ctx->r24 = ctx->r2 & 0XFF;
            goto L_8038C828;
    }
    goto skip_1;
    // 0x8038C7CC: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    skip_1:
    // 0x8038C7D0: bne         $at, $zero, L_8038C81C
    if (ctx->r1 != 0) {
        // 0x8038C7D4: nop
    
            goto L_8038C81C;
    }
    // 0x8038C7D4: nop

    // 0x8038C7D8: jal         0x8012826C
    // 0x8038C7DC: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x8038C7DC: nop

    after_0:
    // 0x8038C7E0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038C7E4: andi        $t5, $v0, 0xF
    ctx->r13 = ctx->r2 & 0XF;
    // 0x8038C7E8: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x8038C7EC: bne         $t5, $at, L_8038C8A4
    if (ctx->r13 != ctx->r1) {
        // 0x8038C7F0: addiu       $t1, $t1, 0x552C
        ctx->r9 = ADD32(ctx->r9, 0X552C);
            goto L_8038C8A4;
    }
    // 0x8038C7F0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x8038C7F4: jal         0x8012826C
    // 0x8038C7F8: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x8038C7F8: nop

    after_1:
    // 0x8038C7FC: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8038C800: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038C804: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038C808: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x8038C80C: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x8038C810: mfhi        $t6
    ctx->r14 = hi;
    // 0x8038C814: b           L_8038C8A4
    // 0x8038C818: sh          $t6, 0x314($t7)
    MEM_H(0X314, ctx->r15) = ctx->r14;
        goto L_8038C8A4;
    // 0x8038C818: sh          $t6, 0x314($t7)
    MEM_H(0X314, ctx->r15) = ctx->r14;
L_8038C81C:
    // 0x8038C81C: b           L_8038C8A4
    // 0x8038C820: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
        goto L_8038C8A4;
    // 0x8038C820: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
    // 0x8038C824: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
L_8038C828:
    // 0x8038C828: slti        $at, $t8, 0x82
    ctx->r1 = SIGNED(ctx->r24) < 0X82 ? 1 : 0;
    // 0x8038C82C: bne         $at, $zero, L_8038C898
    if (ctx->r1 != 0) {
        // 0x8038C830: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_8038C898;
    }
    // 0x8038C830: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038C834: lh          $t9, 0x5534($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5534);
    // 0x8038C838: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038C83C: lh          $a2, 0x4($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X4);
    // 0x8038C840: sll         $t2, $t9, 3
    ctx->r10 = S32(ctx->r25 << 3);
    // 0x8038C844: addu        $v0, $v0, $t2
    ctx->r2 = ADD32(ctx->r2, ctx->r10);
    // 0x8038C848: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038C84C: lh          $a3, 0x8($t0)
    ctx->r7 = MEM_H(ctx->r8, 0X8);
    // 0x8038C850: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8038C854: jal         0x80128C10
    // 0x8038C858: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    func_80128C10(rdram, ctx);
        goto after_2;
    // 0x8038C858: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    after_2:
    // 0x8038C85C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038C860: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x8038C864: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038C868: lh          $t3, 0x302($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X302);
    // 0x8038C86C: sll         $t4, $t3, 2
    ctx->r12 = S32(ctx->r11 << 2);
    // 0x8038C870: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038C874: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8038C878: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038C87C: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8038C880: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x8038C884: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x8038C888: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x8038C88C: subu        $t6, $t5, $v0
    ctx->r14 = SUB32(ctx->r13, ctx->r2);
    // 0x8038C890: b           L_8038C8A4
    // 0x8038C894: sh          $t6, 0x314($v1)
    MEM_H(0X314, ctx->r3) = ctx->r14;
        goto L_8038C8A4;
    // 0x8038C894: sh          $t6, 0x314($v1)
    MEM_H(0X314, ctx->r3) = ctx->r14;
L_8038C898:
    // 0x8038C898: b           L_8038C8A4
    // 0x8038C89C: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
        goto L_8038C8A4;
    // 0x8038C89C: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
L_8038C8A0:
    // 0x8038C8A0: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
L_8038C8A4:
    // 0x8038C8A4: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038C8A8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038C8AC: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x8038C8B0: beq         $v0, $at, L_8038C8C0
    if (ctx->r2 == ctx->r1) {
        // 0x8038C8B4: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8038C8C0;
    }
    // 0x8038C8B4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038C8B8: bnel        $v0, $at, L_8038C8CC
    if (ctx->r2 != ctx->r1) {
        // 0x8038C8BC: lh          $a2, 0x316($v1)
        ctx->r6 = MEM_H(ctx->r3, 0X316);
            goto L_8038C8CC;
    }
    goto skip_2;
    // 0x8038C8BC: lh          $a2, 0x316($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X316);
    skip_2:
L_8038C8C0:
    // 0x8038C8C0: sh          $zero, 0x314($v1)
    MEM_H(0X314, ctx->r3) = 0;
    // 0x8038C8C4: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038C8C8: lh          $a2, 0x316($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X316);
L_8038C8CC:
    // 0x8038C8CC: lh          $t7, 0x314($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X314);
    // 0x8038C8D0: subu        $v0, $t7, $a2
    ctx->r2 = SUB32(ctx->r15, ctx->r6);
    // 0x8038C8D4: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8038C8D8: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038C8DC: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x8038C8E0: bne         $at, $zero, L_8038C900
    if (ctx->r1 != 0) {
        // 0x8038C8E4: nop
    
            goto L_8038C900;
    }
    // 0x8038C8E4: nop

    // 0x8038C8E8: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
L_8038C8EC:
    // 0x8038C8EC: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x8038C8F0: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8038C8F4: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x8038C8F8: beql        $at, $zero, L_8038C8EC
    if (ctx->r1 == 0) {
        // 0x8038C8FC: addiu       $v0, $v0, -0x168
        ctx->r2 = ADD32(ctx->r2, -0X168);
            goto L_8038C8EC;
    }
    goto skip_3;
    // 0x8038C8FC: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
    skip_3:
L_8038C900:
    // 0x8038C900: bgezl       $v0, L_8038C920
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8038C904: slti        $at, $v0, 0xB5
        ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
            goto L_8038C920;
    }
    goto skip_4;
    // 0x8038C904: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    skip_4:
    // 0x8038C908: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
L_8038C90C:
    // 0x8038C90C: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x8038C910: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8038C914: bltzl       $v0, L_8038C90C
    if (SIGNED(ctx->r2) < 0) {
        // 0x8038C918: addiu       $v0, $v0, 0x168
        ctx->r2 = ADD32(ctx->r2, 0X168);
            goto L_8038C90C;
    }
    goto skip_5;
    // 0x8038C918: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
    skip_5:
    // 0x8038C91C: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
L_8038C920:
    // 0x8038C920: bne         $at, $zero, L_8038C948
    if (ctx->r1 != 0) {
        // 0x8038C924: addiu       $a1, $v0, -0x168
        ctx->r5 = ADD32(ctx->r2, -0X168);
            goto L_8038C948;
    }
    // 0x8038C924: addiu       $a1, $v0, -0x168
    ctx->r5 = ADD32(ctx->r2, -0X168);
    // 0x8038C928: slti        $at, $a1, -0x11
    ctx->r1 = SIGNED(ctx->r5) < -0X11 ? 1 : 0;
    // 0x8038C92C: bne         $at, $zero, L_8038C93C
    if (ctx->r1 != 0) {
        // 0x8038C930: addiu       $a0, $zero, -0x12
        ctx->r4 = ADD32(0, -0X12);
            goto L_8038C93C;
    }
    // 0x8038C930: addiu       $a0, $zero, -0x12
    ctx->r4 = ADD32(0, -0X12);
    // 0x8038C934: b           L_8038C93C
    // 0x8038C938: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
        goto L_8038C93C;
    // 0x8038C938: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
L_8038C93C:
    // 0x8038C93C: addu        $t6, $a2, $a0
    ctx->r14 = ADD32(ctx->r6, ctx->r4);
    // 0x8038C940: b           L_8038C964
    // 0x8038C944: sh          $t6, 0x316($v1)
    MEM_H(0X316, ctx->r3) = ctx->r14;
        goto L_8038C964;
    // 0x8038C944: sh          $t6, 0x316($v1)
    MEM_H(0X316, ctx->r3) = ctx->r14;
L_8038C948:
    // 0x8038C948: slti        $at, $v0, 0x12
    ctx->r1 = SIGNED(ctx->r2) < 0X12 ? 1 : 0;
    // 0x8038C94C: beq         $at, $zero, L_8038C95C
    if (ctx->r1 == 0) {
        // 0x8038C950: addiu       $a0, $zero, 0x12
        ctx->r4 = ADD32(0, 0X12);
            goto L_8038C95C;
    }
    // 0x8038C950: addiu       $a0, $zero, 0x12
    ctx->r4 = ADD32(0, 0X12);
    // 0x8038C954: b           L_8038C95C
    // 0x8038C958: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
        goto L_8038C95C;
    // 0x8038C958: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_8038C95C:
    // 0x8038C95C: addu        $t7, $a2, $a0
    ctx->r15 = ADD32(ctx->r6, ctx->r4);
    // 0x8038C960: sh          $t7, 0x316($v1)
    MEM_H(0X316, ctx->r3) = ctx->r15;
L_8038C964:
    // 0x8038C964: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038C968: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8038C96C: lh          $t8, 0x316($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X316);
    // 0x8038C970: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x8038C974: mfhi        $t9
    ctx->r25 = hi;
    // 0x8038C978: sh          $t9, 0x316($v1)
    MEM_H(0X316, ctx->r3) = ctx->r25;
    // 0x8038C97C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038C980: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038C984: jr          $ra
    // 0x8038C988: nop

    return;
    // 0x8038C988: nop

;}
RECOMP_FUNC void func_8038C98C_79E03C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038C98C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038C990: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038C994: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038C998: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038C99C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038C9A0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038C9A4: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x8038C9A8: lhu         $t7, 0x35E($a0)
    ctx->r15 = MEM_HU(ctx->r4, 0X35E);
    // 0x8038C9AC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038C9B0: lb          $t9, 0x2D10($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X2D10);
    // 0x8038C9B4: subu        $a1, $t6, $t7
    ctx->r5 = SUB32(ctx->r14, ctx->r15);
    // 0x8038C9B8: andi        $t8, $a1, 0xFFFF
    ctx->r24 = ctx->r5 & 0XFFFF;
    // 0x8038C9BC: bne         $t9, $zero, L_8038CB20
    if (ctx->r25 != 0) {
        // 0x8038C9C0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_8038CB20;
    }
    // 0x8038C9C0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038C9C4: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8038C9C8: lb          $t1, 0x4A($v1)
    ctx->r9 = MEM_B(ctx->r3, 0X4A);
    // 0x8038C9CC: bnel        $t1, $zero, L_8038CB24
    if (ctx->r9 != 0) {
        // 0x8038C9D0: sh          $zero, 0x314($a0)
        MEM_H(0X314, ctx->r4) = 0;
            goto L_8038CB24;
    }
    goto skip_0;
    // 0x8038C9D0: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
    skip_0:
    // 0x8038C9D4: beq         $t8, $zero, L_8038CB20
    if (ctx->r24 == 0) {
        // 0x8038C9D8: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_8038CB20;
    }
    // 0x8038C9D8: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x8038C9DC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038C9E0: lbu         $t2, 0x5538($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X5538);
    // 0x8038C9E4: andi        $t9, $v0, 0xFF
    ctx->r25 = ctx->r2 & 0XFF;
    // 0x8038C9E8: andi        $t3, $t8, 0xFF
    ctx->r11 = ctx->r24 & 0XFF;
    // 0x8038C9EC: beq         $t2, $zero, L_8038CA6C
    if (ctx->r10 == 0) {
        // 0x8038C9F0: slti        $at, $t9, 0xC8
        ctx->r1 = SIGNED(ctx->r25) < 0XC8 ? 1 : 0;
            goto L_8038CA6C;
    }
    // 0x8038C9F0: slti        $at, $t9, 0xC8
    ctx->r1 = SIGNED(ctx->r25) < 0XC8 ? 1 : 0;
    // 0x8038C9F4: slti        $at, $t3, 0x96
    ctx->r1 = SIGNED(ctx->r11) < 0X96 ? 1 : 0;
    // 0x8038C9F8: bnel        $at, $zero, L_8038CA64
    if (ctx->r1 != 0) {
        // 0x8038C9FC: sh          $zero, 0x314($a0)
        MEM_H(0X314, ctx->r4) = 0;
            goto L_8038CA64;
    }
    goto skip_1;
    // 0x8038C9FC: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
    skip_1:
    // 0x8038CA00: jal         0x8012826C
    // 0x8038CA04: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x8038CA04: nop

    after_0:
    // 0x8038CA08: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038CA0C: andi        $t4, $v0, 0x1F
    ctx->r12 = ctx->r2 & 0X1F;
    // 0x8038CA10: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x8038CA14: bne         $t4, $at, L_8038CA58
    if (ctx->r12 != ctx->r1) {
        // 0x8038CA18: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8038CA58;
    }
    // 0x8038CA18: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038CA1C: jal         0x8012826C
    // 0x8038CA20: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x8038CA20: nop

    after_1:
    // 0x8038CA24: addiu       $at, $zero, 0x8C
    ctx->r1 = ADD32(0, 0X8C);
    // 0x8038CA28: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038CA2C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038CA30: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038CA34: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8038CA38: mfhi        $t5
    ctx->r13 = hi;
    // 0x8038CA3C: addiu       $t6, $t5, -0x46
    ctx->r14 = ADD32(ctx->r13, -0X46);
    // 0x8038CA40: sh          $t6, 0x314($t7)
    MEM_H(0X314, ctx->r15) = ctx->r14;
    // 0x8038CA44: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CA48: lh          $v1, 0x314($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X314);
    // 0x8038CA4C: bgez        $v1, L_8038CA58
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8038CA50: addiu       $t8, $v1, 0x168
        ctx->r24 = ADD32(ctx->r3, 0X168);
            goto L_8038CA58;
    }
    // 0x8038CA50: addiu       $t8, $v1, 0x168
    ctx->r24 = ADD32(ctx->r3, 0X168);
    // 0x8038CA54: sh          $t8, 0x314($a0)
    MEM_H(0X314, ctx->r4) = ctx->r24;
L_8038CA58:
    // 0x8038CA58: b           L_8038CB28
    // 0x8038CA5C: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
        goto L_8038CB28;
    // 0x8038CA5C: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CA60: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
L_8038CA64:
    // 0x8038CA64: b           L_8038CB28
    // 0x8038CA68: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
        goto L_8038CB28;
    // 0x8038CA68: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_8038CA6C:
    // 0x8038CA6C: bne         $at, $zero, L_8038CB14
    if (ctx->r1 != 0) {
        // 0x8038CA70: lui         $t1, 0x803D
        ctx->r9 = S32(0X803D << 16);
            goto L_8038CB14;
    }
    // 0x8038CA70: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8038CA74: lh          $t1, 0x5534($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5534);
    // 0x8038CA78: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038CA7C: lh          $a2, 0x4($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X4);
    // 0x8038CA80: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x8038CA84: addu        $v0, $v0, $t2
    ctx->r2 = ADD32(ctx->r2, ctx->r10);
    // 0x8038CA88: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038CA8C: lh          $a3, 0x8($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X8);
    // 0x8038CA90: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8038CA94: jal         0x80128C10
    // 0x8038CA98: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    func_80128C10(rdram, ctx);
        goto after_2;
    // 0x8038CA98: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    after_2:
    // 0x8038CA9C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038CAA0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038CAA4: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CAA8: addiu       $t7, $zero, 0x55
    ctx->r15 = ADD32(0, 0X55);
    // 0x8038CAAC: addiu       $t8, $zero, -0x55
    ctx->r24 = ADD32(0, -0X55);
    // 0x8038CAB0: lh          $t3, 0x302($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X302);
    // 0x8038CAB4: sll         $t4, $t3, 2
    ctx->r12 = S32(ctx->r11 << 2);
    // 0x8038CAB8: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038CABC: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8038CAC0: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038CAC4: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8038CAC8: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x8038CACC: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x8038CAD0: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x8038CAD4: subu        $t6, $t5, $v0
    ctx->r14 = SUB32(ctx->r13, ctx->r2);
    // 0x8038CAD8: sh          $t6, 0x314($a0)
    MEM_H(0X314, ctx->r4) = ctx->r14;
    // 0x8038CADC: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CAE0: lh          $v1, 0x314($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X314);
    // 0x8038CAE4: slti        $at, $v1, 0x56
    ctx->r1 = SIGNED(ctx->r3) < 0X56 ? 1 : 0;
    // 0x8038CAE8: bnel        $at, $zero, L_8038CB00
    if (ctx->r1 != 0) {
        // 0x8038CAEC: slti        $at, $v1, -0x55
        ctx->r1 = SIGNED(ctx->r3) < -0X55 ? 1 : 0;
            goto L_8038CB00;
    }
    goto skip_2;
    // 0x8038CAEC: slti        $at, $v1, -0x55
    ctx->r1 = SIGNED(ctx->r3) < -0X55 ? 1 : 0;
    skip_2:
    // 0x8038CAF0: sh          $t7, 0x314($a0)
    MEM_H(0X314, ctx->r4) = ctx->r15;
    // 0x8038CAF4: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CAF8: lh          $v1, 0x314($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X314);
    // 0x8038CAFC: slti        $at, $v1, -0x55
    ctx->r1 = SIGNED(ctx->r3) < -0X55 ? 1 : 0;
L_8038CB00:
    // 0x8038CB00: beql        $at, $zero, L_8038CB2C
    if (ctx->r1 == 0) {
        // 0x8038CB04: lbu         $v0, 0x366($a0)
        ctx->r2 = MEM_BU(ctx->r4, 0X366);
            goto L_8038CB2C;
    }
    goto skip_3;
    // 0x8038CB04: lbu         $v0, 0x366($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X366);
    skip_3:
    // 0x8038CB08: sh          $t8, 0x314($a0)
    MEM_H(0X314, ctx->r4) = ctx->r24;
    // 0x8038CB0C: b           L_8038CB28
    // 0x8038CB10: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
        goto L_8038CB28;
    // 0x8038CB10: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_8038CB14:
    // 0x8038CB14: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
    // 0x8038CB18: b           L_8038CB28
    // 0x8038CB1C: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
        goto L_8038CB28;
    // 0x8038CB1C: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_8038CB20:
    // 0x8038CB20: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
L_8038CB24:
    // 0x8038CB24: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_8038CB28:
    // 0x8038CB28: lbu         $v0, 0x366($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X366);
L_8038CB2C:
    // 0x8038CB2C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038CB30: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038CB34: beq         $v0, $at, L_8038CB44
    if (ctx->r2 == ctx->r1) {
        // 0x8038CB38: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8038CB44;
    }
    // 0x8038CB38: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038CB3C: bne         $v0, $at, L_8038CB4C
    if (ctx->r2 != ctx->r1) {
        // 0x8038CB40: nop
    
            goto L_8038CB4C;
    }
    // 0x8038CB40: nop

L_8038CB44:
    // 0x8038CB44: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
    // 0x8038CB48: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_8038CB4C:
    // 0x8038CB4C: lw          $t9, 0x5528($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5528);
    // 0x8038CB50: lhu         $t1, 0x3C0($t9)
    ctx->r9 = MEM_HU(ctx->r25, 0X3C0);
    // 0x8038CB54: beql        $t1, $zero, L_8038CB68
    if (ctx->r9 == 0) {
        // 0x8038CB58: lh          $a2, 0x316($a0)
        ctx->r6 = MEM_H(ctx->r4, 0X316);
            goto L_8038CB68;
    }
    goto skip_4;
    // 0x8038CB58: lh          $a2, 0x316($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X316);
    skip_4:
    // 0x8038CB5C: sh          $zero, 0x314($a0)
    MEM_H(0X314, ctx->r4) = 0;
    // 0x8038CB60: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CB64: lh          $a2, 0x316($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X316);
L_8038CB68:
    // 0x8038CB68: lh          $t2, 0x314($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X314);
    // 0x8038CB6C: subu        $v0, $t2, $a2
    ctx->r2 = SUB32(ctx->r10, ctx->r6);
    // 0x8038CB70: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x8038CB74: sra         $v0, $t3, 16
    ctx->r2 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8038CB78: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x8038CB7C: bne         $at, $zero, L_8038CB9C
    if (ctx->r1 != 0) {
        // 0x8038CB80: nop
    
            goto L_8038CB9C;
    }
    // 0x8038CB80: nop

    // 0x8038CB84: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
L_8038CB88:
    // 0x8038CB88: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x8038CB8C: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8038CB90: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x8038CB94: beql        $at, $zero, L_8038CB88
    if (ctx->r1 == 0) {
        // 0x8038CB98: addiu       $v0, $v0, -0x168
        ctx->r2 = ADD32(ctx->r2, -0X168);
            goto L_8038CB88;
    }
    goto skip_5;
    // 0x8038CB98: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
    skip_5:
L_8038CB9C:
    // 0x8038CB9C: bgezl       $v0, L_8038CBBC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8038CBA0: slti        $at, $v0, 0xB5
        ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
            goto L_8038CBBC;
    }
    goto skip_6;
    // 0x8038CBA0: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    skip_6:
    // 0x8038CBA4: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
L_8038CBA8:
    // 0x8038CBA8: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8038CBAC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038CBB0: bltzl       $v0, L_8038CBA8
    if (SIGNED(ctx->r2) < 0) {
        // 0x8038CBB4: addiu       $v0, $v0, 0x168
        ctx->r2 = ADD32(ctx->r2, 0X168);
            goto L_8038CBA8;
    }
    goto skip_7;
    // 0x8038CBB4: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
    skip_7:
    // 0x8038CBB8: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
L_8038CBBC:
    // 0x8038CBBC: bne         $at, $zero, L_8038CBE4
    if (ctx->r1 != 0) {
        // 0x8038CBC0: addiu       $a1, $v0, -0x168
        ctx->r5 = ADD32(ctx->r2, -0X168);
            goto L_8038CBE4;
    }
    // 0x8038CBC0: addiu       $a1, $v0, -0x168
    ctx->r5 = ADD32(ctx->r2, -0X168);
    // 0x8038CBC4: slti        $at, $a1, -0x7
    ctx->r1 = SIGNED(ctx->r5) < -0X7 ? 1 : 0;
    // 0x8038CBC8: bne         $at, $zero, L_8038CBD8
    if (ctx->r1 != 0) {
        // 0x8038CBCC: addiu       $v1, $zero, -0x8
        ctx->r3 = ADD32(0, -0X8);
            goto L_8038CBD8;
    }
    // 0x8038CBCC: addiu       $v1, $zero, -0x8
    ctx->r3 = ADD32(0, -0X8);
    // 0x8038CBD0: b           L_8038CBD8
    // 0x8038CBD4: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_8038CBD8;
    // 0x8038CBD4: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_8038CBD8:
    // 0x8038CBD8: addu        $t9, $a2, $v1
    ctx->r25 = ADD32(ctx->r6, ctx->r3);
    // 0x8038CBDC: b           L_8038CC00
    // 0x8038CBE0: sh          $t9, 0x316($a0)
    MEM_H(0X316, ctx->r4) = ctx->r25;
        goto L_8038CC00;
    // 0x8038CBE0: sh          $t9, 0x316($a0)
    MEM_H(0X316, ctx->r4) = ctx->r25;
L_8038CBE4:
    // 0x8038CBE4: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x8038CBE8: beq         $at, $zero, L_8038CBF8
    if (ctx->r1 == 0) {
        // 0x8038CBEC: addiu       $v1, $zero, 0x8
        ctx->r3 = ADD32(0, 0X8);
            goto L_8038CBF8;
    }
    // 0x8038CBEC: addiu       $v1, $zero, 0x8
    ctx->r3 = ADD32(0, 0X8);
    // 0x8038CBF0: b           L_8038CBF8
    // 0x8038CBF4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_8038CBF8;
    // 0x8038CBF4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_8038CBF8:
    // 0x8038CBF8: addu        $t1, $a2, $v1
    ctx->r9 = ADD32(ctx->r6, ctx->r3);
    // 0x8038CBFC: sh          $t1, 0x316($a0)
    MEM_H(0X316, ctx->r4) = ctx->r9;
L_8038CC00:
    // 0x8038CC00: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x8038CC04: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8038CC08: lh          $t2, 0x316($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X316);
    // 0x8038CC0C: div         $zero, $t2, $at
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r1)));
    // 0x8038CC10: mfhi        $t3
    ctx->r11 = hi;
    // 0x8038CC14: sh          $t3, 0x316($a0)
    MEM_H(0X316, ctx->r4) = ctx->r11;
    // 0x8038CC18: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038CC1C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038CC20: jr          $ra
    // 0x8038CC24: nop

    return;
    // 0x8038CC24: nop

;}
RECOMP_FUNC void func_8038CC28_79E2D8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CC28: lui         $t6, 0x8028
    ctx->r14 = S32(0X8028 << 16);
    // 0x8038CC2C: lh          $t6, 0x6560($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6560);
    // 0x8038CC30: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038CC34: addiu       $t7, $t6, 0x3
    ctx->r15 = ADD32(ctx->r14, 0X3);
    // 0x8038CC38: andi        $t8, $t7, 0x3F
    ctx->r24 = ctx->r15 & 0X3F;
    // 0x8038CC3C: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x8038CC40: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x8038CC44: addu        $v0, $v0, $t0
    ctx->r2 = ADD32(ctx->r2, ctx->r8);
    // 0x8038CC48: jr          $ra
    // 0x8038CC4C: lh          $v0, 0x62D0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X62D0);
    return;
    // 0x8038CC4C: lh          $v0, 0x62D0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X62D0);
;}
RECOMP_FUNC void func_8038CC50_79E300(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CC50: lui         $t6, 0x8028
    ctx->r14 = S32(0X8028 << 16);
    // 0x8038CC54: lh          $t6, 0x6560($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6560);
    // 0x8038CC58: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8038CC5C: addiu       $t7, $t6, -0x7
    ctx->r15 = ADD32(ctx->r14, -0X7);
    // 0x8038CC60: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8038CC64: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8038CC68: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038CC6C: addiu       $t1, $t0, 0x40
    ctx->r9 = ADD32(ctx->r8, 0X40);
    // 0x8038CC70: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x8038CC74: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x8038CC78: addu        $v0, $v0, $t3
    ctx->r2 = ADD32(ctx->r2, ctx->r11);
    // 0x8038CC7C: lh          $v0, 0x2C78($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2C78);
    // 0x8038CC80: sra         $t4, $v0, 7
    ctx->r12 = S32(SIGNED(ctx->r2) >> 7);
    // 0x8038CC84: addiu       $v0, $t4, 0x100
    ctx->r2 = ADD32(ctx->r12, 0X100);
    // 0x8038CC88: bgez        $v0, L_8038CC98
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8038CC8C: sra         $t5, $v0, 3
        ctx->r13 = S32(SIGNED(ctx->r2) >> 3);
            goto L_8038CC98;
    }
    // 0x8038CC8C: sra         $t5, $v0, 3
    ctx->r13 = S32(SIGNED(ctx->r2) >> 3);
    // 0x8038CC90: addiu       $at, $v0, 0x7
    ctx->r1 = ADD32(ctx->r2, 0X7);
    // 0x8038CC94: sra         $t5, $at, 3
    ctx->r13 = S32(SIGNED(ctx->r1) >> 3);
L_8038CC98:
    // 0x8038CC98: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8038CC9C: jr          $ra
    // 0x8038CCA0: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    return;
    // 0x8038CCA0: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
;}
RECOMP_FUNC void func_8038CCA4_79E354(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CCA4: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x8038CCA8: lh          $v0, 0x6560($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X6560);
    // 0x8038CCAC: addiu       $v0, $v0, 0x7
    ctx->r2 = ADD32(ctx->r2, 0X7);
    // 0x8038CCB0: andi        $t6, $v0, 0x3F
    ctx->r14 = ctx->r2 & 0X3F;
    // 0x8038CCB4: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x8038CCB8: jr          $ra
    // 0x8038CCBC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    return;
    // 0x8038CCBC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
;}
RECOMP_FUNC void func_8038CCC0_79E370(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CCC0: lui         $t6, 0x8028
    ctx->r14 = S32(0X8028 << 16);
    // 0x8038CCC4: lui         $t9, 0x8028
    ctx->r25 = S32(0X8028 << 16);
    // 0x8038CCC8: lh          $t9, 0x6562($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6562);
    // 0x8038CCCC: lh          $t6, 0x6560($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6560);
    // 0x8038CCD0: addiu       $t0, $t9, 0x7
    ctx->r8 = ADD32(ctx->r25, 0X7);
    // 0x8038CCD4: addiu       $t7, $t6, 0x7
    ctx->r15 = ADD32(ctx->r14, 0X7);
    // 0x8038CCD8: andi        $t8, $t7, 0x3F
    ctx->r24 = ctx->r15 & 0X3F;
    // 0x8038CCDC: andi        $t1, $t0, 0x3F
    ctx->r9 = ctx->r8 & 0X3F;
    // 0x8038CCE0: slt         $v0, $t8, $t1
    ctx->r2 = SIGNED(ctx->r24) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x8038CCE4: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x8038CCE8: jr          $ra
    // 0x8038CCEC: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    return;
    // 0x8038CCEC: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
;}
RECOMP_FUNC void func_8038CCF0_79E3A0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CCF0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038CCF4: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038CCF8: lh          $t8, 0x6450($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X6450);
    // 0x8038CCFC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8038CD00: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8038CD04: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038CD08: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038CD0C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8038CD10: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x8038CD14: bne         $t8, $zero, L_8038CD24
    if (ctx->r24 != 0) {
        // 0x8038CD18: sw          $a3, 0x24($sp)
        MEM_W(0X24, ctx->r29) = ctx->r7;
            goto L_8038CD24;
    }
    // 0x8038CD18: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x8038CD1C: b           L_8038CF74
    // 0x8038CD20: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8038CF74;
    // 0x8038CD20: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8038CD24:
    // 0x8038CD24: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038CD28: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8038CD2C: lh          $t9, 0x318($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X318);
    // 0x8038CD30: beql        $t9, $zero, L_8038CD44
    if (ctx->r25 == 0) {
        // 0x8038CD34: lbu         $v0, 0x366($v1)
        ctx->r2 = MEM_BU(ctx->r3, 0X366);
            goto L_8038CD44;
    }
    goto skip_0;
    // 0x8038CD34: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    skip_0:
    // 0x8038CD38: b           L_8038CF74
    // 0x8038CD3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8038CF74;
    // 0x8038CD3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8038CD40: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
L_8038CD44:
    // 0x8038CD44: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038CD48: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8038CD4C: beq         $v0, $at, L_8038CD64
    if (ctx->r2 == ctx->r1) {
        // 0x8038CD50: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8038CD64;
    }
    // 0x8038CD50: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8038CD54: beq         $v0, $at, L_8038CD64
    if (ctx->r2 == ctx->r1) {
        // 0x8038CD58: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8038CD64;
    }
    // 0x8038CD58: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038CD5C: bnel        $v0, $at, L_8038CF78
    if (ctx->r2 != ctx->r1) {
        // 0x8038CD60: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038CF78;
    }
    goto skip_1;
    // 0x8038CD60: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
L_8038CD64:
    // 0x8038CD64: lb          $t1, 0x2D10($t1)
    ctx->r9 = MEM_B(ctx->r9, 0X2D10);
    // 0x8038CD68: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038CD6C: bnel        $t1, $zero, L_8038CF78
    if (ctx->r9 != 0) {
        // 0x8038CD70: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038CF78;
    }
    goto skip_2;
    // 0x8038CD70: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x8038CD74: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x8038CD78: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038CD7C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x8038CD80: lhu         $v0, 0x0($t2)
    ctx->r2 = MEM_HU(ctx->r10, 0X0);
    // 0x8038CD84: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CD88: addiu       $at, $zero, 0x15
        ctx->r1 = ADD32(0, 0X15);
            goto L_8038CDD4;
    }
    // 0x8038CD88: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x8038CD8C: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CD90: addiu       $at, $zero, 0x29
        ctx->r1 = ADD32(0, 0X29);
            goto L_8038CDD4;
    }
    // 0x8038CD90: addiu       $at, $zero, 0x29
    ctx->r1 = ADD32(0, 0X29);
    // 0x8038CD94: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CD98: addiu       $at, $zero, 0x3D
        ctx->r1 = ADD32(0, 0X3D);
            goto L_8038CDD4;
    }
    // 0x8038CD98: addiu       $at, $zero, 0x3D
    ctx->r1 = ADD32(0, 0X3D);
    // 0x8038CD9C: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDA0: addiu       $at, $zero, 0x51
        ctx->r1 = ADD32(0, 0X51);
            goto L_8038CDD4;
    }
    // 0x8038CDA0: addiu       $at, $zero, 0x51
    ctx->r1 = ADD32(0, 0X51);
    // 0x8038CDA4: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDA8: addiu       $at, $zero, 0x65
        ctx->r1 = ADD32(0, 0X65);
            goto L_8038CDD4;
    }
    // 0x8038CDA8: addiu       $at, $zero, 0x65
    ctx->r1 = ADD32(0, 0X65);
    // 0x8038CDAC: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDB0: addiu       $at, $zero, 0x79
        ctx->r1 = ADD32(0, 0X79);
            goto L_8038CDD4;
    }
    // 0x8038CDB0: addiu       $at, $zero, 0x79
    ctx->r1 = ADD32(0, 0X79);
    // 0x8038CDB4: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDB8: addiu       $at, $zero, 0x8D
        ctx->r1 = ADD32(0, 0X8D);
            goto L_8038CDD4;
    }
    // 0x8038CDB8: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x8038CDBC: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDC0: addiu       $at, $zero, 0xB5
        ctx->r1 = ADD32(0, 0XB5);
            goto L_8038CDD4;
    }
    // 0x8038CDC0: addiu       $at, $zero, 0xB5
    ctx->r1 = ADD32(0, 0XB5);
    // 0x8038CDC4: beq         $v0, $at, L_8038CDD4
    if (ctx->r2 == ctx->r1) {
        // 0x8038CDC8: addiu       $at, $zero, 0xC9
        ctx->r1 = ADD32(0, 0XC9);
            goto L_8038CDD4;
    }
    // 0x8038CDC8: addiu       $at, $zero, 0xC9
    ctx->r1 = ADD32(0, 0XC9);
    // 0x8038CDCC: bnel        $v0, $at, L_8038CF78
    if (ctx->r2 != ctx->r1) {
        // 0x8038CDD0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038CF78;
    }
    goto skip_3;
    // 0x8038CDD0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
L_8038CDD4:
    // 0x8038CDD4: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8038CDD8: lh          $v0, 0x46D8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X46D8);
    // 0x8038CDDC: bne         $v0, $zero, L_8038CE40
    if (ctx->r2 != 0) {
        // 0x8038CDE0: slti        $at, $v0, 0x76D
        ctx->r1 = SIGNED(ctx->r2) < 0X76D ? 1 : 0;
            goto L_8038CE40;
    }
    // 0x8038CDE0: slti        $at, $v0, 0x76D
    ctx->r1 = SIGNED(ctx->r2) < 0X76D ? 1 : 0;
    // 0x8038CDE4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038CDE8: lwc1        $f4, 0x517C($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X517C);
    // 0x8038CDEC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038CDF0: ldc1        $f6, -0x4A0($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X4A0);
    // 0x8038CDF4: cvt.d.s     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f0.d = CVT_D_S(ctx->f4.fl);
    // 0x8038CDF8: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x8038CDFC: c.lt.d      $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f6.d < ctx->f0.d;
    // 0x8038CE00: nop

    // 0x8038CE04: bc1fl       L_8038CE18
    if (!c1cs) {
        // 0x8038CE08: mtc1        $at, $f9
        ctx->f_odd[(9 - 1) * 2] = ctx->r1;
            goto L_8038CE18;
    }
    goto skip_4;
    // 0x8038CE08: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    skip_4:
    // 0x8038CE0C: b           L_8038CE64
    // 0x8038CE10: addiu       $v0, $zero, 0x190
    ctx->r2 = ADD32(0, 0X190);
        goto L_8038CE64;
    // 0x8038CE10: addiu       $v0, $zero, 0x190
    ctx->r2 = ADD32(0, 0X190);
    // 0x8038CE14: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
L_8038CE18:
    // 0x8038CE18: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8038CE1C: nop

    // 0x8038CE20: c.lt.d      $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f8.d < ctx->f0.d;
    // 0x8038CE24: nop

    // 0x8038CE28: bc1f        L_8038CE38
    if (!c1cs) {
        // 0x8038CE2C: nop
    
            goto L_8038CE38;
    }
    // 0x8038CE2C: nop

    // 0x8038CE30: b           L_8038CE64
    // 0x8038CE34: addiu       $v0, $zero, 0xC8
    ctx->r2 = ADD32(0, 0XC8);
        goto L_8038CE64;
    // 0x8038CE34: addiu       $v0, $zero, 0xC8
    ctx->r2 = ADD32(0, 0XC8);
L_8038CE38:
    // 0x8038CE38: b           L_8038CE64
    // 0x8038CE3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8038CE64;
    // 0x8038CE3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8038CE40:
    // 0x8038CE40: bnel        $at, $zero, L_8038CE54
    if (ctx->r1 != 0) {
        // 0x8038CE44: slti        $at, $v0, 0x3E9
        ctx->r1 = SIGNED(ctx->r2) < 0X3E9 ? 1 : 0;
            goto L_8038CE54;
    }
    goto skip_5;
    // 0x8038CE44: slti        $at, $v0, 0x3E9
    ctx->r1 = SIGNED(ctx->r2) < 0X3E9 ? 1 : 0;
    skip_5:
    // 0x8038CE48: b           L_8038CE64
    // 0x8038CE4C: addiu       $v0, $zero, 0x12C
    ctx->r2 = ADD32(0, 0X12C);
        goto L_8038CE64;
    // 0x8038CE4C: addiu       $v0, $zero, 0x12C
    ctx->r2 = ADD32(0, 0X12C);
    // 0x8038CE50: slti        $at, $v0, 0x3E9
    ctx->r1 = SIGNED(ctx->r2) < 0X3E9 ? 1 : 0;
L_8038CE54:
    // 0x8038CE54: bne         $at, $zero, L_8038CE64
    if (ctx->r1 != 0) {
        // 0x8038CE58: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8038CE64;
    }
    // 0x8038CE58: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8038CE5C: b           L_8038CE64
    // 0x8038CE60: addiu       $v0, $zero, 0xAF
    ctx->r2 = ADD32(0, 0XAF);
        goto L_8038CE64;
    // 0x8038CE60: addiu       $v0, $zero, 0xAF
    ctx->r2 = ADD32(0, 0XAF);
L_8038CE64:
    // 0x8038CE64: lhu         $t4, 0x31C($v1)
    ctx->r12 = MEM_HU(ctx->r3, 0X31C);
    // 0x8038CE68: lhu         $t3, 0x5544($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X5544);
    // 0x8038CE6C: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x8038CE70: addu        $t6, $t3, $t5
    ctx->r14 = ADD32(ctx->r11, ctx->r13);
    // 0x8038CE74: andi        $t7, $t6, 0x1FF
    ctx->r15 = ctx->r14 & 0X1FF;
    // 0x8038CE78: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8038CE7C: beql        $at, $zero, L_8038CF78
    if (ctx->r1 == 0) {
        // 0x8038CE80: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038CF78;
    }
    goto skip_6;
    // 0x8038CE80: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x8038CE84: jal         0x8038CC28
    // 0x8038CE88: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    func_8038CC28_79E2D8(rdram, ctx);
        goto after_0;
    // 0x8038CE88: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    after_0:
    // 0x8038CE8C: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
    // 0x8038CE90: lh          $a2, 0x1A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X1A);
    // 0x8038CE94: lh          $a3, 0x22($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X22);
    // 0x8038CE98: bltz        $a1, L_8038CEC8
    if (SIGNED(ctx->r5) < 0) {
        // 0x8038CE9C: lh          $t0, 0x26($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X26);
            goto L_8038CEC8;
    }
    // 0x8038CE9C: lh          $t0, 0x26($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X26);
    // 0x8038CEA0: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038CEA4: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038CEA8: addiu       $a0, $a0, 0x3FE0
    ctx->r4 = ADD32(ctx->r4, 0X3FE0);
    // 0x8038CEAC: sll         $t8, $a1, 3
    ctx->r24 = S32(ctx->r5 << 3);
    // 0x8038CEB0: addu        $v1, $a0, $t8
    ctx->r3 = ADD32(ctx->r4, ctx->r24);
    // 0x8038CEB4: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x8038CEB8: mflo        $t1
    ctx->r9 = lo;
    // 0x8038CEBC: sra         $t3, $t1, 6
    ctx->r11 = S32(SIGNED(ctx->r9) >> 6);
    // 0x8038CEC0: subu        $t5, $t9, $t3
    ctx->r13 = SUB32(ctx->r25, ctx->r11);
    // 0x8038CEC4: sh          $t5, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r13;
L_8038CEC8:
    // 0x8038CEC8: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038CECC: bltz        $a3, L_8038CEF4
    if (SIGNED(ctx->r7) < 0) {
        // 0x8038CED0: addiu       $a0, $a0, 0x3FE0
        ctx->r4 = ADD32(ctx->r4, 0X3FE0);
            goto L_8038CEF4;
    }
    // 0x8038CED0: addiu       $a0, $a0, 0x3FE0
    ctx->r4 = ADD32(ctx->r4, 0X3FE0);
    // 0x8038CED4: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038CED8: sll         $t6, $a3, 3
    ctx->r14 = S32(ctx->r7 << 3);
    // 0x8038CEDC: addu        $v1, $a0, $t6
    ctx->r3 = ADD32(ctx->r4, ctx->r14);
    // 0x8038CEE0: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x8038CEE4: mflo        $t8
    ctx->r24 = lo;
    // 0x8038CEE8: sra         $t4, $t8, 6
    ctx->r12 = S32(SIGNED(ctx->r24) >> 6);
    // 0x8038CEEC: subu        $t9, $t7, $t4
    ctx->r25 = SUB32(ctx->r15, ctx->r12);
    // 0x8038CEF0: sh          $t9, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r25;
L_8038CEF4:
    // 0x8038CEF4: bltzl       $t0, L_8038CF20
    if (SIGNED(ctx->r8) < 0) {
        // 0x8038CEF8: lh          $a1, 0x2A($sp)
        ctx->r5 = MEM_H(ctx->r29, 0X2A);
            goto L_8038CF20;
    }
    goto skip_7;
    // 0x8038CEF8: lh          $a1, 0x2A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2A);
    skip_7:
    // 0x8038CEFC: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038CF00: sll         $t3, $t0, 3
    ctx->r11 = S32(ctx->r8 << 3);
    // 0x8038CF04: addu        $v1, $a0, $t3
    ctx->r3 = ADD32(ctx->r4, ctx->r11);
    // 0x8038CF08: lh          $t5, 0x4($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X4);
    // 0x8038CF0C: mflo        $t6
    ctx->r14 = lo;
    // 0x8038CF10: sra         $t2, $t6, 6
    ctx->r10 = S32(SIGNED(ctx->r14) >> 6);
    // 0x8038CF14: subu        $t7, $t5, $t2
    ctx->r15 = SUB32(ctx->r13, ctx->r10);
    // 0x8038CF18: sh          $t7, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r15;
    // 0x8038CF1C: lh          $a1, 0x2A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2A);
L_8038CF20:
    // 0x8038CF20: bltzl       $a1, L_8038CF4C
    if (SIGNED(ctx->r5) < 0) {
        // 0x8038CF24: lh          $a1, 0x2E($sp)
        ctx->r5 = MEM_H(ctx->r29, 0X2E);
            goto L_8038CF4C;
    }
    goto skip_8;
    // 0x8038CF24: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    skip_8:
    // 0x8038CF28: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038CF2C: sll         $t4, $a1, 3
    ctx->r12 = S32(ctx->r5 << 3);
    // 0x8038CF30: addu        $v1, $a0, $t4
    ctx->r3 = ADD32(ctx->r4, ctx->r12);
    // 0x8038CF34: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x8038CF38: mflo        $t3
    ctx->r11 = lo;
    // 0x8038CF3C: sra         $t1, $t3, 6
    ctx->r9 = S32(SIGNED(ctx->r11) >> 6);
    // 0x8038CF40: subu        $t5, $t9, $t1
    ctx->r13 = SUB32(ctx->r25, ctx->r9);
    // 0x8038CF44: sh          $t5, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r13;
    // 0x8038CF48: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
L_8038CF4C:
    // 0x8038CF4C: bltzl       $a1, L_8038CF78
    if (SIGNED(ctx->r5) < 0) {
        // 0x8038CF50: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038CF78;
    }
    goto skip_9;
    // 0x8038CF50: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x8038CF54: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038CF58: sll         $t2, $a1, 3
    ctx->r10 = S32(ctx->r5 << 3);
    // 0x8038CF5C: addu        $v1, $a0, $t2
    ctx->r3 = ADD32(ctx->r4, ctx->r10);
    // 0x8038CF60: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x8038CF64: mflo        $t4
    ctx->r12 = lo;
    // 0x8038CF68: sra         $t8, $t4, 6
    ctx->r24 = S32(SIGNED(ctx->r12) >> 6);
    // 0x8038CF6C: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x8038CF70: sh          $t9, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r25;
L_8038CF74:
    // 0x8038CF74: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038CF78:
    // 0x8038CF78: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038CF7C: jr          $ra
    // 0x8038CF80: nop

    return;
    // 0x8038CF80: nop

;}
RECOMP_FUNC void func_8038CF90_79E640(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038CF90: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x8038CF94: addiu       $a2, $a2, -0x6184
    ctx->r6 = ADD32(ctx->r6, -0X6184);
    // 0x8038CF98: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8038CF9C: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038CFA0: addiu       $t8, $t8, 0x4270
    ctx->r24 = ADD32(ctx->r24, 0X4270);
    // 0x8038CFA4: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8038CFA8: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x8038CFAC: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8038CFB0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038CFB4: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8038CFB8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8038CFBC: lui         $t0, 0xFCFF
    ctx->r8 = S32(0XFCFF << 16);
    // 0x8038CFC0: lui         $t1, 0xFFFD
    ctx->r9 = S32(0XFFFD << 16);
    // 0x8038CFC4: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038CFC8: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x8038CFCC: ori         $t1, $t1, 0xF6FB
    ctx->r9 = ctx->r9 | 0XF6FB;
    // 0x8038CFD0: ori         $t0, $t0, 0xFFFF
    ctx->r8 = ctx->r8 | 0XFFFF;
    // 0x8038CFD4: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8038CFD8: sw          $t1, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r9;
    // 0x8038CFDC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8038CFE0: lui         $t3, 0xB900
    ctx->r11 = S32(0XB900 << 16);
    // 0x8038CFE4: lui         $t4, 0xF0A
    ctx->r12 = S32(0XF0A << 16);
    // 0x8038CFE8: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x8038CFEC: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x8038CFF0: ori         $t4, $t4, 0x4000
    ctx->r12 = ctx->r12 | 0X4000;
    // 0x8038CFF4: ori         $t3, $t3, 0x31D
    ctx->r11 = ctx->r11 | 0X31D;
    // 0x8038CFF8: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x8038CFFC: jr          $ra
    // 0x8038D000: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    return;
    // 0x8038D000: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
;}
RECOMP_FUNC void render_terminal_background_glyphs(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038D004: addiu       $sp, $sp, -0x138
    ctx->r29 = ADD32(ctx->r29, -0X138);
    // 0x8038D008: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8038D00C: sw          $s7, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r23;
    // 0x8038D010: sw          $s1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r17;
    // 0x8038D014: sw          $s0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r16;
    // 0x8038D018: andi        $s0, $a1, 0xFFFF
    ctx->r16 = ctx->r5 & 0XFFFF;
    // 0x8038D01C: or          $s7, $a0, $zero
    ctx->r23 = ctx->r4 | 0;
    // 0x8038D020: sw          $s6, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r22;
    // 0x8038D024: sw          $s5, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r21;
    // 0x8038D028: sw          $s4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r20;
    // 0x8038D02C: sw          $s3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r19;
    // 0x8038D030: sw          $s2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r18;
    // 0x8038D034: sdc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X28, ctx->r29);
    // 0x8038D038: sdc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X20, ctx->r29);
    // 0x8038D03C: sw          $a1, 0x13C($sp)
    MEM_W(0X13C, ctx->r29) = ctx->r5;
    // 0x8038D040: jal         0x8012C1F0
    // 0x8038D044: addiu       $s1, $zero, 0xA
    ctx->r17 = ADD32(0, 0XA);
    load_default_display_list(rdram, ctx);
        goto after_0;
    // 0x8038D044: addiu       $s1, $zero, 0xA
    ctx->r17 = ADD32(0, 0XA);
    after_0:
    // 0x8038D048: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038D04C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038D050: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038D054: jal         0x8012C248
    // 0x8038D058: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_1;
    // 0x8038D058: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_1:
    // 0x8038D05C: sll         $v0, $s0, 2
    ctx->r2 = S32(ctx->r16 << 2);
    // 0x8038D060: slti        $at, $v0, 0x50
    ctx->r1 = SIGNED(ctx->r2) < 0X50 ? 1 : 0;
    // 0x8038D064: beq         $at, $zero, L_8038D074
    if (ctx->r1 == 0) {
        // 0x8038D068: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_8038D074;
    }
    // 0x8038D068: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038D06C: b           L_8038D078
    // 0x8038D070: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_8038D078;
    // 0x8038D070: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_8038D074:
    // 0x8038D074: addiu       $v1, $zero, 0x50
    ctx->r3 = ADD32(0, 0X50);
L_8038D078:
    // 0x8038D078: andi        $a1, $v1, 0xFF
    ctx->r5 = ctx->r3 & 0XFF;
    // 0x8038D07C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038D080: jal         0x8012C214
    // 0x8038D084: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_2;
    // 0x8038D084: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_2:
    // 0x8038D088: lui         $at, 0x4110
    ctx->r1 = S32(0X4110 << 16);
    // 0x8038D08C: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8038D090: lui         $at, 0x4150
    ctx->r1 = S32(0X4150 << 16);
    // 0x8038D094: lui         $s5, 0x803B
    ctx->r21 = S32(0X803B << 16);
    // 0x8038D098: lui         $s2, 0x803C
    ctx->r18 = S32(0X803C << 16);
    // 0x8038D09C: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038D0A0: addiu       $s2, $s2, -0x2C
    ctx->r18 = ADD32(ctx->r18, -0X2C);
    // 0x8038D0A4: addiu       $s5, $s5, 0x6328
    ctx->r21 = ADD32(ctx->r21, 0X6328);
    // 0x8038D0A8: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8038D0AC: addiu       $s6, $zero, 0x39C
    ctx->r22 = ADD32(0, 0X39C);
    // 0x8038D0B0: addiu       $s4, $sp, 0xE4
    ctx->r20 = ADD32(ctx->r29, 0XE4);
    // 0x8038D0B4: addiu       $s3, $sp, 0x64
    ctx->r19 = ADD32(ctx->r29, 0X64);
L_8038D0B8:
    // 0x8038D0B8: jal         0x80129128
    // 0x8038D0BC: nop

    rand_recomp(rdram, ctx);
        goto after_3;
    // 0x8038D0BC: nop

    after_3:
    // 0x8038D0C0: div         $zero, $v0, $s6
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r22))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r22)));
    // 0x8038D0C4: mflo        $t6
    ctx->r14 = lo;
    // 0x8038D0C8: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x8038D0CC: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8038D0D0: addu        $t9, $s5, $t8
    ctx->r25 = ADD32(ctx->r21, ctx->r24);
    // 0x8038D0D4: lw          $a2, 0x0($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X0);
    // 0x8038D0D8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8038D0DC: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x8038D0E0: bne         $s6, $zero, L_8038D0EC
    if (ctx->r22 != 0) {
        // 0x8038D0E4: nop
    
            goto L_8038D0EC;
    }
    // 0x8038D0E4: nop

    // 0x8038D0E8: break       7
    do_break(2151207144);
L_8038D0EC:
    // 0x8038D0EC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8038D0F0: bne         $s6, $at, L_8038D104
    if (ctx->r22 != ctx->r1) {
        // 0x8038D0F4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8038D104;
    }
    // 0x8038D0F4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8038D0F8: bne         $v0, $at, L_8038D104
    if (ctx->r2 != ctx->r1) {
        // 0x8038D0FC: nop
    
            goto L_8038D104;
    }
    // 0x8038D0FC: nop

    // 0x8038D100: break       6
    do_break(2151207168);
L_8038D104:
    // 0x8038D104: jal         0x801395F4
    // 0x8038D108: nop

    sprintf_recomp(rdram, ctx);
        goto after_4;
    // 0x8038D108: nop

    after_4:
    // 0x8038D10C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8038D110: jal         0x801308B4
    // 0x8038D114: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    prepare_text(rdram, ctx);
        goto after_5;
    // 0x8038D114: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    after_5:
    // 0x8038D118: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
    // 0x8038D11C: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x8038D120: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8038D124: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x8038D128: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    // 0x8038D12C: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x8038D130: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038D134: jal         0x8012D374
    // 0x8038D138: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    func_8012D374(rdram, ctx);
        goto after_6;
    // 0x8038D138: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    after_6:
    // 0x8038D13C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038D140: andi        $t2, $s0, 0xFF
    ctx->r10 = ctx->r16 & 0XFF;
    // 0x8038D144: addiu       $s1, $s1, 0xA
    ctx->r17 = ADD32(ctx->r17, 0XA);
    // 0x8038D148: slti        $at, $t2, 0x4
    ctx->r1 = SIGNED(ctx->r10) < 0X4 ? 1 : 0;
    // 0x8038D14C: andi        $t1, $s1, 0xFFFF
    ctx->r9 = ctx->r17 & 0XFFFF;
    // 0x8038D150: or          $s0, $t2, $zero
    ctx->r16 = ctx->r10 | 0;
    // 0x8038D154: bne         $at, $zero, L_8038D0B8
    if (ctx->r1 != 0) {
        // 0x8038D158: or          $s1, $t1, $zero
        ctx->r17 = ctx->r9 | 0;
            goto L_8038D0B8;
    }
    // 0x8038D158: or          $s1, $t1, $zero
    ctx->r17 = ctx->r9 | 0;
    // 0x8038D15C: lui         $s5, 0x803B
    ctx->r21 = S32(0X803B << 16);
    // 0x8038D160: addiu       $s5, $s5, 0x6320
    ctx->r21 = ADD32(ctx->r21, 0X6320);
    // 0x8038D164: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8038D168: addiu       $s6, $zero, 0xD
    ctx->r22 = ADD32(0, 0XD);
L_8038D16C:
    // 0x8038D16C: jal         0x8012826C
    // 0x8038D170: nop

    advance_random_seed(rdram, ctx);
        goto after_7;
    // 0x8038D170: nop

    after_7:
    // 0x8038D174: andi        $t0, $v0, 0x7
    ctx->r8 = ctx->r2 & 0X7;
    // 0x8038D178: sra         $s1, $v0, 3
    ctx->r17 = S32(SIGNED(ctx->r2) >> 3);
    // 0x8038D17C: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8038D180: andi        $t4, $s1, 0xF
    ctx->r12 = ctx->r17 & 0XF;
    // 0x8038D184: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8038D188: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x8038D18C: sra         $s2, $v0, 8
    ctx->r18 = S32(SIGNED(ctx->r2) >> 8);
    // 0x8038D190: addu        $t3, $s5, $t2
    ctx->r11 = ADD32(ctx->r21, ctx->r10);
    // 0x8038D194: lbu         $t4, 0x0($t3)
    ctx->r12 = MEM_BU(ctx->r11, 0X0);
    // 0x8038D198: andi        $t7, $s2, 0x3
    ctx->r15 = ctx->r18 & 0X3;
    // 0x8038D19C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8038D1A0: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8038D1A4: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038D1A8: sb          $zero, 0xE5($sp)
    MEM_B(0XE5, ctx->r29) = 0;
    // 0x8038D1AC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8038D1B0: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x8038D1B4: jal         0x801308B4
    // 0x8038D1B8: sb          $t4, 0xE4($sp)
    MEM_B(0XE4, ctx->r29) = ctx->r12;
    prepare_text(rdram, ctx);
        goto after_8;
    // 0x8038D1B8: sb          $t4, 0xE4($sp)
    MEM_B(0XE4, ctx->r29) = ctx->r12;
    after_8:
    // 0x8038D1BC: multu       $s1, $s6
    result = U64(U32(ctx->r17)) * U64(U32(ctx->r22)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038D1C0: sll         $a3, $s2, 3
    ctx->r7 = S32(ctx->r18 << 3);
    // 0x8038D1C4: addiu       $a3, $a3, 0xA
    ctx->r7 = ADD32(ctx->r7, 0XA);
    // 0x8038D1C8: andi        $t6, $a3, 0xFFFF
    ctx->r14 = ctx->r7 & 0XFFFF;
    // 0x8038D1CC: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8038D1D0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8038D1D4: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x8038D1D8: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038D1DC: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    // 0x8038D1E0: mflo        $a2
    ctx->r6 = lo;
    // 0x8038D1E4: addiu       $a2, $a2, 0xAF
    ctx->r6 = ADD32(ctx->r6, 0XAF);
    // 0x8038D1E8: andi        $t5, $a2, 0xFFFF
    ctx->r13 = ctx->r6 & 0XFFFF;
    // 0x8038D1EC: jal         0x8012DCA8
    // 0x8038D1F0: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    draw_glyph(rdram, ctx);
        goto after_9;
    // 0x8038D1F0: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    after_9:
    // 0x8038D1F4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038D1F8: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x8038D1FC: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038D200: slti        $at, $s0, 0xF
    ctx->r1 = SIGNED(ctx->r16) < 0XF ? 1 : 0;
    // 0x8038D204: bne         $at, $zero, L_8038D16C
    if (ctx->r1 != 0) {
        // 0x8038D208: nop
    
            goto L_8038D16C;
    }
    // 0x8038D208: nop

    // 0x8038D20C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8038D210: lui         $t0, 0xB800
    ctx->r8 = S32(0XB800 << 16);
    // 0x8038D214: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038D218: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x8038D21C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8038D220: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8038D224: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x8038D228: lw          $s7, 0x50($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X50);
    // 0x8038D22C: lw          $s6, 0x4C($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X4C);
    // 0x8038D230: lw          $s5, 0x48($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X48);
    // 0x8038D234: lw          $s4, 0x44($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X44);
    // 0x8038D238: lw          $s3, 0x40($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X40);
    // 0x8038D23C: lw          $s2, 0x3C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X3C);
    // 0x8038D240: lw          $s1, 0x38($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X38);
    // 0x8038D244: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x8038D248: ldc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X28);
    // 0x8038D24C: ldc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
    // 0x8038D250: jr          $ra
    // 0x8038D254: addiu       $sp, $sp, 0x138
    ctx->r29 = ADD32(ctx->r29, 0X138);
    return;
    // 0x8038D254: addiu       $sp, $sp, 0x138
    ctx->r29 = ADD32(ctx->r29, 0X138);
;}
RECOMP_FUNC void setup_terminal_stat_text(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038D258: addiu       $sp, $sp, -0x100
    ctx->r29 = ADD32(ctx->r29, -0X100);
    // 0x8038D25C: sw          $s1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r17;
    // 0x8038D260: sw          $s0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r16;
    // 0x8038D264: lui         $s1, 0x803B
    ctx->r17 = S32(0X803B << 16);
    // 0x8038D268: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x8038D26C: addiu       $s1, $s1, 0x6560
    ctx->r17 = ADD32(ctx->r17, 0X6560);
    // 0x8038D270: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8038D274: sll         $t6, $s0, 2
    ctx->r14 = S32(ctx->r16 << 2);
L_8038D278:
    // 0x8038D278: addu        $t7, $s1, $t6
    ctx->r15 = ADD32(ctx->r17, ctx->r14);
    // 0x8038D27C: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x8038D280: bnel        $t8, $zero, L_8038D294
    if (ctx->r24 != 0) {
        // 0x8038D284: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8038D294;
    }
    goto skip_0;
    // 0x8038D284: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x8038D288: jal         0x80130A90
    // 0x8038D28C: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    get_message_address_by_id(rdram, ctx);
        goto after_0;
    // 0x8038D28C: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    after_0:
    // 0x8038D290: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8038D294:
    // 0x8038D294: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x8038D298: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038D29C: slti        $at, $s0, 0x11
    ctx->r1 = SIGNED(ctx->r16) < 0X11 ? 1 : 0;
    // 0x8038D2A0: bnel        $at, $zero, L_8038D278
    if (ctx->r1 != 0) {
        // 0x8038D2A4: sll         $t6, $s0, 2
        ctx->r14 = S32(ctx->r16 << 2);
            goto L_8038D278;
    }
    goto skip_1;
    // 0x8038D2A4: sll         $t6, $s0, 2
    ctx->r14 = S32(ctx->r16 << 2);
    skip_1:
    // 0x8038D2A8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8038D2AC: lh          $a1, 0x5534($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X5534);
    // 0x8038D2B0: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x8038D2B4: addiu       $t2, $t2, -0x6128
    ctx->r10 = ADD32(ctx->r10, -0X6128);
    // 0x8038D2B8: sll         $t1, $a1, 3
    ctx->r9 = S32(ctx->r5 << 3);
    // 0x8038D2BC: addu        $v0, $t1, $t2
    ctx->r2 = ADD32(ctx->r9, ctx->r10);
    // 0x8038D2C0: addiu       $t3, $v0, 0x3EB0
    ctx->r11 = ADD32(ctx->r2, 0X3EB0);
    // 0x8038D2C4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D2C8: sw          $t3, 0x5520($at)
    MEM_W(0X5520, ctx->r1) = ctx->r11;
    // 0x8038D2CC: lw          $t4, 0x3EB0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X3EB0);
    // 0x8038D2D0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D2D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D2D8: sw          $t4, 0x5524($at)
    MEM_W(0X5524, ctx->r1) = ctx->r12;
    // 0x8038D2DC: lw          $t5, 0x3EB4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X3EB4);
    // 0x8038D2E0: addiu       $a0, $a0, 0x5528
    ctx->r4 = ADD32(ctx->r4, 0X5528);
    // 0x8038D2E4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D2E8: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8038D2EC: sw          $t5, 0x552C($at)
    MEM_W(0X552C, ctx->r1) = ctx->r13;
    // 0x8038D2F0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D2F4: sw          $t5, 0x5530($at)
    MEM_W(0X5530, ctx->r1) = ctx->r13;
    // 0x8038D2F8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D2FC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8038D300: sb          $t6, 0x5538($at)
    MEM_B(0X5538, ctx->r1) = ctx->r14;
    // 0x8038D304: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D308: sh          $a1, 0x553C($at)
    MEM_H(0X553C, ctx->r1) = ctx->r5;
    // 0x8038D30C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038D310: sh          $zero, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = 0;
    // 0x8038D314: jal         0x80130A90
    // 0x8038D318: addiu       $a0, $zero, 0x1F
    ctx->r4 = ADD32(0, 0X1F);
    get_message_address_by_id(rdram, ctx);
        goto after_1;
    // 0x8038D318: addiu       $a0, $zero, 0x1F
    ctx->r4 = ADD32(0, 0X1F);
    after_1:
    // 0x8038D31C: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x8038D320: addiu       $s0, $s0, 0x6500
    ctx->r16 = ADD32(ctx->r16, 0X6500);
    // 0x8038D324: sw          $v0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r2;
    // 0x8038D328: jal         0x80130A90
    // 0x8038D32C: addiu       $a0, $zero, 0x2E
    ctx->r4 = ADD32(0, 0X2E);
    get_message_address_by_id(rdram, ctx);
        goto after_2;
    // 0x8038D32C: addiu       $a0, $zero, 0x2E
    ctx->r4 = ADD32(0, 0X2E);
    after_2:
    // 0x8038D330: sw          $v0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r2;
    // 0x8038D334: jal         0x80130A90
    // 0x8038D338: addiu       $a0, $zero, 0x29
    ctx->r4 = ADD32(0, 0X29);
    get_message_address_by_id(rdram, ctx);
        goto after_3;
    // 0x8038D338: addiu       $a0, $zero, 0x29
    ctx->r4 = ADD32(0, 0X29);
    after_3:
    // 0x8038D33C: sw          $v0, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r2;
    // 0x8038D340: jal         0x80130A90
    // 0x8038D344: addiu       $a0, $zero, 0x2A
    ctx->r4 = ADD32(0, 0X2A);
    get_message_address_by_id(rdram, ctx);
        goto after_4;
    // 0x8038D344: addiu       $a0, $zero, 0x2A
    ctx->r4 = ADD32(0, 0X2A);
    after_4:
    // 0x8038D348: sw          $v0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r2;
    // 0x8038D34C: jal         0x80130A90
    // 0x8038D350: addiu       $a0, $zero, 0x21
    ctx->r4 = ADD32(0, 0X21);
    get_message_address_by_id(rdram, ctx);
        goto after_5;
    // 0x8038D350: addiu       $a0, $zero, 0x21
    ctx->r4 = ADD32(0, 0X21);
    after_5:
    // 0x8038D354: sw          $v0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r2;
    // 0x8038D358: jal         0x80130A90
    // 0x8038D35C: addiu       $a0, $zero, 0x24
    ctx->r4 = ADD32(0, 0X24);
    get_message_address_by_id(rdram, ctx);
        goto after_6;
    // 0x8038D35C: addiu       $a0, $zero, 0x24
    ctx->r4 = ADD32(0, 0X24);
    after_6:
    // 0x8038D360: sw          $v0, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r2;
    // 0x8038D364: jal         0x80130A90
    // 0x8038D368: addiu       $a0, $zero, 0x26
    ctx->r4 = ADD32(0, 0X26);
    get_message_address_by_id(rdram, ctx);
        goto after_7;
    // 0x8038D368: addiu       $a0, $zero, 0x26
    ctx->r4 = ADD32(0, 0X26);
    after_7:
    // 0x8038D36C: sw          $v0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r2;
    // 0x8038D370: jal         0x80130A90
    // 0x8038D374: addiu       $a0, $zero, 0x25
    ctx->r4 = ADD32(0, 0X25);
    get_message_address_by_id(rdram, ctx);
        goto after_8;
    // 0x8038D374: addiu       $a0, $zero, 0x25
    ctx->r4 = ADD32(0, 0X25);
    after_8:
    // 0x8038D378: sw          $v0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r2;
    // 0x8038D37C: jal         0x80130A90
    // 0x8038D380: addiu       $a0, $zero, 0x23
    ctx->r4 = ADD32(0, 0X23);
    get_message_address_by_id(rdram, ctx);
        goto after_9;
    // 0x8038D380: addiu       $a0, $zero, 0x23
    ctx->r4 = ADD32(0, 0X23);
    after_9:
    // 0x8038D384: sw          $v0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r2;
    // 0x8038D388: jal         0x80130A90
    // 0x8038D38C: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    get_message_address_by_id(rdram, ctx);
        goto after_10;
    // 0x8038D38C: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    after_10:
    // 0x8038D390: sw          $v0, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r2;
    // 0x8038D394: jal         0x80130A90
    // 0x8038D398: addiu       $a0, $zero, 0x2C
    ctx->r4 = ADD32(0, 0X2C);
    get_message_address_by_id(rdram, ctx);
        goto after_11;
    // 0x8038D398: addiu       $a0, $zero, 0x2C
    ctx->r4 = ADD32(0, 0X2C);
    after_11:
    // 0x8038D39C: sw          $v0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r2;
    // 0x8038D3A0: jal         0x80130A90
    // 0x8038D3A4: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    get_message_address_by_id(rdram, ctx);
        goto after_12;
    // 0x8038D3A4: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    after_12:
    // 0x8038D3A8: sw          $v0, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = ctx->r2;
    // 0x8038D3AC: jal         0x80130A90
    // 0x8038D3B0: addiu       $a0, $zero, 0x2D
    ctx->r4 = ADD32(0, 0X2D);
    get_message_address_by_id(rdram, ctx);
        goto after_13;
    // 0x8038D3B0: addiu       $a0, $zero, 0x2D
    ctx->r4 = ADD32(0, 0X2D);
    after_13:
    // 0x8038D3B4: sw          $v0, 0x30($s0)
    MEM_W(0X30, ctx->r16) = ctx->r2;
    // 0x8038D3B8: jal         0x80130A90
    // 0x8038D3BC: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    get_message_address_by_id(rdram, ctx);
        goto after_14;
    // 0x8038D3BC: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    after_14:
    // 0x8038D3C0: sw          $v0, 0x34($s0)
    MEM_W(0X34, ctx->r16) = ctx->r2;
    // 0x8038D3C4: jal         0x80130A90
    // 0x8038D3C8: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    get_message_address_by_id(rdram, ctx);
        goto after_15;
    // 0x8038D3C8: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    after_15:
    // 0x8038D3CC: sw          $v0, 0x38($s0)
    MEM_W(0X38, ctx->r16) = ctx->r2;
    // 0x8038D3D0: jal         0x80130A90
    // 0x8038D3D4: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    get_message_address_by_id(rdram, ctx);
        goto after_16;
    // 0x8038D3D4: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    after_16:
    // 0x8038D3D8: sw          $v0, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = ctx->r2;
    // 0x8038D3DC: jal         0x80130A90
    // 0x8038D3E0: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    get_message_address_by_id(rdram, ctx);
        goto after_17;
    // 0x8038D3E0: addiu       $a0, $zero, 0xD5
    ctx->r4 = ADD32(0, 0XD5);
    after_17:
    // 0x8038D3E4: sw          $v0, 0x40($s0)
    MEM_W(0X40, ctx->r16) = ctx->r2;
    // 0x8038D3E8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038D3EC: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8038D3F0: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x8038D3F4: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x8038D3F8: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x8038D3FC: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x8038D400: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x8038D404: addu        $a0, $a0, $t9
    ctx->r4 = ADD32(ctx->r4, ctx->r25);
    // 0x8038D408: jal         0x80130A90
    // 0x8038D40C: lh          $a0, 0x58E0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X58E0);
    get_message_address_by_id(rdram, ctx);
        goto after_18;
    // 0x8038D40C: lh          $a0, 0x58E0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X58E0);
    after_18:
    // 0x8038D410: sw          $v0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r2;
    // 0x8038D414: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038D418: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8038D41C: lui         $s0, 0x803B
    ctx->r16 = S32(0X803B << 16);
    // 0x8038D420: addiu       $s0, $s0, 0x58E0
    ctx->r16 = ADD32(ctx->r16, 0X58E0);
    // 0x8038D424: lhu         $t1, 0x9C($t0)
    ctx->r9 = MEM_HU(ctx->r8, 0X9C);
    // 0x8038D428: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x8038D42C: subu        $t2, $t2, $t1
    ctx->r10 = SUB32(ctx->r10, ctx->r9);
    // 0x8038D430: sll         $t2, $t2, 1
    ctx->r10 = S32(ctx->r10 << 1);
    // 0x8038D434: addu        $t3, $s0, $t2
    ctx->r11 = ADD32(ctx->r16, ctx->r10);
    // 0x8038D438: jal         0x80130A90
    // 0x8038D43C: lh          $a0, 0x8($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X8);
    get_message_address_by_id(rdram, ctx);
        goto after_19;
    // 0x8038D43C: lh          $a0, 0x8($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X8);
    after_19:
    // 0x8038D440: sw          $v0, 0x2C($s1)
    MEM_W(0X2C, ctx->r17) = ctx->r2;
    // 0x8038D444: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x8038D448: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x8038D44C: lhu         $t5, 0x9C($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0X9C);
    // 0x8038D450: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x8038D454: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x8038D458: sll         $t6, $t6, 1
    ctx->r14 = S32(ctx->r14 << 1);
    // 0x8038D45C: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x8038D460: jal         0x80130A90
    // 0x8038D464: lh          $a0, 0xA($t7)
    ctx->r4 = MEM_H(ctx->r15, 0XA);
    get_message_address_by_id(rdram, ctx);
        goto after_20;
    // 0x8038D464: lh          $a0, 0xA($t7)
    ctx->r4 = MEM_H(ctx->r15, 0XA);
    after_20:
    // 0x8038D468: sw          $v0, 0x10($s1)
    MEM_W(0X10, ctx->r17) = ctx->r2;
    // 0x8038D46C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8038D470: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x8038D474: lhu         $t9, 0x9C($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X9C);
    // 0x8038D478: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x8038D47C: subu        $t0, $t0, $t9
    ctx->r8 = SUB32(ctx->r8, ctx->r25);
    // 0x8038D480: sll         $t0, $t0, 1
    ctx->r8 = S32(ctx->r8 << 1);
    // 0x8038D484: addu        $t1, $s0, $t0
    ctx->r9 = ADD32(ctx->r16, ctx->r8);
    // 0x8038D488: jal         0x80130A90
    // 0x8038D48C: lh          $a0, 0xC($t1)
    ctx->r4 = MEM_H(ctx->r9, 0XC);
    get_message_address_by_id(rdram, ctx);
        goto after_21;
    // 0x8038D48C: lh          $a0, 0xC($t1)
    ctx->r4 = MEM_H(ctx->r9, 0XC);
    after_21:
    // 0x8038D490: sw          $v0, 0x1C($s1)
    MEM_W(0X1C, ctx->r17) = ctx->r2;
    // 0x8038D494: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038D498: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x8038D49C: lhu         $t3, 0x9C($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X9C);
    // 0x8038D4A0: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x8038D4A4: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x8038D4A8: sll         $t4, $t4, 1
    ctx->r12 = S32(ctx->r12 << 1);
    // 0x8038D4AC: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    // 0x8038D4B0: jal         0x80130A90
    // 0x8038D4B4: lh          $a0, 0x2($t5)
    ctx->r4 = MEM_H(ctx->r13, 0X2);
    get_message_address_by_id(rdram, ctx);
        goto after_22;
    // 0x8038D4B4: lh          $a0, 0x2($t5)
    ctx->r4 = MEM_H(ctx->r13, 0X2);
    after_22:
    // 0x8038D4B8: sw          $v0, 0x30($s1)
    MEM_W(0X30, ctx->r17) = ctx->r2;
    // 0x8038D4BC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038D4C0: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x8038D4C4: lhu         $t7, 0x9C($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X9C);
    // 0x8038D4C8: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x8038D4CC: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x8038D4D0: sll         $t8, $t8, 1
    ctx->r24 = S32(ctx->r24 << 1);
    // 0x8038D4D4: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x8038D4D8: jal         0x80130A90
    // 0x8038D4DC: lh          $a0, 0x4($t9)
    ctx->r4 = MEM_H(ctx->r25, 0X4);
    get_message_address_by_id(rdram, ctx);
        goto after_23;
    // 0x8038D4DC: lh          $a0, 0x4($t9)
    ctx->r4 = MEM_H(ctx->r25, 0X4);
    after_23:
    // 0x8038D4E0: sw          $v0, 0x8($s1)
    MEM_W(0X8, ctx->r17) = ctx->r2;
    // 0x8038D4E4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038D4E8: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8038D4EC: lhu         $t1, 0x9C($t0)
    ctx->r9 = MEM_HU(ctx->r8, 0X9C);
    // 0x8038D4F0: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x8038D4F4: subu        $t2, $t2, $t1
    ctx->r10 = SUB32(ctx->r10, ctx->r9);
    // 0x8038D4F8: sll         $t2, $t2, 1
    ctx->r10 = S32(ctx->r10 << 1);
    // 0x8038D4FC: addu        $t3, $s0, $t2
    ctx->r11 = ADD32(ctx->r16, ctx->r10);
    // 0x8038D500: jal         0x80130A90
    // 0x8038D504: lh          $a0, 0x6($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X6);
    get_message_address_by_id(rdram, ctx);
        goto after_24;
    // 0x8038D504: lh          $a0, 0x6($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X6);
    after_24:
    // 0x8038D508: sw          $v0, 0xC($s1)
    MEM_W(0XC, ctx->r17) = ctx->r2;
    // 0x8038D50C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D510: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
    // 0x8038D514: lh          $v1, 0xD6($a0)
    ctx->r3 = MEM_H(ctx->r4, 0XD6);
    // 0x8038D518: beq         $v1, $zero, L_8038D540
    if (ctx->r3 == 0) {
        // 0x8038D51C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_8038D540;
    }
    // 0x8038D51C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038D520: beq         $v1, $at, L_8038D558
    if (ctx->r3 == ctx->r1) {
        // 0x8038D524: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8038D558;
    }
    // 0x8038D524: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038D528: beq         $v1, $at, L_8038D570
    if (ctx->r3 == ctx->r1) {
        // 0x8038D52C: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8038D570;
    }
    // 0x8038D52C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8038D530: beq         $v1, $at, L_8038D588
    if (ctx->r3 == ctx->r1) {
        // 0x8038D534: nop
    
            goto L_8038D588;
    }
    // 0x8038D534: nop

    // 0x8038D538: b           L_8038D5A0
    // 0x8038D53C: lhu         $t4, 0x7C($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X7C);
        goto L_8038D5A0;
    // 0x8038D53C: lhu         $t4, 0x7C($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X7C);
L_8038D540:
    // 0x8038D540: jal         0x80130A90
    // 0x8038D544: addiu       $a0, $zero, 0x46
    ctx->r4 = ADD32(0, 0X46);
    get_message_address_by_id(rdram, ctx);
        goto after_25;
    // 0x8038D544: addiu       $a0, $zero, 0x46
    ctx->r4 = ADD32(0, 0X46);
    after_25:
    // 0x8038D548: sw          $v0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r2;
    // 0x8038D54C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D550: b           L_8038D59C
    // 0x8038D554: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D59C;
    // 0x8038D554: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D558:
    // 0x8038D558: jal         0x80130A90
    // 0x8038D55C: addiu       $a0, $zero, 0x49
    ctx->r4 = ADD32(0, 0X49);
    get_message_address_by_id(rdram, ctx);
        goto after_26;
    // 0x8038D55C: addiu       $a0, $zero, 0x49
    ctx->r4 = ADD32(0, 0X49);
    after_26:
    // 0x8038D560: sw          $v0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r2;
    // 0x8038D564: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D568: b           L_8038D59C
    // 0x8038D56C: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D59C;
    // 0x8038D56C: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D570:
    // 0x8038D570: jal         0x80130A90
    // 0x8038D574: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    get_message_address_by_id(rdram, ctx);
        goto after_27;
    // 0x8038D574: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    after_27:
    // 0x8038D578: sw          $v0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r2;
    // 0x8038D57C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D580: b           L_8038D59C
    // 0x8038D584: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D59C;
    // 0x8038D584: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D588:
    // 0x8038D588: jal         0x80130A90
    // 0x8038D58C: addiu       $a0, $zero, 0x47
    ctx->r4 = ADD32(0, 0X47);
    get_message_address_by_id(rdram, ctx);
        goto after_28;
    // 0x8038D58C: addiu       $a0, $zero, 0x47
    ctx->r4 = ADD32(0, 0X47);
    after_28:
    // 0x8038D590: sw          $v0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r2;
    // 0x8038D594: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D598: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D59C:
    // 0x8038D59C: lhu         $t4, 0x7C($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X7C);
L_8038D5A0:
    // 0x8038D5A0: addiu       $t5, $t4, -0x14
    ctx->r13 = ADD32(ctx->r12, -0X14);
    // 0x8038D5A4: sltiu       $at, $t5, 0x51
    ctx->r1 = ctx->r13 < 0X51 ? 1 : 0;
    // 0x8038D5A8: beq         $at, $zero, L_8038D674
    if (ctx->r1 == 0) {
        // 0x8038D5AC: sll         $t5, $t5, 2
        ctx->r13 = S32(ctx->r13 << 2);
            goto L_8038D674;
    }
    // 0x8038D5AC: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x8038D5B0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038D5B4: addu        $at, $at, $t5
    gpr jr_addend_8038D5BC = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x8038D5B8: lw          $t5, -0x20($at)
    ctx->r13 = ADD32(ctx->r1, -0X20);
    // 0x8038D5BC: jr          $t5
    // 0x8038D5C0: nop

    switch (jr_addend_8038D5BC >> 2) {
        case 0: goto L_8038D5C4; break;
        case 1: goto L_8038D674; break;
        case 2: goto L_8038D674; break;
        case 3: goto L_8038D674; break;
        case 4: goto L_8038D674; break;
        case 5: goto L_8038D674; break;
        case 6: goto L_8038D674; break;
        case 7: goto L_8038D674; break;
        case 8: goto L_8038D674; break;
        case 9: goto L_8038D674; break;
        case 10: goto L_8038D674; break;
        case 11: goto L_8038D674; break;
        case 12: goto L_8038D674; break;
        case 13: goto L_8038D674; break;
        case 14: goto L_8038D674; break;
        case 15: goto L_8038D674; break;
        case 16: goto L_8038D674; break;
        case 17: goto L_8038D674; break;
        case 18: goto L_8038D674; break;
        case 19: goto L_8038D674; break;
        case 20: goto L_8038D5E8; break;
        case 21: goto L_8038D674; break;
        case 22: goto L_8038D674; break;
        case 23: goto L_8038D674; break;
        case 24: goto L_8038D674; break;
        case 25: goto L_8038D674; break;
        case 26: goto L_8038D674; break;
        case 27: goto L_8038D674; break;
        case 28: goto L_8038D674; break;
        case 29: goto L_8038D674; break;
        case 30: goto L_8038D674; break;
        case 31: goto L_8038D674; break;
        case 32: goto L_8038D674; break;
        case 33: goto L_8038D674; break;
        case 34: goto L_8038D674; break;
        case 35: goto L_8038D674; break;
        case 36: goto L_8038D674; break;
        case 37: goto L_8038D674; break;
        case 38: goto L_8038D674; break;
        case 39: goto L_8038D674; break;
        case 40: goto L_8038D60C; break;
        case 41: goto L_8038D674; break;
        case 42: goto L_8038D674; break;
        case 43: goto L_8038D674; break;
        case 44: goto L_8038D674; break;
        case 45: goto L_8038D674; break;
        case 46: goto L_8038D674; break;
        case 47: goto L_8038D674; break;
        case 48: goto L_8038D674; break;
        case 49: goto L_8038D674; break;
        case 50: goto L_8038D674; break;
        case 51: goto L_8038D674; break;
        case 52: goto L_8038D674; break;
        case 53: goto L_8038D674; break;
        case 54: goto L_8038D674; break;
        case 55: goto L_8038D674; break;
        case 56: goto L_8038D674; break;
        case 57: goto L_8038D674; break;
        case 58: goto L_8038D674; break;
        case 59: goto L_8038D674; break;
        case 60: goto L_8038D630; break;
        case 61: goto L_8038D674; break;
        case 62: goto L_8038D674; break;
        case 63: goto L_8038D674; break;
        case 64: goto L_8038D674; break;
        case 65: goto L_8038D674; break;
        case 66: goto L_8038D674; break;
        case 67: goto L_8038D674; break;
        case 68: goto L_8038D674; break;
        case 69: goto L_8038D674; break;
        case 70: goto L_8038D674; break;
        case 71: goto L_8038D674; break;
        case 72: goto L_8038D674; break;
        case 73: goto L_8038D674; break;
        case 74: goto L_8038D674; break;
        case 75: goto L_8038D674; break;
        case 76: goto L_8038D674; break;
        case 77: goto L_8038D674; break;
        case 78: goto L_8038D674; break;
        case 79: goto L_8038D674; break;
        case 80: goto L_8038D654; break;
        default: switch_error(__func__, 0x8038D5BC, 0x803BFFE0);
    }
    // 0x8038D5C0: nop

L_8038D5C4:
    // 0x8038D5C4: jal         0x80130A90
    // 0x8038D5C8: addiu       $a0, $zero, 0x34
    ctx->r4 = ADD32(0, 0X34);
    get_message_address_by_id(rdram, ctx);
        goto after_29;
    // 0x8038D5C8: addiu       $a0, $zero, 0x34
    ctx->r4 = ADD32(0, 0X34);
    after_29:
    // 0x8038D5CC: sw          $v0, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r2;
    // 0x8038D5D0: jal         0x80130A90
    // 0x8038D5D4: addiu       $a0, $zero, 0x33
    ctx->r4 = ADD32(0, 0X33);
    get_message_address_by_id(rdram, ctx);
        goto after_30;
    // 0x8038D5D4: addiu       $a0, $zero, 0x33
    ctx->r4 = ADD32(0, 0X33);
    after_30:
    // 0x8038D5D8: sw          $v0, 0x28($s1)
    MEM_W(0X28, ctx->r17) = ctx->r2;
    // 0x8038D5DC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D5E0: b           L_8038D674
    // 0x8038D5E4: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D674;
    // 0x8038D5E4: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D5E8:
    // 0x8038D5E8: jal         0x80130A90
    // 0x8038D5EC: addiu       $a0, $zero, 0x37
    ctx->r4 = ADD32(0, 0X37);
    get_message_address_by_id(rdram, ctx);
        goto after_31;
    // 0x8038D5EC: addiu       $a0, $zero, 0x37
    ctx->r4 = ADD32(0, 0X37);
    after_31:
    // 0x8038D5F0: sw          $v0, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r2;
    // 0x8038D5F4: jal         0x80130A90
    // 0x8038D5F8: addiu       $a0, $zero, 0x36
    ctx->r4 = ADD32(0, 0X36);
    get_message_address_by_id(rdram, ctx);
        goto after_32;
    // 0x8038D5F8: addiu       $a0, $zero, 0x36
    ctx->r4 = ADD32(0, 0X36);
    after_32:
    // 0x8038D5FC: sw          $v0, 0x28($s1)
    MEM_W(0X28, ctx->r17) = ctx->r2;
    // 0x8038D600: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D604: b           L_8038D674
    // 0x8038D608: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D674;
    // 0x8038D608: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D60C:
    // 0x8038D60C: jal         0x80130A90
    // 0x8038D610: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    get_message_address_by_id(rdram, ctx);
        goto after_33;
    // 0x8038D610: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    after_33:
    // 0x8038D614: sw          $v0, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r2;
    // 0x8038D618: jal         0x80130A90
    // 0x8038D61C: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    get_message_address_by_id(rdram, ctx);
        goto after_34;
    // 0x8038D61C: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    after_34:
    // 0x8038D620: sw          $v0, 0x28($s1)
    MEM_W(0X28, ctx->r17) = ctx->r2;
    // 0x8038D624: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D628: b           L_8038D674
    // 0x8038D62C: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D674;
    // 0x8038D62C: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D630:
    // 0x8038D630: jal         0x80130A90
    // 0x8038D634: addiu       $a0, $zero, 0x3B
    ctx->r4 = ADD32(0, 0X3B);
    get_message_address_by_id(rdram, ctx);
        goto after_35;
    // 0x8038D634: addiu       $a0, $zero, 0x3B
    ctx->r4 = ADD32(0, 0X3B);
    after_35:
    // 0x8038D638: sw          $v0, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r2;
    // 0x8038D63C: jal         0x80130A90
    // 0x8038D640: addiu       $a0, $zero, 0x3A
    ctx->r4 = ADD32(0, 0X3A);
    get_message_address_by_id(rdram, ctx);
        goto after_36;
    // 0x8038D640: addiu       $a0, $zero, 0x3A
    ctx->r4 = ADD32(0, 0X3A);
    after_36:
    // 0x8038D644: sw          $v0, 0x28($s1)
    MEM_W(0X28, ctx->r17) = ctx->r2;
    // 0x8038D648: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D64C: b           L_8038D674
    // 0x8038D650: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D674;
    // 0x8038D650: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D654:
    // 0x8038D654: jal         0x80130A90
    // 0x8038D658: addiu       $a0, $zero, 0x3E
    ctx->r4 = ADD32(0, 0X3E);
    get_message_address_by_id(rdram, ctx);
        goto after_37;
    // 0x8038D658: addiu       $a0, $zero, 0x3E
    ctx->r4 = ADD32(0, 0X3E);
    after_37:
    // 0x8038D65C: sw          $v0, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r2;
    // 0x8038D660: jal         0x80130A90
    // 0x8038D664: addiu       $a0, $zero, 0x3D
    ctx->r4 = ADD32(0, 0X3D);
    get_message_address_by_id(rdram, ctx);
        goto after_38;
    // 0x8038D664: addiu       $a0, $zero, 0x3D
    ctx->r4 = ADD32(0, 0X3D);
    after_38:
    // 0x8038D668: sw          $v0, 0x28($s1)
    MEM_W(0X28, ctx->r17) = ctx->r2;
    // 0x8038D66C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D670: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D674:
    // 0x8038D674: lh          $v0, 0xAE($a0)
    ctx->r2 = MEM_H(ctx->r4, 0XAE);
    // 0x8038D678: slti        $at, $v0, 0x14
    ctx->r1 = SIGNED(ctx->r2) < 0X14 ? 1 : 0;
    // 0x8038D67C: beql        $at, $zero, L_8038D698
    if (ctx->r1 == 0) {
        // 0x8038D680: slti        $at, $v0, 0x32
        ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
            goto L_8038D698;
    }
    goto skip_2;
    // 0x8038D680: slti        $at, $v0, 0x32
    ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
    skip_2:
    // 0x8038D684: jal         0x80130A90
    // 0x8038D688: addiu       $a0, $zero, 0x32
    ctx->r4 = ADD32(0, 0X32);
    get_message_address_by_id(rdram, ctx);
        goto after_39;
    // 0x8038D688: addiu       $a0, $zero, 0x32
    ctx->r4 = ADD32(0, 0X32);
    after_39:
    // 0x8038D68C: b           L_8038D6F4
    // 0x8038D690: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
        goto L_8038D6F4;
    // 0x8038D690: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
    // 0x8038D694: slti        $at, $v0, 0x32
    ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
L_8038D698:
    // 0x8038D698: beql        $at, $zero, L_8038D6B4
    if (ctx->r1 == 0) {
        // 0x8038D69C: slti        $at, $v0, 0xA0
        ctx->r1 = SIGNED(ctx->r2) < 0XA0 ? 1 : 0;
            goto L_8038D6B4;
    }
    goto skip_3;
    // 0x8038D69C: slti        $at, $v0, 0xA0
    ctx->r1 = SIGNED(ctx->r2) < 0XA0 ? 1 : 0;
    skip_3:
    // 0x8038D6A0: jal         0x80130A90
    // 0x8038D6A4: addiu       $a0, $zero, 0x35
    ctx->r4 = ADD32(0, 0X35);
    get_message_address_by_id(rdram, ctx);
        goto after_40;
    // 0x8038D6A4: addiu       $a0, $zero, 0x35
    ctx->r4 = ADD32(0, 0X35);
    after_40:
    // 0x8038D6A8: b           L_8038D6F4
    // 0x8038D6AC: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
        goto L_8038D6F4;
    // 0x8038D6AC: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
    // 0x8038D6B0: slti        $at, $v0, 0xA0
    ctx->r1 = SIGNED(ctx->r2) < 0XA0 ? 1 : 0;
L_8038D6B4:
    // 0x8038D6B4: beql        $at, $zero, L_8038D6D0
    if (ctx->r1 == 0) {
        // 0x8038D6B8: slti        $at, $v0, 0x1F4
        ctx->r1 = SIGNED(ctx->r2) < 0X1F4 ? 1 : 0;
            goto L_8038D6D0;
    }
    goto skip_4;
    // 0x8038D6B8: slti        $at, $v0, 0x1F4
    ctx->r1 = SIGNED(ctx->r2) < 0X1F4 ? 1 : 0;
    skip_4:
    // 0x8038D6BC: jal         0x80130A90
    // 0x8038D6C0: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    get_message_address_by_id(rdram, ctx);
        goto after_41;
    // 0x8038D6C0: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    after_41:
    // 0x8038D6C4: b           L_8038D6F4
    // 0x8038D6C8: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
        goto L_8038D6F4;
    // 0x8038D6C8: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
    // 0x8038D6CC: slti        $at, $v0, 0x1F4
    ctx->r1 = SIGNED(ctx->r2) < 0X1F4 ? 1 : 0;
L_8038D6D0:
    // 0x8038D6D0: beq         $at, $zero, L_8038D6E8
    if (ctx->r1 == 0) {
        // 0x8038D6D4: nop
    
            goto L_8038D6E8;
    }
    // 0x8038D6D4: nop

    // 0x8038D6D8: jal         0x80130A90
    // 0x8038D6DC: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    get_message_address_by_id(rdram, ctx);
        goto after_42;
    // 0x8038D6DC: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    after_42:
    // 0x8038D6E0: b           L_8038D6F4
    // 0x8038D6E4: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
        goto L_8038D6F4;
    // 0x8038D6E4: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
L_8038D6E8:
    // 0x8038D6E8: jal         0x80130A90
    // 0x8038D6EC: addiu       $a0, $zero, 0x3C
    ctx->r4 = ADD32(0, 0X3C);
    get_message_address_by_id(rdram, ctx);
        goto after_43;
    // 0x8038D6EC: addiu       $a0, $zero, 0x3C
    ctx->r4 = ADD32(0, 0X3C);
    after_43:
    // 0x8038D6F0: sw          $v0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r2;
L_8038D6F4:
    // 0x8038D6F4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D6F8: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
    // 0x8038D6FC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038D700: lbu         $v1, 0x8B($a0)
    ctx->r3 = MEM_BU(ctx->r4, 0X8B);
    // 0x8038D704: beq         $v1, $at, L_8038D72C
    if (ctx->r3 == ctx->r1) {
        // 0x8038D708: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_8038D72C;
    }
    // 0x8038D708: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8038D70C: beq         $v1, $at, L_8038D744
    if (ctx->r3 == ctx->r1) {
        // 0x8038D710: addiu       $at, $zero, 0x10
        ctx->r1 = ADD32(0, 0X10);
            goto L_8038D744;
    }
    // 0x8038D710: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x8038D714: beq         $v1, $at, L_8038D75C
    if (ctx->r3 == ctx->r1) {
        // 0x8038D718: addiu       $at, $zero, 0xFF
        ctx->r1 = ADD32(0, 0XFF);
            goto L_8038D75C;
    }
    // 0x8038D718: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x8038D71C: beq         $v1, $at, L_8038D774
    if (ctx->r3 == ctx->r1) {
        // 0x8038D720: nop
    
            goto L_8038D774;
    }
    // 0x8038D720: nop

    // 0x8038D724: b           L_8038D78C
    // 0x8038D728: lhu         $v0, 0xB2($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0XB2);
        goto L_8038D78C;
    // 0x8038D728: lhu         $v0, 0xB2($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0XB2);
L_8038D72C:
    // 0x8038D72C: jal         0x80130A90
    // 0x8038D730: addiu       $a0, $zero, 0x37
    ctx->r4 = ADD32(0, 0X37);
    get_message_address_by_id(rdram, ctx);
        goto after_44;
    // 0x8038D730: addiu       $a0, $zero, 0x37
    ctx->r4 = ADD32(0, 0X37);
    after_44:
    // 0x8038D734: sw          $v0, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r2;
    // 0x8038D738: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D73C: b           L_8038D788
    // 0x8038D740: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D788;
    // 0x8038D740: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D744:
    // 0x8038D744: jal         0x80130A90
    // 0x8038D748: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    get_message_address_by_id(rdram, ctx);
        goto after_45;
    // 0x8038D748: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    after_45:
    // 0x8038D74C: sw          $v0, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r2;
    // 0x8038D750: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D754: b           L_8038D788
    // 0x8038D758: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D788;
    // 0x8038D758: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D75C:
    // 0x8038D75C: jal         0x80130A90
    // 0x8038D760: addiu       $a0, $zero, 0x3F
    ctx->r4 = ADD32(0, 0X3F);
    get_message_address_by_id(rdram, ctx);
        goto after_46;
    // 0x8038D760: addiu       $a0, $zero, 0x3F
    ctx->r4 = ADD32(0, 0X3F);
    after_46:
    // 0x8038D764: sw          $v0, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r2;
    // 0x8038D768: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D76C: b           L_8038D788
    // 0x8038D770: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
        goto L_8038D788;
    // 0x8038D770: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D774:
    // 0x8038D774: jal         0x80130A90
    // 0x8038D778: addiu       $a0, $zero, 0x40
    ctx->r4 = ADD32(0, 0X40);
    get_message_address_by_id(rdram, ctx);
        goto after_47;
    // 0x8038D778: addiu       $a0, $zero, 0x40
    ctx->r4 = ADD32(0, 0X40);
    after_47:
    // 0x8038D77C: sw          $v0, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r2;
    // 0x8038D780: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038D784: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
L_8038D788:
    // 0x8038D788: lhu         $v0, 0xB2($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0XB2);
L_8038D78C:
    // 0x8038D78C: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x8038D790: beql        $at, $zero, L_8038D7AC
    if (ctx->r1 == 0) {
        // 0x8038D794: slti        $at, $v0, 0x13
        ctx->r1 = SIGNED(ctx->r2) < 0X13 ? 1 : 0;
            goto L_8038D7AC;
    }
    goto skip_5;
    // 0x8038D794: slti        $at, $v0, 0x13
    ctx->r1 = SIGNED(ctx->r2) < 0X13 ? 1 : 0;
    skip_5:
    // 0x8038D798: jal         0x80130A90
    // 0x8038D79C: addiu       $a0, $zero, 0x41
    ctx->r4 = ADD32(0, 0X41);
    get_message_address_by_id(rdram, ctx);
        goto after_48;
    // 0x8038D79C: addiu       $a0, $zero, 0x41
    ctx->r4 = ADD32(0, 0X41);
    after_48:
    // 0x8038D7A0: b           L_8038D808
    // 0x8038D7A4: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
        goto L_8038D808;
    // 0x8038D7A4: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
    // 0x8038D7A8: slti        $at, $v0, 0x13
    ctx->r1 = SIGNED(ctx->r2) < 0X13 ? 1 : 0;
L_8038D7AC:
    // 0x8038D7AC: beql        $at, $zero, L_8038D7C8
    if (ctx->r1 == 0) {
        // 0x8038D7B0: slti        $at, $v0, 0x28
        ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
            goto L_8038D7C8;
    }
    goto skip_6;
    // 0x8038D7B0: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    skip_6:
    // 0x8038D7B4: jal         0x80130A90
    // 0x8038D7B8: addiu       $a0, $zero, 0x42
    ctx->r4 = ADD32(0, 0X42);
    get_message_address_by_id(rdram, ctx);
        goto after_49;
    // 0x8038D7B8: addiu       $a0, $zero, 0x42
    ctx->r4 = ADD32(0, 0X42);
    after_49:
    // 0x8038D7BC: b           L_8038D808
    // 0x8038D7C0: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
        goto L_8038D808;
    // 0x8038D7C0: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
    // 0x8038D7C4: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
L_8038D7C8:
    // 0x8038D7C8: beql        $at, $zero, L_8038D7E4
    if (ctx->r1 == 0) {
        // 0x8038D7CC: slti        $at, $v0, 0x46
        ctx->r1 = SIGNED(ctx->r2) < 0X46 ? 1 : 0;
            goto L_8038D7E4;
    }
    goto skip_7;
    // 0x8038D7CC: slti        $at, $v0, 0x46
    ctx->r1 = SIGNED(ctx->r2) < 0X46 ? 1 : 0;
    skip_7:
    // 0x8038D7D0: jal         0x80130A90
    // 0x8038D7D4: addiu       $a0, $zero, 0x43
    ctx->r4 = ADD32(0, 0X43);
    get_message_address_by_id(rdram, ctx);
        goto after_50;
    // 0x8038D7D4: addiu       $a0, $zero, 0x43
    ctx->r4 = ADD32(0, 0X43);
    after_50:
    // 0x8038D7D8: b           L_8038D808
    // 0x8038D7DC: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
        goto L_8038D808;
    // 0x8038D7DC: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
    // 0x8038D7E0: slti        $at, $v0, 0x46
    ctx->r1 = SIGNED(ctx->r2) < 0X46 ? 1 : 0;
L_8038D7E4:
    // 0x8038D7E4: beq         $at, $zero, L_8038D7FC
    if (ctx->r1 == 0) {
        // 0x8038D7E8: nop
    
            goto L_8038D7FC;
    }
    // 0x8038D7E8: nop

    // 0x8038D7EC: jal         0x80130A90
    // 0x8038D7F0: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
    get_message_address_by_id(rdram, ctx);
        goto after_51;
    // 0x8038D7F0: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
    after_51:
    // 0x8038D7F4: b           L_8038D808
    // 0x8038D7F8: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
        goto L_8038D808;
    // 0x8038D7F8: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
L_8038D7FC:
    // 0x8038D7FC: jal         0x80130A90
    // 0x8038D800: addiu       $a0, $zero, 0x45
    ctx->r4 = ADD32(0, 0X45);
    get_message_address_by_id(rdram, ctx);
        goto after_52;
    // 0x8038D800: addiu       $a0, $zero, 0x45
    ctx->r4 = ADD32(0, 0X45);
    after_52:
    // 0x8038D804: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
L_8038D808:
    // 0x8038D808: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038D80C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038D810: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8038D814: jal         0x8012C248
    // 0x8038D818: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_53;
    // 0x8038D818: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_53:
    // 0x8038D81C: addiu       $s0, $sp, 0x3C
    ctx->r16 = ADD32(ctx->r29, 0X3C);
    // 0x8038D820: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8038D824: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x8038D828: addiu       $a2, $a2, -0x24
    ctx->r6 = ADD32(ctx->r6, -0X24);
    // 0x8038D82C: addiu       $a1, $a1, -0x28
    ctx->r5 = ADD32(ctx->r5, -0X28);
    // 0x8038D830: jal         0x801395F4
    // 0x8038D834: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    sprintf_recomp(rdram, ctx);
        goto after_54;
    // 0x8038D834: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_54:
    // 0x8038D838: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8038D83C: jal         0x801308B4
    // 0x8038D840: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    prepare_text(rdram, ctx);
        goto after_55;
    // 0x8038D840: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    after_55:
    // 0x8038D844: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8038D848: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038D84C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038D850: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8038D854: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038D858: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8038D85C: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x8038D860: addiu       $a2, $zero, 0x19
    ctx->r6 = ADD32(0, 0X19);
    // 0x8038D864: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038D868: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038D86C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8038D870: jal         0x8012D374
    // 0x8038D874: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_56;
    // 0x8038D874: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_56:
    // 0x8038D878: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8038D87C: sll         $t6, $s0, 2
    ctx->r14 = S32(ctx->r16 << 2);
L_8038D880:
    // 0x8038D880: addu        $t7, $s1, $t6
    ctx->r15 = ADD32(ctx->r17, ctx->r14);
    // 0x8038D884: jal         0x8012C3D8
    // 0x8038D888: lw          $a0, 0x0($t7)
    ctx->r4 = MEM_W(ctx->r15, 0X0);
    get_message_width(rdram, ctx);
        goto after_57;
    // 0x8038D888: lw          $a0, 0x0($t7)
    ctx->r4 = MEM_W(ctx->r15, 0X0);
    after_57:
    // 0x8038D88C: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x8038D890: lh          $t8, 0x3FD0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD0);
    // 0x8038D894: sll         $t1, $s0, 1
    ctx->r9 = S32(ctx->r16 << 1);
    // 0x8038D898: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038D89C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038D8A0: subu        $t9, $t8, $v0
    ctx->r25 = SUB32(ctx->r24, ctx->r2);
    // 0x8038D8A4: sll         $t2, $s0, 16
    ctx->r10 = S32(ctx->r16 << 16);
    // 0x8038D8A8: addiu       $t0, $t9, -0xE
    ctx->r8 = ADD32(ctx->r25, -0XE);
    // 0x8038D8AC: addu        $at, $at, $t1
    ctx->r1 = ADD32(ctx->r1, ctx->r9);
    // 0x8038D8B0: sra         $s0, $t2, 16
    ctx->r16 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8038D8B4: sh          $t0, 0x6548($at)
    MEM_H(0X6548, ctx->r1) = ctx->r8;
    // 0x8038D8B8: slti        $at, $s0, 0xD
    ctx->r1 = SIGNED(ctx->r16) < 0XD ? 1 : 0;
    // 0x8038D8BC: bnel        $at, $zero, L_8038D880
    if (ctx->r1 != 0) {
        // 0x8038D8C0: sll         $t6, $s0, 2
        ctx->r14 = S32(ctx->r16 << 2);
            goto L_8038D880;
    }
    goto skip_8;
    // 0x8038D8C0: sll         $t6, $s0, 2
    ctx->r14 = S32(ctx->r16 << 2);
    skip_8:
    // 0x8038D8C4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038D8C8: addiu       $v0, $v0, 0x6478
    ctx->r2 = ADD32(ctx->r2, 0X6478);
    // 0x8038D8CC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_8038D8D0:
    // 0x8038D8D0: sll         $t4, $s0, 2
    ctx->r12 = S32(ctx->r16 << 2);
    // 0x8038D8D4: addu        $v1, $v0, $t4
    ctx->r3 = ADD32(ctx->r2, ctx->r12);
    // 0x8038D8D8: sll         $t5, $s0, 1
    ctx->r13 = S32(ctx->r16 << 1);
    // 0x8038D8DC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038D8E0: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x8038D8E4: sw          $zero, 0x0($v1)
    MEM_W(0X0, ctx->r3) = 0;
    // 0x8038D8E8: sw          $zero, 0x34($v1)
    MEM_W(0X34, ctx->r3) = 0;
    // 0x8038D8EC: addu        $t6, $v0, $t5
    ctx->r14 = ADD32(ctx->r2, ctx->r13);
    // 0x8038D8F0: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038D8F4: sh          $zero, 0x68($t6)
    MEM_H(0X68, ctx->r14) = 0;
    // 0x8038D8F8: slti        $at, $s0, 0xD
    ctx->r1 = SIGNED(ctx->r16) < 0XD ? 1 : 0;
    // 0x8038D8FC: sh          $zero, 0x82($v0)
    MEM_H(0X82, ctx->r2) = 0;
    // 0x8038D900: sh          $zero, 0x84($v0)
    MEM_H(0X84, ctx->r2) = 0;
    // 0x8038D904: bne         $at, $zero, L_8038D8D0
    if (ctx->r1 != 0) {
        // 0x8038D908: sh          $zero, 0x86($v0)
        MEM_H(0X86, ctx->r2) = 0;
            goto L_8038D8D0;
    }
    // 0x8038D908: sh          $zero, 0x86($v0)
    MEM_H(0X86, ctx->r2) = 0;
    // 0x8038D90C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8038D910: lw          $s0, 0x24($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X24);
    // 0x8038D914: lw          $s1, 0x28($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X28);
    // 0x8038D918: jr          $ra
    // 0x8038D91C: addiu       $sp, $sp, 0x100
    ctx->r29 = ADD32(ctx->r29, 0X100);
    return;
    // 0x8038D91C: addiu       $sp, $sp, 0x100
    ctx->r29 = ADD32(ctx->r29, 0X100);
;}
RECOMP_FUNC void update_terminal_scene_lighting(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038D920: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8038D924: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8038D928: jal         0x8032F950
    // 0x8038D92C: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    func_8032F950_741000(rdram, ctx);
        goto after_0;
    // 0x8038D92C: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    after_0:
    // 0x8038D930: jal         0x802C87E0
    // 0x8038D934: nop

    func_802C87E0_6D9E90(rdram, ctx);
        goto after_1;
    // 0x8038D934: nop

    after_1:
    // 0x8038D938: jal         0x802C8878
    // 0x8038D93C: nop

    func_802C8878_6D9F28(rdram, ctx);
        goto after_2;
    // 0x8038D93C: nop

    after_2:
    // 0x8038D940: jal         0x802E072C
    // 0x8038D944: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_802E072C_6F1DDC(rdram, ctx);
        goto after_3;
    // 0x8038D944: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_3:
    // 0x8038D948: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038D94C: lbu         $t6, 0x2AA2($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2AA2);
    // 0x8038D950: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038D954: beql        $t6, $zero, L_8038DA64
    if (ctx->r14 == 0) {
        // 0x8038D958: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_8038DA64;
    }
    goto skip_0;
    // 0x8038D958: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x8038D95C: lh          $t7, 0x5534($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5534);
    // 0x8038D960: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038D964: lbu         $a3, 0x33($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X33);
    // 0x8038D968: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x8038D96C: addu        $v0, $v0, $t8
    ctx->r2 = ADD32(ctx->r2, ctx->r24);
    // 0x8038D970: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038D974: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8038D978: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8038D97C: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x8038D980: addiu       $a0, $a0, 0x40
    ctx->r4 = ADD32(ctx->r4, 0X40);
    // 0x8038D984: addiu       $a2, $a2, 0x40
    ctx->r6 = ADD32(ctx->r6, 0X40);
    // 0x8038D988: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x8038D98C: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x8038D990: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038D994: sra         $a2, $t1, 16
    ctx->r6 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8038D998: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038D99C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8038D9A0: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x8038D9A4: jal         0x802F2B54
    // 0x8038D9A8: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    add_light_at_location(rdram, ctx);
        goto after_4;
    // 0x8038D9A8: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    after_4:
    // 0x8038D9AC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x8038D9B0: lh          $t3, 0x5534($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X5534);
    // 0x8038D9B4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038D9B8: lw          $a3, 0x2C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X2C);
    // 0x8038D9BC: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x8038D9C0: addu        $v0, $v0, $t4
    ctx->r2 = ADD32(ctx->r2, ctx->r12);
    // 0x8038D9C4: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038D9C8: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x8038D9CC: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8038D9D0: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8038D9D4: addiu       $a1, $a1, -0x40
    ctx->r5 = ADD32(ctx->r5, -0X40);
    // 0x8038D9D8: addiu       $a2, $a2, -0x40
    ctx->r6 = ADD32(ctx->r6, -0X40);
    // 0x8038D9DC: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x8038D9E0: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x8038D9E4: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8038D9E8: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038D9EC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038D9F0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8038D9F4: jal         0x802F2B54
    // 0x8038D9F8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    add_light_at_location(rdram, ctx);
        goto after_5;
    // 0x8038D9F8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    after_5:
    // 0x8038D9FC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038DA00: lbu         $t9, 0x2AA2($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2AA2);
    // 0x8038DA04: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038DA08: lui         $t0, 0x803B
    ctx->r8 = S32(0X803B << 16);
    // 0x8038DA0C: bnel        $t9, $at, L_8038DA64
    if (ctx->r25 != ctx->r1) {
        // 0x8038DA10: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_8038DA64;
    }
    goto skip_1;
    // 0x8038DA10: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_1:
    // 0x8038DA14: lbu         $t0, 0x6318($t0)
    ctx->r8 = MEM_BU(ctx->r8, 0X6318);
    // 0x8038DA18: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038DA1C: addiu       $a0, $zero, 0x46
    ctx->r4 = ADD32(0, 0X46);
    // 0x8038DA20: beq         $t0, $at, L_8038DA60
    if (ctx->r8 == ctx->r1) {
        // 0x8038DA24: addiu       $a1, $zero, 0x46
        ctx->r5 = ADD32(0, 0X46);
            goto L_8038DA60;
    }
    // 0x8038DA24: addiu       $a1, $zero, 0x46
    ctx->r5 = ADD32(0, 0X46);
    // 0x8038DA28: addiu       $t1, $zero, 0x1E
    ctx->r9 = ADD32(0, 0X1E);
    // 0x8038DA2C: addiu       $t2, $zero, 0x1E
    ctx->r10 = ADD32(0, 0X1E);
    // 0x8038DA30: addiu       $t3, $zero, 0x1E
    ctx->r11 = ADD32(0, 0X1E);
    // 0x8038DA34: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x8038DA38: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x8038DA3C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x8038DA40: addiu       $a2, $zero, 0x46
    ctx->r6 = ADD32(0, 0X46);
    // 0x8038DA44: jal         0x802F2EEC
    // 0x8038DA48: addiu       $a3, $zero, 0x32
    ctx->r7 = ADD32(0, 0X32);
    func_802F2EEC_70459C(rdram, ctx);
        goto after_6;
    // 0x8038DA48: addiu       $a3, $zero, 0x32
    ctx->r7 = ADD32(0, 0X32);
    after_6:
    // 0x8038DA4C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x8038DA50: lbu         $t4, 0x2AA2($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X2AA2);
    // 0x8038DA54: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038DA58: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8038DA5C: sb          $t5, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = ctx->r13;
L_8038DA60:
    // 0x8038DA60: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8038DA64:
    // 0x8038DA64: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x8038DA68: jr          $ra
    // 0x8038DA6C: nop

    return;
    // 0x8038DA6C: nop

;}
RECOMP_FUNC void render_terminal_background_scene(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038DA70: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8038DA74: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038DA78: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8038DA7C: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8038DA80: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038DA84: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8038DA88: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    // 0x8038DA8C: jal         0x80380490
    // 0x8038DA90: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    switch_to_current_segment(rdram, ctx);
        goto after_0;
    // 0x8038DA90: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x8038DA94: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038DA98: jal         0x802999E0
    // 0x8038DA9C: lw          $a0, 0x4278($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4278);
    setup_world_perspective_6AB090(rdram, ctx);
        goto after_1;
    // 0x8038DA9C: lw          $a0, 0x4278($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4278);
    after_1:
    // 0x8038DAA0: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038DAA4: lw          $a0, 0x4278($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4278);
    // 0x8038DAA8: jal         0x80299AA8
    // 0x8038DAAC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    setup_frame_render_state(rdram, ctx);
        goto after_2;
    // 0x8038DAAC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_2:
    // 0x8038DAB0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038DAB4: lui         $t7, 0x380
    ctx->r15 = S32(0X380 << 16);
    // 0x8038DAB8: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8038DABC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8038DAC0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8038DAC4: addiu       $t8, $t8, 0x2EA8
    ctx->r24 = ADD32(ctx->r24, 0X2EA8);
    // 0x8038DAC8: ori         $t7, $t7, 0x10
    ctx->r15 = ctx->r15 | 0X10;
    // 0x8038DACC: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038DAD0: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8038DAD4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038DAD8: lui         $t1, 0xFF10
    ctx->r9 = S32(0XFF10 << 16);
    // 0x8038DADC: ori         $t1, $t1, 0x13F
    ctx->r9 = ctx->r9 | 0X13F;
    // 0x8038DAE0: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038DAE4: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8038DAE8: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8038DAEC: sw          $t1, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r9;
    // 0x8038DAF0: lw          $t2, 0x4274($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X4274);
    // 0x8038DAF4: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x8038DAF8: addu        $a0, $a0, $t2
    ctx->r4 = ADD32(ctx->r4, ctx->r10);
    // 0x8038DAFC: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x8038DB00: jal         0x80138130
    // 0x8038DB04: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_3;
    // 0x8038DB04: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    after_3:
    // 0x8038DB08: lw          $a3, 0x20($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X20);
    // 0x8038DB0C: lui         $t4, 0xED02
    ctx->r12 = S32(0XED02 << 16);
    // 0x8038DB10: ori         $t4, $t4, 0x20
    ctx->r12 = ctx->r12 | 0X20;
    // 0x8038DB14: sw          $v0, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r2;
    // 0x8038DB18: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038DB1C: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8038DB20: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8038DB24: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x8038DB28: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8038DB2C: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8038DB30: lh          $t5, 0x3FD0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD0);
    // 0x8038DB34: lh          $t2, 0x3FD2($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X3FD2);
    // 0x8038DB38: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8038DB3C: addiu       $t6, $t5, -0x8
    ctx->r14 = ADD32(ctx->r13, -0X8);
    // 0x8038DB40: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8038DB44: addiu       $t3, $t2, -0x8
    ctx->r11 = ADD32(ctx->r10, -0X8);
    // 0x8038DB48: mtc1        $t3, $f16
    ctx->f16.u32l = ctx->r11;
    // 0x8038DB4C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038DB50: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8038DB54: lui         $t0, 0x600
    ctx->r8 = S32(0X600 << 16);
    // 0x8038DB58: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x8038DB5C: ori         $at, $zero, 0x9600
    ctx->r1 = 0 | 0X9600;
    // 0x8038DB60: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8038DB64: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x8038DB68: nop

    // 0x8038DB6C: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8038DB70: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8038DB74: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8038DB78: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x8038DB7C: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x8038DB80: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8038DB84: sll         $t1, $t9, 12
    ctx->r9 = S32(ctx->r25 << 12);
    // 0x8038DB88: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x8038DB8C: or          $t7, $t1, $t6
    ctx->r15 = ctx->r9 | ctx->r14;
    // 0x8038DB90: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8038DB94: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038DB98: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038DB9C: addiu       $t9, $t9, 0x4270
    ctx->r25 = ADD32(ctx->r25, 0X4270);
    // 0x8038DBA0: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8038DBA4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8038DBA8: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8038DBAC: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8038DBB0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038DBB4: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x8038DBB8: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x8038DBBC: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8038DBC0: lw          $t3, 0x4278($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X4278);
    // 0x8038DBC4: addu        $t4, $t3, $at
    ctx->r12 = ADD32(ctx->r11, ctx->r1);
    // 0x8038DBC8: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    // 0x8038DBCC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8038DBD0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8038DBD4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8038DBD8: jr          $ra
    // 0x8038DBDC: nop

    return;
    // 0x8038DBDC: nop

;}
RECOMP_FUNC void render_terminal_stat_text(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038DBE0: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x8038DBE4: sw          $s2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r18;
    // 0x8038DBE8: lui         $s2, 0x803F
    ctx->r18 = S32(0X803F << 16);
    // 0x8038DBEC: addiu       $s2, $s2, 0x6478
    ctx->r18 = ADD32(ctx->r18, 0X6478);
    // 0x8038DBF0: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
    // 0x8038DBF4: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x8038DBF8: sw          $s3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r19;
    // 0x8038DBFC: sw          $s1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r17;
    // 0x8038DC00: sw          $s0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r16;
    // 0x8038DC04: sdc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X28, ctx->r29);
    // 0x8038DC08: sdc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X20, ctx->r29);
    // 0x8038DC0C: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x8038DC10: bne         $v0, $zero, L_8038DD78
    if (ctx->r2 != 0) {
        // 0x8038DC14: sw          $a1, 0x5C($sp)
        MEM_W(0X5C, ctx->r29) = ctx->r5;
            goto L_8038DD78;
    }
    // 0x8038DC14: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    // 0x8038DC18: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    // 0x8038DC1C: bne         $a1, $zero, L_8038DC2C
    if (ctx->r5 != 0) {
        // 0x8038DC20: nop
    
            goto L_8038DC2C;
    }
    // 0x8038DC20: nop

    // 0x8038DC24: b           L_8038DC40
    // 0x8038DC28: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
        goto L_8038DC40;
    // 0x8038DC28: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
L_8038DC2C:
    // 0x8038DC2C: jal         0x80130AC0
    // 0x8038DC30: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    get_raw_message_length(rdram, ctx);
        goto after_0;
    // 0x8038DC30: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    after_0:
    // 0x8038DC34: sll         $s1, $v0, 16
    ctx->r17 = S32(ctx->r2 << 16);
    // 0x8038DC38: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8038DC3C: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
L_8038DC40:
    // 0x8038DC40: lw          $a1, 0x34($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X34);
    // 0x8038DC44: bne         $a1, $zero, L_8038DC54
    if (ctx->r5 != 0) {
        // 0x8038DC48: nop
    
            goto L_8038DC54;
    }
    // 0x8038DC48: nop

    // 0x8038DC4C: b           L_8038DC68
    // 0x8038DC50: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_8038DC68;
    // 0x8038DC50: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8038DC54:
    // 0x8038DC54: jal         0x80130AC0
    // 0x8038DC58: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    get_raw_message_length(rdram, ctx);
        goto after_1;
    // 0x8038DC58: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    after_1:
    // 0x8038DC5C: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x8038DC60: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8038DC64: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_8038DC68:
    // 0x8038DC68: lh          $s0, 0x84($s2)
    ctx->r16 = MEM_H(ctx->r18, 0X84);
    // 0x8038DC6C: addu        $t8, $s1, $v1
    ctx->r24 = ADD32(ctx->r17, ctx->r3);
    // 0x8038DC70: addiu       $t9, $t8, 0x3
    ctx->r25 = ADD32(ctx->r24, 0X3);
    // 0x8038DC74: slt         $at, $s0, $t9
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8038DC78: bne         $at, $zero, L_8038DCA0
    if (ctx->r1 != 0) {
        // 0x8038DC7C: addiu       $t0, $zero, 0x1
        ctx->r8 = ADD32(0, 0X1);
            goto L_8038DCA0;
    }
    // 0x8038DC7C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x8038DC80: sh          $t0, 0x82($s2)
    MEM_H(0X82, ctx->r18) = ctx->r8;
    // 0x8038DC84: sh          $zero, 0x84($s2)
    MEM_H(0X84, ctx->r18) = 0;
    // 0x8038DC88: addiu       $a0, $zero, 0x15
    ctx->r4 = ADD32(0, 0X15);
    // 0x8038DC8C: addiu       $a1, $zero, 0x3800
    ctx->r5 = ADD32(0, 0X3800);
    // 0x8038DC90: jal         0x8032C2D0
    // 0x8038DC94: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    func_8032C2D0_73D980(rdram, ctx);
        goto after_2;
    // 0x8038DC94: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    after_2:
    // 0x8038DC98: b           L_8038DE34
    // 0x8038DC9C: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
        goto L_8038DE34;
    // 0x8038DC9C: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
L_8038DCA0:
    // 0x8038DCA0: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    // 0x8038DCA4: lui         $s3, 0x801E
    ctx->r19 = S32(0X801E << 16);
    // 0x8038DCA8: addiu       $a0, $s3, -0x6184
    ctx->r4 = ADD32(ctx->r19, -0X6184);
    // 0x8038DCAC: beq         $a1, $zero, L_8038DCDC
    if (ctx->r5 == 0) {
        // 0x8038DCB0: lui         $at, 0x4160
        ctx->r1 = S32(0X4160 << 16);
            goto L_8038DCDC;
    }
    // 0x8038DCB0: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8038DCB4: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038DCB8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038DCBC: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8038DCC0: addiu       $a2, $zero, 0x19
    ctx->r6 = ADD32(0, 0X19);
    // 0x8038DCC4: addiu       $a3, $zero, 0xD2
    ctx->r7 = ADD32(0, 0XD2);
    // 0x8038DCC8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038DCCC: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038DCD0: jal         0x8012D374
    // 0x8038DCD4: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    func_8012D374(rdram, ctx);
        goto after_3;
    // 0x8038DCD4: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    after_3:
    // 0x8038DCD8: lh          $s0, 0x84($s2)
    ctx->r16 = MEM_H(ctx->r18, 0X84);
L_8038DCDC:
    // 0x8038DCDC: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x8038DCE0: lw          $a1, 0x34($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X34);
    // 0x8038DCE4: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038DCE8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038DCEC: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8038DCF0: lui         $s3, 0x801E
    ctx->r19 = S32(0X801E << 16);
    // 0x8038DCF4: beq         $a1, $zero, L_8038DD30
    if (ctx->r5 == 0) {
        // 0x8038DCF8: addiu       $s3, $s3, -0x6184
        ctx->r19 = ADD32(ctx->r19, -0X6184);
            goto L_8038DD30;
    }
    // 0x8038DCF8: addiu       $s3, $s3, -0x6184
    ctx->r19 = ADD32(ctx->r19, -0X6184);
    // 0x8038DCFC: addiu       $t1, $s1, 0x3
    ctx->r9 = ADD32(ctx->r17, 0X3);
    // 0x8038DD00: slt         $at, $t1, $s0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r16) ? 1 : 0;
    // 0x8038DD04: beq         $at, $zero, L_8038DD30
    if (ctx->r1 == 0) {
        // 0x8038DD08: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_8038DD30;
    }
    // 0x8038DD08: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8038DD0C: subu        $t2, $s0, $s1
    ctx->r10 = SUB32(ctx->r16, ctx->r17);
    // 0x8038DD10: addiu       $t3, $t2, -0x3
    ctx->r11 = ADD32(ctx->r10, -0X3);
    // 0x8038DD14: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x8038DD18: lhu         $a2, 0x68($s2)
    ctx->r6 = MEM_HU(ctx->r18, 0X68);
    // 0x8038DD1C: addiu       $a3, $zero, 0xD2
    ctx->r7 = ADD32(0, 0XD2);
    // 0x8038DD20: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038DD24: jal         0x8012D374
    // 0x8038DD28: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    func_8012D374(rdram, ctx);
        goto after_4;
    // 0x8038DD28: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    after_4:
    // 0x8038DD2C: lh          $s0, 0x84($s2)
    ctx->r16 = MEM_H(ctx->r18, 0X84);
L_8038DD30:
    // 0x8038DD30: slt         $at, $s0, $s1
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x8038DD34: bne         $at, $zero, L_8038DD44
    if (ctx->r1 != 0) {
        // 0x8038DD38: addiu       $t4, $s1, 0x3
        ctx->r12 = ADD32(ctx->r17, 0X3);
            goto L_8038DD44;
    }
    // 0x8038DD38: addiu       $t4, $s1, 0x3
    ctx->r12 = ADD32(ctx->r17, 0X3);
    // 0x8038DD3C: slt         $at, $t4, $s0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r16) ? 1 : 0;
    // 0x8038DD40: beq         $at, $zero, L_8038DD68
    if (ctx->r1 == 0) {
        // 0x8038DD44: lui         $at, 0x3F00
        ctx->r1 = S32(0X3F00 << 16);
            goto L_8038DD68;
    }
L_8038DD44:
    // 0x8038DD44: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x8038DD48: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038DD4C: addiu       $a0, $zero, 0x17
    ctx->r4 = ADD32(0, 0X17);
    // 0x8038DD50: addiu       $a1, $zero, 0x36
    ctx->r5 = ADD32(0, 0X36);
    // 0x8038DD54: addiu       $a2, $zero, 0x1AAA
    ctx->r6 = ADD32(0, 0X1AAA);
    // 0x8038DD58: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038DD5C: jal         0x8032CD20
    // 0x8038DD60: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_5;
    // 0x8038DD60: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_5:
    // 0x8038DD64: lh          $s0, 0x84($s2)
    ctx->r16 = MEM_H(ctx->r18, 0X84);
L_8038DD68:
    // 0x8038DD68: addiu       $t5, $s0, 0x1
    ctx->r13 = ADD32(ctx->r16, 0X1);
    // 0x8038DD6C: sh          $t5, 0x84($s2)
    MEM_H(0X84, ctx->r18) = ctx->r13;
    // 0x8038DD70: b           L_8038DE34
    // 0x8038DD74: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
        goto L_8038DE34;
    // 0x8038DD74: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
L_8038DD78:
    // 0x8038DD78: addiu       $t6, $v0, 0x2
    ctx->r14 = ADD32(ctx->r2, 0X2);
    // 0x8038DD7C: sh          $t6, 0x82($s2)
    MEM_H(0X82, ctx->r18) = ctx->r14;
    // 0x8038DD80: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
    // 0x8038DD84: addiu       $s0, $zero, 0xB
    ctx->r16 = ADD32(0, 0XB);
    // 0x8038DD88: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038DD8C: slti        $at, $v0, 0x10
    ctx->r1 = SIGNED(ctx->r2) < 0X10 ? 1 : 0;
    // 0x8038DD90: bnel        $at, $zero, L_8038DE38
    if (ctx->r1 != 0) {
        // 0x8038DD94: lui         $at, 0x4160
        ctx->r1 = S32(0X4160 << 16);
            goto L_8038DE38;
    }
    goto skip_0;
    // 0x8038DD94: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    skip_0:
    // 0x8038DD98: sh          $zero, 0x82($s2)
    MEM_H(0X82, ctx->r18) = 0;
L_8038DD9C:
    // 0x8038DD9C: sll         $t7, $s0, 2
    ctx->r15 = S32(ctx->r16 << 2);
    // 0x8038DDA0: addu        $v0, $s2, $t7
    ctx->r2 = ADD32(ctx->r18, ctx->r15);
    // 0x8038DDA4: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8038DDA8: lw          $t9, 0x34($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X34);
    // 0x8038DDAC: sll         $t0, $s0, 1
    ctx->r8 = S32(ctx->r16 << 1);
    // 0x8038DDB0: addiu       $s0, $s0, -0x1
    ctx->r16 = ADD32(ctx->r16, -0X1);
    // 0x8038DDB4: addu        $v1, $s2, $t0
    ctx->r3 = ADD32(ctx->r18, ctx->r8);
    // 0x8038DDB8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038DDBC: sw          $t9, 0x38($v0)
    MEM_W(0X38, ctx->r2) = ctx->r25;
    // 0x8038DDC0: lh          $t1, 0x68($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X68);
    // 0x8038DDC4: sll         $t2, $s0, 16
    ctx->r10 = S32(ctx->r16 << 16);
    // 0x8038DDC8: sra         $s0, $t2, 16
    ctx->r16 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8038DDCC: bgez        $s0, L_8038DD9C
    if (SIGNED(ctx->r16) >= 0) {
        // 0x8038DDD0: sh          $t1, 0x6A($v1)
        MEM_H(0X6A, ctx->r3) = ctx->r9;
            goto L_8038DD9C;
    }
    // 0x8038DDD0: sh          $t1, 0x6A($v1)
    MEM_H(0X6A, ctx->r3) = ctx->r9;
    // 0x8038DDD4: lh          $t4, 0x86($s2)
    ctx->r12 = MEM_H(ctx->r18, 0X86);
    // 0x8038DDD8: lh          $t3, 0x86($s2)
    ctx->r11 = MEM_H(ctx->r18, 0X86);
    // 0x8038DDDC: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8038DDE0: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x8038DDE4: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x8038DDE8: div         $zero, $t4, $at
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r1)));
    // 0x8038DDEC: lh          $t7, 0x86($s2)
    ctx->r15 = MEM_H(ctx->r18, 0X86);
    // 0x8038DDF0: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x8038DDF4: lw          $t6, 0x6500($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X6500);
    // 0x8038DDF8: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x8038DDFC: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8038DE00: lh          $t0, 0x86($s2)
    ctx->r8 = MEM_H(ctx->r18, 0X86);
    // 0x8038DE04: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x8038DE08: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8038DE0C: lw          $t9, 0x6560($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X6560);
    // 0x8038DE10: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8038DE14: sll         $t1, $t0, 1
    ctx->r9 = S32(ctx->r8 << 1);
    // 0x8038DE18: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x8038DE1C: sw          $t9, 0x34($s2)
    MEM_W(0X34, ctx->r18) = ctx->r25;
    // 0x8038DE20: lh          $t2, 0x6548($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X6548);
    // 0x8038DE24: mfhi        $t5
    ctx->r13 = hi;
    // 0x8038DE28: sh          $t5, 0x86($s2)
    MEM_H(0X86, ctx->r18) = ctx->r13;
    // 0x8038DE2C: lh          $v0, 0x82($s2)
    ctx->r2 = MEM_H(ctx->r18, 0X82);
    // 0x8038DE30: sh          $t2, 0x68($s2)
    MEM_H(0X68, ctx->r18) = ctx->r10;
L_8038DE34:
    // 0x8038DE34: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
L_8038DE38:
    // 0x8038DE38: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038DE3C: addiu       $t6, $zero, 0xD2
    ctx->r14 = ADD32(0, 0XD2);
    // 0x8038DE40: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038DE44: subu        $s1, $t6, $v0
    ctx->r17 = SUB32(ctx->r14, ctx->r2);
    // 0x8038DE48: lui         $s3, 0x801E
    ctx->r19 = S32(0X801E << 16);
    // 0x8038DE4C: sll         $t7, $s1, 16
    ctx->r15 = S32(ctx->r17 << 16);
    // 0x8038DE50: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x8038DE54: addiu       $s3, $s3, -0x6184
    ctx->r19 = ADD32(ctx->r19, -0X6184);
    // 0x8038DE58: sra         $s1, $t7, 16
    ctx->r17 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038DE5C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_8038DE60:
    // 0x8038DE60: bne         $s0, $zero, L_8038DE70
    if (ctx->r16 != 0) {
        // 0x8038DE64: sll         $t0, $s0, 2
        ctx->r8 = S32(ctx->r16 << 2);
            goto L_8038DE70;
    }
    // 0x8038DE64: sll         $t0, $s0, 2
    ctx->r8 = S32(ctx->r16 << 2);
    // 0x8038DE68: lh          $t9, 0x82($s2)
    ctx->r25 = MEM_H(ctx->r18, 0X82);
    // 0x8038DE6C: beq         $t9, $zero, L_8038DED4
    if (ctx->r25 == 0) {
        // 0x8038DE70: addu        $v0, $s2, $t0
        ctx->r2 = ADD32(ctx->r18, ctx->r8);
            goto L_8038DED4;
    }
L_8038DE70:
    // 0x8038DE70: addu        $v0, $s2, $t0
    ctx->r2 = ADD32(ctx->r18, ctx->r8);
    // 0x8038DE74: lw          $a1, 0x0($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X0);
    // 0x8038DE78: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8038DE7C: addiu       $a2, $zero, 0x19
    ctx->r6 = ADD32(0, 0X19);
    // 0x8038DE80: beq         $a1, $zero, L_8038DEA4
    if (ctx->r5 == 0) {
        // 0x8038DE84: andi        $a3, $s1, 0xFFFF
        ctx->r7 = ctx->r17 & 0XFFFF;
            goto L_8038DEA4;
    }
    // 0x8038DE84: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x8038DE88: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
    // 0x8038DE8C: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x8038DE90: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038DE94: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    // 0x8038DE98: jal         0x8012D374
    // 0x8038DE9C: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    func_8012D374(rdram, ctx);
        goto after_6;
    // 0x8038DE9C: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    after_6:
    // 0x8038DEA0: lw          $v0, 0x4C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X4C);
L_8038DEA4:
    // 0x8038DEA4: lw          $a1, 0x34($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X34);
    // 0x8038DEA8: sll         $t2, $s0, 1
    ctx->r10 = S32(ctx->r16 << 1);
    // 0x8038DEAC: addu        $t3, $s2, $t2
    ctx->r11 = ADD32(ctx->r18, ctx->r10);
    // 0x8038DEB0: beq         $a1, $zero, L_8038DED4
    if (ctx->r5 == 0) {
        // 0x8038DEB4: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_8038DED4;
    }
    // 0x8038DEB4: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8038DEB8: lhu         $a2, 0x68($t3)
    ctx->r6 = MEM_HU(ctx->r11, 0X68);
    // 0x8038DEBC: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x8038DEC0: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8038DEC4: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    // 0x8038DEC8: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038DECC: jal         0x8012D374
    // 0x8038DED0: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    func_8012D374(rdram, ctx);
        goto after_7;
    // 0x8038DED0: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    after_7:
L_8038DED4:
    // 0x8038DED4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038DED8: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x8038DEDC: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038DEE0: addiu       $s1, $s1, -0xF
    ctx->r17 = ADD32(ctx->r17, -0XF);
    // 0x8038DEE4: slti        $at, $s0, 0xD
    ctx->r1 = SIGNED(ctx->r16) < 0XD ? 1 : 0;
    // 0x8038DEE8: sll         $t5, $s1, 16
    ctx->r13 = S32(ctx->r17 << 16);
    // 0x8038DEEC: bne         $at, $zero, L_8038DE60
    if (ctx->r1 != 0) {
        // 0x8038DEF0: sra         $s1, $t5, 16
        ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
            goto L_8038DE60;
    }
    // 0x8038DEF0: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8038DEF4: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8038DEF8: ldc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
    // 0x8038DEFC: ldc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X28);
    // 0x8038DF00: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x8038DF04: lw          $s1, 0x38($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X38);
    // 0x8038DF08: lw          $s2, 0x3C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X3C);
    // 0x8038DF0C: lw          $s3, 0x40($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X40);
    // 0x8038DF10: jr          $ra
    // 0x8038DF14: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    return;
    // 0x8038DF14: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
;}
RECOMP_FUNC void spin_dna_helixes(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038DF18: addiu       $sp, $sp, -0xF8
    ctx->r29 = ADD32(ctx->r29, -0XF8);
    // 0x8038DF1C: sw          $ra, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r31;
    // 0x8038DF20: sw          $s0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r16;
    // 0x8038DF24: andi        $s0, $a0, 0xFFFF
    ctx->r16 = ctx->r4 & 0XFFFF;
    // 0x8038DF28: sw          $fp, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r30;
    // 0x8038DF2C: sw          $s7, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r23;
    // 0x8038DF30: sw          $s6, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r22;
    // 0x8038DF34: sw          $s5, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r21;
    // 0x8038DF38: sw          $s4, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r20;
    // 0x8038DF3C: sw          $s3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r19;
    // 0x8038DF40: sw          $s2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r18;
    // 0x8038DF44: sw          $s1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r17;
    // 0x8038DF48: sdc1        $f28, 0x40($sp)
    CHECK_FR(ctx, 28);
    SD(ctx->f28.u64, 0X40, ctx->r29);
    // 0x8038DF4C: sdc1        $f26, 0x38($sp)
    CHECK_FR(ctx, 26);
    SD(ctx->f26.u64, 0X38, ctx->r29);
    // 0x8038DF50: sdc1        $f24, 0x30($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X30, ctx->r29);
    // 0x8038DF54: sdc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X28, ctx->r29);
    // 0x8038DF58: sdc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X20, ctx->r29);
    // 0x8038DF5C: jal         0x8038E80C
    // 0x8038DF60: sw          $a0, 0xF8($sp)
    MEM_W(0XF8, ctx->r29) = ctx->r4;
    step_terminal_dna_simulation(rdram, ctx);
        goto after_0;
    // 0x8038DF60: sw          $a0, 0xF8($sp)
    MEM_W(0XF8, ctx->r29) = ctx->r4;
    after_0:
    // 0x8038DF64: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038DF68: lwc1        $f12, 0x6670($at)
    ctx->f12.u32l = MEM_W(ctx->r1, 0X6670);
    // 0x8038DF6C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038DF70: ldc1        $f22, 0x128($at)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r1, 0X128);
    // 0x8038DF74: lui         $at, 0x4024
    ctx->r1 = S32(0X4024 << 16);
    // 0x8038DF78: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x8038DF7C: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x8038DF80: cvt.d.s     $f4, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f4.d = CVT_D_S(ctx->f12.fl);
    // 0x8038DF84: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    // 0x8038DF88: add.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d + ctx->f6.d;
    // 0x8038DF8C: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038DF90: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x8038DF94: lui         $t9, 0x104
    ctx->r25 = S32(0X104 << 16);
    // 0x8038DF98: cvt.s.d     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f12.fl = CVT_S_D(ctx->f8.d);
    // 0x8038DF9C: mtc1        $zero, $f24
    ctx->f24.u32l = 0;
    // 0x8038DFA0: addiu       $t9, $t9, -0x4780
    ctx->r25 = ADD32(ctx->r25, -0X4780);
    // 0x8038DFA4: addiu       $t8, $t8, 0x65D8
    ctx->r24 = ADD32(ctx->r24, 0X65D8);
    // 0x8038DFA8: cvt.d.s     $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.d = CVT_D_S(ctx->f12.fl);
    // 0x8038DFAC: addiu       $t7, $t7, 0x65E0
    ctx->r15 = ADD32(ctx->r15, 0X65E0);
    // 0x8038DFB0: c.lt.d      $f22, $f0
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f22.d < ctx->f0.d;
    // 0x8038DFB4: sll         $t6, $v1, 3
    ctx->r14 = S32(ctx->r3 << 3);
    // 0x8038DFB8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038DFBC: or          $fp, $zero, $zero
    ctx->r30 = 0 | 0;
    // 0x8038DFC0: bc1f        L_8038DFD0
    if (!c1cs) {
        // 0x8038DFC4: lui         $s7, 0x3
        ctx->r23 = S32(0X3 << 16);
            goto L_8038DFD0;
    }
    // 0x8038DFC4: lui         $s7, 0x3
    ctx->r23 = S32(0X3 << 16);
    // 0x8038DFC8: sub.d       $f10, $f0, $f22
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f22.d); 
    ctx->f10.d = ctx->f0.d - ctx->f22.d;
    // 0x8038DFCC: cvt.s.d     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f12.fl = CVT_S_D(ctx->f10.d);
L_8038DFD0:
    // 0x8038DFD0: sw          $t6, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r14;
    // 0x8038DFD4: sw          $t7, 0x98($sp)
    MEM_W(0X98, ctx->r29) = ctx->r15;
    // 0x8038DFD8: swc1        $f12, 0x6670($at)
    MEM_W(0X6670, ctx->r1) = ctx->f12.u32l;
    // 0x8038DFDC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038DFE0: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038DFE4: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038DFE8: sw          $t8, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r24;
    // 0x8038DFEC: lui         $t8, 0x104
    ctx->r24 = S32(0X104 << 16);
    // 0x8038DFF0: addiu       $t6, $t6, 0x65F8
    ctx->r14 = ADD32(ctx->r14, 0X65F8);
    // 0x8038DFF4: addiu       $t7, $t7, 0x65F0
    ctx->r15 = ADD32(ctx->r15, 0X65F0);
    // 0x8038DFF8: mtc1        $at, $f28
    ctx->f28.u32l = ctx->r1;
    // 0x8038DFFC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E000: sw          $t7, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r15;
    // 0x8038E004: sw          $t6, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r14;
    // 0x8038E008: addiu       $t8, $t8, -0x4590
    ctx->r24 = ADD32(ctx->r24, -0X4590);
    // 0x8038E00C: sw          $t9, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r25;
    // 0x8038E010: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x8038E014: sw          $t8, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r24;
    // 0x8038E018: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038E01C: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x8038E020: ldc1        $f26, 0x130($at)
    CHECK_FR(ctx, 26);
    ctx->f26.u64 = LD(ctx->r1, 0X130);
    // 0x8038E024: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E028: addiu       $t7, $t7, -0x13E0
    ctx->r15 = ADD32(ctx->r15, -0X13E0);
    // 0x8038E02C: addiu       $t6, $t6, 0x65A8
    ctx->r14 = ADD32(ctx->r14, 0X65A8);
    // 0x8038E030: sll         $t8, $s0, 2
    ctx->r24 = S32(ctx->r16 << 2);
    // 0x8038E034: addiu       $t9, $t9, 0x65B0
    ctx->r25 = ADD32(ctx->r25, 0X65B0);
    // 0x8038E038: lui         $s6, 0x8020
    ctx->r22 = S32(0X8020 << 16);
    // 0x8038E03C: lui         $s5, 0x803B
    ctx->r21 = S32(0X803B << 16);
    // 0x8038E040: lui         $s4, 0x803B
    ctx->r20 = S32(0X803B << 16);
    // 0x8038E044: lui         $s3, 0x803B
    ctx->r19 = S32(0X803B << 16);
    // 0x8038E048: lui         $s2, 0x801E
    ctx->r18 = S32(0X801E << 16);
    // 0x8038E04C: addiu       $s2, $s2, -0x6178
    ctx->r18 = ADD32(ctx->r18, -0X6178);
    // 0x8038E050: addiu       $s3, $s3, 0x65D8
    ctx->r19 = ADD32(ctx->r19, 0X65D8);
    // 0x8038E054: addiu       $s4, $s4, 0x65F0
    ctx->r20 = ADD32(ctx->r20, 0X65F0);
    // 0x8038E058: addiu       $s5, $s5, 0x65A8
    ctx->r21 = ADD32(ctx->r21, 0X65A8);
    // 0x8038E05C: addiu       $s6, $s6, 0x4278
    ctx->r22 = ADD32(ctx->r22, 0X4278);
    // 0x8038E060: sw          $t9, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r25;
    // 0x8038E064: sw          $t8, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r24;
    // 0x8038E068: sw          $t6, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r14;
    // 0x8038E06C: sw          $t7, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r15;
    // 0x8038E070: ldc1        $f20, 0x138($at)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r1, 0X138);
    // 0x8038E074: ori         $s7, $s7, 0x8000
    ctx->r23 = ctx->r23 | 0X8000;
L_8038E078:
    // 0x8038E078: addiu       $t9, $fp, -0x8
    ctx->r25 = ADD32(ctx->r30, -0X8);
    // 0x8038E07C: mtc1        $t9, $f16
    ctx->f16.u32l = ctx->r25;
    // 0x8038E080: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038E084: lwc1        $f12, 0x6670($at)
    ctx->f12.u32l = MEM_W(ctx->r1, 0X6670);
    // 0x8038E088: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x8038E08C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038E090: cvt.d.s     $f6, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f6.d = CVT_D_S(ctx->f12.fl);
    // 0x8038E094: mul.d       $f4, $f18, $f26
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 26);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f26.d); 
    ctx->f4.d = MUL_D(ctx->f18.d, ctx->f26.d);
    // 0x8038E098: sub.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d - ctx->f6.d;
    // 0x8038E09C: cvt.s.d     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f0.fl = CVT_S_D(ctx->f8.d);
    // 0x8038E0A0: cvt.d.s     $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f10.d = CVT_D_S(ctx->f0.fl);
    // 0x8038E0A4: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
    // 0x8038E0A8: c.lt.d      $f10, $f20
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    c1cs = ctx->f10.d < ctx->f20.d;
    // 0x8038E0AC: nop

    // 0x8038E0B0: bc1fl       L_8038E0DC
    if (!c1cs) {
        // 0x8038E0B4: lw          $s1, 0x0($s6)
        ctx->r17 = MEM_W(ctx->r22, 0X0);
            goto L_8038E0DC;
    }
    goto skip_0;
    // 0x8038E0B4: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    skip_0:
    // 0x8038E0B8: cvt.d.s     $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.d = CVT_D_S(ctx->f0.fl);
    // 0x8038E0BC: add.d       $f16, $f0, $f22
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f22.d); 
    ctx->f16.d = ctx->f0.d + ctx->f22.d;
L_8038E0C0:
    // 0x8038E0C0: cvt.s.d     $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f2.fl = CVT_S_D(ctx->f16.d);
    // 0x8038E0C4: cvt.d.s     $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f0.d = CVT_D_S(ctx->f2.fl);
    // 0x8038E0C8: c.lt.d      $f0, $f20
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 20);
    c1cs = ctx->f0.d < ctx->f20.d;
    // 0x8038E0CC: nop

    // 0x8038E0D0: bc1tl       L_8038E0C0
    if (c1cs) {
        // 0x8038E0D4: add.d       $f16, $f0, $f22
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f22.d); 
    ctx->f16.d = ctx->f0.d + ctx->f22.d;
            goto L_8038E0C0;
    }
    goto skip_1;
    // 0x8038E0D4: add.d       $f16, $f0, $f22
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f22.d); 
    ctx->f16.d = ctx->f0.d + ctx->f22.d;
    skip_1:
    // 0x8038E0D8: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
L_8038E0DC:
    // 0x8038E0DC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038E0E0: mfc1        $a1, $f24
    ctx->r5 = (int32_t)ctx->f24.u32l;
    // 0x8038E0E4: addu        $t6, $s1, $s7
    ctx->r14 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E0E8: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x8038E0EC: mfc1        $a2, $f24
    ctx->r6 = (int32_t)ctx->f24.u32l;
    // 0x8038E0F0: mfc1        $a3, $f2
    ctx->r7 = (int32_t)ctx->f2.u32l;
    // 0x8038E0F4: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8038E0F8: addu        $a0, $s1, $t8
    ctx->r4 = ADD32(ctx->r17, ctx->r24);
    // 0x8038E0FC: jal         0x8013F328
    // 0x8038E100: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    guTranslate(rdram, ctx);
        goto after_1;
    // 0x8038E100: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    after_1:
    // 0x8038E104: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E108: lui         $t6, 0x104
    ctx->r14 = S32(0X104 << 16);
    // 0x8038E10C: ori         $t6, $t6, 0x40
    ctx->r14 = ctx->r14 | 0X40;
    // 0x8038E110: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8038E114: sw          $t9, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r25;
    // 0x8038E118: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8038E11C: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x8038E120: lui         $v1, 0x3
    ctx->r3 = S32(0X3 << 16);
    // 0x8038E124: ori         $v1, $v1, 0x3590
    ctx->r3 = ctx->r3 | 0X3590;
    // 0x8038E128: addu        $t7, $s1, $s7
    ctx->r15 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E12C: lw          $t8, 0x918($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X918);
    // 0x8038E130: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038E134: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8038E138: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x8038E13C: addu        $t6, $s1, $t9
    ctx->r14 = ADD32(ctx->r17, ctx->r25);
    // 0x8038E140: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x8038E144: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8038E148: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x8038E14C: mfc1        $a2, $f24
    ctx->r6 = (int32_t)ctx->f24.u32l;
    // 0x8038E150: mfc1        $a3, $f24
    ctx->r7 = (int32_t)ctx->f24.u32l;
    // 0x8038E154: addu        $t8, $s1, $s7
    ctx->r24 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E158: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8038E15C: addu        $at, $at, $s1
    ctx->r1 = ADD32(ctx->r1, ctx->r17);
    // 0x8038E160: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x8038E164: sw          $t6, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r14;
    // 0x8038E168: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x8038E16C: addu        $t7, $s1, $s7
    ctx->r15 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E170: lw          $t8, 0x918($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X918);
    // 0x8038E174: sll         $t7, $fp, 4
    ctx->r15 = S32(ctx->r30 << 4);
    // 0x8038E178: swc1        $f28, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f28.u32l;
    // 0x8038E17C: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x8038E180: lw          $t8, 0x9C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X9C);
    // 0x8038E184: addu        $t6, $s1, $t9
    ctx->r14 = ADD32(ctx->r17, ctx->r25);
    // 0x8038E188: addu        $a0, $t6, $v1
    ctx->r4 = ADD32(ctx->r14, ctx->r3);
    // 0x8038E18C: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8038E190: addu        $a1, $a1, $t9
    ctx->r5 = ADD32(ctx->r5, ctx->r25);
    // 0x8038E194: jal         0x8013FB74
    // 0x8038E198: lw          $a1, 0x6570($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6570);
    guRotate(rdram, ctx);
        goto after_2;
    // 0x8038E198: lw          $a1, 0x6570($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6570);
    after_2:
    // 0x8038E19C: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E1A0: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8038E1A4: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x8038E1A8: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038E1AC: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8038E1B0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8038E1B4: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x8038E1B8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038E1BC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038E1C0: addu        $t8, $s1, $s7
    ctx->r24 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E1C4: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8038E1C8: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x8038E1CC: lui         $t5, 0x8000
    ctx->r13 = S32(0X8000 << 16);
    // 0x8038E1D0: sll         $t6, $t9, 6
    ctx->r14 = S32(ctx->r25 << 6);
    // 0x8038E1D4: addu        $t7, $s1, $t6
    ctx->r15 = ADD32(ctx->r17, ctx->r14);
    // 0x8038E1D8: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x8038E1DC: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8038E1E0: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x8038E1E4: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038E1E8: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x8038E1EC: addu        $t9, $s1, $s7
    ctx->r25 = ADD32(ctx->r17, ctx->r23);
    // 0x8038E1F0: lw          $t6, 0x918($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X918);
    // 0x8038E1F4: addu        $at, $at, $s1
    ctx->r1 = ADD32(ctx->r1, ctx->r17);
    // 0x8038E1F8: ori         $t4, $t4, 0x2
    ctx->r12 = ctx->r12 | 0X2;
    // 0x8038E1FC: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038E200: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x8038E204: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E208: lui         $ra, 0x386
    ctx->r31 = S32(0X386 << 16);
    // 0x8038E20C: ori         $ra, $ra, 0x10
    ctx->r31 = ctx->r31 | 0X10;
    // 0x8038E210: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8038E214: sw          $t8, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r24;
    // 0x8038E218: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8038E21C: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8038E220: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E224: lui         $t8, 0x388
    ctx->r24 = S32(0X388 << 16);
    // 0x8038E228: ori         $t8, $t8, 0x10
    ctx->r24 = ctx->r24 | 0X10;
    // 0x8038E22C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8038E230: sw          $t9, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r25;
    // 0x8038E234: sw          $ra, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r31;
    // 0x8038E238: lw          $t6, 0x98($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X98);
    // 0x8038E23C: addiu       $fp, $fp, 0x1
    ctx->r30 = ADD32(ctx->r30, 0X1);
    // 0x8038E240: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8038E244: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E248: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8038E24C: sw          $t7, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r15;
    // 0x8038E250: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8038E254: lw          $t9, 0x94($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X94);
    // 0x8038E258: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8038E25C: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8038E260: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E264: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038E268: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8038E26C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8038E270: lw          $t8, 0x90($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X90);
    // 0x8038E274: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8038E278: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E27C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8038E280: sw          $t9, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r25;
    // 0x8038E284: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8038E288: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8038E28C: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E290: lui         $t9, 0x388
    ctx->r25 = S32(0X388 << 16);
    // 0x8038E294: ori         $t9, $t9, 0x10
    ctx->r25 = ctx->r25 | 0X10;
    // 0x8038E298: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038E29C: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8038E2A0: sw          $ra, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r31;
    // 0x8038E2A4: lw          $t7, 0x8C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X8C);
    // 0x8038E2A8: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8038E2AC: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E2B0: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8038E2B4: sw          $t8, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r24;
    // 0x8038E2B8: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8038E2BC: lw          $t6, 0x88($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X88);
    // 0x8038E2C0: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x8038E2C4: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8038E2C8: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E2CC: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8038E2D0: sw          $t7, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r15;
    // 0x8038E2D4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8038E2D8: lw          $t9, 0x84($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X84);
    // 0x8038E2DC: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8038E2E0: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E2E4: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038E2E8: sw          $t6, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r14;
    // 0x8038E2EC: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8038E2F0: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8038E2F4: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E2F8: lui         $t6, 0x388
    ctx->r14 = S32(0X388 << 16);
    // 0x8038E2FC: ori         $t6, $t6, 0x10
    ctx->r14 = ctx->r14 | 0X10;
    // 0x8038E300: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8038E304: sw          $t7, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r15;
    // 0x8038E308: sw          $ra, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r31;
    // 0x8038E30C: lw          $t8, 0x80($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X80);
    // 0x8038E310: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x8038E314: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E318: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8038E31C: sw          $t9, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r25;
    // 0x8038E320: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8038E324: lw          $t7, 0x7C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X7C);
    // 0x8038E328: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x8038E32C: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8038E330: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E334: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x8038E338: sw          $t8, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r24;
    // 0x8038E33C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8038E340: lw          $t6, 0x78($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X78);
    // 0x8038E344: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8038E348: lw          $t7, 0x74($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X74);
    // 0x8038E34C: lh          $v1, 0x76($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X76);
    // 0x8038E350: slti        $at, $t7, 0x100
    ctx->r1 = SIGNED(ctx->r15) < 0X100 ? 1 : 0;
    // 0x8038E354: bne         $at, $zero, L_8038E364
    if (ctx->r1 != 0) {
        // 0x8038E358: nop
    
            goto L_8038E364;
    }
    // 0x8038E358: nop

    // 0x8038E35C: b           L_8038E364
    // 0x8038E360: addiu       $v1, $zero, 0xFF
    ctx->r3 = ADD32(0, 0XFF);
        goto L_8038E364;
    // 0x8038E360: addiu       $v1, $zero, 0xFF
    ctx->r3 = ADD32(0, 0XFF);
L_8038E364:
    // 0x8038E364: sll         $a0, $v1, 2
    ctx->r4 = S32(ctx->r3 << 2);
    // 0x8038E368: subu        $a0, $a0, $v1
    ctx->r4 = SUB32(ctx->r4, ctx->r3);
    // 0x8038E36C: sll         $a0, $a0, 3
    ctx->r4 = S32(ctx->r4 << 3);
    // 0x8038E370: sll         $a2, $v1, 2
    ctx->r6 = S32(ctx->r3 << 2);
    // 0x8038E374: addu        $a0, $a0, $v1
    ctx->r4 = ADD32(ctx->r4, ctx->r3);
    // 0x8038E378: addu        $a2, $a2, $v1
    ctx->r6 = ADD32(ctx->r6, ctx->r3);
    // 0x8038E37C: sll         $a0, $a0, 1
    ctx->r4 = S32(ctx->r4 << 1);
    // 0x8038E380: sll         $a1, $v1, 2
    ctx->r5 = S32(ctx->r3 << 2);
    // 0x8038E384: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    // 0x8038E388: sll         $t1, $v1, 2
    ctx->r9 = S32(ctx->r3 << 2);
    // 0x8038E38C: sll         $a3, $v1, 2
    ctx->r7 = S32(ctx->r3 << 2);
    // 0x8038E390: sra         $t9, $a0, 8
    ctx->r25 = S32(SIGNED(ctx->r4) >> 8);
    // 0x8038E394: subu        $a1, $a1, $v1
    ctx->r5 = SUB32(ctx->r5, ctx->r3);
    // 0x8038E398: subu        $a2, $a2, $v1
    ctx->r6 = SUB32(ctx->r6, ctx->r3);
    // 0x8038E39C: addu        $t1, $t1, $v1
    ctx->r9 = ADD32(ctx->r9, ctx->r3);
    // 0x8038E3A0: subu        $a3, $a3, $v1
    ctx->r7 = SUB32(ctx->r7, ctx->r3);
    // 0x8038E3A4: sll         $a1, $a1, 3
    ctx->r5 = S32(ctx->r5 << 3);
    // 0x8038E3A8: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    // 0x8038E3AC: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x8038E3B0: sll         $a3, $a3, 3
    ctx->r7 = S32(ctx->r7 << 3);
    // 0x8038E3B4: addu        $a1, $a1, $v1
    ctx->r5 = ADD32(ctx->r5, ctx->r3);
    // 0x8038E3B8: subu        $a2, $a2, $v1
    ctx->r6 = SUB32(ctx->r6, ctx->r3);
    // 0x8038E3BC: subu        $t1, $t1, $v1
    ctx->r9 = SUB32(ctx->r9, ctx->r3);
    // 0x8038E3C0: addu        $a3, $a3, $v1
    ctx->r7 = ADD32(ctx->r7, ctx->r3);
    // 0x8038E3C4: sll         $a1, $a1, 2
    ctx->r5 = S32(ctx->r5 << 2);
    // 0x8038E3C8: sll         $a2, $a2, 1
    ctx->r6 = S32(ctx->r6 << 1);
    // 0x8038E3CC: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x8038E3D0: sra         $t8, $a3, 8
    ctx->r24 = S32(SIGNED(ctx->r7) >> 8);
    // 0x8038E3D4: sb          $t9, 0x5($s3)
    MEM_B(0X5, ctx->r19) = ctx->r25;
    // 0x8038E3D8: sb          $t9, 0x1($s3)
    MEM_B(0X1, ctx->r19) = ctx->r25;
    // 0x8038E3DC: sra         $t6, $a1, 8
    ctx->r14 = S32(SIGNED(ctx->r5) >> 8);
    // 0x8038E3E0: sra         $t7, $a2, 8
    ctx->r15 = S32(SIGNED(ctx->r6) >> 8);
    // 0x8038E3E4: sll         $t0, $v1, 2
    ctx->r8 = S32(ctx->r3 << 2);
    // 0x8038E3E8: sb          $t9, 0x5($s4)
    MEM_B(0X5, ctx->r20) = ctx->r25;
    // 0x8038E3EC: sb          $t9, 0x1($s4)
    MEM_B(0X1, ctx->r20) = ctx->r25;
    // 0x8038E3F0: subu        $t1, $t1, $v1
    ctx->r9 = SUB32(ctx->r9, ctx->r3);
    // 0x8038E3F4: addu        $t0, $t0, $v1
    ctx->r8 = ADD32(ctx->r8, ctx->r3);
    // 0x8038E3F8: sra         $t9, $t1, 8
    ctx->r25 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8038E3FC: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x8038E400: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x8038E404: sb          $t8, 0x4($s3)
    MEM_B(0X4, ctx->r19) = ctx->r24;
    // 0x8038E408: sb          $t8, 0x0($s3)
    MEM_B(0X0, ctx->r19) = ctx->r24;
    // 0x8038E40C: sll         $t0, $t0, 2
    ctx->r8 = S32(ctx->r8 << 2);
    // 0x8038E410: addu        $t2, $t2, $v1
    ctx->r10 = ADD32(ctx->r10, ctx->r3);
    // 0x8038E414: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8038E418: sb          $t6, 0xC($s3)
    MEM_B(0XC, ctx->r19) = ctx->r14;
    // 0x8038E41C: sb          $t6, 0x8($s3)
    MEM_B(0X8, ctx->r19) = ctx->r14;
    // 0x8038E420: sra         $t8, $t0, 8
    ctx->r24 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8038E424: sb          $t9, 0xC($s4)
    MEM_B(0XC, ctx->r20) = ctx->r25;
    // 0x8038E428: sb          $t9, 0x8($s4)
    MEM_B(0X8, ctx->r20) = ctx->r25;
    // 0x8038E42C: sll         $t2, $t2, 1
    ctx->r10 = S32(ctx->r10 << 1);
    // 0x8038E430: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x8038E434: sb          $t7, 0xD($s3)
    MEM_B(0XD, ctx->r19) = ctx->r15;
    // 0x8038E438: sb          $t7, 0x9($s3)
    MEM_B(0X9, ctx->r19) = ctx->r15;
    // 0x8038E43C: sb          $t7, 0xD($s4)
    MEM_B(0XD, ctx->r20) = ctx->r15;
    // 0x8038E440: sb          $t7, 0x9($s4)
    MEM_B(0X9, ctx->r20) = ctx->r15;
    // 0x8038E444: sra         $t6, $t2, 8
    ctx->r14 = S32(SIGNED(ctx->r10) >> 8);
    // 0x8038E448: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038E44C: sb          $t8, 0x4($s4)
    MEM_B(0X4, ctx->r20) = ctx->r24;
    // 0x8038E450: sb          $t8, 0x0($s4)
    MEM_B(0X0, ctx->r20) = ctx->r24;
    // 0x8038E454: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8038E458: slti        $at, $fp, 0x10
    ctx->r1 = SIGNED(ctx->r30) < 0X10 ? 1 : 0;
    // 0x8038E45C: sb          $zero, 0x6($s3)
    MEM_B(0X6, ctx->r19) = 0;
    // 0x8038E460: sb          $zero, 0x2($s3)
    MEM_B(0X2, ctx->r19) = 0;
    // 0x8038E464: sb          $zero, 0xE($s3)
    MEM_B(0XE, ctx->r19) = 0;
    // 0x8038E468: sb          $zero, 0xA($s3)
    MEM_B(0XA, ctx->r19) = 0;
    // 0x8038E46C: sb          $zero, 0x6($s4)
    MEM_B(0X6, ctx->r20) = 0;
    // 0x8038E470: sb          $zero, 0x2($s4)
    MEM_B(0X2, ctx->r20) = 0;
    // 0x8038E474: sb          $zero, 0xE($s4)
    MEM_B(0XE, ctx->r20) = 0;
    // 0x8038E478: sb          $zero, 0xA($s4)
    MEM_B(0XA, ctx->r20) = 0;
    // 0x8038E47C: sb          $zero, 0x4($s5)
    MEM_B(0X4, ctx->r21) = 0;
    // 0x8038E480: sb          $zero, 0x0($s5)
    MEM_B(0X0, ctx->r21) = 0;
    // 0x8038E484: sb          $t6, 0x5($s5)
    MEM_B(0X5, ctx->r21) = ctx->r14;
    // 0x8038E488: sb          $t6, 0x1($s5)
    MEM_B(0X1, ctx->r21) = ctx->r14;
    // 0x8038E48C: sb          $zero, 0x6($s5)
    MEM_B(0X6, ctx->r21) = 0;
    // 0x8038E490: sb          $zero, 0x2($s5)
    MEM_B(0X2, ctx->r21) = 0;
    // 0x8038E494: sb          $zero, 0xC($s5)
    MEM_B(0XC, ctx->r21) = 0;
    // 0x8038E498: sb          $zero, 0x8($s5)
    MEM_B(0X8, ctx->r21) = 0;
    // 0x8038E49C: sb          $a1, 0xD($s5)
    MEM_B(0XD, ctx->r21) = ctx->r5;
    // 0x8038E4A0: sb          $a1, 0x9($s5)
    MEM_B(0X9, ctx->r21) = ctx->r5;
    // 0x8038E4A4: sb          $zero, 0xE($s5)
    MEM_B(0XE, ctx->r21) = 0;
    // 0x8038E4A8: sb          $zero, 0xA($s5)
    MEM_B(0XA, ctx->r21) = 0;
    // 0x8038E4AC: sw          $t7, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r15;
    // 0x8038E4B0: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x8038E4B4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8038E4B8: bne         $at, $zero, L_8038E078
    if (ctx->r1 != 0) {
        // 0x8038E4BC: sw          $zero, 0x4($s0)
        MEM_W(0X4, ctx->r16) = 0;
            goto L_8038E078;
    }
    // 0x8038E4BC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8038E4C0: lw          $ra, 0x6C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X6C);
    // 0x8038E4C4: ldc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
    // 0x8038E4C8: ldc1        $f22, 0x28($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X28);
    // 0x8038E4CC: ldc1        $f24, 0x30($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X30);
    // 0x8038E4D0: ldc1        $f26, 0x38($sp)
    CHECK_FR(ctx, 26);
    ctx->f26.u64 = LD(ctx->r29, 0X38);
    // 0x8038E4D4: ldc1        $f28, 0x40($sp)
    CHECK_FR(ctx, 28);
    ctx->f28.u64 = LD(ctx->r29, 0X40);
    // 0x8038E4D8: lw          $s0, 0x48($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X48);
    // 0x8038E4DC: lw          $s1, 0x4C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X4C);
    // 0x8038E4E0: lw          $s2, 0x50($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X50);
    // 0x8038E4E4: lw          $s3, 0x54($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X54);
    // 0x8038E4E8: lw          $s4, 0x58($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X58);
    // 0x8038E4EC: lw          $s5, 0x5C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X5C);
    // 0x8038E4F0: lw          $s6, 0x60($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X60);
    // 0x8038E4F4: lw          $s7, 0x64($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X64);
    // 0x8038E4F8: lw          $fp, 0x68($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X68);
    // 0x8038E4FC: jr          $ra
    // 0x8038E500: addiu       $sp, $sp, 0xF8
    ctx->r29 = ADD32(ctx->r29, 0XF8);
    return;
    // 0x8038E500: addiu       $sp, $sp, 0xF8
    ctx->r29 = ADD32(ctx->r29, 0XF8);
;}
RECOMP_FUNC void render_terminal_background_dna_79FBB4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038E504: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8038E508: sw          $s1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r17;
    // 0x8038E50C: lui         $s1, 0x8020
    ctx->r17 = S32(0X8020 << 16);
    // 0x8038E510: addiu       $s1, $s1, 0x4278
    ctx->r17 = ADD32(ctx->r17, 0X4278);
    // 0x8038E514: sw          $s0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r16;
    // 0x8038E518: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E51C: sw          $s2, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r18;
    // 0x8038E520: lui         $s2, 0x3
    ctx->r18 = S32(0X3 << 16);
    // 0x8038E524: ori         $s2, $s2, 0x8000
    ctx->r18 = ctx->r18 | 0X8000;
    // 0x8038E528: lui         $at, 0x42C8
    ctx->r1 = S32(0X42C8 << 16);
    // 0x8038E52C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038E530: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8038E534: sw          $s3, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r19;
    // 0x8038E538: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x8038E53C: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E540: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x8038E544: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E548: lwc1        $f6, 0x140($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X140);
    // 0x8038E54C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038E550: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8038E554: lui         $s3, 0x3
    ctx->r19 = S32(0X3 << 16);
    // 0x8038E558: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8038E55C: ori         $s3, $s3, 0x3590
    ctx->r19 = ctx->r19 | 0X3590;
    // 0x8038E560: lui         $a3, 0x3FAA
    ctx->r7 = S32(0X3FAA << 16);
    // 0x8038E564: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x8038E568: addu        $a0, $t9, $s3
    ctx->r4 = ADD32(ctx->r25, ctx->r19);
    // 0x8038E56C: ori         $a3, $a3, 0xAAAB
    ctx->r7 = ctx->r7 | 0XAAAB;
    // 0x8038E570: addiu       $a1, $sp, 0x5E
    ctx->r5 = ADD32(ctx->r29, 0X5E);
    // 0x8038E574: lui         $a2, 0x4204
    ctx->r6 = S32(0X4204 << 16);
    // 0x8038E578: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8038E57C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x8038E580: jal         0x8013F5B0
    // 0x8038E584: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    guPerspective(rdram, ctx);
        goto after_0;
    // 0x8038E584: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_0:
    // 0x8038E588: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x8038E58C: addiu       $v1, $v1, -0x6178
    ctx->r3 = ADD32(ctx->r3, -0X6178);
    // 0x8038E590: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E594: lui         $t3, 0x803B
    ctx->r11 = S32(0X803B << 16);
    // 0x8038E598: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E59C: ldc1        $f2, 0x148($at)
    CHECK_FR(ctx, 2);
    ctx->f2.u64 = LD(ctx->r1, 0X148);
    // 0x8038E5A0: lh          $t3, 0x66E0($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X66E0);
    // 0x8038E5A4: lui         $t5, 0x103
    ctx->r13 = S32(0X103 << 16);
    // 0x8038E5A8: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x8038E5AC: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8038E5B0: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x8038E5B4: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8038E5B8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E5BC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038E5C0: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8038E5C4: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E5C8: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x8038E5CC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038E5D0: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x8038E5D4: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8038E5D8: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x8038E5DC: addu        $t4, $t9, $s3
    ctx->r12 = ADD32(ctx->r25, ctx->r19);
    // 0x8038E5E0: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x8038E5E4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E5E8: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x8038E5EC: ori         $t9, $t9, 0xE
    ctx->r25 = ctx->r25 | 0XE;
    // 0x8038E5F0: addu        $t5, $s0, $s2
    ctx->r13 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E5F4: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x8038E5F8: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x8038E5FC: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x8038E600: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038E604: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x8038E608: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E60C: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x8038E610: lui         $a1, 0x45DA
    ctx->r5 = S32(0X45DA << 16);
    // 0x8038E614: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038E618: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8038E61C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038E620: lhu         $t4, 0x5E($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X5E);
    // 0x8038E624: andi        $t9, $t3, 0xFF
    ctx->r25 = ctx->r11 & 0XFF;
    // 0x8038E628: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x8038E62C: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x8038E630: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E634: sll         $t4, $t9, 1
    ctx->r12 = S32(ctx->r25 << 1);
    // 0x8038E638: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x8038E63C: addu        $t5, $s0, $s2
    ctx->r13 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E640: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x8038E644: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x8038E648: swc1        $f0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f0.u32l;
    // 0x8038E64C: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x8038E650: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x8038E654: addu        $a0, $t8, $s3
    ctx->r4 = ADD32(ctx->r24, ctx->r19);
    // 0x8038E658: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x8038E65C: addiu       $t8, $t3, 0x40
    ctx->r24 = ADD32(ctx->r11, 0X40);
    // 0x8038E660: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8038E664: sll         $t4, $t9, 1
    ctx->r12 = S32(ctx->r25 << 1);
    // 0x8038E668: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x8038E66C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x8038E670: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x8038E674: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8038E678: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x8038E67C: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x8038E680: ori         $a1, $a1, 0xC000
    ctx->r5 = ctx->r5 | 0XC000;
    // 0x8038E684: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8038E688: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x8038E68C: cvt.d.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.d = CVT_D_W(ctx->f10.u32l);
    // 0x8038E690: swc1        $f12, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f12.u32l;
    // 0x8038E694: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x8038E698: div.d       $f18, $f16, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f2.d); 
    ctx->f18.d = DIV_D(ctx->f16.d, ctx->f2.d);
    // 0x8038E69C: div.d       $f10, $f8, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f2.d); 
    ctx->f10.d = DIV_D(ctx->f8.d, ctx->f2.d);
    // 0x8038E6A0: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x8038E6A4: swc1        $f4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f4.u32l;
    // 0x8038E6A8: cvt.s.d     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f16.fl = CVT_S_D(ctx->f10.d);
    // 0x8038E6AC: jal         0x8013F968
    // 0x8038E6B0: swc1        $f16, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f16.u32l;
    guLookAt(rdram, ctx);
        goto after_1;
    // 0x8038E6B0: swc1        $f16, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f16.u32l;
    after_1:
    // 0x8038E6B4: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x8038E6B8: addiu       $v1, $v1, -0x6178
    ctx->r3 = ADD32(ctx->r3, -0X6178);
    // 0x8038E6BC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E6C0: lui         $t9, 0x101
    ctx->r25 = S32(0X101 << 16);
    // 0x8038E6C4: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x8038E6C8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038E6CC: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8038E6D0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038E6D4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E6D8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038E6DC: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8038E6E0: addu        $t4, $s0, $s2
    ctx->r12 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E6E4: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x8038E6E8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038E6EC: mfc1        $a1, $f12
    ctx->r5 = (int32_t)ctx->f12.u32l;
    // 0x8038E6F0: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x8038E6F4: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x8038E6F8: addu        $t8, $t7, $s3
    ctx->r24 = ADD32(ctx->r15, ctx->r19);
    // 0x8038E6FC: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038E700: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E704: mfc1        $a2, $f12
    ctx->r6 = (int32_t)ctx->f12.u32l;
    // 0x8038E708: mfc1        $a3, $f12
    ctx->r7 = (int32_t)ctx->f12.u32l;
    // 0x8038E70C: addu        $t9, $s0, $s2
    ctx->r25 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E710: lw          $t4, 0x918($t9)
    ctx->r12 = MEM_W(ctx->r25, 0X918);
    // 0x8038E714: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x8038E718: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8038E71C: sw          $t5, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r13;
    // 0x8038E720: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E724: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E728: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x8038E72C: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8038E730: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x8038E734: jal         0x8013F664
    // 0x8038E738: addu        $a0, $t9, $s3
    ctx->r4 = ADD32(ctx->r25, ctx->r19);
    guScale(rdram, ctx);
        goto after_2;
    // 0x8038E738: addu        $a0, $t9, $s3
    ctx->r4 = ADD32(ctx->r25, ctx->r19);
    after_2:
    // 0x8038E73C: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x8038E740: addiu       $v1, $v1, -0x6178
    ctx->r3 = ADD32(ctx->r3, -0X6178);
    // 0x8038E744: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E748: lui         $t3, 0x803B
    ctx->r11 = S32(0X803B << 16);
    // 0x8038E74C: lh          $t3, 0x66E0($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X66E0);
    // 0x8038E750: lui         $t5, 0x102
    ctx->r13 = S32(0X102 << 16);
    // 0x8038E754: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x8038E758: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8038E75C: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x8038E760: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8038E764: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E768: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038E76C: lui         $t0, 0x600
    ctx->r8 = S32(0X600 << 16);
    // 0x8038E770: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E774: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x8038E778: addiu       $t3, $t3, 0x1
    ctx->r11 = ADD32(ctx->r11, 0X1);
    // 0x8038E77C: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8038E780: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x8038E784: addu        $t4, $t9, $s3
    ctx->r12 = ADD32(ctx->r25, ctx->r19);
    // 0x8038E788: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x8038E78C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038E790: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x8038E794: addiu       $t9, $t9, 0x6608
    ctx->r25 = ADD32(ctx->r25, 0X6608);
    // 0x8038E798: addu        $t5, $s0, $s2
    ctx->r13 = ADD32(ctx->r16, ctx->r18);
    // 0x8038E79C: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x8038E7A0: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x8038E7A4: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038E7A8: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x8038E7AC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E7B0: andi        $t6, $t3, 0xFF
    ctx->r14 = ctx->r11 & 0XFF;
    // 0x8038E7B4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038E7B8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038E7BC: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8038E7C0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038E7C4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x8038E7C8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038E7CC: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x8038E7D0: addiu       $t8, $t8, 0x66B8
    ctx->r24 = ADD32(ctx->r24, 0X66B8);
    // 0x8038E7D4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038E7D8: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038E7DC: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038E7E0: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x8038E7E4: sh          $t6, 0x66E0($at)
    MEM_H(0X66E0, ctx->r1) = ctx->r14;
    // 0x8038E7E8: jal         0x8038DF18
    // 0x8038E7EC: lhu         $a0, 0x62($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X62);
    spin_dna_helixes(rdram, ctx);
        goto after_3;
    // 0x8038E7EC: lhu         $a0, 0x62($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X62);
    after_3:
    // 0x8038E7F0: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8038E7F4: lw          $s0, 0x2C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X2C);
    // 0x8038E7F8: lw          $s1, 0x30($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X30);
    // 0x8038E7FC: lw          $s2, 0x34($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X34);
    // 0x8038E800: lw          $s3, 0x38($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X38);
    // 0x8038E804: jr          $ra
    // 0x8038E808: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x8038E808: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void step_terminal_dna_simulation(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038E80C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038E810: lh          $t6, 0x6674($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6674);
    // 0x8038E814: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038E818: lbu         $v0, 0x66E4($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X66E4);
    // 0x8038E81C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038E820: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8038E824: andi        $t8, $t7, 0x1FF
    ctx->r24 = ctx->r15 & 0X1FF;
    // 0x8038E828: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038E82C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038E830: beq         $v0, $zero, L_8038E844
    if (ctx->r2 == 0) {
        // 0x8038E834: sh          $t8, 0x6674($at)
        MEM_H(0X6674, ctx->r1) = ctx->r24;
            goto L_8038E844;
    }
    // 0x8038E834: sh          $t8, 0x6674($at)
    MEM_H(0X6674, ctx->r1) = ctx->r24;
    // 0x8038E838: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8038E83C: b           L_8038E84C
    // 0x8038E840: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
        goto L_8038E84C;
    // 0x8038E840: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
L_8038E844:
    // 0x8038E844: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8038E848: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
L_8038E84C:
    // 0x8038E84C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038E850: sb          $v0, 0x66E4($at)
    MEM_B(0X66E4, ctx->r1) = ctx->r2;
    // 0x8038E854: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E858: ldc1        $f14, 0x150($at)
    CHECK_FR(ctx, 14);
    ctx->f14.u64 = LD(ctx->r1, 0X150);
    // 0x8038E85C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038E860: ldc1        $f12, 0x158($at)
    CHECK_FR(ctx, 12);
    ctx->f12.u64 = LD(ctx->r1, 0X158);
    // 0x8038E864: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x8038E868: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038E86C: mtc1        $at, $f3
    ctx->f_odd[(3 - 1) * 2] = ctx->r1;
    // 0x8038E870: mtc1        $zero, $f2
    ctx->f2.u32l = 0;
    // 0x8038E874: addiu       $t0, $t0, 0x6570
    ctx->r8 = ADD32(ctx->r8, 0X6570);
    // 0x8038E878: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038E87C: sll         $a3, $v0, 3
    ctx->r7 = S32(ctx->r2 << 3);
    // 0x8038E880: sll         $t1, $t2, 3
    ctx->r9 = S32(ctx->r10 << 3);
L_8038E884:
    // 0x8038E884: addiu       $a0, $a2, 0x1
    ctx->r4 = ADD32(ctx->r6, 0X1);
    // 0x8038E888: andi        $t9, $a0, 0xF
    ctx->r25 = ctx->r4 & 0XF;
    // 0x8038E88C: addiu       $t6, $a2, -0x1
    ctx->r14 = ADD32(ctx->r6, -0X1);
    // 0x8038E890: andi        $t7, $t6, 0xF
    ctx->r15 = ctx->r14 & 0XF;
    // 0x8038E894: sll         $t3, $t9, 4
    ctx->r11 = S32(ctx->r25 << 4);
    // 0x8038E898: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x8038E89C: sll         $t8, $t7, 4
    ctx->r24 = S32(ctx->r15 << 4);
    // 0x8038E8A0: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x8038E8A4: addu        $t3, $t9, $a3
    ctx->r11 = ADD32(ctx->r25, ctx->r7);
    // 0x8038E8A8: addu        $t5, $t4, $a3
    ctx->r13 = ADD32(ctx->r12, ctx->r7);
    // 0x8038E8AC: lwc1        $f4, 0x0($t5)
    ctx->f4.u32l = MEM_W(ctx->r13, 0X0);
    // 0x8038E8B0: lwc1        $f6, 0x0($t3)
    ctx->f6.u32l = MEM_W(ctx->r11, 0X0);
    // 0x8038E8B4: sll         $t4, $a2, 4
    ctx->r12 = S32(ctx->r6 << 4);
    // 0x8038E8B8: addu        $a1, $t0, $t4
    ctx->r5 = ADD32(ctx->r8, ctx->r12);
    // 0x8038E8BC: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x8038E8C0: addu        $v1, $a1, $a3
    ctx->r3 = ADD32(ctx->r5, ctx->r7);
    // 0x8038E8C4: lwc1        $f18, 0x0($v1)
    ctx->f18.u32l = MEM_W(ctx->r3, 0X0);
    // 0x8038E8C8: addu        $v0, $a1, $t1
    ctx->r2 = ADD32(ctx->r5, ctx->r9);
    // 0x8038E8CC: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x8038E8D0: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x8038E8D4: mul.d       $f16, $f10, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f2.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f2.d);
    // 0x8038E8D8: lwc1        $f10, 0x4($v1)
    ctx->f10.u32l = MEM_W(ctx->r3, 0X4);
    // 0x8038E8DC: sra         $t5, $a2, 16
    ctx->r13 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8038E8E0: slti        $at, $t5, 0x10
    ctx->r1 = SIGNED(ctx->r13) < 0X10 ? 1 : 0;
    // 0x8038E8E4: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    // 0x8038E8E8: cvt.s.d     $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f0.fl = CVT_S_D(ctx->f16.d);
    // 0x8038E8EC: cvt.d.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f16.d = CVT_D_S(ctx->f10.fl);
    // 0x8038E8F0: sub.s       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f0.fl - ctx->f18.fl;
    // 0x8038E8F4: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x8038E8F8: mul.d       $f8, $f6, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f12.d); 
    ctx->f8.d = MUL_D(ctx->f6.d, ctx->f12.d);
    // 0x8038E8FC: nop

    // 0x8038E900: mul.d       $f18, $f16, $f14
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f14.d); 
    ctx->f18.d = MUL_D(ctx->f16.d, ctx->f14.d);
    // 0x8038E904: add.d       $f4, $f8, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f8.d + ctx->f18.d;
    // 0x8038E908: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x8038E90C: swc1        $f6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->f6.u32l;
    // 0x8038E910: lwc1        $f16, 0x0($v1)
    ctx->f16.u32l = MEM_W(ctx->r3, 0X0);
    // 0x8038E914: lwc1        $f10, 0x4($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0X4);
    // 0x8038E918: add.s       $f8, $f10, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = ctx->f10.fl + ctx->f16.fl;
    // 0x8038E91C: bne         $at, $zero, L_8038E884
    if (ctx->r1 != 0) {
        // 0x8038E920: swc1        $f8, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->f8.u32l;
            goto L_8038E884;
    }
    // 0x8038E920: swc1        $f8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f8.u32l;
    // 0x8038E924: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x8038E928: jal         0x8012826C
    // 0x8038E92C: sb          $t2, 0x27($sp)
    MEM_B(0X27, ctx->r29) = ctx->r10;
    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x8038E92C: sb          $t2, 0x27($sp)
    MEM_B(0X27, ctx->r29) = ctx->r10;
    after_0:
    // 0x8038E930: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038E934: andi        $t6, $v0, 0xFF00
    ctx->r14 = ctx->r2 & 0XFF00;
    // 0x8038E938: addiu       $at, $zero, 0x3400
    ctx->r1 = ADD32(0, 0X3400);
    // 0x8038E93C: addiu       $t0, $t0, 0x6570
    ctx->r8 = ADD32(ctx->r8, 0X6570);
    // 0x8038E940: lw          $t1, 0x1C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X1C);
    // 0x8038E944: bne         $t6, $at, L_8038E994
    if (ctx->r14 != ctx->r1) {
        // 0x8038E948: lbu         $t2, 0x27($sp)
        ctx->r10 = MEM_BU(ctx->r29, 0X27);
            goto L_8038E994;
    }
    // 0x8038E948: lbu         $t2, 0x27($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X27);
    // 0x8038E94C: sra         $t3, $v0, 4
    ctx->r11 = S32(SIGNED(ctx->r2) >> 4);
    // 0x8038E950: andi        $t4, $t3, 0xF
    ctx->r12 = ctx->r11 & 0XF;
    // 0x8038E954: addiu       $t5, $t4, -0x7
    ctx->r13 = ADD32(ctx->r12, -0X7);
    // 0x8038E958: mtc1        $t5, $f18
    ctx->f18.u32l = ctx->r13;
    // 0x8038E95C: lui         $at, 0x4024
    ctx->r1 = S32(0X4024 << 16);
    // 0x8038E960: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x8038E964: cvt.d.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.d = CVT_D_W(ctx->f18.u32l);
    // 0x8038E968: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x8038E96C: andi        $t7, $v0, 0xF
    ctx->r15 = ctx->r2 & 0XF;
    // 0x8038E970: sll         $t8, $t7, 4
    ctx->r24 = S32(ctx->r15 << 4);
    // 0x8038E974: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x8038E978: mul.d       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = MUL_D(ctx->f4.d, ctx->f6.d);
    // 0x8038E97C: addu        $v1, $t9, $t1
    ctx->r3 = ADD32(ctx->r25, ctx->r9);
    // 0x8038E980: lwc1        $f16, 0x4($v1)
    ctx->f16.u32l = MEM_W(ctx->r3, 0X4);
    // 0x8038E984: cvt.d.s     $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f8.d = CVT_D_S(ctx->f16.fl);
    // 0x8038E988: add.d       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = ctx->f8.d + ctx->f10.d;
    // 0x8038E98C: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x8038E990: swc1        $f4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->f4.u32l;
L_8038E994:
    // 0x8038E994: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038E998: lh          $t6, 0x6674($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6674);
    // 0x8038E99C: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x8038E9A0: lui         $at, 0x4069
    ctx->r1 = S32(0X4069 << 16);
    // 0x8038E9A4: sra         $t9, $t6, 1
    ctx->r25 = S32(SIGNED(ctx->r14) >> 1);
    // 0x8038E9A8: andi        $t3, $t9, 0xFF
    ctx->r11 = ctx->r25 & 0XFF;
    // 0x8038E9AC: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x8038E9B0: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x8038E9B4: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x8038E9B8: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x8038E9BC: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8038E9C0: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x8038E9C4: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x8038E9C8: addu        $v1, $t0, $t1
    ctx->r3 = ADD32(ctx->r8, ctx->r9);
    // 0x8038E9CC: lwc1        $f18, 0x84($v1)
    ctx->f18.u32l = MEM_W(ctx->r3, 0X84);
    // 0x8038E9D0: cvt.d.w     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    ctx->f16.d = CVT_D_W(ctx->f6.u32l);
    // 0x8038E9D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038E9D8: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x8038E9DC: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    // 0x8038E9E0: cvt.d.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f4.d = CVT_D_S(ctx->f18.fl);
    // 0x8038E9E4: div.d       $f10, $f16, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f16.d, ctx->f8.d);
    // 0x8038E9E8: add.d       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f10.d); 
    ctx->f6.d = ctx->f4.d + ctx->f10.d;
    // 0x8038E9EC: cvt.s.d     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f16.fl = CVT_S_D(ctx->f6.d);
    // 0x8038E9F0: jr          $ra
    // 0x8038E9F4: swc1        $f16, 0x84($v1)
    MEM_W(0X84, ctx->r3) = ctx->f16.u32l;
    return;
    // 0x8038E9F4: swc1        $f16, 0x84($v1)
    MEM_W(0X84, ctx->r3) = ctx->f16.u32l;
;}
RECOMP_FUNC void render_terminal_background_frame(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038E9F8: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x8038E9FC: sw          $s1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r17;
    // 0x8038EA00: sw          $s0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r16;
    // 0x8038EA04: lui         $s0, 0x8020
    ctx->r16 = S32(0X8020 << 16);
    // 0x8038EA08: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x8038EA0C: addiu       $s1, $s1, -0x6184
    ctx->r17 = ADD32(ctx->r17, -0X6184);
    // 0x8038EA10: addiu       $s0, $s0, 0x4278
    ctx->r16 = ADD32(ctx->r16, 0X4278);
    // 0x8038EA14: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8038EA18: sdc1        $f20, 0x28($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X28, ctx->r29);
    // 0x8038EA1C: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x8038EA20: jal         0x80129300
    // 0x8038EA24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    load_segments(rdram, ctx);
        goto after_0;
    // 0x8038EA24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_0:
    // 0x8038EA28: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038EA2C: jal         0x80380490
    // 0x8038EA30: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    switch_to_current_segment(rdram, ctx);
        goto after_1;
    // 0x8038EA30: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    after_1:
    // 0x8038EA34: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EA38: lui         $t7, 0x380
    ctx->r15 = S32(0X380 << 16);
    // 0x8038EA3C: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8038EA40: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038EA44: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038EA48: addiu       $t8, $t8, 0x2EA8
    ctx->r24 = ADD32(ctx->r24, 0X2EA8);
    // 0x8038EA4C: ori         $t7, $t7, 0x10
    ctx->r15 = ctx->r15 | 0X10;
    // 0x8038EA50: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038EA54: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8038EA58: jal         0x80129430
    // 0x8038EA5C: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    clear_depth_buffer(rdram, ctx);
        goto after_2;
    // 0x8038EA5C: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    after_2:
    // 0x8038EA60: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EA64: lui         $t2, 0xFF10
    ctx->r10 = S32(0XFF10 << 16);
    // 0x8038EA68: ori         $t2, $t2, 0x13F
    ctx->r10 = ctx->r10 | 0X13F;
    // 0x8038EA6C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x8038EA70: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8038EA74: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x8038EA78: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x8038EA7C: lw          $t3, 0x4274($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X4274);
    // 0x8038EA80: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x8038EA84: addu        $a0, $a0, $t3
    ctx->r4 = ADD32(ctx->r4, ctx->r11);
    // 0x8038EA88: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x8038EA8C: jal         0x80138130
    // 0x8038EA90: sw          $s0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_3;
    // 0x8038EA90: sw          $s0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r16;
    after_3:
    // 0x8038EA94: lw          $a2, 0x5C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X5C);
    // 0x8038EA98: lui         $t5, 0xED02
    ctx->r13 = S32(0XED02 << 16);
    // 0x8038EA9C: ori         $t5, $t5, 0x20
    ctx->r13 = ctx->r13 | 0X20;
    // 0x8038EAA0: sw          $v0, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r2;
    // 0x8038EAA4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EAA8: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8038EAAC: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8038EAB0: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x8038EAB4: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x8038EAB8: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8038EABC: lh          $t6, 0x3FD0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X3FD0);
    // 0x8038EAC0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x8038EAC4: lh          $t4, 0x3FD2($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD2);
    // 0x8038EAC8: addiu       $t7, $t6, -0x8
    ctx->r15 = ADD32(ctx->r14, -0X8);
    // 0x8038EACC: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x8038EAD0: addiu       $t5, $t4, -0x8
    ctx->r13 = ADD32(ctx->r12, -0X8);
    // 0x8038EAD4: mtc1        $t5, $f16
    ctx->f16.u32l = ctx->r13;
    // 0x8038EAD8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038EADC: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038EAE0: lui         $t5, 0xF400
    ctx->r13 = S32(0XF400 << 16);
    // 0x8038EAE4: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x8038EAE8: ori         $t4, $t4, 0x8
    ctx->r12 = ctx->r12 | 0X8;
    // 0x8038EAEC: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8038EAF0: mul.s       $f8, $f6, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f20.fl);
    // 0x8038EAF4: ori         $t5, $t5, 0xAA00
    ctx->r13 = ctx->r13 | 0XAA00;
    // 0x8038EAF8: mul.s       $f4, $f18, $f20
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f20.fl);
    // 0x8038EAFC: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8038EB00: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8038EB04: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x8038EB08: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8038EB0C: andi        $t2, $t9, 0xFFF
    ctx->r10 = ctx->r25 & 0XFFF;
    // 0x8038EB10: sll         $t3, $t2, 12
    ctx->r11 = S32(ctx->r10 << 12);
    // 0x8038EB14: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8038EB18: or          $t9, $t3, $t8
    ctx->r25 = ctx->r11 | ctx->r24;
    // 0x8038EB1C: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x8038EB20: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EB24: lui         $t7, 0xF800
    ctx->r15 = S32(0XF800 << 16);
    // 0x8038EB28: lui         $t3, 0x803B
    ctx->r11 = S32(0X803B << 16);
    // 0x8038EB2C: addiu       $t2, $s0, 0x8
    ctx->r10 = ADD32(ctx->r16, 0X8);
    // 0x8038EB30: sw          $t2, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r10;
    // 0x8038EB34: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x8038EB38: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8038EB3C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EB40: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8038EB44: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038EB48: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x8038EB4C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8038EB50: lh          $t3, 0x6314($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X6314);
    // 0x8038EB54: bne         $t3, $zero, L_8038EBA8
    if (ctx->r11 != 0) {
        // 0x8038EB58: lui         $at, 0x3F80
        ctx->r1 = S32(0X3F80 << 16);
            goto L_8038EBA8;
    }
    // 0x8038EB58: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038EB5C: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8038EB60: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x8038EB64: jal         0x8013385C
    // 0x8038EB68: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_4;
    // 0x8038EB68: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    after_4:
    // 0x8038EB6C: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8038EB70: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8038EB74: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x8038EB78: addiu       $s0, $s0, 0x646C
    ctx->r16 = ADD32(ctx->r16, 0X646C);
    // 0x8038EB7C: addiu       $v1, $v1, 0x6470
    ctx->r3 = ADD32(ctx->r3, 0X6470);
    // 0x8038EB80: sh          $zero, 0x0($v1)
    MEM_H(0X0, ctx->r3) = 0;
    // 0x8038EB84: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x8038EB88: swc1        $f8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f8.u32l;
    // 0x8038EB8C: lb          $t8, 0x1090($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X1090);
    // 0x8038EB90: beq         $t8, $zero, L_8038EBA8
    if (ctx->r24 == 0) {
        // 0x8038EB94: nop
    
            goto L_8038EBA8;
    }
    // 0x8038EB94: nop

    // 0x8038EB98: jal         0x80137168
    // 0x8038EB9C: nop

    func_80137168(rdram, ctx);
        goto after_5;
    // 0x8038EB9C: nop

    after_5:
    // 0x8038EBA0: jal         0x8013724C
    // 0x8038EBA4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8013724C(rdram, ctx);
        goto after_6;
    // 0x8038EBA4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_6:
L_8038EBA8:
    // 0x8038EBA8: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8038EBAC: addiu       $v1, $v1, 0x6470
    ctx->r3 = ADD32(ctx->r3, 0X6470);
    // 0x8038EBB0: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x8038EBB4: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x8038EBB8: addiu       $s0, $s0, 0x646C
    ctx->r16 = ADD32(ctx->r16, 0X646C);
    // 0x8038EBBC: slti        $at, $v0, 0x64
    ctx->r1 = SIGNED(ctx->r2) < 0X64 ? 1 : 0;
    // 0x8038EBC0: beq         $at, $zero, L_8038EBD0
    if (ctx->r1 == 0) {
        // 0x8038EBC4: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_8038EBD0;
    }
    // 0x8038EBC4: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x8038EBC8: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    // 0x8038EBCC: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
L_8038EBD0:
    // 0x8038EBD0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038EBD4: bne         $v0, $at, L_8038EC04
    if (ctx->r2 != ctx->r1) {
        // 0x8038EBD8: lui         $t2, 0x803F
        ctx->r10 = S32(0X803F << 16);
            goto L_8038EC04;
    }
    // 0x8038EBD8: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8038EBDC: lbu         $t2, 0x2AA2($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X2AA2);
    // 0x8038EBE0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8038EBE4: addiu       $a0, $zero, 0x87
    ctx->r4 = ADD32(0, 0X87);
    // 0x8038EBE8: bne         $t2, $at, L_8038EC04
    if (ctx->r10 != ctx->r1) {
        // 0x8038EBEC: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_8038EC04;
    }
    // 0x8038EBEC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038EBF0: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8038EBF4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8038EBF8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8038EBFC: jal         0x8013307C
    // 0x8038EC00: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_7;
    // 0x8038EC00: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_7:
L_8038EC04:
    // 0x8038EC04: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x8038EC08: lh          $t5, 0x6314($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X6314);
    // 0x8038EC0C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038EC10: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038EC14: slti        $at, $t5, 0x2
    ctx->r1 = SIGNED(ctx->r13) < 0X2 ? 1 : 0;
    // 0x8038EC18: beq         $at, $zero, L_8038EC58
    if (ctx->r1 == 0) {
        // 0x8038EC1C: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8038EC58;
    }
    // 0x8038EC1C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038EC20: addiu       $t6, $zero, 0xF0
    ctx->r14 = ADD32(0, 0XF0);
    // 0x8038EC24: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8038EC28: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x8038EC2C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8038EC30: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x8038EC34: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8038EC38: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038EC3C: jal         0x8012AD30
    // 0x8038EC40: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_8;
    // 0x8038EC40: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_8:
    // 0x8038EC44: lui         $t3, 0x803B
    ctx->r11 = S32(0X803B << 16);
    // 0x8038EC48: lh          $t3, 0x6314($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X6314);
    // 0x8038EC4C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038EC50: addiu       $t8, $t3, 0x1
    ctx->r24 = ADD32(ctx->r11, 0X1);
    // 0x8038EC54: sh          $t8, 0x6314($at)
    MEM_H(0X6314, ctx->r1) = ctx->r24;
L_8038EC58:
    // 0x8038EC58: lui         $at, 0x45C0
    ctx->r1 = S32(0X45C0 << 16);
    // 0x8038EC5C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8038EC60: lwc1        $f16, 0x0($s0)
    ctx->f16.u32l = MEM_W(ctx->r16, 0X0);
    // 0x8038EC64: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038EC68: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8038EC6C: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x8038EC70: addiu       $a0, $zero, 0x45
    ctx->r4 = ADD32(0, 0X45);
    // 0x8038EC74: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x8038EC78: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038EC7C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8038EC80: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x8038EC84: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x8038EC88: nop

    // 0x8038EC8C: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x8038EC90: jal         0x8032CD20
    // 0x8038EC94: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_9;
    // 0x8038EC94: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    after_9:
    // 0x8038EC98: lui         $at, 0x4588
    ctx->r1 = S32(0X4588 << 16);
    // 0x8038EC9C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8038ECA0: lwc1        $f10, 0x0($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X0);
    // 0x8038ECA4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038ECA8: lwc1        $f4, 0x160($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X160);
    // 0x8038ECAC: mul.s       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f8.fl, ctx->f10.fl);
    // 0x8038ECB0: addiu       $a0, $zero, 0xA9
    ctx->r4 = ADD32(0, 0XA9);
    // 0x8038ECB4: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x8038ECB8: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038ECBC: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8038ECC0: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8038ECC4: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
    // 0x8038ECC8: nop

    // 0x8038ECCC: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x8038ECD0: jal         0x8032CD20
    // 0x8038ECD4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_10;
    // 0x8038ECD4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    after_10:
    // 0x8038ECD8: lui         $at, 0x4588
    ctx->r1 = S32(0X4588 << 16);
    // 0x8038ECDC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8038ECE0: lwc1        $f8, 0x0($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X0);
    // 0x8038ECE4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038ECE8: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8038ECEC: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x8038ECF0: addiu       $a0, $zero, 0x171
    ctx->r4 = ADD32(0, 0X171);
    // 0x8038ECF4: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x8038ECF8: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038ECFC: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8038ED00: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8038ED04: mfc1        $a2, $f16
    ctx->r6 = (int32_t)ctx->f16.u32l;
    // 0x8038ED08: nop

    // 0x8038ED0C: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8038ED10: jal         0x8032CD20
    // 0x8038ED14: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_11;
    // 0x8038ED14: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    after_11:
    // 0x8038ED18: lui         $at, 0x46AA
    ctx->r1 = S32(0X46AA << 16);
    // 0x8038ED1C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038ED20: lwc1        $f6, 0x0($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X0);
    // 0x8038ED24: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038ED28: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8038ED2C: mul.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x8038ED30: addiu       $a0, $zero, 0x10D
    ctx->r4 = ADD32(0, 0X10D);
    // 0x8038ED34: addiu       $a1, $zero, 0x86
    ctx->r5 = ADD32(0, 0X86);
    // 0x8038ED38: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038ED3C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x8038ED40: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8038ED44: mfc1        $a2, $f10
    ctx->r6 = (int32_t)ctx->f10.u32l;
    // 0x8038ED48: nop

    // 0x8038ED4C: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x8038ED50: jal         0x8032CD20
    // 0x8038ED54: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_12;
    // 0x8038ED54: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    after_12:
    // 0x8038ED58: lwc1        $f18, 0x0($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X0);
    // 0x8038ED5C: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x8038ED60: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x8038ED64: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x8038ED68: cvt.d.s     $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f0.d = CVT_D_S(ctx->f18.fl);
    // 0x8038ED6C: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x8038ED70: c.lt.d      $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f0.d < ctx->f4.d;
    // 0x8038ED74: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8038ED78: addiu       $a3, $a3, 0x6472
    ctx->r7 = ADD32(ctx->r7, 0X6472);
    // 0x8038ED7C: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x8038ED80: bc1f        L_8038ED98
    if (!c1cs) {
        // 0x8038ED84: lui         $at, 0x803C
        ctx->r1 = S32(0X803C << 16);
            goto L_8038ED98;
    }
    // 0x8038ED84: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038ED88: ldc1        $f6, 0x168($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, 0X168);
    // 0x8038ED8C: add.d       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f0.d + ctx->f6.d;
    // 0x8038ED90: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x8038ED94: swc1        $f10, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f10.u32l;
L_8038ED98:
    // 0x8038ED98: lbu         $v0, 0x0($a3)
    ctx->r2 = MEM_BU(ctx->r7, 0X0);
    // 0x8038ED9C: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8038EDA0: addiu       $t0, $t0, 0x3FD2
    ctx->r8 = ADD32(ctx->r8, 0X3FD2);
    // 0x8038EDA4: sll         $t8, $v0, 1
    ctx->r24 = S32(ctx->r2 << 1);
    // 0x8038EDA8: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8038EDAC: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8038EDB0: addu        $t4, $a2, $t2
    ctx->r12 = ADD32(ctx->r6, ctx->r10);
    // 0x8038EDB4: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x8038EDB8: addiu       $t6, $zero, 0xF0
    ctx->r14 = ADD32(0, 0XF0);
    // 0x8038EDBC: sh          $t6, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r14;
    // 0x8038EDC0: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x8038EDC4: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x8038EDC8: lui         $at, 0x40A9
    ctx->r1 = S32(0X40A9 << 16);
    // 0x8038EDCC: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x8038EDD0: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x8038EDD4: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x8038EDD8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038EDDC: ldc1        $f8, 0x170($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, 0X170);
    // 0x8038EDE0: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x8038EDE4: div.d       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = DIV_D(ctx->f18.d, ctx->f4.d);
    // 0x8038EDE8: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038EDEC: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8038EDF0: addu        $t2, $a2, $t9
    ctx->r10 = ADD32(ctx->r6, ctx->r25);
    // 0x8038EDF4: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8038EDF8: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x8038EDFC: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x8038EE00: addiu       $t1, $t1, 0x2EA8
    ctx->r9 = ADD32(ctx->r9, 0X2EA8);
    // 0x8038EE04: add.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = ctx->f6.d + ctx->f8.d;
    // 0x8038EE08: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x8038EE0C: cvt.s.d     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f16.fl = CVT_S_D(ctx->f10.d);
    // 0x8038EE10: swc1        $f16, 0x6CC4($at)
    MEM_W(0X6CC4, ctx->r1) = ctx->f16.u32l;
    // 0x8038EE14: lh          $t4, 0x0($t2)
    ctx->r12 = MEM_H(ctx->r10, 0X0);
    // 0x8038EE18: lui         $at, 0x402E
    ctx->r1 = S32(0X402E << 16);
    // 0x8038EE1C: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x8038EE20: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x8038EE24: mtc1        $t5, $f18
    ctx->f18.u32l = ctx->r13;
    // 0x8038EE28: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038EE2C: ldc1        $f10, 0x178($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, 0X178);
    // 0x8038EE30: cvt.d.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.d = CVT_D_W(ctx->f18.u32l);
    // 0x8038EE34: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038EE38: div.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = DIV_D(ctx->f4.d, ctx->f6.d);
    // 0x8038EE3C: add.d       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f16.d = ctx->f8.d + ctx->f10.d;
    // 0x8038EE40: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x8038EE44: swc1        $f18, 0x6CC8($at)
    MEM_W(0X6CC8, ctx->r1) = ctx->f18.u32l;
    // 0x8038EE48: sb          $t6, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r14;
    // 0x8038EE4C: lh          $a0, 0x3FD0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X3FD0);
    // 0x8038EE50: lh          $a1, 0x0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X0);
    // 0x8038EE54: sll         $t7, $a0, 1
    ctx->r15 = S32(ctx->r4 << 1);
    // 0x8038EE58: sll         $t3, $a1, 1
    ctx->r11 = S32(ctx->r5 << 1);
    // 0x8038EE5C: sh          $t7, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r15;
    // 0x8038EE60: sh          $t3, 0x2($t1)
    MEM_H(0X2, ctx->r9) = ctx->r11;
    // 0x8038EE64: sh          $t7, 0x8($t1)
    MEM_H(0X8, ctx->r9) = ctx->r15;
    // 0x8038EE68: jal         0x8038CF90
    // 0x8038EE6C: sh          $t3, 0xA($t1)
    MEM_H(0XA, ctx->r9) = ctx->r11;
    func_8038CF90_79E640(rdram, ctx);
        goto after_13;
    // 0x8038EE6C: sh          $t3, 0xA($t1)
    MEM_H(0XA, ctx->r9) = ctx->r11;
    after_13:
    // 0x8038EE70: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x8038EE74: lbu         $t8, 0x6318($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X6318);
    // 0x8038EE78: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038EE7C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038EE80: bne         $t8, $zero, L_8038EEC0
    if (ctx->r24 != 0) {
        // 0x8038EE84: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8038EEC0;
    }
    // 0x8038EE84: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038EE88: addiu       $t9, $zero, 0xF0
    ctx->r25 = ADD32(0, 0XF0);
    // 0x8038EE8C: addiu       $t2, $zero, 0x4B
    ctx->r10 = ADD32(0, 0X4B);
    // 0x8038EE90: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x8038EE94: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038EE98: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038EE9C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038EEA0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038EEA4: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x8038EEA8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8038EEAC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038EEB0: jal         0x8012AD30
    // 0x8038EEB4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_14;
    // 0x8038EEB4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_14:
    // 0x8038EEB8: b           L_8038EEE4
    // 0x8038EEBC: nop

        goto L_8038EEE4;
    // 0x8038EEBC: nop

L_8038EEC0:
    // 0x8038EEC0: addiu       $t4, $zero, 0xF0
    ctx->r12 = ADD32(0, 0XF0);
    // 0x8038EEC4: addiu       $t5, $zero, 0x64
    ctx->r13 = ADD32(0, 0X64);
    // 0x8038EEC8: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x8038EECC: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8038EED0: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x8038EED4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8038EED8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038EEDC: jal         0x8012AD30
    // 0x8038EEE0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_15;
    // 0x8038EEE0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_15:
L_8038EEE4:
    // 0x8038EEE4: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x8038EEE8: lbu         $v1, 0x6318($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X6318);
    // 0x8038EEEC: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
    // 0x8038EEF0: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8038EEF4: beq         $v1, $zero, L_8038EF18
    if (ctx->r3 == 0) {
        // 0x8038EEF8: nop
    
            goto L_8038EF18;
    }
    // 0x8038EEF8: nop

    // 0x8038EEFC: beq         $v1, $s0, L_8038EF80
    if (ctx->r3 == ctx->r16) {
        // 0x8038EF00: addiu       $t3, $zero, 0x140
        ctx->r11 = ADD32(0, 0X140);
            goto L_8038EF80;
    }
    // 0x8038EF00: addiu       $t3, $zero, 0x140
    ctx->r11 = ADD32(0, 0X140);
    // 0x8038EF04: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038EF08: beq         $v1, $at, L_8038F334
    if (ctx->r3 == ctx->r1) {
        // 0x8038EF0C: lui         $v0, 0x803B
        ctx->r2 = S32(0X803B << 16);
            goto L_8038F334;
    }
    // 0x8038EF0C: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038EF10: b           L_8038F3DC
    // 0x8038EF14: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
        goto L_8038F3DC;
    // 0x8038EF14: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
L_8038EF18:
    // 0x8038EF18: lh          $v0, 0x3FD0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X3FD0);
    // 0x8038EF1C: slti        $at, $v0, 0x140
    ctx->r1 = SIGNED(ctx->r2) < 0X140 ? 1 : 0;
    // 0x8038EF20: beq         $at, $zero, L_8038EF30
    if (ctx->r1 == 0) {
        // 0x8038EF24: addiu       $t6, $v0, 0x2
        ctx->r14 = ADD32(ctx->r2, 0X2);
            goto L_8038EF30;
    }
    // 0x8038EF24: addiu       $t6, $v0, 0x2
    ctx->r14 = ADD32(ctx->r2, 0X2);
    // 0x8038EF28: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038EF2C: sh          $t6, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r14;
L_8038EF30:
    // 0x8038EF30: jal         0x8038D920
    // 0x8038EF34: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    update_terminal_scene_lighting(rdram, ctx);
        goto after_16;
    // 0x8038EF34: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    after_16:
    // 0x8038EF38: jal         0x8038DA70
    // 0x8038EF3C: nop

    render_terminal_background_scene(rdram, ctx);
        goto after_17;
    // 0x8038EF3C: nop

    after_17:
    // 0x8038EF40: lui         $s0, 0x803B
    ctx->r16 = S32(0X803B << 16);
    // 0x8038EF44: addiu       $s0, $s0, 0x6310
    ctx->r16 = ADD32(ctx->r16, 0X6310);
    // 0x8038EF48: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x8038EF4C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038EF50: slti        $v1, $v0, 0x29
    ctx->r3 = SIGNED(ctx->r2) < 0X29 ? 1 : 0;
    // 0x8038EF54: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x8038EF58: bne         $v1, $zero, L_8038EF74
    if (ctx->r3 != 0) {
        // 0x8038EF5C: sh          $t7, 0x0($s0)
        MEM_H(0X0, ctx->r16) = ctx->r15;
            goto L_8038EF74;
    }
    // 0x8038EF5C: sh          $t7, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r15;
    // 0x8038EF60: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038EF64: sb          $v1, 0x631C($at)
    MEM_B(0X631C, ctx->r1) = ctx->r3;
    // 0x8038EF68: sh          $zero, 0x0($s0)
    MEM_H(0X0, ctx->r16) = 0;
    // 0x8038EF6C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038EF70: sb          $v1, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = ctx->r3;
L_8038EF74:
    // 0x8038EF74: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038EF78: b           L_8038F3DC
    // 0x8038EF7C: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
        goto L_8038F3DC;
    // 0x8038EF7C: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
L_8038EF80:
    // 0x8038EF80: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038EF84: sh          $t3, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r11;
    // 0x8038EF88: jal         0x8012C1F0
    // 0x8038EF8C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    load_default_display_list(rdram, ctx);
        goto after_18;
    // 0x8038EF8C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_18:
    // 0x8038EF90: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8038EF94: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8038EF98: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8038EF9C: jal         0x8012C214
    // 0x8038EFA0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_19;
    // 0x8038EFA0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_19:
    // 0x8038EFA4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038EFA8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038EFAC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8038EFB0: jal         0x8012C248
    // 0x8038EFB4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_20;
    // 0x8038EFB4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_20:
    // 0x8038EFB8: jal         0x8038D920
    // 0x8038EFBC: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    update_terminal_scene_lighting(rdram, ctx);
        goto after_21;
    // 0x8038EFBC: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    after_21:
    // 0x8038EFC0: jal         0x8012826C
    // 0x8038EFC4: nop

    advance_random_seed(rdram, ctx);
        goto after_22;
    // 0x8038EFC4: nop

    after_22:
    // 0x8038EFC8: andi        $t9, $v0, 0x7
    ctx->r25 = ctx->r2 & 0X7;
    // 0x8038EFCC: sh          $t9, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r25;
    // 0x8038EFD0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_8038EFD4:
    // 0x8038EFD4: lh          $v1, 0x68($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X68);
    // 0x8038EFD8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038EFDC: sll         $t2, $a1, 2
    ctx->r10 = S32(ctx->r5 << 2);
    // 0x8038EFE0: addu        $t2, $t2, $a1
    ctx->r10 = ADD32(ctx->r10, ctx->r5);
    // 0x8038EFE4: sll         $t2, $t2, 3
    ctx->r10 = S32(ctx->r10 << 3);
    // 0x8038EFE8: lui         $t5, 0xFF10
    ctx->r13 = S32(0XFF10 << 16);
    // 0x8038EFEC: addu        $v0, $t2, $v1
    ctx->r2 = ADD32(ctx->r10, ctx->r3);
    // 0x8038EFF0: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x8038EFF4: sh          $v0, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r2;
    // 0x8038EFF8: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x8038EFFC: ori         $t5, $t5, 0x13F
    ctx->r13 = ctx->r13 | 0X13F;
    // 0x8038F000: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8038F004: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8038F008: lw          $t6, 0x4274($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4274);
    // 0x8038F00C: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x8038F010: sra         $t8, $t3, 16
    ctx->r24 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8038F014: lui         $t7, 0x4
    ctx->r15 = S32(0X4 << 16);
    // 0x8038F018: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x8038F01C: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8038F020: lw          $t7, -0x4418($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X4418);
    // 0x8038F024: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x8038F028: sll         $t2, $t9, 7
    ctx->r10 = S32(ctx->r25 << 7);
    // 0x8038F02C: sh          $a1, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r5;
    // 0x8038F030: sw          $s0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r16;
    // 0x8038F034: jal         0x80138130
    // 0x8038F038: addu        $a0, $t7, $t2
    ctx->r4 = ADD32(ctx->r15, ctx->r10);
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_23;
    // 0x8038F038: addu        $a0, $t7, $t2
    ctx->r4 = ADD32(ctx->r15, ctx->r10);
    after_23:
    // 0x8038F03C: lw          $a2, 0x4C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X4C);
    // 0x8038F040: lh          $a1, 0x6A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X6A);
    // 0x8038F044: lui         $t5, 0xED02
    ctx->r13 = S32(0XED02 << 16);
    // 0x8038F048: sw          $v0, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r2;
    // 0x8038F04C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038F050: ori         $t5, $t5, 0x20
    ctx->r13 = ctx->r13 | 0X20;
    // 0x8038F054: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8038F058: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x8038F05C: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x8038F060: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8038F064: lh          $t3, 0x66($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X66);
    // 0x8038F068: lh          $t6, 0x3FD2($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X3FD2);
    // 0x8038F06C: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8038F070: lh          $t5, 0x3FD0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD0);
    // 0x8038F074: subu        $t8, $t6, $t3
    ctx->r24 = SUB32(ctx->r14, ctx->r11);
    // 0x8038F078: addiu       $t9, $t8, -0x9
    ctx->r25 = ADD32(ctx->r24, -0X9);
    // 0x8038F07C: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8038F080: addiu       $t6, $t5, -0x8
    ctx->r14 = ADD32(ctx->r13, -0X8);
    // 0x8038F084: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x8038F088: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038F08C: lui         $t6, 0x600
    ctx->r14 = S32(0X600 << 16);
    // 0x8038F090: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x8038F094: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x8038F098: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8038F09C: mul.s       $f8, $f6, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f20.fl);
    // 0x8038F0A0: nop

    // 0x8038F0A4: mul.s       $f4, $f18, $f20
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f20.fl);
    // 0x8038F0A8: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8038F0AC: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8038F0B0: mfc1        $t2, $f10
    ctx->r10 = (int32_t)ctx->f10.u32l;
    // 0x8038F0B4: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x8038F0B8: andi        $t4, $t2, 0xFFF
    ctx->r12 = ctx->r10 & 0XFFF;
    // 0x8038F0BC: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8038F0C0: sll         $t7, $t9, 12
    ctx->r15 = S32(ctx->r25 << 12);
    // 0x8038F0C4: or          $t2, $t7, $t4
    ctx->r10 = ctx->r15 | ctx->r12;
    // 0x8038F0C8: sw          $t2, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r10;
    // 0x8038F0CC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038F0D0: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x8038F0D4: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038F0D8: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x8038F0DC: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x8038F0E0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8038F0E4: lw          $t3, -0x6170($t3)
    ctx->r11 = MEM_W(ctx->r11, -0X6170);
    // 0x8038F0E8: slti        $at, $a1, 0x6
    ctx->r1 = SIGNED(ctx->r5) < 0X6 ? 1 : 0;
    // 0x8038F0EC: bne         $at, $zero, L_8038EFD4
    if (ctx->r1 != 0) {
        // 0x8038F0F0: sw          $t3, 0x4($s0)
        MEM_W(0X4, ctx->r16) = ctx->r11;
            goto L_8038EFD4;
    }
    // 0x8038F0F0: sw          $t3, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r11;
    // 0x8038F0F4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038F0F8: lui         $t4, 0xFF10
    ctx->r12 = S32(0XFF10 << 16);
    // 0x8038F0FC: ori         $t4, $t4, 0x13F
    ctx->r12 = ctx->r12 | 0X13F;
    // 0x8038F100: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8038F104: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038F108: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8038F10C: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8038F110: lw          $t2, 0x4274($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X4274);
    // 0x8038F114: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x8038F118: addu        $a0, $a0, $t2
    ctx->r4 = ADD32(ctx->r4, ctx->r10);
    // 0x8038F11C: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x8038F120: jal         0x80138130
    // 0x8038F124: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_24;
    // 0x8038F124: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    after_24:
    // 0x8038F128: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x8038F12C: lui         $t6, 0xED02
    ctx->r14 = S32(0XED02 << 16);
    // 0x8038F130: ori         $t6, $t6, 0x20
    ctx->r14 = ctx->r14 | 0X20;
    // 0x8038F134: sw          $v0, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r2;
    // 0x8038F138: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038F13C: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x8038F140: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038F144: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x8038F148: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x8038F14C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8038F150: lh          $t3, 0x3FD0($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X3FD0);
    // 0x8038F154: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8038F158: lh          $t5, 0x3FD2($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD2);
    // 0x8038F15C: addiu       $t8, $t3, -0x8
    ctx->r24 = ADD32(ctx->r11, -0X8);
    // 0x8038F160: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x8038F164: addiu       $t6, $t5, -0x8
    ctx->r14 = ADD32(ctx->r13, -0X8);
    // 0x8038F168: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8038F16C: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8038F170: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8038F174: addiu       $a0, $a0, -0x6170
    ctx->r4 = ADD32(ctx->r4, -0X6170);
    // 0x8038F178: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038F17C: mul.s       $f16, $f10, $f20
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f16.fl = MUL_S(ctx->f10.fl, ctx->f20.fl);
    // 0x8038F180: nop

    // 0x8038F184: mul.s       $f8, $f6, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f20.fl);
    // 0x8038F188: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8038F18C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8038F190: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x8038F194: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x8038F198: andi        $t4, $t7, 0xFFF
    ctx->r12 = ctx->r15 & 0XFFF;
    // 0x8038F19C: sll         $t2, $t4, 12
    ctx->r10 = S32(ctx->r12 << 12);
    // 0x8038F1A0: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8038F1A4: or          $t7, $t2, $t9
    ctx->r15 = ctx->r10 | ctx->r25;
    // 0x8038F1A8: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x8038F1AC: jal         0x8038D004
    // 0x8038F1B0: lhu         $a1, 0x6310($a1)
    ctx->r5 = MEM_HU(ctx->r5, 0X6310);
    render_terminal_background_glyphs(rdram, ctx);
        goto after_25;
    // 0x8038F1B0: lhu         $a1, 0x6310($a1)
    ctx->r5 = MEM_HU(ctx->r5, 0X6310);
    after_25:
    // 0x8038F1B4: lui         $s0, 0x803B
    ctx->r16 = S32(0X803B << 16);
    // 0x8038F1B8: jal         0x8038DA70
    // 0x8038F1BC: addiu       $s0, $s0, 0x6310
    ctx->r16 = ADD32(ctx->r16, 0X6310);
    render_terminal_background_scene(rdram, ctx);
        goto after_26;
    // 0x8038F1BC: addiu       $s0, $s0, 0x6310
    ctx->r16 = ADD32(ctx->r16, 0X6310);
    after_26:
    // 0x8038F1C0: jal         0x8038E504
    // 0x8038F1C4: lhu         $a0, 0x0($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X0);
    render_terminal_background_dna_79FBB4(rdram, ctx);
        goto after_27;
    // 0x8038F1C4: lhu         $a0, 0x0($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X0);
    after_27:
    // 0x8038F1C8: jal         0x8012C1F0
    // 0x8038F1CC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    load_default_display_list(rdram, ctx);
        goto after_28;
    // 0x8038F1CC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_28:
    // 0x8038F1D0: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8038F1D4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8038F1D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038F1DC: jal         0x8012C214
    // 0x8038F1E0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_29;
    // 0x8038F1E0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_29:
    // 0x8038F1E4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F1E8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038F1EC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8038F1F0: jal         0x8012C248
    // 0x8038F1F4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_30;
    // 0x8038F1F4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_30:
    // 0x8038F1F8: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x8038F1FC: jal         0x8038DBE0
    // 0x8038F200: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    render_terminal_stat_text(rdram, ctx);
        goto after_31;
    // 0x8038F200: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_31:
    // 0x8038F204: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x8038F208: ori         $at, $zero, 0xFDE9
    ctx->r1 = 0 | 0XFDE9;
    // 0x8038F20C: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8038F210: slt         $v1, $v0, $at
    ctx->r3 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x8038F214: addiu       $t4, $v0, 0x1
    ctx->r12 = ADD32(ctx->r2, 0X1);
    // 0x8038F218: bne         $v1, $zero, L_8038F228
    if (ctx->r3 != 0) {
        // 0x8038F21C: sh          $t4, 0x0($s0)
        MEM_H(0X0, ctx->r16) = ctx->r12;
            goto L_8038F228;
    }
    // 0x8038F21C: sh          $t4, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r12;
    // 0x8038F220: addiu       $t5, $zero, 0xC8
    ctx->r13 = ADD32(0, 0XC8);
    // 0x8038F224: sh          $t5, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r13;
L_8038F228:
    // 0x8038F228: lw          $t6, 0x10D0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X10D0);
    // 0x8038F22C: lui         $t2, 0x803B
    ctx->r10 = S32(0X803B << 16);
    // 0x8038F230: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x8038F234: andi        $t3, $v0, 0x8000
    ctx->r11 = ctx->r2 & 0X8000;
    // 0x8038F238: bne         $t3, $zero, L_8038F248
    if (ctx->r11 != 0) {
        // 0x8038F23C: andi        $t8, $v0, 0x4000
        ctx->r24 = ctx->r2 & 0X4000;
            goto L_8038F248;
    }
    // 0x8038F23C: andi        $t8, $v0, 0x4000
    ctx->r24 = ctx->r2 & 0X4000;
    // 0x8038F240: beq         $t8, $zero, L_8038F328
    if (ctx->r24 == 0) {
        // 0x8038F244: nop
    
            goto L_8038F328;
    }
    // 0x8038F244: nop

L_8038F248:
    // 0x8038F248: lbu         $t2, 0x631C($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X631C);
    // 0x8038F24C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F250: lui         $a1, 0x41C8
    ctx->r5 = S32(0X41C8 << 16);
    // 0x8038F254: bne         $t2, $zero, L_8038F328
    if (ctx->r10 != 0) {
        // 0x8038F258: addiu       $a2, $zero, 0x0
        ctx->r6 = ADD32(0, 0X0);
            goto L_8038F328;
    }
    // 0x8038F258: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x8038F25C: jal         0x801337DC
    // 0x8038F260: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    start_sequence_volume_fade(rdram, ctx);
        goto after_32;
    // 0x8038F260: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    after_32:
    // 0x8038F264: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F268: sh          $zero, 0x6314($at)
    MEM_H(0X6314, ctx->r1) = 0;
    // 0x8038F26C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038F270: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F274: sb          $v1, 0x631C($at)
    MEM_B(0X631C, ctx->r1) = ctx->r3;
    // 0x8038F278: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F27C: sh          $zero, 0x0($s0)
    MEM_H(0X0, ctx->r16) = 0;
    // 0x8038F280: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F284: addiu       $v0, $v0, 0x2C6D
    ctx->r2 = ADD32(ctx->r2, 0X2C6D);
    // 0x8038F288: sb          $zero, 0x2D10($at)
    MEM_B(0X2D10, ctx->r1) = 0;
    // 0x8038F28C: sb          $zero, 0x0($v0)
    MEM_B(0X0, ctx->r2) = 0;
    // 0x8038F290: lb          $t9, 0x0($v0)
    ctx->r25 = MEM_B(ctx->r2, 0X0);
    // 0x8038F294: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F298: addiu       $t7, $zero, 0x64
    ctx->r15 = ADD32(0, 0X64);
    // 0x8038F29C: sb          $t9, 0x2C6C($at)
    MEM_B(0X2C6C, ctx->r1) = ctx->r25;
    // 0x8038F2A0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F2A4: sb          $zero, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = 0;
    // 0x8038F2A8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F2AC: sb          $t7, 0x6460($at)
    MEM_B(0X6460, ctx->r1) = ctx->r15;
    // 0x8038F2B0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038F2B4: addiu       $t4, $zero, 0x12
    ctx->r12 = ADD32(0, 0X12);
    // 0x8038F2B8: addiu       $t5, $zero, 0xF0
    ctx->r13 = ADD32(0, 0XF0);
    // 0x8038F2BC: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x8038F2C0: sh          $t4, 0x6110($at)
    MEM_H(0X6110, ctx->r1) = ctx->r12;
    // 0x8038F2C4: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8038F2C8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x8038F2CC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038F2D0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038F2D4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038F2D8: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x8038F2DC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8038F2E0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038F2E4: jal         0x8012AD30
    // 0x8038F2E8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_33;
    // 0x8038F2E8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_33:
    // 0x8038F2EC: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8038F2F0: lbu         $t3, 0x2AA2($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X2AA2);
    // 0x8038F2F4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8038F2F8: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x8038F2FC: bne         $t3, $at, L_8038F320
    if (ctx->r11 != ctx->r1) {
        // 0x8038F300: addiu       $t2, $zero, 0x3C
        ctx->r10 = ADD32(0, 0X3C);
            goto L_8038F320;
    }
    // 0x8038F300: addiu       $t2, $zero, 0x3C
    ctx->r10 = ADD32(0, 0X3C);
    // 0x8038F304: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F308: sb          $t8, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = ctx->r24;
    // 0x8038F30C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F310: sh          $zero, 0x6468($at)
    MEM_H(0X6468, ctx->r1) = 0;
    // 0x8038F314: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F318: b           L_8038F328
    // 0x8038F31C: sb          $t2, 0x2AA3($at)
    MEM_B(0X2AA3, ctx->r1) = ctx->r10;
        goto L_8038F328;
    // 0x8038F31C: sb          $t2, 0x2AA3($at)
    MEM_B(0X2AA3, ctx->r1) = ctx->r10;
L_8038F320:
    // 0x8038F320: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F324: sb          $zero, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = 0;
L_8038F328:
    // 0x8038F328: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038F32C: b           L_8038F3DC
    // 0x8038F330: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
        goto L_8038F3DC;
    // 0x8038F330: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
L_8038F334:
    // 0x8038F334: jal         0x8038D920
    // 0x8038F338: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    update_terminal_scene_lighting(rdram, ctx);
        goto after_34;
    // 0x8038F338: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    after_34:
    // 0x8038F33C: jal         0x8038DA70
    // 0x8038F340: nop

    render_terminal_background_scene(rdram, ctx);
        goto after_35;
    // 0x8038F340: nop

    after_35:
    // 0x8038F344: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x8038F348: addiu       $v1, $v1, 0x6310
    ctx->r3 = ADD32(ctx->r3, 0X6310);
    // 0x8038F34C: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x8038F350: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    // 0x8038F354: addiu       $a1, $zero, 0x50
    ctx->r5 = ADD32(0, 0X50);
    // 0x8038F358: bne         $s0, $v0, L_8038F38C
    if (ctx->r16 != ctx->r2) {
        // 0x8038F35C: addiu       $a2, $zero, 0x50
        ctx->r6 = ADD32(0, 0X50);
            goto L_8038F38C;
    }
    // 0x8038F35C: addiu       $a2, $zero, 0x50
    ctx->r6 = ADD32(0, 0X50);
    // 0x8038F360: addiu       $t9, $zero, 0xC8
    ctx->r25 = ADD32(0, 0XC8);
    // 0x8038F364: addiu       $t7, $zero, 0xC8
    ctx->r15 = ADD32(0, 0XC8);
    // 0x8038F368: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x8038F36C: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8038F370: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8038F374: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038F378: jal         0x802F2EEC
    // 0x8038F37C: addiu       $a3, $zero, 0xC8
    ctx->r7 = ADD32(0, 0XC8);
    func_802F2EEC_70459C(rdram, ctx);
        goto after_36;
    // 0x8038F37C: addiu       $a3, $zero, 0xC8
    ctx->r7 = ADD32(0, 0XC8);
    after_36:
    // 0x8038F380: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x8038F384: addiu       $v1, $t5, 0x6310
    ctx->r3 = ADD32(ctx->r13, 0X6310);
    // 0x8038F388: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
L_8038F38C:
    // 0x8038F38C: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8038F390: andi        $t3, $t6, 0xFFFF
    ctx->r11 = ctx->r14 & 0XFFFF;
    // 0x8038F394: addiu       $at, $zero, 0x28
    ctx->r1 = ADD32(0, 0X28);
    // 0x8038F398: bne         $t3, $at, L_8038F3D4
    if (ctx->r11 != ctx->r1) {
        // 0x8038F39C: sh          $t6, 0x0($v1)
        MEM_H(0X0, ctx->r3) = ctx->r14;
            goto L_8038F3D4;
    }
    // 0x8038F39C: sh          $t6, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r14;
    // 0x8038F3A0: sh          $zero, 0x0($v1)
    MEM_H(0X0, ctx->r3) = 0;
    // 0x8038F3A4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F3A8: sb          $zero, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = 0;
    // 0x8038F3AC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F3B0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F3B4: addiu       $v0, $v0, 0x2C6D
    ctx->r2 = ADD32(ctx->r2, 0X2C6D);
    // 0x8038F3B8: sb          $zero, 0x2D10($at)
    MEM_B(0X2D10, ctx->r1) = 0;
    // 0x8038F3BC: sb          $zero, 0x0($v0)
    MEM_B(0X0, ctx->r2) = 0;
    // 0x8038F3C0: lb          $t8, 0x0($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X0);
    // 0x8038F3C4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F3C8: sb          $t8, 0x2C6C($at)
    MEM_B(0X2C6C, ctx->r1) = ctx->r24;
    // 0x8038F3CC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F3D0: sb          $zero, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = 0;
L_8038F3D4:
    // 0x8038F3D4: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8038F3D8: lbu         $v0, 0x631C($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X631C);
L_8038F3DC:
    // 0x8038F3DC: beq         $v0, $zero, L_8038F3FC
    if (ctx->r2 == 0) {
        // 0x8038F3E0: xori        $v1, $v0, 0x7
        ctx->r3 = ctx->r2 ^ 0X7;
            goto L_8038F3FC;
    }
    // 0x8038F3E0: xori        $v1, $v0, 0x7
    ctx->r3 = ctx->r2 ^ 0X7;
    // 0x8038F3E4: addiu       $t2, $v0, 0x1
    ctx->r10 = ADD32(ctx->r2, 0X1);
    // 0x8038F3E8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F3EC: bne         $v1, $zero, L_8038F3FC
    if (ctx->r3 != 0) {
        // 0x8038F3F0: sb          $t2, 0x631C($at)
        MEM_B(0X631C, ctx->r1) = ctx->r10;
            goto L_8038F3FC;
    }
    // 0x8038F3F0: sb          $t2, 0x631C($at)
    MEM_B(0X631C, ctx->r1) = ctx->r10;
    // 0x8038F3F4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F3F8: sb          $zero, 0x631C($at)
    MEM_B(0X631C, ctx->r1) = 0;
L_8038F3FC:
    // 0x8038F3FC: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8038F400: ldc1        $f20, 0x28($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X28);
    // 0x8038F404: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x8038F408: lw          $s1, 0x38($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X38);
    // 0x8038F40C: jr          $ra
    // 0x8038F410: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    return;
    // 0x8038F410: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
;}
RECOMP_FUNC void func_8038F414_7A0AC4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F414: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038F418: addiu       $t0, $t0, 0x2AA2
    ctx->r8 = ADD32(ctx->r8, 0X2AA2);
    // 0x8038F41C: lbu         $v0, 0x0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X0);
    // 0x8038F420: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F424: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F428: beq         $v0, $zero, L_8038F450
    if (ctx->r2 == 0) {
        // 0x8038F42C: lui         $v1, 0x803F
        ctx->r3 = S32(0X803F << 16);
            goto L_8038F450;
    }
    // 0x8038F42C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8038F430: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038F434: beq         $v0, $at, L_8038F4E8
    if (ctx->r2 == ctx->r1) {
        // 0x8038F438: lui         $a0, 0x803F
        ctx->r4 = S32(0X803F << 16);
            goto L_8038F4E8;
    }
    // 0x8038F438: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038F43C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038F440: beq         $v0, $at, L_8038F5C4
    if (ctx->r2 == ctx->r1) {
        // 0x8038F444: lui         $a0, 0x803F
        ctx->r4 = S32(0X803F << 16);
            goto L_8038F5C4;
    }
    // 0x8038F444: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038F448: b           L_8038F5EC
    // 0x8038F44C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038F5EC;
    // 0x8038F44C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038F450:
    // 0x8038F450: addiu       $v1, $v1, 0x6460
    ctx->r3 = ADD32(ctx->r3, 0X6460);
    // 0x8038F454: lbu         $v0, 0x0($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X0);
    // 0x8038F458: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8038F45C: addiu       $a0, $a0, 0x2AA3
    ctx->r4 = ADD32(ctx->r4, 0X2AA3);
    // 0x8038F460: blez        $v0, L_8038F46C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038F464: addiu       $t6, $v0, -0x1
        ctx->r14 = ADD32(ctx->r2, -0X1);
            goto L_8038F46C;
    }
    // 0x8038F464: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x8038F468: sb          $t6, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r14;
L_8038F46C:
    // 0x8038F46C: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x8038F470: blez        $v0, L_8038F5E8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038F474: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_8038F5E8;
    }
    // 0x8038F474: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    // 0x8038F478: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x8038F47C: bne         $t8, $zero, L_8038F5E8
    if (ctx->r24 != 0) {
        // 0x8038F480: sb          $t7, 0x0($a0)
        MEM_B(0X0, ctx->r4) = ctx->r15;
            goto L_8038F5E8;
    }
    // 0x8038F480: sb          $t7, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r15;
    // 0x8038F484: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x8038F488: sb          $t9, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r25;
    // 0x8038F48C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F490: jal         0x8038D258
    // 0x8038F494: sb          $zero, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = 0;
    setup_terminal_stat_text(rdram, ctx);
        goto after_0;
    // 0x8038F494: sb          $zero, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = 0;
    after_0:
    // 0x8038F498: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F49C: sh          $zero, 0x6310($at)
    MEM_H(0X6310, ctx->r1) = 0;
    // 0x8038F4A0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038F4A4: lwc1        $f4, 0x180($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X180);
    // 0x8038F4A8: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038F4AC: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x8038F4B0: swc1        $f4, 0x6CC4($at)
    MEM_W(0X6CC4, ctx->r1) = ctx->f4.u32l;
    // 0x8038F4B4: lui         $at, 0x4234
    ctx->r1 = S32(0X4234 << 16);
    // 0x8038F4B8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8038F4BC: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038F4C0: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8038F4C4: swc1        $f6, 0x6CC8($at)
    MEM_W(0X6CC8, ctx->r1) = ctx->f6.u32l;
    // 0x8038F4C8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F4CC: sb          $zero, 0x6472($at)
    MEM_B(0X6472, ctx->r1) = 0;
    // 0x8038F4D0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F4D4: lh          $t2, 0x2E2A($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2E2A);
    // 0x8038F4D8: sb          $t1, 0x2D10($at)
    MEM_B(0X2D10, ctx->r1) = ctx->r9;
    // 0x8038F4DC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F4E0: b           L_8038F5E8
    // 0x8038F4E4: sh          $t2, 0x6474($at)
    MEM_H(0X6474, ctx->r1) = ctx->r10;
        goto L_8038F5E8;
    // 0x8038F4E4: sh          $t2, 0x6474($at)
    MEM_H(0X6474, ctx->r1) = ctx->r10;
L_8038F4E8:
    // 0x8038F4E8: addiu       $a0, $a0, 0x2AA3
    ctx->r4 = ADD32(ctx->r4, 0X2AA3);
    // 0x8038F4EC: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x8038F4F0: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x8038F4F4: blez        $v0, L_8038F508
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038F4F8: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_8038F508;
    }
    // 0x8038F4F8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x8038F4FC: addiu       $t3, $v0, -0x1
    ctx->r11 = ADD32(ctx->r2, -0X1);
    // 0x8038F500: sb          $t3, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r11;
    // 0x8038F504: andi        $v1, $t3, 0xFF
    ctx->r3 = ctx->r11 & 0XFF;
L_8038F508:
    // 0x8038F508: bgtzl       $v1, L_8038F5EC
    if (SIGNED(ctx->r3) > 0) {
        // 0x8038F50C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038F5EC;
    }
    goto skip_0;
    // 0x8038F50C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x8038F510: lh          $t4, 0x6468($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X6468);
    // 0x8038F514: slti        $at, $t4, 0x64
    ctx->r1 = SIGNED(ctx->r12) < 0X64 ? 1 : 0;
    // 0x8038F518: bnel        $at, $zero, L_8038F5EC
    if (ctx->r1 != 0) {
        // 0x8038F51C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038F5EC;
    }
    goto skip_1;
    // 0x8038F51C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x8038F520: jal         0x802B342C
    // 0x8038F524: nop

    func_802B342C_6C4ADC(rdram, ctx);
        goto after_1;
    // 0x8038F524: nop

    after_1:
    // 0x8038F528: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F52C: lui         $a1, 0x41C8
    ctx->r5 = S32(0X41C8 << 16);
    // 0x8038F530: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8038F534: jal         0x801337DC
    // 0x8038F538: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_2;
    // 0x8038F538: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_2:
    // 0x8038F53C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038F540: addiu       $t0, $t0, 0x2AA2
    ctx->r8 = ADD32(ctx->r8, 0X2AA2);
    // 0x8038F544: addiu       $t5, $zero, 0x4
    ctx->r13 = ADD32(0, 0X4);
    // 0x8038F548: sb          $t5, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r13;
    // 0x8038F54C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8038F550: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F554: jal         0x8038D258
    // 0x8038F558: sb          $t6, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = ctx->r14;
    setup_terminal_stat_text(rdram, ctx);
        goto after_3;
    // 0x8038F558: sb          $t6, 0x6318($at)
    MEM_B(0X6318, ctx->r1) = ctx->r14;
    after_3:
    // 0x8038F55C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038F560: sh          $zero, 0x6310($at)
    MEM_H(0X6310, ctx->r1) = 0;
    // 0x8038F564: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038F568: lwc1        $f8, 0x184($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X184);
    // 0x8038F56C: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038F570: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x8038F574: swc1        $f8, 0x6CC4($at)
    MEM_W(0X6CC4, ctx->r1) = ctx->f8.u32l;
    // 0x8038F578: lui         $at, 0x4234
    ctx->r1 = S32(0X4234 << 16);
    // 0x8038F57C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8038F580: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x8038F584: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038F588: swc1        $f10, 0x6CC8($at)
    MEM_W(0X6CC8, ctx->r1) = ctx->f10.u32l;
    // 0x8038F58C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F590: sb          $zero, 0x6472($at)
    MEM_B(0X6472, ctx->r1) = 0;
    // 0x8038F594: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F598: lh          $t8, 0x2E2A($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2E2A);
    // 0x8038F59C: sb          $t7, 0x2D10($at)
    MEM_B(0X2D10, ctx->r1) = ctx->r15;
    // 0x8038F5A0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F5A4: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8038F5A8: addiu       $a1, $zero, 0x4000
    ctx->r5 = ADD32(0, 0X4000);
    // 0x8038F5AC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038F5B0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8038F5B4: jal         0x8032C508
    // 0x8038F5B8: sh          $t8, 0x6474($at)
    MEM_H(0X6474, ctx->r1) = ctx->r24;
    func_8032C508_73DBB8(rdram, ctx);
        goto after_4;
    // 0x8038F5B8: sh          $t8, 0x6474($at)
    MEM_H(0X6474, ctx->r1) = ctx->r24;
    after_4:
    // 0x8038F5BC: b           L_8038F5EC
    // 0x8038F5C0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038F5EC;
    // 0x8038F5C0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038F5C4:
    // 0x8038F5C4: addiu       $a0, $a0, 0x2AA3
    ctx->r4 = ADD32(ctx->r4, 0X2AA3);
    // 0x8038F5C8: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x8038F5CC: blez        $v0, L_8038F5E8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038F5D0: addiu       $t9, $v0, -0x1
        ctx->r25 = ADD32(ctx->r2, -0X1);
            goto L_8038F5E8;
    }
    // 0x8038F5D0: addiu       $t9, $v0, -0x1
    ctx->r25 = ADD32(ctx->r2, -0X1);
    // 0x8038F5D4: andi        $t1, $t9, 0xFF
    ctx->r9 = ctx->r25 & 0XFF;
    // 0x8038F5D8: bne         $t1, $zero, L_8038F5E8
    if (ctx->r9 != 0) {
        // 0x8038F5DC: sb          $t9, 0x0($a0)
        MEM_B(0X0, ctx->r4) = ctx->r25;
            goto L_8038F5E8;
    }
    // 0x8038F5DC: sb          $t9, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r25;
    // 0x8038F5E0: jal         0x802B34DC
    // 0x8038F5E4: sb          $zero, 0x0($t0)
    MEM_B(0X0, ctx->r8) = 0;
    func_802B34DC_6C4B8C(rdram, ctx);
        goto after_5;
    // 0x8038F5E4: sb          $zero, 0x0($t0)
    MEM_B(0X0, ctx->r8) = 0;
    after_5:
L_8038F5E8:
    // 0x8038F5E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038F5EC:
    // 0x8038F5EC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038F5F0: jr          $ra
    // 0x8038F5F4: nop

    return;
    // 0x8038F5F4: nop

;}
RECOMP_FUNC void func_8038F5F8_7A0CA8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F5F8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038F5FC: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x8038F600: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8038F604: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F608: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x8038F60C: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x8038F610: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8038F614: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F618: addiu       $at, $zero, 0x13F
    ctx->r1 = ADD32(0, 0X13F);
    // 0x8038F61C: lw          $t8, 0x16C($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X16C);
    // 0x8038F620: lhu         $v1, 0x0($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X0);
    // 0x8038F624: beq         $v1, $at, L_8038F684
    if (ctx->r3 == ctx->r1) {
        // 0x8038F628: addiu       $at, $zero, 0x13D
        ctx->r1 = ADD32(0, 0X13D);
            goto L_8038F684;
    }
    // 0x8038F628: addiu       $at, $zero, 0x13D
    ctx->r1 = ADD32(0, 0X13D);
    // 0x8038F62C: beq         $v1, $at, L_8038F684
    if (ctx->r3 == ctx->r1) {
        // 0x8038F630: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_8038F684;
    }
    // 0x8038F630: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038F634: addiu       $a2, $a2, 0x6460
    ctx->r6 = ADD32(ctx->r6, 0X6460);
    // 0x8038F638: lbu         $t9, 0x0($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X0);
    // 0x8038F63C: addiu       $v1, $zero, 0x64
    ctx->r3 = ADD32(0, 0X64);
    // 0x8038F640: addiu       $t0, $zero, 0x64
    ctx->r8 = ADD32(0, 0X64);
    // 0x8038F644: bne         $t9, $zero, L_8038F684
    if (ctx->r25 != 0) {
        // 0x8038F648: lui         $at, 0x803D
        ctx->r1 = S32(0X803D << 16);
            goto L_8038F684;
    }
    // 0x8038F648: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038F64C: sh          $t0, 0x6110($at)
    MEM_H(0X6110, ctx->r1) = ctx->r8;
    // 0x8038F650: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F654: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8038F658: sb          $t1, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = ctx->r9;
    // 0x8038F65C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F660: sw          $a0, 0x6464($at)
    MEM_W(0X6464, ctx->r1) = ctx->r4;
    // 0x8038F664: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F668: sh          $zero, 0x6468($at)
    MEM_H(0X6468, ctx->r1) = 0;
    // 0x8038F66C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F670: sb          $v1, 0x2AA3($at)
    MEM_B(0X2AA3, ctx->r1) = ctx->r3;
    // 0x8038F674: sb          $v1, 0x0($a2)
    MEM_B(0X0, ctx->r6) = ctx->r3;
    // 0x8038F678: lw          $t2, 0x16C($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X16C);
    // 0x8038F67C: jal         0x8032AC48
    // 0x8038F680: lh          $a0, 0x9C($t2)
    ctx->r4 = MEM_H(ctx->r10, 0X9C);
    set_species_as_encountered(rdram, ctx);
        goto after_0;
    // 0x8038F680: lh          $a0, 0x9C($t2)
    ctx->r4 = MEM_H(ctx->r10, 0X9C);
    after_0:
L_8038F684:
    // 0x8038F684: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F688: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038F68C: jr          $ra
    // 0x8038F690: nop

    return;
    // 0x8038F690: nop

;}
RECOMP_FUNC void trigger_new_animal_cutscene(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F694: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F698: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F69C: sb          $zero, 0x2AA2($at)
    MEM_B(0X2AA2, ctx->r1) = 0;
    // 0x8038F6A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F6A4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F6A8: addiu       $t6, $zero, 0x19
    ctx->r14 = ADD32(0, 0X19);
    // 0x8038F6AC: sb          $t6, 0x2AA3($at)
    MEM_B(0X2AA3, ctx->r1) = ctx->r14;
    // 0x8038F6B0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F6B4: lui         $a1, 0x4307
    ctx->r5 = S32(0X4307 << 16);
    // 0x8038F6B8: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8038F6BC: jal         0x801337DC
    // 0x8038F6C0: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_0;
    // 0x8038F6C0: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_0:
    // 0x8038F6C4: lui         $at, 0x4307
    ctx->r1 = S32(0X4307 << 16);
    // 0x8038F6C8: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8038F6CC: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x8038F6D0: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x8038F6D4: jal         0x8013385C
    // 0x8038F6D8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    start_sfx_volume_fade(rdram, ctx);
        goto after_1;
    // 0x8038F6D8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    after_1:
    // 0x8038F6DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F6E0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038F6E4: jr          $ra
    // 0x8038F6E8: nop

    return;
    // 0x8038F6E8: nop

;}
RECOMP_FUNC void func_8038F6F0_7A0DA0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F6F0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F6F4: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038F6F8: addiu       $t6, $zero, 0x5
    ctx->r14 = ADD32(0, 0X5);
    // 0x8038F6FC: sh          $t6, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r14;
    // 0x8038F700: jr          $ra
    // 0x8038F704: sh          $zero, 0xE($v0)
    MEM_H(0XE, ctx->r2) = 0;
    return;
    // 0x8038F704: sh          $zero, 0xE($v0)
    MEM_H(0XE, ctx->r2) = 0;
;}
RECOMP_FUNC void func_8038F708_7A0DB8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F708: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8038F70C: addiu       $v0, $v0, -0xD60
    ctx->r2 = ADD32(ctx->r2, -0XD60);
    // 0x8038F710: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038F714: lh          $t7, 0x6716($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6716);
    // 0x8038F718: lb          $t6, 0xD($v0)
    ctx->r14 = MEM_B(ctx->r2, 0XD);
    // 0x8038F71C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F720: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F724: bne         $t6, $t7, L_8038F750
    if (ctx->r14 != ctx->r15) {
        // 0x8038F728: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_8038F750;
    }
    // 0x8038F728: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038F72C: lb          $t8, 0xC($v0)
    ctx->r24 = MEM_B(ctx->r2, 0XC);
    // 0x8038F730: lh          $t9, 0x6718($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6718);
    // 0x8038F734: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8038F738: bne         $t8, $t9, L_8038F750
    if (ctx->r24 != ctx->r25) {
        // 0x8038F73C: nop
    
            goto L_8038F750;
    }
    // 0x8038F73C: nop

    // 0x8038F740: lb          $t0, 0xE($v0)
    ctx->r8 = MEM_B(ctx->r2, 0XE);
    // 0x8038F744: lh          $t1, 0x671A($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X671A);
    // 0x8038F748: beql        $t0, $t1, L_8038F76C
    if (ctx->r8 == ctx->r9) {
        // 0x8038F74C: addiu       $t2, $zero, 0x1
        ctx->r10 = ADD32(0, 0X1);
            goto L_8038F76C;
    }
    goto skip_0;
    // 0x8038F74C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    skip_0:
L_8038F750:
    // 0x8038F750: jal         0x80130C30
    // 0x8038F754: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    write_eeprom(rdram, ctx);
        goto after_0;
    // 0x8038F754: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_0:
    // 0x8038F758: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8038F75C: addiu       $v0, $v0, -0xD60
    ctx->r2 = ADD32(ctx->r2, -0XD60);
    // 0x8038F760: jal         0x80133BA0
    // 0x8038F764: lb          $a0, 0xC($v0)
    ctx->r4 = MEM_B(ctx->r2, 0XC);
    set_music_volume(rdram, ctx);
        goto after_1;
    // 0x8038F764: lb          $a0, 0xC($v0)
    ctx->r4 = MEM_B(ctx->r2, 0XC);
    after_1:
    // 0x8038F768: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
L_8038F76C:
    // 0x8038F76C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F770: jal         0x802F07D0
    // 0x8038F774: sh          $t2, 0x66A4($at)
    MEM_H(0X66A4, ctx->r1) = ctx->r10;
    static_2_802F07D0(rdram, ctx);
        goto after_2;
    // 0x8038F774: sh          $t2, 0x66A4($at)
    MEM_H(0X66A4, ctx->r1) = ctx->r10;
    after_2:
    // 0x8038F778: jal         0x802F07E8
    // 0x8038F77C: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    static_2_802F07E8(rdram, ctx);
        goto after_3;
    // 0x8038F77C: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    after_3:
    // 0x8038F780: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F784: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x8038F788: sh          $zero, 0x645C($at)
    MEM_H(0X645C, ctx->r1) = 0;
    // 0x8038F78C: jr          $ra
    // 0x8038F790: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038F790: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void trigger_pause_menu(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F794: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F798: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F79C: jal         0x8039D580
    // 0x8038F7A0: nop

    generate_stars(rdram, ctx);
        goto after_0;
    // 0x8038F7A0: nop

    after_0:
    // 0x8038F7A4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F7A8: lui         $a1, 0x4270
    ctx->r5 = S32(0X4270 << 16);
    // 0x8038F7AC: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8038F7B0: jal         0x801337DC
    // 0x8038F7B4: lui         $a3, 0x40C0
    ctx->r7 = S32(0X40C0 << 16);
    start_sequence_volume_fade(rdram, ctx);
        goto after_1;
    // 0x8038F7B4: lui         $a3, 0x40C0
    ctx->r7 = S32(0X40C0 << 16);
    after_1:
    // 0x8038F7B8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F7BC: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038F7C0: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038F7C4: sh          $zero, 0x14($v0)
    MEM_H(0X14, ctx->r2) = 0;
    // 0x8038F7C8: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038F7CC: addiu       $t7, $t7, 0x6730
    ctx->r15 = ADD32(ctx->r15, 0X6730);
    // 0x8038F7D0: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x8038F7D4: lw          $t9, 0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X4);
    // 0x8038F7D8: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038F7DC: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x8038F7E0: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x8038F7E4: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x8038F7E8: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x8038F7EC: lw          $t9, 0xC($t7)
    ctx->r25 = MEM_W(ctx->r15, 0XC);
    // 0x8038F7F0: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x8038F7F4: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x8038F7F8: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x8038F7FC: lw          $t9, 0x14($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X14);
    // 0x8038F800: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x8038F804: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8038F808: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
    // 0x8038F80C: addiu       $t0, $zero, 0x1E
    ctx->r8 = ADD32(0, 0X1E);
    // 0x8038F810: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x8038F814: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8038F818: sb          $zero, 0x31($v0)
    MEM_B(0X31, ctx->r2) = 0;
    // 0x8038F81C: sb          $zero, 0x33($v0)
    MEM_B(0X33, ctx->r2) = 0;
    // 0x8038F820: sb          $zero, 0x35($v0)
    MEM_B(0X35, ctx->r2) = 0;
    // 0x8038F824: sb          $a0, 0x29($v0)
    MEM_B(0X29, ctx->r2) = ctx->r4;
    // 0x8038F828: sh          $t0, 0x16($v0)
    MEM_H(0X16, ctx->r2) = ctx->r8;
    // 0x8038F82C: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038F830: sh          $zero, 0x18($v0)
    MEM_H(0X18, ctx->r2) = 0;
    // 0x8038F834: sb          $zero, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = 0;
    // 0x8038F838: sb          $zero, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = 0;
    // 0x8038F83C: sb          $zero, 0x2B($v0)
    MEM_B(0X2B, ctx->r2) = 0;
    // 0x8038F840: sh          $zero, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = 0;
    // 0x8038F844: sh          $t1, 0x1E($v0)
    MEM_H(0X1E, ctx->r2) = ctx->r9;
    // 0x8038F848: sh          $t2, 0x20($v0)
    MEM_H(0X20, ctx->r2) = ctx->r10;
    // 0x8038F84C: sh          $zero, 0x22($v0)
    MEM_H(0X22, ctx->r2) = 0;
    // 0x8038F850: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x8038F854: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F858: sh          $zero, 0x6706($at)
    MEM_H(0X6706, ctx->r1) = 0;
    // 0x8038F85C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F860: sh          $zero, 0x6708($at)
    MEM_H(0X6708, ctx->r1) = 0;
    // 0x8038F864: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F868: addiu       $t3, $zero, 0x500
    ctx->r11 = ADD32(0, 0X500);
    // 0x8038F86C: sh          $t3, 0x670A($at)
    MEM_H(0X670A, ctx->r1) = ctx->r11;
    // 0x8038F870: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F874: addiu       $t4, $zero, 0x3C0
    ctx->r12 = ADD32(0, 0X3C0);
    // 0x8038F878: sh          $t4, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r12;
    // 0x8038F87C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038F880: sb          $a0, 0x422($at)
    MEM_B(0X422, ctx->r1) = ctx->r4;
    // 0x8038F884: lui         $v1, 0x8024
    ctx->r3 = S32(0X8024 << 16);
    // 0x8038F888: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038F88C: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x8038F890: addiu       $v1, $v1, -0xD60
    ctx->r3 = ADD32(ctx->r3, -0XD60);
    // 0x8038F894: sh          $t5, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r13;
    // 0x8038F898: lb          $t8, 0xD($v1)
    ctx->r24 = MEM_B(ctx->r3, 0XD);
    // 0x8038F89C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F8A0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F8A4: sh          $t8, 0x6716($at)
    MEM_H(0X6716, ctx->r1) = ctx->r24;
    // 0x8038F8A8: lb          $t6, 0xC($v1)
    ctx->r14 = MEM_B(ctx->r3, 0XC);
    // 0x8038F8AC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F8B0: sh          $t6, 0x6718($at)
    MEM_H(0X6718, ctx->r1) = ctx->r14;
    // 0x8038F8B4: lb          $t7, 0xE($v1)
    ctx->r15 = MEM_B(ctx->r3, 0XE);
    // 0x8038F8B8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F8BC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038F8C0: jr          $ra
    // 0x8038F8C4: sh          $t7, 0x671A($at)
    MEM_H(0X671A, ctx->r1) = ctx->r15;
    return;
    // 0x8038F8C4: sh          $t7, 0x671A($at)
    MEM_H(0X671A, ctx->r1) = ctx->r15;
;}
RECOMP_FUNC void trigger_mission_brief_screen(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F8C8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F8CC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F8D0: jal         0x8039D580
    // 0x8038F8D4: nop

    generate_stars(rdram, ctx);
        goto after_0;
    // 0x8038F8D4: nop

    after_0:
    // 0x8038F8D8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038F8DC: lui         $a1, 0x4170
    ctx->r5 = S32(0X4170 << 16);
    // 0x8038F8E0: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8038F8E4: jal         0x801337DC
    // 0x8038F8E8: lui         $a3, 0x40C0
    ctx->r7 = S32(0X40C0 << 16);
    start_sequence_volume_fade(rdram, ctx);
        goto after_1;
    // 0x8038F8E8: lui         $a3, 0x40C0
    ctx->r7 = S32(0X40C0 << 16);
    after_1:
    // 0x8038F8EC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F8F0: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038F8F4: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038F8F8: addiu       $t6, $zero, 0x28
    ctx->r14 = ADD32(0, 0X28);
    // 0x8038F8FC: addiu       $t7, $zero, 0x1E
    ctx->r15 = ADD32(0, 0X1E);
    // 0x8038F900: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x8038F904: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038F908: sb          $zero, 0x31($v0)
    MEM_B(0X31, ctx->r2) = 0;
    // 0x8038F90C: sb          $zero, 0x33($v0)
    MEM_B(0X33, ctx->r2) = 0;
    // 0x8038F910: sb          $zero, 0x35($v0)
    MEM_B(0X35, ctx->r2) = 0;
    // 0x8038F914: sb          $zero, 0x29($v0)
    MEM_B(0X29, ctx->r2) = 0;
    // 0x8038F918: sh          $t6, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r14;
    // 0x8038F91C: sh          $t7, 0x16($v0)
    MEM_H(0X16, ctx->r2) = ctx->r15;
    // 0x8038F920: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038F924: sb          $zero, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = 0;
    // 0x8038F928: sb          $zero, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = 0;
    // 0x8038F92C: sb          $zero, 0x2B($v0)
    MEM_B(0X2B, ctx->r2) = 0;
    // 0x8038F930: sh          $zero, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = 0;
    // 0x8038F934: sh          $t8, 0x1E($v0)
    MEM_H(0X1E, ctx->r2) = ctx->r24;
    // 0x8038F938: sh          $v1, 0x20($v0)
    MEM_H(0X20, ctx->r2) = ctx->r3;
    // 0x8038F93C: sh          $zero, 0x22($v0)
    MEM_H(0X22, ctx->r2) = 0;
    // 0x8038F940: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x8038F944: sh          $v1, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r3;
    // 0x8038F948: addiu       $t9, $zero, 0x140
    ctx->r25 = ADD32(0, 0X140);
    // 0x8038F94C: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038F950: jal         0x8012A400
    // 0x8038F954: sh          $t9, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r25;
    func_8012A400(rdram, ctx);
        goto after_2;
    // 0x8038F954: sh          $t9, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r25;
    after_2:
    // 0x8038F958: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F95C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038F960: jr          $ra
    // 0x8038F964: nop

    return;
    // 0x8038F964: nop

;}
RECOMP_FUNC void func_8038F968_7A1018(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038F968: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038F96C: lh          $t6, -0x7CC0($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X7CC0);
    // 0x8038F970: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038F974: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x8038F978: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8038F97C: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x8038F980: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8038F984: lh          $t8, 0x3330($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3330);
    // 0x8038F988: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8038F98C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038F990: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038F994: addiu       $t0, $t0, 0x34C0
    ctx->r8 = ADD32(ctx->r8, 0X34C0);
    // 0x8038F998: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8038F99C: addiu       $v0, $v0, 0x2CE0
    ctx->r2 = ADD32(ctx->r2, 0X2CE0);
    // 0x8038F9A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038F9A4: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    // 0x8038F9A8: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x8038F9AC: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x8038F9B0: sw          $a0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r4;
    // 0x8038F9B4: jal         0x8012E78C
    // 0x8038F9B8: addiu       $a3, $zero, 0xC
    ctx->r7 = ADD32(0, 0XC);
    func_8012E78C(rdram, ctx);
        goto after_0;
    // 0x8038F9B8: addiu       $a3, $zero, 0xC
    ctx->r7 = ADD32(0, 0XC);
    after_0:
    // 0x8038F9BC: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8038F9C0: addiu       $t2, $v0, -0xC
    ctx->r10 = ADD32(ctx->r2, -0XC);
    // 0x8038F9C4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F9C8: sh          $t2, 0x2CE4($at)
    MEM_H(0X2CE4, ctx->r1) = ctx->r10;
    // 0x8038F9CC: addiu       $v1, $v1, 0x6680
    ctx->r3 = ADD32(ctx->r3, 0X6680);
    // 0x8038F9D0: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8038F9D4: sh          $zero, 0x0($v1)
    MEM_H(0X0, ctx->r3) = 0;
    // 0x8038F9D8: sb          $t3, 0x27($v1)
    MEM_B(0X27, ctx->r3) = ctx->r11;
    // 0x8038F9DC: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8038F9E0: jal         0x80133BA0
    // 0x8038F9E4: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    set_music_volume(rdram, ctx);
        goto after_1;
    // 0x8038F9E4: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    after_1:
    // 0x8038F9E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038F9EC: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8038F9F0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038F9F4: sh          $t4, 0x671C($at)
    MEM_H(0X671C, ctx->r1) = ctx->r12;
    // 0x8038F9F8: jr          $ra
    // 0x8038F9FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038F9FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void trigger_level_failed(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FA00: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FA04: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FA08: jal         0x8039D580
    // 0x8038FA0C: nop

    generate_stars(rdram, ctx);
        goto after_0;
    // 0x8038FA0C: nop

    after_0:
    // 0x8038FA10: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FA14: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FA18: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038FA1C: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038FA20: addiu       $t7, $t7, 0x6730
    ctx->r15 = ADD32(ctx->r15, 0X6730);
    // 0x8038FA24: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x8038FA28: lw          $t9, 0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X4);
    // 0x8038FA2C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038FA30: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x8038FA34: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x8038FA38: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x8038FA3C: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x8038FA40: lw          $t9, 0xC($t7)
    ctx->r25 = MEM_W(ctx->r15, 0XC);
    // 0x8038FA44: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x8038FA48: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x8038FA4C: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x8038FA50: lw          $t9, 0x14($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X14);
    // 0x8038FA54: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x8038FA58: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FA5C: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
    // 0x8038FA60: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x8038FA64: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x8038FA68: addiu       $t1, $zero, 0x14
    ctx->r9 = ADD32(0, 0X14);
    // 0x8038FA6C: addiu       $t2, $zero, 0x1E
    ctx->r10 = ADD32(0, 0X1E);
    // 0x8038FA70: sh          $a0, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r4;
    // 0x8038FA74: sh          $t0, 0x6($v0)
    MEM_H(0X6, ctx->r2) = ctx->r8;
    // 0x8038FA78: sb          $v1, 0x29($v0)
    MEM_B(0X29, ctx->r2) = ctx->r3;
    // 0x8038FA7C: sh          $t1, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r9;
    // 0x8038FA80: sh          $t2, 0x16($v0)
    MEM_H(0X16, ctx->r2) = ctx->r10;
    // 0x8038FA84: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038FA88: sb          $v1, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = ctx->r3;
    // 0x8038FA8C: sb          $v1, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = ctx->r3;
    // 0x8038FA90: sh          $zero, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = 0;
    // 0x8038FA94: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038FA98: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FA9C: sh          $a0, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r4;
    // 0x8038FAA0: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x8038FAA4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FAA8: sb          $v1, 0x422($at)
    MEM_B(0X422, ctx->r1) = ctx->r3;
    // 0x8038FAAC: jr          $ra
    // 0x8038FAB0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038FAB0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void func_8038FAB4_7A1164(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FAB4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FAB8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FABC: jal         0x8039D580
    // 0x8038FAC0: nop

    generate_stars(rdram, ctx);
        goto after_0;
    // 0x8038FAC0: nop

    after_0:
    // 0x8038FAC4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FAC8: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FACC: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038FAD0: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x8038FAD4: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038FAD8: addiu       $t7, $t7, 0x6730
    ctx->r15 = ADD32(ctx->r15, 0X6730);
    // 0x8038FADC: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x8038FAE0: lw          $t9, 0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X4);
    // 0x8038FAE4: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038FAE8: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x8038FAEC: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x8038FAF0: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x8038FAF4: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x8038FAF8: lw          $t9, 0xC($t7)
    ctx->r25 = MEM_W(ctx->r15, 0XC);
    // 0x8038FAFC: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x8038FB00: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x8038FB04: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x8038FB08: lw          $t9, 0x14($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X14);
    // 0x8038FB0C: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x8038FB10: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FB14: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
    // 0x8038FB18: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    // 0x8038FB1C: addiu       $t0, $zero, 0xC
    ctx->r8 = ADD32(0, 0XC);
    // 0x8038FB20: addiu       $t1, $zero, 0x2
    ctx->r9 = ADD32(0, 0X2);
    // 0x8038FB24: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FB28: sh          $t0, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r8;
    // 0x8038FB2C: sh          $t1, 0x6($v0)
    MEM_H(0X6, ctx->r2) = ctx->r9;
    // 0x8038FB30: sb          $v1, 0x29($v0)
    MEM_B(0X29, ctx->r2) = ctx->r3;
    // 0x8038FB34: sh          $a0, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r4;
    // 0x8038FB38: sh          $a0, 0x16($v0)
    MEM_H(0X16, ctx->r2) = ctx->r4;
    // 0x8038FB3C: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038FB40: sb          $v1, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = ctx->r3;
    // 0x8038FB44: sb          $v1, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = ctx->r3;
    // 0x8038FB48: sh          $zero, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = 0;
    // 0x8038FB4C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038FB50: addiu       $t2, $zero, 0x6
    ctx->r10 = ADD32(0, 0X6);
    // 0x8038FB54: sh          $t2, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r10;
    // 0x8038FB58: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FB5C: sb          $v1, 0x422($at)
    MEM_B(0X422, ctx->r1) = ctx->r3;
    // 0x8038FB60: jr          $ra
    // 0x8038FB64: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038FB64: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void func_8038FB68_7A1218(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FB68: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FB6C: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FB70: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FB74: sb          $v1, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = ctx->r3;
    // 0x8038FB78: sb          $v1, 0x27($v0)
    MEM_B(0X27, ctx->r2) = ctx->r3;
    // 0x8038FB7C: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x8038FB80: sb          $zero, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = 0;
    // 0x8038FB84: sb          $zero, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = 0;
    // 0x8038FB88: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FB8C: jr          $ra
    // 0x8038FB90: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    return;
    // 0x8038FB90: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
;}
RECOMP_FUNC void load_demo_level(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FB94: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FB98: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FB9C: sh          $zero, 0x671C($at)
    MEM_H(0X671C, ctx->r1) = 0;
    // 0x8038FBA0: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FBA4: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FBA8: sb          $v1, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = ctx->r3;
    // 0x8038FBAC: sb          $v1, 0x27($v0)
    MEM_B(0X27, ctx->r2) = ctx->r3;
    // 0x8038FBB0: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x8038FBB4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FBB8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FBBC: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    // 0x8038FBC0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FBC4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FBC8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8038FBCC: jal         0x802961D4
    // 0x8038FBD0: sh          $a0, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r4;
    init_level(rdram, ctx);
        goto after_0;
    // 0x8038FBD0: sh          $a0, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r4;
    after_0:
    // 0x8038FBD4: jal         0x8029614C
    // 0x8038FBD8: nop

    reset_player_progress(rdram, ctx);
        goto after_1;
    // 0x8038FBD8: nop

    after_1:
    // 0x8038FBDC: jal         0x802F07E8
    // 0x8038FBE0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    static_2_802F07E8(rdram, ctx);
        goto after_2;
    // 0x8038FBE0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_2:
    // 0x8038FBE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FBE8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FBEC: sb          $zero, 0x2E98($at)
    MEM_B(0X2E98, ctx->r1) = 0;
    // 0x8038FBF0: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8038FBF4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8038FBF8: sh          $t8, 0x1BC0($at)
    MEM_H(0X1BC0, ctx->r1) = ctx->r24;
    // 0x8038FBFC: jr          $ra
    // 0x8038FC00: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038FC00: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void load_intro(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FC04: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FC08: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FC0C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FC10: sb          $v1, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = ctx->r3;
    // 0x8038FC14: sb          $v1, 0x27($v0)
    MEM_B(0X27, ctx->r2) = ctx->r3;
    // 0x8038FC18: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x8038FC1C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FC20: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FC24: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    // 0x8038FC28: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FC2C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FC30: addiu       $t6, $zero, 0x24
    ctx->r14 = ADD32(0, 0X24);
    // 0x8038FC34: jal         0x802961D4
    // 0x8038FC38: sh          $t6, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r14;
    init_level(rdram, ctx);
        goto after_0;
    // 0x8038FC38: sh          $t6, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r14;
    after_0:
    // 0x8038FC3C: jal         0x8029614C
    // 0x8038FC40: nop

    reset_player_progress(rdram, ctx);
        goto after_1;
    // 0x8038FC40: nop

    after_1:
    // 0x8038FC44: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FC48: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FC4C: sb          $zero, 0x2E98($at)
    MEM_B(0X2E98, ctx->r1) = 0;
    // 0x8038FC50: jr          $ra
    // 0x8038FC54: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8038FC54: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void func_8038FC58_7A1308(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FC58: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FC5C: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FC60: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038FC64: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FC68: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FC6C: sb          $v1, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = ctx->r3;
    // 0x8038FC70: sb          $v1, 0x27($v0)
    MEM_B(0X27, ctx->r2) = ctx->r3;
    // 0x8038FC74: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x8038FC78: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FC7C: jal         0x802961D4
    // 0x8038FC80: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    init_level(rdram, ctx);
        goto after_0;
    // 0x8038FC80: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    after_0:
    // 0x8038FC84: jal         0x8029614C
    // 0x8038FC88: nop

    reset_player_progress(rdram, ctx);
        goto after_1;
    // 0x8038FC88: nop

    after_1:
    // 0x8038FC8C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038FC90: lb          $t6, 0x7DD5($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X7DD5);
    // 0x8038FC94: beq         $t6, $zero, L_8038FCA4
    if (ctx->r14 == 0) {
        // 0x8038FC98: nop
    
            goto L_8038FCA4;
    }
    // 0x8038FC98: nop

    // 0x8038FC9C: jal         0x802F07E8
    // 0x8038FCA0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    static_2_802F07E8(rdram, ctx);
        goto after_2;
    // 0x8038FCA0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_2:
L_8038FCA4:
    // 0x8038FCA4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FCA8: sb          $zero, 0x2E98($at)
    MEM_B(0X2E98, ctx->r1) = 0;
    // 0x8038FCAC: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x8038FCB0: sh          $zero, 0x645C($at)
    MEM_H(0X645C, ctx->r1) = 0;
    // 0x8038FCB4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038FCB8: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x8038FCBC: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
    // 0x8038FCC0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038FCC4: lui         $a1, 0x4270
    ctx->r5 = S32(0X4270 << 16);
    // 0x8038FCC8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x8038FCCC: jal         0x801337DC
    // 0x8038FCD0: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    start_sequence_volume_fade(rdram, ctx);
        goto after_3;
    // 0x8038FCD0: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    after_3:
    // 0x8038FCD4: lui         $at, 0x4270
    ctx->r1 = S32(0X4270 << 16);
    // 0x8038FCD8: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8038FCDC: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x8038FCE0: jal         0x8013385C
    // 0x8038FCE4: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_4;
    // 0x8038FCE4: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    after_4:
    // 0x8038FCE8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FCEC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038FCF0: jr          $ra
    // 0x8038FCF4: nop

    return;
    // 0x8038FCF4: nop

;}
RECOMP_FUNC void load_smashing_start(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FCF8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FCFC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FD00: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x8038FD04: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038FD08: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    // 0x8038FD0C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038FD10: lui         $a1, 0x40A0
    ctx->r5 = S32(0X40A0 << 16);
    // 0x8038FD14: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8038FD18: jal         0x801337DC
    // 0x8038FD1C: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_0;
    // 0x8038FD1C: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_0:
    // 0x8038FD20: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FD24: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8038FD28: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FD2C: addiu       $v0, $v0, 0x7DA8
    ctx->r2 = ADD32(ctx->r2, 0X7DA8);
    // 0x8038FD30: sh          $t7, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r15;
    // 0x8038FD34: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038FD38: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8038FD3C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038FD40: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8038FD44: addiu       $a3, $a3, 0x34C0
    ctx->r7 = ADD32(ctx->r7, 0X34C0);
    // 0x8038FD48: addiu       $a2, $a2, 0x3330
    ctx->r6 = ADD32(ctx->r6, 0X3330);
    // 0x8038FD4C: lb          $a0, -0xD52($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD52);
    // 0x8038FD50: jal         0x801308E8
    // 0x8038FD54: lb          $a1, 0x2D($v0)
    ctx->r5 = MEM_B(ctx->r2, 0X2D);
    load_level_text_data(rdram, ctx);
        goto after_1;
    // 0x8038FD54: lb          $a1, 0x2D($v0)
    ctx->r5 = MEM_B(ctx->r2, 0X2D);
    after_1:
    // 0x8038FD58: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FD5C: jal         0x8038FC58
    // 0x8038FD60: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    func_8038FC58_7A1308(rdram, ctx);
        goto after_2;
    // 0x8038FD60: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    after_2:
    // 0x8038FD64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8038FD68: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038FD6C: jr          $ra
    // 0x8038FD70: nop

    return;
    // 0x8038FD70: nop

;}
RECOMP_FUNC void func_8038FD74_7A1424(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FD74: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038FD78: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038FD7C: jal         0x8038BA30
    // 0x8038FD80: nop

    reset_cheats(rdram, ctx);
        goto after_0;
    // 0x8038FD80: nop

    after_0:
    // 0x8038FD84: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FD88: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8038FD8C: sh          $zero, 0x671C($at)
    MEM_H(0X671C, ctx->r1) = 0;
    // 0x8038FD90: jal         0x80133B74
    // 0x8038FD94: lb          $a0, -0xD53($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD53);
    set_sfx_volume(rdram, ctx);
        goto after_1;
    // 0x8038FD94: lb          $a0, -0xD53($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD53);
    after_1:
    // 0x8038FD98: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8038FD9C: jal         0x80133BA0
    // 0x8038FDA0: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    set_music_volume(rdram, ctx);
        goto after_2;
    // 0x8038FDA0: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    after_2:
    // 0x8038FDA4: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8038FDA8: sh          $zero, 0x1BC0($at)
    MEM_H(0X1BC0, ctx->r1) = 0;
    // 0x8038FDAC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FDB0: sh          $zero, 0x424($at)
    MEM_H(0X424, ctx->r1) = 0;
    // 0x8038FDB4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FDB8: jal         0x8038B840
    // 0x8038FDBC: sh          $zero, 0x426($at)
    MEM_H(0X426, ctx->r1) = 0;
    reset_credits_counters(rdram, ctx);
        goto after_3;
    // 0x8038FDBC: sh          $zero, 0x426($at)
    MEM_H(0X426, ctx->r1) = 0;
    after_3:
    // 0x8038FDC0: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8038FDC4: lui         $a2, 0x8023
    ctx->r6 = S32(0X8023 << 16);
    // 0x8038FDC8: lui         $a3, 0x8023
    ctx->r7 = S32(0X8023 << 16);
    // 0x8038FDCC: addiu       $a3, $a3, 0x1D5C
    ctx->r7 = ADD32(ctx->r7, 0X1D5C);
    // 0x8038FDD0: addiu       $a2, $a2, 0x1AA0
    ctx->r6 = ADD32(ctx->r6, 0X1AA0);
    // 0x8038FDD4: lb          $a0, -0xD52($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD52);
    // 0x8038FDD8: jal         0x801308E8
    // 0x8038FDDC: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    load_level_text_data(rdram, ctx);
        goto after_4;
    // 0x8038FDDC: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    after_4:
    // 0x8038FDE0: jal         0x8039D580
    // 0x8038FDE4: nop

    generate_stars(rdram, ctx);
        goto after_5;
    // 0x8038FDE4: nop

    after_5:
    // 0x8038FDE8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FDEC: sh          $zero, 0x6704($at)
    MEM_H(0X6704, ctx->r1) = 0;
    // 0x8038FDF0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FDF4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FDF8: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FDFC: sb          $zero, 0x7DD4($at)
    MEM_B(0X7DD4, ctx->r1) = 0;
    // 0x8038FE00: jal         0x80352280
    // 0x8038FE04: sb          $zero, 0x2E($v0)
    MEM_B(0X2E, ctx->r2) = 0;
    load_ingame_objects(rdram, ctx);
        goto after_6;
    // 0x8038FE04: sb          $zero, 0x2E($v0)
    MEM_B(0X2E, ctx->r2) = 0;
    after_6:
    // 0x8038FE08: jal         0x80352310
    // 0x8038FE0C: nop

    load_water_texture(rdram, ctx);
        goto after_7;
    // 0x8038FE0C: nop

    after_7:
    // 0x8038FE10: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FE14: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FE18: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x8038FE1C: sb          $zero, 0x2D($v0)
    MEM_B(0X2D, ctx->r2) = 0;
    // 0x8038FE20: addiu       $t7, $t7, 0x6790
    ctx->r15 = ADD32(ctx->r15, 0X6790);
    // 0x8038FE24: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x8038FE28: lw          $t9, 0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X4);
    // 0x8038FE2C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8038FE30: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x8038FE34: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x8038FE38: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x8038FE3C: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x8038FE40: lw          $t9, 0xC($t7)
    ctx->r25 = MEM_W(ctx->r15, 0XC);
    // 0x8038FE44: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x8038FE48: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x8038FE4C: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x8038FE50: lw          $t9, 0x14($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X14);
    // 0x8038FE54: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x8038FE58: addiu       $v1, $zero, 0x6
    ctx->r3 = ADD32(0, 0X6);
    // 0x8038FE5C: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
    // 0x8038FE60: addiu       $t0, $zero, 0x1E
    ctx->r8 = ADD32(0, 0X1E);
    // 0x8038FE64: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8038FE68: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x8038FE6C: sh          $v1, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r3;
    // 0x8038FE70: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x8038FE74: sh          $v1, 0x6($v0)
    MEM_H(0X6, ctx->r2) = ctx->r3;
    // 0x8038FE78: sb          $zero, 0x29($v0)
    MEM_B(0X29, ctx->r2) = 0;
    // 0x8038FE7C: sh          $t0, 0x16($v0)
    MEM_H(0X16, ctx->r2) = ctx->r8;
    // 0x8038FE80: sh          $t1, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r9;
    // 0x8038FE84: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038FE88: sh          $t2, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r10;
    // 0x8038FE8C: sh          $zero, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = 0;
    // 0x8038FE90: sb          $zero, 0x2A($v0)
    MEM_B(0X2A, ctx->r2) = 0;
    // 0x8038FE94: sb          $zero, 0x2B($v0)
    MEM_B(0X2B, ctx->r2) = 0;
    // 0x8038FE98: sb          $zero, 0x2C($v0)
    MEM_B(0X2C, ctx->r2) = 0;
    // 0x8038FE9C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FEA0: sb          $zero, 0x7DD6($at)
    MEM_B(0X7DD6, ctx->r1) = 0;
    // 0x8038FEA4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FEA8: sb          $zero, 0x422($at)
    MEM_B(0X422, ctx->r1) = 0;
    // 0x8038FEAC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FEB0: sw          $zero, 0x2D30($at)
    MEM_W(0X2D30, ctx->r1) = 0;
    // 0x8038FEB4: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038FEB8: sh          $v1, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r3;
    // 0x8038FEBC: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x8038FEC0: addiu       $t3, $zero, 0x19
    ctx->r11 = ADD32(0, 0X19);
    // 0x8038FEC4: sh          $t3, 0x645C($at)
    MEM_H(0X645C, ctx->r1) = ctx->r11;
    // 0x8038FEC8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FECC: addiu       $t4, $zero, 0x640
    ctx->r12 = ADD32(0, 0X640);
    // 0x8038FED0: sh          $t4, 0x46D8($at)
    MEM_H(0X46D8, ctx->r1) = ctx->r12;
    // 0x8038FED4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FED8: addiu       $t5, $zero, 0x800
    ctx->r13 = ADD32(0, 0X800);
    // 0x8038FEDC: sh          $t5, 0x46E0($at)
    MEM_H(0X46E0, ctx->r1) = ctx->r13;
    // 0x8038FEE0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038FEE4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038FEE8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FEEC: jal         0x802F07D0
    // 0x8038FEF0: swc1        $f4, 0x517C($at)
    MEM_W(0X517C, ctx->r1) = ctx->f4.u32l;
    static_2_802F07D0(rdram, ctx);
        goto after_8;
    // 0x8038FEF0: swc1        $f4, 0x517C($at)
    MEM_W(0X517C, ctx->r1) = ctx->f4.u32l;
    after_8:
    // 0x8038FEF4: jal         0x802F07E8
    // 0x8038FEF8: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    static_2_802F07E8(rdram, ctx);
        goto after_9;
    // 0x8038FEF8: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_9:
    // 0x8038FEFC: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8038FF00: lb          $v0, 0x4288($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X4288);
    // 0x8038FF04: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x8038FF08: bne         $v0, $at, L_8038FF20
    if (ctx->r2 != ctx->r1) {
        // 0x8038FF0C: nop
    
            goto L_8038FF20;
    }
    // 0x8038FF0C: nop

    // 0x8038FF10: jal         0x8038FC04
    // 0x8038FF14: nop

    load_intro(rdram, ctx);
        goto after_10;
    // 0x8038FF14: nop

    after_10:
    // 0x8038FF18: b           L_8038FF3C
    // 0x8038FF1C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8038FF3C;
    // 0x8038FF1C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038FF20:
    // 0x8038FF20: beq         $v0, $zero, L_8038FF38
    if (ctx->r2 == 0) {
        // 0x8038FF24: sll         $t8, $v0, 1
        ctx->r24 = S32(ctx->r2 << 1);
            goto L_8038FF38;
    }
    // 0x8038FF24: sll         $t8, $v0, 1
    ctx->r24 = S32(ctx->r2 << 1);
    // 0x8038FF28: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x8038FF2C: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    // 0x8038FF30: jal         0x8038FB94
    // 0x8038FF34: lh          $a0, 0x6870($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X6870);
    load_demo_level(rdram, ctx);
        goto after_11;
    // 0x8038FF34: lh          $a0, 0x6870($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X6870);
    after_11:
L_8038FF38:
    // 0x8038FF38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038FF3C:
    // 0x8038FF3C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038FF40: jr          $ra
    // 0x8038FF44: nop

    return;
    // 0x8038FF44: nop

;}
RECOMP_FUNC void func_8038FF48_7A15F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FF48: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8038FF4C: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x8038FF50: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8038FF54: sb          $t6, 0x26($v0)
    MEM_B(0X26, ctx->r2) = ctx->r14;
    // 0x8038FF58: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x8038FF5C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038FF60: jr          $ra
    // 0x8038FF64: sh          $zero, 0x6714($at)
    MEM_H(0X6714, ctx->r1) = 0;
    return;
    // 0x8038FF64: sh          $zero, 0x6714($at)
    MEM_H(0X6714, ctx->r1) = 0;
;}
RECOMP_FUNC void func_8038FF68_7A1618(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038FF68: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x8038FF6C: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8038FF70: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x8038FF74: addiu       $s0, $s0, 0x6680
    ctx->r16 = ADD32(ctx->r16, 0X6680);
    // 0x8038FF78: lh          $v0, 0x24($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X24);
    // 0x8038FF7C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8038FF80: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
    // 0x8038FF84: beq         $v0, $zero, L_8038FFB4
    if (ctx->r2 == 0) {
        // 0x8038FF88: addiu       $t6, $v0, 0x1
        ctx->r14 = ADD32(ctx->r2, 0X1);
            goto L_8038FFB4;
    }
    // 0x8038FF88: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8038FF8C: sh          $t6, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r14;
    // 0x8038FF90: lh          $t7, 0x24($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X24);
    // 0x8038FF94: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x8038FF98: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038FF9C: slti        $at, $t7, 0xE
    ctx->r1 = SIGNED(ctx->r15) < 0XE ? 1 : 0;
    // 0x8038FFA0: bne         $at, $zero, L_8038FFB4
    if (ctx->r1 != 0) {
        // 0x8038FFA4: lui         $at, 0x8020
        ctx->r1 = S32(0X8020 << 16);
            goto L_8038FFB4;
    }
    // 0x8038FFA4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038FFA8: sh          $t8, 0x4284($at)
    MEM_H(0X4284, ctx->r1) = ctx->r24;
    // 0x8038FFAC: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8038FFB0: sb          $t9, 0x2E90($at)
    MEM_B(0X2E90, ctx->r1) = ctx->r25;
L_8038FFB4:
    // 0x8038FFB4: lh          $v0, 0x2($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2);
    // 0x8038FFB8: addiu       $t7, $zero, 0x140
    ctx->r15 = ADD32(0, 0X140);
    // 0x8038FFBC: addiu       $t8, $zero, 0xF0
    ctx->r24 = ADD32(0, 0XF0);
    // 0x8038FFC0: slti        $at, $v0, 0x384
    ctx->r1 = SIGNED(ctx->r2) < 0X384 ? 1 : 0;
    // 0x8038FFC4: beq         $at, $zero, L_8038FFD0
    if (ctx->r1 == 0) {
        // 0x8038FFC8: addiu       $t6, $v0, 0x1
        ctx->r14 = ADD32(ctx->r2, 0X1);
            goto L_8038FFD0;
    }
    // 0x8038FFC8: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8038FFCC: sh          $t6, 0x2($s0)
    MEM_H(0X2, ctx->r16) = ctx->r14;
L_8038FFD0:
    // 0x8038FFD0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038FFD4: sh          $t7, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r15;
    // 0x8038FFD8: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038FFDC: sh          $t8, 0x3FD2($at)
    MEM_H(0X3FD2, ctx->r1) = ctx->r24;
    // 0x8038FFE0: jal         0x80392668
    // 0x8038FFE4: sh          $zero, 0x3C($sp)
    MEM_H(0X3C, ctx->r29) = 0;
    func_80392668_7A3D18(rdram, ctx);
        goto after_0;
    // 0x8038FFE4: sh          $zero, 0x3C($sp)
    MEM_H(0X3C, ctx->r29) = 0;
    after_0:
    // 0x8038FFE8: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8038FFEC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FFF0: sw          $t6, 0x640($at)
    MEM_W(0X640, ctx->r1) = ctx->r14;
    // 0x8038FFF4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038FFF8: lui         $t7, 0xC800
    ctx->r15 = S32(0XC800 << 16);
    // 0x8038FFFC: sw          $t7, 0x644($at)
    MEM_W(0X644, ctx->r1) = ctx->r15;
    // 0x80390000: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80390004: addiu       $t8, $zero, 0x0
    ctx->r24 = ADD32(0, 0X0);
    // 0x80390008: sw          $t8, 0x648($at)
    MEM_W(0X648, ctx->r1) = ctx->r24;
    // 0x8039000C: lui         $t9, 0x11
    ctx->r25 = S32(0X11 << 16);
    // 0x80390010: ori         $t9, $t9, 0x2038
    ctx->r25 = ctx->r25 | 0X2038;
    // 0x80390014: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80390018: jal         0x80391A38
    // 0x8039001C: sw          $t9, 0x64C($at)
    MEM_W(0X64C, ctx->r1) = ctx->r25;
    func_80391A38_7A30E8(rdram, ctx);
        goto after_1;
    // 0x8039001C: sw          $t9, 0x64C($at)
    MEM_W(0X64C, ctx->r1) = ctx->r25;
    after_1:
    // 0x80390020: lbu         $t6, 0x2A($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X2A);
    // 0x80390024: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80390028: beql        $t6, $zero, L_803904B0
    if (ctx->r14 == 0) {
        // 0x8039002C: lbu         $v0, 0x29($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X29);
            goto L_803904B0;
    }
    goto skip_0;
    // 0x8039002C: lbu         $v0, 0x29($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X29);
    skip_0:
    // 0x80390030: jal         0x80395480
    // 0x80390034: sh          $t7, 0x3C($sp)
    MEM_H(0X3C, ctx->r29) = ctx->r15;
    setup_pause_menu_perspective_a_7A6B30(rdram, ctx);
        goto after_2;
    // 0x80390034: sh          $t7, 0x3C($sp)
    MEM_H(0X3C, ctx->r29) = ctx->r15;
    after_2:
    // 0x80390038: jal         0x80395B58
    // 0x8039003C: nop

    func_80395B58_7A7208(rdram, ctx);
        goto after_3;
    // 0x8039003C: nop

    after_3:
    // 0x80390040: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x80390044: addiu       $a2, $a2, -0x6184
    ctx->r6 = ADD32(ctx->r6, -0X6184);
    // 0x80390048: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8039004C: lui         $ra, 0xE700
    ctx->r31 = S32(0XE700 << 16);
    // 0x80390050: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x80390054: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80390058: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x8039005C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80390060: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80390064: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x80390068: ori         $t6, $t6, 0x1402
    ctx->r14 = ctx->r14 | 0X1402;
    // 0x8039006C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80390070: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80390074: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80390078: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039007C: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x80390080: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80390084: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80390088: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x8039008C: jal         0x80397840
    // 0x80390090: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    func_80397840_7A8EF0(rdram, ctx);
        goto after_4;
    // 0x80390090: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    after_4:
    // 0x80390094: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x80390098: addiu       $v1, $v1, 0x6870
    ctx->r3 = ADD32(ctx->r3, 0X6870);
    // 0x8039009C: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x803900A0: lbu         $v0, 0x2B($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X2B);
    // 0x803900A4: lui         $ra, 0xE700
    ctx->r31 = S32(0XE700 << 16);
    // 0x803900A8: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803900AC: beq         $v0, $zero, L_803902E0
    if (ctx->r2 == 0) {
        // 0x803900B0: sh          $t9, 0x0($v1)
        MEM_H(0X0, ctx->r3) = ctx->r25;
            goto L_803902E0;
    }
    // 0x803900B0: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    // 0x803900B4: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x803900B8: addiu       $v1, $v1, -0x6174
    ctx->r3 = ADD32(ctx->r3, -0X6174);
    // 0x803900BC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803900C0: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x803900C4: addiu       $t8, $t8, 0x4270
    ctx->r24 = ADD32(ctx->r24, 0X4270);
    // 0x803900C8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803900CC: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x803900D0: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x803900D4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803900D8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803900DC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803900E0: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x803900E4: ori         $t7, $t7, 0x1402
    ctx->r15 = ctx->r15 | 0X1402;
    // 0x803900E8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803900EC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x803900F0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803900F4: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x803900F8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803900FC: lui         $t8, 0x10
    ctx->r24 = S32(0X10 << 16);
    // 0x80390100: lui         $a0, 0x406
    ctx->r4 = S32(0X406 << 16);
    // 0x80390104: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80390108: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8039010C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80390110: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80390114: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390118: lui         $t7, 0xC19
    ctx->r15 = S32(0XC19 << 16);
    // 0x8039011C: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x80390120: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80390124: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80390128: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x8039012C: ori         $t7, $t7, 0x2078
    ctx->r15 = ctx->r15 | 0X2078;
    // 0x80390130: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80390134: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80390138: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8039013C: lui         $t6, 0x500
    ctx->r14 = S32(0X500 << 16);
    // 0x80390140: addiu       $t6, $t6, 0x5000
    ctx->r14 = ADD32(ctx->r14, 0X5000);
    // 0x80390144: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80390148: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8039014C: lui         $t9, 0xFD10
    ctx->r25 = S32(0XFD10 << 16);
    // 0x80390150: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80390154: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80390158: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8039015C: lui         $t9, 0x701
    ctx->r25 = S32(0X701 << 16);
    // 0x80390160: ori         $t9, $t9, 0x4050
    ctx->r25 = ctx->r25 | 0X4050;
    // 0x80390164: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80390168: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8039016C: lui         $t8, 0xF510
    ctx->r24 = S32(0XF510 << 16);
    // 0x80390170: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80390174: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80390178: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8039017C: lui         $t7, 0xE600
    ctx->r15 = S32(0XE600 << 16);
    // 0x80390180: lui         $t9, 0xF300
    ctx->r25 = S32(0XF300 << 16);
    // 0x80390184: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80390188: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8039018C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80390190: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80390194: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390198: lui         $t6, 0x77F
    ctx->r14 = S32(0X77F << 16);
    // 0x8039019C: ori         $t6, $t6, 0xF100
    ctx->r14 = ctx->r14 | 0XF100;
    // 0x803901A0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803901A4: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x803901A8: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803901AC: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803901B0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803901B4: lui         $t9, 0xF510
    ctx->r25 = S32(0XF510 << 16);
    // 0x803901B8: lui         $t6, 0x1
    ctx->r14 = S32(0X1 << 16);
    // 0x803901BC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803901C0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x803901C4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803901C8: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x803901CC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803901D0: ori         $t6, $t6, 0x4050
    ctx->r14 = ctx->r14 | 0X4050;
    // 0x803901D4: ori         $t9, $t9, 0x1000
    ctx->r25 = ctx->r25 | 0X1000;
    // 0x803901D8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803901DC: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x803901E0: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803901E4: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803901E8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803901EC: lui         $t9, 0x7
    ctx->r25 = S32(0X7 << 16);
    // 0x803901F0: ori         $t9, $t9, 0xC0FC
    ctx->r25 = ctx->r25 | 0XC0FC;
    // 0x803901F4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803901F8: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x803901FC: lui         $t8, 0xF200
    ctx->r24 = S32(0XF200 << 16);
    // 0x80390200: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80390204: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80390208: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8039020C: lui         $t8, 0x1
    ctx->r24 = S32(0X1 << 16);
    // 0x80390210: lui         $t7, 0xF510
    ctx->r15 = S32(0XF510 << 16);
    // 0x80390214: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80390218: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8039021C: ori         $t7, $t7, 0x1000
    ctx->r15 = ctx->r15 | 0X1000;
    // 0x80390220: ori         $t8, $t8, 0x4050
    ctx->r24 = ctx->r24 | 0X4050;
    // 0x80390224: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80390228: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039022C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390230: lui         $t7, 0x101
    ctx->r15 = S32(0X101 << 16);
    // 0x80390234: lui         $t6, 0xF510
    ctx->r14 = S32(0XF510 << 16);
    // 0x80390238: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039023C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80390240: ori         $t6, $t6, 0x1100
    ctx->r14 = ctx->r14 | 0X1100;
    // 0x80390244: ori         $t7, $t7, 0x4050
    ctx->r15 = ctx->r15 | 0X4050;
    // 0x80390248: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039024C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80390250: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390254: lui         $t6, 0x2
    ctx->r14 = S32(0X2 << 16);
    // 0x80390258: lui         $t9, 0xB700
    ctx->r25 = S32(0XB700 << 16);
    // 0x8039025C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80390260: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80390264: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80390268: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039026C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390270: lui         $t9, 0x1FFC
    ctx->r25 = S32(0X1FFC << 16);
    // 0x80390274: lui         $t8, 0xFC27
    ctx->r24 = S32(0XFC27 << 16);
    // 0x80390278: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039027C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80390280: ori         $t8, $t8, 0x7E04
    ctx->r24 = ctx->r24 | 0X7E04;
    // 0x80390284: ori         $t9, $t9, 0xFFF9
    ctx->r25 = ctx->r25 | 0XFFF9;
    // 0x80390288: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039028C: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80390290: lbu         $t6, 0x30($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X30);
    // 0x80390294: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80390298: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039029C: addiu       $t7, $t6, 0x8
    ctx->r15 = ADD32(ctx->r14, 0X8);
    // 0x803902A0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803902A4: sb          $t7, 0x30($s0)
    MEM_B(0X30, ctx->r16) = ctx->r15;
    // 0x803902A8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x803902AC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803902B0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803902B4: ori         $t6, $zero, 0xEA60
    ctx->r14 = 0 | 0XEA60;
    // 0x803902B8: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x803902BC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803902C0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803902C4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x803902C8: lui         $a1, 0x492
    ctx->r5 = S32(0X492 << 16);
    // 0x803902CC: lui         $a2, 0x3FD
    ctx->r6 = S32(0X3FD << 16);
    // 0x803902D0: jal         0x80397F5C
    // 0x803902D4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    render_rig_instance_xlu(rdram, ctx);
        goto after_5;
    // 0x803902D4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_5:
    // 0x803902D8: lui         $ra, 0xE700
    ctx->r31 = S32(0XE700 << 16);
    // 0x803902DC: lbu         $v0, 0x2B($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X2B);
L_803902E0:
    // 0x803902E0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803902E4: bne         $v0, $zero, L_8039035C
    if (ctx->r2 != 0) {
        // 0x803902E8: addiu       $a0, $a0, -0x6174
        ctx->r4 = ADD32(ctx->r4, -0X6174);
            goto L_8039035C;
    }
    // 0x803902E8: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x803902EC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803902F0: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x803902F4: addiu       $t9, $t9, 0x4270
    ctx->r25 = ADD32(ctx->r25, 0X4270);
    // 0x803902F8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803902FC: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80390300: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x80390304: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80390308: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039030C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80390310: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x80390314: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x80390318: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039031C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80390320: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80390324: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80390328: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039032C: lui         $t9, 0x10
    ctx->r25 = S32(0X10 << 16);
    // 0x80390330: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80390334: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80390338: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039033C: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80390340: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80390344: lui         $t8, 0x2
    ctx->r24 = S32(0X2 << 16);
    // 0x80390348: lui         $t7, 0xB700
    ctx->r15 = S32(0XB700 << 16);
    // 0x8039034C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80390350: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80390354: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80390358: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
L_8039035C:
    // 0x8039035C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80390360: lui         $t7, 0xFC41
    ctx->r15 = S32(0XFC41 << 16);
    // 0x80390364: lui         $t8, 0xFF8F
    ctx->r24 = S32(0XFF8F << 16);
    // 0x80390368: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039036C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80390370: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80390374: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80390378: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039037C: ori         $t8, $t8, 0xFFFF
    ctx->r24 = ctx->r24 | 0XFFFF;
    // 0x80390380: ori         $t7, $t7, 0xC683
    ctx->r15 = ctx->r15 | 0XC683;
    // 0x80390384: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80390388: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039038C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80390390: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80390394: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80390398: lui         $t7, 0xC19
    ctx->r15 = S32(0XC19 << 16);
    // 0x8039039C: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x803903A0: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803903A4: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x803903A8: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x803903AC: ori         $t7, $t7, 0x2230
    ctx->r15 = ctx->r15 | 0X2230;
    // 0x803903B0: addiu       $a1, $zero, 0x3C0
    ctx->r5 = ADD32(0, 0X3C0);
    // 0x803903B4: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803903B8: addiu       $a3, $zero, 0x417
    ctx->r7 = ADD32(0, 0X417);
    // 0x803903BC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x803903C0: jal         0x803951BC
    // 0x803903C4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    render_tv_body(rdram, ctx);
        goto after_6;
    // 0x803903C4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    after_6:
    // 0x803903C8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803903CC: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x803903D0: addiu       $a1, $zero, 0x3E8
    ctx->r5 = ADD32(0, 0X3E8);
    // 0x803903D4: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803903D8: jal         0x803951BC
    // 0x803903DC: addiu       $a3, $zero, 0x417
    ctx->r7 = ADD32(0, 0X417);
    render_tv_body(rdram, ctx);
        goto after_7;
    // 0x803903DC: addiu       $a3, $zero, 0x417
    ctx->r7 = ADD32(0, 0X417);
    after_7:
    // 0x803903E0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803903E4: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x803903E8: addiu       $a1, $zero, 0x410
    ctx->r5 = ADD32(0, 0X410);
    // 0x803903EC: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803903F0: jal         0x803951BC
    // 0x803903F4: addiu       $a3, $zero, 0x417
    ctx->r7 = ADD32(0, 0X417);
    render_tv_body(rdram, ctx);
        goto after_8;
    // 0x803903F4: addiu       $a3, $zero, 0x417
    ctx->r7 = ADD32(0, 0X417);
    after_8:
    // 0x803903F8: lbu         $t8, 0x2C($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2C);
    // 0x803903FC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80390400: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x80390404: beq         $t8, $zero, L_80390474
    if (ctx->r24 == 0) {
        // 0x80390408: lui         $t6, 0xFC41
        ctx->r14 = S32(0XFC41 << 16);
            goto L_80390474;
    }
    // 0x80390408: lui         $t6, 0xFC41
    ctx->r14 = S32(0XFC41 << 16);
    // 0x8039040C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80390410: lui         $t7, 0xFF8F
    ctx->r15 = S32(0XFF8F << 16);
    // 0x80390414: ori         $t7, $t7, 0xFFFF
    ctx->r15 = ctx->r15 | 0XFFFF;
    // 0x80390418: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039041C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80390420: ori         $t6, $t6, 0xC683
    ctx->r14 = ctx->r14 | 0XC683;
    // 0x80390424: addiu       $a1, $zero, 0x3C0
    ctx->r5 = ADD32(0, 0X3C0);
    // 0x80390428: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x8039042C: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    // 0x80390430: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80390434: jal         0x80395314
    // 0x80390438: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    render_tv_glass(rdram, ctx);
        goto after_9;
    // 0x80390438: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    after_9:
    // 0x8039043C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80390440: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x80390444: addiu       $a1, $zero, 0x3E8
    ctx->r5 = ADD32(0, 0X3E8);
    // 0x80390448: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x8039044C: jal         0x80395314
    // 0x80390450: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    render_tv_glass(rdram, ctx);
        goto after_10;
    // 0x80390450: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    after_10:
    // 0x80390454: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80390458: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
    // 0x8039045C: addiu       $a1, $zero, 0x410
    ctx->r5 = ADD32(0, 0X410);
    // 0x80390460: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x80390464: jal         0x80395314
    // 0x80390468: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    render_tv_glass(rdram, ctx);
        goto after_11;
    // 0x80390468: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    after_11:
    // 0x8039046C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80390470: addiu       $a0, $a0, -0x6174
    ctx->r4 = ADD32(ctx->r4, -0X6174);
L_80390474:
    // 0x80390474: jal         0x803960F4
    // 0x80390478: nop

    render_spaceship_interior(rdram, ctx);
        goto after_12;
    // 0x80390478: nop

    after_12:
    // 0x8039047C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80390480: lw          $v0, -0x6184($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6184);
    // 0x80390484: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80390488: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x8039048C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80390490: sw          $t8, -0x6184($at)
    MEM_W(-0X6184, ctx->r1) = ctx->r24;
    // 0x80390494: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x80390498: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039049C: lw          $t6, 0x4278($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4278);
    // 0x803904A0: ori         $at, $zero, 0xBB80
    ctx->r1 = 0 | 0XBB80;
    // 0x803904A4: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x803904A8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x803904AC: lbu         $v0, 0x29($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X29);
L_803904B0:
    // 0x803904B0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803904B4: beql        $v0, $zero, L_803904D0
    if (ctx->r2 == 0) {
        // 0x803904B8: lh          $v1, 0x18($s0)
        ctx->r3 = MEM_H(ctx->r16, 0X18);
            goto L_803904D0;
    }
    goto skip_1;
    // 0x803904B8: lh          $v1, 0x18($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X18);
    skip_1:
    // 0x803904BC: beql        $v0, $at, L_80390F8C
    if (ctx->r2 == ctx->r1) {
        // 0x803904C0: lh          $v1, 0x18($s0)
        ctx->r3 = MEM_H(ctx->r16, 0X18);
            goto L_80390F8C;
    }
    goto skip_2;
    // 0x803904C0: lh          $v1, 0x18($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X18);
    skip_2:
    // 0x803904C4: b           L_80391990
    // 0x803904C8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803904C8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    // 0x803904CC: lh          $v1, 0x18($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X18);
L_803904D0:
    // 0x803904D0: addiu       $t8, $v1, 0x4
    ctx->r24 = ADD32(ctx->r3, 0X4);
    // 0x803904D4: sltiu       $at, $t8, 0x2D
    ctx->r1 = ctx->r24 < 0X2D ? 1 : 0;
    // 0x803904D8: beq         $at, $zero, L_8039198C
    if (ctx->r1 == 0) {
        // 0x803904DC: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_8039198C;
    }
    // 0x803904DC: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x803904E0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803904E4: addu        $at, $at, $t8
    gpr jr_addend_803904EC = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x803904E8: lw          $t8, 0x1CC($at)
    ctx->r24 = ADD32(ctx->r1, 0X1CC);
    // 0x803904EC: jr          $t8
    // 0x803904F0: nop

    switch (jr_addend_803904EC >> 2) {
        case 0: goto L_803904F4; break;
        case 1: goto L_8039054C; break;
        case 2: goto L_803905A0; break;
        case 3: goto L_8039198C; break;
        case 4: goto L_803905DC; break;
        case 5: goto L_80390608; break;
        case 6: goto L_80390624; break;
        case 7: goto L_8039065C; break;
        case 8: goto L_803906D0; break;
        case 9: goto L_80390748; break;
        case 10: goto L_803907C8; break;
        case 11: goto L_80390848; break;
        case 12: goto L_80390924; break;
        case 13: goto L_803909A0; break;
        case 14: goto L_803909D4; break;
        case 15: goto L_80390B3C; break;
        case 16: goto L_80390C30; break;
        case 17: goto L_80390CD4; break;
        case 18: goto L_80390DAC; break;
        case 19: goto L_80390DD8; break;
        case 20: goto L_8039198C; break;
        case 21: goto L_8039198C; break;
        case 22: goto L_8039198C; break;
        case 23: goto L_8039198C; break;
        case 24: goto L_8039198C; break;
        case 25: goto L_8039198C; break;
        case 26: goto L_8039198C; break;
        case 27: goto L_8039198C; break;
        case 28: goto L_8039198C; break;
        case 29: goto L_8039198C; break;
        case 30: goto L_8039198C; break;
        case 31: goto L_8039198C; break;
        case 32: goto L_8039198C; break;
        case 33: goto L_8039198C; break;
        case 34: goto L_80390E1C; break;
        case 35: goto L_80390E48; break;
        case 36: goto L_8039198C; break;
        case 37: goto L_80390EC4; break;
        case 38: goto L_8039198C; break;
        case 39: goto L_8039198C; break;
        case 40: goto L_8039198C; break;
        case 41: goto L_8039198C; break;
        case 42: goto L_8039198C; break;
        case 43: goto L_8039198C; break;
        case 44: goto L_80390EEC; break;
        default: switch_error(__func__, 0x803904EC, 0x803C01CC);
    }
    // 0x803904F0: nop

L_803904F4:
    // 0x803904F4: jal         0x802F07D0
    // 0x803904F8: nop

    static_2_802F07D0(rdram, ctx);
        goto after_13;
    // 0x803904F8: nop

    after_13:
    // 0x803904FC: jal         0x802F07E8
    // 0x80390500: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    static_2_802F07E8(rdram, ctx);
        goto after_14;
    // 0x80390500: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_14:
    // 0x80390504: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80390508: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039050C: sh          $t9, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r25;
    // 0x80390510: addiu       $a0, $zero, 0xC
    ctx->r4 = ADD32(0, 0XC);
    // 0x80390514: addiu       $a1, $zero, 0x4
    ctx->r5 = ADD32(0, 0X4);
    // 0x80390518: jal         0x8039661C
    // 0x8039051C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_15;
    // 0x8039051C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_15:
    // 0x80390520: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80390524: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390528: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x8039052C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80390530: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80390534: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80390538: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x8039053C: jal         0x80397734
    // 0x80390540: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_16;
    // 0x80390540: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_16:
    // 0x80390544: b           L_8039198C
    // 0x80390548: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80390548: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_8039054C:
    // 0x8039054C: lh          $t8, 0x1A($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X1A);
    // 0x80390550: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80390554: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80390558: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8039055C: sh          $t9, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r25;
    // 0x80390560: lhu         $t6, 0x713C($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X713C);
    // 0x80390564: bne         $t6, $zero, L_80390574
    if (ctx->r14 != 0) {
        // 0x80390568: nop
    
            goto L_80390574;
    }
    // 0x80390568: nop

    // 0x8039056C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390570: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
L_80390574:
    // 0x80390574: jal         0x80396748
    // 0x80390578: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_17;
    // 0x80390578: nop

    after_17:
    // 0x8039057C: beq         $v0, $zero, L_8039198C
    if (ctx->r2 == 0) {
        // 0x80390580: addiu       $t8, $zero, 0x3
        ctx->r24 = ADD32(0, 0X3);
            goto L_8039198C;
    }
    // 0x80390580: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x80390584: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80390588: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x8039058C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390590: jal         0x8039264C
    // 0x80390594: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    func_8039264C_7A3CFC(rdram, ctx);
        goto after_18;
    // 0x80390594: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    after_18:
    // 0x80390598: b           L_80391990
    // 0x8039059C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x8039059C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803905A0:
    // 0x803905A0: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x803905A4: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x803905A8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803905AC: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x803905B0: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x803905B4: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x803905B8: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x803905BC: bnel        $t7, $at, L_80391990
    if (ctx->r15 != ctx->r1) {
        // 0x803905C0: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_3;
    // 0x803905C0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_3:
    // 0x803905C4: jal         0x8039661C
    // 0x803905C8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_19;
    // 0x803905C8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_19:
    // 0x803905CC: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x803905D0: addiu       $t9, $t8, 0x2
    ctx->r25 = ADD32(ctx->r24, 0X2);
    // 0x803905D4: b           L_8039198C
    // 0x803905D8: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x803905D8: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_803905DC:
    // 0x803905DC: jal         0x80396714
    // 0x803905E0: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_20;
    // 0x803905E0: nop

    after_20:
    // 0x803905E4: beq         $v0, $zero, L_8039198C
    if (ctx->r2 == 0) {
        // 0x803905E8: addiu       $t0, $zero, 0x1
        ctx->r8 = ADD32(0, 0X1);
            goto L_8039198C;
    }
    // 0x803905E8: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x803905EC: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x803905F0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803905F4: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x803905F8: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x803905FC: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80390600: b           L_8039198C
    // 0x80390604: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
        goto L_8039198C;
    // 0x80390604: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
L_80390608:
    // 0x80390608: jal         0x80396714
    // 0x8039060C: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_21;
    // 0x8039060C: nop

    after_21:
    // 0x80390610: beq         $v0, $zero, L_8039198C
    if (ctx->r2 == 0) {
        // 0x80390614: addiu       $t8, $zero, 0x2
        ctx->r24 = ADD32(0, 0X2);
            goto L_8039198C;
    }
    // 0x80390614: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80390618: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x8039061C: b           L_8039198C
    // 0x80390620: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80390620: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_80390624:
    // 0x80390624: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x80390628: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8039062C: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x80390630: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x80390634: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x80390638: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x8039063C: bnel        $t7, $at, L_80391990
    if (ctx->r15 != ctx->r1) {
        // 0x80390640: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_4;
    // 0x80390640: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_4:
    // 0x80390644: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x80390648: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x8039064C: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80390650: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390654: b           L_8039198C
    // 0x80390658: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80390658: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
L_8039065C:
    // 0x8039065C: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x80390660: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80390664: addiu       $t7, $t7, 0x6700
    ctx->r15 = ADD32(ctx->r15, 0X6700);
    // 0x80390668: bne         $t9, $zero, L_803906B8
    if (ctx->r25 != 0) {
        // 0x8039066C: lui         $t6, 0x803B
        ctx->r14 = S32(0X803B << 16);
            goto L_803906B8;
    }
    // 0x8039066C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390670: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x80390674: lw          $t9, 0x4($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X4);
    // 0x80390678: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x8039067C: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x80390680: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x80390684: lw          $t9, 0xC($t7)
    ctx->r25 = MEM_W(ctx->r15, 0XC);
    // 0x80390688: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x8039068C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80390690: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x80390694: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x80390698: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x8039069C: lw          $t9, 0x14($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X14);
    // 0x803906A0: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x803906A4: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
    // 0x803906A8: jal         0x8039884C
    // 0x803906AC: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    func_8039884C_7A9EFC(rdram, ctx);
        goto after_22;
    // 0x803906AC: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    after_22:
    // 0x803906B0: jal         0x8039895C
    // 0x803906B4: nop

    func_8039895C_7AA00C(rdram, ctx);
        goto after_23;
    // 0x803906B4: nop

    after_23:
L_803906B8:
    // 0x803906B8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x803906BC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803906C0: jal         0x8039A2DC
    // 0x803906C4: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    func_8039A2DC_7AB98C(rdram, ctx);
        goto after_24;
    // 0x803906C4: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    after_24:
    // 0x803906C8: b           L_80391990
    // 0x803906CC: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803906CC: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803906D0:
    // 0x803906D0: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x803906D4: lw          $v0, -0xD6C($v0)
    ctx->r2 = MEM_W(ctx->r2, -0XD6C);
    // 0x803906D8: andi        $t7, $v0, 0x1
    ctx->r15 = ctx->r2 & 0X1;
    // 0x803906DC: bnel        $t7, $zero, L_803906F0
    if (ctx->r15 != 0) {
        // 0x803906E0: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_803906F0;
    }
    goto skip_5;
    // 0x803906E0: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    skip_5:
    // 0x803906E4: jal         0x8038FCF8
    // 0x803906E8: nop

    load_smashing_start(rdram, ctx);
        goto after_25;
    // 0x803906E8: nop

    after_25:
    // 0x803906EC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
L_803906F0:
    // 0x803906F0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803906F4: jal         0x80398A0C
    // 0x803906F8: sh          $t9, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r25;
    display_zone_select_screen(rdram, ctx);
        goto after_26;
    // 0x803906F8: sh          $t9, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r25;
    after_26:
    // 0x803906FC: jal         0x8039264C
    // 0x80390700: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_27;
    // 0x80390700: nop

    after_27:
    // 0x80390704: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390708: addiu       $t6, $t6, 0x6700
    ctx->r14 = ADD32(ctx->r14, 0X6700);
    // 0x8039070C: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x80390710: lw          $t9, 0x4($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X4);
    // 0x80390714: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80390718: addiu       $t8, $t8, 0x683C
    ctx->r24 = ADD32(ctx->r24, 0X683C);
    // 0x8039071C: sw          $at, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r1;
    // 0x80390720: sw          $t9, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r25;
    // 0x80390724: lw          $t9, 0xC($t6)
    ctx->r25 = MEM_W(ctx->r14, 0XC);
    // 0x80390728: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x8039072C: sw          $t9, 0xC($t8)
    MEM_W(0XC, ctx->r24) = ctx->r25;
    // 0x80390730: sw          $at, 0x8($t8)
    MEM_W(0X8, ctx->r24) = ctx->r1;
    // 0x80390734: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x80390738: lw          $t9, 0x14($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X14);
    // 0x8039073C: sw          $at, 0x10($t8)
    MEM_W(0X10, ctx->r24) = ctx->r1;
    // 0x80390740: b           L_8039198C
    // 0x80390744: sw          $t9, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r25;
        goto L_8039198C;
    // 0x80390744: sw          $t9, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r25;
L_80390748:
    // 0x80390748: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x8039074C: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390750: jal         0x8039264C
    // 0x80390754: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
    func_8039264C_7A3CFC(rdram, ctx);
        goto after_28;
    // 0x80390754: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
    after_28:
    // 0x80390758: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x8039075C: addiu       $t6, $t6, 0x6700
    ctx->r14 = ADD32(ctx->r14, 0X6700);
    // 0x80390760: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x80390764: lw          $t7, 0x4($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X4);
    // 0x80390768: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x8039076C: addiu       $t8, $t8, 0x683C
    ctx->r24 = ADD32(ctx->r24, 0X683C);
    // 0x80390770: sw          $at, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r1;
    // 0x80390774: sw          $t7, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r15;
    // 0x80390778: lw          $t7, 0xC($t6)
    ctx->r15 = MEM_W(ctx->r14, 0XC);
    // 0x8039077C: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x80390780: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390784: sw          $t7, 0xC($t8)
    MEM_W(0XC, ctx->r24) = ctx->r15;
    // 0x80390788: sw          $at, 0x8($t8)
    MEM_W(0X8, ctx->r24) = ctx->r1;
    // 0x8039078C: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x80390790: lw          $t7, 0x14($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X14);
    // 0x80390794: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x80390798: sw          $at, 0x10($t8)
    MEM_W(0X10, ctx->r24) = ctx->r1;
    // 0x8039079C: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
    // 0x803907A0: lh          $t9, 0x18($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X18);
    // 0x803907A4: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x803907A8: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x803907AC: addiu       $t8, $t9, 0x1
    ctx->r24 = ADD32(ctx->r25, 0X1);
    // 0x803907B0: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x803907B4: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x803907B8: jal         0x803800F0
    // 0x803907BC: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    load_data_section(rdram, ctx);
        goto after_29;
    // 0x803907BC: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    after_29:
    // 0x803907C0: b           L_80391990
    // 0x803907C4: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803907C4: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803907C8:
    // 0x803907C8: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x803907CC: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x803907D0: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x803907D4: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x803907D8: sh          $t7, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r15;
    // 0x803907DC: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x803907E0: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x803907E4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803907E8: slti        $at, $t9, 0xB
    ctx->r1 = SIGNED(ctx->r25) < 0XB ? 1 : 0;
    // 0x803907EC: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x803907F0: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_6;
    // 0x803907F0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_6:
    // 0x803907F4: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x803907F8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x803907FC: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x80390800: beq         $v0, $at, L_80390814
    if (ctx->r2 == ctx->r1) {
        // 0x80390804: addiu       $a0, $zero, 0x2
        ctx->r4 = ADD32(0, 0X2);
            goto L_80390814;
    }
    // 0x80390804: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80390808: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x8039080C: bne         $v0, $at, L_8039082C
    if (ctx->r2 != ctx->r1) {
        // 0x80390810: addiu       $t6, $v1, 0x2
        ctx->r14 = ADD32(ctx->r3, 0X2);
            goto L_8039082C;
    }
    // 0x80390810: addiu       $t6, $v1, 0x2
    ctx->r14 = ADD32(ctx->r3, 0X2);
L_80390814:
    // 0x80390814: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x80390818: addiu       $a1, $zero, 0x4
    ctx->r5 = ADD32(0, 0X4);
    // 0x8039081C: jal         0x8039661C
    // 0x80390820: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_30;
    // 0x80390820: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_30:
    // 0x80390824: b           L_80391990
    // 0x80390828: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390828: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_8039082C:
    // 0x8039082C: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
    // 0x80390830: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80390834: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80390838: jal         0x8039661C
    // 0x8039083C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_31;
    // 0x8039083C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_31:
    // 0x80390840: b           L_80391990
    // 0x80390844: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390844: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390848:
    // 0x80390848: jal         0x80396714
    // 0x8039084C: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_32;
    // 0x8039084C: nop

    after_32:
    // 0x80390850: beq         $v0, $zero, L_8039088C
    if (ctx->r2 == 0) {
        // 0x80390854: addiu       $t7, $zero, 0xE
        ctx->r15 = ADD32(0, 0XE);
            goto L_8039088C;
    }
    // 0x80390854: addiu       $t7, $zero, 0xE
    ctx->r15 = ADD32(0, 0XE);
    // 0x80390858: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x8039085C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390860: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80390864: lui         $a1, 0x4120
    ctx->r5 = S32(0X4120 << 16);
    // 0x80390868: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x8039086C: jal         0x801337DC
    // 0x80390870: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_33;
    // 0x80390870: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_33:
    // 0x80390874: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x80390878: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8039087C: lui         $at, 0x4198
    ctx->r1 = S32(0X4198 << 16);
    // 0x80390880: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80390884: jal         0x8013385C
    // 0x80390888: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_34;
    // 0x80390888: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    after_34:
L_8039088C:
    // 0x8039088C: jal         0x80396748
    // 0x80390890: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_35;
    // 0x80390890: nop

    after_35:
    // 0x80390894: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80390898: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_7;
    // 0x80390898: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_7:
    // 0x8039089C: jal         0x8039264C
    // 0x803908A0: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_36;
    // 0x803908A0: nop

    after_36:
    // 0x803908A4: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x803908A8: addiu       $t8, $t8, 0x6730
    ctx->r24 = ADD32(ctx->r24, 0X6730);
    // 0x803908AC: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x803908B0: lw          $t7, 0x4($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X4);
    // 0x803908B4: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x803908B8: addiu       $t9, $t9, 0x683C
    ctx->r25 = ADD32(ctx->r25, 0X683C);
    // 0x803908BC: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x803908C0: sw          $t7, 0x4($t9)
    MEM_W(0X4, ctx->r25) = ctx->r15;
    // 0x803908C4: lw          $t7, 0xC($t8)
    ctx->r15 = MEM_W(ctx->r24, 0XC);
    // 0x803908C8: lw          $at, 0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X8);
    // 0x803908CC: addiu       $t6, $zero, 0xE
    ctx->r14 = ADD32(0, 0XE);
    // 0x803908D0: sw          $t7, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r15;
    // 0x803908D4: sw          $at, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r1;
    // 0x803908D8: lw          $at, 0x10($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X10);
    // 0x803908DC: lw          $t7, 0x14($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X14);
    // 0x803908E0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803908E4: sw          $at, 0x10($t9)
    MEM_W(0X10, ctx->r25) = ctx->r1;
    // 0x803908E8: sw          $t7, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r15;
    // 0x803908EC: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
    // 0x803908F0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803908F4: lui         $a1, 0x4120
    ctx->r5 = S32(0X4120 << 16);
    // 0x803908F8: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x803908FC: jal         0x801337DC
    // 0x80390900: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_37;
    // 0x80390900: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_37:
    // 0x80390904: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x80390908: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x8039090C: lui         $at, 0x4198
    ctx->r1 = S32(0X4198 << 16);
    // 0x80390910: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80390914: jal         0x8013385C
    // 0x80390918: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_38;
    // 0x80390918: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    after_38:
    // 0x8039091C: b           L_80391990
    // 0x80390920: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390920: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390924:
    // 0x80390924: jal         0x80396714
    // 0x80390928: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_39;
    // 0x80390928: nop

    after_39:
    // 0x8039092C: beq         $v0, $zero, L_80390944
    if (ctx->r2 == 0) {
        // 0x80390930: nop
    
            goto L_80390944;
    }
    // 0x80390930: nop

    // 0x80390934: lh          $t9, 0x18($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X18);
    // 0x80390938: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x8039093C: addiu       $t8, $t9, 0x1
    ctx->r24 = ADD32(ctx->r25, 0X1);
    // 0x80390940: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
L_80390944:
    // 0x80390944: jal         0x80396748
    // 0x80390948: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_40;
    // 0x80390948: nop

    after_40:
    // 0x8039094C: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80390950: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_8;
    // 0x80390950: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_8:
    // 0x80390954: jal         0x8039264C
    // 0x80390958: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_41;
    // 0x80390958: nop

    after_41:
    // 0x8039095C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390960: addiu       $t6, $t6, 0x6718
    ctx->r14 = ADD32(ctx->r14, 0X6718);
    // 0x80390964: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x80390968: lw          $t8, 0x4($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X4);
    // 0x8039096C: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80390970: addiu       $t7, $t7, 0x683C
    ctx->r15 = ADD32(ctx->r15, 0X683C);
    // 0x80390974: sw          $at, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r1;
    // 0x80390978: sw          $t8, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r24;
    // 0x8039097C: lw          $t8, 0xC($t6)
    ctx->r24 = MEM_W(ctx->r14, 0XC);
    // 0x80390980: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x80390984: sw          $t8, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r24;
    // 0x80390988: sw          $at, 0x8($t7)
    MEM_W(0X8, ctx->r15) = ctx->r1;
    // 0x8039098C: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x80390990: lw          $t8, 0x14($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X14);
    // 0x80390994: sw          $at, 0x10($t7)
    MEM_W(0X10, ctx->r15) = ctx->r1;
    // 0x80390998: b           L_8039198C
    // 0x8039099C: sw          $t8, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r24;
        goto L_8039198C;
    // 0x8039099C: sw          $t8, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r24;
L_803909A0:
    // 0x803909A0: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x803909A4: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x803909A8: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x803909AC: sh          $t7, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r15;
    // 0x803909B0: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x803909B4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x803909B8: blezl       $t6, L_80391990
    if (SIGNED(ctx->r14) <= 0) {
        // 0x803909BC: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_9;
    // 0x803909BC: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_9:
    // 0x803909C0: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x803909C4: sh          $t9, 0x1E($s0)
    MEM_H(0X1E, ctx->r16) = ctx->r25;
    // 0x803909C8: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x803909CC: b           L_8039198C
    // 0x803909D0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x803909D0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_803909D4:
    // 0x803909D4: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x803909D8: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x803909DC: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803909E0: bne         $t7, $zero, L_80390A1C
    if (ctx->r15 != 0) {
        // 0x803909E4: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_80390A1C;
    }
    // 0x803909E4: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803909E8: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x803909EC: addiu       $a3, $a3, 0x34C0
    ctx->r7 = ADD32(ctx->r7, 0X34C0);
    // 0x803909F0: lb          $a0, -0xD52($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD52);
    // 0x803909F4: lb          $a1, 0x7DD5($a1)
    ctx->r5 = MEM_B(ctx->r5, 0X7DD5);
    // 0x803909F8: jal         0x801308E8
    // 0x803909FC: addiu       $a2, $a2, 0x3330
    ctx->r6 = ADD32(ctx->r6, 0X3330);
    load_level_text_data(rdram, ctx);
        goto after_42;
    // 0x803909FC: addiu       $a2, $a2, 0x3330
    ctx->r6 = ADD32(ctx->r6, 0X3330);
    after_42:
    // 0x80390A00: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80390A04: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    // 0x80390A08: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80390A0C: sh          $zero, 0x6704($at)
    MEM_H(0X6704, ctx->r1) = 0;
    // 0x80390A10: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80390A14: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80390A18: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
L_80390A1C:
    // 0x80390A1C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80390A20: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390A24: sh          $t8, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r24;
    // 0x80390A28: jal         0x803929FC
    // 0x80390A2C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    load_mission_brief_screen(rdram, ctx);
        goto after_43;
    // 0x80390A2C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_43:
    // 0x80390A30: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x80390A34: lw          $t9, 0x10D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X10D0);
    // 0x80390A38: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80390A3C: lhu         $v0, 0x0($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X0);
    // 0x80390A40: andi        $t7, $v0, 0x1000
    ctx->r15 = ctx->r2 & 0X1000;
    // 0x80390A44: beq         $t7, $zero, L_80390A5C
    if (ctx->r15 == 0) {
        // 0x80390A48: andi        $t8, $v0, 0x8000
        ctx->r24 = ctx->r2 & 0X8000;
            goto L_80390A5C;
    }
    // 0x80390A48: andi        $t8, $v0, 0x8000
    ctx->r24 = ctx->r2 & 0X8000;
    // 0x80390A4C: lbu         $t6, 0x12DE($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12DE);
    // 0x80390A50: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80390A54: beql        $t6, $at, L_80390A74
    if (ctx->r14 == ctx->r1) {
        // 0x80390A58: addiu       $t7, $zero, 0x40
        ctx->r15 = ADD32(0, 0X40);
            goto L_80390A74;
    }
    goto skip_10;
    // 0x80390A58: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    skip_10:
L_80390A5C:
    // 0x80390A5C: beq         $t8, $zero, L_80390AC4
    if (ctx->r24 == 0) {
        // 0x80390A60: lui         $t9, 0x8029
        ctx->r25 = S32(0X8029 << 16);
            goto L_80390AC4;
    }
    // 0x80390A60: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x80390A64: lbu         $t9, 0x12DF($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X12DF);
    // 0x80390A68: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80390A6C: bne         $t9, $at, L_80390AC4
    if (ctx->r25 != ctx->r1) {
        // 0x80390A70: addiu       $t7, $zero, 0x40
        ctx->r15 = ADD32(0, 0X40);
            goto L_80390AC4;
    }
    // 0x80390A70: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
L_80390A74:
    // 0x80390A74: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80390A78: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80390A7C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80390A80: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80390A84: jal         0x8013307C
    // 0x80390A88: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_44;
    // 0x80390A88: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_44:
    // 0x80390A8C: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x80390A90: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80390A94: sh          $t6, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r14;
    // 0x80390A98: jal         0x80395074
    // 0x80390A9C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_45;
    // 0x80390A9C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_45:
    // 0x80390AA0: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390AA4: addiu       $t8, $zero, 0xC
    ctx->r24 = ADD32(0, 0XC);
    // 0x80390AA8: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x80390AAC: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390AB0: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80390AB4: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x80390AB8: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x80390ABC: lw          $t9, 0x10D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X10D0);
    // 0x80390AC0: lhu         $v0, 0x0($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X0);
L_80390AC4:
    // 0x80390AC4: andi        $t7, $v0, 0x4000
    ctx->r15 = ctx->r2 & 0X4000;
    // 0x80390AC8: beq         $t7, $zero, L_8039198C
    if (ctx->r15 == 0) {
        // 0x80390ACC: lui         $t6, 0x8029
        ctx->r14 = S32(0X8029 << 16);
            goto L_8039198C;
    }
    // 0x80390ACC: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80390AD0: lbu         $t6, 0x12E0($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12E0);
    // 0x80390AD4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80390AD8: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x80390ADC: bne         $t6, $at, L_8039198C
    if (ctx->r14 != ctx->r1) {
        // 0x80390AE0: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_8039198C;
    }
    // 0x80390AE0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80390AE4: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80390AE8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80390AEC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80390AF0: jal         0x8013307C
    // 0x80390AF4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_46;
    // 0x80390AF4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_46:
    // 0x80390AF8: jal         0x80395074
    // 0x80390AFC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_47;
    // 0x80390AFC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_47:
    // 0x80390B00: addiu       $t9, $zero, 0xA
    ctx->r25 = ADD32(0, 0XA);
    // 0x80390B04: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80390B08: sh          $t9, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r25;
    // 0x80390B0C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80390B10: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80390B14: jal         0x8039661C
    // 0x80390B18: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_48;
    // 0x80390B18: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_48:
    // 0x80390B1C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390B20: addiu       $t7, $zero, 0xB
    ctx->r15 = ADD32(0, 0XB);
    // 0x80390B24: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80390B28: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80390B2C: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x80390B30: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x80390B34: b           L_8039198C
    // 0x80390B38: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80390B38: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_80390B3C:
    // 0x80390B3C: jal         0x80396714
    // 0x80390B40: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_49;
    // 0x80390B40: nop

    after_49:
    // 0x80390B44: beql        $v0, $zero, L_80390B64
    if (ctx->r2 == 0) {
        // 0x80390B48: lh          $v0, 0x1A($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X1A);
            goto L_80390B64;
    }
    goto skip_11;
    // 0x80390B48: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    skip_11:
    // 0x80390B4C: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80390B50: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80390B54: bnel        $t6, $zero, L_80390B64
    if (ctx->r14 != 0) {
        // 0x80390B58: lh          $v0, 0x1A($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X1A);
            goto L_80390B64;
    }
    goto skip_12;
    // 0x80390B58: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    skip_12:
    // 0x80390B5C: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    // 0x80390B60: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
L_80390B64:
    // 0x80390B64: beq         $v0, $zero, L_80390BD4
    if (ctx->r2 == 0) {
        // 0x80390B68: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_80390BD4;
    }
    // 0x80390B68: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x80390B6C: sh          $t9, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r25;
    // 0x80390B70: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x80390B74: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80390B78: addiu       $t8, $t8, 0x6700
    ctx->r24 = ADD32(ctx->r24, 0X6700);
    // 0x80390B7C: slti        $at, $t7, 0x3
    ctx->r1 = SIGNED(ctx->r15) < 0X3 ? 1 : 0;
    // 0x80390B80: bne         $at, $zero, L_80390BD4
    if (ctx->r1 != 0) {
        // 0x80390B84: lui         $t6, 0x803B
        ctx->r14 = S32(0X803B << 16);
            goto L_80390BD4;
    }
    // 0x80390B84: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390B88: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x80390B8C: lw          $t7, 0x4($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X4);
    // 0x80390B90: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x80390B94: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x80390B98: sw          $t7, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r15;
    // 0x80390B9C: lw          $t7, 0xC($t8)
    ctx->r15 = MEM_W(ctx->r24, 0XC);
    // 0x80390BA0: lw          $at, 0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X8);
    // 0x80390BA4: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x80390BA8: sw          $t7, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r15;
    // 0x80390BAC: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x80390BB0: lw          $at, 0x10($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X10);
    // 0x80390BB4: lw          $t7, 0x14($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X14);
    // 0x80390BB8: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x80390BBC: sw          $t7, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r15;
    // 0x80390BC0: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80390BC4: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80390BC8: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
    // 0x80390BCC: jal         0x8039884C
    // 0x80390BD0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    func_8039884C_7A9EFC(rdram, ctx);
        goto after_50;
    // 0x80390BD0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    after_50:
L_80390BD4:
    // 0x80390BD4: jal         0x80396748
    // 0x80390BD8: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_51;
    // 0x80390BD8: nop

    after_51:
    // 0x80390BDC: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80390BE0: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_13;
    // 0x80390BE0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_13:
    // 0x80390BE4: jal         0x8039264C
    // 0x80390BE8: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_52;
    // 0x80390BE8: nop

    after_52:
    // 0x80390BEC: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80390BF0: addiu       $t8, $t8, 0x6730
    ctx->r24 = ADD32(ctx->r24, 0X6730);
    // 0x80390BF4: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x80390BF8: lw          $t9, 0x4($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X4);
    // 0x80390BFC: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390C00: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x80390C04: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x80390C08: sw          $t9, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r25;
    // 0x80390C0C: lw          $t9, 0xC($t8)
    ctx->r25 = MEM_W(ctx->r24, 0XC);
    // 0x80390C10: lw          $at, 0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X8);
    // 0x80390C14: sw          $t9, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r25;
    // 0x80390C18: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x80390C1C: lw          $at, 0x10($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X10);
    // 0x80390C20: lw          $t9, 0x14($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X14);
    // 0x80390C24: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x80390C28: b           L_8039198C
    // 0x80390C2C: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
        goto L_8039198C;
    // 0x80390C2C: sw          $t9, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r25;
L_80390C30:
    // 0x80390C30: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x80390C34: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390C38: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
    // 0x80390C3C: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80390C40: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80390C44: jal         0x8039661C
    // 0x80390C48: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_53;
    // 0x80390C48: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_53:
    // 0x80390C4C: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80390C50: addiu       $t8, $t8, 0x6718
    ctx->r24 = ADD32(ctx->r24, 0X6718);
    // 0x80390C54: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x80390C58: lw          $t7, 0x4($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X4);
    // 0x80390C5C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390C60: addiu       $t6, $t6, 0x683C
    ctx->r14 = ADD32(ctx->r14, 0X683C);
    // 0x80390C64: sw          $at, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r1;
    // 0x80390C68: sw          $t7, 0x4($t6)
    MEM_W(0X4, ctx->r14) = ctx->r15;
    // 0x80390C6C: lw          $t7, 0xC($t8)
    ctx->r15 = MEM_W(ctx->r24, 0XC);
    // 0x80390C70: lw          $at, 0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X8);
    // 0x80390C74: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390C78: sw          $t7, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r15;
    // 0x80390C7C: sw          $at, 0x8($t6)
    MEM_W(0X8, ctx->r14) = ctx->r1;
    // 0x80390C80: lw          $at, 0x10($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X10);
    // 0x80390C84: lw          $t7, 0x14($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X14);
    // 0x80390C88: addiu       $t9, $zero, 0xD
    ctx->r25 = ADD32(0, 0XD);
    // 0x80390C8C: sw          $at, 0x10($t6)
    MEM_W(0X10, ctx->r14) = ctx->r1;
    // 0x80390C90: sw          $t7, 0x14($t6)
    MEM_W(0X14, ctx->r14) = ctx->r15;
    // 0x80390C94: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390C98: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
    // 0x80390C9C: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80390CA0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80390CA4: lui         $a1, 0x4120
    ctx->r5 = S32(0X4120 << 16);
    // 0x80390CA8: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    // 0x80390CAC: jal         0x801337DC
    // 0x80390CB0: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    start_sequence_volume_fade(rdram, ctx);
        goto after_54;
    // 0x80390CB0: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_54:
    // 0x80390CB4: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x80390CB8: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x80390CBC: lui         $at, 0x4198
    ctx->r1 = S32(0X4198 << 16);
    // 0x80390CC0: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80390CC4: jal         0x8013385C
    // 0x80390CC8: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_55;
    // 0x80390CC8: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    after_55:
    // 0x80390CCC: b           L_80391990
    // 0x80390CD0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390CD0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390CD4:
    // 0x80390CD4: jal         0x80396714
    // 0x80390CD8: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_56;
    // 0x80390CD8: nop

    after_56:
    // 0x80390CDC: beq         $v0, $zero, L_80390D00
    if (ctx->r2 == 0) {
        // 0x80390CE0: nop
    
            goto L_80390D00;
    }
    // 0x80390CE0: nop

    // 0x80390CE4: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80390CE8: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390CEC: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80390CF0: jal         0x802F07D0
    // 0x80390CF4: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    static_2_802F07D0(rdram, ctx);
        goto after_57;
    // 0x80390CF4: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    after_57:
    // 0x80390CF8: jal         0x802F07E8
    // 0x80390CFC: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    static_2_802F07E8(rdram, ctx);
        goto after_58;
    // 0x80390CFC: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    after_58:
L_80390D00:
    // 0x80390D00: jal         0x80396748
    // 0x80390D04: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_59;
    // 0x80390D04: nop

    after_59:
    // 0x80390D08: beq         $v0, $zero, L_8039198C
    if (ctx->r2 == 0) {
        // 0x80390D0C: addiu       $t7, $zero, 0xE
        ctx->r15 = ADD32(0, 0XE);
            goto L_8039198C;
    }
    // 0x80390D0C: addiu       $t7, $zero, 0xE
    ctx->r15 = ADD32(0, 0XE);
    // 0x80390D10: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80390D14: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80390D18: addiu       $t6, $t6, 0x6730
    ctx->r14 = ADD32(ctx->r14, 0X6730);
    // 0x80390D1C: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x80390D20: lw          $t7, 0x4($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X4);
    // 0x80390D24: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80390D28: addiu       $t9, $t9, 0x683C
    ctx->r25 = ADD32(ctx->r25, 0X683C);
    // 0x80390D2C: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x80390D30: sw          $t7, 0x4($t9)
    MEM_W(0X4, ctx->r25) = ctx->r15;
    // 0x80390D34: lw          $t7, 0xC($t6)
    ctx->r15 = MEM_W(ctx->r14, 0XC);
    // 0x80390D38: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x80390D3C: sw          $t7, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r15;
    // 0x80390D40: sw          $at, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r1;
    // 0x80390D44: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x80390D48: lw          $t7, 0x14($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X14);
    // 0x80390D4C: sw          $at, 0x10($t9)
    MEM_W(0X10, ctx->r25) = ctx->r1;
    // 0x80390D50: jal         0x8039264C
    // 0x80390D54: sw          $t7, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r15;
    func_8039264C_7A3CFC(rdram, ctx);
        goto after_60;
    // 0x80390D54: sw          $t7, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r15;
    after_60:
    // 0x80390D58: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80390D5C: addiu       $t9, $t9, 0x6730
    ctx->r25 = ADD32(ctx->r25, 0X6730);
    // 0x80390D60: lw          $at, 0x0($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X0);
    // 0x80390D64: lw          $t7, 0x4($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X4);
    // 0x80390D68: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80390D6C: addiu       $t8, $t8, 0x683C
    ctx->r24 = ADD32(ctx->r24, 0X683C);
    // 0x80390D70: sw          $at, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r1;
    // 0x80390D74: sw          $t7, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r15;
    // 0x80390D78: lw          $t7, 0xC($t9)
    ctx->r15 = MEM_W(ctx->r25, 0XC);
    // 0x80390D7C: lw          $at, 0x8($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X8);
    // 0x80390D80: sw          $t7, 0xC($t8)
    MEM_W(0XC, ctx->r24) = ctx->r15;
    // 0x80390D84: sw          $at, 0x8($t8)
    MEM_W(0X8, ctx->r24) = ctx->r1;
    // 0x80390D88: lw          $at, 0x10($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X10);
    // 0x80390D8C: lw          $t7, 0x14($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X14);
    // 0x80390D90: sw          $at, 0x10($t8)
    MEM_W(0X10, ctx->r24) = ctx->r1;
    // 0x80390D94: jal         0x802F07D0
    // 0x80390D98: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
    static_2_802F07D0(rdram, ctx);
        goto after_61;
    // 0x80390D98: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
    after_61:
    // 0x80390D9C: jal         0x802F07E8
    // 0x80390DA0: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    static_2_802F07E8(rdram, ctx);
        goto after_62;
    // 0x80390DA0: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    after_62:
    // 0x80390DA4: b           L_80391990
    // 0x80390DA8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390DA8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390DAC:
    // 0x80390DAC: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80390DB0: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80390DB4: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80390DB8: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    // 0x80390DBC: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x80390DC0: slti        $at, $t9, 0x2
    ctx->r1 = SIGNED(ctx->r25) < 0X2 ? 1 : 0;
    // 0x80390DC4: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x80390DC8: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_14;
    // 0x80390DC8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_14:
    // 0x80390DCC: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80390DD0: b           L_8039198C
    // 0x80390DD4: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80390DD4: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_80390DD8:
    // 0x80390DD8: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80390DDC: addiu       $at, $zero, 0xB
    ctx->r1 = ADD32(0, 0XB);
    // 0x80390DE0: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80390DE4: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    // 0x80390DE8: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    // 0x80390DEC: bnel        $v0, $at, L_80390E04
    if (ctx->r2 != ctx->r1) {
        // 0x80390DF0: slti        $at, $v0, 0xC
        ctx->r1 = SIGNED(ctx->r2) < 0XC ? 1 : 0;
            goto L_80390E04;
    }
    goto skip_15;
    // 0x80390DF0: slti        $at, $v0, 0xC
    ctx->r1 = SIGNED(ctx->r2) < 0XC ? 1 : 0;
    skip_15:
    // 0x80390DF4: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80390DF8: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80390DFC: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x80390E00: slti        $at, $v0, 0xC
    ctx->r1 = SIGNED(ctx->r2) < 0XC ? 1 : 0;
L_80390E04:
    // 0x80390E04: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x80390E08: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_16;
    // 0x80390E08: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_16:
    // 0x80390E0C: jal         0x8038FC58
    // 0x80390E10: nop

    func_8038FC58_7A1308(rdram, ctx);
        goto after_63;
    // 0x80390E10: nop

    after_63:
    // 0x80390E14: b           L_80391990
    // 0x80390E18: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390E18: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390E1C:
    // 0x80390E1C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390E20: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80390E24: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x80390E28: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80390E2C: addiu       $a1, $zero, 0x6
    ctx->r5 = ADD32(0, 0X6);
    // 0x80390E30: jal         0x8039661C
    // 0x80390E34: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_64;
    // 0x80390E34: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_64:
    // 0x80390E38: lh          $t9, 0x18($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X18);
    // 0x80390E3C: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80390E40: b           L_8039198C
    // 0x80390E44: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
        goto L_8039198C;
    // 0x80390E44: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
L_80390E48:
    // 0x80390E48: jal         0x80396714
    // 0x80390E4C: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_65;
    // 0x80390E4C: nop

    after_65:
    // 0x80390E50: beq         $v0, $zero, L_80390E68
    if (ctx->r2 == 0) {
        // 0x80390E54: nop
    
            goto L_80390E68;
    }
    // 0x80390E54: nop

    // 0x80390E58: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80390E5C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80390E60: addiu       $t8, $t6, 0x2
    ctx->r24 = ADD32(ctx->r14, 0X2);
    // 0x80390E64: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
L_80390E68:
    // 0x80390E68: jal         0x80396748
    // 0x80390E6C: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_66;
    // 0x80390E6C: nop

    after_66:
    // 0x80390E70: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80390E74: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_17;
    // 0x80390E74: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_17:
    // 0x80390E78: jal         0x8039264C
    // 0x80390E7C: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_67;
    // 0x80390E7C: nop

    after_67:
    // 0x80390E80: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80390E84: addiu       $t7, $t7, 0x6700
    ctx->r15 = ADD32(ctx->r15, 0X6700);
    // 0x80390E88: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x80390E8C: lw          $t8, 0x4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X4);
    // 0x80390E90: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80390E94: addiu       $t9, $t9, 0x683C
    ctx->r25 = ADD32(ctx->r25, 0X683C);
    // 0x80390E98: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x80390E9C: sw          $t8, 0x4($t9)
    MEM_W(0X4, ctx->r25) = ctx->r24;
    // 0x80390EA0: lw          $t8, 0xC($t7)
    ctx->r24 = MEM_W(ctx->r15, 0XC);
    // 0x80390EA4: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x80390EA8: sw          $t8, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r24;
    // 0x80390EAC: sw          $at, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r1;
    // 0x80390EB0: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x80390EB4: lw          $t8, 0x14($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X14);
    // 0x80390EB8: sw          $at, 0x10($t9)
    MEM_W(0X10, ctx->r25) = ctx->r1;
    // 0x80390EBC: b           L_8039198C
    // 0x80390EC0: sw          $t8, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r24;
        goto L_8039198C;
    // 0x80390EC0: sw          $t8, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r24;
L_80390EC4:
    // 0x80390EC4: addiu       $t6, $zero, 0x4
    ctx->r14 = ADD32(0, 0X4);
    // 0x80390EC8: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
    // 0x80390ECC: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80390ED0: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80390ED4: jal         0x8039895C
    // 0x80390ED8: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    func_8039895C_7AA00C(rdram, ctx);
        goto after_68;
    // 0x80390ED8: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    after_68:
    // 0x80390EDC: jal         0x8039884C
    // 0x80390EE0: nop

    func_8039884C_7A9EFC(rdram, ctx);
        goto after_69;
    // 0x80390EE0: nop

    after_69:
    // 0x80390EE4: b           L_80391990
    // 0x80390EE8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390EE8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80390EEC:
    // 0x80390EEC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80390EF0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390EF4: sh          $t9, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r25;
    // 0x80390EF8: jal         0x803929FC
    // 0x80390EFC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    load_mission_brief_screen(rdram, ctx);
        goto after_70;
    // 0x80390EFC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_70:
    // 0x80390F00: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x80390F04: lw          $t7, 0x10D0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X10D0);
    // 0x80390F08: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80390F0C: lhu         $v0, 0x0($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X0);
    // 0x80390F10: andi        $t8, $v0, 0x1000
    ctx->r24 = ctx->r2 & 0X1000;
    // 0x80390F14: beq         $t8, $zero, L_80390F2C
    if (ctx->r24 == 0) {
        // 0x80390F18: andi        $t9, $v0, 0x8000
        ctx->r25 = ctx->r2 & 0X8000;
            goto L_80390F2C;
    }
    // 0x80390F18: andi        $t9, $v0, 0x8000
    ctx->r25 = ctx->r2 & 0X8000;
    // 0x80390F1C: lbu         $t6, 0x12DE($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12DE);
    // 0x80390F20: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80390F24: beql        $t6, $at, L_80390F44
    if (ctx->r14 == ctx->r1) {
        // 0x80390F28: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_80390F44;
    }
    goto skip_18;
    // 0x80390F28: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    skip_18:
L_80390F2C:
    // 0x80390F2C: beq         $t9, $zero, L_8039198C
    if (ctx->r25 == 0) {
        // 0x80390F30: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039198C;
    }
    // 0x80390F30: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x80390F34: lbu         $t7, 0x12DF($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12DF);
    // 0x80390F38: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80390F3C: bne         $t7, $at, L_8039198C
    if (ctx->r15 != ctx->r1) {
        // 0x80390F40: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_8039198C;
    }
    // 0x80390F40: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
L_80390F44:
    // 0x80390F44: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80390F48: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80390F4C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80390F50: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80390F54: jal         0x8013307C
    // 0x80390F58: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_71;
    // 0x80390F58: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_71:
    // 0x80390F5C: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x80390F60: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390F64: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    // 0x80390F68: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80390F6C: sh          $zero, 0x0($s0)
    MEM_H(0X0, ctx->r16) = 0;
    // 0x80390F70: sb          $t0, 0x27($s0)
    MEM_B(0X27, ctx->r16) = ctx->r8;
    // 0x80390F74: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x80390F78: jal         0x80133BA0
    // 0x80390F7C: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    set_music_volume(rdram, ctx);
        goto after_72;
    // 0x80390F7C: lb          $a0, -0xD54($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD54);
    after_72:
    // 0x80390F80: b           L_80391990
    // 0x80390F84: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80390F84: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    // 0x80390F88: lh          $v1, 0x18($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X18);
L_80390F8C:
    // 0x80390F8C: sltiu       $at, $v1, 0x2B
    ctx->r1 = ctx->r3 < 0X2B ? 1 : 0;
    // 0x80390F90: beq         $at, $zero, L_8039198C
    if (ctx->r1 == 0) {
        // 0x80390F94: sll         $t9, $v1, 2
        ctx->r25 = S32(ctx->r3 << 2);
            goto L_8039198C;
    }
    // 0x80390F94: sll         $t9, $v1, 2
    ctx->r25 = S32(ctx->r3 << 2);
    // 0x80390F98: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80390F9C: addu        $at, $at, $t9
    gpr jr_addend_80390FA4 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80390FA0: lw          $t9, 0x280($at)
    ctx->r25 = ADD32(ctx->r1, 0X280);
    // 0x80390FA4: jr          $t9
    // 0x80390FA8: nop

    switch (jr_addend_80390FA4 >> 2) {
        case 0: goto L_80390FAC; break;
        case 1: goto L_803910E4; break;
        case 2: goto L_8039110C; break;
        case 3: goto L_8039198C; break;
        case 4: goto L_80391148; break;
        case 5: goto L_803911C4; break;
        case 6: goto L_803911E4; break;
        case 7: goto L_803912B0; break;
        case 8: goto L_803912EC; break;
        case 9: goto L_8039198C; break;
        case 10: goto L_80391364; break;
        case 11: goto L_8039198C; break;
        case 12: goto L_8039198C; break;
        case 13: goto L_8039198C; break;
        case 14: goto L_8039198C; break;
        case 15: goto L_8039198C; break;
        case 16: goto L_8039198C; break;
        case 17: goto L_8039198C; break;
        case 18: goto L_8039198C; break;
        case 19: goto L_8039198C; break;
        case 20: goto L_80391390; break;
        case 21: goto L_80391468; break;
        case 22: goto L_80391500; break;
        case 23: goto L_80391550; break;
        case 24: goto L_803915B4; break;
        case 25: goto L_803915E0; break;
        case 26: goto L_80391618; break;
        case 27: goto L_8039198C; break;
        case 28: goto L_8039198C; break;
        case 29: goto L_8039198C; break;
        case 30: goto L_80391648; break;
        case 31: goto L_80391790; break;
        case 32: goto L_80391870; break;
        case 33: goto L_80391894; break;
        case 34: goto L_803918C8; break;
        case 35: goto L_8039198C; break;
        case 36: goto L_8039198C; break;
        case 37: goto L_8039198C; break;
        case 38: goto L_8039198C; break;
        case 39: goto L_8039198C; break;
        case 40: goto L_803918F4; break;
        case 41: goto L_80391928; break;
        case 42: goto L_8039195C; break;
        default: switch_error(__func__, 0x80390FA4, 0x803C0280);
    }
    // 0x80390FA8: nop

L_80390FAC:
    // 0x80390FAC: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x80390FB0: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80390FB4: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80390FB8: bne         $t7, $zero, L_80390FC4
    if (ctx->r15 != 0) {
        // 0x80390FBC: lui         $at, 0x8020
        ctx->r1 = S32(0X8020 << 16);
            goto L_80390FC4;
    }
    // 0x80390FBC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80390FC0: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
L_80390FC4:
    // 0x80390FC4: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    // 0x80390FC8: lh          $a1, 0x1C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X1C);
    // 0x80390FCC: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x80390FD0: blez        $a1, L_80390FE0
    if (SIGNED(ctx->r5) <= 0) {
        // 0x80390FD4: addiu       $t9, $a1, -0x14
        ctx->r25 = ADD32(ctx->r5, -0X14);
            goto L_80390FE0;
    }
    // 0x80390FD4: addiu       $t9, $a1, -0x14
    ctx->r25 = ADD32(ctx->r5, -0X14);
    // 0x80390FD8: sh          $t9, 0x1C($s0)
    MEM_H(0X1C, ctx->r16) = ctx->r25;
    // 0x80390FDC: lh          $a1, 0x1C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X1C);
L_80390FE0:
    // 0x80390FE0: jal         0x80393238
    // 0x80390FE4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    load_pause_menu(rdram, ctx);
        goto after_73;
    // 0x80390FE4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_73:
    // 0x80390FE8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80390FEC: addiu       $t7, $zero, 0xF0
    ctx->r15 = ADD32(0, 0XF0);
    // 0x80390FF0: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x80390FF4: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80390FF8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80390FFC: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x80391000: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80391004: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80391008: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x8039100C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80391010: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80391014: jal         0x8012AD30
    // 0x80391018: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_74;
    // 0x80391018: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_74:
    // 0x8039101C: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80391020: lh          $a3, 0x3FD0($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X3FD0);
    // 0x80391024: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80391028: addiu       $t7, $zero, 0xF0
    ctx->r15 = ADD32(0, 0XF0);
    // 0x8039102C: addiu       $a1, $a3, -0x8
    ctx->r5 = ADD32(ctx->r7, -0X8);
    // 0x80391030: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80391034: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x80391038: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8039103C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80391040: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80391044: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x80391048: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039104C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80391050: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80391054: jal         0x8012AD30
    // 0x80391058: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_75;
    // 0x80391058: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_75:
    // 0x8039105C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80391060: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80391064: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    // 0x80391068: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x8039106C: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x80391070: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80391074: lh          $a3, 0x3FD0($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X3FD0);
    // 0x80391078: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039107C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80391080: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80391084: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80391088: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039108C: jal         0x8012AD30
    // 0x80391090: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_76;
    // 0x80391090: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_76:
    // 0x80391094: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x80391098: lh          $a2, 0x3FD2($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X3FD2);
    // 0x8039109C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803910A0: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x803910A4: addiu       $a2, $a2, -0x8
    ctx->r6 = ADD32(ctx->r6, -0X8);
    // 0x803910A8: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x803910AC: addiu       $t6, $zero, 0xF0
    ctx->r14 = ADD32(0, 0XF0);
    // 0x803910B0: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x803910B4: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x803910B8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803910BC: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803910C0: lh          $a3, 0x3FD0($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X3FD0);
    // 0x803910C4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x803910C8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803910CC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803910D0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803910D4: jal         0x8012AD30
    // 0x803910D8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_77;
    // 0x803910D8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_77:
    // 0x803910DC: b           L_80391990
    // 0x803910E0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803910E0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803910E4:
    // 0x803910E4: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x803910E8: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803910EC: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
    // 0x803910F0: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x803910F4: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x803910F8: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803910FC: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x80391100: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x80391104: b           L_8039198C
    // 0x80391108: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
        goto L_8039198C;
    // 0x80391108: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
L_8039110C:
    // 0x8039110C: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80391110: addiu       $t8, $v1, 0x2
    ctx->r24 = ADD32(ctx->r3, 0X2);
    // 0x80391114: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80391118: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x8039111C: sh          $t9, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r25;
    // 0x80391120: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x80391124: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391128: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8039112C: slti        $at, $t7, 0x8
    ctx->r1 = SIGNED(ctx->r15) < 0X8 ? 1 : 0;
    // 0x80391130: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x80391134: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_19;
    // 0x80391134: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_19:
    // 0x80391138: jal         0x8039661C
    // 0x8039113C: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_78;
    // 0x8039113C: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    after_78:
    // 0x80391140: b           L_8039198C
    // 0x80391144: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80391144: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_80391148:
    // 0x80391148: jal         0x80396714
    // 0x8039114C: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_79;
    // 0x8039114C: nop

    after_79:
    // 0x80391150: beq         $v0, $zero, L_80391168
    if (ctx->r2 == 0) {
        // 0x80391154: nop
    
            goto L_80391168;
    }
    // 0x80391154: nop

    // 0x80391158: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x8039115C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80391160: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x80391164: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_80391168:
    // 0x80391168: jal         0x80396748
    // 0x8039116C: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_80;
    // 0x8039116C: nop

    after_80:
    // 0x80391170: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80391174: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_20;
    // 0x80391174: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_20:
    // 0x80391178: jal         0x8039264C
    // 0x8039117C: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_81;
    // 0x8039117C: nop

    after_81:
    // 0x80391180: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80391184: addiu       $t8, $t8, 0x6718
    ctx->r24 = ADD32(ctx->r24, 0X6718);
    // 0x80391188: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x8039118C: lw          $t9, 0x4($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X4);
    // 0x80391190: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80391194: addiu       $t7, $t7, 0x683C
    ctx->r15 = ADD32(ctx->r15, 0X683C);
    // 0x80391198: sw          $at, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r1;
    // 0x8039119C: sw          $t9, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r25;
    // 0x803911A0: lw          $t9, 0xC($t8)
    ctx->r25 = MEM_W(ctx->r24, 0XC);
    // 0x803911A4: lw          $at, 0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X8);
    // 0x803911A8: sw          $t9, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r25;
    // 0x803911AC: sw          $at, 0x8($t7)
    MEM_W(0X8, ctx->r15) = ctx->r1;
    // 0x803911B0: lw          $at, 0x10($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X10);
    // 0x803911B4: lw          $t9, 0x14($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X14);
    // 0x803911B8: sw          $at, 0x10($t7)
    MEM_W(0X10, ctx->r15) = ctx->r1;
    // 0x803911BC: b           L_8039198C
    // 0x803911C0: sw          $t9, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r25;
        goto L_8039198C;
    // 0x803911C0: sw          $t9, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r25;
L_803911C4:
    // 0x803911C4: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x803911C8: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x803911CC: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
    // 0x803911D0: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x803911D4: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x803911D8: sh          $t7, 0x1E($s0)
    MEM_H(0X1E, ctx->r16) = ctx->r15;
    // 0x803911DC: b           L_8039198C
    // 0x803911E0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x803911E0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_803911E4:
    // 0x803911E4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x803911E8: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803911EC: sh          $t8, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r24;
    // 0x803911F0: jal         0x803929FC
    // 0x803911F4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    load_mission_brief_screen(rdram, ctx);
        goto after_82;
    // 0x803911F4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_82:
    // 0x803911F8: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x803911FC: lw          $t9, 0x10D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X10D0);
    // 0x80391200: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x80391204: lhu         $v0, 0x0($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X0);
    // 0x80391208: andi        $t6, $v0, 0x1000
    ctx->r14 = ctx->r2 & 0X1000;
    // 0x8039120C: beq         $t6, $zero, L_80391224
    if (ctx->r14 == 0) {
        // 0x80391210: andi        $t8, $v0, 0x8000
        ctx->r24 = ctx->r2 & 0X8000;
            goto L_80391224;
    }
    // 0x80391210: andi        $t8, $v0, 0x8000
    ctx->r24 = ctx->r2 & 0X8000;
    // 0x80391214: lbu         $t7, 0x12DE($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12DE);
    // 0x80391218: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039121C: beql        $t7, $at, L_80391254
    if (ctx->r15 == ctx->r1) {
        // 0x80391220: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_80391254;
    }
    goto skip_21;
    // 0x80391220: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    skip_21:
L_80391224:
    // 0x80391224: beq         $t8, $zero, L_80391238
    if (ctx->r24 == 0) {
        // 0x80391228: lui         $t9, 0x8029
        ctx->r25 = S32(0X8029 << 16);
            goto L_80391238;
    }
    // 0x80391228: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x8039122C: lbu         $t9, 0x12DF($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X12DF);
    // 0x80391230: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80391234: beq         $t9, $at, L_80391250
    if (ctx->r25 == ctx->r1) {
        // 0x80391238: andi        $t6, $v0, 0x4000
        ctx->r14 = ctx->r2 & 0X4000;
            goto L_80391250;
    }
L_80391238:
    // 0x80391238: andi        $t6, $v0, 0x4000
    ctx->r14 = ctx->r2 & 0X4000;
    // 0x8039123C: beq         $t6, $zero, L_8039198C
    if (ctx->r14 == 0) {
        // 0x80391240: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039198C;
    }
    // 0x80391240: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x80391244: lbu         $t7, 0x12E0($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12E0);
    // 0x80391248: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039124C: bne         $t7, $at, L_8039198C
    if (ctx->r15 != ctx->r1) {
        // 0x80391250: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_8039198C;
    }
L_80391250:
    // 0x80391250: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
L_80391254:
    // 0x80391254: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80391258: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x8039125C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80391260: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80391264: jal         0x8013307C
    // 0x80391268: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_83;
    // 0x80391268: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_83:
    // 0x8039126C: addiu       $t9, $zero, 0xA
    ctx->r25 = ADD32(0, 0XA);
    // 0x80391270: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80391274: sh          $t9, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r25;
    // 0x80391278: jal         0x80395074
    // 0x8039127C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_84;
    // 0x8039127C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_84:
    // 0x80391280: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80391284: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80391288: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x8039128C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80391290: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80391294: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    // 0x80391298: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x8039129C: sh          $zero, 0x14($s0)
    MEM_H(0X14, ctx->r16) = 0;
    // 0x803912A0: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x803912A4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803912A8: b           L_8039198C
    // 0x803912AC: sh          $t8, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r24;
        goto L_8039198C;
    // 0x803912AC: sh          $t8, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r24;
L_803912B0:
    // 0x803912B0: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x803912B4: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x803912B8: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x803912BC: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x803912C0: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x803912C4: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x803912C8: slti        $at, $t7, 0x9
    ctx->r1 = SIGNED(ctx->r15) < 0X9 ? 1 : 0;
    // 0x803912CC: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x803912D0: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_22;
    // 0x803912D0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_22:
    // 0x803912D4: jal         0x8039661C
    // 0x803912D8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_85;
    // 0x803912D8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_85:
    // 0x803912DC: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x803912E0: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803912E4: b           L_8039198C
    // 0x803912E8: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x803912E8: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_803912EC:
    // 0x803912EC: jal         0x80396714
    // 0x803912F0: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_86;
    // 0x803912F0: nop

    after_86:
    // 0x803912F4: beq         $v0, $zero, L_80391308
    if (ctx->r2 == 0) {
        // 0x803912F8: nop
    
            goto L_80391308;
    }
    // 0x803912F8: nop

    // 0x803912FC: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80391300: addiu       $t7, $t6, 0x2
    ctx->r15 = ADD32(ctx->r14, 0X2);
    // 0x80391304: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
L_80391308:
    // 0x80391308: jal         0x80396748
    // 0x8039130C: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_87;
    // 0x8039130C: nop

    after_87:
    // 0x80391310: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80391314: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_23;
    // 0x80391314: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_23:
    // 0x80391318: jal         0x8039264C
    // 0x8039131C: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_88;
    // 0x8039131C: nop

    after_88:
    // 0x80391320: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80391324: addiu       $t9, $t9, 0x6730
    ctx->r25 = ADD32(ctx->r25, 0X6730);
    // 0x80391328: lw          $at, 0x0($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X0);
    // 0x8039132C: lw          $t7, 0x4($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X4);
    // 0x80391330: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80391334: addiu       $t8, $t8, 0x683C
    ctx->r24 = ADD32(ctx->r24, 0X683C);
    // 0x80391338: sw          $at, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r1;
    // 0x8039133C: sw          $t7, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r15;
    // 0x80391340: lw          $t7, 0xC($t9)
    ctx->r15 = MEM_W(ctx->r25, 0XC);
    // 0x80391344: lw          $at, 0x8($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X8);
    // 0x80391348: sw          $t7, 0xC($t8)
    MEM_W(0XC, ctx->r24) = ctx->r15;
    // 0x8039134C: sw          $at, 0x8($t8)
    MEM_W(0X8, ctx->r24) = ctx->r1;
    // 0x80391350: lw          $at, 0x10($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X10);
    // 0x80391354: lw          $t7, 0x14($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X14);
    // 0x80391358: sw          $at, 0x10($t8)
    MEM_W(0X10, ctx->r24) = ctx->r1;
    // 0x8039135C: b           L_8039198C
    // 0x80391360: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
        goto L_8039198C;
    // 0x80391360: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
L_80391364:
    // 0x80391364: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80391368: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x8039136C: sh          $t8, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r24;
    // 0x80391370: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x80391374: slti        $at, $t9, 0x9
    ctx->r1 = SIGNED(ctx->r25) < 0X9 ? 1 : 0;
    // 0x80391378: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x8039137C: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_24;
    // 0x8039137C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_24:
    // 0x80391380: sh          $zero, 0x18($s0)
    MEM_H(0X18, ctx->r16) = 0;
    // 0x80391384: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80391388: b           L_8039198C
    // 0x8039138C: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x8039138C: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
L_80391390:
    // 0x80391390: jal         0x8039BBB8
    // 0x80391394: nop

    func_8039BBB8_7AD268(rdram, ctx);
        goto after_89;
    // 0x80391394: nop

    after_89:
    // 0x80391398: jal         0x8039D6A4
    // 0x8039139C: nop

    determine_available_levels(rdram, ctx);
        goto after_90;
    // 0x8039139C: nop

    after_90:
    // 0x803913A0: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x803913A4: sb          $t0, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = ctx->r8;
    // 0x803913A8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803913AC: jal         0x802F07D0
    // 0x803913B0: sw          $zero, 0x2D30($at)
    MEM_W(0X2D30, ctx->r1) = 0;
    static_2_802F07D0(rdram, ctx);
        goto after_91;
    // 0x803913B0: sw          $zero, 0x2D30($at)
    MEM_W(0X2D30, ctx->r1) = 0;
    after_91:
    // 0x803913B4: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x803913B8: addiu       $t6, $t6, 0x6730
    ctx->r14 = ADD32(ctx->r14, 0X6730);
    // 0x803913BC: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x803913C0: lw          $t9, 0x4($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X4);
    // 0x803913C4: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x803913C8: addiu       $t7, $t7, 0x683C
    ctx->r15 = ADD32(ctx->r15, 0X683C);
    // 0x803913CC: sw          $at, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r1;
    // 0x803913D0: sw          $t9, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r25;
    // 0x803913D4: lw          $t9, 0xC($t6)
    ctx->r25 = MEM_W(ctx->r14, 0XC);
    // 0x803913D8: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x803913DC: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x803913E0: sw          $t9, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r25;
    // 0x803913E4: sw          $at, 0x8($t7)
    MEM_W(0X8, ctx->r15) = ctx->r1;
    // 0x803913E8: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x803913EC: lw          $t9, 0x14($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X14);
    // 0x803913F0: sw          $at, 0x10($t7)
    MEM_W(0X10, ctx->r15) = ctx->r1;
    // 0x803913F4: sw          $t9, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r25;
    // 0x803913F8: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x803913FC: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80391400: sb          $t0, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r8;
    // 0x80391404: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x80391408: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x8039140C: jal         0x80140D20
    // 0x80391410: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    guRandom(rdram, ctx);
        goto after_92;
    // 0x80391410: sb          $t0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r8;
    after_92:
    // 0x80391414: bgez        $v0, L_80391428
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80391418: andi        $a0, $v0, 0x3
        ctx->r4 = ctx->r2 & 0X3;
            goto L_80391428;
    }
    // 0x80391418: andi        $a0, $v0, 0x3
    ctx->r4 = ctx->r2 & 0X3;
    // 0x8039141C: beq         $a0, $zero, L_80391428
    if (ctx->r4 == 0) {
        // 0x80391420: nop
    
            goto L_80391428;
    }
    // 0x80391420: nop

    // 0x80391424: addiu       $a0, $a0, -0x4
    ctx->r4 = ADD32(ctx->r4, -0X4);
L_80391428:
    // 0x80391428: addiu       $a0, $a0, 0xD
    ctx->r4 = ADD32(ctx->r4, 0XD);
    // 0x8039142C: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80391430: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80391434: jal         0x80397734
    // 0x80391438: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_93;
    // 0x80391438: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_93:
    // 0x8039143C: addiu       $a0, $zero, 0xB
    ctx->r4 = ADD32(0, 0XB);
    // 0x80391440: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391444: jal         0x8039661C
    // 0x80391448: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_94;
    // 0x80391448: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_94:
    // 0x8039144C: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80391450: mtc1        $at, $f12
    ctx->f12.u32l = ctx->r1;
    // 0x80391454: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80391458: jal         0x8013385C
    // 0x8039145C: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    start_sfx_volume_fade(rdram, ctx);
        goto after_95;
    // 0x8039145C: lui         $a2, 0x41A0
    ctx->r6 = S32(0X41A0 << 16);
    after_95:
    // 0x80391460: b           L_80391990
    // 0x80391464: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80391464: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80391468:
    // 0x80391468: jal         0x80396748
    // 0x8039146C: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_96;
    // 0x8039146C: nop

    after_96:
    // 0x80391470: beq         $v0, $zero, L_803914D0
    if (ctx->r2 == 0) {
        // 0x80391474: addiu       $t8, $zero, 0x19
        ctx->r24 = ADD32(0, 0X19);
            goto L_803914D0;
    }
    // 0x80391474: addiu       $t8, $zero, 0x19
    ctx->r24 = ADD32(0, 0X19);
    // 0x80391478: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x8039147C: jal         0x8039264C
    // 0x80391480: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    func_8039264C_7A3CFC(rdram, ctx);
        goto after_97;
    // 0x80391480: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    after_97:
    // 0x80391484: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80391488: addiu       $t6, $t6, 0x6700
    ctx->r14 = ADD32(ctx->r14, 0X6700);
    // 0x8039148C: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x80391490: lw          $t8, 0x4($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X4);
    // 0x80391494: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80391498: addiu       $t7, $t7, 0x683C
    ctx->r15 = ADD32(ctx->r15, 0X683C);
    // 0x8039149C: sw          $at, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r1;
    // 0x803914A0: sw          $t8, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r24;
    // 0x803914A4: lw          $t8, 0xC($t6)
    ctx->r24 = MEM_W(ctx->r14, 0XC);
    // 0x803914A8: lw          $at, 0x8($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X8);
    // 0x803914AC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803914B0: sw          $t8, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r24;
    // 0x803914B4: sw          $at, 0x8($t7)
    MEM_W(0X8, ctx->r15) = ctx->r1;
    // 0x803914B8: lw          $at, 0x10($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X10);
    // 0x803914BC: lw          $t8, 0x14($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X14);
    // 0x803914C0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803914C4: sw          $at, 0x10($t7)
    MEM_W(0X10, ctx->r15) = ctx->r1;
    // 0x803914C8: jal         0x80397734
    // 0x803914CC: sw          $t8, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r24;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_98;
    // 0x803914CC: sw          $t8, 0x14($t7)
    MEM_W(0X14, ctx->r15) = ctx->r24;
    after_98:
L_803914D0:
    // 0x803914D0: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x803914D4: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x803914D8: sh          $t7, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r15;
    // 0x803914DC: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x803914E0: slti        $at, $t6, 0x1F
    ctx->r1 = SIGNED(ctx->r14) < 0X1F ? 1 : 0;
    // 0x803914E4: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x803914E8: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_25;
    // 0x803914E8: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_25:
    // 0x803914EC: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x803914F0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803914F4: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803914F8: b           L_8039198C
    // 0x803914FC: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x803914FC: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_80391500:
    // 0x80391500: jal         0x80396748
    // 0x80391504: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_99;
    // 0x80391504: nop

    after_99:
    // 0x80391508: beql        $v0, $zero, L_8039152C
    if (ctx->r2 == 0) {
        // 0x8039150C: lh          $t7, 0x1A($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X1A);
            goto L_8039152C;
    }
    goto skip_26;
    // 0x8039150C: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    skip_26:
    // 0x80391510: jal         0x8039264C
    // 0x80391514: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_100;
    // 0x80391514: nop

    after_100:
    // 0x80391518: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039151C: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391520: jal         0x8039661C
    // 0x80391524: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_101;
    // 0x80391524: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_101:
    // 0x80391528: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
L_8039152C:
    // 0x8039152C: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x80391530: jal         0x80396714
    // 0x80391534: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    func_80396714_7A7DC4(rdram, ctx);
        goto after_102;
    // 0x80391534: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    after_102:
    // 0x80391538: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x8039153C: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_27;
    // 0x8039153C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_27:
    // 0x80391540: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x80391544: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80391548: b           L_8039198C
    // 0x8039154C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x8039154C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_80391550:
    // 0x80391550: jal         0x80396748
    // 0x80391554: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_103;
    // 0x80391554: nop

    after_103:
    // 0x80391558: beq         $v0, $zero, L_80391578
    if (ctx->r2 == 0) {
        // 0x8039155C: addiu       $t7, $zero, 0x18
        ctx->r15 = ADD32(0, 0X18);
            goto L_80391578;
    }
    // 0x8039155C: addiu       $t7, $zero, 0x18
    ctx->r15 = ADD32(0, 0X18);
    // 0x80391560: jal         0x8039264C
    // 0x80391564: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    func_8039264C_7A3CFC(rdram, ctx);
        goto after_104;
    // 0x80391564: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    after_104:
    // 0x80391568: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039156C: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391570: jal         0x8039661C
    // 0x80391574: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_105;
    // 0x80391574: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_105:
L_80391578:
    // 0x80391578: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8039157C: lhu         $t6, 0x713C($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X713C);
    // 0x80391580: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80391584: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391588: bnel        $t6, $zero, L_803915A8
    if (ctx->r14 != 0) {
        // 0x8039158C: lh          $t7, 0x1A($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X1A);
            goto L_803915A8;
    }
    goto skip_28;
    // 0x8039158C: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    skip_28:
    // 0x80391590: jal         0x8039661C
    // 0x80391594: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_106;
    // 0x80391594: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_106:
    // 0x80391598: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x8039159C: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803915A0: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
    // 0x803915A4: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
L_803915A8:
    // 0x803915A8: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x803915AC: b           L_8039198C
    // 0x803915B0: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
        goto L_8039198C;
    // 0x803915B0: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
L_803915B4:
    // 0x803915B4: jal         0x80396714
    // 0x803915B8: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_107;
    // 0x803915B8: nop

    after_107:
    // 0x803915BC: beq         $v0, $zero, L_8039198C
    if (ctx->r2 == 0) {
        // 0x803915C0: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_8039198C;
    }
    // 0x803915C0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803915C4: jal         0x80397734
    // 0x803915C8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_108;
    // 0x803915C8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_108:
    // 0x803915CC: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
    // 0x803915D0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803915D4: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803915D8: b           L_8039198C
    // 0x803915DC: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x803915DC: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_803915E0:
    // 0x803915E0: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x803915E4: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x803915E8: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x803915EC: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x803915F0: lh          $t8, 0x1A($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X1A);
    // 0x803915F4: slti        $at, $t8, 0x3
    ctx->r1 = SIGNED(ctx->r24) < 0X3 ? 1 : 0;
    // 0x803915F8: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x803915FC: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_29;
    // 0x803915FC: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_29:
    // 0x80391600: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
    // 0x80391604: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80391608: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x8039160C: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x80391610: b           L_8039198C
    // 0x80391614: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
        goto L_8039198C;
    // 0x80391614: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
L_80391618:
    // 0x80391618: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x8039161C: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80391620: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80391624: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x80391628: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x8039162C: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80391630: jal         0x8039884C
    // 0x80391634: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    func_8039884C_7A9EFC(rdram, ctx);
        goto after_109;
    // 0x80391634: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    after_109:
    // 0x80391638: jal         0x8039895C
    // 0x8039163C: nop

    func_8039895C_7AA00C(rdram, ctx);
        goto after_110;
    // 0x8039163C: nop

    after_110:
    // 0x80391640: b           L_80391990
    // 0x80391644: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80391644: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80391648:
    // 0x80391648: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    // 0x8039164C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80391650: sb          $t0, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = ctx->r8;
    // 0x80391654: bne         $v0, $zero, L_8039166C
    if (ctx->r2 != 0) {
        // 0x80391658: addiu       $a0, $zero, 0xB
        ctx->r4 = ADD32(0, 0XB);
            goto L_8039166C;
    }
    // 0x80391658: addiu       $a0, $zero, 0xB
    ctx->r4 = ADD32(0, 0XB);
    // 0x8039165C: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391660: jal         0x8039661C
    // 0x80391664: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_111;
    // 0x80391664: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_111:
    // 0x80391668: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
L_8039166C:
    // 0x8039166C: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x80391670: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x80391674: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    // 0x80391678: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039167C: bnel        $v0, $at, L_8039169C
    if (ctx->r2 != ctx->r1) {
        // 0x80391680: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8039169C;
    }
    goto skip_30;
    // 0x80391680: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    skip_30:
    // 0x80391684: jal         0x8039BBB8
    // 0x80391688: nop

    func_8039BBB8_7AD268(rdram, ctx);
        goto after_112;
    // 0x80391688: nop

    after_112:
    // 0x8039168C: jal         0x8039D6A4
    // 0x80391690: nop

    determine_available_levels(rdram, ctx);
        goto after_113;
    // 0x80391690: nop

    after_113:
    // 0x80391694: lh          $v0, 0x1A($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X1A);
    // 0x80391698: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
L_8039169C:
    // 0x8039169C: bne         $v0, $at, L_8039198C
    if (ctx->r2 != ctx->r1) {
        // 0x803916A0: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_8039198C;
    }
    // 0x803916A0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803916A4: lh          $v0, 0x2D38($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2D38);
    // 0x803916A8: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x803916AC: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x803916B0: beq         $v0, $at, L_803916D0
    if (ctx->r2 == ctx->r1) {
        // 0x803916B4: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803916D0;
    }
    // 0x803916B4: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803916B8: beq         $v0, $at, L_803916D0
    if (ctx->r2 == ctx->r1) {
        // 0x803916BC: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_803916D0;
    }
    // 0x803916BC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x803916C0: beq         $v0, $at, L_803916D0
    if (ctx->r2 == ctx->r1) {
        // 0x803916C4: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_803916D0;
    }
    // 0x803916C4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x803916C8: bne         $v0, $at, L_80391750
    if (ctx->r2 != ctx->r1) {
        // 0x803916CC: nop
    
            goto L_80391750;
    }
    // 0x803916CC: nop

L_803916D0:
    // 0x803916D0: lw          $t8, 0x4D28($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X4D28);
    // 0x803916D4: andi        $t9, $t8, 0x2
    ctx->r25 = ctx->r24 & 0X2;
    // 0x803916D8: beq         $t9, $zero, L_80391718
    if (ctx->r25 == 0) {
        // 0x803916DC: nop
    
            goto L_80391718;
    }
    // 0x803916DC: nop

    // 0x803916E0: jal         0x80140D20
    // 0x803916E4: nop

    guRandom(rdram, ctx);
        goto after_114;
    // 0x803916E4: nop

    after_114:
    // 0x803916E8: bgez        $v0, L_803916FC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803916EC: andi        $a0, $v0, 0x3
        ctx->r4 = ctx->r2 & 0X3;
            goto L_803916FC;
    }
    // 0x803916EC: andi        $a0, $v0, 0x3
    ctx->r4 = ctx->r2 & 0X3;
    // 0x803916F0: beq         $a0, $zero, L_803916FC
    if (ctx->r4 == 0) {
        // 0x803916F4: nop
    
            goto L_803916FC;
    }
    // 0x803916F4: nop

    // 0x803916F8: addiu       $a0, $a0, -0x4
    ctx->r4 = ADD32(ctx->r4, -0X4);
L_803916FC:
    // 0x803916FC: addiu       $a0, $a0, 0x11
    ctx->r4 = ADD32(ctx->r4, 0X11);
    // 0x80391700: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80391704: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80391708: jal         0x80397734
    // 0x8039170C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_115;
    // 0x8039170C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_115:
    // 0x80391710: b           L_80391784
    // 0x80391714: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
        goto L_80391784;
    // 0x80391714: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
L_80391718:
    // 0x80391718: jal         0x80140D20
    // 0x8039171C: nop

    guRandom(rdram, ctx);
        goto after_116;
    // 0x8039171C: nop

    after_116:
    // 0x80391720: bgez        $v0, L_80391734
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80391724: andi        $a0, $v0, 0x3
        ctx->r4 = ctx->r2 & 0X3;
            goto L_80391734;
    }
    // 0x80391724: andi        $a0, $v0, 0x3
    ctx->r4 = ctx->r2 & 0X3;
    // 0x80391728: beq         $a0, $zero, L_80391734
    if (ctx->r4 == 0) {
        // 0x8039172C: nop
    
            goto L_80391734;
    }
    // 0x8039172C: nop

    // 0x80391730: addiu       $a0, $a0, -0x4
    ctx->r4 = ADD32(ctx->r4, -0X4);
L_80391734:
    // 0x80391734: addiu       $a0, $a0, 0xD
    ctx->r4 = ADD32(ctx->r4, 0XD);
    // 0x80391738: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x8039173C: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80391740: jal         0x80397734
    // 0x80391744: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_117;
    // 0x80391744: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_117:
    // 0x80391748: b           L_80391784
    // 0x8039174C: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
        goto L_80391784;
    // 0x8039174C: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
L_80391750:
    // 0x80391750: jal         0x80140D20
    // 0x80391754: nop

    guRandom(rdram, ctx);
        goto after_118;
    // 0x80391754: nop

    after_118:
    // 0x80391758: bgez        $v0, L_8039176C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8039175C: andi        $a0, $v0, 0x3
        ctx->r4 = ctx->r2 & 0X3;
            goto L_8039176C;
    }
    // 0x8039175C: andi        $a0, $v0, 0x3
    ctx->r4 = ctx->r2 & 0X3;
    // 0x80391760: beq         $a0, $zero, L_8039176C
    if (ctx->r4 == 0) {
        // 0x80391764: nop
    
            goto L_8039176C;
    }
    // 0x80391764: nop

    // 0x80391768: addiu       $a0, $a0, -0x4
    ctx->r4 = ADD32(ctx->r4, -0X4);
L_8039176C:
    // 0x8039176C: addiu       $a0, $a0, 0x11
    ctx->r4 = ADD32(ctx->r4, 0X11);
    // 0x80391770: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80391774: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80391778: jal         0x80397734
    // 0x8039177C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_80397734_7A8DE4(rdram, ctx);
        goto after_119;
    // 0x8039177C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_119:
    // 0x80391780: lh          $t8, 0x18($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X18);
L_80391784:
    // 0x80391784: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80391788: b           L_8039198C
    // 0x8039178C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x8039178C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_80391790:
    // 0x80391790: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80391794: lhu         $t7, 0x713C($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X713C);
    // 0x80391798: beq         $t7, $zero, L_803917B0
    if (ctx->r15 == 0) {
        // 0x8039179C: nop
    
            goto L_803917B0;
    }
    // 0x8039179C: nop

    // 0x803917A0: jal         0x80396748
    // 0x803917A4: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_120;
    // 0x803917A4: nop

    after_120:
    // 0x803917A8: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x803917AC: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_31;
    // 0x803917AC: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_31:
L_803917B0:
    // 0x803917B0: jal         0x8039264C
    // 0x803917B4: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_121;
    // 0x803917B4: nop

    after_121:
    // 0x803917B8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803917BC: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x803917C0: addiu       $at, $zero, 0x22
    ctx->r1 = ADD32(0, 0X22);
    // 0x803917C4: addiu       $t8, $zero, 0x28
    ctx->r24 = ADD32(0, 0X28);
    // 0x803917C8: bne         $v0, $at, L_803917F8
    if (ctx->r2 != ctx->r1) {
        // 0x803917CC: addiu       $t6, $v0, 0x1
        ctx->r14 = ADD32(ctx->r2, 0X1);
            goto L_803917F8;
    }
    // 0x803917CC: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x803917D0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803917D4: sh          $t6, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r14;
    // 0x803917D8: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x803917DC: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803917E0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x803917E4: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    // 0x803917E8: jal         0x8039661C
    // 0x803917EC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_122;
    // 0x803917EC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_122:
    // 0x803917F0: b           L_80391990
    // 0x803917F4: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803917F4: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803917F8:
    // 0x803917F8: jal         0x80396748
    // 0x803917FC: nop

    func_80396748_7A7DF8(rdram, ctx);
        goto after_123;
    // 0x803917FC: nop

    after_123:
    // 0x80391800: beq         $v0, $zero, L_80391854
    if (ctx->r2 == 0) {
        // 0x80391804: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_80391854;
    }
    // 0x80391804: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80391808: jal         0x8039264C
    // 0x8039180C: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_124;
    // 0x8039180C: nop

    after_124:
    // 0x80391810: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80391814: addiu       $t7, $t7, 0x6700
    ctx->r15 = ADD32(ctx->r15, 0X6700);
    // 0x80391818: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x8039181C: lw          $t8, 0x4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X4);
    // 0x80391820: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80391824: addiu       $t9, $t9, 0x683C
    ctx->r25 = ADD32(ctx->r25, 0X683C);
    // 0x80391828: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x8039182C: sw          $t8, 0x4($t9)
    MEM_W(0X4, ctx->r25) = ctx->r24;
    // 0x80391830: lw          $t8, 0xC($t7)
    ctx->r24 = MEM_W(ctx->r15, 0XC);
    // 0x80391834: lw          $at, 0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X8);
    // 0x80391838: sw          $t8, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r24;
    // 0x8039183C: sw          $at, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r1;
    // 0x80391840: lw          $at, 0x10($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X10);
    // 0x80391844: lw          $t8, 0x14($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X14);
    // 0x80391848: sw          $at, 0x10($t9)
    MEM_W(0X10, ctx->r25) = ctx->r1;
    // 0x8039184C: b           L_80391860
    // 0x80391850: sw          $t8, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r24;
        goto L_80391860;
    // 0x80391850: sw          $t8, 0x14($t9)
    MEM_W(0X14, ctx->r25) = ctx->r24;
L_80391854:
    // 0x80391854: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80391858: jal         0x8039661C
    // 0x8039185C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_125;
    // 0x8039185C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_125:
L_80391860:
    // 0x80391860: lh          $t6, 0x18($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X18);
    // 0x80391864: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x80391868: b           L_8039198C
    // 0x8039186C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
        goto L_8039198C;
    // 0x8039186C: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
L_80391870:
    // 0x80391870: jal         0x80396714
    // 0x80391874: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_126;
    // 0x80391874: nop

    after_126:
    // 0x80391878: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x8039187C: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_32;
    // 0x8039187C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_32:
    // 0x80391880: lh          $t7, 0x18($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X18);
    // 0x80391884: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80391888: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8039188C: b           L_8039198C
    // 0x80391890: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
        goto L_8039198C;
    // 0x80391890: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
L_80391894:
    // 0x80391894: lh          $t6, 0x1A($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1A);
    // 0x80391898: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039189C: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x803918A0: addiu       $t9, $t6, 0x1
    ctx->r25 = ADD32(ctx->r14, 0X1);
    // 0x803918A4: sh          $t9, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r25;
    // 0x803918A8: lh          $t7, 0x1A($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X1A);
    // 0x803918AC: bnel        $t7, $at, L_80391990
    if (ctx->r15 != ctx->r1) {
        // 0x803918B0: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_33;
    // 0x803918B0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_33:
    // 0x803918B4: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x803918B8: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x803918BC: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x803918C0: b           L_8039198C
    // 0x803918C4: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
        goto L_8039198C;
    // 0x803918C4: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
L_803918C8:
    // 0x803918C8: addiu       $t6, $zero, 0x4
    ctx->r14 = ADD32(0, 0X4);
    // 0x803918CC: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
    // 0x803918D0: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x803918D4: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x803918D8: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x803918DC: jal         0x8039884C
    // 0x803918E0: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    func_8039884C_7A9EFC(rdram, ctx);
        goto after_127;
    // 0x803918E0: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    after_127:
    // 0x803918E4: jal         0x8039895C
    // 0x803918E8: nop

    func_8039895C_7AA00C(rdram, ctx);
        goto after_128;
    // 0x803918E8: nop

    after_128:
    // 0x803918EC: b           L_80391990
    // 0x803918F0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x803918F0: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_803918F4:
    // 0x803918F4: jal         0x80396714
    // 0x803918F8: nop

    func_80396714_7A7DC4(rdram, ctx);
        goto after_129;
    // 0x803918F8: nop

    after_129:
    // 0x803918FC: beql        $v0, $zero, L_80391990
    if (ctx->r2 == 0) {
        // 0x80391900: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_34;
    // 0x80391900: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_34:
    // 0x80391904: lh          $t9, 0x18($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X18);
    // 0x80391908: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x8039190C: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80391910: jal         0x802F07D0
    // 0x80391914: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    static_2_802F07D0(rdram, ctx);
        goto after_130;
    // 0x80391914: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    after_130:
    // 0x80391918: jal         0x802F07E8
    // 0x8039191C: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    static_2_802F07E8(rdram, ctx);
        goto after_131;
    // 0x8039191C: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    after_131:
    // 0x80391920: b           L_80391990
    // 0x80391924: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
        goto L_80391990;
    // 0x80391924: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80391928:
    // 0x80391928: lh          $t8, 0x1A($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X1A);
    // 0x8039192C: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80391930: addiu       $t6, $t8, 0x1
    ctx->r14 = ADD32(ctx->r24, 0X1);
    // 0x80391934: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x80391938: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x8039193C: slti        $at, $t9, 0xD
    ctx->r1 = SIGNED(ctx->r25) < 0XD ? 1 : 0;
    // 0x80391940: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x80391944: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_35;
    // 0x80391944: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_35:
    // 0x80391948: sb          $zero, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = 0;
    // 0x8039194C: sb          $zero, 0x2B($s0)
    MEM_B(0X2B, ctx->r16) = 0;
    // 0x80391950: sb          $zero, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = 0;
    // 0x80391954: b           L_8039198C
    // 0x80391958: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
        goto L_8039198C;
    // 0x80391958: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
L_8039195C:
    // 0x8039195C: lh          $t8, 0x1A($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X1A);
    // 0x80391960: addiu       $t6, $t8, 0x1
    ctx->r14 = ADD32(ctx->r24, 0X1);
    // 0x80391964: sh          $t6, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r14;
    // 0x80391968: lh          $t9, 0x1A($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1A);
    // 0x8039196C: slti        $at, $t9, 0x2
    ctx->r1 = SIGNED(ctx->r25) < 0X2 ? 1 : 0;
    // 0x80391970: bnel        $at, $zero, L_80391990
    if (ctx->r1 != 0) {
        // 0x80391974: lh          $t7, 0x3C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X3C);
            goto L_80391990;
    }
    goto skip_36;
    // 0x80391974: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
    skip_36:
    // 0x80391978: jal         0x8038B840
    // 0x8039197C: nop

    reset_credits_counters(rdram, ctx);
        goto after_132;
    // 0x8039197C: nop

    after_132:
    // 0x80391980: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80391984: jal         0x8038FC58
    // 0x80391988: sh          $zero, 0x428($at)
    MEM_H(0X428, ctx->r1) = 0;
    func_8038FC58_7A1308(rdram, ctx);
        goto after_133;
    // 0x80391988: sh          $zero, 0x428($at)
    MEM_H(0X428, ctx->r1) = 0;
    after_133:
L_8039198C:
    // 0x8039198C: lh          $t7, 0x3C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3C);
L_80391990:
    // 0x80391990: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80391994: bnel        $t7, $at, L_80391A28
    if (ctx->r15 != ctx->r1) {
        // 0x80391998: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80391A28;
    }
    goto skip_37;
    // 0x80391998: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_37:
    // 0x8039199C: lbu         $t8, 0x2C($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2C);
    // 0x803919A0: beql        $t8, $zero, L_80391A28
    if (ctx->r24 == 0) {
        // 0x803919A4: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80391A28;
    }
    goto skip_38;
    // 0x803919A4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_38:
    // 0x803919A8: jal         0x80395B58
    // 0x803919AC: nop

    func_80395B58_7A7208(rdram, ctx);
        goto after_134;
    // 0x803919AC: nop

    after_134:
    // 0x803919B0: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x803919B4: addiu       $s0, $s0, -0x6170
    ctx->r16 = ADD32(ctx->r16, -0X6170);
    // 0x803919B8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803919BC: addiu       $a1, $zero, 0x3C0
    ctx->r5 = ADD32(0, 0X3C0);
    // 0x803919C0: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803919C4: jal         0x8039546C
    // 0x803919C8: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    func_8039546C_7A6B1C(rdram, ctx);
        goto after_135;
    // 0x803919C8: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    after_135:
    // 0x803919CC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803919D0: addiu       $a1, $zero, 0x3E8
    ctx->r5 = ADD32(0, 0X3E8);
    // 0x803919D4: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803919D8: jal         0x8039546C
    // 0x803919DC: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    func_8039546C_7A6B1C(rdram, ctx);
        goto after_136;
    // 0x803919DC: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    after_136:
    // 0x803919E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803919E4: addiu       $a1, $zero, 0x410
    ctx->r5 = ADD32(0, 0X410);
    // 0x803919E8: addiu       $a2, $zero, 0x435
    ctx->r6 = ADD32(0, 0X435);
    // 0x803919EC: jal         0x8039546C
    // 0x803919F0: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    func_8039546C_7A6B1C(rdram, ctx);
        goto after_137;
    // 0x803919F0: addiu       $a3, $zero, 0x416
    ctx->r7 = ADD32(0, 0X416);
    after_137:
    // 0x803919F4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x803919F8: lw          $v0, -0x6184($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6184);
    // 0x803919FC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80391A00: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x80391A04: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80391A08: sw          $t6, -0x6184($at)
    MEM_W(-0X6184, ctx->r1) = ctx->r14;
    // 0x80391A0C: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80391A10: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80391A14: lw          $t7, 0x4278($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X4278);
    // 0x80391A18: ori         $at, $zero, 0xDAC0
    ctx->r1 = 0 | 0XDAC0;
    // 0x80391A1C: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x80391A20: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80391A24: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80391A28:
    // 0x80391A28: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80391A2C: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x80391A30: jr          $ra
    // 0x80391A34: nop

    return;
    // 0x80391A34: nop

;}
RECOMP_FUNC void func_80391A38_7A30E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80391A38: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80391A3C: lwc1        $f4, 0x32C($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X32C);
    // 0x80391A40: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80391A44: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80391A48: addiu       $a0, $zero, 0x491
    ctx->r4 = ADD32(0, 0X491);
    // 0x80391A4C: addiu       $a1, $zero, 0x49
    ctx->r5 = ADD32(0, 0X49);
    // 0x80391A50: addiu       $a2, $zero, 0x4000
    ctx->r6 = ADD32(0, 0X4000);
    // 0x80391A54: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391A58: jal         0x8032CD20
    // 0x80391A5C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_0;
    // 0x80391A5C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_0:
    // 0x80391A60: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80391A64: lbu         $t6, 0x66AA($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X66AA);
    // 0x80391A68: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80391A6C: bnel        $t6, $at, L_80391C84
    if (ctx->r14 != ctx->r1) {
        // 0x80391A70: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80391C84;
    }
    goto skip_0;
    // 0x80391A70: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80391A74: jal         0x80140D20
    // 0x80391A78: nop

    guRandom(rdram, ctx);
        goto after_1;
    // 0x80391A78: nop

    after_1:
    // 0x80391A7C: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80391A80: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80391A84: mfhi        $t7
    ctx->r15 = hi;
    // 0x80391A88: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80391A8C: bne         $t7, $at, L_80391AB0
    if (ctx->r15 != ctx->r1) {
        // 0x80391A90: nop
    
            goto L_80391AB0;
    }
    // 0x80391A90: nop

    // 0x80391A94: jal         0x80140D20
    // 0x80391A98: nop

    guRandom(rdram, ctx);
        goto after_2;
    // 0x80391A98: nop

    after_2:
    // 0x80391A9C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80391AA0: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80391AA4: mfhi        $t8
    ctx->r24 = hi;
    // 0x80391AA8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80391AAC: sw          $t8, 0x6880($at)
    MEM_W(0X6880, ctx->r1) = ctx->r24;
L_80391AB0:
    // 0x80391AB0: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80391AB4: lw          $t9, 0x6880($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X6880);
    // 0x80391AB8: sltiu       $at, $t9, 0x6
    ctx->r1 = ctx->r25 < 0X6 ? 1 : 0;
    // 0x80391ABC: beq         $at, $zero, L_80391C80
    if (ctx->r1 == 0) {
        // 0x80391AC0: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_80391C80;
    }
    // 0x80391AC0: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80391AC4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80391AC8: addu        $at, $at, $t9
    gpr jr_addend_80391AD0 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80391ACC: lw          $t9, 0x330($at)
    ctx->r25 = ADD32(ctx->r1, 0X330);
    // 0x80391AD0: jr          $t9
    // 0x80391AD4: nop

    switch (jr_addend_80391AD0 >> 2) {
        case 0: goto L_80391AD8; break;
        case 1: goto L_80391B20; break;
        case 2: goto L_80391B68; break;
        case 3: goto L_80391BB0; break;
        case 4: goto L_80391BF8; break;
        case 5: goto L_80391C40; break;
        default: switch_error(__func__, 0x80391AD0, 0x803C0330);
    }
    // 0x80391AD4: nop

L_80391AD8:
    // 0x80391AD8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391ADC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80391AE0: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391AE4: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391AE8: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391AEC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391AF0: jal         0x8032CD20
    // 0x80391AF4: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_3;
    // 0x80391AF4: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    after_3:
    // 0x80391AF8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391AFC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80391B00: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391B04: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391B08: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391B0C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391B10: jal         0x8032CD20
    // 0x80391B14: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_4;
    // 0x80391B14: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    after_4:
    // 0x80391B18: b           L_80391C84
    // 0x80391B1C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80391C84;
    // 0x80391B1C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391B20:
    // 0x80391B20: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391B24: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80391B28: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391B2C: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391B30: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391B34: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391B38: jal         0x8032CD20
    // 0x80391B3C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_5;
    // 0x80391B3C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    after_5:
    // 0x80391B40: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391B44: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80391B48: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391B4C: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391B50: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391B54: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391B58: jal         0x8032CD20
    // 0x80391B5C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_6;
    // 0x80391B5C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    after_6:
    // 0x80391B60: b           L_80391C84
    // 0x80391B64: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80391C84;
    // 0x80391B64: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391B68:
    // 0x80391B68: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391B6C: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80391B70: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391B74: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391B78: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391B7C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391B80: jal         0x8032CD20
    // 0x80391B84: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_7;
    // 0x80391B84: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    after_7:
    // 0x80391B88: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391B8C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80391B90: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391B94: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391B98: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391B9C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391BA0: jal         0x8032CD20
    // 0x80391BA4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_8;
    // 0x80391BA4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_8:
    // 0x80391BA8: b           L_80391C84
    // 0x80391BAC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80391C84;
    // 0x80391BAC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391BB0:
    // 0x80391BB0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391BB4: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80391BB8: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391BBC: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391BC0: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391BC4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391BC8: jal         0x8032CD20
    // 0x80391BCC: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_9;
    // 0x80391BCC: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    after_9:
    // 0x80391BD0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391BD4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80391BD8: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391BDC: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391BE0: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391BE4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391BE8: jal         0x8032CD20
    // 0x80391BEC: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_10;
    // 0x80391BEC: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    after_10:
    // 0x80391BF0: b           L_80391C84
    // 0x80391BF4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80391C84;
    // 0x80391BF4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391BF8:
    // 0x80391BF8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80391BFC: lwc1        $f10, 0x348($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X348);
    // 0x80391C00: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391C04: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391C08: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391C0C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391C10: jal         0x8032CD20
    // 0x80391C14: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_11;
    // 0x80391C14: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    after_11:
    // 0x80391C18: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391C1C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80391C20: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391C24: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391C28: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391C2C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391C30: jal         0x8032CD20
    // 0x80391C34: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_12;
    // 0x80391C34: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    after_12:
    // 0x80391C38: b           L_80391C84
    // 0x80391C3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80391C84;
    // 0x80391C3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391C40:
    // 0x80391C40: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80391C44: lwc1        $f18, 0x34C($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X34C);
    // 0x80391C48: addiu       $a0, $zero, 0x4F5
    ctx->r4 = ADD32(0, 0X4F5);
    // 0x80391C4C: addiu       $a1, $zero, 0x84
    ctx->r5 = ADD32(0, 0X84);
    // 0x80391C50: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391C54: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391C58: jal         0x8032CD20
    // 0x80391C5C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_13;
    // 0x80391C5C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    after_13:
    // 0x80391C60: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391C64: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80391C68: addiu       $a0, $zero, 0x559
    ctx->r4 = ADD32(0, 0X559);
    // 0x80391C6C: addiu       $a1, $zero, 0x85
    ctx->r5 = ADD32(0, 0X85);
    // 0x80391C70: addiu       $a2, $zero, 0x1000
    ctx->r6 = ADD32(0, 0X1000);
    // 0x80391C74: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80391C78: jal         0x8032CD20
    // 0x80391C7C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_14;
    // 0x80391C7C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_14:
L_80391C80:
    // 0x80391C80: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80391C84:
    // 0x80391C84: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80391C88: jr          $ra
    // 0x80391C8C: nop

    return;
    // 0x80391C8C: nop

;}
RECOMP_FUNC void func_80391C90_7A3340(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80391C90: addiu       $sp, $sp, -0x118
    ctx->r29 = ADD32(ctx->r29, -0X118);
    // 0x80391C94: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80391C98: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x80391C9C: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80391CA0: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80391CA4: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80391CA8: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80391CAC: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80391CB0: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80391CB4: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80391CB8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80391CBC: sdc1        $f22, 0x10($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X10, ctx->r29);
    // 0x80391CC0: sdc1        $f20, 0x8($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X8, ctx->r29);
    // 0x80391CC4: sw          $a1, 0x11C($sp)
    MEM_W(0X11C, ctx->r29) = ctx->r5;
    // 0x80391CC8: sw          $a3, 0x124($sp)
    MEM_W(0X124, ctx->r29) = ctx->r7;
    // 0x80391CCC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391CD0: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x80391CD4: addiu       $t8, $t8, 0x4270
    ctx->r24 = ADD32(ctx->r24, 0X4270);
    // 0x80391CD8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80391CDC: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80391CE0: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x80391CE4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80391CE8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80391CEC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391CF0: lui         $s3, 0xE700
    ctx->r19 = S32(0XE700 << 16);
    // 0x80391CF4: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x80391CF8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80391CFC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80391D00: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80391D04: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x80391D08: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391D0C: ori         $t7, $t7, 0x1402
    ctx->r15 = ctx->r15 | 0X1402;
    // 0x80391D10: lui         $at, 0x4130
    ctx->r1 = S32(0X4130 << 16);
    // 0x80391D14: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80391D18: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80391D1C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80391D20: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80391D24: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391D28: lui         $t7, 0xC19
    ctx->r15 = S32(0XC19 << 16);
    // 0x80391D2C: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x80391D30: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80391D34: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80391D38: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80391D3C: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x80391D40: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391D44: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x80391D48: ori         $t7, $t7, 0x2078
    ctx->r15 = ctx->r15 | 0X2078;
    // 0x80391D4C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80391D50: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80391D54: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80391D58: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80391D5C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391D60: lui         $t6, 0xFFFC
    ctx->r14 = S32(0XFFFC << 16);
    // 0x80391D64: lui         $t9, 0xFCFF
    ctx->r25 = S32(0XFCFF << 16);
    // 0x80391D68: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80391D6C: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80391D70: ori         $t9, $t9, 0xFFFF
    ctx->r25 = ctx->r25 | 0XFFFF;
    // 0x80391D74: ori         $t6, $t6, 0xF87C
    ctx->r14 = ctx->r14 | 0XF87C;
    // 0x80391D78: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80391D7C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80391D80: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391D84: lui         $t9, 0x2
    ctx->r25 = S32(0X2 << 16);
    // 0x80391D88: ori         $t9, $t9, 0x2200
    ctx->r25 = ctx->r25 | 0X2200;
    // 0x80391D8C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80391D90: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80391D94: lui         $t8, 0xB600
    ctx->r24 = S32(0XB600 << 16);
    // 0x80391D98: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80391D9C: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80391DA0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80391DA4: lui         $t8, 0x8000
    ctx->r24 = S32(0X8000 << 16);
    // 0x80391DA8: lui         $t7, 0xBB00
    ctx->r15 = S32(0XBB00 << 16);
    // 0x80391DAC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80391DB0: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80391DB4: ori         $t7, $t7, 0x1
    ctx->r15 = ctx->r15 | 0X1;
    // 0x80391DB8: ori         $t8, $t8, 0x8000
    ctx->r24 = ctx->r24 | 0X8000;
    // 0x80391DBC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80391DC0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80391DC4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80391DC8: mtc1        $a2, $f12
    ctx->f12.u32l = ctx->r6;
    // 0x80391DCC: lwc1        $f2, 0x128($sp)
    ctx->f2.u32l = MEM_W(ctx->r29, 0X128);
    // 0x80391DD0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80391DD4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80391DD8: lwc1        $f6, 0x11C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X11C);
    // 0x80391DDC: sub.s       $f14, $f2, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f14.fl = ctx->f2.fl - ctx->f12.fl;
    // 0x80391DE0: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80391DE4: addiu       $v1, $v1, 0x4278
    ctx->r3 = ADD32(ctx->r3, 0X4278);
    // 0x80391DE8: sub.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x80391DEC: lwc1        $f6, 0x12C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X12C);
    // 0x80391DF0: lh          $t2, 0xF6($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XF6);
    // 0x80391DF4: div.s       $f16, $f14, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f16.fl = DIV_S(ctx->f14.fl, ctx->f4.fl);
    // 0x80391DF8: lui         $a3, 0x3
    ctx->r7 = S32(0X3 << 16);
    // 0x80391DFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80391E00: addiu       $s1, $zero, 0xB
    ctx->r17 = ADD32(0, 0XB);
    // 0x80391E04: trunc.w.s   $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80391E08: lwc1        $f10, 0x124($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X124);
    // 0x80391E0C: addiu       $s2, $zero, 0x1F
    ctx->r18 = ADD32(0, 0X1F);
    // 0x80391E10: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80391E14: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    // 0x80391E18: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80391E1C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80391E20: mfc1        $s4, $f8
    ctx->r20 = (int32_t)ctx->f8.u32l;
    // 0x80391E24: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x80391E28: addiu       $s5, $zero, 0xFF
    ctx->r21 = ADD32(0, 0XFF);
    // 0x80391E2C: addiu       $s6, $zero, 0x2800
    ctx->r22 = ADD32(0, 0X2800);
    // 0x80391E30: addiu       $s7, $zero, 0x6E0
    ctx->r23 = ADD32(0, 0X6E0);
    // 0x80391E34: ori         $fp, $zero, 0xB2E0
    ctx->r30 = 0 | 0XB2E0;
    // 0x80391E38: lui         $ra, 0xF510
    ctx->r31 = S32(0XF510 << 16);
    // 0x80391E3C: add.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f10.fl + ctx->f4.fl;
    // 0x80391E40: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80391E44: mfc1        $s0, $f8
    ctx->r16 = (int32_t)ctx->f8.u32l;
    // 0x80391E48: nop

L_80391E4C:
    // 0x80391E4C: mtc1        $a1, $f10
    ctx->f10.u32l = ctx->r5;
    // 0x80391E50: nop

    // 0x80391E54: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80391E58: mul.s       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f16.fl, ctx->f4.fl);
    // 0x80391E5C: sub.s       $f18, $f12, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f18.fl = ctx->f12.fl - ctx->f6.fl;
    // 0x80391E60: bne         $a1, $s1, L_80391E80
    if (ctx->r5 != ctx->r17) {
        // 0x80391E64: mov.s       $f0, $f18
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    ctx->f0.fl = ctx->f18.fl;
            goto L_80391E80;
    }
    // 0x80391E64: mov.s       $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    ctx->f0.fl = ctx->f18.fl;
    // 0x80391E68: mtc1        $t2, $f8
    ctx->f8.u32l = ctx->r10;
    // 0x80391E6C: nop

    // 0x80391E70: cvt.s.w     $f20, $f8
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 8);
    ctx->f20.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80391E74: sub.s       $f10, $f18, $f20
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f10.fl = ctx->f18.fl - ctx->f20.fl;
    // 0x80391E78: div.s       $f4, $f10, $f22
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f4.fl = DIV_S(ctx->f10.fl, ctx->f22.fl);
    // 0x80391E7C: add.s       $f0, $f4, $f20
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f0.fl = ctx->f4.fl + ctx->f20.fl;
L_80391E80:
    // 0x80391E80: multu       $a1, $s2
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80391E84: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x80391E88: sll         $t1, $a1, 1
    ctx->r9 = S32(ctx->r5 << 1);
    // 0x80391E8C: sll         $t0, $t1, 16
    ctx->r8 = S32(ctx->r9 << 16);
    // 0x80391E90: sra         $t6, $t0, 16
    ctx->r14 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80391E94: mfc1        $a2, $f6
    ctx->r6 = (int32_t)ctx->f6.u32l;
    // 0x80391E98: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x80391E9C: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x80391EA0: sra         $t9, $t2, 16
    ctx->r25 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80391EA4: mflo        $t4
    ctx->r12 = lo;
    // 0x80391EA8: sll         $t7, $t4, 6
    ctx->r15 = S32(ctx->r12 << 6);
    // 0x80391EAC: or          $t2, $t9, $zero
    ctx->r10 = ctx->r25 | 0;
    // 0x80391EB0: sll         $t3, $t7, 16
    ctx->r11 = S32(ctx->r15 << 16);
    // 0x80391EB4: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80391EB8: sra         $t8, $t3, 16
    ctx->r24 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80391EBC: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80391EC0: bgez        $t6, L_80391ECC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80391EC4: or          $t3, $t8, $zero
        ctx->r11 = ctx->r24 | 0;
            goto L_80391ECC;
    }
    // 0x80391EC4: or          $t3, $t8, $zero
    ctx->r11 = ctx->r24 | 0;
    // 0x80391EC8: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
L_80391ECC:
    // 0x80391ECC: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80391ED0: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x80391ED4: sra         $t7, $t4, 16
    ctx->r15 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80391ED8: sll         $t4, $t7, 4
    ctx->r12 = S32(ctx->r15 << 4);
    // 0x80391EDC: addu        $t6, $t9, $t4
    ctx->r14 = ADD32(ctx->r25, ctx->r12);
    // 0x80391EE0: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80391EE4: sh          $t5, 0x1070($t7)
    MEM_H(0X1070, ctx->r15) = ctx->r13;
    // 0x80391EE8: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80391EEC: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x80391EF0: addu        $t9, $t8, $t4
    ctx->r25 = ADD32(ctx->r24, ctx->r12);
    // 0x80391EF4: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80391EF8: sh          $s4, 0x1072($t6)
    MEM_H(0X1072, ctx->r14) = ctx->r20;
    // 0x80391EFC: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80391F00: addu        $t8, $t7, $t4
    ctx->r24 = ADD32(ctx->r15, ctx->r12);
    // 0x80391F04: addu        $t9, $t8, $a3
    ctx->r25 = ADD32(ctx->r24, ctx->r7);
    // 0x80391F08: sh          $a2, 0x1074($t9)
    MEM_H(0X1074, ctx->r25) = ctx->r6;
    // 0x80391F0C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80391F10: addu        $t7, $t6, $t4
    ctx->r15 = ADD32(ctx->r14, ctx->r12);
    // 0x80391F14: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x80391F18: sb          $s5, 0x107C($t8)
    MEM_B(0X107C, ctx->r24) = ctx->r21;
    // 0x80391F1C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80391F20: addu        $t6, $t9, $t4
    ctx->r14 = ADD32(ctx->r25, ctx->r12);
    // 0x80391F24: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80391F28: sb          $s5, 0x107D($t7)
    MEM_B(0X107D, ctx->r15) = ctx->r21;
    // 0x80391F2C: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80391F30: addu        $t9, $t8, $t4
    ctx->r25 = ADD32(ctx->r24, ctx->r12);
    // 0x80391F34: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80391F38: sb          $s5, 0x107E($t6)
    MEM_B(0X107E, ctx->r14) = ctx->r21;
    // 0x80391F3C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80391F40: addu        $t8, $t7, $t4
    ctx->r24 = ADD32(ctx->r15, ctx->r12);
    // 0x80391F44: addu        $t9, $t8, $a3
    ctx->r25 = ADD32(ctx->r24, ctx->r7);
    // 0x80391F48: sb          $s5, 0x107F($t9)
    MEM_B(0X107F, ctx->r25) = ctx->r21;
    // 0x80391F4C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80391F50: addu        $t7, $t6, $t4
    ctx->r15 = ADD32(ctx->r14, ctx->r12);
    // 0x80391F54: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x80391F58: sh          $zero, 0x1078($t8)
    MEM_H(0X1078, ctx->r24) = 0;
    // 0x80391F5C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80391F60: addu        $t6, $t9, $t4
    ctx->r14 = ADD32(ctx->r25, ctx->r12);
    // 0x80391F64: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80391F68: sh          $t3, 0x107A($t7)
    MEM_H(0X107A, ctx->r15) = ctx->r11;
    // 0x80391F6C: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80391F70: addu        $t9, $t8, $t4
    ctx->r25 = ADD32(ctx->r24, ctx->r12);
    // 0x80391F74: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80391F78: sh          $s0, 0x1080($t6)
    MEM_H(0X1080, ctx->r14) = ctx->r16;
    // 0x80391F7C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80391F80: addu        $t8, $t7, $t4
    ctx->r24 = ADD32(ctx->r15, ctx->r12);
    // 0x80391F84: addu        $t9, $t8, $a3
    ctx->r25 = ADD32(ctx->r24, ctx->r7);
    // 0x80391F88: sh          $s4, 0x1082($t9)
    MEM_H(0X1082, ctx->r25) = ctx->r20;
    // 0x80391F8C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80391F90: addu        $t7, $t6, $t4
    ctx->r15 = ADD32(ctx->r14, ctx->r12);
    // 0x80391F94: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x80391F98: sh          $a2, 0x1084($t8)
    MEM_H(0X1084, ctx->r24) = ctx->r6;
    // 0x80391F9C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80391FA0: sll         $a2, $t0, 4
    ctx->r6 = S32(ctx->r8 << 4);
    // 0x80391FA4: addu        $t6, $t9, $t4
    ctx->r14 = ADD32(ctx->r25, ctx->r12);
    // 0x80391FA8: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80391FAC: sb          $s5, 0x108C($t7)
    MEM_B(0X108C, ctx->r15) = ctx->r21;
    // 0x80391FB0: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80391FB4: addu        $t9, $t8, $a2
    ctx->r25 = ADD32(ctx->r24, ctx->r6);
    // 0x80391FB8: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80391FBC: sb          $s5, 0x108D($t6)
    MEM_B(0X108D, ctx->r14) = ctx->r21;
    // 0x80391FC0: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80391FC4: addu        $t8, $t7, $a2
    ctx->r24 = ADD32(ctx->r15, ctx->r6);
    // 0x80391FC8: addu        $t9, $t8, $a3
    ctx->r25 = ADD32(ctx->r24, ctx->r7);
    // 0x80391FCC: sb          $s5, 0x108E($t9)
    MEM_B(0X108E, ctx->r25) = ctx->r21;
    // 0x80391FD0: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80391FD4: addu        $t7, $t6, $a2
    ctx->r15 = ADD32(ctx->r14, ctx->r6);
    // 0x80391FD8: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x80391FDC: sb          $s5, 0x108F($t8)
    MEM_B(0X108F, ctx->r24) = ctx->r21;
    // 0x80391FE0: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80391FE4: addu        $t6, $t9, $a2
    ctx->r14 = ADD32(ctx->r25, ctx->r6);
    // 0x80391FE8: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80391FEC: sh          $s6, 0x1088($t7)
    MEM_H(0X1088, ctx->r15) = ctx->r22;
    // 0x80391FF0: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80391FF4: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80391FF8: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80391FFC: addu        $t9, $t8, $a2
    ctx->r25 = ADD32(ctx->r24, ctx->r6);
    // 0x80392000: slti        $at, $a1, 0xC
    ctx->r1 = SIGNED(ctx->r5) < 0XC ? 1 : 0;
    // 0x80392004: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80392008: bne         $at, $zero, L_80391E4C
    if (ctx->r1 != 0) {
        // 0x8039200C: sh          $t3, 0x108A($t6)
        MEM_H(0X108A, ctx->r14) = ctx->r11;
            goto L_80391E4C;
    }
    // 0x8039200C: sh          $t3, 0x108A($t6)
    MEM_H(0X108A, ctx->r14) = ctx->r11;
    // 0x80392010: sh          $t2, 0xF6($sp)
    MEM_H(0XF6, ctx->r29) = ctx->r10;
    // 0x80392014: sw          $t5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r13;
    // 0x80392018: sw          $s0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r16;
    // 0x8039201C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392020: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80392024: ori         $t6, $t6, 0x7DEF
    ctx->r14 = ctx->r14 | 0X7DEF;
    // 0x80392028: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039202C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80392030: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80392034: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80392038: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039203C: ori         $at, $at, 0x1070
    ctx->r1 = ctx->r1 | 0X1070;
    // 0x80392040: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x80392044: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x80392048: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x8039204C: and         $t9, $t8, $at
    ctx->r25 = ctx->r24 & ctx->r1;
    // 0x80392050: lui         $s6, 0x800C
    ctx->r22 = S32(0X800C << 16);
    // 0x80392054: addiu       $s6, $s6, -0x58A0
    ctx->r22 = ADD32(ctx->r22, -0X58A0);
    // 0x80392058: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039205C: lui         $s5, 0xFD10
    ctx->r21 = S32(0XFD10 << 16);
    // 0x80392060: lui         $s2, 0xB214
    ctx->r18 = S32(0XB214 << 16);
    // 0x80392064: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
L_80392068:
    // 0x80392068: multu       $a1, $s7
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039206C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392070: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80392074: sll         $t1, $a1, 1
    ctx->r9 = S32(ctx->r5 << 1);
    // 0x80392078: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039207C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80392080: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392084: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x80392088: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039208C: addiu       $s1, $zero, 0x170
    ctx->r17 = ADD32(0, 0X170);
    // 0x80392090: mflo        $t8
    ctx->r24 = lo;
    // 0x80392094: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80392098: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039209C: addu        $t9, $s6, $t8
    ctx->r25 = ADD32(ctx->r22, ctx->r24);
    // 0x803920A0: addu        $t6, $t9, $fp
    ctx->r14 = ADD32(ctx->r25, ctx->r30);
    // 0x803920A4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803920A8: sw          $s5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r21;
    // 0x803920AC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803920B0: lui         $t8, 0x700
    ctx->r24 = S32(0X700 << 16);
    // 0x803920B4: lui         $t6, 0xE600
    ctx->r14 = S32(0XE600 << 16);
    // 0x803920B8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803920BC: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803920C0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803920C4: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x803920C8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803920CC: lui         $t8, 0xF300
    ctx->r24 = S32(0XF300 << 16);
    // 0x803920D0: addiu       $t3, $a1, 0x2
    ctx->r11 = ADD32(ctx->r5, 0X2);
    // 0x803920D4: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803920D8: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x803920DC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803920E0: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803920E4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803920E8: lui         $t9, 0x777
    ctx->r25 = S32(0X777 << 16);
    // 0x803920EC: ori         $t9, $t9, 0xF034
    ctx->r25 = ctx->r25 | 0XF034;
    // 0x803920F0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803920F4: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803920F8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x803920FC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80392100: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392104: lui         $t8, 0xF510
    ctx->r24 = S32(0XF510 << 16);
    // 0x80392108: ori         $t8, $t8, 0x5000
    ctx->r24 = ctx->r24 | 0X5000;
    // 0x8039210C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80392110: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80392114: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392118: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x8039211C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392120: lui         $t6, 0xF200
    ctx->r14 = S32(0XF200 << 16);
    // 0x80392124: andi        $t5, $t1, 0xFF
    ctx->r13 = ctx->r9 & 0XFF;
    // 0x80392128: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039212C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80392130: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392134: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80392138: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039213C: lui         $t7, 0x27
    ctx->r15 = S32(0X27 << 16);
    // 0x80392140: ori         $t7, $t7, 0xC02C
    ctx->r15 = ctx->r15 | 0XC02C;
    // 0x80392144: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80392148: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039214C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80392150: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80392154: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392158: lui         $t7, 0xB0
    ctx->r15 = S32(0XB0 << 16);
    // 0x8039215C: ori         $t7, $t7, 0x10
    ctx->r15 = ctx->r15 | 0X10;
    // 0x80392160: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80392164: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80392168: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039216C: bne         $a1, $at, L_80392178
    if (ctx->r5 != ctx->r1) {
        // 0x80392170: sw          $s3, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->r19;
            goto L_80392178;
    }
    // 0x80392170: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x80392174: addiu       $s1, $zero, 0x130
    ctx->r17 = ADD32(0, 0X130);
L_80392178:
    // 0x80392178: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039217C: sll         $t8, $a1, 1
    ctx->r24 = S32(ctx->r5 << 1);
    // 0x80392180: lui         $at, 0xB0
    ctx->r1 = S32(0XB0 << 16);
    // 0x80392184: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80392188: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039218C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392190: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x80392194: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392198: andi        $t9, $t8, 0xFFFF
    ctx->r25 = ctx->r24 & 0XFFFF;
    // 0x8039219C: addiu       $s0, $t1, 0x6
    ctx->r16 = ADD32(ctx->r9, 0X6);
    // 0x803921A0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803921A4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x803921A8: or          $t6, $t9, $s2
    ctx->r14 = ctx->r25 | ctx->r18;
    // 0x803921AC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803921B0: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x803921B4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803921B8: addiu       $t6, $a1, 0x1
    ctx->r14 = ADD32(ctx->r5, 0X1);
    // 0x803921BC: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x803921C0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803921C4: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x803921C8: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x803921CC: lui         $t6, 0x1170
    ctx->r14 = S32(0X1170 << 16);
    // 0x803921D0: ori         $t6, $t6, 0x10
    ctx->r14 = ctx->r14 | 0X10;
    // 0x803921D4: or          $t9, $t8, $s2
    ctx->r25 = ctx->r24 | ctx->r18;
    // 0x803921D8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803921DC: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803921E0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803921E4: sll         $t9, $t3, 1
    ctx->r25 = S32(ctx->r11 << 1);
    // 0x803921E8: andi        $t6, $t9, 0xFFFF
    ctx->r14 = ctx->r25 & 0XFFFF;
    // 0x803921EC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803921F0: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803921F4: or          $t7, $t6, $s2
    ctx->r15 = ctx->r14 | ctx->r18;
    // 0x803921F8: or          $t8, $s1, $at
    ctx->r24 = ctx->r17 | ctx->r1;
    // 0x803921FC: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80392200: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80392204: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392208: addiu       $t7, $a1, 0x3
    ctx->r15 = ADD32(ctx->r5, 0X3);
    // 0x8039220C: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80392210: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80392214: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80392218: andi        $t9, $t8, 0xFFFF
    ctx->r25 = ctx->r24 & 0XFFFF;
    // 0x8039221C: lui         $at, 0x1170
    ctx->r1 = S32(0X1170 << 16);
    // 0x80392220: or          $t7, $s1, $at
    ctx->r15 = ctx->r17 | ctx->r1;
    // 0x80392224: or          $t6, $t9, $s2
    ctx->r14 = ctx->r25 | ctx->r18;
    // 0x80392228: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039222C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80392230: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392234: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80392238: or          $t5, $t6, $zero
    ctx->r13 = ctx->r14 | 0;
    // 0x8039223C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80392240: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80392244: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392248: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x8039224C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392250: addiu       $t8, $t1, 0x4
    ctx->r24 = ADD32(ctx->r9, 0X4);
    // 0x80392254: andi        $t7, $s0, 0xFF
    ctx->r15 = ctx->r16 & 0XFF;
    // 0x80392258: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039225C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80392260: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x80392264: sll         $t6, $t9, 8
    ctx->r14 = S32(ctx->r25 << 8);
    // 0x80392268: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
    // 0x8039226C: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80392270: or          $t8, $t7, $s0
    ctx->r24 = ctx->r15 | ctx->r16;
    // 0x80392274: lui         $at, 0xB100
    ctx->r1 = S32(0XB100 << 16);
    // 0x80392278: or          $t9, $t8, $at
    ctx->r25 = ctx->r24 | ctx->r1;
    // 0x8039227C: addiu       $t8, $t1, 0x2
    ctx->r24 = ADD32(ctx->r9, 0X2);
    // 0x80392280: sll         $t6, $s0, 8
    ctx->r14 = S32(ctx->r16 << 8);
    // 0x80392284: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80392288: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8039228C: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80392290: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x80392294: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80392298: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039229C: sll         $a1, $t3, 16
    ctx->r5 = S32(ctx->r11 << 16);
    // 0x803922A0: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803922A4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803922A8: slti        $at, $t7, 0x16
    ctx->r1 = SIGNED(ctx->r15) < 0X16 ? 1 : 0;
    // 0x803922AC: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x803922B0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x803922B4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803922B8: bne         $at, $zero, L_80392068
    if (ctx->r1 != 0) {
        // 0x803922BC: sw          $s3, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->r19;
            goto L_80392068;
    }
    // 0x803922BC: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x803922C0: lwc1        $f8, 0x11C($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X11C);
    // 0x803922C4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803922C8: sub.s       $f6, $f2, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = ctx->f2.fl - ctx->f14.fl;
    // 0x803922CC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803922D0: lw          $t1, 0x4C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X4C);
    // 0x803922D4: add.s       $f10, $f8, $f22
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f22.fl;
    // 0x803922D8: lw          $s0, 0x44($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X44);
    // 0x803922DC: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x803922E0: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x803922E4: addiu       $t0, $zero, 0x25
    ctx->r8 = ADD32(0, 0X25);
    // 0x803922E8: trunc.w.s   $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x803922EC: mfc1        $a2, $f8
    ctx->r6 = (int32_t)ctx->f8.u32l;
    // 0x803922F0: sub.s       $f8, $f12, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = ctx->f12.fl - ctx->f14.fl;
    // 0x803922F4: mfc1        $v0, $f4
    ctx->r2 = (int32_t)ctx->f4.u32l;
    // 0x803922F8: addiu       $t2, $a2, 0x2
    ctx->r10 = ADD32(ctx->r6, 0X2);
    // 0x803922FC: addiu       $t5, $a2, -0x1
    ctx->r13 = ADD32(ctx->r6, -0X1);
    // 0x80392300: sh          $v0, 0x1250($at)
    MEM_H(0X1250, ctx->r1) = ctx->r2;
    // 0x80392304: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80392308: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039230C: sll         $a2, $t0, 4
    ctx->r6 = S32(ctx->r8 << 4);
    // 0x80392310: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80392314: sh          $s4, 0x1252($at)
    MEM_H(0X1252, ctx->r1) = ctx->r20;
    // 0x80392318: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x8039231C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392320: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80392324: sh          $t2, 0x1254($at)
    MEM_H(0X1254, ctx->r1) = ctx->r10;
    // 0x80392328: lwc1        $f10, 0x124($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X124);
    // 0x8039232C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80392330: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392334: sub.s       $f4, $f10, $f22
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f22.fl;
    // 0x80392338: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x8039233C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80392340: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80392344: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x80392348: mfc1        $t3, $f6
    ctx->r11 = (int32_t)ctx->f6.u32l;
    // 0x8039234C: addiu       $t4, $a1, -0x2
    ctx->r12 = ADD32(ctx->r5, -0X2);
    // 0x80392350: sh          $t3, 0x1260($at)
    MEM_H(0X1260, ctx->r1) = ctx->r11;
    // 0x80392354: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80392358: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039235C: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x80392360: sh          $s4, 0x1262($at)
    MEM_H(0X1262, ctx->r1) = ctx->r20;
    // 0x80392364: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80392368: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039236C: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80392370: sh          $t2, 0x1264($at)
    MEM_H(0X1264, ctx->r1) = ctx->r10;
    // 0x80392374: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80392378: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039237C: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80392380: sh          $t3, 0x1270($at)
    MEM_H(0X1270, ctx->r1) = ctx->r11;
    // 0x80392384: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80392388: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039238C: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80392390: sh          $s4, 0x1272($at)
    MEM_H(0X1272, ctx->r1) = ctx->r20;
    // 0x80392394: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80392398: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039239C: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x803923A0: sh          $t4, 0x1274($at)
    MEM_H(0X1274, ctx->r1) = ctx->r12;
    // 0x803923A4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803923A8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803923AC: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x803923B0: sh          $v0, 0x1280($at)
    MEM_H(0X1280, ctx->r1) = ctx->r2;
    // 0x803923B4: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803923B8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803923BC: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x803923C0: sh          $s4, 0x1282($at)
    MEM_H(0X1282, ctx->r1) = ctx->r20;
    // 0x803923C4: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x803923C8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803923CC: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x803923D0: sh          $t4, 0x1284($at)
    MEM_H(0X1284, ctx->r1) = ctx->r12;
    // 0x803923D4: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x803923D8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803923DC: addiu       $t4, $a1, 0x1
    ctx->r12 = ADD32(ctx->r5, 0X1);
    // 0x803923E0: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x803923E4: sh          $t1, 0x1290($at)
    MEM_H(0X1290, ctx->r1) = ctx->r9;
    // 0x803923E8: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803923EC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803923F0: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x803923F4: sh          $s4, 0x1292($at)
    MEM_H(0X1292, ctx->r1) = ctx->r20;
    // 0x803923F8: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803923FC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392400: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80392404: sh          $t5, 0x1294($at)
    MEM_H(0X1294, ctx->r1) = ctx->r13;
    // 0x80392408: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x8039240C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392410: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80392414: sh          $s0, 0x12A0($at)
    MEM_H(0X12A0, ctx->r1) = ctx->r16;
    // 0x80392418: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x8039241C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392420: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80392424: sh          $s4, 0x12A2($at)
    MEM_H(0X12A2, ctx->r1) = ctx->r20;
    // 0x80392428: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x8039242C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392430: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x80392434: sh          $t5, 0x12A4($at)
    MEM_H(0X12A4, ctx->r1) = ctx->r13;
    // 0x80392438: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x8039243C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392440: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80392444: sh          $s0, 0x12B0($at)
    MEM_H(0X12B0, ctx->r1) = ctx->r16;
    // 0x80392448: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x8039244C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392450: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80392454: sh          $s4, 0x12B2($at)
    MEM_H(0X12B2, ctx->r1) = ctx->r20;
    // 0x80392458: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x8039245C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80392460: ori         $at, $at, 0x1250
    ctx->r1 = ctx->r1 | 0X1250;
    // 0x80392464: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x80392468: sh          $t4, 0x12B4($t6)
    MEM_H(0X12B4, ctx->r14) = ctx->r12;
    // 0x8039246C: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80392470: addu        $t7, $t8, $a2
    ctx->r15 = ADD32(ctx->r24, ctx->r6);
    // 0x80392474: addu        $t9, $t7, $a3
    ctx->r25 = ADD32(ctx->r15, ctx->r7);
    // 0x80392478: sh          $t1, 0x1070($t9)
    MEM_H(0X1070, ctx->r25) = ctx->r9;
    // 0x8039247C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80392480: addu        $t8, $t6, $a2
    ctx->r24 = ADD32(ctx->r14, ctx->r6);
    // 0x80392484: addu        $t7, $t8, $a3
    ctx->r15 = ADD32(ctx->r24, ctx->r7);
    // 0x80392488: sh          $s4, 0x1072($t7)
    MEM_H(0X1072, ctx->r15) = ctx->r20;
    // 0x8039248C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80392490: addu        $t6, $t9, $a2
    ctx->r14 = ADD32(ctx->r25, ctx->r6);
    // 0x80392494: addu        $t8, $t6, $a3
    ctx->r24 = ADD32(ctx->r14, ctx->r7);
    // 0x80392498: sh          $t4, 0x1074($t8)
    MEM_H(0X1074, ctx->r24) = ctx->r12;
    // 0x8039249C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803924A0: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803924A4: ori         $t9, $t9, 0x207F
    ctx->r25 = ctx->r25 | 0X207F;
    // 0x803924A8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803924AC: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803924B0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803924B4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803924B8: addu        $t8, $t6, $at
    ctx->r24 = ADD32(ctx->r14, ctx->r1);
    // 0x803924BC: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x803924C0: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x803924C4: and         $t7, $t8, $at
    ctx->r15 = ctx->r24 & ctx->r1;
    // 0x803924C8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x803924CC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803924D0: lui         $t8, 0xFFFD
    ctx->r24 = S32(0XFFFD << 16);
    // 0x803924D4: lui         $t6, 0xFCFF
    ctx->r14 = S32(0XFCFF << 16);
    // 0x803924D8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803924DC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x803924E0: ori         $t6, $t6, 0xFFFF
    ctx->r14 = ctx->r14 | 0XFFFF;
    // 0x803924E4: ori         $t8, $t8, 0xF6FB
    ctx->r24 = ctx->r24 | 0XF6FB;
    // 0x803924E8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803924EC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803924F0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803924F4: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x803924F8: lui         $t8, 0xB100
    ctx->r24 = S32(0XB100 << 16);
    // 0x803924FC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80392500: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80392504: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80392508: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039250C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392510: lui         $t7, 0x2
    ctx->r15 = S32(0X2 << 16);
    // 0x80392514: ori         $t7, $t7, 0x80A
    ctx->r15 = ctx->r15 | 0X80A;
    // 0x80392518: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039251C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80392520: ori         $t8, $t8, 0x802
    ctx->r24 = ctx->r24 | 0X802;
    // 0x80392524: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80392528: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039252C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392530: lui         $t8, 0xE
    ctx->r24 = S32(0XE << 16);
    // 0x80392534: lui         $t6, 0xB100
    ctx->r14 = S32(0XB100 << 16);
    // 0x80392538: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039253C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80392540: ori         $t6, $t6, 0x60E
    ctx->r14 = ctx->r14 | 0X60E;
    // 0x80392544: ori         $t8, $t8, 0x800
    ctx->r24 = ctx->r24 | 0X800;
    // 0x80392548: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039254C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80392550: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392554: lui         $t6, 0xA
    ctx->r14 = S32(0XA << 16);
    // 0x80392558: lui         $t9, 0xB102
    ctx->r25 = S32(0XB102 << 16);
    // 0x8039255C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80392560: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80392564: ori         $t9, $t9, 0xA04
    ctx->r25 = ctx->r25 | 0XA04;
    // 0x80392568: ori         $t6, $t6, 0xC04
    ctx->r14 = ctx->r14 | 0XC04;
    // 0x8039256C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80392570: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80392574: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80392578: lui         $t9, 0x4
    ctx->r25 = S32(0X4 << 16);
    // 0x8039257C: lui         $t7, 0xB10E
    ctx->r15 = S32(0XB10E << 16);
    // 0x80392580: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80392584: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80392588: ori         $t7, $t7, 0x604
    ctx->r15 = ctx->r15 | 0X604;
    // 0x8039258C: ori         $t9, $t9, 0xC0E
    ctx->r25 = ctx->r25 | 0XC0E;
    // 0x80392590: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80392594: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80392598: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8039259C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x803925A0: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x803925A4: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x803925A8: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x803925AC: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x803925B0: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x803925B4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x803925B8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x803925BC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803925C0: ldc1        $f22, 0x10($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X10);
    // 0x803925C4: ldc1        $f20, 0x8($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X8);
    // 0x803925C8: jr          $ra
    // 0x803925CC: addiu       $sp, $sp, 0x118
    ctx->r29 = ADD32(ctx->r29, 0X118);
    return;
    // 0x803925CC: addiu       $sp, $sp, 0x118
    ctx->r29 = ADD32(ctx->r29, 0X118);
;}
RECOMP_FUNC void func_803925D0_7A3C80(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803925D0: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x803925D4: addiu       $t2, $t2, 0x53E0
    ctx->r10 = ADD32(ctx->r10, 0X53E0);
    // 0x803925D8: lh          $a3, 0xA($t2)
    ctx->r7 = MEM_H(ctx->r10, 0XA);
    // 0x803925DC: addiu       $t6, $zero, 0x140
    ctx->r14 = ADD32(0, 0X140);
    // 0x803925E0: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x803925E4: subu        $a2, $t6, $a3
    ctx->r6 = SUB32(ctx->r14, ctx->r7);
    // 0x803925E8: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x803925EC: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803925F0: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x803925F4: sll         $t1, $t8, 1
    ctx->r9 = S32(ctx->r24 << 1);
    // 0x803925F8: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_803925FC:
    // 0x803925FC: blez        $a3, L_8039262C
    if (SIGNED(ctx->r7) <= 0) {
        // 0x80392600: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_8039262C;
    }
    // 0x80392600: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80392604:
    // 0x80392604: lhu         $a1, 0x0($v0)
    ctx->r5 = MEM_HU(ctx->r2, 0X0);
    // 0x80392608: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x8039260C: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80392610: sh          $a1, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r5;
    // 0x80392614: lh          $a3, 0xA($t2)
    ctx->r7 = MEM_H(ctx->r10, 0XA);
    // 0x80392618: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039261C: addiu       $v1, $v1, 0x2
    ctx->r3 = ADD32(ctx->r3, 0X2);
    // 0x80392620: slt         $at, $a0, $a3
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x80392624: bne         $at, $zero, L_80392604
    if (ctx->r1 != 0) {
        // 0x80392628: addiu       $v0, $v0, 0x4
        ctx->r2 = ADD32(ctx->r2, 0X4);
            goto L_80392604;
    }
    // 0x80392628: addiu       $v0, $v0, 0x4
    ctx->r2 = ADD32(ctx->r2, 0X4);
L_8039262C:
    // 0x8039262C: addiu       $t0, $t0, 0x1
    ctx->r8 = ADD32(ctx->r8, 0X1);
    // 0x80392630: sll         $t4, $t0, 16
    ctx->r12 = S32(ctx->r8 << 16);
    // 0x80392634: sra         $t0, $t4, 16
    ctx->r8 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80392638: slti        $at, $t0, 0xF0
    ctx->r1 = SIGNED(ctx->r8) < 0XF0 ? 1 : 0;
    // 0x8039263C: bne         $at, $zero, L_803925FC
    if (ctx->r1 != 0) {
        // 0x80392640: addu        $v0, $v0, $t1
        ctx->r2 = ADD32(ctx->r2, ctx->r9);
            goto L_803925FC;
    }
    // 0x80392640: addu        $v0, $v0, $t1
    ctx->r2 = ADD32(ctx->r2, ctx->r9);
    // 0x80392644: jr          $ra
    // 0x80392648: nop

    return;
    // 0x80392648: nop

;}
RECOMP_FUNC void func_8039264C_7A3CFC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039264C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80392650: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80392654: addiu       $v0, $v0, 0x66B8
    ctx->r2 = ADD32(ctx->r2, 0X66B8);
    // 0x80392658: sh          $zero, 0x40($v0)
    MEM_H(0X40, ctx->r2) = 0;
    // 0x8039265C: sh          $zero, 0x42($v0)
    MEM_H(0X42, ctx->r2) = 0;
    // 0x80392660: jr          $ra
    // 0x80392664: swc1        $f4, 0x48($v0)
    MEM_W(0X48, ctx->r2) = ctx->f4.u32l;
    return;
    // 0x80392664: swc1        $f4, 0x48($v0)
    MEM_W(0X48, ctx->r2) = ctx->f4.u32l;
;}
RECOMP_FUNC void func_80392668_7A3D18(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80392668: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8039266C: addiu       $a2, $a2, 0x66B8
    ctx->r6 = ADD32(ctx->r6, 0X66B8);
    // 0x80392670: lh          $v0, 0x42($a2)
    ctx->r2 = MEM_H(ctx->r6, 0X42);
    // 0x80392674: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80392678: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8039267C: bne         $v0, $zero, L_80392690
    if (ctx->r2 != 0) {
        // 0x80392680: addiu       $a3, $a3, 0x6680
        ctx->r7 = ADD32(ctx->r7, 0X6680);
            goto L_80392690;
    }
    // 0x80392680: addiu       $a3, $a3, 0x6680
    ctx->r7 = ADD32(ctx->r7, 0X6680);
    // 0x80392684: lh          $v1, 0x40($a2)
    ctx->r3 = MEM_H(ctx->r6, 0X40);
    // 0x80392688: beq         $v1, $zero, L_803926B8
    if (ctx->r3 == 0) {
        // 0x8039268C: nop
    
            goto L_803926B8;
    }
    // 0x8039268C: nop

L_80392690:
    // 0x80392690: lbu         $t6, 0x2B($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X2B);
    // 0x80392694: lh          $v1, 0x40($a2)
    ctx->r3 = MEM_H(ctx->r6, 0X40);
    // 0x80392698: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x8039269C: bne         $t6, $zero, L_803926B4
    if (ctx->r14 != 0) {
        // 0x803926A0: lui         $at, 0x8020
        ctx->r1 = S32(0X8020 << 16);
            goto L_803926B4;
    }
    // 0x803926A0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803926A4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x803926A8: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x803926AC: b           L_803926B8
    // 0x803926B0: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
        goto L_803926B8;
    // 0x803926B0: sh          $t7, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r15;
L_803926B4:
    // 0x803926B4: sh          $t8, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r24;
L_803926B8:
    // 0x803926B8: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x803926BC: beq         $v1, $zero, L_80392888
    if (ctx->r3 == 0) {
        // 0x803926C0: addiu       $a3, $a3, 0x6680
        ctx->r7 = ADD32(ctx->r7, 0X6680);
            goto L_80392888;
    }
    // 0x803926C0: addiu       $a3, $a3, 0x6680
    ctx->r7 = ADD32(ctx->r7, 0X6680);
    // 0x803926C4: lw          $v1, 0x30($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X30);
    // 0x803926C8: addiu       $a1, $zero, -0x8000
    ctx->r5 = ADD32(0, -0X8000);
    // 0x803926CC: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x803926D0: slti        $at, $v1, 0x100
    ctx->r1 = SIGNED(ctx->r3) < 0X100 ? 1 : 0;
    // 0x803926D4: bnel        $at, $zero, L_803926EC
    if (ctx->r1 != 0) {
        // 0x803926D8: lw          $t9, 0x38($a2)
        ctx->r25 = MEM_W(ctx->r6, 0X38);
            goto L_803926EC;
    }
    goto skip_0;
    // 0x803926D8: lw          $t9, 0x38($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X38);
    skip_0:
    // 0x803926DC: sh          $zero, 0x40($a2)
    MEM_H(0X40, ctx->r6) = 0;
    // 0x803926E0: b           L_803926F8
    // 0x803926E4: sh          $zero, 0xC($a3)
    MEM_H(0XC, ctx->r7) = 0;
        goto L_803926F8;
    // 0x803926E4: sh          $zero, 0xC($a3)
    MEM_H(0XC, ctx->r7) = 0;
    // 0x803926E8: lw          $t9, 0x38($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X38);
L_803926EC:
    // 0x803926EC: addu        $t1, $v1, $t9
    ctx->r9 = ADD32(ctx->r3, ctx->r25);
    // 0x803926F0: sw          $t1, 0x30($a2)
    MEM_W(0X30, ctx->r6) = ctx->r9;
    // 0x803926F4: or          $v1, $t1, $zero
    ctx->r3 = ctx->r9 | 0;
L_803926F8:
    // 0x803926F8: lwc1        $f16, 0x0($a2)
    ctx->f16.u32l = MEM_W(ctx->r6, 0X0);
    // 0x803926FC: lwc1        $f4, 0x18($a2)
    ctx->f4.u32l = MEM_W(ctx->r6, 0X18);
    // 0x80392700: lwc1        $f18, 0x4($a2)
    ctx->f18.u32l = MEM_W(ctx->r6, 0X4);
    // 0x80392704: lwc1        $f8, 0x1C($a2)
    ctx->f8.u32l = MEM_W(ctx->r6, 0X1C);
    // 0x80392708: sub.s       $f6, $f4, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f16.fl;
    // 0x8039270C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80392710: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80392714: lwc1        $f4, 0x8($a2)
    ctx->f4.u32l = MEM_W(ctx->r6, 0X8);
    // 0x80392718: sub.s       $f10, $f8, $f18
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f18.fl;
    // 0x8039271C: lw          $a0, 0x34($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X34);
    // 0x80392720: swc1        $f4, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f4.u32l;
    // 0x80392724: div.s       $f2, $f6, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80392728: lwc1        $f6, 0x20($a2)
    ctx->f6.u32l = MEM_W(ctx->r6, 0X20);
    // 0x8039272C: lwc1        $f8, 0x4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4);
    // 0x80392730: sra         $t1, $v1, 1
    ctx->r9 = S32(SIGNED(ctx->r3) >> 1);
    // 0x80392734: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x80392738: slti        $at, $a0, 0x100
    ctx->r1 = SIGNED(ctx->r4) < 0X100 ? 1 : 0;
    // 0x8039273C: andi        $t9, $v1, 0x1
    ctx->r25 = ctx->r3 & 0X1;
    // 0x80392740: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80392744: div.s       $f12, $f10, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
    // 0x80392748: sub.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8039274C: bne         $at, $zero, L_8039275C
    if (ctx->r1 != 0) {
        // 0x80392750: div.s       $f14, $f10, $f0
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
            goto L_8039275C;
    }
    // 0x80392750: div.s       $f14, $f10, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
    // 0x80392754: b           L_80392790
    // 0x80392758: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
        goto L_80392790;
    // 0x80392758: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
L_8039275C:
    // 0x8039275C: bne         $a0, $zero, L_80392774
    if (ctx->r4 != 0) {
        // 0x80392760: lui         $t0, 0x8015
        ctx->r8 = S32(0X8015 << 16);
            goto L_80392774;
    }
    // 0x80392760: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80392764: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80392768: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x8039276C: b           L_80392790
    // 0x80392770: ori         $a1, $zero, 0x8000
    ctx->r5 = 0 | 0X8000;
        goto L_80392790;
    // 0x80392770: ori         $a1, $zero, 0x8000
    ctx->r5 = 0 | 0X8000;
L_80392774:
    // 0x80392774: sra         $t4, $a0, 1
    ctx->r12 = S32(SIGNED(ctx->r4) >> 1);
    // 0x80392778: addiu       $t5, $t4, 0x40
    ctx->r13 = ADD32(ctx->r12, 0X40);
    // 0x8039277C: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x80392780: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x80392784: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80392788: addu        $t8, $t0, $t7
    ctx->r24 = ADD32(ctx->r8, ctx->r15);
    // 0x8039278C: lh          $a1, 0x0($t8)
    ctx->r5 = MEM_H(ctx->r24, 0X0);
L_80392790:
    // 0x80392790: beq         $t9, $zero, L_803927C4
    if (ctx->r25 == 0) {
        // 0x80392794: sra         $t4, $t3, 16
        ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
            goto L_803927C4;
    }
    // 0x80392794: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80392798: addiu       $t5, $t4, 0x40
    ctx->r13 = ADD32(ctx->r12, 0X40);
    // 0x8039279C: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x803927A0: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x803927A4: addu        $t8, $t0, $t7
    ctx->r24 = ADD32(ctx->r8, ctx->r15);
    // 0x803927A8: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x803927AC: addu        $a1, $t9, $a1
    ctx->r5 = ADD32(ctx->r25, ctx->r5);
    // 0x803927B0: bgez        $a1, L_803927C0
    if (SIGNED(ctx->r5) >= 0) {
        // 0x803927B4: sra         $t1, $a1, 1
        ctx->r9 = S32(SIGNED(ctx->r5) >> 1);
            goto L_803927C0;
    }
    // 0x803927B4: sra         $t1, $a1, 1
    ctx->r9 = S32(SIGNED(ctx->r5) >> 1);
    // 0x803927B8: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x803927BC: sra         $t1, $at, 1
    ctx->r9 = S32(SIGNED(ctx->r1) >> 1);
L_803927C0:
    // 0x803927C0: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
L_803927C4:
    // 0x803927C4: lh          $t2, 0x44($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X44);
    // 0x803927C8: sra         $t3, $a0, 1
    ctx->r11 = S32(SIGNED(ctx->r4) >> 1);
    // 0x803927CC: mtc1        $a1, $f10
    ctx->f10.u32l = ctx->r5;
    // 0x803927D0: beq         $t2, $zero, L_80392804
    if (ctx->r10 == 0) {
        // 0x803927D4: sll         $t4, $t3, 1
        ctx->r12 = S32(ctx->r11 << 1);
            goto L_80392804;
    }
    // 0x803927D4: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x803927D8: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x803927DC: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x803927E0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803927E4: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x803927E8: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x803927EC: mflo        $t8
    ctx->r24 = lo;
    // 0x803927F0: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x803927F4: nop

    // 0x803927F8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x803927FC: b           L_80392810
    // 0x80392800: swc1        $f6, 0x48($a2)
    MEM_W(0X48, ctx->r6) = ctx->f6.u32l;
        goto L_80392810;
    // 0x80392800: swc1        $f6, 0x48($a2)
    MEM_W(0X48, ctx->r6) = ctx->f6.u32l;
L_80392804:
    // 0x80392804: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80392808: nop

    // 0x8039280C: swc1        $f8, 0x48($a2)
    MEM_W(0X48, ctx->r6) = ctx->f8.u32l;
L_80392810:
    // 0x80392810: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80392814: mul.s       $f6, $f2, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f2.fl, ctx->f0.fl);
    // 0x80392818: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x8039281C: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x80392820: addiu       $v1, $v1, 0x683C
    ctx->r3 = ADD32(ctx->r3, 0X683C);
    // 0x80392824: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x80392828: lwc1        $f8, 0x10($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X10);
    // 0x8039282C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80392830: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80392834: add.s       $f8, $f16, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = ctx->f16.fl + ctx->f2.fl;
    // 0x80392838: div.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f10.fl, ctx->f4.fl);
    // 0x8039283C: mul.s       $f4, $f12, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f12.fl, ctx->f0.fl);
    // 0x80392840: sub.s       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f6.fl;
    // 0x80392844: lwc1        $f8, 0x10($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X10);
    // 0x80392848: mul.s       $f6, $f4, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f8.fl);
    // 0x8039284C: swc1        $f10, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->f10.u32l;
    // 0x80392850: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80392854: add.s       $f8, $f18, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = ctx->f18.fl + ctx->f12.fl;
    // 0x80392858: div.s       $f4, $f6, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = DIV_S(ctx->f6.fl, ctx->f10.fl);
    // 0x8039285C: mul.s       $f10, $f14, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f14.fl, ctx->f0.fl);
    // 0x80392860: sub.s       $f6, $f8, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f8.fl - ctx->f4.fl;
    // 0x80392864: lwc1        $f8, 0x10($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X10);
    // 0x80392868: mul.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f8.fl);
    // 0x8039286C: swc1        $f6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->f6.u32l;
    // 0x80392870: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80392874: lwc1        $f8, 0x4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4);
    // 0x80392878: div.s       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = DIV_S(ctx->f4.fl, ctx->f6.fl);
    // 0x8039287C: add.s       $f4, $f8, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = ctx->f8.fl + ctx->f14.fl;
    // 0x80392880: sub.s       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f10.fl;
    // 0x80392884: swc1        $f6, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->f6.u32l;
L_80392888:
    // 0x80392888: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x8039288C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80392890: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x80392894: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80392898: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x8039289C: beq         $v0, $zero, L_803929F4
    if (ctx->r2 == 0) {
        // 0x803928A0: addiu       $v1, $v1, 0x683C
        ctx->r3 = ADD32(ctx->r3, 0X683C);
            goto L_803929F4;
    }
    // 0x803928A0: addiu       $v1, $v1, 0x683C
    ctx->r3 = ADD32(ctx->r3, 0X683C);
    // 0x803928A4: lw          $a0, 0x34($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X34);
    // 0x803928A8: slti        $at, $a0, 0x100
    ctx->r1 = SIGNED(ctx->r4) < 0X100 ? 1 : 0;
    // 0x803928AC: bnel        $at, $zero, L_803928C4
    if (ctx->r1 != 0) {
        // 0x803928B0: lw          $t9, 0x3C($a2)
        ctx->r25 = MEM_W(ctx->r6, 0X3C);
            goto L_803928C4;
    }
    goto skip_1;
    // 0x803928B0: lw          $t9, 0x3C($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X3C);
    skip_1:
    // 0x803928B4: sh          $zero, 0x42($a2)
    MEM_H(0X42, ctx->r6) = 0;
    // 0x803928B8: b           L_803928D0
    // 0x803928BC: sh          $zero, 0xC($a3)
    MEM_H(0XC, ctx->r7) = 0;
        goto L_803928D0;
    // 0x803928BC: sh          $zero, 0xC($a3)
    MEM_H(0XC, ctx->r7) = 0;
    // 0x803928C0: lw          $t9, 0x3C($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X3C);
L_803928C4:
    // 0x803928C4: addu        $t1, $a0, $t9
    ctx->r9 = ADD32(ctx->r4, ctx->r25);
    // 0x803928C8: sw          $t1, 0x34($a2)
    MEM_W(0X34, ctx->r6) = ctx->r9;
    // 0x803928CC: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
L_803928D0:
    // 0x803928D0: lwc1        $f16, 0xC($a2)
    ctx->f16.u32l = MEM_W(ctx->r6, 0XC);
    // 0x803928D4: lwc1        $f8, 0x24($a2)
    ctx->f8.u32l = MEM_W(ctx->r6, 0X24);
    // 0x803928D8: lwc1        $f18, 0x10($a2)
    ctx->f18.u32l = MEM_W(ctx->r6, 0X10);
    // 0x803928DC: lwc1        $f10, 0x28($a2)
    ctx->f10.u32l = MEM_W(ctx->r6, 0X28);
    // 0x803928E0: sub.s       $f4, $f8, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f16.fl;
    // 0x803928E4: lwc1        $f8, 0x14($a2)
    ctx->f8.u32l = MEM_W(ctx->r6, 0X14);
    // 0x803928E8: sra         $t1, $a0, 1
    ctx->r9 = S32(SIGNED(ctx->r4) >> 1);
    // 0x803928EC: sub.s       $f6, $f10, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = ctx->f10.fl - ctx->f18.fl;
    // 0x803928F0: swc1        $f8, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->f8.u32l;
    // 0x803928F4: lwc1        $f10, 0xC($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XC);
    // 0x803928F8: div.s       $f2, $f4, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f4.fl, ctx->f0.fl);
    // 0x803928FC: lwc1        $f4, 0x2C($a2)
    ctx->f4.u32l = MEM_W(ctx->r6, 0X2C);
    // 0x80392900: slti        $at, $a0, 0x100
    ctx->r1 = SIGNED(ctx->r4) < 0X100 ? 1 : 0;
    // 0x80392904: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x80392908: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x8039290C: andi        $t9, $a0, 0x1
    ctx->r25 = ctx->r4 & 0X1;
    // 0x80392910: div.s       $f12, $f6, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80392914: sub.s       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f10.fl;
    // 0x80392918: mul.s       $f10, $f2, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f0.fl);
    // 0x8039291C: bne         $at, $zero, L_8039292C
    if (ctx->r1 != 0) {
        // 0x80392920: div.s       $f14, $f6, $f0
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
            goto L_8039292C;
    }
    // 0x80392920: div.s       $f14, $f6, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80392924: b           L_80392950
    // 0x80392928: addiu       $a1, $zero, -0x8000
    ctx->r5 = ADD32(0, -0X8000);
        goto L_80392950;
    // 0x80392928: addiu       $a1, $zero, -0x8000
    ctx->r5 = ADD32(0, -0X8000);
L_8039292C:
    // 0x8039292C: bne         $a0, $zero, L_8039293C
    if (ctx->r4 != 0) {
        // 0x80392930: sra         $t4, $a0, 1
        ctx->r12 = S32(SIGNED(ctx->r4) >> 1);
            goto L_8039293C;
    }
    // 0x80392930: sra         $t4, $a0, 1
    ctx->r12 = S32(SIGNED(ctx->r4) >> 1);
    // 0x80392934: b           L_80392950
    // 0x80392938: ori         $a1, $zero, 0x8000
    ctx->r5 = 0 | 0X8000;
        goto L_80392950;
    // 0x80392938: ori         $a1, $zero, 0x8000
    ctx->r5 = 0 | 0X8000;
L_8039293C:
    // 0x8039293C: addiu       $t5, $t4, 0x40
    ctx->r13 = ADD32(ctx->r12, 0X40);
    // 0x80392940: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x80392944: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80392948: addu        $t8, $t0, $t7
    ctx->r24 = ADD32(ctx->r8, ctx->r15);
    // 0x8039294C: lh          $a1, 0x0($t8)
    ctx->r5 = MEM_H(ctx->r24, 0X0);
L_80392950:
    // 0x80392950: beq         $t9, $zero, L_80392984
    if (ctx->r25 == 0) {
        // 0x80392954: sra         $t4, $t3, 16
        ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
            goto L_80392984;
    }
    // 0x80392954: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80392958: addiu       $t5, $t4, 0x40
    ctx->r13 = ADD32(ctx->r12, 0X40);
    // 0x8039295C: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x80392960: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80392964: addu        $t8, $t0, $t7
    ctx->r24 = ADD32(ctx->r8, ctx->r15);
    // 0x80392968: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x8039296C: addu        $a1, $t9, $a1
    ctx->r5 = ADD32(ctx->r25, ctx->r5);
    // 0x80392970: bgez        $a1, L_80392980
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80392974: sra         $t1, $a1, 1
        ctx->r9 = S32(SIGNED(ctx->r5) >> 1);
            goto L_80392980;
    }
    // 0x80392974: sra         $t1, $a1, 1
    ctx->r9 = S32(SIGNED(ctx->r5) >> 1);
    // 0x80392978: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x8039297C: sra         $t1, $at, 1
    ctx->r9 = S32(SIGNED(ctx->r1) >> 1);
L_80392980:
    // 0x80392980: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
L_80392984:
    // 0x80392984: mtc1        $a1, $f8
    ctx->f8.u32l = ctx->r5;
    // 0x80392988: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x8039298C: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80392990: swc1        $f4, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->f4.u32l;
    // 0x80392994: lwc1        $f6, 0x8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X8);
    // 0x80392998: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039299C: mul.s       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f6.fl);
    // 0x803929A0: add.s       $f6, $f16, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = ctx->f16.fl + ctx->f2.fl;
    // 0x803929A4: div.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
    // 0x803929A8: mul.s       $f4, $f12, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f12.fl, ctx->f0.fl);
    // 0x803929AC: sub.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x803929B0: lwc1        $f6, 0x8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X8);
    // 0x803929B4: mul.s       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x803929B8: swc1        $f8, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->f8.u32l;
    // 0x803929BC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x803929C0: add.s       $f6, $f18, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f12.fl;
    // 0x803929C4: div.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = DIV_S(ctx->f10.fl, ctx->f8.fl);
    // 0x803929C8: mul.s       $f8, $f14, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f14.fl, ctx->f0.fl);
    // 0x803929CC: sub.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f4.fl;
    // 0x803929D0: lwc1        $f6, 0x8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X8);
    // 0x803929D4: mul.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x803929D8: swc1        $f10, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->f10.u32l;
    // 0x803929DC: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x803929E0: lwc1        $f6, 0xC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XC);
    // 0x803929E4: div.s       $f8, $f4, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = DIV_S(ctx->f4.fl, ctx->f10.fl);
    // 0x803929E8: add.s       $f4, $f6, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = ctx->f6.fl + ctx->f14.fl;
    // 0x803929EC: sub.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x803929F0: swc1        $f10, 0x14($v1)
    MEM_W(0X14, ctx->r3) = ctx->f10.u32l;
L_803929F4:
    // 0x803929F4: jr          $ra
    // 0x803929F8: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x803929F8: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void load_mission_brief_screen(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803929FC: addiu       $sp, $sp, -0xB0
    ctx->r29 = ADD32(ctx->r29, -0XB0);
    // 0x80392A00: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x80392A04: sll         $s0, $a0, 16
    ctx->r16 = S32(ctx->r4 << 16);
    // 0x80392A08: sw          $a0, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r4;
    // 0x80392A0C: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x80392A10: sw          $ra, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r31;
    // 0x80392A14: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80392A18: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x80392A1C: sw          $fp, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r30;
    // 0x80392A20: sw          $s7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r23;
    // 0x80392A24: sw          $s6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r22;
    // 0x80392A28: sw          $s5, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r21;
    // 0x80392A2C: sw          $s4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r20;
    // 0x80392A30: sw          $s3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r19;
    // 0x80392A34: sw          $s2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r18;
    // 0x80392A38: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x80392A3C: jal         0x8039CE38
    // 0x80392A40: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    func_8039CE38_7AE4E8(rdram, ctx);
        goto after_0;
    // 0x80392A40: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_0:
    sssv_file_select_layout_hook(rdram, ctx, 0);
    // 0x80392A44: jal         0x8039CAB8
    // 0x80392A48: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_8039CAB8_7AE168(rdram, ctx);
        goto after_1;
    // 0x80392A48: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    // 0x80392A4C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    sssv_file_select_layout_hook(rdram, ctx, 1);
    // 0x80392A50: jal         0x8039D30C
    // 0x80392A54: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    render_stars(rdram, ctx);
        goto after_2;
    // 0x80392A54: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_2:
    sssv_file_select_layout_hook(rdram, ctx, 2);
    // 0x80392A58: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80392A5C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x80392A60: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80392A64: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x80392A68: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80392A6C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80392A70: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80392A74: jal         0x8012C1F0
    // 0x80392A78: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    load_default_display_list(rdram, ctx);
        goto after_3;
    // 0x80392A78: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    after_3:
    // 0x80392A7C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80392A80: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80392A84: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392A88: jal         0x8012C248
    // 0x80392A8C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_4;
    // 0x80392A8C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_4:
    // 0x80392A90: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80392A94: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80392A98: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392A9C: jal         0x8012C214
    // 0x80392AA0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_5;
    // 0x80392AA0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_5:
    // 0x80392AA4: jal         0x80130A90
    // 0x80392AA8: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    get_message_address_by_id(rdram, ctx);
        goto after_6;
    // 0x80392AA8: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    after_6:
    // 0x80392AAC: lui         $at, 0x41C0
    ctx->r1 = S32(0X41C0 << 16);
    // 0x80392AB0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80392AB4: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80392AB8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80392ABC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80392AC0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x80392AC4: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80392AC8: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x80392ACC: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80392AD0: addiu       $a2, $zero, 0x18
    ctx->r6 = ADD32(0, 0X18);
    // 0x80392AD4: addiu       $a3, $zero, 0x1E
    ctx->r7 = ADD32(0, 0X1E);
    // 0x80392AD8: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x80392ADC: jal         0x8012D374
    // 0x80392AE0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_7;
    // 0x80392AE0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_7:
    // 0x80392AE4: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x80392AE8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80392AEC: lui         $at, 0x4150
    ctx->r1 = S32(0X4150 << 16);
    // 0x80392AF0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80392AF4: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x80392AF8: lui         $s5, 0x803B
    ctx->r21 = S32(0X803B << 16);
    // 0x80392AFC: addiu       $s5, $s5, 0x686C
    ctx->r21 = ADD32(ctx->r21, 0X686C);
    // 0x80392B00: addiu       $v0, $v0, 0x6868
    ctx->r2 = ADD32(ctx->r2, 0X6868);
    // 0x80392B04: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x80392B08: swc1        $f8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f8.u32l;
    // 0x80392B0C: swc1        $f10, 0x0($s5)
    MEM_W(0X0, ctx->r21) = ctx->f10.u32l;
    // 0x80392B10: lb          $t2, -0xD52($t2)
    ctx->r10 = MEM_B(ctx->r10, -0XD52);
    // 0x80392B14: addiu       $s1, $s0, 0x34
    ctx->r17 = ADD32(ctx->r16, 0X34);
    // 0x80392B18: sll         $t0, $s1, 16
    ctx->r8 = S32(ctx->r17 << 16);
    // 0x80392B1C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80392B20: sra         $s1, $t0, 16
    ctx->r17 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80392B24: bne         $t2, $at, L_80392B44
    if (ctx->r10 != ctx->r1) {
        // 0x80392B28: addiu       $fp, $zero, 0x17
        ctx->r30 = ADD32(0, 0X17);
            goto L_80392B44;
    }
    // 0x80392B28: addiu       $fp, $zero, 0x17
    ctx->r30 = ADD32(0, 0X17);
    // 0x80392B2C: lui         $at, 0x4160
    ctx->r1 = S32(0X4160 << 16);
    // 0x80392B30: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80392B34: lui         $at, 0x4170
    ctx->r1 = S32(0X4170 << 16);
    // 0x80392B38: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80392B3C: swc1        $f16, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f16.u32l;
    // 0x80392B40: swc1        $f18, 0x0($s5)
    MEM_W(0X0, ctx->r21) = ctx->f18.u32l;
L_80392B44:
    // 0x80392B44: or          $s7, $zero, $zero
    ctx->r23 = 0 | 0;
    // 0x80392B48: sh          $zero, 0xA2($sp)
    MEM_H(0XA2, ctx->r29) = 0;
    // 0x80392B4C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80392B50: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80392B54: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392B58: jal         0x8012C248
    // 0x80392B5C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_8;
    // 0x80392B5C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_8:
    // 0x80392B60: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80392B64: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80392B68: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80392B6C: jal         0x8012C214
    // 0x80392B70: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_9;
    // 0x80392B70: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_9:
    // 0x80392B74: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80392B78: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80392B7C: lui         $s6, 0x801E
    ctx->r22 = S32(0X801E << 16);
    // 0x80392B80: addiu       $s6, $s6, -0x6168
    ctx->r22 = ADD32(ctx->r22, -0X6168);
    // 0x80392B84: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80392B88: addiu       $t3, $zero, 0x128
    ctx->r11 = ADD32(0, 0X128);
    // 0x80392B8C: addiu       $t4, $zero, 0xE
    ctx->r12 = ADD32(0, 0XE);
    // 0x80392B90: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80392B94: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x80392B98: addiu       $a1, $a1, 0x2E34
    ctx->r5 = ADD32(ctx->r5, 0X2E34);
    // 0x80392B9C: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x80392BA0: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x80392BA4: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x80392BA8: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80392BAC: jal         0x8012FBEC
    // 0x80392BB0: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text_wrapped(rdram, ctx);
        goto after_10;
    // 0x80392BB0: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_10:
    // 0x80392BB4: addiu       $s1, $v0, 0x18
    ctx->r17 = ADD32(ctx->r2, 0X18);
    // 0x80392BB8: sll         $t5, $s1, 16
    ctx->r13 = S32(ctx->r17 << 16);
    // 0x80392BBC: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80392BC0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80392BC4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80392BC8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392BCC: jal         0x8012C248
    // 0x80392BD0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_11;
    // 0x80392BD0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_11:
    // 0x80392BD4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80392BD8: lh          $v1, 0x63C0($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X63C0);
    // 0x80392BDC: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x80392BE0: addiu       $s4, $sp, 0x64
    ctx->r20 = ADD32(ctx->r29, 0X64);
    // 0x80392BE4: blez        $v1, L_80392F98
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80392BE8: addiu       $s3, $sp, 0x8C
        ctx->r19 = ADD32(ctx->r29, 0X8C);
            goto L_80392F98;
    }
    // 0x80392BE8: addiu       $s3, $sp, 0x8C
    ctx->r19 = ADD32(ctx->r29, 0X8C);
    // 0x80392BEC: sll         $t7, $s2, 1
    ctx->r15 = S32(ctx->r18 << 1);
L_80392BF0:
    // 0x80392BF0: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80392BF4: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x80392BF8: lh          $t8, 0x3330($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3330);
    // 0x80392BFC: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80392C00: addiu       $t0, $t0, 0x34C0
    ctx->r8 = ADD32(ctx->r8, 0X34C0);
    // 0x80392C04: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80392C08: addu        $s0, $t9, $t0
    ctx->r16 = ADD32(ctx->r25, ctx->r8);
    // 0x80392C0C: lh          $t1, 0x0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X0);
    // 0x80392C10: addiu       $at, $zero, 0x133
    ctx->r1 = ADD32(0, 0X133);
    // 0x80392C14: bnel        $t1, $at, L_80392F84
    if (ctx->r9 != ctx->r1) {
        // 0x80392C18: addiu       $s2, $s2, 0x1
        ctx->r18 = ADD32(ctx->r18, 0X1);
            goto L_80392F84;
    }
    goto skip_0;
    // 0x80392C18: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    skip_0:
    // 0x80392C1C: lh          $v0, 0x2($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2);
    // 0x80392C20: addiu       $at, $zero, 0x133
    ctx->r1 = ADD32(0, 0X133);
    // 0x80392C24: lh          $t2, 0xA2($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XA2);
    // 0x80392C28: bne         $v0, $at, L_80392E7C
    if (ctx->r2 != ctx->r1) {
        // 0x80392C2C: lui         $t9, 0x803E
        ctx->r25 = S32(0X803E << 16);
            goto L_80392E7C;
    }
    // 0x80392C2C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80392C30: bne         $t2, $zero, L_80392C64
    if (ctx->r10 != 0) {
        // 0x80392C34: addiu       $fp, $zero, 0x2B
        ctx->r30 = ADD32(0, 0X2B);
            goto L_80392C64;
    }
    // 0x80392C34: addiu       $fp, $zero, 0x2B
    ctx->r30 = ADD32(0, 0X2B);
    // 0x80392C38: mtc1        $s1, $f4
    ctx->f4.u32l = ctx->r17;
    // 0x80392C3C: lwc1        $f8, 0x0($s5)
    ctx->f8.u32l = MEM_W(ctx->r21, 0X0);
    // 0x80392C40: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80392C44: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80392C48: sh          $t3, 0xA2($sp)
    MEM_H(0XA2, ctx->r29) = ctx->r11;
    // 0x80392C4C: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x80392C50: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80392C54: mfc1        $s1, $f16
    ctx->r17 = (int32_t)ctx->f16.u32l;
    // 0x80392C58: nop

    // 0x80392C5C: sll         $t5, $s1, 16
    ctx->r13 = S32(ctx->r17 << 16);
    // 0x80392C60: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
L_80392C64:
    // 0x80392C64: lw          $t9, 0x4D2C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4D2C);
    // 0x80392C68: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80392C6C: sllv        $t8, $t7, $s7
    ctx->r24 = S32(ctx->r15 << (ctx->r23 & 31));
    // 0x80392C70: and         $t0, $t8, $t9
    ctx->r8 = ctx->r24 & ctx->r25;
    // 0x80392C74: beq         $t0, $zero, L_80392D84
    if (ctx->r8 == 0) {
        // 0x80392C78: addiu       $a0, $zero, 0xFF
        ctx->r4 = ADD32(0, 0XFF);
            goto L_80392D84;
    }
    // 0x80392C78: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80392C7C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80392C80: addiu       $a1, $zero, 0xC8
    ctx->r5 = ADD32(0, 0XC8);
    // 0x80392C84: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392C88: jal         0x8012C214
    // 0x80392C8C: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_12;
    // 0x80392C8C: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_12:
    // 0x80392C90: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80392C94: addiu       $a1, $a1, 0x190
    ctx->r5 = ADD32(ctx->r5, 0X190);
    // 0x80392C98: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80392C9C: jal         0x801395F4
    // 0x80392CA0: addiu       $a2, $zero, 0x5D
    ctx->r6 = ADD32(0, 0X5D);
    sprintf_recomp(rdram, ctx);
        goto after_13;
    // 0x80392CA0: addiu       $a2, $zero, 0x5D
    ctx->r6 = ADD32(0, 0X5D);
    after_13:
    // 0x80392CA4: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80392CA8: jal         0x801308B4
    // 0x80392CAC: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    prepare_text(rdram, ctx);
        goto after_14;
    // 0x80392CAC: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    after_14:
    // 0x80392CB0: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x80392CB4: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80392CB8: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80392CBC: lwc1        $f0, 0x0($s5)
    ctx->f0.u32l = MEM_W(ctx->r21, 0X0);
    // 0x80392CC0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80392CC4: lwc1        $f18, 0x6868($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X6868);
    // 0x80392CC8: cvt.w.s     $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = CVT_W_S(ctx->f0.fl);
    // 0x80392CCC: addiu       $t1, $zero, 0x128
    ctx->r9 = ADD32(0, 0X128);
    // 0x80392CD0: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x80392CD4: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x80392CD8: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80392CDC: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x80392CE0: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x80392CE4: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x80392CE8: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x80392CEC: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80392CF0: beq         $t3, $zero, L_80392D40
    if (ctx->r11 == 0) {
        // 0x80392CF4: swc1        $f18, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
            goto L_80392D40;
    }
    // 0x80392CF4: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80392CF8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80392CFC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80392D00: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80392D04: sub.s       $f4, $f0, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f0.fl - ctx->f4.fl;
    // 0x80392D08: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80392D0C: nop

    // 0x80392D10: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80392D14: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80392D18: nop

    // 0x80392D1C: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x80392D20: bne         $t3, $zero, L_80392D38
    if (ctx->r11 != 0) {
        // 0x80392D24: nop
    
            goto L_80392D38;
    }
    // 0x80392D24: nop

    // 0x80392D28: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    // 0x80392D2C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80392D30: b           L_80392D50
    // 0x80392D34: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
        goto L_80392D50;
    // 0x80392D34: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
L_80392D38:
    // 0x80392D38: b           L_80392D50
    // 0x80392D3C: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
        goto L_80392D50;
    // 0x80392D3C: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
L_80392D40:
    // 0x80392D40: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    // 0x80392D44: nop

    // 0x80392D48: bltz        $t3, L_80392D38
    if (SIGNED(ctx->r11) < 0) {
        // 0x80392D4C: nop
    
            goto L_80392D38;
    }
    // 0x80392D4C: nop

L_80392D50:
    // 0x80392D50: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x80392D54: jal         0x8012FBEC
    // 0x80392D58: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    display_text_wrapped(rdram, ctx);
        goto after_15;
    // 0x80392D58: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    after_15:
    // 0x80392D5C: sll         $s1, $v0, 16
    ctx->r17 = S32(ctx->r2 << 16);
    // 0x80392D60: sra         $t4, $s1, 16
    ctx->r12 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80392D64: or          $s1, $t4, $zero
    ctx->r17 = ctx->r12 | 0;
    // 0x80392D68: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    // 0x80392D6C: addiu       $a1, $zero, 0x78
    ctx->r5 = ADD32(0, 0X78);
    // 0x80392D70: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392D74: jal         0x8012C214
    // 0x80392D78: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_16;
    // 0x80392D78: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_16:
    // 0x80392D7C: b           L_80392E70
    // 0x80392D80: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
        goto L_80392E70;
    // 0x80392D80: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
L_80392D84:
    // 0x80392D84: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80392D88: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80392D8C: jal         0x8012C214
    // 0x80392D90: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_17;
    // 0x80392D90: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_17:
    // 0x80392D94: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80392D98: addiu       $a1, $a1, 0x194
    ctx->r5 = ADD32(ctx->r5, 0X194);
    // 0x80392D9C: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80392DA0: jal         0x801395F4
    // 0x80392DA4: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    sprintf_recomp(rdram, ctx);
        goto after_18;
    // 0x80392DA4: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    after_18:
    // 0x80392DA8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80392DAC: jal         0x801308B4
    // 0x80392DB0: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    prepare_text(rdram, ctx);
        goto after_19;
    // 0x80392DB0: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    after_19:
    // 0x80392DB4: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80392DB8: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80392DBC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80392DC0: lwc1        $f0, 0x0($s5)
    ctx->f0.u32l = MEM_W(ctx->r21, 0X0);
    // 0x80392DC4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80392DC8: lwc1        $f6, 0x6868($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X6868);
    // 0x80392DCC: cvt.w.s     $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = CVT_W_S(ctx->f0.fl);
    // 0x80392DD0: addiu       $t5, $zero, 0x128
    ctx->r13 = ADD32(0, 0X128);
    // 0x80392DD4: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80392DD8: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x80392DDC: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80392DE0: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x80392DE4: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x80392DE8: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80392DEC: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x80392DF0: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80392DF4: beq         $t7, $zero, L_80392E44
    if (ctx->r15 == 0) {
        // 0x80392DF8: swc1        $f6, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
            goto L_80392E44;
    }
    // 0x80392DF8: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x80392DFC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80392E00: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80392E04: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80392E08: sub.s       $f8, $f0, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f0.fl - ctx->f8.fl;
    // 0x80392E0C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80392E10: nop

    // 0x80392E14: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80392E18: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80392E1C: nop

    // 0x80392E20: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80392E24: bne         $t7, $zero, L_80392E3C
    if (ctx->r15 != 0) {
        // 0x80392E28: nop
    
            goto L_80392E3C;
    }
    // 0x80392E28: nop

    // 0x80392E2C: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x80392E30: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80392E34: b           L_80392E54
    // 0x80392E38: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_80392E54;
    // 0x80392E38: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_80392E3C:
    // 0x80392E3C: b           L_80392E54
    // 0x80392E40: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_80392E54;
    // 0x80392E40: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
L_80392E44:
    // 0x80392E44: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x80392E48: nop

    // 0x80392E4C: bltz        $t7, L_80392E3C
    if (SIGNED(ctx->r15) < 0) {
        // 0x80392E50: nop
    
            goto L_80392E3C;
    }
    // 0x80392E50: nop

L_80392E54:
    // 0x80392E54: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80392E58: jal         0x8012FBEC
    // 0x80392E5C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    display_text_wrapped(rdram, ctx);
        goto after_20;
    // 0x80392E5C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    after_20:
    // 0x80392E60: sll         $s1, $v0, 16
    ctx->r17 = S32(ctx->r2 << 16);
    // 0x80392E64: sra         $t8, $s1, 16
    ctx->r24 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80392E68: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x80392E6C: addiu       $s7, $s7, 0x1
    ctx->r23 = ADD32(ctx->r23, 0X1);
L_80392E70:
    // 0x80392E70: sll         $t9, $s7, 16
    ctx->r25 = S32(ctx->r23 << 16);
    // 0x80392E74: sra         $s7, $t9, 16
    ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80392E78: lh          $v0, 0x2($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2);
L_80392E7C:
    // 0x80392E7C: addiu       $at, $zero, 0x173
    ctx->r1 = ADD32(0, 0X173);
    // 0x80392E80: bne         $v0, $at, L_80392E9C
    if (ctx->r2 != ctx->r1) {
        // 0x80392E84: addiu       $a0, $zero, 0xFF
        ctx->r4 = ADD32(0, 0XFF);
            goto L_80392E9C;
    }
    // 0x80392E84: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80392E88: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80392E8C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80392E90: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    // 0x80392E94: jal         0x8012C214
    // 0x80392E98: addiu       $fp, $zero, 0x17
    ctx->r30 = ADD32(0, 0X17);
    set_menu_text_color(rdram, ctx);
        goto after_21;
    // 0x80392E98: addiu       $fp, $zero, 0x17
    ctx->r30 = ADD32(0, 0X17);
    after_21:
L_80392E9C:
    // 0x80392E9C: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x80392EA0: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80392EA4: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80392EA8: lwc1        $f0, 0x0($s5)
    ctx->f0.u32l = MEM_W(ctx->r21, 0X0);
    // 0x80392EAC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80392EB0: lwc1        $f10, 0x6868($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X6868);
    // 0x80392EB4: cvt.w.s     $f16, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    ctx->f16.u32l = CVT_W_S(ctx->f0.fl);
    // 0x80392EB8: addiu       $t1, $zero, 0x128
    ctx->r9 = ADD32(0, 0X128);
    // 0x80392EBC: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80392EC0: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x80392EC4: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80392EC8: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x80392ECC: andi        $a2, $fp, 0xFFFF
    ctx->r6 = ctx->r30 & 0XFFFF;
    // 0x80392ED0: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x80392ED4: andi        $a3, $s1, 0xFFFF
    ctx->r7 = ctx->r17 & 0XFFFF;
    // 0x80392ED8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80392EDC: beq         $t3, $zero, L_80392F2C
    if (ctx->r11 == 0) {
        // 0x80392EE0: swc1        $f10, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
            goto L_80392F2C;
    }
    // 0x80392EE0: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80392EE4: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80392EE8: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80392EEC: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80392EF0: sub.s       $f16, $f0, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f0.fl - ctx->f16.fl;
    // 0x80392EF4: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80392EF8: nop

    // 0x80392EFC: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80392F00: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80392F04: nop

    // 0x80392F08: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x80392F0C: bne         $t3, $zero, L_80392F24
    if (ctx->r11 != 0) {
        // 0x80392F10: nop
    
            goto L_80392F24;
    }
    // 0x80392F10: nop

    // 0x80392F14: mfc1        $t3, $f16
    ctx->r11 = (int32_t)ctx->f16.u32l;
    // 0x80392F18: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80392F1C: b           L_80392F3C
    // 0x80392F20: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
        goto L_80392F3C;
    // 0x80392F20: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
L_80392F24:
    // 0x80392F24: b           L_80392F3C
    // 0x80392F28: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
        goto L_80392F3C;
    // 0x80392F28: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
L_80392F2C:
    // 0x80392F2C: mfc1        $t3, $f16
    ctx->r11 = (int32_t)ctx->f16.u32l;
    // 0x80392F30: nop

    // 0x80392F34: bltz        $t3, L_80392F24
    if (SIGNED(ctx->r11) < 0) {
        // 0x80392F38: nop
    
            goto L_80392F24;
    }
    // 0x80392F38: nop

L_80392F3C:
    // 0x80392F3C: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x80392F40: jal         0x8012FBEC
    // 0x80392F44: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    display_text_wrapped(rdram, ctx);
        goto after_22;
    // 0x80392F44: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    after_22:
    // 0x80392F48: mtc1        $v0, $f8
    ctx->f8.u32l = ctx->r2;
    // 0x80392F4C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80392F50: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80392F54: lwc1        $f18, 0x0($s5)
    ctx->f18.u32l = MEM_W(ctx->r21, 0X0);
    // 0x80392F58: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80392F5C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80392F60: lh          $v1, 0x63C0($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X63C0);
    // 0x80392F64: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x80392F68: add.s       $f16, $f10, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x80392F6C: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80392F70: mfc1        $s1, $f18
    ctx->r17 = (int32_t)ctx->f18.u32l;
    // 0x80392F74: nop

    // 0x80392F78: sll         $t5, $s1, 16
    ctx->r13 = S32(ctx->r17 << 16);
    // 0x80392F7C: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80392F80: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
L_80392F84:
    // 0x80392F84: sll         $t7, $s2, 16
    ctx->r15 = S32(ctx->r18 << 16);
    // 0x80392F88: sra         $s2, $t7, 16
    ctx->r18 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80392F8C: slt         $at, $s2, $v1
    ctx->r1 = SIGNED(ctx->r18) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80392F90: bnel        $at, $zero, L_80392BF0
    if (ctx->r1 != 0) {
        // 0x80392F94: sll         $t7, $s2, 1
        ctx->r15 = S32(ctx->r18 << 1);
            goto L_80392BF0;
    }
    goto skip_1;
    // 0x80392F94: sll         $t7, $s2, 1
    ctx->r15 = S32(ctx->r18 << 1);
    skip_1:
L_80392F98:
    // 0x80392F98: lw          $a2, 0x0($s6)
    ctx->r6 = MEM_W(ctx->r22, 0X0);
    // 0x80392F9C: lui         $t0, 0xB800
    ctx->r8 = S32(0XB800 << 16);
    // 0x80392FA0: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x80392FA4: addiu       $t9, $a2, 0x8
    ctx->r25 = ADD32(ctx->r6, 0X8);
    // 0x80392FA8: sw          $t9, 0x0($s6)
    MEM_W(0X0, ctx->r22) = ctx->r25;
    // 0x80392FAC: sw          $zero, 0x4($a2)
    MEM_W(0X4, ctx->r6) = 0;
    // 0x80392FB0: sw          $t0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r8;
    // 0x80392FB4: lw          $v1, -0x6184($v1)
    ctx->r3 = MEM_W(ctx->r3, -0X6184);
    // 0x80392FB8: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80392FBC: lui         $t2, 0x600
    ctx->r10 = S32(0X600 << 16);
    // 0x80392FC0: addiu       $t1, $v1, 0x8
    ctx->r9 = ADD32(ctx->r3, 0X8);
    // 0x80392FC4: sw          $t1, -0x6184($at)
    MEM_W(-0X6184, ctx->r1) = ctx->r9;
    // 0x80392FC8: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x80392FCC: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x80392FD0: lw          $t3, 0x4278($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X4278);
    // 0x80392FD4: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x80392FD8: ori         $at, $at, 0x9A0
    ctx->r1 = ctx->r1 | 0X9A0;
    // 0x80392FDC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80392FE0: addu        $t4, $t3, $at
    ctx->r12 = ADD32(ctx->r11, ctx->r1);
    // 0x80392FE4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x80392FE8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    sssv_file_select_layout_hook(rdram, ctx, 3);
    // 0x80392FEC: jal         0x8039D034
    // 0x80392FF0: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    func_8039D034_7AE6E4(rdram, ctx);
        goto after_23;
    // 0x80392FF0: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    after_23:
    // 0x80392FF4: lw          $ra, 0x4C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X4C);
    // 0x80392FF8: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x80392FFC: lw          $s1, 0x2C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X2C);
    // 0x80393000: lw          $s2, 0x30($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X30);
    // 0x80393004: lw          $s3, 0x34($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X34);
    // 0x80393008: lw          $s4, 0x38($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X38);
    // 0x8039300C: lw          $s5, 0x3C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X3C);
    // 0x80393010: lw          $s6, 0x40($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X40);
    // 0x80393014: lw          $s7, 0x44($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X44);
    // 0x80393018: lw          $fp, 0x48($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X48);
    // 0x8039301C: jr          $ra
    // 0x80393020: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
    return;
    // 0x80393020: addiu       $sp, $sp, 0xB0
    ctx->r29 = ADD32(ctx->r29, 0XB0);
;}
RECOMP_FUNC void func_80393024_7A46D4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80393024: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80393028: lh          $t0, 0x1A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X1A);
    // 0x8039302C: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x80393030: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x80393034: sll         $t6, $t0, 4
    ctx->r14 = S32(ctx->r8 << 4);
    // 0x80393038: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x8039303C: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x80393040: addu        $t9, $t8, $t3
    ctx->r25 = ADD32(ctx->r24, ctx->r11);
    // 0x80393044: sh          $a1, 0x1070($t9)
    MEM_H(0X1070, ctx->r25) = ctx->r5;
    // 0x80393048: lw          $t5, 0x0($t2)
    ctx->r13 = MEM_W(ctx->r10, 0X0);
    // 0x8039304C: lw          $t4, 0x14($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X14);
    // 0x80393050: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x80393054: addu        $t6, $t5, $t6
    ctx->r14 = ADD32(ctx->r13, ctx->r14);
    // 0x80393058: addu        $t7, $t6, $t3
    ctx->r15 = ADD32(ctx->r14, ctx->r11);
    // 0x8039305C: sh          $t4, 0x1072($t7)
    MEM_H(0X1072, ctx->r15) = ctx->r12;
    // 0x80393060: lw          $t8, 0x0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0X0);
    // 0x80393064: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80393068: ori         $at, $at, 0x1070
    ctx->r1 = ctx->r1 | 0X1070;
    // 0x8039306C: addu        $t9, $t8, $t0
    ctx->r25 = ADD32(ctx->r24, ctx->r8);
    // 0x80393070: addu        $t5, $t9, $t3
    ctx->r13 = ADD32(ctx->r25, ctx->r11);
    // 0x80393074: sh          $a2, 0x1074($t5)
    MEM_H(0X1074, ctx->r13) = ctx->r6;
    // 0x80393078: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x8039307C: lui         $v1, 0xE700
    ctx->r3 = S32(0XE700 << 16);
    // 0x80393080: addu        $t4, $t6, $t0
    ctx->r12 = ADD32(ctx->r14, ctx->r8);
    // 0x80393084: addu        $t7, $t4, $t3
    ctx->r15 = ADD32(ctx->r12, ctx->r11);
    // 0x80393088: sh          $a1, 0x1080($t7)
    MEM_H(0X1080, ctx->r15) = ctx->r5;
    // 0x8039308C: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x80393090: lw          $t8, 0x14($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X14);
    // 0x80393094: addu        $t5, $t9, $t0
    ctx->r13 = ADD32(ctx->r25, ctx->r8);
    // 0x80393098: addu        $t6, $t5, $t3
    ctx->r14 = ADD32(ctx->r13, ctx->r11);
    // 0x8039309C: sh          $t8, 0x1082($t6)
    MEM_H(0X1082, ctx->r14) = ctx->r24;
    // 0x803930A0: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x803930A4: lw          $t4, 0x10($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X10);
    // 0x803930A8: addu        $t9, $t7, $t0
    ctx->r25 = ADD32(ctx->r15, ctx->r8);
    // 0x803930AC: addu        $t5, $t9, $t3
    ctx->r13 = ADD32(ctx->r25, ctx->r11);
    // 0x803930B0: sh          $t4, 0x1084($t5)
    MEM_H(0X1084, ctx->r13) = ctx->r12;
    // 0x803930B4: lw          $t8, 0x0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0X0);
    // 0x803930B8: addu        $t6, $t8, $t0
    ctx->r14 = ADD32(ctx->r24, ctx->r8);
    // 0x803930BC: addu        $t7, $t6, $t3
    ctx->r15 = ADD32(ctx->r14, ctx->r11);
    // 0x803930C0: sh          $a3, 0x1090($t7)
    MEM_H(0X1090, ctx->r15) = ctx->r7;
    // 0x803930C4: lw          $t4, 0x0($t2)
    ctx->r12 = MEM_W(ctx->r10, 0X0);
    // 0x803930C8: lw          $t9, 0x14($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X14);
    // 0x803930CC: addu        $t5, $t4, $t0
    ctx->r13 = ADD32(ctx->r12, ctx->r8);
    // 0x803930D0: addu        $t8, $t5, $t3
    ctx->r24 = ADD32(ctx->r13, ctx->r11);
    // 0x803930D4: sh          $t9, 0x1092($t8)
    MEM_H(0X1092, ctx->r24) = ctx->r25;
    // 0x803930D8: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x803930DC: lw          $t6, 0x10($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X10);
    // 0x803930E0: addu        $t4, $t7, $t0
    ctx->r12 = ADD32(ctx->r15, ctx->r8);
    // 0x803930E4: addu        $t5, $t4, $t3
    ctx->r13 = ADD32(ctx->r12, ctx->r11);
    // 0x803930E8: sh          $t6, 0x1094($t5)
    MEM_H(0X1094, ctx->r13) = ctx->r14;
    // 0x803930EC: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x803930F0: addu        $t8, $t9, $t0
    ctx->r24 = ADD32(ctx->r25, ctx->r8);
    // 0x803930F4: addu        $t7, $t8, $t3
    ctx->r15 = ADD32(ctx->r24, ctx->r11);
    // 0x803930F8: sh          $a3, 0x10A0($t7)
    MEM_H(0X10A0, ctx->r15) = ctx->r7;
    // 0x803930FC: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x80393100: lw          $t4, 0x14($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X14);
    // 0x80393104: addu        $t5, $t6, $t0
    ctx->r13 = ADD32(ctx->r14, ctx->r8);
    // 0x80393108: addu        $t9, $t5, $t3
    ctx->r25 = ADD32(ctx->r13, ctx->r11);
    // 0x8039310C: sh          $t4, 0x10A2($t9)
    MEM_H(0X10A2, ctx->r25) = ctx->r12;
    // 0x80393110: lw          $t8, 0x0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0X0);
    // 0x80393114: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80393118: ori         $t4, $t4, 0x103F
    ctx->r12 = ctx->r12 | 0X103F;
    // 0x8039311C: addu        $t7, $t8, $t0
    ctx->r15 = ADD32(ctx->r24, ctx->r8);
    // 0x80393120: addu        $t6, $t7, $t3
    ctx->r14 = ADD32(ctx->r15, ctx->r11);
    // 0x80393124: sh          $a2, 0x10A4($t6)
    MEM_H(0X10A4, ctx->r14) = ctx->r6;
    // 0x80393128: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039312C: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80393130: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x80393134: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80393138: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x8039313C: addu        $t8, $t9, $t0
    ctx->r24 = ADD32(ctx->r25, ctx->r8);
    // 0x80393140: addu        $t7, $t8, $at
    ctx->r15 = ADD32(ctx->r24, ctx->r1);
    // 0x80393144: lui         $at, 0x1FFF
    ctx->r1 = S32(0X1FFF << 16);
    // 0x80393148: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x8039314C: and         $t6, $t7, $at
    ctx->r14 = ctx->r15 & ctx->r1;
    // 0x80393150: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80393154: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80393158: lui         $t8, 0xC19
    ctx->r24 = S32(0XC19 << 16);
    // 0x8039315C: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x80393160: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80393164: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x80393168: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039316C: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x80393170: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80393174: ori         $t9, $t9, 0x31D
    ctx->r25 = ctx->r25 | 0X31D;
    // 0x80393178: ori         $t8, $t8, 0x2078
    ctx->r24 = ctx->r24 | 0X2078;
    // 0x8039317C: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80393180: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x80393184: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80393188: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039318C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80393190: lui         $t5, 0x2
    ctx->r13 = S32(0X2 << 16);
    // 0x80393194: ori         $t5, $t5, 0x2200
    ctx->r13 = ctx->r13 | 0X2200;
    // 0x80393198: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039319C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803931A0: lui         $t6, 0xB600
    ctx->r14 = S32(0XB600 << 16);
    // 0x803931A4: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803931A8: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x803931AC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803931B0: lui         $t9, 0xFC71
    ctx->r25 = S32(0XFC71 << 16);
    // 0x803931B4: ori         $t9, $t9, 0xFEE3
    ctx->r25 = ctx->r25 | 0XFEE3;
    // 0x803931B8: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x803931BC: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x803931C0: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x803931C4: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803931C8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803931CC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803931D0: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x803931D4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803931D8: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803931DC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x803931E0: lbu         $t5, 0x1F($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X1F);
    // 0x803931E4: sll         $t4, $t5, 24
    ctx->r12 = S32(ctx->r13 << 24);
    // 0x803931E8: sll         $t9, $t5, 16
    ctx->r25 = S32(ctx->r13 << 16);
    // 0x803931EC: or          $t8, $t4, $t9
    ctx->r24 = ctx->r12 | ctx->r25;
    // 0x803931F0: sll         $t7, $t5, 8
    ctx->r15 = S32(ctx->r13 << 8);
    // 0x803931F4: or          $t6, $t8, $t7
    ctx->r14 = ctx->r24 | ctx->r15;
    // 0x803931F8: ori         $t5, $t6, 0x80
    ctx->r13 = ctx->r14 | 0X80;
    // 0x803931FC: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80393200: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80393204: lui         $t8, 0xB100
    ctx->r24 = S32(0XB100 << 16);
    // 0x80393208: ori         $t8, $t8, 0x204
    ctx->r24 = ctx->r24 | 0X204;
    // 0x8039320C: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80393210: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x80393214: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80393218: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8039321C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80393220: addiu       $t7, $zero, 0x406
    ctx->r15 = ADD32(0, 0X406);
    // 0x80393224: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80393228: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039322C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80393230: jr          $ra
    // 0x80393234: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    return;
    // 0x80393234: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
;}
RECOMP_FUNC void load_pause_menu(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80393238: addiu       $sp, $sp, -0x1B0
    ctx->r29 = ADD32(ctx->r29, -0X1B0);
    // 0x8039323C: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x80393240: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80393244: addiu       $s1, $s1, -0xD60
    ctx->r17 = ADD32(ctx->r17, -0XD60);
    // 0x80393248: lb          $a2, 0xE($s1)
    ctx->r6 = MEM_B(ctx->r17, 0XE);
    // 0x8039324C: addiu       $t6, $zero, 0x10
    ctx->r14 = ADD32(0, 0X10);
    // 0x80393250: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80393254: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x80393258: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x8039325C: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x80393260: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x80393264: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x80393268: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x8039326C: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x80393270: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x80393274: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80393278: sw          $a0, 0x1B0($sp)
    MEM_W(0X1B0, ctx->r29) = ctx->r4;
    // 0x8039327C: sw          $a1, 0x1B4($sp)
    MEM_W(0X1B4, ctx->r29) = ctx->r5;
    // 0x80393280: beq         $a2, $at, L_80393290
    if (ctx->r6 == ctx->r1) {
        // 0x80393284: sh          $t6, 0xE6($sp)
        MEM_H(0XE6, ctx->r29) = ctx->r14;
            goto L_80393290;
    }
    // 0x80393284: sh          $t6, 0xE6($sp)
    MEM_H(0XE6, ctx->r29) = ctx->r14;
    // 0x80393288: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8039328C: bne         $a2, $at, L_80393298
    if (ctx->r6 != ctx->r1) {
        // 0x80393290: addiu       $t7, $zero, 0xA
        ctx->r15 = ADD32(0, 0XA);
            goto L_80393298;
    }
L_80393290:
    // 0x80393290: addiu       $t7, $zero, 0xA
    ctx->r15 = ADD32(0, 0XA);
    // 0x80393294: sh          $t7, 0xE6($sp)
    MEM_H(0XE6, ctx->r29) = ctx->r15;
L_80393298:
    // 0x80393298: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039329C: beq         $a2, $at, L_803932BC
    if (ctx->r6 == ctx->r1) {
        // 0x803932A0: lui         $s0, 0x803F
        ctx->r16 = S32(0X803F << 16);
            goto L_803932BC;
    }
    // 0x803932A0: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x803932A4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803932A8: beq         $a2, $at, L_803932BC
    if (ctx->r6 == ctx->r1) {
        // 0x803932AC: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803932BC;
    }
    // 0x803932AC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803932B0: beq         $a2, $at, L_803932BC
    if (ctx->r6 == ctx->r1) {
        // 0x803932B4: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_803932BC;
    }
    // 0x803932B4: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x803932B8: bne         $a2, $at, L_803932C4
    if (ctx->r6 != ctx->r1) {
        // 0x803932BC: addiu       $t8, $zero, 0xC
        ctx->r24 = ADD32(0, 0XC);
            goto L_803932C4;
    }
L_803932BC:
    // 0x803932BC: addiu       $t8, $zero, 0xC
    ctx->r24 = ADD32(0, 0XC);
    // 0x803932C0: sh          $t8, 0xE6($sp)
    MEM_H(0XE6, ctx->r29) = ctx->r24;
L_803932C4:
    // 0x803932C4: addiu       $s0, $s0, 0x6680
    ctx->r16 = ADD32(ctx->r16, 0X6680);
    // 0x803932C8: lh          $v0, 0x20($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X20);
    // 0x803932CC: beq         $v0, $zero, L_80393400
    if (ctx->r2 == 0) {
        // 0x803932D0: slti        $at, $v0, 0xFF
        ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
            goto L_80393400;
    }
    // 0x803932D0: slti        $at, $v0, 0xFF
    ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
    // 0x803932D4: beq         $at, $zero, L_803932E4
    if (ctx->r1 == 0) {
        // 0x803932D8: lui         $a1, 0x803F
        ctx->r5 = S32(0X803F << 16);
            goto L_803932E4;
    }
    // 0x803932D8: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803932DC: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x803932E0: sh          $t9, 0x20($s0)
    MEM_H(0X20, ctx->r16) = ctx->r25;
L_803932E4:
    // 0x803932E4: lh          $a1, 0x6706($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6706);
    // 0x803932E8: addiu       $at, $zero, 0x2F8
    ctx->r1 = ADD32(0, 0X2F8);
    // 0x803932EC: addiu       $t6, $zero, 0x2F8
    ctx->r14 = ADD32(0, 0X2F8);
    // 0x803932F0: beq         $a1, $at, L_803933F8
    if (ctx->r5 == ctx->r1) {
        // 0x803932F4: subu        $t7, $t6, $a1
        ctx->r15 = SUB32(ctx->r14, ctx->r5);
            goto L_803933F8;
    }
    // 0x803932F4: subu        $t7, $t6, $a1
    ctx->r15 = SUB32(ctx->r14, ctx->r5);
    // 0x803932F8: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x803932FC: lui         $at, 0x3FC0
    ctx->r1 = S32(0X3FC0 << 16);
    // 0x80393300: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x80393304: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80393308: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x8039330C: mtc1        $a1, $f4
    ctx->f4.u32l = ctx->r5;
    // 0x80393310: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80393314: lh          $v0, 0x670A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X670A);
    // 0x80393318: mul.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f0.d);
    // 0x8039331C: addiu       $t6, $zero, 0x490
    ctx->r14 = ADD32(0, 0X490);
    // 0x80393320: subu        $t7, $t6, $v0
    ctx->r15 = SUB32(ctx->r14, ctx->r2);
    // 0x80393324: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x80393328: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039332C: lh          $v1, 0x6708($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X6708);
    // 0x80393330: addiu       $t6, $zero, 0xE0
    ctx->r14 = ADD32(0, 0XE0);
    // 0x80393334: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80393338: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039333C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80393340: lh          $a0, 0x670C($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X670C);
    // 0x80393344: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x80393348: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039334C: add.s       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f6.fl + ctx->f18.fl;
    // 0x80393350: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x80393354: subu        $t7, $t6, $v1
    ctx->r15 = SUB32(ctx->r14, ctx->r3);
    // 0x80393358: addiu       $t6, $zero, 0x200
    ctx->r14 = ADD32(0, 0X200);
    // 0x8039335C: cvt.d.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.d = CVT_D_W(ctx->f6.u32l);
    // 0x80393360: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80393364: mul.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = MUL_D(ctx->f18.d, ctx->f0.d);
    // 0x80393368: mtc1        $v1, $f18
    ctx->f18.u32l = ctx->r3;
    // 0x8039336C: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x80393370: nop

    // 0x80393374: sh          $t9, 0x6706($at)
    MEM_H(0X6706, ctx->r1) = ctx->r25;
    // 0x80393378: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039337C: cvt.s.d     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f8.fl = CVT_S_D(ctx->f4.d);
    // 0x80393380: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80393384: add.s       $f10, $f16, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f16.fl + ctx->f8.fl;
    // 0x80393388: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x8039338C: subu        $t7, $t6, $a0
    ctx->r15 = SUB32(ctx->r14, ctx->r4);
    // 0x80393390: cvt.d.w     $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.d = CVT_D_W(ctx->f16.u32l);
    // 0x80393394: trunc.w.s   $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80393398: mul.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = MUL_D(ctx->f8.d, ctx->f0.d);
    // 0x8039339C: mtc1        $a0, $f8
    ctx->f8.u32l = ctx->r4;
    // 0x803933A0: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
    // 0x803933A4: nop

    // 0x803933A8: sh          $t9, 0x670A($at)
    MEM_H(0X670A, ctx->r1) = ctx->r25;
    // 0x803933AC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803933B0: cvt.s.d     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f6.fl = CVT_S_D(ctx->f10.d);
    // 0x803933B4: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x803933B8: add.s       $f18, $f4, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f18.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x803933BC: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x803933C0: nop

    // 0x803933C4: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x803933C8: trunc.w.s   $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    ctx->f16.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x803933CC: mul.d       $f18, $f6, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f0.d); 
    ctx->f18.d = MUL_D(ctx->f6.d, ctx->f0.d);
    // 0x803933D0: mfc1        $t9, $f16
    ctx->r25 = (int32_t)ctx->f16.u32l;
    // 0x803933D4: nop

    // 0x803933D8: sh          $t9, 0x6708($at)
    MEM_H(0X6708, ctx->r1) = ctx->r25;
    // 0x803933DC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803933E0: cvt.s.d     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f16.fl = CVT_S_D(ctx->f18.d);
    // 0x803933E4: add.s       $f8, $f10, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = ctx->f10.fl + ctx->f16.fl;
    // 0x803933E8: trunc.w.s   $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x803933EC: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x803933F0: nop

    // 0x803933F4: sh          $t9, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r25;
L_803933F8:
    // 0x803933F8: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x803933FC: sb          $t6, 0xF3($sp)
    MEM_B(0XF3, ctx->r29) = ctx->r14;
L_80393400:
    // 0x80393400: lh          $v0, 0x22($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X22);
    // 0x80393404: beq         $v0, $zero, L_803935B8
    if (ctx->r2 == 0) {
        // 0x80393408: addiu       $t7, $zero, 0xFF
        ctx->r15 = ADD32(0, 0XFF);
            goto L_803935B8;
    }
    // 0x80393408: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8039340C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80393410: bne         $v0, $at, L_80393464
    if (ctx->r2 != ctx->r1) {
        // 0x80393414: sb          $t7, 0xF3($sp)
        MEM_B(0XF3, ctx->r29) = ctx->r15;
            goto L_80393464;
    }
    // 0x80393414: sb          $t7, 0xF3($sp)
    MEM_B(0XF3, ctx->r29) = ctx->r15;
    // 0x80393418: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8039341C: lh          $t9, 0x6716($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6716);
    // 0x80393420: lb          $t8, 0xD($s1)
    ctx->r24 = MEM_B(ctx->r17, 0XD);
    // 0x80393424: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80393428: bne         $t8, $t9, L_80393450
    if (ctx->r24 != ctx->r25) {
        // 0x8039342C: nop
    
            goto L_80393450;
    }
    // 0x8039342C: nop

    // 0x80393430: lb          $t6, 0xC($s1)
    ctx->r14 = MEM_B(ctx->r17, 0XC);
    // 0x80393434: lh          $t7, 0x6718($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6718);
    // 0x80393438: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8039343C: bne         $t6, $t7, L_80393450
    if (ctx->r14 != ctx->r15) {
        // 0x80393440: nop
    
            goto L_80393450;
    }
    // 0x80393440: nop

    // 0x80393444: lh          $t8, 0x671A($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X671A);
    // 0x80393448: beq         $a2, $t8, L_80393464
    if (ctx->r6 == ctx->r24) {
        // 0x8039344C: nop
    
            goto L_80393464;
    }
    // 0x8039344C: nop

L_80393450:
    // 0x80393450: jal         0x80130C30
    // 0x80393454: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    write_eeprom(rdram, ctx);
        goto after_0;
    // 0x80393454: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_0:
    // 0x80393458: jal         0x80133BA0
    // 0x8039345C: lb          $a0, 0xC($s1)
    ctx->r4 = MEM_B(ctx->r17, 0XC);
    set_music_volume(rdram, ctx);
        goto after_1;
    // 0x8039345C: lb          $a0, 0xC($s1)
    ctx->r4 = MEM_B(ctx->r17, 0XC);
    after_1:
    // 0x80393460: lh          $v0, 0x22($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X22);
L_80393464:
    // 0x80393464: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80393468: slti        $at, $v0, 0xFF
    ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
    // 0x8039346C: beq         $at, $zero, L_8039347C
    if (ctx->r1 == 0) {
        // 0x80393470: lh          $a1, 0x6706($a1)
        ctx->r5 = MEM_H(ctx->r5, 0X6706);
            goto L_8039347C;
    }
    // 0x80393470: lh          $a1, 0x6706($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6706);
    // 0x80393474: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x80393478: sh          $t9, 0x22($s0)
    MEM_H(0X22, ctx->r16) = ctx->r25;
L_8039347C:
    // 0x8039347C: slti        $at, $a1, 0x9
    ctx->r1 = SIGNED(ctx->r5) < 0X9 ? 1 : 0;
    // 0x80393480: bne         $at, $zero, L_80393590
    if (ctx->r1 != 0) {
        // 0x80393484: addiu       $t8, $zero, 0x500
        ctx->r24 = ADD32(0, 0X500);
            goto L_80393590;
    }
    // 0x80393484: addiu       $t8, $zero, 0x500
    ctx->r24 = ADD32(0, 0X500);
    // 0x80393488: negu        $t6, $a1
    ctx->r14 = SUB32(0, ctx->r5);
    // 0x8039348C: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x80393490: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x80393494: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x80393498: cvt.d.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.d = CVT_D_W(ctx->f10.u32l);
    // 0x8039349C: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x803934A0: mtc1        $a1, $f6
    ctx->f6.u32l = ctx->r5;
    // 0x803934A4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803934A8: lh          $v0, 0x670A($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X670A);
    // 0x803934AC: mul.d       $f8, $f16, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f0.d); 
    ctx->f8.d = MUL_D(ctx->f16.d, ctx->f0.d);
    // 0x803934B0: addiu       $t9, $zero, 0x500
    ctx->r25 = ADD32(0, 0X500);
    // 0x803934B4: subu        $t6, $t9, $v0
    ctx->r14 = SUB32(ctx->r25, ctx->r2);
    // 0x803934B8: mtc1        $v0, $f16
    ctx->f16.u32l = ctx->r2;
    // 0x803934BC: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803934C0: lh          $v1, 0x6708($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X6708);
    // 0x803934C4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803934C8: cvt.s.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
    // 0x803934CC: negu        $t9, $v1
    ctx->r25 = SUB32(0, ctx->r3);
    // 0x803934D0: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803934D4: lh          $a0, 0x670C($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X670C);
    // 0x803934D8: cvt.s.d     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f4.fl = CVT_S_D(ctx->f8.d);
    // 0x803934DC: cvt.s.w     $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.fl = CVT_S_W(ctx->f16.u32l);
    // 0x803934E0: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x803934E4: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x803934E8: nop

    // 0x803934EC: cvt.d.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.d = CVT_D_W(ctx->f18.u32l);
    // 0x803934F0: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x803934F4: mul.d       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f0.d); 
    ctx->f6.d = MUL_D(ctx->f4.d, ctx->f0.d);
    // 0x803934F8: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x803934FC: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x80393500: nop

    // 0x80393504: sh          $t8, 0x6706($at)
    MEM_H(0X6706, ctx->r1) = ctx->r24;
    // 0x80393508: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039350C: cvt.s.d     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f10.fl = CVT_S_D(ctx->f6.d);
    // 0x80393510: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80393514: add.s       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x80393518: mtc1        $t9, $f8
    ctx->f8.u32l = ctx->r25;
    // 0x8039351C: nop

    // 0x80393520: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80393524: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80393528: mul.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f0.d);
    // 0x8039352C: mtc1        $a0, $f10
    ctx->f10.u32l = ctx->r4;
    // 0x80393530: mfc1        $t8, $f18
    ctx->r24 = (int32_t)ctx->f18.u32l;
    // 0x80393534: nop

    // 0x80393538: sh          $t8, 0x670A($at)
    MEM_H(0X670A, ctx->r1) = ctx->r24;
    // 0x8039353C: addiu       $t8, $zero, 0x3C0
    ctx->r24 = ADD32(0, 0X3C0);
    // 0x80393540: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x80393544: subu        $t9, $t8, $a0
    ctx->r25 = SUB32(ctx->r24, ctx->r4);
    // 0x80393548: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039354C: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80393550: add.s       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f6.fl + ctx->f18.fl;
    // 0x80393554: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x80393558: nop

    // 0x8039355C: cvt.d.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.d = CVT_D_W(ctx->f6.u32l);
    // 0x80393560: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80393564: mul.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = MUL_D(ctx->f18.d, ctx->f0.d);
    // 0x80393568: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x8039356C: nop

    // 0x80393570: sh          $t7, 0x6708($at)
    MEM_H(0X6708, ctx->r1) = ctx->r15;
    // 0x80393574: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80393578: cvt.s.d     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f8.fl = CVT_S_D(ctx->f4.d);
    // 0x8039357C: add.s       $f10, $f16, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f16.fl + ctx->f8.fl;
    // 0x80393580: trunc.w.s   $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80393584: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x80393588: b           L_803935B8
    // 0x8039358C: sh          $t7, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r15;
        goto L_803935B8;
    // 0x8039358C: sh          $t7, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r15;
L_80393590:
    // 0x80393590: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80393594: sh          $zero, 0x6706($at)
    MEM_H(0X6706, ctx->r1) = 0;
    // 0x80393598: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039359C: sh          $t8, 0x670A($at)
    MEM_H(0X670A, ctx->r1) = ctx->r24;
    // 0x803935A0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803935A4: sh          $zero, 0x6708($at)
    MEM_H(0X6708, ctx->r1) = 0;
    // 0x803935A8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803935AC: addiu       $t9, $zero, 0x3C0
    ctx->r25 = ADD32(0, 0X3C0);
    // 0x803935B0: jal         0x8038F968
    // 0x803935B4: sh          $t9, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r25;
    func_8038F968_7A1018(rdram, ctx);
        goto after_2;
    // 0x803935B4: sh          $t9, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r25;
    after_2:
L_803935B8:
    // 0x803935B8: lui         $s7, 0x801E
    ctx->r23 = S32(0X801E << 16);
    // 0x803935BC: addiu       $s7, $s7, -0x6184
    ctx->r23 = ADD32(ctx->r23, -0X6184);
    // 0x803935C0: jal         0x8039CE38
    // 0x803935C4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    func_8039CE38_7AE4E8(rdram, ctx);
        goto after_3;
    // 0x803935C4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    after_3:
    sssv_file_select_layout_hook(rdram, ctx, 0);
    // 0x803935C8: jal         0x8039CAB8
    // 0x803935CC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_8039CAB8_7AE168(rdram, ctx);
        goto after_4;
    // 0x803935CC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_4:
    sssv_file_select_layout_hook(rdram, ctx, 1);
    // 0x803935D0: jal         0x8039D30C
    // 0x803935D4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    render_stars(rdram, ctx);
        goto after_5;
    // 0x803935D4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    after_5:
    sssv_file_select_layout_hook(rdram, ctx, 2);
    // 0x803935D8: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803935DC: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x803935E0: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x803935E4: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x803935E8: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x803935EC: addiu       $t8, $t8, -0x7B60
    ctx->r24 = ADD32(ctx->r24, -0X7B60);
    // 0x803935F0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x803935F4: sw          $t8, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r24;
    // 0x803935F8: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x803935FC: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393600: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80393604: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x80393608: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8039360C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x80393610: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x80393614: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80393618: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8039361C: lui         $s6, 0xE700
    ctx->r22 = S32(0XE700 << 16);
    // 0x80393620: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393624: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393628: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x8039362C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393630: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393634: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393638: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8039363C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x80393640: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393644: jal         0x8012C1F0
    // 0x80393648: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    load_default_display_list(rdram, ctx);
        goto after_6;
    // 0x80393648: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    after_6:
    // 0x8039364C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80393650: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80393654: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80393658: jal         0x8012C248
    // 0x8039365C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_7;
    // 0x8039365C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_7:
    // 0x80393660: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393664: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393668: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039366C: jal         0x8012C214
    // 0x80393670: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_8;
    // 0x80393670: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_8:
    // 0x80393674: jal         0x80130A90
    // 0x80393678: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    get_message_address_by_id(rdram, ctx);
        goto after_9;
    // 0x80393678: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_9:
    // 0x8039367C: lui         $at, 0x41C0
    ctx->r1 = S32(0X41C0 << 16);
    // 0x80393680: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80393684: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393688: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039368C: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x80393690: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80393694: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393698: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039369C: addiu       $a2, $zero, 0x18
    ctx->r6 = ADD32(0, 0X18);
    // 0x803936A0: addiu       $a3, $zero, 0x1F
    ctx->r7 = ADD32(0, 0X1F);
    // 0x803936A4: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x803936A8: jal         0x8012D374
    // 0x803936AC: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    func_8012D374(rdram, ctx);
        goto after_10;
    // 0x803936AC: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_10:
    // 0x803936B0: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x803936B4: lb          $t2, 0x7DD5($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X7DD5);
    // 0x803936B8: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x803936BC: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x803936C0: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x803936C4: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803936C8: beql        $t8, $at, L_80393AFC
    if (ctx->r24 == ctx->r1) {
        // 0x803936CC: lh          $fp, 0x1B6($sp)
        ctx->r30 = MEM_H(ctx->r29, 0X1B6);
            goto L_80393AFC;
    }
    goto skip_0;
    // 0x803936CC: lh          $fp, 0x1B6($sp)
    ctx->r30 = MEM_H(ctx->r29, 0X1B6);
    skip_0:
    // 0x803936D0: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803936D4: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x803936D8: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x803936DC: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x803936E0: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x803936E4: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x803936E8: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x803936EC: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803936F0: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x803936F4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803936F8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x803936FC: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x80393700: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80393704: lw          $t8, 0x64($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X64);
    // 0x80393708: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8039370C: ori         $t7, $t7, 0x31D
    ctx->r15 = ctx->r15 | 0X31D;
    // 0x80393710: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80393714: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393718: lui         $t8, 0x50
    ctx->r24 = S32(0X50 << 16);
    // 0x8039371C: ori         $t8, $t8, 0x4240
    ctx->r24 = ctx->r24 | 0X4240;
    // 0x80393720: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x80393724: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x80393728: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8039372C: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393730: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393734: addiu       $a0, $zero, 0xE0
    ctx->r4 = ADD32(0, 0XE0);
    // 0x80393738: addiu       $a1, $zero, 0x6E
    ctx->r5 = ADD32(0, 0X6E);
    // 0x8039373C: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80393740: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x80393744: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80393748: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8039374C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393750: lui         $t7, 0xFF2F
    ctx->r15 = S32(0XFF2F << 16);
    // 0x80393754: lui         $t6, 0xFC11
    ctx->r14 = S32(0XFC11 << 16);
    // 0x80393758: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8039375C: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x80393760: ori         $t6, $t6, 0x9623
    ctx->r14 = ctx->r14 | 0X9623;
    // 0x80393764: ori         $t7, $t7, 0xFFFF
    ctx->r15 = ctx->r15 | 0XFFFF;
    // 0x80393768: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8039376C: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80393770: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393774: addiu       $t6, $zero, -0xE2
    ctx->r14 = ADD32(0, -0XE2);
    // 0x80393778: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039377C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393780: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393784: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80393788: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8039378C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393790: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393794: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393798: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8039379C: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x803937A0: lb          $t2, 0x7DD5($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X7DD5);
    // 0x803937A4: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x803937A8: sll         $t8, $t2, 16
    ctx->r24 = S32(ctx->r10 << 16);
    // 0x803937AC: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803937B0: beq         $t9, $at, L_803937D8
    if (ctx->r25 == ctx->r1) {
        // 0x803937B4: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803937D8;
    }
    // 0x803937B4: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803937B8: beq         $t9, $at, L_803937D8
    if (ctx->r25 == ctx->r1) {
        // 0x803937BC: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_803937D8;
    }
    // 0x803937BC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x803937C0: beq         $t9, $at, L_803937D8
    if (ctx->r25 == ctx->r1) {
        // 0x803937C4: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_803937D8;
    }
    // 0x803937C4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x803937C8: beq         $t9, $at, L_803937D8
    if (ctx->r25 == ctx->r1) {
        // 0x803937CC: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_803937D8;
    }
    // 0x803937CC: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x803937D0: bne         $t9, $at, L_80393890
    if (ctx->r25 != ctx->r1) {
        // 0x803937D4: or          $s1, $zero, $zero
        ctx->r17 = 0 | 0;
            goto L_80393890;
    }
    // 0x803937D4: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
L_803937D8:
    // 0x803937D8: lh          $v0, 0x2E1E($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2E1E);
    // 0x803937DC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803937E0: addiu       $t6, $zero, 0xC8
    ctx->r14 = ADD32(0, 0XC8);
    // 0x803937E4: beq         $v0, $zero, L_80393808
    if (ctx->r2 == 0) {
        // 0x803937E8: addiu       $t7, $zero, 0xC8
        ctx->r15 = ADD32(0, 0XC8);
            goto L_80393808;
    }
    // 0x803937E8: addiu       $t7, $zero, 0xC8
    ctx->r15 = ADD32(0, 0XC8);
    // 0x803937EC: beq         $v0, $at, L_80393818
    if (ctx->r2 == ctx->r1) {
        // 0x803937F0: addiu       $t8, $zero, 0xB4
        ctx->r24 = ADD32(0, 0XB4);
            goto L_80393818;
    }
    // 0x803937F0: addiu       $t8, $zero, 0xB4
    ctx->r24 = ADD32(0, 0XB4);
    // 0x803937F4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803937F8: beq         $v0, $at, L_80393830
    if (ctx->r2 == ctx->r1) {
        // 0x803937FC: addiu       $t7, $zero, 0xFF
        ctx->r15 = ADD32(0, 0XFF);
            goto L_80393830;
    }
    // 0x803937FC: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x80393800: b           L_80393844
    // 0x80393804: nop

        goto L_80393844;
    // 0x80393804: nop

L_80393808:
    // 0x80393808: sb          $t6, 0xEB($sp)
    MEM_B(0XEB, ctx->r29) = ctx->r14;
    // 0x8039380C: sb          $t7, 0xEA($sp)
    MEM_B(0XEA, ctx->r29) = ctx->r15;
    // 0x80393810: b           L_80393844
    // 0x80393814: sb          $zero, 0xE9($sp)
    MEM_B(0XE9, ctx->r29) = 0;
        goto L_80393844;
    // 0x80393814: sb          $zero, 0xE9($sp)
    MEM_B(0XE9, ctx->r29) = 0;
L_80393818:
    // 0x80393818: addiu       $t9, $zero, 0xB4
    ctx->r25 = ADD32(0, 0XB4);
    // 0x8039381C: addiu       $t6, $zero, 0xB4
    ctx->r14 = ADD32(0, 0XB4);
    // 0x80393820: sb          $t8, 0xEB($sp)
    MEM_B(0XEB, ctx->r29) = ctx->r24;
    // 0x80393824: sb          $t9, 0xEA($sp)
    MEM_B(0XEA, ctx->r29) = ctx->r25;
    // 0x80393828: b           L_80393844
    // 0x8039382C: sb          $t6, 0xE9($sp)
    MEM_B(0XE9, ctx->r29) = ctx->r14;
        goto L_80393844;
    // 0x8039382C: sb          $t6, 0xE9($sp)
    MEM_B(0XE9, ctx->r29) = ctx->r14;
L_80393830:
    // 0x80393830: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x80393834: addiu       $t9, $zero, 0x14
    ctx->r25 = ADD32(0, 0X14);
    // 0x80393838: sb          $t7, 0xEB($sp)
    MEM_B(0XEB, ctx->r29) = ctx->r15;
    // 0x8039383C: sb          $t8, 0xEA($sp)
    MEM_B(0XEA, ctx->r29) = ctx->r24;
    // 0x80393840: sb          $t9, 0xE9($sp)
    MEM_B(0XE9, ctx->r29) = ctx->r25;
L_80393844:
    // 0x80393844: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80393848: lb          $v0, -0xD65($v0)
    ctx->r2 = MEM_B(ctx->r2, -0XD65);
    // 0x8039384C: lbu         $t6, 0xE9($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XE9);
    // 0x80393850: lbu         $a2, 0xEB($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0XEB);
    // 0x80393854: andi        $t7, $v0, 0x2
    ctx->r15 = ctx->r2 & 0X2;
    // 0x80393858: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8039385C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80393860: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80393864: andi        $t6, $v0, 0x8
    ctx->r14 = ctx->r2 & 0X8;
    // 0x80393868: andi        $t8, $v0, 0x1
    ctx->r24 = ctx->r2 & 0X1;
    // 0x8039386C: andi        $t9, $v0, 0x4
    ctx->r25 = ctx->r2 & 0X4;
    // 0x80393870: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80393874: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80393878: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8039387C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80393880: jal         0x803967D4
    // 0x80393884: lbu         $a3, 0xEA($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XEA);
    func_803967D4_7A7E84(rdram, ctx);
        goto after_11;
    // 0x80393884: lbu         $a3, 0xEA($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XEA);
    after_11:
    // 0x80393888: b           L_80393AFC
    // 0x8039388C: lh          $fp, 0x1B6($sp)
    ctx->r30 = MEM_H(ctx->r29, 0X1B6);
        goto L_80393AFC;
    // 0x8039388C: lh          $fp, 0x1B6($sp)
    ctx->r30 = MEM_H(ctx->r29, 0X1B6);
L_80393890:
    // 0x80393890: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393894: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x80393898: ori         $t9, $t9, 0x602
    ctx->r25 = ctx->r25 | 0X602;
    // 0x8039389C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x803938A0: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x803938A4: addiu       $t6, $zero, 0xC0
    ctx->r14 = ADD32(0, 0XC0);
    // 0x803938A8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x803938AC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x803938B0: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803938B4: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x803938B8: ori         $t8, $t8, 0x402
    ctx->r24 = ctx->r24 | 0X402;
    // 0x803938BC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x803938C0: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x803938C4: lui         $s5, 0x800E
    ctx->r21 = S32(0X800E << 16);
    // 0x803938C8: addiu       $s5, $s5, -0x1C70
    ctx->r21 = ADD32(ctx->r21, -0X1C70);
    // 0x803938CC: or          $fp, $zero, $zero
    ctx->r30 = 0 | 0;
    // 0x803938D0: addiu       $s2, $zero, 0x16
    ctx->r18 = ADD32(0, 0X16);
    // 0x803938D4: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x803938D8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x803938DC: sll         $v1, $fp, 2
    ctx->r3 = S32(ctx->r30 << 2);
L_803938E0:
    // 0x803938E0: subu        $v1, $v1, $fp
    ctx->r3 = SUB32(ctx->r3, ctx->r30);
    // 0x803938E4: sll         $v1, $v1, 2
    ctx->r3 = S32(ctx->r3 << 2);
    // 0x803938E8: subu        $v1, $v1, $fp
    ctx->r3 = SUB32(ctx->r3, ctx->r30);
    // 0x803938EC: sll         $v1, $v1, 1
    ctx->r3 = S32(ctx->r3 << 1);
    // 0x803938F0: addiu       $t9, $v1, 0x88
    ctx->r25 = ADD32(ctx->r3, 0X88);
    // 0x803938F4: sll         $t6, $t9, 18
    ctx->r14 = S32(ctx->r25 << 18);
    // 0x803938F8: addiu       $t8, $v1, 0x98
    ctx->r24 = ADD32(ctx->r3, 0X98);
    // 0x803938FC: sll         $t9, $t8, 18
    ctx->r25 = S32(ctx->r24 << 18);
    // 0x80393900: sra         $s4, $t9, 16
    ctx->r20 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393904: sra         $s3, $t6, 16
    ctx->r19 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80393908: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_8039390C:
    // 0x8039390C: multu       $s0, $s2
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80393910: sll         $a2, $s3, 16
    ctx->r6 = S32(ctx->r19 << 16);
    // 0x80393914: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80393918: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x8039391C: addiu       $t6, $zero, 0x20
    ctx->r14 = ADD32(0, 0X20);
    // 0x80393920: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80393924: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393928: sw          $s4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r20;
    // 0x8039392C: sw          $s5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r21;
    // 0x80393930: mflo        $v0
    ctx->r2 = lo;
    // 0x80393934: addiu       $t7, $v0, 0xBC
    ctx->r15 = ADD32(ctx->r2, 0XBC);
    // 0x80393938: sll         $t8, $t7, 18
    ctx->r24 = S32(ctx->r15 << 18);
    // 0x8039393C: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80393940: addiu       $t7, $v0, 0xCC
    ctx->r15 = ADD32(ctx->r2, 0XCC);
    // 0x80393944: sll         $t8, $t7, 18
    ctx->r24 = S32(ctx->r15 << 18);
    // 0x80393948: addiu       $t7, $zero, 0x20
    ctx->r15 = ADD32(0, 0X20);
    // 0x8039394C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80393950: jal         0x803962EC
    // 0x80393954: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    func_803962EC_7A799C(rdram, ctx);
        goto after_12;
    // 0x80393954: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    after_12:
    // 0x80393958: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x8039395C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80393960: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x80393964: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80393968: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8039396C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393970: slti        $at, $s0, 0x5
    ctx->r1 = SIGNED(ctx->r16) < 0X5 ? 1 : 0;
    // 0x80393974: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393978: sll         $t9, $s1, 16
    ctx->r25 = S32(ctx->r17 << 16);
    // 0x8039397C: sra         $s1, $t9, 16
    ctx->r17 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393980: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393984: bne         $at, $zero, L_8039390C
    if (ctx->r1 != 0) {
        // 0x80393988: sw          $s6, 0x0($v1)
        MEM_W(0X0, ctx->r3) = ctx->r22;
            goto L_8039390C;
    }
    // 0x80393988: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x8039398C: addiu       $fp, $fp, 0x1
    ctx->r30 = ADD32(ctx->r30, 0X1);
    // 0x80393990: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x80393994: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393998: slti        $at, $fp, 0x3
    ctx->r1 = SIGNED(ctx->r30) < 0X3 ? 1 : 0;
    // 0x8039399C: bnel        $at, $zero, L_803938E0
    if (ctx->r1 != 0) {
        // 0x803939A0: sll         $v1, $fp, 2
        ctx->r3 = S32(ctx->r30 << 2);
            goto L_803938E0;
    }
    goto skip_1;
    // 0x803939A0: sll         $v1, $fp, 2
    ctx->r3 = S32(ctx->r30 << 2);
    skip_1:
    // 0x803939A4: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803939A8: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x803939AC: lui         $s3, 0x803F
    ctx->r19 = S32(0X803F << 16);
    // 0x803939B0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x803939B4: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x803939B8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x803939BC: lw          $t9, 0x64($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X64);
    // 0x803939C0: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x803939C4: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x803939C8: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x803939CC: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803939D0: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x803939D4: addiu       $s3, $s3, 0x2D30
    ctx->r19 = ADD32(ctx->r19, 0X2D30);
    // 0x803939D8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x803939DC: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x803939E0: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x803939E4: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x803939E8: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x803939EC: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x803939F0: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x803939F4: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x803939F8: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x803939FC: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80393A00: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x80393A04: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80393A08: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393A0C: addiu       $t6, $zero, 0x80
    ctx->r14 = ADD32(0, 0X80);
    // 0x80393A10: lui         $t9, 0xF900
    ctx->r25 = S32(0XF900 << 16);
    // 0x80393A14: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393A18: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393A1C: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80393A20: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80393A24: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393A28: or          $fp, $zero, $zero
    ctx->r30 = 0 | 0;
    // 0x80393A2C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393A30: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393A34: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393A38: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393A3C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_80393A40:
    // 0x80393A40: lh          $t8, 0xC($s3)
    ctx->r24 = MEM_H(ctx->r19, 0XC);
    // 0x80393A44: slt         $at, $s1, $t8
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80393A48: beql        $at, $zero, L_80393AC4
    if (ctx->r1 == 0) {
        // 0x80393A4C: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80393AC4;
    }
    goto skip_2;
    // 0x80393A4C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_2:
    // 0x80393A50: multu       $s0, $s2
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80393A54: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393A58: sw          $s5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r21;
    // 0x80393A5C: mflo        $v0
    ctx->r2 = lo;
    // 0x80393A60: addiu       $t9, $v0, 0xBC
    ctx->r25 = ADD32(ctx->r2, 0XBC);
    // 0x80393A64: sll         $t6, $t9, 18
    ctx->r14 = S32(ctx->r25 << 18);
    // 0x80393A68: multu       $fp, $s2
    result = U64(U32(ctx->r30)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80393A6C: addiu       $t7, $v0, 0xCC
    ctx->r15 = ADD32(ctx->r2, 0XCC);
    // 0x80393A70: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80393A74: mflo        $v1
    ctx->r3 = lo;
    // 0x80393A78: addiu       $t8, $v1, 0x88
    ctx->r24 = ADD32(ctx->r3, 0X88);
    // 0x80393A7C: sll         $t9, $t8, 18
    ctx->r25 = S32(ctx->r24 << 18);
    // 0x80393A80: sll         $t8, $t7, 18
    ctx->r24 = S32(ctx->r15 << 18);
    // 0x80393A84: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80393A88: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393A8C: addiu       $t6, $v1, 0x98
    ctx->r14 = ADD32(ctx->r3, 0X98);
    // 0x80393A90: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80393A94: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x80393A98: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x80393A9C: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80393AA0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80393AA4: jal         0x803962EC
    // 0x80393AA8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    func_803962EC_7A799C(rdram, ctx);
        goto after_13;
    // 0x80393AA8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    after_13:
    // 0x80393AAC: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393AB0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80393AB4: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x80393AB8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393ABC: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393AC0: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80393AC4:
    // 0x80393AC4: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x80393AC8: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393ACC: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x80393AD0: slti        $at, $s0, 0x5
    ctx->r1 = SIGNED(ctx->r16) < 0X5 ? 1 : 0;
    // 0x80393AD4: sll         $t7, $s1, 16
    ctx->r15 = S32(ctx->r17 << 16);
    // 0x80393AD8: bne         $at, $zero, L_80393A40
    if (ctx->r1 != 0) {
        // 0x80393ADC: sra         $s1, $t7, 16
        ctx->r17 = S32(SIGNED(ctx->r15) >> 16);
            goto L_80393A40;
    }
    // 0x80393ADC: sra         $s1, $t7, 16
    ctx->r17 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80393AE0: addiu       $fp, $fp, 0x1
    ctx->r30 = ADD32(ctx->r30, 0X1);
    // 0x80393AE4: sll         $t7, $fp, 16
    ctx->r15 = S32(ctx->r30 << 16);
    // 0x80393AE8: sra         $fp, $t7, 16
    ctx->r30 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80393AEC: slti        $at, $fp, 0x3
    ctx->r1 = SIGNED(ctx->r30) < 0X3 ? 1 : 0;
    // 0x80393AF0: bnel        $at, $zero, L_80393A40
    if (ctx->r1 != 0) {
        // 0x80393AF4: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_80393A40;
    }
    goto skip_3;
    // 0x80393AF4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    skip_3:
    // 0x80393AF8: lh          $fp, 0x1B6($sp)
    ctx->r30 = MEM_H(ctx->r29, 0X1B6);
L_80393AFC:
    // 0x80393AFC: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80393B00: lh          $t7, 0x4260($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4260);
    // 0x80393B04: addiu       $fp, $fp, 0x3A
    ctx->r30 = ADD32(ctx->r30, 0X3A);
    // 0x80393B08: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x80393B0C: lui         $s3, 0x803F
    ctx->r19 = S32(0X803F << 16);
    // 0x80393B10: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80393B14: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80393B18: addiu       $s3, $s3, 0x2D30
    ctx->r19 = ADD32(ctx->r19, 0X2D30);
    // 0x80393B1C: bne         $t7, $at, L_80393B30
    if (ctx->r15 != ctx->r1) {
        // 0x80393B20: or          $fp, $t6, $zero
        ctx->r30 = ctx->r14 | 0;
            goto L_80393B30;
    }
    // 0x80393B20: or          $fp, $t6, $zero
    ctx->r30 = ctx->r14 | 0;
    // 0x80393B24: addiu       $fp, $t6, 0x8
    ctx->r30 = ADD32(ctx->r14, 0X8);
    // 0x80393B28: sll         $t8, $fp, 16
    ctx->r24 = S32(ctx->r30 << 16);
    // 0x80393B2C: sra         $fp, $t8, 16
    ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
L_80393B30:
    // 0x80393B30: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80393B34: addiu       $v1, $v1, 0x6680
    ctx->r3 = ADD32(ctx->r3, 0X6680);
    // 0x80393B38: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
    // 0x80393B3C: addiu       $t6, $zero, 0x7
    ctx->r14 = ADD32(0, 0X7);
    // 0x80393B40: bgezl       $v0, L_80393B54
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80393B44: slti        $at, $v0, 0x8
        ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
            goto L_80393B54;
    }
    goto skip_4;
    // 0x80393B44: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    skip_4:
    // 0x80393B48: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
    // 0x80393B4C: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
    // 0x80393B50: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
L_80393B54:
    // 0x80393B54: bnel        $at, $zero, L_80393B64
    if (ctx->r1 != 0) {
        // 0x80393B58: lw          $v1, 0x0($s7)
        ctx->r3 = MEM_W(ctx->r23, 0X0);
            goto L_80393B64;
    }
    goto skip_5;
    // 0x80393B58: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    skip_5:
    // 0x80393B5C: sh          $zero, 0x14($v1)
    MEM_H(0X14, ctx->r3) = 0;
    // 0x80393B60: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
L_80393B64:
    // 0x80393B64: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x80393B68: addiu       $at, $zero, -0x100
    ctx->r1 = ADD32(0, -0X100);
    // 0x80393B6C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393B70: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393B74: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393B78: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393B7C: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393B80: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80393B84: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80393B88: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393B8C: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393B90: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80393B94: lw          $t6, 0x64($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X64);
    // 0x80393B98: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x80393B9C: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x80393BA0: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80393BA4: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393BA8: ori         $t9, $t9, 0x201
    ctx->r25 = ctx->r25 | 0X201;
    // 0x80393BAC: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80393BB0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393BB4: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393BB8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80393BBC: lbu         $t6, 0xF3($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XF3);
    // 0x80393BC0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393BC4: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x80393BC8: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x80393BCC: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393BD0: addiu       $t6, $zero, 0x4
    ctx->r14 = ADD32(0, 0X4);
    // 0x80393BD4: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393BD8: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393BDC: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80393BE0: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80393BE4: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393BE8: lui         $t9, 0x50
    ctx->r25 = S32(0X50 << 16);
    // 0x80393BEC: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x80393BF0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393BF4: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393BF8: ori         $t8, $t8, 0x31D
    ctx->r24 = ctx->r24 | 0X31D;
    // 0x80393BFC: ori         $t9, $t9, 0x41C8
    ctx->r25 = ctx->r25 | 0X41C8;
    // 0x80393C00: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x80393C04: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80393C08: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393C0C: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x80393C10: ori         $t7, $t7, 0x2
    ctx->r15 = ctx->r15 | 0X2;
    // 0x80393C14: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80393C18: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x80393C1C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393C20: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80393C24: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393C28: lui         $t9, 0xFC30
    ctx->r25 = S32(0XFC30 << 16);
    // 0x80393C2C: ori         $t9, $t9, 0xFE61
    ctx->r25 = ctx->r25 | 0XFE61;
    // 0x80393C30: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80393C34: sw          $t8, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r24;
    // 0x80393C38: addiu       $t6, $zero, -0x805
    ctx->r14 = ADD32(0, -0X805);
    // 0x80393C3C: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
    // 0x80393C40: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80393C44: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393C48: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80393C4C: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x80393C50: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393C54: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393C58: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393C5C: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80393C60: lh          $t8, 0x670C($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X670C);
    // 0x80393C64: lh          $t6, 0x53EA($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X53EA);
    // 0x80393C68: lui         $t9, 0x800C
    ctx->r25 = S32(0X800C << 16);
    // 0x80393C6C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80393C70: addiu       $t8, $zero, 0xF0
    ctx->r24 = ADD32(0, 0XF0);
    // 0x80393C74: addiu       $t9, $t9, 0x5A40
    ctx->r25 = ADD32(ctx->r25, 0X5A40);
    // 0x80393C78: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80393C7C: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80393C80: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80393C84: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80393C88: lh          $a3, 0x670A($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X670A);
    // 0x80393C8C: lh          $a2, 0x6708($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X6708);
    // 0x80393C90: jal         0x803962EC
    // 0x80393C94: lh          $a1, 0x6706($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6706);
    func_803962EC_7A799C(rdram, ctx);
        goto after_14;
    // 0x80393C94: lh          $a1, 0x6706($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6706);
    after_14:
    // 0x80393C98: lui         $s4, 0x803F
    ctx->r20 = S32(0X803F << 16);
    // 0x80393C9C: addiu       $s4, $s4, 0x6680
    ctx->r20 = ADD32(ctx->r20, 0X6680);
    // 0x80393CA0: lh          $t9, 0x22($s4)
    ctx->r25 = MEM_H(ctx->r20, 0X22);
    // 0x80393CA4: bnel        $t9, $zero, L_80395048
    if (ctx->r25 != 0) {
        // 0x80393CA8: lw          $ra, 0x54($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X54);
            goto L_80395048;
    }
    goto skip_6;
    // 0x80393CA8: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    skip_6:
    // 0x80393CAC: lh          $t6, 0x24($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X24);
    // 0x80393CB0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80393CB4: bnel        $t6, $zero, L_80395048
    if (ctx->r14 != 0) {
        // 0x80393CB8: lw          $ra, 0x54($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X54);
            goto L_80395048;
    }
    goto skip_7;
    // 0x80393CB8: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    skip_7:
    // 0x80393CBC: lb          $t7, 0x7DD5($t7)
    ctx->r15 = MEM_B(ctx->r15, 0X7DD5);
    // 0x80393CC0: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80393CC4: beq         $t7, $at, L_80393D04
    if (ctx->r15 == ctx->r1) {
        // 0x80393CC8: addiu       $t8, $zero, 0xE0
        ctx->r24 = ADD32(0, 0XE0);
            goto L_80393D04;
    }
    // 0x80393CC8: addiu       $t8, $zero, 0xE0
    ctx->r24 = ADD32(0, 0XE0);
    // 0x80393CCC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80393CD0: addiu       $t8, $zero, 0x2D
    ctx->r24 = ADD32(0, 0X2D);
    // 0x80393CD4: addiu       $t9, $zero, 0x50
    ctx->r25 = ADD32(0, 0X50);
    // 0x80393CD8: addiu       $t6, $zero, 0x50
    ctx->r14 = ADD32(0, 0X50);
    // 0x80393CDC: addiu       $t7, $zero, 0x50
    ctx->r15 = ADD32(0, 0X50);
    // 0x80393CE0: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80393CE4: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80393CE8: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80393CEC: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80393CF0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393CF4: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x80393CF8: addiu       $a2, $zero, 0xCC
    ctx->r6 = ADD32(0, 0XCC);
    // 0x80393CFC: jal         0x8012AD30
    // 0x80393D00: addiu       $a3, $zero, 0x12C
    ctx->r7 = ADD32(0, 0X12C);
    draw_rectangle(rdram, ctx);
        goto after_15;
    // 0x80393D00: addiu       $a3, $zero, 0x12C
    ctx->r7 = ADD32(0, 0X12C);
    after_15:
L_80393D04:
    // 0x80393D04: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393D08: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393D0C: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x80393D10: sw          $t9, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r25;
    // 0x80393D14: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393D18: jal         0x8012C1F0
    // 0x80393D1C: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    load_default_display_list(rdram, ctx);
        goto after_16;
    // 0x80393D1C: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    after_16:
    // 0x80393D20: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80393D24: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80393D28: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80393D2C: jal         0x8012C248
    // 0x80393D30: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_17;
    // 0x80393D30: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_17:
    // 0x80393D34: addiu       $a0, $zero, 0xA0
    ctx->r4 = ADD32(0, 0XA0);
    // 0x80393D38: addiu       $a1, $zero, 0xA0
    ctx->r5 = ADD32(0, 0XA0);
    // 0x80393D3C: addiu       $a2, $zero, 0xA0
    ctx->r6 = ADD32(0, 0XA0);
    // 0x80393D40: jal         0x8012C214
    // 0x80393D44: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_18;
    // 0x80393D44: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_18:
    // 0x80393D48: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80393D4C: lb          $t6, 0x7DD5($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X7DD5);
    // 0x80393D50: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80393D54: beq         $t6, $at, L_80393D80
    if (ctx->r14 == ctx->r1) {
        // 0x80393D58: lui         $at, 0x4180
        ctx->r1 = S32(0X4180 << 16);
            goto L_80393D80;
    }
    // 0x80393D58: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393D5C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80393D60: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80393D64: addiu       $a1, $a1, 0x2E34
    ctx->r5 = ADD32(ctx->r5, 0X2E34);
    // 0x80393D68: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393D6C: addiu       $a2, $zero, 0xA0
    ctx->r6 = ADD32(0, 0XA0);
    // 0x80393D70: addiu       $a3, $zero, 0xD0
    ctx->r7 = ADD32(0, 0XD0);
    // 0x80393D74: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80393D78: jal         0x8012C978
    // 0x80393D7C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text_centered(rdram, ctx);
        goto after_19;
    // 0x80393D7C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_19:
L_80393D80:
    // 0x80393D80: lw          $v1, 0x0($s7)
    ctx->r3 = MEM_W(ctx->r23, 0X0);
    // 0x80393D84: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393D88: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80393D8C: sw          $t7, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r15;
    // 0x80393D90: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80393D94: jal         0x8012C1F0
    // 0x80393D98: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    load_default_display_list(rdram, ctx);
        goto after_20;
    // 0x80393D98: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    after_20:
    // 0x80393D9C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80393DA0: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80393DA4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80393DA8: jal         0x8012C248
    // 0x80393DAC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_21;
    // 0x80393DAC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_21:
    // 0x80393DB0: lh          $t8, 0x14($s4)
    ctx->r24 = MEM_H(ctx->r20, 0X14);
    // 0x80393DB4: bne         $t8, $zero, L_80393DD4
    if (ctx->r24 != 0) {
        // 0x80393DB8: addiu       $a0, $zero, 0xFF
        ctx->r4 = ADD32(0, 0XFF);
            goto L_80393DD4;
    }
    // 0x80393DB8: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393DBC: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393DC0: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80393DC4: jal         0x8012C214
    // 0x80393DC8: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_22;
    // 0x80393DC8: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_22:
    // 0x80393DCC: b           L_80393DE8
    // 0x80393DD0: nop

        goto L_80393DE8;
    // 0x80393DD0: nop

L_80393DD4:
    // 0x80393DD4: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80393DD8: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80393DDC: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80393DE0: jal         0x8012C214
    // 0x80393DE4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_23;
    // 0x80393DE4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_23:
L_80393DE8:
    // 0x80393DE8: jal         0x80130A90
    // 0x80393DEC: addiu       $a0, $zero, 0x15
    ctx->r4 = ADD32(0, 0X15);
    get_message_address_by_id(rdram, ctx);
        goto after_24;
    // 0x80393DEC: addiu       $a0, $zero, 0x15
    ctx->r4 = ADD32(0, 0X15);
    after_24:
    // 0x80393DF0: lh          $t9, 0xE6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XE6);
    // 0x80393DF4: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393DF8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80393DFC: mtc1        $t9, $f16
    ctx->f16.u32l = ctx->r25;
    // 0x80393E00: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393E04: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80393E08: cvt.s.w     $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    ctx->f0.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80393E0C: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80393E10: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80393E14: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    // 0x80393E18: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80393E1C: jal         0x8012C978
    // 0x80393E20: swc1        $f0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f0.u32l;
    display_text_centered(rdram, ctx);
        goto after_25;
    // 0x80393E20: swc1        $f0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f0.u32l;
    after_25:
    // 0x80393E24: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80393E28: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x80393E2C: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80393E30: sll         $t6, $fp, 16
    ctx->r14 = S32(ctx->r30 << 16);
    // 0x80393E34: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80393E38: beq         $v0, $at, L_80393EC4
    if (ctx->r2 == ctx->r1) {
        // 0x80393E3C: sra         $fp, $t6, 16
        ctx->r30 = S32(SIGNED(ctx->r14) >> 16);
            goto L_80393EC4;
    }
    // 0x80393E3C: sra         $fp, $t6, 16
    ctx->r30 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80393E40: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80393E44: beql        $v0, $at, L_80393EC8
    if (ctx->r2 == ctx->r1) {
        // 0x80393E48: lh          $t7, 0x14($s4)
        ctx->r15 = MEM_H(ctx->r20, 0X14);
            goto L_80393EC8;
    }
    goto skip_8;
    // 0x80393E48: lh          $t7, 0x14($s4)
    ctx->r15 = MEM_H(ctx->r20, 0X14);
    skip_8:
    // 0x80393E4C: lh          $t8, 0x14($s4)
    ctx->r24 = MEM_H(ctx->r20, 0X14);
    // 0x80393E50: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80393E54: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80393E58: bne         $t8, $at, L_80393E7C
    if (ctx->r24 != ctx->r1) {
        // 0x80393E5C: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_80393E7C;
    }
    // 0x80393E5C: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80393E60: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393E64: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393E68: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80393E6C: jal         0x8012C214
    // 0x80393E70: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_26;
    // 0x80393E70: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_26:
    // 0x80393E74: b           L_80393E88
    // 0x80393E78: nop

        goto L_80393E88;
    // 0x80393E78: nop

L_80393E7C:
    // 0x80393E7C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80393E80: jal         0x8012C214
    // 0x80393E84: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_27;
    // 0x80393E84: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_27:
L_80393E88:
    // 0x80393E88: jal         0x80130A90
    // 0x80393E8C: addiu       $a0, $zero, 0x16
    ctx->r4 = ADD32(0, 0X16);
    get_message_address_by_id(rdram, ctx);
        goto after_28;
    // 0x80393E8C: addiu       $a0, $zero, 0x16
    ctx->r4 = ADD32(0, 0X16);
    after_28:
    // 0x80393E90: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393E94: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80393E98: lwc1        $f10, 0x60($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80393E9C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393EA0: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80393EA4: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80393EA8: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80393EAC: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80393EB0: jal         0x8012C978
    // 0x80393EB4: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text_centered(rdram, ctx);
        goto after_29;
    // 0x80393EB4: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_29:
    // 0x80393EB8: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80393EBC: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x80393EC0: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
L_80393EC4:
    // 0x80393EC4: lh          $t7, 0x14($s4)
    ctx->r15 = MEM_H(ctx->r20, 0X14);
L_80393EC8:
    // 0x80393EC8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80393ECC: bnel        $t7, $at, L_80394024
    if (ctx->r15 != ctx->r1) {
        // 0x80393ED0: addiu       $a0, $zero, 0x80
        ctx->r4 = ADD32(0, 0X80);
            goto L_80394024;
    }
    goto skip_9;
    // 0x80393ED0: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    skip_9:
    // 0x80393ED4: lbu         $t8, 0x35($s4)
    ctx->r24 = MEM_BU(ctx->r20, 0X35);
    // 0x80393ED8: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393EDC: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393EE0: bne         $t8, $zero, L_80393F30
    if (ctx->r24 != 0) {
        // 0x80393EE4: addiu       $a2, $zero, 0xFF
        ctx->r6 = ADD32(0, 0XFF);
            goto L_80393F30;
    }
    // 0x80393EE4: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80393EE8: jal         0x8012C214
    // 0x80393EEC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_30;
    // 0x80393EEC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_30:
    // 0x80393EF0: jal         0x80130A90
    // 0x80393EF4: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    get_message_address_by_id(rdram, ctx);
        goto after_31;
    // 0x80393EF4: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    after_31:
    // 0x80393EF8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393EFC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80393F00: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80393F04: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393F08: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80393F0C: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80393F10: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80393F14: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80393F18: jal         0x8012C978
    // 0x80393F1C: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text_centered(rdram, ctx);
        goto after_32;
    // 0x80393F1C: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_32:
    // 0x80393F20: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80393F24: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x80393F28: b           L_80394070
    // 0x80393F2C: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
        goto L_80394070;
    // 0x80393F2C: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
L_80393F30:
    // 0x80393F30: lbu         $t7, 0x36($s4)
    ctx->r15 = MEM_BU(ctx->r20, 0X36);
    // 0x80393F34: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80393F38: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80393F3C: bne         $t7, $zero, L_80393F60
    if (ctx->r15 != 0) {
        // 0x80393F40: addiu       $a2, $zero, 0x80
        ctx->r6 = ADD32(0, 0X80);
            goto L_80393F60;
    }
    // 0x80393F40: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80393F44: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393F48: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393F4C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80393F50: jal         0x8012C214
    // 0x80393F54: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_33;
    // 0x80393F54: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_33:
    // 0x80393F58: b           L_80393F68
    // 0x80393F5C: nop

        goto L_80393F68;
    // 0x80393F5C: nop

L_80393F60:
    // 0x80393F60: jal         0x8012C214
    // 0x80393F64: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_34;
    // 0x80393F64: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_34:
L_80393F68:
    // 0x80393F68: jal         0x80130A90
    // 0x80393F6C: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    get_message_address_by_id(rdram, ctx);
        goto after_35;
    // 0x80393F6C: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    after_35:
    // 0x80393F70: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393F74: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80393F78: lwc1        $f16, 0x60($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80393F7C: andi        $s0, $fp, 0xFFFF
    ctx->r16 = ctx->r30 & 0XFFFF;
    // 0x80393F80: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80393F84: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393F88: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80393F8C: addiu       $a2, $zero, 0x5B
    ctx->r6 = ADD32(0, 0X5B);
    // 0x80393F90: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x80393F94: jal         0x8012DEF8
    // 0x80393F98: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text(rdram, ctx);
        goto after_36;
    // 0x80393F98: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_36:
    // 0x80393F9C: lbu         $t8, 0x36($s4)
    ctx->r24 = MEM_BU(ctx->r20, 0X36);
    // 0x80393FA0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80393FA4: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80393FA8: bne         $t8, $at, L_80393FCC
    if (ctx->r24 != ctx->r1) {
        // 0x80393FAC: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_80393FCC;
    }
    // 0x80393FAC: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80393FB0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80393FB4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80393FB8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80393FBC: jal         0x8012C214
    // 0x80393FC0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_37;
    // 0x80393FC0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_37:
    // 0x80393FC4: b           L_80393FD8
    // 0x80393FC8: nop

        goto L_80393FD8;
    // 0x80393FC8: nop

L_80393FCC:
    // 0x80393FCC: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80393FD0: jal         0x8012C214
    // 0x80393FD4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_38;
    // 0x80393FD4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_38:
L_80393FD8:
    // 0x80393FD8: jal         0x80130A90
    // 0x80393FDC: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    get_message_address_by_id(rdram, ctx);
        goto after_39;
    // 0x80393FDC: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    after_39:
    // 0x80393FE0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80393FE4: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80393FE8: lwc1        $f10, 0x60($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80393FEC: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x80393FF0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80393FF4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80393FF8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80393FFC: addiu       $a2, $zero, 0x61
    ctx->r6 = ADD32(0, 0X61);
    // 0x80394000: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80394004: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80394008: jal         0x8012D374
    // 0x8039400C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_40;
    // 0x8039400C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_40:
    // 0x80394010: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80394014: sll         $t6, $fp, 16
    ctx->r14 = S32(ctx->r30 << 16);
    // 0x80394018: b           L_80394070
    // 0x8039401C: sra         $fp, $t6, 16
    ctx->r30 = S32(SIGNED(ctx->r14) >> 16);
        goto L_80394070;
    // 0x8039401C: sra         $fp, $t6, 16
    ctx->r30 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80394020: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
L_80394024:
    // 0x80394024: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80394028: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039402C: jal         0x8012C214
    // 0x80394030: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_41;
    // 0x80394030: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_41:
    // 0x80394034: jal         0x80130A90
    // 0x80394038: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    get_message_address_by_id(rdram, ctx);
        goto after_42;
    // 0x80394038: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    after_42:
    // 0x8039403C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394040: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80394044: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80394048: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x8039404C: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80394050: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80394054: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80394058: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039405C: jal         0x8012C978
    // 0x80394060: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text_centered(rdram, ctx);
        goto after_43;
    // 0x80394060: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_43:
    // 0x80394064: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80394068: sll         $t8, $fp, 16
    ctx->r24 = S32(ctx->r30 << 16);
    // 0x8039406C: sra         $fp, $t8, 16
    ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
L_80394070:
    // 0x80394070: lh          $t6, 0x14($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X14);
    // 0x80394074: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80394078: bnel        $t6, $at, L_803941D0
    if (ctx->r14 != ctx->r1) {
        // 0x8039407C: addiu       $a0, $zero, 0x80
        ctx->r4 = ADD32(0, 0X80);
            goto L_803941D0;
    }
    goto skip_10;
    // 0x8039407C: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    skip_10:
    // 0x80394080: lbu         $t7, 0x31($s4)
    ctx->r15 = MEM_BU(ctx->r20, 0X31);
    // 0x80394084: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80394088: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039408C: bne         $t7, $zero, L_803940DC
    if (ctx->r15 != 0) {
        // 0x80394090: addiu       $a2, $zero, 0xFF
        ctx->r6 = ADD32(0, 0XFF);
            goto L_803940DC;
    }
    // 0x80394090: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80394094: jal         0x8012C214
    // 0x80394098: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_44;
    // 0x80394098: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_44:
    // 0x8039409C: jal         0x80130A90
    // 0x803940A0: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    get_message_address_by_id(rdram, ctx);
        goto after_45;
    // 0x803940A0: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    after_45:
    // 0x803940A4: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x803940A8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x803940AC: lwc1        $f16, 0x60($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X60);
    // 0x803940B0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803940B4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x803940B8: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x803940BC: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x803940C0: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x803940C4: jal         0x8012C978
    // 0x803940C8: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text_centered(rdram, ctx);
        goto after_46;
    // 0x803940C8: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_46:
    // 0x803940CC: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x803940D0: sll         $t8, $fp, 16
    ctx->r24 = S32(ctx->r30 << 16);
    // 0x803940D4: b           L_8039421C
    // 0x803940D8: sra         $fp, $t8, 16
    ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
        goto L_8039421C;
    // 0x803940D8: sra         $fp, $t8, 16
    ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
L_803940DC:
    // 0x803940DC: lbu         $t6, 0x32($s4)
    ctx->r14 = MEM_BU(ctx->r20, 0X32);
    // 0x803940E0: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x803940E4: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x803940E8: bne         $t6, $zero, L_8039410C
    if (ctx->r14 != 0) {
        // 0x803940EC: addiu       $a2, $zero, 0x80
        ctx->r6 = ADD32(0, 0X80);
            goto L_8039410C;
    }
    // 0x803940EC: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x803940F0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x803940F4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x803940F8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x803940FC: jal         0x8012C214
    // 0x80394100: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_47;
    // 0x80394100: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_47:
    // 0x80394104: b           L_80394114
    // 0x80394108: nop

        goto L_80394114;
    // 0x80394108: nop

L_8039410C:
    // 0x8039410C: jal         0x8012C214
    // 0x80394110: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_48;
    // 0x80394110: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_48:
L_80394114:
    // 0x80394114: jal         0x80130A90
    // 0x80394118: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    get_message_address_by_id(rdram, ctx);
        goto after_49;
    // 0x80394118: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    after_49:
    // 0x8039411C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394120: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80394124: lwc1        $f10, 0x60($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80394128: andi        $s0, $fp, 0xFFFF
    ctx->r16 = ctx->r30 & 0XFFFF;
    // 0x8039412C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80394130: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80394134: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80394138: addiu       $a2, $zero, 0x5B
    ctx->r6 = ADD32(0, 0X5B);
    // 0x8039413C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80394140: jal         0x8012DEF8
    // 0x80394144: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text(rdram, ctx);
        goto after_50;
    // 0x80394144: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_50:
    // 0x80394148: lbu         $t7, 0x32($s4)
    ctx->r15 = MEM_BU(ctx->r20, 0X32);
    // 0x8039414C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80394150: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80394154: bne         $t7, $at, L_80394178
    if (ctx->r15 != ctx->r1) {
        // 0x80394158: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_80394178;
    }
    // 0x80394158: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039415C: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80394160: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80394164: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80394168: jal         0x8012C214
    // 0x8039416C: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_51;
    // 0x8039416C: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_51:
    // 0x80394170: b           L_80394184
    // 0x80394174: nop

        goto L_80394184;
    // 0x80394174: nop

L_80394178:
    // 0x80394178: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039417C: jal         0x8012C214
    // 0x80394180: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_52;
    // 0x80394180: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_52:
L_80394184:
    // 0x80394184: jal         0x80130A90
    // 0x80394188: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    get_message_address_by_id(rdram, ctx);
        goto after_53;
    // 0x80394188: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    after_53:
    // 0x8039418C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394190: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80394194: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x80394198: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8039419C: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x803941A0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803941A4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x803941A8: addiu       $a2, $zero, 0x61
    ctx->r6 = ADD32(0, 0X61);
    // 0x803941AC: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x803941B0: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x803941B4: jal         0x8012D374
    // 0x803941B8: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    func_8012D374(rdram, ctx);
        goto after_54;
    // 0x803941B8: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_54:
    // 0x803941BC: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x803941C0: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x803941C4: b           L_8039421C
    // 0x803941C8: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
        goto L_8039421C;
    // 0x803941C8: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803941CC: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
L_803941D0:
    // 0x803941D0: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x803941D4: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x803941D8: jal         0x8012C214
    // 0x803941DC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_55;
    // 0x803941DC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_55:
    // 0x803941E0: jal         0x80130A90
    // 0x803941E4: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    get_message_address_by_id(rdram, ctx);
        goto after_56;
    // 0x803941E4: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    after_56:
    // 0x803941E8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x803941EC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x803941F0: lwc1        $f16, 0x60($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X60);
    // 0x803941F4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803941F8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x803941FC: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80394200: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80394204: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x80394208: jal         0x8012C978
    // 0x8039420C: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text_centered(rdram, ctx);
        goto after_57;
    // 0x8039420C: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_57:
    // 0x80394210: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x80394214: sll         $t7, $fp, 16
    ctx->r15 = S32(ctx->r30 << 16);
    // 0x80394218: sra         $fp, $t7, 16
    ctx->r30 = S32(SIGNED(ctx->r15) >> 16);
L_8039421C:
    // 0x8039421C: lh          $t9, 0x14($s4)
    ctx->r25 = MEM_H(ctx->r20, 0X14);
    // 0x80394220: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80394224: bne         $t9, $at, L_80394244
    if (ctx->r25 != ctx->r1) {
        // 0x80394228: addiu       $a0, $zero, 0xFF
        ctx->r4 = ADD32(0, 0XFF);
            goto L_80394244;
    }
    // 0x80394228: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039422C: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80394230: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80394234: jal         0x8012C214
    // 0x80394238: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_58;
    // 0x80394238: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_58:
    // 0x8039423C: b           L_8039425C
    // 0x80394240: addiu       $s0, $sp, 0x174
    ctx->r16 = ADD32(ctx->r29, 0X174);
        goto L_8039425C;
    // 0x80394240: addiu       $s0, $sp, 0x174
    ctx->r16 = ADD32(ctx->r29, 0X174);
L_80394244:
    // 0x80394244: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80394248: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039424C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80394250: jal         0x8012C214
    // 0x80394254: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_59;
    // 0x80394254: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_59:
    // 0x80394258: addiu       $s0, $sp, 0x174
    ctx->r16 = ADD32(ctx->r29, 0X174);
L_8039425C:
    // 0x8039425C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80394260: addiu       $a1, $a1, 0x198
    ctx->r5 = ADD32(ctx->r5, 0X198);
    // 0x80394264: jal         0x801395F4
    // 0x80394268: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    sprintf_recomp(rdram, ctx);
        goto after_60;
    // 0x80394268: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_60:
    // 0x8039426C: lui         $s2, 0x8024
    ctx->r18 = S32(0X8024 << 16);
    // 0x80394270: addiu       $s2, $s2, -0xD60
    ctx->r18 = ADD32(ctx->r18, -0XD60);
    // 0x80394274: lb          $t6, 0xC($s2)
    ctx->r14 = MEM_B(ctx->r18, 0XC);
    // 0x80394278: addiu       $s1, $sp, 0xFC
    ctx->r17 = ADD32(ctx->r29, 0XFC);
    // 0x8039427C: addiu       $s5, $zero, 0x3E
    ctx->r21 = ADD32(0, 0X3E);
    // 0x80394280: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x80394284: sb          $s5, 0x2($t7)
    MEM_B(0X2, ctx->r15) = ctx->r21;
    // 0x80394288: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8039428C: jal         0x801308B4
    // 0x80394290: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    prepare_text(rdram, ctx);
        goto after_61;
    // 0x80394290: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_61:
    // 0x80394294: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394298: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039429C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803942A0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803942A4: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x803942A8: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x803942AC: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x803942B0: jal         0x8012C978
    // 0x803942B4: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text_centered(rdram, ctx);
        goto after_62;
    // 0x803942B4: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_62:
    // 0x803942B8: lh          $t6, 0x14($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X14);
    // 0x803942BC: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x803942C0: sll         $t8, $fp, 16
    ctx->r24 = S32(ctx->r30 << 16);
    // 0x803942C4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803942C8: bne         $t6, $at, L_803942EC
    if (ctx->r14 != ctx->r1) {
        // 0x803942CC: sra         $fp, $t8, 16
        ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
            goto L_803942EC;
    }
    // 0x803942CC: sra         $fp, $t8, 16
    ctx->r30 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803942D0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x803942D4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x803942D8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x803942DC: jal         0x8012C214
    // 0x803942E0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_63;
    // 0x803942E0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_63:
    // 0x803942E4: b           L_80394300
    // 0x803942E8: nop

        goto L_80394300;
    // 0x803942E8: nop

L_803942EC:
    // 0x803942EC: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x803942F0: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x803942F4: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x803942F8: jal         0x8012C214
    // 0x803942FC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_64;
    // 0x803942FC: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_64:
L_80394300:
    // 0x80394300: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80394304: addiu       $a1, $a1, 0x1B0
    ctx->r5 = ADD32(ctx->r5, 0X1B0);
    // 0x80394308: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039430C: jal         0x801395F4
    // 0x80394310: addiu       $a2, $zero, 0x5C
    ctx->r6 = ADD32(0, 0X5C);
    sprintf_recomp(rdram, ctx);
        goto after_65;
    // 0x80394310: addiu       $a2, $zero, 0x5C
    ctx->r6 = ADD32(0, 0X5C);
    after_65:
    // 0x80394314: lb          $t7, 0xD($s2)
    ctx->r15 = MEM_B(ctx->r18, 0XD);
    // 0x80394318: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039431C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80394320: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x80394324: jal         0x801308B4
    // 0x80394328: sb          $s5, 0x2($t8)
    MEM_B(0X2, ctx->r24) = ctx->r21;
    prepare_text(rdram, ctx);
        goto after_66;
    // 0x80394328: sb          $s5, 0x2($t8)
    MEM_B(0X2, ctx->r24) = ctx->r21;
    after_66:
    // 0x8039432C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394330: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80394334: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80394338: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8039433C: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80394340: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x80394344: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80394348: jal         0x8012C978
    // 0x8039434C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    display_text_centered(rdram, ctx);
        goto after_67;
    // 0x8039434C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_67:
    // 0x80394350: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80394354: lh          $t7, 0x4260($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4260);
    // 0x80394358: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x8039435C: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x80394360: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80394364: beq         $t7, $at, L_803943F8
    if (ctx->r15 == ctx->r1) {
        // 0x80394368: sra         $fp, $t9, 16
        ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
            goto L_803943F8;
    }
    // 0x80394368: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039436C: lh          $t8, 0x14($s4)
    ctx->r24 = MEM_H(ctx->r20, 0X14);
    // 0x80394370: addiu       $s6, $zero, 0x6
    ctx->r22 = ADD32(0, 0X6);
    // 0x80394374: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80394378: bne         $s6, $t8, L_8039439C
    if (ctx->r22 != ctx->r24) {
        // 0x8039437C: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_8039439C;
    }
    // 0x8039437C: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x80394380: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80394384: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80394388: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039438C: jal         0x8012C214
    // 0x80394390: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_68;
    // 0x80394390: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_68:
    // 0x80394394: b           L_803943A8
    // 0x80394398: nop

        goto L_803943A8;
    // 0x80394398: nop

L_8039439C:
    // 0x8039439C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x803943A0: jal         0x8012C214
    // 0x803943A4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_69;
    // 0x803943A4: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_69:
L_803943A8:
    // 0x803943A8: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803943AC: addiu       $a1, $a1, 0x1C8
    ctx->r5 = ADD32(ctx->r5, 0X1C8);
    // 0x803943B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803943B4: jal         0x801395F4
    // 0x803943B8: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
    sprintf_recomp(rdram, ctx);
        goto after_70;
    // 0x803943B8: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
    after_70:
    // 0x803943BC: jal         0x80130A90
    // 0x803943C0: addiu       $a0, $zero, 0x1C
    ctx->r4 = ADD32(0, 0X1C);
    get_message_address_by_id(rdram, ctx);
        goto after_71;
    // 0x803943C0: addiu       $a0, $zero, 0x1C
    ctx->r4 = ADD32(0, 0X1C);
    after_71:
    // 0x803943C4: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x803943C8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803943CC: lwc1        $f10, 0x60($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X60);
    // 0x803943D0: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803943D4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x803943D8: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x803943DC: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x803943E0: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x803943E4: jal         0x8012C978
    // 0x803943E8: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text_centered(rdram, ctx);
        goto after_72;
    // 0x803943E8: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_72:
    // 0x803943EC: addiu       $fp, $fp, 0x12
    ctx->r30 = ADD32(ctx->r30, 0X12);
    // 0x803943F0: sll         $t9, $fp, 16
    ctx->r25 = S32(ctx->r30 << 16);
    // 0x803943F4: sra         $fp, $t9, 16
    ctx->r30 = S32(SIGNED(ctx->r25) >> 16);
L_803943F8:
    // 0x803943F8: lh          $t7, 0x14($s4)
    ctx->r15 = MEM_H(ctx->r20, 0X14);
    // 0x803943FC: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80394400: addiu       $s6, $zero, 0x6
    ctx->r22 = ADD32(0, 0X6);
    // 0x80394404: bne         $t7, $at, L_80394548
    if (ctx->r15 != ctx->r1) {
        // 0x80394408: addiu       $a0, $zero, 0x80
        ctx->r4 = ADD32(0, 0X80);
            goto L_80394548;
    }
    // 0x80394408: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039440C: lbu         $t8, 0x33($s4)
    ctx->r24 = MEM_BU(ctx->r20, 0X33);
    // 0x80394410: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80394414: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80394418: bne         $t8, $zero, L_80394460
    if (ctx->r24 != 0) {
        // 0x8039441C: addiu       $a2, $zero, 0xFF
        ctx->r6 = ADD32(0, 0XFF);
            goto L_80394460;
    }
    // 0x8039441C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80394420: jal         0x8012C214
    // 0x80394424: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_73;
    // 0x80394424: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_73:
    // 0x80394428: jal         0x80130A90
    // 0x8039442C: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    get_message_address_by_id(rdram, ctx);
        goto after_74;
    // 0x8039442C: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    after_74:
    // 0x80394430: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394434: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80394438: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x8039443C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80394440: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80394444: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80394448: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x8039444C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80394450: jal         0x8012C978
    // 0x80394454: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text_centered(rdram, ctx);
        goto after_75;
    // 0x80394454: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_75:
    // 0x80394458: b           L_80394588
    // 0x8039445C: nop

        goto L_80394588;
    // 0x8039445C: nop

L_80394460:
    // 0x80394460: lbu         $t9, 0x34($s4)
    ctx->r25 = MEM_BU(ctx->r20, 0X34);
    // 0x80394464: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x80394468: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039446C: bne         $t9, $zero, L_80394490
    if (ctx->r25 != 0) {
        // 0x80394470: addiu       $a2, $zero, 0x80
        ctx->r6 = ADD32(0, 0X80);
            goto L_80394490;
    }
    // 0x80394470: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80394474: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80394478: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039447C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80394480: jal         0x8012C214
    // 0x80394484: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_76;
    // 0x80394484: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_76:
    // 0x80394488: b           L_80394498
    // 0x8039448C: nop

        goto L_80394498;
    // 0x8039448C: nop

L_80394490:
    // 0x80394490: jal         0x8012C214
    // 0x80394494: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_77;
    // 0x80394494: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_77:
L_80394498:
    // 0x80394498: jal         0x80130A90
    // 0x8039449C: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    get_message_address_by_id(rdram, ctx);
        goto after_78;
    // 0x8039449C: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    after_78:
    // 0x803944A0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x803944A4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x803944A8: lwc1        $f16, 0x60($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X60);
    // 0x803944AC: andi        $s0, $fp, 0xFFFF
    ctx->r16 = ctx->r30 & 0XFFFF;
    // 0x803944B0: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x803944B4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x803944B8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x803944BC: addiu       $a2, $zero, 0x5B
    ctx->r6 = ADD32(0, 0X5B);
    // 0x803944C0: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x803944C4: jal         0x8012DEF8
    // 0x803944C8: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text(rdram, ctx);
        goto after_79;
    // 0x803944C8: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_79:
    // 0x803944CC: lbu         $t6, 0x34($s4)
    ctx->r14 = MEM_BU(ctx->r20, 0X34);
    // 0x803944D0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803944D4: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x803944D8: bne         $t6, $at, L_803944FC
    if (ctx->r14 != ctx->r1) {
        // 0x803944DC: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_803944FC;
    }
    // 0x803944DC: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x803944E0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x803944E4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x803944E8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x803944EC: jal         0x8012C214
    // 0x803944F0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_80;
    // 0x803944F0: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_80:
    // 0x803944F4: b           L_80394508
    // 0x803944F8: nop

        goto L_80394508;
    // 0x803944F8: nop

L_803944FC:
    // 0x803944FC: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80394500: jal         0x8012C214
    // 0x80394504: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_81;
    // 0x80394504: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_81:
L_80394508:
    // 0x80394508: jal         0x80130A90
    // 0x8039450C: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    get_message_address_by_id(rdram, ctx);
        goto after_82;
    // 0x8039450C: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    after_82:
    // 0x80394510: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394514: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80394518: lwc1        $f10, 0x60($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X60);
    // 0x8039451C: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80394520: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80394524: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80394528: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039452C: addiu       $a2, $zero, 0x61
    ctx->r6 = ADD32(0, 0X61);
    // 0x80394530: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80394534: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80394538: jal         0x8012D374
    // 0x8039453C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_83;
    // 0x8039453C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_83:
    // 0x80394540: b           L_80394588
    // 0x80394544: nop

        goto L_80394588;
    // 0x80394544: nop

L_80394548:
    // 0x80394548: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039454C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x80394550: jal         0x8012C214
    // 0x80394554: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    set_menu_text_color(rdram, ctx);
        goto after_84;
    // 0x80394554: lbu         $a3, 0xF3($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XF3);
    after_84:
    // 0x80394558: jal         0x80130A90
    // 0x8039455C: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    get_message_address_by_id(rdram, ctx);
        goto after_85;
    // 0x8039455C: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    after_85:
    // 0x80394560: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80394564: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80394568: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x8039456C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80394570: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80394574: addiu       $a2, $zero, 0x5E
    ctx->r6 = ADD32(0, 0X5E);
    // 0x80394578: andi        $a3, $fp, 0xFFFF
    ctx->r7 = ctx->r30 & 0XFFFF;
    // 0x8039457C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80394580: jal         0x8012C978
    // 0x80394584: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text_centered(rdram, ctx);
        goto after_86;
    // 0x80394584: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_86:
L_80394588:
    // 0x80394588: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x8039458C: lw          $v1, 0x10D0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X10D0);
    // 0x80394590: lui         $s5, 0x801E
    ctx->r21 = S32(0X801E << 16);
    // 0x80394594: addiu       $s5, $s5, -0x612C
    ctx->r21 = ADD32(ctx->r21, -0X612C);
    // 0x80394598: lb          $a0, 0x3($v1)
    ctx->r4 = MEM_B(ctx->r3, 0X3);
    // 0x8039459C: slti        $at, $a0, 0x33
    ctx->r1 = SIGNED(ctx->r4) < 0X33 ? 1 : 0;
    // 0x803945A0: beql        $at, $zero, L_803945C4
    if (ctx->r1 == 0) {
        // 0x803945A4: lh          $t6, 0x0($s5)
        ctx->r14 = MEM_H(ctx->r21, 0X0);
            goto L_803945C4;
    }
    goto skip_11;
    // 0x803945A4: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
    skip_11:
    // 0x803945A8: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x803945AC: andi        $t8, $v0, 0x800
    ctx->r24 = ctx->r2 & 0X800;
    // 0x803945B0: bne         $t8, $zero, L_803945C0
    if (ctx->r24 != 0) {
        // 0x803945B4: andi        $t9, $v0, 0x8
        ctx->r25 = ctx->r2 & 0X8;
            goto L_803945C0;
    }
    // 0x803945B4: andi        $t9, $v0, 0x8
    ctx->r25 = ctx->r2 & 0X8;
    // 0x803945B8: beq         $t9, $zero, L_8039468C
    if (ctx->r25 == 0) {
        // 0x803945BC: nop
    
            goto L_8039468C;
    }
    // 0x803945BC: nop

L_803945C0:
    // 0x803945C0: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
L_803945C4:
    // 0x803945C4: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x803945C8: addiu       $s0, $s0, 0x6680
    ctx->r16 = ADD32(ctx->r16, 0X6680);
    // 0x803945CC: bne         $t6, $zero, L_8039468C
    if (ctx->r14 != 0) {
        // 0x803945D0: nop
    
            goto L_8039468C;
    }
    // 0x803945D0: nop

    // 0x803945D4: lbu         $t7, 0x31($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X31);
    // 0x803945D8: bne         $t7, $zero, L_8039468C
    if (ctx->r15 != 0) {
        // 0x803945DC: nop
    
            goto L_8039468C;
    }
    // 0x803945DC: nop

    // 0x803945E0: lbu         $t8, 0x35($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X35);
    // 0x803945E4: bne         $t8, $zero, L_8039468C
    if (ctx->r24 != 0) {
        // 0x803945E8: nop
    
            goto L_8039468C;
    }
    // 0x803945E8: nop

    // 0x803945EC: lbu         $t9, 0x33($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X33);
    // 0x803945F0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803945F4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803945F8: bne         $t9, $zero, L_8039468C
    if (ctx->r25 != 0) {
        // 0x803945FC: lui         $a3, 0x3F80
        ctx->r7 = S32(0X3F80 << 16);
            goto L_8039468C;
    }
    // 0x803945FC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x80394600: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394604: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80394608: jal         0x8013307C
    // 0x8039460C: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    play_sound_effect(rdram, ctx);
        goto after_87;
    // 0x8039460C: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    after_87:
    // 0x80394610: lh          $t8, 0x14($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14);
    // 0x80394614: addiu       $t7, $zero, 0xA
    ctx->r15 = ADD32(0, 0XA);
    // 0x80394618: sh          $t7, 0x0($s5)
    MEM_H(0X0, ctx->r21) = ctx->r15;
    // 0x8039461C: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x80394620: sh          $t9, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r25;
    // 0x80394624: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x80394628: lh          $t6, 0x4260($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X4260);
    // 0x8039462C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80394630: bne         $t6, $at, L_80394648
    if (ctx->r14 != ctx->r1) {
        // 0x80394634: nop
    
            goto L_80394648;
    }
    // 0x80394634: nop

    // 0x80394638: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
    // 0x8039463C: bne         $s6, $v0, L_80394648
    if (ctx->r22 != ctx->r2) {
        // 0x80394640: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_80394648;
    }
    // 0x80394640: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    // 0x80394644: sh          $t7, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r15;
L_80394648:
    // 0x80394648: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8039464C: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x80394650: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80394654: beq         $v0, $at, L_80394664
    if (ctx->r2 == ctx->r1) {
        // 0x80394658: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_80394664;
    }
    // 0x80394658: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x8039465C: bne         $v0, $at, L_80394678
    if (ctx->r2 != ctx->r1) {
        // 0x80394660: nop
    
            goto L_80394678;
    }
    // 0x80394660: nop

L_80394664:
    // 0x80394664: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
    // 0x80394668: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8039466C: bne         $s4, $v0, L_80394678
    if (ctx->r20 != ctx->r2) {
        // 0x80394670: addiu       $t8, $v0, -0x1
        ctx->r24 = ADD32(ctx->r2, -0X1);
            goto L_80394678;
    }
    // 0x80394670: addiu       $t8, $v0, -0x1
    ctx->r24 = ADD32(ctx->r2, -0X1);
    // 0x80394674: sh          $t8, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r24;
L_80394678:
    // 0x80394678: jal         0x80395074
    // 0x8039467C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_88;
    // 0x8039467C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_88:
    // 0x80394680: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80394684: lw          $v1, 0x10D0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X10D0);
    // 0x80394688: lb          $a0, 0x3($v1)
    ctx->r4 = MEM_B(ctx->r3, 0X3);
L_8039468C:
    // 0x8039468C: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x80394690: lui         $s5, 0x801E
    ctx->r21 = S32(0X801E << 16);
    // 0x80394694: slti        $at, $a0, -0x32
    ctx->r1 = SIGNED(ctx->r4) < -0X32 ? 1 : 0;
    // 0x80394698: addiu       $s5, $s5, -0x612C
    ctx->r21 = ADD32(ctx->r21, -0X612C);
    // 0x8039469C: addiu       $s0, $s0, 0x6680
    ctx->r16 = ADD32(ctx->r16, 0X6680);
    // 0x803946A0: bne         $at, $zero, L_803946C0
    if (ctx->r1 != 0) {
        // 0x803946A4: addiu       $s4, $zero, 0x1
        ctx->r20 = ADD32(0, 0X1);
            goto L_803946C0;
    }
    // 0x803946A4: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x803946A8: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x803946AC: andi        $t9, $v0, 0x400
    ctx->r25 = ctx->r2 & 0X400;
    // 0x803946B0: bne         $t9, $zero, L_803946C0
    if (ctx->r25 != 0) {
        // 0x803946B4: andi        $t6, $v0, 0x4
        ctx->r14 = ctx->r2 & 0X4;
            goto L_803946C0;
    }
    // 0x803946B4: andi        $t6, $v0, 0x4
    ctx->r14 = ctx->r2 & 0X4;
    // 0x803946B8: beql        $t6, $zero, L_80394780
    if (ctx->r14 == 0) {
        // 0x803946BC: lhu         $t6, 0x0($v1)
        ctx->r14 = MEM_HU(ctx->r3, 0X0);
            goto L_80394780;
    }
    goto skip_12;
    // 0x803946BC: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    skip_12:
L_803946C0:
    // 0x803946C0: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
    // 0x803946C4: bnel        $t7, $zero, L_80394780
    if (ctx->r15 != 0) {
        // 0x803946C8: lhu         $t6, 0x0($v1)
        ctx->r14 = MEM_HU(ctx->r3, 0X0);
            goto L_80394780;
    }
    goto skip_13;
    // 0x803946C8: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    skip_13:
    // 0x803946CC: lbu         $t8, 0x31($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X31);
    // 0x803946D0: bnel        $t8, $zero, L_80394780
    if (ctx->r24 != 0) {
        // 0x803946D4: lhu         $t6, 0x0($v1)
        ctx->r14 = MEM_HU(ctx->r3, 0X0);
            goto L_80394780;
    }
    goto skip_14;
    // 0x803946D4: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    skip_14:
    // 0x803946D8: lbu         $t9, 0x35($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X35);
    // 0x803946DC: bnel        $t9, $zero, L_80394780
    if (ctx->r25 != 0) {
        // 0x803946E0: lhu         $t6, 0x0($v1)
        ctx->r14 = MEM_HU(ctx->r3, 0X0);
            goto L_80394780;
    }
    goto skip_15;
    // 0x803946E0: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    skip_15:
    // 0x803946E4: lbu         $t6, 0x33($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X33);
    // 0x803946E8: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x803946EC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803946F0: bne         $t6, $zero, L_8039477C
    if (ctx->r14 != 0) {
        // 0x803946F4: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039477C;
    }
    // 0x803946F4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803946F8: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x803946FC: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80394700: jal         0x8013307C
    // 0x80394704: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_89;
    // 0x80394704: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_89:
    // 0x80394708: lh          $t9, 0x14($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X14);
    // 0x8039470C: addiu       $t8, $zero, 0xA
    ctx->r24 = ADD32(0, 0XA);
    // 0x80394710: sh          $t8, 0x0($s5)
    MEM_H(0X0, ctx->r21) = ctx->r24;
    // 0x80394714: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x80394718: sh          $t6, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r14;
    // 0x8039471C: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80394720: lh          $t7, 0x4260($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4260);
    // 0x80394724: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80394728: bne         $t7, $at, L_80394740
    if (ctx->r15 != ctx->r1) {
        // 0x8039472C: nop
    
            goto L_80394740;
    }
    // 0x8039472C: nop

    // 0x80394730: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
    // 0x80394734: bne         $s6, $v0, L_80394740
    if (ctx->r22 != ctx->r2) {
        // 0x80394738: addiu       $t8, $v0, 0x1
        ctx->r24 = ADD32(ctx->r2, 0X1);
            goto L_80394740;
    }
    // 0x80394738: addiu       $t8, $v0, 0x1
    ctx->r24 = ADD32(ctx->r2, 0X1);
    // 0x8039473C: sh          $t8, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r24;
L_80394740:
    // 0x80394740: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80394744: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x80394748: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x8039474C: beq         $v0, $at, L_8039475C
    if (ctx->r2 == ctx->r1) {
        // 0x80394750: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_8039475C;
    }
    // 0x80394750: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80394754: bne         $v0, $at, L_8039476C
    if (ctx->r2 != ctx->r1) {
        // 0x80394758: nop
    
            goto L_8039476C;
    }
    // 0x80394758: nop

L_8039475C:
    // 0x8039475C: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
    // 0x80394760: bne         $s4, $v0, L_8039476C
    if (ctx->r20 != ctx->r2) {
        // 0x80394764: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_8039476C;
    }
    // 0x80394764: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x80394768: sh          $t9, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r25;
L_8039476C:
    // 0x8039476C: jal         0x80395074
    // 0x80394770: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_90;
    // 0x80394770: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_90:
    // 0x80394774: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80394778: lw          $v1, 0x10D0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X10D0);
L_8039477C:
    // 0x8039477C: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
L_80394780:
    // 0x80394780: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80394784: andi        $t7, $t6, 0x4000
    ctx->r15 = ctx->r14 & 0X4000;
    // 0x80394788: beql        $t7, $zero, L_803947EC
    if (ctx->r15 == 0) {
        // 0x8039478C: lb          $v0, 0x2($v1)
        ctx->r2 = MEM_B(ctx->r3, 0X2);
            goto L_803947EC;
    }
    goto skip_16;
    // 0x8039478C: lb          $v0, 0x2($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X2);
    skip_16:
    // 0x80394790: lbu         $t8, 0x12E0($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12E0);
    // 0x80394794: bnel        $s4, $t8, L_803947EC
    if (ctx->r20 != ctx->r24) {
        // 0x80394798: lb          $v0, 0x2($v1)
        ctx->r2 = MEM_B(ctx->r3, 0X2);
            goto L_803947EC;
    }
    goto skip_17;
    // 0x80394798: lb          $v0, 0x2($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X2);
    skip_17:
    // 0x8039479C: lbu         $t9, 0x31($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X31);
    // 0x803947A0: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x803947A4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803947A8: bne         $t9, $zero, L_803947C4
    if (ctx->r25 != 0) {
        // 0x803947AC: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_803947C4;
    }
    // 0x803947AC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803947B0: lbu         $t6, 0x35($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X35);
    // 0x803947B4: bnel        $t6, $zero, L_803947C8
    if (ctx->r14 != 0) {
        // 0x803947B8: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_803947C8;
    }
    goto skip_18;
    // 0x803947B8: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    skip_18:
    // 0x803947BC: lbu         $t7, 0x33($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X33);
    // 0x803947C0: beq         $t7, $zero, L_803947E8
    if (ctx->r15 == 0) {
        // 0x803947C4: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_803947E8;
    }
L_803947C4:
    // 0x803947C4: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
L_803947C8:
    // 0x803947C8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803947CC: jal         0x8013307C
    // 0x803947D0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_91;
    // 0x803947D0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_91:
    // 0x803947D4: sb          $zero, 0x31($s0)
    MEM_B(0X31, ctx->r16) = 0;
    // 0x803947D8: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
    // 0x803947DC: sb          $zero, 0x33($s0)
    MEM_B(0X33, ctx->r16) = 0;
    // 0x803947E0: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x803947E4: lw          $v1, 0x10D0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X10D0);
L_803947E8:
    // 0x803947E8: lb          $v0, 0x2($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X2);
L_803947EC:
    // 0x803947EC: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x803947F0: slti        $at, $v0, -0x32
    ctx->r1 = SIGNED(ctx->r2) < -0X32 ? 1 : 0;
    // 0x803947F4: bnel        $at, $zero, L_80394810
    if (ctx->r1 != 0) {
        // 0x803947F8: lh          $t7, 0x0($s5)
        ctx->r15 = MEM_H(ctx->r21, 0X0);
            goto L_80394810;
    }
    goto skip_19;
    // 0x803947F8: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
    skip_19:
    // 0x803947FC: lhu         $t9, 0x0($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X0);
    // 0x80394800: andi        $t6, $t9, 0x200
    ctx->r14 = ctx->r25 & 0X200;
    // 0x80394804: beql        $t6, $zero, L_80394820
    if (ctx->r14 == 0) {
        // 0x80394808: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80394820;
    }
    goto skip_20;
    // 0x80394808: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_20:
    // 0x8039480C: lh          $t7, 0x0($s5)
    ctx->r15 = MEM_H(ctx->r21, 0X0);
L_80394810:
    // 0x80394810: bnel        $t7, $zero, L_80394820
    if (ctx->r15 != 0) {
        // 0x80394814: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80394820;
    }
    goto skip_21;
    // 0x80394814: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_21:
    // 0x80394818: addiu       $s1, $zero, -0x1
    ctx->r17 = ADD32(0, -0X1);
    // 0x8039481C: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
L_80394820:
    // 0x80394820: beql        $at, $zero, L_8039483C
    if (ctx->r1 == 0) {
        // 0x80394824: lh          $t6, 0x0($s5)
        ctx->r14 = MEM_H(ctx->r21, 0X0);
            goto L_8039483C;
    }
    goto skip_22;
    // 0x80394824: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
    skip_22:
    // 0x80394828: lhu         $t8, 0x0($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X0);
    // 0x8039482C: andi        $t9, $t8, 0x100
    ctx->r25 = ctx->r24 & 0X100;
    // 0x80394830: beq         $t9, $zero, L_80394850
    if (ctx->r25 == 0) {
        // 0x80394834: nop
    
            goto L_80394850;
    }
    // 0x80394834: nop

    // 0x80394838: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
L_8039483C:
    // 0x8039483C: bne         $t6, $zero, L_80394850
    if (ctx->r14 != 0) {
        // 0x80394840: nop
    
            goto L_80394850;
    }
    // 0x80394840: nop

    // 0x80394844: sll         $s1, $s4, 16
    ctx->r17 = S32(ctx->r20 << 16);
    // 0x80394848: sra         $t7, $s1, 16
    ctx->r15 = S32(SIGNED(ctx->r17) >> 16);
    // 0x8039484C: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
L_80394850:
    // 0x80394850: beql        $s1, $zero, L_80394BE4
    if (ctx->r17 == 0) {
        // 0x80394854: lh          $v0, 0x14($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X14);
            goto L_80394BE4;
    }
    goto skip_23;
    // 0x80394854: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
    skip_23:
    // 0x80394858: lh          $t8, 0x14($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14);
    // 0x8039485C: addiu       $t9, $t8, -0x2
    ctx->r25 = ADD32(ctx->r24, -0X2);
    // 0x80394860: sltiu       $at, $t9, 0x6
    ctx->r1 = ctx->r25 < 0X6 ? 1 : 0;
    // 0x80394864: beq         $at, $zero, L_80394BD0
    if (ctx->r1 == 0) {
        // 0x80394868: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_80394BD0;
    }
    // 0x80394868: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039486C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80394870: addu        $at, $at, $t9
    gpr jr_addend_80394878 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80394874: lw          $t9, 0x350($at)
    ctx->r25 = ADD32(ctx->r1, 0X350);
    // 0x80394878: jr          $t9
    // 0x8039487C: nop

    switch (jr_addend_80394878 >> 2) {
        case 0: goto L_80394988; break;
        case 1: goto L_803949FC; break;
        case 2: goto L_80394880; break;
        case 3: goto L_803948FC; break;
        case 4: goto L_80394AEC; break;
        case 5: goto L_80394A74; break;
        default: switch_error(__func__, 0x80394878, 0x803C0350);
    }
    // 0x8039487C: nop

L_80394880:
    // 0x80394880: lb          $t6, 0xC($s2)
    ctx->r14 = MEM_B(ctx->r18, 0XC);
    // 0x80394884: addiu       $t8, $zero, 0x13
    ctx->r24 = ADD32(0, 0X13);
    // 0x80394888: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x8039488C: addu        $t7, $t6, $s1
    ctx->r15 = ADD32(ctx->r14, ctx->r17);
    // 0x80394890: sb          $t7, 0xC($s2)
    MEM_B(0XC, ctx->r18) = ctx->r15;
    // 0x80394894: lb          $v0, 0xC($s2)
    ctx->r2 = MEM_B(ctx->r18, 0XC);
    // 0x80394898: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039489C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803948A0: bgez        $v0, L_803948B0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803948A4: lui         $a3, 0x3F80
        ctx->r7 = S32(0X3F80 << 16);
            goto L_803948B0;
    }
    // 0x803948A4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x803948A8: sb          $zero, 0xC($s2)
    MEM_B(0XC, ctx->r18) = 0;
    // 0x803948AC: lb          $v0, 0xC($s2)
    ctx->r2 = MEM_B(ctx->r18, 0XC);
L_803948B0:
    // 0x803948B0: slti        $at, $v0, 0x14
    ctx->r1 = SIGNED(ctx->r2) < 0X14 ? 1 : 0;
    // 0x803948B4: bne         $at, $zero, L_803948C0
    if (ctx->r1 != 0) {
        // 0x803948B8: addiu       $t9, $zero, 0x40
        ctx->r25 = ADD32(0, 0X40);
            goto L_803948C0;
    }
    // 0x803948B8: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x803948BC: sb          $t8, 0xC($s2)
    MEM_B(0XC, ctx->r18) = ctx->r24;
L_803948C0:
    // 0x803948C0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803948C4: bne         $s1, $at, L_803948D4
    if (ctx->r17 != ctx->r1) {
        // 0x803948C8: nop
    
            goto L_803948D4;
    }
    // 0x803948C8: nop

    // 0x803948CC: jal         0x8013307C
    // 0x803948D0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    play_sound_effect(rdram, ctx);
        goto after_92;
    // 0x803948D0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_92:
L_803948D4:
    // 0x803948D4: bne         $s1, $s4, L_80394BD0
    if (ctx->r17 != ctx->r20) {
        // 0x803948D8: addiu       $a0, $zero, 0x90
        ctx->r4 = ADD32(0, 0X90);
            goto L_80394BD0;
    }
    // 0x803948D8: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x803948DC: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x803948E0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803948E4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803948E8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803948EC: jal         0x8013307C
    // 0x803948F0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_93;
    // 0x803948F0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_93:
    // 0x803948F4: b           L_80394BD0
    // 0x803948F8: nop

        goto L_80394BD0;
    // 0x803948F8: nop

L_803948FC:
    // 0x803948FC: lb          $t7, 0xD($s2)
    ctx->r15 = MEM_B(ctx->r18, 0XD);
    // 0x80394900: addiu       $t9, $zero, 0x13
    ctx->r25 = ADD32(0, 0X13);
    // 0x80394904: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x80394908: addu        $t8, $t7, $s1
    ctx->r24 = ADD32(ctx->r15, ctx->r17);
    // 0x8039490C: sb          $t8, 0xD($s2)
    MEM_B(0XD, ctx->r18) = ctx->r24;
    // 0x80394910: lb          $v0, 0xD($s2)
    ctx->r2 = MEM_B(ctx->r18, 0XD);
    // 0x80394914: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394918: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039491C: bgez        $v0, L_8039492C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80394920: lui         $a3, 0x3F80
        ctx->r7 = S32(0X3F80 << 16);
            goto L_8039492C;
    }
    // 0x80394920: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x80394924: sb          $zero, 0xD($s2)
    MEM_B(0XD, ctx->r18) = 0;
    // 0x80394928: lb          $v0, 0xD($s2)
    ctx->r2 = MEM_B(ctx->r18, 0XD);
L_8039492C:
    // 0x8039492C: slti        $at, $v0, 0x14
    ctx->r1 = SIGNED(ctx->r2) < 0X14 ? 1 : 0;
    // 0x80394930: bne         $at, $zero, L_8039493C
    if (ctx->r1 != 0) {
        // 0x80394934: addiu       $t6, $zero, 0x40
        ctx->r14 = ADD32(0, 0X40);
            goto L_8039493C;
    }
    // 0x80394934: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394938: sb          $t9, 0xD($s2)
    MEM_B(0XD, ctx->r18) = ctx->r25;
L_8039493C:
    // 0x8039493C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80394940: bne         $s1, $at, L_80394950
    if (ctx->r17 != ctx->r1) {
        // 0x80394944: nop
    
            goto L_80394950;
    }
    // 0x80394944: nop

    // 0x80394948: jal         0x8013307C
    // 0x8039494C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    play_sound_effect(rdram, ctx);
        goto after_94;
    // 0x8039494C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_94:
L_80394950:
    // 0x80394950: bne         $s1, $s4, L_80394970
    if (ctx->r17 != ctx->r20) {
        // 0x80394954: addiu       $a0, $zero, 0x90
        ctx->r4 = ADD32(0, 0X90);
            goto L_80394970;
    }
    // 0x80394954: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x80394958: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x8039495C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80394960: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394964: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394968: jal         0x8013307C
    // 0x8039496C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_95;
    // 0x8039496C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_95:
L_80394970:
    // 0x80394970: jal         0x80395074
    // 0x80394974: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_96;
    // 0x80394974: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_96:
    // 0x80394978: jal         0x80133B74
    // 0x8039497C: lb          $a0, 0xD($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XD);
    set_sfx_volume(rdram, ctx);
        goto after_97;
    // 0x8039497C: lb          $a0, 0xD($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XD);
    after_97:
    // 0x80394980: b           L_80394BD0
    // 0x80394984: nop

        goto L_80394BD0;
    // 0x80394984: nop

L_80394988:
    // 0x80394988: lbu         $t8, 0x35($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X35);
    // 0x8039498C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80394990: beql        $t8, $zero, L_80394A00
    if (ctx->r24 == 0) {
        // 0x80394994: lbu         $t6, 0x31($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X31);
            goto L_80394A00;
    }
    goto skip_24;
    // 0x80394994: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
    skip_24:
    // 0x80394998: bne         $s1, $at, L_803949C8
    if (ctx->r17 != ctx->r1) {
        // 0x8039499C: nop
    
            goto L_803949C8;
    }
    // 0x8039499C: nop

    // 0x803949A0: lbu         $t9, 0x36($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X36);
    // 0x803949A4: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x803949A8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803949AC: bne         $s4, $t9, L_803949C4
    if (ctx->r20 != ctx->r25) {
        // 0x803949B0: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_803949C4;
    }
    // 0x803949B0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803949B4: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x803949B8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803949BC: jal         0x8013307C
    // 0x803949C0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_98;
    // 0x803949C0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_98:
L_803949C4:
    // 0x803949C4: sb          $zero, 0x36($s0)
    MEM_B(0X36, ctx->r16) = 0;
L_803949C8:
    // 0x803949C8: bnel        $s1, $s4, L_80394A00
    if (ctx->r17 != ctx->r20) {
        // 0x803949CC: lbu         $t6, 0x31($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X31);
            goto L_80394A00;
    }
    goto skip_25;
    // 0x803949CC: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
    skip_25:
    // 0x803949D0: lbu         $t7, 0x36($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X36);
    // 0x803949D4: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x803949D8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803949DC: bne         $t7, $zero, L_803949F4
    if (ctx->r15 != 0) {
        // 0x803949E0: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_803949F4;
    }
    // 0x803949E0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803949E4: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x803949E8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803949EC: jal         0x8013307C
    // 0x803949F0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_99;
    // 0x803949F0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_99:
L_803949F4:
    // 0x803949F4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x803949F8: sb          $t9, 0x36($s0)
    MEM_B(0X36, ctx->r16) = ctx->r25;
L_803949FC:
    // 0x803949FC: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
L_80394A00:
    // 0x80394A00: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80394A04: beq         $t6, $zero, L_80394BD0
    if (ctx->r14 == 0) {
        // 0x80394A08: nop
    
            goto L_80394BD0;
    }
    // 0x80394A08: nop

    // 0x80394A0C: bne         $s1, $at, L_80394A3C
    if (ctx->r17 != ctx->r1) {
        // 0x80394A10: nop
    
            goto L_80394A3C;
    }
    // 0x80394A10: nop

    // 0x80394A14: lbu         $t7, 0x32($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X32);
    // 0x80394A18: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x80394A1C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394A20: bne         $s4, $t7, L_80394A38
    if (ctx->r20 != ctx->r15) {
        // 0x80394A24: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394A38;
    }
    // 0x80394A24: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394A28: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394A2C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80394A30: jal         0x8013307C
    // 0x80394A34: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_100;
    // 0x80394A34: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_100:
L_80394A38:
    // 0x80394A38: sb          $zero, 0x32($s0)
    MEM_B(0X32, ctx->r16) = 0;
L_80394A3C:
    // 0x80394A3C: bne         $s1, $s4, L_80394BD0
    if (ctx->r17 != ctx->r20) {
        // 0x80394A40: nop
    
            goto L_80394BD0;
    }
    // 0x80394A40: nop

    // 0x80394A44: lbu         $t9, 0x32($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X32);
    // 0x80394A48: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x80394A4C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394A50: bne         $t9, $zero, L_80394A68
    if (ctx->r25 != 0) {
        // 0x80394A54: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394A68;
    }
    // 0x80394A54: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394A58: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394A5C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80394A60: jal         0x8013307C
    // 0x80394A64: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_101;
    // 0x80394A64: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_101:
L_80394A68:
    // 0x80394A68: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80394A6C: b           L_80394BD0
    // 0x80394A70: sb          $t7, 0x32($s0)
    MEM_B(0X32, ctx->r16) = ctx->r15;
        goto L_80394BD0;
    // 0x80394A70: sb          $t7, 0x32($s0)
    MEM_B(0X32, ctx->r16) = ctx->r15;
L_80394A74:
    // 0x80394A74: lbu         $t8, 0x33($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X33);
    // 0x80394A78: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80394A7C: beq         $t8, $zero, L_80394BD0
    if (ctx->r24 == 0) {
        // 0x80394A80: nop
    
            goto L_80394BD0;
    }
    // 0x80394A80: nop

    // 0x80394A84: bne         $s1, $at, L_80394AB4
    if (ctx->r17 != ctx->r1) {
        // 0x80394A88: nop
    
            goto L_80394AB4;
    }
    // 0x80394A88: nop

    // 0x80394A8C: lbu         $t9, 0x34($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X34);
    // 0x80394A90: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x80394A94: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394A98: bne         $s4, $t9, L_80394AB0
    if (ctx->r20 != ctx->r25) {
        // 0x80394A9C: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394AB0;
    }
    // 0x80394A9C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394AA0: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394AA4: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80394AA8: jal         0x8013307C
    // 0x80394AAC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_102;
    // 0x80394AAC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_102:
L_80394AB0:
    // 0x80394AB0: sb          $zero, 0x34($s0)
    MEM_B(0X34, ctx->r16) = 0;
L_80394AB4:
    // 0x80394AB4: bne         $s1, $s4, L_80394BD0
    if (ctx->r17 != ctx->r20) {
        // 0x80394AB8: nop
    
            goto L_80394BD0;
    }
    // 0x80394AB8: nop

    // 0x80394ABC: lbu         $t7, 0x34($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X34);
    // 0x80394AC0: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x80394AC4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394AC8: bne         $t7, $zero, L_80394AE0
    if (ctx->r15 != 0) {
        // 0x80394ACC: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394AE0;
    }
    // 0x80394ACC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394AD0: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394AD4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80394AD8: jal         0x8013307C
    // 0x80394ADC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_103;
    // 0x80394ADC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_103:
L_80394AE0:
    // 0x80394AE0: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80394AE4: b           L_80394BD0
    // 0x80394AE8: sb          $t9, 0x34($s0)
    MEM_B(0X34, ctx->r16) = ctx->r25;
        goto L_80394BD0;
    // 0x80394AE8: sb          $t9, 0x34($s0)
    MEM_B(0X34, ctx->r16) = ctx->r25;
L_80394AEC:
    // 0x80394AEC: lb          $t6, 0xE($s2)
    ctx->r14 = MEM_B(ctx->r18, 0XE);
    // 0x80394AF0: addiu       $t8, $zero, 0x8
    ctx->r24 = ADD32(0, 0X8);
    // 0x80394AF4: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x80394AF8: addu        $t7, $t6, $s1
    ctx->r15 = ADD32(ctx->r14, ctx->r17);
    // 0x80394AFC: sb          $t7, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r15;
    // 0x80394B00: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
    // 0x80394B04: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394B08: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x80394B0C: slti        $at, $a2, 0x9
    ctx->r1 = SIGNED(ctx->r6) < 0X9 ? 1 : 0;
    // 0x80394B10: bne         $at, $zero, L_80394B20
    if (ctx->r1 != 0) {
        // 0x80394B14: nop
    
            goto L_80394B20;
    }
    // 0x80394B14: nop

    // 0x80394B18: sb          $zero, 0xE($s2)
    MEM_B(0XE, ctx->r18) = 0;
    // 0x80394B1C: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
L_80394B20:
    // 0x80394B20: bgez        $a2, L_80394B30
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80394B24: nop
    
            goto L_80394B30;
    }
    // 0x80394B24: nop

    // 0x80394B28: sb          $t8, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r24;
    // 0x80394B2C: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
L_80394B30:
    // 0x80394B30: bne         $s1, $s4, L_80394B58
    if (ctx->r17 != ctx->r20) {
        // 0x80394B34: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_80394B58;
    }
    // 0x80394B34: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394B38: bne         $a2, $zero, L_80394B48
    if (ctx->r6 != 0) {
        // 0x80394B3C: addiu       $t9, $zero, 0x7
        ctx->r25 = ADD32(0, 0X7);
            goto L_80394B48;
    }
    // 0x80394B3C: addiu       $t9, $zero, 0x7
    ctx->r25 = ADD32(0, 0X7);
    // 0x80394B40: sb          $s4, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r20;
    // 0x80394B44: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
L_80394B48:
    // 0x80394B48: bne         $s6, $a2, L_80394B58
    if (ctx->r22 != ctx->r6) {
        // 0x80394B4C: nop
    
            goto L_80394B58;
    }
    // 0x80394B4C: nop

    // 0x80394B50: sb          $t9, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r25;
    // 0x80394B54: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
L_80394B58:
    // 0x80394B58: bne         $a2, $zero, L_80394B68
    if (ctx->r6 != 0) {
        // 0x80394B5C: addiu       $t6, $zero, 0x8
        ctx->r14 = ADD32(0, 0X8);
            goto L_80394B68;
    }
    // 0x80394B5C: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    // 0x80394B60: sb          $t6, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r14;
    // 0x80394B64: lb          $a2, 0xE($s2)
    ctx->r6 = MEM_B(ctx->r18, 0XE);
L_80394B68:
    // 0x80394B68: bne         $s6, $a2, L_80394B74
    if (ctx->r22 != ctx->r6) {
        // 0x80394B6C: addiu       $t7, $zero, 0x5
        ctx->r15 = ADD32(0, 0X5);
            goto L_80394B74;
    }
    // 0x80394B6C: addiu       $t7, $zero, 0x5
    ctx->r15 = ADD32(0, 0X5);
    // 0x80394B70: sb          $t7, 0xE($s2)
    MEM_B(0XE, ctx->r18) = ctx->r15;
L_80394B74:
    // 0x80394B74: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394B78: jal         0x8013307C
    // 0x80394B7C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    play_sound_effect(rdram, ctx);
        goto after_104;
    // 0x80394B7C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    after_104:
    // 0x80394B80: jal         0x80395074
    // 0x80394B84: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_105;
    // 0x80394B84: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_105:
    // 0x80394B88: lui         $a2, 0x8023
    ctx->r6 = S32(0X8023 << 16);
    // 0x80394B8C: lui         $a3, 0x8023
    ctx->r7 = S32(0X8023 << 16);
    // 0x80394B90: addiu       $a3, $a3, 0x1D5C
    ctx->r7 = ADD32(ctx->r7, 0X1D5C);
    // 0x80394B94: addiu       $a2, $a2, 0x1AA0
    ctx->r6 = ADD32(ctx->r6, 0X1AA0);
    // 0x80394B98: lb          $a0, 0xE($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XE);
    // 0x80394B9C: jal         0x801308E8
    // 0x80394BA0: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    load_level_text_data(rdram, ctx);
        goto after_106;
    // 0x80394BA0: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    after_106:
    // 0x80394BA4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80394BA8: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80394BAC: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80394BB0: addiu       $a3, $a3, 0x34C0
    ctx->r7 = ADD32(ctx->r7, 0X34C0);
    // 0x80394BB4: addiu       $a2, $a2, 0x3330
    ctx->r6 = ADD32(ctx->r6, 0X3330);
    // 0x80394BB8: lb          $a1, 0x7DD5($a1)
    ctx->r5 = MEM_B(ctx->r5, 0X7DD5);
    // 0x80394BBC: jal         0x801308E8
    // 0x80394BC0: lb          $a0, 0xE($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XE);
    load_level_text_data(rdram, ctx);
        goto after_107;
    // 0x80394BC0: lb          $a0, 0xE($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XE);
    after_107:
    // 0x80394BC4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80394BC8: jal         0x8039DBC8
    // 0x80394BCC: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    static_2_8039DBC8(rdram, ctx);
        goto after_108;
    // 0x80394BCC: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    after_108:
L_80394BD0:
    // 0x80394BD0: jal         0x80395074
    // 0x80394BD4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_109;
    // 0x80394BD4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_109:
    // 0x80394BD8: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80394BDC: lw          $v1, 0x10D0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X10D0);
    // 0x80394BE0: lh          $v0, 0x14($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14);
L_80394BE4:
    // 0x80394BE4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80394BE8: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80394BEC: beql        $v0, $at, L_80394C00
    if (ctx->r2 == ctx->r1) {
        // 0x80394BF0: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80394C00;
    }
    goto skip_26;
    // 0x80394BF0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    skip_26:
    // 0x80394BF4: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
    // 0x80394BF8: sb          $zero, 0x36($s0)
    MEM_B(0X36, ctx->r16) = 0;
    // 0x80394BFC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
L_80394C00:
    // 0x80394C00: beql        $v0, $at, L_80394C14
    if (ctx->r2 == ctx->r1) {
        // 0x80394C04: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_80394C14;
    }
    goto skip_27;
    // 0x80394C04: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    skip_27:
    // 0x80394C08: sb          $zero, 0x31($s0)
    MEM_B(0X31, ctx->r16) = 0;
    // 0x80394C0C: sb          $zero, 0x32($s0)
    MEM_B(0X32, ctx->r16) = 0;
    // 0x80394C10: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
L_80394C14:
    // 0x80394C14: beql        $v0, $at, L_80394C28
    if (ctx->r2 == ctx->r1) {
        // 0x80394C18: lhu         $v0, 0x0($v1)
        ctx->r2 = MEM_HU(ctx->r3, 0X0);
            goto L_80394C28;
    }
    goto skip_28;
    // 0x80394C18: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    skip_28:
    // 0x80394C1C: sb          $zero, 0x33($s0)
    MEM_B(0X33, ctx->r16) = 0;
    // 0x80394C20: sb          $zero, 0x34($s0)
    MEM_B(0X34, ctx->r16) = 0;
    // 0x80394C24: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
L_80394C28:
    // 0x80394C28: andi        $t9, $v0, 0x1000
    ctx->r25 = ctx->r2 & 0X1000;
    // 0x80394C2C: beq         $t9, $zero, L_80394C40
    if (ctx->r25 == 0) {
        // 0x80394C30: andi        $t7, $v0, 0x8000
        ctx->r15 = ctx->r2 & 0X8000;
            goto L_80394C40;
    }
    // 0x80394C30: andi        $t7, $v0, 0x8000
    ctx->r15 = ctx->r2 & 0X8000;
    // 0x80394C34: lbu         $t6, 0x12DE($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12DE);
    // 0x80394C38: beq         $s4, $t6, L_80394C54
    if (ctx->r20 == ctx->r14) {
        // 0x80394C3C: nop
    
            goto L_80394C54;
    }
    // 0x80394C3C: nop

L_80394C40:
    // 0x80394C40: beq         $t7, $zero, L_80395038
    if (ctx->r15 == 0) {
        // 0x80394C44: lui         $t8, 0x8029
        ctx->r24 = S32(0X8029 << 16);
            goto L_80395038;
    }
    // 0x80394C44: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80394C48: lbu         $t8, 0x12DF($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12DF);
    // 0x80394C4C: bnel        $s4, $t8, L_8039503C
    if (ctx->r20 != ctx->r24) {
        // 0x80394C50: or          $a0, $s7, $zero
        ctx->r4 = ctx->r23 | 0;
            goto L_8039503C;
    }
    goto skip_29;
    // 0x80394C50: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    skip_29:
L_80394C54:
    // 0x80394C54: jal         0x80395074
    // 0x80394C58: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_110;
    // 0x80394C58: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_110:
    // 0x80394C5C: lhu         $t9, 0x14($s0)
    ctx->r25 = MEM_HU(ctx->r16, 0X14);
    // 0x80394C60: sltiu       $at, $t9, 0x8
    ctx->r1 = ctx->r25 < 0X8 ? 1 : 0;
    // 0x80394C64: beq         $at, $zero, L_80395038
    if (ctx->r1 == 0) {
        // 0x80394C68: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_80395038;
    }
    // 0x80394C68: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80394C6C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80394C70: addu        $at, $at, $t9
    gpr jr_addend_80394C78 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80394C74: lw          $t9, 0x368($at)
    ctx->r25 = ADD32(ctx->r1, 0X368);
    // 0x80394C78: jr          $t9
    // 0x80394C7C: nop

    switch (jr_addend_80394C78 >> 2) {
        case 0: goto L_80394C80; break;
        case 1: goto L_80394CCC; break;
        case 2: goto L_80394D28; break;
        case 3: goto L_80394EC8; break;
        case 4: goto L_80394C80; break;
        case 5: goto L_80394C80; break;
        case 6: goto L_80394C80; break;
        case 7: goto L_80394FB0; break;
        default: switch_error(__func__, 0x80394C78, 0x803C0368);
    }
    // 0x80394C7C: nop

L_80394C80:
    // 0x80394C80: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394C84: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80394C88: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80394C8C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394C90: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394C94: jal         0x8013307C
    // 0x80394C98: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_111;
    // 0x80394C98: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_111:
    // 0x80394C9C: sh          $s4, 0x22($s0)
    MEM_H(0X22, ctx->r16) = ctx->r20;
    // 0x80394CA0: sh          $zero, 0x20($s0)
    MEM_H(0X20, ctx->r16) = 0;
    // 0x80394CA4: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x80394CA8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80394CAC: sh          $t7, 0x420($at)
    MEM_H(0X420, ctx->r1) = ctx->r15;
    // 0x80394CB0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80394CB4: lui         $a1, 0x4270
    ctx->r5 = S32(0X4270 << 16);
    // 0x80394CB8: lui         $a2, 0x40C0
    ctx->r6 = S32(0X40C0 << 16);
    // 0x80394CBC: jal         0x801337DC
    // 0x80394CC0: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    start_sequence_volume_fade(rdram, ctx);
        goto after_112;
    // 0x80394CC0: lui         $a3, 0x41A0
    ctx->r7 = S32(0X41A0 << 16);
    after_112:
    // 0x80394CC4: b           L_8039503C
    // 0x80394CC8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_8039503C;
    // 0x80394CC8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80394CCC:
    // 0x80394CCC: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394CD0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80394CD4: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80394CD8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394CDC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394CE0: jal         0x8013307C
    // 0x80394CE4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_113;
    // 0x80394CE4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_113:
    // 0x80394CE8: addiu       $t9, $zero, 0x2F8
    ctx->r25 = ADD32(0, 0X2F8);
    // 0x80394CEC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80394CF0: sh          $t9, 0x6706($at)
    MEM_H(0X6706, ctx->r1) = ctx->r25;
    // 0x80394CF4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80394CF8: addiu       $t6, $zero, 0x490
    ctx->r14 = ADD32(0, 0X490);
    // 0x80394CFC: sh          $t6, 0x670A($at)
    MEM_H(0X670A, ctx->r1) = ctx->r14;
    // 0x80394D00: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80394D04: addiu       $t7, $zero, 0xE0
    ctx->r15 = ADD32(0, 0XE0);
    // 0x80394D08: sh          $t7, 0x6708($at)
    MEM_H(0X6708, ctx->r1) = ctx->r15;
    // 0x80394D0C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80394D10: addiu       $t8, $zero, 0x200
    ctx->r24 = ADD32(0, 0X200);
    // 0x80394D14: sh          $t8, 0x670C($at)
    MEM_H(0X670C, ctx->r1) = ctx->r24;
    // 0x80394D18: lh          $t9, 0x18($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X18);
    // 0x80394D1C: addiu       $t6, $t9, 0x1
    ctx->r14 = ADD32(ctx->r25, 0X1);
    // 0x80394D20: b           L_80395038
    // 0x80394D24: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
        goto L_80395038;
    // 0x80394D24: sh          $t6, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r14;
L_80394D28:
    // 0x80394D28: lbu         $t7, 0x35($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X35);
    // 0x80394D2C: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x80394D30: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394D34: bne         $t7, $zero, L_80394D5C
    if (ctx->r15 != 0) {
        // 0x80394D38: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394D5C;
    }
    // 0x80394D38: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394D3C: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394D40: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80394D44: jal         0x8013307C
    // 0x80394D48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_114;
    // 0x80394D48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_114:
    // 0x80394D4C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80394D50: sb          $t9, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r25;
    // 0x80394D54: b           L_80395038
    // 0x80394D58: sb          $zero, 0x36($s0)
    MEM_B(0X36, ctx->r16) = 0;
        goto L_80395038;
    // 0x80394D58: sb          $zero, 0x36($s0)
    MEM_B(0X36, ctx->r16) = 0;
L_80394D5C:
    // 0x80394D5C: lbu         $t6, 0x36($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X36);
    // 0x80394D60: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x80394D64: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394D68: bne         $s4, $t6, L_80394EB0
    if (ctx->r20 != ctx->r14) {
        // 0x80394D6C: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394EB0;
    }
    // 0x80394D6C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394D70: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80394D74: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x80394D78: sw          $zero, 0x4D2C($at)
    MEM_W(0X4D2C, ctx->r1) = 0;
    // 0x80394D7C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80394D80: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80394D84: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394D88: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394D8C: jal         0x8013307C
    // 0x80394D90: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_115;
    // 0x80394D90: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_115:
    // 0x80394D94: jal         0x8039264C
    // 0x80394D98: nop

    func_8039264C_7A3CFC(rdram, ctx);
        goto after_116;
    // 0x80394D98: nop

    after_116:
    // 0x80394D9C: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80394DA0: addiu       $t9, $t9, 0x6730
    ctx->r25 = ADD32(ctx->r25, 0X6730);
    // 0x80394DA4: lw          $at, 0x0($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X0);
    // 0x80394DA8: lw          $t7, 0x4($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X4);
    // 0x80394DAC: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80394DB0: addiu       $t8, $t8, 0x683C
    ctx->r24 = ADD32(ctx->r24, 0X683C);
    // 0x80394DB4: sw          $at, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r1;
    // 0x80394DB8: sw          $t7, 0x4($t8)
    MEM_W(0X4, ctx->r24) = ctx->r15;
    // 0x80394DBC: lw          $t7, 0xC($t9)
    ctx->r15 = MEM_W(ctx->r25, 0XC);
    // 0x80394DC0: lw          $at, 0x8($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X8);
    // 0x80394DC4: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80394DC8: sw          $t7, 0xC($t8)
    MEM_W(0XC, ctx->r24) = ctx->r15;
    // 0x80394DCC: sw          $at, 0x8($t8)
    MEM_W(0X8, ctx->r24) = ctx->r1;
    // 0x80394DD0: lw          $at, 0x10($t9)
    ctx->r1 = MEM_W(ctx->r25, 0X10);
    // 0x80394DD4: lw          $t7, 0x14($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X14);
    // 0x80394DD8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80394DDC: sw          $at, 0x10($t8)
    MEM_W(0X10, ctx->r24) = ctx->r1;
    // 0x80394DE0: sw          $t7, 0x14($t8)
    MEM_W(0X14, ctx->r24) = ctx->r15;
    // 0x80394DE4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80394DE8: sb          $t6, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r14;
    // 0x80394DEC: sb          $t8, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r24;
    // 0x80394DF0: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80394DF4: jal         0x8039661C
    // 0x80394DF8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_117;
    // 0x80394DF8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_117:
    // 0x80394DFC: addiu       $t9, $zero, 0x8
    ctx->r25 = ADD32(0, 0X8);
    // 0x80394E00: sh          $t9, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r25;
    // 0x80394E04: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80394E08: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80394E0C: sh          $zero, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = 0;
    // 0x80394E10: sb          $t7, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r15;
    // 0x80394E14: sb          $t6, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r14;
    // 0x80394E18: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    // 0x80394E1C: sw          $zero, 0x0($s3)
    MEM_W(0X0, ctx->r19) = 0;
    // 0x80394E20: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80394E24: lh          $t9, 0x6716($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6716);
    // 0x80394E28: lb          $t8, 0xD($s2)
    ctx->r24 = MEM_B(ctx->r18, 0XD);
    // 0x80394E2C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80394E30: bne         $t8, $t9, L_80394E5C
    if (ctx->r24 != ctx->r25) {
        // 0x80394E34: nop
    
            goto L_80394E5C;
    }
    // 0x80394E34: nop

    // 0x80394E38: lb          $t7, 0xC($s2)
    ctx->r15 = MEM_B(ctx->r18, 0XC);
    // 0x80394E3C: lh          $t6, 0x6718($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X6718);
    // 0x80394E40: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80394E44: bne         $t7, $t6, L_80394E5C
    if (ctx->r15 != ctx->r14) {
        // 0x80394E48: nop
    
            goto L_80394E5C;
    }
    // 0x80394E48: nop

    // 0x80394E4C: lb          $t8, 0xE($s2)
    ctx->r24 = MEM_B(ctx->r18, 0XE);
    // 0x80394E50: lh          $t9, 0x671A($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X671A);
    // 0x80394E54: beq         $t8, $t9, L_80394E6C
    if (ctx->r24 == ctx->r25) {
        // 0x80394E58: nop
    
            goto L_80394E6C;
    }
    // 0x80394E58: nop

L_80394E5C:
    // 0x80394E5C: jal         0x80130C30
    // 0x80394E60: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    write_eeprom(rdram, ctx);
        goto after_118;
    // 0x80394E60: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_118:
    // 0x80394E64: jal         0x80133BA0
    // 0x80394E68: lb          $a0, 0xC($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XC);
    set_music_volume(rdram, ctx);
        goto after_119;
    // 0x80394E68: lb          $a0, 0xC($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XC);
    after_119:
L_80394E6C:
    // 0x80394E6C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80394E70: lb          $v0, 0x7DD5($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7DD5);
    // 0x80394E74: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80394E78: addiu       $t7, $zero, 0x7
    ctx->r15 = ADD32(0, 0X7);
    // 0x80394E7C: beq         $v0, $at, L_80394E90
    if (ctx->r2 == ctx->r1) {
        // 0x80394E80: addiu       $t6, $zero, 0x1
        ctx->r14 = ADD32(0, 0X1);
            goto L_80394E90;
    }
    // 0x80394E80: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80394E84: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80394E88: bnel        $v0, $at, L_8039503C
    if (ctx->r2 != ctx->r1) {
        // 0x80394E8C: or          $a0, $s7, $zero
        ctx->r4 = ctx->r23 | 0;
            goto L_8039503C;
    }
    goto skip_30;
    // 0x80394E8C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    skip_30:
L_80394E90:
    // 0x80394E90: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80394E94: sb          $t6, 0x2A($s0)
    MEM_B(0X2A, ctx->r16) = ctx->r14;
    // 0x80394E98: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80394E9C: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x80394EA0: jal         0x8039661C
    // 0x80394EA4: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8039661C_7A7CCC(rdram, ctx);
        goto after_120;
    // 0x80394EA4: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_120:
    // 0x80394EA8: b           L_8039503C
    // 0x80394EAC: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_8039503C;
    // 0x80394EAC: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80394EB0:
    // 0x80394EB0: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80394EB4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80394EB8: jal         0x8013307C
    // 0x80394EBC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_121;
    // 0x80394EBC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_121:
    // 0x80394EC0: b           L_80395038
    // 0x80394EC4: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
        goto L_80395038;
    // 0x80394EC4: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
L_80394EC8:
    // 0x80394EC8: lbu         $t9, 0x31($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X31);
    // 0x80394ECC: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x80394ED0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394ED4: bne         $t9, $zero, L_80394EFC
    if (ctx->r25 != 0) {
        // 0x80394ED8: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394EFC;
    }
    // 0x80394ED8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394EDC: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x80394EE0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80394EE4: jal         0x8013307C
    // 0x80394EE8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_122;
    // 0x80394EE8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_122:
    // 0x80394EEC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80394EF0: sb          $t6, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r14;
    // 0x80394EF4: b           L_80395038
    // 0x80394EF8: sb          $zero, 0x32($s0)
    MEM_B(0X32, ctx->r16) = 0;
        goto L_80395038;
    // 0x80394EF8: sb          $zero, 0x32($s0)
    MEM_B(0X32, ctx->r16) = 0;
L_80394EFC:
    // 0x80394EFC: lbu         $t8, 0x32($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X32);
    // 0x80394F00: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x80394F04: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394F08: bne         $s4, $t8, L_80394F98
    if (ctx->r20 != ctx->r24) {
        // 0x80394F0C: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394F98;
    }
    // 0x80394F0C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394F10: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80394F14: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x80394F18: sw          $zero, 0x4D2C($at)
    MEM_W(0X4D2C, ctx->r1) = 0;
    // 0x80394F1C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80394F20: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80394F24: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394F28: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394F2C: jal         0x8013307C
    // 0x80394F30: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_123;
    // 0x80394F30: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_123:
    // 0x80394F34: addiu       $t7, $zero, 0x1E
    ctx->r15 = ADD32(0, 0X1E);
    // 0x80394F38: sh          $t7, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r15;
    // 0x80394F3C: sb          $zero, 0x29($s0)
    MEM_B(0X29, ctx->r16) = 0;
    // 0x80394F40: sw          $zero, 0x0($s3)
    MEM_W(0X0, ctx->r19) = 0;
    // 0x80394F44: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80394F48: lh          $t8, 0x6716($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X6716);
    // 0x80394F4C: lb          $t6, 0xD($s2)
    ctx->r14 = MEM_B(ctx->r18, 0XD);
    // 0x80394F50: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80394F54: bne         $t6, $t8, L_80394F80
    if (ctx->r14 != ctx->r24) {
        // 0x80394F58: nop
    
            goto L_80394F80;
    }
    // 0x80394F58: nop

    // 0x80394F5C: lb          $t9, 0xC($s2)
    ctx->r25 = MEM_B(ctx->r18, 0XC);
    // 0x80394F60: lh          $t7, 0x6718($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6718);
    // 0x80394F64: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80394F68: bne         $t9, $t7, L_80394F80
    if (ctx->r25 != ctx->r15) {
        // 0x80394F6C: nop
    
            goto L_80394F80;
    }
    // 0x80394F6C: nop

    // 0x80394F70: lb          $t6, 0xE($s2)
    ctx->r14 = MEM_B(ctx->r18, 0XE);
    // 0x80394F74: lh          $t8, 0x671A($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X671A);
    // 0x80394F78: beql        $t6, $t8, L_8039503C
    if (ctx->r14 == ctx->r24) {
        // 0x80394F7C: or          $a0, $s7, $zero
        ctx->r4 = ctx->r23 | 0;
            goto L_8039503C;
    }
    goto skip_31;
    // 0x80394F7C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    skip_31:
L_80394F80:
    // 0x80394F80: jal         0x80130C30
    // 0x80394F84: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    write_eeprom(rdram, ctx);
        goto after_124;
    // 0x80394F84: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_124:
    // 0x80394F88: jal         0x80133BA0
    // 0x80394F8C: lb          $a0, 0xC($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XC);
    set_music_volume(rdram, ctx);
        goto after_125;
    // 0x80394F8C: lb          $a0, 0xC($s2)
    ctx->r4 = MEM_B(ctx->r18, 0XC);
    after_125:
    // 0x80394F90: b           L_8039503C
    // 0x80394F94: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_8039503C;
    // 0x80394F94: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80394F98:
    // 0x80394F98: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x80394F9C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80394FA0: jal         0x8013307C
    // 0x80394FA4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_126;
    // 0x80394FA4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_126:
    // 0x80394FA8: b           L_80395038
    // 0x80394FAC: sb          $zero, 0x31($s0)
    MEM_B(0X31, ctx->r16) = 0;
        goto L_80395038;
    // 0x80394FAC: sb          $zero, 0x31($s0)
    MEM_B(0X31, ctx->r16) = 0;
L_80394FB0:
    // 0x80394FB0: lbu         $t7, 0x33($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X33);
    // 0x80394FB4: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x80394FB8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394FBC: bne         $t7, $zero, L_80394FE4
    if (ctx->r15 != 0) {
        // 0x80394FC0: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80394FE4;
    }
    // 0x80394FC0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394FC4: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80394FC8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80394FCC: jal         0x8013307C
    // 0x80394FD0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_127;
    // 0x80394FD0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_127:
    // 0x80394FD4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80394FD8: sb          $t8, 0x33($s0)
    MEM_B(0X33, ctx->r16) = ctx->r24;
    // 0x80394FDC: b           L_80395038
    // 0x80394FE0: sb          $zero, 0x34($s0)
    MEM_B(0X34, ctx->r16) = 0;
        goto L_80395038;
    // 0x80394FE0: sb          $zero, 0x34($s0)
    MEM_B(0X34, ctx->r16) = 0;
L_80394FE4:
    // 0x80394FE4: lbu         $t9, 0x34($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X34);
    // 0x80394FE8: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x80394FEC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80394FF0: bne         $s4, $t9, L_80395024
    if (ctx->r20 != ctx->r25) {
        // 0x80394FF4: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80395024;
    }
    // 0x80394FF4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80394FF8: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x80394FFC: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80395000: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x80395004: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80395008: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039500C: jal         0x8013307C
    // 0x80395010: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_128;
    // 0x80395010: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_128:
    // 0x80395014: jal         0x8038F708
    // 0x80395018: nop

    func_8038F708_7A0DB8(rdram, ctx);
        goto after_129;
    // 0x80395018: nop

    after_129:
    // 0x8039501C: b           L_8039503C
    // 0x80395020: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_8039503C;
    // 0x80395020: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80395024:
    // 0x80395024: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80395028: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039502C: jal         0x8013307C
    // 0x80395030: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_130;
    // 0x80395030: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_130:
    // 0x80395034: sb          $zero, 0x33($s0)
    MEM_B(0X33, ctx->r16) = 0;
L_80395038:
    // 0x80395038: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_8039503C:
    sssv_file_select_layout_hook(rdram, ctx, 1);
    // 0x8039503C: jal         0x8039D034
    // 0x80395040: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_8039D034_7AE6E4(rdram, ctx);
        goto after_131;
    // 0x80395040: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_131:
    // 0x80395044: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_80395048:
    sssv_file_select_layout_hook(rdram, ctx, 3);
    // 0x80395048: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8039504C: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x80395050: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x80395054: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x80395058: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x8039505C: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x80395060: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x80395064: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x80395068: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x8039506C: jr          $ra
    // 0x80395070: addiu       $sp, $sp, 0x1B0
    ctx->r29 = ADD32(ctx->r29, 0X1B0);
    return;
    // 0x80395070: addiu       $sp, $sp, 0x1B0
    ctx->r29 = ADD32(ctx->r29, 0X1B0);
;}
RECOMP_FUNC void func_80395074_7A6724(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395074: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x80395078: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8039507C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80395080: jr          $ra
    // 0x80395084: sh          $t6, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r14;
    return;
    // 0x80395084: sh          $t6, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r14;
;}
