#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void display_score(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801304EC: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x801304F0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x801304F4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x801304F8: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x801304FC: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80130500: swc1        $f0, -0xE08($at)
    MEM_W(-0XE08, ctx->r1) = ctx->f0.u32l;
    // 0x80130504: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x80130508: sw          $fp, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r30;
    // 0x8013050C: sw          $s7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r23;
    // 0x80130510: sw          $s6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r22;
    // 0x80130514: sw          $s5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r21;
    // 0x80130518: sw          $s4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r20;
    // 0x8013051C: sw          $s3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r19;
    // 0x80130520: sw          $s2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r18;
    // 0x80130524: sw          $s1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r17;
    // 0x80130528: sw          $s0, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r16;
    // 0x8013052C: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x80130530: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x80130534: swc1        $f0, -0xE04($at)
    MEM_W(-0XE04, ctx->r1) = ctx->f0.u32l;
    // 0x80130538: lbu         $t6, 0x0($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X0);
    // 0x8013053C: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x80130540: andi        $s2, $a2, 0xFFFF
    ctx->r18 = ctx->r6 & 0XFFFF;
    // 0x80130544: andi        $s3, $a3, 0xFFFF
    ctx->r19 = ctx->r7 & 0XFFFF;
    // 0x80130548: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x8013054C: beq         $t6, $zero, L_80130594
    if (ctx->r14 == 0) {
        // 0x80130550: or          $s1, $zero, $zero
        ctx->r17 = 0 | 0;
            goto L_80130594;
    }
    // 0x80130550: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80130554: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80130558: addiu       $t0, $t0, -0xE20
    ctx->r8 = ADD32(ctx->r8, -0XE20);
    // 0x8013055C: andi        $v1, $t6, 0xFF
    ctx->r3 = ctx->r14 & 0XFF;
L_80130560:
    // 0x80130560: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80130564: addiu       $a3, $v1, -0x20
    ctx->r7 = ADD32(ctx->r3, -0X20);
    // 0x80130568: andi        $t7, $a3, 0xFF
    ctx->r15 = ctx->r7 & 0XFF;
    // 0x8013056C: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x80130570: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x80130574: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x80130578: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x8013057C: lbu         $v1, 0x1($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X1);
    // 0x80130580: addiu       $s1, $s1, 0x10
    ctx->r17 = ADD32(ctx->r17, 0X10);
    // 0x80130584: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x80130588: sra         $s1, $t6, 16
    ctx->r17 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8013058C: bne         $v1, $zero, L_80130560
    if (ctx->r3 != 0) {
        // 0x80130590: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_80130560;
    }
    // 0x80130590: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_80130594:
    // 0x80130594: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130598: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x8013059C: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x801305A0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801305A4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801305A8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801305AC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x801305B0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801305B4: ori         $t9, $t9, 0x1402
    ctx->r25 = ctx->r25 | 0X1402;
    // 0x801305B8: lui         $t7, 0xFCFF
    ctx->r15 = S32(0XFCFF << 16);
    // 0x801305BC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x801305C0: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x801305C4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801305C8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x801305CC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801305D0: lui         $t8, 0xFFFC
    ctx->r24 = S32(0XFFFC << 16);
    // 0x801305D4: ori         $t8, $t8, 0xF279
    ctx->r24 = ctx->r24 | 0XF279;
    // 0x801305D8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801305DC: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801305E0: ori         $t7, $t7, 0xFFFF
    ctx->r15 = ctx->r15 | 0XFFFF;
    // 0x801305E4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x801305E8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x801305EC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801305F0: lui         $t7, 0x55
    ctx->r15 = S32(0X55 << 16);
    // 0x801305F4: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x801305F8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x801305FC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80130600: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x80130604: ori         $t7, $t7, 0x2220
    ctx->r15 = ctx->r15 | 0X2220;
    // 0x80130608: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8013060C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80130610: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130614: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x80130618: ori         $t9, $t9, 0x201
    ctx->r25 = ctx->r25 | 0X201;
    // 0x8013061C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80130620: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80130624: addiu       $t6, $zero, 0x4
    ctx->r14 = ADD32(0, 0X4);
    // 0x80130628: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8013062C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80130630: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130634: lui         $t8, 0xEE00
    ctx->r24 = S32(0XEE00 << 16);
    // 0x80130638: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x8013063C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80130640: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80130644: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130648: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8013064C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130650: ori         $t6, $t6, 0x1301
    ctx->r14 = ctx->r14 | 0X1301;
    // 0x80130654: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x80130658: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8013065C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80130660: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130664: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80130668: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8013066C: ori         $t8, $t8, 0xE02
    ctx->r24 = ctx->r24 | 0XE02;
    // 0x80130670: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x80130674: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80130678: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8013067C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130680: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80130684: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130688: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x8013068C: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80130690: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80130694: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80130698: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8013069C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x801306A0: lbu         $v1, 0x0($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X0);
    // 0x801306A4: addiu       $t0, $t0, -0xE20
    ctx->r8 = ADD32(ctx->r8, -0XE20);
    // 0x801306A8: lui         $ra, 0xF300
    ctx->r31 = S32(0XF300 << 16);
    // 0x801306AC: beq         $v1, $zero, L_8013086C
    if (ctx->r3 == 0) {
        // 0x801306B0: lui         $fp, 0xE600
        ctx->r30 = S32(0XE600 << 16);
            goto L_8013086C;
    }
    // 0x801306B0: lui         $fp, 0xE600
    ctx->r30 = S32(0XE600 << 16);
    // 0x801306B4: lui         $s7, 0x701
    ctx->r23 = S32(0X701 << 16);
    // 0x801306B8: lui         $s5, 0x8016
    ctx->r21 = S32(0X8016 << 16);
    // 0x801306BC: addiu       $s5, $s5, -0x7AB0
    ctx->r21 = ADD32(ctx->r21, -0X7AB0);
    // 0x801306C0: ori         $s7, $s7, 0x40
    ctx->r23 = ctx->r23 | 0X40;
    // 0x801306C4: lui         $s6, 0xF510
    ctx->r22 = S32(0XF510 << 16);
    // 0x801306C8: lui         $s4, 0xFD10
    ctx->r20 = S32(0XFD10 << 16);
    // 0x801306CC: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
L_801306D0:
    // 0x801306D0: addiu       $a3, $v1, -0x20
    ctx->r7 = ADD32(ctx->r3, -0X20);
    // 0x801306D4: andi        $t7, $a3, 0xFF
    ctx->r15 = ctx->r7 & 0XFF;
    // 0x801306D8: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x801306DC: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x801306E0: beq         $t7, $zero, L_80130844
    if (ctx->r15 == 0) {
        // 0x801306E4: sw          $t9, 0x0($t0)
        MEM_W(0X0, ctx->r8) = ctx->r25;
            goto L_80130844;
    }
    // 0x801306E4: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x801306E8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801306EC: sll         $t7, $t7, 8
    ctx->r15 = S32(ctx->r15 << 8);
    // 0x801306F0: addiu       $t8, $t7, -0x1000
    ctx->r24 = ADD32(ctx->r15, -0X1000);
    // 0x801306F4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801306F8: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801306FC: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80130700: addu        $t6, $s5, $t9
    ctx->r14 = ADD32(ctx->r21, ctx->r25);
    // 0x80130704: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80130708: sw          $s4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r20;
    // 0x8013070C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130710: addiu       $t4, $s3, 0x10
    ctx->r12 = ADD32(ctx->r19, 0X10);
    // 0x80130714: sll         $t6, $t4, 2
    ctx->r14 = S32(ctx->r12 << 2);
    // 0x80130718: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8013071C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80130720: sw          $s7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r23;
    // 0x80130724: sw          $s6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r22;
    // 0x80130728: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8013072C: andi        $t4, $t6, 0xFFF
    ctx->r12 = ctx->r14 & 0XFFF;
    // 0x80130730: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80130734: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80130738: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8013073C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130740: sw          $fp, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r30;
    // 0x80130744: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130748: sll         $t5, $s3, 2
    ctx->r13 = S32(ctx->r19 << 2);
    // 0x8013074C: andi        $t8, $t5, 0xFFF
    ctx->r24 = ctx->r13 & 0XFFF;
    // 0x80130750: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80130754: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80130758: lui         $t9, 0x70F
    ctx->r25 = S32(0X70F << 16);
    // 0x8013075C: ori         $t9, $t9, 0xF200
    ctx->r25 = ctx->r25 | 0XF200;
    // 0x80130760: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80130764: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80130768: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8013076C: or          $t5, $t8, $zero
    ctx->r13 = ctx->r24 | 0;
    // 0x80130770: lui         $t9, 0xF510
    ctx->r25 = S32(0XF510 << 16);
    // 0x80130774: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80130778: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8013077C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130780: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80130784: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130788: lui         $t6, 0x1
    ctx->r14 = S32(0X1 << 16);
    // 0x8013078C: ori         $t6, $t6, 0x40
    ctx->r14 = ctx->r14 | 0X40;
    // 0x80130790: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80130794: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80130798: ori         $t9, $t9, 0x800
    ctx->r25 = ctx->r25 | 0X800;
    // 0x8013079C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x801307A0: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x801307A4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801307A8: lui         $t9, 0x3
    ctx->r25 = S32(0X3 << 16);
    // 0x801307AC: ori         $t9, $t9, 0xC03C
    ctx->r25 = ctx->r25 | 0XC03C;
    // 0x801307B0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x801307B4: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x801307B8: lui         $t8, 0xF200
    ctx->r24 = S32(0XF200 << 16);
    // 0x801307BC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x801307C0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x801307C4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801307C8: subu        $t3, $s2, $s1
    ctx->r11 = SUB32(ctx->r18, ctx->r17);
    // 0x801307CC: addiu       $t7, $t3, 0x18
    ctx->r15 = ADD32(ctx->r11, 0X18);
    // 0x801307D0: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x801307D4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801307D8: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801307DC: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x801307E0: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x801307E4: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x801307E8: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x801307EC: or          $t8, $t7, $t4
    ctx->r24 = ctx->r15 | ctx->r12;
    // 0x801307F0: addiu       $t9, $t3, 0x8
    ctx->r25 = ADD32(ctx->r11, 0X8);
    // 0x801307F4: sll         $t6, $t9, 2
    ctx->r14 = S32(ctx->r25 << 2);
    // 0x801307F8: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x801307FC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80130800: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x80130804: or          $t9, $t8, $t5
    ctx->r25 = ctx->r24 | ctx->r13;
    // 0x80130808: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8013080C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130810: lui         $t7, 0xB400
    ctx->r15 = S32(0XB400 << 16);
    // 0x80130814: lui         $t9, 0xB300
    ctx->r25 = S32(0XB300 << 16);
    // 0x80130818: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8013081C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80130820: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130824: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80130828: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8013082C: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80130830: ori         $t6, $t6, 0x400
    ctx->r14 = ctx->r14 | 0X400;
    // 0x80130834: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80130838: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8013083C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80130840: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
L_80130844:
    // 0x80130844: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80130848: addiu       $s2, $s2, 0x10
    ctx->r18 = ADD32(ctx->r18, 0X10);
    // 0x8013084C: andi        $t7, $s2, 0xFFFF
    ctx->r15 = ctx->r18 & 0XFFFF;
    // 0x80130850: subu        $t9, $t8, $a3
    ctx->r25 = SUB32(ctx->r24, ctx->r7);
    // 0x80130854: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x80130858: lbu         $v1, 0x1($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X1);
    // 0x8013085C: or          $s2, $t7, $zero
    ctx->r18 = ctx->r15 | 0;
    // 0x80130860: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80130864: bnel        $v1, $zero, L_801306D0
    if (ctx->r3 != 0) {
        // 0x80130868: lw          $t8, 0x0($t0)
        ctx->r24 = MEM_W(ctx->r8, 0X0);
            goto L_801306D0;
    }
    goto skip_0;
    // 0x80130868: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    skip_0:
L_8013086C:
    // 0x8013086C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80130870: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80130874: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80130878: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8013087C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80130880: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80130884: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x80130888: lw          $fp, 0x28($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X28);
    // 0x8013088C: lw          $s7, 0x24($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X24);
    // 0x80130890: lw          $s6, 0x20($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X20);
    // 0x80130894: lw          $s5, 0x1C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X1C);
    // 0x80130898: lw          $s4, 0x18($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X18);
    // 0x8013089C: lw          $s3, 0x14($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X14);
    // 0x801308A0: lw          $s2, 0x10($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X10);
    // 0x801308A4: lw          $s1, 0xC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XC);
    // 0x801308A8: lw          $s0, 0x8($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X8);
    // 0x801308AC: jr          $ra
    // 0x801308B0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x801308B0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void prepare_text(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801308B4: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x801308B8: addiu       $t7, $zero, 0x7530
    ctx->r15 = ADD32(0, 0X7530);
    // 0x801308BC: beq         $v0, $zero, L_801308E0
    if (ctx->r2 == 0) {
        // 0x801308C0: andi        $v1, $v0, 0xFF
        ctx->r3 = ctx->r2 & 0XFF;
            goto L_801308E0;
    }
    // 0x801308C0: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
L_801308C4:
    // 0x801308C4: addiu       $t6, $v1, 0x110
    ctx->r14 = ADD32(ctx->r3, 0X110);
    // 0x801308C8: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
    // 0x801308CC: lbu         $v0, 0x1($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X1);
    // 0x801308D0: addiu       $a1, $a1, 0x2
    ctx->r5 = ADD32(ctx->r5, 0X2);
    // 0x801308D4: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x801308D8: bnel        $v0, $zero, L_801308C4
    if (ctx->r2 != 0) {
        // 0x801308DC: andi        $v1, $v0, 0xFF
        ctx->r3 = ctx->r2 & 0XFF;
            goto L_801308C4;
    }
    goto skip_0;
    // 0x801308DC: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
    skip_0:
L_801308E0:
    // 0x801308E0: jr          $ra
    // 0x801308E4: sh          $t7, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r15;
    return;
    // 0x801308E4: sh          $t7, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r15;
;}
RECOMP_FUNC void load_level_text_data(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801308E8: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x801308EC: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x801308F0: lh          $v0, 0x4260($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X4260);
    // 0x801308F4: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x801308F8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801308FC: sll         $s0, $a0, 16
    ctx->r16 = S32(ctx->r4 << 16);
    // 0x80130900: sll         $s1, $a1, 16
    ctx->r17 = S32(ctx->r5 << 16);
    // 0x80130904: sra         $t7, $s1, 16
    ctx->r15 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80130908: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8013090C: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80130910: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80130914: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80130918: or          $s5, $a2, $zero
    ctx->r21 = ctx->r6 | 0;
    // 0x8013091C: or          $s6, $a3, $zero
    ctx->r22 = ctx->r7 | 0;
    // 0x80130920: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x80130924: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x80130928: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8013092C: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80130930: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80130934: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80130938: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x8013093C: bne         $v0, $at, L_80130970
    if (ctx->r2 != ctx->r1) {
        // 0x80130940: sw          $a1, 0x3C($sp)
        MEM_W(0X3C, ctx->r29) = ctx->r5;
            goto L_80130970;
    }
    // 0x80130940: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x80130944: bgezl       $t6, L_80130954
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80130948: slti        $at, $s0, 0x9
        ctx->r1 = SIGNED(ctx->r16) < 0X9 ? 1 : 0;
            goto L_80130954;
    }
    goto skip_0;
    // 0x80130948: slti        $at, $s0, 0x9
    ctx->r1 = SIGNED(ctx->r16) < 0X9 ? 1 : 0;
    skip_0:
    // 0x8013094C: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
    // 0x80130950: slti        $at, $s0, 0x9
    ctx->r1 = SIGNED(ctx->r16) < 0X9 ? 1 : 0;
L_80130954:
    // 0x80130954: bnel        $at, $zero, L_80130964
    if (ctx->r1 != 0) {
        // 0x80130958: addiu       $at, $zero, 0x14
        ctx->r1 = ADD32(0, 0X14);
            goto L_80130964;
    }
    goto skip_1;
    // 0x80130958: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    skip_1:
    // 0x8013095C: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
    // 0x80130960: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
L_80130964:
    // 0x80130964: bnel        $s0, $at, L_80130974
    if (ctx->r16 != ctx->r1) {
        // 0x80130968: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80130974;
    }
    goto skip_2;
    // 0x80130968: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    skip_2:
    // 0x8013096C: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
L_80130970:
    // 0x80130970: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
L_80130974:
    // 0x80130974: bne         $v0, $at, L_80130980
    if (ctx->r2 != ctx->r1) {
        // 0x80130978: lui         $s3, 0x8023
        ctx->r19 = S32(0X8023 << 16);
            goto L_80130980;
    }
    // 0x80130978: lui         $s3, 0x8023
    ctx->r19 = S32(0X8023 << 16);
    // 0x8013097C: addiu       $s0, $zero, 0x2
    ctx->r16 = ADD32(0, 0X2);
L_80130980:
    // 0x80130980: bne         $v0, $zero, L_8013098C
    if (ctx->r2 != 0) {
        // 0x80130984: addiu       $s3, $s3, -0x1C10
        ctx->r19 = ADD32(ctx->r19, -0X1C10);
            goto L_8013098C;
    }
    // 0x80130984: addiu       $s3, $s3, -0x1C10
    ctx->r19 = ADD32(ctx->r19, -0X1C10);
    // 0x80130988: addiu       $s0, $zero, 0x6
    ctx->r16 = ADD32(0, 0X6);
L_8013098C:
    // 0x8013098C: sll         $t8, $s1, 2
    ctx->r24 = S32(ctx->r17 << 2);
    // 0x80130990: sll         $t9, $s1, 2
    ctx->r25 = S32(ctx->r17 << 2);
    // 0x80130994: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x80130998: addiu       $t1, $t1, 0x4500
    ctx->r9 = ADD32(ctx->r9, 0X4500);
    // 0x8013099C: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x801309A0: addu        $v0, $t0, $t1
    ctx->r2 = ADD32(ctx->r8, ctx->r9);
    // 0x801309A4: lw          $a0, 0x0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X0);
    // 0x801309A8: lw          $t2, 0x4($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X4);
    // 0x801309AC: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x801309B0: jal         0x80129290
    // 0x801309B4: subu        $a2, $t2, $a0
    ctx->r6 = SUB32(ctx->r10, ctx->r4);
    dma_read(rdram, ctx);
        goto after_0;
    // 0x801309B4: subu        $a2, $t2, $a0
    ctx->r6 = SUB32(ctx->r10, ctx->r4);
    after_0:
    // 0x801309B8: lui         $s1, 0x8023
    ctx->r17 = S32(0X8023 << 16);
    // 0x801309BC: addiu       $s1, $s1, 0x5410
    ctx->r17 = ADD32(ctx->r17, 0X5410);
    // 0x801309C0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x801309C4: jal         0x8012B0F0
    // 0x801309C8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    UnpackRNC(rdram, ctx);
        goto after_1;
    // 0x801309C8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    after_1:
    // 0x801309CC: sll         $t3, $s0, 2
    ctx->r11 = S32(ctx->r16 << 2);
    // 0x801309D0: addu        $t4, $s1, $t3
    ctx->r12 = ADD32(ctx->r17, ctx->r11);
    // 0x801309D4: lw          $t5, 0x0($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X0);
    // 0x801309D8: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x801309DC: addiu       $a2, $zero, 0x2EE0
    ctx->r6 = ADD32(0, 0X2EE0);
    // 0x801309E0: jal         0x80129158
    // 0x801309E4: addu        $a0, $s1, $t5
    ctx->r4 = ADD32(ctx->r17, ctx->r13);
    memcpy_sssv(rdram, ctx);
        goto after_2;
    // 0x801309E4: addu        $a0, $s1, $t5
    ctx->r4 = ADD32(ctx->r17, ctx->r13);
    after_2:
    // 0x801309E8: lh          $s4, 0x0($s3)
    ctx->r20 = MEM_H(ctx->r19, 0X0);
    // 0x801309EC: lui         $s0, 0x8023
    ctx->r16 = S32(0X8023 << 16);
    // 0x801309F0: addiu       $s0, $s0, -0x1C0E
    ctx->r16 = ADD32(ctx->r16, -0X1C0E);
    // 0x801309F4: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x801309F8: blez        $s4, L_80130A64
    if (SIGNED(ctx->r20) <= 0) {
        // 0x801309FC: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_80130A64;
    }
    // 0x801309FC: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_80130A00:
    // 0x80130A00: lh          $s3, 0x0($s0)
    ctx->r19 = MEM_H(ctx->r16, 0X0);
    // 0x80130A04: sll         $t6, $s1, 1
    ctx->r14 = S32(ctx->r17 << 1);
    // 0x80130A08: addiu       $s0, $s0, 0x2
    ctx->r16 = ADD32(ctx->r16, 0X2);
    // 0x80130A0C: addu        $t7, $s5, $t6
    ctx->r15 = ADD32(ctx->r21, ctx->r14);
    // 0x80130A10: sll         $t8, $s2, 1
    ctx->r24 = S32(ctx->r18 << 1);
    // 0x80130A14: sh          $s2, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r18;
    // 0x80130A18: addu        $a1, $t8, $s6
    ctx->r5 = ADD32(ctx->r24, ctx->r22);
    // 0x80130A1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80130A20: jal         0x80129158
    // 0x80130A24: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_3;
    // 0x80130A24: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_3:
    // 0x80130A28: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x80130A2C: sll         $t3, $s1, 16
    ctx->r11 = S32(ctx->r17 << 16);
    // 0x80130A30: addu        $s2, $s2, $s3
    ctx->r18 = ADD32(ctx->r18, ctx->r19);
    // 0x80130A34: sra         $s1, $t3, 16
    ctx->r17 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80130A38: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x80130A3C: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80130A40: or          $s2, $t0, $zero
    ctx->r18 = ctx->r8 | 0;
    // 0x80130A44: bgez        $s3, L_80130A54
    if (SIGNED(ctx->r19) >= 0) {
        // 0x80130A48: sra         $t1, $s3, 1
        ctx->r9 = S32(SIGNED(ctx->r19) >> 1);
            goto L_80130A54;
    }
    // 0x80130A48: sra         $t1, $s3, 1
    ctx->r9 = S32(SIGNED(ctx->r19) >> 1);
    // 0x80130A4C: addiu       $at, $s3, 0x1
    ctx->r1 = ADD32(ctx->r19, 0X1);
    // 0x80130A50: sra         $t1, $at, 1
    ctx->r9 = S32(SIGNED(ctx->r1) >> 1);
L_80130A54:
    // 0x80130A54: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x80130A58: sll         $t2, $t1, 1
    ctx->r10 = S32(ctx->r9 << 1);
    // 0x80130A5C: bne         $at, $zero, L_80130A00
    if (ctx->r1 != 0) {
        // 0x80130A60: addu        $s0, $s0, $t2
        ctx->r16 = ADD32(ctx->r16, ctx->r10);
            goto L_80130A00;
    }
    // 0x80130A60: addu        $s0, $s0, $t2
    ctx->r16 = ADD32(ctx->r16, ctx->r10);
L_80130A64:
    // 0x80130A64: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80130A68: or          $v0, $s4, $zero
    ctx->r2 = ctx->r20 | 0;
    // 0x80130A6C: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80130A70: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80130A74: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80130A78: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80130A7C: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80130A80: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80130A84: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80130A88: jr          $ra
    // 0x80130A8C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x80130A8C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void get_message_address_by_id(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130A90: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80130A94: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80130A98: lui         $v1, 0x8023
    ctx->r3 = S32(0X8023 << 16);
    // 0x80130A9C: addiu       $v1, $v1, -0x1C10
    ctx->r3 = ADD32(ctx->r3, -0X1C10);
    // 0x80130AA0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80130AA4: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x80130AA8: lh          $t0, 0x36B0($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X36B0);
    // 0x80130AAC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80130AB0: sll         $t1, $t0, 1
    ctx->r9 = S32(ctx->r8 << 1);
    // 0x80130AB4: addu        $v0, $v1, $t1
    ctx->r2 = ADD32(ctx->r3, ctx->r9);
    // 0x80130AB8: jr          $ra
    // 0x80130ABC: addiu       $v0, $v0, 0x396C
    ctx->r2 = ADD32(ctx->r2, 0X396C);
    return;
    // 0x80130ABC: addiu       $v0, $v0, 0x396C
    ctx->r2 = ADD32(ctx->r2, 0X396C);
;}
RECOMP_FUNC void get_raw_message_length(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130AC0: lh          $t6, 0x0($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X0);
    // 0x80130AC4: addiu       $v0, $zero, 0x7530
    ctx->r2 = ADD32(0, 0X7530);
    // 0x80130AC8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80130ACC: beq         $v0, $t6, L_80130AEC
    if (ctx->r2 == ctx->r14) {
        // 0x80130AD0: nop
    
            goto L_80130AEC;
    }
    // 0x80130AD0: nop

L_80130AD4:
    // 0x80130AD4: lh          $t9, 0x2($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X2);
    // 0x80130AD8: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80130ADC: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x80130AE0: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80130AE4: bne         $v0, $t9, L_80130AD4
    if (ctx->r2 != ctx->r25) {
        // 0x80130AE8: addiu       $a0, $a0, 0x2
        ctx->r4 = ADD32(ctx->r4, 0X2);
            goto L_80130AD4;
    }
    // 0x80130AE8: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
L_80130AEC:
    // 0x80130AEC: jr          $ra
    // 0x80130AF0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80130AF0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void font_init(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130B00: lui         $t6, 0x13
    ctx->r14 = S32(0X13 << 16);
    // 0x80130B04: lui         $t7, 0x13
    ctx->r15 = S32(0X13 << 16);
    // 0x80130B08: lui         $t8, 0x800F
    ctx->r24 = S32(0X800F << 16);
    // 0x80130B0C: lui         $t9, 0x800E
    ctx->r25 = S32(0X800E << 16);
    // 0x80130B10: addiu       $t9, $t9, 0x1220
    ctx->r25 = ADD32(ctx->r25, 0X1220);
    // 0x80130B14: addiu       $t8, $t8, -0xF30
    ctx->r24 = ADD32(ctx->r24, -0XF30);
    // 0x80130B18: addiu       $t7, $t7, -0x5C70
    ctx->r15 = ADD32(ctx->r15, -0X5C70);
    // 0x80130B1C: addiu       $t6, $t6, -0x1240
    ctx->r14 = ADD32(ctx->r14, -0X1240);
    // 0x80130B20: subu        $a3, $t6, $t7
    ctx->r7 = SUB32(ctx->r14, ctx->r15);
    // 0x80130B24: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x80130B28: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80130B2C: sltu        $at, $a3, $t0
    ctx->r1 = ctx->r7 < ctx->r8 ? 1 : 0;
    // 0x80130B30: bne         $at, $zero, L_80130B5C
    if (ctx->r1 != 0) {
        // 0x80130B34: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_80130B5C;
    }
    // 0x80130B34: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80130B38: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80130B3C: lui         $a1, 0x8016
    ctx->r5 = S32(0X8016 << 16);
    // 0x80130B40: addiu       $a1, $a1, -0x52A4
    ctx->r5 = ADD32(ctx->r5, -0X52A4);
    // 0x80130B44: addiu       $a0, $a0, -0x52F0
    ctx->r4 = ADD32(ctx->r4, -0X52F0);
    // 0x80130B48: addiu       $a2, $zero, 0x4A
    ctx->r6 = ADD32(0, 0X4A);
    // 0x80130B4C: jal         0x8013966C
    // 0x80130B50: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    osSyncPrintf(rdram, ctx);
        goto after_0;
    // 0x80130B50: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    after_0:
    // 0x80130B54: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x80130B58: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_80130B5C:
    // 0x80130B5C: lui         $a1, 0x8023
    ctx->r5 = S32(0X8023 << 16);
    // 0x80130B60: addiu       $a1, $a1, -0x1C10
    ctx->r5 = ADD32(ctx->r5, -0X1C10);
    // 0x80130B64: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80130B68: lui         $a0, 0x13
    ctx->r4 = S32(0X13 << 16);
    // 0x80130B6C: sw          $a1, -0x6190($at)
    MEM_W(-0X6190, ctx->r1) = ctx->r5;
    // 0x80130B70: addiu       $a0, $a0, -0x5C70
    ctx->r4 = ADD32(ctx->r4, -0X5C70);
    // 0x80130B74: jal         0x80129290
    // 0x80130B78: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    dma_read(rdram, ctx);
        goto after_1;
    // 0x80130B78: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    after_1:
    // 0x80130B7C: lui         $a0, 0x8023
    ctx->r4 = S32(0X8023 << 16);
    // 0x80130B80: lui         $a1, 0x800E
    ctx->r5 = S32(0X800E << 16);
    // 0x80130B84: addiu       $a1, $a1, 0x1220
    ctx->r5 = ADD32(ctx->r5, 0X1220);
    // 0x80130B88: jal         0x8012B0F0
    // 0x80130B8C: addiu       $a0, $a0, -0x1C10
    ctx->r4 = ADD32(ctx->r4, -0X1C10);
    UnpackRNC(rdram, ctx);
        goto after_2;
    // 0x80130B8C: addiu       $a0, $a0, -0x1C10
    ctx->r4 = ADD32(ctx->r4, -0X1C10);
    after_2:
    // 0x80130B90: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80130B94: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80130B98: jr          $ra
    // 0x80130B9C: nop

    return;
    // 0x80130B9C: nop

;}
RECOMP_FUNC void func_80130BA0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130BA0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80130BA4: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_80130BA8:
    // 0x80130BA8: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x80130BAC: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80130BB0: sltiu       $at, $v0, 0x3C
    ctx->r1 = ctx->r2 < 0X3C ? 1 : 0;
    // 0x80130BB4: bnel        $at, $zero, L_80130BA8
    if (ctx->r1 != 0) {
        // 0x80130BB8: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_80130BA8;
    }
    goto skip_0;
    // 0x80130BB8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_0:
    // 0x80130BBC: jr          $ra
    // 0x80130BC0: nop

    return;
    // 0x80130BC0: nop

;}
RECOMP_FUNC void junk_eeprom(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130BC4: lui         $v1, 0x8024
    ctx->r3 = S32(0X8024 << 16);
    // 0x80130BC8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80130BCC: addiu       $v1, $v1, -0xD9C
    ctx->r3 = ADD32(ctx->r3, -0XD9C);
    // 0x80130BD0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80130BD4:
    // 0x80130BD4: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80130BD8: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80130BDC: sb          $v0, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r2;
    // 0x80130BE0: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80130BE4: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80130BE8: sltiu       $at, $a0, 0x3C
    ctx->r1 = ctx->r4 < 0X3C ? 1 : 0;
    // 0x80130BEC: andi        $t6, $v0, 0xFFFF
    ctx->r14 = ctx->r2 & 0XFFFF;
    // 0x80130BF0: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80130BF4: bne         $at, $zero, L_80130BD4
    if (ctx->r1 != 0) {
        // 0x80130BF8: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_80130BD4;
    }
    // 0x80130BF8: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x80130BFC: jr          $ra
    // 0x80130C00: nop

    return;
    // 0x80130C00: nop

;}
RECOMP_FUNC void clear_player_eeprom_state(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130C04: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80130C08: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80130C0C: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x80130C10: addiu       $a0, $a0, -0xDA0
    ctx->r4 = ADD32(ctx->r4, -0XDA0);
    // 0x80130C14: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80130C18: jal         0x80129090
    // 0x80130C1C: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memset_bytes(rdram, ctx);
        goto after_0;
    // 0x80130C1C: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_0:
    // 0x80130C20: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80130C24: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80130C28: jr          $ra
    // 0x80130C2C: nop

    return;
    // 0x80130C2C: nop

;}
RECOMP_FUNC void write_eeprom(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130C30: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80130C34: lw          $t6, 0x12D4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X12D4);
    // 0x80130C38: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80130C3C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80130C40: bne         $t6, $zero, L_80130C50
    if (ctx->r14 != 0) {
        // 0x80130C44: sw          $a0, 0x30($sp)
        MEM_W(0X30, ctx->r29) = ctx->r4;
            goto L_80130C50;
    }
    // 0x80130C44: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x80130C48: b           L_80130CC4
    // 0x80130C4C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80130CC4;
    // 0x80130C4C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80130C50:
    // 0x80130C50: lh          $t7, 0x32($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X32);
    // 0x80130C54: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80130C58: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x80130C5C: bne         $t7, $at, L_80130C70
    if (ctx->r15 != ctx->r1) {
        // 0x80130C60: addiu       $a2, $a2, -0xDA0
        ctx->r6 = ADD32(ctx->r6, -0XDA0);
            goto L_80130C70;
    }
    // 0x80130C60: addiu       $a2, $a2, -0xDA0
    ctx->r6 = ADD32(ctx->r6, -0XDA0);
    // 0x80130C64: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x80130C68: b           L_80130C70
    // 0x80130C6C: addiu       $a2, $a2, -0xD60
    ctx->r6 = ADD32(ctx->r6, -0XD60);
        goto L_80130C70;
    // 0x80130C6C: addiu       $a2, $a2, -0xD60
    ctx->r6 = ADD32(ctx->r6, -0XD60);
L_80130C70:
    // 0x80130C70: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    // 0x80130C74: jal         0x80130E10
    // 0x80130C78: sw          $a2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r6;
    eeprom_checksum(rdram, ctx);
        goto after_0;
    // 0x80130C78: sw          $a2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r6;
    after_0:
    // 0x80130C7C: lh          $v1, 0x32($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X32);
    // 0x80130C80: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80130C84: lw          $a2, 0x1C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X1C);
    // 0x80130C88: bne         $v1, $at, L_80130C9C
    if (ctx->r3 != ctx->r1) {
        // 0x80130C8C: lui         $a0, 0x8029
        ctx->r4 = S32(0X8029 << 16);
            goto L_80130C9C;
    }
    // 0x80130C8C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80130C90: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x80130C94: b           L_80130CA4
    // 0x80130C98: sw          $v0, -0xD60($at)
    MEM_W(-0XD60, ctx->r1) = ctx->r2;
        goto L_80130CA4;
    // 0x80130C98: sw          $v0, -0xD60($at)
    MEM_W(-0XD60, ctx->r1) = ctx->r2;
L_80130C9C:
    // 0x80130C9C: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x80130CA0: sw          $v0, -0xDA0($at)
    MEM_W(-0XDA0, ctx->r1) = ctx->r2;
L_80130CA4:
    // 0x80130CA4: sll         $a1, $v1, 6
    ctx->r5 = S32(ctx->r3 << 6);
    // 0x80130CA8: srl         $t8, $a1, 3
    ctx->r24 = S32(U32(ctx->r5) >> 3);
    // 0x80130CAC: andi        $a1, $t8, 0xFF
    ctx->r5 = ctx->r24 & 0XFF;
    // 0x80130CB0: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    // 0x80130CB4: jal         0x80139690
    // 0x80130CB8: addiu       $a3, $zero, 0x40
    ctx->r7 = ADD32(0, 0X40);
    osEepromLongWrite_recomp(rdram, ctx);
        goto after_1;
    // 0x80130CB8: addiu       $a3, $zero, 0x40
    ctx->r7 = ADD32(0, 0X40);
    after_1:
    // 0x80130CBC: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x80130CC0: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
L_80130CC4:
    // 0x80130CC4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80130CC8: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80130CCC: jr          $ra
    // 0x80130CD0: nop

    return;
    // 0x80130CD0: nop

;}
RECOMP_FUNC void read_eeprom(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130CD4: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80130CD8: lw          $t6, 0x12D4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X12D4);
    // 0x80130CDC: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80130CE0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80130CE4: bne         $t6, $zero, L_80130CF4
    if (ctx->r14 != 0) {
        // 0x80130CE8: sw          $a0, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r4;
            goto L_80130CF4;
    }
    // 0x80130CE8: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x80130CEC: b           L_80130E00
    // 0x80130CF0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80130E00;
    // 0x80130CF0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80130CF4:
    // 0x80130CF4: lh          $t7, 0x2A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2A);
    // 0x80130CF8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80130CFC: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80130D00: bne         $t7, $at, L_80130D14
    if (ctx->r15 != ctx->r1) {
        // 0x80130D04: addiu       $a0, $a0, -0x2F58
        ctx->r4 = ADD32(ctx->r4, -0X2F58);
            goto L_80130D14;
    }
    // 0x80130D04: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    // 0x80130D08: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80130D0C: b           L_80130D1C
    // 0x80130D10: addiu       $a2, $t0, -0xD60
    ctx->r6 = ADD32(ctx->r8, -0XD60);
        goto L_80130D1C;
    // 0x80130D10: addiu       $a2, $t0, -0xD60
    ctx->r6 = ADD32(ctx->r8, -0XD60);
L_80130D14:
    // 0x80130D14: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x80130D18: addiu       $a2, $a2, -0xDA0
    ctx->r6 = ADD32(ctx->r6, -0XDA0);
L_80130D1C:
    // 0x80130D1C: lh          $a1, 0x2A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2A);
    // 0x80130D20: addiu       $a3, $zero, 0x40
    ctx->r7 = ADD32(0, 0X40);
    // 0x80130D24: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    // 0x80130D28: sll         $t8, $a1, 6
    ctx->r24 = S32(ctx->r5 << 6);
    // 0x80130D2C: srl         $t9, $t8, 3
    ctx->r25 = S32(U32(ctx->r24) >> 3);
    // 0x80130D30: jal         0x80139780
    // 0x80130D34: andi        $a1, $t9, 0xFF
    ctx->r5 = ctx->r25 & 0XFF;
    osEepromLongRead_recomp(rdram, ctx);
        goto after_0;
    // 0x80130D34: andi        $a1, $t9, 0xFF
    ctx->r5 = ctx->r25 & 0XFF;
    after_0:
    // 0x80130D38: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x80130D3C: jal         0x80130E10
    // 0x80130D40: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    eeprom_checksum(rdram, ctx);
        goto after_1;
    // 0x80130D40: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    after_1:
    // 0x80130D44: lh          $t2, 0x2A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X2A);
    // 0x80130D48: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80130D4C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80130D50: bne         $t2, $at, L_80130DE4
    if (ctx->r10 != ctx->r1) {
        // 0x80130D54: addiu       $t0, $t0, -0xD60
        ctx->r8 = ADD32(ctx->r8, -0XD60);
            goto L_80130DE4;
    }
    // 0x80130D54: addiu       $t0, $t0, -0xD60
    ctx->r8 = ADD32(ctx->r8, -0XD60);
    // 0x80130D58: lb          $v1, 0xC($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XC);
    // 0x80130D5C: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x80130D60: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x80130D64: bgezl       $v1, L_80130D78
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80130D68: slti        $at, $v1, 0x14
        ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
            goto L_80130D78;
    }
    goto skip_0;
    // 0x80130D68: slti        $at, $v1, 0x14
    ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
    skip_0:
    // 0x80130D6C: sb          $a0, 0xC($t0)
    MEM_B(0XC, ctx->r8) = ctx->r4;
    // 0x80130D70: lb          $v1, 0xC($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XC);
    // 0x80130D74: slti        $at, $v1, 0x14
    ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
L_80130D78:
    // 0x80130D78: bne         $at, $zero, L_80130D84
    if (ctx->r1 != 0) {
        // 0x80130D7C: addiu       $a0, $zero, 0x10
        ctx->r4 = ADD32(0, 0X10);
            goto L_80130D84;
    }
    // 0x80130D7C: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x80130D80: sb          $a0, 0xC($t0)
    MEM_B(0XC, ctx->r8) = ctx->r4;
L_80130D84:
    // 0x80130D84: lb          $v1, 0xD($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XD);
    // 0x80130D88: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x80130D8C: bgezl       $v1, L_80130DA0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80130D90: slti        $at, $v1, 0x14
        ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
            goto L_80130DA0;
    }
    goto skip_1;
    // 0x80130D90: slti        $at, $v1, 0x14
    ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
    skip_1:
    // 0x80130D94: sb          $a0, 0xD($t0)
    MEM_B(0XD, ctx->r8) = ctx->r4;
    // 0x80130D98: lb          $v1, 0xD($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XD);
    // 0x80130D9C: slti        $at, $v1, 0x14
    ctx->r1 = SIGNED(ctx->r3) < 0X14 ? 1 : 0;
L_80130DA0:
    // 0x80130DA0: bnel        $at, $zero, L_80130DB0
    if (ctx->r1 != 0) {
        // 0x80130DA4: lb          $v1, 0xE($t0)
        ctx->r3 = MEM_B(ctx->r8, 0XE);
            goto L_80130DB0;
    }
    goto skip_2;
    // 0x80130DA4: lb          $v1, 0xE($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XE);
    skip_2:
    // 0x80130DA8: sb          $a0, 0xD($t0)
    MEM_B(0XD, ctx->r8) = ctx->r4;
    // 0x80130DAC: lb          $v1, 0xE($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XE);
L_80130DB0:
    // 0x80130DB0: slti        $at, $v1, 0x9
    ctx->r1 = SIGNED(ctx->r3) < 0X9 ? 1 : 0;
    // 0x80130DB4: bne         $at, $zero, L_80130DC4
    if (ctx->r1 != 0) {
        // 0x80130DB8: nop
    
            goto L_80130DC4;
    }
    // 0x80130DB8: nop

    // 0x80130DBC: sb          $t3, 0xE($t0)
    MEM_B(0XE, ctx->r8) = ctx->r11;
    // 0x80130DC0: lb          $v1, 0xE($t0)
    ctx->r3 = MEM_B(ctx->r8, 0XE);
L_80130DC4:
    // 0x80130DC4: bgezl       $v1, L_80130DD4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80130DC8: lw          $t5, 0x0($t0)
        ctx->r13 = MEM_W(ctx->r8, 0X0);
            goto L_80130DD4;
    }
    goto skip_3;
    // 0x80130DC8: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    skip_3:
    // 0x80130DCC: sb          $t4, 0xE($t0)
    MEM_B(0XE, ctx->r8) = ctx->r12;
    // 0x80130DD0: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
L_80130DD4:
    // 0x80130DD4: beql        $v0, $t5, L_80130E00
    if (ctx->r2 == ctx->r13) {
        // 0x80130DD8: lh          $v0, 0x26($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X26);
            goto L_80130E00;
    }
    goto skip_4;
    // 0x80130DD8: lh          $v0, 0x26($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X26);
    skip_4:
    // 0x80130DDC: b           L_80130E00
    // 0x80130DE0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80130E00;
    // 0x80130DE0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80130DE4:
    // 0x80130DE4: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x80130DE8: lw          $t6, -0xDA0($t6)
    ctx->r14 = MEM_W(ctx->r14, -0XDA0);
    // 0x80130DEC: beql        $v0, $t6, L_80130E00
    if (ctx->r2 == ctx->r14) {
        // 0x80130DF0: lh          $v0, 0x26($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X26);
            goto L_80130E00;
    }
    goto skip_5;
    // 0x80130DF0: lh          $v0, 0x26($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X26);
    skip_5:
    // 0x80130DF4: b           L_80130E00
    // 0x80130DF8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80130E00;
    // 0x80130DF8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80130DFC: lh          $v0, 0x26($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X26);
L_80130E00:
    // 0x80130E00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80130E04: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80130E08: jr          $ra
    // 0x80130E0C: nop

    return;
    // 0x80130E0C: nop

;}
RECOMP_FUNC void eeprom_checksum(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130E10: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80130E14: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
    // 0x80130E18: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80130E1C:
    // 0x80130E1C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80130E20: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80130E24: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x80130E28: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80130E2C: sltiu       $at, $v0, 0x3C
    ctx->r1 = ctx->r2 < 0X3C ? 1 : 0;
    // 0x80130E30: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80130E34: bne         $at, $zero, L_80130E1C
    if (ctx->r1 != 0) {
        // 0x80130E38: addu        $v1, $v1, $t6
        ctx->r3 = ADD32(ctx->r3, ctx->r14);
            goto L_80130E1C;
    }
    // 0x80130E38: addu        $v1, $v1, $t6
    ctx->r3 = ADD32(ctx->r3, ctx->r14);
    // 0x80130E3C: jr          $ra
    // 0x80130E40: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80130E40: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_80130E44(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80130E44: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80130E48: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80130E4C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80130E50: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x80130E54: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x80130E58: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80130E5C: sh          $zero, 0x28($sp)
    MEM_H(0X28, ctx->r29) = 0;
    // 0x80130E60: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_80130E64:
    // 0x80130E64: jal         0x80130CD4
    // 0x80130E68: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    read_eeprom(rdram, ctx);
        goto after_0;
    // 0x80130E68: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_0:
    // 0x80130E6C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80130E70: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80130E74: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x80130E78: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80130E7C: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80130E80: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x80130E84: beq         $v0, $zero, L_80130E98
    if (ctx->r2 == 0) {
        // 0x80130E88: or          $s0, $t8, $zero
        ctx->r16 = ctx->r24 | 0;
            goto L_80130E98;
    }
    // 0x80130E88: or          $s0, $t8, $zero
    ctx->r16 = ctx->r24 | 0;
    // 0x80130E8C: slti        $at, $t8, 0x4
    ctx->r1 = SIGNED(ctx->r24) < 0X4 ? 1 : 0;
    // 0x80130E90: bne         $at, $zero, L_80130E64
    if (ctx->r1 != 0) {
        // 0x80130E94: nop
    
            goto L_80130E64;
    }
    // 0x80130E94: nop

L_80130E98:
    // 0x80130E98: bne         $v1, $zero, L_80130EBC
    if (ctx->r3 != 0) {
        // 0x80130E9C: slti        $at, $s0, 0x4
        ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
            goto L_80130EBC;
    }
    // 0x80130E9C: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x80130EA0: beq         $at, $zero, L_80130EBC
    if (ctx->r1 == 0) {
        // 0x80130EA4: lui         $s1, 0x8024
        ctx->r17 = S32(0X8024 << 16);
            goto L_80130EBC;
    }
    // 0x80130EA4: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80130EA8: addiu       $s1, $s1, -0xD60
    ctx->r17 = ADD32(ctx->r17, -0XD60);
    // 0x80130EAC: lw          $t9, 0x4($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X4);
    // 0x80130EB0: lui         $at, 0xCF7
    ctx->r1 = S32(0XCF7 << 16);
    // 0x80130EB4: ori         $at, $at, 0x6F7E
    ctx->r1 = ctx->r1 | 0X6F7E;
    // 0x80130EB8: beq         $t9, $at, L_80130F54
    if (ctx->r25 == ctx->r1) {
        // 0x80130EBC: lui         $s1, 0x8024
        ctx->r17 = S32(0X8024 << 16);
            goto L_80130F54;
    }
L_80130EBC:
    // 0x80130EBC: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80130EC0: addiu       $s1, $s1, -0xD60
    ctx->r17 = ADD32(ctx->r17, -0XD60);
    // 0x80130EC4: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80130EC8: sh          $t0, 0x28($sp)
    MEM_H(0X28, ctx->r29) = ctx->r8;
    // 0x80130ECC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80130ED0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80130ED4: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    // 0x80130ED8: jal         0x80129090
    // 0x80130EDC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    memset_bytes(rdram, ctx);
        goto after_1;
    // 0x80130EDC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    after_1:
    // 0x80130EE0: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x80130EE4: lui         $t1, 0xCF7
    ctx->r9 = S32(0XCF7 << 16);
    // 0x80130EE8: ori         $t1, $t1, 0x6F7E
    ctx->r9 = ctx->r9 | 0X6F7E;
    // 0x80130EEC: sw          $t1, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r9;
    // 0x80130EF0: sb          $a0, 0xC($s1)
    MEM_B(0XC, ctx->r17) = ctx->r4;
    // 0x80130EF4: sb          $a0, 0xD($s1)
    MEM_B(0XD, ctx->r17) = ctx->r4;
    // 0x80130EF8: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80130EFC: lh          $v1, 0x4260($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X4260);
    // 0x80130F00: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80130F04: addiu       $t2, $zero, 0x14
    ctx->r10 = ADD32(0, 0X14);
    // 0x80130F08: bne         $a1, $v1, L_80130F18
    if (ctx->r5 != ctx->r3) {
        // 0x80130F0C: addiu       $t4, $zero, 0x1
        ctx->r12 = ADD32(0, 0X1);
            goto L_80130F18;
    }
    // 0x80130F0C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80130F10: b           L_80130F1C
    // 0x80130F14: sb          $a1, 0xE($s1)
    MEM_B(0XE, ctx->r17) = ctx->r5;
        goto L_80130F1C;
    // 0x80130F14: sb          $a1, 0xE($s1)
    MEM_B(0XE, ctx->r17) = ctx->r5;
L_80130F18:
    // 0x80130F18: sb          $t2, 0xE($s1)
    MEM_B(0XE, ctx->r17) = ctx->r10;
L_80130F1C:
    // 0x80130F1C: bne         $v1, $zero, L_80130F28
    if (ctx->r3 != 0) {
        // 0x80130F20: addiu       $t3, $zero, 0x6
        ctx->r11 = ADD32(0, 0X6);
            goto L_80130F28;
    }
    // 0x80130F20: addiu       $t3, $zero, 0x6
    ctx->r11 = ADD32(0, 0X6);
    // 0x80130F24: sb          $t3, 0xE($s1)
    MEM_B(0XE, ctx->r17) = ctx->r11;
L_80130F28:
    // 0x80130F28: sw          $t4, 0x8($s1)
    MEM_W(0X8, ctx->r17) = ctx->r12;
L_80130F2C:
    // 0x80130F2C: jal         0x80130C30
    // 0x80130F30: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    write_eeprom(rdram, ctx);
        goto after_2;
    // 0x80130F30: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    after_2:
    // 0x80130F34: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80130F38: sll         $t5, $s0, 16
    ctx->r13 = S32(ctx->r16 << 16);
    // 0x80130F3C: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80130F40: beq         $v0, $zero, L_80130F54
    if (ctx->r2 == 0) {
        // 0x80130F44: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_80130F54;
    }
    // 0x80130F44: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x80130F48: slti        $at, $t6, 0x4
    ctx->r1 = SIGNED(ctx->r14) < 0X4 ? 1 : 0;
    // 0x80130F4C: bne         $at, $zero, L_80130F2C
    if (ctx->r1 != 0) {
        // 0x80130F50: nop
    
            goto L_80130F2C;
    }
    // 0x80130F50: nop

L_80130F54:
    // 0x80130F54: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x80130F58: addiu       $s3, $s3, -0xDA0
    ctx->r19 = ADD32(ctx->r19, -0XDA0);
    // 0x80130F5C: addiu       $s1, $zero, 0x3
    ctx->r17 = ADD32(0, 0X3);
    // 0x80130F60: addiu       $s2, $zero, 0x4
    ctx->r18 = ADD32(0, 0X4);
    // 0x80130F64: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_80130F68:
    // 0x80130F68: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
L_80130F6C:
    // 0x80130F6C: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80130F70: jal         0x80130CD4
    // 0x80130F74: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    read_eeprom(rdram, ctx);
        goto after_3;
    // 0x80130F74: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_3:
    // 0x80130F78: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80130F7C: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80130F80: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x80130F84: sra         $t8, $v1, 16
    ctx->r24 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80130F88: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80130F8C: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x80130F90: beq         $v0, $zero, L_80130FA4
    if (ctx->r2 == 0) {
        // 0x80130F94: or          $s0, $t0, $zero
        ctx->r16 = ctx->r8 | 0;
            goto L_80130FA4;
    }
    // 0x80130F94: or          $s0, $t0, $zero
    ctx->r16 = ctx->r8 | 0;
    // 0x80130F98: slti        $at, $t0, 0x4
    ctx->r1 = SIGNED(ctx->r8) < 0X4 ? 1 : 0;
    // 0x80130F9C: bnel        $at, $zero, L_80130F6C
    if (ctx->r1 != 0) {
        // 0x80130FA0: sll         $a0, $s1, 16
        ctx->r4 = S32(ctx->r17 << 16);
            goto L_80130F6C;
    }
    goto skip_0;
    // 0x80130FA0: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    skip_0:
L_80130FA4:
    // 0x80130FA4: bne         $v1, $zero, L_80130FB4
    if (ctx->r3 != 0) {
        // 0x80130FA8: lh          $t1, 0x28($sp)
        ctx->r9 = MEM_H(ctx->r29, 0X28);
            goto L_80130FB4;
    }
    // 0x80130FA8: lh          $t1, 0x28($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X28);
    // 0x80130FAC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80130FB0: bne         $t1, $at, L_80131014
    if (ctx->r9 != ctx->r1) {
        // 0x80130FB4: lui         $a0, 0x8016
        ctx->r4 = S32(0X8016 << 16);
            goto L_80131014;
    }
L_80130FB4:
    // 0x80130FB4: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80130FB8: addiu       $a0, $a0, -0x5290
    ctx->r4 = ADD32(ctx->r4, -0X5290);
    // 0x80130FBC: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80130FC0: jal         0x8013966C
    // 0x80130FC4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    osSyncPrintf(rdram, ctx);
        goto after_4;
    // 0x80130FC4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    after_4:
    // 0x80130FC8: beq         $s1, $s2, L_80130FDC
    if (ctx->r17 == ctx->r18) {
        // 0x80130FCC: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_80130FDC;
    }
    // 0x80130FCC: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80130FD0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80130FD4: jal         0x80129090
    // 0x80130FD8: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memset_bytes(rdram, ctx);
        goto after_5;
    // 0x80130FD8: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_5:
L_80130FDC:
    // 0x80130FDC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
L_80130FE0:
    // 0x80130FE0: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80130FE4: jal         0x80130C30
    // 0x80130FE8: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    write_eeprom(rdram, ctx);
        goto after_6;
    // 0x80130FE8: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    after_6:
    // 0x80130FEC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80130FF0: sll         $t3, $s0, 16
    ctx->r11 = S32(ctx->r16 << 16);
    // 0x80130FF4: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80130FF8: beq         $v0, $zero, L_80131034
    if (ctx->r2 == 0) {
        // 0x80130FFC: or          $s0, $t4, $zero
        ctx->r16 = ctx->r12 | 0;
            goto L_80131034;
    }
    // 0x80130FFC: or          $s0, $t4, $zero
    ctx->r16 = ctx->r12 | 0;
    // 0x80131000: slti        $at, $t4, 0x4
    ctx->r1 = SIGNED(ctx->r12) < 0X4 ? 1 : 0;
    // 0x80131004: bnel        $at, $zero, L_80130FE0
    if (ctx->r1 != 0) {
        // 0x80131008: sll         $a0, $s1, 16
        ctx->r4 = S32(ctx->r17 << 16);
            goto L_80130FE0;
    }
    goto skip_1;
    // 0x80131008: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    skip_1:
    // 0x8013100C: b           L_80131038
    // 0x80131010: addiu       $s1, $s1, -0x1
    ctx->r17 = ADD32(ctx->r17, -0X1);
        goto L_80131038;
    // 0x80131010: addiu       $s1, $s1, -0x1
    ctx->r17 = ADD32(ctx->r17, -0X1);
L_80131014:
    // 0x80131014: beq         $s1, $s2, L_80131034
    if (ctx->r17 == ctx->r18) {
        // 0x80131018: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_80131034;
    }
    // 0x80131018: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8013101C: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x80131020: addiu       $t6, $t6, -0xD20
    ctx->r14 = ADD32(ctx->r14, -0XD20);
    // 0x80131024: sll         $t5, $s1, 6
    ctx->r13 = S32(ctx->r17 << 6);
    // 0x80131028: addu        $a1, $t5, $t6
    ctx->r5 = ADD32(ctx->r13, ctx->r14);
    // 0x8013102C: jal         0x80129158
    // 0x80131030: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_7;
    // 0x80131030: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_7:
L_80131034:
    // 0x80131034: addiu       $s1, $s1, -0x1
    ctx->r17 = ADD32(ctx->r17, -0X1);
L_80131038:
    // 0x80131038: sll         $t7, $s1, 16
    ctx->r15 = S32(ctx->r17 << 16);
    // 0x8013103C: sra         $s1, $t7, 16
    ctx->r17 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80131040: bgezl       $s1, L_80130F68
    if (SIGNED(ctx->r17) >= 0) {
        // 0x80131044: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_80130F68;
    }
    goto skip_2;
    // 0x80131044: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    skip_2:
    if (MEM_W(0, S32(0x8023F2A8)) & 1) {
    MEM_W(0, S32(0x8023F2A8)) &= ~1;
    recomp_context saved = *ctx;
    ctx->r4 = 4;
    write_eeprom(rdram, ctx);
    *ctx = saved;
}

    // 0x80131048: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8013104C: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80131050: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80131054: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x80131058: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x8013105C: jr          $ra
    // 0x80131060: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x80131060: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void reset_task_list(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131070: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x80131074: jr          $ra
    // 0x80131078: sh          $zero, -0xC20($at)
    MEM_H(-0XC20, ctx->r1) = 0;
    return;
    // 0x80131078: sh          $zero, -0xC20($at)
    MEM_H(-0XC20, ctx->r1) = 0;
;}
RECOMP_FUNC void func_8013107C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    sssv_submit_main_display_list(rdram, ctx);
    // 0x8013107C: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80131080: lhu         $t0, -0xC20($t0)
    ctx->r8 = MEM_HU(ctx->r8, -0XC20);
    // 0x80131084: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80131088: sll         $t6, $a3, 24
    ctx->r14 = S32(ctx->r7 << 24);
    // 0x8013108C: sll         $t1, $t0, 2
    ctx->r9 = S32(ctx->r8 << 2);
    // 0x80131090: subu        $t1, $t1, $t0
    ctx->r9 = SUB32(ctx->r9, ctx->r8);
    // 0x80131094: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x80131098: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x8013109C: sra         $t7, $t6, 24
    ctx->r15 = S32(SIGNED(ctx->r14) >> 24);
    // 0x801310A0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801310A4: addiu       $t9, $a0, 0x4E0
    ctx->r25 = ADD32(ctx->r4, 0X4E0);
    // 0x801310A8: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x801310AC: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x801310B0: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801310B4: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x801310B8: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x801310BC: sw          $t9, -0x6184($at)
    MEM_W(-0X6184, ctx->r1) = ctx->r25;
    // 0x801310C0: beq         $t7, $zero, L_801310E8
    if (ctx->r15 == 0) {
        // 0x801310C4: addu        $s0, $a0, $t1
        ctx->r16 = ADD32(ctx->r4, ctx->r9);
            goto L_801310E8;
    }
    // 0x801310C4: addu        $s0, $a0, $t1
    ctx->r16 = ADD32(ctx->r4, ctx->r9);
    // 0x801310C8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x801310CC: beq         $t7, $at, L_80131120
    if (ctx->r15 == ctx->r1) {
        // 0x801310D0: addiu       $t4, $zero, 0x6
        ctx->r12 = ADD32(0, 0X6);
            goto L_80131120;
    }
    // 0x801310D0: addiu       $t4, $zero, 0x6
    ctx->r12 = ADD32(0, 0X6);
    // 0x801310D4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x801310D8: beq         $t7, $at, L_80131174
    if (ctx->r15 == ctx->r1) {
        // 0x801310DC: addiu       $t1, $zero, 0x6
        ctx->r9 = ADD32(0, 0X6);
            goto L_80131174;
    }
    // 0x801310DC: addiu       $t1, $zero, 0x6
    ctx->r9 = ADD32(0, 0X6);
    // 0x801310E0: b           L_801311C4
    // 0x801310E4: nop

        goto L_801311C4;
    // 0x801310E4: nop

L_801310E8:
    // 0x801310E8: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x801310EC: lui         $t3, 0x8016
    ctx->r11 = S32(0X8016 << 16);
    // 0x801310F0: addiu       $t2, $t2, -0x2BA0
    ctx->r10 = ADD32(ctx->r10, -0X2BA0);
    // 0x801310F4: addiu       $t3, $t3, -0x4870
    ctx->r11 = ADD32(ctx->r11, -0X4870);
    // 0x801310F8: sw          $a1, 0x40($s0)
    MEM_W(0X40, ctx->r16) = ctx->r5;
    // 0x801310FC: sw          $a2, 0x44($s0)
    MEM_W(0X44, ctx->r16) = ctx->r6;
    // 0x80131100: sw          $zero, 0x14($s0)
    MEM_W(0X14, ctx->r16) = 0;
    // 0x80131104: sw          $t2, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r10;
    // 0x80131108: sw          $t3, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r11;
    // 0x8013110C: sw          $zero, 0x38($s0)
    MEM_W(0X38, ctx->r16) = 0;
    // 0x80131110: sw          $zero, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = 0;
    // 0x80131114: sw          $zero, 0x48($s0)
    MEM_W(0X48, ctx->r16) = 0;
    // 0x80131118: b           L_801311C4
    // 0x8013111C: sw          $zero, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = 0;
        goto L_801311C4;
    // 0x8013111C: sw          $zero, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = 0;
L_80131120:
    // 0x80131120: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80131124: lui         $t6, 0x8016
    ctx->r14 = S32(0X8016 << 16);
    // 0x80131128: lui         $t7, 0x800F
    ctx->r15 = S32(0X800F << 16);
    // 0x8013112C: lui         $t9, 0x8010
    ctx->r25 = S32(0X8010 << 16);
    // 0x80131130: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80131134: addiu       $t5, $t5, -0xE30
    ctx->r13 = ADD32(ctx->r13, -0XE30);
    // 0x80131138: addiu       $t6, $t6, -0x28F0
    ctx->r14 = ADD32(ctx->r14, -0X28F0);
    // 0x8013113C: addiu       $t7, $t7, -0xF30
    ctx->r15 = ADD32(ctx->r15, -0XF30);
    // 0x80131140: addiu       $t9, $t9, -0xF30
    ctx->r25 = ADD32(ctx->r25, -0XF30);
    // 0x80131144: addiu       $t0, $t0, 0x43E0
    ctx->r8 = ADD32(ctx->r8, 0X43E0);
    // 0x80131148: addiu       $t8, $zero, 0xC00
    ctx->r24 = ADD32(0, 0XC00);
    // 0x8013114C: sw          $a1, 0x40($s0)
    MEM_W(0X40, ctx->r16) = ctx->r5;
    // 0x80131150: sw          $a2, 0x44($s0)
    MEM_W(0X44, ctx->r16) = ctx->r6;
    // 0x80131154: sw          $t4, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r12;
    // 0x80131158: sw          $t5, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r13;
    // 0x8013115C: sw          $t6, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r14;
    // 0x80131160: sw          $t7, 0x38($s0)
    MEM_W(0X38, ctx->r16) = ctx->r15;
    // 0x80131164: sw          $t9, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = ctx->r25;
    // 0x80131168: sw          $t0, 0x48($s0)
    MEM_W(0X48, ctx->r16) = ctx->r8;
    // 0x8013116C: b           L_801311C4
    // 0x80131170: sw          $t8, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = ctx->r24;
        goto L_801311C4;
    // 0x80131170: sw          $t8, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = ctx->r24;
L_80131174:
    // 0x80131174: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x80131178: lui         $t3, 0x8016
    ctx->r11 = S32(0X8016 << 16);
    // 0x8013117C: lui         $t4, 0x800F
    ctx->r12 = S32(0X800F << 16);
    // 0x80131180: lui         $t5, 0x8010
    ctx->r13 = S32(0X8010 << 16);
    // 0x80131184: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x80131188: addiu       $t2, $t2, -0xE30
    ctx->r10 = ADD32(ctx->r10, -0XE30);
    // 0x8013118C: addiu       $t3, $t3, -0x28F0
    ctx->r11 = ADD32(ctx->r11, -0X28F0);
    // 0x80131190: addiu       $t4, $t4, -0xF30
    ctx->r12 = ADD32(ctx->r12, -0XF30);
    // 0x80131194: addiu       $t5, $t5, -0xF30
    ctx->r13 = ADD32(ctx->r13, -0XF30);
    // 0x80131198: addiu       $t6, $t6, 0x43E0
    ctx->r14 = ADD32(ctx->r14, 0X43E0);
    // 0x8013119C: addiu       $t7, $zero, 0xC00
    ctx->r15 = ADD32(0, 0XC00);
    // 0x801311A0: sw          $a1, 0x40($s0)
    MEM_W(0X40, ctx->r16) = ctx->r5;
    // 0x801311A4: sw          $a2, 0x44($s0)
    MEM_W(0X44, ctx->r16) = ctx->r6;
    // 0x801311A8: sw          $t1, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r9;
    // 0x801311AC: sw          $t2, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r10;
    // 0x801311B0: sw          $t3, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r11;
    // 0x801311B4: sw          $t4, 0x38($s0)
    MEM_W(0X38, ctx->r16) = ctx->r12;
    // 0x801311B8: sw          $t5, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = ctx->r13;
    // 0x801311BC: sw          $t6, 0x48($s0)
    MEM_W(0X48, ctx->r16) = ctx->r14;
    // 0x801311C0: sw          $t7, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = ctx->r15;
L_801311C4:
    // 0x801311C4: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x801311C8: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x801311CC: addiu       $v0, $v0, -0x2C70
    ctx->r2 = ADD32(ctx->r2, -0X2C70);
    // 0x801311D0: addiu       $t0, $t0, -0x2BA0
    ctx->r8 = ADD32(ctx->r8, -0X2BA0);
    // 0x801311D4: lui         $t3, 0x800E
    ctx->r11 = S32(0X800E << 16);
    // 0x801311D8: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x801311DC: subu        $t8, $t0, $v0
    ctx->r24 = SUB32(ctx->r8, ctx->r2);
    // 0x801311E0: addiu       $t1, $zero, 0x1000
    ctx->r9 = ADD32(0, 0X1000);
    // 0x801311E4: addiu       $t2, $zero, 0x800
    ctx->r10 = ADD32(0, 0X800);
    // 0x801311E8: addiu       $t3, $t3, -0x11E0
    ctx->r11 = ADD32(ctx->r11, -0X11E0);
    // 0x801311EC: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x801311F0: sw          $t9, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r25;
    // 0x801311F4: sw          $v0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r2;
    // 0x801311F8: sw          $t8, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r24;
    // 0x801311FC: sw          $t1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r9;
    // 0x80131200: sw          $t2, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = ctx->r10;
    // 0x80131204: sw          $t3, 0x30($s0)
    MEM_W(0X30, ctx->r16) = ctx->r11;
    // 0x80131208: sw          $t4, 0x34($s0)
    MEM_W(0X34, ctx->r16) = ctx->r12;
    // 0x8013120C: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
    // 0x80131210: lw          $t5, 0x34($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X34);
    // 0x80131214: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80131218: addiu       $t6, $t6, -0x2FA0
    ctx->r14 = ADD32(ctx->r14, -0X2FA0);
    // 0x8013121C: sw          $t6, 0x50($s0)
    MEM_W(0X50, ctx->r16) = ctx->r14;
    // 0x80131220: sw          $t5, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r13;
    // 0x80131224: lw          $t7, 0x30($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X30);
    // 0x80131228: lui         $t0, 0x4
    ctx->r8 = S32(0X4 << 16);
    // 0x8013122C: addiu       $a0, $zero, 0x3C0
    ctx->r4 = ADD32(0, 0X3C0);
    // 0x80131230: sw          $t7, 0x54($s0)
    MEM_W(0X54, ctx->r16) = ctx->r15;
    // 0x80131234: lw          $t9, 0x20($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X20);
    // 0x80131238: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x8013123C: lw          $t0, -0x4418($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X4418);
    // 0x80131240: jal         0x80139810
    // 0x80131244: sw          $t0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r8;
    osDpSetStatus_recomp(rdram, ctx);
        goto after_0;
    // 0x80131244: sw          $t0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r8;
    after_0:
    // 0x80131248: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x8013124C: jal         0x80138A60
    // 0x80131250: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    osScGetCmdQ(rdram, ctx);
        goto after_1;
    // 0x80131250: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    after_1:
    // 0x80131254: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80131258: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8013125C: jal         0x80139050
    // 0x80131260: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSendMesg_recomp(rdram, ctx);
        goto after_2;
    // 0x80131260: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_2:
    // 0x80131264: lui         $v1, 0x8024
    ctx->r3 = S32(0X8024 << 16);
    // 0x80131268: addiu       $v1, $v1, -0xC20
    ctx->r3 = ADD32(ctx->r3, -0XC20);
    // 0x8013126C: lhu         $t8, 0x0($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X0);
    // 0x80131270: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80131274: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80131278: addiu       $t1, $t8, 0x1
    ctx->r9 = ADD32(ctx->r24, 0X1);
    // 0x8013127C: sh          $t1, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r9;
    // 0x80131280: jr          $ra
    // 0x80131284: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x80131284: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void amCreateAudioMgr(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131290: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80131294: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80131298: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x8013129C: lui         $t6, 0x8013
    ctx->r14 = S32(0X8013 << 16);
    // 0x801312A0: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x801312A4: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x801312A8: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x801312AC: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x801312B0: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x801312B4: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x801312B8: sb          $zero, 0x1758($at)
    MEM_B(0X1758, ctx->r1) = 0;
    // 0x801312BC: addiu       $t6, $t6, 0x1AA0
    ctx->r14 = ADD32(ctx->r14, 0X1AA0);
    // 0x801312C0: or          $s3, $a0, $zero
    ctx->r19 = ctx->r4 | 0;
    // 0x801312C4: sw          $t6, 0x10($a0)
    MEM_W(0X10, ctx->r4) = ctx->r14;
    // 0x801312C8: jal         0x80139820
    // 0x801312CC: addiu       $a0, $zero, 0x7D00
    ctx->r4 = ADD32(0, 0X7D00);
    osAiSetFrequency_recomp(rdram, ctx);
        goto after_0;
    // 0x801312CC: addiu       $a0, $zero, 0x7D00
    ctx->r4 = ADD32(0, 0X7D00);
    after_0:
    // 0x801312D0: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x801312D4: sw          $v0, 0x18($s3)
    MEM_W(0X18, ctx->r19) = ctx->r2;
    // 0x801312D8: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x801312DC: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801312E0: lh          $t7, 0x4294($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4294);
    // 0x801312E4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x801312E8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x801312EC: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x801312F0: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x801312F4: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x801312F8: addiu       $a0, $a0, 0x1D0A
    ctx->r4 = ADD32(ctx->r4, 0X1D0A);
    // 0x801312FC: lui         $s4, 0x8024
    ctx->r20 = S32(0X8024 << 16);
    // 0x80131300: addiu       $s4, $s4, 0x1D0C
    ctx->r20 = ADD32(ctx->r20, 0X1D0C);
    // 0x80131304: lui         $at, 0x8024
    ctx->r1 = S32(0X8024 << 16);
    // 0x80131308: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x8013130C: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80131310: div.s       $f0, $f10, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f0.fl = DIV_S(ctx->f10.fl, ctx->f18.fl);
    // 0x80131314: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x80131318: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x8013131C: nop

    // 0x80131320: sh          $t9, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r25;
    // 0x80131324: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
    // 0x80131328: mtc1        $v1, $f6
    ctx->f6.u32l = ctx->r3;
    // 0x8013132C: nop

    // 0x80131330: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80131334: c.lt.s      $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f8.fl < ctx->f0.fl;
    // 0x80131338: nop

    // 0x8013133C: bc1f        L_8013134C
    if (!c1cs) {
        // 0x80131340: addiu       $t0, $v1, 0x1
        ctx->r8 = ADD32(ctx->r3, 0X1);
            goto L_8013134C;
    }
    // 0x80131340: addiu       $t0, $v1, 0x1
    ctx->r8 = ADD32(ctx->r3, 0X1);
    // 0x80131344: sh          $t0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r8;
    // 0x80131348: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
L_8013134C:
    // 0x8013134C: andi        $t1, $v1, 0xF
    ctx->r9 = ctx->r3 & 0XF;
    // 0x80131350: beq         $t1, $zero, L_80131364
    if (ctx->r9 == 0) {
        // 0x80131354: andi        $t2, $v1, 0xFFF0
        ctx->r10 = ctx->r3 & 0XFFF0;
            goto L_80131364;
    }
    // 0x80131354: andi        $t2, $v1, 0xFFF0
    ctx->r10 = ctx->r3 & 0XFFF0;
    // 0x80131358: addiu       $t3, $t2, 0x10
    ctx->r11 = ADD32(ctx->r10, 0X10);
    // 0x8013135C: sh          $t3, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r11;
    // 0x80131360: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
L_80131364:
    // 0x80131364: addiu       $t4, $v1, -0x10
    ctx->r12 = ADD32(ctx->r3, -0X10);
    // 0x80131368: sh          $t4, 0x1D08($at)
    MEM_H(0X1D08, ctx->r1) = ctx->r12;
    // 0x8013136C: addiu       $t5, $v1, 0xC4
    ctx->r13 = ADD32(ctx->r3, 0XC4);
    // 0x80131370: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x80131374: sh          $t5, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r13;
    // 0x80131378: jal         0x80139A0C
    // 0x8013137C: addiu       $a0, $a0, -0x8F8
    ctx->r4 = ADD32(ctx->r4, -0X8F8);
    alInit(rdram, ctx);
        goto after_1;
    // 0x8013137C: addiu       $a0, $a0, -0x8F8
    ctx->r4 = ADD32(ctx->r4, -0X8F8);
    after_1:
    // 0x80131380: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80131384: addiu       $v0, $v0, 0x1768
    ctx->r2 = ADD32(ctx->r2, 0X1768);
    // 0x80131388: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x8013138C: lui         $s0, 0x8024
    ctx->r16 = S32(0X8024 << 16);
    // 0x80131390: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80131394: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80131398: addiu       $s0, $s0, 0x177C
    ctx->r16 = ADD32(ctx->r16, 0X177C);
    // 0x8013139C: addiu       $s1, $s1, 0x1768
    ctx->r17 = ADD32(ctx->r17, 0X1768);
    // 0x801313A0: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_801313A4:
    // 0x801313A4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x801313A8: jal         0x801399B0
    // 0x801313AC: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    alLink(rdram, ctx);
        goto after_2;
    // 0x801313AC: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_2:
    // 0x801313B0: lw          $a2, 0x14($s3)
    ctx->r6 = MEM_W(ctx->r19, 0X14);
    // 0x801313B4: addiu       $t6, $zero, 0x400
    ctx->r14 = ADD32(0, 0X400);
    // 0x801313B8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x801313BC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x801313C0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x801313C4: jal         0x80139A40
    // 0x801313C8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_3;
    // 0x801313C8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_3:
    // 0x801313CC: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x801313D0: slti        $at, $s2, 0x47
    ctx->r1 = SIGNED(ctx->r18) < 0X47 ? 1 : 0;
    // 0x801313D4: addiu       $s1, $s1, 0x14
    ctx->r17 = ADD32(ctx->r17, 0X14);
    // 0x801313D8: addiu       $s0, $s0, 0x14
    ctx->r16 = ADD32(ctx->r16, 0X14);
    // 0x801313DC: bne         $at, $zero, L_801313A4
    if (ctx->r1 != 0) {
        // 0x801313E0: sw          $v0, -0x4($s1)
        MEM_W(-0X4, ctx->r17) = ctx->r2;
            goto L_801313A4;
    }
    // 0x801313E0: sw          $v0, -0x4($s1)
    MEM_W(-0X4, ctx->r17) = ctx->r2;
    // 0x801313E4: lw          $a2, 0x14($s3)
    ctx->r6 = MEM_W(ctx->r19, 0X14);
    // 0x801313E8: addiu       $t7, $zero, 0x400
    ctx->r15 = ADD32(0, 0X400);
    // 0x801313EC: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x801313F0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x801313F4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x801313F8: jal         0x80139A40
    // 0x801313FC: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_4;
    // 0x801313FC: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_4:
    // 0x80131400: sw          $v0, 0x10($s1)
    MEM_W(0X10, ctx->r17) = ctx->r2;
    // 0x80131404: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80131408: lui         $s0, 0x8024
    ctx->r16 = S32(0X8024 << 16);
    // 0x8013140C: addiu       $s0, $s0, -0xBF0
    ctx->r16 = ADD32(ctx->r16, -0XBF0);
    // 0x80131410: addiu       $s1, $s1, -0xBE8
    ctx->r17 = ADD32(ctx->r17, -0XBE8);
L_80131414:
    // 0x80131414: lw          $a2, 0x14($s3)
    ctx->r6 = MEM_W(ctx->r19, 0X14);
    // 0x80131418: addiu       $t8, $zero, 0x3E80
    ctx->r24 = ADD32(0, 0X3E80);
    // 0x8013141C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80131420: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131424: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131428: jal         0x80139A40
    // 0x8013142C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_5;
    // 0x8013142C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_5:
    // 0x80131430: addiu       $s0, $s0, 0x4
    ctx->r16 = ADD32(ctx->r16, 0X4);
    // 0x80131434: sltu        $at, $s0, $s1
    ctx->r1 = ctx->r16 < ctx->r17 ? 1 : 0;
    // 0x80131438: bne         $at, $zero, L_80131414
    if (ctx->r1 != 0) {
        // 0x8013143C: sw          $v0, -0x4($s0)
        MEM_W(-0X4, ctx->r16) = ctx->r2;
            goto L_80131414;
    }
    // 0x8013143C: sw          $v0, -0x4($s0)
    MEM_W(-0X4, ctx->r16) = ctx->r2;
    // 0x80131440: lui         $s0, 0x8024
    ctx->r16 = S32(0X8024 << 16);
    // 0x80131444: lui         $s2, 0x8024
    ctx->r18 = S32(0X8024 << 16);
    // 0x80131448: addiu       $s2, $s2, -0xBE4
    ctx->r18 = ADD32(ctx->r18, -0XBE4);
    // 0x8013144C: addiu       $s0, $s0, -0xBF0
    ctx->r16 = ADD32(ctx->r16, -0XBF0);
    // 0x80131450: addiu       $s1, $zero, 0x2
    ctx->r17 = ADD32(0, 0X2);
L_80131454:
    // 0x80131454: lw          $a2, 0x14($s3)
    ctx->r6 = MEM_W(ctx->r19, 0X14);
    // 0x80131458: addiu       $t9, $zero, 0x90
    ctx->r25 = ADD32(0, 0X90);
    // 0x8013145C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80131460: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131464: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131468: jal         0x80139A40
    // 0x8013146C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_6;
    // 0x8013146C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_6:
    // 0x80131470: sw          $v0, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r2;
    // 0x80131474: sh          $s1, 0x70($v0)
    MEM_H(0X70, ctx->r2) = ctx->r17;
    // 0x80131478: lw          $v1, 0x8($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X8);
    // 0x8013147C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131480: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131484: sw          $v1, 0x74($v1)
    MEM_W(0X74, ctx->r3) = ctx->r3;
    // 0x80131488: lh          $t0, 0x0($s4)
    ctx->r8 = MEM_H(ctx->r20, 0X0);
    // 0x8013148C: lw          $a2, 0x14($s3)
    ctx->r6 = MEM_W(ctx->r19, 0X14);
    // 0x80131490: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x80131494: sll         $t1, $t0, 2
    ctx->r9 = S32(ctx->r8 << 2);
    // 0x80131498: jal         0x80139A40
    // 0x8013149C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    alHeapDBAlloc(rdram, ctx);
        goto after_7;
    // 0x8013149C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    after_7:
    // 0x801314A0: lw          $t2, 0x8($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X8);
    // 0x801314A4: addiu       $s0, $s0, 0x4
    ctx->r16 = ADD32(ctx->r16, 0X4);
    // 0x801314A8: bne         $s0, $s2, L_80131454
    if (ctx->r16 != ctx->r18) {
        // 0x801314AC: sw          $v0, 0x0($t2)
        MEM_W(0X0, ctx->r10) = ctx->r2;
            goto L_80131454;
    }
    // 0x801314AC: sw          $v0, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r2;
    // 0x801314B0: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x801314B4: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x801314B8: addiu       $a1, $a1, -0x978
    ctx->r5 = ADD32(ctx->r5, -0X978);
    // 0x801314BC: addiu       $a0, $a0, -0x990
    ctx->r4 = ADD32(ctx->r4, -0X990);
    // 0x801314C0: jal         0x801381B0
    // 0x801314C4: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_8;
    // 0x801314C4: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    after_8:
    // 0x801314C8: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x801314CC: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x801314D0: addiu       $a1, $a1, -0xA10
    ctx->r5 = ADD32(ctx->r5, -0XA10);
    // 0x801314D4: addiu       $a0, $a0, -0xA28
    ctx->r4 = ADD32(ctx->r4, -0XA28);
    // 0x801314D8: jal         0x801381B0
    // 0x801314DC: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_9;
    // 0x801314DC: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    after_9:
    // 0x801314E0: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x801314E4: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x801314E8: addiu       $a1, $a1, 0x23E8
    ctx->r5 = ADD32(ctx->r5, 0X23E8);
    // 0x801314EC: addiu       $a0, $a0, 0x23D0
    ctx->r4 = ADD32(ctx->r4, 0X23D0);
    // 0x801314F0: jal         0x801381B0
    // 0x801314F4: addiu       $a2, $zero, 0x48
    ctx->r6 = ADD32(0, 0X48);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_10;
    // 0x801314F4: addiu       $a2, $zero, 0x48
    ctx->r6 = ADD32(0, 0X48);
    after_10:
    // 0x801314F8: lw          $t4, 0x3C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X3C);
    // 0x801314FC: lui         $s0, 0x8024
    ctx->r16 = S32(0X8024 << 16);
    // 0x80131500: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x80131504: addiu       $s0, $s0, -0xBD8
    ctx->r16 = ADD32(ctx->r16, -0XBD8);
    // 0x80131508: addiu       $t3, $t3, 0x1758
    ctx->r11 = ADD32(ctx->r11, 0X1758);
    // 0x8013150C: lui         $a2, 0x8013
    ctx->r6 = S32(0X8013 << 16);
    // 0x80131510: addiu       $a2, $a2, 0x1554
    ctx->r6 = ADD32(ctx->r6, 0X1554);
    // 0x80131514: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80131518: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8013151C: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x80131520: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80131524: jal         0x80139AA0
    // 0x80131528: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    osCreateThread_recomp(rdram, ctx);
        goto after_11;
    // 0x80131528: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_11:
    // 0x8013152C: jal         0x801381E0
    // 0x80131530: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    osStartThread_recomp(rdram, ctx);
        goto after_12;
    // 0x80131530: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_12:
    // 0x80131534: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80131538: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8013153C: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x80131540: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x80131544: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x80131548: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8013154C: jr          $ra
    // 0x80131550: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x80131550: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void __amMain(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131554: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x80131558: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8013155C: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x80131560: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x80131564: addiu       $s3, $s3, -0xA28
    ctx->r19 = ADD32(ctx->r19, -0XA28);
    // 0x80131568: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8013156C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80131570: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80131574: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80131578: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8013157C: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80131580: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80131584: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80131588: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8013158C: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80131590: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80131594: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80131598: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    // 0x8013159C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x801315A0: jal         0x80138AF0
    // 0x801315A4: addiu       $a1, $sp, 0x48
    ctx->r5 = ADD32(ctx->r29, 0X48);
    osScAddClient(rdram, ctx);
        goto after_0;
    // 0x801315A4: addiu       $a1, $sp, 0x48
    ctx->r5 = ADD32(ctx->r29, 0X48);
    after_0:
    // 0x801315A8: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801315AC: lui         $fp, 0x8015
    ctx->r30 = S32(0X8015 << 16);
    // 0x801315B0: lui         $s7, 0x8024
    ctx->r23 = S32(0X8024 << 16);
    // 0x801315B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x801315B8: addiu       $s7, $s7, -0xBF0
    ctx->r23 = ADD32(ctx->r23, -0XBF0);
    // 0x801315BC: addiu       $fp, $fp, 0x4680
    ctx->r30 = ADD32(ctx->r30, 0X4680);
    // 0x801315C0: sh          $zero, 0x654C($at)
    MEM_H(0X654C, ctx->r1) = 0;
    // 0x801315C4: addiu       $s6, $zero, 0xA
    ctx->r22 = ADD32(0, 0XA);
    // 0x801315C8: addiu       $s5, $zero, 0x4
    ctx->r21 = ADD32(0, 0X4);
    // 0x801315CC: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x801315D0: addiu       $s2, $sp, 0x54
    ctx->r18 = ADD32(ctx->r29, 0X54);
L_801315D4:
    // 0x801315D4: beq         $v0, $zero, L_801315E8
    if (ctx->r2 == 0) {
        // 0x801315D8: lui         $at, 0x8028
        ctx->r1 = S32(0X8028 << 16);
            goto L_801315E8;
    }
    // 0x801315D8: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801315DC: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x801315E0: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x801315E4: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
L_801315E8:
    // 0x801315E8: sh          $v0, 0x654C($at)
    MEM_H(0X654C, ctx->r1) = ctx->r2;
    // 0x801315EC: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
    // 0x801315F0: bne         $at, $zero, L_801315FC
    if (ctx->r1 != 0) {
        // 0x801315F4: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_801315FC;
    }
    // 0x801315F4: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x801315F8: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
L_801315FC:
    // 0x801315FC: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80131600: jal         0x80137FF0
    // 0x80131604: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x80131604: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    after_1:
    // 0x80131608: lw          $t8, 0x54($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X54);
    // 0x8013160C: lh          $v1, 0x0($t8)
    ctx->r3 = MEM_H(ctx->r24, 0X0);
    // 0x80131610: beql        $v1, $s4, L_80131634
    if (ctx->r3 == ctx->r20) {
        // 0x80131614: lw          $t9, 0x0($fp)
        ctx->r25 = MEM_W(ctx->r30, 0X0);
            goto L_80131634;
    }
    goto skip_0;
    // 0x80131614: lw          $t9, 0x0($fp)
    ctx->r25 = MEM_W(ctx->r30, 0X0);
    skip_0:
    // 0x80131618: beq         $v1, $s5, L_80131684
    if (ctx->r3 == ctx->r21) {
        // 0x8013161C: lui         $at, 0x8028
        ctx->r1 = S32(0X8028 << 16);
            goto L_80131684;
    }
    // 0x8013161C: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80131620: beql        $v1, $s6, L_80131690
    if (ctx->r3 == ctx->r22) {
        // 0x80131624: addiu       $s0, $zero, 0x1
        ctx->r16 = ADD32(0, 0X1);
            goto L_80131690;
    }
    goto skip_1;
    // 0x80131624: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
    skip_1:
    // 0x80131628: b           L_80131690
    // 0x8013162C: nop

        goto L_80131690;
    // 0x8013162C: nop

    // 0x80131630: lw          $t9, 0x0($fp)
    ctx->r25 = MEM_W(ctx->r30, 0X0);
L_80131634:
    // 0x80131634: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80131638: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8013163C: divu        $zero, $t9, $at
    lo = S32(U32(ctx->r25) / U32(ctx->r1)); hi = S32(U32(ctx->r25) % U32(ctx->r1));
    // 0x80131640: mfhi        $t0
    ctx->r8 = hi;
    // 0x80131644: sll         $t1, $t0, 2
    ctx->r9 = S32(ctx->r8 << 2);
    // 0x80131648: addu        $t2, $s7, $t1
    ctx->r10 = ADD32(ctx->r23, ctx->r9);
    // 0x8013164C: jal         0x80131700
    // 0x80131650: lw          $a0, 0x8($t2)
    ctx->r4 = MEM_W(ctx->r10, 0X8);
    __amHandleFrameMsg(rdram, ctx);
        goto after_2;
    // 0x80131650: lw          $a0, 0x8($t2)
    ctx->r4 = MEM_W(ctx->r10, 0X8);
    after_2:
    // 0x80131654: beq         $v0, $zero, L_80131690
    if (ctx->r2 == 0) {
        // 0x80131658: lui         $a0, 0x8024
        ctx->r4 = S32(0X8024 << 16);
            goto L_80131690;
    }
    // 0x80131658: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8013165C: addiu       $a0, $a0, -0x990
    ctx->r4 = ADD32(ctx->r4, -0X990);
    // 0x80131660: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80131664: jal         0x80137FF0
    // 0x80131668: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_3;
    // 0x80131668: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    after_3:
    // 0x8013166C: lw          $t3, 0x54($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X54);
    // 0x80131670: jal         0x801318C8
    // 0x80131674: lw          $a0, 0x4($t3)
    ctx->r4 = MEM_W(ctx->r11, 0X4);
    __amHandleDoneMsg(rdram, ctx);
        goto after_4;
    // 0x80131674: lw          $a0, 0x4($t3)
    ctx->r4 = MEM_W(ctx->r11, 0X4);
    after_4:
    // 0x80131678: lw          $t4, 0x54($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X54);
    // 0x8013167C: b           L_80131690
    // 0x80131680: lw          $s1, 0x4($t4)
    ctx->r17 = MEM_W(ctx->r12, 0X4);
        goto L_80131690;
    // 0x80131680: lw          $s1, 0x4($t4)
    ctx->r17 = MEM_W(ctx->r12, 0X4);
L_80131684:
    // 0x80131684: b           L_80131690
    // 0x80131688: sh          $s4, 0x654C($at)
    MEM_H(0X654C, ctx->r1) = ctx->r20;
        goto L_80131690;
    // 0x80131688: sh          $s4, 0x654C($at)
    MEM_H(0X654C, ctx->r1) = ctx->r20;
    // 0x8013168C: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
L_80131690:
    // 0x80131690: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80131694: beq         $s0, $zero, L_801315D4
    if (ctx->r16 == 0) {
        // 0x80131698: lh          $v0, 0x654C($v0)
        ctx->r2 = MEM_H(ctx->r2, 0X654C);
            goto L_801315D4;
    }
    // 0x80131698: lh          $v0, 0x654C($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X654C);
    // 0x8013169C: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x801316A0: addiu       $a0, $a0, -0x8F8
    ctx->r4 = ADD32(ctx->r4, -0X8F8);
    // 0x801316A4: jal         0x801399D4
    // 0x801316A8: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
    alClose(rdram, ctx);
        goto after_5;
    // 0x801316A8: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
    after_5:
L_801316AC:
    // 0x801316AC: b           L_801316AC
    pause_self(rdram);
    // 0x801316B0: nop

    // 0x801316B4: nop

    // 0x801316B8: nop

    // 0x801316BC: nop

    // 0x801316C0: nop

    // 0x801316C4: nop

    // 0x801316C8: nop

    // 0x801316CC: nop

    // 0x801316D0: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x801316D4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801316D8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x801316DC: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x801316E0: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x801316E4: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x801316E8: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x801316EC: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x801316F0: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x801316F4: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x801316F8: jr          $ra
    // 0x801316FC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x801316FC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void __amHandleFrameMsg(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131700: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x80131704: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80131708: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8013170C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80131710: jal         0x80131AD8
    // 0x80131714: sw          $a1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r5;
    __clearAudioDMA(rdram, ctx);
        goto after_0;
    // 0x80131714: sw          $a1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80131718: jal         0x80138130
    // 0x8013171C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x8013171C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    after_1:
    // 0x80131720: lw          $v1, 0x4C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X4C);
    // 0x80131724: sw          $v0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r2;
    // 0x80131728: beq         $v1, $zero, L_80131744
    if (ctx->r3 == 0) {
        // 0x8013172C: nop
    
            goto L_80131744;
    }
    // 0x8013172C: nop

    // 0x80131730: lh          $a1, 0x4($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X4);
    // 0x80131734: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80131738: sll         $t6, $a1, 2
    ctx->r14 = S32(ctx->r5 << 2);
    // 0x8013173C: jal         0x80139BF0
    // 0x80131740: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    osAiSetNextBuffer_recomp(rdram, ctx);
        goto after_2;
    // 0x80131740: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    after_2:
L_80131744:
    // 0x80131744: jal         0x80139CA0
    // 0x80131748: nop

    osAiGetLength_recomp(rdram, ctx);
        goto after_3;
    // 0x80131748: nop

    after_3:
    // 0x8013174C: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x80131750: lh          $t7, 0x1D0A($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X1D0A);
    // 0x80131754: srl         $t8, $v0, 2
    ctx->r24 = S32(U32(ctx->r2) >> 2);
    // 0x80131758: lui         $v1, 0x8024
    ctx->r3 = S32(0X8024 << 16);
    // 0x8013175C: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x80131760: addiu       $t0, $t9, 0xC4
    ctx->r8 = ADD32(ctx->r25, 0XC4);
    // 0x80131764: andi        $t1, $t0, 0xFFF0
    ctx->r9 = ctx->r8 & 0XFFF0;
    // 0x80131768: sh          $t1, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r9;
    // 0x8013176C: lh          $v1, 0x1D08($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X1D08);
    // 0x80131770: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x80131774: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x80131778: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8013177C: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80131780: beq         $at, $zero, L_80131790
    if (ctx->r1 == 0) {
        // 0x80131784: nop
    
            goto L_80131790;
    }
    // 0x80131784: nop

    // 0x80131788: sh          $v1, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r3;
    // 0x8013178C: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
L_80131790:
    // 0x80131790: lh          $t2, 0x4688($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X4688);
    // 0x80131794: addiu       $a1, $sp, 0x3C
    ctx->r5 = ADD32(ctx->r29, 0X3C);
    // 0x80131798: lw          $a2, 0x44($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X44);
    // 0x8013179C: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x801317A0: addu        $a0, $a0, $t3
    ctx->r4 = ADD32(ctx->r4, ctx->r11);
    // 0x801317A4: jal         0x80139DF8
    // 0x801317A8: lw          $a0, -0xBF0($a0)
    ctx->r4 = MEM_W(ctx->r4, -0XBF0);
    alAudioFrame(rdram, ctx);
        goto after_4;
    // 0x801317A8: lw          $a0, -0xBF0($a0)
    ctx->r4 = MEM_W(ctx->r4, -0XBF0);
    after_4:
    // 0x801317AC: lw          $t4, 0x3C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X3C);
    // 0x801317B0: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x801317B4: addiu       $a3, $a3, -0xBF0
    ctx->r7 = ADD32(ctx->r7, -0XBF0);
    // 0x801317B8: bne         $t4, $zero, L_801317C8
    if (ctx->r12 != 0) {
        // 0x801317BC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_801317C8;
    }
    // 0x801317BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x801317C0: b           L_801318B4
    // 0x801317C4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_801318B4;
    // 0x801317C4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_801317C8:
    // 0x801317C8: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x801317CC: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
    // 0x801317D0: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x801317D4: addiu       $t5, $t5, -0x990
    ctx->r13 = ADD32(ctx->r13, -0X990);
    // 0x801317D8: addiu       $t6, $s0, 0x70
    ctx->r14 = ADD32(ctx->r16, 0X70);
    // 0x801317DC: addiu       $a2, $a2, 0x4688
    ctx->r6 = ADD32(ctx->r6, 0X4688);
    // 0x801317E0: sw          $zero, 0x8($s0)
    MEM_W(0X8, ctx->r16) = 0;
    // 0x801317E4: sw          $t5, 0x58($s0)
    MEM_W(0X58, ctx->r16) = ctx->r13;
    // 0x801317E8: sw          $t6, 0x5C($s0)
    MEM_W(0X5C, ctx->r16) = ctx->r14;
    // 0x801317EC: sw          $v0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r2;
    // 0x801317F0: lh          $t7, 0x0($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X0);
    // 0x801317F4: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x801317F8: addiu       $a1, $a1, -0x2C70
    ctx->r5 = ADD32(ctx->r5, -0X2C70);
    // 0x801317FC: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x80131800: addu        $t9, $a3, $t8
    ctx->r25 = ADD32(ctx->r7, ctx->r24);
    // 0x80131804: lw          $t0, 0x0($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X0);
    // 0x80131808: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8013180C: addiu       $t8, $t8, -0x2BA0
    ctx->r24 = ADD32(ctx->r24, -0X2BA0);
    // 0x80131810: sw          $t0, 0x48($s0)
    MEM_W(0X48, ctx->r16) = ctx->r8;
    // 0x80131814: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x80131818: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x8013181C: subu        $t9, $t8, $a1
    ctx->r25 = SUB32(ctx->r24, ctx->r5);
    // 0x80131820: sll         $t2, $t1, 2
    ctx->r10 = S32(ctx->r9 << 2);
    // 0x80131824: addu        $t3, $a3, $t2
    ctx->r11 = ADD32(ctx->r7, ctx->r10);
    // 0x80131828: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x8013182C: lui         $t1, 0x8016
    ctx->r9 = S32(0X8016 << 16);
    // 0x80131830: addiu       $t0, $t0, 0x600
    ctx->r8 = ADD32(ctx->r8, 0X600);
    // 0x80131834: subu        $t5, $v1, $t4
    ctx->r13 = SUB32(ctx->r3, ctx->r12);
    // 0x80131838: sra         $t6, $t5, 3
    ctx->r14 = S32(SIGNED(ctx->r13) >> 3);
    // 0x8013183C: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x80131840: addiu       $t1, $t1, -0x20F0
    ctx->r9 = ADD32(ctx->r9, -0X20F0);
    // 0x80131844: addiu       $t2, $zero, 0x800
    ctx->r10 = ADD32(0, 0X800);
    // 0x80131848: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x8013184C: sw          $t7, 0x4C($s0)
    MEM_W(0X4C, ctx->r16) = ctx->r15;
    // 0x80131850: sw          $v0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r2;
    // 0x80131854: sw          $a1, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r5;
    // 0x80131858: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x8013185C: sw          $zero, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = 0;
    // 0x80131860: sw          $t0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r8;
    // 0x80131864: sw          $t1, 0x30($s0)
    MEM_W(0X30, ctx->r16) = ctx->r9;
    // 0x80131868: sw          $t2, 0x34($s0)
    MEM_W(0X34, ctx->r16) = ctx->r10;
    // 0x8013186C: sw          $zero, 0x38($s0)
    MEM_W(0X38, ctx->r16) = 0;
    // 0x80131870: sw          $zero, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = 0;
    // 0x80131874: sw          $zero, 0x40($s0)
    MEM_W(0X40, ctx->r16) = 0;
    // 0x80131878: sw          $zero, 0x44($s0)
    MEM_W(0X44, ctx->r16) = 0;
    // 0x8013187C: sw          $zero, 0x50($s0)
    MEM_W(0X50, ctx->r16) = 0;
    // 0x80131880: sw          $zero, 0x54($s0)
    MEM_W(0X54, ctx->r16) = 0;
    // 0x80131884: jal         0x80138A60
    // 0x80131888: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    osScGetCmdQ(rdram, ctx);
        goto after_5;
    // 0x80131888: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    after_5:
    // 0x8013188C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80131890: addiu       $a1, $s0, 0x8
    ctx->r5 = ADD32(ctx->r16, 0X8);
    // 0x80131894: jal         0x80139050
    // 0x80131898: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSendMesg_recomp(rdram, ctx);
        goto after_6;
    // 0x80131898: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_6:
    // 0x8013189C: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x801318A0: lh          $t3, 0x4688($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X4688);
    // 0x801318A4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801318A8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x801318AC: xori        $t4, $t3, 0x1
    ctx->r12 = ctx->r11 ^ 0X1;
    // 0x801318B0: sh          $t4, 0x4688($at)
    MEM_H(0X4688, ctx->r1) = ctx->r12;
L_801318B4:
    // 0x801318B4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x801318B8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801318BC: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x801318C0: jr          $ra
    // 0x801318C4: nop

    return;
    // 0x801318C4: nop

;}
RECOMP_FUNC void __amHandleDoneMsg(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801318C8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801318CC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801318D0: jal         0x80139CA0
    // 0x801318D4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    osAiGetLength_recomp(rdram, ctx);
        goto after_0;
    // 0x801318D4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x801318D8: srl         $t6, $v0, 2
    ctx->r14 = S32(U32(ctx->r2) >> 2);
    // 0x801318DC: bne         $t6, $zero, L_801318F8
    if (ctx->r14 != 0) {
        // 0x801318E0: lui         $t7, 0x8015
        ctx->r15 = S32(0X8015 << 16);
            goto L_801318F8;
    }
    // 0x801318E0: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x801318E4: lw          $t7, 0x518C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X518C);
    // 0x801318E8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801318EC: bnel        $t7, $zero, L_801318FC
    if (ctx->r15 != 0) {
        // 0x801318F0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_801318FC;
    }
    goto skip_0;
    // 0x801318F0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x801318F4: sw          $zero, 0x518C($at)
    MEM_W(0X518C, ctx->r1) = 0;
L_801318F8:
    // 0x801318F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801318FC:
    // 0x801318FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80131900: jr          $ra
    // 0x80131904: nop

    return;
    // 0x80131904: nop

;}
RECOMP_FUNC void __amDMA(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131908: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x8013190C: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x80131910: addiu       $t0, $t0, 0x1758
    ctx->r8 = ADD32(ctx->r8, 0X1758);
    // 0x80131914: sw          $s1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r17;
    // 0x80131918: lw          $s1, 0x4($t0)
    ctx->r17 = MEM_W(ctx->r8, 0X4);
    // 0x8013191C: sw          $s0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r16;
    // 0x80131920: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x80131924: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80131928: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x8013192C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80131930: beq         $s1, $zero, L_80131988
    if (ctx->r17 == 0) {
        // 0x80131934: or          $s0, $s1, $zero
        ctx->r16 = ctx->r17 | 0;
            goto L_80131988;
    }
    // 0x80131934: or          $s0, $s1, $zero
    ctx->r16 = ctx->r17 | 0;
    // 0x80131938: lw          $v0, 0x8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X8);
L_8013193C:
    // 0x8013193C: addu        $t6, $a3, $a1
    ctx->r14 = ADD32(ctx->r7, ctx->r5);
    // 0x80131940: sltu        $at, $a3, $v0
    ctx->r1 = ctx->r7 < ctx->r2 ? 1 : 0;
    // 0x80131944: bne         $at, $zero, L_80131988
    if (ctx->r1 != 0) {
        // 0x80131948: addiu       $v1, $v0, 0x400
        ctx->r3 = ADD32(ctx->r2, 0X400);
            goto L_80131988;
    }
    // 0x80131948: addiu       $v1, $v0, 0x400
    ctx->r3 = ADD32(ctx->r2, 0X400);
    // 0x8013194C: slt         $at, $v1, $t6
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80131950: bne         $at, $zero, L_8013197C
    if (ctx->r1 != 0) {
        // 0x80131954: or          $a2, $s0, $zero
        ctx->r6 = ctx->r16 | 0;
            goto L_8013197C;
    }
    // 0x80131954: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80131958: lw          $t8, 0x10($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X10);
    // 0x8013195C: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80131960: lw          $t7, 0x4680($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X4680);
    // 0x80131964: addu        $t9, $t8, $a3
    ctx->r25 = ADD32(ctx->r24, ctx->r7);
    // 0x80131968: subu        $a0, $t9, $v0
    ctx->r4 = SUB32(ctx->r25, ctx->r2);
    // 0x8013196C: jal         0x80138130
    // 0x80131970: sw          $t7, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r15;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_0;
    // 0x80131970: sw          $t7, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r15;
    after_0:
    // 0x80131974: b           L_80131A90
    // 0x80131978: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
        goto L_80131A90;
    // 0x80131978: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_8013197C:
    // 0x8013197C: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    // 0x80131980: bnel        $s0, $zero, L_8013193C
    if (ctx->r16 != 0) {
        // 0x80131984: lw          $v0, 0x8($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X8);
            goto L_8013193C;
    }
    goto skip_0;
    // 0x80131984: lw          $v0, 0x8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X8);
    skip_0:
L_80131988:
    // 0x80131988: lw          $s0, 0x8($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X8);
    // 0x8013198C: bne         $s0, $zero, L_801319A4
    if (ctx->r16 != 0) {
        // 0x80131990: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_801319A4;
    }
    // 0x80131990: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80131994: jal         0x80138130
    // 0x80131998: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x80131998: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_1:
    // 0x8013199C: b           L_80131A90
    // 0x801319A0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
        goto L_80131A90;
    // 0x801319A0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_801319A4:
    // 0x801319A4: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x801319A8: sw          $a3, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r7;
    // 0x801319AC: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x801319B0: jal         0x80139980
    // 0x801319B4: sw          $t2, 0x8($t0)
    MEM_W(0X8, ctx->r8) = ctx->r10;
    alUnlink(rdram, ctx);
        goto after_2;
    // 0x801319B4: sw          $t2, 0x8($t0)
    MEM_W(0X8, ctx->r8) = ctx->r10;
    after_2:
    // 0x801319B8: lw          $a2, 0x30($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X30);
    // 0x801319BC: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x801319C0: addiu       $t0, $t0, 0x1758
    ctx->r8 = ADD32(ctx->r8, 0X1758);
    // 0x801319C4: beq         $a2, $zero, L_801319E4
    if (ctx->r6 == 0) {
        // 0x801319C8: lw          $a3, 0x48($sp)
        ctx->r7 = MEM_W(ctx->r29, 0X48);
            goto L_801319E4;
    }
    // 0x801319C8: lw          $a3, 0x48($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X48);
    // 0x801319CC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x801319D0: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
    // 0x801319D4: jal         0x801399B0
    // 0x801319D8: sw          $a3, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r7;
    alLink(rdram, ctx);
        goto after_3;
    // 0x801319D8: sw          $a3, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r7;
    after_3:
    // 0x801319DC: b           L_80131A10
    // 0x801319E0: lw          $a3, 0x48($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X48);
        goto L_80131A10;
    // 0x801319E0: lw          $a3, 0x48($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X48);
L_801319E4:
    // 0x801319E4: lw          $s1, 0x4($t0)
    ctx->r17 = MEM_W(ctx->r8, 0X4);
    // 0x801319E8: beql        $s1, $zero, L_80131A08
    if (ctx->r17 == 0) {
        // 0x801319EC: sw          $s0, 0x4($t0)
        MEM_W(0X4, ctx->r8) = ctx->r16;
            goto L_80131A08;
    }
    goto skip_1;
    // 0x801319EC: sw          $s0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r16;
    skip_1:
    // 0x801319F0: sw          $s0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r16;
    // 0x801319F4: sw          $s1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r17;
    // 0x801319F8: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x801319FC: b           L_80131A10
    // 0x80131A00: sw          $s0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r16;
        goto L_80131A10;
    // 0x80131A00: sw          $s0, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r16;
    // 0x80131A04: sw          $s0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r16;
L_80131A08:
    // 0x80131A08: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
    // 0x80131A0C: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
L_80131A10:
    // 0x80131A10: andi        $s1, $a3, 0x1
    ctx->r17 = ctx->r7 & 0X1;
    // 0x80131A14: subu        $a3, $a3, $s1
    ctx->r7 = SUB32(ctx->r7, ctx->r17);
    // 0x80131A18: sw          $a3, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r7;
    // 0x80131A1C: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x80131A20: lw          $t3, 0x4680($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X4680);
    // 0x80131A24: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x80131A28: addiu       $t1, $t1, 0x4684
    ctx->r9 = ADD32(ctx->r9, 0X4684);
    // 0x80131A2C: sw          $t3, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r11;
    // 0x80131A30: lh          $v1, 0x0($t1)
    ctx->r3 = MEM_H(ctx->r9, 0X0);
    // 0x80131A34: lw          $t0, 0x10($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X10);
    // 0x80131A38: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x80131A3C: sll         $t4, $v1, 2
    ctx->r12 = S32(ctx->r3 << 2);
    // 0x80131A40: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x80131A44: subu        $t4, $t4, $v1
    ctx->r12 = SUB32(ctx->r12, ctx->r3);
    // 0x80131A48: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x80131A4C: addiu       $t7, $t7, 0x23D0
    ctx->r15 = ADD32(ctx->r15, 0X23D0);
    // 0x80131A50: addiu       $t5, $t5, 0x1D10
    ctx->r13 = ADD32(ctx->r13, 0X1D10);
    // 0x80131A54: addiu       $t6, $zero, 0x400
    ctx->r14 = ADD32(0, 0X400);
    // 0x80131A58: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x80131A5C: sh          $t8, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r24;
    // 0x80131A60: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80131A64: addu        $a0, $t4, $t5
    ctx->r4 = ADD32(ctx->r12, ctx->r13);
    // 0x80131A68: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80131A6C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131A70: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80131A74: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80131A78: jal         0x80137EE0
    // 0x80131A7C: sw          $t0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r8;
    osPiStartDma_recomp(rdram, ctx);
        goto after_4;
    // 0x80131A7C: sw          $t0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r8;
    after_4:
    // 0x80131A80: jal         0x80138130
    // 0x80131A84: lw          $a0, 0x44($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X44);
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_5;
    // 0x80131A84: lw          $a0, 0x44($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X44);
    after_5:
    // 0x80131A88: addu        $v0, $v0, $s1
    ctx->r2 = ADD32(ctx->r2, ctx->r17);
    // 0x80131A8C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_80131A90:
    // 0x80131A90: lw          $s0, 0x24($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X24);
    // 0x80131A94: lw          $s1, 0x28($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X28);
    // 0x80131A98: jr          $ra
    // 0x80131A9C: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x80131A9C: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void __amDmaNew(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131AA0: lui         $v1, 0x8024
    ctx->r3 = S32(0X8024 << 16);
    // 0x80131AA4: addiu       $v1, $v1, 0x1758
    ctx->r3 = ADD32(ctx->r3, 0X1758);
    // 0x80131AA8: lbu         $t6, 0x0($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X0);
    // 0x80131AAC: lui         $v0, 0x8013
    ctx->r2 = S32(0X8013 << 16);
    // 0x80131AB0: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x80131AB4: bne         $t6, $zero, L_80131AD0
    if (ctx->r14 != 0) {
        // 0x80131AB8: addiu       $v0, $v0, 0x1908
        ctx->r2 = ADD32(ctx->r2, 0X1908);
            goto L_80131AD0;
    }
    // 0x80131AB8: addiu       $v0, $v0, 0x1908
    ctx->r2 = ADD32(ctx->r2, 0X1908);
    // 0x80131ABC: addiu       $t7, $t7, 0x1768
    ctx->r15 = ADD32(ctx->r15, 0X1768);
    // 0x80131AC0: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80131AC4: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80131AC8: sw          $t7, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r15;
    // 0x80131ACC: sb          $t8, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r24;
L_80131AD0:
    // 0x80131AD0: jr          $ra
    // 0x80131AD4: sw          $v1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r3;
    return;
    // 0x80131AD4: sw          $v1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r3;
;}
RECOMP_FUNC void __clearAudioDMA(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131AD8: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x80131ADC: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80131AE0: lui         $s4, 0x8015
    ctx->r20 = S32(0X8015 << 16);
    // 0x80131AE4: addiu       $s4, $s4, 0x4684
    ctx->r20 = ADD32(ctx->r20, 0X4684);
    // 0x80131AE8: lh          $t6, 0x0($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X0);
    // 0x80131AEC: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80131AF0: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80131AF4: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80131AF8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80131AFC: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80131B00: beq         $t6, $zero, L_80131B38
    if (ctx->r14 == 0) {
        // 0x80131B04: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_80131B38;
    }
    // 0x80131B04: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80131B08: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80131B0C: addiu       $s1, $s1, 0x23D0
    ctx->r17 = ADD32(ctx->r17, 0X23D0);
    // 0x80131B10: addiu       $s2, $sp, 0x40
    ctx->r18 = ADD32(ctx->r29, 0X40);
    // 0x80131B14: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_80131B18:
    // 0x80131B18: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80131B1C: jal         0x80137FF0
    // 0x80131B20: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x80131B20: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_0:
    // 0x80131B24: lh          $t7, 0x0($s4)
    ctx->r15 = MEM_H(ctx->r20, 0X0);
    // 0x80131B28: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80131B2C: sltu        $at, $s0, $t7
    ctx->r1 = ctx->r16 < ctx->r15 ? 1 : 0;
    // 0x80131B30: bnel        $at, $zero, L_80131B18
    if (ctx->r1 != 0) {
        // 0x80131B34: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80131B18;
    }
    goto skip_0;
    // 0x80131B34: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_0:
L_80131B38:
    // 0x80131B38: lui         $s2, 0x8024
    ctx->r18 = S32(0X8024 << 16);
    // 0x80131B3C: addiu       $s2, $s2, 0x1758
    ctx->r18 = ADD32(ctx->r18, 0X1758);
    // 0x80131B40: lw          $s0, 0x4($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X4);
    // 0x80131B44: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80131B48: addiu       $s3, $s3, 0x4680
    ctx->r19 = ADD32(ctx->r19, 0X4680);
    // 0x80131B4C: beq         $s0, $zero, L_80131BB8
    if (ctx->r16 == 0) {
        // 0x80131B50: nop
    
            goto L_80131BB8;
    }
    // 0x80131B50: nop

L_80131B54:
    // 0x80131B54: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x80131B58: lw          $t8, 0x0($s3)
    ctx->r24 = MEM_W(ctx->r19, 0X0);
    // 0x80131B5C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80131B60: addiu       $t0, $t9, 0x2
    ctx->r8 = ADD32(ctx->r25, 0X2);
    // 0x80131B64: sltu        $at, $t0, $t8
    ctx->r1 = ctx->r8 < ctx->r24 ? 1 : 0;
    // 0x80131B68: beq         $at, $zero, L_80131BB0
    if (ctx->r1 == 0) {
        // 0x80131B6C: or          $s1, $v0, $zero
        ctx->r17 = ctx->r2 | 0;
            goto L_80131BB0;
    }
    // 0x80131B6C: or          $s1, $v0, $zero
    ctx->r17 = ctx->r2 | 0;
    // 0x80131B70: lw          $t1, 0x4($s2)
    ctx->r9 = MEM_W(ctx->r18, 0X4);
    // 0x80131B74: bne         $s0, $t1, L_80131B80
    if (ctx->r16 != ctx->r9) {
        // 0x80131B78: nop
    
            goto L_80131B80;
    }
    // 0x80131B78: nop

    // 0x80131B7C: sw          $v0, 0x4($s2)
    MEM_W(0X4, ctx->r18) = ctx->r2;
L_80131B80:
    // 0x80131B80: jal         0x80139980
    // 0x80131B84: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    alUnlink(rdram, ctx);
        goto after_1;
    // 0x80131B84: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x80131B88: lw          $a1, 0x8($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X8);
    // 0x80131B8C: beql        $a1, $zero, L_80131BA8
    if (ctx->r5 == 0) {
        // 0x80131B90: sw          $s0, 0x8($s2)
        MEM_W(0X8, ctx->r18) = ctx->r16;
            goto L_80131BA8;
    }
    goto skip_1;
    // 0x80131B90: sw          $s0, 0x8($s2)
    MEM_W(0X8, ctx->r18) = ctx->r16;
    skip_1:
    // 0x80131B94: jal         0x801399B0
    // 0x80131B98: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    alLink(rdram, ctx);
        goto after_2;
    // 0x80131B98: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
    // 0x80131B9C: b           L_80131BB0
    // 0x80131BA0: nop

        goto L_80131BB0;
    // 0x80131BA0: nop

    // 0x80131BA4: sw          $s0, 0x8($s2)
    MEM_W(0X8, ctx->r18) = ctx->r16;
L_80131BA8:
    // 0x80131BA8: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
    // 0x80131BAC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
L_80131BB0:
    // 0x80131BB0: bne         $s1, $zero, L_80131B54
    if (ctx->r17 != 0) {
        // 0x80131BB4: or          $s0, $s1, $zero
        ctx->r16 = ctx->r17 | 0;
            goto L_80131B54;
    }
    // 0x80131BB4: or          $s0, $s1, $zero
    ctx->r16 = ctx->r17 | 0;
L_80131BB8:
    // 0x80131BB8: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80131BBC: addiu       $s3, $s3, 0x4680
    ctx->r19 = ADD32(ctx->r19, 0X4680);
    // 0x80131BC0: lw          $t2, 0x0($s3)
    ctx->r10 = MEM_W(ctx->r19, 0X0);
    // 0x80131BC4: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x80131BC8: sh          $zero, 0x0($s4)
    MEM_H(0X0, ctx->r20) = 0;
    // 0x80131BCC: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x80131BD0: sw          $t3, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r11;
    // 0x80131BD4: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80131BD8: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80131BDC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80131BE0: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80131BE4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80131BE8: jr          $ra
    // 0x80131BEC: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x80131BEC: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void initialise_audio(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80131BF0: addiu       $sp, $sp, -0x218
    ctx->r29 = ADD32(ctx->r29, -0X218);
    // 0x80131BF4: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80131BF8: addiu       $t7, $t7, 0x5190
    ctx->r15 = ADD32(ctx->r15, 0X5190);
    // 0x80131BFC: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80131C00: sw          $s3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r19;
    // 0x80131C04: sw          $s2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r18;
    // 0x80131C08: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x80131C0C: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x80131C10: sw          $a0, 0x218($sp)
    MEM_W(0X218, ctx->r29) = ctx->r4;
    // 0x80131C14: addiu       $t0, $t7, 0x108
    ctx->r8 = ADD32(ctx->r15, 0X108);
    // 0x80131C18: addiu       $t6, $sp, 0x48
    ctx->r14 = ADD32(ctx->r29, 0X48);
L_80131C1C:
    // 0x80131C1C: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x80131C20: addiu       $t7, $t7, 0xC
    ctx->r15 = ADD32(ctx->r15, 0XC);
    // 0x80131C24: addiu       $t6, $t6, 0xC
    ctx->r14 = ADD32(ctx->r14, 0XC);
    // 0x80131C28: sw          $at, -0xC($t6)
    MEM_W(-0XC, ctx->r14) = ctx->r1;
    // 0x80131C2C: lw          $at, -0x8($t7)
    ctx->r1 = MEM_W(ctx->r15, -0X8);
    // 0x80131C30: sw          $at, -0x8($t6)
    MEM_W(-0X8, ctx->r14) = ctx->r1;
    // 0x80131C34: lw          $at, -0x4($t7)
    ctx->r1 = MEM_W(ctx->r15, -0X4);
    // 0x80131C38: bne         $t7, $t0, L_80131C1C
    if (ctx->r15 != ctx->r8) {
        // 0x80131C3C: sw          $at, -0x4($t6)
        MEM_W(-0X4, ctx->r14) = ctx->r1;
            goto L_80131C1C;
    }
    // 0x80131C3C: sw          $at, -0x4($t6)
    MEM_W(-0X4, ctx->r14) = ctx->r1;
    // 0x80131C40: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80131C44: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80131C48: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80131C4C: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x80131C50: sw          $t1, 0x5154($at)
    MEM_W(0X5154, ctx->r1) = ctx->r9;
    // 0x80131C54: addiu       $v1, $v1, 0x62F8
    ctx->r3 = ADD32(ctx->r3, 0X62F8);
    // 0x80131C58: addiu       $v0, $v0, 0x2508
    ctx->r2 = ADD32(ctx->r2, 0X2508);
L_80131C5C:
    // 0x80131C5C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80131C60: sltu        $at, $v0, $v1
    ctx->r1 = ctx->r2 < ctx->r3 ? 1 : 0;
    // 0x80131C64: bne         $at, $zero, L_80131C5C
    if (ctx->r1 != 0) {
        // 0x80131C68: sb          $zero, -0x1($v0)
        MEM_B(-0X1, ctx->r2) = 0;
            goto L_80131C5C;
    }
    // 0x80131C68: sb          $zero, -0x1($v0)
    MEM_B(-0X1, ctx->r2) = 0;
    // 0x80131C6C: lui         $s3, 0x8028
    ctx->r19 = S32(0X8028 << 16);
    // 0x80131C70: addiu       $s3, $s3, 0x6328
    ctx->r19 = ADD32(ctx->r19, 0X6328);
    // 0x80131C74: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x80131C78: lui         $a2, 0x4
    ctx->r6 = S32(0X4 << 16);
    // 0x80131C7C: ori         $a2, $a2, 0x3DF0
    ctx->r6 = ctx->r6 | 0X3DF0;
    // 0x80131C80: addiu       $a1, $a1, 0x2508
    ctx->r5 = ADD32(ctx->r5, 0X2508);
    // 0x80131C84: jal         0x8013A390
    // 0x80131C88: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    alHeapInit(rdram, ctx);
        goto after_0;
    // 0x80131C88: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    after_0:
    // 0x80131C8C: lui         $s1, 0x13
    ctx->r17 = S32(0X13 << 16);
    // 0x80131C90: lui         $t2, 0x13
    ctx->r10 = S32(0X13 << 16);
    // 0x80131C94: addiu       $s1, $s1, -0x1240
    ctx->r17 = ADD32(ctx->r17, -0X1240);
    // 0x80131C98: addiu       $t2, $t2, 0x3450
    ctx->r10 = ADD32(ctx->r10, 0X3450);
    // 0x80131C9C: subu        $s0, $t2, $s1
    ctx->r16 = SUB32(ctx->r10, ctx->r17);
    // 0x80131CA0: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x80131CA4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131CA8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131CAC: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131CB0: jal         0x80139A40
    // 0x80131CB4: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_1;
    // 0x80131CB4: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_1:
    // 0x80131CB8: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80131CBC: addiu       $s2, $s2, 0x62F8
    ctx->r18 = ADD32(ctx->r18, 0X62F8);
    // 0x80131CC0: sw          $v0, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r2;
    // 0x80131CC4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80131CC8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80131CCC: jal         0x80129290
    // 0x80131CD0: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    dma_read(rdram, ctx);
        goto after_2;
    // 0x80131CD0: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_2:
    // 0x80131CD4: lui         $a1, 0x13
    ctx->r5 = S32(0X13 << 16);
    // 0x80131CD8: addiu       $a1, $a1, 0x3450
    ctx->r5 = ADD32(ctx->r5, 0X3450);
    // 0x80131CDC: jal         0x8013A4D4
    // 0x80131CE0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alBnkfNew(rdram, ctx);
        goto after_3;
    // 0x80131CE0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_3:
    // 0x80131CE4: lui         $t3, 0x1C
    ctx->r11 = S32(0X1C << 16);
    // 0x80131CE8: lui         $t4, 0x1B
    ctx->r12 = S32(0X1B << 16);
    // 0x80131CEC: addiu       $t4, $t4, 0x6510
    ctx->r12 = ADD32(ctx->r12, 0X6510);
    // 0x80131CF0: addiu       $t3, $t3, 0x7C80
    ctx->r11 = ADD32(ctx->r11, 0X7C80);
    // 0x80131CF4: subu        $s0, $t3, $t4
    ctx->r16 = SUB32(ctx->r11, ctx->r12);
    // 0x80131CF8: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    // 0x80131CFC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131D00: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131D04: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131D08: jal         0x80139A40
    // 0x80131D0C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_4;
    // 0x80131D0C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_4:
    // 0x80131D10: lui         $s1, 0x8028
    ctx->r17 = S32(0X8028 << 16);
    // 0x80131D14: addiu       $s1, $s1, 0x62FC
    ctx->r17 = ADD32(ctx->r17, 0X62FC);
    // 0x80131D18: lui         $a0, 0x1B
    ctx->r4 = S32(0X1B << 16);
    // 0x80131D1C: sw          $v0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r2;
    // 0x80131D20: addiu       $a0, $a0, 0x6510
    ctx->r4 = ADD32(ctx->r4, 0X6510);
    // 0x80131D24: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80131D28: jal         0x80129290
    // 0x80131D2C: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    dma_read(rdram, ctx);
        goto after_5;
    // 0x80131D2C: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_5:
    // 0x80131D30: lui         $a1, 0x1C
    ctx->r5 = S32(0X1C << 16);
    // 0x80131D34: addiu       $a1, $a1, 0x7C80
    ctx->r5 = ADD32(ctx->r5, 0X7C80);
    // 0x80131D38: jal         0x8013A4D4
    // 0x80131D3C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    alBnkfNew(rdram, ctx);
        goto after_6;
    // 0x80131D3C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_6:
    // 0x80131D40: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x80131D44: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80131D48: addiu       $t7, $zero, 0x18
    ctx->r15 = ADD32(0, 0X18);
    // 0x80131D4C: lw          $t9, 0x4($t5)
    ctx->r25 = MEM_W(ctx->r13, 0X4);
    // 0x80131D50: addiu       $t6, $zero, 0x14
    ctx->r14 = ADD32(0, 0X14);
    // 0x80131D54: addiu       $t1, $zero, 0xB4
    ctx->r9 = ADD32(0, 0XB4);
    // 0x80131D58: sw          $t9, 0x6300($at)
    MEM_W(0X6300, ctx->r1) = ctx->r25;
    // 0x80131D5C: lw          $t8, 0x0($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X0);
    // 0x80131D60: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80131D64: addiu       $t2, $zero, 0x6
    ctx->r10 = ADD32(0, 0X6);
    // 0x80131D68: lw          $t0, 0x4($t8)
    ctx->r8 = MEM_W(ctx->r24, 0X4);
    // 0x80131D6C: sw          $t7, 0x1EC($sp)
    MEM_W(0X1EC, ctx->r29) = ctx->r15;
    // 0x80131D70: sw          $t6, 0x1F0($sp)
    MEM_W(0X1F0, ctx->r29) = ctx->r14;
    // 0x80131D74: sw          $t1, 0x1F4($sp)
    MEM_W(0X1F4, ctx->r29) = ctx->r9;
    // 0x80131D78: sw          $zero, 0x1FC($sp)
    MEM_W(0X1FC, ctx->r29) = 0;
    // 0x80131D7C: sb          $t2, 0x208($sp)
    MEM_B(0X208, ctx->r29) = ctx->r10;
    // 0x80131D80: addiu       $a0, $zero, 0x7D00
    ctx->r4 = ADD32(0, 0X7D00);
    // 0x80131D84: jal         0x80139820
    // 0x80131D88: sw          $t0, 0x6304($at)
    MEM_W(0X6304, ctx->r1) = ctx->r8;
    osAiSetFrequency_recomp(rdram, ctx);
        goto after_7;
    // 0x80131D88: sw          $t0, 0x6304($at)
    MEM_W(0X6304, ctx->r1) = ctx->r8;
    after_7:
    // 0x80131D8C: addiu       $t3, $sp, 0x48
    ctx->r11 = ADD32(ctx->r29, 0X48);
    // 0x80131D90: sw          $v0, 0x204($sp)
    MEM_W(0X204, ctx->r29) = ctx->r2;
    // 0x80131D94: sw          $s3, 0x200($sp)
    MEM_W(0X200, ctx->r29) = ctx->r19;
    // 0x80131D98: sw          $t3, 0x20C($sp)
    MEM_W(0X20C, ctx->r29) = ctx->r11;
    // 0x80131D9C: addiu       $a0, $sp, 0x1EC
    ctx->r4 = ADD32(ctx->r29, 0X1EC);
    // 0x80131DA0: jal         0x80131290
    // 0x80131DA4: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    amCreateAudioMgr(rdram, ctx);
        goto after_8;
    // 0x80131DA4: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    after_8:
    // 0x80131DA8: lui         $s1, 0x8028
    ctx->r17 = S32(0X8028 << 16);
    // 0x80131DAC: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80131DB0: addiu       $s2, $s2, 0x63CC
    ctx->r18 = ADD32(ctx->r18, 0X63CC);
    // 0x80131DB4: addiu       $s1, $s1, 0x63C8
    ctx->r17 = ADD32(ctx->r17, 0X63C8);
    // 0x80131DB8: addiu       $s0, $sp, 0x170
    ctx->r16 = ADD32(ctx->r29, 0X170);
L_80131DBC:
    // 0x80131DBC: addiu       $t4, $zero, 0xC
    ctx->r12 = ADD32(0, 0XC);
    // 0x80131DC0: addiu       $t5, $zero, 0x100
    ctx->r13 = ADD32(0, 0X100);
    // 0x80131DC4: addiu       $t9, $zero, 0x10
    ctx->r25 = ADD32(0, 0X10);
    // 0x80131DC8: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x80131DCC: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x80131DD0: sb          $t9, 0x8($s0)
    MEM_B(0X8, ctx->r16) = ctx->r25;
    // 0x80131DD4: sw          $s3, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r19;
    // 0x80131DD8: sw          $zero, 0x10($s0)
    MEM_W(0X10, ctx->r16) = 0;
    // 0x80131DDC: sw          $zero, 0x14($s0)
    MEM_W(0X14, ctx->r16) = 0;
    // 0x80131DE0: sw          $zero, 0x18($s0)
    MEM_W(0X18, ctx->r16) = 0;
    // 0x80131DE4: addiu       $t8, $zero, 0x7C
    ctx->r24 = ADD32(0, 0X7C);
    // 0x80131DE8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80131DEC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131DF0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131DF4: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131DF8: jal         0x80139A40
    // 0x80131DFC: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_9;
    // 0x80131DFC: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_9:
    // 0x80131E00: sw          $v0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r2;
    // 0x80131E04: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80131E08: jal         0x80133F00
    // 0x80131E0C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    alCSPNew(rdram, ctx);
        goto after_10;
    // 0x80131E0C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_10:
    // 0x80131E10: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x80131E14: addiu       $t7, $zero, 0xF8
    ctx->r15 = ADD32(0, 0XF8);
    // 0x80131E18: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131E1C: sw          $zero, 0x2C($t0)
    MEM_W(0X2C, ctx->r8) = 0;
    // 0x80131E20: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80131E24: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131E28: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131E2C: jal         0x80139A40
    // 0x80131E30: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_11;
    // 0x80131E30: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_11:
    // 0x80131E34: lui         $t6, 0x8028
    ctx->r14 = S32(0X8028 << 16);
    // 0x80131E38: addiu       $t6, $t6, 0x63D0
    ctx->r14 = ADD32(ctx->r14, 0X63D0);
    // 0x80131E3C: addiu       $s2, $s2, 0x4
    ctx->r18 = ADD32(ctx->r18, 0X4);
    // 0x80131E40: sltu        $at, $s2, $t6
    ctx->r1 = ctx->r18 < ctx->r14 ? 1 : 0;
    // 0x80131E44: addiu       $s0, $s0, 0x1C
    ctx->r16 = ADD32(ctx->r16, 0X1C);
    // 0x80131E48: addiu       $s1, $s1, 0x4
    ctx->r17 = ADD32(ctx->r17, 0X4);
    // 0x80131E4C: bne         $at, $zero, L_80131DBC
    if (ctx->r1 != 0) {
        // 0x80131E50: sw          $v0, -0x4($s2)
        MEM_W(-0X4, ctx->r18) = ctx->r2;
            goto L_80131DBC;
    }
    // 0x80131E50: sw          $v0, -0x4($s2)
    MEM_W(-0X4, ctx->r18) = ctx->r2;
    // 0x80131E54: addiu       $t1, $zero, 0x8
    ctx->r9 = ADD32(0, 0X8);
    // 0x80131E58: addiu       $t2, $zero, 0x100
    ctx->r10 = ADD32(0, 0X100);
    // 0x80131E5C: addiu       $t3, $zero, 0x54
    ctx->r11 = ADD32(0, 0X54);
    // 0x80131E60: sw          $t1, 0x1E0($sp)
    MEM_W(0X1E0, ctx->r29) = ctx->r9;
    // 0x80131E64: sw          $t2, 0x1E4($sp)
    MEM_W(0X1E4, ctx->r29) = ctx->r10;
    // 0x80131E68: sw          $s3, 0x1E8($sp)
    MEM_W(0X1E8, ctx->r29) = ctx->r19;
    // 0x80131E6C: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80131E70: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131E74: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131E78: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131E7C: jal         0x80139A40
    // 0x80131E80: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_12;
    // 0x80131E80: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_12:
    // 0x80131E84: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x80131E88: addiu       $v1, $v1, 0x6310
    ctx->r3 = ADD32(ctx->r3, 0X6310);
    // 0x80131E8C: sw          $v0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r2;
    // 0x80131E90: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80131E94: jal         0x8013ABF4
    // 0x80131E98: addiu       $a1, $sp, 0x1E0
    ctx->r5 = ADD32(ctx->r29, 0X1E0);
    alSndpNew(rdram, ctx);
        goto after_13;
    // 0x80131E98: addiu       $a1, $sp, 0x1E0
    ctx->r5 = ADD32(ctx->r29, 0X1E0);
    after_13:
    // 0x80131E9C: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80131EA0: lui         $s1, 0x8028
    ctx->r17 = S32(0X8028 << 16);
    // 0x80131EA4: addiu       $s1, $s1, 0x6388
    ctx->r17 = ADD32(ctx->r17, 0X6388);
    // 0x80131EA8: addiu       $s0, $s0, 0x6338
    ctx->r16 = ADD32(ctx->r16, 0X6338);
L_80131EAC:
    // 0x80131EAC: addiu       $t4, $zero, 0x34
    ctx->r12 = ADD32(0, 0X34);
    // 0x80131EB0: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80131EB4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131EB8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131EBC: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131EC0: jal         0x80139A40
    // 0x80131EC4: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_14;
    // 0x80131EC4: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_14:
    // 0x80131EC8: addiu       $s0, $s0, 0x4
    ctx->r16 = ADD32(ctx->r16, 0X4);
    // 0x80131ECC: bne         $s0, $s1, L_80131EAC
    if (ctx->r16 != ctx->r17) {
        // 0x80131ED0: sw          $v0, -0x4($s0)
        MEM_W(-0X4, ctx->r16) = ctx->r2;
            goto L_80131EAC;
    }
    // 0x80131ED0: sw          $v0, -0x4($s0)
    MEM_W(-0X4, ctx->r16) = ctx->r2;
    // 0x80131ED4: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80131ED8: addiu       $v0, $v0, 0x6320
    ctx->r2 = ADD32(ctx->r2, 0X6320);
    // 0x80131EDC: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80131EE0: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80131EE4: sw          $zero, 0x631C($at)
    MEM_W(0X631C, ctx->r1) = 0;
    // 0x80131EE8: jal         0x80132044
    // 0x80131EEC: addiu       $a0, $zero, -0x1
    ctx->r4 = ADD32(0, -0X1);
    func_80132044(rdram, ctx);
        goto after_15;
    // 0x80131EEC: addiu       $a0, $zero, -0x1
    ctx->r4 = ADD32(0, -0X1);
    after_15:
    // 0x80131EF0: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x80131EF4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80131EF8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131EFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131F00: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131F04: jal         0x80139A40
    // 0x80131F08: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    alHeapDBAlloc(rdram, ctx);
        goto after_16;
    // 0x80131F08: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_16:
    // 0x80131F0C: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80131F10: addiu       $s0, $s0, 0x6308
    ctx->r16 = ADD32(ctx->r16, 0X6308);
    // 0x80131F14: jal         0x80137EB0
    // 0x80131F18: sw          $v0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r2;
    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_17;
    // 0x80131F18: sw          $v0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r2;
    after_17:
    // 0x80131F1C: lui         $s2, 0x41
    ctx->r18 = S32(0X41 << 16);
    // 0x80131F20: addiu       $s2, $s2, -0x4DF0
    ctx->r18 = ADD32(ctx->r18, -0X4DF0);
    // 0x80131F24: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80131F28: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x80131F2C: jal         0x80129290
    // 0x80131F30: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    dma_read(rdram, ctx);
        goto after_18;
    // 0x80131F30: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    after_18:
    // 0x80131F34: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80131F38: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80131F3C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80131F40: lh          $v0, 0x2($t8)
    ctx->r2 = MEM_H(ctx->r24, 0X2);
    // 0x80131F44: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80131F48: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x80131F4C: sll         $t0, $v0, 3
    ctx->r8 = S32(ctx->r2 << 3);
    // 0x80131F50: addiu       $v0, $t0, 0x4
    ctx->r2 = ADD32(ctx->r8, 0X4);
    // 0x80131F54: sll         $s1, $v0, 16
    ctx->r17 = S32(ctx->r2 << 16);
    // 0x80131F58: sra         $t7, $s1, 16
    ctx->r15 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80131F5C: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x80131F60: jal         0x80139A40
    // 0x80131F64: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    alHeapDBAlloc(rdram, ctx);
        goto after_19;
    // 0x80131F64: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    after_19:
    // 0x80131F68: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80131F6C: addiu       $s0, $s0, 0x630C
    ctx->r16 = ADD32(ctx->r16, 0X630C);
    // 0x80131F70: jal         0x80137EB0
    // 0x80131F74: sw          $v0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r2;
    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_20;
    // 0x80131F74: sw          $v0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r2;
    after_20:
    // 0x80131F78: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80131F7C: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x80131F80: jal         0x80129290
    // 0x80131F84: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    dma_read(rdram, ctx);
        goto after_21;
    // 0x80131F84: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_21:
    // 0x80131F88: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x80131F8C: jal         0x8013A5D8
    // 0x80131F90: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    alSeqFileNew(rdram, ctx);
        goto after_22;
    // 0x80131F90: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    after_22:
    // 0x80131F94: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x80131F98: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80131F9C: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80131FA0: lh          $a2, 0x2($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X2);
    // 0x80131FA4: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80131FA8: addiu       $s2, $s2, 0x6318
    ctx->r18 = ADD32(ctx->r18, 0X6318);
    // 0x80131FAC: blez        $a2, L_80131FEC
    if (SIGNED(ctx->r6) <= 0) {
        // 0x80131FB0: addiu       $s0, $s0, 0x6314
        ctx->r16 = ADD32(ctx->r16, 0X6314);
            goto L_80131FEC;
    }
    // 0x80131FB0: addiu       $s0, $s0, 0x6314
    ctx->r16 = ADD32(ctx->r16, 0X6314);
    // 0x80131FB4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80131FB8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x80131FBC: sll         $a1, $a2, 3
    ctx->r5 = S32(ctx->r6 << 3);
L_80131FC0:
    // 0x80131FC0: lw          $a0, 0x8($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X8);
    // 0x80131FC4: addiu       $v0, $v0, 0x8
    ctx->r2 = ADD32(ctx->r2, 0X8);
    // 0x80131FC8: slt         $at, $s1, $a0
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80131FCC: beql        $at, $zero, L_80131FE4
    if (ctx->r1 == 0) {
        // 0x80131FD0: slt         $at, $v0, $a1
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_80131FE4;
    }
    goto skip_0;
    // 0x80131FD0: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
    skip_0:
    // 0x80131FD4: sll         $s1, $a0, 16
    ctx->r17 = S32(ctx->r4 << 16);
    // 0x80131FD8: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80131FDC: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x80131FE0: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
L_80131FE4:
    // 0x80131FE4: bne         $at, $zero, L_80131FC0
    if (ctx->r1 != 0) {
        // 0x80131FE8: addiu       $v1, $v1, 0x8
        ctx->r3 = ADD32(ctx->r3, 0X8);
            goto L_80131FC0;
    }
    // 0x80131FE8: addiu       $v1, $v1, 0x8
    ctx->r3 = ADD32(ctx->r3, 0X8);
L_80131FEC:
    // 0x80131FEC: andi        $t1, $s1, 0x1
    ctx->r9 = ctx->r17 & 0X1;
    // 0x80131FF0: beq         $t1, $zero, L_80132004
    if (ctx->r9 == 0) {
        // 0x80131FF4: nop
    
            goto L_80132004;
    }
    // 0x80131FF4: nop

    // 0x80131FF8: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x80131FFC: sll         $t2, $s1, 16
    ctx->r10 = S32(ctx->r17 << 16);
    // 0x80132000: sra         $s1, $t2, 16
    ctx->r17 = S32(SIGNED(ctx->r10) >> 16);
L_80132004:
    // 0x80132004: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80132008: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8013200C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80132010: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x80132014: jal         0x80139A40
    // 0x80132018: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    alHeapDBAlloc(rdram, ctx);
        goto after_23;
    // 0x80132018: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    after_23:
    // 0x8013201C: addiu       $s0, $s0, 0x4
    ctx->r16 = ADD32(ctx->r16, 0X4);
    // 0x80132020: bne         $s0, $s2, L_80132004
    if (ctx->r16 != ctx->r18) {
        // 0x80132024: sw          $v0, -0x4($s0)
        MEM_W(-0X4, ctx->r16) = ctx->r2;
            goto L_80132004;
    }
    // 0x80132024: sw          $v0, -0x4($s0)
    MEM_W(-0X4, ctx->r16) = ctx->r2;
    // 0x80132028: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8013202C: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x80132030: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x80132034: lw          $s2, 0x24($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X24);
    // 0x80132038: lw          $s3, 0x28($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X28);
    // 0x8013203C: jr          $ra
    // 0x80132040: addiu       $sp, $sp, 0x218
    ctx->r29 = ADD32(ctx->r29, 0X218);
    return;
    // 0x80132040: addiu       $sp, $sp, 0x218
    ctx->r29 = ADD32(ctx->r29, 0X218);
;}
RECOMP_FUNC void func_80132044(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132044: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80132048: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x8013204C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80132050: beq         $t6, $zero, L_801320E4
    if (ctx->r14 == 0) {
        // 0x80132054: nop
    
            goto L_801320E4;
    }
    // 0x80132054: nop

    // 0x80132058: bne         $a0, $at, L_801320C4
    if (ctx->r4 != ctx->r1) {
        // 0x8013205C: lui         $v0, 0x8015
        ctx->r2 = S32(0X8015 << 16);
            goto L_801320C4;
    }
    // 0x8013205C: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80132060: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80132064: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x80132068: addiu       $v1, $v1, 0x63B0
    ctx->r3 = ADD32(ctx->r3, 0X63B0);
    // 0x8013206C: addiu       $v0, $v0, 0x6388
    ctx->r2 = ADD32(ctx->r2, 0X6388);
    // 0x80132070: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80132074: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
L_80132078:
    // 0x80132078: addiu       $t7, $a0, 0x1
    ctx->r15 = ADD32(ctx->r4, 0X1);
    // 0x8013207C: addiu       $t8, $a0, 0x2
    ctx->r24 = ADD32(ctx->r4, 0X2);
    // 0x80132080: addiu       $t9, $a0, 0x3
    ctx->r25 = ADD32(ctx->r4, 0X3);
    // 0x80132084: sh          $a0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r4;
    // 0x80132088: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
    // 0x8013208C: sh          $t9, 0x6($v0)
    MEM_H(0X6, ctx->r2) = ctx->r25;
    // 0x80132090: sh          $t8, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r24;
    // 0x80132094: sh          $t7, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r15;
    // 0x80132098: sb          $zero, 0x1($v1)
    MEM_B(0X1, ctx->r3) = 0;
    // 0x8013209C: sb          $zero, 0x2($v1)
    MEM_B(0X2, ctx->r3) = 0;
    // 0x801320A0: sb          $zero, 0x3($v1)
    MEM_B(0X3, ctx->r3) = 0;
    // 0x801320A4: addiu       $v0, $v0, 0x8
    ctx->r2 = ADD32(ctx->r2, 0X8);
    // 0x801320A8: addiu       $v1, $v1, 0x4
    ctx->r3 = ADD32(ctx->r3, 0X4);
    // 0x801320AC: bne         $a0, $a1, L_80132078
    if (ctx->r4 != ctx->r5) {
        // 0x801320B0: sb          $zero, -0x4($v1)
        MEM_B(-0X4, ctx->r3) = 0;
            goto L_80132078;
    }
    // 0x801320B0: sb          $zero, -0x4($v1)
    MEM_B(-0X4, ctx->r3) = 0;
    // 0x801320B4: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x801320B8: addiu       $v0, $v0, 0x468C
    ctx->r2 = ADD32(ctx->r2, 0X468C);
    // 0x801320BC: jr          $ra
    // 0x801320C0: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    return;
    // 0x801320C0: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
L_801320C4:
    // 0x801320C4: sll         $t0, $a0, 1
    ctx->r8 = S32(ctx->r4 << 1);
    // 0x801320C8: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801320CC: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x801320D0: addiu       $v0, $v0, 0x468C
    ctx->r2 = ADD32(ctx->r2, 0X468C);
    // 0x801320D4: sh          $a0, 0x6388($at)
    MEM_H(0X6388, ctx->r1) = ctx->r4;
    // 0x801320D8: lh          $t1, 0x0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X0);
    // 0x801320DC: addiu       $t2, $t1, -0x1
    ctx->r10 = ADD32(ctx->r9, -0X1);
    // 0x801320E0: sh          $t2, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r10;
L_801320E4:
    // 0x801320E4: jr          $ra
    // 0x801320E8: nop

    return;
    // 0x801320E8: nop

;}
RECOMP_FUNC void func_801320EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801320EC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x801320F0: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x801320F4: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x801320F8: bne         $t6, $zero, L_80132108
    if (ctx->r14 != 0) {
        // 0x801320FC: nop
    
            goto L_80132108;
    }
    // 0x801320FC: nop

    // 0x80132100: jr          $ra
    // 0x80132104: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80132104: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80132108:
    // 0x80132108: lh          $t7, 0x468C($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X468C);
    // 0x8013210C: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80132110: addiu       $v0, $v0, 0x6388
    ctx->r2 = ADD32(ctx->r2, 0X6388);
    // 0x80132114: slti        $at, $t7, 0x15
    ctx->r1 = SIGNED(ctx->r15) < 0X15 ? 1 : 0;
    // 0x80132118: bne         $at, $zero, L_80132128
    if (ctx->r1 != 0) {
        // 0x8013211C: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_80132128;
    }
    // 0x8013211C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80132120: jr          $ra
    // 0x80132124: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80132124: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80132128:
    // 0x80132128: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x8013212C: addiu       $a0, $zero, -0x1
    ctx->r4 = ADD32(0, -0X1);
L_80132130:
    // 0x80132130: lh          $t8, 0x0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X0);
    // 0x80132134: beql        $a0, $t8, L_80132148
    if (ctx->r4 == ctx->r24) {
        // 0x80132138: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_80132148;
    }
    goto skip_0;
    // 0x80132138: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    skip_0:
    // 0x8013213C: b           L_80132150
    // 0x80132140: sh          $a0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r4;
        goto L_80132150;
    // 0x80132140: sh          $a0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r4;
    // 0x80132144: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_80132148:
    // 0x80132148: bne         $v1, $a1, L_80132130
    if (ctx->r3 != ctx->r5) {
        // 0x8013214C: addiu       $v0, $v0, 0x2
        ctx->r2 = ADD32(ctx->r2, 0X2);
            goto L_80132130;
    }
    // 0x8013214C: addiu       $v0, $v0, 0x2
    ctx->r2 = ADD32(ctx->r2, 0X2);
L_80132150:
    // 0x80132150: lui         $t0, 0x8028
    ctx->r8 = S32(0X8028 << 16);
    // 0x80132154: addiu       $t0, $t0, 0x6338
    ctx->r8 = ADD32(ctx->r8, 0X6338);
    // 0x80132158: sll         $t9, $v1, 2
    ctx->r25 = S32(ctx->r3 << 2);
    // 0x8013215C: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    // 0x80132160: lw          $t1, 0x0($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X0);
    // 0x80132164: sh          $v1, 0x1E($t1)
    MEM_H(0X1E, ctx->r9) = ctx->r3;
    // 0x80132168: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8013216C: jr          $ra
    // 0x80132170: nop

    return;
    // 0x80132170: nop

;}
RECOMP_FUNC void func_80132174(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132174: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80132178: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8013217C: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80132180: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80132184: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80132188: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x8013218C: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x80132190: beq         $t6, $zero, L_801322DC
    if (ctx->r14 == 0) {
        // 0x80132194: sw          $a3, 0x2C($sp)
        MEM_W(0X2C, ctx->r29) = ctx->r7;
            goto L_801322DC;
    }
    // 0x80132194: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x80132198: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8013219C: addiu       $v1, $v1, 0x468C
    ctx->r3 = ADD32(ctx->r3, 0X468C);
    // 0x801321A0: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x801321A4: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
    // 0x801321A8: slti        $at, $v0, 0x14
    ctx->r1 = SIGNED(ctx->r2) < 0X14 ? 1 : 0;
    // 0x801321AC: beq         $at, $zero, L_801322DC
    if (ctx->r1 == 0) {
        // 0x801321B0: lw          $a0, 0x0($t0)
        ctx->r4 = MEM_W(ctx->r8, 0X0);
            goto L_801322DC;
    }
    // 0x801321B0: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x801321B4: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x801321B8: sh          $t7, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r15;
    // 0x801321BC: jal         0x801320EC
    // 0x801321C0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    func_801320EC(rdram, ctx);
        goto after_0;
    // 0x801321C0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x801321C4: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x801321C8: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
    // 0x801321CC: beq         $v0, $zero, L_801322DC
    if (ctx->r2 == 0) {
        // 0x801321D0: or          $a3, $v0, $zero
        ctx->r7 = ctx->r2 | 0;
            goto L_801322DC;
    }
    // 0x801321D0: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    // 0x801321D4: addiu       $t8, $sp, 0x20
    ctx->r24 = ADD32(ctx->r29, 0X20);
    // 0x801321D8: lw          $a2, 0x58($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X58);
    // 0x801321DC: lh          $v1, 0x1E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X1E);
    // 0x801321E0: addiu       $t1, $t8, 0x30
    ctx->r9 = ADD32(ctx->r24, 0X30);
    // 0x801321E4: or          $t2, $v0, $zero
    ctx->r10 = ctx->r2 | 0;
L_801321E8:
    // 0x801321E8: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x801321EC: addiu       $t8, $t8, 0xC
    ctx->r24 = ADD32(ctx->r24, 0XC);
    // 0x801321F0: addiu       $t2, $t2, 0xC
    ctx->r10 = ADD32(ctx->r10, 0XC);
    // 0x801321F4: sw          $at, -0xC($t2)
    MEM_W(-0XC, ctx->r10) = ctx->r1;
    // 0x801321F8: lw          $at, -0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, -0X8);
    // 0x801321FC: sw          $at, -0x8($t2)
    MEM_W(-0X8, ctx->r10) = ctx->r1;
    // 0x80132200: lw          $at, -0x4($t8)
    ctx->r1 = MEM_W(ctx->r24, -0X4);
    // 0x80132204: bne         $t8, $t1, L_801321E8
    if (ctx->r24 != ctx->r9) {
        // 0x80132208: sw          $at, -0x4($t2)
        MEM_W(-0X4, ctx->r10) = ctx->r1;
            goto L_801321E8;
    }
    // 0x80132208: sw          $at, -0x4($t2)
    MEM_W(-0X4, ctx->r10) = ctx->r1;
    // 0x8013220C: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x80132210: sw          $at, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r1;
    // 0x80132214: sh          $v1, 0x1E($v0)
    MEM_H(0X1E, ctx->r2) = ctx->r3;
    // 0x80132218: lw          $t3, 0x0($a2)
    ctx->r11 = MEM_W(ctx->r6, 0X0);
    // 0x8013221C: bne         $t3, $zero, L_80132238
    if (ctx->r11 != 0) {
        // 0x80132220: nop
    
            goto L_80132238;
    }
    // 0x80132220: nop

    // 0x80132224: sw          $zero, 0x30($v0)
    MEM_W(0X30, ctx->r2) = 0;
    // 0x80132228: sw          $zero, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = 0;
    // 0x8013222C: sw          $v0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r2;
    // 0x80132230: b           L_801322DC
    // 0x80132234: sw          $v0, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r2;
        goto L_801322DC;
    // 0x80132234: sw          $v0, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r2;
L_80132238:
    // 0x80132238: beq         $a0, $zero, L_801322CC
    if (ctx->r4 == 0) {
        // 0x8013223C: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_801322CC;
    }
    // 0x8013223C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80132240: lhu         $a1, 0x0($v0)
    ctx->r5 = MEM_HU(ctx->r2, 0X0);
    // 0x80132244: lhu         $t4, 0x0($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X0);
L_80132248:
    // 0x80132248: subu        $v1, $t4, $a1
    ctx->r3 = SUB32(ctx->r12, ctx->r5);
    // 0x8013224C: bgez        $v1, L_8013225C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80132250: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_8013225C;
    }
    // 0x80132250: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x80132254: b           L_801322C4
    // 0x80132258: lw          $a0, 0x30($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X30);
        goto L_801322C4;
    // 0x80132258: lw          $a0, 0x30($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X30);
L_8013225C:
    // 0x8013225C: lw          $v1, 0x2C($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X2C);
    // 0x80132260: beql        $v1, $zero, L_80132284
    if (ctx->r3 == 0) {
        // 0x80132264: lhu         $t6, 0x2($v0)
        ctx->r14 = MEM_HU(ctx->r2, 0X2);
            goto L_80132284;
    }
    goto skip_0;
    // 0x80132264: lhu         $t6, 0x2($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2);
    skip_0:
    // 0x80132268: sw          $v0, 0x30($v1)
    MEM_W(0X30, ctx->r3) = ctx->r2;
    // 0x8013226C: sw          $a0, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r4;
    // 0x80132270: lw          $t5, 0x2C($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X2C);
    // 0x80132274: sw          $t5, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->r13;
    // 0x80132278: b           L_801322DC
    // 0x8013227C: sw          $v0, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = ctx->r2;
        goto L_801322DC;
    // 0x8013227C: sw          $v0, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = ctx->r2;
    // 0x80132280: lhu         $t6, 0x2($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2);
L_80132284:
    // 0x80132284: lhu         $t7, 0x2($a0)
    ctx->r15 = MEM_HU(ctx->r4, 0X2);
    // 0x80132288: bnel        $t6, $t7, L_801322B4
    if (ctx->r14 != ctx->r15) {
        // 0x8013228C: sw          $a0, 0x30($v0)
        MEM_W(0X30, ctx->r2) = ctx->r4;
            goto L_801322B4;
    }
    goto skip_1;
    // 0x8013228C: sw          $a0, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r4;
    skip_1:
    // 0x80132290: lh          $t9, 0x22($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X22);
    // 0x80132294: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80132298: bnel        $t9, $at, L_801322B4
    if (ctx->r25 != ctx->r1) {
        // 0x8013229C: sw          $a0, 0x30($v0)
        MEM_W(0X30, ctx->r2) = ctx->r4;
            goto L_801322B4;
    }
    goto skip_2;
    // 0x8013229C: sw          $a0, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r4;
    skip_2:
    // 0x801322A0: jal         0x80132044
    // 0x801322A4: lh          $a0, 0x1E($a3)
    ctx->r4 = MEM_H(ctx->r7, 0X1E);
    func_80132044(rdram, ctx);
        goto after_1;
    // 0x801322A4: lh          $a0, 0x1E($a3)
    ctx->r4 = MEM_H(ctx->r7, 0X1E);
    after_1:
    // 0x801322A8: b           L_801322E0
    // 0x801322AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_801322E0;
    // 0x801322AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x801322B0: sw          $a0, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->r4;
L_801322B4:
    // 0x801322B4: sw          $zero, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = 0;
    // 0x801322B8: sw          $v0, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = ctx->r2;
    // 0x801322BC: b           L_801322DC
    // 0x801322C0: sw          $v0, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r2;
        goto L_801322DC;
    // 0x801322C0: sw          $v0, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r2;
L_801322C4:
    // 0x801322C4: bnel        $a0, $zero, L_80132248
    if (ctx->r4 != 0) {
        // 0x801322C8: lhu         $t4, 0x0($a0)
        ctx->r12 = MEM_HU(ctx->r4, 0X0);
            goto L_80132248;
    }
    goto skip_3;
    // 0x801322C8: lhu         $t4, 0x0($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X0);
    skip_3:
L_801322CC:
    // 0x801322CC: sw          $v0, 0x30($v1)
    MEM_W(0X30, ctx->r3) = ctx->r2;
    // 0x801322D0: sw          $zero, 0x30($v0)
    MEM_W(0X30, ctx->r2) = 0;
    // 0x801322D4: sw          $v1, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->r3;
    // 0x801322D8: sw          $v0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r2;
L_801322DC:
    // 0x801322DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801322E0:
    // 0x801322E0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x801322E4: jr          $ra
    // 0x801322E8: nop

    return;
    // 0x801322E8: nop

;}
RECOMP_FUNC void func_801322EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801322EC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x801322F0: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x801322F4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801322F8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801322FC: beq         $t6, $zero, L_80132384
    if (ctx->r14 == 0) {
        // 0x80132300: or          $a3, $a0, $zero
        ctx->r7 = ctx->r4 | 0;
            goto L_80132384;
    }
    // 0x80132300: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x80132304: beql        $a0, $zero, L_80132388
    if (ctx->r4 == 0) {
        // 0x80132308: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80132388;
    }
    goto skip_0;
    // 0x80132308: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x8013230C: lh          $a0, 0x1E($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X1E);
    // 0x80132310: sw          $a3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r7;
    // 0x80132314: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x80132318: jal         0x80132044
    // 0x8013231C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    func_80132044(rdram, ctx);
        goto after_0;
    // 0x8013231C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80132320: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80132324: lw          $a3, 0x18($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X18);
    // 0x80132328: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x8013232C: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x80132330: bnel        $a3, $t7, L_80132358
    if (ctx->r7 != ctx->r15) {
        // 0x80132334: lw          $t9, 0x30($a3)
        ctx->r25 = MEM_W(ctx->r7, 0X30);
            goto L_80132358;
    }
    goto skip_1;
    // 0x80132334: lw          $t9, 0x30($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X30);
    skip_1:
    // 0x80132338: lw          $t8, 0x30($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X30);
    // 0x8013233C: beq         $t8, $zero, L_8013234C
    if (ctx->r24 == 0) {
        // 0x80132340: sw          $t8, 0x0($a1)
        MEM_W(0X0, ctx->r5) = ctx->r24;
            goto L_8013234C;
    }
    // 0x80132340: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x80132344: b           L_80132384
    // 0x80132348: sw          $zero, 0x2C($t8)
    MEM_W(0X2C, ctx->r24) = 0;
        goto L_80132384;
    // 0x80132348: sw          $zero, 0x2C($t8)
    MEM_W(0X2C, ctx->r24) = 0;
L_8013234C:
    // 0x8013234C: b           L_80132384
    // 0x80132350: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
        goto L_80132384;
    // 0x80132350: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
    // 0x80132354: lw          $t9, 0x30($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X30);
L_80132358:
    // 0x80132358: lw          $t0, 0x2C($a3)
    ctx->r8 = MEM_W(ctx->r7, 0X2C);
    // 0x8013235C: sw          $t9, 0x30($t0)
    MEM_W(0X30, ctx->r8) = ctx->r25;
    // 0x80132360: lw          $t1, 0x0($a2)
    ctx->r9 = MEM_W(ctx->r6, 0X0);
    // 0x80132364: beql        $a3, $t1, L_80132380
    if (ctx->r7 == ctx->r9) {
        // 0x80132368: lw          $t4, 0x2C($a3)
        ctx->r12 = MEM_W(ctx->r7, 0X2C);
            goto L_80132380;
    }
    goto skip_2;
    // 0x80132368: lw          $t4, 0x2C($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X2C);
    skip_2:
    // 0x8013236C: lw          $t2, 0x2C($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X2C);
    // 0x80132370: lw          $t3, 0x30($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X30);
    // 0x80132374: b           L_80132384
    // 0x80132378: sw          $t2, 0x2C($t3)
    MEM_W(0X2C, ctx->r11) = ctx->r10;
        goto L_80132384;
    // 0x80132378: sw          $t2, 0x2C($t3)
    MEM_W(0X2C, ctx->r11) = ctx->r10;
    // 0x8013237C: lw          $t4, 0x2C($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X2C);
L_80132380:
    // 0x80132380: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
L_80132384:
    // 0x80132384: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80132388:
    // 0x80132388: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8013238C: jr          $ra
    // 0x80132390: nop

    return;
    // 0x80132390: nop

;}
RECOMP_FUNC void func_80132394(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132394: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80132398: lw          $v0, 0x631C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X631C);
    // 0x8013239C: beq         $v0, $zero, L_801323B0
    if (ctx->r2 == 0) {
        // 0x801323A0: nop
    
            goto L_801323B0;
    }
    // 0x801323A0: nop

    // 0x801323A4: lw          $v0, 0x30($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X30);
L_801323A8:
    // 0x801323A8: bnel        $v0, $zero, L_801323A8
    if (ctx->r2 != 0) {
        // 0x801323AC: lw          $v0, 0x30($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X30);
            goto L_801323A8;
    }
    goto skip_0;
    // 0x801323AC: lw          $v0, 0x30($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X30);
    skip_0:
L_801323B0:
    // 0x801323B0: jr          $ra
    // 0x801323B4: nop

    return;
    // 0x801323B4: nop

;}
RECOMP_FUNC void get_sound_by_slot(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801323B8: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x801323BC: lw          $t8, 0x5154($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5154);
    // 0x801323C0: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x801323C4: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x801323C8: bne         $t8, $zero, L_801323D8
    if (ctx->r24 != 0) {
        // 0x801323CC: sra         $a0, $t6, 16
        ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
            goto L_801323D8;
    }
    // 0x801323CC: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x801323D0: jr          $ra
    // 0x801323D4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x801323D4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_801323D8:
    // 0x801323D8: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x801323DC: lw          $v1, 0x631C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X631C);
    // 0x801323E0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x801323E4: beq         $v1, $zero, L_8013240C
    if (ctx->r3 == 0) {
        // 0x801323E8: nop
    
            goto L_8013240C;
    }
    // 0x801323E8: nop

    // 0x801323EC: lh          $t9, 0x22($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X22);
L_801323F0:
    // 0x801323F0: bnel        $a0, $t9, L_80132404
    if (ctx->r4 != ctx->r25) {
        // 0x801323F4: lw          $v1, 0x30($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X30);
            goto L_80132404;
    }
    goto skip_0;
    // 0x801323F4: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
    skip_0:
    // 0x801323F8: jr          $ra
    // 0x801323FC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x801323FC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x80132400: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
L_80132404:
    // 0x80132404: bnel        $v1, $zero, L_801323F0
    if (ctx->r3 != 0) {
        // 0x80132408: lh          $t9, 0x22($v1)
        ctx->r25 = MEM_H(ctx->r3, 0X22);
            goto L_801323F0;
    }
    goto skip_1;
    // 0x80132408: lh          $t9, 0x22($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X22);
    skip_1:
L_8013240C:
    // 0x8013240C: jr          $ra
    // 0x80132410: nop

    return;
    // 0x80132410: nop

;}
RECOMP_FUNC void get_sound_by_id(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132414: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80132418: lw          $t7, 0x5154($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5154);
    // 0x8013241C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80132420: andi        $t6, $a0, 0xFFFF
    ctx->r14 = ctx->r4 & 0XFFFF;
    // 0x80132424: bne         $t7, $zero, L_80132434
    if (ctx->r15 != 0) {
        // 0x80132428: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_80132434;
    }
    // 0x80132428: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x8013242C: jr          $ra
    // 0x80132430: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80132430: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80132434:
    // 0x80132434: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x80132438: lw          $v1, 0x631C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X631C);
    // 0x8013243C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x80132440: beql        $v1, $zero, L_8013246C
    if (ctx->r3 == 0) {
        // 0x80132444: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8013246C;
    }
    goto skip_0;
    // 0x80132444: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80132448: lhu         $t8, 0x2($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X2);
L_8013244C:
    // 0x8013244C: bnel        $t8, $v0, L_80132460
    if (ctx->r24 != ctx->r2) {
        // 0x80132450: lw          $v1, 0x30($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X30);
            goto L_80132460;
    }
    goto skip_1;
    // 0x80132450: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
    skip_1:
    // 0x80132454: jr          $ra
    // 0x80132458: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80132458: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8013245C: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
L_80132460:
    // 0x80132460: bnel        $v1, $zero, L_8013244C
    if (ctx->r3 != 0) {
        // 0x80132464: lhu         $t8, 0x2($v1)
        ctx->r24 = MEM_HU(ctx->r3, 0X2);
            goto L_8013244C;
    }
    goto skip_2;
    // 0x80132464: lhu         $t8, 0x2($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X2);
    skip_2:
    // 0x80132468: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8013246C:
    // 0x8013246C: jr          $ra
    // 0x80132470: nop

    return;
    // 0x80132470: nop

;}
RECOMP_FUNC void func_80132474(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132474: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80132478: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8013247C: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80132480: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80132484: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x80132488: sw          $s4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r20;
    // 0x8013248C: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x80132490: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x80132494: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80132498: bne         $t6, $zero, L_801324A8
    if (ctx->r14 != 0) {
        // 0x8013249C: sw          $s0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r16;
            goto L_801324A8;
    }
    // 0x8013249C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x801324A0: b           L_80132544
    // 0x801324A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80132544;
    // 0x801324A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_801324A8:
    // 0x801324A8: lui         $s5, 0x8028
    ctx->r21 = S32(0X8028 << 16);
    // 0x801324AC: lui         $s4, 0x8028
    ctx->r20 = S32(0X8028 << 16);
    // 0x801324B0: lui         $s3, 0x8024
    ctx->r19 = S32(0X8024 << 16);
    // 0x801324B4: addiu       $s3, $s3, 0x1D0E
    ctx->r19 = ADD32(ctx->r19, 0X1D0E);
    // 0x801324B8: addiu       $s4, $s4, 0x631C
    ctx->r20 = ADD32(ctx->r20, 0X631C);
    // 0x801324BC: addiu       $s5, $s5, 0x6320
    ctx->r21 = ADD32(ctx->r21, 0X6320);
    // 0x801324C0: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x801324C4: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x801324C8: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
    // 0x801324CC: lw          $a0, 0x0($s4)
    ctx->r4 = MEM_W(ctx->r20, 0X0);
L_801324D0:
    // 0x801324D0: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x801324D4: or          $a2, $s5, $zero
    ctx->r6 = ctx->r21 | 0;
    // 0x801324D8: beql        $a0, $zero, L_80132544
    if (ctx->r4 == 0) {
        // 0x801324DC: or          $v0, $s0, $zero
        ctx->r2 = ctx->r16 | 0;
            goto L_80132544;
    }
    goto skip_0;
    // 0x801324DC: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    skip_0:
    // 0x801324E0: lh          $t7, 0x22($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X22);
L_801324E4:
    // 0x801324E4: bnel        $s2, $t7, L_80132538
    if (ctx->r18 != ctx->r15) {
        // 0x801324E8: lw          $a0, 0x30($a0)
        ctx->r4 = MEM_W(ctx->r4, 0X30);
            goto L_80132538;
    }
    goto skip_1;
    // 0x801324E8: lw          $a0, 0x30($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X30);
    skip_1:
    // 0x801324EC: lhu         $v0, 0x10($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X10);
    // 0x801324F0: lhu         $t8, 0x0($s3)
    ctx->r24 = MEM_HU(ctx->r19, 0X0);
    // 0x801324F4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x801324F8: subu        $t9, $t8, $v0
    ctx->r25 = SUB32(ctx->r24, ctx->r2);
    // 0x801324FC: slti        $at, $t9, 0x10
    ctx->r1 = SIGNED(ctx->r25) < 0X10 ? 1 : 0;
    // 0x80132500: bne         $at, $zero, L_8013251C
    if (ctx->r1 != 0) {
        // 0x80132504: nop
    
            goto L_8013251C;
    }
    // 0x80132504: nop

    // 0x80132508: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8013250C: jal         0x801322EC
    // 0x80132510: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    func_801322EC(rdram, ctx);
        goto after_0;
    // 0x80132510: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    after_0:
    // 0x80132514: b           L_801324D0
    // 0x80132518: lw          $a0, 0x0($s4)
    ctx->r4 = MEM_W(ctx->r20, 0X0);
        goto L_801324D0;
    // 0x80132518: lw          $a0, 0x0($s4)
    ctx->r4 = MEM_W(ctx->r20, 0X0);
L_8013251C:
    // 0x8013251C: beq         $s0, $zero, L_8013252C
    if (ctx->r16 == 0) {
        // 0x80132520: slt         $at, $v1, $s1
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r17) ? 1 : 0;
            goto L_8013252C;
    }
    // 0x80132520: slt         $at, $v1, $s1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x80132524: beql        $at, $zero, L_80132538
    if (ctx->r1 == 0) {
        // 0x80132528: lw          $a0, 0x30($a0)
        ctx->r4 = MEM_W(ctx->r4, 0X30);
            goto L_80132538;
    }
    goto skip_2;
    // 0x80132528: lw          $a0, 0x30($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X30);
    skip_2:
L_8013252C:
    // 0x8013252C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80132530: andi        $s1, $v0, 0xFFFF
    ctx->r17 = ctx->r2 & 0XFFFF;
    // 0x80132534: lw          $a0, 0x30($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X30);
L_80132538:
    // 0x80132538: bnel        $a0, $zero, L_801324E4
    if (ctx->r4 != 0) {
        // 0x8013253C: lh          $t7, 0x22($a0)
        ctx->r15 = MEM_H(ctx->r4, 0X22);
            goto L_801324E4;
    }
    goto skip_3;
    // 0x8013253C: lh          $t7, 0x22($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X22);
    skip_3:
    // 0x80132540: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
L_80132544:
    // 0x80132544: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x80132548: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x8013254C: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80132550: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x80132554: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x80132558: lw          $s4, 0x24($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X24);
    // 0x8013255C: lw          $s5, 0x28($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X28);
    // 0x80132560: jr          $ra
    // 0x80132564: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x80132564: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void func_80132568(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132568: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x8013256C: addiu       $v0, $v0, 0x6320
    ctx->r2 = ADD32(ctx->r2, 0X6320);
    // 0x80132570: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80132574: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80132578: jr          $ra
    // 0x8013257C: sw          $zero, 0x631C($at)
    MEM_W(0X631C, ctx->r1) = 0;
    return;
    // 0x8013257C: sw          $zero, 0x631C($at)
    MEM_W(0X631C, ctx->r1) = 0;
;}
RECOMP_FUNC void get_sound_by_object_and_id(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132580: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80132584: lw          $t8, 0x5154($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5154);
    // 0x80132588: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8013258C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80132590: bne         $t8, $zero, L_801325A0
    if (ctx->r24 != 0) {
        // 0x80132594: sra         $a1, $t6, 16
        ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
            goto L_801325A0;
    }
    // 0x80132594: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80132598: jr          $ra
    // 0x8013259C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x8013259C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_801325A0:
    // 0x801325A0: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x801325A4: lw          $v1, 0x631C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X631C);
    // 0x801325A8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x801325AC: beq         $v1, $zero, L_801325E0
    if (ctx->r3 == 0) {
        // 0x801325B0: nop
    
            goto L_801325E0;
    }
    // 0x801325B0: nop

    // 0x801325B4: lw          $t9, 0x28($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X28);
L_801325B8:
    // 0x801325B8: bnel        $a0, $t9, L_801325D8
    if (ctx->r4 != ctx->r25) {
        // 0x801325BC: lw          $v1, 0x30($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X30);
            goto L_801325D8;
    }
    goto skip_0;
    // 0x801325BC: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
    skip_0:
    // 0x801325C0: lhu         $t0, 0x2($v1)
    ctx->r8 = MEM_HU(ctx->r3, 0X2);
    // 0x801325C4: bnel        $a1, $t0, L_801325D8
    if (ctx->r5 != ctx->r8) {
        // 0x801325C8: lw          $v1, 0x30($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X30);
            goto L_801325D8;
    }
    goto skip_1;
    // 0x801325C8: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
    skip_1:
    // 0x801325CC: jr          $ra
    // 0x801325D0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x801325D0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x801325D4: lw          $v1, 0x30($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X30);
L_801325D8:
    // 0x801325D8: bnel        $v1, $zero, L_801325B8
    if (ctx->r3 != 0) {
        // 0x801325DC: lw          $t9, 0x28($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X28);
            goto L_801325B8;
    }
    goto skip_2;
    // 0x801325DC: lw          $t9, 0x28($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X28);
    skip_2:
L_801325E0:
    // 0x801325E0: jr          $ra
    // 0x801325E4: nop

    return;
    // 0x801325E4: nop

;}
RECOMP_FUNC void load_sequence(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801325E8: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x801325EC: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x801325F0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x801325F4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801325F8: beq         $t6, $zero, L_8013265C
    if (ctx->r14 == 0) {
        // 0x801325FC: sw          $a1, 0x24($sp)
        MEM_W(0X24, ctx->r29) = ctx->r5;
            goto L_8013265C;
    }
    // 0x801325FC: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x80132600: lui         $t7, 0x8028
    ctx->r15 = S32(0X8028 << 16);
    // 0x80132604: lw          $t7, 0x630C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X630C);
    // 0x80132608: sll         $t8, $a0, 3
    ctx->r24 = S32(ctx->r4 << 3);
    // 0x8013260C: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x80132610: lh          $a2, 0xA($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XA);
    // 0x80132614: lw          $a0, 0x4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X4);
    // 0x80132618: andi        $t9, $a2, 0x1
    ctx->r25 = ctx->r6 & 0X1;
    // 0x8013261C: beql        $t9, $zero, L_80132634
    if (ctx->r25 == 0) {
        // 0x80132620: sw          $a0, 0x1C($sp)
        MEM_W(0X1C, ctx->r29) = ctx->r4;
            goto L_80132634;
    }
    goto skip_0;
    // 0x80132620: sw          $a0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r4;
    skip_0:
    // 0x80132624: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
    // 0x80132628: sll         $t0, $a2, 16
    ctx->r8 = S32(ctx->r6 << 16);
    // 0x8013262C: sra         $a2, $t0, 16
    ctx->r6 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80132630: sw          $a0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r4;
L_80132634:
    // 0x80132634: jal         0x80137EB0
    // 0x80132638: sh          $a2, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r6;
    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_0;
    // 0x80132638: sh          $a2, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r6;
    after_0:
    // 0x8013263C: lb          $t2, 0x27($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X27);
    // 0x80132640: lui         $a1, 0x8028
    ctx->r5 = S32(0X8028 << 16);
    // 0x80132644: lw          $a0, 0x1C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X1C);
    // 0x80132648: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x8013264C: addu        $a1, $a1, $t3
    ctx->r5 = ADD32(ctx->r5, ctx->r11);
    // 0x80132650: lh          $a2, 0x1A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X1A);
    // 0x80132654: jal         0x80129290
    // 0x80132658: lw          $a1, 0x6314($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6314);
    dma_read(rdram, ctx);
        goto after_1;
    // 0x80132658: lw          $a1, 0x6314($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6314);
    after_1:
L_8013265C:
    // 0x8013265C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80132660: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80132664: jr          $ra
    // 0x80132668: nop

    return;
    // 0x80132668: nop

;}
RECOMP_FUNC void get_seqp_state(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013266C: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80132670: lw          $t8, 0x5154($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5154);
    // 0x80132674: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80132678: sll         $t6, $a0, 24
    ctx->r14 = S32(ctx->r4 << 24);
    // 0x8013267C: bne         $t8, $zero, L_8013268C
    if (ctx->r24 != 0) {
        // 0x80132680: sra         $a0, $t6, 24
        ctx->r4 = S32(SIGNED(ctx->r14) >> 24);
            goto L_8013268C;
    }
    // 0x80132680: sra         $a0, $t6, 24
    ctx->r4 = S32(SIGNED(ctx->r14) >> 24);
    // 0x80132684: jr          $ra
    // 0x80132688: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80132688: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8013268C:
    // 0x8013268C: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x80132690: lui         $t0, 0x8028
    ctx->r8 = S32(0X8028 << 16);
    // 0x80132694: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x80132698: lw          $t0, 0x63C8($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X63C8);
    // 0x8013269C: lw          $v0, 0x2C($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X2C);
    // 0x801326A0: jr          $ra
    // 0x801326A4: nop

    return;
    // 0x801326A4: nop

;}
RECOMP_FUNC void func_801326A8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801326A8: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x801326AC: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x801326B0: lw          $t7, 0x5154($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5154);
    // 0x801326B4: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x801326B8: sll         $s1, $a1, 24
    ctx->r17 = S32(ctx->r5 << 24);
    // 0x801326BC: sra         $t6, $s1, 24
    ctx->r14 = S32(SIGNED(ctx->r17) >> 24);
    // 0x801326C0: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x801326C4: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x801326C8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x801326CC: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801326D0: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    // 0x801326D4: beq         $t7, $zero, L_801328E0
    if (ctx->r15 == 0) {
        // 0x801326D8: sw          $a1, 0x44($sp)
        MEM_W(0X44, ctx->r29) = ctx->r5;
            goto L_801328E0;
    }
    // 0x801326D8: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    // 0x801326DC: sll         $a0, $t6, 24
    ctx->r4 = S32(ctx->r14 << 24);
    // 0x801326E0: sra         $t8, $a0, 24
    ctx->r24 = S32(SIGNED(ctx->r4) >> 24);
    // 0x801326E4: jal         0x8013266C
    // 0x801326E8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    get_seqp_state(rdram, ctx);
        goto after_0;
    // 0x801326E8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    after_0:
    // 0x801326EC: bne         $v0, $zero, L_801328E0
    if (ctx->r2 != 0) {
        // 0x801326F0: lb          $a0, 0x43($sp)
        ctx->r4 = MEM_B(ctx->r29, 0X43);
            goto L_801328E0;
    }
    // 0x801326F0: lb          $a0, 0x43($sp)
    ctx->r4 = MEM_B(ctx->r29, 0X43);
    // 0x801326F4: sll         $a1, $s1, 24
    ctx->r5 = S32(ctx->r17 << 24);
    // 0x801326F8: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x801326FC: jal         0x801325E8
    // 0x80132700: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    load_sequence(rdram, ctx);
        goto after_1;
    // 0x80132700: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    after_1:
    // 0x80132704: lui         $t0, 0x8028
    ctx->r8 = S32(0X8028 << 16);
    // 0x80132708: lui         $t1, 0x8028
    ctx->r9 = S32(0X8028 << 16);
    // 0x8013270C: lw          $t1, 0x62F8($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X62F8);
    // 0x80132710: addiu       $t0, $t0, 0x63C8
    ctx->r8 = ADD32(ctx->r8, 0X63C8);
    // 0x80132714: sll         $s0, $s1, 2
    ctx->r16 = S32(ctx->r17 << 2);
    // 0x80132718: addu        $s2, $s0, $t0
    ctx->r18 = ADD32(ctx->r16, ctx->r8);
    // 0x8013271C: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80132720: jal         0x8013AD30
    // 0x80132724: lw          $a1, 0x4($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X4);
    alSeqpSetBank(rdram, ctx);
        goto after_2;
    // 0x80132724: lw          $a1, 0x4($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X4);
    after_2:
    // 0x80132728: lui         $t2, 0x8028
    ctx->r10 = S32(0X8028 << 16);
    // 0x8013272C: addiu       $t2, $t2, 0x63CC
    ctx->r10 = ADD32(ctx->r10, 0X63CC);
    // 0x80132730: lui         $a1, 0x8028
    ctx->r5 = S32(0X8028 << 16);
    // 0x80132734: addu        $a1, $a1, $s0
    ctx->r5 = ADD32(ctx->r5, ctx->r16);
    // 0x80132738: addu        $v0, $s0, $t2
    ctx->r2 = ADD32(ctx->r16, ctx->r10);
    // 0x8013273C: lw          $a0, 0x0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X0);
    // 0x80132740: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    // 0x80132744: jal         0x8013B2CC
    // 0x80132748: lw          $a1, 0x6314($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6314);
    alCSeqNew(rdram, ctx);
        goto after_3;
    // 0x80132748: lw          $a1, 0x6314($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X6314);
    after_3:
    // 0x8013274C: lw          $v0, 0x2C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X2C);
    // 0x80132750: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80132754: jal         0x8013B830
    // 0x80132758: lw          $a1, 0x0($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X0);
    alSeqpSetSeq(rdram, ctx);
        goto after_4;
    // 0x80132758: lw          $a1, 0x0($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X0);
    after_4:
    // 0x8013275C: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x80132760: addu        $t3, $t3, $s1
    ctx->r11 = ADD32(ctx->r11, ctx->r17);
    // 0x80132764: lb          $t3, 0x46A8($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X46A8);
    // 0x80132768: lb          $t4, 0x43($sp)
    ctx->r12 = MEM_B(ctx->r29, 0X43);
    // 0x8013276C: sll         $t2, $s1, 1
    ctx->r10 = S32(ctx->r17 << 1);
    // 0x80132770: bne         $t3, $zero, L_801327D0
    if (ctx->r11 != 0) {
        // 0x80132774: sll         $t5, $t4, 1
        ctx->r13 = S32(ctx->r12 << 1);
            goto L_801327D0;
    }
    // 0x80132774: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x80132778: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8013277C: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x80132780: lh          $t6, 0x50F8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X50F8);
    // 0x80132784: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132788: lwc1        $f8, 0x46D0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46D0);
    // 0x8013278C: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80132790: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132794: lwc1        $f16, 0x517C($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X517C);
    // 0x80132798: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8013279C: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x801327A0: addiu       $t1, $t1, 0x516C
    ctx->r9 = ADD32(ctx->r9, 0X516C);
    // 0x801327A4: sll         $t0, $s1, 1
    ctx->r8 = S32(ctx->r17 << 1);
    // 0x801327A8: addu        $v0, $t0, $t1
    ctx->r2 = ADD32(ctx->r8, ctx->r9);
    // 0x801327AC: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x801327B0: nop

    // 0x801327B4: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x801327B8: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x801327BC: mfc1        $a1, $f4
    ctx->r5 = (int32_t)ctx->f4.u32l;
    // 0x801327C0: nop

    // 0x801327C4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x801327C8: b           L_8013286C
    // 0x801327CC: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
        goto L_8013286C;
    // 0x801327CC: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_801327D0:
    // 0x801327D0: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x801327D4: addiu       $t3, $t3, 0x516C
    ctx->r11 = ADD32(ctx->r11, 0X516C);
    // 0x801327D8: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x801327DC: lh          $t4, 0x0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X0);
    // 0x801327E0: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x801327E4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801327E8: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x801327EC: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x801327F0: lh          $t6, 0x50F8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X50F8);
    // 0x801327F4: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x801327F8: lwc1        $f8, 0x46B8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46B8);
    // 0x801327FC: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x80132800: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132804: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80132808: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8013280C: lwc1        $f10, 0x46AC($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X46AC);
    // 0x80132810: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132814: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80132818: lwc1        $f4, 0x46B0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X46B0);
    // 0x8013281C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132820: mul.s       $f16, $f0, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f0.fl, ctx->f10.fl);
    // 0x80132824: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80132828: lwc1        $f10, 0x46B4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X46B4);
    // 0x8013282C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132830: mul.s       $f18, $f8, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f8.fl, ctx->f16.fl);
    // 0x80132834: div.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80132838: lwc1        $f18, 0x46D0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X46D0);
    // 0x8013283C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132840: mul.s       $f8, $f10, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x80132844: lwc1        $f10, 0x517C($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X517C);
    // 0x80132848: add.s       $f16, $f6, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x8013284C: mul.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = MUL_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80132850: nop

    // 0x80132854: mul.s       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f10.fl);
    // 0x80132858: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8013285C: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
    // 0x80132860: nop

    // 0x80132864: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80132868: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_8013286C:
    // 0x8013286C: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80132870: lh          $t0, 0x46D8($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X46D8);
    // 0x80132874: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x80132878: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8013287C: mtc1        $t0, $f16
    ctx->f16.u32l = ctx->r8;
    // 0x80132880: mtc1        $a1, $f10
    ctx->f10.u32l = ctx->r5;
    // 0x80132884: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80132888: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8013288C: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    // 0x80132890: cvt.s.w     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80132894: div.s       $f0, $f18, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = DIV_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80132898: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x8013289C: trunc.w.s   $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x801328A0: mfc1        $a1, $f16
    ctx->r5 = (int32_t)ctx->f16.u32l;
    // 0x801328A4: nop

    // 0x801328A8: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x801328AC: jal         0x8013B870
    // 0x801328B0: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    alSeqpSetVol(rdram, ctx);
        goto after_5;
    // 0x801328B0: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    after_5:
    // 0x801328B4: jal         0x8013B8B0
    // 0x801328B8: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSeqpPlay(rdram, ctx);
        goto after_6;
    // 0x801328B8: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_6:
    // 0x801328BC: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801328C0: lw          $v0, 0x2C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X2C);
    // 0x801328C4: lb          $t5, 0x43($sp)
    ctx->r13 = MEM_B(ctx->r29, 0X43);
    // 0x801328C8: addu        $at, $at, $s1
    ctx->r1 = ADD32(ctx->r1, ctx->r17);
    // 0x801328CC: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x801328D0: sb          $t4, 0x5168($at)
    MEM_B(0X5168, ctx->r1) = ctx->r12;
    // 0x801328D4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801328D8: sh          $t5, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r13;
    // 0x801328DC: sw          $zero, 0x46E4($at)
    MEM_W(0X46E4, ctx->r1) = 0;
L_801328E0:
    // 0x801328E0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x801328E4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801328E8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x801328EC: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x801328F0: jr          $ra
    // 0x801328F4: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x801328F4: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_801328F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801328F8: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x801328FC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80132900: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80132904: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80132908: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x8013290C: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x80132910: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80132914: beq         $t6, $zero, L_80132C2C
    if (ctx->r14 == 0) {
        // 0x80132918: sw          $s0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r16;
            goto L_80132C2C;
    }
    // 0x80132918: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8013291C: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80132920: addiu       $v0, $v0, 0x1D0E
    ctx->r2 = ADD32(ctx->r2, 0X1D0E);
    // 0x80132924: lhu         $t7, 0x0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X0);
    // 0x80132928: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x8013292C: addiu       $s2, $s2, 0x6310
    ctx->r18 = ADD32(ctx->r18, 0X6310);
    // 0x80132930: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80132934: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
    // 0x80132938: jal         0x80132D84
    // 0x8013293C: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    func_80132D84(rdram, ctx);
        goto after_0;
    // 0x8013293C: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_0:
    // 0x80132940: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x80132944: beq         $at, $zero, L_80132AD0
    if (ctx->r1 == 0) {
        // 0x80132948: addiu       $t9, $zero, 0x8
        ctx->r25 = ADD32(0, 0X8);
            goto L_80132AD0;
    }
    // 0x80132948: addiu       $t9, $zero, 0x8
    ctx->r25 = ADD32(0, 0X8);
    // 0x8013294C: subu        $v1, $t9, $v0
    ctx->r3 = SUB32(ctx->r25, ctx->r2);
    // 0x80132950: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x80132954: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80132958: sh          $v1, 0x2C($sp)
    MEM_H(0X2C, ctx->r29) = ctx->r3;
    // 0x8013295C: blez        $t1, L_80132AD0
    if (SIGNED(ctx->r9) <= 0) {
        // 0x80132960: or          $s1, $zero, $zero
        ctx->r17 = 0 | 0;
            goto L_80132AD0;
    }
    // 0x80132960: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80132964: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80132968: addiu       $s3, $s3, 0x46D4
    ctx->r19 = ADD32(ctx->r19, 0X46D4);
L_8013296C:
    // 0x8013296C: jal         0x80132474
    // 0x80132970: nop

    func_80132474(rdram, ctx);
        goto after_1;
    // 0x80132970: nop

    after_1:
    // 0x80132974: beq         $v0, $zero, L_80132AD0
    if (ctx->r2 == 0) {
        // 0x80132978: or          $s0, $v0, $zero
        ctx->r16 = ctx->r2 | 0;
            goto L_80132AD0;
    }
    // 0x80132978: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x8013297C: lhu         $t3, 0x2($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X2);
    // 0x80132980: lui         $t2, 0x8028
    ctx->r10 = S32(0X8028 << 16);
    // 0x80132984: lw          $t2, 0x6300($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X6300);
    // 0x80132988: sll         $t4, $t3, 2
    ctx->r12 = S32(ctx->r11 << 2);
    // 0x8013298C: lh          $t6, 0x1C($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1C);
    // 0x80132990: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x80132994: lw          $v0, 0xC($t5)
    ctx->r2 = MEM_W(ctx->r13, 0XC);
    // 0x80132998: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8013299C: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x801329A0: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x801329A4: jal         0x8013B8E0
    // 0x801329A8: lw          $a1, 0x10($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X10);
    alSndpAllocate(rdram, ctx);
        goto after_2;
    // 0x801329A8: lw          $a1, 0x10($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X10);
    after_2:
    // 0x801329AC: sh          $v0, 0x22($s0)
    MEM_H(0X22, ctx->r16) = ctx->r2;
    // 0x801329B0: lh          $v1, 0x22($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X22);
    // 0x801329B4: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801329B8: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x801329BC: bltz        $v1, L_80132AB4
    if (SIGNED(ctx->r3) < 0) {
        // 0x801329C0: addu        $at, $at, $v1
        ctx->r1 = ADD32(ctx->r1, ctx->r3);
            goto L_80132AB4;
    }
    // 0x801329C0: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x801329C4: lui         $t0, 0x8024
    ctx->r8 = S32(0X8024 << 16);
    // 0x801329C8: lhu         $t0, 0x1D0E($t0)
    ctx->r8 = MEM_HU(ctx->r8, 0X1D0E);
    // 0x801329CC: sb          $t9, 0x63B0($at)
    MEM_B(0X63B0, ctx->r1) = ctx->r25;
    // 0x801329D0: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    // 0x801329D4: sh          $t0, 0x20($s0)
    MEM_H(0X20, ctx->r16) = ctx->r8;
    // 0x801329D8: jal         0x8013B980
    // 0x801329DC: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSndpSetSound(rdram, ctx);
        goto after_3;
    // 0x801329DC: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_3:
    // 0x801329E0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x801329E4: jal         0x8013B9A0
    // 0x801329E8: lw          $a1, 0x8($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X8);
    alSndpSetPitch(rdram, ctx);
        goto after_4;
    // 0x801329E8: lw          $a1, 0x8($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X8);
    after_4:
    // 0x801329EC: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x801329F0: lb          $t1, 0x46BC($t1)
    ctx->r9 = MEM_B(ctx->r9, 0X46BC);
    // 0x801329F4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801329F8: bnel        $t1, $at, L_80132A64
    if (ctx->r9 != ctx->r1) {
        // 0x801329FC: lh          $t6, 0xC($s0)
        ctx->r14 = MEM_H(ctx->r16, 0XC);
            goto L_80132A64;
    }
    goto skip_0;
    // 0x801329FC: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    skip_0:
    // 0x80132A00: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x80132A04: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132A08: lwc1        $f6, 0x46CC($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X46CC);
    // 0x80132A0C: mtc1        $t3, $f4
    ctx->f4.u32l = ctx->r11;
    // 0x80132A10: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132A14: lwc1        $f8, 0x46C0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46C0);
    // 0x80132A18: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80132A1C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132A20: lwc1        $f18, 0x46C4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X46C4);
    // 0x80132A24: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132A28: mul.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80132A2C: lwc1        $f8, 0x46C8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46C8);
    // 0x80132A30: mul.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x80132A34: div.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80132A38: lwc1        $f16, 0x0($s3)
    ctx->f16.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80132A3C: mul.s       $f6, $f0, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80132A40: add.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x80132A44: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80132A48: trunc.w.s   $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    ctx->f8.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80132A4C: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
    // 0x80132A50: nop

    // 0x80132A54: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x80132A58: b           L_80132A8C
    // 0x80132A5C: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
        goto L_80132A8C;
    // 0x80132A5C: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80132A60: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
L_80132A64:
    // 0x80132A64: lwc1        $f10, 0x0($s3)
    ctx->f10.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80132A68: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x80132A6C: nop

    // 0x80132A70: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80132A74: mul.s       $f16, $f4, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f4.fl, ctx->f10.fl);
    // 0x80132A78: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80132A7C: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x80132A80: nop

    // 0x80132A84: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80132A88: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_80132A8C:
    // 0x80132A8C: jal         0x8013BA00
    // 0x80132A90: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSndpSetVol(rdram, ctx);
        goto after_5;
    // 0x80132A90: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_5:
    // 0x80132A94: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x80132A98: lbu         $a1, 0x5178($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5178);
    // 0x80132A9C: jal         0x8013BA60
    // 0x80132AA0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSndpSetFXMix(rdram, ctx);
        goto after_6;
    // 0x80132AA0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_6:
    // 0x80132AA4: jal         0x8013BAC0
    // 0x80132AA8: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSndpPlay(rdram, ctx);
        goto after_7;
    // 0x80132AA8: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_7:
    // 0x80132AAC: addiu       $t0, $zero, 0x9
    ctx->r8 = ADD32(0, 0X9);
    // 0x80132AB0: sb          $t0, 0x24($s0)
    MEM_B(0X24, ctx->r16) = ctx->r8;
L_80132AB4:
    // 0x80132AB4: lh          $t2, 0x2C($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X2C);
    // 0x80132AB8: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x80132ABC: sll         $t1, $s1, 16
    ctx->r9 = S32(ctx->r17 << 16);
    // 0x80132AC0: sra         $s1, $t1, 16
    ctx->r17 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80132AC4: slt         $at, $s1, $t2
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x80132AC8: bne         $at, $zero, L_8013296C
    if (ctx->r1 != 0) {
        // 0x80132ACC: nop
    
            goto L_8013296C;
    }
    // 0x80132ACC: nop

L_80132AD0:
    // 0x80132AD0: lui         $s0, 0x8015
    ctx->r16 = S32(0X8015 << 16);
    // 0x80132AD4: addiu       $s0, $s0, 0x46A8
    ctx->r16 = ADD32(ctx->r16, 0X46A8);
    // 0x80132AD8: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80132ADC: addu        $t4, $s0, $s1
    ctx->r12 = ADD32(ctx->r16, ctx->r17);
L_80132AE0:
    // 0x80132AE0: lb          $t5, 0x0($t4)
    ctx->r13 = MEM_B(ctx->r12, 0X0);
    // 0x80132AE4: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80132AE8: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80132AEC: beql        $t5, $zero, L_80132B00
    if (ctx->r13 == 0) {
        // 0x80132AF0: addiu       $s1, $s1, 0x1
        ctx->r17 = ADD32(ctx->r17, 0X1);
            goto L_80132B00;
    }
    goto skip_1;
    // 0x80132AF0: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    skip_1:
    // 0x80132AF4: jal         0x801338A8
    // 0x80132AF8: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_801338A8(rdram, ctx);
        goto after_8;
    // 0x80132AF8: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_8:
    // 0x80132AFC: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
L_80132B00:
    // 0x80132B00: sll         $t7, $s1, 16
    ctx->r15 = S32(ctx->r17 << 16);
    // 0x80132B04: sra         $s1, $t7, 16
    ctx->r17 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80132B08: blezl       $s1, L_80132AE0
    if (SIGNED(ctx->r17) <= 0) {
        // 0x80132B0C: addu        $t4, $s0, $s1
        ctx->r12 = ADD32(ctx->r16, ctx->r17);
            goto L_80132AE0;
    }
    goto skip_2;
    // 0x80132B0C: addu        $t4, $s0, $s1
    ctx->r12 = ADD32(ctx->r16, ctx->r17);
    skip_2:
    // 0x80132B10: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x80132B14: lb          $t9, 0x46BC($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X46BC);
    // 0x80132B18: beq         $t9, $zero, L_80132B28
    if (ctx->r25 == 0) {
        // 0x80132B1C: nop
    
            goto L_80132B28;
    }
    // 0x80132B1C: nop

    // 0x80132B20: jal         0x801339F8
    // 0x80132B24: nop

    func_801339F8(rdram, ctx);
        goto after_9;
    // 0x80132B24: nop

    after_9:
L_80132B28:
    // 0x80132B28: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x80132B2C: addiu       $v1, $v1, 0x46DC
    ctx->r3 = ADD32(ctx->r3, 0X46DC);
    // 0x80132B30: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80132B34: lh          $v0, 0x46D8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X46D8);
    // 0x80132B38: lh          $t0, 0x0($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X0);
    // 0x80132B3C: lui         $s0, 0x8015
    ctx->r16 = S32(0X8015 << 16);
    // 0x80132B40: addiu       $s0, $s0, 0x517C
    ctx->r16 = ADD32(ctx->r16, 0X517C);
    // 0x80132B44: beq         $t0, $v0, L_80132B5C
    if (ctx->r8 == ctx->r2) {
        // 0x80132B48: lui         $at, 0x8015
        ctx->r1 = S32(0X8015 << 16);
            goto L_80132B5C;
    }
    // 0x80132B48: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132B4C: jal         0x80133C50
    // 0x80132B50: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
    func_80133C50(rdram, ctx);
        goto after_10;
    // 0x80132B50: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
    after_10:
    // 0x80132B54: b           L_80132BE4
    // 0x80132B58: nop

        goto L_80132BE4;
    // 0x80132B58: nop

L_80132B5C:
    // 0x80132B5C: lwc1        $f14, 0x529C($at)
    ctx->f14.u32l = MEM_W(ctx->r1, 0X529C);
    // 0x80132B60: lwc1        $f2, 0x0($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80132B64: c.eq.s      $f14, $f2
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f14.fl == ctx->f2.fl;
    // 0x80132B68: nop

    // 0x80132B6C: bc1t        L_80132BE4
    if (c1cs) {
        // 0x80132B70: nop
    
            goto L_80132BE4;
    }
    // 0x80132B70: nop

    // 0x80132B74: sub.s       $f12, $f2, $f14
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f12.fl = ctx->f2.fl - ctx->f14.fl;
    // 0x80132B78: mtc1        $zero, $f9
    ctx->f_odd[(9 - 1) * 2] = 0;
    // 0x80132B7C: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80132B80: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80132B84: cvt.d.s     $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.d = CVT_D_S(ctx->f12.fl);
    // 0x80132B88: swc1        $f12, 0x6554($at)
    MEM_W(0X6554, ctx->r1) = ctx->f12.u32l;
    // 0x80132B8C: c.lt.d      $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f0.d < ctx->f8.d;
    // 0x80132B90: lui         $at, 0xBFF0
    ctx->r1 = S32(0XBFF0 << 16);
    // 0x80132B94: bc1f        L_80132BB8
    if (!c1cs) {
        // 0x80132B98: nop
    
            goto L_80132BB8;
    }
    // 0x80132B98: nop

    // 0x80132B9C: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80132BA0: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80132BA4: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80132BA8: mul.d       $f4, $f0, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f6.d);
    // 0x80132BAC: cvt.s.d     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f12.fl = CVT_S_D(ctx->f4.d);
    // 0x80132BB0: cvt.d.s     $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.d = CVT_D_S(ctx->f12.fl);
    // 0x80132BB4: swc1        $f12, 0x6554($at)
    MEM_W(0X6554, ctx->r1) = ctx->f12.u32l;
L_80132BB8:
    // 0x80132BB8: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80132BBC: ldc1        $f10, -0x51F8($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X51F8);
    // 0x80132BC0: c.lt.d      $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f10.d < ctx->f0.d;
    // 0x80132BC4: nop

    // 0x80132BC8: bc1f        L_80132BE4
    if (!c1cs) {
        // 0x80132BCC: nop
    
            goto L_80132BE4;
    }
    // 0x80132BCC: nop

    // 0x80132BD0: jal         0x80133C50
    // 0x80132BD4: nop

    func_80133C50(rdram, ctx);
        goto after_11;
    // 0x80132BD4: nop

    after_11:
    // 0x80132BD8: lwc1        $f14, 0x0($s0)
    ctx->f14.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80132BDC: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132BE0: swc1        $f14, 0x529C($at)
    MEM_W(0X529C, ctx->r1) = ctx->f14.u32l;
L_80132BE4:
    // 0x80132BE4: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x80132BE8: addiu       $v1, $v1, 0x5188
    ctx->r3 = ADD32(ctx->r3, 0X5188);
    // 0x80132BEC: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80132BF0: lh          $v0, 0x645C($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X645C);
    // 0x80132BF4: lh          $t1, 0x0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X0);
    // 0x80132BF8: beql        $v0, $t1, L_80132C30
    if (ctx->r2 == ctx->r9) {
        // 0x80132BFC: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_80132C30;
    }
    goto skip_3;
    // 0x80132BFC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_3:
    // 0x80132C00: bne         $v0, $zero, L_80132C18
    if (ctx->r2 != 0) {
        // 0x80132C04: sh          $v0, 0x0($v1)
        MEM_H(0X0, ctx->r3) = ctx->r2;
            goto L_80132C18;
    }
    // 0x80132C04: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
    // 0x80132C08: jal         0x8013364C
    // 0x80132C0C: nop

    func_8013364C(rdram, ctx);
        goto after_12;
    // 0x80132C0C: nop

    after_12:
    // 0x80132C10: b           L_80132C30
    // 0x80132C14: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_80132C30;
    // 0x80132C14: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80132C18:
    // 0x80132C18: sll         $a0, $v0, 24
    ctx->r4 = S32(ctx->r2 << 24);
    // 0x80132C1C: sra         $t3, $a0, 24
    ctx->r11 = S32(SIGNED(ctx->r4) >> 24);
    // 0x80132C20: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80132C24: jal         0x801337BC
    // 0x80132C28: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    func_801337BC(rdram, ctx);
        goto after_13;
    // 0x80132C28: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    after_13:
L_80132C2C:
    // 0x80132C2C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80132C30:
    // 0x80132C30: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80132C34: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80132C38: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x80132C3C: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x80132C40: jr          $ra
    // 0x80132C44: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x80132C44: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void func_80132C48(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132C48: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80132C4C: lw          $t7, 0x5154($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5154);
    // 0x80132C50: sll         $a1, $a0, 24
    ctx->r5 = S32(ctx->r4 << 24);
    // 0x80132C54: sra         $t6, $a1, 24
    ctx->r14 = S32(SIGNED(ctx->r5) >> 24);
    // 0x80132C58: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80132C5C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80132C60: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80132C64: beq         $t7, $zero, L_80132CB0
    if (ctx->r15 == 0) {
        // 0x80132C68: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_80132CB0;
    }
    // 0x80132C68: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80132C6C: sll         $t8, $t6, 2
    ctx->r24 = S32(ctx->r14 << 2);
    // 0x80132C70: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80132C74: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    // 0x80132C78: lw          $a0, 0x63C8($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63C8);
    // 0x80132C7C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132C80: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x80132C84: lw          $t9, 0x2C($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X2C);
    // 0x80132C88: bne         $t9, $zero, L_80132C98
    if (ctx->r25 != 0) {
        // 0x80132C8C: nop
    
            goto L_80132C98;
    }
    // 0x80132C8C: nop

    // 0x80132C90: b           L_80132CB0
    // 0x80132C94: sb          $zero, 0x5168($at)
    MEM_B(0X5168, ctx->r1) = 0;
        goto L_80132CB0;
    // 0x80132C94: sb          $zero, 0x5168($at)
    MEM_B(0X5168, ctx->r1) = 0;
L_80132C98:
    // 0x80132C98: jal         0x8013BB30
    // 0x80132C9C: sb          $a1, 0x1B($sp)
    MEM_B(0X1B, ctx->r29) = ctx->r5;
    alSeqpStop(rdram, ctx);
        goto after_0;
    // 0x80132C9C: sb          $a1, 0x1B($sp)
    MEM_B(0X1B, ctx->r29) = ctx->r5;
    after_0:
    // 0x80132CA0: lb          $a1, 0x1B($sp)
    ctx->r5 = MEM_B(ctx->r29, 0X1B);
    // 0x80132CA4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132CA8: addu        $at, $at, $a1
    ctx->r1 = ADD32(ctx->r1, ctx->r5);
    // 0x80132CAC: sb          $zero, 0x5168($at)
    MEM_B(0X5168, ctx->r1) = 0;
L_80132CB0:
    // 0x80132CB0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80132CB4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80132CB8: jr          $ra
    // 0x80132CBC: nop

    return;
    // 0x80132CBC: nop

;}
RECOMP_FUNC void func_80132CC0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132CC0: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80132CC4: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x80132CC8: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x80132CCC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80132CD0: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80132CD4: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80132CD8: sw          $s2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r18;
    // 0x80132CDC: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x80132CE0: lw          $s0, 0x631C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X631C);
    // 0x80132CE4: jal         0x8013966C
    // 0x80132CE8: addiu       $a0, $a0, -0x5270
    ctx->r4 = ADD32(ctx->r4, -0X5270);
    osSyncPrintf(rdram, ctx);
        goto after_0;
    // 0x80132CE8: addiu       $a0, $a0, -0x5270
    ctx->r4 = ADD32(ctx->r4, -0X5270);
    after_0:
    // 0x80132CEC: beq         $s0, $zero, L_80132D3C
    if (ctx->r16 == 0) {
        // 0x80132CF0: lui         $s2, 0x8028
        ctx->r18 = S32(0X8028 << 16);
            goto L_80132D3C;
    }
    // 0x80132CF0: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80132CF4: lui         $s1, 0x8016
    ctx->r17 = S32(0X8016 << 16);
    // 0x80132CF8: addiu       $s1, $s1, -0x524C
    ctx->r17 = ADD32(ctx->r17, -0X524C);
    // 0x80132CFC: addiu       $s2, $s2, 0x63B0
    ctx->r18 = ADD32(ctx->r18, 0X63B0);
    // 0x80132D00: lh          $a2, 0x22($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X22);
L_80132D04:
    // 0x80132D04: lw          $t6, 0x28($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X28);
    // 0x80132D08: lbu         $a1, 0x24($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X24);
    // 0x80132D0C: lhu         $a3, 0x2($s0)
    ctx->r7 = MEM_HU(ctx->r16, 0X2);
    // 0x80132D10: addu        $t8, $s2, $a2
    ctx->r24 = ADD32(ctx->r18, ctx->r6);
    // 0x80132D14: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80132D18: lhu         $t7, 0xE($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0XE);
    // 0x80132D1C: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x80132D20: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80132D24: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80132D28: jal         0x8013966C
    // 0x80132D2C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    osSyncPrintf(rdram, ctx);
        goto after_1;
    // 0x80132D2C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    after_1:
    // 0x80132D30: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
    // 0x80132D34: bnel        $s0, $zero, L_80132D04
    if (ctx->r16 != 0) {
        // 0x80132D38: lh          $a2, 0x22($s0)
        ctx->r6 = MEM_H(ctx->r16, 0X22);
            goto L_80132D04;
    }
    goto skip_0;
    // 0x80132D38: lh          $a2, 0x22($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X22);
    skip_0:
L_80132D3C:
    // 0x80132D3C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80132D40: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x80132D44: lw          $s1, 0x2C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X2C);
    // 0x80132D48: lw          $s2, 0x30($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X30);
    // 0x80132D4C: jr          $ra
    // 0x80132D50: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x80132D50: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void get_used_sound_count(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132D54: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80132D58: lw          $v0, 0x631C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X631C);
    // 0x80132D5C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80132D60: beq         $v0, $zero, L_80132D7C
    if (ctx->r2 == 0) {
        // 0x80132D64: nop
    
            goto L_80132D7C;
    }
    // 0x80132D64: nop

L_80132D68:
    // 0x80132D68: lw          $v0, 0x30($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X30);
    // 0x80132D6C: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80132D70: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x80132D74: bne         $v0, $zero, L_80132D68
    if (ctx->r2 != 0) {
        // 0x80132D78: sra         $v1, $t6, 16
        ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
            goto L_80132D68;
    }
    // 0x80132D78: sra         $v1, $t6, 16
    ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
L_80132D7C:
    // 0x80132D7C: jr          $ra
    // 0x80132D80: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80132D80: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_80132D84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132D84: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x80132D88: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80132D8C: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80132D90: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80132D94: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80132D98: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x80132D9C: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80132DA0: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x80132DA4: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80132DA8: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80132DAC: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80132DB0: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80132DB4: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80132DB8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80132DBC: bne         $t6, $zero, L_80132DCC
    if (ctx->r14 != 0) {
        // 0x80132DC0: or          $s6, $zero, $zero
        ctx->r22 = 0 | 0;
            goto L_80132DCC;
    }
    // 0x80132DC0: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x80132DC4: b           L_80132F40
    // 0x80132DC8: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
        goto L_80132F40;
    // 0x80132DC8: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
L_80132DCC:
    // 0x80132DCC: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80132DD0: addiu       $s2, $s2, 0x631C
    ctx->r18 = ADD32(ctx->r18, 0X631C);
    // 0x80132DD4: lw          $s0, 0x0($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X0);
    // 0x80132DD8: addiu       $fp, $zero, 0x1
    ctx->r30 = ADD32(0, 0X1);
    // 0x80132DDC: addiu       $s7, $zero, -0x2
    ctx->r23 = ADD32(0, -0X2);
    // 0x80132DE0: beq         $s0, $zero, L_80132F3C
    if (ctx->r16 == 0) {
        // 0x80132DE4: lui         $s5, 0x8028
        ctx->r21 = S32(0X8028 << 16);
            goto L_80132F3C;
    }
    // 0x80132DE4: lui         $s5, 0x8028
    ctx->r21 = S32(0X8028 << 16);
    // 0x80132DE8: lui         $s3, 0x8028
    ctx->r19 = S32(0X8028 << 16);
    // 0x80132DEC: addiu       $s3, $s3, 0x6320
    ctx->r19 = ADD32(ctx->r19, 0X6320);
    // 0x80132DF0: addiu       $s5, $s5, 0x63B0
    ctx->r21 = ADD32(ctx->r21, 0X63B0);
    // 0x80132DF4: addiu       $s4, $zero, 0x9
    ctx->r20 = ADD32(0, 0X9);
    // 0x80132DF8: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
L_80132DFC:
    // 0x80132DFC: bgez        $a1, L_80132E20
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80132E00: nop
    
            goto L_80132E20;
    }
    // 0x80132E00: nop

    // 0x80132E04: bne         $s7, $a1, L_80132F30
    if (ctx->r23 != ctx->r5) {
        // 0x80132E08: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_80132F30;
    }
    // 0x80132E08: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80132E0C: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80132E10: jal         0x801322EC
    // 0x80132E14: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    func_801322EC(rdram, ctx);
        goto after_0;
    // 0x80132E14: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_0:
    // 0x80132E18: b           L_80132F34
    // 0x80132E1C: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
        goto L_80132F34;
    // 0x80132E1C: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
L_80132E20:
    // 0x80132E20: jal         0x8013B980
    // 0x80132E24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpSetSound(rdram, ctx);
        goto after_1;
    // 0x80132E24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_1:
    // 0x80132E28: jal         0x8013BB60
    // 0x80132E2C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpGetState(rdram, ctx);
        goto after_2;
    // 0x80132E2C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_2:
    // 0x80132E30: beql        $v0, $zero, L_80132E90
    if (ctx->r2 == 0) {
        // 0x80132E34: lh          $t6, 0x22($s0)
        ctx->r14 = MEM_H(ctx->r16, 0X22);
            goto L_80132E90;
    }
    goto skip_0;
    // 0x80132E34: lh          $t6, 0x22($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X22);
    skip_0:
    // 0x80132E38: lw          $t7, 0x28($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X28);
    // 0x80132E3C: beql        $t7, $zero, L_80132E68
    if (ctx->r15 == 0) {
        // 0x80132E40: lbu         $t3, 0x24($s0)
        ctx->r11 = MEM_BU(ctx->r16, 0X24);
            goto L_80132E68;
    }
    goto skip_1;
    // 0x80132E40: lbu         $t3, 0x24($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X24);
    skip_1:
    // 0x80132E44: lhu         $t8, 0xE($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0XE);
    // 0x80132E48: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x80132E4C: andi        $t0, $t9, 0xFFFF
    ctx->r8 = ctx->r25 & 0XFFFF;
    // 0x80132E50: bne         $t0, $zero, L_80132E64
    if (ctx->r8 != 0) {
        // 0x80132E54: sh          $t9, 0xE($s0)
        MEM_H(0XE, ctx->r16) = ctx->r25;
            goto L_80132E64;
    }
    // 0x80132E54: sh          $t9, 0xE($s0)
    MEM_H(0XE, ctx->r16) = ctx->r25;
    // 0x80132E58: jal         0x80133608
    // 0x80132E5C: lh          $a0, 0x22($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X22);
    play_sound_by_slot(rdram, ctx);
        goto after_3;
    // 0x80132E5C: lh          $a0, 0x22($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X22);
    after_3:
    // 0x80132E60: sw          $zero, 0x28($s0)
    MEM_W(0X28, ctx->r16) = 0;
L_80132E64:
    // 0x80132E64: lbu         $t3, 0x24($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X24);
L_80132E68:
    // 0x80132E68: addiu       $s6, $s6, 0x1
    ctx->r22 = ADD32(ctx->r22, 0X1);
    // 0x80132E6C: sll         $t1, $s6, 16
    ctx->r9 = S32(ctx->r22 << 16);
    // 0x80132E70: bne         $s4, $t3, L_80132E7C
    if (ctx->r20 != ctx->r11) {
        // 0x80132E74: sra         $s6, $t1, 16
        ctx->r22 = S32(SIGNED(ctx->r9) >> 16);
            goto L_80132E7C;
    }
    // 0x80132E74: sra         $s6, $t1, 16
    ctx->r22 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80132E78: sb          $fp, 0x24($s0)
    MEM_B(0X24, ctx->r16) = ctx->r30;
L_80132E7C:
    // 0x80132E7C: lh          $t4, 0x22($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X22);
    // 0x80132E80: addu        $t5, $s5, $t4
    ctx->r13 = ADD32(ctx->r21, ctx->r12);
    // 0x80132E84: b           L_80132F30
    // 0x80132E88: sb          $zero, 0x0($t5)
    MEM_B(0X0, ctx->r13) = 0;
        goto L_80132F30;
    // 0x80132E88: sb          $zero, 0x0($t5)
    MEM_B(0X0, ctx->r13) = 0;
    // 0x80132E8C: lh          $t6, 0x22($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X22);
L_80132E90:
    // 0x80132E90: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x80132E94: addu        $t7, $s5, $t6
    ctx->r15 = ADD32(ctx->r21, ctx->r14);
    // 0x80132E98: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x80132E9C: bne         $t8, $zero, L_80132EEC
    if (ctx->r24 != 0) {
        // 0x80132EA0: nop
    
            goto L_80132EEC;
    }
    // 0x80132EA0: nop

    // 0x80132EA4: jal         0x8013BB60
    // 0x80132EA8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpGetState(rdram, ctx);
        goto after_4;
    // 0x80132EA8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_4:
    // 0x80132EAC: bne         $v0, $zero, L_80132F30
    if (ctx->r2 != 0) {
        // 0x80132EB0: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80132F30;
    }
    // 0x80132EB0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80132EB4: jal         0x8013BB80
    // 0x80132EB8: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    alSndpDeallocate(rdram, ctx);
        goto after_5;
    // 0x80132EB8: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    after_5:
    // 0x80132EBC: lbu         $t9, 0x24($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X24);
    // 0x80132EC0: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
    // 0x80132EC4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80132EC8: bne         $s4, $t9, L_80132EDC
    if (ctx->r20 != ctx->r25) {
        // 0x80132ECC: or          $a1, $s2, $zero
        ctx->r5 = ctx->r18 | 0;
            goto L_80132EDC;
    }
    // 0x80132ECC: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80132ED0: sh          $t0, 0x22($s0)
    MEM_H(0X22, ctx->r16) = ctx->r8;
    // 0x80132ED4: b           L_80132F30
    // 0x80132ED8: sb          $zero, 0x24($s0)
    MEM_B(0X24, ctx->r16) = 0;
        goto L_80132F30;
    // 0x80132ED8: sb          $zero, 0x24($s0)
    MEM_B(0X24, ctx->r16) = 0;
L_80132EDC:
    // 0x80132EDC: jal         0x801322EC
    // 0x80132EE0: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    func_801322EC(rdram, ctx);
        goto after_6;
    // 0x80132EE0: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_6:
    // 0x80132EE4: b           L_80132F34
    // 0x80132EE8: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
        goto L_80132F34;
    // 0x80132EE8: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
L_80132EEC:
    // 0x80132EEC: lhu         $t1, 0x1D0E($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X1D0E);
    // 0x80132EF0: lhu         $t2, 0x20($s0)
    ctx->r10 = MEM_HU(ctx->r16, 0X20);
    // 0x80132EF4: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x80132EF8: andi        $t4, $t3, 0xFFFF
    ctx->r12 = ctx->r11 & 0XFFFF;
    // 0x80132EFC: slti        $at, $t4, 0x7
    ctx->r1 = SIGNED(ctx->r12) < 0X7 ? 1 : 0;
    // 0x80132F00: bnel        $at, $zero, L_80132F34
    if (ctx->r1 != 0) {
        // 0x80132F04: lw          $s0, 0x30($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X30);
            goto L_80132F34;
    }
    goto skip_2;
    // 0x80132F04: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
    skip_2:
    // 0x80132F08: jal         0x8013BB60
    // 0x80132F0C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpGetState(rdram, ctx);
        goto after_7;
    // 0x80132F0C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_7:
    // 0x80132F10: bne         $v0, $zero, L_80132F30
    if (ctx->r2 != 0) {
        // 0x80132F14: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80132F30;
    }
    // 0x80132F14: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80132F18: jal         0x8013BB80
    // 0x80132F1C: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    alSndpDeallocate(rdram, ctx);
        goto after_8;
    // 0x80132F1C: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    after_8:
    // 0x80132F20: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80132F24: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80132F28: jal         0x801322EC
    // 0x80132F2C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    func_801322EC(rdram, ctx);
        goto after_9;
    // 0x80132F2C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_9:
L_80132F30:
    // 0x80132F30: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
L_80132F34:
    // 0x80132F34: bnel        $s0, $zero, L_80132DFC
    if (ctx->r16 != 0) {
        // 0x80132F38: lh          $a1, 0x22($s0)
        ctx->r5 = MEM_H(ctx->r16, 0X22);
            goto L_80132DFC;
    }
    goto skip_3;
    // 0x80132F38: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    skip_3:
L_80132F3C:
    // 0x80132F3C: or          $v0, $s6, $zero
    ctx->r2 = ctx->r22 | 0;
L_80132F40:
    // 0x80132F40: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80132F44: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80132F48: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80132F4C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80132F50: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80132F54: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80132F58: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80132F5C: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80132F60: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80132F64: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80132F68: jr          $ra
    // 0x80132F6C: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x80132F6C: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_80132F70(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80132F70: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80132F74: lw          $t8, 0x5154($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5154);
    // 0x80132F78: addiu       $sp, $sp, -0x90
    ctx->r29 = ADD32(ctx->r29, -0X90);
    // 0x80132F7C: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80132F80: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80132F84: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80132F88: sw          $a0, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r4;
    // 0x80132F8C: beq         $t8, $zero, L_8013306C
    if (ctx->r24 == 0) {
        // 0x80132F90: sw          $a1, 0x94($sp)
        MEM_W(0X94, ctx->r29) = ctx->r5;
            goto L_8013306C;
    }
    // 0x80132F90: sw          $a1, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r5;
    // 0x80132F94: addiu       $at, $zero, 0x2710
    ctx->r1 = ADD32(0, 0X2710);
    // 0x80132F98: beq         $t7, $at, L_8013306C
    if (ctx->r15 == ctx->r1) {
        // 0x80132F9C: sll         $v0, $t7, 2
        ctx->r2 = S32(ctx->r15 << 2);
            goto L_8013306C;
    }
    // 0x80132F9C: sll         $v0, $t7, 2
    ctx->r2 = S32(ctx->r15 << 2);
    // 0x80132FA0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80132FA4: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80132FA8: lwc1        $f0, 0x46E8($at)
    ctx->f0.u32l = MEM_W(ctx->r1, 0X46E8);
    // 0x80132FAC: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80132FB0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80132FB4: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x80132FB8: addu        $t9, $t9, $v0
    ctx->r25 = ADD32(ctx->r25, ctx->r2);
    // 0x80132FBC: c.lt.s      $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f4.fl < ctx->f0.fl;
    // 0x80132FC0: lw          $t9, 0x4C4C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4C4C);
    // 0x80132FC4: addiu       $t0, $zero, 0x40
    ctx->r8 = ADD32(0, 0X40);
    // 0x80132FC8: sh          $t7, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r15;
    // 0x80132FCC: sw          $zero, 0x64($sp)
    MEM_W(0X64, ctx->r29) = 0;
    // 0x80132FD0: sw          $zero, 0x68($sp)
    MEM_W(0X68, ctx->r29) = 0;
    // 0x80132FD4: sh          $zero, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = 0;
    // 0x80132FD8: sb          $t0, 0x54($sp)
    MEM_B(0X54, ctx->r29) = ctx->r8;
    // 0x80132FDC: swc1        $f0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->f0.u32l;
    // 0x80132FE0: bc1t        L_8013306C
    if (c1cs) {
        // 0x80132FE4: sh          $t9, 0x50($sp)
        MEM_H(0X50, ctx->r29) = ctx->r25;
            goto L_8013306C;
    }
    // 0x80132FE4: sh          $t9, 0x50($sp)
    MEM_H(0X50, ctx->r29) = ctx->r25;
    // 0x80132FE8: lui         $t2, 0x8024
    ctx->r10 = S32(0X8024 << 16);
    // 0x80132FEC: lh          $t1, 0x96($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X96);
    // 0x80132FF0: lhu         $t2, 0x1D0E($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X1D0E);
    // 0x80132FF4: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
    // 0x80132FF8: addiu       $t4, $sp, 0x50
    ctx->r12 = ADD32(ctx->r29, 0X50);
    // 0x80132FFC: sw          $zero, 0x78($sp)
    MEM_W(0X78, ctx->r29) = 0;
    // 0x80133000: sh          $t3, 0x72($sp)
    MEM_H(0X72, ctx->r29) = ctx->r11;
    // 0x80133004: addiu       $t6, $t4, 0x30
    ctx->r14 = ADD32(ctx->r12, 0X30);
    // 0x80133008: or          $t7, $sp, $zero
    ctx->r15 = ctx->r29 | 0;
    // 0x8013300C: sh          $t1, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r9;
    // 0x80133010: sh          $t2, 0x60($sp)
    MEM_H(0X60, ctx->r29) = ctx->r10;
L_80133014:
    // 0x80133014: lw          $at, 0x0($t4)
    ctx->r1 = MEM_W(ctx->r12, 0X0);
    // 0x80133018: addiu       $t4, $t4, 0xC
    ctx->r12 = ADD32(ctx->r12, 0XC);
    // 0x8013301C: addiu       $t7, $t7, 0xC
    ctx->r15 = ADD32(ctx->r15, 0XC);
    // 0x80133020: sw          $at, -0xC($t7)
    MEM_W(-0XC, ctx->r15) = ctx->r1;
    // 0x80133024: lw          $at, -0x8($t4)
    ctx->r1 = MEM_W(ctx->r12, -0X8);
    // 0x80133028: sw          $at, -0x8($t7)
    MEM_W(-0X8, ctx->r15) = ctx->r1;
    // 0x8013302C: lw          $at, -0x4($t4)
    ctx->r1 = MEM_W(ctx->r12, -0X4);
    // 0x80133030: bne         $t4, $t6, L_80133014
    if (ctx->r12 != ctx->r14) {
        // 0x80133034: sw          $at, -0x4($t7)
        MEM_W(-0X4, ctx->r15) = ctx->r1;
            goto L_80133014;
    }
    // 0x80133034: sw          $at, -0x4($t7)
    MEM_W(-0X4, ctx->r15) = ctx->r1;
    // 0x80133038: lw          $at, 0x0($t4)
    ctx->r1 = MEM_W(ctx->r12, 0X0);
    // 0x8013303C: lui         $t8, 0x8028
    ctx->r24 = S32(0X8028 << 16);
    // 0x80133040: lui         $t9, 0x8028
    ctx->r25 = S32(0X8028 << 16);
    // 0x80133044: sw          $at, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r1;
    // 0x80133048: addiu       $t9, $t9, 0x6320
    ctx->r25 = ADD32(ctx->r25, 0X6320);
    // 0x8013304C: addiu       $t8, $t8, 0x631C
    ctx->r24 = ADD32(ctx->r24, 0X631C);
    // 0x80133050: sw          $t8, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r24;
    // 0x80133054: sw          $t9, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r25;
    // 0x80133058: lw          $a3, 0xC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XC);
    // 0x8013305C: lw          $a2, 0x8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X8);
    // 0x80133060: lw          $a1, 0x4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4);
    // 0x80133064: jal         0x80132174
    // 0x80133068: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    func_80132174(rdram, ctx);
        goto after_0;
    // 0x80133068: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    after_0:
L_8013306C:
    // 0x8013306C: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x80133070: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
    // 0x80133074: jr          $ra
    // 0x80133078: nop

    return;
    // 0x80133078: nop

;}
RECOMP_FUNC void play_sound_effect(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013307C: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80133080: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80133084: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x80133088: mtc1        $a3, $f12
    ctx->f12.u32l = ctx->r7;
    // 0x8013308C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80133090: sw          $a0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r4;
    // 0x80133094: sw          $a1, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r5;
    // 0x80133098: beq         $t6, $zero, L_80133178
    if (ctx->r14 == 0) {
        // 0x8013309C: sw          $a2, 0x88($sp)
        MEM_W(0X88, ctx->r29) = ctx->r6;
            goto L_80133178;
    }
    // 0x8013309C: sw          $a2, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r6;
    // 0x801330A0: lh          $t7, 0x82($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X82);
    // 0x801330A4: lh          $t8, 0x82($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X82);
    // 0x801330A8: addiu       $at, $zero, 0x2710
    ctx->r1 = ADD32(0, 0X2710);
    // 0x801330AC: beq         $t7, $at, L_80133178
    if (ctx->r15 == ctx->r1) {
        // 0x801330B0: sll         $v0, $t8, 2
        ctx->r2 = S32(ctx->r24 << 2);
            goto L_80133178;
    }
    // 0x801330B0: sll         $v0, $t8, 2
    ctx->r2 = S32(ctx->r24 << 2);
    // 0x801330B4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801330B8: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x801330BC: lwc1        $f4, 0x46E8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X46E8);
    // 0x801330C0: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x801330C4: addu        $t9, $t9, $v0
    ctx->r25 = ADD32(ctx->r25, ctx->r2);
    // 0x801330C8: mul.s       $f6, $f4, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f12.fl);
    // 0x801330CC: lw          $t9, 0x4C4C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4C4C);
    // 0x801330D0: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x801330D4: lh          $t0, 0x86($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X86);
    // 0x801330D8: lbu         $t1, 0x93($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X93);
    // 0x801330DC: lh          $t2, 0x8A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X8A);
    // 0x801330E0: lhu         $t3, 0x1D0E($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X1D0E);
    // 0x801330E4: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x801330E8: addiu       $t5, $sp, 0x4C
    ctx->r13 = ADD32(ctx->r29, 0X4C);
    // 0x801330EC: sh          $t9, 0x4C($sp)
    MEM_H(0X4C, ctx->r29) = ctx->r25;
    // 0x801330F0: sh          $t8, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r24;
    // 0x801330F4: sw          $zero, 0x60($sp)
    MEM_W(0X60, ctx->r29) = 0;
    // 0x801330F8: sw          $zero, 0x64($sp)
    MEM_W(0X64, ctx->r29) = 0;
    // 0x801330FC: swc1        $f6, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f6.u32l;
    // 0x80133100: sw          $zero, 0x74($sp)
    MEM_W(0X74, ctx->r29) = 0;
    // 0x80133104: sh          $t4, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r12;
    // 0x80133108: or          $t9, $sp, $zero
    ctx->r25 = ctx->r29 | 0;
    // 0x8013310C: addiu       $t7, $t5, 0x30
    ctx->r15 = ADD32(ctx->r13, 0X30);
    // 0x80133110: sh          $t0, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r8;
    // 0x80133114: sb          $t1, 0x50($sp)
    MEM_B(0X50, ctx->r29) = ctx->r9;
    // 0x80133118: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    // 0x8013311C: sh          $t3, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r11;
L_80133120:
    // 0x80133120: lw          $at, 0x0($t5)
    ctx->r1 = MEM_W(ctx->r13, 0X0);
    // 0x80133124: addiu       $t5, $t5, 0xC
    ctx->r13 = ADD32(ctx->r13, 0XC);
    // 0x80133128: addiu       $t9, $t9, 0xC
    ctx->r25 = ADD32(ctx->r25, 0XC);
    // 0x8013312C: sw          $at, -0xC($t9)
    MEM_W(-0XC, ctx->r25) = ctx->r1;
    // 0x80133130: lw          $at, -0x8($t5)
    ctx->r1 = MEM_W(ctx->r13, -0X8);
    // 0x80133134: sw          $at, -0x8($t9)
    MEM_W(-0X8, ctx->r25) = ctx->r1;
    // 0x80133138: lw          $at, -0x4($t5)
    ctx->r1 = MEM_W(ctx->r13, -0X4);
    // 0x8013313C: bne         $t5, $t7, L_80133120
    if (ctx->r13 != ctx->r15) {
        // 0x80133140: sw          $at, -0x4($t9)
        MEM_W(-0X4, ctx->r25) = ctx->r1;
            goto L_80133120;
    }
    // 0x80133140: sw          $at, -0x4($t9)
    MEM_W(-0X4, ctx->r25) = ctx->r1;
    // 0x80133144: lw          $at, 0x0($t5)
    ctx->r1 = MEM_W(ctx->r13, 0X0);
    // 0x80133148: lui         $t8, 0x8028
    ctx->r24 = S32(0X8028 << 16);
    // 0x8013314C: lui         $t0, 0x8028
    ctx->r8 = S32(0X8028 << 16);
    // 0x80133150: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x80133154: addiu       $t0, $t0, 0x6320
    ctx->r8 = ADD32(ctx->r8, 0X6320);
    // 0x80133158: addiu       $t8, $t8, 0x631C
    ctx->r24 = ADD32(ctx->r24, 0X631C);
    // 0x8013315C: sw          $t8, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r24;
    // 0x80133160: sw          $t0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r8;
    // 0x80133164: lw          $a3, 0xC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XC);
    // 0x80133168: lw          $a2, 0x8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X8);
    // 0x8013316C: lw          $a1, 0x4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4);
    // 0x80133170: jal         0x80132174
    // 0x80133174: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    func_80132174(rdram, ctx);
        goto after_0;
    // 0x80133174: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    after_0:
L_80133178:
    // 0x80133178: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8013317C: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    // 0x80133180: jr          $ra
    // 0x80133184: nop

    return;
    // 0x80133184: nop

;}
RECOMP_FUNC void func_80133188(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133188: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8013318C: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80133190: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x80133194: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80133198: sw          $a0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r4;
    // 0x8013319C: sw          $a1, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r5;
    // 0x801331A0: beq         $t6, $zero, L_8013327C
    if (ctx->r14 == 0) {
        // 0x801331A4: sw          $a2, 0x88($sp)
        MEM_W(0X88, ctx->r29) = ctx->r6;
            goto L_8013327C;
    }
    // 0x801331A4: sw          $a2, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r6;
    // 0x801331A8: lh          $t7, 0x82($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X82);
    // 0x801331AC: lh          $t8, 0x82($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X82);
    // 0x801331B0: addiu       $at, $zero, 0x2710
    ctx->r1 = ADD32(0, 0X2710);
    // 0x801331B4: beq         $t7, $at, L_8013327C
    if (ctx->r15 == ctx->r1) {
        // 0x801331B8: sll         $v0, $t8, 2
        ctx->r2 = S32(ctx->r24 << 2);
            goto L_8013327C;
    }
    // 0x801331B8: sll         $v0, $t8, 2
    ctx->r2 = S32(ctx->r24 << 2);
    // 0x801331BC: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x801331C0: addu        $t9, $t9, $v0
    ctx->r25 = ADD32(ctx->r25, ctx->r2);
    // 0x801331C4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801331C8: lw          $t9, 0x4C4C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4C4C);
    // 0x801331CC: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x801331D0: lui         $t3, 0x8024
    ctx->r11 = S32(0X8024 << 16);
    // 0x801331D4: lh          $t0, 0x8A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X8A);
    // 0x801331D8: lwc1        $f4, 0x46E8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X46E8);
    // 0x801331DC: lh          $t2, 0x86($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X86);
    // 0x801331E0: lhu         $t3, 0x1D0E($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X1D0E);
    // 0x801331E4: addiu       $t1, $zero, 0x40
    ctx->r9 = ADD32(0, 0X40);
    // 0x801331E8: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x801331EC: addiu       $t5, $sp, 0x4C
    ctx->r13 = ADD32(ctx->r29, 0X4C);
    // 0x801331F0: sh          $t9, 0x4C($sp)
    MEM_H(0X4C, ctx->r29) = ctx->r25;
    // 0x801331F4: sh          $t8, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r24;
    // 0x801331F8: sw          $zero, 0x60($sp)
    MEM_W(0X60, ctx->r29) = 0;
    // 0x801331FC: sw          $zero, 0x64($sp)
    MEM_W(0X64, ctx->r29) = 0;
    // 0x80133200: sb          $t1, 0x50($sp)
    MEM_B(0X50, ctx->r29) = ctx->r9;
    // 0x80133204: sw          $zero, 0x74($sp)
    MEM_W(0X74, ctx->r29) = 0;
    // 0x80133208: sh          $t4, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r12;
    // 0x8013320C: or          $t9, $sp, $zero
    ctx->r25 = ctx->r29 | 0;
    // 0x80133210: addiu       $t7, $t5, 0x30
    ctx->r15 = ADD32(ctx->r13, 0X30);
    // 0x80133214: sh          $t0, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r8;
    // 0x80133218: swc1        $f4, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f4.u32l;
    // 0x8013321C: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    // 0x80133220: sh          $t3, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r11;
L_80133224:
    // 0x80133224: lw          $at, 0x0($t5)
    ctx->r1 = MEM_W(ctx->r13, 0X0);
    // 0x80133228: addiu       $t5, $t5, 0xC
    ctx->r13 = ADD32(ctx->r13, 0XC);
    // 0x8013322C: addiu       $t9, $t9, 0xC
    ctx->r25 = ADD32(ctx->r25, 0XC);
    // 0x80133230: sw          $at, -0xC($t9)
    MEM_W(-0XC, ctx->r25) = ctx->r1;
    // 0x80133234: lw          $at, -0x8($t5)
    ctx->r1 = MEM_W(ctx->r13, -0X8);
    // 0x80133238: sw          $at, -0x8($t9)
    MEM_W(-0X8, ctx->r25) = ctx->r1;
    // 0x8013323C: lw          $at, -0x4($t5)
    ctx->r1 = MEM_W(ctx->r13, -0X4);
    // 0x80133240: bne         $t5, $t7, L_80133224
    if (ctx->r13 != ctx->r15) {
        // 0x80133244: sw          $at, -0x4($t9)
        MEM_W(-0X4, ctx->r25) = ctx->r1;
            goto L_80133224;
    }
    // 0x80133244: sw          $at, -0x4($t9)
    MEM_W(-0X4, ctx->r25) = ctx->r1;
    // 0x80133248: lw          $at, 0x0($t5)
    ctx->r1 = MEM_W(ctx->r13, 0X0);
    // 0x8013324C: lui         $t8, 0x8028
    ctx->r24 = S32(0X8028 << 16);
    // 0x80133250: lui         $t0, 0x8028
    ctx->r8 = S32(0X8028 << 16);
    // 0x80133254: sw          $at, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r1;
    // 0x80133258: addiu       $t0, $t0, 0x6320
    ctx->r8 = ADD32(ctx->r8, 0X6320);
    // 0x8013325C: addiu       $t8, $t8, 0x631C
    ctx->r24 = ADD32(ctx->r24, 0X631C);
    // 0x80133260: sw          $t8, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r24;
    // 0x80133264: sw          $t0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r8;
    // 0x80133268: lw          $a3, 0xC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XC);
    // 0x8013326C: lw          $a2, 0x8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X8);
    // 0x80133270: lw          $a1, 0x4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4);
    // 0x80133274: jal         0x80132174
    // 0x80133278: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    func_80132174(rdram, ctx);
        goto after_0;
    // 0x80133278: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    after_0:
L_8013327C:
    // 0x8013327C: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x80133280: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    // 0x80133284: jr          $ra
    // 0x80133288: nop

    return;
    // 0x80133288: nop

;}
RECOMP_FUNC void func_8013328C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013328C: addiu       $sp, $sp, -0x90
    ctx->r29 = ADD32(ctx->r29, -0X90);
    // 0x80133290: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80133294: sw          $a1, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r5;
    // 0x80133298: sw          $a0, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r4;
    // 0x8013329C: sw          $a2, 0x98($sp)
    MEM_W(0X98, ctx->r29) = ctx->r6;
    // 0x801332A0: sw          $a3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r7;
    // 0x801332A4: jal         0x80132580
    // 0x801332A8: lh          $a1, 0x96($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X96);
    get_sound_by_object_and_id(rdram, ctx);
        goto after_0;
    // 0x801332A8: lh          $a1, 0x96($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X96);
    after_0:
    // 0x801332AC: lh          $t0, 0x9A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X9A);
    // 0x801332B0: beq         $v0, $zero, L_8013344C
    if (ctx->r2 == 0) {
        // 0x801332B4: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_8013344C;
    }
    // 0x801332B4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x801332B8: lh          $t6, 0x22($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X22);
    // 0x801332BC: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801332C0: bltzl       $t6, L_80133444
    if (SIGNED(ctx->r14) < 0) {
        // 0x801332C4: addiu       $t1, $zero, 0x6
        ctx->r9 = ADD32(0, 0X6);
            goto L_80133444;
    }
    goto skip_0;
    // 0x801332C4: addiu       $t1, $zero, 0x6
    ctx->r9 = ADD32(0, 0X6);
    skip_0:
    // 0x801332C8: lh          $a1, 0x22($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X22);
    // 0x801332CC: sw          $v0, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r2;
    // 0x801332D0: jal         0x8013B980
    // 0x801332D4: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    alSndpSetSound(rdram, ctx);
        goto after_1;
    // 0x801332D4: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    after_1:
    // 0x801332D8: lw          $v1, 0x8C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X8C);
    // 0x801332DC: lh          $t0, 0x9A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X9A);
    // 0x801332E0: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801332E4: lbu         $t7, 0x4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X4);
    // 0x801332E8: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x801332EC: andi        $a1, $t0, 0xFF
    ctx->r5 = ctx->r8 & 0XFF;
    // 0x801332F0: beql        $t0, $t7, L_80133318
    if (ctx->r8 == ctx->r15) {
        // 0x801332F4: lh          $t8, 0x96($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X96);
            goto L_80133318;
    }
    goto skip_1;
    // 0x801332F4: lh          $t8, 0x96($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X96);
    skip_1:
    // 0x801332F8: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x801332FC: sw          $t0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r8;
    // 0x80133300: jal         0x8013BBD0
    // 0x80133304: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    alSndpSetPan(rdram, ctx);
        goto after_2;
    // 0x80133304: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    after_2:
    // 0x80133308: lw          $v0, 0x50($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X50);
    // 0x8013330C: lw          $v1, 0x8C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X8C);
    // 0x80133310: sb          $v0, 0x4($v1)
    MEM_B(0X4, ctx->r3) = ctx->r2;
    // 0x80133314: lh          $t8, 0x96($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X96);
L_80133318:
    // 0x80133318: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x8013331C: addiu       $t1, $t1, 0x46E8
    ctx->r9 = ADD32(ctx->r9, 0X46E8);
    // 0x80133320: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x80133324: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x80133328: lwc1        $f4, 0x0($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X0);
    // 0x8013332C: lwc1        $f6, 0x9C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X9C);
    // 0x80133330: lwc1        $f8, 0x8($v1)
    ctx->f8.u32l = MEM_W(ctx->r3, 0X8);
    // 0x80133334: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133338: mul.s       $f0, $f4, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x8013333C: c.eq.s      $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f8.fl == ctx->f0.fl;
    // 0x80133340: nop

    // 0x80133344: bc1tl       L_8013337C
    if (c1cs) {
        // 0x80133348: lh          $v0, 0xA2($sp)
        ctx->r2 = MEM_H(ctx->r29, 0XA2);
            goto L_8013337C;
    }
    goto skip_2;
    // 0x80133348: lh          $v0, 0xA2($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA2);
    skip_2:
    // 0x8013334C: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x80133350: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x80133354: sw          $v0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r2;
    // 0x80133358: jal         0x8013B9A0
    // 0x8013335C: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    alSndpSetPitch(rdram, ctx);
        goto after_3;
    // 0x8013335C: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    after_3:
    // 0x80133360: lw          $v0, 0x50($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X50);
    // 0x80133364: lwc1        $f16, 0x9C($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X9C);
    // 0x80133368: lw          $v1, 0x8C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X8C);
    // 0x8013336C: lwc1        $f10, 0x0($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0X0);
    // 0x80133370: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80133374: swc1        $f18, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->f18.u32l;
    // 0x80133378: lh          $v0, 0xA2($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA2);
L_8013337C:
    // 0x8013337C: lh          $t2, 0xC($v1)
    ctx->r10 = MEM_H(ctx->r3, 0XC);
    // 0x80133380: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x80133384: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133388: beql        $v0, $t2, L_80133444
    if (ctx->r2 == ctx->r10) {
        // 0x8013338C: addiu       $t1, $zero, 0x6
        ctx->r9 = ADD32(0, 0X6);
            goto L_80133444;
    }
    goto skip_3;
    // 0x8013338C: addiu       $t1, $zero, 0x6
    ctx->r9 = ADD32(0, 0X6);
    skip_3:
    // 0x80133390: lb          $t3, 0x46BC($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X46BC);
    // 0x80133394: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80133398: bnel        $t3, $at, L_80133404
    if (ctx->r11 != ctx->r1) {
        // 0x8013339C: mtc1        $v0, $f6
        ctx->f6.u32l = ctx->r2;
            goto L_80133404;
    }
    goto skip_4;
    // 0x8013339C: mtc1        $v0, $f6
    ctx->f6.u32l = ctx->r2;
    skip_4:
    // 0x801333A0: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x801333A4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801333A8: lwc1        $f6, 0x46CC($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X46CC);
    // 0x801333AC: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801333B0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801333B4: lwc1        $f8, 0x46C0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46C0);
    // 0x801333B8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801333BC: lwc1        $f18, 0x46C4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X46C4);
    // 0x801333C0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801333C4: mul.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x801333C8: lwc1        $f8, 0x46C8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46C8);
    // 0x801333CC: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801333D0: mul.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x801333D4: div.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    // 0x801333D8: lwc1        $f16, 0x46D4($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X46D4);
    // 0x801333DC: mul.s       $f6, $f0, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x801333E0: add.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x801333E4: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x801333E8: trunc.w.s   $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    ctx->f8.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x801333EC: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
    // 0x801333F0: nop

    // 0x801333F4: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x801333F8: b           L_80133428
    // 0x801333FC: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
        goto L_80133428;
    // 0x801333FC: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80133400: mtc1        $v0, $f6
    ctx->f6.u32l = ctx->r2;
L_80133404:
    // 0x80133404: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133408: lwc1        $f10, 0x46D4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X46D4);
    // 0x8013340C: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80133410: mul.s       $f16, $f4, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f4.fl, ctx->f10.fl);
    // 0x80133414: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80133418: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x8013341C: nop

    // 0x80133420: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80133424: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_80133428:
    // 0x80133428: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x8013342C: jal         0x8013BA00
    // 0x80133430: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    alSndpSetVol(rdram, ctx);
        goto after_4;
    // 0x80133430: sw          $v1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r3;
    after_4:
    // 0x80133434: lh          $v0, 0xA2($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA2);
    // 0x80133438: lw          $v1, 0x8C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X8C);
    // 0x8013343C: sh          $v0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r2;
    // 0x80133440: addiu       $t1, $zero, 0x6
    ctx->r9 = ADD32(0, 0X6);
L_80133444:
    // 0x80133444: b           L_80133518
    // 0x80133448: sh          $t1, 0xE($v1)
    MEM_H(0XE, ctx->r3) = ctx->r9;
        goto L_80133518;
    // 0x80133448: sh          $t1, 0xE($v1)
    MEM_H(0XE, ctx->r3) = ctx->r9;
L_8013344C:
    // 0x8013344C: lh          $v1, 0x96($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X96);
    // 0x80133450: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133454: lwc1        $f6, 0x9C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X9C);
    // 0x80133458: sll         $t3, $v1, 2
    ctx->r11 = S32(ctx->r3 << 2);
    // 0x8013345C: addu        $at, $at, $t3
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x80133460: lwc1        $f8, 0x46E8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46E8);
    // 0x80133464: lh          $t2, 0xA6($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XA6);
    // 0x80133468: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8013346C: mul.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x80133470: lh          $v0, 0xA2($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA2);
    // 0x80133474: lw          $t4, 0x90($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X90);
    // 0x80133478: lhu         $t6, 0x1D0E($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X1D0E);
    // 0x8013347C: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x80133480: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80133484: addiu       $t8, $sp, 0x58
    ctx->r24 = ADD32(ctx->r29, 0X58);
    // 0x80133488: sh          $t2, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r10;
    // 0x8013348C: sw          $zero, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = 0;
    // 0x80133490: sw          $zero, 0x70($sp)
    MEM_W(0X70, ctx->r29) = 0;
    // 0x80133494: sb          $t0, 0x5C($sp)
    MEM_B(0X5C, ctx->r29) = ctx->r8;
    // 0x80133498: swc1        $f4, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f4.u32l;
    // 0x8013349C: sh          $zero, 0x74($sp)
    MEM_H(0X74, ctx->r29) = 0;
    // 0x801334A0: sh          $t5, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r13;
    // 0x801334A4: sh          $t7, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r15;
    // 0x801334A8: or          $t2, $sp, $zero
    ctx->r10 = ctx->r29 | 0;
    // 0x801334AC: addiu       $t1, $t8, 0x30
    ctx->r9 = ADD32(ctx->r24, 0X30);
    // 0x801334B0: sh          $v1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r3;
    // 0x801334B4: sh          $v0, 0x64($sp)
    MEM_H(0X64, ctx->r29) = ctx->r2;
    // 0x801334B8: sw          $t4, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r12;
    // 0x801334BC: sh          $t6, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r14;
L_801334C0:
    // 0x801334C0: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x801334C4: addiu       $t8, $t8, 0xC
    ctx->r24 = ADD32(ctx->r24, 0XC);
    // 0x801334C8: addiu       $t2, $t2, 0xC
    ctx->r10 = ADD32(ctx->r10, 0XC);
    // 0x801334CC: sw          $at, -0xC($t2)
    MEM_W(-0XC, ctx->r10) = ctx->r1;
    // 0x801334D0: lw          $at, -0x8($t8)
    ctx->r1 = MEM_W(ctx->r24, -0X8);
    // 0x801334D4: sw          $at, -0x8($t2)
    MEM_W(-0X8, ctx->r10) = ctx->r1;
    // 0x801334D8: lw          $at, -0x4($t8)
    ctx->r1 = MEM_W(ctx->r24, -0X4);
    // 0x801334DC: bne         $t8, $t1, L_801334C0
    if (ctx->r24 != ctx->r9) {
        // 0x801334E0: sw          $at, -0x4($t2)
        MEM_W(-0X4, ctx->r10) = ctx->r1;
            goto L_801334C0;
    }
    // 0x801334E0: sw          $at, -0x4($t2)
    MEM_W(-0X4, ctx->r10) = ctx->r1;
    // 0x801334E4: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x801334E8: lui         $t3, 0x8028
    ctx->r11 = S32(0X8028 << 16);
    // 0x801334EC: lui         $t4, 0x8028
    ctx->r12 = S32(0X8028 << 16);
    // 0x801334F0: sw          $at, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r1;
    // 0x801334F4: addiu       $t4, $t4, 0x6320
    ctx->r12 = ADD32(ctx->r12, 0X6320);
    // 0x801334F8: addiu       $t3, $t3, 0x631C
    ctx->r11 = ADD32(ctx->r11, 0X631C);
    // 0x801334FC: sw          $t3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r11;
    // 0x80133500: sw          $t4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r12;
    // 0x80133504: lw          $a3, 0xC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XC);
    // 0x80133508: lw          $a2, 0x8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X8);
    // 0x8013350C: lw          $a1, 0x4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4);
    // 0x80133510: jal         0x80132174
    // 0x80133514: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    func_80132174(rdram, ctx);
        goto after_5;
    // 0x80133514: lw          $a0, 0x0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X0);
    after_5:
L_80133518:
    // 0x80133518: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8013351C: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
    // 0x80133520: jr          $ra
    // 0x80133524: nop

    return;
    // 0x80133524: nop

;}
RECOMP_FUNC void play_sound_by_id_with_volume(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133528: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8013352C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80133530: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80133534: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80133538: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x8013353C: jal         0x80132414
    // 0x80133540: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    get_sound_by_id(rdram, ctx);
        goto after_0;
    // 0x80133540: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80133544: beql        $v0, $zero, L_80133590
    if (ctx->r2 == 0) {
        // 0x80133548: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80133590;
    }
    goto skip_0;
    // 0x80133548: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x8013354C: lh          $v1, 0x22($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X22);
    // 0x80133550: lui         $t7, 0x8028
    ctx->r15 = S32(0X8028 << 16);
    // 0x80133554: bltz        $v1, L_8013358C
    if (SIGNED(ctx->r3) < 0) {
        // 0x80133558: addu        $t7, $t7, $v1
        ctx->r15 = ADD32(ctx->r15, ctx->r3);
            goto L_8013358C;
    }
    // 0x80133558: addu        $t7, $t7, $v1
    ctx->r15 = ADD32(ctx->r15, ctx->r3);
    // 0x8013355C: lbu         $t7, 0x63B0($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X63B0);
    // 0x80133560: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80133564: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133568: beql        $t7, $at, L_80133590
    if (ctx->r15 == ctx->r1) {
        // 0x8013356C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80133590;
    }
    goto skip_1;
    // 0x8013356C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80133570: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x80133574: jal         0x8013B980
    // 0x80133578: lh          $a1, 0x22($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X22);
    alSndpSetSound(rdram, ctx);
        goto after_1;
    // 0x80133578: lh          $a1, 0x22($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X22);
    after_1:
    // 0x8013357C: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133580: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x80133584: jal         0x8013BA00
    // 0x80133588: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
    alSndpSetVol(rdram, ctx);
        goto after_2;
    // 0x80133588: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
    after_2:
L_8013358C:
    // 0x8013358C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80133590:
    // 0x80133590: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80133594: jr          $ra
    // 0x80133598: nop

    return;
    // 0x80133598: nop

;}
RECOMP_FUNC void play_sound_by_id(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013359C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801335A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801335A4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x801335A8: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x801335AC: jal         0x80132414
    // 0x801335B0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    get_sound_by_id(rdram, ctx);
        goto after_0;
    // 0x801335B0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_0:
    // 0x801335B4: beql        $v0, $zero, L_801335FC
    if (ctx->r2 == 0) {
        // 0x801335B8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_801335FC;
    }
    goto skip_0;
    // 0x801335B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x801335BC: lh          $v1, 0x22($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X22);
    // 0x801335C0: lui         $t7, 0x8028
    ctx->r15 = S32(0X8028 << 16);
    // 0x801335C4: bltz        $v1, L_801335F8
    if (SIGNED(ctx->r3) < 0) {
        // 0x801335C8: addu        $t7, $t7, $v1
        ctx->r15 = ADD32(ctx->r15, ctx->r3);
            goto L_801335F8;
    }
    // 0x801335C8: addu        $t7, $t7, $v1
    ctx->r15 = ADD32(ctx->r15, ctx->r3);
    // 0x801335CC: lbu         $t7, 0x63B0($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X63B0);
    // 0x801335D0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801335D4: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801335D8: beql        $t7, $at, L_801335FC
    if (ctx->r15 == ctx->r1) {
        // 0x801335DC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_801335FC;
    }
    goto skip_1;
    // 0x801335DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x801335E0: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    // 0x801335E4: jal         0x8013B980
    // 0x801335E8: lh          $a1, 0x22($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X22);
    alSndpSetSound(rdram, ctx);
        goto after_1;
    // 0x801335E8: lh          $a1, 0x22($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X22);
    after_1:
    // 0x801335EC: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801335F0: jal         0x8013BC30
    // 0x801335F4: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    alSndpStop(rdram, ctx);
        goto after_2;
    // 0x801335F4: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    after_2:
L_801335F8:
    // 0x801335F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801335FC:
    // 0x801335FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80133600: jr          $ra
    // 0x80133604: nop

    return;
    // 0x80133604: nop

;}
RECOMP_FUNC void play_sound_by_slot(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133608: sll         $a1, $a0, 16
    ctx->r5 = S32(ctx->r4 << 16);
    // 0x8013360C: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80133610: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80133614: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80133618: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8013361C: bltz        $t6, L_8013363C
    if (SIGNED(ctx->r14) < 0) {
        // 0x80133620: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_8013363C;
    }
    // 0x80133620: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80133624: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133628: jal         0x8013B980
    // 0x8013362C: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    alSndpSetSound(rdram, ctx);
        goto after_0;
    // 0x8013362C: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    after_0:
    // 0x80133630: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133634: jal         0x8013BC30
    // 0x80133638: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    alSndpStop(rdram, ctx);
        goto after_1;
    // 0x80133638: lw          $a0, 0x6310($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X6310);
    after_1:
L_8013363C:
    // 0x8013363C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80133640: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80133644: jr          $ra
    // 0x80133648: nop

    return;
    // 0x80133648: nop

;}
RECOMP_FUNC void func_8013364C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013364C: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80133650: sw          $s6, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r22;
    // 0x80133654: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x80133658: sw          $s4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r20;
    // 0x8013365C: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x80133660: sw          $s7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r23;
    // 0x80133664: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x80133668: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8013366C: lui         $s2, 0x8015
    ctx->r18 = S32(0X8015 << 16);
    // 0x80133670: lui         $s4, 0x8028
    ctx->r20 = S32(0X8028 << 16);
    // 0x80133674: lui         $s5, 0x8015
    ctx->r21 = S32(0X8015 << 16);
    // 0x80133678: lui         $s6, 0x8015
    ctx->r22 = S32(0X8015 << 16);
    // 0x8013367C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80133680: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80133684: addiu       $s6, $s6, 0x5164
    ctx->r22 = ADD32(ctx->r22, 0X5164);
    // 0x80133688: addiu       $s5, $s5, 0x4690
    ctx->r21 = ADD32(ctx->r21, 0X4690);
    // 0x8013368C: addiu       $s4, $s4, 0x63C8
    ctx->r20 = ADD32(ctx->r20, 0X63C8);
    // 0x80133690: addiu       $s2, $s2, 0x5168
    ctx->r18 = ADD32(ctx->r18, 0X5168);
    // 0x80133694: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80133698: addiu       $s3, $zero, 0x1
    ctx->r19 = ADD32(0, 0X1);
    // 0x8013369C: addiu       $s7, $zero, -0x1
    ctx->r23 = ADD32(0, -0X1);
L_801336A0:
    // 0x801336A0: addu        $s1, $s2, $s0
    ctx->r17 = ADD32(ctx->r18, ctx->r16);
    // 0x801336A4: andi        $t6, $s3, 0xFF
    ctx->r14 = ctx->r19 & 0XFF;
    // 0x801336A8: beq         $t6, $zero, L_801336C4
    if (ctx->r14 == 0) {
        // 0x801336AC: sb          $s3, 0x0($s1)
        MEM_B(0X0, ctx->r17) = ctx->r19;
            goto L_801336C4;
    }
    // 0x801336AC: sb          $s3, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r19;
    // 0x801336B0: sll         $t7, $s0, 2
    ctx->r15 = S32(ctx->r16 << 2);
    // 0x801336B4: addu        $t8, $s4, $t7
    ctx->r24 = ADD32(ctx->r20, ctx->r15);
    // 0x801336B8: jal         0x8013BB30
    // 0x801336BC: lw          $a0, 0x0($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X0);
    alSeqpStop(rdram, ctx);
        goto after_0;
    // 0x801336BC: lw          $a0, 0x0($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X0);
    after_0:
    // 0x801336C0: sb          $zero, 0x0($s1)
    MEM_B(0X0, ctx->r17) = 0;
L_801336C4:
    // 0x801336C4: addu        $t9, $s5, $s0
    ctx->r25 = ADD32(ctx->r21, ctx->r16);
    // 0x801336C8: addu        $t0, $s6, $s0
    ctx->r8 = ADD32(ctx->r22, ctx->r16);
    // 0x801336CC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x801336D0: sll         $t1, $s0, 24
    ctx->r9 = S32(ctx->r16 << 24);
    // 0x801336D4: sra         $s0, $t1, 24
    ctx->r16 = S32(SIGNED(ctx->r9) >> 24);
    // 0x801336D8: sb          $zero, 0x0($t9)
    MEM_B(0X0, ctx->r25) = 0;
    // 0x801336DC: blez        $s0, L_801336A0
    if (SIGNED(ctx->r16) <= 0) {
        // 0x801336E0: sb          $s7, 0x0($t0)
        MEM_B(0X0, ctx->r8) = ctx->r23;
            goto L_801336A0;
    }
    // 0x801336E0: sb          $s7, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r23;
    // 0x801336E4: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x801336E8: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801336EC: sb          $t3, 0x6458($at)
    MEM_B(0X6458, ctx->r1) = ctx->r11;
    // 0x801336F0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801336F4: sw          $s7, 0x515C($at)
    MEM_W(0X515C, ctx->r1) = ctx->r23;
    // 0x801336F8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801336FC: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80133700: sb          $s7, 0x5170($at)
    MEM_B(0X5170, ctx->r1) = ctx->r23;
    // 0x80133704: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133708: addiu       $t4, $zero, -0x63
    ctx->r12 = ADD32(0, -0X63);
    // 0x8013370C: lw          $s7, 0x30($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X30);
    // 0x80133710: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80133714: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80133718: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x8013371C: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x80133720: lw          $s4, 0x24($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X24);
    // 0x80133724: lw          $s5, 0x28($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X28);
    // 0x80133728: lw          $s6, 0x2C($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X2C);
    // 0x8013372C: sh          $t4, 0x5188($at)
    MEM_H(0X5188, ctx->r1) = ctx->r12;
    // 0x80133730: jr          $ra
    // 0x80133734: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x80133734: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void stop_all_sounds(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133738: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8013373C: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80133740: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80133744: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80133748: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8013374C: beq         $t6, $zero, L_801337A8
    if (ctx->r14 == 0) {
        // 0x80133750: sw          $s0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r16;
            goto L_801337A8;
    }
    // 0x80133750: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80133754: lui         $s1, 0x8028
    ctx->r17 = S32(0X8028 << 16);
    // 0x80133758: addiu       $s1, $s1, 0x6310
    ctx->r17 = ADD32(ctx->r17, 0X6310);
    // 0x8013375C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80133760: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
L_80133764:
    // 0x80133764: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80133768: jal         0x801323B8
    // 0x8013376C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    get_sound_by_slot(rdram, ctx);
        goto after_0;
    // 0x8013376C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_0:
    // 0x80133770: beql        $v0, $zero, L_80133784
    if (ctx->r2 == 0) {
        // 0x80133774: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80133784;
    }
    goto skip_0;
    // 0x80133774: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x80133778: jal         0x8013BC30
    // 0x8013377C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    alSndpStop(rdram, ctx);
        goto after_1;
    // 0x8013377C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_1:
    // 0x80133780: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80133784:
    // 0x80133784: sll         $t8, $s0, 24
    ctx->r24 = S32(ctx->r16 << 24);
    // 0x80133788: sra         $s0, $t8, 24
    ctx->r16 = S32(SIGNED(ctx->r24) >> 24);
    // 0x8013378C: slti        $at, $s0, 0x14
    ctx->r1 = SIGNED(ctx->r16) < 0X14 ? 1 : 0;
    // 0x80133790: bnel        $at, $zero, L_80133764
    if (ctx->r1 != 0) {
        // 0x80133794: sll         $a0, $s0, 16
        ctx->r4 = S32(ctx->r16 << 16);
            goto L_80133764;
    }
    goto skip_1;
    // 0x80133794: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
    skip_1:
    // 0x80133798: jal         0x8013364C
    // 0x8013379C: nop

    func_8013364C(rdram, ctx);
        goto after_2;
    // 0x8013379C: nop

    after_2:
    // 0x801337A0: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801337A4: sh          $zero, 0x645C($at)
    MEM_H(0X645C, ctx->r1) = 0;
L_801337A8:
    // 0x801337A8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x801337AC: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x801337B0: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x801337B4: jr          $ra
    // 0x801337B8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x801337B8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
