#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_802A4184_6B5834(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4184: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4188: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802A418C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4190: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4194: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802A4198: jal         0x80298F78
    // 0x802A419C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    func_80298F78_6AA628(rdram, ctx);
        goto after_0;
    // 0x802A419C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    after_0:
    // 0x802A41A0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A41A4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A41A8: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802A41AC: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802A41B0: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802A41B4: lhu         $t8, 0xBA($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XBA);
    // 0x802A41B8: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x802A41BC: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A41C0: subu        $a0, $t9, $v0
    ctx->r4 = SUB32(ctx->r25, ctx->r2);
    // 0x802A41C4: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x802A41C8: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802A41CC: bltz        $a0, L_802A41E8
    if (SIGNED(ctx->r4) < 0) {
        // 0x802A41D0: slti        $at, $a0, -0xF
        ctx->r1 = SIGNED(ctx->r4) < -0XF ? 1 : 0;
            goto L_802A41E8;
    }
    // 0x802A41D0: slti        $at, $a0, -0xF
    ctx->r1 = SIGNED(ctx->r4) < -0XF ? 1 : 0;
    // 0x802A41D4: lw          $t2, 0x24($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X24);
    // 0x802A41D8: lw          $t3, 0x5B0($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5B0);
    // 0x802A41DC: subu        $t4, $t2, $t3
    ctx->r12 = SUB32(ctx->r10, ctx->r11);
    // 0x802A41E0: b           L_802A4210
    // 0x802A41E4: sw          $t4, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r12;
        goto L_802A4210;
    // 0x802A41E4: sw          $t4, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r12;
L_802A41E8:
    // 0x802A41E8: bne         $at, $zero, L_802A4210
    if (ctx->r1 != 0) {
        // 0x802A41EC: lui         $t7, 0x803A
        ctx->r15 = S32(0X803A << 16);
            goto L_802A4210;
    }
    // 0x802A41EC: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x802A41F0: lw          $t7, 0x5B0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5B0);
    // 0x802A41F4: addiu       $t5, $a0, 0x10
    ctx->r13 = ADD32(ctx->r4, 0X10);
    // 0x802A41F8: lw          $t9, 0x24($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X24);
    // 0x802A41FC: multu       $t5, $t7
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4200: mflo        $t6
    ctx->r14 = lo;
    // 0x802A4204: sra         $t8, $t6, 4
    ctx->r24 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802A4208: subu        $t0, $t9, $t8
    ctx->r8 = SUB32(ctx->r25, ctx->r24);
    // 0x802A420C: sw          $t0, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r8;
L_802A4210:
    // 0x802A4210: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4214: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4218: jr          $ra
    // 0x802A421C: nop

    return;
    // 0x802A421C: nop

;}
RECOMP_FUNC void func_802A4220_6B58D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4220: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802A4224: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802A4228: bgez        $v0, L_802A4238
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A422C: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A4238;
    }
    // 0x802A422C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A4230: b           L_802A4238
    // 0x802A4234: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A4238;
    // 0x802A4234: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A4238:
    // 0x802A4238: lw          $a2, 0x0($a1)
    ctx->r6 = MEM_W(ctx->r5, 0X0);
    // 0x802A423C: lhu         $v1, 0xA($sp)
    ctx->r3 = MEM_HU(ctx->r29, 0XA);
    // 0x802A4240: bgez        $a2, L_802A4250
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802A4244: or          $a3, $a2, $zero
        ctx->r7 = ctx->r6 | 0;
            goto L_802A4250;
    }
    // 0x802A4244: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x802A4248: b           L_802A4250
    // 0x802A424C: negu        $a3, $a2
    ctx->r7 = SUB32(0, ctx->r6);
        goto L_802A4250;
    // 0x802A424C: negu        $a3, $a2
    ctx->r7 = SUB32(0, ctx->r6);
L_802A4250:
    // 0x802A4250: multu       $v0, $v1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4254: mflo        $t6
    ctx->r14 = lo;
    // 0x802A4258: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x802A425C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x802A4260: lw          $t8, 0x0($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X0);
    // 0x802A4264: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4268: mflo        $t9
    ctx->r25 = lo;
    // 0x802A426C: sra         $t0, $t9, 8
    ctx->r8 = S32(SIGNED(ctx->r25) >> 8);
    // 0x802A4270: jr          $ra
    // 0x802A4274: sw          $t0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r8;
    return;
    // 0x802A4274: sw          $t0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r8;
;}
RECOMP_FUNC void func_802A4278_6B5928(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4278: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802A427C: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x802A4280: andi        $t6, $a0, 0xFFFF
    ctx->r14 = ctx->r4 & 0XFFFF;
    // 0x802A4284: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A4288: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A428C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802A4290: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x802A4294: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x802A4298: lh          $t1, 0x302($t6)
    ctx->r9 = MEM_H(ctx->r14, 0X302);
    // 0x802A429C: andi        $t7, $a1, 0xFFFF
    ctx->r15 = ctx->r5 & 0XFFFF;
    // 0x802A42A0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802A42A4: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802A42A8: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802A42AC: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x802A42B0: andi        $t7, $t1, 0xFF
    ctx->r15 = ctx->r9 & 0XFF;
    // 0x802A42B4: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802A42B8: addiu       $t9, $t9, 0x2C78
    ctx->r25 = ADD32(ctx->r25, 0X2C78);
    // 0x802A42BC: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x802A42C0: lh          $t0, 0x0($t6)
    ctx->r8 = MEM_H(ctx->r14, 0X0);
    // 0x802A42C4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A42C8: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802A42CC: addiu       $t8, $t1, 0x40
    ctx->r24 = ADD32(ctx->r9, 0X40);
    // 0x802A42D0: sra         $t7, $t0, 5
    ctx->r15 = S32(SIGNED(ctx->r8) >> 5);
    // 0x802A42D4: lw          $v0, 0x1C($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X1C);
    // 0x802A42D8: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x802A42DC: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x802A42E0: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802A42E4: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x802A42E8: sra         $t7, $v0, 10
    ctx->r15 = S32(SIGNED(ctx->r2) >> 10);
    // 0x802A42EC: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A42F0: lh          $t2, 0x0($t8)
    ctx->r10 = MEM_H(ctx->r24, 0X0);
    // 0x802A42F4: lw          $a3, 0x20($v1)
    ctx->r7 = MEM_W(ctx->r3, 0X20);
    // 0x802A42F8: sw          $a1, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r5;
    // 0x802A42FC: sra         $t6, $t2, 5
    ctx->r14 = S32(SIGNED(ctx->r10) >> 5);
    // 0x802A4300: sra         $t8, $a3, 10
    ctx->r24 = S32(SIGNED(ctx->r7) >> 10);
    // 0x802A4304: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
    // 0x802A4308: mflo        $t9
    ctx->r25 = lo;
    // 0x802A430C: nop

    // 0x802A4310: nop

    // 0x802A4314: multu       $t8, $t6
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4318: mflo        $t6
    ctx->r14 = lo;
    // 0x802A431C: addu        $t4, $t9, $t6
    ctx->r12 = ADD32(ctx->r25, ctx->r14);
    // 0x802A4320: sra         $t7, $t4, 10
    ctx->r15 = S32(SIGNED(ctx->r12) >> 10);
    // 0x802A4324: multu       $t0, $t7
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4328: mflo        $t0
    ctx->r8 = lo;
    // 0x802A432C: subu        $t8, $v0, $t0
    ctx->r24 = SUB32(ctx->r2, ctx->r8);
    // 0x802A4330: nop

    // 0x802A4334: multu       $t2, $t7
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4338: srav        $t7, $v0, $a1
    ctx->r15 = S32(SIGNED(ctx->r2) >> (ctx->r5 & 31));
    // 0x802A433C: mflo        $t2
    ctx->r10 = lo;
    // 0x802A4340: srav        $t9, $t8, $a0
    ctx->r25 = S32(SIGNED(ctx->r24) >> (ctx->r4 & 31));
    // 0x802A4344: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x802A4348: multu       $t8, $a2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A434C: subu        $t8, $a3, $t2
    ctx->r24 = SUB32(ctx->r7, ctx->r10);
    // 0x802A4350: mflo        $t9
    ctx->r25 = lo;
    // 0x802A4354: sra         $t7, $t9, 4
    ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802A4358: subu        $v0, $v0, $t7
    ctx->r2 = SUB32(ctx->r2, ctx->r15);
    // 0x802A435C: srav        $t9, $t8, $a0
    ctx->r25 = S32(SIGNED(ctx->r24) >> (ctx->r4 & 31));
    // 0x802A4360: srav        $t7, $a3, $a1
    ctx->r15 = S32(SIGNED(ctx->r7) >> (ctx->r5 & 31));
    // 0x802A4364: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x802A4368: multu       $t8, $a2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A436C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A4370: sw          $v0, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r2;
    // 0x802A4374: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A4378: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802A437C: mflo        $t6
    ctx->r14 = lo;
    // 0x802A4380: sra         $t9, $t6, 4
    ctx->r25 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802A4384: subu        $a3, $a3, $t9
    ctx->r7 = SUB32(ctx->r7, ctx->r25);
    // 0x802A4388: jr          $ra
    // 0x802A438C: sw          $a3, 0x20($t7)
    MEM_W(0X20, ctx->r15) = ctx->r7;
    return;
    // 0x802A438C: sw          $a3, 0x20($t7)
    MEM_W(0X20, ctx->r15) = ctx->r7;
;}
RECOMP_FUNC void func_802A4390_6B5A40(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4390: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A4394: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A4398: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A439C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A43A0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A43A4: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802A43A8: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A43AC: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A43B0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A43B4: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A43B8: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A43BC: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A43C0: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A43C4: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A43C8: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A43CC: jal         0x802B8720
    // 0x802A43D0: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A43D0: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    after_0:
    // 0x802A43D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A43D8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A43DC: jr          $ra
    // 0x802A43E0: nop

    return;
    // 0x802A43E0: nop

;}
RECOMP_FUNC void func_802A43E4_6B5A94(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A43E4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A43E8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A43EC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A43F0: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A43F4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A43F8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A43FC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4400: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A4404: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4408: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802A440C: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802A4410: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A4414: lw          $t2, 0x0($a2)
    ctx->r10 = MEM_W(ctx->r6, 0X0);
    // 0x802A4418: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x802A441C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A4420: sh          $t1, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r9;
    // 0x802A4424: lw          $t3, 0x0($a2)
    ctx->r11 = MEM_W(ctx->r6, 0X0);
    // 0x802A4428: addiu       $a3, $a3, 0x5524
    ctx->r7 = ADD32(ctx->r7, 0X5524);
    // 0x802A442C: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A4430: sh          $a0, 0x2C($t3)
    MEM_H(0X2C, ctx->r11) = ctx->r4;
    // 0x802A4434: lw          $t4, 0x0($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X0);
    // 0x802A4438: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x802A443C: sra         $a1, $t7, 24
    ctx->r5 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A4440: lhu         $v0, 0x9C($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X9C);
    // 0x802A4444: beq         $v0, $at, L_802A4454
    if (ctx->r2 == ctx->r1) {
        // 0x802A4448: addiu       $at, $zero, 0x16
        ctx->r1 = ADD32(0, 0X16);
            goto L_802A4454;
    }
    // 0x802A4448: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802A444C: bnel        $v0, $at, L_802A4484
    if (ctx->r2 != ctx->r1) {
        // 0x802A4450: lw          $t1, 0x0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X0);
            goto L_802A4484;
    }
    goto skip_0;
    // 0x802A4450: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    skip_0:
L_802A4454:
    // 0x802A4454: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802A4458: sll         $t7, $a1, 2
    ctx->r15 = S32(ctx->r5 << 2);
    // 0x802A445C: addu        $t7, $t7, $a1
    ctx->r15 = ADD32(ctx->r15, ctx->r5);
    // 0x802A4460: lw          $t6, 0x320($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X320);
    // 0x802A4464: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A4468: beql        $t6, $zero, L_802A4484
    if (ctx->r14 == 0) {
        // 0x802A446C: lw          $t1, 0x0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X0);
            goto L_802A4484;
    }
    goto skip_1;
    // 0x802A446C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    skip_1:
    // 0x802A4470: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x802A4474: mflo        $t8
    ctx->r24 = lo;
    // 0x802A4478: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x802A447C: sra         $a1, $t9, 24
    ctx->r5 = S32(SIGNED(ctx->r25) >> 24);
    // 0x802A4480: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
L_802A4484:
    // 0x802A4484: sb          $a1, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r5;
    // 0x802A4488: lw          $t2, 0x0($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X0);
    // 0x802A448C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802A4490: lhu         $t3, 0xA4($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XA4);
    // 0x802A4494: multu       $a1, $t3
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4498: mflo        $t4
    ctx->r12 = lo;
    // 0x802A449C: bgez        $t4, L_802A44AC
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802A44A0: sra         $t5, $t4, 4
        ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
            goto L_802A44AC;
    }
    // 0x802A44A0: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802A44A4: addiu       $at, $t4, 0xF
    ctx->r1 = ADD32(ctx->r12, 0XF);
    // 0x802A44A8: sra         $t5, $at, 4
    ctx->r13 = S32(SIGNED(ctx->r1) >> 4);
L_802A44AC:
    // 0x802A44AC: jal         0x802B8790
    // 0x802A44B0: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A44B0: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    after_0:
    // 0x802A44B4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A44B8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A44BC: jr          $ra
    // 0x802A44C0: nop

    return;
    // 0x802A44C0: nop

;}
RECOMP_FUNC void func_802A44C4_6B5B74(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A44C4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A44C8: addiu       $a3, $a3, 0x5530
    ctx->r7 = ADD32(ctx->r7, 0X5530);
    // 0x802A44CC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A44D0: lw          $t0, 0x0($a3)
    ctx->r8 = MEM_W(ctx->r7, 0X0);
    // 0x802A44D4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A44D8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A44DC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A44E0: addiu       $t9, $zero, 0x6
    ctx->r25 = ADD32(0, 0X6);
    // 0x802A44E4: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A44E8: lw          $t1, 0x0($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X0);
    // 0x802A44EC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A44F0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A44F4: sh          $a0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r4;
    // 0x802A44F8: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A44FC: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A4500: sra         $a1, $t7, 24
    ctx->r5 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A4504: sh          $zero, 0x2F2($t2)
    MEM_H(0X2F2, ctx->r10) = 0;
    // 0x802A4508: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802A450C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802A4510: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x802A4514: sh          $zero, 0x2F4($t3)
    MEM_H(0X2F4, ctx->r11) = 0;
    // 0x802A4518: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A451C: sb          $a1, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r5;
    // 0x802A4520: lw          $a2, 0x5524($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X5524);
    // 0x802A4524: lhu         $v0, 0x9C($a2)
    ctx->r2 = MEM_HU(ctx->r6, 0X9C);
    // 0x802A4528: beq         $v0, $at, L_802A4538
    if (ctx->r2 == ctx->r1) {
        // 0x802A452C: addiu       $at, $zero, 0x16
        ctx->r1 = ADD32(0, 0X16);
            goto L_802A4538;
    }
    // 0x802A452C: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802A4530: bnel        $v0, $at, L_802A4568
    if (ctx->r2 != ctx->r1) {
        // 0x802A4534: lhu         $t1, 0xA4($a2)
        ctx->r9 = MEM_HU(ctx->r6, 0XA4);
            goto L_802A4568;
    }
    goto skip_0;
    // 0x802A4534: lhu         $t1, 0xA4($a2)
    ctx->r9 = MEM_HU(ctx->r6, 0XA4);
    skip_0:
L_802A4538:
    // 0x802A4538: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802A453C: sll         $t7, $a1, 2
    ctx->r15 = S32(ctx->r5 << 2);
    // 0x802A4540: addu        $t7, $t7, $a1
    ctx->r15 = ADD32(ctx->r15, ctx->r5);
    // 0x802A4544: lw          $t6, 0x320($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X320);
    // 0x802A4548: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A454C: beql        $t6, $zero, L_802A4568
    if (ctx->r14 == 0) {
        // 0x802A4550: lhu         $t1, 0xA4($a2)
        ctx->r9 = MEM_HU(ctx->r6, 0XA4);
            goto L_802A4568;
    }
    goto skip_1;
    // 0x802A4550: lhu         $t1, 0xA4($a2)
    ctx->r9 = MEM_HU(ctx->r6, 0XA4);
    skip_1:
    // 0x802A4554: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x802A4558: mflo        $t8
    ctx->r24 = lo;
    // 0x802A455C: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x802A4560: sra         $a1, $t9, 24
    ctx->r5 = S32(SIGNED(ctx->r25) >> 24);
    // 0x802A4564: lhu         $t1, 0xA4($a2)
    ctx->r9 = MEM_HU(ctx->r6, 0XA4);
L_802A4568:
    // 0x802A4568: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A456C: multu       $a1, $t1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4570: mflo        $t2
    ctx->r10 = lo;
    // 0x802A4574: bgez        $t2, L_802A4584
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802A4578: sra         $t3, $t2, 4
        ctx->r11 = S32(SIGNED(ctx->r10) >> 4);
            goto L_802A4584;
    }
    // 0x802A4578: sra         $t3, $t2, 4
    ctx->r11 = S32(SIGNED(ctx->r10) >> 4);
    // 0x802A457C: addiu       $at, $t2, 0xF
    ctx->r1 = ADD32(ctx->r10, 0XF);
    // 0x802A4580: sra         $t3, $at, 4
    ctx->r11 = S32(SIGNED(ctx->r1) >> 4);
L_802A4584:
    // 0x802A4584: jal         0x802B8790
    // 0x802A4588: sh          $t3, 0x31A($t4)
    MEM_H(0X31A, ctx->r12) = ctx->r11;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A4588: sh          $t3, 0x31A($t4)
    MEM_H(0X31A, ctx->r12) = ctx->r11;
    after_0:
    // 0x802A458C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4590: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4594: jr          $ra
    // 0x802A4598: nop

    return;
    // 0x802A4598: nop

;}
RECOMP_FUNC void func_802A459C_6B5C4C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A459C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A45A0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A45A4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A45A8: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A45AC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A45B0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A45B4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A45B8: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A45BC: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A45C0: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802A45C4: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802A45C8: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A45CC: lw          $t2, 0x0($a2)
    ctx->r10 = MEM_W(ctx->r6, 0X0);
    // 0x802A45D0: addiu       $t1, $zero, 0x4
    ctx->r9 = ADD32(0, 0X4);
    // 0x802A45D4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A45D8: sh          $t1, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r9;
    // 0x802A45DC: lw          $t3, 0x0($a2)
    ctx->r11 = MEM_W(ctx->r6, 0X0);
    // 0x802A45E0: addiu       $a3, $a3, 0x5524
    ctx->r7 = ADD32(ctx->r7, 0X5524);
    // 0x802A45E4: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A45E8: sh          $a0, 0x2C($t3)
    MEM_H(0X2C, ctx->r11) = ctx->r4;
    // 0x802A45EC: lw          $t4, 0x0($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X0);
    // 0x802A45F0: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x802A45F4: sra         $a1, $t7, 24
    ctx->r5 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A45F8: lhu         $v0, 0x9C($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X9C);
    // 0x802A45FC: beq         $v0, $at, L_802A460C
    if (ctx->r2 == ctx->r1) {
        // 0x802A4600: addiu       $at, $zero, 0x16
        ctx->r1 = ADD32(0, 0X16);
            goto L_802A460C;
    }
    // 0x802A4600: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802A4604: bnel        $v0, $at, L_802A463C
    if (ctx->r2 != ctx->r1) {
        // 0x802A4608: lw          $t1, 0x0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X0);
            goto L_802A463C;
    }
    goto skip_0;
    // 0x802A4608: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    skip_0:
L_802A460C:
    // 0x802A460C: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802A4610: sll         $t7, $a1, 2
    ctx->r15 = S32(ctx->r5 << 2);
    // 0x802A4614: addu        $t7, $t7, $a1
    ctx->r15 = ADD32(ctx->r15, ctx->r5);
    // 0x802A4618: lw          $t6, 0x320($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X320);
    // 0x802A461C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A4620: beql        $t6, $zero, L_802A463C
    if (ctx->r14 == 0) {
        // 0x802A4624: lw          $t1, 0x0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X0);
            goto L_802A463C;
    }
    goto skip_1;
    // 0x802A4624: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    skip_1:
    // 0x802A4628: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x802A462C: mflo        $t8
    ctx->r24 = lo;
    // 0x802A4630: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x802A4634: sra         $a1, $t9, 24
    ctx->r5 = S32(SIGNED(ctx->r25) >> 24);
    // 0x802A4638: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
L_802A463C:
    // 0x802A463C: sb          $a1, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r5;
    // 0x802A4640: lw          $t2, 0x0($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X0);
    // 0x802A4644: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802A4648: lhu         $t3, 0xA4($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XA4);
    // 0x802A464C: multu       $a1, $t3
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4650: mflo        $t4
    ctx->r12 = lo;
    // 0x802A4654: bgez        $t4, L_802A4664
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802A4658: sra         $t5, $t4, 4
        ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
            goto L_802A4664;
    }
    // 0x802A4658: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802A465C: addiu       $at, $t4, 0xF
    ctx->r1 = ADD32(ctx->r12, 0XF);
    // 0x802A4660: sra         $t5, $at, 4
    ctx->r13 = S32(SIGNED(ctx->r1) >> 4);
L_802A4664:
    // 0x802A4664: jal         0x802B8810
    // 0x802A4668: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    func_802B8810_6C9EC0(rdram, ctx);
        goto after_0;
    // 0x802A4668: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    after_0:
    // 0x802A466C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4670: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4674: jr          $ra
    // 0x802A4678: nop

    return;
    // 0x802A4678: nop

;}
RECOMP_FUNC void func_802A467C_6B5D2C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A467C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A4680: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x802A4684: addiu       $sp, $sp, -0x68
    ctx->r29 = ADD32(ctx->r29, -0X68);
    // 0x802A4688: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802A468C: beq         $t6, $zero, L_802A46C0
    if (ctx->r14 == 0) {
        // 0x802A4690: sw          $a0, 0x68($sp)
        MEM_W(0X68, ctx->r29) = ctx->r4;
            goto L_802A46C0;
    }
    // 0x802A4690: sw          $a0, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r4;
    // 0x802A4694: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802A4698: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A469C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A46A0: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A46A4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A46A8: lh          $a0, 0x5564($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X5564);
    // 0x802A46AC: lh          $a1, 0x5568($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X5568);
    // 0x802A46B0: lh          $v1, 0x556C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X556C);
    // 0x802A46B4: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802A46B8: b           L_802A46DC
    // 0x802A46BC: lw          $t3, 0x5560($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5560);
        goto L_802A46DC;
    // 0x802A46BC: lw          $t3, 0x5560($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5560);
L_802A46C0:
    // 0x802A46C0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A46C4: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802A46C8: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A46CC: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802A46D0: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802A46D4: lbu         $v1, 0x160($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X160);
    // 0x802A46D8: lw          $t3, 0x6C($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X6C);
L_802A46DC:
    // 0x802A46DC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A46E0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A46E4: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x802A46E8: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x802A46EC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802A46F0: sb          $t7, 0x367($t8)
    MEM_B(0X367, ctx->r24) = ctx->r15;
    // 0x802A46F4: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x802A46F8: addiu       $a2, $sp, 0x66
    ctx->r6 = ADD32(ctx->r29, 0X66);
    // 0x802A46FC: beq         $t3, $zero, L_802A4710
    if (ctx->r11 == 0) {
        // 0x802A4700: sb          $t9, 0x36D($t6)
        MEM_B(0X36D, ctx->r14) = ctx->r25;
            goto L_802A4710;
    }
    // 0x802A4700: sb          $t9, 0x36D($t6)
    MEM_B(0X36D, ctx->r14) = ctx->r25;
    // 0x802A4704: sh          $zero, 0x64($sp)
    MEM_H(0X64, ctx->r29) = 0;
    // 0x802A4708: b           L_802A474C
    // 0x802A470C: sh          $zero, 0x66($sp)
    MEM_H(0X66, ctx->r29) = 0;
        goto L_802A474C;
    // 0x802A470C: sh          $zero, 0x66($sp)
    MEM_H(0X66, ctx->r29) = 0;
L_802A4710:
    // 0x802A4710: addiu       $a3, $sp, 0x64
    ctx->r7 = ADD32(ctx->r29, 0X64);
    // 0x802A4714: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    // 0x802A4718: sh          $v1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r3;
    // 0x802A471C: sh          $a0, 0x4A($sp)
    MEM_H(0X4A, ctx->r29) = ctx->r4;
    // 0x802A4720: sh          $a1, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r5;
    // 0x802A4724: jal         0x80311A2C
    // 0x802A4728: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_0;
    // 0x802A4728: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    after_0:
    // 0x802A472C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A4730: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A4734: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802A4738: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A473C: lh          $v1, 0x46($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X46);
    // 0x802A4740: lh          $a0, 0x4A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X4A);
    // 0x802A4744: lh          $a1, 0x48($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X48);
    // 0x802A4748: lw          $t3, 0x40($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X40);
L_802A474C:
    // 0x802A474C: bne         $t3, $zero, L_802A47F4
    if (ctx->r11 != 0) {
        // 0x802A4750: lh          $t7, 0x66($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X66);
            goto L_802A47F4;
    }
    // 0x802A4750: lh          $t7, 0x66($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X66);
    // 0x802A4754: bne         $t7, $zero, L_802A4760
    if (ctx->r15 != 0) {
        // 0x802A4758: lh          $t8, 0x64($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X64);
            goto L_802A4760;
    }
    // 0x802A4758: lh          $t8, 0x64($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X64);
    // 0x802A475C: beq         $t8, $zero, L_802A47F4
    if (ctx->r24 == 0) {
        // 0x802A4760: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A47F4;
    }
L_802A4760:
    // 0x802A4760: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A4764: bne         $v1, $at, L_802A47B0
    if (ctx->r3 != ctx->r1) {
        // 0x802A4768: sra         $t8, $a0, 6
        ctx->r24 = S32(SIGNED(ctx->r4) >> 6);
            goto L_802A47B0;
    }
    // 0x802A4768: sra         $t8, $a0, 6
    ctx->r24 = S32(SIGNED(ctx->r4) >> 6);
    // 0x802A476C: sra         $t9, $a0, 6
    ctx->r25 = S32(SIGNED(ctx->r4) >> 6);
    // 0x802A4770: sll         $t6, $t9, 7
    ctx->r14 = S32(ctx->r25 << 7);
    // 0x802A4774: sra         $t7, $a1, 6
    ctx->r15 = S32(SIGNED(ctx->r5) >> 6);
    // 0x802A4778: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802A477C: addu        $t6, $t6, $t9
    ctx->r14 = ADD32(ctx->r14, ctx->r25);
    // 0x802A4780: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802A4784: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A4788: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x802A478C: addu        $t7, $t7, $t9
    ctx->r15 = ADD32(ctx->r15, ctx->r25);
    // 0x802A4790: lbu         $t7, 0x743($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X743);
    // 0x802A4794: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802A4798: sll         $t6, $t7, 2
    ctx->r14 = S32(ctx->r15 << 2);
    // 0x802A479C: subu        $t6, $t6, $t7
    ctx->r14 = SUB32(ctx->r14, ctx->r15);
    // 0x802A47A0: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802A47A4: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x802A47A8: b           L_802A47EC
    // 0x802A47AC: lbu         $v0, 0x1D30($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X1D30);
        goto L_802A47EC;
    // 0x802A47AC: lbu         $v0, 0x1D30($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X1D30);
L_802A47B0:
    // 0x802A47B0: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x802A47B4: sra         $t7, $a1, 6
    ctx->r15 = S32(SIGNED(ctx->r5) >> 6);
    // 0x802A47B8: sll         $t6, $t7, 3
    ctx->r14 = S32(ctx->r15 << 3);
    // 0x802A47BC: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802A47C0: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802A47C4: addu        $t8, $t9, $t6
    ctx->r24 = ADD32(ctx->r25, ctx->r14);
    // 0x802A47C8: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x802A47CC: addu        $t7, $t7, $t8
    ctx->r15 = ADD32(ctx->r15, ctx->r24);
    // 0x802A47D0: lbu         $t7, 0x742($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X742);
    // 0x802A47D4: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802A47D8: sll         $t9, $t7, 2
    ctx->r25 = S32(ctx->r15 << 2);
    // 0x802A47DC: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x802A47E0: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802A47E4: addu        $v0, $v0, $t9
    ctx->r2 = ADD32(ctx->r2, ctx->r25);
    // 0x802A47E8: lbu         $v0, 0x1D30($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X1D30);
L_802A47EC:
    // 0x802A47EC: beql        $v0, $zero, L_802A4CAC
    if (ctx->r2 == 0) {
        // 0x802A47F0: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802A4CAC;
    }
    goto skip_0;
    // 0x802A47F0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
L_802A47F4:
    // 0x802A47F4: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x802A47F8: addiu       $t7, $zero, 0x16
    ctx->r15 = ADD32(0, 0X16);
    // 0x802A47FC: sh          $zero, 0x2F2($t6)
    MEM_H(0X2F2, ctx->r14) = 0;
    // 0x802A4800: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x802A4804: sh          $zero, 0x2F4($t8)
    MEM_H(0X2F4, ctx->r24) = 0;
    // 0x802A4808: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x802A480C: sh          $t7, 0x2FC($t9)
    MEM_H(0X2FC, ctx->r25) = ctx->r15;
    // 0x802A4810: lb          $t6, 0x6B($sp)
    ctx->r14 = MEM_B(ctx->r29, 0X6B);
    // 0x802A4814: lh          $t1, 0x66($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X66);
    // 0x802A4818: lh          $t4, 0x64($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X64);
    // 0x802A481C: bne         $t6, $zero, L_802A4838
    if (ctx->r14 != 0) {
        // 0x802A4820: lh          $t9, 0x66($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X66);
            goto L_802A4838;
    }
    // 0x802A4820: lh          $t9, 0x66($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X66);
    // 0x802A4824: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802A4828: addiu       $ra, $ra, 0x5524
    ctx->r31 = ADD32(ctx->r31, 0X5524);
    // 0x802A482C: lw          $t8, 0x0($ra)
    ctx->r24 = MEM_W(ctx->r31, 0X0);
    // 0x802A4830: b           L_802A4848
    // 0x802A4834: lhu         $t5, 0xA6($t8)
    ctx->r13 = MEM_HU(ctx->r24, 0XA6);
        goto L_802A4848;
    // 0x802A4834: lhu         $t5, 0xA6($t8)
    ctx->r13 = MEM_HU(ctx->r24, 0XA6);
L_802A4838:
    // 0x802A4838: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802A483C: addiu       $ra, $ra, 0x5524
    ctx->r31 = ADD32(ctx->r31, 0X5524);
    // 0x802A4840: lw          $t7, 0x0($ra)
    ctx->r15 = MEM_W(ctx->r31, 0X0);
    // 0x802A4844: lhu         $t5, 0xA8($t7)
    ctx->r13 = MEM_HU(ctx->r15, 0XA8);
L_802A4848:
    // 0x802A4848: bgezl       $t9, L_802A485C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802A484C: lh          $v0, 0x66($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X66);
            goto L_802A485C;
    }
    goto skip_1;
    // 0x802A484C: lh          $v0, 0x66($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X66);
    skip_1:
    // 0x802A4850: b           L_802A485C
    // 0x802A4854: negu        $v0, $t9
    ctx->r2 = SUB32(0, ctx->r25);
        goto L_802A485C;
    // 0x802A4854: negu        $v0, $t9
    ctx->r2 = SUB32(0, ctx->r25);
    // 0x802A4858: lh          $v0, 0x66($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X66);
L_802A485C:
    // 0x802A485C: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A4860: beq         $at, $zero, L_802A4890
    if (ctx->r1 == 0) {
        // 0x802A4864: nop
    
            goto L_802A4890;
    }
    // 0x802A4864: nop

    // 0x802A4868: lh          $t6, 0x64($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X64);
    // 0x802A486C: lh          $v0, 0x64($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X64);
    // 0x802A4870: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802A4874: bgez        $t6, L_802A4884
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802A4878: nop
    
            goto L_802A4884;
    }
    // 0x802A4878: nop

    // 0x802A487C: b           L_802A4884
    // 0x802A4880: negu        $v0, $t6
    ctx->r2 = SUB32(0, ctx->r14);
        goto L_802A4884;
    // 0x802A4880: negu        $v0, $t6
    ctx->r2 = SUB32(0, ctx->r14);
L_802A4884:
    // 0x802A4884: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A4888: bne         $at, $zero, L_802A4898
    if (ctx->r1 != 0) {
        // 0x802A488C: nop
    
            goto L_802A4898;
    }
    // 0x802A488C: nop

L_802A4890:
    // 0x802A4890: b           L_802A4898
    // 0x802A4894: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
        goto L_802A4898;
    // 0x802A4894: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_802A4898:
    // 0x802A4898: bne         $t0, $zero, L_802A4960
    if (ctx->r8 != 0) {
        // 0x802A489C: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_802A4960;
    }
    // 0x802A489C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A48A0: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x802A48A4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802A48A8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A48AC: beq         $t8, $zero, L_802A4960
    if (ctx->r24 == 0) {
        // 0x802A48B0: addiu       $a2, $sp, 0x60
        ctx->r6 = ADD32(ctx->r29, 0X60);
            goto L_802A4960;
    }
    // 0x802A48B0: addiu       $a2, $sp, 0x60
    ctx->r6 = ADD32(ctx->r29, 0X60);
    // 0x802A48B4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A48B8: lh          $t7, 0x556E($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X556E);
    // 0x802A48BC: lh          $a0, 0x5566($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X5566);
    // 0x802A48C0: lh          $a1, 0x556A($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X556A);
    // 0x802A48C4: addiu       $a3, $sp, 0x5E
    ctx->r7 = ADD32(ctx->r29, 0X5E);
    // 0x802A48C8: sh          $t0, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r8;
    // 0x802A48CC: sh          $t1, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r9;
    // 0x802A48D0: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x802A48D4: sh          $t4, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r12;
    // 0x802A48D8: sw          $t5, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r13;
    // 0x802A48DC: jal         0x80311A2C
    // 0x802A48E0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_1;
    // 0x802A48E0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    after_1:
    // 0x802A48E4: lh          $a0, 0x60($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X60);
    // 0x802A48E8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A48EC: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802A48F0: addiu       $ra, $ra, 0x5524
    ctx->r31 = ADD32(ctx->r31, 0X5524);
    // 0x802A48F4: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802A48F8: lh          $t0, 0x44($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X44);
    // 0x802A48FC: lh          $t1, 0x5C($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X5C);
    // 0x802A4900: lw          $t3, 0x40($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X40);
    // 0x802A4904: lh          $t4, 0x5A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X5A);
    // 0x802A4908: bgez        $a0, L_802A4918
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A490C: lw          $t5, 0x54($sp)
        ctx->r13 = MEM_W(ctx->r29, 0X54);
            goto L_802A4918;
    }
    // 0x802A490C: lw          $t5, 0x54($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X54);
    // 0x802A4910: b           L_802A491C
    // 0x802A4914: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
        goto L_802A491C;
    // 0x802A4914: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
L_802A4918:
    // 0x802A4918: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_802A491C:
    // 0x802A491C: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A4920: beq         $at, $zero, L_802A4960
    if (ctx->r1 == 0) {
        // 0x802A4924: lh          $v1, 0x5E($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X5E);
            goto L_802A4960;
    }
    // 0x802A4924: lh          $v1, 0x5E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X5E);
    // 0x802A4928: bgez        $v1, L_802A4938
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802A492C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802A4938;
    }
    // 0x802A492C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802A4930: b           L_802A4938
    // 0x802A4934: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802A4938;
    // 0x802A4934: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802A4938:
    // 0x802A4938: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A493C: beql        $at, $zero, L_802A4964
    if (ctx->r1 == 0) {
        // 0x802A4940: slti        $at, $t1, -0x17
        ctx->r1 = SIGNED(ctx->r9) < -0X17 ? 1 : 0;
            goto L_802A4964;
    }
    goto skip_2;
    // 0x802A4940: slti        $at, $t1, -0x17
    ctx->r1 = SIGNED(ctx->r9) < -0X17 ? 1 : 0;
    skip_2:
    // 0x802A4944: sll         $t1, $a0, 16
    ctx->r9 = S32(ctx->r4 << 16);
    // 0x802A4948: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x802A494C: sra         $t9, $t1, 16
    ctx->r25 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802A4950: sra         $t6, $t4, 16
    ctx->r14 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802A4954: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802A4958: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x802A495C: or          $t4, $t6, $zero
    ctx->r12 = ctx->r14 | 0;
L_802A4960:
    // 0x802A4960: slti        $at, $t1, -0x17
    ctx->r1 = SIGNED(ctx->r9) < -0X17 ? 1 : 0;
L_802A4964:
    // 0x802A4964: beql        $at, $zero, L_802A49A0
    if (ctx->r1 == 0) {
        // 0x802A4968: slti        $at, $t1, 0x18
        ctx->r1 = SIGNED(ctx->r9) < 0X18 ? 1 : 0;
            goto L_802A49A0;
    }
    goto skip_3;
    // 0x802A4968: slti        $at, $t1, 0x18
    ctx->r1 = SIGNED(ctx->r9) < 0X18 ? 1 : 0;
    skip_3:
    // 0x802A496C: lw          $t8, 0x0($ra)
    ctx->r24 = MEM_W(ctx->r31, 0X0);
    // 0x802A4970: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4974: lhu         $a0, 0xA6($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XA6);
    // 0x802A4978: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A497C: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A4980: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A4984: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A4988: beq         $at, $zero, L_802A4998
    if (ctx->r1 == 0) {
        // 0x802A498C: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A4998;
    }
    // 0x802A498C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A4990: b           L_802A499C
    // 0x802A4994: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
        goto L_802A499C;
    // 0x802A4994: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
L_802A4998:
    // 0x802A4998: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
L_802A499C:
    // 0x802A499C: slti        $at, $t1, 0x18
    ctx->r1 = SIGNED(ctx->r9) < 0X18 ? 1 : 0;
L_802A49A0:
    // 0x802A49A0: bnel        $at, $zero, L_802A49D8
    if (ctx->r1 != 0) {
        // 0x802A49A4: slti        $at, $t4, -0x17
        ctx->r1 = SIGNED(ctx->r12) < -0X17 ? 1 : 0;
            goto L_802A49D8;
    }
    goto skip_4;
    // 0x802A49A4: slti        $at, $t4, -0x17
    ctx->r1 = SIGNED(ctx->r12) < -0X17 ? 1 : 0;
    skip_4:
    // 0x802A49A8: lw          $t9, 0x0($ra)
    ctx->r25 = MEM_W(ctx->r31, 0X0);
    // 0x802A49AC: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A49B0: lhu         $a0, 0xA6($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0XA6);
    // 0x802A49B4: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A49B8: sll         $t6, $a0, 15
    ctx->r14 = S32(ctx->r4 << 15);
    // 0x802A49BC: slt         $at, $t6, $v1
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A49C0: beq         $at, $zero, L_802A49D0
    if (ctx->r1 == 0) {
        // 0x802A49C4: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_802A49D0;
    }
    // 0x802A49C4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A49C8: b           L_802A49D4
    // 0x802A49CC: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
        goto L_802A49D4;
    // 0x802A49CC: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
L_802A49D0:
    // 0x802A49D0: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
L_802A49D4:
    // 0x802A49D4: slti        $at, $t4, -0x17
    ctx->r1 = SIGNED(ctx->r12) < -0X17 ? 1 : 0;
L_802A49D8:
    // 0x802A49D8: beq         $at, $zero, L_802A4A10
    if (ctx->r1 == 0) {
        // 0x802A49DC: sll         $a1, $t5, 12
        ctx->r5 = S32(ctx->r13 << 12);
            goto L_802A4A10;
    }
    // 0x802A49DC: sll         $a1, $t5, 12
    ctx->r5 = S32(ctx->r13 << 12);
    // 0x802A49E0: lw          $t8, 0x0($ra)
    ctx->r24 = MEM_W(ctx->r31, 0X0);
    // 0x802A49E4: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A49E8: lhu         $a0, 0xA6($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XA6);
    // 0x802A49EC: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A49F0: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A49F4: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A49F8: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A49FC: beq         $at, $zero, L_802A4A0C
    if (ctx->r1 == 0) {
        // 0x802A4A00: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A4A0C;
    }
    // 0x802A4A00: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A4A04: b           L_802A4A10
    // 0x802A4A08: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
        goto L_802A4A10;
    // 0x802A4A08: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
L_802A4A0C:
    // 0x802A4A0C: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
L_802A4A10:
    // 0x802A4A10: slti        $at, $t4, 0x18
    ctx->r1 = SIGNED(ctx->r12) < 0X18 ? 1 : 0;
    // 0x802A4A14: bnel        $at, $zero, L_802A4A4C
    if (ctx->r1 != 0) {
        // 0x802A4A18: lw          $v0, 0x0($t2)
        ctx->r2 = MEM_W(ctx->r10, 0X0);
            goto L_802A4A4C;
    }
    goto skip_5;
    // 0x802A4A18: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    skip_5:
    // 0x802A4A1C: lw          $t9, 0x0($ra)
    ctx->r25 = MEM_W(ctx->r31, 0X0);
    // 0x802A4A20: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4A24: lhu         $a0, 0xA6($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0XA6);
    // 0x802A4A28: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A4A2C: sll         $t6, $a0, 15
    ctx->r14 = S32(ctx->r4 << 15);
    // 0x802A4A30: slt         $at, $t6, $v1
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A4A34: beq         $at, $zero, L_802A4A44
    if (ctx->r1 == 0) {
        // 0x802A4A38: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_802A4A44;
    }
    // 0x802A4A38: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A4A3C: b           L_802A4A48
    // 0x802A4A40: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
        goto L_802A4A48;
    // 0x802A4A40: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
L_802A4A44:
    // 0x802A4A44: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
L_802A4A48:
    // 0x802A4A48: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
L_802A4A4C:
    // 0x802A4A4C: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802A4A50: beq         $t0, $zero, L_802A4A8C
    if (ctx->r8 == 0) {
        // 0x802A4A54: or          $a3, $v1, $zero
        ctx->r7 = ctx->r3 | 0;
            goto L_802A4A8C;
    }
    // 0x802A4A54: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802A4A58: lbu         $a2, 0x162($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X162);
    // 0x802A4A5C: sll         $a0, $t5, 16
    ctx->r4 = S32(ctx->r13 << 16);
    // 0x802A4A60: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A4A64: beq         $a2, $at, L_802A4A80
    if (ctx->r6 == ctx->r1) {
        // 0x802A4A68: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A4A80;
    }
    // 0x802A4A68: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A4A6C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A4A70: beq         $a2, $at, L_802A4A80
    if (ctx->r6 == ctx->r1) {
        // 0x802A4A74: lui         $t8, 0x803A
        ctx->r24 = S32(0X803A << 16);
            goto L_802A4A80;
    }
    // 0x802A4A74: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x802A4A78: lw          $t8, 0x5B0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5B0);
    // 0x802A4A7C: addu        $a1, $a0, $t8
    ctx->r5 = ADD32(ctx->r4, ctx->r24);
L_802A4A80:
    // 0x802A4A80: addu        $t7, $v1, $a1
    ctx->r15 = ADD32(ctx->r3, ctx->r5);
    // 0x802A4A84: b           L_802A4A94
    // 0x802A4A88: sw          $t7, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r15;
        goto L_802A4A94;
    // 0x802A4A88: sw          $t7, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r15;
L_802A4A8C:
    // 0x802A4A8C: addu        $t9, $v1, $a1
    ctx->r25 = ADD32(ctx->r3, ctx->r5);
    // 0x802A4A90: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
L_802A4A94:
    // 0x802A4A94: bne         $t3, $zero, L_802A4AE0
    if (ctx->r11 != 0) {
        // 0x802A4A98: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_802A4AE0;
    }
    // 0x802A4A98: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A4A9C: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4AA0: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802A4AA4: slt         $at, $a1, $v1
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A4AA8: beql        $at, $zero, L_802A4ABC
    if (ctx->r1 == 0) {
        // 0x802A4AAC: sw          $v1, 0x24($v0)
        MEM_W(0X24, ctx->r2) = ctx->r3;
            goto L_802A4ABC;
    }
    goto skip_6;
    // 0x802A4AAC: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
    skip_6:
    // 0x802A4AB0: b           L_802A4ABC
    // 0x802A4AB4: sw          $a1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r5;
        goto L_802A4ABC;
    // 0x802A4AB4: sw          $a1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r5;
    // 0x802A4AB8: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
L_802A4ABC:
    // 0x802A4ABC: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4AC0: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802A4AC4: slt         $at, $v1, $a3
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802A4AC8: beq         $at, $zero, L_802A4AD8
    if (ctx->r1 == 0) {
        // 0x802A4ACC: nop
    
            goto L_802A4AD8;
    }
    // 0x802A4ACC: nop

    // 0x802A4AD0: b           L_802A4B28
    // 0x802A4AD4: sw          $a3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r7;
        goto L_802A4B28;
    // 0x802A4AD4: sw          $a3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r7;
L_802A4AD8:
    // 0x802A4AD8: b           L_802A4B28
    // 0x802A4ADC: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
        goto L_802A4B28;
    // 0x802A4ADC: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
L_802A4AE0:
    // 0x802A4AE0: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4AE4: lw          $t6, 0x24($t3)
    ctx->r14 = MEM_W(ctx->r11, 0X24);
    // 0x802A4AE8: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802A4AEC: addu        $a0, $t6, $a1
    ctx->r4 = ADD32(ctx->r14, ctx->r5);
    // 0x802A4AF0: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A4AF4: beql        $at, $zero, L_802A4B08
    if (ctx->r1 == 0) {
        // 0x802A4AF8: sw          $v1, 0x24($v0)
        MEM_W(0X24, ctx->r2) = ctx->r3;
            goto L_802A4B08;
    }
    goto skip_7;
    // 0x802A4AF8: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
    skip_7:
    // 0x802A4AFC: b           L_802A4B08
    // 0x802A4B00: sw          $a0, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r4;
        goto L_802A4B08;
    // 0x802A4B00: sw          $a0, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r4;
    // 0x802A4B04: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
L_802A4B08:
    // 0x802A4B08: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4B0C: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802A4B10: slt         $at, $v1, $a3
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802A4B14: beql        $at, $zero, L_802A4B28
    if (ctx->r1 == 0) {
        // 0x802A4B18: sw          $v1, 0x24($v0)
        MEM_W(0X24, ctx->r2) = ctx->r3;
            goto L_802A4B28;
    }
    goto skip_8;
    // 0x802A4B18: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
    skip_8:
    // 0x802A4B1C: b           L_802A4B28
    // 0x802A4B20: sw          $a3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r7;
        goto L_802A4B28;
    // 0x802A4B20: sw          $a3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r7;
    // 0x802A4B24: sw          $v1, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r3;
L_802A4B28:
    // 0x802A4B28: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4B2C: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x802A4B30: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802A4B34: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802A4B38: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802A4B3C: slti        $at, $v1, 0x7
    ctx->r1 = SIGNED(ctx->r3) < 0X7 ? 1 : 0;
    // 0x802A4B40: beql        $at, $zero, L_802A4B64
    if (ctx->r1 == 0) {
        // 0x802A4B44: slti        $at, $v1, 0x19
        ctx->r1 = SIGNED(ctx->r3) < 0X19 ? 1 : 0;
            goto L_802A4B64;
    }
    goto skip_9;
    // 0x802A4B44: slti        $at, $v1, 0x19
    ctx->r1 = SIGNED(ctx->r3) < 0X19 ? 1 : 0;
    skip_9:
    // 0x802A4B48: sb          $t8, 0x162($v0)
    MEM_B(0X162, ctx->r2) = ctx->r24;
    // 0x802A4B4C: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x802A4B50: addiu       $t7, $zero, 0x5
    ctx->r15 = ADD32(0, 0X5);
    // 0x802A4B54: sh          $t7, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r15;
    // 0x802A4B58: b           L_802A4BC0
    // 0x802A4B5C: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
        goto L_802A4BC0;
    // 0x802A4B5C: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x802A4B60: slti        $at, $v1, 0x19
    ctx->r1 = SIGNED(ctx->r3) < 0X19 ? 1 : 0;
L_802A4B64:
    // 0x802A4B64: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B68: slti        $at, $v1, 0x2B
        ctx->r1 = SIGNED(ctx->r3) < 0X2B ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B68: slti        $at, $v1, 0x2B
    ctx->r1 = SIGNED(ctx->r3) < 0X2B ? 1 : 0;
    // 0x802A4B6C: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B70: slti        $at, $v1, 0x40
        ctx->r1 = SIGNED(ctx->r3) < 0X40 ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B70: slti        $at, $v1, 0x40
    ctx->r1 = SIGNED(ctx->r3) < 0X40 ? 1 : 0;
    // 0x802A4B74: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B78: slti        $at, $v1, 0x52
        ctx->r1 = SIGNED(ctx->r3) < 0X52 ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B78: slti        $at, $v1, 0x52
    ctx->r1 = SIGNED(ctx->r3) < 0X52 ? 1 : 0;
    // 0x802A4B7C: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B80: slti        $at, $v1, 0x6B
        ctx->r1 = SIGNED(ctx->r3) < 0X6B ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B80: slti        $at, $v1, 0x6B
    ctx->r1 = SIGNED(ctx->r3) < 0X6B ? 1 : 0;
    // 0x802A4B84: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B88: slti        $at, $v1, 0x7C
        ctx->r1 = SIGNED(ctx->r3) < 0X7C ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B88: slti        $at, $v1, 0x7C
    ctx->r1 = SIGNED(ctx->r3) < 0X7C ? 1 : 0;
    // 0x802A4B8C: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B90: slti        $at, $v1, 0x91
        ctx->r1 = SIGNED(ctx->r3) < 0X91 ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B90: slti        $at, $v1, 0x91
    ctx->r1 = SIGNED(ctx->r3) < 0X91 ? 1 : 0;
    // 0x802A4B94: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4B98: slti        $at, $v1, 0xA3
        ctx->r1 = SIGNED(ctx->r3) < 0XA3 ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4B98: slti        $at, $v1, 0xA3
    ctx->r1 = SIGNED(ctx->r3) < 0XA3 ? 1 : 0;
    // 0x802A4B9C: bne         $at, $zero, L_802A4BC0
    if (ctx->r1 != 0) {
        // 0x802A4BA0: slti        $at, $v1, 0xBA
        ctx->r1 = SIGNED(ctx->r3) < 0XBA ? 1 : 0;
            goto L_802A4BC0;
    }
    // 0x802A4BA0: slti        $at, $v1, 0xBA
    ctx->r1 = SIGNED(ctx->r3) < 0XBA ? 1 : 0;
    // 0x802A4BA4: beq         $at, $zero, L_802A4BC0
    if (ctx->r1 == 0) {
        // 0x802A4BA8: addiu       $t6, $zero, 0x7
        ctx->r14 = ADD32(0, 0X7);
            goto L_802A4BC0;
    }
    // 0x802A4BA8: addiu       $t6, $zero, 0x7
    ctx->r14 = ADD32(0, 0X7);
    // 0x802A4BAC: sb          $t6, 0x162($v0)
    MEM_B(0X162, ctx->r2) = ctx->r14;
    // 0x802A4BB0: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x802A4BB4: addiu       $t8, $zero, 0xB8
    ctx->r24 = ADD32(0, 0XB8);
    // 0x802A4BB8: sh          $t8, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r24;
    // 0x802A4BBC: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
L_802A4BC0:
    // 0x802A4BC0: lw          $t9, 0x0($ra)
    ctx->r25 = MEM_W(ctx->r31, 0X0);
    // 0x802A4BC4: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x802A4BC8: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x802A4BCC: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
    // 0x802A4BD0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A4BD4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802A4BD8: sll         $t6, $v1, 1
    ctx->r14 = S32(ctx->r3 << 1);
    // 0x802A4BDC: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x802A4BE0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802A4BE4: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    // 0x802A4BE8: addu        $a1, $a1, $t6
    ctx->r5 = ADD32(ctx->r5, ctx->r14);
    // 0x802A4BEC: lh          $a1, 0x6680($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6680);
    // 0x802A4BF0: lh          $a0, 0x65D0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X65D0);
    // 0x802A4BF4: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x802A4BF8: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802A4BFC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802A4C00: jal         0x8032C360
    // 0x802A4C04: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x802A4C04: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_2:
    // 0x802A4C08: jal         0x802B8890
    // 0x802A4C0C: nop

    func_802B8890_6C9F40(rdram, ctx);
        goto after_3;
    // 0x802A4C0C: nop

    after_3:
    // 0x802A4C10: lw          $t3, 0x40($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X40);
    // 0x802A4C14: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A4C18: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802A4C1C: beql        $t3, $zero, L_802A4CAC
    if (ctx->r11 == 0) {
        // 0x802A4C20: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802A4CAC;
    }
    goto skip_10;
    // 0x802A4C20: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_10:
    // 0x802A4C24: lbu         $t9, 0x162($t3)
    ctx->r25 = MEM_BU(ctx->r11, 0X162);
    // 0x802A4C28: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802A4C2C: bnel        $t9, $at, L_802A4CAC
    if (ctx->r25 != ctx->r1) {
        // 0x802A4C30: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802A4CAC;
    }
    goto skip_11;
    // 0x802A4C30: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_11:
    // 0x802A4C34: lw          $t6, 0x4C($t3)
    ctx->r14 = MEM_W(ctx->r11, 0X4C);
    // 0x802A4C38: sll         $t7, $t6, 29
    ctx->r15 = S32(ctx->r14 << 29);
    // 0x802A4C3C: bgezl       $t7, L_802A4CAC
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802A4C40: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802A4CAC;
    }
    goto skip_12;
    // 0x802A4C40: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_12:
    // 0x802A4C44: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x802A4C48: lhu         $t7, 0x44($t3)
    ctx->r15 = MEM_HU(ctx->r11, 0X44);
    // 0x802A4C4C: lhu         $t6, 0x44($t9)
    ctx->r14 = MEM_HU(ctx->r25, 0X44);
    // 0x802A4C50: sll         $t8, $t6, 19
    ctx->r24 = S32(ctx->r14 << 19);
    // 0x802A4C54: div         $zero, $t8, $t7
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r15))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r15)));
    // 0x802A4C58: bne         $t7, $zero, L_802A4C64
    if (ctx->r15 != 0) {
        // 0x802A4C5C: nop
    
            goto L_802A4C64;
    }
    // 0x802A4C5C: nop

    // 0x802A4C60: break       7
    do_break(2150255712);
L_802A4C64:
    // 0x802A4C64: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802A4C68: bne         $t7, $at, L_802A4C7C
    if (ctx->r15 != ctx->r1) {
        // 0x802A4C6C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802A4C7C;
    }
    // 0x802A4C6C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802A4C70: bne         $t8, $at, L_802A4C7C
    if (ctx->r24 != ctx->r1) {
        // 0x802A4C74: nop
    
            goto L_802A4C7C;
    }
    // 0x802A4C74: nop

    // 0x802A4C78: break       6
    do_break(2150255736);
L_802A4C7C:
    // 0x802A4C7C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802A4C80: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802A4C84: mflo        $v1
    ctx->r3 = lo;
    // 0x802A4C88: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802A4C8C: bne         $at, $zero, L_802A4C9C
    if (ctx->r1 != 0) {
        // 0x802A4C90: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802A4C9C;
    }
    // 0x802A4C90: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802A4C94: b           L_802A4C9C
    // 0x802A4C98: lui         $v0, 0x4
    ctx->r2 = S32(0X4 << 16);
        goto L_802A4C9C;
    // 0x802A4C98: lui         $v0, 0x4
    ctx->r2 = S32(0X4 << 16);
L_802A4C9C:
    // 0x802A4C9C: lw          $t9, 0x24($t3)
    ctx->r25 = MEM_W(ctx->r11, 0X24);
    // 0x802A4CA0: subu        $t6, $t9, $v0
    ctx->r14 = SUB32(ctx->r25, ctx->r2);
    // 0x802A4CA4: sw          $t6, 0x24($t3)
    MEM_W(0X24, ctx->r11) = ctx->r14;
    // 0x802A4CA8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802A4CAC:
    // 0x802A4CAC: addiu       $sp, $sp, 0x68
    ctx->r29 = ADD32(ctx->r29, 0X68);
    // 0x802A4CB0: jr          $ra
    // 0x802A4CB4: nop

    return;
    // 0x802A4CB4: nop

;}
RECOMP_FUNC void func_802A4CB8_6B6368(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4CB8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A4CBC: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A4CC0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4CC4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4CC8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4CCC: addiu       $t6, $zero, 0x15
    ctx->r14 = ADD32(0, 0X15);
    // 0x802A4CD0: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4CD4: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A4CD8: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A4CDC: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A4CE0: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A4CE4: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A4CE8: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A4CEC: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A4CF0: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A4CF4: jal         0x802B8720
    // 0x802A4CF8: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A4CF8: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    after_0:
    // 0x802A4CFC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4D00: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4D04: jr          $ra
    // 0x802A4D08: nop

    return;
    // 0x802A4D08: nop

;}
RECOMP_FUNC void func_802A4D0C_6B63BC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4D0C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4D10: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A4D14: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4D18: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4D1C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4D20: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A4D24: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4D28: addiu       $t9, $zero, 0x16
    ctx->r25 = ADD32(0, 0X16);
    // 0x802A4D2C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A4D30: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A4D34: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A4D38: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4D3C: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4D40: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A4D44: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A4D48: sh          $t2, 0x31A($t3)
    MEM_H(0X31A, ctx->r11) = ctx->r10;
    // 0x802A4D4C: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A4D50: sh          $a0, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r4;
    // 0x802A4D54: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A4D58: sh          $zero, 0x2F2($t5)
    MEM_H(0X2F2, ctx->r13) = 0;
    // 0x802A4D5C: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A4D60: sh          $zero, 0x2F4($t6)
    MEM_H(0X2F4, ctx->r14) = 0;
    // 0x802A4D64: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A4D68: jal         0x802B8918
    // 0x802A4D6C: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    func_802B8918_6C9FC8(rdram, ctx);
        goto after_0;
    // 0x802A4D6C: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    after_0:
    // 0x802A4D70: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4D74: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4D78: jr          $ra
    // 0x802A4D7C: nop

    return;
    // 0x802A4D7C: nop

;}
RECOMP_FUNC void func_802A4D80_6B6430(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4D80: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4D84: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A4D88: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4D8C: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4D90: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4D94: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A4D98: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4D9C: addiu       $t9, $zero, 0x18
    ctx->r25 = ADD32(0, 0X18);
    // 0x802A4DA0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A4DA4: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A4DA8: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A4DAC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4DB0: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4DB4: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A4DB8: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A4DBC: sh          $t2, 0x31A($t3)
    MEM_H(0X31A, ctx->r11) = ctx->r10;
    // 0x802A4DC0: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A4DC4: sh          $a0, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r4;
    // 0x802A4DC8: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A4DCC: sh          $zero, 0x2F2($t5)
    MEM_H(0X2F2, ctx->r13) = 0;
    // 0x802A4DD0: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A4DD4: sh          $zero, 0x2F4($t6)
    MEM_H(0X2F4, ctx->r14) = 0;
    // 0x802A4DD8: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A4DDC: jal         0x802B8918
    // 0x802A4DE0: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    func_802B8918_6C9FC8(rdram, ctx);
        goto after_0;
    // 0x802A4DE0: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    after_0:
    // 0x802A4DE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4DE8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4DEC: jr          $ra
    // 0x802A4DF0: nop

    return;
    // 0x802A4DF0: nop

;}
RECOMP_FUNC void func_802A4DF4_6B64A4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4DF4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4DF8: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A4DFC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4E00: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4E04: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4E08: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A4E0C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4E10: addiu       $t9, $zero, 0x17
    ctx->r25 = ADD32(0, 0X17);
    // 0x802A4E14: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A4E18: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A4E1C: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A4E20: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4E24: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4E28: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A4E2C: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A4E30: or          $t7, $a1, $zero
    ctx->r15 = ctx->r5 | 0;
    // 0x802A4E34: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x802A4E38: sh          $t3, 0x31A($t4)
    MEM_H(0X31A, ctx->r12) = ctx->r11;
    // 0x802A4E3C: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802A4E40: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802A4E44: sh          $a0, 0x2C($t5)
    MEM_H(0X2C, ctx->r13) = ctx->r4;
    // 0x802A4E48: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A4E4C: sh          $zero, 0x2F2($t6)
    MEM_H(0X2F2, ctx->r14) = 0;
    // 0x802A4E50: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A4E54: sh          $zero, 0x2F4($t7)
    MEM_H(0X2F4, ctx->r15) = 0;
    // 0x802A4E58: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A4E5C: jal         0x802B8978
    // 0x802A4E60: sb          $a1, 0x368($t8)
    MEM_B(0X368, ctx->r24) = ctx->r5;
    func_802B8978_6CA028(rdram, ctx);
        goto after_0;
    // 0x802A4E60: sb          $a1, 0x368($t8)
    MEM_B(0X368, ctx->r24) = ctx->r5;
    after_0:
    // 0x802A4E64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4E68: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4E6C: jr          $ra
    // 0x802A4E70: nop

    return;
    // 0x802A4E70: nop

;}
RECOMP_FUNC void func_802A4E74_6B6524(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4E74: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A4E78: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A4E7C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4E80: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4E84: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4E88: addiu       $t6, $zero, 0xB5
    ctx->r14 = ADD32(0, 0XB5);
    // 0x802A4E8C: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4E90: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A4E94: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A4E98: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A4E9C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A4EA0: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A4EA4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A4EA8: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A4EAC: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A4EB0: jal         0x802B8720
    // 0x802A4EB4: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A4EB4: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    after_0:
    // 0x802A4EB8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4EBC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4EC0: jr          $ra
    // 0x802A4EC4: nop

    return;
    // 0x802A4EC4: nop

;}
RECOMP_FUNC void func_802A4EC8_6B6578(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4EC8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4ECC: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A4ED0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4ED4: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4ED8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4EDC: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A4EE0: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4EE4: addiu       $t9, $zero, 0xB6
    ctx->r25 = ADD32(0, 0XB6);
    // 0x802A4EE8: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A4EEC: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A4EF0: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802A4EF4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4EF8: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4EFC: sh          $t6, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r14;
    // 0x802A4F00: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A4F04: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A4F08: sra         $t8, $t7, 24
    ctx->r24 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A4F0C: sh          $zero, 0x2F2($t2)
    MEM_H(0X2F2, ctx->r10) = 0;
    // 0x802A4F10: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A4F14: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A4F18: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A4F1C: sh          $zero, 0x2F4($t3)
    MEM_H(0X2F4, ctx->r11) = 0;
    // 0x802A4F20: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A4F24: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802A4F28: sb          $t8, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r24;
    // 0x802A4F2C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802A4F30: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A4F34: lhu         $t6, 0xA4($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0XA4);
    // 0x802A4F38: multu       $t8, $t6
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4F3C: mflo        $t7
    ctx->r15 = lo;
    // 0x802A4F40: bgez        $t7, L_802A4F50
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802A4F44: sra         $t8, $t7, 4
        ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
            goto L_802A4F50;
    }
    // 0x802A4F44: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802A4F48: addiu       $at, $t7, 0xF
    ctx->r1 = ADD32(ctx->r15, 0XF);
    // 0x802A4F4C: sra         $t8, $at, 4
    ctx->r24 = S32(SIGNED(ctx->r1) >> 4);
L_802A4F50:
    // 0x802A4F50: jal         0x802B8790
    // 0x802A4F54: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A4F54: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    after_0:
    // 0x802A4F58: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4F5C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A4F60: jr          $ra
    // 0x802A4F64: nop

    return;
    // 0x802A4F64: nop

;}
RECOMP_FUNC void func_802A4F68_6B6618(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A4F68: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A4F6C: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A4F70: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A4F74: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A4F78: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A4F7C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A4F80: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A4F84: addiu       $t9, $zero, 0xB9
    ctx->r25 = ADD32(0, 0XB9);
    // 0x802A4F88: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A4F8C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A4F90: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802A4F94: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A4F98: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A4F9C: sh          $t6, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r14;
    // 0x802A4FA0: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A4FA4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A4FA8: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A4FAC: sh          $zero, 0x2F2($t2)
    MEM_H(0X2F2, ctx->r10) = 0;
    // 0x802A4FB0: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A4FB4: sra         $t8, $t7, 24
    ctx->r24 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A4FB8: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802A4FBC: sh          $zero, 0x2F4($t3)
    MEM_H(0X2F4, ctx->r11) = 0;
    // 0x802A4FC0: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802A4FC4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A4FC8: lhu         $t5, 0xA4($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0XA4);
    // 0x802A4FCC: multu       $t8, $t5
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A4FD0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A4FD4: mflo        $t6
    ctx->r14 = lo;
    // 0x802A4FD8: bgez        $t6, L_802A4FE8
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802A4FDC: sra         $t7, $t6, 4
        ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
            goto L_802A4FE8;
    }
    // 0x802A4FDC: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802A4FE0: addiu       $at, $t6, 0xF
    ctx->r1 = ADD32(ctx->r14, 0XF);
    // 0x802A4FE4: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_802A4FE8:
    // 0x802A4FE8: sh          $t7, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = ctx->r15;
    // 0x802A4FEC: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A4FF0: jal         0x802B8790
    // 0x802A4FF4: sb          $a1, 0x368($t9)
    MEM_B(0X368, ctx->r25) = ctx->r5;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A4FF4: sb          $a1, 0x368($t9)
    MEM_B(0X368, ctx->r25) = ctx->r5;
    after_0:
    // 0x802A4FF8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A4FFC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5000: jr          $ra
    // 0x802A5004: nop

    return;
    // 0x802A5004: nop

;}
RECOMP_FUNC void func_802A5008_6B66B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5008: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A500C: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5010: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5014: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A5018: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A501C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A5020: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A5024: addiu       $t9, $zero, 0xB7
    ctx->r25 = ADD32(0, 0XB7);
    // 0x802A5028: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A502C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A5030: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802A5034: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5038: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A503C: sh          $t6, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r14;
    // 0x802A5040: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A5044: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A5048: sra         $t8, $t7, 24
    ctx->r24 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A504C: sh          $zero, 0x2F2($t2)
    MEM_H(0X2F2, ctx->r10) = 0;
    // 0x802A5050: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5054: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A5058: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A505C: sh          $zero, 0x2F4($t3)
    MEM_H(0X2F4, ctx->r11) = 0;
    // 0x802A5060: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A5064: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802A5068: sb          $t8, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r24;
    // 0x802A506C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802A5070: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5074: lhu         $t6, 0xA4($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0XA4);
    // 0x802A5078: multu       $t8, $t6
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A507C: mflo        $t7
    ctx->r15 = lo;
    // 0x802A5080: bgez        $t7, L_802A5090
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802A5084: sra         $t8, $t7, 4
        ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
            goto L_802A5090;
    }
    // 0x802A5084: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802A5088: addiu       $at, $t7, 0xF
    ctx->r1 = ADD32(ctx->r15, 0XF);
    // 0x802A508C: sra         $t8, $at, 4
    ctx->r24 = S32(SIGNED(ctx->r1) >> 4);
L_802A5090:
    // 0x802A5090: jal         0x802B8810
    // 0x802A5094: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    func_802B8810_6C9EC0(rdram, ctx);
        goto after_0;
    // 0x802A5094: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    after_0:
    // 0x802A5098: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A509C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A50A0: jr          $ra
    // 0x802A50A4: nop

    return;
    // 0x802A50A4: nop

;}
RECOMP_FUNC void func_802A50A8_6B6758(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A50A8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A50AC: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A50B0: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802A50B4: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802A50B8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802A50BC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A50C0: addiu       $t6, $zero, 0xB8
    ctx->r14 = ADD32(0, 0XB8);
    // 0x802A50C4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A50C8: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A50CC: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A50D0: addiu       $t1, $zero, 0x16
    ctx->r9 = ADD32(0, 0X16);
    // 0x802A50D4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A50D8: sh          $zero, 0x2F2($t8)
    MEM_H(0X2F2, ctx->r24) = 0;
    // 0x802A50DC: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A50E0: addiu       $a2, $sp, 0x36
    ctx->r6 = ADD32(ctx->r29, 0X36);
    // 0x802A50E4: addiu       $a3, $sp, 0x34
    ctx->r7 = ADD32(ctx->r29, 0X34);
    // 0x802A50E8: sh          $zero, 0x2F4($t9)
    MEM_H(0X2F4, ctx->r25) = 0;
    // 0x802A50EC: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A50F0: sh          $t1, 0x2FC($t2)
    MEM_H(0X2FC, ctx->r10) = ctx->r9;
    // 0x802A50F4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A50F8: lbu         $t3, 0x162($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X162);
    // 0x802A50FC: beql        $t3, $at, L_802A5114
    if (ctx->r11 == ctx->r1) {
        // 0x802A5100: lbu         $t4, 0x160($v0)
        ctx->r12 = MEM_BU(ctx->r2, 0X160);
            goto L_802A5114;
    }
    goto skip_0;
    // 0x802A5100: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
    skip_0:
    // 0x802A5104: sh          $zero, 0x34($sp)
    MEM_H(0X34, ctx->r29) = 0;
    // 0x802A5108: b           L_802A5130
    // 0x802A510C: sh          $zero, 0x36($sp)
    MEM_H(0X36, ctx->r29) = 0;
        goto L_802A5130;
    // 0x802A510C: sh          $zero, 0x36($sp)
    MEM_H(0X36, ctx->r29) = 0;
    // 0x802A5110: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
L_802A5114:
    // 0x802A5114: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802A5118: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802A511C: jal         0x80311A2C
    // 0x802A5120: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_0;
    // 0x802A5120: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_0:
    // 0x802A5124: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A5128: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A512C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5130:
    // 0x802A5130: lh          $t5, 0x36($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X36);
    // 0x802A5134: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A5138: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x802A513C: slti        $at, $t5, -0x17
    ctx->r1 = SIGNED(ctx->r13) < -0X17 ? 1 : 0;
    // 0x802A5140: beql        $at, $zero, L_802A5180
    if (ctx->r1 == 0) {
        // 0x802A5144: lh          $t8, 0x36($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X36);
            goto L_802A5180;
    }
    goto skip_1;
    // 0x802A5144: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    skip_1:
    // 0x802A5148: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x802A514C: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A5150: lhu         $a0, 0xA6($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA6);
    // 0x802A5154: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A5158: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A515C: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A5160: beq         $at, $zero, L_802A5174
    if (ctx->r1 == 0) {
        // 0x802A5164: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A5174;
    }
    // 0x802A5164: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A5168: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A516C: b           L_802A517C
    // 0x802A5170: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A517C;
    // 0x802A5170: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5174:
    // 0x802A5174: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    // 0x802A5178: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A517C:
    // 0x802A517C: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
L_802A5180:
    // 0x802A5180: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A5184: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x802A5188: slti        $at, $t8, 0x18
    ctx->r1 = SIGNED(ctx->r24) < 0X18 ? 1 : 0;
    // 0x802A518C: bnel        $at, $zero, L_802A51C8
    if (ctx->r1 != 0) {
        // 0x802A5190: lh          $t2, 0x34($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X34);
            goto L_802A51C8;
    }
    goto skip_2;
    // 0x802A5190: lh          $t2, 0x34($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X34);
    skip_2:
    // 0x802A5194: lw          $t9, 0x0($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X0);
    // 0x802A5198: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A519C: lhu         $a0, 0xA6($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0XA6);
    // 0x802A51A0: sll         $t1, $a0, 15
    ctx->r9 = S32(ctx->r4 << 15);
    // 0x802A51A4: slt         $at, $t1, $v1
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A51A8: beq         $at, $zero, L_802A51BC
    if (ctx->r1 == 0) {
        // 0x802A51AC: or          $a0, $t1, $zero
        ctx->r4 = ctx->r9 | 0;
            goto L_802A51BC;
    }
    // 0x802A51AC: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    // 0x802A51B0: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A51B4: b           L_802A51C4
    // 0x802A51B8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A51C4;
    // 0x802A51B8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A51BC:
    // 0x802A51BC: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    // 0x802A51C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A51C4:
    // 0x802A51C4: lh          $t2, 0x34($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X34);
L_802A51C8:
    // 0x802A51C8: slti        $at, $t2, -0x17
    ctx->r1 = SIGNED(ctx->r10) < -0X17 ? 1 : 0;
    // 0x802A51CC: beql        $at, $zero, L_802A520C
    if (ctx->r1 == 0) {
        // 0x802A51D0: lh          $t5, 0x34($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X34);
            goto L_802A520C;
    }
    goto skip_3;
    // 0x802A51D0: lh          $t5, 0x34($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X34);
    skip_3:
    // 0x802A51D4: lw          $t3, 0x0($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X0);
    // 0x802A51D8: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A51DC: lhu         $a0, 0xA6($t3)
    ctx->r4 = MEM_HU(ctx->r11, 0XA6);
    // 0x802A51E0: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A51E4: sll         $t4, $a0, 15
    ctx->r12 = S32(ctx->r4 << 15);
    // 0x802A51E8: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802A51EC: beq         $at, $zero, L_802A5200
    if (ctx->r1 == 0) {
        // 0x802A51F0: or          $a0, $t4, $zero
        ctx->r4 = ctx->r12 | 0;
            goto L_802A5200;
    }
    // 0x802A51F0: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x802A51F4: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A51F8: b           L_802A5208
    // 0x802A51FC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A5208;
    // 0x802A51FC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5200:
    // 0x802A5200: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    // 0x802A5204: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5208:
    // 0x802A5208: lh          $t5, 0x34($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X34);
L_802A520C:
    // 0x802A520C: slti        $at, $t5, 0x18
    ctx->r1 = SIGNED(ctx->r13) < 0X18 ? 1 : 0;
    // 0x802A5210: bnel        $at, $zero, L_802A524C
    if (ctx->r1 != 0) {
        // 0x802A5214: lh          $t8, 0x36($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X36);
            goto L_802A524C;
    }
    goto skip_4;
    // 0x802A5214: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    skip_4:
    // 0x802A5218: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x802A521C: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A5220: lhu         $a0, 0xA6($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA6);
    // 0x802A5224: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A5228: slt         $at, $t7, $v1
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A522C: beq         $at, $zero, L_802A5240
    if (ctx->r1 == 0) {
        // 0x802A5230: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A5240;
    }
    // 0x802A5230: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A5234: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A5238: b           L_802A5248
    // 0x802A523C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A5248;
    // 0x802A523C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5240:
    // 0x802A5240: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    // 0x802A5244: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5248:
    // 0x802A5248: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
L_802A524C:
    // 0x802A524C: lh          $v1, 0x36($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X36);
    // 0x802A5250: lh          $t9, 0x34($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X34);
    // 0x802A5254: bgez        $t8, L_802A5264
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802A5258: nop
    
            goto L_802A5264;
    }
    // 0x802A5258: nop

    // 0x802A525C: b           L_802A5264
    // 0x802A5260: negu        $v1, $t8
    ctx->r3 = SUB32(0, ctx->r24);
        goto L_802A5264;
    // 0x802A5260: negu        $v1, $t8
    ctx->r3 = SUB32(0, ctx->r24);
L_802A5264:
    // 0x802A5264: slti        $at, $v1, 0x18
    ctx->r1 = SIGNED(ctx->r3) < 0X18 ? 1 : 0;
    // 0x802A5268: beql        $at, $zero, L_802A5290
    if (ctx->r1 == 0) {
        // 0x802A526C: lw          $t2, 0x0($a1)
        ctx->r10 = MEM_W(ctx->r5, 0X0);
            goto L_802A5290;
    }
    goto skip_5;
    // 0x802A526C: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
    skip_5:
    // 0x802A5270: bgez        $t9, L_802A5280
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802A5274: lh          $v1, 0x34($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X34);
            goto L_802A5280;
    }
    // 0x802A5274: lh          $v1, 0x34($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X34);
    // 0x802A5278: b           L_802A5280
    // 0x802A527C: negu        $v1, $t9
    ctx->r3 = SUB32(0, ctx->r25);
        goto L_802A5280;
    // 0x802A527C: negu        $v1, $t9
    ctx->r3 = SUB32(0, ctx->r25);
L_802A5280:
    // 0x802A5280: slti        $at, $v1, 0x18
    ctx->r1 = SIGNED(ctx->r3) < 0X18 ? 1 : 0;
    // 0x802A5284: bnel        $at, $zero, L_802A52AC
    if (ctx->r1 != 0) {
        // 0x802A5288: lw          $t7, 0x0($a1)
        ctx->r15 = MEM_W(ctx->r5, 0X0);
            goto L_802A52AC;
    }
    goto skip_6;
    // 0x802A5288: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    skip_6:
    // 0x802A528C: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
L_802A5290:
    // 0x802A5290: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802A5294: lhu         $t3, 0xA6($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XA6);
    // 0x802A5298: sll         $t4, $t3, 12
    ctx->r12 = S32(ctx->r11 << 12);
    // 0x802A529C: addu        $t5, $t1, $t4
    ctx->r13 = ADD32(ctx->r9, ctx->r12);
    // 0x802A52A0: b           L_802A52E8
    // 0x802A52A4: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
        goto L_802A52E8;
    // 0x802A52A4: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
    // 0x802A52A8: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
L_802A52AC:
    // 0x802A52AC: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802A52B0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A52B4: lhu         $t8, 0xA6($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XA6);
    // 0x802A52B8: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802A52BC: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802A52C0: addu        $t2, $t6, $t9
    ctx->r10 = ADD32(ctx->r14, ctx->r25);
    // 0x802A52C4: sw          $t2, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r10;
    // 0x802A52C8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A52CC: lbu         $t3, 0x162($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X162);
    // 0x802A52D0: beq         $t3, $at, L_802A52E8
    if (ctx->r11 == ctx->r1) {
        // 0x802A52D4: nop
    
            goto L_802A52E8;
    }
    // 0x802A52D4: nop

    // 0x802A52D8: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802A52DC: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802A52E0: addu        $t5, $t1, $t4
    ctx->r13 = ADD32(ctx->r9, ctx->r12);
    // 0x802A52E4: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
L_802A52E8:
    // 0x802A52E8: jal         0x802B8890
    // 0x802A52EC: nop

    func_802B8890_6C9F40(rdram, ctx);
        goto after_1;
    // 0x802A52EC: nop

    after_1:
    // 0x802A52F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802A52F4: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802A52F8: jr          $ra
    // 0x802A52FC: nop

    return;
    // 0x802A52FC: nop

;}
RECOMP_FUNC void func_802A5300_6B69B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5300: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A5304: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A5308: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802A530C: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802A5310: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802A5314: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5318: addiu       $t6, $zero, 0xB8
    ctx->r14 = ADD32(0, 0XB8);
    // 0x802A531C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A5320: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5324: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A5328: addiu       $t1, $zero, 0x20
    ctx->r9 = ADD32(0, 0X20);
    // 0x802A532C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A5330: sh          $zero, 0x2F2($t8)
    MEM_H(0X2F2, ctx->r24) = 0;
    // 0x802A5334: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5338: addiu       $a2, $sp, 0x36
    ctx->r6 = ADD32(ctx->r29, 0X36);
    // 0x802A533C: addiu       $a3, $sp, 0x34
    ctx->r7 = ADD32(ctx->r29, 0X34);
    // 0x802A5340: sh          $zero, 0x2F4($t9)
    MEM_H(0X2F4, ctx->r25) = 0;
    // 0x802A5344: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A5348: sh          $t1, 0x2FC($t2)
    MEM_H(0X2FC, ctx->r10) = ctx->r9;
    // 0x802A534C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5350: lbu         $t3, 0x162($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X162);
    // 0x802A5354: beql        $t3, $at, L_802A536C
    if (ctx->r11 == ctx->r1) {
        // 0x802A5358: lbu         $t4, 0x160($v0)
        ctx->r12 = MEM_BU(ctx->r2, 0X160);
            goto L_802A536C;
    }
    goto skip_0;
    // 0x802A5358: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
    skip_0:
    // 0x802A535C: sh          $zero, 0x34($sp)
    MEM_H(0X34, ctx->r29) = 0;
    // 0x802A5360: b           L_802A5388
    // 0x802A5364: sh          $zero, 0x36($sp)
    MEM_H(0X36, ctx->r29) = 0;
        goto L_802A5388;
    // 0x802A5364: sh          $zero, 0x36($sp)
    MEM_H(0X36, ctx->r29) = 0;
    // 0x802A5368: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
L_802A536C:
    // 0x802A536C: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802A5370: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802A5374: jal         0x80311A2C
    // 0x802A5378: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_0;
    // 0x802A5378: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_0:
    // 0x802A537C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A5380: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A5384: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5388:
    // 0x802A5388: lh          $t5, 0x36($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X36);
    // 0x802A538C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A5390: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x802A5394: slti        $at, $t5, -0x17
    ctx->r1 = SIGNED(ctx->r13) < -0X17 ? 1 : 0;
    // 0x802A5398: beql        $at, $zero, L_802A53D8
    if (ctx->r1 == 0) {
        // 0x802A539C: lh          $t8, 0x36($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X36);
            goto L_802A53D8;
    }
    goto skip_1;
    // 0x802A539C: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    skip_1:
    // 0x802A53A0: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x802A53A4: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A53A8: lhu         $a0, 0xA8($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA8);
    // 0x802A53AC: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A53B0: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A53B4: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A53B8: beq         $at, $zero, L_802A53CC
    if (ctx->r1 == 0) {
        // 0x802A53BC: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A53CC;
    }
    // 0x802A53BC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A53C0: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A53C4: b           L_802A53D4
    // 0x802A53C8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A53D4;
    // 0x802A53C8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A53CC:
    // 0x802A53CC: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    // 0x802A53D0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A53D4:
    // 0x802A53D4: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
L_802A53D8:
    // 0x802A53D8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A53DC: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x802A53E0: slti        $at, $t8, 0x18
    ctx->r1 = SIGNED(ctx->r24) < 0X18 ? 1 : 0;
    // 0x802A53E4: bnel        $at, $zero, L_802A5420
    if (ctx->r1 != 0) {
        // 0x802A53E8: lh          $t2, 0x34($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X34);
            goto L_802A5420;
    }
    goto skip_2;
    // 0x802A53E8: lh          $t2, 0x34($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X34);
    skip_2:
    // 0x802A53EC: lw          $t9, 0x0($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X0);
    // 0x802A53F0: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A53F4: lhu         $a0, 0xA8($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0XA8);
    // 0x802A53F8: sll         $t1, $a0, 15
    ctx->r9 = S32(ctx->r4 << 15);
    // 0x802A53FC: slt         $at, $t1, $v1
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A5400: beq         $at, $zero, L_802A5414
    if (ctx->r1 == 0) {
        // 0x802A5404: or          $a0, $t1, $zero
        ctx->r4 = ctx->r9 | 0;
            goto L_802A5414;
    }
    // 0x802A5404: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    // 0x802A5408: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A540C: b           L_802A541C
    // 0x802A5410: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A541C;
    // 0x802A5410: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5414:
    // 0x802A5414: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    // 0x802A5418: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A541C:
    // 0x802A541C: lh          $t2, 0x34($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X34);
L_802A5420:
    // 0x802A5420: slti        $at, $t2, -0x17
    ctx->r1 = SIGNED(ctx->r10) < -0X17 ? 1 : 0;
    // 0x802A5424: beql        $at, $zero, L_802A5464
    if (ctx->r1 == 0) {
        // 0x802A5428: lh          $t5, 0x34($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X34);
            goto L_802A5464;
    }
    goto skip_3;
    // 0x802A5428: lh          $t5, 0x34($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X34);
    skip_3:
    // 0x802A542C: lw          $t3, 0x0($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X0);
    // 0x802A5430: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A5434: lhu         $a0, 0xA8($t3)
    ctx->r4 = MEM_HU(ctx->r11, 0XA8);
    // 0x802A5438: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
    // 0x802A543C: sll         $t4, $a0, 15
    ctx->r12 = S32(ctx->r4 << 15);
    // 0x802A5440: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802A5444: beq         $at, $zero, L_802A5458
    if (ctx->r1 == 0) {
        // 0x802A5448: or          $a0, $t4, $zero
        ctx->r4 = ctx->r12 | 0;
            goto L_802A5458;
    }
    // 0x802A5448: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x802A544C: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A5450: b           L_802A5460
    // 0x802A5454: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A5460;
    // 0x802A5454: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5458:
    // 0x802A5458: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    // 0x802A545C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5460:
    // 0x802A5460: lh          $t5, 0x34($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X34);
L_802A5464:
    // 0x802A5464: slti        $at, $t5, 0x18
    ctx->r1 = SIGNED(ctx->r13) < 0X18 ? 1 : 0;
    // 0x802A5468: bnel        $at, $zero, L_802A54A4
    if (ctx->r1 != 0) {
        // 0x802A546C: lh          $t8, 0x36($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X36);
            goto L_802A54A4;
    }
    goto skip_4;
    // 0x802A546C: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    skip_4:
    // 0x802A5470: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x802A5474: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A5478: lhu         $a0, 0xA8($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA8);
    // 0x802A547C: sll         $t7, $a0, 15
    ctx->r15 = S32(ctx->r4 << 15);
    // 0x802A5480: slt         $at, $t7, $v1
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A5484: beq         $at, $zero, L_802A5498
    if (ctx->r1 == 0) {
        // 0x802A5488: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802A5498;
    }
    // 0x802A5488: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A548C: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A5490: b           L_802A54A0
    // 0x802A5494: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_802A54A0;
    // 0x802A5494: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5498:
    // 0x802A5498: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    // 0x802A549C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A54A0:
    // 0x802A54A0: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
L_802A54A4:
    // 0x802A54A4: lh          $v1, 0x36($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X36);
    // 0x802A54A8: lh          $t9, 0x34($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X34);
    // 0x802A54AC: bgez        $t8, L_802A54BC
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802A54B0: nop
    
            goto L_802A54BC;
    }
    // 0x802A54B0: nop

    // 0x802A54B4: b           L_802A54BC
    // 0x802A54B8: negu        $v1, $t8
    ctx->r3 = SUB32(0, ctx->r24);
        goto L_802A54BC;
    // 0x802A54B8: negu        $v1, $t8
    ctx->r3 = SUB32(0, ctx->r24);
L_802A54BC:
    // 0x802A54BC: slti        $at, $v1, 0x18
    ctx->r1 = SIGNED(ctx->r3) < 0X18 ? 1 : 0;
    // 0x802A54C0: beql        $at, $zero, L_802A54E8
    if (ctx->r1 == 0) {
        // 0x802A54C4: lw          $t2, 0x0($a1)
        ctx->r10 = MEM_W(ctx->r5, 0X0);
            goto L_802A54E8;
    }
    goto skip_5;
    // 0x802A54C4: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
    skip_5:
    // 0x802A54C8: bgez        $t9, L_802A54D8
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802A54CC: lh          $v1, 0x34($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X34);
            goto L_802A54D8;
    }
    // 0x802A54CC: lh          $v1, 0x34($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X34);
    // 0x802A54D0: b           L_802A54D8
    // 0x802A54D4: negu        $v1, $t9
    ctx->r3 = SUB32(0, ctx->r25);
        goto L_802A54D8;
    // 0x802A54D4: negu        $v1, $t9
    ctx->r3 = SUB32(0, ctx->r25);
L_802A54D8:
    // 0x802A54D8: slti        $at, $v1, 0x18
    ctx->r1 = SIGNED(ctx->r3) < 0X18 ? 1 : 0;
    // 0x802A54DC: bnel        $at, $zero, L_802A5504
    if (ctx->r1 != 0) {
        // 0x802A54E0: lw          $t7, 0x0($a1)
        ctx->r15 = MEM_W(ctx->r5, 0X0);
            goto L_802A5504;
    }
    goto skip_6;
    // 0x802A54E0: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    skip_6:
    // 0x802A54E4: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
L_802A54E8:
    // 0x802A54E8: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802A54EC: lhu         $t3, 0xA8($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XA8);
    // 0x802A54F0: sll         $t4, $t3, 12
    ctx->r12 = S32(ctx->r11 << 12);
    // 0x802A54F4: addu        $t5, $t1, $t4
    ctx->r13 = ADD32(ctx->r9, ctx->r12);
    // 0x802A54F8: b           L_802A5540
    // 0x802A54FC: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
        goto L_802A5540;
    // 0x802A54FC: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
    // 0x802A5500: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
L_802A5504:
    // 0x802A5504: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802A5508: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A550C: lhu         $t8, 0xA8($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XA8);
    // 0x802A5510: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802A5514: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802A5518: addu        $t2, $t6, $t9
    ctx->r10 = ADD32(ctx->r14, ctx->r25);
    // 0x802A551C: sw          $t2, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r10;
    // 0x802A5520: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5524: lbu         $t3, 0x162($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X162);
    // 0x802A5528: beq         $t3, $at, L_802A5540
    if (ctx->r11 == ctx->r1) {
        // 0x802A552C: nop
    
            goto L_802A5540;
    }
    // 0x802A552C: nop

    // 0x802A5530: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802A5534: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802A5538: addu        $t5, $t1, $t4
    ctx->r13 = ADD32(ctx->r9, ctx->r12);
    // 0x802A553C: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
L_802A5540:
    // 0x802A5540: jal         0x802B8890
    // 0x802A5544: nop

    func_802B8890_6C9F40(rdram, ctx);
        goto after_1;
    // 0x802A5544: nop

    after_1:
    // 0x802A5548: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802A554C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802A5550: jr          $ra
    // 0x802A5554: nop

    return;
    // 0x802A5554: nop

;}
RECOMP_FUNC void func_802A5558_6B6C08(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5558: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A555C: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A5560: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5564: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5568: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A556C: addiu       $t6, $zero, 0xC9
    ctx->r14 = ADD32(0, 0XC9);
    // 0x802A5570: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5574: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5578: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A557C: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A5580: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5584: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A5588: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A558C: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A5590: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A5594: jal         0x802B8720
    // 0x802A5598: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A5598: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    after_0:
    // 0x802A559C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A55A0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A55A4: jr          $ra
    // 0x802A55A8: nop

    return;
    // 0x802A55A8: nop

;}
RECOMP_FUNC void func_802A55AC_6B6C5C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A55AC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A55B0: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A55B4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A55B8: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A55BC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A55C0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A55C4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A55C8: addiu       $t9, $zero, 0xCA
    ctx->r25 = ADD32(0, 0XCA);
    // 0x802A55CC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A55D0: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A55D4: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A55D8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A55DC: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A55E0: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A55E4: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A55E8: sh          $t2, 0x31A($t3)
    MEM_H(0X31A, ctx->r11) = ctx->r10;
    // 0x802A55EC: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A55F0: sh          $a0, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r4;
    // 0x802A55F4: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A55F8: sh          $zero, 0x2F2($t5)
    MEM_H(0X2F2, ctx->r13) = 0;
    // 0x802A55FC: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A5600: sh          $zero, 0x2F4($t6)
    MEM_H(0X2F4, ctx->r14) = 0;
    // 0x802A5604: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A5608: jal         0x802B8918
    // 0x802A560C: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    func_802B8918_6C9FC8(rdram, ctx);
        goto after_0;
    // 0x802A560C: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    after_0:
    // 0x802A5610: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5614: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5618: jr          $ra
    // 0x802A561C: nop

    return;
    // 0x802A561C: nop

;}
RECOMP_FUNC void func_802A5620_6B6CD0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5620: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5624: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5628: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A562C: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A5630: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5634: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A5638: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A563C: addiu       $t9, $zero, 0xCC
    ctx->r25 = ADD32(0, 0XCC);
    // 0x802A5640: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A5644: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A5648: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A564C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5650: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5654: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5658: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A565C: sh          $t2, 0x31A($t3)
    MEM_H(0X31A, ctx->r11) = ctx->r10;
    // 0x802A5660: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A5664: sh          $a0, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r4;
    // 0x802A5668: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A566C: sh          $zero, 0x2F2($t5)
    MEM_H(0X2F2, ctx->r13) = 0;
    // 0x802A5670: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A5674: sh          $zero, 0x2F4($t6)
    MEM_H(0X2F4, ctx->r14) = 0;
    // 0x802A5678: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A567C: jal         0x802B8918
    // 0x802A5680: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    func_802B8918_6C9FC8(rdram, ctx);
        goto after_0;
    // 0x802A5680: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    after_0:
    // 0x802A5684: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5688: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A568C: jr          $ra
    // 0x802A5690: nop

    return;
    // 0x802A5690: nop

;}
RECOMP_FUNC void func_802A5694_6B6D44(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5694: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5698: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A569C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A56A0: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A56A4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A56A8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A56AC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A56B0: addiu       $t9, $zero, 0xCB
    ctx->r25 = ADD32(0, 0XCB);
    // 0x802A56B4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A56B8: sh          $t9, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r25;
    // 0x802A56BC: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A56C0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A56C4: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A56C8: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A56CC: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802A56D0: sh          $t2, 0x31A($t3)
    MEM_H(0X31A, ctx->r11) = ctx->r10;
    // 0x802A56D4: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A56D8: sh          $a0, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r4;
    // 0x802A56DC: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A56E0: sh          $zero, 0x2F2($t5)
    MEM_H(0X2F2, ctx->r13) = 0;
    // 0x802A56E4: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A56E8: sh          $zero, 0x2F4($t6)
    MEM_H(0X2F4, ctx->r14) = 0;
    // 0x802A56EC: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A56F0: jal         0x802B8978
    // 0x802A56F4: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    func_802B8978_6CA028(rdram, ctx);
        goto after_0;
    // 0x802A56F4: sb          $a1, 0x368($t7)
    MEM_B(0X368, ctx->r15) = ctx->r5;
    after_0:
    // 0x802A56F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A56FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5700: jr          $ra
    // 0x802A5704: nop

    return;
    // 0x802A5704: nop

;}
RECOMP_FUNC void func_802A5708_6B6DB8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5708: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A570C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5710: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A5714: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5718: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A571C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A5720: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A5724: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x802A5728: andi        $t2, $a0, 0xFF
    ctx->r10 = ctx->r4 & 0XFF;
    // 0x802A572C: sh          $t2, 0x2C($t3)
    MEM_H(0X2C, ctx->r11) = ctx->r10;
    // 0x802A5730: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A5734: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5738: addiu       $t5, $zero, 0x51
    ctx->r13 = ADD32(0, 0X51);
    // 0x802A573C: sh          $a1, 0x28($t4)
    MEM_H(0X28, ctx->r12) = ctx->r5;
    // 0x802A5740: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A5744: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A5748: sh          $t5, 0x0($t6)
    MEM_H(0X0, ctx->r14) = ctx->r13;
    // 0x802A574C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802A5750: sh          $zero, 0x2F2($t7)
    MEM_H(0X2F2, ctx->r15) = 0;
    // 0x802A5754: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A5758: sh          $zero, 0x2F4($t8)
    MEM_H(0X2F4, ctx->r24) = 0;
    // 0x802A575C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5760: jal         0x802B8A48
    // 0x802A5764: sb          $a2, 0x368($t9)
    MEM_B(0X368, ctx->r25) = ctx->r6;
    func_802B8A48_6CA0F8(rdram, ctx);
        goto after_0;
    // 0x802A5764: sb          $a2, 0x368($t9)
    MEM_B(0X368, ctx->r25) = ctx->r6;
    after_0:
    // 0x802A5768: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A576C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5770: jr          $ra
    // 0x802A5774: nop

    return;
    // 0x802A5774: nop

;}
RECOMP_FUNC void func_802A5778_6B6E28(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5778: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A577C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A5780: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802A5784: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802A5788: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802A578C: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x802A5790: sw          $a1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r5;
    // 0x802A5794: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A5798: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802A579C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A57A0: sb          $t6, 0x36D($t7)
    MEM_B(0X36D, ctx->r15) = ctx->r14;
    // 0x802A57A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A57A8: lbu         $t9, 0x4F($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X4F);
    // 0x802A57AC: lw          $t8, 0x6C($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X6C);
    // 0x802A57B0: bnel        $t8, $zero, L_802A57C4
    if (ctx->r24 != 0) {
        // 0x802A57B4: sh          $zero, 0x40($sp)
        MEM_H(0X40, ctx->r29) = 0;
            goto L_802A57C4;
    }
    goto skip_0;
    // 0x802A57B4: sh          $zero, 0x40($sp)
    MEM_H(0X40, ctx->r29) = 0;
    skip_0:
    // 0x802A57B8: beq         $t9, $zero, L_802A57CC
    if (ctx->r25 == 0) {
        // 0x802A57BC: addiu       $a2, $sp, 0x42
        ctx->r6 = ADD32(ctx->r29, 0X42);
            goto L_802A57CC;
    }
    // 0x802A57BC: addiu       $a2, $sp, 0x42
    ctx->r6 = ADD32(ctx->r29, 0X42);
    // 0x802A57C0: sh          $zero, 0x40($sp)
    MEM_H(0X40, ctx->r29) = 0;
L_802A57C4:
    // 0x802A57C4: b           L_802A57F8
    // 0x802A57C8: sh          $zero, 0x42($sp)
    MEM_H(0X42, ctx->r29) = 0;
        goto L_802A57F8;
    // 0x802A57C8: sh          $zero, 0x42($sp)
    MEM_H(0X42, ctx->r29) = 0;
L_802A57CC:
    // 0x802A57CC: lbu         $t3, 0x160($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X160);
    // 0x802A57D0: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802A57D4: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802A57D8: addiu       $a3, $sp, 0x40
    ctx->r7 = ADD32(ctx->r29, 0X40);
    // 0x802A57DC: jal         0x80311A2C
    // 0x802A57E0: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_0;
    // 0x802A57E0: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    after_0:
    // 0x802A57E4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A57E8: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A57EC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A57F0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A57F4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A57F8:
    // 0x802A57F8: lbu         $t4, 0x4F($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X4F);
    // 0x802A57FC: bnel        $t4, $zero, L_802A58D0
    if (ctx->r12 != 0) {
        // 0x802A5800: addiu       $t7, $zero, 0x2A
        ctx->r15 = ADD32(0, 0X2A);
            goto L_802A58D0;
    }
    goto skip_1;
    // 0x802A5800: addiu       $t7, $zero, 0x2A
    ctx->r15 = ADD32(0, 0X2A);
    skip_1:
    // 0x802A5804: lw          $t5, 0x6C($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X6C);
    // 0x802A5808: lh          $t6, 0x42($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X42);
    // 0x802A580C: bnel        $t5, $zero, L_802A58D0
    if (ctx->r13 != 0) {
        // 0x802A5810: addiu       $t7, $zero, 0x2A
        ctx->r15 = ADD32(0, 0X2A);
            goto L_802A58D0;
    }
    goto skip_2;
    // 0x802A5810: addiu       $t7, $zero, 0x2A
    ctx->r15 = ADD32(0, 0X2A);
    skip_2:
    // 0x802A5814: bne         $t6, $zero, L_802A5824
    if (ctx->r14 != 0) {
        // 0x802A5818: lh          $t7, 0x40($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X40);
            goto L_802A5824;
    }
    // 0x802A5818: lh          $t7, 0x40($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X40);
    // 0x802A581C: beql        $t7, $zero, L_802A58D0
    if (ctx->r15 == 0) {
        // 0x802A5820: addiu       $t7, $zero, 0x2A
        ctx->r15 = ADD32(0, 0X2A);
            goto L_802A58D0;
    }
    goto skip_3;
    // 0x802A5820: addiu       $t7, $zero, 0x2A
    ctx->r15 = ADD32(0, 0X2A);
    skip_3:
L_802A5824:
    // 0x802A5824: lbu         $t8, 0x160($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X160);
    // 0x802A5828: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A582C: bnel        $t8, $at, L_802A5884
    if (ctx->r24 != ctx->r1) {
        // 0x802A5830: lh          $t5, 0x4($v0)
        ctx->r13 = MEM_H(ctx->r2, 0X4);
            goto L_802A5884;
    }
    goto skip_4;
    // 0x802A5830: lh          $t5, 0x4($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X4);
    skip_4:
    // 0x802A5834: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    // 0x802A5838: lh          $t5, 0x8($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X8);
    // 0x802A583C: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A5840: sra         $t3, $t9, 6
    ctx->r11 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802A5844: sll         $t4, $t3, 7
    ctx->r12 = S32(ctx->r11 << 7);
    // 0x802A5848: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x802A584C: sra         $t6, $t5, 6
    ctx->r14 = S32(SIGNED(ctx->r13) >> 6);
    // 0x802A5850: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802A5854: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x802A5858: addu        $t8, $t4, $t7
    ctx->r24 = ADD32(ctx->r12, ctx->r15);
    // 0x802A585C: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x802A5860: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802A5864: lbu         $t9, 0x743($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X743);
    // 0x802A5868: sll         $t3, $t9, 2
    ctx->r11 = S32(ctx->r25 << 2);
    // 0x802A586C: subu        $t3, $t3, $t9
    ctx->r11 = SUB32(ctx->r11, ctx->r25);
    // 0x802A5870: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802A5874: addu        $v1, $v1, $t3
    ctx->r3 = ADD32(ctx->r3, ctx->r11);
    // 0x802A5878: b           L_802A58C8
    // 0x802A587C: lbu         $v1, 0x1D30($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D30);
        goto L_802A58C8;
    // 0x802A587C: lbu         $v1, 0x1D30($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D30);
    // 0x802A5880: lh          $t5, 0x4($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X4);
L_802A5884:
    // 0x802A5884: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x802A5888: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A588C: sra         $t6, $t5, 6
    ctx->r14 = S32(SIGNED(ctx->r13) >> 6);
    // 0x802A5890: sll         $t4, $t6, 7
    ctx->r12 = S32(ctx->r14 << 7);
    // 0x802A5894: addu        $t4, $t4, $t6
    ctx->r12 = ADD32(ctx->r12, ctx->r14);
    // 0x802A5898: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802A589C: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802A58A0: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x802A58A4: addu        $t3, $t4, $t9
    ctx->r11 = ADD32(ctx->r12, ctx->r25);
    // 0x802A58A8: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x802A58AC: addu        $t5, $t5, $t3
    ctx->r13 = ADD32(ctx->r13, ctx->r11);
    // 0x802A58B0: lbu         $t5, 0x742($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X742);
    // 0x802A58B4: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x802A58B8: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x802A58BC: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802A58C0: addu        $v1, $v1, $t6
    ctx->r3 = ADD32(ctx->r3, ctx->r14);
    // 0x802A58C4: lbu         $v1, 0x1D30($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D30);
L_802A58C8:
    // 0x802A58C8: beq         $v1, $zero, L_802A5C70
    if (ctx->r3 == 0) {
        // 0x802A58CC: addiu       $t7, $zero, 0x2A
        ctx->r15 = ADD32(0, 0X2A);
            goto L_802A5C70;
    }
    // 0x802A58CC: addiu       $t7, $zero, 0x2A
    ctx->r15 = ADD32(0, 0X2A);
L_802A58D0:
    // 0x802A58D0: sh          $t7, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r15;
    // 0x802A58D4: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x802A58D8: addiu       $t9, $zero, 0x16
    ctx->r25 = ADD32(0, 0X16);
    // 0x802A58DC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A58E0: sh          $zero, 0x2F2($t8)
    MEM_H(0X2F2, ctx->r24) = 0;
    // 0x802A58E4: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802A58E8: addiu       $t2, $t2, 0x5524
    ctx->r10 = ADD32(ctx->r10, 0X5524);
    // 0x802A58EC: sh          $zero, 0x2F4($t4)
    MEM_H(0X2F4, ctx->r12) = 0;
    // 0x802A58F0: lw          $t3, 0x0($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X0);
    // 0x802A58F4: sh          $t9, 0x2FC($t3)
    MEM_H(0X2FC, ctx->r11) = ctx->r25;
    // 0x802A58F8: lbu         $t5, 0x4F($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X4F);
    // 0x802A58FC: beql        $t5, $zero, L_802A592C
    if (ctx->r13 == 0) {
        // 0x802A5900: lh          $t3, 0x4A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X4A);
            goto L_802A592C;
    }
    goto skip_5;
    // 0x802A5900: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    skip_5:
    // 0x802A5904: lw          $t8, 0x0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0X0);
    // 0x802A5908: lh          $t6, 0x4A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X4A);
    // 0x802A590C: lhu         $t4, 0xA6($t8)
    ctx->r12 = MEM_HU(ctx->r24, 0XA6);
    // 0x802A5910: addiu       $t7, $t6, 0x6
    ctx->r15 = ADD32(ctx->r14, 0X6);
    // 0x802A5914: sll         $t9, $t4, 13
    ctx->r25 = S32(ctx->r12 << 13);
    // 0x802A5918: multu       $t7, $t9
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A591C: mflo        $a1
    ctx->r5 = lo;
    // 0x802A5920: b           L_802A59FC
    // 0x802A5924: lh          $t5, 0x42($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X42);
        goto L_802A59FC;
    // 0x802A5924: lh          $t5, 0x42($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X42);
    // 0x802A5928: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
L_802A592C:
    // 0x802A592C: bne         $t3, $zero, L_802A5948
    if (ctx->r11 != 0) {
        // 0x802A5930: lui         $t2, 0x803D
        ctx->r10 = S32(0X803D << 16);
            goto L_802A5948;
    }
    // 0x802A5930: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A5934: addiu       $t2, $t2, 0x5524
    ctx->r10 = ADD32(ctx->r10, 0X5524);
    // 0x802A5938: lw          $t5, 0x0($t2)
    ctx->r13 = MEM_W(ctx->r10, 0X0);
    // 0x802A593C: lhu         $t6, 0xA6($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0XA6);
    // 0x802A5940: b           L_802A59F8
    // 0x802A5944: sll         $a1, $t6, 16
    ctx->r5 = S32(ctx->r14 << 16);
        goto L_802A59F8;
    // 0x802A5944: sll         $a1, $t6, 16
    ctx->r5 = S32(ctx->r14 << 16);
L_802A5948:
    // 0x802A5948: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A594C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A5950: addiu       $t2, $t2, 0x5524
    ctx->r10 = ADD32(ctx->r10, 0X5524);
    // 0x802A5954: lh          $t3, 0x2C($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2C);
    // 0x802A5958: lw          $t4, 0x0($t2)
    ctx->r12 = MEM_W(ctx->r10, 0X0);
    // 0x802A595C: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802A5960: andi        $t5, $t3, 0xFF
    ctx->r13 = ctx->r11 & 0XFF;
    // 0x802A5964: lhu         $t7, 0xA4($t4)
    ctx->r15 = MEM_HU(ctx->r12, 0XA4);
    // 0x802A5968: addiu       $v1, $v1, 0x2C78
    ctx->r3 = ADD32(ctx->r3, 0X2C78);
    // 0x802A596C: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802A5970: addu        $t8, $v1, $t6
    ctx->r24 = ADD32(ctx->r3, ctx->r14);
    // 0x802A5974: lh          $t4, 0x0($t8)
    ctx->r12 = MEM_H(ctx->r24, 0X0);
    // 0x802A5978: sra         $t9, $t7, 6
    ctx->r25 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802A597C: lw          $t5, 0x1C($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X1C);
    // 0x802A5980: multu       $t9, $t4
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A5984: mflo        $t7
    ctx->r15 = lo;
    // 0x802A5988: sll         $t3, $t7, 1
    ctx->r11 = S32(ctx->r15 << 1);
    // 0x802A598C: addu        $t6, $t5, $t3
    ctx->r14 = ADD32(ctx->r13, ctx->r11);
    // 0x802A5990: sw          $t6, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r14;
    // 0x802A5994: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5998: lw          $t8, 0x0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0X0);
    // 0x802A599C: lh          $t7, 0x2C($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2C);
    // 0x802A59A0: lhu         $t9, 0xA4($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0XA4);
    // 0x802A59A4: addiu       $t5, $t7, 0x40
    ctx->r13 = ADD32(ctx->r15, 0X40);
    // 0x802A59A8: andi        $t3, $t5, 0xFF
    ctx->r11 = ctx->r13 & 0XFF;
    // 0x802A59AC: sll         $t6, $t3, 1
    ctx->r14 = S32(ctx->r11 << 1);
    // 0x802A59B0: addu        $t8, $v1, $t6
    ctx->r24 = ADD32(ctx->r3, ctx->r14);
    // 0x802A59B4: sra         $t4, $t9, 6
    ctx->r12 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802A59B8: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x802A59BC: lw          $t3, 0x20($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X20);
    // 0x802A59C0: multu       $t4, $t9
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A59C4: mflo        $t7
    ctx->r15 = lo;
    // 0x802A59C8: sll         $t5, $t7, 1
    ctx->r13 = S32(ctx->r15 << 1);
    // 0x802A59CC: addu        $t6, $t3, $t5
    ctx->r14 = ADD32(ctx->r11, ctx->r13);
    // 0x802A59D0: sw          $t6, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r14;
    // 0x802A59D4: lw          $t9, 0x0($t2)
    ctx->r25 = MEM_W(ctx->r10, 0X0);
    // 0x802A59D8: lh          $t8, 0x4A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X4A);
    // 0x802A59DC: lhu         $t7, 0xA6($t9)
    ctx->r15 = MEM_HU(ctx->r25, 0XA6);
    // 0x802A59E0: addiu       $t4, $t8, 0x1
    ctx->r12 = ADD32(ctx->r24, 0X1);
    // 0x802A59E4: sll         $t3, $t7, 14
    ctx->r11 = S32(ctx->r15 << 14);
    // 0x802A59E8: multu       $t4, $t3
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A59EC: mflo        $a1
    ctx->r5 = lo;
    // 0x802A59F0: nop

    // 0x802A59F4: nop

L_802A59F8:
    // 0x802A59F8: lh          $t5, 0x42($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X42);
L_802A59FC:
    // 0x802A59FC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A5A00: slti        $at, $t5, -0x17
    ctx->r1 = SIGNED(ctx->r13) < -0X17 ? 1 : 0;
    // 0x802A5A04: beql        $at, $zero, L_802A5A3C
    if (ctx->r1 == 0) {
        // 0x802A5A08: lh          $t8, 0x42($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X42);
            goto L_802A5A3C;
    }
    goto skip_6;
    // 0x802A5A08: lh          $t8, 0x42($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X42);
    skip_6:
    // 0x802A5A0C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5A10: negu        $a0, $a1
    ctx->r4 = SUB32(0, ctx->r5);
    // 0x802A5A14: sra         $t6, $a0, 3
    ctx->r14 = S32(SIGNED(ctx->r4) >> 3);
    // 0x802A5A18: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A5A1C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A5A20: slt         $at, $v1, $t6
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802A5A24: beql        $at, $zero, L_802A5A38
    if (ctx->r1 == 0) {
        // 0x802A5A28: sw          $a0, 0x1C($v0)
        MEM_W(0X1C, ctx->r2) = ctx->r4;
            goto L_802A5A38;
    }
    goto skip_7;
    // 0x802A5A28: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    skip_7:
    // 0x802A5A2C: b           L_802A5A38
    // 0x802A5A30: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
        goto L_802A5A38;
    // 0x802A5A30: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A5A34: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
L_802A5A38:
    // 0x802A5A38: lh          $t8, 0x42($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X42);
L_802A5A3C:
    // 0x802A5A3C: slti        $at, $t8, 0x18
    ctx->r1 = SIGNED(ctx->r24) < 0X18 ? 1 : 0;
    // 0x802A5A40: bnel        $at, $zero, L_802A5A70
    if (ctx->r1 != 0) {
        // 0x802A5A44: lh          $t9, 0x40($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X40);
            goto L_802A5A70;
    }
    goto skip_8;
    // 0x802A5A44: lh          $t9, 0x40($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X40);
    skip_8:
    // 0x802A5A48: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5A4C: sra         $a0, $a1, 3
    ctx->r4 = S32(SIGNED(ctx->r5) >> 3);
    // 0x802A5A50: lw          $v1, 0x1C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X1C);
    // 0x802A5A54: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A5A58: beql        $at, $zero, L_802A5A6C
    if (ctx->r1 == 0) {
        // 0x802A5A5C: sw          $a0, 0x1C($v0)
        MEM_W(0X1C, ctx->r2) = ctx->r4;
            goto L_802A5A6C;
    }
    goto skip_9;
    // 0x802A5A5C: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
    skip_9:
    // 0x802A5A60: b           L_802A5A6C
    // 0x802A5A64: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
        goto L_802A5A6C;
    // 0x802A5A64: sw          $v1, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r3;
    // 0x802A5A68: sw          $a0, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r4;
L_802A5A6C:
    // 0x802A5A6C: lh          $t9, 0x40($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X40);
L_802A5A70:
    // 0x802A5A70: slti        $at, $t9, -0x17
    ctx->r1 = SIGNED(ctx->r25) < -0X17 ? 1 : 0;
    // 0x802A5A74: beql        $at, $zero, L_802A5AAC
    if (ctx->r1 == 0) {
        // 0x802A5A78: lh          $t4, 0x40($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X40);
            goto L_802A5AAC;
    }
    goto skip_10;
    // 0x802A5A78: lh          $t4, 0x40($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X40);
    skip_10:
    // 0x802A5A7C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5A80: negu        $a0, $a1
    ctx->r4 = SUB32(0, ctx->r5);
    // 0x802A5A84: sra         $t7, $a0, 3
    ctx->r15 = S32(SIGNED(ctx->r4) >> 3);
    // 0x802A5A88: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A5A8C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802A5A90: slt         $at, $v1, $t7
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A5A94: beql        $at, $zero, L_802A5AA8
    if (ctx->r1 == 0) {
        // 0x802A5A98: sw          $a0, 0x20($v0)
        MEM_W(0X20, ctx->r2) = ctx->r4;
            goto L_802A5AA8;
    }
    goto skip_11;
    // 0x802A5A98: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    skip_11:
    // 0x802A5A9C: b           L_802A5AA8
    // 0x802A5AA0: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
        goto L_802A5AA8;
    // 0x802A5AA0: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A5AA4: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
L_802A5AA8:
    // 0x802A5AA8: lh          $t4, 0x40($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X40);
L_802A5AAC:
    // 0x802A5AAC: slti        $at, $t4, 0x18
    ctx->r1 = SIGNED(ctx->r12) < 0X18 ? 1 : 0;
    // 0x802A5AB0: bnel        $at, $zero, L_802A5AE0
    if (ctx->r1 != 0) {
        // 0x802A5AB4: lh          $t3, 0x42($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X42);
            goto L_802A5AE0;
    }
    goto skip_12;
    // 0x802A5AB4: lh          $t3, 0x42($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X42);
    skip_12:
    // 0x802A5AB8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5ABC: sra         $a0, $a1, 3
    ctx->r4 = S32(SIGNED(ctx->r5) >> 3);
    // 0x802A5AC0: lw          $v1, 0x20($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X20);
    // 0x802A5AC4: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A5AC8: beql        $at, $zero, L_802A5ADC
    if (ctx->r1 == 0) {
        // 0x802A5ACC: sw          $a0, 0x20($v0)
        MEM_W(0X20, ctx->r2) = ctx->r4;
            goto L_802A5ADC;
    }
    goto skip_13;
    // 0x802A5ACC: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    skip_13:
    // 0x802A5AD0: b           L_802A5ADC
    // 0x802A5AD4: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
        goto L_802A5ADC;
    // 0x802A5AD4: sw          $v1, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r3;
    // 0x802A5AD8: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
L_802A5ADC:
    // 0x802A5ADC: lh          $t3, 0x42($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X42);
L_802A5AE0:
    // 0x802A5AE0: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802A5AE4: bgezl       $t3, L_802A5AF8
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802A5AE8: lh          $v0, 0x42($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X42);
            goto L_802A5AF8;
    }
    goto skip_14;
    // 0x802A5AE8: lh          $v0, 0x42($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X42);
    skip_14:
    // 0x802A5AEC: b           L_802A5AF8
    // 0x802A5AF0: negu        $v0, $t3
    ctx->r2 = SUB32(0, ctx->r11);
        goto L_802A5AF8;
    // 0x802A5AF0: negu        $v0, $t3
    ctx->r2 = SUB32(0, ctx->r11);
    // 0x802A5AF4: lh          $v0, 0x42($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X42);
L_802A5AF8:
    // 0x802A5AF8: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A5AFC: beql        $at, $zero, L_802A5B2C
    if (ctx->r1 == 0) {
        // 0x802A5B00: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_802A5B2C;
    }
    goto skip_15;
    // 0x802A5B00: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_15:
    // 0x802A5B04: lh          $t5, 0x40($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X40);
    // 0x802A5B08: lh          $v0, 0x40($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X40);
    // 0x802A5B0C: bgez        $t5, L_802A5B1C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802A5B10: nop
    
            goto L_802A5B1C;
    }
    // 0x802A5B10: nop

    // 0x802A5B14: b           L_802A5B1C
    // 0x802A5B18: negu        $v0, $t5
    ctx->r2 = SUB32(0, ctx->r13);
        goto L_802A5B1C;
    // 0x802A5B18: negu        $v0, $t5
    ctx->r2 = SUB32(0, ctx->r13);
L_802A5B1C:
    // 0x802A5B1C: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802A5B20: bnel        $at, $zero, L_802A5B44
    if (ctx->r1 != 0) {
        // 0x802A5B24: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_802A5B44;
    }
    goto skip_16;
    // 0x802A5B24: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_16:
    // 0x802A5B28: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5B2C:
    // 0x802A5B2C: sra         $t8, $a1, 4
    ctx->r24 = S32(SIGNED(ctx->r5) >> 4);
    // 0x802A5B30: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802A5B34: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A5B38: b           L_802A5B50
    // 0x802A5B3C: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
        goto L_802A5B50;
    // 0x802A5B3C: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
    // 0x802A5B40: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A5B44:
    // 0x802A5B44: lw          $t7, 0x24($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X24);
    // 0x802A5B48: addu        $t4, $t7, $a1
    ctx->r12 = ADD32(ctx->r15, ctx->r5);
    // 0x802A5B4C: sw          $t4, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r12;
L_802A5B50:
    // 0x802A5B50: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802A5B54: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802A5B58: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802A5B5C: slti        $at, $v1, 0x6
    ctx->r1 = SIGNED(ctx->r3) < 0X6 ? 1 : 0;
    // 0x802A5B60: beq         $at, $zero, L_802A5B70
    if (ctx->r1 == 0) {
        // 0x802A5B64: addiu       $t3, $zero, 0x6
        ctx->r11 = ADD32(0, 0X6);
            goto L_802A5B70;
    }
    // 0x802A5B64: addiu       $t3, $zero, 0x6
    ctx->r11 = ADD32(0, 0X6);
    // 0x802A5B68: b           L_802A5B74
    // 0x802A5B6C: sh          $t3, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r11;
        goto L_802A5B74;
    // 0x802A5B6C: sh          $t3, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r11;
L_802A5B70:
    // 0x802A5B70: sh          $v1, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r3;
L_802A5B74:
    // 0x802A5B74: lw          $t5, 0x0($t2)
    ctx->r13 = MEM_W(ctx->r10, 0X0);
    // 0x802A5B78: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5B7C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A5B80: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
    // 0x802A5B84: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x802A5B88: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x802A5B8C: sll         $t6, $v1, 1
    ctx->r14 = S32(ctx->r3 << 1);
    // 0x802A5B90: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802A5B94: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802A5B98: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x802A5B9C: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    // 0x802A5BA0: addu        $a1, $a1, $t6
    ctx->r5 = ADD32(ctx->r5, ctx->r14);
    // 0x802A5BA4: lh          $a1, 0x6680($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6680);
    // 0x802A5BA8: lh          $a0, 0x65D0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X65D0);
    // 0x802A5BAC: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802A5BB0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802A5BB4: jal         0x8032C360
    // 0x802A5BB8: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802A5BB8: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_1:
    // 0x802A5BBC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A5BC0: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A5BC4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A5BC8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A5BCC: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A5BD0: lw          $v1, 0x6C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X6C);
    // 0x802A5BD4: beql        $v1, $zero, L_802A5C64
    if (ctx->r3 == 0) {
        // 0x802A5BD8: lh          $t3, 0x4A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X4A);
            goto L_802A5C64;
    }
    goto skip_17;
    // 0x802A5BD8: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    skip_17:
    // 0x802A5BDC: lbu         $t7, 0x162($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X162);
    // 0x802A5BE0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802A5BE4: bnel        $t7, $at, L_802A5C64
    if (ctx->r15 != ctx->r1) {
        // 0x802A5BE8: lh          $t3, 0x4A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X4A);
            goto L_802A5C64;
    }
    goto skip_18;
    // 0x802A5BE8: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    skip_18:
    // 0x802A5BEC: lw          $t4, 0x4C($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X4C);
    // 0x802A5BF0: sll         $t3, $t4, 29
    ctx->r11 = S32(ctx->r12 << 29);
    // 0x802A5BF4: srl         $t5, $t3, 31
    ctx->r13 = S32(U32(ctx->r11) >> 31);
    // 0x802A5BF8: beql        $t5, $zero, L_802A5C64
    if (ctx->r13 == 0) {
        // 0x802A5BFC: lh          $t3, 0x4A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X4A);
            goto L_802A5C64;
    }
    goto skip_19;
    // 0x802A5BFC: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    skip_19:
    // 0x802A5C00: lhu         $t6, 0x44($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X44);
    // 0x802A5C04: lhu         $t9, 0x44($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X44);
    // 0x802A5C08: sll         $t8, $t6, 19
    ctx->r24 = S32(ctx->r14 << 19);
    // 0x802A5C0C: div         $zero, $t8, $t9
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r25))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r25)));
    // 0x802A5C10: bne         $t9, $zero, L_802A5C1C
    if (ctx->r25 != 0) {
        // 0x802A5C14: nop
    
            goto L_802A5C1C;
    }
    // 0x802A5C14: nop

    // 0x802A5C18: break       7
    do_break(2150259736);
L_802A5C1C:
    // 0x802A5C1C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802A5C20: bne         $t9, $at, L_802A5C34
    if (ctx->r25 != ctx->r1) {
        // 0x802A5C24: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802A5C34;
    }
    // 0x802A5C24: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802A5C28: bne         $t8, $at, L_802A5C34
    if (ctx->r24 != ctx->r1) {
        // 0x802A5C2C: nop
    
            goto L_802A5C34;
    }
    // 0x802A5C2C: nop

    // 0x802A5C30: break       6
    do_break(2150259760);
L_802A5C34:
    // 0x802A5C34: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802A5C38: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802A5C3C: mflo        $a0
    ctx->r4 = lo;
    // 0x802A5C40: slt         $at, $a0, $at
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802A5C44: bne         $at, $zero, L_802A5C54
    if (ctx->r1 != 0) {
        // 0x802A5C48: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802A5C54;
    }
    // 0x802A5C48: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802A5C4C: b           L_802A5C54
    // 0x802A5C50: lui         $v0, 0x4
    ctx->r2 = S32(0X4 << 16);
        goto L_802A5C54;
    // 0x802A5C50: lui         $v0, 0x4
    ctx->r2 = S32(0X4 << 16);
L_802A5C54:
    // 0x802A5C54: lw          $t7, 0x24($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X24);
    // 0x802A5C58: subu        $t4, $t7, $v0
    ctx->r12 = SUB32(ctx->r15, ctx->r2);
    // 0x802A5C5C: sw          $t4, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r12;
    // 0x802A5C60: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
L_802A5C64:
    // 0x802A5C64: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802A5C68: sll         $t5, $t3, 2
    ctx->r13 = S32(ctx->r11 << 2);
    // 0x802A5C6C: sb          $t5, 0x368($t6)
    MEM_B(0X368, ctx->r14) = ctx->r13;
L_802A5C70:
    // 0x802A5C70: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x802A5C74: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x802A5C78: jr          $ra
    // 0x802A5C7C: nop

    return;
    // 0x802A5C7C: nop

;}
RECOMP_FUNC void func_802A5C80_6B7330(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5C80: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A5C84: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A5C88: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5C8C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5C90: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5C94: addiu       $t6, $zero, 0x29
    ctx->r14 = ADD32(0, 0X29);
    // 0x802A5C98: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5C9C: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5CA0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A5CA4: addiu       $t1, $zero, 0x6
    ctx->r9 = ADD32(0, 0X6);
    // 0x802A5CA8: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A5CAC: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5CB0: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A5CB4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5CB8: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A5CBC: lw          $v1, 0x0($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X0);
    // 0x802A5CC0: lh          $a0, 0x30C($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X30C);
    // 0x802A5CC4: slti        $at, $a0, 0x6
    ctx->r1 = SIGNED(ctx->r4) < 0X6 ? 1 : 0;
    // 0x802A5CC8: beql        $at, $zero, L_802A5CDC
    if (ctx->r1 == 0) {
        // 0x802A5CCC: sh          $a0, 0x30C($v1)
        MEM_H(0X30C, ctx->r3) = ctx->r4;
            goto L_802A5CDC;
    }
    goto skip_0;
    // 0x802A5CCC: sh          $a0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r4;
    skip_0:
    // 0x802A5CD0: b           L_802A5CDC
    // 0x802A5CD4: sh          $t1, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r9;
        goto L_802A5CDC;
    // 0x802A5CD4: sh          $t1, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r9;
    // 0x802A5CD8: sh          $a0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r4;
L_802A5CDC:
    // 0x802A5CDC: jal         0x802B8720
    // 0x802A5CE0: nop

    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A5CE0: nop

    after_0:
    // 0x802A5CE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5CE8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5CEC: jr          $ra
    // 0x802A5CF0: nop

    return;
    // 0x802A5CF0: nop

;}
RECOMP_FUNC void func_802A5CF4_6B73A4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5CF4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5CF8: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5CFC: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D00: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5D04: addiu       $t6, $zero, 0x32
    ctx->r14 = ADD32(0, 0X32);
    // 0x802A5D08: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5D0C: sh          $t6, 0x30E($t7)
    MEM_H(0X30E, ctx->r15) = ctx->r14;
    // 0x802A5D10: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5D14: addiu       $t8, $zero, 0x7B
    ctx->r24 = ADD32(0, 0X7B);
    // 0x802A5D18: addiu       $t2, $zero, 0x16
    ctx->r10 = ADD32(0, 0X16);
    // 0x802A5D1C: sh          $t8, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r24;
    // 0x802A5D20: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D24: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x802A5D28: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x802A5D2C: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A5D30: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D34: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A5D38: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D3C: sh          $t2, 0x2FC($t3)
    MEM_H(0X2FC, ctx->r11) = ctx->r10;
    // 0x802A5D40: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D44: sb          $zero, 0x368($t4)
    MEM_B(0X368, ctx->r12) = 0;
    // 0x802A5D48: lw          $t5, 0x5B0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B0);
    // 0x802A5D4C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802A5D50: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802A5D54: sw          $t6, 0x24($t7)
    MEM_W(0X24, ctx->r15) = ctx->r14;
    // 0x802A5D58: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5D5C: jr          $ra
    // 0x802A5D60: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
    return;
    // 0x802A5D60: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
;}
RECOMP_FUNC void func_802A5D64_6B7414(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5D64: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5D68: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5D6C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802A5D70: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5D74: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5D78: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5D7C: addiu       $t6, $zero, 0x79
    ctx->r14 = ADD32(0, 0X79);
    // 0x802A5D80: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5D84: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5D88: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A5D8C: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802A5D90: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A5D94: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5D98: sw          $zero, 0x24($t9)
    MEM_W(0X24, ctx->r25) = 0;
    // 0x802A5D9C: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5DA0: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A5DA4: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A5DA8: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A5DAC: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A5DB0: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
    // 0x802A5DB4: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A5DB8: jal         0x802B8720
    // 0x802A5DBC: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A5DBC: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    after_0:
    // 0x802A5DC0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5DC4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5DC8: jr          $ra
    // 0x802A5DCC: nop

    return;
    // 0x802A5DCC: nop

;}
RECOMP_FUNC void func_802A5DD0_6B7480(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5DD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5DD4: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A5DD8: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A5DDC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5DE0: addiu       $t6, $zero, 0x3E
    ctx->r14 = ADD32(0, 0X3E);
    // 0x802A5DE4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A5DE8: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5DEC: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A5DF0: addiu       $t0, $zero, 0x16
    ctx->r8 = ADD32(0, 0X16);
    // 0x802A5DF4: sh          $zero, 0x2F2($t8)
    MEM_H(0X2F2, ctx->r24) = 0;
    // 0x802A5DF8: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5DFC: sh          $zero, 0x2F4($t9)
    MEM_H(0X2F4, ctx->r25) = 0;
    // 0x802A5E00: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A5E04: sh          $t0, 0x2FC($t1)
    MEM_H(0X2FC, ctx->r9) = ctx->r8;
    // 0x802A5E08: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A5E0C: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
    // 0x802A5E10: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E14: jr          $ra
    // 0x802A5E18: sw          $zero, 0x24($t3)
    MEM_W(0X24, ctx->r11) = 0;
    return;
    // 0x802A5E18: sw          $zero, 0x24($t3)
    MEM_W(0X24, ctx->r11) = 0;
;}
RECOMP_FUNC void func_802A5E1C_6B74CC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5E1C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5E20: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A5E24: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E28: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802A5E2C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5E30: sh          $a0, 0x2C($t7)
    MEM_H(0X2C, ctx->r15) = ctx->r4;
    // 0x802A5E34: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E38: addiu       $t8, $zero, 0xA2
    ctx->r24 = ADD32(0, 0XA2);
    // 0x802A5E3C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A5E40: sh          $t8, 0x0($t9)
    MEM_H(0X0, ctx->r25) = ctx->r24;
    // 0x802A5E44: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A5E48: addiu       $t2, $zero, 0x10
    ctx->r10 = ADD32(0, 0X10);
    // 0x802A5E4C: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A5E50: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A5E54: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A5E58: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802A5E5C: jr          $ra
    // 0x802A5E60: sb          $t2, 0x368($t3)
    MEM_B(0X368, ctx->r11) = ctx->r10;
    return;
    // 0x802A5E60: sb          $t2, 0x368($t3)
    MEM_B(0X368, ctx->r11) = ctx->r10;
;}
RECOMP_FUNC void func_802A5E64_6B7514(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5E64: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A5E68: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A5E6C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5E70: addiu       $t6, $zero, 0xA1
    ctx->r14 = ADD32(0, 0XA1);
    // 0x802A5E74: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5E78: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5E7C: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E80: addiu       $t1, $zero, 0xA
    ctx->r9 = ADD32(0, 0XA);
    // 0x802A5E84: sh          $zero, 0x2F2($t8)
    MEM_H(0X2F2, ctx->r24) = 0;
    // 0x802A5E88: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E8C: sh          $zero, 0x2F4($t9)
    MEM_H(0X2F4, ctx->r25) = 0;
    // 0x802A5E90: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E94: sb          $zero, 0x368($t0)
    MEM_B(0X368, ctx->r8) = 0;
    // 0x802A5E98: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A5E9C: jr          $ra
    // 0x802A5EA0: sh          $t1, 0x308($t2)
    MEM_H(0X308, ctx->r10) = ctx->r9;
    return;
    // 0x802A5EA0: sh          $t1, 0x308($t2)
    MEM_H(0X308, ctx->r10) = ctx->r9;
;}
RECOMP_FUNC void func_802A5EA4_6B7554(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5EA4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A5EA8: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A5EAC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5EB0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5EB4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5EB8: addiu       $t6, $zero, 0x8D
    ctx->r14 = ADD32(0, 0X8D);
    // 0x802A5EBC: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5EC0: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A5EC4: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A5EC8: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A5ECC: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A5ED0: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A5ED4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5ED8: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A5EDC: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A5EE0: jal         0x802B8720
    // 0x802A5EE4: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    func_802B8720_6C9DD0(rdram, ctx);
        goto after_0;
    // 0x802A5EE4: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    after_0:
    // 0x802A5EE8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5EEC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5EF0: jr          $ra
    // 0x802A5EF4: nop

    return;
    // 0x802A5EF4: nop

;}
RECOMP_FUNC void func_802A5EF8_6B75A8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5EF8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5EFC: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5F00: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5F04: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5F08: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5F0C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A5F10: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A5F14: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802A5F18: sh          $t6, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r14;
    // 0x802A5F1C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A5F20: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5F24: addiu       $t0, $zero, 0x8E
    ctx->r8 = ADD32(0, 0X8E);
    // 0x802A5F28: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5F2C: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    // 0x802A5F30: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A5F34: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A5F38: sra         $a1, $t7, 24
    ctx->r5 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A5F3C: sh          $zero, 0x31A($t2)
    MEM_H(0X31A, ctx->r10) = 0;
    // 0x802A5F40: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5F44: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A5F48: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A5F4C: sh          $zero, 0x2F2($t3)
    MEM_H(0X2F2, ctx->r11) = 0;
    // 0x802A5F50: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A5F54: sh          $zero, 0x2F4($t4)
    MEM_H(0X2F4, ctx->r12) = 0;
    // 0x802A5F58: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A5F5C: sb          $a1, 0x368($t5)
    MEM_B(0X368, ctx->r13) = ctx->r5;
    // 0x802A5F60: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802A5F64: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A5F68: lhu         $t7, 0xA4($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA4);
    // 0x802A5F6C: multu       $a1, $t7
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A5F70: mflo        $t8
    ctx->r24 = lo;
    // 0x802A5F74: bgez        $t8, L_802A5F84
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802A5F78: sra         $t9, $t8, 4
        ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
            goto L_802A5F84;
    }
    // 0x802A5F78: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802A5F7C: addiu       $at, $t8, 0xF
    ctx->r1 = ADD32(ctx->r24, 0XF);
    // 0x802A5F80: sra         $t9, $at, 4
    ctx->r25 = S32(SIGNED(ctx->r1) >> 4);
L_802A5F84:
    // 0x802A5F84: jal         0x802B8790
    // 0x802A5F88: sh          $t9, 0x31A($t0)
    MEM_H(0X31A, ctx->r8) = ctx->r25;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A5F88: sh          $t9, 0x31A($t0)
    MEM_H(0X31A, ctx->r8) = ctx->r25;
    after_0:
    // 0x802A5F8C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A5F90: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A5F94: jr          $ra
    // 0x802A5F98: nop

    return;
    // 0x802A5F98: nop

;}
RECOMP_FUNC void func_802A5F9C_6B764C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A5F9C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A5FA0: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A5FA4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A5FA8: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A5FAC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A5FB0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A5FB4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A5FB8: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802A5FBC: sh          $t6, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r14;
    // 0x802A5FC0: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A5FC4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A5FC8: addiu       $t0, $zero, 0x90
    ctx->r8 = ADD32(0, 0X90);
    // 0x802A5FCC: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A5FD0: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    // 0x802A5FD4: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A5FD8: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802A5FDC: sll         $t7, $a1, 24
    ctx->r15 = S32(ctx->r5 << 24);
    // 0x802A5FE0: sh          $zero, 0x31A($t2)
    MEM_H(0X31A, ctx->r10) = 0;
    // 0x802A5FE4: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A5FE8: sra         $a1, $t7, 24
    ctx->r5 = S32(SIGNED(ctx->r15) >> 24);
    // 0x802A5FEC: negu        $t5, $a1
    ctx->r13 = SUB32(0, ctx->r5);
    // 0x802A5FF0: sh          $zero, 0x2F2($t3)
    MEM_H(0X2F2, ctx->r11) = 0;
    // 0x802A5FF4: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A5FF8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A5FFC: sh          $zero, 0x2F4($t4)
    MEM_H(0X2F4, ctx->r12) = 0;
    // 0x802A6000: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802A6004: sb          $t5, 0x368($t6)
    MEM_B(0X368, ctx->r14) = ctx->r13;
    // 0x802A6008: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802A600C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A6010: lhu         $t8, 0xA4($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XA4);
    // 0x802A6014: multu       $a1, $t8
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A6018: mflo        $t9
    ctx->r25 = lo;
    // 0x802A601C: bgez        $t9, L_802A602C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802A6020: sra         $t0, $t9, 4
        ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
            goto L_802A602C;
    }
    // 0x802A6020: sra         $t0, $t9, 4
    ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802A6024: addiu       $at, $t9, 0xF
    ctx->r1 = ADD32(ctx->r25, 0XF);
    // 0x802A6028: sra         $t0, $at, 4
    ctx->r8 = S32(SIGNED(ctx->r1) >> 4);
L_802A602C:
    // 0x802A602C: jal         0x802B8790
    // 0x802A6030: sh          $t0, 0x31A($t1)
    MEM_H(0X31A, ctx->r9) = ctx->r8;
    func_802B8790_6C9E40(rdram, ctx);
        goto after_0;
    // 0x802A6030: sh          $t0, 0x31A($t1)
    MEM_H(0X31A, ctx->r9) = ctx->r8;
    after_0:
    // 0x802A6034: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A6038: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A603C: jr          $ra
    // 0x802A6040: nop

    return;
    // 0x802A6040: nop

;}
RECOMP_FUNC void func_802A6044_6B76F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A6044: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6048: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A604C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A6050: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A6054: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A6058: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802A605C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802A6060: sh          $a0, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r4;
    // 0x802A6064: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A6068: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A606C: addiu       $t0, $zero, 0x8F
    ctx->r8 = ADD32(0, 0X8F);
    // 0x802A6070: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A6074: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    // 0x802A6078: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A607C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6080: sh          $zero, 0x31A($t2)
    MEM_H(0X31A, ctx->r10) = 0;
    // 0x802A6084: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A6088: sh          $zero, 0x2F2($t3)
    MEM_H(0X2F2, ctx->r11) = 0;
    // 0x802A608C: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A6090: sh          $zero, 0x2F4($t4)
    MEM_H(0X2F4, ctx->r12) = 0;
    // 0x802A6094: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A6098: sb          $a1, 0x368($t5)
    MEM_B(0X368, ctx->r13) = ctx->r5;
    // 0x802A609C: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802A60A0: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A60A4: lhu         $t7, 0xA4($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA4);
    // 0x802A60A8: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802A60AC: jal         0x802B8810
    // 0x802A60B0: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    func_802B8810_6C9EC0(rdram, ctx);
        goto after_0;
    // 0x802A60B0: sh          $t8, 0x31A($t9)
    MEM_H(0X31A, ctx->r25) = ctx->r24;
    after_0:
    // 0x802A60B4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A60B8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A60BC: jr          $ra
    // 0x802A60C0: nop

    return;
    // 0x802A60C0: nop

;}
RECOMP_FUNC void func_802A60C4_6B7774(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A60C4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A60C8: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A60CC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A60D0: addiu       $t6, $zero, 0x65
    ctx->r14 = ADD32(0, 0X65);
    // 0x802A60D4: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A60D8: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A60DC: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A60E0: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A60E4: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A60E8: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A60EC: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A60F0: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A60F4: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A60F8: jr          $ra
    // 0x802A60FC: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    return;
    // 0x802A60FC: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
;}
RECOMP_FUNC void func_802A6100_6B77B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A6100: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A6104: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802A6108: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A610C: addiu       $t6, $zero, 0x67
    ctx->r14 = ADD32(0, 0X67);
    // 0x802A6110: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A6114: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802A6118: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A611C: sh          $zero, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = 0;
    // 0x802A6120: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A6124: sh          $zero, 0x2F2($t9)
    MEM_H(0X2F2, ctx->r25) = 0;
    // 0x802A6128: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A612C: sh          $zero, 0x2F4($t0)
    MEM_H(0X2F4, ctx->r8) = 0;
    // 0x802A6130: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A6134: jr          $ra
    // 0x802A6138: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
    return;
    // 0x802A6138: sb          $zero, 0x368($t1)
    MEM_B(0X368, ctx->r9) = 0;
;}
RECOMP_FUNC void func_802A613C_6B77EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A613C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6140: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802A6144: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A6148: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802A614C: andi        $t6, $a0, 0xFFFF
    ctx->r14 = ctx->r4 & 0XFFFF;
    // 0x802A6150: addiu       $t7, $zero, 0x68
    ctx->r15 = ADD32(0, 0X68);
    // 0x802A6154: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802A6158: beq         $t6, $at, L_802A6168
    if (ctx->r14 == ctx->r1) {
        // 0x802A615C: sh          $t7, 0x0($t8)
        MEM_H(0X0, ctx->r24) = ctx->r15;
            goto L_802A6168;
    }
    // 0x802A615C: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    // 0x802A6160: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A6164: sh          $t6, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r14;
L_802A6168:
    // 0x802A6168: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A616C: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A6170: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802A6174: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x802A6178: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A617C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A6180: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A6184: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802A6188: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
    // 0x802A618C: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A6190: jr          $ra
    // 0x802A6194: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    return;
    // 0x802A6194: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
;}
RECOMP_FUNC void func_802A6198_6B7848(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A6198: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A619C: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A61A0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A61A4: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802A61A8: addiu       $t7, $zero, 0x69
    ctx->r15 = ADD32(0, 0X69);
    // 0x802A61AC: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    // 0x802A61B0: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A61B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A61B8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A61BC: sh          $a0, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r4;
    // 0x802A61C0: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A61C4: addiu       $t2, $zero, 0x10
    ctx->r10 = ADD32(0, 0X10);
    // 0x802A61C8: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x802A61CC: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A61D0: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A61D4: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A61D8: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802A61DC: sb          $t2, 0x368($t3)
    MEM_B(0X368, ctx->r11) = ctx->r10;
    // 0x802A61E0: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802A61E4: jr          $ra
    // 0x802A61E8: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
    return;
    // 0x802A61E8: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
;}
RECOMP_FUNC void func_802A61EC_6B789C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A61EC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A61F0: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A61F4: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802A61F8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802A61FC: addiu       $t7, $zero, 0x6A
    ctx->r15 = ADD32(0, 0X6A);
    // 0x802A6200: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    // 0x802A6204: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A6208: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A620C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A6210: sh          $a0, 0x2C($t9)
    MEM_H(0X2C, ctx->r25) = ctx->r4;
    // 0x802A6214: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802A6218: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x802A621C: sh          $zero, 0x2F2($t0)
    MEM_H(0X2F2, ctx->r8) = 0;
    // 0x802A6220: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802A6224: sh          $zero, 0x2F4($t1)
    MEM_H(0X2F4, ctx->r9) = 0;
    // 0x802A6228: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A622C: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
    // 0x802A6230: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A6234: jr          $ra
    // 0x802A6238: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    return;
    // 0x802A6238: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
;}
RECOMP_FUNC void func_802A623C_6B78EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A623C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A6240: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802A6244: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A6248: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802A624C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802A6250: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6254: addiu       $t0, $zero, 0xDD
    ctx->r8 = ADD32(0, 0XDD);
    // 0x802A6258: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A625C: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    // 0x802A6260: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802A6264: sll         $t3, $a1, 4
    ctx->r11 = S32(ctx->r5 << 4);
    // 0x802A6268: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802A626C: sh          $a0, 0x308($t2)
    MEM_H(0X308, ctx->r10) = ctx->r4;
    // 0x802A6270: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802A6274: sh          $t3, 0x30A($t4)
    MEM_H(0X30A, ctx->r12) = ctx->r11;
    // 0x802A6278: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802A627C: sb          $zero, 0x368($t5)
    MEM_B(0X368, ctx->r13) = 0;
    // 0x802A6280: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802A6284: jr          $ra
    // 0x802A6288: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
    return;
    // 0x802A6288: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
;}
RECOMP_FUNC void func_802A628C_6B793C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A628C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6290: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802A6294: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802A6298: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802A629C: jal         0x802E4A78
    // 0x802A62A0: lh          $a0, 0x308($t6)
    ctx->r4 = MEM_H(ctx->r14, 0X308);
    func_802E4A78_6F6128(rdram, ctx);
        goto after_0;
    // 0x802A62A0: lh          $a0, 0x308($t6)
    ctx->r4 = MEM_H(ctx->r14, 0X308);
    after_0:
    // 0x802A62A4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x802A62A8: lh          $t7, 0x2A98($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2A98);
    // 0x802A62AC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802A62B0: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x802A62B4: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802A62B8: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x802A62BC: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802A62C0: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x802A62C4: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802A62C8: addu        $at, $at, $t8
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802A62CC: lwc1        $f4, 0x2900($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X2900);
    // 0x802A62D0: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x802A62D4: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802A62D8: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802A62DC: lh          $a0, -0x614C($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614C);
    // 0x802A62E0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A62E4: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A62E8: mfc1        $t2, $f6
    ctx->r10 = (int32_t)ctx->f6.u32l;
    // 0x802A62EC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A62F0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A62F4: addiu       $t3, $t2, 0x40
    ctx->r11 = ADD32(ctx->r10, 0X40);
    // 0x802A62F8: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x802A62FC: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x802A6300: addu        $t6, $a3, $t5
    ctx->r14 = ADD32(ctx->r7, ctx->r13);
    // 0x802A6304: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x802A6308: andi        $t1, $t2, 0xFF
    ctx->r9 = ctx->r10 & 0XFF;
    // 0x802A630C: sll         $t2, $t1, 1
    ctx->r10 = S32(ctx->r9 << 1);
    // 0x802A6310: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802A6314: multu       $t8, $a0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A6318: addu        $t3, $a3, $t2
    ctx->r11 = ADD32(ctx->r7, ctx->r10);
    // 0x802A631C: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x802A6320: negu        $t6, $a0
    ctx->r14 = SUB32(0, ctx->r4);
    // 0x802A6324: lw          $t8, 0x1C($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X1C);
    // 0x802A6328: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x802A632C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A6330: addiu       $t4, $zero, 0x32
    ctx->r12 = ADD32(0, 0X32);
    // 0x802A6334: mflo        $a1
    ctx->r5 = lo;
    // 0x802A6338: sll         $t9, $a1, 4
    ctx->r25 = S32(ctx->r5 << 4);
    // 0x802A633C: addu        $t9, $t8, $t9
    ctx->r25 = ADD32(ctx->r24, ctx->r25);
    // 0x802A6340: multu       $t5, $t6
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A6344: sw          $t9, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r25;
    // 0x802A6348: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A634C: lw          $t1, 0x20($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X20);
    // 0x802A6350: mflo        $a2
    ctx->r6 = lo;
    // 0x802A6354: sll         $t7, $a2, 4
    ctx->r15 = S32(ctx->r6 << 4);
    // 0x802A6358: addu        $t2, $t1, $t7
    ctx->r10 = ADD32(ctx->r9, ctx->r15);
    // 0x802A635C: sw          $t2, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r10;
    // 0x802A6360: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802A6364: sb          $zero, 0x368($t3)
    MEM_B(0X368, ctx->r11) = 0;
    // 0x802A6368: jal         0x802B2EA8
    // 0x802A636C: sh          $t4, 0x5546($at)
    MEM_H(0X5546, ctx->r1) = ctx->r12;
    func_802B2EA8_6C4558(rdram, ctx);
        goto after_1;
    // 0x802A636C: sh          $t4, 0x5546($at)
    MEM_H(0X5546, ctx->r1) = ctx->r12;
    after_1:
    // 0x802A6370: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6374: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802A6378: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x802A637C: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
    // 0x802A6380: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802A6384: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802A6388: jr          $ra
    // 0x802A638C: nop

    return;
    // 0x802A638C: nop

;}
RECOMP_FUNC void func_802A6390_6B7A40(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A6390: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6394: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A6398: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802A639C: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802A63A0: lb          $t6, 0x360($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X360);
    // 0x802A63A4: bne         $t6, $zero, L_802A63B8
    if (ctx->r14 != 0) {
        // 0x802A63A8: nop
    
            goto L_802A63B8;
    }
    // 0x802A63A8: nop

    // 0x802A63AC: sb          $t7, 0x360($v0)
    MEM_B(0X360, ctx->r2) = ctx->r15;
    // 0x802A63B0: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A63B4: sb          $zero, 0x361($t8)
    MEM_B(0X361, ctx->r24) = 0;
L_802A63B8:
    // 0x802A63B8: jr          $ra
    // 0x802A63BC: nop

    return;
    // 0x802A63BC: nop

;}
RECOMP_FUNC void func_802A63C0_6B7A70(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A63C0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A63C4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A63C8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802A63CC: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802A63D0: lb          $t6, 0x360($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X360);
    // 0x802A63D4: bnel        $t6, $zero, L_802A63F4
    if (ctx->r14 != 0) {
        // 0x802A63D8: addiu       $t0, $zero, 0x1
        ctx->r8 = ADD32(0, 0X1);
            goto L_802A63F4;
    }
    goto skip_0;
    // 0x802A63D8: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    skip_0:
    // 0x802A63DC: sb          $t7, 0x360($v0)
    MEM_B(0X360, ctx->r2) = ctx->r15;
    // 0x802A63E0: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802A63E4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802A63E8: jr          $ra
    // 0x802A63EC: sb          $t8, 0x361($t9)
    MEM_B(0X361, ctx->r25) = ctx->r24;
    return;
    // 0x802A63EC: sb          $t8, 0x361($t9)
    MEM_B(0X361, ctx->r25) = ctx->r24;
    // 0x802A63F0: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
L_802A63F4:
    // 0x802A63F4: sb          $t0, 0x361($v0)
    MEM_B(0X361, ctx->r2) = ctx->r8;
    // 0x802A63F8: jr          $ra
    // 0x802A63FC: nop

    return;
    // 0x802A63FC: nop

;}
RECOMP_FUNC void func_802A6400_6B7AB0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A6400: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6404: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802A6408: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802A640C: slti        $at, $v0, 0x6B
    ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
    // 0x802A6410: bne         $at, $zero, L_802A6438
    if (ctx->r1 != 0) {
        // 0x802A6414: addiu       $t6, $v0, -0xB5
        ctx->r14 = ADD32(ctx->r2, -0XB5);
            goto L_802A6438;
    }
    // 0x802A6414: addiu       $t6, $v0, -0xB5
    ctx->r14 = ADD32(ctx->r2, -0XB5);
    // 0x802A6418: sltiu       $at, $t6, 0x5
    ctx->r1 = ctx->r14 < 0X5 ? 1 : 0;
    // 0x802A641C: beq         $at, $zero, L_802A64A8
    if (ctx->r1 == 0) {
        // 0x802A6420: sll         $t6, $t6, 2
        ctx->r14 = S32(ctx->r14 << 2);
            goto L_802A64A8;
    }
    // 0x802A6420: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802A6424: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A6428: addu        $at, $at, $t6
    gpr jr_addend_802A6430 = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x802A642C: lw          $t6, -0x5240($at)
    ctx->r14 = ADD32(ctx->r1, -0X5240);
    // 0x802A6430: jr          $t6
    // 0x802A6434: nop

    switch (jr_addend_802A6430 >> 2) {
        case 0: goto L_802A64A0; break;
        case 1: goto L_802A64A0; break;
        case 2: goto L_802A64A0; break;
        case 3: goto L_802A64A0; break;
        case 4: goto L_802A64A0; break;
        default: switch_error(__func__, 0x802A6430, 0x803BADC0);
    }
    // 0x802A6434: nop

L_802A6438:
    // 0x802A6438: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x802A643C: bne         $at, $zero, L_802A6468
    if (ctx->r1 != 0) {
        // 0x802A6440: addiu       $t8, $v0, -0x2
        ctx->r24 = ADD32(ctx->r2, -0X2);
            goto L_802A6468;
    }
    // 0x802A6440: addiu       $t8, $v0, -0x2
    ctx->r24 = ADD32(ctx->r2, -0X2);
    // 0x802A6444: addiu       $t7, $v0, -0x65
    ctx->r15 = ADD32(ctx->r2, -0X65);
    // 0x802A6448: sltiu       $at, $t7, 0x6
    ctx->r1 = ctx->r15 < 0X6 ? 1 : 0;
    // 0x802A644C: beq         $at, $zero, L_802A64A8
    if (ctx->r1 == 0) {
        // 0x802A6450: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_802A64A8;
    }
    // 0x802A6450: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802A6454: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A6458: addu        $at, $at, $t7
    gpr jr_addend_802A6460 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x802A645C: lw          $t7, -0x522C($at)
    ctx->r15 = ADD32(ctx->r1, -0X522C);
    // 0x802A6460: jr          $t7
    // 0x802A6464: nop

    switch (jr_addend_802A6460 >> 2) {
        case 0: goto L_802A6494; break;
        case 1: goto L_802A6494; break;
        case 2: goto L_802A6494; break;
        case 3: goto L_802A6494; break;
        case 4: goto L_802A6494; break;
        case 5: goto L_802A6494; break;
        default: switch_error(__func__, 0x802A6460, 0x803BADD4);
    }
    // 0x802A6464: nop

L_802A6468:
    // 0x802A6468: sltiu       $at, $t8, 0x5
    ctx->r1 = ctx->r24 < 0X5 ? 1 : 0;
    // 0x802A646C: beq         $at, $zero, L_802A64A8
    if (ctx->r1 == 0) {
        // 0x802A6470: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802A64A8;
    }
    // 0x802A6470: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802A6474: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A6478: addu        $at, $at, $t8
    gpr jr_addend_802A6480 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802A647C: lw          $t8, -0x5214($at)
    ctx->r24 = ADD32(ctx->r1, -0X5214);
    // 0x802A6480: jr          $t8
    // 0x802A6484: nop

    switch (jr_addend_802A6480 >> 2) {
        case 0: goto L_802A6488; break;
        case 1: goto L_802A6488; break;
        case 2: goto L_802A6488; break;
        case 3: goto L_802A6488; break;
        case 4: goto L_802A6488; break;
        default: switch_error(__func__, 0x802A6480, 0x803BADEC);
    }
    // 0x802A6484: nop

L_802A6488:
    // 0x802A6488: addiu       $t9, $zero, 0x5
    ctx->r25 = ADD32(0, 0X5);
    // 0x802A648C: jr          $ra
    // 0x802A6490: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    return;
    // 0x802A6490: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
L_802A6494:
    // 0x802A6494: addiu       $t0, $zero, 0x67
    ctx->r8 = ADD32(0, 0X67);
    // 0x802A6498: jr          $ra
    // 0x802A649C: sh          $t0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r8;
    return;
    // 0x802A649C: sh          $t0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r8;
L_802A64A0:
    // 0x802A64A0: addiu       $t1, $zero, 0xB8
    ctx->r9 = ADD32(0, 0XB8);
    // 0x802A64A4: sh          $t1, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r9;
L_802A64A8:
    // 0x802A64A8: jr          $ra
    // 0x802A64AC: nop

    return;
    // 0x802A64AC: nop

;}
RECOMP_FUNC void func_802A64B0_6B7B60(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A64B0: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802A64B4: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802A64B8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A64BC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A64C0: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802A64C4: sb          $zero, 0x54($sp)
    MEM_B(0X54, ctx->r29) = 0;
    // 0x802A64C8: lbu         $t6, 0x161($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X161);
    // 0x802A64CC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A64D0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802A64D4: beq         $t6, $at, L_802A64E8
    if (ctx->r14 == ctx->r1) {
        // 0x802A64D8: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_802A64E8;
    }
    // 0x802A64D8: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A64DC: lbu         $t7, 0x54($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X54);
    // 0x802A64E0: ori         $t8, $t7, 0xA
    ctx->r24 = ctx->r15 | 0XA;
    // 0x802A64E4: sb          $t8, 0x54($s0)
    MEM_B(0X54, ctx->r16) = ctx->r24;
L_802A64E8:
    // 0x802A64E8: lbu         $t9, 0x5538($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X5538);
    // 0x802A64EC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802A64F0: lui         $at, 0x801F
    ctx->r1 = S32(0X801F << 16);
    // 0x802A64F4: beq         $t9, $zero, L_802A6500
    if (ctx->r25 == 0) {
        // 0x802A64F8: nop
    
            goto L_802A6500;
    }
    // 0x802A64F8: nop

    // 0x802A64FC: sh          $t2, -0x615A($at)
    MEM_H(-0X615A, ctx->r1) = ctx->r10;
L_802A6500:
    // 0x802A6500: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802A6504: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A6508: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802A650C: lb          $t4, 0xE7($t3)
    ctx->r12 = MEM_B(ctx->r11, 0XE7);
    // 0x802A6510: jal         0x802B8B1C
    // 0x802A6514: sb          $t4, 0x367($t5)
    MEM_B(0X367, ctx->r13) = ctx->r12;
    func_802B8B1C_6CA1CC(rdram, ctx);
        goto after_0;
    // 0x802A6514: sb          $t4, 0x367($t5)
    MEM_B(0X367, ctx->r13) = ctx->r12;
    after_0:
    // 0x802A6518: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A651C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802A6520: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802A6524: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6528: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802A652C: lhu         $t8, 0x48($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X48);
    // 0x802A6530: subu        $t9, $t6, $t8
    ctx->r25 = SUB32(ctx->r14, ctx->r24);
    // 0x802A6534: slti        $at, $t9, 0x7
    ctx->r1 = SIGNED(ctx->r25) < 0X7 ? 1 : 0;
    // 0x802A6538: bne         $at, $zero, L_802A661C
    if (ctx->r1 != 0) {
        // 0x802A653C: nop
    
            goto L_802A661C;
    }
    // 0x802A653C: nop

    // 0x802A6540: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6544: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802A6548: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A654C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A6550: lbu         $t2, 0x369($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X369);
    // 0x802A6554: bne         $t2, $at, L_802A661C
    if (ctx->r10 != ctx->r1) {
        // 0x802A6558: nop
    
            goto L_802A661C;
    }
    // 0x802A6558: nop

    // 0x802A655C: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802A6560: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x802A6564: addiu       $a0, $zero, 0x19
    ctx->r4 = ADD32(0, 0X19);
    // 0x802A6568: lhu         $v0, 0x9C($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X9C);
    // 0x802A656C: beq         $v0, $at, L_802A657C
    if (ctx->r2 == ctx->r1) {
        // 0x802A6570: addiu       $at, $zero, 0x26
        ctx->r1 = ADD32(0, 0X26);
            goto L_802A657C;
    }
    // 0x802A6570: addiu       $at, $zero, 0x26
    ctx->r1 = ADD32(0, 0X26);
    // 0x802A6574: bne         $v0, $at, L_802A661C
    if (ctx->r2 != ctx->r1) {
        // 0x802A6578: nop
    
            goto L_802A661C;
    }
    // 0x802A6578: nop

L_802A657C:
    // 0x802A657C: sb          $zero, 0x369($v1)
    MEM_B(0X369, ctx->r3) = 0;
    // 0x802A6580: jal         0x8037D340
    // 0x802A6584: addiu       $a1, $zero, 0xC0
    ctx->r5 = ADD32(0, 0XC0);
    func_8037D340_78E9F0(rdram, ctx);
        goto after_1;
    // 0x802A6584: addiu       $a1, $zero, 0xC0
    ctx->r5 = ADD32(0, 0XC0);
    after_1:
    // 0x802A6588: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A658C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6590: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6594: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802A6598: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802A659C: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A65A0: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A65A4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802A65A8: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802A65AC: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802A65B0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A65B4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x802A65B8: jal         0x8032C360
    // 0x802A65BC: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x802A65BC: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_2:
    // 0x802A65C0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A65C4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A65C8: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    // 0x802A65CC: lh          $a1, 0x4($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X4);
    // 0x802A65D0: lh          $a2, 0x8($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X8);
    // 0x802A65D4: jal         0x8034220C
    // 0x802A65D8: lh          $a3, 0xC($s0)
    ctx->r7 = MEM_H(ctx->r16, 0XC);
    func_8034220C_7538BC(rdram, ctx);
        goto after_3;
    // 0x802A65D8: lh          $a3, 0xC($s0)
    ctx->r7 = MEM_H(ctx->r16, 0XC);
    after_3:
    // 0x802A65DC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A65E0: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x802A65E4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A65E8: beq         $t7, $zero, L_802A661C
    if (ctx->r15 == 0) {
        // 0x802A65EC: nop
    
            goto L_802A661C;
    }
    // 0x802A65EC: nop

    // 0x802A65F0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A65F4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A65F8: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A65FC: jal         0x8029B7D0
    // 0x802A6600: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    static_2_8029B7D0(rdram, ctx);
        goto after_4;
    // 0x802A6600: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    after_4:
    // 0x802A6604: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A6608: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x802A660C: addiu       $a2, $zero, 0x3C
    ctx->r6 = ADD32(0, 0X3C);
    // 0x802A6610: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A6614: jal         0x801373CC
    // 0x802A6618: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    do_rumble(rdram, ctx);
        goto after_5;
    // 0x802A6618: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    after_5:
L_802A661C:
    // 0x802A661C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6620: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802A6624: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A6628: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802A662C: lhu         $t8, 0xA2($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0XA2);
    // 0x802A6630: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6634: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A6638: andi        $t9, $t8, 0x2
    ctx->r25 = ctx->r24 & 0X2;
    // 0x802A663C: beql        $t9, $zero, L_802A6BB0
    if (ctx->r25 == 0) {
        // 0x802A6640: lbu         $t9, 0x161($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X161);
            goto L_802A6BB0;
    }
    goto skip_0;
    // 0x802A6640: lbu         $t9, 0x161($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X161);
    skip_0:
    // 0x802A6644: lbu         $t2, 0x5538($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X5538);
    // 0x802A6648: addiu       $a2, $sp, 0x5A
    ctx->r6 = ADD32(ctx->r29, 0X5A);
    // 0x802A664C: beql        $t2, $zero, L_802A6BB0
    if (ctx->r10 == 0) {
        // 0x802A6650: lbu         $t9, 0x161($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X161);
            goto L_802A6BB0;
    }
    goto skip_1;
    // 0x802A6650: lbu         $t9, 0x161($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X161);
    skip_1:
    // 0x802A6654: lbu         $t3, 0x160($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X160);
    // 0x802A6658: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A665C: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A6660: addiu       $a3, $sp, 0x58
    ctx->r7 = ADD32(ctx->r29, 0X58);
    // 0x802A6664: jal         0x80311A2C
    // 0x802A6668: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_6;
    // 0x802A6668: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    after_6:
    // 0x802A666C: lh          $a1, 0x5A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5A);
    // 0x802A6670: slti        $at, $a1, -0x17
    ctx->r1 = SIGNED(ctx->r5) < -0X17 ? 1 : 0;
    // 0x802A6674: bne         $at, $zero, L_802A67E8
    if (ctx->r1 != 0) {
        // 0x802A6678: slti        $at, $a1, 0x18
        ctx->r1 = SIGNED(ctx->r5) < 0X18 ? 1 : 0;
            goto L_802A67E8;
    }
    // 0x802A6678: slti        $at, $a1, 0x18
    ctx->r1 = SIGNED(ctx->r5) < 0X18 ? 1 : 0;
    // 0x802A667C: beq         $at, $zero, L_802A67E8
    if (ctx->r1 == 0) {
        // 0x802A6680: lh          $t4, 0x58($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X58);
            goto L_802A67E8;
    }
    // 0x802A6680: lh          $t4, 0x58($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X58);
    // 0x802A6684: slti        $at, $t4, -0x17
    ctx->r1 = SIGNED(ctx->r12) < -0X17 ? 1 : 0;
    // 0x802A6688: bne         $at, $zero, L_802A67E8
    if (ctx->r1 != 0) {
        // 0x802A668C: slti        $at, $t4, 0x18
        ctx->r1 = SIGNED(ctx->r12) < 0X18 ? 1 : 0;
            goto L_802A67E8;
    }
    // 0x802A668C: slti        $at, $t4, 0x18
    ctx->r1 = SIGNED(ctx->r12) < 0X18 ? 1 : 0;
    // 0x802A6690: beq         $at, $zero, L_802A67E8
    if (ctx->r1 == 0) {
        // 0x802A6694: lui         $t5, 0x801F
        ctx->r13 = S32(0X801F << 16);
            goto L_802A67E8;
    }
    // 0x802A6694: lui         $t5, 0x801F
    ctx->r13 = S32(0X801F << 16);
    // 0x802A6698: lhu         $t5, -0x6176($t5)
    ctx->r13 = MEM_HU(ctx->r13, -0X6176);
    // 0x802A669C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A66A0: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802A66A4: beq         $t5, $zero, L_802A6788
    if (ctx->r13 == 0) {
        // 0x802A66A8: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_802A6788;
    }
    // 0x802A66A8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A66AC: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x802A66B0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A66B4: addiu       $t1, $t1, 0x5524
    ctx->r9 = ADD32(ctx->r9, 0X5524);
    // 0x802A66B8: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A66BC: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802A66C0: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802A66C4: bgez        $v0, L_802A66D4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A66C8: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_802A66D4;
    }
    // 0x802A66C8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A66CC: b           L_802A66D8
    // 0x802A66D0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A66D8;
    // 0x802A66D0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A66D4:
    // 0x802A66D4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A66D8:
    // 0x802A66D8: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802A66DC: lui         $t3, 0x23
    ctx->r11 = S32(0X23 << 16);
    // 0x802A66E0: lhu         $t6, 0xA6($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0XA6);
    // 0x802A66E4: sll         $t8, $t6, 14
    ctx->r24 = S32(ctx->r14 << 14);
    // 0x802A66E8: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x802A66EC: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x802A66F0: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x802A66F4: lh          $t2, 0x24($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X24);
    // 0x802A66F8: slti        $at, $t2, 0x24
    ctx->r1 = SIGNED(ctx->r10) < 0X24 ? 1 : 0;
    // 0x802A66FC: bnel        $at, $zero, L_802A6710
    if (ctx->r1 != 0) {
        // 0x802A6700: lw          $t4, 0x0($t1)
        ctx->r12 = MEM_W(ctx->r9, 0X0);
            goto L_802A6710;
    }
    goto skip_2;
    // 0x802A6700: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    skip_2:
    // 0x802A6704: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
    // 0x802A6708: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x802A670C: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
L_802A6710:
    // 0x802A6710: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x802A6714: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6718: lhu         $v0, 0x9C($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X9C);
    // 0x802A671C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6720: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802A6724: sll         $t5, $v0, 1
    ctx->r13 = S32(ctx->r2 << 1);
    // 0x802A6728: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802A672C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802A6730: addu        $a0, $a0, $t5
    ctx->r4 = ADD32(ctx->r4, ctx->r13);
    // 0x802A6734: addu        $a1, $a1, $t5
    ctx->r5 = ADD32(ctx->r5, ctx->r13);
    // 0x802A6738: lh          $a1, 0x6680($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6680);
    // 0x802A673C: lh          $a0, 0x65D0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X65D0);
    // 0x802A6740: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x802A6744: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802A6748: jal         0x8032C360
    // 0x802A674C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_7;
    // 0x802A674C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_7:
    // 0x802A6750: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A6754: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802A6758: lh          $t9, 0x24($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X24);
    // 0x802A675C: slti        $at, $t9, 0x15
    ctx->r1 = SIGNED(ctx->r25) < 0X15 ? 1 : 0;
    // 0x802A6760: bne         $at, $zero, L_802A6770
    if (ctx->r1 != 0) {
        // 0x802A6764: nop
    
            goto L_802A6770;
    }
    // 0x802A6764: nop

    // 0x802A6768: jal         0x803421E0
    // 0x802A676C: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    func_803421E0_753890(rdram, ctx);
        goto after_8;
    // 0x802A676C: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    after_8:
L_802A6770:
    // 0x802A6770: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A6774: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802A6778: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802A677C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A6780: b           L_802A7634
    // 0x802A6784: sb          $t2, 0x36D($t3)
    MEM_B(0X36D, ctx->r11) = ctx->r10;
        goto L_802A7634;
    // 0x802A6784: sb          $t2, 0x36D($t3)
    MEM_B(0X36D, ctx->r11) = ctx->r10;
L_802A6788:
    // 0x802A6788: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A678C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802A6790: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6794: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A6798: lhu         $t7, 0xA6($t5)
    ctx->r15 = MEM_HU(ctx->r13, 0XA6);
    // 0x802A679C: lh          $t4, 0x24($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X24);
    // 0x802A67A0: negu        $t6, $t7
    ctx->r14 = SUB32(0, ctx->r15);
    // 0x802A67A4: slt         $at, $t4, $t6
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802A67A8: beq         $at, $zero, L_802A67E0
    if (ctx->r1 == 0) {
        // 0x802A67AC: nop
    
            goto L_802A67E0;
    }
    // 0x802A67AC: nop

    // 0x802A67B0: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A67B4: bgez        $v0, L_802A67C4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A67B8: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A67C4;
    }
    // 0x802A67B8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A67BC: b           L_802A67C4
    // 0x802A67C0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A67C4;
    // 0x802A67C0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A67C4:
    // 0x802A67C4: bgez        $v1, L_802A67D4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802A67C8: sra         $t8, $v1, 1
        ctx->r24 = S32(SIGNED(ctx->r3) >> 1);
            goto L_802A67D4;
    }
    // 0x802A67C8: sra         $t8, $v1, 1
    ctx->r24 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802A67CC: addiu       $at, $v1, 0x1
    ctx->r1 = ADD32(ctx->r3, 0X1);
    // 0x802A67D0: sra         $t8, $at, 1
    ctx->r24 = S32(SIGNED(ctx->r1) >> 1);
L_802A67D4:
    // 0x802A67D4: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x802A67D8: b           L_802A7634
    // 0x802A67DC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A7634;
    // 0x802A67DC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802A67E0:
    // 0x802A67E0: b           L_802A6BAC
    // 0x802A67E4: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
        goto L_802A6BAC;
    // 0x802A67E4: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
L_802A67E8:
    // 0x802A67E8: slti        $at, $a1, -0x47
    ctx->r1 = SIGNED(ctx->r5) < -0X47 ? 1 : 0;
    // 0x802A67EC: bne         $at, $zero, L_802A6BA0
    if (ctx->r1 != 0) {
        // 0x802A67F0: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_802A6BA0;
    }
    // 0x802A67F0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A67F4: slti        $at, $a1, 0x48
    ctx->r1 = SIGNED(ctx->r5) < 0X48 ? 1 : 0;
    // 0x802A67F8: beq         $at, $zero, L_802A6BA0
    if (ctx->r1 == 0) {
        // 0x802A67FC: lh          $t9, 0x58($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X58);
            goto L_802A6BA0;
    }
    // 0x802A67FC: lh          $t9, 0x58($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X58);
    // 0x802A6800: slti        $at, $t9, -0x47
    ctx->r1 = SIGNED(ctx->r25) < -0X47 ? 1 : 0;
    // 0x802A6804: bne         $at, $zero, L_802A6BA0
    if (ctx->r1 != 0) {
        // 0x802A6808: slti        $at, $t9, 0x48
        ctx->r1 = SIGNED(ctx->r25) < 0X48 ? 1 : 0;
            goto L_802A6BA0;
    }
    // 0x802A6808: slti        $at, $t9, 0x48
    ctx->r1 = SIGNED(ctx->r25) < 0X48 ? 1 : 0;
    // 0x802A680C: beq         $at, $zero, L_802A6BA0
    if (ctx->r1 == 0) {
        // 0x802A6810: nop
    
            goto L_802A6BA0;
    }
    // 0x802A6810: nop

    // 0x802A6814: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6818: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A681C: lh          $t2, 0x24($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X24);
    // 0x802A6820: slti        $at, $t2, -0x2
    ctx->r1 = SIGNED(ctx->r10) < -0X2 ? 1 : 0;
    // 0x802A6824: beq         $at, $zero, L_802A6A2C
    if (ctx->r1 == 0) {
        // 0x802A6828: nop
    
            goto L_802A6A2C;
    }
    // 0x802A6828: nop

    // 0x802A682C: lh          $a1, 0x5A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5A);
    // 0x802A6830: lui         $a2, 0x8
    ctx->r6 = S32(0X8 << 16);
    // 0x802A6834: ori         $a2, $a2, 0x1
    ctx->r6 = ctx->r6 | 0X1;
    // 0x802A6838: slti        $at, $a1, -0x18
    ctx->r1 = SIGNED(ctx->r5) < -0X18 ? 1 : 0;
    // 0x802A683C: beq         $at, $zero, L_802A68AC
    if (ctx->r1 == 0) {
        // 0x802A6840: lui         $a3, 0x8
        ctx->r7 = S32(0X8 << 16);
            goto L_802A68AC;
    }
    // 0x802A6840: lui         $a3, 0x8
    ctx->r7 = S32(0X8 << 16);
    // 0x802A6844: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A6848: bgez        $v0, L_802A6858
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A684C: sra         $t3, $v0, 2
        ctx->r11 = S32(SIGNED(ctx->r2) >> 2);
            goto L_802A6858;
    }
    // 0x802A684C: sra         $t3, $v0, 2
    ctx->r11 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802A6850: addiu       $at, $v0, 0x3
    ctx->r1 = ADD32(ctx->r2, 0X3);
    // 0x802A6854: sra         $t3, $at, 2
    ctx->r11 = S32(SIGNED(ctx->r1) >> 2);
L_802A6858:
    // 0x802A6858: bgez        $t3, L_802A6868
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802A685C: or          $v0, $t3, $zero
        ctx->r2 = ctx->r11 | 0;
            goto L_802A6868;
    }
    // 0x802A685C: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    // 0x802A6860: b           L_802A686C
    // 0x802A6864: negu        $v1, $t3
    ctx->r3 = SUB32(0, ctx->r11);
        goto L_802A686C;
    // 0x802A6864: negu        $v1, $t3
    ctx->r3 = SUB32(0, ctx->r11);
L_802A6868:
    // 0x802A6868: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A686C:
    // 0x802A686C: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A6870: bne         $at, $zero, L_802A6880
    if (ctx->r1 != 0) {
        // 0x802A6874: nop
    
            goto L_802A6880;
    }
    // 0x802A6874: nop

    // 0x802A6878: b           L_802A6894
    // 0x802A687C: lui         $v1, 0x8
    ctx->r3 = S32(0X8 << 16);
        goto L_802A6894;
    // 0x802A687C: lui         $v1, 0x8
    ctx->r3 = S32(0X8 << 16);
L_802A6880:
    // 0x802A6880: bgez        $v0, L_802A6890
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6884: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A6890;
    }
    // 0x802A6884: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A6888: b           L_802A6890
    // 0x802A688C: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A6890;
    // 0x802A688C: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A6890:
    // 0x802A6890: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802A6894:
    // 0x802A6894: lw          $t5, 0x1C($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X1C);
    // 0x802A6898: subu        $t7, $t5, $v1
    ctx->r15 = SUB32(ctx->r13, ctx->r3);
    // 0x802A689C: sw          $t7, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r15;
    // 0x802A68A0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A68A4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A68A8: lh          $a1, 0x5A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5A);
L_802A68AC:
    // 0x802A68AC: lui         $a2, 0x8
    ctx->r6 = S32(0X8 << 16);
    // 0x802A68B0: slti        $at, $a1, 0x19
    ctx->r1 = SIGNED(ctx->r5) < 0X19 ? 1 : 0;
    // 0x802A68B4: bne         $at, $zero, L_802A6920
    if (ctx->r1 != 0) {
        // 0x802A68B8: ori         $a2, $a2, 0x1
        ctx->r6 = ctx->r6 | 0X1;
            goto L_802A6920;
    }
    // 0x802A68B8: ori         $a2, $a2, 0x1
    ctx->r6 = ctx->r6 | 0X1;
    // 0x802A68BC: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A68C0: bgez        $v0, L_802A68D0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A68C4: sra         $t4, $v0, 2
        ctx->r12 = S32(SIGNED(ctx->r2) >> 2);
            goto L_802A68D0;
    }
    // 0x802A68C4: sra         $t4, $v0, 2
    ctx->r12 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802A68C8: addiu       $at, $v0, 0x3
    ctx->r1 = ADD32(ctx->r2, 0X3);
    // 0x802A68CC: sra         $t4, $at, 2
    ctx->r12 = S32(SIGNED(ctx->r1) >> 2);
L_802A68D0:
    // 0x802A68D0: bgez        $t4, L_802A68E0
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802A68D4: or          $v0, $t4, $zero
        ctx->r2 = ctx->r12 | 0;
            goto L_802A68E0;
    }
    // 0x802A68D4: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
    // 0x802A68D8: b           L_802A68E4
    // 0x802A68DC: negu        $v1, $t4
    ctx->r3 = SUB32(0, ctx->r12);
        goto L_802A68E4;
    // 0x802A68DC: negu        $v1, $t4
    ctx->r3 = SUB32(0, ctx->r12);
L_802A68E0:
    // 0x802A68E0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A68E4:
    // 0x802A68E4: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A68E8: bne         $at, $zero, L_802A68F8
    if (ctx->r1 != 0) {
        // 0x802A68EC: nop
    
            goto L_802A68F8;
    }
    // 0x802A68EC: nop

    // 0x802A68F0: b           L_802A690C
    // 0x802A68F4: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
        goto L_802A690C;
    // 0x802A68F4: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
L_802A68F8:
    // 0x802A68F8: bgez        $v0, L_802A6908
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A68FC: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A6908;
    }
    // 0x802A68FC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A6900: b           L_802A6908
    // 0x802A6904: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A6908;
    // 0x802A6904: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A6908:
    // 0x802A6908: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802A690C:
    // 0x802A690C: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802A6910: addu        $t8, $t6, $v1
    ctx->r24 = ADD32(ctx->r14, ctx->r3);
    // 0x802A6914: sw          $t8, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r24;
    // 0x802A6918: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A691C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6920:
    // 0x802A6920: lh          $t9, 0x58($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X58);
    // 0x802A6924: slti        $at, $t9, -0x18
    ctx->r1 = SIGNED(ctx->r25) < -0X18 ? 1 : 0;
    // 0x802A6928: beq         $at, $zero, L_802A6994
    if (ctx->r1 == 0) {
        // 0x802A692C: addiu       $t9, $zero, 0x6
        ctx->r25 = ADD32(0, 0X6);
            goto L_802A6994;
    }
    // 0x802A692C: addiu       $t9, $zero, 0x6
    ctx->r25 = ADD32(0, 0X6);
    // 0x802A6930: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A6934: bgez        $v0, L_802A6944
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6938: sra         $t2, $v0, 2
        ctx->r10 = S32(SIGNED(ctx->r2) >> 2);
            goto L_802A6944;
    }
    // 0x802A6938: sra         $t2, $v0, 2
    ctx->r10 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802A693C: addiu       $at, $v0, 0x3
    ctx->r1 = ADD32(ctx->r2, 0X3);
    // 0x802A6940: sra         $t2, $at, 2
    ctx->r10 = S32(SIGNED(ctx->r1) >> 2);
L_802A6944:
    // 0x802A6944: bgez        $t2, L_802A6954
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802A6948: or          $v0, $t2, $zero
        ctx->r2 = ctx->r10 | 0;
            goto L_802A6954;
    }
    // 0x802A6948: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    // 0x802A694C: b           L_802A6958
    // 0x802A6950: negu        $v1, $t2
    ctx->r3 = SUB32(0, ctx->r10);
        goto L_802A6958;
    // 0x802A6950: negu        $v1, $t2
    ctx->r3 = SUB32(0, ctx->r10);
L_802A6954:
    // 0x802A6954: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A6958:
    // 0x802A6958: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A695C: bne         $at, $zero, L_802A696C
    if (ctx->r1 != 0) {
        // 0x802A6960: nop
    
            goto L_802A696C;
    }
    // 0x802A6960: nop

    // 0x802A6964: b           L_802A6980
    // 0x802A6968: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
        goto L_802A6980;
    // 0x802A6968: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
L_802A696C:
    // 0x802A696C: bgez        $v0, L_802A697C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6970: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A697C;
    }
    // 0x802A6970: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A6974: b           L_802A697C
    // 0x802A6978: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A697C;
    // 0x802A6978: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A697C:
    // 0x802A697C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802A6980:
    // 0x802A6980: lw          $t3, 0x20($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X20);
    // 0x802A6984: subu        $t5, $t3, $v1
    ctx->r13 = SUB32(ctx->r11, ctx->r3);
    // 0x802A6988: sw          $t5, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r13;
    // 0x802A698C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6990: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6994:
    // 0x802A6994: lh          $t7, 0x58($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X58);
    // 0x802A6998: slti        $at, $t7, 0x19
    ctx->r1 = SIGNED(ctx->r15) < 0X19 ? 1 : 0;
    // 0x802A699C: bne         $at, $zero, L_802A6A08
    if (ctx->r1 != 0) {
        // 0x802A69A0: nop
    
            goto L_802A6A08;
    }
    // 0x802A69A0: nop

    // 0x802A69A4: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A69A8: bgez        $v0, L_802A69B8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A69AC: sra         $t4, $v0, 2
        ctx->r12 = S32(SIGNED(ctx->r2) >> 2);
            goto L_802A69B8;
    }
    // 0x802A69AC: sra         $t4, $v0, 2
    ctx->r12 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802A69B0: addiu       $at, $v0, 0x3
    ctx->r1 = ADD32(ctx->r2, 0X3);
    // 0x802A69B4: sra         $t4, $at, 2
    ctx->r12 = S32(SIGNED(ctx->r1) >> 2);
L_802A69B8:
    // 0x802A69B8: bgez        $t4, L_802A69C8
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802A69BC: or          $v0, $t4, $zero
        ctx->r2 = ctx->r12 | 0;
            goto L_802A69C8;
    }
    // 0x802A69BC: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
    // 0x802A69C0: b           L_802A69CC
    // 0x802A69C4: negu        $v1, $t4
    ctx->r3 = SUB32(0, ctx->r12);
        goto L_802A69CC;
    // 0x802A69C4: negu        $v1, $t4
    ctx->r3 = SUB32(0, ctx->r12);
L_802A69C8:
    // 0x802A69C8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A69CC:
    // 0x802A69CC: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A69D0: bne         $at, $zero, L_802A69E0
    if (ctx->r1 != 0) {
        // 0x802A69D4: nop
    
            goto L_802A69E0;
    }
    // 0x802A69D4: nop

    // 0x802A69D8: b           L_802A69F4
    // 0x802A69DC: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
        goto L_802A69F4;
    // 0x802A69DC: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
L_802A69E0:
    // 0x802A69E0: bgez        $v0, L_802A69F0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A69E4: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A69F0;
    }
    // 0x802A69E4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A69E8: b           L_802A69F0
    // 0x802A69EC: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A69F0;
    // 0x802A69EC: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A69F0:
    // 0x802A69F0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802A69F4:
    // 0x802A69F4: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802A69F8: addu        $t8, $t6, $v1
    ctx->r24 = ADD32(ctx->r14, ctx->r3);
    // 0x802A69FC: sw          $t8, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r24;
    // 0x802A6A00: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6A04: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6A08:
    // 0x802A6A08: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6A0C: addiu       $v1, $v1, 0x5546
    ctx->r3 = ADD32(ctx->r3, 0X5546);
    // 0x802A6A10: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x802A6A14: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x802A6A18: bnel        $at, $zero, L_802A6A2C
    if (ctx->r1 != 0) {
        // 0x802A6A1C: sh          $t9, 0x0($v1)
        MEM_H(0X0, ctx->r3) = ctx->r25;
            goto L_802A6A2C;
    }
    goto skip_3;
    // 0x802A6A1C: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    skip_3:
    // 0x802A6A20: b           L_802A6A2C
    // 0x802A6A24: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
        goto L_802A6A2C;
    // 0x802A6A24: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
    // 0x802A6A28: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
L_802A6A2C:
    // 0x802A6A2C: lui         $t2, 0x801F
    ctx->r10 = S32(0X801F << 16);
    // 0x802A6A30: lhu         $t2, -0x6176($t2)
    ctx->r10 = MEM_HU(ctx->r10, -0X6176);
    // 0x802A6A34: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A6A38: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802A6A3C: beq         $t2, $zero, L_802A6B3C
    if (ctx->r10 == 0) {
        // 0x802A6A40: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_802A6B3C;
    }
    // 0x802A6A40: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A6A44: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A6A48: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802A6A4C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6A50: sll         $t3, $v0, 2
    ctx->r11 = S32(ctx->r2 << 2);
    // 0x802A6A54: subu        $t3, $t3, $v0
    ctx->r11 = SUB32(ctx->r11, ctx->r2);
    // 0x802A6A58: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    // 0x802A6A5C: bgez        $v0, L_802A6A6C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6A60: sra         $t5, $v0, 2
        ctx->r13 = S32(SIGNED(ctx->r2) >> 2);
            goto L_802A6A6C;
    }
    // 0x802A6A60: sra         $t5, $v0, 2
    ctx->r13 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802A6A64: addiu       $at, $v0, 0x3
    ctx->r1 = ADD32(ctx->r2, 0X3);
    // 0x802A6A68: sra         $t5, $at, 2
    ctx->r13 = S32(SIGNED(ctx->r1) >> 2);
L_802A6A6C:
    // 0x802A6A6C: bgez        $t5, L_802A6A7C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802A6A70: or          $v0, $t5, $zero
        ctx->r2 = ctx->r13 | 0;
            goto L_802A6A7C;
    }
    // 0x802A6A70: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x802A6A74: b           L_802A6A80
    // 0x802A6A78: negu        $v1, $t5
    ctx->r3 = SUB32(0, ctx->r13);
        goto L_802A6A80;
    // 0x802A6A78: negu        $v1, $t5
    ctx->r3 = SUB32(0, ctx->r13);
L_802A6A7C:
    // 0x802A6A7C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A6A80:
    // 0x802A6A80: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802A6A84: lui         $t2, 0x23
    ctx->r10 = S32(0X23 << 16);
    // 0x802A6A88: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A6A8C: lhu         $t4, 0xA6($t7)
    ctx->r12 = MEM_HU(ctx->r15, 0XA6);
    // 0x802A6A90: sll         $t6, $t4, 14
    ctx->r14 = S32(ctx->r12 << 14);
    // 0x802A6A94: addu        $t8, $v1, $t6
    ctx->r24 = ADD32(ctx->r3, ctx->r14);
    // 0x802A6A98: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x802A6A9C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6AA0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6AA4: lh          $t9, 0x24($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X24);
    // 0x802A6AA8: slti        $at, $t9, 0x24
    ctx->r1 = SIGNED(ctx->r25) < 0X24 ? 1 : 0;
    // 0x802A6AAC: bne         $at, $zero, L_802A6AC0
    if (ctx->r1 != 0) {
        // 0x802A6AB0: nop
    
            goto L_802A6AC0;
    }
    // 0x802A6AB0: nop

    // 0x802A6AB4: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
    // 0x802A6AB8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6ABC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6AC0:
    // 0x802A6AC0: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802A6AC4: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x802A6AC8: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6ACC: lhu         $v0, 0x9C($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X9C);
    // 0x802A6AD0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6AD4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802A6AD8: sll         $t5, $v0, 1
    ctx->r13 = S32(ctx->r2 << 1);
    // 0x802A6ADC: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802A6AE0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802A6AE4: addu        $a0, $a0, $t5
    ctx->r4 = ADD32(ctx->r4, ctx->r13);
    // 0x802A6AE8: addu        $a1, $a1, $t5
    ctx->r5 = ADD32(ctx->r5, ctx->r13);
    // 0x802A6AEC: lh          $a1, 0x6680($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6680);
    // 0x802A6AF0: lh          $a0, 0x65D0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X65D0);
    // 0x802A6AF4: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x802A6AF8: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x802A6AFC: jal         0x8032C360
    // 0x802A6B00: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_9;
    // 0x802A6B00: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_9:
    // 0x802A6B04: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6B08: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802A6B0C: lh          $t8, 0x24($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X24);
    // 0x802A6B10: slti        $at, $t8, 0x15
    ctx->r1 = SIGNED(ctx->r24) < 0X15 ? 1 : 0;
    // 0x802A6B14: bne         $at, $zero, L_802A6B24
    if (ctx->r1 != 0) {
        // 0x802A6B18: nop
    
            goto L_802A6B24;
    }
    // 0x802A6B18: nop

    // 0x802A6B1C: jal         0x803421E0
    // 0x802A6B20: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    func_803421E0_753890(rdram, ctx);
        goto after_10;
    // 0x802A6B20: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    after_10:
L_802A6B24:
    // 0x802A6B24: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A6B28: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x802A6B2C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802A6B30: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A6B34: b           L_802A7634
    // 0x802A6B38: sb          $t9, 0x36D($t2)
    MEM_B(0X36D, ctx->r10) = ctx->r25;
        goto L_802A7634;
    // 0x802A6B38: sb          $t9, 0x36D($t2)
    MEM_B(0X36D, ctx->r10) = ctx->r25;
L_802A6B3C:
    // 0x802A6B3C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802A6B40: lh          $t3, 0x24($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X24);
    // 0x802A6B44: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A6B48: lhu         $t7, 0xA6($t5)
    ctx->r15 = MEM_HU(ctx->r13, 0XA6);
    // 0x802A6B4C: negu        $t4, $t7
    ctx->r12 = SUB32(0, ctx->r15);
    // 0x802A6B50: slt         $at, $t3, $t4
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802A6B54: beq         $at, $zero, L_802A6B98
    if (ctx->r1 == 0) {
        // 0x802A6B58: nop
    
            goto L_802A6B98;
    }
    // 0x802A6B58: nop

    // 0x802A6B5C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A6B60: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802A6B64: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x802A6B68: bgez        $t6, L_802A6B78
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802A6B6C: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_802A6B78;
    }
    // 0x802A6B6C: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802A6B70: b           L_802A6B7C
    // 0x802A6B74: negu        $v1, $t6
    ctx->r3 = SUB32(0, ctx->r14);
        goto L_802A6B7C;
    // 0x802A6B74: negu        $v1, $t6
    ctx->r3 = SUB32(0, ctx->r14);
L_802A6B78:
    // 0x802A6B78: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802A6B7C:
    // 0x802A6B7C: bgez        $v1, L_802A6B8C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802A6B80: sra         $t8, $v1, 2
        ctx->r24 = S32(SIGNED(ctx->r3) >> 2);
            goto L_802A6B8C;
    }
    // 0x802A6B80: sra         $t8, $v1, 2
    ctx->r24 = S32(SIGNED(ctx->r3) >> 2);
    // 0x802A6B84: addiu       $at, $v1, 0x3
    ctx->r1 = ADD32(ctx->r3, 0X3);
    // 0x802A6B88: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_802A6B8C:
    // 0x802A6B8C: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x802A6B90: b           L_802A7634
    // 0x802A6B94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A7634;
    // 0x802A6B94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802A6B98:
    // 0x802A6B98: b           L_802A6BAC
    // 0x802A6B9C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
        goto L_802A6BAC;
    // 0x802A6B9C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
L_802A6BA0:
    // 0x802A6BA0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A6BA4: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802A6BA8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6BAC:
    // 0x802A6BAC: lbu         $t9, 0x161($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X161);
L_802A6BB0:
    // 0x802A6BB0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A6BB4: bne         $t9, $at, L_802A6DF4
    if (ctx->r25 != ctx->r1) {
        // 0x802A6BB8: nop
    
            goto L_802A6DF4;
    }
    // 0x802A6BB8: nop

    // 0x802A6BBC: lw          $t0, 0x68($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X68);
    // 0x802A6BC0: addiu       $a2, $zero, 0x5
    ctx->r6 = ADD32(0, 0X5);
    // 0x802A6BC4: lw          $v0, 0x16C($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X16C);
    // 0x802A6BC8: lbu         $t2, 0x2($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2);
    // 0x802A6BCC: bnel        $a2, $t2, L_802A6D58
    if (ctx->r6 != ctx->r10) {
        // 0x802A6BD0: lbu         $t3, 0x162($t0)
        ctx->r11 = MEM_BU(ctx->r8, 0X162);
            goto L_802A6D58;
    }
    goto skip_4;
    // 0x802A6BD0: lbu         $t3, 0x162($t0)
    ctx->r11 = MEM_BU(ctx->r8, 0X162);
    skip_4:
    // 0x802A6BD4: lhu         $a0, 0x9C($v0)
    ctx->r4 = MEM_HU(ctx->r2, 0X9C);
    // 0x802A6BD8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6BDC: addiu       $at, $zero, 0x1D
    ctx->r1 = ADD32(0, 0X1D);
    // 0x802A6BE0: lb          $a1, 0xE6($v0)
    ctx->r5 = MEM_B(ctx->r2, 0XE6);
    // 0x802A6BE4: beq         $a0, $at, L_802A6C00
    if (ctx->r4 == ctx->r1) {
        // 0x802A6BE8: lw          $v1, 0x5524($v1)
        ctx->r3 = MEM_W(ctx->r3, 0X5524);
            goto L_802A6C00;
    }
    // 0x802A6BE8: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x802A6BEC: addiu       $at, $zero, 0x41
    ctx->r1 = ADD32(0, 0X41);
    // 0x802A6BF0: beq         $a0, $at, L_802A6C00
    if (ctx->r4 == ctx->r1) {
        // 0x802A6BF4: addiu       $at, $zero, 0x37
        ctx->r1 = ADD32(0, 0X37);
            goto L_802A6C00;
    }
    // 0x802A6BF4: addiu       $at, $zero, 0x37
    ctx->r1 = ADD32(0, 0X37);
    // 0x802A6BF8: bnel        $a0, $at, L_802A6C08
    if (ctx->r4 != ctx->r1) {
        // 0x802A6BFC: lb          $v0, 0xE6($v1)
        ctx->r2 = MEM_B(ctx->r3, 0XE6);
            goto L_802A6C08;
    }
    goto skip_5;
    // 0x802A6BFC: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    skip_5:
L_802A6C00:
    // 0x802A6C00: lb          $a1, 0xE6($v1)
    ctx->r5 = MEM_B(ctx->r3, 0XE6);
    // 0x802A6C04: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
L_802A6C08:
    // 0x802A6C08: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A6C0C: beq         $at, $zero, L_802A6CCC
    if (ctx->r1 == 0) {
        // 0x802A6C10: nop
    
            goto L_802A6CCC;
    }
    // 0x802A6C10: nop

    // 0x802A6C14: lbu         $v1, 0x366($t0)
    ctx->r3 = MEM_BU(ctx->r8, 0X366);
    // 0x802A6C18: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A6C1C: beq         $a2, $v1, L_802A6CCC
    if (ctx->r6 == ctx->r3) {
        // 0x802A6C20: nop
    
            goto L_802A6CCC;
    }
    // 0x802A6C20: nop

    // 0x802A6C24: beq         $v1, $at, L_802A6CCC
    if (ctx->r3 == ctx->r1) {
        // 0x802A6C28: lui         $t5, 0xE
        ctx->r13 = S32(0XE << 16);
            goto L_802A6CCC;
    }
    // 0x802A6C28: lui         $t5, 0xE
    ctx->r13 = S32(0XE << 16);
    // 0x802A6C2C: sw          $t5, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r13;
    // 0x802A6C30: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802A6C34: addiu       $t5, $zero, 0x14
    ctx->r13 = ADD32(0, 0X14);
    // 0x802A6C38: lw          $t0, 0x68($t7)
    ctx->r8 = MEM_W(ctx->r15, 0X68);
    // 0x802A6C3C: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802A6C40: lw          $t3, 0x4C($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X4C);
    // 0x802A6C44: sll         $t6, $t3, 26
    ctx->r14 = S32(ctx->r11 << 26);
    // 0x802A6C48: bltzl       $t6, L_802A6C68
    if (SIGNED(ctx->r14) < 0) {
        // 0x802A6C4C: sb          $t5, 0x65($t0)
        MEM_B(0X65, ctx->r8) = ctx->r13;
            goto L_802A6C68;
    }
    goto skip_6;
    // 0x802A6C4C: sb          $t5, 0x65($t0)
    MEM_B(0X65, ctx->r8) = ctx->r13;
    skip_6:
    // 0x802A6C50: lh          $t8, 0x14C($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X14C);
    // 0x802A6C54: addiu       $t9, $t8, -0x14
    ctx->r25 = ADD32(ctx->r24, -0X14);
    // 0x802A6C58: sh          $t9, 0x14C($t0)
    MEM_H(0X14C, ctx->r8) = ctx->r25;
    // 0x802A6C5C: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x802A6C60: lw          $t0, 0x68($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X68);
    // 0x802A6C64: sb          $t5, 0x65($t0)
    MEM_B(0X65, ctx->r8) = ctx->r13;
L_802A6C68:
    // 0x802A6C68: lw          $t3, 0x0($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X0);
    // 0x802A6C6C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6C70: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802A6C74: sb          $t7, 0x162($t3)
    MEM_B(0X162, ctx->r11) = ctx->r15;
    // 0x802A6C78: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6C7C: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A6C80: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A6C84: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802A6C88: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6C8C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6C90: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802A6C94: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802A6C98: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
    // 0x802A6C9C: jal         0x8032C360
    // 0x802A6CA0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_11;
    // 0x802A6CA0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_11:
    // 0x802A6CA4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A6CA8: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802A6CAC: addiu       $a1, $zero, 0x14
    ctx->r5 = ADD32(0, 0X14);
    // 0x802A6CB0: jal         0x80349280
    // 0x802A6CB4: lw          $a0, 0x68($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X68);
    func_80349280_75A930(rdram, ctx);
        goto after_12;
    // 0x802A6CB4: lw          $a0, 0x68($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X68);
    after_12:
    // 0x802A6CB8: jal         0x802B8890
    // 0x802A6CBC: nop

    func_802B8890_6C9F40(rdram, ctx);
        goto after_13;
    // 0x802A6CBC: nop

    after_13:
    // 0x802A6CC0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6CC4: b           L_802A6DF4
    // 0x802A6CC8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A6DF4;
    // 0x802A6CC8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A6CCC:
    // 0x802A6CCC: bnel        $a1, $v0, L_802A6D18
    if (ctx->r5 != ctx->r2) {
        // 0x802A6CD0: lw          $v0, 0x24($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X24);
            goto L_802A6D18;
    }
    goto skip_7;
    // 0x802A6CD0: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    skip_7:
    // 0x802A6CD4: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A6CD8: bgez        $v0, L_802A6CE8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6CDC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A6CE8;
    }
    // 0x802A6CDC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A6CE0: b           L_802A6CE8
    // 0x802A6CE4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A6CE8;
    // 0x802A6CE4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A6CE8:
    // 0x802A6CE8: sra         $t9, $v1, 3
    ctx->r25 = S32(SIGNED(ctx->r3) >> 3);
    // 0x802A6CEC: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x802A6CF0: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6CF4: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802A6CF8: lw          $t2, 0x24($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X24);
    // 0x802A6CFC: slt         $at, $t2, $at
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802A6D00: beq         $at, $zero, L_802A6DF4
    if (ctx->r1 == 0) {
        // 0x802A6D04: nop
    
            goto L_802A6DF4;
    }
    // 0x802A6D04: nop

    // 0x802A6D08: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
    // 0x802A6D0C: b           L_802A6DF4
    // 0x802A6D10: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
        goto L_802A6DF4;
    // 0x802A6D10: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6D14: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
L_802A6D18:
    // 0x802A6D18: bgez        $v0, L_802A6D28
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A6D1C: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A6D28;
    }
    // 0x802A6D1C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A6D20: b           L_802A6D28
    // 0x802A6D24: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A6D28;
    // 0x802A6D24: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A6D28:
    // 0x802A6D28: sra         $t5, $v1, 3
    ctx->r13 = S32(SIGNED(ctx->r3) >> 3);
    // 0x802A6D2C: sw          $t5, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r13;
    // 0x802A6D30: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6D34: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802A6D38: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x802A6D3C: slt         $at, $t7, $at
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802A6D40: beq         $at, $zero, L_802A6DF4
    if (ctx->r1 == 0) {
        // 0x802A6D44: nop
    
            goto L_802A6DF4;
    }
    // 0x802A6D44: nop

    // 0x802A6D48: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
    // 0x802A6D4C: b           L_802A6DF4
    // 0x802A6D50: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
        goto L_802A6DF4;
    // 0x802A6D50: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
    // 0x802A6D54: lbu         $t3, 0x162($t0)
    ctx->r11 = MEM_BU(ctx->r8, 0X162);
L_802A6D58:
    // 0x802A6D58: bne         $a2, $t3, L_802A6DF4
    if (ctx->r6 != ctx->r11) {
        // 0x802A6D5C: nop
    
            goto L_802A6DF4;
    }
    // 0x802A6D5C: nop

    // 0x802A6D60: lw          $t4, 0x4C($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X4C);
    // 0x802A6D64: sll         $t8, $t4, 29
    ctx->r24 = S32(ctx->r12 << 29);
    // 0x802A6D68: bgez        $t8, L_802A6DF4
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802A6D6C: nop
    
            goto L_802A6DF4;
    }
    // 0x802A6D6C: nop

    // 0x802A6D70: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802A6D74: lhu         $v0, 0x44($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X44);
    // 0x802A6D78: lw          $t7, 0x24($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X24);
    // 0x802A6D7C: sra         $t2, $t9, 8
    ctx->r10 = S32(SIGNED(ctx->r25) >> 8);
    // 0x802A6D80: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A6D84: lhu         $a0, 0x44($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0X44);
    // 0x802A6D88: sra         $t3, $t7, 8
    ctx->r11 = S32(SIGNED(ctx->r15) >> 8);
    // 0x802A6D8C: addu        $t8, $v0, $a0
    ctx->r24 = ADD32(ctx->r2, ctx->r4);
    // 0x802A6D90: mflo        $t5
    ctx->r13 = lo;
    // 0x802A6D94: nop

    // 0x802A6D98: nop

    // 0x802A6D9C: multu       $t3, $a0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A6DA0: mflo        $t4
    ctx->r12 = lo;
    // 0x802A6DA4: addu        $t6, $t5, $t4
    ctx->r14 = ADD32(ctx->r13, ctx->r12);
    // 0x802A6DA8: nop

    // 0x802A6DAC: div         $zero, $t6, $t8
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r24))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r24)));
    // 0x802A6DB0: mflo        $v1
    ctx->r3 = lo;
    // 0x802A6DB4: sll         $t9, $v1, 8
    ctx->r25 = S32(ctx->r3 << 8);
    // 0x802A6DB8: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x802A6DBC: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x802A6DC0: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x802A6DC4: bne         $t8, $zero, L_802A6DD0
    if (ctx->r24 != 0) {
        // 0x802A6DC8: nop
    
            goto L_802A6DD0;
    }
    // 0x802A6DC8: nop

    // 0x802A6DCC: break       7
    do_break(2150264268);
L_802A6DD0:
    // 0x802A6DD0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802A6DD4: bne         $t8, $at, L_802A6DE8
    if (ctx->r24 != ctx->r1) {
        // 0x802A6DD8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802A6DE8;
    }
    // 0x802A6DD8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802A6DDC: bne         $t6, $at, L_802A6DE8
    if (ctx->r14 != ctx->r1) {
        // 0x802A6DE0: nop
    
            goto L_802A6DE8;
    }
    // 0x802A6DE0: nop

    // 0x802A6DE4: break       6
    do_break(2150264292);
L_802A6DE8:
    // 0x802A6DE8: lw          $t7, 0x68($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X68);
    // 0x802A6DEC: sw          $t9, 0x24($t7)
    MEM_W(0X24, ctx->r15) = ctx->r25;
    // 0x802A6DF0: lw          $s0, 0x0($t1)
    ctx->r16 = MEM_W(ctx->r9, 0X0);
L_802A6DF4:
    // 0x802A6DF4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A6DF8: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x802A6DFC: lh          $v0, 0x24($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X24);
    // 0x802A6E00: lh          $a0, 0xAE($v1)
    ctx->r4 = MEM_H(ctx->r3, 0XAE);
    // 0x802A6E04: negu        $t3, $a0
    ctx->r11 = SUB32(0, ctx->r4);
    // 0x802A6E08: slt         $at, $v0, $t3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802A6E0C: beq         $at, $zero, L_802A6F78
    if (ctx->r1 == 0) {
        // 0x802A6E10: sll         $t9, $a0, 1
        ctx->r25 = S32(ctx->r4 << 1);
            goto L_802A6F78;
    }
    // 0x802A6E10: sll         $t9, $a0, 1
    ctx->r25 = S32(ctx->r4 << 1);
    // 0x802A6E14: jal         0x8034A684
    // 0x802A6E18: nop

    spawn_dizzy_stars_big(rdram, ctx);
        goto after_14;
    // 0x802A6E18: nop

    after_14:
    // 0x802A6E1C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A6E20: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802A6E24: lhu         $v0, 0x44($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X44);
    // 0x802A6E28: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    // 0x802A6E2C: bnel        $at, $zero, L_802A6EA4
    if (ctx->r1 != 0) {
        // 0x802A6E30: slti        $at, $v0, 0x15
        ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
            goto L_802A6EA4;
    }
    goto skip_8;
    // 0x802A6E30: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
    skip_8:
    // 0x802A6E34: jal         0x803421E0
    // 0x802A6E38: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    func_803421E0_753890(rdram, ctx);
        goto after_15;
    // 0x802A6E38: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    after_15:
    // 0x802A6E3C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6E40: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6E44: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6E48: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x802A6E4C: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802A6E50: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6E54: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A6E58: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802A6E5C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802A6E60: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A6E64: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6E68: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    // 0x802A6E6C: jal         0x8032C360
    // 0x802A6E70: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_16;
    // 0x802A6E70: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_16:
    // 0x802A6E74: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A6E78: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x802A6E7C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A6E80: addiu       $a1, $zero, 0x19
    ctx->r5 = ADD32(0, 0X19);
    // 0x802A6E84: beq         $t8, $zero, L_802A6F58
    if (ctx->r24 == 0) {
        // 0x802A6E88: addiu       $a2, $zero, 0x37
        ctx->r6 = ADD32(0, 0X37);
            goto L_802A6F58;
    }
    // 0x802A6E88: addiu       $a2, $zero, 0x37
    ctx->r6 = ADD32(0, 0X37);
    // 0x802A6E8C: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A6E90: jal         0x801373CC
    // 0x802A6E94: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_17;
    // 0x802A6E94: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_17:
    // 0x802A6E98: b           L_802A6F58
    // 0x802A6E9C: nop

        goto L_802A6F58;
    // 0x802A6E9C: nop

    // 0x802A6EA0: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
L_802A6EA4:
    // 0x802A6EA4: bne         $at, $zero, L_802A6F18
    if (ctx->r1 != 0) {
        // 0x802A6EA8: nop
    
            goto L_802A6F18;
    }
    // 0x802A6EA8: nop

    // 0x802A6EAC: jal         0x803421E0
    // 0x802A6EB0: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    func_803421E0_753890(rdram, ctx);
        goto after_18;
    // 0x802A6EB0: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    after_18:
    // 0x802A6EB4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6EB8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6EBC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6EC0: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x802A6EC4: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802A6EC8: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6ECC: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A6ED0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802A6ED4: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802A6ED8: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A6EDC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6EE0: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    // 0x802A6EE4: jal         0x8032C360
    // 0x802A6EE8: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    play_sound_effect_at_location(rdram, ctx);
        goto after_19;
    // 0x802A6EE8: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_19:
    // 0x802A6EEC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A6EF0: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x802A6EF4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A6EF8: addiu       $a1, $zero, 0x12
    ctx->r5 = ADD32(0, 0X12);
    // 0x802A6EFC: beq         $t7, $zero, L_802A6F58
    if (ctx->r15 == 0) {
        // 0x802A6F00: addiu       $a2, $zero, 0x32
        ctx->r6 = ADD32(0, 0X32);
            goto L_802A6F58;
    }
    // 0x802A6F00: addiu       $a2, $zero, 0x32
    ctx->r6 = ADD32(0, 0X32);
    // 0x802A6F04: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A6F08: jal         0x801373CC
    // 0x802A6F0C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_20;
    // 0x802A6F0C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_20:
    // 0x802A6F10: b           L_802A6F58
    // 0x802A6F14: nop

        goto L_802A6F58;
    // 0x802A6F14: nop

L_802A6F18:
    // 0x802A6F18: jal         0x803421E0
    // 0x802A6F1C: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    func_803421E0_753890(rdram, ctx);
        goto after_21;
    // 0x802A6F1C: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_21:
    // 0x802A6F20: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6F24: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6F28: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6F2C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802A6F30: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x802A6F34: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6F38: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A6F3C: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802A6F40: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802A6F44: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A6F48: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6F4C: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x802A6F50: jal         0x8032C360
    // 0x802A6F54: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    play_sound_effect_at_location(rdram, ctx);
        goto after_22;
    // 0x802A6F54: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_22:
L_802A6F58:
    // 0x802A6F58: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6F5C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6F60: lw          $t4, 0x4C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4C);
    // 0x802A6F64: sll         $t8, $t4, 26
    ctx->r24 = S32(ctx->r12 << 26);
    // 0x802A6F68: bltz        $t8, L_802A718C
    if (SIGNED(ctx->r24) < 0) {
        // 0x802A6F6C: nop
    
            goto L_802A718C;
    }
    // 0x802A6F6C: nop

    // 0x802A6F70: b           L_802A718C
    // 0x802A6F74: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802A718C;
    // 0x802A6F74: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
L_802A6F78:
    // 0x802A6F78: sra         $t2, $t9, 2
    ctx->r10 = S32(SIGNED(ctx->r25) >> 2);
    // 0x802A6F7C: negu        $t7, $t2
    ctx->r15 = SUB32(0, ctx->r10);
    // 0x802A6F80: slt         $at, $v0, $t7
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802A6F84: beq         $at, $zero, L_802A713C
    if (ctx->r1 == 0) {
        // 0x802A6F88: addiu       $t5, $zero, 0x1
        ctx->r13 = ADD32(0, 0X1);
            goto L_802A713C;
    }
    // 0x802A6F88: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802A6F8C: jal         0x8034A684
    // 0x802A6F90: nop

    spawn_dizzy_stars_big(rdram, ctx);
        goto after_23;
    // 0x802A6F90: nop

    after_23:
    // 0x802A6F94: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A6F98: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x802A6F9C: lhu         $v0, 0x44($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X44);
    // 0x802A6FA0: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    // 0x802A6FA4: bnel        $at, $zero, L_802A701C
    if (ctx->r1 != 0) {
        // 0x802A6FA8: slti        $at, $v0, 0x15
        ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
            goto L_802A701C;
    }
    goto skip_9;
    // 0x802A6FA8: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
    skip_9:
    // 0x802A6FAC: jal         0x803421E0
    // 0x802A6FB0: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    func_803421E0_753890(rdram, ctx);
        goto after_24;
    // 0x802A6FB0: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    after_24:
    // 0x802A6FB4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A6FB8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A6FBC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A6FC0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802A6FC4: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x802A6FC8: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A6FCC: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A6FD0: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802A6FD4: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802A6FD8: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A6FDC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A6FE0: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x802A6FE4: jal         0x8032C360
    // 0x802A6FE8: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    play_sound_effect_at_location(rdram, ctx);
        goto after_25;
    // 0x802A6FE8: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_25:
    // 0x802A6FEC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A6FF0: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x802A6FF4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A6FF8: addiu       $a1, $zero, 0x19
    ctx->r5 = ADD32(0, 0X19);
    // 0x802A6FFC: beq         $t6, $zero, L_802A70F4
    if (ctx->r14 == 0) {
        // 0x802A7000: addiu       $a2, $zero, 0x37
        ctx->r6 = ADD32(0, 0X37);
            goto L_802A70F4;
    }
    // 0x802A7000: addiu       $a2, $zero, 0x37
    ctx->r6 = ADD32(0, 0X37);
    // 0x802A7004: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A7008: jal         0x801373CC
    // 0x802A700C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_26;
    // 0x802A700C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_26:
    // 0x802A7010: b           L_802A70F4
    // 0x802A7014: nop

        goto L_802A70F4;
    // 0x802A7014: nop

    // 0x802A7018: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
L_802A701C:
    // 0x802A701C: bne         $at, $zero, L_802A7090
    if (ctx->r1 != 0) {
        // 0x802A7020: nop
    
            goto L_802A7090;
    }
    // 0x802A7020: nop

    // 0x802A7024: jal         0x803421E0
    // 0x802A7028: addiu       $a0, $zero, 0x11
    ctx->r4 = ADD32(0, 0X11);
    func_803421E0_753890(rdram, ctx);
        goto after_27;
    // 0x802A7028: addiu       $a0, $zero, 0x11
    ctx->r4 = ADD32(0, 0X11);
    after_27:
    // 0x802A702C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7030: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7034: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A7038: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802A703C: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802A7040: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A7044: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A7048: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802A704C: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802A7050: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A7054: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A7058: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x802A705C: jal         0x8032C360
    // 0x802A7060: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_28;
    // 0x802A7060: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_28:
    // 0x802A7064: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A7068: lbu         $t2, 0x5538($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X5538);
    // 0x802A706C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A7070: addiu       $a1, $zero, 0x12
    ctx->r5 = ADD32(0, 0X12);
    // 0x802A7074: beq         $t2, $zero, L_802A70F4
    if (ctx->r10 == 0) {
        // 0x802A7078: addiu       $a2, $zero, 0x32
        ctx->r6 = ADD32(0, 0X32);
            goto L_802A70F4;
    }
    // 0x802A7078: addiu       $a2, $zero, 0x32
    ctx->r6 = ADD32(0, 0X32);
    // 0x802A707C: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A7080: jal         0x801373CC
    // 0x802A7084: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_29;
    // 0x802A7084: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_29:
    // 0x802A7088: b           L_802A70F4
    // 0x802A708C: nop

        goto L_802A70F4;
    // 0x802A708C: nop

L_802A7090:
    // 0x802A7090: jal         0x803421E0
    // 0x802A7094: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    func_803421E0_753890(rdram, ctx);
        goto after_30;
    // 0x802A7094: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_30:
    // 0x802A7098: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A709C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A70A0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A70A4: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802A70A8: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x802A70AC: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A70B0: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A70B4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802A70B8: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x802A70BC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A70C0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A70C4: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
    // 0x802A70C8: jal         0x8032C360
    // 0x802A70CC: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    play_sound_effect_at_location(rdram, ctx);
        goto after_31;
    // 0x802A70CC: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    after_31:
    // 0x802A70D0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A70D4: lbu         $t5, 0x5538($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X5538);
    // 0x802A70D8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A70DC: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x802A70E0: beq         $t5, $zero, L_802A70F4
    if (ctx->r13 == 0) {
        // 0x802A70E4: addiu       $a2, $zero, 0x2D
        ctx->r6 = ADD32(0, 0X2D);
            goto L_802A70F4;
    }
    // 0x802A70E4: addiu       $a2, $zero, 0x2D
    ctx->r6 = ADD32(0, 0X2D);
    // 0x802A70E8: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A70EC: jal         0x801373CC
    // 0x802A70F0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_32;
    // 0x802A70F0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_32:
L_802A70F4:
    // 0x802A70F4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A70F8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A70FC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A7100: lw          $t4, 0x4C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4C);
    // 0x802A7104: sll         $t8, $t4, 26
    ctx->r24 = S32(ctx->r12 << 26);
    // 0x802A7108: bltz        $t8, L_802A718C
    if (SIGNED(ctx->r24) < 0) {
        // 0x802A710C: nop
    
            goto L_802A718C;
    }
    // 0x802A710C: nop

    // 0x802A7110: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802A7114: lh          $t9, 0x14C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X14C);
    // 0x802A7118: lbu         $t7, 0x8A($t2)
    ctx->r15 = MEM_BU(ctx->r10, 0X8A);
    // 0x802A711C: sra         $t3, $t7, 1
    ctx->r11 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802A7120: subu        $v0, $t9, $t3
    ctx->r2 = SUB32(ctx->r25, ctx->r11);
    // 0x802A7124: bgez        $v0, L_802A7134
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7128: nop
    
            goto L_802A7134;
    }
    // 0x802A7128: nop

    // 0x802A712C: b           L_802A718C
    // 0x802A7130: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802A718C;
    // 0x802A7130: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
L_802A7134:
    // 0x802A7134: b           L_802A718C
    // 0x802A7138: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
        goto L_802A718C;
    // 0x802A7138: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
L_802A713C:
    // 0x802A713C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A7140: sh          $t5, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r13;
    // 0x802A7144: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802A7148: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802A714C: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802A7150: lhu         $a1, 0x9C($v1)
    ctx->r5 = MEM_HU(ctx->r3, 0X9C);
    // 0x802A7154: lhu         $a0, 0x7C($v1)
    ctx->r4 = MEM_HU(ctx->r3, 0X7C);
    // 0x802A7158: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802A715C: lbu         $t6, 0x160($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X160);
    // 0x802A7160: jal         0x8032C5A8
    // 0x802A7164: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_footstep_sfx(rdram, ctx);
        goto after_33;
    // 0x802A7164: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_33:
    // 0x802A7168: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A716C: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x802A7170: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A7174: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    // 0x802A7178: beq         $t8, $zero, L_802A718C
    if (ctx->r24 == 0) {
        // 0x802A717C: addiu       $a2, $zero, 0x2D
        ctx->r6 = ADD32(0, 0X2D);
            goto L_802A718C;
    }
    // 0x802A717C: addiu       $a2, $zero, 0x2D
    ctx->r6 = ADD32(0, 0X2D);
    // 0x802A7180: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A7184: jal         0x801373CC
    // 0x802A7188: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    do_rumble(rdram, ctx);
        goto after_34;
    // 0x802A7188: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_34:
L_802A718C:
    // 0x802A718C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7190: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7194: lbu         $t2, 0x162($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X162);
    // 0x802A7198: andi        $t7, $t2, 0xF
    ctx->r15 = ctx->r10 & 0XF;
    // 0x802A719C: addiu       $t9, $t7, -0x1
    ctx->r25 = ADD32(ctx->r15, -0X1);
    // 0x802A71A0: sltiu       $at, $t9, 0x7
    ctx->r1 = ctx->r25 < 0X7 ? 1 : 0;
    // 0x802A71A4: beq         $at, $zero, L_802A74BC
    if (ctx->r1 == 0) {
        // 0x802A71A8: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802A74BC;
    }
    // 0x802A71A8: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802A71AC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A71B0: addu        $at, $at, $t9
    gpr jr_addend_802A71B8 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802A71B4: lw          $t9, -0x5200($at)
    ctx->r25 = ADD32(ctx->r1, -0X5200);
    // 0x802A71B8: jr          $t9
    // 0x802A71BC: nop

    switch (jr_addend_802A71B8 >> 2) {
        case 0: goto L_802A71C0; break;
        case 1: goto L_802A71C0; break;
        case 2: goto L_802A71C0; break;
        case 3: goto L_802A7480; break;
        case 4: goto L_802A7480; break;
        case 5: goto L_802A7480; break;
        case 6: goto L_802A7480; break;
        default: switch_error(__func__, 0x802A71B8, 0x803BAE00);
    }
    // 0x802A71BC: nop

L_802A71C0:
    // 0x802A71C0: lhu         $t3, 0x0($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X0);
    // 0x802A71C4: addiu       $at, $zero, 0x6A
    ctx->r1 = ADD32(0, 0X6A);
    // 0x802A71C8: bne         $t3, $at, L_802A7284
    if (ctx->r11 != ctx->r1) {
        // 0x802A71CC: nop
    
            goto L_802A7284;
    }
    // 0x802A71CC: nop

    // 0x802A71D0: jal         0x802A60C4
    // 0x802A71D4: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_35;
    // 0x802A71D4: nop

    after_35:
    // 0x802A71D8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A71DC: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802A71E0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802A71E4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A71E8: sb          $v1, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r3;
    // 0x802A71EC: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802A71F0: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    // 0x802A71F4: lhu         $t6, 0x9C($t4)
    ctx->r14 = MEM_HU(ctx->r12, 0X9C);
    // 0x802A71F8: bne         $t6, $at, L_802A7284
    if (ctx->r14 != ctx->r1) {
        // 0x802A71FC: nop
    
            goto L_802A7284;
    }
    // 0x802A71FC: nop

    // 0x802A7200: jal         0x8032AAF0
    // 0x802A7204: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    load_animal(rdram, ctx);
        goto after_36;
    // 0x802A7204: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    after_36:
    // 0x802A7208: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A720C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7210: lh          $v0, 0x24($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X24);
    // 0x802A7214: slti        $at, $v0, -0x14
    ctx->r1 = SIGNED(ctx->r2) < -0X14 ? 1 : 0;
    // 0x802A7218: beql        $at, $zero, L_802A7254
    if (ctx->r1 == 0) {
        // 0x802A721C: slti        $at, $v0, -0xA
        ctx->r1 = SIGNED(ctx->r2) < -0XA ? 1 : 0;
            goto L_802A7254;
    }
    goto skip_10;
    // 0x802A721C: slti        $at, $v0, -0xA
    ctx->r1 = SIGNED(ctx->r2) < -0XA ? 1 : 0;
    skip_10:
    // 0x802A7220: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A7224: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A7228: jal         0x8029B7D0
    // 0x802A722C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    static_2_8029B7D0(rdram, ctx);
        goto after_37;
    // 0x802A722C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    after_37:
    // 0x802A7230: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A7234: addiu       $a1, $zero, 0xF
    ctx->r5 = ADD32(0, 0XF);
    // 0x802A7238: addiu       $a2, $zero, 0x46
    ctx->r6 = ADD32(0, 0X46);
    // 0x802A723C: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A7240: jal         0x801373CC
    // 0x802A7244: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    do_rumble(rdram, ctx);
        goto after_38;
    // 0x802A7244: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    after_38:
    // 0x802A7248: b           L_802A7284
    // 0x802A724C: nop

        goto L_802A7284;
    // 0x802A724C: nop

    // 0x802A7250: slti        $at, $v0, -0xA
    ctx->r1 = SIGNED(ctx->r2) < -0XA ? 1 : 0;
L_802A7254:
    // 0x802A7254: beq         $at, $zero, L_802A7284
    if (ctx->r1 == 0) {
        // 0x802A7258: nop
    
            goto L_802A7284;
    }
    // 0x802A7258: nop

    // 0x802A725C: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A7260: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A7264: jal         0x8029B7D0
    // 0x802A7268: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    static_2_8029B7D0(rdram, ctx);
        goto after_39;
    // 0x802A7268: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    after_39:
    // 0x802A726C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802A7270: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x802A7274: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
    // 0x802A7278: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    // 0x802A727C: jal         0x801373CC
    // 0x802A7280: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    do_rumble(rdram, ctx);
        goto after_40;
    // 0x802A7280: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    after_40:
L_802A7284:
    // 0x802A7284: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7288: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A728C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802A7290: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x802A7294: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x802A7298: beql        $at, $zero, L_802A72C8
    if (ctx->r1 == 0) {
        // 0x802A729C: slti        $at, $v0, 0x19
        ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
            goto L_802A72C8;
    }
    goto skip_11;
    // 0x802A729C: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
    skip_11:
    // 0x802A72A0: jal         0x802A4390
    // 0x802A72A4: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_41;
    // 0x802A72A4: nop

    after_41:
    // 0x802A72A8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A72AC: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x802A72B0: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802A72B4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A72B8: sb          $t8, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r24;
    // 0x802A72BC: b           L_802A74BC
    // 0x802A72C0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A72C0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A72C4: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
L_802A72C8:
    // 0x802A72C8: beql        $at, $zero, L_802A72F8
    if (ctx->r1 == 0) {
        // 0x802A72CC: slti        $at, $v0, 0x2B
        ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
            goto L_802A72F8;
    }
    goto skip_12;
    // 0x802A72CC: slti        $at, $v0, 0x2B
    ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
    skip_12:
    // 0x802A72D0: jal         0x802A4CB8
    // 0x802A72D4: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_42;
    // 0x802A72D4: nop

    after_42:
    // 0x802A72D8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802A72DC: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x802A72E0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802A72E4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A72E8: sb          $t7, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r15;
    // 0x802A72EC: b           L_802A74BC
    // 0x802A72F0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A72F0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A72F4: slti        $at, $v0, 0x2B
    ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
L_802A72F8:
    // 0x802A72F8: beql        $at, $zero, L_802A7328
    if (ctx->r1 == 0) {
        // 0x802A72FC: slti        $at, $v0, 0x40
        ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
            goto L_802A7328;
    }
    goto skip_13;
    // 0x802A72FC: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    skip_13:
    // 0x802A7300: jal         0x802A5C80
    // 0x802A7304: nop

    func_802A5C80_6B7330(rdram, ctx);
        goto after_43;
    // 0x802A7304: nop

    after_43:
    // 0x802A7308: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A730C: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802A7310: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802A7314: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7318: sb          $t3, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r11;
    // 0x802A731C: b           L_802A74BC
    // 0x802A7320: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A7320: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7324: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
L_802A7328:
    // 0x802A7328: beq         $at, $zero, L_802A734C
    if (ctx->r1 == 0) {
        // 0x802A732C: addiu       $t4, $zero, 0xA1
        ctx->r12 = ADD32(0, 0XA1);
            goto L_802A734C;
    }
    // 0x802A732C: addiu       $t4, $zero, 0xA1
    ctx->r12 = ADD32(0, 0XA1);
    // 0x802A7330: sh          $t4, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r12;
    // 0x802A7334: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A7338: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802A733C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7340: sb          $v1, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r3;
    // 0x802A7344: b           L_802A74BC
    // 0x802A7348: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A7348: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A734C:
    // 0x802A734C: slti        $at, $v0, 0x52
    ctx->r1 = SIGNED(ctx->r2) < 0X52 ? 1 : 0;
    // 0x802A7350: beq         $at, $zero, L_802A73B0
    if (ctx->r1 == 0) {
        // 0x802A7354: addiu       $t8, $zero, 0x1
        ctx->r24 = ADD32(0, 0X1);
            goto L_802A73B0;
    }
    // 0x802A7354: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802A7358: sb          $t8, 0x54($sp)
    MEM_B(0X54, ctx->r29) = ctx->r24;
    // 0x802A735C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802A7360: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802A7364: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x802A7368: jal         0x802B38FC
    // 0x802A736C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B38FC_6C4FAC(rdram, ctx);
        goto after_44;
    // 0x802A736C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_44:
    // 0x802A7370: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7374: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7378: addiu       $t9, $zero, 0x8
    ctx->r25 = ADD32(0, 0X8);
    // 0x802A737C: addiu       $t3, $zero, 0x8
    ctx->r11 = ADD32(0, 0X8);
    // 0x802A7380: lh          $t2, 0x24($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X24);
    // 0x802A7384: sra         $t7, $t2, 1
    ctx->r15 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802A7388: subu        $v0, $t9, $t7
    ctx->r2 = SUB32(ctx->r25, ctx->r15);
    // 0x802A738C: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x802A7390: beql        $at, $zero, L_802A73A4
    if (ctx->r1 == 0) {
        // 0x802A7394: sh          $v0, 0x24($s0)
        MEM_H(0X24, ctx->r16) = ctx->r2;
            goto L_802A73A4;
    }
    goto skip_14;
    // 0x802A7394: sh          $v0, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r2;
    skip_14:
    // 0x802A7398: b           L_802A73A4
    // 0x802A739C: sh          $t3, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r11;
        goto L_802A73A4;
    // 0x802A739C: sh          $t3, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r11;
    // 0x802A73A0: sh          $v0, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r2;
L_802A73A4:
    // 0x802A73A4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A73A8: b           L_802A74BC
    // 0x802A73AC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A73AC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A73B0:
    // 0x802A73B0: slti        $at, $v0, 0x6B
    ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
    // 0x802A73B4: beql        $at, $zero, L_802A73E4
    if (ctx->r1 == 0) {
        // 0x802A73B8: slti        $at, $v0, 0x7C
        ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
            goto L_802A73E4;
    }
    goto skip_15;
    // 0x802A73B8: slti        $at, $v0, 0x7C
    ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
    skip_15:
    // 0x802A73BC: jal         0x802A60C4
    // 0x802A73C0: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_45;
    // 0x802A73C0: nop

    after_45:
    // 0x802A73C4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A73C8: lw          $t4, 0x5530($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5530);
    // 0x802A73CC: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802A73D0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A73D4: sb          $t5, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r13;
    // 0x802A73D8: b           L_802A74BC
    // 0x802A73DC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A73DC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A73E0: slti        $at, $v0, 0x7C
    ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
L_802A73E4:
    // 0x802A73E4: beql        $at, $zero, L_802A7414
    if (ctx->r1 == 0) {
        // 0x802A73E8: slti        $at, $v0, 0x91
        ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
            goto L_802A7414;
    }
    goto skip_16;
    // 0x802A73E8: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
    skip_16:
    // 0x802A73EC: jal         0x802A5D64
    // 0x802A73F0: nop

    func_802A5D64_6B7414(rdram, ctx);
        goto after_46;
    // 0x802A73F0: nop

    after_46:
    // 0x802A73F4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A73F8: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802A73FC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802A7400: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7404: sb          $t6, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r14;
    // 0x802A7408: b           L_802A74BC
    // 0x802A740C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A740C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7410: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
L_802A7414:
    // 0x802A7414: beq         $at, $zero, L_802A742C
    if (ctx->r1 == 0) {
        // 0x802A7418: addiu       $t2, $zero, 0x6
        ctx->r10 = ADD32(0, 0X6);
            goto L_802A742C;
    }
    // 0x802A7418: addiu       $t2, $zero, 0x6
    ctx->r10 = ADD32(0, 0X6);
    // 0x802A741C: sb          $t2, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r10;
    // 0x802A7420: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7424: b           L_802A74BC
    // 0x802A7428: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A7428: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A742C:
    // 0x802A742C: slti        $at, $v0, 0xA3
    ctx->r1 = SIGNED(ctx->r2) < 0XA3 ? 1 : 0;
    // 0x802A7430: beql        $at, $zero, L_802A744C
    if (ctx->r1 == 0) {
        // 0x802A7434: slti        $at, $v0, 0xBA
        ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
            goto L_802A744C;
    }
    goto skip_17;
    // 0x802A7434: slti        $at, $v0, 0xBA
    ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
    skip_17:
    // 0x802A7438: sb          $v1, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r3;
    // 0x802A743C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7440: b           L_802A74BC
    // 0x802A7444: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A7444: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A7448: slti        $at, $v0, 0xBA
    ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
L_802A744C:
    // 0x802A744C: beq         $at, $zero, L_802A7464
    if (ctx->r1 == 0) {
        // 0x802A7450: addiu       $t9, $zero, 0x6
        ctx->r25 = ADD32(0, 0X6);
            goto L_802A7464;
    }
    // 0x802A7450: addiu       $t9, $zero, 0x6
    ctx->r25 = ADD32(0, 0X6);
    // 0x802A7454: sb          $t9, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r25;
    // 0x802A7458: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A745C: b           L_802A74BC
    // 0x802A7460: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A7460: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A7464:
    // 0x802A7464: slti        $at, $v0, 0xCD
    ctx->r1 = SIGNED(ctx->r2) < 0XCD ? 1 : 0;
    // 0x802A7468: beq         $at, $zero, L_802A74BC
    if (ctx->r1 == 0) {
        // 0x802A746C: addiu       $t7, $zero, 0x6
        ctx->r15 = ADD32(0, 0X6);
            goto L_802A74BC;
    }
    // 0x802A746C: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x802A7470: sb          $t7, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r15;
    // 0x802A7474: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7478: b           L_802A74BC
    // 0x802A747C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
        goto L_802A74BC;
    // 0x802A747C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A7480:
    // 0x802A7480: lhu         $t3, 0x0($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X0);
    // 0x802A7484: addiu       $at, $zero, 0xB8
    ctx->r1 = ADD32(0, 0XB8);
    // 0x802A7488: addiu       $t6, $zero, 0x6
    ctx->r14 = ADD32(0, 0X6);
    // 0x802A748C: bnel        $t3, $at, L_802A74B4
    if (ctx->r11 != ctx->r1) {
        // 0x802A7490: sb          $t6, 0x162($s0)
        MEM_B(0X162, ctx->r16) = ctx->r14;
            goto L_802A74B4;
    }
    goto skip_18;
    // 0x802A7490: sb          $t6, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r14;
    skip_18:
    // 0x802A7494: jal         0x802A4E74
    // 0x802A7498: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_47;
    // 0x802A7498: nop

    after_47:
    // 0x802A749C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A74A0: lw          $t4, 0x5530($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5530);
    // 0x802A74A4: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x802A74A8: b           L_802A74B4
    // 0x802A74AC: sb          $t5, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r13;
        goto L_802A74B4;
    // 0x802A74AC: sb          $t5, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r13;
    // 0x802A74B0: sb          $t6, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r14;
L_802A74B4:
    // 0x802A74B4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A74B8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
L_802A74BC:
    // 0x802A74BC: lbu         $t8, 0x161($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X161);
    // 0x802A74C0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A74C4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A74C8: bnel        $t8, $at, L_802A74DC
    if (ctx->r24 != ctx->r1) {
        // 0x802A74CC: lbu         $t9, 0x160($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X160);
            goto L_802A74DC;
    }
    goto skip_19;
    // 0x802A74CC: lbu         $t9, 0x160($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X160);
    skip_19:
    // 0x802A74D0: b           L_802A7634
    // 0x802A74D4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A7634;
    // 0x802A74D4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A74D8: lbu         $t9, 0x160($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X160);
L_802A74DC:
    // 0x802A74DC: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802A74E0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A74E4: bne         $t9, $at, L_802A7538
    if (ctx->r25 != ctx->r1) {
        // 0x802A74E8: lhu         $v0, 0x9C($t2)
        ctx->r2 = MEM_HU(ctx->r10, 0X9C);
            goto L_802A7538;
    }
    // 0x802A74E8: lhu         $v0, 0x9C($t2)
    ctx->r2 = MEM_HU(ctx->r10, 0X9C);
    // 0x802A74EC: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x802A74F0: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802A74F4: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x802A74F8: sra         $t3, $t7, 6
    ctx->r11 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802A74FC: sll         $t5, $t3, 7
    ctx->r13 = S32(ctx->r11 << 7);
    // 0x802A7500: addu        $t5, $t5, $t3
    ctx->r13 = ADD32(ctx->r13, ctx->r11);
    // 0x802A7504: sra         $t6, $t4, 6
    ctx->r14 = S32(SIGNED(ctx->r12) >> 6);
    // 0x802A7508: sll         $t8, $t6, 3
    ctx->r24 = S32(ctx->r14 << 3);
    // 0x802A750C: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802A7510: addu        $t2, $t5, $t8
    ctx->r10 = ADD32(ctx->r13, ctx->r24);
    // 0x802A7514: addu        $t9, $t9, $t2
    ctx->r25 = ADD32(ctx->r25, ctx->r10);
    // 0x802A7518: lbu         $t9, 0x743($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X743);
    // 0x802A751C: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A7520: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x802A7524: subu        $t7, $t7, $t9
    ctx->r15 = SUB32(ctx->r15, ctx->r25);
    // 0x802A7528: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802A752C: addu        $v1, $v1, $t7
    ctx->r3 = ADD32(ctx->r3, ctx->r15);
    // 0x802A7530: b           L_802A7580
    // 0x802A7534: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
        goto L_802A7580;
    // 0x802A7534: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
L_802A7538:
    // 0x802A7538: lh          $t3, 0x4($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X4);
    // 0x802A753C: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x802A7540: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x802A7544: sra         $t4, $t3, 6
    ctx->r12 = S32(SIGNED(ctx->r11) >> 6);
    // 0x802A7548: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802A754C: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802A7550: sra         $t8, $t5, 6
    ctx->r24 = S32(SIGNED(ctx->r13) >> 6);
    // 0x802A7554: sll         $t2, $t8, 3
    ctx->r10 = S32(ctx->r24 << 3);
    // 0x802A7558: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802A755C: addu        $t9, $t6, $t2
    ctx->r25 = ADD32(ctx->r14, ctx->r10);
    // 0x802A7560: addu        $t7, $t7, $t9
    ctx->r15 = ADD32(ctx->r15, ctx->r25);
    // 0x802A7564: lbu         $t7, 0x742($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X742);
    // 0x802A7568: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A756C: sll         $t3, $t7, 2
    ctx->r11 = S32(ctx->r15 << 2);
    // 0x802A7570: subu        $t3, $t3, $t7
    ctx->r11 = SUB32(ctx->r11, ctx->r15);
    // 0x802A7574: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802A7578: addu        $v1, $v1, $t3
    ctx->r3 = ADD32(ctx->r3, ctx->r11);
    // 0x802A757C: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
L_802A7580:
    // 0x802A7580: slti        $at, $v1, 0x11
    ctx->r1 = SIGNED(ctx->r3) < 0X11 ? 1 : 0;
    // 0x802A7584: beq         $at, $zero, L_802A7594
    if (ctx->r1 == 0) {
        // 0x802A7588: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802A7594;
    }
    // 0x802A7588: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802A758C: b           L_802A75A0
    // 0x802A7590: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802A75A0;
    // 0x802A7590: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802A7594:
    // 0x802A7594: addiu       $v1, $a0, -0x10
    ctx->r3 = ADD32(ctx->r4, -0X10);
    // 0x802A7598: andi        $t4, $v1, 0xFF
    ctx->r12 = ctx->r3 & 0XFF;
    // 0x802A759C: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
L_802A75A0:
    // 0x802A75A0: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x802A75A4: bne         $v0, $at, L_802A75C8
    if (ctx->r2 != ctx->r1) {
        // 0x802A75A8: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802A75C8;
    }
    // 0x802A75A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802A75AC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A75B0: lbu         $t5, 0x5538($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X5538);
    // 0x802A75B4: beq         $t5, $zero, L_802A75C8
    if (ctx->r13 == 0) {
        // 0x802A75B8: nop
    
            goto L_802A75C8;
    }
    // 0x802A75B8: nop

    // 0x802A75BC: addiu       $v1, $v1, 0xF
    ctx->r3 = ADD32(ctx->r3, 0XF);
    // 0x802A75C0: andi        $t8, $v1, 0xFF
    ctx->r24 = ctx->r3 & 0XFF;
    // 0x802A75C4: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_802A75C8:
    // 0x802A75C8: jal         0x80311D48
    // 0x802A75CC: sb          $v1, 0x57($sp)
    MEM_B(0X57, ctx->r29) = ctx->r3;
    func_80311D48_7233F8(rdram, ctx);
        goto after_48;
    // 0x802A75CC: sb          $v1, 0x57($sp)
    MEM_B(0X57, ctx->r29) = ctx->r3;
    after_48:
    // 0x802A75D0: sll         $t6, $v0, 24
    ctx->r14 = S32(ctx->r2 << 24);
    // 0x802A75D4: sra         $t2, $t6, 24
    ctx->r10 = S32(SIGNED(ctx->r14) >> 24);
    // 0x802A75D8: bne         $t2, $zero, L_802A75EC
    if (ctx->r10 != 0) {
        // 0x802A75DC: lbu         $v1, 0x57($sp)
        ctx->r3 = MEM_BU(ctx->r29, 0X57);
            goto L_802A75EC;
    }
    // 0x802A75DC: lbu         $v1, 0x57($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X57);
    // 0x802A75E0: lb          $t9, 0x54($sp)
    ctx->r25 = MEM_B(ctx->r29, 0X54);
    // 0x802A75E4: beq         $t9, $zero, L_802A75F4
    if (ctx->r25 == 0) {
        // 0x802A75E8: nop
    
            goto L_802A75F4;
    }
    // 0x802A75E8: nop

L_802A75EC:
    // 0x802A75EC: b           L_802A7634
    // 0x802A75F0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A7634;
    // 0x802A75F0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802A75F4:
    // 0x802A75F4: bne         $v1, $zero, L_802A7604
    if (ctx->r3 != 0) {
        // 0x802A75F8: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802A7604;
    }
    // 0x802A75F8: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802A75FC: b           L_802A7634
    // 0x802A7600: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802A7634;
    // 0x802A7600: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802A7604:
    // 0x802A7604: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A7608: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802A760C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A7610: bgez        $v0, L_802A7620
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7614: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A7620;
    }
    // 0x802A7614: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A7618: b           L_802A7620
    // 0x802A761C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A7620;
    // 0x802A761C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A7620:
    // 0x802A7620: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A7624: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A7628: mflo        $t7
    ctx->r15 = lo;
    // 0x802A762C: sra         $t3, $t7, 4
    ctx->r11 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802A7630: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
L_802A7634:
    // 0x802A7634: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802A7638: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802A763C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802A7640: jr          $ra
    // 0x802A7644: nop

    return;
    // 0x802A7644: nop

;}
RECOMP_FUNC void func_802A7648_6B8CF8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A7648: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802A764C: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802A7650: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802A7654: lbu         $t6, 0x161($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X161);
    // 0x802A7658: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A765C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802A7660: beq         $t6, $at, L_802A7674
    if (ctx->r14 == ctx->r1) {
        // 0x802A7664: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_802A7674;
    }
    // 0x802A7664: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802A7668: lbu         $t7, 0x54($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X54);
    // 0x802A766C: ori         $t8, $t7, 0xA
    ctx->r24 = ctx->r15 | 0XA;
    // 0x802A7670: sb          $t8, 0x54($a0)
    MEM_B(0X54, ctx->r4) = ctx->r24;
L_802A7674:
    // 0x802A7674: lw          $t9, 0x16C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X16C);
    // 0x802A7678: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A767C: addiu       $v0, $v0, 0x2D50
    ctx->r2 = ADD32(ctx->r2, 0X2D50);
    // 0x802A7680: lhu         $t0, 0x0($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X0);
    // 0x802A7684: bnel        $t0, $at, L_802A76AC
    if (ctx->r8 != ctx->r1) {
        // 0x802A7688: lh          $t3, 0x24($s0)
        ctx->r11 = MEM_H(ctx->r16, 0X24);
            goto L_802A76AC;
    }
    goto skip_0;
    // 0x802A7688: lh          $t3, 0x24($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X24);
    skip_0:
    // 0x802A768C: lh          $t1, 0x52($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X52);
    // 0x802A7690: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A7694: bnel        $t1, $at, L_802A76AC
    if (ctx->r9 != ctx->r1) {
        // 0x802A7698: lh          $t3, 0x24($s0)
        ctx->r11 = MEM_H(ctx->r16, 0X24);
            goto L_802A76AC;
    }
    goto skip_1;
    // 0x802A7698: lh          $t3, 0x24($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X24);
    skip_1:
    // 0x802A769C: lh          $t2, 0x20($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X20);
    // 0x802A76A0: beql        $t2, $zero, L_802A774C
    if (ctx->r10 == 0) {
        // 0x802A76A4: lbu         $t1, 0x162($s0)
        ctx->r9 = MEM_BU(ctx->r16, 0X162);
            goto L_802A774C;
    }
    goto skip_2;
    // 0x802A76A4: lbu         $t1, 0x162($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X162);
    skip_2:
    // 0x802A76A8: lh          $t3, 0x24($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X24);
L_802A76AC:
    // 0x802A76AC: lhu         $v0, 0x44($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X44);
    // 0x802A76B0: negu        $t4, $t3
    ctx->r12 = SUB32(0, ctx->r11);
    // 0x802A76B4: multu       $t4, $v0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A76B8: slti        $at, $v0, 0x79
    ctx->r1 = SIGNED(ctx->r2) < 0X79 ? 1 : 0;
    // 0x802A76BC: mflo        $v1
    ctx->r3 = lo;
    // 0x802A76C0: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802A76C4: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802A76C8: bne         $at, $zero, L_802A7748
    if (ctx->r1 != 0) {
        // 0x802A76CC: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_802A7748;
    }
    // 0x802A76CC: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802A76D0: slti        $at, $t6, 0x7D1
    ctx->r1 = SIGNED(ctx->r14) < 0X7D1 ? 1 : 0;
    // 0x802A76D4: bne         $at, $zero, L_802A7710
    if (ctx->r1 != 0) {
        // 0x802A76D8: addiu       $a0, $zero, 0x4B
        ctx->r4 = ADD32(0, 0X4B);
            goto L_802A7710;
    }
    // 0x802A76D8: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A76DC: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x802A76E0: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A76E4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802A76E8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802A76EC: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x802A76F0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802A76F4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802A76F8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A76FC: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x802A7700: jal         0x8032C360
    // 0x802A7704: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x802A7704: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_0:
    // 0x802A7708: b           L_802A774C
    // 0x802A770C: lbu         $t1, 0x162($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X162);
        goto L_802A774C;
    // 0x802A770C: lbu         $t1, 0x162($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X162);
L_802A7710:
    // 0x802A7710: slti        $at, $v1, 0x1F5
    ctx->r1 = SIGNED(ctx->r3) < 0X1F5 ? 1 : 0;
    // 0x802A7714: bne         $at, $zero, L_802A7748
    if (ctx->r1 != 0) {
        // 0x802A7718: addiu       $a0, $zero, 0x4B
        ctx->r4 = ADD32(0, 0X4B);
            goto L_802A7748;
    }
    // 0x802A7718: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802A771C: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802A7720: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802A7724: lui         $at, 0x3FC0
    ctx->r1 = S32(0X3FC0 << 16);
    // 0x802A7728: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802A772C: lh          $t0, 0xC($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XC);
    // 0x802A7730: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802A7734: addiu       $a1, $zero, 0x2800
    ctx->r5 = ADD32(0, 0X2800);
    // 0x802A7738: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802A773C: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802A7740: jal         0x8032C360
    // 0x802A7744: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802A7744: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_1:
L_802A7748:
    // 0x802A7748: lbu         $t1, 0x162($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X162);
L_802A774C:
    // 0x802A774C: andi        $t2, $t1, 0xF
    ctx->r10 = ctx->r9 & 0XF;
    // 0x802A7750: addiu       $t3, $t2, -0x1
    ctx->r11 = ADD32(ctx->r10, -0X1);
    // 0x802A7754: sltiu       $at, $t3, 0x7
    ctx->r1 = ctx->r11 < 0X7 ? 1 : 0;
    // 0x802A7758: beq         $at, $zero, L_802A7774
    if (ctx->r1 == 0) {
        // 0x802A775C: sll         $t3, $t3, 2
        ctx->r11 = S32(ctx->r11 << 2);
            goto L_802A7774;
    }
    // 0x802A775C: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802A7760: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A7764: addu        $at, $at, $t3
    gpr jr_addend_802A776C = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802A7768: lw          $t3, -0x51E4($at)
    ctx->r11 = ADD32(ctx->r1, -0X51E4);
    // 0x802A776C: jr          $t3
    // 0x802A7770: nop

    switch (jr_addend_802A776C >> 2) {
        case 0: goto L_802A7774; break;
        case 1: goto L_802A7774; break;
        case 2: goto L_802A7774; break;
        case 3: goto L_802A7774; break;
        case 4: goto L_802A7780; break;
        case 5: goto L_802A7780; break;
        case 6: goto L_802A7780; break;
        default: switch_error(__func__, 0x802A776C, 0x803BAE1C);
    }
    // 0x802A7770: nop

L_802A7774:
    // 0x802A7774: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802A7778: b           L_802A7788
    // 0x802A777C: sb          $t4, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r12;
        goto L_802A7788;
    // 0x802A777C: sb          $t4, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r12;
L_802A7780:
    // 0x802A7780: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x802A7784: sb          $t5, 0x162($s0)
    MEM_B(0X162, ctx->r16) = ctx->r13;
L_802A7788:
    // 0x802A7788: lbu         $t6, 0x161($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X161);
    // 0x802A778C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A7790: bnel        $t6, $at, L_802A77A4
    if (ctx->r14 != ctx->r1) {
        // 0x802A7794: lbu         $t7, 0x160($s0)
        ctx->r15 = MEM_BU(ctx->r16, 0X160);
            goto L_802A77A4;
    }
    goto skip_3;
    // 0x802A7794: lbu         $t7, 0x160($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X160);
    skip_3:
    // 0x802A7798: b           L_802A78B8
    // 0x802A779C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A78B8;
    // 0x802A779C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A77A0: lbu         $t7, 0x160($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X160);
L_802A77A4:
    // 0x802A77A4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A77A8: bnel        $t7, $at, L_802A7800
    if (ctx->r15 != ctx->r1) {
        // 0x802A77AC: lh          $t7, 0x4($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X4);
            goto L_802A7800;
    }
    goto skip_4;
    // 0x802A77AC: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    skip_4:
    // 0x802A77B0: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x802A77B4: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x802A77B8: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x802A77BC: sra         $t9, $t8, 6
    ctx->r25 = S32(SIGNED(ctx->r24) >> 6);
    // 0x802A77C0: sll         $t0, $t9, 7
    ctx->r8 = S32(ctx->r25 << 7);
    // 0x802A77C4: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x802A77C8: sra         $t2, $t1, 6
    ctx->r10 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802A77CC: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x802A77D0: sll         $t0, $t0, 3
    ctx->r8 = S32(ctx->r8 << 3);
    // 0x802A77D4: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x802A77D8: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802A77DC: lbu         $t5, 0x743($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X743);
    // 0x802A77E0: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A77E4: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x802A77E8: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x802A77EC: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802A77F0: addu        $v1, $v1, $t6
    ctx->r3 = ADD32(ctx->r3, ctx->r14);
    // 0x802A77F4: b           L_802A7844
    // 0x802A77F8: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
        goto L_802A7844;
    // 0x802A77F8: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
    // 0x802A77FC: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
L_802A7800:
    // 0x802A7800: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x802A7804: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802A7808: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802A780C: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x802A7810: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802A7814: sra         $t2, $t1, 6
    ctx->r10 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802A7818: sll         $t0, $t2, 3
    ctx->r8 = S32(ctx->r10 << 3);
    // 0x802A781C: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802A7820: addu        $t3, $t9, $t0
    ctx->r11 = ADD32(ctx->r25, ctx->r8);
    // 0x802A7824: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x802A7828: lbu         $t4, 0x742($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X742);
    // 0x802A782C: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802A7830: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x802A7834: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802A7838: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802A783C: addu        $v1, $v1, $t5
    ctx->r3 = ADD32(ctx->r3, ctx->r13);
    // 0x802A7840: lbu         $v1, 0x1D33($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X1D33);
L_802A7844:
    // 0x802A7844: slti        $at, $v1, 0x11
    ctx->r1 = SIGNED(ctx->r3) < 0X11 ? 1 : 0;
    // 0x802A7848: beq         $at, $zero, L_802A7858
    if (ctx->r1 == 0) {
        // 0x802A784C: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802A7858;
    }
    // 0x802A784C: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802A7850: b           L_802A7864
    // 0x802A7854: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802A7864;
    // 0x802A7854: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802A7858:
    // 0x802A7858: addiu       $v1, $a0, -0x10
    ctx->r3 = ADD32(ctx->r4, -0X10);
    // 0x802A785C: andi        $t6, $v1, 0xFF
    ctx->r14 = ctx->r3 & 0XFF;
    // 0x802A7860: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_802A7864:
    // 0x802A7864: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802A7868: jal         0x80311D48
    // 0x802A786C: sb          $v1, 0x31($sp)
    MEM_B(0X31, ctx->r29) = ctx->r3;
    func_80311D48_7233F8(rdram, ctx);
        goto after_2;
    // 0x802A786C: sb          $v1, 0x31($sp)
    MEM_B(0X31, ctx->r29) = ctx->r3;
    after_2:
    // 0x802A7870: beq         $v0, $zero, L_802A7880
    if (ctx->r2 == 0) {
        // 0x802A7874: lbu         $v1, 0x31($sp)
        ctx->r3 = MEM_BU(ctx->r29, 0X31);
            goto L_802A7880;
    }
    // 0x802A7874: lbu         $v1, 0x31($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X31);
    // 0x802A7878: b           L_802A78B8
    // 0x802A787C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802A78B8;
    // 0x802A787C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802A7880:
    // 0x802A7880: bne         $v1, $zero, L_802A7890
    if (ctx->r3 != 0) {
        // 0x802A7884: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802A7890;
    }
    // 0x802A7884: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802A7888: b           L_802A78B8
    // 0x802A788C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802A78B8;
    // 0x802A788C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802A7890:
    // 0x802A7890: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x802A7894: bgez        $v0, L_802A78A4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7898: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A78A4;
    }
    // 0x802A7898: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A789C: b           L_802A78A4
    // 0x802A78A0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A78A4;
    // 0x802A78A0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A78A4:
    // 0x802A78A4: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A78A8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802A78AC: mflo        $t7
    ctx->r15 = lo;
    // 0x802A78B0: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802A78B4: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
L_802A78B8:
    // 0x802A78B8: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802A78BC: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802A78C0: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802A78C4: jr          $ra
    // 0x802A78C8: nop

    return;
    // 0x802A78C8: nop

;}
RECOMP_FUNC void func_802A78CC_6B8F7C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A78CC: addiu       $sp, $sp, -0xD0
    ctx->r29 = ADD32(ctx->r29, -0XD0);
    // 0x802A78D0: sw          $s1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r17;
    // 0x802A78D4: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x802A78D8: addiu       $s1, $s1, 0x5530
    ctx->r17 = ADD32(ctx->r17, 0X5530);
    // 0x802A78DC: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x802A78E0: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802A78E4: sw          $s0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r16;
    // 0x802A78E8: lb          $t7, 0x4A($t6)
    ctx->r15 = MEM_B(ctx->r14, 0X4A);
    // 0x802A78EC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A78F0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A78F4: bne         $t7, $zero, L_802A9348
    if (ctx->r15 != 0) {
        // 0x802A78F8: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802A9348;
    }
    // 0x802A78F8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A78FC: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A7900: addiu       $a1, $a1, 0x5546
    ctx->r5 = ADD32(ctx->r5, 0X5546);
    // 0x802A7904: lhu         $t8, 0x2F2($a3)
    ctx->r24 = MEM_HU(ctx->r7, 0X2F2);
    // 0x802A7908: sh          $t8, 0x2F4($a3)
    MEM_H(0X2F4, ctx->r7) = ctx->r24;
    // 0x802A790C: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A7910: lhu         $t9, 0x2F2($a3)
    ctx->r25 = MEM_HU(ctx->r7, 0X2F2);
    // 0x802A7914: addiu       $t2, $t9, 0x1
    ctx->r10 = ADD32(ctx->r25, 0X1);
    // 0x802A7918: sh          $t2, 0x2F2($a3)
    MEM_H(0X2F2, ctx->r7) = ctx->r10;
    // 0x802A791C: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A7920: lhu         $v0, 0x2F2($a3)
    ctx->r2 = MEM_HU(ctx->r7, 0X2F2);
    // 0x802A7924: slti        $at, $v0, 0x4000
    ctx->r1 = SIGNED(ctx->r2) < 0X4000 ? 1 : 0;
    // 0x802A7928: bne         $at, $zero, L_802A7938
    if (ctx->r1 != 0) {
        // 0x802A792C: addiu       $t3, $v0, -0x2000
        ctx->r11 = ADD32(ctx->r2, -0X2000);
            goto L_802A7938;
    }
    // 0x802A792C: addiu       $t3, $v0, -0x2000
    ctx->r11 = ADD32(ctx->r2, -0X2000);
    // 0x802A7930: sh          $t3, 0x2F2($a3)
    MEM_H(0X2F2, ctx->r7) = ctx->r11;
    // 0x802A7934: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
L_802A7938:
    // 0x802A7938: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A793C: lw          $t4, 0x6C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X6C);
    // 0x802A7940: sw          $t4, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r12;
    // 0x802A7944: lbu         $v0, 0x367($a3)
    ctx->r2 = MEM_BU(ctx->r7, 0X367);
    // 0x802A7948: blez        $v0, L_802A795C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802A794C: addiu       $t5, $v0, -0x1
        ctx->r13 = ADD32(ctx->r2, -0X1);
            goto L_802A795C;
    }
    // 0x802A794C: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x802A7950: sb          $t5, 0x367($a3)
    MEM_B(0X367, ctx->r7) = ctx->r13;
    // 0x802A7954: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A7958: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A795C:
    // 0x802A795C: lh          $v0, 0x0($a1)
    ctx->r2 = MEM_H(ctx->r5, 0X0);
    // 0x802A7960: beq         $v0, $zero, L_802A798C
    if (ctx->r2 == 0) {
        // 0x802A7964: addiu       $t6, $v0, -0x1
        ctx->r14 = ADD32(ctx->r2, -0X1);
            goto L_802A798C;
    }
    // 0x802A7964: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x802A7968: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
    // 0x802A796C: lbu         $v1, 0x162($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X162);
    // 0x802A7970: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A7974: andi        $t7, $v1, 0xF
    ctx->r15 = ctx->r3 & 0XF;
    // 0x802A7978: beq         $t7, $at, L_802A7988
    if (ctx->r15 == ctx->r1) {
        // 0x802A797C: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802A7988;
    }
    // 0x802A797C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802A7980: bnel        $t7, $at, L_802A7990
    if (ctx->r15 != ctx->r1) {
        // 0x802A7984: lw          $t8, 0xC($a3)
        ctx->r24 = MEM_W(ctx->r7, 0XC);
            goto L_802A7990;
    }
    goto skip_0;
    // 0x802A7984: lw          $t8, 0xC($a3)
    ctx->r24 = MEM_W(ctx->r7, 0XC);
    skip_0:
L_802A7988:
    // 0x802A7988: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
L_802A798C:
    // 0x802A798C: lw          $t8, 0xC($a3)
    ctx->r24 = MEM_W(ctx->r7, 0XC);
L_802A7990:
    // 0x802A7990: sw          $t8, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->r24;
    // 0x802A7994: lbu         $t9, 0x162($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X162);
    // 0x802A7998: andi        $t2, $t9, 0xF
    ctx->r10 = ctx->r25 & 0XF;
    // 0x802A799C: addiu       $t3, $t2, -0x1
    ctx->r11 = ADD32(ctx->r10, -0X1);
    // 0x802A79A0: sltiu       $at, $t3, 0x7
    ctx->r1 = ctx->r11 < 0X7 ? 1 : 0;
    // 0x802A79A4: beq         $at, $zero, L_802A90B0
    if (ctx->r1 == 0) {
        // 0x802A79A8: sll         $t3, $t3, 2
        ctx->r11 = S32(ctx->r11 << 2);
            goto L_802A90B0;
    }
    // 0x802A79A8: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802A79AC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A79B0: addu        $at, $at, $t3
    gpr jr_addend_802A79B8 = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802A79B4: lw          $t3, -0x51C8($at)
    ctx->r11 = ADD32(ctx->r1, -0X51C8);
    // 0x802A79B8: jr          $t3
    // 0x802A79BC: nop

    switch (jr_addend_802A79B8 >> 2) {
        case 0: goto L_802A79C0; break;
        case 1: goto L_802A8274; break;
        case 2: goto L_802A8410; break;
        case 3: goto L_802A88E4; break;
        case 4: goto L_802A8AF8; break;
        case 5: goto L_802A8E24; break;
        case 6: goto L_802A8F54; break;
        default: switch_error(__func__, 0x802A79B8, 0x803BAE38);
    }
    // 0x802A79BC: nop

L_802A79C0:
    // 0x802A79C0: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x802A79C4: lw          $t5, 0x5B4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B4);
    // 0x802A79C8: lw          $t4, 0x24($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X24);
    // 0x802A79CC: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x802A79D0: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
    // 0x802A79D4: jal         0x8030AAE0
    // 0x802A79D8: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_8030AAE0_71C190(rdram, ctx);
        goto after_0;
    // 0x802A79D8: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_0:
    // 0x802A79DC: beq         $v0, $zero, L_802A7A38
    if (ctx->r2 == 0) {
        // 0x802A79E0: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A7A38;
    }
    // 0x802A79E0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A79E4: beq         $v0, $at, L_802A79FC
    if (ctx->r2 == ctx->r1) {
        // 0x802A79E8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A79FC;
    }
    // 0x802A79E8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A79EC: beql        $v0, $at, L_802A7A3C
    if (ctx->r2 == ctx->r1) {
        // 0x802A79F0: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A7A3C;
    }
    goto skip_1;
    // 0x802A79F0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_1:
    // 0x802A79F4: b           L_802A7A3C
    // 0x802A79F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A7A3C;
    // 0x802A79F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A79FC:
    // 0x802A79FC: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x802A7A00: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802A7A04: jal         0x802A6400
    // 0x802A7A08: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
    func_802A6400_6B7AB0(rdram, ctx);
        goto after_1;
    // 0x802A7A08: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
    after_1:
    // 0x802A7A0C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A7A10: lw          $a3, 0x552C($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X552C);
    // 0x802A7A14: lui         $t2, 0x803A
    ctx->r10 = S32(0X803A << 16);
    // 0x802A7A18: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802A7A1C: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802A7A20: lw          $t2, 0x5B4($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5B4);
    // 0x802A7A24: lw          $t9, 0x24($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X24);
    // 0x802A7A28: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x802A7A2C: addu        $t3, $t9, $t2
    ctx->r11 = ADD32(ctx->r25, ctx->r10);
    // 0x802A7A30: subu        $t6, $t3, $t5
    ctx->r14 = SUB32(ctx->r11, ctx->r13);
    // 0x802A7A34: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
L_802A7A38:
    // 0x802A7A38: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A7A3C:
    // 0x802A7A3C: lw          $t7, 0x74($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X74);
    // 0x802A7A40: lw          $v0, 0x6C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X6C);
    // 0x802A7A44: beql        $t7, $v0, L_802A7A58
    if (ctx->r15 == ctx->r2) {
        // 0x802A7A48: sh          $zero, 0x70($sp)
        MEM_H(0X70, ctx->r29) = 0;
            goto L_802A7A58;
    }
    goto skip_2;
    // 0x802A7A48: sh          $zero, 0x70($sp)
    MEM_H(0X70, ctx->r29) = 0;
    skip_2:
    // 0x802A7A4C: bnel        $v0, $zero, L_802A7B40
    if (ctx->r2 != 0) {
        // 0x802A7A50: lbu         $t2, 0x162($s0)
        ctx->r10 = MEM_BU(ctx->r16, 0X162);
            goto L_802A7B40;
    }
    goto skip_3;
    // 0x802A7A50: lbu         $t2, 0x162($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X162);
    skip_3:
    // 0x802A7A54: sh          $zero, 0x70($sp)
    MEM_H(0X70, ctx->r29) = 0;
L_802A7A58:
    // 0x802A7A58: sh          $zero, 0x72($sp)
    MEM_H(0X72, ctx->r29) = 0;
    // 0x802A7A5C: lw          $t8, 0x6C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X6C);
    // 0x802A7A60: addiu       $a2, $sp, 0x72
    ctx->r6 = ADD32(ctx->r29, 0X72);
    // 0x802A7A64: addiu       $a3, $sp, 0x70
    ctx->r7 = ADD32(ctx->r29, 0X70);
    // 0x802A7A68: bnel        $t8, $zero, L_802A7A8C
    if (ctx->r24 != 0) {
        // 0x802A7A6C: lh          $v0, 0x72($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X72);
            goto L_802A7A8C;
    }
    goto skip_4;
    // 0x802A7A6C: lh          $v0, 0x72($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X72);
    skip_4:
    // 0x802A7A70: lbu         $t9, 0x160($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X160);
    // 0x802A7A74: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A7A78: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A7A7C: jal         0x80311A2C
    // 0x802A7A80: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_2;
    // 0x802A7A80: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_2:
    // 0x802A7A84: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7A88: lh          $v0, 0x72($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X72);
L_802A7A8C:
    // 0x802A7A8C: bgez        $v0, L_802A7A9C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7A90: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A7A9C;
    }
    // 0x802A7A90: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A7A94: b           L_802A7A9C
    // 0x802A7A98: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A7A9C;
    // 0x802A7A98: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A7A9C:
    // 0x802A7A9C: slti        $at, $v1, 0x24
    ctx->r1 = SIGNED(ctx->r3) < 0X24 ? 1 : 0;
    // 0x802A7AA0: beq         $at, $zero, L_802A7AC4
    if (ctx->r1 == 0) {
        // 0x802A7AA4: lh          $v0, 0x70($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X70);
            goto L_802A7AC4;
    }
    // 0x802A7AA4: lh          $v0, 0x70($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X70);
    // 0x802A7AA8: bgez        $v0, L_802A7AB8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7AAC: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802A7AB8;
    }
    // 0x802A7AAC: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802A7AB0: b           L_802A7AB8
    // 0x802A7AB4: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802A7AB8;
    // 0x802A7AB4: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802A7AB8:
    // 0x802A7AB8: slti        $at, $a1, 0x24
    ctx->r1 = SIGNED(ctx->r5) < 0X24 ? 1 : 0;
    // 0x802A7ABC: bnel        $at, $zero, L_802A7AF8
    if (ctx->r1 != 0) {
        // 0x802A7AC0: lw          $t5, 0xC($s0)
        ctx->r13 = MEM_W(ctx->r16, 0XC);
            goto L_802A7AF8;
    }
    goto skip_5;
    // 0x802A7AC0: lw          $t5, 0xC($s0)
    ctx->r13 = MEM_W(ctx->r16, 0XC);
    skip_5:
L_802A7AC4:
    // 0x802A7AC4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A7AC8: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A7ACC: jal         0x80310EE4
    // 0x802A7AD0: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_3;
    // 0x802A7AD0: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    after_3:
    // 0x802A7AD4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7AD8: sra         $t4, $v0, 16
    ctx->r12 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802A7ADC: lw          $t9, 0xB4($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XB4);
    // 0x802A7AE0: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802A7AE4: subu        $t3, $t2, $t4
    ctx->r11 = SUB32(ctx->r10, ctx->r12);
    // 0x802A7AE8: slti        $at, $t3, 0x41
    ctx->r1 = SIGNED(ctx->r11) < 0X41 ? 1 : 0;
    // 0x802A7AEC: bnel        $at, $zero, L_802A7B10
    if (ctx->r1 != 0) {
        // 0x802A7AF0: lw          $t8, 0xC($s0)
        ctx->r24 = MEM_W(ctx->r16, 0XC);
            goto L_802A7B10;
    }
    goto skip_6;
    // 0x802A7AF0: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    skip_6:
    // 0x802A7AF4: lw          $t5, 0xC($s0)
    ctx->r13 = MEM_W(ctx->r16, 0XC);
L_802A7AF8:
    // 0x802A7AF8: lw          $t6, 0xB4($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XB4);
    // 0x802A7AFC: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x802A7B00: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
    // 0x802A7B04: b           L_802A7B3C
    // 0x802A7B08: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A7B3C;
    // 0x802A7B08: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7B0C: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
L_802A7B10:
    // 0x802A7B10: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802A7B14: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802A7B18: subu        $v0, $t8, $t9
    ctx->r2 = SUB32(ctx->r24, ctx->r25);
    // 0x802A7B1C: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802A7B20: bne         $at, $zero, L_802A7B34
    if (ctx->r1 != 0) {
        // 0x802A7B24: lui         $a2, 0x4
        ctx->r6 = S32(0X4 << 16);
            goto L_802A7B34;
    }
    // 0x802A7B24: lui         $a2, 0x4
    ctx->r6 = S32(0X4 << 16);
    // 0x802A7B28: sw          $a2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r6;
    // 0x802A7B2C: b           L_802A7B3C
    // 0x802A7B30: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A7B3C;
    // 0x802A7B30: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A7B34:
    // 0x802A7B34: sw          $v0, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r2;
    // 0x802A7B38: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A7B3C:
    // 0x802A7B3C: lbu         $t2, 0x162($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X162);
L_802A7B40:
    // 0x802A7B40: addiu       $v1, $zero, 0x3
    ctx->r3 = ADD32(0, 0X3);
    // 0x802A7B44: bne         $v1, $t2, L_802A7BF0
    if (ctx->r3 != ctx->r10) {
        // 0x802A7B48: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802A7BF0;
    }
    // 0x802A7B48: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A7B4C: lw          $a3, 0x552C($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X552C);
    // 0x802A7B50: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A7B54: lb          $t4, 0x360($a3)
    ctx->r12 = MEM_B(ctx->r7, 0X360);
    // 0x802A7B58: bnel        $t4, $zero, L_802A7BC8
    if (ctx->r12 != 0) {
        // 0x802A7B5C: lw          $v0, 0x24($a3)
        ctx->r2 = MEM_W(ctx->r7, 0X24);
            goto L_802A7BC8;
    }
    goto skip_7;
    // 0x802A7B5C: lw          $v0, 0x24($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X24);
    skip_7:
    // 0x802A7B60: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802A7B64: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A7B68: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A7B6C: lhu         $t5, 0xA2($t3)
    ctx->r13 = MEM_HU(ctx->r11, 0XA2);
    // 0x802A7B70: andi        $t6, $t5, 0x1
    ctx->r14 = ctx->r13 & 0X1;
    // 0x802A7B74: beq         $t6, $zero, L_802A7BF0
    if (ctx->r14 == 0) {
        // 0x802A7B78: nop
    
            goto L_802A7BF0;
    }
    // 0x802A7B78: nop

    // 0x802A7B7C: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x802A7B80: lhu         $t8, 0x555A($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X555A);
    // 0x802A7B84: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x802A7B88: slti        $at, $t9, 0x3
    ctx->r1 = SIGNED(ctx->r25) < 0X3 ? 1 : 0;
    // 0x802A7B8C: beq         $at, $zero, L_802A7BF0
    if (ctx->r1 == 0) {
        // 0x802A7B90: nop
    
            goto L_802A7BF0;
    }
    // 0x802A7B90: nop

    // 0x802A7B94: lbu         $t2, 0x367($a3)
    ctx->r10 = MEM_BU(ctx->r7, 0X367);
    // 0x802A7B98: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A7B9C: bne         $t2, $zero, L_802A7BF0
    if (ctx->r10 != 0) {
        // 0x802A7BA0: nop
    
            goto L_802A7BF0;
    }
    // 0x802A7BA0: nop

    // 0x802A7BA4: lw          $v0, 0x5560($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5560);
    // 0x802A7BA8: beql        $v0, $zero, L_802A7BC8
    if (ctx->r2 == 0) {
        // 0x802A7BAC: lw          $v0, 0x24($a3)
        ctx->r2 = MEM_W(ctx->r7, 0X24);
            goto L_802A7BC8;
    }
    goto skip_8;
    // 0x802A7BAC: lw          $v0, 0x24($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X24);
    skip_8:
    // 0x802A7BB0: lw          $t4, 0x16C($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X16C);
    // 0x802A7BB4: lw          $t3, 0x80($t4)
    ctx->r11 = MEM_W(ctx->r12, 0X80);
    // 0x802A7BB8: sll         $t6, $t3, 17
    ctx->r14 = S32(ctx->r11 << 17);
    // 0x802A7BBC: bgez        $t6, L_802A7BF0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802A7BC0: nop
    
            goto L_802A7BF0;
    }
    // 0x802A7BC0: nop

    // 0x802A7BC4: lw          $v0, 0x24($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X24);
L_802A7BC8:
    // 0x802A7BC8: lui         $v1, 0x803A
    ctx->r3 = S32(0X803A << 16);
    // 0x802A7BCC: bgez        $v0, L_802A7BF0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7BD0: nop
    
            goto L_802A7BF0;
    }
    // 0x802A7BD0: nop

    // 0x802A7BD4: lw          $v1, 0x5B4($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5B4);
    // 0x802A7BD8: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A7BDC: beq         $at, $zero, L_802A7BEC
    if (ctx->r1 == 0) {
        // 0x802A7BE0: addu        $t7, $v0, $v1
        ctx->r15 = ADD32(ctx->r2, ctx->r3);
            goto L_802A7BEC;
    }
    // 0x802A7BE0: addu        $t7, $v0, $v1
    ctx->r15 = ADD32(ctx->r2, ctx->r3);
    // 0x802A7BE4: b           L_802A7BF0
    // 0x802A7BE8: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
        goto L_802A7BF0;
    // 0x802A7BE8: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
L_802A7BEC:
    // 0x802A7BEC: sw          $zero, 0x24($a3)
    MEM_W(0X24, ctx->r7) = 0;
L_802A7BF0:
    // 0x802A7BF0: jal         0x802B2834
    // 0x802A7BF4: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_4;
    // 0x802A7BF4: nop

    after_4:
    // 0x802A7BF8: jal         0x802A3CD0
    // 0x802A7BFC: nop

    func_802A3CD0_6B5380(rdram, ctx);
        goto after_5;
    // 0x802A7BFC: nop

    after_5:
    // 0x802A7C00: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    // 0x802A7C04: jal         0x802AC5CC
    // 0x802A7C08: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_6;
    // 0x802A7C08: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_6:
    // 0x802A7C0C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A7C10: lw          $t8, 0x5520($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5520);
    // 0x802A7C14: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A7C18: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802A7C1C: lw          $t9, 0x0($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X0);
    // 0x802A7C20: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x802A7C24: lhu         $t2, 0xB2($t9)
    ctx->r10 = MEM_HU(ctx->r25, 0XB2);
    // 0x802A7C28: sh          $t2, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r10;
    // 0x802A7C2C: lhu         $v0, 0x9C($t0)
    ctx->r2 = MEM_HU(ctx->r8, 0X9C);
    // 0x802A7C30: bne         $v0, $at, L_802A7D28
    if (ctx->r2 != ctx->r1) {
        // 0x802A7C34: addiu       $a0, $zero, 0x2
        ctx->r4 = ADD32(0, 0X2);
            goto L_802A7D28;
    }
    // 0x802A7C34: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x802A7C38: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x802A7C3C: jal         0x802A4278
    // 0x802A7C40: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    func_802A4278_6B5928(rdram, ctx);
        goto after_7;
    // 0x802A7C40: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    after_7:
    // 0x802A7C44: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A7C48: lb          $t4, 0x554C($t4)
    ctx->r12 = MEM_B(ctx->r12, 0X554C);
    // 0x802A7C4C: beq         $t4, $zero, L_802A7D20
    if (ctx->r12 == 0) {
        // 0x802A7C50: nop
    
            goto L_802A7D20;
    }
    // 0x802A7C50: nop

    // 0x802A7C54: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7C58: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802A7C5C: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802A7C60: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A7C64: lw          $t3, 0x20($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X20);
    // 0x802A7C68: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802A7C6C: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
    // 0x802A7C70: mtc1        $t3, $f8
    ctx->f8.u32l = ctx->r11;
    // 0x802A7C74: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A7C78: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802A7C7C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A7C80: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802A7C84: div.d       $f0, $f6, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f0.d = DIV_D(ctx->f6.d, ctx->f18.d);
    // 0x802A7C88: div.d       $f2, $f10, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f2.d = DIV_D(ctx->f10.d, ctx->f18.d);
    // 0x802A7C8C: mul.d       $f4, $f0, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f0.d);
    // 0x802A7C90: ldc1        $f10, -0x51A8($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X51A8);
    // 0x802A7C94: mul.d       $f6, $f2, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = MUL_D(ctx->f2.d, ctx->f2.d);
    // 0x802A7C98: add.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d + ctx->f6.d;
    // 0x802A7C9C: c.lt.d      $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f8.d < ctx->f10.d;
    // 0x802A7CA0: nop

    // 0x802A7CA4: bc1f        L_802A7D20
    if (!c1cs) {
        // 0x802A7CA8: nop
    
            goto L_802A7D20;
    }
    // 0x802A7CA8: nop

    // 0x802A7CAC: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802A7CB0: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A7CB4: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A7CB8: lh          $t6, 0x302($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X302);
    // 0x802A7CBC: addiu       $v1, $zero, 0xDE
    ctx->r3 = ADD32(0, 0XDE);
    // 0x802A7CC0: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802A7CC4: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802A7CC8: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802A7CCC: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x802A7CD0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A7CD4: sra         $t4, $t2, 7
    ctx->r12 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802A7CD8: multu       $t4, $v1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A7CDC: mflo        $t3
    ctx->r11 = lo;
    // 0x802A7CE0: addu        $t5, $a0, $t3
    ctx->r13 = ADD32(ctx->r4, ctx->r11);
    // 0x802A7CE4: sw          $t5, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r13;
    // 0x802A7CE8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A7CEC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7CF0: lh          $t8, 0x302($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X302);
    // 0x802A7CF4: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802A7CF8: addiu       $t9, $t8, 0x40
    ctx->r25 = ADD32(ctx->r24, 0X40);
    // 0x802A7CFC: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x802A7D00: sll         $t4, $t2, 1
    ctx->r12 = S32(ctx->r10 << 1);
    // 0x802A7D04: addu        $t3, $v0, $t4
    ctx->r11 = ADD32(ctx->r2, ctx->r12);
    // 0x802A7D08: lh          $t5, 0x0($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X0);
    // 0x802A7D0C: sra         $t7, $t5, 7
    ctx->r15 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802A7D10: multu       $t7, $v1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A7D14: mflo        $t8
    ctx->r24 = lo;
    // 0x802A7D18: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A7D1C: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
L_802A7D20:
    // 0x802A7D20: b           L_802A7F64
    // 0x802A7D24: nop

        goto L_802A7F64;
    // 0x802A7D24: nop

L_802A7D28:
    // 0x802A7D28: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802A7D2C: bne         $v0, $at, L_802A7E54
    if (ctx->r2 != ctx->r1) {
        // 0x802A7D30: lui         $t2, 0x803D
        ctx->r10 = S32(0X803D << 16);
            goto L_802A7E54;
    }
    // 0x802A7D30: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A7D34: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x802A7D38: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x802A7D3C: jal         0x802A4278
    // 0x802A7D40: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    func_802A4278_6B5928(rdram, ctx);
        goto after_8;
    // 0x802A7D40: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    after_8:
    // 0x802A7D44: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A7D48: lb          $t2, 0x554C($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X554C);
    // 0x802A7D4C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802A7D50: beq         $t2, $zero, L_802A7F64
    if (ctx->r10 == 0) {
        // 0x802A7D54: nop
    
            goto L_802A7F64;
    }
    // 0x802A7D54: nop

    // 0x802A7D58: lh          $t4, 0x2DA2($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2DA2);
    // 0x802A7D5C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A7D60: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802A7D64: beq         $t4, $at, L_802A7DE4
    if (ctx->r12 == ctx->r1) {
        // 0x802A7D68: addiu       $v1, $v1, 0x552C
        ctx->r3 = ADD32(ctx->r3, 0X552C);
            goto L_802A7DE4;
    }
    // 0x802A7D68: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802A7D6C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A7D70: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802A7D74: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A7D78: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A7D7C: lh          $t7, 0x302($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X302);
    // 0x802A7D80: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7D84: andi        $t6, $t7, 0xFF
    ctx->r14 = ctx->r15 & 0XFF;
    // 0x802A7D88: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802A7D8C: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802A7D90: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x802A7D94: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x802A7D98: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A7D9C: sra         $t4, $t2, 7
    ctx->r12 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802A7DA0: sll         $t5, $t4, 7
    ctx->r13 = S32(ctx->r12 << 7);
    // 0x802A7DA4: addu        $t7, $t3, $t5
    ctx->r15 = ADD32(ctx->r11, ctx->r13);
    // 0x802A7DA8: sw          $t7, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r15;
    // 0x802A7DAC: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802A7DB0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7DB4: lh          $t9, 0x302($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X302);
    // 0x802A7DB8: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802A7DBC: addiu       $t2, $t9, 0x40
    ctx->r10 = ADD32(ctx->r25, 0X40);
    // 0x802A7DC0: andi        $t4, $t2, 0xFF
    ctx->r12 = ctx->r10 & 0XFF;
    // 0x802A7DC4: sll         $t3, $t4, 1
    ctx->r11 = S32(ctx->r12 << 1);
    // 0x802A7DC8: addu        $t5, $v0, $t3
    ctx->r13 = ADD32(ctx->r2, ctx->r11);
    // 0x802A7DCC: lh          $t7, 0x0($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X0);
    // 0x802A7DD0: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802A7DD4: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x802A7DD8: addu        $t2, $t6, $t9
    ctx->r10 = ADD32(ctx->r14, ctx->r25);
    // 0x802A7DDC: b           L_802A7F64
    // 0x802A7DE0: sw          $t2, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r10;
        goto L_802A7F64;
    // 0x802A7DE0: sw          $t2, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r10;
L_802A7DE4:
    // 0x802A7DE4: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802A7DE8: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A7DEC: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A7DF0: lh          $t5, 0x302($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X302);
    // 0x802A7DF4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7DF8: andi        $t7, $t5, 0xFF
    ctx->r15 = ctx->r13 & 0XFF;
    // 0x802A7DFC: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802A7E00: addu        $t6, $v0, $t8
    ctx->r14 = ADD32(ctx->r2, ctx->r24);
    // 0x802A7E04: lh          $t9, 0x0($t6)
    ctx->r25 = MEM_H(ctx->r14, 0X0);
    // 0x802A7E08: lw          $t4, 0x1C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X1C);
    // 0x802A7E0C: sra         $t2, $t9, 7
    ctx->r10 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802A7E10: sll         $t3, $t2, 8
    ctx->r11 = S32(ctx->r10 << 8);
    // 0x802A7E14: addu        $t5, $t4, $t3
    ctx->r13 = ADD32(ctx->r12, ctx->r11);
    // 0x802A7E18: sw          $t5, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r13;
    // 0x802A7E1C: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802A7E20: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7E24: lh          $t6, 0x302($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X302);
    // 0x802A7E28: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802A7E2C: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x802A7E30: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x802A7E34: sll         $t4, $t2, 1
    ctx->r12 = S32(ctx->r10 << 1);
    // 0x802A7E38: addu        $t3, $v0, $t4
    ctx->r11 = ADD32(ctx->r2, ctx->r12);
    // 0x802A7E3C: lh          $t5, 0x0($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X0);
    // 0x802A7E40: sra         $t8, $t5, 7
    ctx->r24 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802A7E44: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x802A7E48: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x802A7E4C: b           L_802A7F64
    // 0x802A7E50: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
        goto L_802A7F64;
    // 0x802A7E50: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
L_802A7E54:
    // 0x802A7E54: lb          $t2, 0x554C($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X554C);
    // 0x802A7E58: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A7E5C: lw          $t4, 0xC8($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XC8);
    // 0x802A7E60: beq         $t2, $zero, L_802A7F64
    if (ctx->r10 == 0) {
        // 0x802A7E64: nop
    
            goto L_802A7F64;
    }
    // 0x802A7E64: nop

    // 0x802A7E68: lb          $v0, 0x554B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X554B);
    // 0x802A7E6C: lw          $t7, 0xC4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XC4);
    // 0x802A7E70: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7E74: multu       $t4, $v0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A7E78: mflo        $t3
    ctx->r11 = lo;
    // 0x802A7E7C: sra         $t5, $t3, 4
    ctx->r13 = S32(SIGNED(ctx->r11) >> 4);
    // 0x802A7E80: addu        $t8, $t4, $t5
    ctx->r24 = ADD32(ctx->r12, ctx->r13);
    // 0x802A7E84: multu       $t7, $v0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A7E88: sw          $t8, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->r24;
    // 0x802A7E8C: mflo        $t6
    ctx->r14 = lo;
    // 0x802A7E90: sra         $t9, $t6, 4
    ctx->r25 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802A7E94: addu        $t2, $t7, $t9
    ctx->r10 = ADD32(ctx->r15, ctx->r25);
    // 0x802A7E98: sw          $t2, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r10;
    // 0x802A7E9C: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A7EA0: bgez        $a0, L_802A7EB0
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A7EA4: or          $a2, $a0, $zero
        ctx->r6 = ctx->r4 | 0;
            goto L_802A7EB0;
    }
    // 0x802A7EA4: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802A7EA8: b           L_802A7EB0
    // 0x802A7EAC: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
        goto L_802A7EB0;
    // 0x802A7EAC: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
L_802A7EB0:
    // 0x802A7EB0: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802A7EB4: lhu         $t5, 0x8A($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A7EB8: bgez        $v0, L_802A7EC8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A7EBC: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A7EC8;
    }
    // 0x802A7EBC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A7EC0: b           L_802A7EC8
    // 0x802A7EC4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A7EC8;
    // 0x802A7EC4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A7EC8:
    // 0x802A7EC8: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A7ECC: beq         $at, $zero, L_802A7EDC
    if (ctx->r1 == 0) {
        // 0x802A7ED0: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A7EDC;
    }
    // 0x802A7ED0: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A7ED4: b           L_802A7EDC
    // 0x802A7ED8: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A7EDC;
    // 0x802A7ED8: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A7EDC:
    // 0x802A7EDC: slt         $at, $a2, $a0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802A7EE0: beq         $at, $zero, L_802A7EF0
    if (ctx->r1 == 0) {
        // 0x802A7EE4: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802A7EF0;
    }
    // 0x802A7EE4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802A7EE8: b           L_802A7EF0
    // 0x802A7EEC: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
        goto L_802A7EF0;
    // 0x802A7EEC: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_802A7EF0:
    // 0x802A7EF0: lhu         $a0, 0xA4($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0XA4);
    // 0x802A7EF4: sra         $t3, $v1, 1
    ctx->r11 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802A7EF8: addu        $v0, $t3, $a1
    ctx->r2 = ADD32(ctx->r11, ctx->r5);
    // 0x802A7EFC: sll         $t4, $a0, 11
    ctx->r12 = S32(ctx->r4 << 11);
    // 0x802A7F00: slt         $at, $t4, $v0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A7F04: beq         $at, $zero, L_802A7F24
    if (ctx->r1 == 0) {
        // 0x802A7F08: sll         $t6, $a0, 10
        ctx->r14 = S32(ctx->r4 << 10);
            goto L_802A7F24;
    }
    // 0x802A7F08: sll         $t6, $a0, 10
    ctx->r14 = S32(ctx->r4 << 10);
    // 0x802A7F0C: bgez        $t5, L_802A7F1C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802A7F10: sra         $t8, $t5, 2
        ctx->r24 = S32(SIGNED(ctx->r13) >> 2);
            goto L_802A7F1C;
    }
    // 0x802A7F10: sra         $t8, $t5, 2
    ctx->r24 = S32(SIGNED(ctx->r13) >> 2);
    // 0x802A7F14: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x802A7F18: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_802A7F1C:
    // 0x802A7F1C: b           L_802A7F64
    // 0x802A7F20: sh          $t8, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r24;
        goto L_802A7F64;
    // 0x802A7F20: sh          $t8, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r24;
L_802A7F24:
    // 0x802A7F24: slt         $at, $t6, $v0
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A7F28: beq         $at, $zero, L_802A7F4C
    if (ctx->r1 == 0) {
        // 0x802A7F2C: sll         $t2, $a0, 8
        ctx->r10 = S32(ctx->r4 << 8);
            goto L_802A7F4C;
    }
    // 0x802A7F2C: sll         $t2, $a0, 8
    ctx->r10 = S32(ctx->r4 << 8);
    // 0x802A7F30: lhu         $t7, 0x8A($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A7F34: bgez        $t7, L_802A7F44
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802A7F38: sra         $t9, $t7, 1
        ctx->r25 = S32(SIGNED(ctx->r15) >> 1);
            goto L_802A7F44;
    }
    // 0x802A7F38: sra         $t9, $t7, 1
    ctx->r25 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802A7F3C: addiu       $at, $t7, 0x1
    ctx->r1 = ADD32(ctx->r15, 0X1);
    // 0x802A7F40: sra         $t9, $at, 1
    ctx->r25 = S32(SIGNED(ctx->r1) >> 1);
L_802A7F44:
    // 0x802A7F44: b           L_802A7F64
    // 0x802A7F48: sh          $t9, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r25;
        goto L_802A7F64;
    // 0x802A7F48: sh          $t9, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r25;
L_802A7F4C:
    // 0x802A7F4C: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802A7F50: beq         $at, $zero, L_802A7F64
    if (ctx->r1 == 0) {
        // 0x802A7F54: lhu         $v0, 0x8A($sp)
        ctx->r2 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A7F64;
    }
    // 0x802A7F54: lhu         $v0, 0x8A($sp)
    ctx->r2 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A7F58: sra         $t3, $v0, 1
    ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802A7F5C: addu        $t4, $v0, $t3
    ctx->r12 = ADD32(ctx->r2, ctx->r11);
    // 0x802A7F60: sh          $t4, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r12;
L_802A7F64:
    // 0x802A7F64: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x802A7F68: lh          $t5, 0x2D70($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2D70);
    // 0x802A7F6C: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802A7F70: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802A7F74: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802A7F78: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A7F7C: bnel        $t5, $at, L_802A81E0
    if (ctx->r13 != ctx->r1) {
        // 0x802A7F80: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A81E0;
    }
    goto skip_9;
    // 0x802A7F80: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_9:
    // 0x802A7F84: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A7F88: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A7F8C: lw          $t8, 0x6C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X6C);
    // 0x802A7F90: bnel        $t8, $zero, L_802A81E0
    if (ctx->r24 != 0) {
        // 0x802A7F94: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A81E0;
    }
    goto skip_10;
    // 0x802A7F94: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_10:
    // 0x802A7F98: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802A7F9C: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802A7FA0: lui         $a3, 0x6
    ctx->r7 = S32(0X6 << 16);
    // 0x802A7FA4: lhu         $v0, 0x9C($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9C);
    // 0x802A7FA8: beq         $v0, $at, L_802A8050
    if (ctx->r2 == ctx->r1) {
        // 0x802A7FAC: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_802A8050;
    }
    // 0x802A7FAC: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x802A7FB0: bne         $v0, $at, L_802A7FC8
    if (ctx->r2 != ctx->r1) {
        // 0x802A7FB4: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802A7FC8;
    }
    // 0x802A7FB4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A7FB8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A7FBC: lh          $t9, 0x310($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X310);
    // 0x802A7FC0: beql        $t9, $zero, L_802A8054
    if (ctx->r25 == 0) {
        // 0x802A7FC4: lw          $a0, 0x1C($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X1C);
            goto L_802A8054;
    }
    goto skip_11;
    // 0x802A7FC4: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    skip_11:
L_802A7FC8:
    // 0x802A7FC8: lw          $a0, 0xC8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC8);
    // 0x802A7FCC: lui         $v0, 0x1
    ctx->r2 = S32(0X1 << 16);
    // 0x802A7FD0: bgez        $a0, L_802A7FE0
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A7FD4: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802A7FE0;
    }
    // 0x802A7FD4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802A7FD8: b           L_802A7FE0
    // 0x802A7FDC: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_802A7FE0;
    // 0x802A7FDC: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
L_802A7FE0:
    // 0x802A7FE0: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A7FE4: beq         $at, $zero, L_802A81DC
    if (ctx->r1 == 0) {
        // 0x802A7FE8: lw          $v1, 0xC4($sp)
        ctx->r3 = MEM_W(ctx->r29, 0XC4);
            goto L_802A81DC;
    }
    // 0x802A7FE8: lw          $v1, 0xC4($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XC4);
    // 0x802A7FEC: bgez        $v1, L_802A7FFC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802A7FF0: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_802A7FFC;
    }
    // 0x802A7FF0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802A7FF4: b           L_802A7FFC
    // 0x802A7FF8: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
        goto L_802A7FFC;
    // 0x802A7FF8: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
L_802A7FFC:
    // 0x802A7FFC: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A8000: beql        $at, $zero, L_802A81E0
    if (ctx->r1 == 0) {
        // 0x802A8004: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A81E0;
    }
    goto skip_12;
    // 0x802A8004: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_12:
    // 0x802A8008: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A800C: bgez        $a0, L_802A801C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A8010: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802A801C;
    }
    // 0x802A8010: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802A8014: b           L_802A801C
    // 0x802A8018: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
        goto L_802A801C;
    // 0x802A8018: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
L_802A801C:
    // 0x802A801C: lui         $a0, 0x2
    ctx->r4 = S32(0X2 << 16);
    // 0x802A8020: ori         $a0, $a0, 0x1
    ctx->r4 = ctx->r4 | 0X1;
    // 0x802A8024: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802A8028: beql        $at, $zero, L_802A8054
    if (ctx->r1 == 0) {
        // 0x802A802C: lw          $a0, 0x1C($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X1C);
            goto L_802A8054;
    }
    goto skip_13;
    // 0x802A802C: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    skip_13:
    // 0x802A8030: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802A8034: bgez        $v0, L_802A8044
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8038: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A8044;
    }
    // 0x802A8038: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A803C: b           L_802A8044
    // 0x802A8040: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A8044;
    // 0x802A8040: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A8044:
    // 0x802A8044: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802A8048: bnel        $at, $zero, L_802A81E0
    if (ctx->r1 != 0) {
        // 0x802A804C: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A81E0;
    }
    goto skip_14;
    // 0x802A804C: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_14:
L_802A8050:
    // 0x802A8050: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
L_802A8054:
    // 0x802A8054: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802A8058: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802A805C: bgez        $a0, L_802A806C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A8060: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A806C;
    }
    // 0x802A8060: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A8064: b           L_802A806C
    // 0x802A8068: negu        $a1, $a0
    ctx->r5 = SUB32(0, ctx->r4);
        goto L_802A806C;
    // 0x802A8068: negu        $a1, $a0
    ctx->r5 = SUB32(0, ctx->r4);
L_802A806C:
    // 0x802A806C: bgez        $v0, L_802A807C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8070: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A807C;
    }
    // 0x802A8070: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A8074: b           L_802A807C
    // 0x802A8078: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A807C;
    // 0x802A8078: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A807C:
    // 0x802A807C: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802A8080: beq         $at, $zero, L_802A80A4
    if (ctx->r1 == 0) {
        // 0x802A8084: nop
    
            goto L_802A80A4;
    }
    // 0x802A8084: nop

    // 0x802A8088: bgez        $a0, L_802A809C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A808C: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802A809C;
    }
    // 0x802A808C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802A8090: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
    // 0x802A8094: b           L_802A80B8
    // 0x802A8098: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
        goto L_802A80B8;
    // 0x802A8098: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_802A809C:
    // 0x802A809C: b           L_802A80B8
    // 0x802A80A0: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
        goto L_802A80B8;
    // 0x802A80A0: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_802A80A4:
    // 0x802A80A4: bgez        $v0, L_802A80B4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A80A8: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A80B4;
    }
    // 0x802A80A8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A80AC: b           L_802A80B4
    // 0x802A80B0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A80B4;
    // 0x802A80B0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A80B4:
    // 0x802A80B4: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_802A80B8:
    // 0x802A80B8: slt         $at, $a0, $a3
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802A80BC: bnel        $at, $zero, L_802A80CC
    if (ctx->r1 != 0) {
        // 0x802A80C0: mtc1        $a0, $f4
        ctx->f4.u32l = ctx->r4;
            goto L_802A80CC;
    }
    goto skip_15;
    // 0x802A80C0: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
    skip_15:
    // 0x802A80C4: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x802A80C8: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
L_802A80CC:
    // 0x802A80CC: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x802A80D0: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x802A80D4: cvt.d.w     $f14, $f4
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    ctx->f14.d = CVT_D_W(ctx->f4.u32l);
    // 0x802A80D8: lui         $at, 0x4110
    ctx->r1 = S32(0X4110 << 16);
    // 0x802A80DC: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802A80E0: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x802A80E4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A80E8: div.d       $f0, $f14, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f14.d); NAN_CHECK(ctx->f6.d); 
    ctx->f0.d = DIV_D(ctx->f14.d, ctx->f6.d);
    // 0x802A80EC: c.lt.d      $f16, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f16.d < ctx->f0.d;
    // 0x802A80F0: nop

    // 0x802A80F4: bc1fl       L_802A8108
    if (!c1cs) {
        // 0x802A80F8: cvt.s.d     $f12, $f0
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f12.fl = CVT_S_D(ctx->f0.d);
            goto L_802A8108;
    }
    goto skip_16;
    // 0x802A80F8: cvt.s.d     $f12, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f12.fl = CVT_S_D(ctx->f0.d);
    skip_16:
    // 0x802A80FC: b           L_802A8108
    // 0x802A8100: cvt.s.d     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f12.fl = CVT_S_D(ctx->f16.d);
        goto L_802A8108;
    // 0x802A8100: cvt.s.d     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f12.fl = CVT_S_D(ctx->f16.d);
    // 0x802A8104: cvt.s.d     $f12, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f12.fl = CVT_S_D(ctx->f0.d);
L_802A8108:
    // 0x802A8108: lwc1        $f8, 0x5580($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X5580);
    // 0x802A810C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A8110: ldc1        $f4, -0x51A0($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, -0X51A0);
    // 0x802A8114: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x802A8118: cvt.d.s     $f2, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f2.d = CVT_D_S(ctx->f12.fl);
    // 0x802A811C: add.d       $f0, $f10, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f4.d); 
    ctx->f0.d = ctx->f10.d + ctx->f4.d;
    // 0x802A8120: div.d       $f10, $f14, $f18
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f14.d); NAN_CHECK(ctx->f18.d); 
    ctx->f10.d = DIV_D(ctx->f14.d, ctx->f18.d);
    // 0x802A8124: c.lt.d      $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f0.d < ctx->f2.d;
    // 0x802A8128: nop

    // 0x802A812C: bc1fl       L_802A8148
    if (!c1cs) {
        // 0x802A8130: cvt.s.d     $f8, $f2
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); 
    ctx->f8.fl = CVT_S_D(ctx->f2.d);
            goto L_802A8148;
    }
    goto skip_17;
    // 0x802A8130: cvt.s.d     $f8, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); 
    ctx->f8.fl = CVT_S_D(ctx->f2.d);
    skip_17:
    // 0x802A8134: cvt.s.d     $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f6.fl = CVT_S_D(ctx->f0.d);
    // 0x802A8138: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A813C: b           L_802A8150
    // 0x802A8140: swc1        $f6, 0x5580($at)
    MEM_W(0X5580, ctx->r1) = ctx->f6.u32l;
        goto L_802A8150;
    // 0x802A8140: swc1        $f6, 0x5580($at)
    MEM_W(0X5580, ctx->r1) = ctx->f6.u32l;
    // 0x802A8144: cvt.s.d     $f8, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); 
    ctx->f8.fl = CVT_S_D(ctx->f2.d);
L_802A8148:
    // 0x802A8148: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A814C: swc1        $f8, 0x5580($at)
    MEM_W(0X5580, ctx->r1) = ctx->f8.u32l;
L_802A8150:
    // 0x802A8150: add.d       $f4, $f10, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f4.d = ctx->f10.d + ctx->f16.d;
    // 0x802A8154: jal         0x80137E10
    // 0x802A8158: cvt.s.d     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f12.fl = CVT_S_D(ctx->f4.d);
    sqrtf_recomp(rdram, ctx);
        goto after_9;
    // 0x802A8158: cvt.s.d     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f12.fl = CVT_S_D(ctx->f4.d);
    after_9:
    // 0x802A815C: lui         $at, 0x46A0
    ctx->r1 = S32(0X46A0 << 16);
    // 0x802A8160: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802A8164: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A8168: lwc1        $f8, 0x5580($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X5580);
    // 0x802A816C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A8170: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8174: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802A8178: ldc1        $f6, -0x5198($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X5198);
    // 0x802A817C: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x802A8180: addiu       $a0, $zero, 0x6F
    ctx->r4 = ADD32(0, 0X6F);
    // 0x802A8184: addiu       $a1, $zero, 0x3F
    ctx->r5 = ADD32(0, 0X3F);
    // 0x802A8188: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802A818C: cvt.d.s     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f4.d = CVT_D_S(ctx->f10.fl);
    // 0x802A8190: mul.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f4.d, ctx->f6.d);
    // 0x802A8194: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802A8198: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802A819C: cvt.d.s     $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f4.d = CVT_D_S(ctx->f0.fl);
    // 0x802A81A0: trunc.w.d   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_D(ctx->f8.d);
    // 0x802A81A4: mul.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f4.d, ctx->f6.d);
    // 0x802A81A8: mfc1        $a2, $f10
    ctx->r6 = (int32_t)ctx->f10.u32l;
    // 0x802A81AC: nop

    // 0x802A81B0: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802A81B4: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802A81B8: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x802A81BC: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x802A81C0: lh          $t5, 0x4($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X4);
    // 0x802A81C4: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x802A81C8: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802A81CC: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x802A81D0: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802A81D4: jal         0x8032CD70
    // 0x802A81D8: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_8032CD70_73E420(rdram, ctx);
        goto after_10;
    // 0x802A81D8: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_10:
L_802A81DC:
    // 0x802A81DC: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
L_802A81E0:
    // 0x802A81E0: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A81E4: jal         0x802ABB10
    // 0x802A81E8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    func_802ABB10_6BD1C0(rdram, ctx);
        goto after_11;
    // 0x802A81E8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    after_11:
    // 0x802A81EC: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    // 0x802A81F0: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A81F4: jal         0x802A3E70
    // 0x802A81F8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    func_802A3E70_6B5520(rdram, ctx);
        goto after_12;
    // 0x802A81F8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    after_12:
    // 0x802A81FC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A8200: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A8204: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802A8208: lw          $t7, 0xC8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XC8);
    // 0x802A820C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A8210: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A8214: sw          $t7, 0x1C($t9)
    MEM_W(0X1C, ctx->r25) = ctx->r15;
    // 0x802A8218: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802A821C: lw          $t2, 0xC4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC4);
    // 0x802A8220: sw          $t2, 0x20($t3)
    MEM_W(0X20, ctx->r11) = ctx->r10;
    // 0x802A8224: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8228: lw          $t4, 0x4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4);
    // 0x802A822C: lw          $t5, 0x1C($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8230: addu        $t8, $t4, $t5
    ctx->r24 = ADD32(ctx->r12, ctx->r13);
    // 0x802A8234: sw          $t8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r24;
    // 0x802A8238: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A823C: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x802A8240: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x802A8244: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802A8248: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802A824C: sw          $t9, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r25;
    // 0x802A8250: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8254: lw          $t5, 0x5B4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B4);
    // 0x802A8258: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802A825C: lw          $t3, 0x24($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X24);
    // 0x802A8260: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x802A8264: subu        $t8, $t4, $t5
    ctx->r24 = SUB32(ctx->r12, ctx->r13);
    // 0x802A8268: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
    // 0x802A826C: b           L_802A90B0
    // 0x802A8270: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A8270: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8274:
    // 0x802A8274: jal         0x8030AAE0
    // 0x802A8278: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_13;
    // 0x802A8278: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_13:
    // 0x802A827C: beq         $v0, $zero, L_802A829C
    if (ctx->r2 == 0) {
        // 0x802A8280: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A829C;
    }
    // 0x802A8280: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A8284: beq         $v0, $at, L_802A82F4
    if (ctx->r2 == ctx->r1) {
        // 0x802A8288: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A82F4;
    }
    // 0x802A8288: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A828C: beql        $v0, $at, L_802A8310
    if (ctx->r2 == ctx->r1) {
        // 0x802A8290: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8310;
    }
    goto skip_18;
    // 0x802A8290: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_18:
    // 0x802A8294: b           L_802A8320
    // 0x802A8298: nop

        goto L_802A8320;
    // 0x802A8298: nop

L_802A829C:
    // 0x802A829C: jal         0x802A64B0
    // 0x802A82A0: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_14;
    // 0x802A82A0: nop

    after_14:
    // 0x802A82A4: beq         $v0, $zero, L_802A82C0
    if (ctx->r2 == 0) {
        // 0x802A82A8: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_802A82C0;
    }
    // 0x802A82A8: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802A82AC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A82B0: lw          $t7, 0xB4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB4);
    // 0x802A82B4: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x802A82B8: subu        $t9, $t6, $t7
    ctx->r25 = SUB32(ctx->r14, ctx->r15);
    // 0x802A82BC: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
L_802A82C0:
    // 0x802A82C0: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x802A82C4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A82C8: lhu         $t2, 0x5544($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X5544);
    // 0x802A82CC: lhu         $t4, 0x48($t3)
    ctx->r12 = MEM_HU(ctx->r11, 0X48);
    // 0x802A82D0: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A82D4: subu        $t5, $t2, $t4
    ctx->r13 = SUB32(ctx->r10, ctx->r12);
    // 0x802A82D8: slti        $at, $t5, 0x4
    ctx->r1 = SIGNED(ctx->r13) < 0X4 ? 1 : 0;
    // 0x802A82DC: bne         $at, $zero, L_802A8320
    if (ctx->r1 != 0) {
        // 0x802A82E0: nop
    
            goto L_802A8320;
    }
    // 0x802A82E0: nop

    // 0x802A82E4: jal         0x802DBA58
    // 0x802A82E8: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    func_802DBA58_6ED108(rdram, ctx);
        goto after_15;
    // 0x802A82E8: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    after_15:
    // 0x802A82EC: b           L_802A8320
    // 0x802A82F0: nop

        goto L_802A8320;
    // 0x802A82F0: nop

L_802A82F4:
    // 0x802A82F4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A82F8: lw          $t6, 0xB4($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XB4);
    // 0x802A82FC: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x802A8300: subu        $t7, $t8, $t6
    ctx->r15 = SUB32(ctx->r24, ctx->r14);
    // 0x802A8304: b           L_802A8320
    // 0x802A8308: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
        goto L_802A8320;
    // 0x802A8308: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
    // 0x802A830C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8310:
    // 0x802A8310: lw          $t3, 0xB4($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8314: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x802A8318: subu        $t2, $t9, $t3
    ctx->r10 = SUB32(ctx->r25, ctx->r11);
    // 0x802A831C: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
L_802A8320:
    // 0x802A8320: jal         0x802B2834
    // 0x802A8324: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_16;
    // 0x802A8324: nop

    after_16:
    // 0x802A8328: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    // 0x802A832C: jal         0x802AC5CC
    // 0x802A8330: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_17;
    // 0x802A8330: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_17:
    // 0x802A8334: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A8338: lb          $t4, 0x554C($t4)
    ctx->r12 = MEM_B(ctx->r12, 0X554C);
    // 0x802A833C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802A8340: beq         $t4, $zero, L_802A837C
    if (ctx->r12 == 0) {
        // 0x802A8344: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802A837C;
    }
    // 0x802A8344: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A8348: lw          $a0, 0xC8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC8);
    // 0x802A834C: lb          $v0, 0x554B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X554B);
    // 0x802A8350: lw          $v1, 0xC4($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XC4);
    // 0x802A8354: multu       $a0, $v0
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8358: mflo        $t5
    ctx->r13 = lo;
    // 0x802A835C: sra         $t8, $t5, 4
    ctx->r24 = S32(SIGNED(ctx->r13) >> 4);
    // 0x802A8360: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    // 0x802A8364: multu       $v1, $v0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8368: sw          $a0, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->r4;
    // 0x802A836C: mflo        $t6
    ctx->r14 = lo;
    // 0x802A8370: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802A8374: addu        $v1, $v1, $t7
    ctx->r3 = ADD32(ctx->r3, ctx->r15);
    // 0x802A8378: sw          $v1, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r3;
L_802A837C:
    // 0x802A837C: lw          $t9, 0x5520($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5520);
    // 0x802A8380: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A8384: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    // 0x802A8388: lw          $t3, 0x0($t9)
    ctx->r11 = MEM_W(ctx->r25, 0X0);
    // 0x802A838C: lhu         $a0, 0xB6($t3)
    ctx->r4 = MEM_HU(ctx->r11, 0XB6);
    // 0x802A8390: sll         $t2, $a0, 2
    ctx->r10 = S32(ctx->r4 << 2);
    // 0x802A8394: subu        $t2, $t2, $a0
    ctx->r10 = SUB32(ctx->r10, ctx->r4);
    // 0x802A8398: sll         $t2, $t2, 3
    ctx->r10 = S32(ctx->r10 << 3);
    // 0x802A839C: addu        $t2, $t2, $a0
    ctx->r10 = ADD32(ctx->r10, ctx->r4);
    // 0x802A83A0: sll         $t2, $t2, 2
    ctx->r10 = S32(ctx->r10 << 2);
    // 0x802A83A4: jal         0x802AC484
    // 0x802A83A8: andi        $a0, $t2, 0xFFFF
    ctx->r4 = ctx->r10 & 0XFFFF;
    func_802AC484_6BDB34(rdram, ctx);
        goto after_18;
    // 0x802A83A8: andi        $a0, $t2, 0xFFFF
    ctx->r4 = ctx->r10 & 0XFFFF;
    after_18:
    // 0x802A83AC: lw          $t5, 0xC8($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XC8);
    // 0x802A83B0: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x802A83B4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A83B8: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A83BC: sw          $t5, 0x1C($t8)
    MEM_W(0X1C, ctx->r24) = ctx->r13;
    // 0x802A83C0: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x802A83C4: lw          $t6, 0xC4($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XC4);
    // 0x802A83C8: sw          $t6, 0x20($t7)
    MEM_W(0X20, ctx->r15) = ctx->r14;
    // 0x802A83CC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A83D0: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
    // 0x802A83D4: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x802A83D8: addu        $t2, $t9, $t3
    ctx->r10 = ADD32(ctx->r25, ctx->r11);
    // 0x802A83DC: sw          $t2, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r10;
    // 0x802A83E0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A83E4: lw          $t4, 0x8($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X8);
    // 0x802A83E8: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x802A83EC: addu        $t8, $t4, $t5
    ctx->r24 = ADD32(ctx->r12, ctx->r13);
    // 0x802A83F0: sw          $t8, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r24;
    // 0x802A83F4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A83F8: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x802A83FC: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x802A8400: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802A8404: sw          $t9, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r25;
    // 0x802A8408: b           L_802A90B0
    // 0x802A840C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A840C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8410:
    // 0x802A8410: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802A8414: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A8418: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802A841C: jal         0x8030AAE0
    // 0x802A8420: swc1        $f4, 0x5580($at)
    MEM_W(0X5580, ctx->r1) = ctx->f4.u32l;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_19;
    // 0x802A8420: swc1        $f4, 0x5580($at)
    MEM_W(0X5580, ctx->r1) = ctx->f4.u32l;
    after_19:
    // 0x802A8424: beq         $v0, $zero, L_802A8444
    if (ctx->r2 == 0) {
        // 0x802A8428: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A8444;
    }
    // 0x802A8428: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A842C: beq         $v0, $at, L_802A8578
    if (ctx->r2 == ctx->r1) {
        // 0x802A8430: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A8578;
    }
    // 0x802A8430: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A8434: beql        $v0, $at, L_802A8594
    if (ctx->r2 == ctx->r1) {
        // 0x802A8438: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8594;
    }
    goto skip_19;
    // 0x802A8438: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_19:
    // 0x802A843C: b           L_802A85A4
    // 0x802A8440: nop

        goto L_802A85A4;
    // 0x802A8440: nop

L_802A8444:
    // 0x802A8444: jal         0x802A64B0
    // 0x802A8448: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_20;
    // 0x802A8448: nop

    after_20:
    // 0x802A844C: beq         $v0, $zero, L_802A84AC
    if (ctx->r2 == 0) {
        // 0x802A8450: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802A84AC;
    }
    // 0x802A8450: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A8454: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8458: lui         $a2, 0x4
    ctx->r6 = S32(0X4 << 16);
    // 0x802A845C: lw          $t4, 0xB4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8460: lw          $t3, 0x24($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X24);
    // 0x802A8464: addu        $a0, $t3, $a2
    ctx->r4 = ADD32(ctx->r11, ctx->r6);
    // 0x802A8468: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A846C: beq         $at, $zero, L_802A847C
    if (ctx->r1 == 0) {
        // 0x802A8470: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802A847C;
    }
    // 0x802A8470: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802A8474: b           L_802A847C
    // 0x802A8478: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
        goto L_802A847C;
    // 0x802A8478: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_802A847C:
    // 0x802A847C: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802A8480: subu        $v0, $t2, $t4
    ctx->r2 = SUB32(ctx->r10, ctx->r12);
    // 0x802A8484: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A8488: beq         $at, $zero, L_802A84A8
    if (ctx->r1 == 0) {
        // 0x802A848C: slt         $at, $a0, $a2
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
            goto L_802A84A8;
    }
    // 0x802A848C: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A8490: beq         $at, $zero, L_802A84A0
    if (ctx->r1 == 0) {
        // 0x802A8494: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A84A0;
    }
    // 0x802A8494: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A8498: b           L_802A84A0
    // 0x802A849C: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A84A0;
    // 0x802A849C: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A84A0:
    // 0x802A84A0: b           L_802A84AC
    // 0x802A84A4: sw          $a1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r5;
        goto L_802A84AC;
    // 0x802A84A4: sw          $a1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r5;
L_802A84A8:
    // 0x802A84A8: sw          $v0, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r2;
L_802A84AC:
    // 0x802A84AC: lw          $a3, 0x552C($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X552C);
    // 0x802A84B0: addiu       $v1, $zero, 0x3
    ctx->r3 = ADD32(0, 0X3);
    // 0x802A84B4: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x802A84B8: lbu         $t5, 0x364($a3)
    ctx->r13 = MEM_BU(ctx->r7, 0X364);
    // 0x802A84BC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A84C0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A84C4: bne         $v1, $t5, L_802A84DC
    if (ctx->r3 != ctx->r13) {
        // 0x802A84C8: addiu       $a2, $sp, 0x88
        ctx->r6 = ADD32(ctx->r29, 0X88);
            goto L_802A84DC;
    }
    // 0x802A84C8: addiu       $a2, $sp, 0x88
    ctx->r6 = ADD32(ctx->r29, 0X88);
    // 0x802A84CC: sb          $t8, 0x364($a3)
    MEM_B(0X364, ctx->r7) = ctx->r24;
    // 0x802A84D0: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A84D4: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802A84D8: sh          $t6, 0x334($t7)
    MEM_H(0X334, ctx->r15) = ctx->r14;
L_802A84DC:
    // 0x802A84DC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A84E0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802A84E4: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x802A84E8: lhu         $t3, 0x48($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X48);
    // 0x802A84EC: addiu       $a3, $sp, 0x86
    ctx->r7 = ADD32(ctx->r29, 0X86);
    // 0x802A84F0: subu        $t2, $t9, $t3
    ctx->r10 = SUB32(ctx->r25, ctx->r11);
    // 0x802A84F4: slti        $at, $t2, 0x5
    ctx->r1 = SIGNED(ctx->r10) < 0X5 ? 1 : 0;
    // 0x802A84F8: bne         $at, $zero, L_802A85A4
    if (ctx->r1 != 0) {
        // 0x802A84FC: nop
    
            goto L_802A85A4;
    }
    // 0x802A84FC: nop

    // 0x802A8500: lbu         $t4, 0x160($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X160);
    // 0x802A8504: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A8508: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A850C: jal         0x80311A2C
    // 0x802A8510: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_21;
    // 0x802A8510: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_21:
    // 0x802A8514: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x802A8518: lh          $v0, 0x88($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X88);
    // 0x802A851C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802A8520: lh          $t8, 0x24($t5)
    ctx->r24 = MEM_H(ctx->r13, 0X24);
    // 0x802A8524: slti        $at, $t8, -0x6
    ctx->r1 = SIGNED(ctx->r24) < -0X6 ? 1 : 0;
    // 0x802A8528: bne         $at, $zero, L_802A8564
    if (ctx->r1 != 0) {
        // 0x802A852C: nop
    
            goto L_802A8564;
    }
    // 0x802A852C: nop

    // 0x802A8530: bgez        $v0, L_802A8540
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8534: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A8540;
    }
    // 0x802A8534: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A8538: b           L_802A8540
    // 0x802A853C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A8540;
    // 0x802A853C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A8540:
    // 0x802A8540: slti        $at, $v1, 0x18
    ctx->r1 = SIGNED(ctx->r3) < 0X18 ? 1 : 0;
    // 0x802A8544: beq         $at, $zero, L_802A85A4
    if (ctx->r1 == 0) {
        // 0x802A8548: lh          $v0, 0x86($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X86);
            goto L_802A85A4;
    }
    // 0x802A8548: lh          $v0, 0x86($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X86);
    // 0x802A854C: bgez        $v0, L_802A855C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8550: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802A855C;
    }
    // 0x802A8550: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802A8554: b           L_802A855C
    // 0x802A8558: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802A855C;
    // 0x802A8558: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802A855C:
    // 0x802A855C: slti        $at, $a1, 0x18
    ctx->r1 = SIGNED(ctx->r5) < 0X18 ? 1 : 0;
    // 0x802A8560: beq         $at, $zero, L_802A85A4
    if (ctx->r1 == 0) {
        // 0x802A8564: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802A85A4;
    }
L_802A8564:
    // 0x802A8564: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A8568: jal         0x802DBA58
    // 0x802A856C: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    func_802DBA58_6ED108(rdram, ctx);
        goto after_22;
    // 0x802A856C: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    after_22:
    // 0x802A8570: b           L_802A85A4
    // 0x802A8574: nop

        goto L_802A85A4;
    // 0x802A8574: nop

L_802A8578:
    // 0x802A8578: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A857C: lw          $t7, 0xB4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8580: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x802A8584: subu        $t9, $t6, $t7
    ctx->r25 = SUB32(ctx->r14, ctx->r15);
    // 0x802A8588: b           L_802A85A4
    // 0x802A858C: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
        goto L_802A85A4;
    // 0x802A858C: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x802A8590: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8594:
    // 0x802A8594: lw          $t2, 0xB4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8598: lw          $t3, 0xC($s0)
    ctx->r11 = MEM_W(ctx->r16, 0XC);
    // 0x802A859C: subu        $t4, $t3, $t2
    ctx->r12 = SUB32(ctx->r11, ctx->r10);
    // 0x802A85A0: sw          $t4, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r12;
L_802A85A4:
    // 0x802A85A4: jal         0x802B2834
    // 0x802A85A8: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_23;
    // 0x802A85A8: nop

    after_23:
    // 0x802A85AC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A85B0: lh          $t5, 0x5546($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5546);
    // 0x802A85B4: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    // 0x802A85B8: bne         $t5, $zero, L_802A87F4
    if (ctx->r13 != 0) {
        // 0x802A85BC: nop
    
            goto L_802A87F4;
    }
    // 0x802A85BC: nop

    // 0x802A85C0: jal         0x802AC8A0
    // 0x802A85C4: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802AC8A0_6BDF50(rdram, ctx);
        goto after_24;
    // 0x802A85C4: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_24:
    // 0x802A85C8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A85CC: lw          $t8, 0x5520($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5520);
    // 0x802A85D0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A85D4: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802A85D8: lw          $t6, 0x0($t8)
    ctx->r14 = MEM_W(ctx->r24, 0X0);
    // 0x802A85DC: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x802A85E0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A85E4: lhu         $t7, 0xB2($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XB2);
    // 0x802A85E8: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x802A85EC: sh          $t9, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r25;
    // 0x802A85F0: lhu         $t3, 0x9C($t0)
    ctx->r11 = MEM_HU(ctx->r8, 0X9C);
    // 0x802A85F4: bne         $t3, $at, L_802A86D8
    if (ctx->r11 != ctx->r1) {
        // 0x802A85F8: nop
    
            goto L_802A86D8;
    }
    // 0x802A85F8: nop

    // 0x802A85FC: lb          $t2, 0x554C($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X554C);
    // 0x802A8600: beql        $t2, $zero, L_802A87D0
    if (ctx->r10 == 0) {
        // 0x802A8604: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A87D0;
    }
    goto skip_20;
    // 0x802A8604: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_20:
    // 0x802A8608: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A860C: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802A8610: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802A8614: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8618: lw          $t4, 0x20($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X20);
    // 0x802A861C: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802A8620: mtc1        $a0, $f6
    ctx->f6.u32l = ctx->r4;
    // 0x802A8624: mtc1        $t4, $f10
    ctx->f10.u32l = ctx->r12;
    // 0x802A8628: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A862C: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x802A8630: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A8634: cvt.d.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.d = CVT_D_W(ctx->f10.u32l);
    // 0x802A8638: div.d       $f0, $f8, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f18.d); 
    ctx->f0.d = DIV_D(ctx->f8.d, ctx->f18.d);
    // 0x802A863C: div.d       $f2, $f4, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f18.d); 
    ctx->f2.d = DIV_D(ctx->f4.d, ctx->f18.d);
    // 0x802A8640: mul.d       $f6, $f0, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f0.d); 
    ctx->f6.d = MUL_D(ctx->f0.d, ctx->f0.d);
    // 0x802A8644: ldc1        $f4, -0x5190($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, -0X5190);
    // 0x802A8648: mul.d       $f8, $f2, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f2.d); 
    ctx->f8.d = MUL_D(ctx->f2.d, ctx->f2.d);
    // 0x802A864C: add.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = ctx->f6.d + ctx->f8.d;
    // 0x802A8650: c.lt.d      $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f10.d < ctx->f4.d;
    // 0x802A8654: nop

    // 0x802A8658: bc1fl       L_802A87D0
    if (!c1cs) {
        // 0x802A865C: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A87D0;
    }
    goto skip_21;
    // 0x802A865C: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_21:
    // 0x802A8660: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802A8664: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A8668: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A866C: lh          $t8, 0x302($t5)
    ctx->r24 = MEM_H(ctx->r13, 0X302);
    // 0x802A8670: addiu       $v1, $zero, 0xDE
    ctx->r3 = ADD32(0, 0XDE);
    // 0x802A8674: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x802A8678: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802A867C: addu        $t9, $v0, $t7
    ctx->r25 = ADD32(ctx->r2, ctx->r15);
    // 0x802A8680: lh          $t3, 0x0($t9)
    ctx->r11 = MEM_H(ctx->r25, 0X0);
    // 0x802A8684: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A8688: sra         $t2, $t3, 7
    ctx->r10 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802A868C: multu       $t2, $v1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8690: mflo        $t4
    ctx->r12 = lo;
    // 0x802A8694: addu        $t5, $a0, $t4
    ctx->r13 = ADD32(ctx->r4, ctx->r12);
    // 0x802A8698: sw          $t5, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r13;
    // 0x802A869C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802A86A0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A86A4: lh          $t7, 0x302($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X302);
    // 0x802A86A8: lw          $t8, 0x20($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X20);
    // 0x802A86AC: addiu       $t9, $t7, 0x40
    ctx->r25 = ADD32(ctx->r15, 0X40);
    // 0x802A86B0: andi        $t3, $t9, 0xFF
    ctx->r11 = ctx->r25 & 0XFF;
    // 0x802A86B4: sll         $t2, $t3, 1
    ctx->r10 = S32(ctx->r11 << 1);
    // 0x802A86B8: addu        $t4, $v0, $t2
    ctx->r12 = ADD32(ctx->r2, ctx->r10);
    // 0x802A86BC: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x802A86C0: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802A86C4: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A86C8: mflo        $t7
    ctx->r15 = lo;
    // 0x802A86CC: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x802A86D0: b           L_802A87CC
    // 0x802A86D4: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
        goto L_802A87CC;
    // 0x802A86D4: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
L_802A86D8:
    // 0x802A86D8: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A86DC: lb          $t3, 0x554C($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X554C);
    // 0x802A86E0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A86E4: lw          $t2, 0xC8($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC8);
    // 0x802A86E8: beql        $t3, $zero, L_802A87D0
    if (ctx->r11 == 0) {
        // 0x802A86EC: lhu         $a0, 0x8A($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A87D0;
    }
    goto skip_22;
    // 0x802A86EC: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    skip_22:
    // 0x802A86F0: lb          $v0, 0x554B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X554B);
    // 0x802A86F4: lw          $t8, 0xC4($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XC4);
    // 0x802A86F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A86FC: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8700: mflo        $t4
    ctx->r12 = lo;
    // 0x802A8704: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802A8708: addu        $t6, $t2, $t5
    ctx->r14 = ADD32(ctx->r10, ctx->r13);
    // 0x802A870C: multu       $t8, $v0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8710: sw          $t6, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->r14;
    // 0x802A8714: mflo        $t7
    ctx->r15 = lo;
    // 0x802A8718: sra         $t9, $t7, 4
    ctx->r25 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802A871C: addu        $t3, $t8, $t9
    ctx->r11 = ADD32(ctx->r24, ctx->r25);
    // 0x802A8720: sw          $t3, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r11;
    // 0x802A8724: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8728: bgez        $a0, L_802A8738
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A872C: or          $a2, $a0, $zero
        ctx->r6 = ctx->r4 | 0;
            goto L_802A8738;
    }
    // 0x802A872C: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802A8730: b           L_802A8738
    // 0x802A8734: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
        goto L_802A8738;
    // 0x802A8734: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
L_802A8738:
    // 0x802A8738: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802A873C: lhu         $t5, 0x8A($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A8740: bgez        $v0, L_802A8750
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8744: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A8750;
    }
    // 0x802A8744: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A8748: b           L_802A8750
    // 0x802A874C: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A8750;
    // 0x802A874C: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A8750:
    // 0x802A8750: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A8754: beq         $at, $zero, L_802A8764
    if (ctx->r1 == 0) {
        // 0x802A8758: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A8764;
    }
    // 0x802A8758: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A875C: b           L_802A8764
    // 0x802A8760: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A8764;
    // 0x802A8760: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A8764:
    // 0x802A8764: slt         $at, $a2, $a0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802A8768: beq         $at, $zero, L_802A8778
    if (ctx->r1 == 0) {
        // 0x802A876C: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802A8778;
    }
    // 0x802A876C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802A8770: b           L_802A8778
    // 0x802A8774: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
        goto L_802A8778;
    // 0x802A8774: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_802A8778:
    // 0x802A8778: lhu         $a0, 0xA4($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0XA4);
    // 0x802A877C: sra         $t4, $v1, 1
    ctx->r12 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802A8780: addu        $v0, $t4, $a1
    ctx->r2 = ADD32(ctx->r12, ctx->r5);
    // 0x802A8784: sll         $t2, $a0, 11
    ctx->r10 = S32(ctx->r4 << 11);
    // 0x802A8788: slt         $at, $t2, $v0
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A878C: beq         $at, $zero, L_802A87AC
    if (ctx->r1 == 0) {
        // 0x802A8790: sll         $t7, $a0, 10
        ctx->r15 = S32(ctx->r4 << 10);
            goto L_802A87AC;
    }
    // 0x802A8790: sll         $t7, $a0, 10
    ctx->r15 = S32(ctx->r4 << 10);
    // 0x802A8794: bgez        $t5, L_802A87A4
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802A8798: sra         $t6, $t5, 2
        ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
            goto L_802A87A4;
    }
    // 0x802A8798: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x802A879C: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x802A87A0: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_802A87A4:
    // 0x802A87A4: b           L_802A87CC
    // 0x802A87A8: sh          $t6, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r14;
        goto L_802A87CC;
    // 0x802A87A8: sh          $t6, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r14;
L_802A87AC:
    // 0x802A87AC: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A87B0: beq         $at, $zero, L_802A87CC
    if (ctx->r1 == 0) {
        // 0x802A87B4: lhu         $t8, 0x8A($sp)
        ctx->r24 = MEM_HU(ctx->r29, 0X8A);
            goto L_802A87CC;
    }
    // 0x802A87B4: lhu         $t8, 0x8A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A87B8: bgez        $t8, L_802A87C8
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802A87BC: sra         $t9, $t8, 1
        ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
            goto L_802A87C8;
    }
    // 0x802A87BC: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802A87C0: addiu       $at, $t8, 0x1
    ctx->r1 = ADD32(ctx->r24, 0X1);
    // 0x802A87C4: sra         $t9, $at, 1
    ctx->r25 = S32(SIGNED(ctx->r1) >> 1);
L_802A87C8:
    // 0x802A87C8: sh          $t9, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r25;
L_802A87CC:
    // 0x802A87CC: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
L_802A87D0:
    // 0x802A87D0: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A87D4: jal         0x802AC484
    // 0x802A87D8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    func_802AC484_6BDB34(rdram, ctx);
        goto after_25;
    // 0x802A87D8: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    after_25:
    // 0x802A87DC: lw          $t3, 0xC8($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XC8);
    // 0x802A87E0: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x802A87E4: sw          $t3, 0x1C($t4)
    MEM_W(0X1C, ctx->r12) = ctx->r11;
    // 0x802A87E8: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x802A87EC: lw          $t2, 0xC4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC4);
    // 0x802A87F0: sw          $t2, 0x20($t5)
    MEM_W(0X20, ctx->r13) = ctx->r10;
L_802A87F4:
    // 0x802A87F4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A87F8: lw          $a3, 0x552C($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X552C);
    // 0x802A87FC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A8800: lb          $t6, 0x360($a3)
    ctx->r14 = MEM_B(ctx->r7, 0X360);
    // 0x802A8804: bnel        $t6, $zero, L_802A889C
    if (ctx->r14 != 0) {
        // 0x802A8808: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A889C;
    }
    goto skip_23;
    // 0x802A8808: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_23:
    // 0x802A880C: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802A8810: lhu         $t7, 0xA2($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0XA2);
    // 0x802A8814: andi        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 & 0X1;
    // 0x802A8818: beql        $t8, $zero, L_802A8884
    if (ctx->r24 == 0) {
        // 0x802A881C: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8884;
    }
    goto skip_24;
    // 0x802A881C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_24:
    // 0x802A8820: lhu         $t9, 0x9E($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0X9E);
    // 0x802A8824: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802A8828: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A882C: beq         $t9, $at, L_802A8880
    if (ctx->r25 == ctx->r1) {
        // 0x802A8830: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_802A8880;
    }
    // 0x802A8830: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A8834: lhu         $t3, 0x5544($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X5544);
    // 0x802A8838: lhu         $t4, 0x555A($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X555A);
    // 0x802A883C: subu        $t2, $t3, $t4
    ctx->r10 = SUB32(ctx->r11, ctx->r12);
    // 0x802A8840: andi        $t5, $t2, 0xFFFF
    ctx->r13 = ctx->r10 & 0XFFFF;
    // 0x802A8844: slti        $at, $t5, 0x3
    ctx->r1 = SIGNED(ctx->r13) < 0X3 ? 1 : 0;
    // 0x802A8848: beql        $at, $zero, L_802A8884
    if (ctx->r1 == 0) {
        // 0x802A884C: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8884;
    }
    goto skip_25;
    // 0x802A884C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_25:
    // 0x802A8850: lbu         $t6, 0x367($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X367);
    // 0x802A8854: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A8858: bnel        $t6, $zero, L_802A8884
    if (ctx->r14 != 0) {
        // 0x802A885C: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8884;
    }
    goto skip_26;
    // 0x802A885C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_26:
    // 0x802A8860: lw          $v0, 0x5560($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5560);
    // 0x802A8864: beql        $v0, $zero, L_802A889C
    if (ctx->r2 == 0) {
        // 0x802A8868: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A889C;
    }
    goto skip_27;
    // 0x802A8868: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_27:
    // 0x802A886C: lw          $t7, 0x16C($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X16C);
    // 0x802A8870: lw          $t8, 0x80($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X80);
    // 0x802A8874: sll         $t3, $t8, 17
    ctx->r11 = S32(ctx->r24 << 17);
    // 0x802A8878: bltzl       $t3, L_802A889C
    if (SIGNED(ctx->r11) < 0) {
        // 0x802A887C: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A889C;
    }
    goto skip_28;
    // 0x802A887C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_28:
L_802A8880:
    // 0x802A8880: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8884:
    // 0x802A8884: lui         $t2, 0x803A
    ctx->r10 = S32(0X803A << 16);
    // 0x802A8888: lw          $t2, 0x5B0($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5B0);
    // 0x802A888C: lw          $t4, 0x24($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X24);
    // 0x802A8890: subu        $t5, $t4, $t2
    ctx->r13 = SUB32(ctx->r12, ctx->r10);
    // 0x802A8894: sw          $t5, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r13;
    // 0x802A8898: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A889C:
    // 0x802A889C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A88A0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A88A4: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    // 0x802A88A8: lw          $t7, 0x1C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X1C);
    // 0x802A88AC: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802A88B0: sw          $t8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r24;
    // 0x802A88B4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A88B8: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x802A88BC: lw          $t3, 0x20($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X20);
    // 0x802A88C0: addu        $t4, $t9, $t3
    ctx->r12 = ADD32(ctx->r25, ctx->r11);
    // 0x802A88C4: sw          $t4, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r12;
    // 0x802A88C8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A88CC: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802A88D0: lw          $t5, 0x24($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X24);
    // 0x802A88D4: addu        $t6, $t2, $t5
    ctx->r14 = ADD32(ctx->r10, ctx->r13);
    // 0x802A88D8: sw          $t6, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r14;
    // 0x802A88DC: b           L_802A90B0
    // 0x802A88E0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A88E0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A88E4:
    // 0x802A88E4: lw          $v1, 0x4($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X4);
    // 0x802A88E8: sw          $v1, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r3;
    // 0x802A88EC: lw          $a2, 0x8($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X8);
    // 0x802A88F0: sw          $a2, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->r6;
    // 0x802A88F4: lw          $v0, 0xC($s0)
    ctx->r2 = MEM_W(ctx->r16, 0XC);
    // 0x802A88F8: sw          $v0, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r2;
    // 0x802A88FC: lw          $t7, 0x1C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8900: lw          $t8, 0x20($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X20);
    // 0x802A8904: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802A8908: addu        $a3, $v1, $t7
    ctx->r7 = ADD32(ctx->r3, ctx->r15);
    // 0x802A890C: addu        $t0, $a2, $t8
    ctx->r8 = ADD32(ctx->r6, ctx->r24);
    // 0x802A8910: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802A8914: sra         $a0, $a3, 16
    ctx->r4 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802A8918: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x802A891C: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x802A8920: addu        $t3, $v0, $t9
    ctx->r11 = ADD32(ctx->r2, ctx->r25);
    // 0x802A8924: sw          $t3, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r11;
    // 0x802A8928: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802A892C: jal         0x8031124C
    // 0x802A8930: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_26;
    // 0x802A8930: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    after_26:
    // 0x802A8934: lw          $t7, 0x8C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X8C);
    // 0x802A8938: sra         $t9, $v0, 16
    ctx->r25 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802A893C: sll         $t3, $t9, 16
    ctx->r11 = S32(ctx->r25 << 16);
    // 0x802A8940: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802A8944: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802A8948: subu        $t2, $t8, $t4
    ctx->r10 = SUB32(ctx->r24, ctx->r12);
    // 0x802A894C: slti        $at, $t2, 0xA
    ctx->r1 = SIGNED(ctx->r10) < 0XA ? 1 : 0;
    // 0x802A8950: beq         $at, $zero, L_802A8A0C
    if (ctx->r1 == 0) {
        // 0x802A8954: nop
    
            goto L_802A8A0C;
    }
    // 0x802A8954: nop

    // 0x802A8958: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A895C: lw          $t5, 0x4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X4);
    // 0x802A8960: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8964: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x802A8968: lw          $t4, 0x20($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X20);
    // 0x802A896C: addu        $a0, $t5, $t6
    ctx->r4 = ADD32(ctx->r13, ctx->r14);
    // 0x802A8970: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802A8974: addu        $a1, $t8, $t4
    ctx->r5 = ADD32(ctx->r24, ctx->r12);
    // 0x802A8978: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802A897C: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x802A8980: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x802A8984: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802A8988: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802A898C: jal         0x80310EE4
    // 0x802A8990: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_27;
    // 0x802A8990: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    after_27:
    // 0x802A8994: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8998: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802A899C: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802A89A0: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    // 0x802A89A4: jal         0x80310EE4
    // 0x802A89A8: sw          $v0, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r2;
    func_80310EE4_722594(rdram, ctx);
        goto after_28;
    // 0x802A89A8: sw          $v0, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r2;
    after_28:
    // 0x802A89AC: lw          $v1, 0x6C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X6C);
    // 0x802A89B0: lui         $a3, 0x6
    ctx->r7 = S32(0X6 << 16);
    // 0x802A89B4: subu        $a0, $v1, $v0
    ctx->r4 = SUB32(ctx->r3, ctx->r2);
    // 0x802A89B8: slt         $at, $a0, $a3
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802A89BC: beq         $at, $zero, L_802A89CC
    if (ctx->r1 == 0) {
        // 0x802A89C0: or          $a2, $a0, $zero
        ctx->r6 = ctx->r4 | 0;
            goto L_802A89CC;
    }
    // 0x802A89C0: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802A89C4: b           L_802A89D0
    // 0x802A89C8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802A89D0;
    // 0x802A89C8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802A89CC:
    // 0x802A89CC: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
L_802A89D0:
    // 0x802A89D0: bgez        $v1, L_802A89E0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802A89D4: slt         $at, $a2, $a3
        ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
            goto L_802A89E0;
    }
    // 0x802A89D4: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802A89D8: b           L_802A89F4
    // 0x802A89DC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
        goto L_802A89F4;
    // 0x802A89DC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_802A89E0:
    // 0x802A89E0: beq         $at, $zero, L_802A89F0
    if (ctx->r1 == 0) {
        // 0x802A89E4: or          $a1, $a3, $zero
        ctx->r5 = ctx->r7 | 0;
            goto L_802A89F0;
    }
    // 0x802A89E4: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802A89E8: b           L_802A89F0
    // 0x802A89EC: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A89F0;
    // 0x802A89EC: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A89F0:
    // 0x802A89F0: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
L_802A89F4:
    // 0x802A89F4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A89F8: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x802A89FC: slt         $at, $t7, $a2
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A8A00: beq         $at, $zero, L_802A8A0C
    if (ctx->r1 == 0) {
        // 0x802A8A04: nop
    
            goto L_802A8A0C;
    }
    // 0x802A8A04: nop

    // 0x802A8A08: sw          $a2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r6;
L_802A8A0C:
    // 0x802A8A0C: jal         0x8030AAE0
    // 0x802A8A10: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_8030AAE0_71C190(rdram, ctx);
        goto after_29;
    // 0x802A8A10: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_29:
    // 0x802A8A14: beq         $v0, $zero, L_802A8A34
    if (ctx->r2 == 0) {
        // 0x802A8A18: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A8A34;
    }
    // 0x802A8A18: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A8A1C: beq         $v0, $at, L_802A8A78
    if (ctx->r2 == ctx->r1) {
        // 0x802A8A20: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A8A78;
    }
    // 0x802A8A20: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A8A24: beql        $v0, $at, L_802A8A84
    if (ctx->r2 == ctx->r1) {
        // 0x802A8A28: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8A84;
    }
    goto skip_29;
    // 0x802A8A28: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_29:
    // 0x802A8A2C: b           L_802A8A84
    // 0x802A8A30: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A8A84;
    // 0x802A8A30: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8A34:
    // 0x802A8A34: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8A38: lw          $t9, 0x6C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X6C);
    // 0x802A8A3C: bnel        $t9, $zero, L_802A8A88
    if (ctx->r25 != 0) {
        // 0x802A8A40: lw          $t7, 0xC($s0)
        ctx->r15 = MEM_W(ctx->r16, 0XC);
            goto L_802A8A88;
    }
    goto skip_30;
    // 0x802A8A40: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    skip_30:
    // 0x802A8A44: lw          $t3, 0x70($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X70);
    // 0x802A8A48: lw          $t8, 0xAC($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XAC);
    // 0x802A8A4C: bnel        $t3, $zero, L_802A8A88
    if (ctx->r11 != 0) {
        // 0x802A8A50: lw          $t7, 0xC($s0)
        ctx->r15 = MEM_W(ctx->r16, 0XC);
            goto L_802A8A88;
    }
    goto skip_31;
    // 0x802A8A50: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
    skip_31:
    // 0x802A8A54: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x802A8A58: lw          $t2, 0x0($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X0);
    // 0x802A8A5C: lw          $t4, 0xA8($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XA8);
    // 0x802A8A60: sw          $t4, 0x8($t2)
    MEM_W(0X8, ctx->r10) = ctx->r12;
    // 0x802A8A64: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x802A8A68: lw          $t5, 0xA4($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XA4);
    // 0x802A8A6C: sw          $t5, 0xC($t6)
    MEM_W(0XC, ctx->r14) = ctx->r13;
    // 0x802A8A70: b           L_802A8A84
    // 0x802A8A74: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A8A84;
    // 0x802A8A74: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8A78:
    // 0x802A8A78: b           L_802A8A84
    // 0x802A8A7C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A8A84;
    // 0x802A8A7C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8A80: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8A84:
    // 0x802A8A84: lw          $t7, 0xC($s0)
    ctx->r15 = MEM_W(ctx->r16, 0XC);
L_802A8A88:
    // 0x802A8A88: lw          $t9, 0xB4($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8A8C: subu        $t3, $t7, $t9
    ctx->r11 = SUB32(ctx->r15, ctx->r25);
    // 0x802A8A90: jal         0x802B2964
    // 0x802A8A94: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
    func_802B2964_6C4014(rdram, ctx);
        goto after_30;
    // 0x802A8A94: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
    after_30:
    // 0x802A8A98: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    // 0x802A8A9C: jal         0x802A403C
    // 0x802A8AA0: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_31;
    // 0x802A8AA0: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    after_31:
    // 0x802A8AA4: jal         0x802A4184
    // 0x802A8AA8: nop

    func_802A4184_6B5834(rdram, ctx);
        goto after_32;
    // 0x802A8AA8: nop

    after_32:
    // 0x802A8AAC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8AB0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A8AB4: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A8AB8: lw          $t8, 0x4($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4);
    // 0x802A8ABC: lw          $t4, 0x1C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8AC0: addu        $t2, $t8, $t4
    ctx->r10 = ADD32(ctx->r24, ctx->r12);
    // 0x802A8AC4: sw          $t2, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r10;
    // 0x802A8AC8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8ACC: lw          $t5, 0x8($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X8);
    // 0x802A8AD0: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802A8AD4: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802A8AD8: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x802A8ADC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8AE0: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x802A8AE4: lw          $t3, 0x24($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X24);
    // 0x802A8AE8: addu        $t8, $t9, $t3
    ctx->r24 = ADD32(ctx->r25, ctx->r11);
    // 0x802A8AEC: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
    // 0x802A8AF0: b           L_802A90B0
    // 0x802A8AF4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A8AF4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8AF8:
    // 0x802A8AF8: lw          $t4, 0x4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4);
    // 0x802A8AFC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802A8B00: sw          $t4, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r12;
    // 0x802A8B04: lw          $t2, 0x8($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X8);
    // 0x802A8B08: sw          $t2, 0xB8($sp)
    MEM_W(0XB8, ctx->r29) = ctx->r10;
    // 0x802A8B0C: lbu         $t5, 0x160($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X160);
    // 0x802A8B10: jal         0x8030AAE0
    // 0x802A8B14: sb          $t5, 0x7B($sp)
    MEM_B(0X7B, ctx->r29) = ctx->r13;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_33;
    // 0x802A8B14: sb          $t5, 0x7B($sp)
    MEM_B(0X7B, ctx->r29) = ctx->r13;
    after_33:
    // 0x802A8B18: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B1C: lw          $t7, 0xBC($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XBC);
    // 0x802A8B20: lw          $t3, 0xB8($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XB8);
    // 0x802A8B24: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    // 0x802A8B28: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x802A8B2C: subu        $a0, $t6, $t7
    ctx->r4 = SUB32(ctx->r14, ctx->r15);
    // 0x802A8B30: jal         0x802B2AF0
    // 0x802A8B34: subu        $a1, $t9, $t3
    ctx->r5 = SUB32(ctx->r25, ctx->r11);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_34;
    // 0x802A8B34: subu        $a1, $t9, $t3
    ctx->r5 = SUB32(ctx->r25, ctx->r11);
    after_34:
    // 0x802A8B38: beq         $v0, $zero, L_802A8BC4
    if (ctx->r2 == 0) {
        // 0x802A8B3C: lbu         $t8, 0x7B($sp)
        ctx->r24 = MEM_BU(ctx->r29, 0X7B);
            goto L_802A8BC4;
    }
    // 0x802A8B3C: lbu         $t8, 0x7B($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X7B);
    // 0x802A8B40: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B44: lw          $v0, 0xBC($sp)
    ctx->r2 = MEM_W(ctx->r29, 0XBC);
    // 0x802A8B48: sb          $t8, 0x160($t4)
    MEM_B(0X160, ctx->r12) = ctx->r24;
    // 0x802A8B4C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B50: lw          $t2, 0x4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4);
    // 0x802A8B54: sw          $t2, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r10;
    // 0x802A8B58: sw          $v0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r2;
    // 0x802A8B5C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B60: lw          $t7, 0xB8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB8);
    // 0x802A8B64: lw          $t5, 0x4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X4);
    // 0x802A8B68: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x802A8B6C: subu        $a0, $t5, $v0
    ctx->r4 = SUB32(ctx->r13, ctx->r2);
    // 0x802A8B70: jal         0x802B2AF0
    // 0x802A8B74: subu        $a1, $t6, $t7
    ctx->r5 = SUB32(ctx->r14, ctx->r15);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_35;
    // 0x802A8B74: subu        $a1, $t6, $t7
    ctx->r5 = SUB32(ctx->r14, ctx->r15);
    after_35:
    // 0x802A8B78: beq         $v0, $zero, L_802A8BC4
    if (ctx->r2 == 0) {
        // 0x802A8B7C: lw          $t9, 0xB0($sp)
        ctx->r25 = MEM_W(ctx->r29, 0XB0);
            goto L_802A8BC4;
    }
    // 0x802A8B7C: lw          $t9, 0xB0($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XB0);
    // 0x802A8B80: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B84: sw          $t9, 0x4($t3)
    MEM_W(0X4, ctx->r11) = ctx->r25;
    // 0x802A8B88: lw          $t8, 0xB8($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XB8);
    // 0x802A8B8C: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B90: sw          $t8, 0x8($t4)
    MEM_W(0X8, ctx->r12) = ctx->r24;
    // 0x802A8B94: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8B98: lw          $t7, 0xB8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB8);
    // 0x802A8B9C: lw          $t5, 0xBC($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XBC);
    // 0x802A8BA0: lw          $t2, 0x4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4);
    // 0x802A8BA4: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x802A8BA8: subu        $a0, $t2, $t5
    ctx->r4 = SUB32(ctx->r10, ctx->r13);
    // 0x802A8BAC: jal         0x802B2AF0
    // 0x802A8BB0: subu        $a1, $t6, $t7
    ctx->r5 = SUB32(ctx->r14, ctx->r15);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_36;
    // 0x802A8BB0: subu        $a1, $t6, $t7
    ctx->r5 = SUB32(ctx->r14, ctx->r15);
    after_36:
    // 0x802A8BB4: beq         $v0, $zero, L_802A8BC4
    if (ctx->r2 == 0) {
        // 0x802A8BB8: lw          $t9, 0xBC($sp)
        ctx->r25 = MEM_W(ctx->r29, 0XBC);
            goto L_802A8BC4;
    }
    // 0x802A8BB8: lw          $t9, 0xBC($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XBC);
    // 0x802A8BBC: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x802A8BC0: sw          $t9, 0x4($t3)
    MEM_W(0X4, ctx->r11) = ctx->r25;
L_802A8BC4:
    // 0x802A8BC4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8BC8: lw          $t4, 0xB4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8BCC: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x802A8BD0: subu        $t2, $t8, $t4
    ctx->r10 = SUB32(ctx->r24, ctx->r12);
    // 0x802A8BD4: jal         0x802B2964
    // 0x802A8BD8: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
    func_802B2964_6C4014(rdram, ctx);
        goto after_37;
    // 0x802A8BD8: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
    after_37:
    // 0x802A8BDC: jal         0x802A40EC
    // 0x802A8BE0: nop

    func_802A40EC_6B579C(rdram, ctx);
        goto after_38;
    // 0x802A8BE0: nop

    after_38:
    // 0x802A8BE4: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    // 0x802A8BE8: jal         0x802AC5CC
    // 0x802A8BEC: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_39;
    // 0x802A8BEC: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_39:
    // 0x802A8BF0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A8BF4: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802A8BF8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A8BFC: lw          $t5, 0x5520($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5520);
    // 0x802A8C00: lhu         $t7, 0x9C($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0X9C);
    // 0x802A8C04: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802A8C08: lw          $t6, 0x0($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X0);
    // 0x802A8C0C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A8C10: bne         $t7, $at, L_802A8CD0
    if (ctx->r15 != ctx->r1) {
        // 0x802A8C14: lhu         $a3, 0xB4($t6)
        ctx->r7 = MEM_HU(ctx->r14, 0XB4);
            goto L_802A8CD0;
    }
    // 0x802A8C14: lhu         $a3, 0xB4($t6)
    ctx->r7 = MEM_HU(ctx->r14, 0XB4);
    // 0x802A8C18: sll         $a2, $a3, 16
    ctx->r6 = S32(ctx->r7 << 16);
    // 0x802A8C1C: sra         $t9, $a2, 16
    ctx->r25 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802A8C20: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802A8C24: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x802A8C28: addiu       $a1, $zero, 0xC
    ctx->r5 = ADD32(0, 0XC);
    // 0x802A8C2C: jal         0x802A4278
    // 0x802A8C30: sh          $a3, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r7;
    func_802A4278_6B5928(rdram, ctx);
        goto after_40;
    // 0x802A8C30: sh          $a3, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r7;
    after_40:
    // 0x802A8C34: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A8C38: lb          $t3, 0x554C($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X554C);
    // 0x802A8C3C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A8C40: beql        $t3, $zero, L_802A8DA8
    if (ctx->r11 == 0) {
        // 0x802A8C44: addiu       $a0, $sp, 0xC8
        ctx->r4 = ADD32(ctx->r29, 0XC8);
            goto L_802A8DA8;
    }
    goto skip_32;
    // 0x802A8C44: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    skip_32:
    // 0x802A8C48: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802A8C4C: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A8C50: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A8C54: lh          $t2, 0x302($t4)
    ctx->r10 = MEM_H(ctx->r12, 0X302);
    // 0x802A8C58: addiu       $v1, $zero, 0x3
    ctx->r3 = ADD32(0, 0X3);
    // 0x802A8C5C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8C60: andi        $t5, $t2, 0xFF
    ctx->r13 = ctx->r10 & 0XFF;
    // 0x802A8C64: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802A8C68: addu        $t7, $v0, $t6
    ctx->r15 = ADD32(ctx->r2, ctx->r14);
    // 0x802A8C6C: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802A8C70: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8C74: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A8C78: sra         $t3, $t9, 7
    ctx->r11 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802A8C7C: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8C80: mflo        $t4
    ctx->r12 = lo;
    // 0x802A8C84: sll         $t2, $t4, 6
    ctx->r10 = S32(ctx->r12 << 6);
    // 0x802A8C88: addu        $t5, $t8, $t2
    ctx->r13 = ADD32(ctx->r24, ctx->r10);
    // 0x802A8C8C: sw          $t5, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r13;
    // 0x802A8C90: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A8C94: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8C98: lh          $t9, 0x302($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X302);
    // 0x802A8C9C: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802A8CA0: addiu       $t3, $t9, 0x40
    ctx->r11 = ADD32(ctx->r25, 0X40);
    // 0x802A8CA4: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x802A8CA8: sll         $t8, $t4, 1
    ctx->r24 = S32(ctx->r12 << 1);
    // 0x802A8CAC: addu        $t2, $v0, $t8
    ctx->r10 = ADD32(ctx->r2, ctx->r24);
    // 0x802A8CB0: lh          $t5, 0x0($t2)
    ctx->r13 = MEM_H(ctx->r10, 0X0);
    // 0x802A8CB4: sra         $t7, $t5, 7
    ctx->r15 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802A8CB8: multu       $t7, $v1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8CBC: mflo        $t9
    ctx->r25 = lo;
    // 0x802A8CC0: sll         $t3, $t9, 6
    ctx->r11 = S32(ctx->r25 << 6);
    // 0x802A8CC4: addu        $t4, $t6, $t3
    ctx->r12 = ADD32(ctx->r14, ctx->r11);
    // 0x802A8CC8: b           L_802A8DA4
    // 0x802A8CCC: sw          $t4, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r12;
        goto L_802A8DA4;
    // 0x802A8CCC: sw          $t4, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r12;
L_802A8CD0:
    // 0x802A8CD0: lb          $t8, 0x554C($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X554C);
    // 0x802A8CD4: sh          $a3, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r7;
    // 0x802A8CD8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A8CDC: beq         $t8, $zero, L_802A8DA4
    if (ctx->r24 == 0) {
        // 0x802A8CE0: lw          $t2, 0xC8($sp)
        ctx->r10 = MEM_W(ctx->r29, 0XC8);
            goto L_802A8DA4;
    }
    // 0x802A8CE0: lw          $t2, 0xC8($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC8);
    // 0x802A8CE4: lb          $v0, 0x554B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X554B);
    // 0x802A8CE8: lw          $t6, 0xC4($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XC4);
    // 0x802A8CEC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8CF0: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8CF4: mflo        $t5
    ctx->r13 = lo;
    // 0x802A8CF8: sra         $t7, $t5, 4
    ctx->r15 = S32(SIGNED(ctx->r13) >> 4);
    // 0x802A8CFC: addu        $t9, $t2, $t7
    ctx->r25 = ADD32(ctx->r10, ctx->r15);
    // 0x802A8D00: multu       $t6, $v0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A8D04: sw          $t9, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->r25;
    // 0x802A8D08: mflo        $t3
    ctx->r11 = lo;
    // 0x802A8D0C: sra         $t4, $t3, 4
    ctx->r12 = S32(SIGNED(ctx->r11) >> 4);
    // 0x802A8D10: addu        $t8, $t6, $t4
    ctx->r24 = ADD32(ctx->r14, ctx->r12);
    // 0x802A8D14: sw          $t8, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r24;
    // 0x802A8D18: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8D1C: bgez        $a0, L_802A8D2C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A8D20: or          $a2, $a0, $zero
        ctx->r6 = ctx->r4 | 0;
            goto L_802A8D2C;
    }
    // 0x802A8D20: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802A8D24: b           L_802A8D2C
    // 0x802A8D28: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
        goto L_802A8D2C;
    // 0x802A8D28: negu        $a2, $a0
    ctx->r6 = SUB32(0, ctx->r4);
L_802A8D2C:
    // 0x802A8D2C: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802A8D30: sll         $t8, $a3, 1
    ctx->r24 = S32(ctx->r7 << 1);
    // 0x802A8D34: bgez        $v0, L_802A8D44
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A8D38: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802A8D44;
    }
    // 0x802A8D38: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802A8D3C: b           L_802A8D44
    // 0x802A8D40: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802A8D44;
    // 0x802A8D40: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802A8D44:
    // 0x802A8D44: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A8D48: beq         $at, $zero, L_802A8D58
    if (ctx->r1 == 0) {
        // 0x802A8D4C: or          $a1, $a0, $zero
        ctx->r5 = ctx->r4 | 0;
            goto L_802A8D58;
    }
    // 0x802A8D4C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802A8D50: b           L_802A8D58
    // 0x802A8D54: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A8D58;
    // 0x802A8D54: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A8D58:
    // 0x802A8D58: slt         $at, $a2, $a0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802A8D5C: beq         $at, $zero, L_802A8D6C
    if (ctx->r1 == 0) {
        // 0x802A8D60: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802A8D6C;
    }
    // 0x802A8D60: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802A8D64: b           L_802A8D6C
    // 0x802A8D68: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
        goto L_802A8D6C;
    // 0x802A8D68: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_802A8D6C:
    // 0x802A8D6C: lhu         $t5, 0xAA($t0)
    ctx->r13 = MEM_HU(ctx->r8, 0XAA);
    // 0x802A8D70: sra         $t7, $v1, 1
    ctx->r15 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802A8D74: addu        $t9, $t7, $a1
    ctx->r25 = ADD32(ctx->r15, ctx->r5);
    // 0x802A8D78: sll         $t2, $t5, 10
    ctx->r10 = S32(ctx->r13 << 10);
    // 0x802A8D7C: slt         $at, $t2, $t9
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802A8D80: beql        $at, $zero, L_802A8DA4
    if (ctx->r1 == 0) {
        // 0x802A8D84: sh          $t8, 0x8A($sp)
        MEM_H(0X8A, ctx->r29) = ctx->r24;
            goto L_802A8DA4;
    }
    goto skip_33;
    // 0x802A8D84: sh          $t8, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r24;
    skip_33:
    // 0x802A8D88: bgez        $a3, L_802A8D98
    if (SIGNED(ctx->r7) >= 0) {
        // 0x802A8D8C: sra         $t3, $a3, 1
        ctx->r11 = S32(SIGNED(ctx->r7) >> 1);
            goto L_802A8D98;
    }
    // 0x802A8D8C: sra         $t3, $a3, 1
    ctx->r11 = S32(SIGNED(ctx->r7) >> 1);
    // 0x802A8D90: addiu       $at, $a3, 0x1
    ctx->r1 = ADD32(ctx->r7, 0X1);
    // 0x802A8D94: sra         $t3, $at, 1
    ctx->r11 = S32(SIGNED(ctx->r1) >> 1);
L_802A8D98:
    // 0x802A8D98: b           L_802A8DA4
    // 0x802A8D9C: sh          $t3, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r11;
        goto L_802A8DA4;
    // 0x802A8D9C: sh          $t3, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r11;
    // 0x802A8DA0: sh          $t8, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r24;
L_802A8DA4:
    // 0x802A8DA4: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
L_802A8DA8:
    // 0x802A8DA8: jal         0x802A3F68
    // 0x802A8DAC: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802A3F68_6B5618(rdram, ctx);
        goto after_41;
    // 0x802A8DAC: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_41:
    // 0x802A8DB0: lhu         $a0, 0x8A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X8A);
    // 0x802A8DB4: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A8DB8: jal         0x802AC158
    // 0x802A8DBC: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    func_802AC158_6BD808(rdram, ctx);
        goto after_42;
    // 0x802A8DBC: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    after_42:
    // 0x802A8DC0: lw          $t5, 0xC8($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XC8);
    // 0x802A8DC4: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x802A8DC8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A8DCC: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A8DD0: sw          $t5, 0x1C($t7)
    MEM_W(0X1C, ctx->r15) = ctx->r13;
    // 0x802A8DD4: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x802A8DD8: lw          $t2, 0xC4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC4);
    // 0x802A8DDC: sw          $t2, 0x20($t9)
    MEM_W(0X20, ctx->r25) = ctx->r10;
    // 0x802A8DE0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8DE4: lw          $t3, 0x4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X4);
    // 0x802A8DE8: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8DEC: addu        $t4, $t3, $t6
    ctx->r12 = ADD32(ctx->r11, ctx->r14);
    // 0x802A8DF0: sw          $t4, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r12;
    // 0x802A8DF4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8DF8: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x802A8DFC: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x802A8E00: addu        $t7, $t8, $t5
    ctx->r15 = ADD32(ctx->r24, ctx->r13);
    // 0x802A8E04: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x802A8E08: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8E0C: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802A8E10: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802A8E14: addu        $t3, $t2, $t9
    ctx->r11 = ADD32(ctx->r10, ctx->r25);
    // 0x802A8E18: sw          $t3, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r11;
    // 0x802A8E1C: b           L_802A90B0
    // 0x802A8E20: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A8E20: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8E24:
    // 0x802A8E24: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802A8E28: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802A8E2C: lw          $t6, 0x24($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X24);
    // 0x802A8E30: subu        $t8, $t6, $t4
    ctx->r24 = SUB32(ctx->r14, ctx->r12);
    // 0x802A8E34: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x802A8E38: jal         0x8030AAE0
    // 0x802A8E3C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_8030AAE0_71C190(rdram, ctx);
        goto after_43;
    // 0x802A8E3C: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_43:
    // 0x802A8E40: beq         $v0, $zero, L_802A8E74
    if (ctx->r2 == 0) {
        // 0x802A8E44: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A8E74;
    }
    // 0x802A8E44: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A8E48: beq         $v0, $at, L_802A8E60
    if (ctx->r2 == ctx->r1) {
        // 0x802A8E4C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A8E60;
    }
    // 0x802A8E4C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A8E50: beql        $v0, $at, L_802A8E78
    if (ctx->r2 == ctx->r1) {
        // 0x802A8E54: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A8E78;
    }
    goto skip_34;
    // 0x802A8E54: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_34:
    // 0x802A8E58: b           L_802A8E78
    // 0x802A8E5C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A8E78;
    // 0x802A8E5C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8E60:
    // 0x802A8E60: jal         0x802A6400
    // 0x802A8E64: nop

    func_802A6400_6B7AB0(rdram, ctx);
        goto after_44;
    // 0x802A8E64: nop

    after_44:
    // 0x802A8E68: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x802A8E6C: addiu       $t5, $zero, 0x7
    ctx->r13 = ADD32(0, 0X7);
    // 0x802A8E70: sb          $t5, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r13;
L_802A8E74:
    // 0x802A8E74: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8E78:
    // 0x802A8E78: lw          $t2, 0x74($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X74);
    // 0x802A8E7C: lw          $t3, 0xB4($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8E80: lw          $v0, 0x6C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X6C);
    // 0x802A8E84: beql        $t2, $v0, L_802A8E98
    if (ctx->r10 == ctx->r2) {
        // 0x802A8E88: lw          $t9, 0xC($s0)
        ctx->r25 = MEM_W(ctx->r16, 0XC);
            goto L_802A8E98;
    }
    goto skip_35;
    // 0x802A8E88: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    skip_35:
    // 0x802A8E8C: bne         $v0, $zero, L_802A8EA0
    if (ctx->r2 != 0) {
        // 0x802A8E90: nop
    
            goto L_802A8EA0;
    }
    // 0x802A8E90: nop

    // 0x802A8E94: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
L_802A8E98:
    // 0x802A8E98: subu        $t6, $t9, $t3
    ctx->r14 = SUB32(ctx->r25, ctx->r11);
    // 0x802A8E9C: sw          $t6, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r14;
L_802A8EA0:
    // 0x802A8EA0: jal         0x802B2964
    // 0x802A8EA4: nop

    func_802B2964_6C4014(rdram, ctx);
        goto after_45;
    // 0x802A8EA4: nop

    after_45:
    // 0x802A8EA8: jal         0x802A3CD0
    // 0x802A8EAC: nop

    func_802A3CD0_6B5380(rdram, ctx);
        goto after_46;
    // 0x802A8EAC: nop

    after_46:
    // 0x802A8EB0: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    // 0x802A8EB4: jal         0x802A403C
    // 0x802A8EB8: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_47;
    // 0x802A8EB8: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    after_47:
    // 0x802A8EBC: addiu       $a0, $sp, 0xC8
    ctx->r4 = ADD32(ctx->r29, 0XC8);
    // 0x802A8EC0: jal         0x802AC5CC
    // 0x802A8EC4: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_48;
    // 0x802A8EC4: addiu       $a1, $sp, 0xC4
    ctx->r5 = ADD32(ctx->r29, 0XC4);
    after_48:
    // 0x802A8EC8: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A8ECC: lw          $t4, 0x5520($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5520);
    // 0x802A8ED0: addiu       $a1, $sp, 0xC8
    ctx->r5 = ADD32(ctx->r29, 0XC8);
    // 0x802A8ED4: addiu       $a2, $sp, 0xC4
    ctx->r6 = ADD32(ctx->r29, 0XC4);
    // 0x802A8ED8: lw          $t8, 0x0($t4)
    ctx->r24 = MEM_W(ctx->r12, 0X0);
    // 0x802A8EDC: jal         0x802ABB10
    // 0x802A8EE0: lhu         $a0, 0xB2($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XB2);
    func_802ABB10_6BD1C0(rdram, ctx);
        goto after_49;
    // 0x802A8EE0: lhu         $a0, 0xB2($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XB2);
    after_49:
    // 0x802A8EE4: lw          $t5, 0xC8($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XC8);
    // 0x802A8EE8: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x802A8EEC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A8EF0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A8EF4: sw          $t5, 0x1C($t7)
    MEM_W(0X1C, ctx->r15) = ctx->r13;
    // 0x802A8EF8: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x802A8EFC: lw          $t2, 0xC4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC4);
    // 0x802A8F00: sw          $t2, 0x20($t9)
    MEM_W(0X20, ctx->r25) = ctx->r10;
    // 0x802A8F04: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8F08: lw          $t3, 0x4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X4);
    // 0x802A8F0C: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802A8F10: addu        $t4, $t3, $t6
    ctx->r12 = ADD32(ctx->r11, ctx->r14);
    // 0x802A8F14: sw          $t4, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r12;
    // 0x802A8F18: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8F1C: lui         $t6, 0x803A
    ctx->r14 = S32(0X803A << 16);
    // 0x802A8F20: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x802A8F24: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x802A8F28: addu        $t7, $t8, $t5
    ctx->r15 = ADD32(ctx->r24, ctx->r13);
    // 0x802A8F2C: sw          $t7, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r15;
    // 0x802A8F30: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8F34: lw          $t6, 0x5B0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5B0);
    // 0x802A8F38: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802A8F3C: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802A8F40: addu        $t3, $t2, $t9
    ctx->r11 = ADD32(ctx->r10, ctx->r25);
    // 0x802A8F44: subu        $t4, $t3, $t6
    ctx->r12 = SUB32(ctx->r11, ctx->r14);
    // 0x802A8F48: sw          $t4, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r12;
    // 0x802A8F4C: b           L_802A90B0
    // 0x802A8F50: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A90B0;
    // 0x802A8F50: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A8F54:
    // 0x802A8F54: jal         0x8030AAE0
    // 0x802A8F58: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_50;
    // 0x802A8F58: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_50:
    // 0x802A8F5C: beq         $v0, $zero, L_802A8F7C
    if (ctx->r2 == 0) {
        // 0x802A8F60: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A8F7C;
    }
    // 0x802A8F60: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A8F64: beq         $v0, $at, L_802A900C
    if (ctx->r2 == ctx->r1) {
        // 0x802A8F68: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A900C;
    }
    // 0x802A8F68: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A8F6C: beql        $v0, $at, L_802A9028
    if (ctx->r2 == ctx->r1) {
        // 0x802A8F70: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_802A9028;
    }
    goto skip_36;
    // 0x802A8F70: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_36:
    // 0x802A8F74: b           L_802A9038
    // 0x802A8F78: nop

        goto L_802A9038;
    // 0x802A8F78: nop

L_802A8F7C:
    // 0x802A8F7C: jal         0x802A64B0
    // 0x802A8F80: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_51;
    // 0x802A8F80: nop

    after_51:
    // 0x802A8F84: beq         $v0, $zero, L_802A9038
    if (ctx->r2 == 0) {
        // 0x802A8F88: nop
    
            goto L_802A9038;
    }
    // 0x802A8F88: nop

    // 0x802A8F8C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A8F90: lw          $t5, 0xB4($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XB4);
    // 0x802A8F94: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A8F98: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x802A8F9C: addiu       $v0, $v0, 0x5544
    ctx->r2 = ADD32(ctx->r2, 0X5544);
    // 0x802A8FA0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802A8FA4: subu        $t7, $t8, $t5
    ctx->r15 = SUB32(ctx->r24, ctx->r13);
    // 0x802A8FA8: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
    // 0x802A8FAC: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x802A8FB0: lhu         $t2, 0x0($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X0);
    // 0x802A8FB4: lhu         $t3, 0x48($t9)
    ctx->r11 = MEM_HU(ctx->r25, 0X48);
    // 0x802A8FB8: subu        $t6, $t2, $t3
    ctx->r14 = SUB32(ctx->r10, ctx->r11);
    // 0x802A8FBC: slti        $at, $t6, 0x5
    ctx->r1 = SIGNED(ctx->r14) < 0X5 ? 1 : 0;
    // 0x802A8FC0: bne         $at, $zero, L_802A9038
    if (ctx->r1 != 0) {
        // 0x802A8FC4: nop
    
            goto L_802A9038;
    }
    // 0x802A8FC4: nop

    // 0x802A8FC8: lw          $a3, 0x552C($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X552C);
    // 0x802A8FCC: addiu       $v1, $zero, 0x3
    ctx->r3 = ADD32(0, 0X3);
    // 0x802A8FD0: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x802A8FD4: lbu         $t4, 0x364($a3)
    ctx->r12 = MEM_BU(ctx->r7, 0X364);
    // 0x802A8FD8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A8FDC: bnel        $v1, $t4, L_802A8FFC
    if (ctx->r3 != ctx->r12) {
        // 0x802A8FE0: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_802A8FFC;
    }
    goto skip_37;
    // 0x802A8FE0: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    skip_37:
    // 0x802A8FE4: sb          $t8, 0x364($a3)
    MEM_B(0X364, ctx->r7) = ctx->r24;
    // 0x802A8FE8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A8FEC: lhu         $t5, 0x0($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X0);
    // 0x802A8FF0: b           L_802A9038
    // 0x802A8FF4: sh          $t5, 0x334($t7)
    MEM_H(0X334, ctx->r15) = ctx->r13;
        goto L_802A9038;
    // 0x802A8FF4: sh          $t5, 0x334($t7)
    MEM_H(0X334, ctx->r15) = ctx->r13;
    // 0x802A8FF8: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
L_802A8FFC:
    // 0x802A8FFC: jal         0x802DBA58
    // 0x802A9000: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_52;
    // 0x802A9000: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    after_52:
    // 0x802A9004: b           L_802A9038
    // 0x802A9008: nop

        goto L_802A9038;
    // 0x802A9008: nop

L_802A900C:
    // 0x802A900C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9010: lw          $t2, 0xB4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB4);
    // 0x802A9014: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x802A9018: subu        $t3, $t9, $t2
    ctx->r11 = SUB32(ctx->r25, ctx->r10);
    // 0x802A901C: b           L_802A9038
    // 0x802A9020: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
        goto L_802A9038;
    // 0x802A9020: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
    // 0x802A9024: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A9028:
    // 0x802A9028: lw          $t4, 0xB4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XB4);
    // 0x802A902C: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x802A9030: subu        $t8, $t6, $t4
    ctx->r24 = SUB32(ctx->r14, ctx->r12);
    // 0x802A9034: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
L_802A9038:
    // 0x802A9038: jal         0x802B2964
    // 0x802A903C: nop

    func_802B2964_6C4014(rdram, ctx);
        goto after_53;
    // 0x802A903C: nop

    after_53:
    // 0x802A9040: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9044: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x802A9048: lw          $t7, 0x5B0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5B0);
    // 0x802A904C: lw          $t5, 0x24($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X24);
    // 0x802A9050: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802A9054: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x802A9058: subu        $t2, $t5, $t9
    ctx->r10 = SUB32(ctx->r13, ctx->r25);
    // 0x802A905C: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
    // 0x802A9060: jal         0x802A403C
    // 0x802A9064: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_54;
    // 0x802A9064: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_54:
    // 0x802A9068: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A906C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A9070: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802A9074: lw          $t3, 0x4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X4);
    // 0x802A9078: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802A907C: addu        $t4, $t3, $t6
    ctx->r12 = ADD32(ctx->r11, ctx->r14);
    // 0x802A9080: sw          $t4, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r12;
    // 0x802A9084: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9088: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x802A908C: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802A9090: addu        $t5, $t8, $t7
    ctx->r13 = ADD32(ctx->r24, ctx->r15);
    // 0x802A9094: sw          $t5, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r13;
    // 0x802A9098: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A909C: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x802A90A0: lw          $t2, 0x24($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X24);
    // 0x802A90A4: addu        $t3, $t9, $t2
    ctx->r11 = ADD32(ctx->r25, ctx->r10);
    // 0x802A90A8: sw          $t3, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r11;
    // 0x802A90AC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A90B0:
    // 0x802A90B0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A90B4: lb          $v0, 0x554C($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X554C);
    // 0x802A90B8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A90BC: blez        $v0, L_802A90C8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802A90C0: addiu       $t6, $v0, -0x1
        ctx->r14 = ADD32(ctx->r2, -0X1);
            goto L_802A90C8;
    }
    // 0x802A90C0: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x802A90C4: sb          $t6, 0x554C($at)
    MEM_B(0X554C, ctx->r1) = ctx->r14;
L_802A90C8:
    // 0x802A90C8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802A90CC: sb          $zero, 0x554B($at)
    MEM_B(0X554B, ctx->r1) = 0;
    // 0x802A90D0: lhu         $t4, 0x0($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X0);
    // 0x802A90D4: addiu       $t8, $t4, -0x2
    ctx->r24 = ADD32(ctx->r12, -0X2);
    // 0x802A90D8: sltiu       $at, $t8, 0xDC
    ctx->r1 = ctx->r24 < 0XDC ? 1 : 0;
    // 0x802A90DC: beq         $at, $zero, L_802A9148
    if (ctx->r1 == 0) {
        // 0x802A90E0: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802A9148;
    }
    // 0x802A90E0: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802A90E4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A90E8: addu        $at, $at, $t8
    gpr jr_addend_802A90F0 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802A90EC: lw          $t8, -0x5188($at)
    ctx->r24 = ADD32(ctx->r1, -0X5188);
    // 0x802A90F0: jr          $t8
    // 0x802A90F4: nop

    switch (jr_addend_802A90F0 >> 2) {
        case 0: goto L_802A90F8; break;
        case 1: goto L_802A90F8; break;
        case 2: goto L_802A90F8; break;
        case 3: goto L_802A90F8; break;
        case 4: goto L_802A90F8; break;
        case 5: goto L_802A9148; break;
        case 6: goto L_802A9148; break;
        case 7: goto L_802A9148; break;
        case 8: goto L_802A9148; break;
        case 9: goto L_802A9148; break;
        case 10: goto L_802A9148; break;
        case 11: goto L_802A9148; break;
        case 12: goto L_802A9148; break;
        case 13: goto L_802A9148; break;
        case 14: goto L_802A9148; break;
        case 15: goto L_802A9148; break;
        case 16: goto L_802A9148; break;
        case 17: goto L_802A9148; break;
        case 18: goto L_802A9148; break;
        case 19: goto L_802A90F8; break;
        case 20: goto L_802A90F8; break;
        case 21: goto L_802A90F8; break;
        case 22: goto L_802A90F8; break;
        case 23: goto L_802A9148; break;
        case 24: goto L_802A9148; break;
        case 25: goto L_802A9148; break;
        case 26: goto L_802A9148; break;
        case 27: goto L_802A9148; break;
        case 28: goto L_802A9148; break;
        case 29: goto L_802A9148; break;
        case 30: goto L_802A9148; break;
        case 31: goto L_802A9148; break;
        case 32: goto L_802A9148; break;
        case 33: goto L_802A9148; break;
        case 34: goto L_802A9148; break;
        case 35: goto L_802A9148; break;
        case 36: goto L_802A9148; break;
        case 37: goto L_802A9148; break;
        case 38: goto L_802A9148; break;
        case 39: goto L_802A90F8; break;
        case 40: goto L_802A90F8; break;
        case 41: goto L_802A9148; break;
        case 42: goto L_802A9148; break;
        case 43: goto L_802A9148; break;
        case 44: goto L_802A9148; break;
        case 45: goto L_802A9148; break;
        case 46: goto L_802A9148; break;
        case 47: goto L_802A9148; break;
        case 48: goto L_802A9148; break;
        case 49: goto L_802A9148; break;
        case 50: goto L_802A9148; break;
        case 51: goto L_802A9148; break;
        case 52: goto L_802A9148; break;
        case 53: goto L_802A9148; break;
        case 54: goto L_802A9148; break;
        case 55: goto L_802A9148; break;
        case 56: goto L_802A9148; break;
        case 57: goto L_802A9148; break;
        case 58: goto L_802A9148; break;
        case 59: goto L_802A90F8; break;
        case 60: goto L_802A90F8; break;
        case 61: goto L_802A9148; break;
        case 62: goto L_802A9148; break;
        case 63: goto L_802A9148; break;
        case 64: goto L_802A9148; break;
        case 65: goto L_802A9148; break;
        case 66: goto L_802A9148; break;
        case 67: goto L_802A9148; break;
        case 68: goto L_802A9148; break;
        case 69: goto L_802A9148; break;
        case 70: goto L_802A9148; break;
        case 71: goto L_802A9148; break;
        case 72: goto L_802A9148; break;
        case 73: goto L_802A9148; break;
        case 74: goto L_802A9148; break;
        case 75: goto L_802A9148; break;
        case 76: goto L_802A9148; break;
        case 77: goto L_802A9148; break;
        case 78: goto L_802A9148; break;
        case 79: goto L_802A9128; break;
        case 80: goto L_802A9148; break;
        case 81: goto L_802A9148; break;
        case 82: goto L_802A9148; break;
        case 83: goto L_802A9148; break;
        case 84: goto L_802A9148; break;
        case 85: goto L_802A9148; break;
        case 86: goto L_802A9148; break;
        case 87: goto L_802A9148; break;
        case 88: goto L_802A9148; break;
        case 89: goto L_802A9148; break;
        case 90: goto L_802A9148; break;
        case 91: goto L_802A9148; break;
        case 92: goto L_802A9148; break;
        case 93: goto L_802A9148; break;
        case 94: goto L_802A9148; break;
        case 95: goto L_802A9148; break;
        case 96: goto L_802A9148; break;
        case 97: goto L_802A9148; break;
        case 98: goto L_802A9148; break;
        case 99: goto L_802A90F8; break;
        case 100: goto L_802A9148; break;
        case 101: goto L_802A90F8; break;
        case 102: goto L_802A90F8; break;
        case 103: goto L_802A90F8; break;
        case 104: goto L_802A90F8; break;
        case 105: goto L_802A9148; break;
        case 106: goto L_802A9148; break;
        case 107: goto L_802A9148; break;
        case 108: goto L_802A9148; break;
        case 109: goto L_802A9148; break;
        case 110: goto L_802A9148; break;
        case 111: goto L_802A9148; break;
        case 112: goto L_802A9148; break;
        case 113: goto L_802A9148; break;
        case 114: goto L_802A9148; break;
        case 115: goto L_802A9148; break;
        case 116: goto L_802A9148; break;
        case 117: goto L_802A9148; break;
        case 118: goto L_802A9148; break;
        case 119: goto L_802A90F8; break;
        case 120: goto L_802A90F8; break;
        case 121: goto L_802A90F8; break;
        case 122: goto L_802A9148; break;
        case 123: goto L_802A9148; break;
        case 124: goto L_802A9148; break;
        case 125: goto L_802A9148; break;
        case 126: goto L_802A9148; break;
        case 127: goto L_802A9148; break;
        case 128: goto L_802A9148; break;
        case 129: goto L_802A9148; break;
        case 130: goto L_802A9148; break;
        case 131: goto L_802A9148; break;
        case 132: goto L_802A9148; break;
        case 133: goto L_802A9148; break;
        case 134: goto L_802A9148; break;
        case 135: goto L_802A9148; break;
        case 136: goto L_802A9148; break;
        case 137: goto L_802A9148; break;
        case 138: goto L_802A9148; break;
        case 139: goto L_802A90F8; break;
        case 140: goto L_802A90F8; break;
        case 141: goto L_802A90F8; break;
        case 142: goto L_802A90F8; break;
        case 143: goto L_802A9148; break;
        case 144: goto L_802A9148; break;
        case 145: goto L_802A9148; break;
        case 146: goto L_802A9148; break;
        case 147: goto L_802A9148; break;
        case 148: goto L_802A9148; break;
        case 149: goto L_802A9148; break;
        case 150: goto L_802A9148; break;
        case 151: goto L_802A9148; break;
        case 152: goto L_802A9148; break;
        case 153: goto L_802A9148; break;
        case 154: goto L_802A9148; break;
        case 155: goto L_802A9148; break;
        case 156: goto L_802A9148; break;
        case 157: goto L_802A9148; break;
        case 158: goto L_802A9148; break;
        case 159: goto L_802A90F8; break;
        case 160: goto L_802A90F8; break;
        case 161: goto L_802A9148; break;
        case 162: goto L_802A9148; break;
        case 163: goto L_802A9148; break;
        case 164: goto L_802A9148; break;
        case 165: goto L_802A9148; break;
        case 166: goto L_802A9148; break;
        case 167: goto L_802A9148; break;
        case 168: goto L_802A9148; break;
        case 169: goto L_802A9148; break;
        case 170: goto L_802A9148; break;
        case 171: goto L_802A9148; break;
        case 172: goto L_802A9148; break;
        case 173: goto L_802A9148; break;
        case 174: goto L_802A9148; break;
        case 175: goto L_802A9148; break;
        case 176: goto L_802A9148; break;
        case 177: goto L_802A9148; break;
        case 178: goto L_802A9148; break;
        case 179: goto L_802A90F8; break;
        case 180: goto L_802A90F8; break;
        case 181: goto L_802A90F8; break;
        case 182: goto L_802A90F8; break;
        case 183: goto L_802A90F8; break;
        case 184: goto L_802A9148; break;
        case 185: goto L_802A9148; break;
        case 186: goto L_802A9148; break;
        case 187: goto L_802A9148; break;
        case 188: goto L_802A9148; break;
        case 189: goto L_802A9148; break;
        case 190: goto L_802A9148; break;
        case 191: goto L_802A9148; break;
        case 192: goto L_802A9148; break;
        case 193: goto L_802A9148; break;
        case 194: goto L_802A9148; break;
        case 195: goto L_802A9148; break;
        case 196: goto L_802A9148; break;
        case 197: goto L_802A9148; break;
        case 198: goto L_802A9148; break;
        case 199: goto L_802A90F8; break;
        case 200: goto L_802A90F8; break;
        case 201: goto L_802A90F8; break;
        case 202: goto L_802A90F8; break;
        case 203: goto L_802A9148; break;
        case 204: goto L_802A9148; break;
        case 205: goto L_802A9148; break;
        case 206: goto L_802A9148; break;
        case 207: goto L_802A9148; break;
        case 208: goto L_802A9148; break;
        case 209: goto L_802A9148; break;
        case 210: goto L_802A9148; break;
        case 211: goto L_802A9148; break;
        case 212: goto L_802A9148; break;
        case 213: goto L_802A9148; break;
        case 214: goto L_802A9148; break;
        case 215: goto L_802A9148; break;
        case 216: goto L_802A9148; break;
        case 217: goto L_802A9148; break;
        case 218: goto L_802A9148; break;
        case 219: goto L_802A90F8; break;
        default: switch_error(__func__, 0x802A90F0, 0x803BAE78);
    }
    // 0x802A90F4: nop

L_802A90F8:
    // 0x802A90F8: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A90FC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802A9100: lh          $t7, 0x302($a3)
    ctx->r15 = MEM_H(ctx->r7, 0X302);
    // 0x802A9104: sh          $t7, 0x304($a3)
    MEM_H(0X304, ctx->r7) = ctx->r15;
    // 0x802A9108: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A910C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802A9110: addiu       $a0, $a3, 0x302
    ctx->r4 = ADD32(ctx->r7, 0X302);
    // 0x802A9114: lh          $a1, 0x2C($a3)
    ctx->r5 = MEM_H(ctx->r7, 0X2C);
    // 0x802A9118: jal         0x802DB940
    // 0x802A911C: lhu         $a2, 0xB0($t5)
    ctx->r6 = MEM_HU(ctx->r13, 0XB0);
    func_802DB940_6ECFF0(rdram, ctx);
        goto after_55;
    // 0x802A911C: lhu         $a2, 0xB0($t5)
    ctx->r6 = MEM_HU(ctx->r13, 0XB0);
    after_55:
    // 0x802A9120: b           L_802A9148
    // 0x802A9124: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_802A9148;
    // 0x802A9124: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A9128:
    // 0x802A9128: lw          $a3, 0x0($t1)
    ctx->r7 = MEM_W(ctx->r9, 0X0);
    // 0x802A912C: lh          $t9, 0x302($a3)
    ctx->r25 = MEM_H(ctx->r7, 0X302);
    // 0x802A9130: sh          $t9, 0x304($a3)
    MEM_H(0X304, ctx->r7) = ctx->r25;
    // 0x802A9134: lw          $t2, 0x0($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X0);
    // 0x802A9138: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802A913C: lh          $t3, 0x2C($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X2C);
    // 0x802A9140: sh          $t3, 0x302($t6)
    MEM_H(0X302, ctx->r14) = ctx->r11;
    // 0x802A9144: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_802A9148:
    // 0x802A9148: sb          $zero, 0x65($s0)
    MEM_B(0X65, ctx->r16) = 0;
    // 0x802A914C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9150: lbu         $t4, 0x4B($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X4B);
    // 0x802A9154: slti        $at, $t4, 0x21
    ctx->r1 = SIGNED(ctx->r12) < 0X21 ? 1 : 0;
    // 0x802A9158: bne         $at, $zero, L_802A920C
    if (ctx->r1 != 0) {
        // 0x802A915C: nop
    
            goto L_802A920C;
    }
    // 0x802A915C: nop

    // 0x802A9160: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
    // 0x802A9164: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802A9168: sll         $t5, $t8, 26
    ctx->r13 = S32(ctx->r24 << 26);
    // 0x802A916C: bltz        $t5, L_802A920C
    if (SIGNED(ctx->r13) < 0) {
        // 0x802A9170: nop
    
            goto L_802A920C;
    }
    // 0x802A9170: nop

    // 0x802A9174: lh          $v0, 0x14C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14C);
    // 0x802A9178: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x802A917C: bgezl       $v0, L_802A9190
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A9180: sh          $v0, 0x14C($s0)
        MEM_H(0X14C, ctx->r16) = ctx->r2;
            goto L_802A9190;
    }
    goto skip_38;
    // 0x802A9180: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
    skip_38:
    // 0x802A9184: b           L_802A9190
    // 0x802A9188: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802A9190;
    // 0x802A9188: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    // 0x802A918C: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
L_802A9190:
    // 0x802A9190: jal         0x80349280
    // 0x802A9194: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_56;
    // 0x802A9194: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_56:
    // 0x802A9198: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A919C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802A91A0: lbu         $v0, 0x4B($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X4B);
    // 0x802A91A4: slti        $at, $v0, 0x31
    ctx->r1 = SIGNED(ctx->r2) < 0X31 ? 1 : 0;
    // 0x802A91A8: bnel        $at, $zero, L_802A91E0
    if (ctx->r1 != 0) {
        // 0x802A91AC: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_802A91E0;
    }
    goto skip_39;
    // 0x802A91AC: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_39:
    // 0x802A91B0: lh          $v0, 0x14C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14C);
    // 0x802A91B4: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x802A91B8: bgezl       $v0, L_802A91CC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A91BC: sh          $v0, 0x14C($s0)
        MEM_H(0X14C, ctx->r16) = ctx->r2;
            goto L_802A91CC;
    }
    goto skip_40;
    // 0x802A91BC: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
    skip_40:
    // 0x802A91C0: b           L_802A91CC
    // 0x802A91C4: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802A91CC;
    // 0x802A91C4: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    // 0x802A91C8: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
L_802A91CC:
    // 0x802A91CC: jal         0x80349280
    // 0x802A91D0: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_57;
    // 0x802A91D0: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_57:
    // 0x802A91D4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A91D8: lbu         $v0, 0x4B($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X4B);
    // 0x802A91DC: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_802A91E0:
    // 0x802A91E0: bne         $at, $zero, L_802A920C
    if (ctx->r1 != 0) {
        // 0x802A91E4: addiu       $a1, $zero, 0x4
        ctx->r5 = ADD32(0, 0X4);
            goto L_802A920C;
    }
    // 0x802A91E4: addiu       $a1, $zero, 0x4
    ctx->r5 = ADD32(0, 0X4);
    // 0x802A91E8: lh          $v0, 0x14C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14C);
    // 0x802A91EC: addiu       $v0, $v0, -0x4
    ctx->r2 = ADD32(ctx->r2, -0X4);
    // 0x802A91F0: bgezl       $v0, L_802A9204
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A91F4: sh          $v0, 0x14C($s0)
        MEM_H(0X14C, ctx->r16) = ctx->r2;
            goto L_802A9204;
    }
    goto skip_41;
    // 0x802A91F4: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
    skip_41:
    // 0x802A91F8: b           L_802A9204
    // 0x802A91FC: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802A9204;
    // 0x802A91FC: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    // 0x802A9200: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
L_802A9204:
    // 0x802A9204: jal         0x80349280
    // 0x802A9208: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_58;
    // 0x802A9208: lw          $a0, 0x0($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X0);
    after_58:
L_802A920C:
    // 0x802A920C: jal         0x802B3230
    // 0x802A9210: nop

    func_802B3230_6C48E0(rdram, ctx);
        goto after_59;
    // 0x802A9210: nop

    after_59:
    // 0x802A9214: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9218: addiu       $t2, $zero, 0x80
    ctx->r10 = ADD32(0, 0X80);
    // 0x802A921C: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x802A9220: lh          $t9, 0x4($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X4);
    // 0x802A9224: addiu       $t5, $zero, 0x117F
    ctx->r13 = ADD32(0, 0X117F);
    // 0x802A9228: slti        $at, $t9, 0x80
    ctx->r1 = SIGNED(ctx->r25) < 0X80 ? 1 : 0;
    // 0x802A922C: beql        $at, $zero, L_802A9248
    if (ctx->r1 == 0) {
        // 0x802A9230: lh          $t6, 0x8($s0)
        ctx->r14 = MEM_H(ctx->r16, 0X8);
            goto L_802A9248;
    }
    goto skip_42;
    // 0x802A9230: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    skip_42:
    // 0x802A9234: sh          $t2, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r10;
    // 0x802A9238: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x802A923C: sw          $zero, 0x1C($t3)
    MEM_W(0X1C, ctx->r11) = 0;
    // 0x802A9240: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9244: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
L_802A9248:
    // 0x802A9248: addiu       $t3, $zero, 0x1F7F
    ctx->r11 = ADD32(0, 0X1F7F);
    // 0x802A924C: slti        $at, $t6, 0x80
    ctx->r1 = SIGNED(ctx->r14) < 0X80 ? 1 : 0;
    // 0x802A9250: beql        $at, $zero, L_802A926C
    if (ctx->r1 == 0) {
        // 0x802A9254: lh          $t7, 0x4($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X4);
            goto L_802A926C;
    }
    goto skip_43;
    // 0x802A9254: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    skip_43:
    // 0x802A9258: sh          $t4, 0x8($s0)
    MEM_H(0X8, ctx->r16) = ctx->r12;
    // 0x802A925C: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x802A9260: sw          $zero, 0x20($t8)
    MEM_W(0X20, ctx->r24) = 0;
    // 0x802A9264: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A9268: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
L_802A926C:
    // 0x802A926C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802A9270: slti        $at, $t7, 0x1180
    ctx->r1 = SIGNED(ctx->r15) < 0X1180 ? 1 : 0;
    // 0x802A9274: bnel        $at, $zero, L_802A9290
    if (ctx->r1 != 0) {
        // 0x802A9278: lh          $t2, 0x8($s0)
        ctx->r10 = MEM_H(ctx->r16, 0X8);
            goto L_802A9290;
    }
    goto skip_44;
    // 0x802A9278: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    skip_44:
    // 0x802A927C: sh          $t5, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r13;
    // 0x802A9280: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x802A9284: sw          $zero, 0x1C($t9)
    MEM_W(0X1C, ctx->r25) = 0;
    // 0x802A9288: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A928C: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
L_802A9290:
    // 0x802A9290: slti        $at, $t2, 0x1F80
    ctx->r1 = SIGNED(ctx->r10) < 0X1F80 ? 1 : 0;
    // 0x802A9294: bnel        $at, $zero, L_802A92B0
    if (ctx->r1 != 0) {
        // 0x802A9298: lhu         $v0, 0x0($s0)
        ctx->r2 = MEM_HU(ctx->r16, 0X0);
            goto L_802A92B0;
    }
    goto skip_45;
    // 0x802A9298: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    skip_45:
    // 0x802A929C: sh          $t3, 0x8($s0)
    MEM_H(0X8, ctx->r16) = ctx->r11;
    // 0x802A92A0: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x802A92A4: sw          $zero, 0x20($t6)
    MEM_W(0X20, ctx->r14) = 0;
    // 0x802A92A8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x802A92AC: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
L_802A92B0:
    // 0x802A92B0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A92B4: beq         $v0, $at, L_802A92D4
    if (ctx->r2 == ctx->r1) {
        // 0x802A92B8: addiu       $at, $zero, 0x15
        ctx->r1 = ADD32(0, 0X15);
            goto L_802A92D4;
    }
    // 0x802A92B8: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x802A92BC: beq         $v0, $at, L_802A92D4
    if (ctx->r2 == ctx->r1) {
        // 0x802A92C0: addiu       $at, $zero, 0x29
        ctx->r1 = ADD32(0, 0X29);
            goto L_802A92D4;
    }
    // 0x802A92C0: addiu       $at, $zero, 0x29
    ctx->r1 = ADD32(0, 0X29);
    // 0x802A92C4: beq         $v0, $at, L_802A92D4
    if (ctx->r2 == ctx->r1) {
        // 0x802A92C8: addiu       $at, $zero, 0x79
        ctx->r1 = ADD32(0, 0X79);
            goto L_802A92D4;
    }
    // 0x802A92C8: addiu       $at, $zero, 0x79
    ctx->r1 = ADD32(0, 0X79);
    // 0x802A92CC: bnel        $v0, $at, L_802A934C
    if (ctx->r2 != ctx->r1) {
        // 0x802A92D0: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802A934C;
    }
    goto skip_46;
    // 0x802A92D0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_46:
L_802A92D4:
    // 0x802A92D4: lh          $t4, 0x6450($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X6450);
    // 0x802A92D8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802A92DC: beql        $t4, $zero, L_802A934C
    if (ctx->r12 == 0) {
        // 0x802A92E0: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802A934C;
    }
    goto skip_47;
    // 0x802A92E0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_47:
    // 0x802A92E4: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802A92E8: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802A92EC: lhu         $v0, 0x9C($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X9C);
    // 0x802A92F0: beq         $v0, $at, L_802A932C
    if (ctx->r2 == ctx->r1) {
        // 0x802A92F4: addiu       $at, $zero, 0x39
        ctx->r1 = ADD32(0, 0X39);
            goto L_802A932C;
    }
    // 0x802A92F4: addiu       $at, $zero, 0x39
    ctx->r1 = ADD32(0, 0X39);
    // 0x802A92F8: beq         $v0, $at, L_802A932C
    if (ctx->r2 == ctx->r1) {
        // 0x802A92FC: addiu       $at, $zero, 0x3A
        ctx->r1 = ADD32(0, 0X3A);
            goto L_802A932C;
    }
    // 0x802A92FC: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x802A9300: beq         $v0, $at, L_802A932C
    if (ctx->r2 == ctx->r1) {
        // 0x802A9304: nop
    
            goto L_802A932C;
    }
    // 0x802A9304: nop

    // 0x802A9308: jal         0x8012826C
    // 0x802A930C: nop

    advance_random_seed(rdram, ctx);
        goto after_60;
    // 0x802A930C: nop

    after_60:
    // 0x802A9310: andi        $t7, $v0, 0x1F
    ctx->r15 = ctx->r2 & 0X1F;
    // 0x802A9314: bnel        $t7, $zero, L_802A934C
    if (ctx->r15 != 0) {
        // 0x802A9318: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802A934C;
    }
    goto skip_48;
    // 0x802A9318: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_48:
    // 0x802A931C: jal         0x802AA5C0
    // 0x802A9320: nop

    func_802AA5C0_6BBC70(rdram, ctx);
        goto after_61;
    // 0x802A9320: nop

    after_61:
    // 0x802A9324: b           L_802A934C
    // 0x802A9328: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
        goto L_802A934C;
    // 0x802A9328: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802A932C:
    // 0x802A932C: jal         0x8012826C
    // 0x802A9330: nop

    advance_random_seed(rdram, ctx);
        goto after_62;
    // 0x802A9330: nop

    after_62:
    // 0x802A9334: andi        $t5, $v0, 0xF
    ctx->r13 = ctx->r2 & 0XF;
    // 0x802A9338: bnel        $t5, $zero, L_802A934C
    if (ctx->r13 != 0) {
        // 0x802A933C: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802A934C;
    }
    goto skip_49;
    // 0x802A933C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_49:
    // 0x802A9340: jal         0x802AA85C
    // 0x802A9344: nop

    func_802AA85C_6BBF0C(rdram, ctx);
        goto after_63;
    // 0x802A9344: nop

    after_63:
L_802A9348:
    // 0x802A9348: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802A934C:
    // 0x802A934C: lw          $s0, 0x24($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X24);
    // 0x802A9350: lw          $s1, 0x28($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X28);
    // 0x802A9354: jr          $ra
    // 0x802A9358: addiu       $sp, $sp, 0xD0
    ctx->r29 = ADD32(ctx->r29, 0XD0);
    return;
    // 0x802A9358: addiu       $sp, $sp, 0xD0
    ctx->r29 = ADD32(ctx->r29, 0XD0);
;}
RECOMP_FUNC void func_802A935C_6BAA0C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802A935C: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x802A9360: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802A9364: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802A9368: addiu       $s0, $s0, 0x5530
    ctx->r16 = ADD32(ctx->r16, 0X5530);
    // 0x802A936C: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x802A9370: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802A9374: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9378: lb          $t7, 0x4A($t6)
    ctx->r15 = MEM_B(ctx->r14, 0X4A);
    // 0x802A937C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9380: bnel        $t7, $zero, L_802AA090
    if (ctx->r15 != 0) {
        // 0x802A9384: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_802AA090;
    }
    goto skip_0;
    // 0x802A9384: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x802A9388: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A938C: lhu         $t8, 0x2F2($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802A9390: sh          $t8, 0x2F4($v0)
    MEM_H(0X2F4, ctx->r2) = ctx->r24;
    // 0x802A9394: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A9398: lhu         $t9, 0x2F2($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802A939C: addiu       $t1, $t9, 0x1
    ctx->r9 = ADD32(ctx->r25, 0X1);
    // 0x802A93A0: sh          $t1, 0x2F2($v0)
    MEM_H(0X2F2, ctx->r2) = ctx->r9;
    // 0x802A93A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A93A8: lhu         $v1, 0x2F2($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802A93AC: slti        $at, $v1, 0x4000
    ctx->r1 = SIGNED(ctx->r3) < 0X4000 ? 1 : 0;
    // 0x802A93B0: bne         $at, $zero, L_802A93C0
    if (ctx->r1 != 0) {
        // 0x802A93B4: addiu       $t2, $v1, -0x2000
        ctx->r10 = ADD32(ctx->r3, -0X2000);
            goto L_802A93C0;
    }
    // 0x802A93B4: addiu       $t2, $v1, -0x2000
    ctx->r10 = ADD32(ctx->r3, -0X2000);
    // 0x802A93B8: sh          $t2, 0x2F2($v0)
    MEM_H(0X2F2, ctx->r2) = ctx->r10;
    // 0x802A93BC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_802A93C0:
    // 0x802A93C0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A93C4: lw          $t3, 0x6C($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X6C);
    // 0x802A93C8: sw          $t3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r11;
    // 0x802A93CC: lbu         $v1, 0x367($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X367);
    // 0x802A93D0: blez        $v1, L_802A93E4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802A93D4: addiu       $t4, $v1, -0x1
        ctx->r12 = ADD32(ctx->r3, -0X1);
            goto L_802A93E4;
    }
    // 0x802A93D4: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x802A93D8: sb          $t4, 0x367($v0)
    MEM_B(0X367, ctx->r2) = ctx->r12;
    // 0x802A93DC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A93E0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A93E4:
    // 0x802A93E4: lw          $t5, 0xC($v0)
    ctx->r13 = MEM_W(ctx->r2, 0XC);
    // 0x802A93E8: sw          $t5, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r13;
    // 0x802A93EC: lbu         $t6, 0x162($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X162);
    // 0x802A93F0: andi        $t7, $t6, 0xF
    ctx->r15 = ctx->r14 & 0XF;
    // 0x802A93F4: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x802A93F8: sltiu       $at, $t8, 0x7
    ctx->r1 = ctx->r24 < 0X7 ? 1 : 0;
    // 0x802A93FC: beq         $at, $zero, L_802A9F80
    if (ctx->r1 == 0) {
        // 0x802A9400: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802A9F80;
    }
    // 0x802A9400: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802A9404: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A9408: addu        $at, $at, $t8
    gpr jr_addend_802A9410 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802A940C: lw          $t8, -0x4E18($at)
    ctx->r24 = ADD32(ctx->r1, -0X4E18);
    // 0x802A9410: jr          $t8
    // 0x802A9414: nop

    switch (jr_addend_802A9410 >> 2) {
        case 0: goto L_802A9418; break;
        case 1: goto L_802A972C; break;
        case 2: goto L_802A9888; break;
        case 3: goto L_802A9A14; break;
        case 4: goto L_802A9B2C; break;
        case 5: goto L_802A9D5C; break;
        case 6: goto L_802A9E8C; break;
        default: switch_error(__func__, 0x802A9410, 0x803BB1E8);
    }
    // 0x802A9414: nop

L_802A9418:
    // 0x802A9418: lui         $t1, 0x803A
    ctx->r9 = S32(0X803A << 16);
    // 0x802A941C: lw          $t1, 0x5B4($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5B4);
    // 0x802A9420: lw          $t9, 0x24($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X24);
    // 0x802A9424: subu        $t2, $t9, $t1
    ctx->r10 = SUB32(ctx->r25, ctx->r9);
    // 0x802A9428: sw          $t2, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r10;
    // 0x802A942C: jal         0x8030AAE0
    // 0x802A9430: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    func_8030AAE0_71C190(rdram, ctx);
        goto after_0;
    // 0x802A9430: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    after_0:
    // 0x802A9434: beq         $v0, $zero, L_802A9494
    if (ctx->r2 == 0) {
        // 0x802A9438: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A9494;
    }
    // 0x802A9438: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A943C: beq         $v0, $at, L_802A9454
    if (ctx->r2 == ctx->r1) {
        // 0x802A9440: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A9454;
    }
    // 0x802A9440: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A9444: beql        $v0, $at, L_802A9498
    if (ctx->r2 == ctx->r1) {
        // 0x802A9448: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9498;
    }
    goto skip_1;
    // 0x802A9448: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_1:
    // 0x802A944C: b           L_802A9498
    // 0x802A9450: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9498;
    // 0x802A9450: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9454:
    // 0x802A9454: jal         0x802A6400
    // 0x802A9458: nop

    func_802A6400_6B7AB0(rdram, ctx);
        goto after_1;
    // 0x802A9458: nop

    after_1:
    // 0x802A945C: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x802A9460: addiu       $t3, $zero, 0x3
    ctx->r11 = ADD32(0, 0X3);
    // 0x802A9464: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A9468: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    // 0x802A946C: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    // 0x802A9470: lui         $t6, 0x803A
    ctx->r14 = S32(0X803A << 16);
    // 0x802A9474: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x802A9478: lw          $t8, 0x5B0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5B0);
    // 0x802A947C: lw          $t6, 0x5B4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5B4);
    // 0x802A9480: lw          $t5, 0x24($a1)
    ctx->r13 = MEM_W(ctx->r5, 0X24);
    // 0x802A9484: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802A9488: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802A948C: subu        $t1, $t7, $t9
    ctx->r9 = SUB32(ctx->r15, ctx->r25);
    // 0x802A9490: sw          $t1, 0x24($a1)
    MEM_W(0X24, ctx->r5) = ctx->r9;
L_802A9494:
    // 0x802A9494: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9498:
    // 0x802A9498: lw          $t2, 0x3C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X3C);
    // 0x802A949C: lw          $t4, 0x58($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X58);
    // 0x802A94A0: lw          $v0, 0x6C($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X6C);
    // 0x802A94A4: beql        $t2, $v0, L_802A94B8
    if (ctx->r10 == ctx->r2) {
        // 0x802A94A8: lw          $t3, 0xC($a3)
        ctx->r11 = MEM_W(ctx->r7, 0XC);
            goto L_802A94B8;
    }
    goto skip_2;
    // 0x802A94A8: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
    skip_2:
    // 0x802A94AC: bne         $v0, $zero, L_802A94C0
    if (ctx->r2 != 0) {
        // 0x802A94B0: nop
    
            goto L_802A94C0;
    }
    // 0x802A94B0: nop

    // 0x802A94B4: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
L_802A94B8:
    // 0x802A94B8: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x802A94BC: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
L_802A94C0:
    // 0x802A94C0: jal         0x802B2834
    // 0x802A94C4: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_2;
    // 0x802A94C4: nop

    after_2:
    // 0x802A94C8: jal         0x802A3CD0
    // 0x802A94CC: nop

    func_802A3CD0_6B5380(rdram, ctx);
        goto after_3;
    // 0x802A94CC: nop

    after_3:
    // 0x802A94D0: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    // 0x802A94D4: jal         0x802AC5CC
    // 0x802A94D8: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_4;
    // 0x802A94D8: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_4:
    // 0x802A94DC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A94E0: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802A94E4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A94E8: lw          $t6, 0x5520($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5520);
    // 0x802A94EC: lhu         $t7, 0x9C($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0X9C);
    // 0x802A94F0: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802A94F4: lw          $t8, 0x0($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X0);
    // 0x802A94F8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A94FC: bne         $t7, $at, L_802A9590
    if (ctx->r15 != ctx->r1) {
        // 0x802A9500: lhu         $a0, 0xB2($t8)
        ctx->r4 = MEM_HU(ctx->r24, 0XB2);
            goto L_802A9590;
    }
    // 0x802A9500: lhu         $a0, 0xB2($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XB2);
    // 0x802A9504: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802A9508: lb          $t2, 0x554C($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X554C);
    // 0x802A950C: sll         $t9, $a0, 1
    ctx->r25 = S32(ctx->r4 << 1);
    // 0x802A9510: andi        $a0, $t9, 0xFFFF
    ctx->r4 = ctx->r25 & 0XFFFF;
    // 0x802A9514: beq         $t2, $zero, L_802A9698
    if (ctx->r10 == 0) {
        // 0x802A9518: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_802A9698;
    }
    // 0x802A9518: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A951C: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802A9520: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A9524: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A9528: lh          $t5, 0x302($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X302);
    // 0x802A952C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9530: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802A9534: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802A9538: addu        $t7, $v0, $t8
    ctx->r15 = ADD32(ctx->r2, ctx->r24);
    // 0x802A953C: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802A9540: lw          $t3, 0x1C($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9544: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A9548: sra         $t1, $t9, 7
    ctx->r9 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802A954C: sll         $t2, $t1, 8
    ctx->r10 = S32(ctx->r9 << 8);
    // 0x802A9550: addu        $t4, $t3, $t2
    ctx->r12 = ADD32(ctx->r11, ctx->r10);
    // 0x802A9554: sw          $t4, 0x1C($a3)
    MEM_W(0X1C, ctx->r7) = ctx->r12;
    // 0x802A9558: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802A955C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9560: lh          $t8, 0x302($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X302);
    // 0x802A9564: lw          $t5, 0x20($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X20);
    // 0x802A9568: addiu       $t7, $t8, 0x40
    ctx->r15 = ADD32(ctx->r24, 0X40);
    // 0x802A956C: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802A9570: sll         $t1, $t9, 1
    ctx->r9 = S32(ctx->r25 << 1);
    // 0x802A9574: addu        $t3, $v0, $t1
    ctx->r11 = ADD32(ctx->r2, ctx->r9);
    // 0x802A9578: lh          $t2, 0x0($t3)
    ctx->r10 = MEM_H(ctx->r11, 0X0);
    // 0x802A957C: sra         $t4, $t2, 7
    ctx->r12 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802A9580: sll         $t6, $t4, 8
    ctx->r14 = S32(ctx->r12 << 8);
    // 0x802A9584: addu        $t8, $t5, $t6
    ctx->r24 = ADD32(ctx->r13, ctx->r14);
    // 0x802A9588: b           L_802A9698
    // 0x802A958C: sw          $t8, 0x20($a3)
    MEM_W(0X20, ctx->r7) = ctx->r24;
        goto L_802A9698;
    // 0x802A958C: sw          $t8, 0x20($a3)
    MEM_W(0X20, ctx->r7) = ctx->r24;
L_802A9590:
    // 0x802A9590: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    // 0x802A9594: lw          $t7, 0x7C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X7C);
    // 0x802A9598: lb          $v1, 0x36E($a1)
    ctx->r3 = MEM_B(ctx->r5, 0X36E);
    // 0x802A959C: beql        $v1, $zero, L_802A969C
    if (ctx->r3 == 0) {
        // 0x802A95A0: addiu       $a1, $sp, 0x7C
        ctx->r5 = ADD32(ctx->r29, 0X7C);
            goto L_802A969C;
    }
    goto skip_3;
    // 0x802A95A0: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    skip_3:
    // 0x802A95A4: multu       $t7, $v1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A95A8: lw          $t2, 0x78($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X78);
    // 0x802A95AC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A95B0: mflo        $t9
    ctx->r25 = lo;
    // 0x802A95B4: sra         $t1, $t9, 4
    ctx->r9 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802A95B8: addu        $t3, $t7, $t1
    ctx->r11 = ADD32(ctx->r15, ctx->r9);
    // 0x802A95BC: sw          $t3, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r11;
    // 0x802A95C0: lb          $t4, 0x36E($a1)
    ctx->r12 = MEM_B(ctx->r5, 0X36E);
    // 0x802A95C4: multu       $t2, $t4
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802A95C8: mflo        $t5
    ctx->r13 = lo;
    // 0x802A95CC: sra         $t6, $t5, 4
    ctx->r14 = S32(SIGNED(ctx->r13) >> 4);
    // 0x802A95D0: addu        $t8, $t2, $t6
    ctx->r24 = ADD32(ctx->r10, ctx->r14);
    // 0x802A95D4: sw          $t8, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r24;
    // 0x802A95D8: lw          $v0, 0x1C($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X1C);
    // 0x802A95DC: bgez        $v0, L_802A95EC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A95E0: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_802A95EC;
    }
    // 0x802A95E0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x802A95E4: b           L_802A95EC
    // 0x802A95E8: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_802A95EC;
    // 0x802A95E8: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_802A95EC:
    // 0x802A95EC: lw          $v0, 0x20($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X20);
    // 0x802A95F0: bgez        $v0, L_802A9600
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802A95F4: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802A9600;
    }
    // 0x802A95F4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802A95F8: b           L_802A9600
    // 0x802A95FC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802A9600;
    // 0x802A95FC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802A9600:
    // 0x802A9600: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802A9604: beq         $at, $zero, L_802A9614
    if (ctx->r1 == 0) {
        // 0x802A9608: or          $a3, $v1, $zero
        ctx->r7 = ctx->r3 | 0;
            goto L_802A9614;
    }
    // 0x802A9608: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802A960C: b           L_802A9614
    // 0x802A9610: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
        goto L_802A9614;
    // 0x802A9610: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
L_802A9614:
    // 0x802A9614: slt         $at, $a2, $v1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802A9618: beq         $at, $zero, L_802A9628
    if (ctx->r1 == 0) {
        // 0x802A961C: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_802A9628;
    }
    // 0x802A961C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802A9620: b           L_802A9628
    // 0x802A9624: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
        goto L_802A9628;
    // 0x802A9624: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
L_802A9628:
    // 0x802A9628: lhu         $v1, 0xA4($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0XA4);
    // 0x802A962C: sra         $t9, $a1, 1
    ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802A9630: addu        $v0, $t9, $a3
    ctx->r2 = ADD32(ctx->r25, ctx->r7);
    // 0x802A9634: sll         $t7, $v1, 11
    ctx->r15 = S32(ctx->r3 << 11);
    // 0x802A9638: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A963C: beq         $at, $zero, L_802A965C
    if (ctx->r1 == 0) {
        // 0x802A9640: sll         $t4, $v1, 10
        ctx->r12 = S32(ctx->r3 << 10);
            goto L_802A965C;
    }
    // 0x802A9640: sll         $t4, $v1, 10
    ctx->r12 = S32(ctx->r3 << 10);
    // 0x802A9644: bgez        $a0, L_802A9654
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A9648: sra         $t1, $a0, 2
        ctx->r9 = S32(SIGNED(ctx->r4) >> 2);
            goto L_802A9654;
    }
    // 0x802A9648: sra         $t1, $a0, 2
    ctx->r9 = S32(SIGNED(ctx->r4) >> 2);
    // 0x802A964C: addiu       $at, $a0, 0x3
    ctx->r1 = ADD32(ctx->r4, 0X3);
    // 0x802A9650: sra         $t1, $at, 2
    ctx->r9 = S32(SIGNED(ctx->r1) >> 2);
L_802A9654:
    // 0x802A9654: b           L_802A9698
    // 0x802A9658: andi        $a0, $t1, 0xFFFF
    ctx->r4 = ctx->r9 & 0XFFFF;
        goto L_802A9698;
    // 0x802A9658: andi        $a0, $t1, 0xFFFF
    ctx->r4 = ctx->r9 & 0XFFFF;
L_802A965C:
    // 0x802A965C: slt         $at, $t4, $v0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802A9660: beq         $at, $zero, L_802A9680
    if (ctx->r1 == 0) {
        // 0x802A9664: sll         $t6, $v1, 8
        ctx->r14 = S32(ctx->r3 << 8);
            goto L_802A9680;
    }
    // 0x802A9664: sll         $t6, $v1, 8
    ctx->r14 = S32(ctx->r3 << 8);
    // 0x802A9668: bgez        $a0, L_802A9678
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802A966C: sra         $t5, $a0, 1
        ctx->r13 = S32(SIGNED(ctx->r4) >> 1);
            goto L_802A9678;
    }
    // 0x802A966C: sra         $t5, $a0, 1
    ctx->r13 = S32(SIGNED(ctx->r4) >> 1);
    // 0x802A9670: addiu       $at, $a0, 0x1
    ctx->r1 = ADD32(ctx->r4, 0X1);
    // 0x802A9674: sra         $t5, $at, 1
    ctx->r13 = S32(SIGNED(ctx->r1) >> 1);
L_802A9678:
    // 0x802A9678: b           L_802A9698
    // 0x802A967C: andi        $a0, $t5, 0xFFFF
    ctx->r4 = ctx->r13 & 0XFFFF;
        goto L_802A9698;
    // 0x802A967C: andi        $a0, $t5, 0xFFFF
    ctx->r4 = ctx->r13 & 0XFFFF;
L_802A9680:
    // 0x802A9680: slt         $at, $v0, $t6
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802A9684: beq         $at, $zero, L_802A9698
    if (ctx->r1 == 0) {
        // 0x802A9688: sra         $t8, $a0, 1
        ctx->r24 = S32(SIGNED(ctx->r4) >> 1);
            goto L_802A9698;
    }
    // 0x802A9688: sra         $t8, $a0, 1
    ctx->r24 = S32(SIGNED(ctx->r4) >> 1);
    // 0x802A968C: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    // 0x802A9690: andi        $t9, $a0, 0xFFFF
    ctx->r25 = ctx->r4 & 0XFFFF;
    // 0x802A9694: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_802A9698:
    // 0x802A9698: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
L_802A969C:
    // 0x802A969C: jal         0x802ABB10
    // 0x802A96A0: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    func_802ABB10_6BD1C0(rdram, ctx);
        goto after_5;
    // 0x802A96A0: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    after_5:
    // 0x802A96A4: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x802A96A8: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x802A96AC: jal         0x802A3E70
    // 0x802A96B0: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    func_802A3E70_6B5520(rdram, ctx);
        goto after_6;
    // 0x802A96B0: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    after_6:
    // 0x802A96B4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A96B8: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802A96BC: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802A96C0: lw          $t7, 0x7C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X7C);
    // 0x802A96C4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A96C8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A96CC: sw          $t7, 0x1C($t1)
    MEM_W(0X1C, ctx->r9) = ctx->r15;
    // 0x802A96D0: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802A96D4: lw          $t3, 0x78($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X78);
    // 0x802A96D8: sw          $t3, 0x20($t4)
    MEM_W(0X20, ctx->r12) = ctx->r11;
    // 0x802A96DC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A96E0: lw          $t5, 0x4($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X4);
    // 0x802A96E4: lw          $t2, 0x1C($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X1C);
    // 0x802A96E8: addu        $t6, $t5, $t2
    ctx->r14 = ADD32(ctx->r13, ctx->r10);
    // 0x802A96EC: sw          $t6, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r14;
    // 0x802A96F0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A96F4: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x802A96F8: lw          $t8, 0x8($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X8);
    // 0x802A96FC: lw          $t9, 0x20($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X20);
    // 0x802A9700: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x802A9704: sw          $t7, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r15;
    // 0x802A9708: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A970C: lw          $t5, 0x5B4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B4);
    // 0x802A9710: lw          $t1, 0xC($a3)
    ctx->r9 = MEM_W(ctx->r7, 0XC);
    // 0x802A9714: lw          $t3, 0x24($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X24);
    // 0x802A9718: addu        $t4, $t1, $t3
    ctx->r12 = ADD32(ctx->r9, ctx->r11);
    // 0x802A971C: subu        $t2, $t4, $t5
    ctx->r10 = SUB32(ctx->r12, ctx->r13);
    // 0x802A9720: sw          $t2, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r10;
    // 0x802A9724: b           L_802A9F80
    // 0x802A9728: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9728: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A972C:
    // 0x802A972C: jal         0x8030AAE0
    // 0x802A9730: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_7;
    // 0x802A9730: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_7:
    // 0x802A9734: beq         $v0, $zero, L_802A9754
    if (ctx->r2 == 0) {
        // 0x802A9738: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A9754;
    }
    // 0x802A9738: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A973C: beq         $v0, $at, L_802A97B0
    if (ctx->r2 == ctx->r1) {
        // 0x802A9740: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A97B0;
    }
    // 0x802A9740: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A9744: beql        $v0, $at, L_802A97CC
    if (ctx->r2 == ctx->r1) {
        // 0x802A9748: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A97CC;
    }
    goto skip_4;
    // 0x802A9748: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_4:
    // 0x802A974C: b           L_802A97DC
    // 0x802A9750: nop

        goto L_802A97DC;
    // 0x802A9750: nop

L_802A9754:
    // 0x802A9754: jal         0x802A64B0
    // 0x802A9758: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_8;
    // 0x802A9758: nop

    after_8:
    // 0x802A975C: beq         $v0, $zero, L_802A9778
    if (ctx->r2 == 0) {
        // 0x802A9760: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_802A9778;
    }
    // 0x802A9760: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802A9764: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9768: lw          $t8, 0x58($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X58);
    // 0x802A976C: lw          $t6, 0xC($a3)
    ctx->r14 = MEM_W(ctx->r7, 0XC);
    // 0x802A9770: subu        $t9, $t6, $t8
    ctx->r25 = SUB32(ctx->r14, ctx->r24);
    // 0x802A9774: sw          $t9, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r25;
L_802A9778:
    // 0x802A9778: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x802A977C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A9780: addiu       $v0, $v0, 0x5544
    ctx->r2 = ADD32(ctx->r2, 0X5544);
    // 0x802A9784: lhu         $t7, 0x0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X0);
    // 0x802A9788: lhu         $t3, 0x48($t1)
    ctx->r11 = MEM_HU(ctx->r9, 0X48);
    // 0x802A978C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A9790: subu        $t4, $t7, $t3
    ctx->r12 = SUB32(ctx->r15, ctx->r11);
    // 0x802A9794: slti        $at, $t4, 0x4
    ctx->r1 = SIGNED(ctx->r12) < 0X4 ? 1 : 0;
    // 0x802A9798: bne         $at, $zero, L_802A97DC
    if (ctx->r1 != 0) {
        // 0x802A979C: nop
    
            goto L_802A97DC;
    }
    // 0x802A979C: nop

    // 0x802A97A0: jal         0x802DBA58
    // 0x802A97A4: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    func_802DBA58_6ED108(rdram, ctx);
        goto after_9;
    // 0x802A97A4: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    after_9:
    // 0x802A97A8: b           L_802A97DC
    // 0x802A97AC: nop

        goto L_802A97DC;
    // 0x802A97AC: nop

L_802A97B0:
    // 0x802A97B0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A97B4: lw          $t2, 0x58($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X58);
    // 0x802A97B8: lw          $t5, 0xC($a3)
    ctx->r13 = MEM_W(ctx->r7, 0XC);
    // 0x802A97BC: subu        $t6, $t5, $t2
    ctx->r14 = SUB32(ctx->r13, ctx->r10);
    // 0x802A97C0: b           L_802A97DC
    // 0x802A97C4: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
        goto L_802A97DC;
    // 0x802A97C4: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
    // 0x802A97C8: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A97CC:
    // 0x802A97CC: lw          $t9, 0x58($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X58);
    // 0x802A97D0: lw          $t8, 0xC($a3)
    ctx->r24 = MEM_W(ctx->r7, 0XC);
    // 0x802A97D4: subu        $t1, $t8, $t9
    ctx->r9 = SUB32(ctx->r24, ctx->r25);
    // 0x802A97D8: sw          $t1, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r9;
L_802A97DC:
    // 0x802A97DC: jal         0x802B2834
    // 0x802A97E0: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_10;
    // 0x802A97E0: nop

    after_10:
    // 0x802A97E4: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    // 0x802A97E8: jal         0x802AC5CC
    // 0x802A97EC: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_11;
    // 0x802A97EC: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_11:
    // 0x802A97F0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A97F4: lw          $t7, 0x5520($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5520);
    // 0x802A97F8: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x802A97FC: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    // 0x802A9800: lw          $t3, 0x0($t7)
    ctx->r11 = MEM_W(ctx->r15, 0X0);
    // 0x802A9804: lhu         $a0, 0xB6($t3)
    ctx->r4 = MEM_HU(ctx->r11, 0XB6);
    // 0x802A9808: sll         $t4, $a0, 2
    ctx->r12 = S32(ctx->r4 << 2);
    // 0x802A980C: subu        $t4, $t4, $a0
    ctx->r12 = SUB32(ctx->r12, ctx->r4);
    // 0x802A9810: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x802A9814: addu        $t4, $t4, $a0
    ctx->r12 = ADD32(ctx->r12, ctx->r4);
    // 0x802A9818: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x802A981C: jal         0x802AC484
    // 0x802A9820: andi        $a0, $t4, 0xFFFF
    ctx->r4 = ctx->r12 & 0XFFFF;
    func_802AC484_6BDB34(rdram, ctx);
        goto after_12;
    // 0x802A9820: andi        $a0, $t4, 0xFFFF
    ctx->r4 = ctx->r12 & 0XFFFF;
    after_12:
    // 0x802A9824: lw          $t2, 0x7C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X7C);
    // 0x802A9828: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x802A982C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9830: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9834: sw          $t2, 0x1C($t6)
    MEM_W(0X1C, ctx->r14) = ctx->r10;
    // 0x802A9838: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x802A983C: lw          $t8, 0x78($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X78);
    // 0x802A9840: sw          $t8, 0x20($t9)
    MEM_W(0X20, ctx->r25) = ctx->r24;
    // 0x802A9844: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9848: lw          $t1, 0x4($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X4);
    // 0x802A984C: lw          $t7, 0x1C($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9850: addu        $t3, $t1, $t7
    ctx->r11 = ADD32(ctx->r9, ctx->r15);
    // 0x802A9854: sw          $t3, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r11;
    // 0x802A9858: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A985C: lw          $t4, 0x8($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X8);
    // 0x802A9860: lw          $t5, 0x20($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X20);
    // 0x802A9864: addu        $t2, $t4, $t5
    ctx->r10 = ADD32(ctx->r12, ctx->r13);
    // 0x802A9868: sw          $t2, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r10;
    // 0x802A986C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9870: lw          $t6, 0xC($a3)
    ctx->r14 = MEM_W(ctx->r7, 0XC);
    // 0x802A9874: lw          $t8, 0x24($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X24);
    // 0x802A9878: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A987C: sw          $t9, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r25;
    // 0x802A9880: b           L_802A9F80
    // 0x802A9884: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9884: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9888:
    // 0x802A9888: jal         0x8030AAE0
    // 0x802A988C: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_13;
    // 0x802A988C: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_13:
    // 0x802A9890: beq         $v0, $zero, L_802A98B0
    if (ctx->r2 == 0) {
        // 0x802A9894: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A98B0;
    }
    // 0x802A9894: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A9898: beq         $v0, $at, L_802A9938
    if (ctx->r2 == ctx->r1) {
        // 0x802A989C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A9938;
    }
    // 0x802A989C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A98A0: beql        $v0, $at, L_802A9954
    if (ctx->r2 == ctx->r1) {
        // 0x802A98A4: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9954;
    }
    goto skip_5;
    // 0x802A98A4: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_5:
    // 0x802A98A8: b           L_802A9968
    // 0x802A98AC: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
        goto L_802A9968;
    // 0x802A98AC: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
L_802A98B0:
    // 0x802A98B0: jal         0x802A64B0
    // 0x802A98B4: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_14;
    // 0x802A98B4: nop

    after_14:
    // 0x802A98B8: beq         $v0, $zero, L_802A98D4
    if (ctx->r2 == 0) {
        // 0x802A98BC: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802A98D4;
    }
    // 0x802A98BC: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802A98C0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A98C4: lw          $t7, 0x58($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X58);
    // 0x802A98C8: lw          $t1, 0xC($a3)
    ctx->r9 = MEM_W(ctx->r7, 0XC);
    // 0x802A98CC: subu        $t3, $t1, $t7
    ctx->r11 = SUB32(ctx->r9, ctx->r15);
    // 0x802A98D0: sw          $t3, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r11;
L_802A98D4:
    // 0x802A98D4: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x802A98D8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802A98DC: addiu       $v0, $v0, 0x5544
    ctx->r2 = ADD32(ctx->r2, 0X5544);
    // 0x802A98E0: lhu         $t4, 0x0($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X0);
    // 0x802A98E4: lhu         $t2, 0x48($t5)
    ctx->r10 = MEM_HU(ctx->r13, 0X48);
    // 0x802A98E8: subu        $t6, $t4, $t2
    ctx->r14 = SUB32(ctx->r12, ctx->r10);
    // 0x802A98EC: slti        $at, $t6, 0x4
    ctx->r1 = SIGNED(ctx->r14) < 0X4 ? 1 : 0;
    // 0x802A98F0: bnel        $at, $zero, L_802A9968
    if (ctx->r1 != 0) {
        // 0x802A98F4: addiu       $a0, $sp, 0x7C
        ctx->r4 = ADD32(ctx->r29, 0X7C);
            goto L_802A9968;
    }
    goto skip_6;
    // 0x802A98F4: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    skip_6:
    // 0x802A98F8: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    // 0x802A98FC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802A9900: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x802A9904: lbu         $t8, 0x364($a1)
    ctx->r24 = MEM_BU(ctx->r5, 0X364);
    // 0x802A9908: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802A990C: bne         $t8, $at, L_802A9928
    if (ctx->r24 != ctx->r1) {
        // 0x802A9910: nop
    
            goto L_802A9928;
    }
    // 0x802A9910: nop

    // 0x802A9914: sb          $t9, 0x364($a1)
    MEM_B(0X364, ctx->r5) = ctx->r25;
    // 0x802A9918: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802A991C: lhu         $t1, 0x0($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X0);
    // 0x802A9920: b           L_802A9964
    // 0x802A9924: sh          $t1, 0x334($t7)
    MEM_H(0X334, ctx->r15) = ctx->r9;
        goto L_802A9964;
    // 0x802A9924: sh          $t1, 0x334($t7)
    MEM_H(0X334, ctx->r15) = ctx->r9;
L_802A9928:
    // 0x802A9928: jal         0x802DBA58
    // 0x802A992C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    func_802DBA58_6ED108(rdram, ctx);
        goto after_15;
    // 0x802A992C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    after_15:
    // 0x802A9930: b           L_802A9968
    // 0x802A9934: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
        goto L_802A9968;
    // 0x802A9934: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
L_802A9938:
    // 0x802A9938: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A993C: lw          $t5, 0x58($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X58);
    // 0x802A9940: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
    // 0x802A9944: subu        $t4, $t3, $t5
    ctx->r12 = SUB32(ctx->r11, ctx->r13);
    // 0x802A9948: b           L_802A9964
    // 0x802A994C: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
        goto L_802A9964;
    // 0x802A994C: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
    // 0x802A9950: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9954:
    // 0x802A9954: lw          $t6, 0x58($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X58);
    // 0x802A9958: lw          $t2, 0xC($a3)
    ctx->r10 = MEM_W(ctx->r7, 0XC);
    // 0x802A995C: subu        $t8, $t2, $t6
    ctx->r24 = SUB32(ctx->r10, ctx->r14);
    // 0x802A9960: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
L_802A9964:
    // 0x802A9964: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
L_802A9968:
    // 0x802A9968: jal         0x802AC5CC
    // 0x802A996C: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_16;
    // 0x802A996C: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_16:
    // 0x802A9970: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802A9974: lw          $t9, 0x5520($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5520);
    // 0x802A9978: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x802A997C: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    // 0x802A9980: lw          $t1, 0x0($t9)
    ctx->r9 = MEM_W(ctx->r25, 0X0);
    // 0x802A9984: lhu         $a0, 0xB2($t1)
    ctx->r4 = MEM_HU(ctx->r9, 0XB2);
    // 0x802A9988: sll         $t7, $a0, 4
    ctx->r15 = S32(ctx->r4 << 4);
    // 0x802A998C: jal         0x802AC484
    // 0x802A9990: andi        $a0, $t7, 0xFFFF
    ctx->r4 = ctx->r15 & 0XFFFF;
    func_802AC484_6BDB34(rdram, ctx);
        goto after_17;
    // 0x802A9990: andi        $a0, $t7, 0xFFFF
    ctx->r4 = ctx->r15 & 0XFFFF;
    after_17:
    // 0x802A9994: lw          $t5, 0x7C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X7C);
    // 0x802A9998: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x802A999C: sw          $t5, 0x1C($t4)
    MEM_W(0X1C, ctx->r12) = ctx->r13;
    // 0x802A99A0: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x802A99A4: lw          $t2, 0x78($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X78);
    // 0x802A99A8: jal         0x802B2834
    // 0x802A99AC: sw          $t2, 0x20($t6)
    MEM_W(0X20, ctx->r14) = ctx->r10;
    func_802B2834_6C3EE4(rdram, ctx);
        goto after_18;
    // 0x802A99AC: sw          $t2, 0x20($t6)
    MEM_W(0X20, ctx->r14) = ctx->r10;
    after_18:
    // 0x802A99B0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A99B4: lui         $t9, 0x803A
    ctx->r25 = S32(0X803A << 16);
    // 0x802A99B8: lw          $t9, 0x5B0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5B0);
    // 0x802A99BC: lw          $t8, 0x24($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X24);
    // 0x802A99C0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A99C4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A99C8: subu        $t1, $t8, $t9
    ctx->r9 = SUB32(ctx->r24, ctx->r25);
    // 0x802A99CC: sw          $t1, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r9;
    // 0x802A99D0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A99D4: lw          $t7, 0x4($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X4);
    // 0x802A99D8: lw          $t3, 0x1C($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X1C);
    // 0x802A99DC: addu        $t5, $t7, $t3
    ctx->r13 = ADD32(ctx->r15, ctx->r11);
    // 0x802A99E0: sw          $t5, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r13;
    // 0x802A99E4: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A99E8: lw          $t4, 0x8($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X8);
    // 0x802A99EC: lw          $t2, 0x20($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X20);
    // 0x802A99F0: addu        $t6, $t4, $t2
    ctx->r14 = ADD32(ctx->r12, ctx->r10);
    // 0x802A99F4: sw          $t6, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r14;
    // 0x802A99F8: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A99FC: lw          $t8, 0xC($a3)
    ctx->r24 = MEM_W(ctx->r7, 0XC);
    // 0x802A9A00: lw          $t9, 0x24($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X24);
    // 0x802A9A04: addu        $t1, $t8, $t9
    ctx->r9 = ADD32(ctx->r24, ctx->r25);
    // 0x802A9A08: sw          $t1, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r9;
    // 0x802A9A0C: b           L_802A9F80
    // 0x802A9A10: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9A10: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9A14:
    // 0x802A9A14: lw          $t7, 0x4($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X4);
    // 0x802A9A18: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x802A9A1C: sw          $t7, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r15;
    // 0x802A9A20: lw          $t3, 0x8($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X8);
    // 0x802A9A24: sw          $t3, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r11;
    // 0x802A9A28: lw          $t5, 0xC($a3)
    ctx->r13 = MEM_W(ctx->r7, 0XC);
    // 0x802A9A2C: jal         0x8030AAE0
    // 0x802A9A30: sw          $t5, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r13;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_19;
    // 0x802A9A30: sw          $t5, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r13;
    after_19:
    // 0x802A9A34: beq         $v0, $zero, L_802A9A54
    if (ctx->r2 == 0) {
        // 0x802A9A38: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A9A54;
    }
    // 0x802A9A38: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A9A3C: beq         $v0, $at, L_802A9A98
    if (ctx->r2 == ctx->r1) {
        // 0x802A9A40: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A9A98;
    }
    // 0x802A9A40: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A9A44: beql        $v0, $at, L_802A9AA4
    if (ctx->r2 == ctx->r1) {
        // 0x802A9A48: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9AA4;
    }
    goto skip_7;
    // 0x802A9A48: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_7:
    // 0x802A9A4C: b           L_802A9AA4
    // 0x802A9A50: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9AA4;
    // 0x802A9A50: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9A54:
    // 0x802A9A54: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9A58: lw          $t4, 0x6C($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X6C);
    // 0x802A9A5C: bnel        $t4, $zero, L_802A9AA8
    if (ctx->r12 != 0) {
        // 0x802A9A60: lw          $t3, 0xC($a3)
        ctx->r11 = MEM_W(ctx->r7, 0XC);
            goto L_802A9AA8;
    }
    goto skip_8;
    // 0x802A9A60: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
    skip_8:
    // 0x802A9A64: lw          $t2, 0x70($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X70);
    // 0x802A9A68: lw          $t6, 0x74($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X74);
    // 0x802A9A6C: bnel        $t2, $zero, L_802A9AA8
    if (ctx->r10 != 0) {
        // 0x802A9A70: lw          $t3, 0xC($a3)
        ctx->r11 = MEM_W(ctx->r7, 0XC);
            goto L_802A9AA8;
    }
    goto skip_9;
    // 0x802A9A70: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
    skip_9:
    // 0x802A9A74: sw          $t6, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r14;
    // 0x802A9A78: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x802A9A7C: lw          $t8, 0x70($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X70);
    // 0x802A9A80: sw          $t8, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r24;
    // 0x802A9A84: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x802A9A88: lw          $t1, 0x6C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X6C);
    // 0x802A9A8C: sw          $t1, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r9;
    // 0x802A9A90: b           L_802A9AA4
    // 0x802A9A94: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9AA4;
    // 0x802A9A94: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9A98:
    // 0x802A9A98: b           L_802A9AA4
    // 0x802A9A9C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9AA4;
    // 0x802A9A9C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9AA0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9AA4:
    // 0x802A9AA4: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
L_802A9AA8:
    // 0x802A9AA8: lw          $t5, 0x58($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X58);
    // 0x802A9AAC: subu        $t4, $t3, $t5
    ctx->r12 = SUB32(ctx->r11, ctx->r13);
    // 0x802A9AB0: jal         0x802B2964
    // 0x802A9AB4: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
    func_802B2964_6C4014(rdram, ctx);
        goto after_20;
    // 0x802A9AB4: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
    after_20:
    // 0x802A9AB8: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9ABC: addiu       $a2, $zero, 0xD2
    ctx->r6 = ADD32(0, 0XD2);
    // 0x802A9AC0: addiu       $a0, $a3, 0x1C
    ctx->r4 = ADD32(ctx->r7, 0X1C);
    // 0x802A9AC4: jal         0x802A4220
    // 0x802A9AC8: addiu       $a1, $a3, 0x20
    ctx->r5 = ADD32(ctx->r7, 0X20);
    func_802A4220_6B58D0(rdram, ctx);
        goto after_21;
    // 0x802A9AC8: addiu       $a1, $a3, 0x20
    ctx->r5 = ADD32(ctx->r7, 0X20);
    after_21:
    // 0x802A9ACC: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x802A9AD0: jal         0x802A403C
    // 0x802A9AD4: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_22;
    // 0x802A9AD4: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    after_22:
    // 0x802A9AD8: jal         0x802A4184
    // 0x802A9ADC: nop

    func_802A4184_6B5834(rdram, ctx);
        goto after_23;
    // 0x802A9ADC: nop

    after_23:
    // 0x802A9AE0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9AE4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9AE8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9AEC: lw          $t2, 0x4($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X4);
    // 0x802A9AF0: lw          $t6, 0x1C($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9AF4: addu        $t8, $t2, $t6
    ctx->r24 = ADD32(ctx->r10, ctx->r14);
    // 0x802A9AF8: sw          $t8, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r24;
    // 0x802A9AFC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9B00: lw          $t9, 0x8($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X8);
    // 0x802A9B04: lw          $t1, 0x20($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X20);
    // 0x802A9B08: addu        $t7, $t9, $t1
    ctx->r15 = ADD32(ctx->r25, ctx->r9);
    // 0x802A9B0C: sw          $t7, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r15;
    // 0x802A9B10: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9B14: lw          $t3, 0xC($a3)
    ctx->r11 = MEM_W(ctx->r7, 0XC);
    // 0x802A9B18: lw          $t5, 0x24($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X24);
    // 0x802A9B1C: addu        $t4, $t3, $t5
    ctx->r12 = ADD32(ctx->r11, ctx->r13);
    // 0x802A9B20: sw          $t4, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r12;
    // 0x802A9B24: b           L_802A9F80
    // 0x802A9B28: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9B28: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9B2C:
    // 0x802A9B2C: lw          $t2, 0x4($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X4);
    // 0x802A9B30: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x802A9B34: sw          $t2, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r10;
    // 0x802A9B38: lw          $t6, 0x8($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X8);
    // 0x802A9B3C: sw          $t6, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r14;
    // 0x802A9B40: lbu         $t8, 0x160($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X160);
    // 0x802A9B44: jal         0x8030AAE0
    // 0x802A9B48: sb          $t8, 0x51($sp)
    MEM_B(0X51, ctx->r29) = ctx->r24;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_24;
    // 0x802A9B48: sb          $t8, 0x51($sp)
    MEM_B(0X51, ctx->r29) = ctx->r24;
    after_24:
    // 0x802A9B4C: beql        $v0, $zero, L_802A9B58
    if (ctx->r2 == 0) {
        // 0x802A9B50: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9B58;
    }
    goto skip_10;
    // 0x802A9B50: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_10:
    // 0x802A9B54: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9B58:
    // 0x802A9B58: lw          $t1, 0x60($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X60);
    // 0x802A9B5C: lw          $t3, 0x5C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X5C);
    // 0x802A9B60: lw          $t9, 0x4($a3)
    ctx->r25 = MEM_W(ctx->r7, 0X4);
    // 0x802A9B64: lw          $t7, 0x8($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X8);
    // 0x802A9B68: subu        $a0, $t9, $t1
    ctx->r4 = SUB32(ctx->r25, ctx->r9);
    // 0x802A9B6C: jal         0x802B2AF0
    // 0x802A9B70: subu        $a1, $t7, $t3
    ctx->r5 = SUB32(ctx->r15, ctx->r11);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_25;
    // 0x802A9B70: subu        $a1, $t7, $t3
    ctx->r5 = SUB32(ctx->r15, ctx->r11);
    after_25:
    // 0x802A9B74: beq         $v0, $zero, L_802A9C00
    if (ctx->r2 == 0) {
        // 0x802A9B78: lbu         $t5, 0x51($sp)
        ctx->r13 = MEM_BU(ctx->r29, 0X51);
            goto L_802A9C00;
    }
    // 0x802A9B78: lbu         $t5, 0x51($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X51);
    // 0x802A9B7C: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x802A9B80: lw          $v0, 0x60($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X60);
    // 0x802A9B84: sb          $t5, 0x160($t4)
    MEM_B(0X160, ctx->r12) = ctx->r13;
    // 0x802A9B88: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9B8C: lw          $t2, 0x4($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X4);
    // 0x802A9B90: sw          $t2, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r10;
    // 0x802A9B94: sw          $v0, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r2;
    // 0x802A9B98: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9B9C: lw          $t9, 0x5C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X5C);
    // 0x802A9BA0: lw          $t6, 0x4($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X4);
    // 0x802A9BA4: lw          $t8, 0x8($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X8);
    // 0x802A9BA8: subu        $a0, $t6, $v0
    ctx->r4 = SUB32(ctx->r14, ctx->r2);
    // 0x802A9BAC: jal         0x802B2AF0
    // 0x802A9BB0: subu        $a1, $t8, $t9
    ctx->r5 = SUB32(ctx->r24, ctx->r25);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_26;
    // 0x802A9BB0: subu        $a1, $t8, $t9
    ctx->r5 = SUB32(ctx->r24, ctx->r25);
    after_26:
    // 0x802A9BB4: beq         $v0, $zero, L_802A9C00
    if (ctx->r2 == 0) {
        // 0x802A9BB8: lw          $t1, 0x54($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X54);
            goto L_802A9C00;
    }
    // 0x802A9BB8: lw          $t1, 0x54($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X54);
    // 0x802A9BBC: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x802A9BC0: sw          $t1, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r9;
    // 0x802A9BC4: lw          $t3, 0x5C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X5C);
    // 0x802A9BC8: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x802A9BCC: sw          $t3, 0x8($t5)
    MEM_W(0X8, ctx->r13) = ctx->r11;
    // 0x802A9BD0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9BD4: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    // 0x802A9BD8: lw          $t2, 0x60($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X60);
    // 0x802A9BDC: lw          $t4, 0x4($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X4);
    // 0x802A9BE0: lw          $t6, 0x8($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X8);
    // 0x802A9BE4: subu        $a0, $t4, $t2
    ctx->r4 = SUB32(ctx->r12, ctx->r10);
    // 0x802A9BE8: jal         0x802B2AF0
    // 0x802A9BEC: subu        $a1, $t6, $t8
    ctx->r5 = SUB32(ctx->r14, ctx->r24);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_27;
    // 0x802A9BEC: subu        $a1, $t6, $t8
    ctx->r5 = SUB32(ctx->r14, ctx->r24);
    after_27:
    // 0x802A9BF0: beq         $v0, $zero, L_802A9C00
    if (ctx->r2 == 0) {
        // 0x802A9BF4: lw          $t9, 0x60($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X60);
            goto L_802A9C00;
    }
    // 0x802A9BF4: lw          $t9, 0x60($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X60);
    // 0x802A9BF8: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x802A9BFC: sw          $t9, 0x4($t1)
    MEM_W(0X4, ctx->r9) = ctx->r25;
L_802A9C00:
    // 0x802A9C00: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9C04: lw          $t3, 0x58($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X58);
    // 0x802A9C08: lw          $t7, 0xC($a3)
    ctx->r15 = MEM_W(ctx->r7, 0XC);
    // 0x802A9C0C: subu        $t5, $t7, $t3
    ctx->r13 = SUB32(ctx->r15, ctx->r11);
    // 0x802A9C10: jal         0x802B2964
    // 0x802A9C14: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
    func_802B2964_6C4014(rdram, ctx);
        goto after_28;
    // 0x802A9C14: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
    after_28:
    // 0x802A9C18: jal         0x802A40EC
    // 0x802A9C1C: nop

    func_802A40EC_6B579C(rdram, ctx);
        goto after_29;
    // 0x802A9C1C: nop

    after_29:
    // 0x802A9C20: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    // 0x802A9C24: jal         0x802AC5CC
    // 0x802A9C28: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_30;
    // 0x802A9C28: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_30:
    // 0x802A9C2C: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    // 0x802A9C30: jal         0x802A3F68
    // 0x802A9C34: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802A3F68_6B5618(rdram, ctx);
        goto after_31;
    // 0x802A9C34: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_31:
    // 0x802A9C38: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A9C3C: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802A9C40: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A9C44: lw          $t4, 0x5520($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5520);
    // 0x802A9C48: lhu         $t8, 0x9C($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0X9C);
    // 0x802A9C4C: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802A9C50: lw          $t2, 0x0($t4)
    ctx->r10 = MEM_W(ctx->r12, 0X0);
    // 0x802A9C54: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x802A9C58: bne         $t8, $at, L_802A9CF0
    if (ctx->r24 != ctx->r1) {
        // 0x802A9C5C: lhu         $a0, 0xB4($t2)
        ctx->r4 = MEM_HU(ctx->r10, 0XB4);
            goto L_802A9CF0;
    }
    // 0x802A9C5C: lhu         $a0, 0xB4($t2)
    ctx->r4 = MEM_HU(ctx->r10, 0XB4);
    // 0x802A9C60: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A9C64: lb          $t3, 0x554C($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X554C);
    // 0x802A9C68: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x802A9C6C: addu        $t9, $t9, $a0
    ctx->r25 = ADD32(ctx->r25, ctx->r4);
    // 0x802A9C70: sra         $t1, $t9, 1
    ctx->r9 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802A9C74: beq         $t3, $zero, L_802A9CF0
    if (ctx->r11 == 0) {
        // 0x802A9C78: andi        $a0, $t1, 0xFFFF
        ctx->r4 = ctx->r9 & 0XFFFF;
            goto L_802A9CF0;
    }
    // 0x802A9C78: andi        $a0, $t1, 0xFFFF
    ctx->r4 = ctx->r9 & 0XFFFF;
    // 0x802A9C7C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802A9C80: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802A9C84: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802A9C88: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x802A9C8C: lh          $t2, 0x302($t4)
    ctx->r10 = MEM_H(ctx->r12, 0X302);
    // 0x802A9C90: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9C94: andi        $t6, $t2, 0xFF
    ctx->r14 = ctx->r10 & 0XFF;
    // 0x802A9C98: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802A9C9C: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802A9CA0: lh          $t1, 0x0($t9)
    ctx->r9 = MEM_H(ctx->r25, 0X0);
    // 0x802A9CA4: lw          $t5, 0x1C($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9CA8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802A9CAC: sra         $t7, $t1, 7
    ctx->r15 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802A9CB0: sll         $t3, $t7, 8
    ctx->r11 = S32(ctx->r15 << 8);
    // 0x802A9CB4: addu        $t4, $t5, $t3
    ctx->r12 = ADD32(ctx->r13, ctx->r11);
    // 0x802A9CB8: sw          $t4, 0x1C($a3)
    MEM_W(0X1C, ctx->r7) = ctx->r12;
    // 0x802A9CBC: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802A9CC0: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9CC4: lh          $t8, 0x302($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X302);
    // 0x802A9CC8: lw          $t2, 0x20($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X20);
    // 0x802A9CCC: addiu       $t9, $t8, 0x40
    ctx->r25 = ADD32(ctx->r24, 0X40);
    // 0x802A9CD0: andi        $t1, $t9, 0xFF
    ctx->r9 = ctx->r25 & 0XFF;
    // 0x802A9CD4: sll         $t7, $t1, 1
    ctx->r15 = S32(ctx->r9 << 1);
    // 0x802A9CD8: addu        $t5, $v0, $t7
    ctx->r13 = ADD32(ctx->r2, ctx->r15);
    // 0x802A9CDC: lh          $t3, 0x0($t5)
    ctx->r11 = MEM_H(ctx->r13, 0X0);
    // 0x802A9CE0: sra         $t4, $t3, 7
    ctx->r12 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802A9CE4: sll         $t6, $t4, 8
    ctx->r14 = S32(ctx->r12 << 8);
    // 0x802A9CE8: addu        $t8, $t2, $t6
    ctx->r24 = ADD32(ctx->r10, ctx->r14);
    // 0x802A9CEC: sw          $t8, 0x20($a3)
    MEM_W(0X20, ctx->r7) = ctx->r24;
L_802A9CF0:
    // 0x802A9CF0: jal         0x802AC158
    // 0x802A9CF4: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    func_802AC158_6BD808(rdram, ctx);
        goto after_32;
    // 0x802A9CF4: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    after_32:
    // 0x802A9CF8: lw          $t9, 0x7C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X7C);
    // 0x802A9CFC: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x802A9D00: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9D04: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9D08: sw          $t9, 0x1C($t1)
    MEM_W(0X1C, ctx->r9) = ctx->r25;
    // 0x802A9D0C: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x802A9D10: lw          $t7, 0x78($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X78);
    // 0x802A9D14: sw          $t7, 0x20($t5)
    MEM_W(0X20, ctx->r13) = ctx->r15;
    // 0x802A9D18: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9D1C: lw          $t3, 0x4($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X4);
    // 0x802A9D20: lw          $t4, 0x1C($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9D24: addu        $t2, $t3, $t4
    ctx->r10 = ADD32(ctx->r11, ctx->r12);
    // 0x802A9D28: sw          $t2, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r10;
    // 0x802A9D2C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9D30: lw          $t6, 0x8($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X8);
    // 0x802A9D34: lw          $t8, 0x20($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X20);
    // 0x802A9D38: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A9D3C: sw          $t9, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r25;
    // 0x802A9D40: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9D44: lw          $t1, 0xC($a3)
    ctx->r9 = MEM_W(ctx->r7, 0XC);
    // 0x802A9D48: lw          $t7, 0x24($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X24);
    // 0x802A9D4C: addu        $t5, $t1, $t7
    ctx->r13 = ADD32(ctx->r9, ctx->r15);
    // 0x802A9D50: sw          $t5, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r13;
    // 0x802A9D54: b           L_802A9F80
    // 0x802A9D58: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9D58: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9D5C:
    // 0x802A9D5C: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802A9D60: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802A9D64: lw          $t3, 0x24($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X24);
    // 0x802A9D68: subu        $t2, $t3, $t4
    ctx->r10 = SUB32(ctx->r11, ctx->r12);
    // 0x802A9D6C: sw          $t2, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r10;
    // 0x802A9D70: jal         0x8030AAE0
    // 0x802A9D74: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    func_8030AAE0_71C190(rdram, ctx);
        goto after_33;
    // 0x802A9D74: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    after_33:
    // 0x802A9D78: beq         $v0, $zero, L_802A9DAC
    if (ctx->r2 == 0) {
        // 0x802A9D7C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A9DAC;
    }
    // 0x802A9D7C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A9D80: beq         $v0, $at, L_802A9D98
    if (ctx->r2 == ctx->r1) {
        // 0x802A9D84: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A9D98;
    }
    // 0x802A9D84: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A9D88: beql        $v0, $at, L_802A9DB0
    if (ctx->r2 == ctx->r1) {
        // 0x802A9D8C: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9DB0;
    }
    goto skip_11;
    // 0x802A9D8C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_11:
    // 0x802A9D90: b           L_802A9DB0
    // 0x802A9D94: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9DB0;
    // 0x802A9D94: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9D98:
    // 0x802A9D98: jal         0x802A6400
    // 0x802A9D9C: nop

    func_802A6400_6B7AB0(rdram, ctx);
        goto after_34;
    // 0x802A9D9C: nop

    after_34:
    // 0x802A9DA0: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x802A9DA4: addiu       $t6, $zero, 0x7
    ctx->r14 = ADD32(0, 0X7);
    // 0x802A9DA8: sb          $t6, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r14;
L_802A9DAC:
    // 0x802A9DAC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9DB0:
    // 0x802A9DB0: lw          $t9, 0x3C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X3C);
    // 0x802A9DB4: lw          $t7, 0x58($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X58);
    // 0x802A9DB8: lw          $v0, 0x6C($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X6C);
    // 0x802A9DBC: beql        $t9, $v0, L_802A9DD0
    if (ctx->r25 == ctx->r2) {
        // 0x802A9DC0: lw          $t1, 0xC($a3)
        ctx->r9 = MEM_W(ctx->r7, 0XC);
            goto L_802A9DD0;
    }
    goto skip_12;
    // 0x802A9DC0: lw          $t1, 0xC($a3)
    ctx->r9 = MEM_W(ctx->r7, 0XC);
    skip_12:
    // 0x802A9DC4: bne         $v0, $zero, L_802A9DD8
    if (ctx->r2 != 0) {
        // 0x802A9DC8: nop
    
            goto L_802A9DD8;
    }
    // 0x802A9DC8: nop

    // 0x802A9DCC: lw          $t1, 0xC($a3)
    ctx->r9 = MEM_W(ctx->r7, 0XC);
L_802A9DD0:
    // 0x802A9DD0: subu        $t5, $t1, $t7
    ctx->r13 = SUB32(ctx->r9, ctx->r15);
    // 0x802A9DD4: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
L_802A9DD8:
    // 0x802A9DD8: jal         0x802B2964
    // 0x802A9DDC: nop

    func_802B2964_6C4014(rdram, ctx);
        goto after_35;
    // 0x802A9DDC: nop

    after_35:
    // 0x802A9DE0: jal         0x802A3CD0
    // 0x802A9DE4: nop

    func_802A3CD0_6B5380(rdram, ctx);
        goto after_36;
    // 0x802A9DE4: nop

    after_36:
    // 0x802A9DE8: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x802A9DEC: jal         0x802A403C
    // 0x802A9DF0: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_37;
    // 0x802A9DF0: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    after_37:
    // 0x802A9DF4: addiu       $a0, $sp, 0x7C
    ctx->r4 = ADD32(ctx->r29, 0X7C);
    // 0x802A9DF8: jal         0x802AC5CC
    // 0x802A9DFC: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    func_802AC5CC_6BDC7C(rdram, ctx);
        goto after_38;
    // 0x802A9DFC: addiu       $a1, $sp, 0x78
    ctx->r5 = ADD32(ctx->r29, 0X78);
    after_38:
    // 0x802A9E00: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802A9E04: lw          $t3, 0x5520($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5520);
    // 0x802A9E08: addiu       $a1, $sp, 0x7C
    ctx->r5 = ADD32(ctx->r29, 0X7C);
    // 0x802A9E0C: addiu       $a2, $sp, 0x78
    ctx->r6 = ADD32(ctx->r29, 0X78);
    // 0x802A9E10: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x802A9E14: jal         0x802ABB10
    // 0x802A9E18: lhu         $a0, 0xB2($t4)
    ctx->r4 = MEM_HU(ctx->r12, 0XB2);
    func_802ABB10_6BD1C0(rdram, ctx);
        goto after_39;
    // 0x802A9E18: lhu         $a0, 0xB2($t4)
    ctx->r4 = MEM_HU(ctx->r12, 0XB2);
    after_39:
    // 0x802A9E1C: lw          $t2, 0x7C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X7C);
    // 0x802A9E20: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x802A9E24: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9E28: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9E2C: sw          $t2, 0x1C($t6)
    MEM_W(0X1C, ctx->r14) = ctx->r10;
    // 0x802A9E30: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x802A9E34: lw          $t8, 0x78($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X78);
    // 0x802A9E38: sw          $t8, 0x20($t9)
    MEM_W(0X20, ctx->r25) = ctx->r24;
    // 0x802A9E3C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9E40: lw          $t1, 0x4($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X4);
    // 0x802A9E44: lw          $t7, 0x1C($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9E48: addu        $t5, $t1, $t7
    ctx->r13 = ADD32(ctx->r9, ctx->r15);
    // 0x802A9E4C: sw          $t5, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r13;
    // 0x802A9E50: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9E54: lui         $t1, 0x803A
    ctx->r9 = S32(0X803A << 16);
    // 0x802A9E58: lw          $t3, 0x8($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X8);
    // 0x802A9E5C: lw          $t4, 0x20($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X20);
    // 0x802A9E60: addu        $t2, $t3, $t4
    ctx->r10 = ADD32(ctx->r11, ctx->r12);
    // 0x802A9E64: sw          $t2, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r10;
    // 0x802A9E68: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9E6C: lw          $t1, 0x5B0($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5B0);
    // 0x802A9E70: lw          $t6, 0xC($a3)
    ctx->r14 = MEM_W(ctx->r7, 0XC);
    // 0x802A9E74: lw          $t8, 0x24($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X24);
    // 0x802A9E78: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A9E7C: subu        $t7, $t9, $t1
    ctx->r15 = SUB32(ctx->r25, ctx->r9);
    // 0x802A9E80: sw          $t7, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r15;
    // 0x802A9E84: b           L_802A9F80
    // 0x802A9E88: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
        goto L_802A9F80;
    // 0x802A9E88: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9E8C:
    // 0x802A9E8C: jal         0x8030AAE0
    // 0x802A9E90: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    func_8030AAE0_71C190(rdram, ctx);
        goto after_40;
    // 0x802A9E90: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_40:
    // 0x802A9E94: beq         $v0, $zero, L_802A9EB4
    if (ctx->r2 == 0) {
        // 0x802A9E98: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802A9EB4;
    }
    // 0x802A9E98: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802A9E9C: beq         $v0, $at, L_802A9EDC
    if (ctx->r2 == ctx->r1) {
        // 0x802A9EA0: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802A9EDC;
    }
    // 0x802A9EA0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802A9EA4: beql        $v0, $at, L_802A9EF8
    if (ctx->r2 == ctx->r1) {
        // 0x802A9EA8: lw          $a3, 0x0($s0)
        ctx->r7 = MEM_W(ctx->r16, 0X0);
            goto L_802A9EF8;
    }
    goto skip_13;
    // 0x802A9EA8: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    skip_13:
    // 0x802A9EAC: b           L_802A9F08
    // 0x802A9EB0: nop

        goto L_802A9F08;
    // 0x802A9EB0: nop

L_802A9EB4:
    // 0x802A9EB4: jal         0x802A64B0
    // 0x802A9EB8: nop

    func_802A64B0_6B7B60(rdram, ctx);
        goto after_41;
    // 0x802A9EB8: nop

    after_41:
    // 0x802A9EBC: beq         $v0, $zero, L_802A9F08
    if (ctx->r2 == 0) {
        // 0x802A9EC0: nop
    
            goto L_802A9F08;
    }
    // 0x802A9EC0: nop

    // 0x802A9EC4: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9EC8: lw          $t3, 0x58($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X58);
    // 0x802A9ECC: lw          $t5, 0xC($a3)
    ctx->r13 = MEM_W(ctx->r7, 0XC);
    // 0x802A9ED0: subu        $t4, $t5, $t3
    ctx->r12 = SUB32(ctx->r13, ctx->r11);
    // 0x802A9ED4: b           L_802A9F08
    // 0x802A9ED8: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
        goto L_802A9F08;
    // 0x802A9ED8: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
L_802A9EDC:
    // 0x802A9EDC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9EE0: lw          $t6, 0x58($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X58);
    // 0x802A9EE4: lw          $t2, 0xC($a3)
    ctx->r10 = MEM_W(ctx->r7, 0XC);
    // 0x802A9EE8: subu        $t8, $t2, $t6
    ctx->r24 = SUB32(ctx->r10, ctx->r14);
    // 0x802A9EEC: b           L_802A9F08
    // 0x802A9EF0: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
        goto L_802A9F08;
    // 0x802A9EF0: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
    // 0x802A9EF4: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9EF8:
    // 0x802A9EF8: lw          $t1, 0x58($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X58);
    // 0x802A9EFC: lw          $t9, 0xC($a3)
    ctx->r25 = MEM_W(ctx->r7, 0XC);
    // 0x802A9F00: subu        $t7, $t9, $t1
    ctx->r15 = SUB32(ctx->r25, ctx->r9);
    // 0x802A9F04: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
L_802A9F08:
    // 0x802A9F08: jal         0x802B2964
    // 0x802A9F0C: nop

    func_802B2964_6C4014(rdram, ctx);
        goto after_42;
    // 0x802A9F0C: nop

    after_42:
    // 0x802A9F10: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9F14: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802A9F18: lw          $t3, 0x5B0($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5B0);
    // 0x802A9F1C: lw          $t5, 0x24($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X24);
    // 0x802A9F20: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802A9F24: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802A9F28: subu        $t2, $t5, $t4
    ctx->r10 = SUB32(ctx->r13, ctx->r12);
    // 0x802A9F2C: sw          $t2, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r10;
    // 0x802A9F30: jal         0x802A403C
    // 0x802A9F34: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    func_802A403C_6B56EC(rdram, ctx);
        goto after_43;
    // 0x802A9F34: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    after_43:
    // 0x802A9F38: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9F3C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802A9F40: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802A9F44: lw          $t6, 0x4($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X4);
    // 0x802A9F48: lw          $t8, 0x1C($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X1C);
    // 0x802A9F4C: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802A9F50: sw          $t9, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r25;
    // 0x802A9F54: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9F58: lw          $t1, 0x8($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X8);
    // 0x802A9F5C: lw          $t7, 0x20($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X20);
    // 0x802A9F60: addu        $t3, $t1, $t7
    ctx->r11 = ADD32(ctx->r9, ctx->r15);
    // 0x802A9F64: sw          $t3, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r11;
    // 0x802A9F68: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802A9F6C: lw          $t5, 0xC($a3)
    ctx->r13 = MEM_W(ctx->r7, 0XC);
    // 0x802A9F70: lw          $t4, 0x24($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X24);
    // 0x802A9F74: addu        $t2, $t5, $t4
    ctx->r10 = ADD32(ctx->r13, ctx->r12);
    // 0x802A9F78: sw          $t2, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->r10;
    // 0x802A9F7C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
L_802A9F80:
    // 0x802A9F80: lhu         $t6, 0x0($a3)
    ctx->r14 = MEM_HU(ctx->r7, 0X0);
    // 0x802A9F84: addiu       $t8, $t6, -0x2
    ctx->r24 = ADD32(ctx->r14, -0X2);
    // 0x802A9F88: sltiu       $at, $t8, 0xCB
    ctx->r1 = ctx->r24 < 0XCB ? 1 : 0;
    // 0x802A9F8C: beq         $at, $zero, L_802A9FF4
    if (ctx->r1 == 0) {
        // 0x802A9F90: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802A9FF4;
    }
    // 0x802A9F90: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802A9F94: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802A9F98: addu        $at, $at, $t8
    gpr jr_addend_802A9FA0 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802A9F9C: lw          $t8, -0x4DFC($at)
    ctx->r24 = ADD32(ctx->r1, -0X4DFC);
    // 0x802A9FA0: jr          $t8
    // 0x802A9FA4: nop

    switch (jr_addend_802A9FA0 >> 2) {
        case 0: goto L_802A9FA8; break;
        case 1: goto L_802A9FA8; break;
        case 2: goto L_802A9FA8; break;
        case 3: goto L_802A9FA8; break;
        case 4: goto L_802A9FA8; break;
        case 5: goto L_802A9FF4; break;
        case 6: goto L_802A9FF4; break;
        case 7: goto L_802A9FF4; break;
        case 8: goto L_802A9FF4; break;
        case 9: goto L_802A9FF4; break;
        case 10: goto L_802A9FF4; break;
        case 11: goto L_802A9FF4; break;
        case 12: goto L_802A9FF4; break;
        case 13: goto L_802A9FF4; break;
        case 14: goto L_802A9FF4; break;
        case 15: goto L_802A9FF4; break;
        case 16: goto L_802A9FF4; break;
        case 17: goto L_802A9FF4; break;
        case 18: goto L_802A9FF4; break;
        case 19: goto L_802A9FA8; break;
        case 20: goto L_802A9FA8; break;
        case 21: goto L_802A9FA8; break;
        case 22: goto L_802A9FA8; break;
        case 23: goto L_802A9FF4; break;
        case 24: goto L_802A9FF4; break;
        case 25: goto L_802A9FF4; break;
        case 26: goto L_802A9FF4; break;
        case 27: goto L_802A9FF4; break;
        case 28: goto L_802A9FF4; break;
        case 29: goto L_802A9FF4; break;
        case 30: goto L_802A9FF4; break;
        case 31: goto L_802A9FF4; break;
        case 32: goto L_802A9FF4; break;
        case 33: goto L_802A9FF4; break;
        case 34: goto L_802A9FF4; break;
        case 35: goto L_802A9FF4; break;
        case 36: goto L_802A9FF4; break;
        case 37: goto L_802A9FF4; break;
        case 38: goto L_802A9FF4; break;
        case 39: goto L_802A9FA8; break;
        case 40: goto L_802A9FF4; break;
        case 41: goto L_802A9FF4; break;
        case 42: goto L_802A9FF4; break;
        case 43: goto L_802A9FF4; break;
        case 44: goto L_802A9FF4; break;
        case 45: goto L_802A9FF4; break;
        case 46: goto L_802A9FF4; break;
        case 47: goto L_802A9FF4; break;
        case 48: goto L_802A9FF4; break;
        case 49: goto L_802A9FF4; break;
        case 50: goto L_802A9FF4; break;
        case 51: goto L_802A9FF4; break;
        case 52: goto L_802A9FF4; break;
        case 53: goto L_802A9FF4; break;
        case 54: goto L_802A9FF4; break;
        case 55: goto L_802A9FF4; break;
        case 56: goto L_802A9FF4; break;
        case 57: goto L_802A9FF4; break;
        case 58: goto L_802A9FF4; break;
        case 59: goto L_802A9FA8; break;
        case 60: goto L_802A9FA8; break;
        case 61: goto L_802A9FF4; break;
        case 62: goto L_802A9FF4; break;
        case 63: goto L_802A9FF4; break;
        case 64: goto L_802A9FF4; break;
        case 65: goto L_802A9FF4; break;
        case 66: goto L_802A9FF4; break;
        case 67: goto L_802A9FF4; break;
        case 68: goto L_802A9FF4; break;
        case 69: goto L_802A9FF4; break;
        case 70: goto L_802A9FF4; break;
        case 71: goto L_802A9FF4; break;
        case 72: goto L_802A9FF4; break;
        case 73: goto L_802A9FF4; break;
        case 74: goto L_802A9FF4; break;
        case 75: goto L_802A9FF4; break;
        case 76: goto L_802A9FF4; break;
        case 77: goto L_802A9FF4; break;
        case 78: goto L_802A9FF4; break;
        case 79: goto L_802A9FD8; break;
        case 80: goto L_802A9FF4; break;
        case 81: goto L_802A9FF4; break;
        case 82: goto L_802A9FF4; break;
        case 83: goto L_802A9FF4; break;
        case 84: goto L_802A9FF4; break;
        case 85: goto L_802A9FF4; break;
        case 86: goto L_802A9FF4; break;
        case 87: goto L_802A9FF4; break;
        case 88: goto L_802A9FF4; break;
        case 89: goto L_802A9FF4; break;
        case 90: goto L_802A9FF4; break;
        case 91: goto L_802A9FF4; break;
        case 92: goto L_802A9FF4; break;
        case 93: goto L_802A9FF4; break;
        case 94: goto L_802A9FF4; break;
        case 95: goto L_802A9FF4; break;
        case 96: goto L_802A9FF4; break;
        case 97: goto L_802A9FF4; break;
        case 98: goto L_802A9FF4; break;
        case 99: goto L_802A9FA8; break;
        case 100: goto L_802A9FF4; break;
        case 101: goto L_802A9FF4; break;
        case 102: goto L_802A9FA8; break;
        case 103: goto L_802A9FA8; break;
        case 104: goto L_802A9FF4; break;
        case 105: goto L_802A9FF4; break;
        case 106: goto L_802A9FF4; break;
        case 107: goto L_802A9FF4; break;
        case 108: goto L_802A9FF4; break;
        case 109: goto L_802A9FF4; break;
        case 110: goto L_802A9FF4; break;
        case 111: goto L_802A9FF4; break;
        case 112: goto L_802A9FF4; break;
        case 113: goto L_802A9FF4; break;
        case 114: goto L_802A9FF4; break;
        case 115: goto L_802A9FF4; break;
        case 116: goto L_802A9FF4; break;
        case 117: goto L_802A9FF4; break;
        case 118: goto L_802A9FF4; break;
        case 119: goto L_802A9FA8; break;
        case 120: goto L_802A9FA8; break;
        case 121: goto L_802A9FA8; break;
        case 122: goto L_802A9FF4; break;
        case 123: goto L_802A9FF4; break;
        case 124: goto L_802A9FF4; break;
        case 125: goto L_802A9FF4; break;
        case 126: goto L_802A9FF4; break;
        case 127: goto L_802A9FF4; break;
        case 128: goto L_802A9FF4; break;
        case 129: goto L_802A9FF4; break;
        case 130: goto L_802A9FF4; break;
        case 131: goto L_802A9FF4; break;
        case 132: goto L_802A9FF4; break;
        case 133: goto L_802A9FF4; break;
        case 134: goto L_802A9FF4; break;
        case 135: goto L_802A9FF4; break;
        case 136: goto L_802A9FF4; break;
        case 137: goto L_802A9FF4; break;
        case 138: goto L_802A9FF4; break;
        case 139: goto L_802A9FA8; break;
        case 140: goto L_802A9FA8; break;
        case 141: goto L_802A9FA8; break;
        case 142: goto L_802A9FA8; break;
        case 143: goto L_802A9FF4; break;
        case 144: goto L_802A9FF4; break;
        case 145: goto L_802A9FF4; break;
        case 146: goto L_802A9FF4; break;
        case 147: goto L_802A9FF4; break;
        case 148: goto L_802A9FF4; break;
        case 149: goto L_802A9FF4; break;
        case 150: goto L_802A9FF4; break;
        case 151: goto L_802A9FF4; break;
        case 152: goto L_802A9FF4; break;
        case 153: goto L_802A9FF4; break;
        case 154: goto L_802A9FF4; break;
        case 155: goto L_802A9FF4; break;
        case 156: goto L_802A9FF4; break;
        case 157: goto L_802A9FF4; break;
        case 158: goto L_802A9FF4; break;
        case 159: goto L_802A9FA8; break;
        case 160: goto L_802A9FA8; break;
        case 161: goto L_802A9FF4; break;
        case 162: goto L_802A9FF4; break;
        case 163: goto L_802A9FF4; break;
        case 164: goto L_802A9FF4; break;
        case 165: goto L_802A9FF4; break;
        case 166: goto L_802A9FF4; break;
        case 167: goto L_802A9FF4; break;
        case 168: goto L_802A9FF4; break;
        case 169: goto L_802A9FF4; break;
        case 170: goto L_802A9FF4; break;
        case 171: goto L_802A9FF4; break;
        case 172: goto L_802A9FF4; break;
        case 173: goto L_802A9FF4; break;
        case 174: goto L_802A9FF4; break;
        case 175: goto L_802A9FF4; break;
        case 176: goto L_802A9FF4; break;
        case 177: goto L_802A9FF4; break;
        case 178: goto L_802A9FF4; break;
        case 179: goto L_802A9FA8; break;
        case 180: goto L_802A9FA8; break;
        case 181: goto L_802A9FA8; break;
        case 182: goto L_802A9FF4; break;
        case 183: goto L_802A9FA8; break;
        case 184: goto L_802A9FF4; break;
        case 185: goto L_802A9FF4; break;
        case 186: goto L_802A9FF4; break;
        case 187: goto L_802A9FF4; break;
        case 188: goto L_802A9FF4; break;
        case 189: goto L_802A9FF4; break;
        case 190: goto L_802A9FF4; break;
        case 191: goto L_802A9FF4; break;
        case 192: goto L_802A9FF4; break;
        case 193: goto L_802A9FF4; break;
        case 194: goto L_802A9FF4; break;
        case 195: goto L_802A9FF4; break;
        case 196: goto L_802A9FF4; break;
        case 197: goto L_802A9FF4; break;
        case 198: goto L_802A9FF4; break;
        case 199: goto L_802A9FA8; break;
        case 200: goto L_802A9FA8; break;
        case 201: goto L_802A9FA8; break;
        case 202: goto L_802A9FA8; break;
        default: switch_error(__func__, 0x802A9FA0, 0x803BB204);
    }
    // 0x802A9FA4: nop

L_802A9FA8:
    // 0x802A9FA8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A9FAC: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802A9FB0: lh          $t9, 0x302($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X302);
    // 0x802A9FB4: sh          $t9, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r25;
    // 0x802A9FB8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802A9FBC: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802A9FC0: addiu       $a0, $v0, 0x302
    ctx->r4 = ADD32(ctx->r2, 0X302);
    // 0x802A9FC4: lh          $a1, 0x2C($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X2C);
    // 0x802A9FC8: jal         0x802DB940
    // 0x802A9FCC: lhu         $a2, 0xB0($t1)
    ctx->r6 = MEM_HU(ctx->r9, 0XB0);
    func_802DB940_6ECFF0(rdram, ctx);
        goto after_44;
    // 0x802A9FCC: lhu         $a2, 0xB0($t1)
    ctx->r6 = MEM_HU(ctx->r9, 0XB0);
    after_44:
    // 0x802A9FD0: b           L_802A9FF4
    // 0x802A9FD4: nop

        goto L_802A9FF4;
    // 0x802A9FD4: nop

L_802A9FD8:
    // 0x802A9FD8: lw          $a1, 0x0($t0)
    ctx->r5 = MEM_W(ctx->r8, 0X0);
    // 0x802A9FDC: lh          $t7, 0x302($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X302);
    // 0x802A9FE0: sh          $t7, 0x304($a1)
    MEM_H(0X304, ctx->r5) = ctx->r15;
    // 0x802A9FE4: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x802A9FE8: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x802A9FEC: lh          $t5, 0x2C($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X2C);
    // 0x802A9FF0: sh          $t5, 0x302($t4)
    MEM_H(0X302, ctx->r12) = ctx->r13;
L_802A9FF4:
    // 0x802A9FF4: jal         0x802B3230
    // 0x802A9FF8: nop

    func_802B3230_6C48E0(rdram, ctx);
        goto after_45;
    // 0x802A9FF8: nop

    after_45:
    // 0x802A9FFC: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802AA000: addiu       $t6, $zero, 0x80
    ctx->r14 = ADD32(0, 0X80);
    // 0x802AA004: addiu       $t1, $zero, 0x80
    ctx->r9 = ADD32(0, 0X80);
    // 0x802AA008: lh          $t2, 0x4($a3)
    ctx->r10 = MEM_H(ctx->r7, 0X4);
    // 0x802AA00C: addiu       $t5, $zero, 0x117F
    ctx->r13 = ADD32(0, 0X117F);
    // 0x802AA010: slti        $at, $t2, 0x80
    ctx->r1 = SIGNED(ctx->r10) < 0X80 ? 1 : 0;
    // 0x802AA014: beql        $at, $zero, L_802AA030
    if (ctx->r1 == 0) {
        // 0x802AA018: lh          $t9, 0x8($a3)
        ctx->r25 = MEM_H(ctx->r7, 0X8);
            goto L_802AA030;
    }
    goto skip_14;
    // 0x802AA018: lh          $t9, 0x8($a3)
    ctx->r25 = MEM_H(ctx->r7, 0X8);
    skip_14:
    // 0x802AA01C: sh          $t6, 0x4($a3)
    MEM_H(0X4, ctx->r7) = ctx->r14;
    // 0x802AA020: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x802AA024: sw          $zero, 0x1C($t8)
    MEM_W(0X1C, ctx->r24) = 0;
    // 0x802AA028: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802AA02C: lh          $t9, 0x8($a3)
    ctx->r25 = MEM_H(ctx->r7, 0X8);
L_802AA030:
    // 0x802AA030: addiu       $t6, $zero, 0x1F7F
    ctx->r14 = ADD32(0, 0X1F7F);
    // 0x802AA034: slti        $at, $t9, 0x80
    ctx->r1 = SIGNED(ctx->r25) < 0X80 ? 1 : 0;
    // 0x802AA038: beql        $at, $zero, L_802AA054
    if (ctx->r1 == 0) {
        // 0x802AA03C: lh          $t3, 0x4($a3)
        ctx->r11 = MEM_H(ctx->r7, 0X4);
            goto L_802AA054;
    }
    goto skip_15;
    // 0x802AA03C: lh          $t3, 0x4($a3)
    ctx->r11 = MEM_H(ctx->r7, 0X4);
    skip_15:
    // 0x802AA040: sh          $t1, 0x8($a3)
    MEM_H(0X8, ctx->r7) = ctx->r9;
    // 0x802AA044: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x802AA048: sw          $zero, 0x20($t7)
    MEM_W(0X20, ctx->r15) = 0;
    // 0x802AA04C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802AA050: lh          $t3, 0x4($a3)
    ctx->r11 = MEM_H(ctx->r7, 0X4);
L_802AA054:
    // 0x802AA054: slti        $at, $t3, 0x1180
    ctx->r1 = SIGNED(ctx->r11) < 0X1180 ? 1 : 0;
    // 0x802AA058: bnel        $at, $zero, L_802AA074
    if (ctx->r1 != 0) {
        // 0x802AA05C: lh          $t2, 0x8($a3)
        ctx->r10 = MEM_H(ctx->r7, 0X8);
            goto L_802AA074;
    }
    goto skip_16;
    // 0x802AA05C: lh          $t2, 0x8($a3)
    ctx->r10 = MEM_H(ctx->r7, 0X8);
    skip_16:
    // 0x802AA060: sh          $t5, 0x4($a3)
    MEM_H(0X4, ctx->r7) = ctx->r13;
    // 0x802AA064: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x802AA068: sw          $zero, 0x1C($t4)
    MEM_W(0X1C, ctx->r12) = 0;
    // 0x802AA06C: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x802AA070: lh          $t2, 0x8($a3)
    ctx->r10 = MEM_H(ctx->r7, 0X8);
L_802AA074:
    // 0x802AA074: slti        $at, $t2, 0x1F80
    ctx->r1 = SIGNED(ctx->r10) < 0X1F80 ? 1 : 0;
    // 0x802AA078: bnel        $at, $zero, L_802AA090
    if (ctx->r1 != 0) {
        // 0x802AA07C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_802AA090;
    }
    goto skip_17;
    // 0x802AA07C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_17:
    // 0x802AA080: sh          $t6, 0x8($a3)
    MEM_H(0X8, ctx->r7) = ctx->r14;
    // 0x802AA084: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x802AA088: sw          $zero, 0x20($t8)
    MEM_W(0X20, ctx->r24) = 0;
    // 0x802AA08C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_802AA090:
    // 0x802AA090: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802AA094: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    // 0x802AA098: jr          $ra
    // 0x802AA09C: nop

    return;
    // 0x802AA09C: nop

;}
RECOMP_FUNC void func_802AA0A0_6BB750(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA0A0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AA0A4: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802AA0A8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AA0AC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AA0B0: lbu         $t7, 0x366($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X366);
    // 0x802AA0B4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802AA0B8: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AA0BC: beq         $t7, $at, L_802AA118
    if (ctx->r15 == ctx->r1) {
        // 0x802AA0C0: addiu       $a2, $a2, 0x5530
        ctx->r6 = ADD32(ctx->r6, 0X5530);
            goto L_802AA118;
    }
    // 0x802AA0C0: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802AA0C4: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802AA0C8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802AA0CC: lhu         $v0, 0x0($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X0);
    // 0x802AA0D0: beq         $v0, $at, L_802AA0F0
    if (ctx->r2 == ctx->r1) {
        // 0x802AA0D4: addiu       $at, $zero, 0x15
        ctx->r1 = ADD32(0, 0X15);
            goto L_802AA0F0;
    }
    // 0x802AA0D4: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x802AA0D8: beq         $v0, $at, L_802AA0F0
    if (ctx->r2 == ctx->r1) {
        // 0x802AA0DC: addiu       $at, $zero, 0x29
        ctx->r1 = ADD32(0, 0X29);
            goto L_802AA0F0;
    }
    // 0x802AA0DC: addiu       $at, $zero, 0x29
    ctx->r1 = ADD32(0, 0X29);
    // 0x802AA0E0: beq         $v0, $at, L_802AA0F0
    if (ctx->r2 == ctx->r1) {
        // 0x802AA0E4: addiu       $at, $zero, 0x79
        ctx->r1 = ADD32(0, 0X79);
            goto L_802AA0F0;
    }
    // 0x802AA0E4: addiu       $at, $zero, 0x79
    ctx->r1 = ADD32(0, 0X79);
    // 0x802AA0E8: bne         $v0, $at, L_802AA118
    if (ctx->r2 != ctx->r1) {
        // 0x802AA0EC: nop
    
            goto L_802AA118;
    }
    // 0x802AA0EC: nop

L_802AA0F0:
    // 0x802AA0F0: jal         0x8012826C
    // 0x802AA0F4: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x802AA0F4: nop

    after_0:
    // 0x802AA0F8: andi        $t9, $v0, 0x1F
    ctx->r25 = ctx->r2 & 0X1F;
    // 0x802AA0FC: bne         $t9, $zero, L_802AA118
    if (ctx->r25 != 0) {
        // 0x802AA100: lui         $t0, 0x803F
        ctx->r8 = S32(0X803F << 16);
            goto L_802AA118;
    }
    // 0x802AA100: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x802AA104: lh          $t0, 0x6450($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X6450);
    // 0x802AA108: beq         $t0, $zero, L_802AA118
    if (ctx->r8 == 0) {
        // 0x802AA10C: nop
    
            goto L_802AA118;
    }
    // 0x802AA10C: nop

    // 0x802AA110: jal         0x802AA5C0
    // 0x802AA114: nop

    func_802AA5C0_6BBC70(rdram, ctx);
        goto after_1;
    // 0x802AA114: nop

    after_1:
L_802AA118:
    // 0x802AA118: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AA11C: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802AA120: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802AA124: lbu         $t1, 0x4B($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X4B);
    // 0x802AA128: slti        $at, $t1, 0x21
    ctx->r1 = SIGNED(ctx->r9) < 0X21 ? 1 : 0;
    // 0x802AA12C: bnel        $at, $zero, L_802AA1E0
    if (ctx->r1 != 0) {
        // 0x802AA130: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA1E0;
    }
    goto skip_0;
    // 0x802AA130: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AA134: lw          $t2, 0x4C($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X4C);
    // 0x802AA138: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AA13C: sll         $t4, $t2, 26
    ctx->r12 = S32(ctx->r10 << 26);
    // 0x802AA140: bltzl       $t4, L_802AA1E0
    if (SIGNED(ctx->r12) < 0) {
        // 0x802AA144: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA1E0;
    }
    goto skip_1;
    // 0x802AA144: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802AA148: lh          $v1, 0x14C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14C);
    // 0x802AA14C: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x802AA150: bgezl       $v1, L_802AA164
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AA154: sh          $v1, 0x14C($v0)
        MEM_H(0X14C, ctx->r2) = ctx->r3;
            goto L_802AA164;
    }
    goto skip_2;
    // 0x802AA154: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
    skip_2:
    // 0x802AA158: b           L_802AA164
    // 0x802AA15C: sh          $zero, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = 0;
        goto L_802AA164;
    // 0x802AA15C: sh          $zero, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = 0;
    // 0x802AA160: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
L_802AA164:
    // 0x802AA164: jal         0x80349280
    // 0x802AA168: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_2;
    // 0x802AA168: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    after_2:
    // 0x802AA16C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AA170: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802AA174: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802AA178: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AA17C: lbu         $v1, 0x4B($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X4B);
    // 0x802AA180: slti        $at, $v1, 0x31
    ctx->r1 = SIGNED(ctx->r3) < 0X31 ? 1 : 0;
    // 0x802AA184: bnel        $at, $zero, L_802AA1C8
    if (ctx->r1 != 0) {
        // 0x802AA188: slti        $at, $v1, 0x3D
        ctx->r1 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
            goto L_802AA1C8;
    }
    goto skip_3;
    // 0x802AA188: slti        $at, $v1, 0x3D
    ctx->r1 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
    skip_3:
    // 0x802AA18C: lh          $v1, 0x14C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14C);
    // 0x802AA190: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x802AA194: bgezl       $v1, L_802AA1A8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AA198: sh          $v1, 0x14C($v0)
        MEM_H(0X14C, ctx->r2) = ctx->r3;
            goto L_802AA1A8;
    }
    goto skip_4;
    // 0x802AA198: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
    skip_4:
    // 0x802AA19C: b           L_802AA1A8
    // 0x802AA1A0: sh          $zero, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = 0;
        goto L_802AA1A8;
    // 0x802AA1A0: sh          $zero, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = 0;
    // 0x802AA1A4: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
L_802AA1A8:
    // 0x802AA1A8: jal         0x80349280
    // 0x802AA1AC: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_3;
    // 0x802AA1AC: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    after_3:
    // 0x802AA1B0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AA1B4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AA1B8: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AA1BC: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x802AA1C0: lbu         $v1, 0x4B($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X4B);
    // 0x802AA1C4: slti        $at, $v1, 0x3D
    ctx->r1 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
L_802AA1C8:
    // 0x802AA1C8: bne         $at, $zero, L_802AA1DC
    if (ctx->r1 != 0) {
        // 0x802AA1CC: addiu       $a1, $zero, 0x28
        ctx->r5 = ADD32(0, 0X28);
            goto L_802AA1DC;
    }
    // 0x802AA1CC: addiu       $a1, $zero, 0x28
    ctx->r5 = ADD32(0, 0X28);
    // 0x802AA1D0: sh          $zero, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = 0;
    // 0x802AA1D4: jal         0x80349280
    // 0x802AA1D8: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    func_80349280_75A930(rdram, ctx);
        goto after_4;
    // 0x802AA1D8: lw          $a0, 0x0($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X0);
    after_4:
L_802AA1DC:
    // 0x802AA1DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AA1E0:
    // 0x802AA1E0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AA1E4: jr          $ra
    // 0x802AA1E8: nop

    return;
    // 0x802AA1E8: nop

;}
RECOMP_FUNC void func_802AA1EC_6BB89C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA1EC: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802AA1F0: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802AA1F4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802AA1F8: addiu       $s0, $s0, 0x5530
    ctx->r16 = ADD32(ctx->r16, 0X5530);
    // 0x802AA1FC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x802AA200: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802AA204: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802AA208: lhu         $t6, 0x0($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X0);
    // 0x802AA20C: beq         $t6, $at, L_802AA3F4
    if (ctx->r14 == ctx->r1) {
        // 0x802AA210: nop
    
            goto L_802AA3F4;
    }
    // 0x802AA210: nop

    // 0x802AA214: lbu         $t7, 0x162($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X162);
    // 0x802AA218: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x802AA21C: addiu       $t9, $t8, -0x2
    ctx->r25 = ADD32(ctx->r24, -0X2);
    // 0x802AA220: sltiu       $at, $t9, 0x6
    ctx->r1 = ctx->r25 < 0X6 ? 1 : 0;
    // 0x802AA224: beq         $at, $zero, L_802AA37C
    if (ctx->r1 == 0) {
        // 0x802AA228: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802AA37C;
    }
    // 0x802AA228: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802AA22C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AA230: addu        $at, $at, $t9
    gpr jr_addend_802AA238 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802AA234: lw          $t9, -0x4AD0($at)
    ctx->r25 = ADD32(ctx->r1, -0X4AD0);
    // 0x802AA238: jr          $t9
    // 0x802AA23C: nop

    switch (jr_addend_802AA238 >> 2) {
        case 0: goto L_802AA2F4; break;
        case 1: goto L_802AA2F4; break;
        case 2: goto L_802AA240; break;
        case 3: goto L_802AA240; break;
        case 4: goto L_802AA240; break;
        case 5: goto L_802AA240; break;
        default: switch_error(__func__, 0x802AA238, 0x803BB530);
    }
    // 0x802AA23C: nop

L_802AA240:
    // 0x802AA240: lw          $t0, 0x4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X4);
    // 0x802AA244: sw          $t0, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r8;
    // 0x802AA248: lw          $t1, 0x8($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X8);
    // 0x802AA24C: sw          $t1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r9;
    // 0x802AA250: lbu         $t2, 0x160($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X160);
    // 0x802AA254: jal         0x802AA444
    // 0x802AA258: sb          $t2, 0x37($sp)
    MEM_B(0X37, ctx->r29) = ctx->r10;
    func_802AA444_6BBAF4(rdram, ctx);
        goto after_0;
    // 0x802AA258: sb          $t2, 0x37($sp)
    MEM_B(0X37, ctx->r29) = ctx->r10;
    after_0:
    // 0x802AA25C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x802AA260: lw          $t4, 0x3C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X3C);
    // 0x802AA264: lw          $t6, 0x38($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X38);
    // 0x802AA268: lw          $t3, 0x4($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X4);
    // 0x802AA26C: lw          $t5, 0x8($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X8);
    // 0x802AA270: subu        $a0, $t3, $t4
    ctx->r4 = SUB32(ctx->r11, ctx->r12);
    // 0x802AA274: jal         0x802B2AF0
    // 0x802AA278: subu        $a1, $t5, $t6
    ctx->r5 = SUB32(ctx->r13, ctx->r14);
    func_802B2AF0_6C41A0(rdram, ctx);
        goto after_1;
    // 0x802AA278: subu        $a1, $t5, $t6
    ctx->r5 = SUB32(ctx->r13, ctx->r14);
    after_1:
    // 0x802AA27C: beq         $v0, $zero, L_802AA2A4
    if (ctx->r2 == 0) {
        // 0x802AA280: lbu         $t7, 0x37($sp)
        ctx->r15 = MEM_BU(ctx->r29, 0X37);
            goto L_802AA2A4;
    }
    // 0x802AA280: lbu         $t7, 0x37($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X37);
    // 0x802AA284: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x802AA288: sb          $t7, 0x160($t8)
    MEM_B(0X160, ctx->r24) = ctx->r15;
    // 0x802AA28C: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x802AA290: lw          $t9, 0x3C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X3C);
    // 0x802AA294: sw          $t9, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r25;
    // 0x802AA298: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x802AA29C: lw          $t1, 0x38($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X38);
    // 0x802AA2A0: sw          $t1, 0x8($t2)
    MEM_W(0X8, ctx->r10) = ctx->r9;
L_802AA2A4:
    // 0x802AA2A4: jal         0x802B2964
    // 0x802AA2A8: nop

    func_802B2964_6C4014(rdram, ctx);
        goto after_2;
    // 0x802AA2A8: nop

    after_2:
    // 0x802AA2AC: jal         0x802A40EC
    // 0x802AA2B0: nop

    func_802A40EC_6B579C(rdram, ctx);
        goto after_3;
    // 0x802AA2B0: nop

    after_3:
    // 0x802AA2B4: sw          $zero, 0x40($sp)
    MEM_W(0X40, ctx->r29) = 0;
    // 0x802AA2B8: sw          $zero, 0x44($sp)
    MEM_W(0X44, ctx->r29) = 0;
    // 0x802AA2BC: addiu       $a0, $sp, 0x44
    ctx->r4 = ADD32(ctx->r29, 0X44);
    // 0x802AA2C0: jal         0x802A3F68
    // 0x802AA2C4: addiu       $a1, $sp, 0x40
    ctx->r5 = ADD32(ctx->r29, 0X40);
    func_802A3F68_6B5618(rdram, ctx);
        goto after_4;
    // 0x802AA2C4: addiu       $a1, $sp, 0x40
    ctx->r5 = ADD32(ctx->r29, 0X40);
    after_4:
    // 0x802AA2C8: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x802AA2CC: addiu       $a1, $sp, 0x44
    ctx->r5 = ADD32(ctx->r29, 0X44);
    // 0x802AA2D0: jal         0x802AC158
    // 0x802AA2D4: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    func_802AC158_6BD808(rdram, ctx);
        goto after_5;
    // 0x802AA2D4: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    after_5:
    // 0x802AA2D8: lw          $t3, 0x44($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X44);
    // 0x802AA2DC: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x802AA2E0: sw          $t3, 0x1C($t4)
    MEM_W(0X1C, ctx->r12) = ctx->r11;
    // 0x802AA2E4: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x802AA2E8: lw          $t5, 0x40($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X40);
    // 0x802AA2EC: b           L_802AA3F4
    // 0x802AA2F0: sw          $t5, 0x20($t6)
    MEM_W(0X20, ctx->r14) = ctx->r13;
        goto L_802AA3F4;
    // 0x802AA2F0: sw          $t5, 0x20($t6)
    MEM_W(0X20, ctx->r14) = ctx->r13;
L_802AA2F4:
    // 0x802AA2F4: jal         0x802AA444
    // 0x802AA2F8: nop

    func_802AA444_6BBAF4(rdram, ctx);
        goto after_6;
    // 0x802AA2F8: nop

    after_6:
    // 0x802AA2FC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x802AA300: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AA304: lbu         $t7, 0x162($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X162);
    // 0x802AA308: bne         $t7, $at, L_802AA350
    if (ctx->r15 != ctx->r1) {
        // 0x802AA30C: nop
    
            goto L_802AA350;
    }
    // 0x802AA30C: nop

    // 0x802AA310: lh          $t8, 0x24($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X24);
    // 0x802AA314: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    // 0x802AA318: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802AA31C: slti        $at, $t8, -0xA
    ctx->r1 = SIGNED(ctx->r24) < -0XA ? 1 : 0;
    // 0x802AA320: beq         $at, $zero, L_802AA350
    if (ctx->r1 == 0) {
        // 0x802AA324: nop
    
            goto L_802AA350;
    }
    // 0x802AA324: nop

    // 0x802AA328: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x802AA32C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x802AA330: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x802AA334: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802AA338: lh          $t0, 0xC($v0)
    ctx->r8 = MEM_H(ctx->r2, 0XC);
    // 0x802AA33C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802AA340: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802AA344: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802AA348: jal         0x8032C360
    // 0x802AA34C: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_7;
    // 0x802AA34C: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_7:
L_802AA350:
    // 0x802AA350: jal         0x802B2834
    // 0x802AA354: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_8;
    // 0x802AA354: nop

    after_8:
    // 0x802AA358: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA35C: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802AA360: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802AA364: lui         $t2, 0x803A
    ctx->r10 = S32(0X803A << 16);
    // 0x802AA368: lw          $t2, 0x5B0($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5B0);
    // 0x802AA36C: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802AA370: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x802AA374: b           L_802AA3F4
    // 0x802AA378: sw          $t3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r11;
        goto L_802AA3F4;
    // 0x802AA378: sw          $t3, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r11;
L_802AA37C:
    // 0x802AA37C: jal         0x802AA444
    // 0x802AA380: nop

    func_802AA444_6BBAF4(rdram, ctx);
        goto after_9;
    // 0x802AA380: nop

    after_9:
    // 0x802AA384: jal         0x802B2834
    // 0x802AA388: nop

    func_802B2834_6C3EE4(rdram, ctx);
        goto after_10;
    // 0x802AA388: nop

    after_10:
    // 0x802AA38C: jal         0x802A3CD0
    // 0x802AA390: nop

    func_802A3CD0_6B5380(rdram, ctx);
        goto after_11;
    // 0x802AA390: nop

    after_11:
    // 0x802AA394: sw          $zero, 0x40($sp)
    MEM_W(0X40, ctx->r29) = 0;
    // 0x802AA398: sw          $zero, 0x44($sp)
    MEM_W(0X44, ctx->r29) = 0;
    // 0x802AA39C: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    // 0x802AA3A0: addiu       $a1, $sp, 0x44
    ctx->r5 = ADD32(ctx->r29, 0X44);
    // 0x802AA3A4: jal         0x802ABB10
    // 0x802AA3A8: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    func_802ABB10_6BD1C0(rdram, ctx);
        goto after_12;
    // 0x802AA3A8: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    after_12:
    // 0x802AA3AC: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x802AA3B0: addiu       $a1, $sp, 0x44
    ctx->r5 = ADD32(ctx->r29, 0X44);
    // 0x802AA3B4: jal         0x802A3E70
    // 0x802AA3B8: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    func_802A3E70_6B5520(rdram, ctx);
        goto after_13;
    // 0x802AA3B8: addiu       $a2, $sp, 0x40
    ctx->r6 = ADD32(ctx->r29, 0X40);
    after_13:
    // 0x802AA3BC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA3C0: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802AA3C4: lw          $t5, 0x0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X0);
    // 0x802AA3C8: lw          $t4, 0x44($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X44);
    // 0x802AA3CC: lui         $t9, 0x803A
    ctx->r25 = S32(0X803A << 16);
    // 0x802AA3D0: sw          $t4, 0x1C($t5)
    MEM_W(0X1C, ctx->r13) = ctx->r12;
    // 0x802AA3D4: lw          $t7, 0x0($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X0);
    // 0x802AA3D8: lw          $t6, 0x40($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X40);
    // 0x802AA3DC: sw          $t6, 0x20($t7)
    MEM_W(0X20, ctx->r15) = ctx->r14;
    // 0x802AA3E0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802AA3E4: lw          $t9, 0x5B0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5B0);
    // 0x802AA3E8: lw          $t8, 0x24($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X24);
    // 0x802AA3EC: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x802AA3F0: sw          $t0, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r8;
L_802AA3F4:
    // 0x802AA3F4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA3F8: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802AA3FC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802AA400: lh          $v1, 0x2C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2C);
    // 0x802AA404: sh          $v1, 0x302($v0)
    MEM_H(0X302, ctx->r2) = ctx->r3;
    // 0x802AA408: lw          $t1, 0x0($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X0);
    // 0x802AA40C: sh          $v1, 0x304($t1)
    MEM_H(0X304, ctx->r9) = ctx->r3;
    // 0x802AA410: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802AA414: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802AA418: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x802AA41C: jr          $ra
    // 0x802AA420: nop

    return;
    // 0x802AA420: nop

;}
