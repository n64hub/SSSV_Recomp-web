#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_802AA424_6BBAD4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA424: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AA428: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AA42C: jal         0x802AA444
    // 0x802AA430: nop

    func_802AA444_6BBAF4(rdram, ctx);
        goto after_0;
    // 0x802AA430: nop

    after_0:
    // 0x802AA434: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AA438: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AA43C: jr          $ra
    // 0x802AA440: nop

    return;
    // 0x802AA440: nop

;}
RECOMP_FUNC void func_802AA444_6BBAF4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA444: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AA448: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802AA44C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802AA450: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AA454: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA458: lw          $t7, 0xC($t6)
    ctx->r15 = MEM_W(ctx->r14, 0XC);
    // 0x802AA45C: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AA460: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x802AA464: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x802AA468: lbu         $t8, 0x162($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X162);
    // 0x802AA46C: andi        $t9, $t8, 0xF
    ctx->r25 = ctx->r24 & 0XF;
    // 0x802AA470: addiu       $t0, $t9, -0x1
    ctx->r8 = ADD32(ctx->r25, -0X1);
    // 0x802AA474: sltiu       $at, $t0, 0x7
    ctx->r1 = ctx->r8 < 0X7 ? 1 : 0;
    // 0x802AA478: beq         $at, $zero, L_802AA5A0
    if (ctx->r1 == 0) {
        // 0x802AA47C: sll         $t0, $t0, 2
        ctx->r8 = S32(ctx->r8 << 2);
            goto L_802AA5A0;
    }
    // 0x802AA47C: sll         $t0, $t0, 2
    ctx->r8 = S32(ctx->r8 << 2);
    // 0x802AA480: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AA484: addu        $at, $at, $t0
    gpr jr_addend_802AA48C = ctx->r8;
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x802AA488: lw          $t0, -0x4AB8($at)
    ctx->r8 = ADD32(ctx->r1, -0X4AB8);
    // 0x802AA48C: jr          $t0
    // 0x802AA490: nop

    switch (jr_addend_802AA48C >> 2) {
        case 0: goto L_802AA494; break;
        case 1: goto L_802AA4CC; break;
        case 2: goto L_802AA4CC; break;
        case 3: goto L_802AA51C; break;
        case 4: goto L_802AA51C; break;
        case 5: goto L_802AA56C; break;
        case 6: goto L_802AA51C; break;
        default: switch_error(__func__, 0x802AA48C, 0x803BB548);
    }
    // 0x802AA490: nop

L_802AA494:
    // 0x802AA494: jal         0x8030AAE0
    // 0x802AA498: nop

    func_8030AAE0_71C190(rdram, ctx);
        goto after_0;
    // 0x802AA498: nop

    after_0:
    // 0x802AA49C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA4A0: beq         $v0, $zero, L_802AA4C0
    if (ctx->r2 == 0) {
        // 0x802AA4A4: addiu       $v1, $v1, 0x5530
        ctx->r3 = ADD32(ctx->r3, 0X5530);
            goto L_802AA4C0;
    }
    // 0x802AA4A4: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AA4A8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AA4AC: bne         $v0, $at, L_802AA4C0
    if (ctx->r2 != ctx->r1) {
        // 0x802AA4B0: nop
    
            goto L_802AA4C0;
    }
    // 0x802AA4B0: nop

    // 0x802AA4B4: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA4B8: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x802AA4BC: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
L_802AA4C0:
    // 0x802AA4C0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA4C4: b           L_802AA5A0
    // 0x802AA4C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
        goto L_802AA5A0;
    // 0x802AA4C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
L_802AA4CC:
    // 0x802AA4CC: jal         0x8030AAE0
    // 0x802AA4D0: nop

    func_8030AAE0_71C190(rdram, ctx);
        goto after_1;
    // 0x802AA4D0: nop

    after_1:
    // 0x802AA4D4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA4D8: beq         $v0, $zero, L_802AA4F4
    if (ctx->r2 == 0) {
        // 0x802AA4DC: addiu       $v1, $v1, 0x5530
        ctx->r3 = ADD32(ctx->r3, 0X5530);
            goto L_802AA4F4;
    }
    // 0x802AA4DC: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AA4E0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AA4E4: beql        $v0, $at, L_802AA508
    if (ctx->r2 == ctx->r1) {
        // 0x802AA4E8: lw          $t6, 0x0($v1)
        ctx->r14 = MEM_W(ctx->r3, 0X0);
            goto L_802AA508;
    }
    goto skip_0;
    // 0x802AA4E8: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    skip_0:
    // 0x802AA4EC: b           L_802AA510
    // 0x802AA4F0: nop

        goto L_802AA510;
    // 0x802AA4F0: nop

L_802AA4F4:
    // 0x802AA4F4: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802AA4F8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802AA4FC: b           L_802AA510
    // 0x802AA500: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
        goto L_802AA510;
    // 0x802AA500: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
    // 0x802AA504: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
L_802AA508:
    // 0x802AA508: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x802AA50C: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
L_802AA510:
    // 0x802AA510: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA514: b           L_802AA5A0
    // 0x802AA518: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
        goto L_802AA5A0;
    // 0x802AA518: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
L_802AA51C:
    // 0x802AA51C: jal         0x8030AAE0
    // 0x802AA520: nop

    func_8030AAE0_71C190(rdram, ctx);
        goto after_2;
    // 0x802AA520: nop

    after_2:
    // 0x802AA524: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA528: beq         $v0, $zero, L_802AA544
    if (ctx->r2 == 0) {
        // 0x802AA52C: addiu       $v1, $v1, 0x5530
        ctx->r3 = ADD32(ctx->r3, 0X5530);
            goto L_802AA544;
    }
    // 0x802AA52C: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AA530: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AA534: beql        $v0, $at, L_802AA558
    if (ctx->r2 == ctx->r1) {
        // 0x802AA538: lw          $t0, 0x0($v1)
        ctx->r8 = MEM_W(ctx->r3, 0X0);
            goto L_802AA558;
    }
    goto skip_1;
    // 0x802AA538: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    skip_1:
    // 0x802AA53C: b           L_802AA560
    // 0x802AA540: nop

        goto L_802AA560;
    // 0x802AA540: nop

L_802AA544:
    // 0x802AA544: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802AA548: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x802AA54C: b           L_802AA560
    // 0x802AA550: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
        goto L_802AA560;
    // 0x802AA550: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
    // 0x802AA554: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
L_802AA558:
    // 0x802AA558: addiu       $t9, $zero, 0x5
    ctx->r25 = ADD32(0, 0X5);
    // 0x802AA55C: sb          $t9, 0x162($t0)
    MEM_B(0X162, ctx->r8) = ctx->r25;
L_802AA560:
    // 0x802AA560: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA564: b           L_802AA5A0
    // 0x802AA568: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
        goto L_802AA5A0;
    // 0x802AA568: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
L_802AA56C:
    // 0x802AA56C: jal         0x8030AAE0
    // 0x802AA570: nop

    func_8030AAE0_71C190(rdram, ctx);
        goto after_3;
    // 0x802AA570: nop

    after_3:
    // 0x802AA574: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA578: beq         $v0, $zero, L_802AA598
    if (ctx->r2 == 0) {
        // 0x802AA57C: addiu       $v1, $v1, 0x5530
        ctx->r3 = ADD32(ctx->r3, 0X5530);
            goto L_802AA598;
    }
    // 0x802AA57C: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AA580: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AA584: bne         $v0, $at, L_802AA598
    if (ctx->r2 != ctx->r1) {
        // 0x802AA588: nop
    
            goto L_802AA598;
    }
    // 0x802AA588: nop

    // 0x802AA58C: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA590: addiu       $t1, $zero, 0x7
    ctx->r9 = ADD32(0, 0X7);
    // 0x802AA594: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
L_802AA598:
    // 0x802AA598: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AA59C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
L_802AA5A0:
    // 0x802AA5A0: lw          $t3, 0xC($a0)
    ctx->r11 = MEM_W(ctx->r4, 0XC);
    // 0x802AA5A4: lw          $t4, 0x1C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X1C);
    // 0x802AA5A8: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x802AA5AC: sw          $t5, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r13;
    // 0x802AA5B0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AA5B4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802AA5B8: jr          $ra
    // 0x802AA5BC: nop

    return;
    // 0x802AA5BC: nop

;}
RECOMP_FUNC void func_802AA5C0_6BBC70(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA5C0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AA5C4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AA5C8: jal         0x8012826C
    // 0x802AA5CC: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x802AA5CC: nop

    after_0:
    // 0x802AA5D0: sra         $t7, $v0, 8
    ctx->r15 = S32(SIGNED(ctx->r2) >> 8);
    // 0x802AA5D4: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x802AA5D8: sltiu       $at, $t8, 0xC
    ctx->r1 = ctx->r24 < 0XC ? 1 : 0;
    // 0x802AA5DC: beq         $at, $zero, L_802AA84C
    if (ctx->r1 == 0) {
        // 0x802AA5E0: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802AA84C;
    }
    // 0x802AA5E0: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802AA5E4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AA5E8: addu        $at, $at, $t8
    gpr jr_addend_802AA5F0 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802AA5EC: lw          $t8, -0x4A9C($at)
    ctx->r24 = ADD32(ctx->r1, -0X4A9C);
    // 0x802AA5F0: jr          $t8
    // 0x802AA5F4: nop

    switch (jr_addend_802AA5F0 >> 2) {
        case 0: goto L_802AA5F8; break;
        case 1: goto L_802AA630; break;
        case 2: goto L_802AA668; break;
        case 3: goto L_802AA6A0; break;
        case 4: goto L_802AA6D8; break;
        case 5: goto L_802AA710; break;
        case 6: goto L_802AA748; break;
        case 7: goto L_802AA780; break;
        case 8: goto L_802AA7B8; break;
        case 9: goto L_802AA7B8; break;
        case 10: goto L_802AA810; break;
        case 11: goto L_802AA810; break;
        default: switch_error(__func__, 0x802AA5F0, 0x803BB564);
    }
    // 0x802AA5F4: nop

L_802AA5F8:
    // 0x802AA5F8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA5FC: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA600: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA604: lhu         $t9, 0x380($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA608: bnel        $t9, $zero, L_802AA850
    if (ctx->r25 != 0) {
        // 0x802AA60C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_0;
    // 0x802AA60C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AA610: lhu         $t0, 0x394($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA614: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802AA618: bnel        $t0, $zero, L_802AA850
    if (ctx->r8 != 0) {
        // 0x802AA61C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_1;
    // 0x802AA61C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802AA620: sh          $t1, 0x380($v0)
    MEM_H(0X380, ctx->r2) = ctx->r9;
    // 0x802AA624: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA628: b           L_802AA84C
    // 0x802AA62C: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
        goto L_802AA84C;
    // 0x802AA62C: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
L_802AA630:
    // 0x802AA630: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA634: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA638: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA63C: lhu         $t3, 0x394($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA640: bnel        $t3, $zero, L_802AA850
    if (ctx->r11 != 0) {
        // 0x802AA644: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_2;
    // 0x802AA644: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AA648: lhu         $t4, 0x380($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA64C: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802AA650: bnel        $t4, $zero, L_802AA850
    if (ctx->r12 != 0) {
        // 0x802AA654: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_3;
    // 0x802AA654: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x802AA658: sh          $t5, 0x394($v0)
    MEM_H(0X394, ctx->r2) = ctx->r13;
    // 0x802AA65C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802AA660: b           L_802AA84C
    // 0x802AA664: sh          $zero, 0x396($t6)
    MEM_H(0X396, ctx->r14) = 0;
        goto L_802AA84C;
    // 0x802AA664: sh          $zero, 0x396($t6)
    MEM_H(0X396, ctx->r14) = 0;
L_802AA668:
    // 0x802AA668: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA66C: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA670: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA674: lhu         $t7, 0x3A8($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AA678: bnel        $t7, $zero, L_802AA850
    if (ctx->r15 != 0) {
        // 0x802AA67C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_4;
    // 0x802AA67C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802AA680: lhu         $t8, 0x3BC($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA684: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802AA688: bnel        $t8, $zero, L_802AA850
    if (ctx->r24 != 0) {
        // 0x802AA68C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_5;
    // 0x802AA68C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AA690: sh          $t9, 0x3A8($v0)
    MEM_H(0X3A8, ctx->r2) = ctx->r25;
    // 0x802AA694: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802AA698: b           L_802AA84C
    // 0x802AA69C: sh          $zero, 0x3AA($t0)
    MEM_H(0X3AA, ctx->r8) = 0;
        goto L_802AA84C;
    // 0x802AA69C: sh          $zero, 0x3AA($t0)
    MEM_H(0X3AA, ctx->r8) = 0;
L_802AA6A0:
    // 0x802AA6A0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA6A4: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA6A8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA6AC: lhu         $t1, 0x3BC($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA6B0: bnel        $t1, $zero, L_802AA850
    if (ctx->r9 != 0) {
        // 0x802AA6B4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_6;
    // 0x802AA6B4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x802AA6B8: lhu         $t2, 0x3A8($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AA6BC: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802AA6C0: bnel        $t2, $zero, L_802AA850
    if (ctx->r10 != 0) {
        // 0x802AA6C4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_7;
    // 0x802AA6C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x802AA6C8: sh          $t3, 0x3BC($v0)
    MEM_H(0X3BC, ctx->r2) = ctx->r11;
    // 0x802AA6CC: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802AA6D0: b           L_802AA84C
    // 0x802AA6D4: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
        goto L_802AA84C;
    // 0x802AA6D4: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
L_802AA6D8:
    // 0x802AA6D8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA6DC: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA6E0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA6E4: lhu         $t5, 0x380($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA6E8: bnel        $t5, $zero, L_802AA850
    if (ctx->r13 != 0) {
        // 0x802AA6EC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_8;
    // 0x802AA6EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x802AA6F0: lhu         $t6, 0x394($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA6F4: addiu       $t7, $zero, 0xB
    ctx->r15 = ADD32(0, 0XB);
    // 0x802AA6F8: bnel        $t6, $zero, L_802AA850
    if (ctx->r14 != 0) {
        // 0x802AA6FC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_9;
    // 0x802AA6FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x802AA700: sh          $t7, 0x380($v0)
    MEM_H(0X380, ctx->r2) = ctx->r15;
    // 0x802AA704: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802AA708: b           L_802AA84C
    // 0x802AA70C: sh          $zero, 0x382($t8)
    MEM_H(0X382, ctx->r24) = 0;
        goto L_802AA84C;
    // 0x802AA70C: sh          $zero, 0x382($t8)
    MEM_H(0X382, ctx->r24) = 0;
L_802AA710:
    // 0x802AA710: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA714: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA718: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA71C: lhu         $t9, 0x394($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA720: bnel        $t9, $zero, L_802AA850
    if (ctx->r25 != 0) {
        // 0x802AA724: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_10;
    // 0x802AA724: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_10:
    // 0x802AA728: lhu         $t0, 0x380($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA72C: addiu       $t1, $zero, 0xB
    ctx->r9 = ADD32(0, 0XB);
    // 0x802AA730: bnel        $t0, $zero, L_802AA850
    if (ctx->r8 != 0) {
        // 0x802AA734: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_11;
    // 0x802AA734: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_11:
    // 0x802AA738: sh          $t1, 0x394($v0)
    MEM_H(0X394, ctx->r2) = ctx->r9;
    // 0x802AA73C: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA740: b           L_802AA84C
    // 0x802AA744: sh          $zero, 0x396($t2)
    MEM_H(0X396, ctx->r10) = 0;
        goto L_802AA84C;
    // 0x802AA744: sh          $zero, 0x396($t2)
    MEM_H(0X396, ctx->r10) = 0;
L_802AA748:
    // 0x802AA748: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA74C: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA750: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA754: lhu         $t3, 0x3A8($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AA758: bnel        $t3, $zero, L_802AA850
    if (ctx->r11 != 0) {
        // 0x802AA75C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_12;
    // 0x802AA75C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_12:
    // 0x802AA760: lhu         $t4, 0x3BC($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA764: addiu       $t5, $zero, 0xB
    ctx->r13 = ADD32(0, 0XB);
    // 0x802AA768: bnel        $t4, $zero, L_802AA850
    if (ctx->r12 != 0) {
        // 0x802AA76C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_13;
    // 0x802AA76C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_13:
    // 0x802AA770: sh          $t5, 0x3A8($v0)
    MEM_H(0X3A8, ctx->r2) = ctx->r13;
    // 0x802AA774: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802AA778: b           L_802AA84C
    // 0x802AA77C: sh          $zero, 0x3AA($t6)
    MEM_H(0X3AA, ctx->r14) = 0;
        goto L_802AA84C;
    // 0x802AA77C: sh          $zero, 0x3AA($t6)
    MEM_H(0X3AA, ctx->r14) = 0;
L_802AA780:
    // 0x802AA780: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA784: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA788: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA78C: lhu         $t7, 0x3BC($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA790: bnel        $t7, $zero, L_802AA850
    if (ctx->r15 != 0) {
        // 0x802AA794: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_14;
    // 0x802AA794: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_14:
    // 0x802AA798: lhu         $t8, 0x3A8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AA79C: addiu       $t9, $zero, 0xB
    ctx->r25 = ADD32(0, 0XB);
    // 0x802AA7A0: bnel        $t8, $zero, L_802AA850
    if (ctx->r24 != 0) {
        // 0x802AA7A4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_15;
    // 0x802AA7A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_15:
    // 0x802AA7A8: sh          $t9, 0x3BC($v0)
    MEM_H(0X3BC, ctx->r2) = ctx->r25;
    // 0x802AA7AC: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802AA7B0: b           L_802AA84C
    // 0x802AA7B4: sh          $zero, 0x3BE($t0)
    MEM_H(0X3BE, ctx->r8) = 0;
        goto L_802AA84C;
    // 0x802AA7B4: sh          $zero, 0x3BE($t0)
    MEM_H(0X3BE, ctx->r8) = 0;
L_802AA7B8:
    // 0x802AA7B8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA7BC: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA7C0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA7C4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AA7C8: lhu         $t1, 0x3C0($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X3C0);
    // 0x802AA7CC: bnel        $t1, $zero, L_802AA850
    if (ctx->r9 != 0) {
        // 0x802AA7D0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_16;
    // 0x802AA7D0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_16:
    // 0x802AA7D4: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AA7D8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802AA7DC: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AA7E0: lhu         $t3, 0x9C($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X9C);
    // 0x802AA7E4: beql        $t3, $at, L_802AA850
    if (ctx->r11 == ctx->r1) {
        // 0x802AA7E8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_17;
    // 0x802AA7E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_17:
    // 0x802AA7EC: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802AA7F0: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802AA7F4: lh          $t5, 0x318($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X318);
    // 0x802AA7F8: bnel        $t5, $zero, L_802AA850
    if (ctx->r13 != 0) {
        // 0x802AA7FC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_18;
    // 0x802AA7FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_18:
    // 0x802AA800: sh          $t6, 0x3C0($v0)
    MEM_H(0X3C0, ctx->r2) = ctx->r14;
    // 0x802AA804: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802AA808: b           L_802AA84C
    // 0x802AA80C: sh          $zero, 0x3C2($t7)
    MEM_H(0X3C2, ctx->r15) = 0;
        goto L_802AA84C;
    // 0x802AA80C: sh          $zero, 0x3C2($t7)
    MEM_H(0X3C2, ctx->r15) = 0;
L_802AA810:
    // 0x802AA810: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA814: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA818: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA81C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AA820: lhu         $t8, 0x3C0($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X3C0);
    // 0x802AA824: bnel        $t8, $zero, L_802AA850
    if (ctx->r24 != 0) {
        // 0x802AA828: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_19;
    // 0x802AA828: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_19:
    // 0x802AA82C: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802AA830: addiu       $t1, $zero, 0x5
    ctx->r9 = ADD32(0, 0X5);
    // 0x802AA834: lh          $t0, 0x318($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X318);
    // 0x802AA838: bnel        $t0, $zero, L_802AA850
    if (ctx->r8 != 0) {
        // 0x802AA83C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AA850;
    }
    goto skip_20;
    // 0x802AA83C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_20:
    // 0x802AA840: sh          $t1, 0x3C0($v0)
    MEM_H(0X3C0, ctx->r2) = ctx->r9;
    // 0x802AA844: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA848: sh          $zero, 0x3C2($t2)
    MEM_H(0X3C2, ctx->r10) = 0;
L_802AA84C:
    // 0x802AA84C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AA850:
    // 0x802AA850: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AA854: jr          $ra
    // 0x802AA858: nop

    return;
    // 0x802AA858: nop

;}
RECOMP_FUNC void func_802AA85C_6BBF0C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AA85C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AA860: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AA864: jal         0x8012826C
    // 0x802AA868: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x802AA868: nop

    after_0:
    // 0x802AA86C: sra         $t7, $v0, 8
    ctx->r15 = S32(SIGNED(ctx->r2) >> 8);
    // 0x802AA870: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x802AA874: sltiu       $at, $t8, 0x10
    ctx->r1 = ctx->r24 < 0X10 ? 1 : 0;
    // 0x802AA878: beq         $at, $zero, L_802AAAA0
    if (ctx->r1 == 0) {
        // 0x802AA87C: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802AAAA0;
    }
    // 0x802AA87C: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802AA880: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AA884: addu        $at, $at, $t8
    gpr jr_addend_802AA88C = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802AA888: lw          $t8, -0x4A6C($at)
    ctx->r24 = ADD32(ctx->r1, -0X4A6C);
    // 0x802AA88C: jr          $t8
    // 0x802AA890: nop

    switch (jr_addend_802AA88C >> 2) {
        case 0: goto L_802AA894; break;
        case 1: goto L_802AA8CC; break;
        case 2: goto L_802AAAA0; break;
        case 3: goto L_802AA904; break;
        case 4: goto L_802AA944; break;
        case 5: goto L_802AA97C; break;
        case 6: goto L_802AA9B4; break;
        case 7: goto L_802AA9EC; break;
        case 8: goto L_802AAA24; break;
        case 9: goto L_802AAA24; break;
        case 10: goto L_802AAA24; break;
        case 11: goto L_802AAA24; break;
        case 12: goto L_802AAA64; break;
        case 13: goto L_802AAA64; break;
        case 14: goto L_802AAA64; break;
        case 15: goto L_802AAA64; break;
        default: switch_error(__func__, 0x802AA88C, 0x803BB594);
    }
    // 0x802AA890: nop

L_802AA894:
    // 0x802AA894: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA898: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA89C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA8A0: lhu         $t9, 0x380($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA8A4: bnel        $t9, $zero, L_802AAAA4
    if (ctx->r25 != 0) {
        // 0x802AA8A8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_0;
    // 0x802AA8A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AA8AC: lhu         $t0, 0x394($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA8B0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802AA8B4: bnel        $t0, $zero, L_802AAAA4
    if (ctx->r8 != 0) {
        // 0x802AA8B8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_1;
    // 0x802AA8B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802AA8BC: sh          $t1, 0x380($v0)
    MEM_H(0X380, ctx->r2) = ctx->r9;
    // 0x802AA8C0: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AA8C4: b           L_802AAAA0
    // 0x802AA8C8: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
        goto L_802AAAA0;
    // 0x802AA8C8: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
L_802AA8CC:
    // 0x802AA8CC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA8D0: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA8D4: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA8D8: lhu         $t3, 0x394($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA8DC: bnel        $t3, $zero, L_802AAAA4
    if (ctx->r11 != 0) {
        // 0x802AA8E0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_2;
    // 0x802AA8E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AA8E4: lhu         $t4, 0x380($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA8E8: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802AA8EC: bnel        $t4, $zero, L_802AAAA4
    if (ctx->r12 != 0) {
        // 0x802AA8F0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_3;
    // 0x802AA8F0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x802AA8F4: sh          $t5, 0x394($v0)
    MEM_H(0X394, ctx->r2) = ctx->r13;
    // 0x802AA8F8: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802AA8FC: b           L_802AAAA0
    // 0x802AA900: sh          $zero, 0x396($t6)
    MEM_H(0X396, ctx->r14) = 0;
        goto L_802AAAA0;
    // 0x802AA900: sh          $zero, 0x396($t6)
    MEM_H(0X396, ctx->r14) = 0;
L_802AA904:
    // 0x802AA904: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA908: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA90C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA910: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AA914: lhu         $t7, 0x3C0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X3C0);
    // 0x802AA918: bnel        $t7, $zero, L_802AAAA4
    if (ctx->r15 != 0) {
        // 0x802AA91C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_4;
    // 0x802AA91C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802AA920: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802AA924: addiu       $t0, $zero, 0x11
    ctx->r8 = ADD32(0, 0X11);
    // 0x802AA928: lh          $t9, 0x318($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X318);
    // 0x802AA92C: bnel        $t9, $zero, L_802AAAA4
    if (ctx->r25 != 0) {
        // 0x802AA930: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_5;
    // 0x802AA930: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AA934: sh          $t0, 0x3C0($v0)
    MEM_H(0X3C0, ctx->r2) = ctx->r8;
    // 0x802AA938: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802AA93C: b           L_802AAAA0
    // 0x802AA940: sh          $zero, 0x3C2($t1)
    MEM_H(0X3C2, ctx->r9) = 0;
        goto L_802AAAA0;
    // 0x802AA940: sh          $zero, 0x3C2($t1)
    MEM_H(0X3C2, ctx->r9) = 0;
L_802AA944:
    // 0x802AA944: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA948: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA94C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA950: lhu         $t2, 0x380($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA954: bnel        $t2, $zero, L_802AAAA4
    if (ctx->r10 != 0) {
        // 0x802AA958: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_6;
    // 0x802AA958: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x802AA95C: lhu         $t3, 0x394($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA960: addiu       $t4, $zero, 0xB
    ctx->r12 = ADD32(0, 0XB);
    // 0x802AA964: bnel        $t3, $zero, L_802AAAA4
    if (ctx->r11 != 0) {
        // 0x802AA968: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_7;
    // 0x802AA968: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x802AA96C: sh          $t4, 0x380($v0)
    MEM_H(0X380, ctx->r2) = ctx->r12;
    // 0x802AA970: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802AA974: b           L_802AAAA0
    // 0x802AA978: sh          $zero, 0x382($t5)
    MEM_H(0X382, ctx->r13) = 0;
        goto L_802AAAA0;
    // 0x802AA978: sh          $zero, 0x382($t5)
    MEM_H(0X382, ctx->r13) = 0;
L_802AA97C:
    // 0x802AA97C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA980: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA984: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA988: lhu         $t6, 0x394($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X394);
    // 0x802AA98C: bnel        $t6, $zero, L_802AAAA4
    if (ctx->r14 != 0) {
        // 0x802AA990: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_8;
    // 0x802AA990: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x802AA994: lhu         $t7, 0x380($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X380);
    // 0x802AA998: addiu       $t8, $zero, 0xB
    ctx->r24 = ADD32(0, 0XB);
    // 0x802AA99C: bnel        $t7, $zero, L_802AAAA4
    if (ctx->r15 != 0) {
        // 0x802AA9A0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_9;
    // 0x802AA9A0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x802AA9A4: sh          $t8, 0x394($v0)
    MEM_H(0X394, ctx->r2) = ctx->r24;
    // 0x802AA9A8: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802AA9AC: b           L_802AAAA0
    // 0x802AA9B0: sh          $zero, 0x396($t9)
    MEM_H(0X396, ctx->r25) = 0;
        goto L_802AAAA0;
    // 0x802AA9B0: sh          $zero, 0x396($t9)
    MEM_H(0X396, ctx->r25) = 0;
L_802AA9B4:
    // 0x802AA9B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA9B8: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA9BC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA9C0: lhu         $t0, 0x3A8($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AA9C4: bnel        $t0, $zero, L_802AAAA4
    if (ctx->r8 != 0) {
        // 0x802AA9C8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_10;
    // 0x802AA9C8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_10:
    // 0x802AA9CC: lhu         $t1, 0x3BC($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA9D0: addiu       $t2, $zero, 0xB
    ctx->r10 = ADD32(0, 0XB);
    // 0x802AA9D4: bnel        $t1, $zero, L_802AAAA4
    if (ctx->r9 != 0) {
        // 0x802AA9D8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_11;
    // 0x802AA9D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_11:
    // 0x802AA9DC: sh          $t2, 0x3A8($v0)
    MEM_H(0X3A8, ctx->r2) = ctx->r10;
    // 0x802AA9E0: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802AA9E4: b           L_802AAAA0
    // 0x802AA9E8: sh          $zero, 0x3AA($t3)
    MEM_H(0X3AA, ctx->r11) = 0;
        goto L_802AAAA0;
    // 0x802AA9E8: sh          $zero, 0x3AA($t3)
    MEM_H(0X3AA, ctx->r11) = 0;
L_802AA9EC:
    // 0x802AA9EC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AA9F0: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AA9F4: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AA9F8: lhu         $t4, 0x3BC($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X3BC);
    // 0x802AA9FC: bnel        $t4, $zero, L_802AAAA4
    if (ctx->r12 != 0) {
        // 0x802AAA00: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_12;
    // 0x802AAA00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_12:
    // 0x802AAA04: lhu         $t5, 0x3A8($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X3A8);
    // 0x802AAA08: addiu       $t6, $zero, 0xB
    ctx->r14 = ADD32(0, 0XB);
    // 0x802AAA0C: bnel        $t5, $zero, L_802AAAA4
    if (ctx->r13 != 0) {
        // 0x802AAA10: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_13;
    // 0x802AAA10: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_13:
    // 0x802AAA14: sh          $t6, 0x3BC($v0)
    MEM_H(0X3BC, ctx->r2) = ctx->r14;
    // 0x802AAA18: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802AAA1C: b           L_802AAAA0
    // 0x802AAA20: sh          $zero, 0x3BE($t7)
    MEM_H(0X3BE, ctx->r15) = 0;
        goto L_802AAAA0;
    // 0x802AAA20: sh          $zero, 0x3BE($t7)
    MEM_H(0X3BE, ctx->r15) = 0;
L_802AAA24:
    // 0x802AAA24: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AAA28: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AAA2C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AAA30: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AAA34: lhu         $t8, 0x3C0($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X3C0);
    // 0x802AAA38: bnel        $t8, $zero, L_802AAAA4
    if (ctx->r24 != 0) {
        // 0x802AAA3C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_14;
    // 0x802AAA3C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_14:
    // 0x802AAA40: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802AAA44: addiu       $t1, $zero, 0x5
    ctx->r9 = ADD32(0, 0X5);
    // 0x802AAA48: lh          $t0, 0x318($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X318);
    // 0x802AAA4C: bnel        $t0, $zero, L_802AAAA4
    if (ctx->r8 != 0) {
        // 0x802AAA50: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_15;
    // 0x802AAA50: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_15:
    // 0x802AAA54: sh          $t1, 0x3C0($v0)
    MEM_H(0X3C0, ctx->r2) = ctx->r9;
    // 0x802AAA58: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802AAA5C: b           L_802AAAA0
    // 0x802AAA60: sh          $zero, 0x3C2($t2)
    MEM_H(0X3C2, ctx->r10) = 0;
        goto L_802AAAA0;
    // 0x802AAA60: sh          $zero, 0x3C2($t2)
    MEM_H(0X3C2, ctx->r10) = 0;
L_802AAA64:
    // 0x802AAA64: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AAA68: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802AAA6C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AAA70: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AAA74: lhu         $t3, 0x3C0($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X3C0);
    // 0x802AAA78: bnel        $t3, $zero, L_802AAAA4
    if (ctx->r11 != 0) {
        // 0x802AAA7C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_16;
    // 0x802AAA7C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_16:
    // 0x802AAA80: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802AAA84: addiu       $t6, $zero, 0x13
    ctx->r14 = ADD32(0, 0X13);
    // 0x802AAA88: lh          $t5, 0x318($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X318);
    // 0x802AAA8C: bnel        $t5, $zero, L_802AAAA4
    if (ctx->r13 != 0) {
        // 0x802AAA90: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AAAA4;
    }
    goto skip_17;
    // 0x802AAA90: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_17:
    // 0x802AAA94: sh          $t6, 0x3C0($v0)
    MEM_H(0X3C0, ctx->r2) = ctx->r14;
    // 0x802AAA98: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802AAA9C: sh          $zero, 0x3C2($t7)
    MEM_H(0X3C2, ctx->r15) = 0;
L_802AAAA0:
    // 0x802AAAA0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AAAA4:
    // 0x802AAAA4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AAAA8: jr          $ra
    // 0x802AAAAC: nop

    return;
    // 0x802AAAAC: nop

;}
RECOMP_FUNC void func_802AAAB0_6BC160(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AAAB0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AAAB4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AAAB8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AAABC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AAAC0: lb          $v1, 0x360($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X360);
    // 0x802AAAC4: beq         $v1, $zero, L_802AAAEC
    if (ctx->r3 == 0) {
        // 0x802AAAC8: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_802AAAEC;
    }
    // 0x802AAAC8: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x802AAACC: sb          $t6, 0x360($v0)
    MEM_B(0X360, ctx->r2) = ctx->r14;
    // 0x802AAAD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AAAD4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AAAD8: lb          $t7, 0x360($v0)
    ctx->r15 = MEM_B(ctx->r2, 0X360);
    // 0x802AAADC: bne         $t7, $zero, L_802AAAEC
    if (ctx->r15 != 0) {
        // 0x802AAAE0: nop
    
            goto L_802AAAEC;
    }
    // 0x802AAAE0: nop

    // 0x802AAAE4: jal         0x802A467C
    // 0x802AAAE8: lb          $a0, 0x361($v0)
    ctx->r4 = MEM_B(ctx->r2, 0X361);
    func_802A467C_6B5D2C(rdram, ctx);
        goto after_0;
    // 0x802AAAE8: lb          $a0, 0x361($v0)
    ctx->r4 = MEM_B(ctx->r2, 0X361);
    after_0:
L_802AAAEC:
    // 0x802AAAEC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AAAF0: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802AAAF4: lhu         $v0, 0x0($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X0);
    // 0x802AAAF8: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x802AAAFC: beql        $at, $zero, L_802AAB20
    if (ctx->r1 == 0) {
        // 0x802AAB00: slti        $at, $v0, 0x19
        ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
            goto L_802AAB20;
    }
    goto skip_0;
    // 0x802AAB00: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
    skip_0:
    // 0x802AAB04: jal         0x802AC980
    // 0x802AAB08: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_1;
    // 0x802AAB08: nop

    after_1:
    // 0x802AAB0C: jal         0x802AD87C
    // 0x802AAB10: nop

    func_802AD87C_6BEF2C(rdram, ctx);
        goto after_2;
    // 0x802AAB10: nop

    after_2:
    // 0x802AAB14: b           L_802AACA0
    // 0x802AAB18: nop

        goto L_802AACA0;
    // 0x802AAB18: nop

    // 0x802AAB1C: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
L_802AAB20:
    // 0x802AAB20: beql        $at, $zero, L_802AAB44
    if (ctx->r1 == 0) {
        // 0x802AAB24: slti        $at, $v0, 0x2B
        ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
            goto L_802AAB44;
    }
    goto skip_1;
    // 0x802AAB24: slti        $at, $v0, 0x2B
    ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
    skip_1:
    // 0x802AAB28: jal         0x802AC980
    // 0x802AAB2C: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_3;
    // 0x802AAB2C: nop

    after_3:
    // 0x802AAB30: jal         0x802AE278
    // 0x802AAB34: nop

    func_802AE278_6BF928(rdram, ctx);
        goto after_4;
    // 0x802AAB34: nop

    after_4:
    // 0x802AAB38: b           L_802AACA0
    // 0x802AAB3C: nop

        goto L_802AACA0;
    // 0x802AAB3C: nop

    // 0x802AAB40: slti        $at, $v0, 0x2B
    ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
L_802AAB44:
    // 0x802AAB44: beql        $at, $zero, L_802AAB68
    if (ctx->r1 == 0) {
        // 0x802AAB48: slti        $at, $v0, 0x40
        ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
            goto L_802AAB68;
    }
    goto skip_2;
    // 0x802AAB48: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    skip_2:
    // 0x802AAB4C: jal         0x802AC980
    // 0x802AAB50: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_5;
    // 0x802AAB50: nop

    after_5:
    // 0x802AAB54: jal         0x802AE9C4
    // 0x802AAB58: nop

    func_802AE9C4_6C0074(rdram, ctx);
        goto after_6;
    // 0x802AAB58: nop

    after_6:
    // 0x802AAB5C: b           L_802AACA0
    // 0x802AAB60: nop

        goto L_802AACA0;
    // 0x802AAB60: nop

    // 0x802AAB64: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
L_802AAB68:
    // 0x802AAB68: beql        $at, $zero, L_802AAB8C
    if (ctx->r1 == 0) {
        // 0x802AAB6C: slti        $at, $v0, 0x52
        ctx->r1 = SIGNED(ctx->r2) < 0X52 ? 1 : 0;
            goto L_802AAB8C;
    }
    goto skip_3;
    // 0x802AAB6C: slti        $at, $v0, 0x52
    ctx->r1 = SIGNED(ctx->r2) < 0X52 ? 1 : 0;
    skip_3:
    // 0x802AAB70: jal         0x802AD63C
    // 0x802AAB74: nop

    func_802AD63C_6BECEC(rdram, ctx);
        goto after_7;
    // 0x802AAB74: nop

    after_7:
    // 0x802AAB78: jal         0x802AEE18
    // 0x802AAB7C: nop

    func_802AEE18_6C04C8(rdram, ctx);
        goto after_8;
    // 0x802AAB7C: nop

    after_8:
    // 0x802AAB80: b           L_802AACA0
    // 0x802AAB84: nop

        goto L_802AACA0;
    // 0x802AAB84: nop

    // 0x802AAB88: slti        $at, $v0, 0x52
    ctx->r1 = SIGNED(ctx->r2) < 0X52 ? 1 : 0;
L_802AAB8C:
    // 0x802AAB8C: beql        $at, $zero, L_802AABB0
    if (ctx->r1 == 0) {
        // 0x802AAB90: slti        $at, $v0, 0x6B
        ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
            goto L_802AABB0;
    }
    goto skip_4;
    // 0x802AAB90: slti        $at, $v0, 0x6B
    ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
    skip_4:
    // 0x802AAB94: jal         0x802AD63C
    // 0x802AAB98: nop

    func_802AD63C_6BECEC(rdram, ctx);
        goto after_9;
    // 0x802AAB98: nop

    after_9:
    // 0x802AAB9C: jal         0x802AE698
    // 0x802AABA0: nop

    func_802AE698_6BFD48(rdram, ctx);
        goto after_10;
    // 0x802AABA0: nop

    after_10:
    // 0x802AABA4: b           L_802AACA0
    // 0x802AABA8: nop

        goto L_802AACA0;
    // 0x802AABA8: nop

    // 0x802AABAC: slti        $at, $v0, 0x6B
    ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
L_802AABB0:
    // 0x802AABB0: beql        $at, $zero, L_802AABD4
    if (ctx->r1 == 0) {
        // 0x802AABB4: slti        $at, $v0, 0x7C
        ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
            goto L_802AABD4;
    }
    goto skip_5;
    // 0x802AABB4: slti        $at, $v0, 0x7C
    ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
    skip_5:
    // 0x802AABB8: jal         0x802AC980
    // 0x802AABBC: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_11;
    // 0x802AABBC: nop

    after_11:
    // 0x802AABC0: jal         0x802AF9FC
    // 0x802AABC4: nop

    func_802AF9FC_6C10AC(rdram, ctx);
        goto after_12;
    // 0x802AABC4: nop

    after_12:
    // 0x802AABC8: b           L_802AACA0
    // 0x802AABCC: nop

        goto L_802AACA0;
    // 0x802AABCC: nop

    // 0x802AABD0: slti        $at, $v0, 0x7C
    ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
L_802AABD4:
    // 0x802AABD4: beql        $at, $zero, L_802AABF8
    if (ctx->r1 == 0) {
        // 0x802AABD8: slti        $at, $v0, 0x91
        ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
            goto L_802AABF8;
    }
    goto skip_6;
    // 0x802AABD8: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
    skip_6:
    // 0x802AABDC: jal         0x802AC980
    // 0x802AABE0: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_13;
    // 0x802AABE0: nop

    after_13:
    // 0x802AABE4: jal         0x802AEBB0
    // 0x802AABE8: nop

    func_802AEBB0_6C0260(rdram, ctx);
        goto after_14;
    // 0x802AABE8: nop

    after_14:
    // 0x802AABEC: b           L_802AACA0
    // 0x802AABF0: nop

        goto L_802AACA0;
    // 0x802AABF0: nop

    // 0x802AABF4: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
L_802AABF8:
    // 0x802AABF8: beql        $at, $zero, L_802AAC1C
    if (ctx->r1 == 0) {
        // 0x802AABFC: slti        $at, $v0, 0xA3
        ctx->r1 = SIGNED(ctx->r2) < 0XA3 ? 1 : 0;
            goto L_802AAC1C;
    }
    goto skip_7;
    // 0x802AABFC: slti        $at, $v0, 0xA3
    ctx->r1 = SIGNED(ctx->r2) < 0XA3 ? 1 : 0;
    skip_7:
    // 0x802AAC00: jal         0x802AC980
    // 0x802AAC04: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_15;
    // 0x802AAC04: nop

    after_15:
    // 0x802AAC08: jal         0x802AF308
    // 0x802AAC0C: nop

    func_802AF308_6C09B8(rdram, ctx);
        goto after_16;
    // 0x802AAC0C: nop

    after_16:
    // 0x802AAC10: b           L_802AACA0
    // 0x802AAC14: nop

        goto L_802AACA0;
    // 0x802AAC14: nop

    // 0x802AAC18: slti        $at, $v0, 0xA3
    ctx->r1 = SIGNED(ctx->r2) < 0XA3 ? 1 : 0;
L_802AAC1C:
    // 0x802AAC1C: beql        $at, $zero, L_802AAC40
    if (ctx->r1 == 0) {
        // 0x802AAC20: slti        $at, $v0, 0xBA
        ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
            goto L_802AAC40;
    }
    goto skip_8;
    // 0x802AAC20: slti        $at, $v0, 0xBA
    ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
    skip_8:
    // 0x802AAC24: jal         0x802AC980
    // 0x802AAC28: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_17;
    // 0x802AAC28: nop

    after_17:
    // 0x802AAC2C: jal         0x802AF7E4
    // 0x802AAC30: nop

    func_802AF7E4_6C0E94(rdram, ctx);
        goto after_18;
    // 0x802AAC30: nop

    after_18:
    // 0x802AAC34: b           L_802AACA0
    // 0x802AAC38: nop

        goto L_802AACA0;
    // 0x802AAC38: nop

    // 0x802AAC3C: slti        $at, $v0, 0xBA
    ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
L_802AAC40:
    // 0x802AAC40: beql        $at, $zero, L_802AAC64
    if (ctx->r1 == 0) {
        // 0x802AAC44: slti        $at, $v0, 0xCD
        ctx->r1 = SIGNED(ctx->r2) < 0XCD ? 1 : 0;
            goto L_802AAC64;
    }
    goto skip_9;
    // 0x802AAC44: slti        $at, $v0, 0xCD
    ctx->r1 = SIGNED(ctx->r2) < 0XCD ? 1 : 0;
    skip_9:
    // 0x802AAC48: jal         0x802AC980
    // 0x802AAC4C: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_19;
    // 0x802AAC4C: nop

    after_19:
    // 0x802AAC50: jal         0x802ADDD0
    // 0x802AAC54: nop

    func_802ADDD0_6BF480(rdram, ctx);
        goto after_20;
    // 0x802AAC54: nop

    after_20:
    // 0x802AAC58: b           L_802AACA0
    // 0x802AAC5C: nop

        goto L_802AACA0;
    // 0x802AAC5C: nop

    // 0x802AAC60: slti        $at, $v0, 0xCD
    ctx->r1 = SIGNED(ctx->r2) < 0XCD ? 1 : 0;
L_802AAC64:
    // 0x802AAC64: beql        $at, $zero, L_802AAC88
    if (ctx->r1 == 0) {
        // 0x802AAC68: slti        $at, $v0, 0xDE
        ctx->r1 = SIGNED(ctx->r2) < 0XDE ? 1 : 0;
            goto L_802AAC88;
    }
    goto skip_10;
    // 0x802AAC68: slti        $at, $v0, 0xDE
    ctx->r1 = SIGNED(ctx->r2) < 0XDE ? 1 : 0;
    skip_10:
    // 0x802AAC6C: jal         0x802AC980
    // 0x802AAC70: nop

    func_802AC980_6BE030(rdram, ctx);
        goto after_21;
    // 0x802AAC70: nop

    after_21:
    // 0x802AAC74: jal         0x802AE488
    // 0x802AAC78: nop

    func_802AE488_6BFB38(rdram, ctx);
        goto after_22;
    // 0x802AAC78: nop

    after_22:
    // 0x802AAC7C: b           L_802AACA0
    // 0x802AAC80: nop

        goto L_802AACA0;
    // 0x802AAC80: nop

    // 0x802AAC84: slti        $at, $v0, 0xDE
    ctx->r1 = SIGNED(ctx->r2) < 0XDE ? 1 : 0;
L_802AAC88:
    // 0x802AAC88: beq         $at, $zero, L_802AACA0
    if (ctx->r1 == 0) {
        // 0x802AAC8C: nop
    
            goto L_802AACA0;
    }
    // 0x802AAC8C: nop

    // 0x802AAC90: jal         0x802AD63C
    // 0x802AAC94: nop

    func_802AD63C_6BECEC(rdram, ctx);
        goto after_23;
    // 0x802AAC94: nop

    after_23:
    // 0x802AAC98: jal         0x802B066C
    // 0x802AAC9C: nop

    func_802B066C_6C1D1C(rdram, ctx);
        goto after_24;
    // 0x802AAC9C: nop

    after_24:
L_802AACA0:
    // 0x802AACA0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AACA4: lh          $t9, 0x5534($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5534);
    // 0x802AACA8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AACAC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AACB0: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x802AACB4: addu        $t1, $a2, $t0
    ctx->r9 = ADD32(ctx->r6, ctx->r8);
    // 0x802AACB8: lw          $t2, 0x3EB4($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X3EB4);
    // 0x802AACBC: addiu       $t4, $a2, 0x7FFF
    ctx->r12 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AACC0: lb          $t3, 0x4A($t2)
    ctx->r11 = MEM_B(ctx->r10, 0X4A);
    // 0x802AACC4: bnel        $t3, $zero, L_802AB8A0
    if (ctx->r11 != 0) {
        // 0x802AACC8: addiu       $t9, $a2, 0x7FFF
        ctx->r25 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AB8A0;
    }
    goto skip_11;
    // 0x802AACC8: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
    skip_11:
    // 0x802AACCC: lhu         $t4, 0x7FB3($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X7FB3);
    // 0x802AACD0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AACD4: beq         $t4, $zero, L_802AAF1C
    if (ctx->r12 == 0) {
        // 0x802AACD8: nop
    
            goto L_802AAF1C;
    }
    // 0x802AACD8: nop

    // 0x802AACDC: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802AACE0: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x802AACE4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AACE8: lh          $v1, 0x2E2($t5)
    ctx->r3 = MEM_H(ctx->r13, 0X2E2);
    // 0x802AACEC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802AACF0: beq         $v1, $zero, L_802AAD00
    if (ctx->r3 == 0) {
        // 0x802AACF4: nop
    
            goto L_802AAD00;
    }
    // 0x802AACF4: nop

    // 0x802AACF8: bne         $v1, $at, L_802AAF1C
    if (ctx->r3 != ctx->r1) {
        // 0x802AACFC: nop
    
            goto L_802AAF1C;
    }
    // 0x802AACFC: nop

L_802AAD00:
    // 0x802AAD00: jal         0x8035E344
    // 0x802AAD04: lw          $a0, 0x5520($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5520);
    func_8035E344_76F9F4(rdram, ctx);
        goto after_25;
    // 0x802AAD04: lw          $a0, 0x5520($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5520);
    after_25:
    // 0x802AAD08: beq         $v0, $zero, L_802AAF1C
    if (ctx->r2 == 0) {
        // 0x802AAD0C: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802AAF1C;
    }
    // 0x802AAD0C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AAD10: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AAD14: lhu         $t7, 0x9C($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X9C);
    // 0x802AAD18: addiu       $t8, $t7, -0x2
    ctx->r24 = ADD32(ctx->r15, -0X2);
    // 0x802AAD1C: sltiu       $at, $t8, 0x42
    ctx->r1 = ctx->r24 < 0X42 ? 1 : 0;
    // 0x802AAD20: beq         $at, $zero, L_802AAF10
    if (ctx->r1 == 0) {
        // 0x802AAD24: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802AAF10;
    }
    // 0x802AAD24: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802AAD28: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AAD2C: addu        $at, $at, $t8
    gpr jr_addend_802AAD34 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802AAD30: lw          $t8, -0x4A2C($at)
    ctx->r24 = ADD32(ctx->r1, -0X4A2C);
    // 0x802AAD34: jr          $t8
    // 0x802AAD38: nop

    switch (jr_addend_802AAD34 >> 2) {
        case 0: goto L_802AAE7C; break;
        case 1: goto L_802AAF10; break;
        case 2: goto L_802AAD78; break;
        case 3: goto L_802AAD3C; break;
        case 4: goto L_802AADA0; break;
        case 5: goto L_802AAD8C; break;
        case 6: goto L_802AAF10; break;
        case 7: goto L_802AAF10; break;
        case 8: goto L_802AAF10; break;
        case 9: goto L_802AAF10; break;
        case 10: goto L_802AAF10; break;
        case 11: goto L_802AAEF4; break;
        case 12: goto L_802AAF10; break;
        case 13: goto L_802AAF10; break;
        case 14: goto L_802AAF10; break;
        case 15: goto L_802AAF10; break;
        case 16: goto L_802AADB4; break;
        case 17: goto L_802AAF10; break;
        case 18: goto L_802AAF10; break;
        case 19: goto L_802AAF10; break;
        case 20: goto L_802AAD50; break;
        case 21: goto L_802AAF10; break;
        case 22: goto L_802AAD64; break;
        case 23: goto L_802AAF10; break;
        case 24: goto L_802AADA0; break;
        case 25: goto L_802AAECC; break;
        case 26: goto L_802AAEA4; break;
        case 27: goto L_802AAF10; break;
        case 28: goto L_802AAF10; break;
        case 29: goto L_802AAF10; break;
        case 30: goto L_802AADC8; break;
        case 31: goto L_802AAEB8; break;
        case 32: goto L_802AAF10; break;
        case 33: goto L_802AAEE0; break;
        case 34: goto L_802AAF10; break;
        case 35: goto L_802AAF10; break;
        case 36: goto L_802AAF10; break;
        case 37: goto L_802AAE40; break;
        case 38: goto L_802AAF10; break;
        case 39: goto L_802AAF10; break;
        case 40: goto L_802AAE2C; break;
        case 41: goto L_802AAF10; break;
        case 42: goto L_802AAE18; break;
        case 43: goto L_802AAF10; break;
        case 44: goto L_802AAF10; break;
        case 45: goto L_802AADDC; break;
        case 46: goto L_802AAF10; break;
        case 47: goto L_802AAF10; break;
        case 48: goto L_802AAF10; break;
        case 49: goto L_802AAF10; break;
        case 50: goto L_802AAF10; break;
        case 51: goto L_802AADF0; break;
        case 52: goto L_802AAF10; break;
        case 53: goto L_802AAF10; break;
        case 54: goto L_802AAE90; break;
        case 55: goto L_802AAF10; break;
        case 56: goto L_802AAE68; break;
        case 57: goto L_802AAE54; break;
        case 58: goto L_802AAF10; break;
        case 59: goto L_802AAF10; break;
        case 60: goto L_802AAF10; break;
        case 61: goto L_802AAF10; break;
        case 62: goto L_802AAE04; break;
        case 63: goto L_802AAF10; break;
        case 64: goto L_802AAF10; break;
        case 65: goto L_802AAF08; break;
        default: switch_error(__func__, 0x802AAD34, 0x803BB5D4);
    }
    // 0x802AAD38: nop

L_802AAD3C:
    // 0x802AAD3C: jal         0x802EE89C
    // 0x802AAD40: nop

    func_802EE89C_6FFF4C(rdram, ctx);
        goto after_26;
    // 0x802AAD40: nop

    after_26:
    // 0x802AAD44: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAD48: b           L_802AAFEC
    // 0x802AAD4C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAD4C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAD50:
    // 0x802AAD50: jal         0x803277B4
    // 0x802AAD54: nop

    func_803277B4_738E64(rdram, ctx);
        goto after_27;
    // 0x802AAD54: nop

    after_27:
    // 0x802AAD58: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAD5C: b           L_802AAFEC
    // 0x802AAD60: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAD60: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAD64:
    // 0x802AAD64: jal         0x803279BC
    // 0x802AAD68: nop

    func_803279BC_73906C(rdram, ctx);
        goto after_28;
    // 0x802AAD68: nop

    after_28:
    // 0x802AAD6C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAD70: b           L_802AAFEC
    // 0x802AAD74: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAD74: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAD78:
    // 0x802AAD78: jal         0x802EEA7C
    // 0x802AAD7C: nop

    func_802EEA7C_70012C(rdram, ctx);
        goto after_29;
    // 0x802AAD7C: nop

    after_29:
    // 0x802AAD80: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAD84: b           L_802AAFEC
    // 0x802AAD88: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAD88: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAD8C:
    // 0x802AAD8C: jal         0x802E84E0
    // 0x802AAD90: nop

    func_802E84E0_6F9B90(rdram, ctx);
        goto after_30;
    // 0x802AAD90: nop

    after_30:
    // 0x802AAD94: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAD98: b           L_802AAFEC
    // 0x802AAD9C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAD9C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AADA0:
    // 0x802AADA0: jal         0x802E864C
    // 0x802AADA4: nop

    func_802E864C_6F9CFC(rdram, ctx);
        goto after_31;
    // 0x802AADA4: nop

    after_31:
    // 0x802AADA8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AADAC: b           L_802AAFEC
    // 0x802AADB0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AADB0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AADB4:
    // 0x802AADB4: jal         0x8031F8BC
    // 0x802AADB8: nop

    func_8031F8BC_730F6C(rdram, ctx);
        goto after_32;
    // 0x802AADB8: nop

    after_32:
    // 0x802AADBC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AADC0: b           L_802AAFEC
    // 0x802AADC4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AADC4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AADC8:
    // 0x802AADC8: jal         0x8035F92C
    // 0x802AADCC: nop

    func_8035F92C_770FDC(rdram, ctx);
        goto after_33;
    // 0x802AADCC: nop

    after_33:
    // 0x802AADD0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AADD4: b           L_802AAFEC
    // 0x802AADD8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AADD8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AADDC:
    // 0x802AADDC: jal         0x8036F404
    // 0x802AADE0: nop

    func_8036F404_780AB4(rdram, ctx);
        goto after_34;
    // 0x802AADE0: nop

    after_34:
    // 0x802AADE4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AADE8: b           L_802AAFEC
    // 0x802AADEC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AADEC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AADF0:
    // 0x802AADF0: jal         0x80379048
    // 0x802AADF4: nop

    func_80379048_78A6F8(rdram, ctx);
        goto after_35;
    // 0x802AADF4: nop

    after_35:
    // 0x802AADF8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AADFC: b           L_802AAFEC
    // 0x802AAE00: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE00: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE04:
    // 0x802AAE04: jal         0x80365954
    // 0x802AAE08: nop

    func_80365954_777004(rdram, ctx);
        goto after_36;
    // 0x802AAE08: nop

    after_36:
    // 0x802AAE0C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE10: b           L_802AAFEC
    // 0x802AAE14: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE14: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE18:
    // 0x802AAE18: jal         0x803766E8
    // 0x802AAE1C: nop

    func_803766E8_787D98(rdram, ctx);
        goto after_37;
    // 0x802AAE1C: nop

    after_37:
    // 0x802AAE20: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE24: b           L_802AAFEC
    // 0x802AAE28: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE28: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE2C:
    // 0x802AAE2C: jal         0x8036BBE8
    // 0x802AAE30: nop

    func_8036BBE8_77D298(rdram, ctx);
        goto after_38;
    // 0x802AAE30: nop

    after_38:
    // 0x802AAE34: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE38: b           L_802AAFEC
    // 0x802AAE3C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE3C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE40:
    // 0x802AAE40: jal         0x80368B78
    // 0x802AAE44: nop

    func_80368B78_77A228(rdram, ctx);
        goto after_39;
    // 0x802AAE44: nop

    after_39:
    // 0x802AAE48: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE4C: b           L_802AAFEC
    // 0x802AAE50: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE50: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE54:
    // 0x802AAE54: jal         0x8035C018
    // 0x802AAE58: nop

    chameleon_attack(rdram, ctx);
        goto after_40;
    // 0x802AAE58: nop

    after_40:
    // 0x802AAE5C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE60: b           L_802AAFEC
    // 0x802AAE64: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE64: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE68:
    // 0x802AAE68: jal         0x8035A170
    // 0x802AAE6C: nop

    func_8035A170_76B820(rdram, ctx);
        goto after_41;
    // 0x802AAE6C: nop

    after_41:
    // 0x802AAE70: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE74: b           L_802AAFEC
    // 0x802AAE78: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE78: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE7C:
    // 0x802AAE7C: jal         0x802F0374
    // 0x802AAE80: nop

    func_802F0374_701A24(rdram, ctx);
        goto after_42;
    // 0x802AAE80: nop

    after_42:
    // 0x802AAE84: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE88: b           L_802AAFEC
    // 0x802AAE8C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAE8C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAE90:
    // 0x802AAE90: jal         0x8037D06C
    // 0x802AAE94: nop

    func_8037D06C_78E71C(rdram, ctx);
        goto after_43;
    // 0x802AAE94: nop

    after_43:
    // 0x802AAE98: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAE9C: b           L_802AAFEC
    // 0x802AAEA0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAEA0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAEA4:
    // 0x802AAEA4: jal         0x80355F64
    // 0x802AAEA8: nop

    func_80355F64_767614(rdram, ctx);
        goto after_44;
    // 0x802AAEA8: nop

    after_44:
    // 0x802AAEAC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAEB0: b           L_802AAFEC
    // 0x802AAEB4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAEB4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAEB8:
    // 0x802AAEB8: jal         0x80362618
    // 0x802AAEBC: nop

    sheep_float(rdram, ctx);
        goto after_45;
    // 0x802AAEBC: nop

    after_45:
    // 0x802AAEC0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAEC4: b           L_802AAFEC
    // 0x802AAEC8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAEC8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAECC:
    // 0x802AAECC: jal         0x80355EDC
    // 0x802AAED0: nop

    func_80355EDC_76758C(rdram, ctx);
        goto after_46;
    // 0x802AAED0: nop

    after_46:
    // 0x802AAED4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAED8: b           L_802AAFEC
    // 0x802AAEDC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAEDC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAEE0:
    // 0x802AAEE0: jal         0x80362A00
    // 0x802AAEE4: nop

    func_80362A00_7740B0(rdram, ctx);
        goto after_47;
    // 0x802AAEE4: nop

    after_47:
    // 0x802AAEE8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAEEC: b           L_802AAFEC
    // 0x802AAEF0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAEF0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAEF4:
    // 0x802AAEF4: jal         0x8035FA84
    // 0x802AAEF8: nop

    func_8035FA84_771134(rdram, ctx);
        goto after_48;
    // 0x802AAEF8: nop

    after_48:
    // 0x802AAEFC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAF00: b           L_802AAFEC
    // 0x802AAF04: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAF04: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAF08:
    // 0x802AAF08: jal         0x8038B330
    // 0x802AAF0C: nop

    func_8038B330_79C9E0(rdram, ctx);
        goto after_49;
    // 0x802AAF0C: nop

    after_49:
L_802AAF10:
    // 0x802AAF10: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAF14: b           L_802AAFEC
    // 0x802AAF18: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAF18: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAF1C:
    // 0x802AAF1C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAF20: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AAF24: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AAF28: lhu         $t9, 0x7FB3($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X7FB3);
    // 0x802AAF2C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AAF30: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AAF34: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AAF38: bne         $t9, $zero, L_802AAF5C
    if (ctx->r25 != 0) {
        // 0x802AAF3C: lh          $v1, 0x2E2($v0)
        ctx->r3 = MEM_H(ctx->r2, 0X2E2);
            goto L_802AAF5C;
    }
    // 0x802AAF3C: lh          $v1, 0x2E2($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E2);
    // 0x802AAF40: addiu       $at, $zero, 0x7FFF
    ctx->r1 = ADD32(0, 0X7FFF);
    // 0x802AAF44: bnel        $v1, $at, L_802AAF60
    if (ctx->r3 != ctx->r1) {
        // 0x802AAF48: addiu       $at, $zero, 0x7FFE
        ctx->r1 = ADD32(0, 0X7FFE);
            goto L_802AAF60;
    }
    goto skip_12;
    // 0x802AAF48: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    skip_12:
    // 0x802AAF4C: sh          $zero, 0x2E2($v0)
    MEM_H(0X2E2, ctx->r2) = 0;
    // 0x802AAF50: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AAF54: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AAF58: lh          $v1, 0x2E2($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E2);
L_802AAF5C:
    // 0x802AAF5C: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
L_802AAF60:
    // 0x802AAF60: bne         $v1, $at, L_802AAF6C
    if (ctx->r3 != ctx->r1) {
        // 0x802AAF64: addiu       $t0, $zero, 0x7FFF
        ctx->r8 = ADD32(0, 0X7FFF);
            goto L_802AAF6C;
    }
    // 0x802AAF64: addiu       $t0, $zero, 0x7FFF
    ctx->r8 = ADD32(0, 0X7FFF);
    // 0x802AAF68: sh          $t0, 0x2E2($v0)
    MEM_H(0X2E2, ctx->r2) = ctx->r8;
L_802AAF6C:
    // 0x802AAF6C: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AAF70: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802AAF74: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
    // 0x802AAF78: beq         $v1, $at, L_802AAFA0
    if (ctx->r3 == ctx->r1) {
        // 0x802AAF7C: addiu       $at, $zero, 0xD
        ctx->r1 = ADD32(0, 0XD);
            goto L_802AAFA0;
    }
    // 0x802AAF7C: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x802AAF80: beq         $v1, $at, L_802AAFC8
    if (ctx->r3 == ctx->r1) {
        // 0x802AAF84: addiu       $at, $zero, 0x21
        ctx->r1 = ADD32(0, 0X21);
            goto L_802AAFC8;
    }
    // 0x802AAF84: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x802AAF88: beq         $v1, $at, L_802AAFDC
    if (ctx->r3 == ctx->r1) {
        // 0x802AAF8C: addiu       $at, $zero, 0x38
        ctx->r1 = ADD32(0, 0X38);
            goto L_802AAFDC;
    }
    // 0x802AAF8C: addiu       $at, $zero, 0x38
    ctx->r1 = ADD32(0, 0X38);
    // 0x802AAF90: beq         $v1, $at, L_802AAFB4
    if (ctx->r3 == ctx->r1) {
        // 0x802AAF94: nop
    
            goto L_802AAFB4;
    }
    // 0x802AAF94: nop

    // 0x802AAF98: b           L_802AAFF0
    // 0x802AAF9C: addiu       $t2, $a2, 0x7FFF
    ctx->r10 = ADD32(ctx->r6, 0X7FFF);
        goto L_802AAFF0;
    // 0x802AAF9C: addiu       $t2, $a2, 0x7FFF
    ctx->r10 = ADD32(ctx->r6, 0X7FFF);
L_802AAFA0:
    // 0x802AAFA0: jal         0x802EE9EC
    // 0x802AAFA4: nop

    func_802EE9EC_70009C(rdram, ctx);
        goto after_50;
    // 0x802AAFA4: nop

    after_50:
    // 0x802AAFA8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAFAC: b           L_802AAFEC
    // 0x802AAFB0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAFB0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAFB4:
    // 0x802AAFB4: jal         0x8037D0EC
    // 0x802AAFB8: nop

    func_8037D0EC_78E79C(rdram, ctx);
        goto after_51;
    // 0x802AAFB8: nop

    after_51:
    // 0x802AAFBC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAFC0: b           L_802AAFEC
    // 0x802AAFC4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAFC4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAFC8:
    // 0x802AAFC8: jal         0x8035FAEC
    // 0x802AAFCC: nop

    func_8035FAEC_77119C(rdram, ctx);
        goto after_52;
    // 0x802AAFCC: nop

    after_52:
    // 0x802AAFD0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAFD4: b           L_802AAFEC
    // 0x802AAFD8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AAFEC;
    // 0x802AAFD8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAFDC:
    // 0x802AAFDC: jal         0x80362964
    // 0x802AAFE0: nop

    func_80362964_774014(rdram, ctx);
        goto after_53;
    // 0x802AAFE0: nop

    after_53:
    // 0x802AAFE4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AAFE8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AAFEC:
    // 0x802AAFEC: addiu       $t2, $a2, 0x7FFF
    ctx->r10 = ADD32(ctx->r6, 0X7FFF);
L_802AAFF0:
    // 0x802AAFF0: lhu         $t2, 0x7FB7($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X7FB7);
    // 0x802AAFF4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AAFF8: beq         $t2, $zero, L_802AB5E0
    if (ctx->r10 == 0) {
        // 0x802AAFFC: nop
    
            goto L_802AB5E0;
    }
    // 0x802AAFFC: nop

    // 0x802AB000: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802AB004: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x802AB008: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AB00C: lh          $v1, 0x2E6($t3)
    ctx->r3 = MEM_H(ctx->r11, 0X2E6);
    // 0x802AB010: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AB014: beq         $v1, $zero, L_802AB024
    if (ctx->r3 == 0) {
        // 0x802AB018: nop
    
            goto L_802AB024;
    }
    // 0x802AB018: nop

    // 0x802AB01C: bne         $v1, $at, L_802AB5E0
    if (ctx->r3 != ctx->r1) {
        // 0x802AB020: nop
    
            goto L_802AB5E0;
    }
    // 0x802AB020: nop

L_802AB024:
    // 0x802AB024: jal         0x8035E344
    // 0x802AB028: lw          $a0, 0x5520($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5520);
    func_8035E344_76F9F4(rdram, ctx);
        goto after_54;
    // 0x802AB028: lw          $a0, 0x5520($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5520);
    after_54:
    // 0x802AB02C: beq         $v0, $zero, L_802AB5E0
    if (ctx->r2 == 0) {
        // 0x802AB030: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_802AB5E0;
    }
    // 0x802AB030: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB034: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB038: lhu         $v0, 0x9C($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X9C);
    // 0x802AB03C: sltiu       $at, $v0, 0x44
    ctx->r1 = ctx->r2 < 0X44 ? 1 : 0;
    // 0x802AB040: beq         $at, $zero, L_802AB5D0
    if (ctx->r1 == 0) {
        // 0x802AB044: sll         $t5, $v0, 2
        ctx->r13 = S32(ctx->r2 << 2);
            goto L_802AB5D0;
    }
    // 0x802AB044: sll         $t5, $v0, 2
    ctx->r13 = S32(ctx->r2 << 2);
    // 0x802AB048: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AB04C: addu        $at, $at, $t5
    gpr jr_addend_802AB054 = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x802AB050: lw          $t5, -0x4924($at)
    ctx->r13 = ADD32(ctx->r1, -0X4924);
    // 0x802AB054: jr          $t5
    // 0x802AB058: nop

    switch (jr_addend_802AB054 >> 2) {
        case 0: goto L_802AB29C; break;
        case 1: goto L_802AB49C; break;
        case 2: goto L_802AB4BC; break;
        case 3: goto L_802AB5D0; break;
        case 4: goto L_802AB11C; break;
        case 5: goto L_802AB05C; break;
        case 6: goto L_802AB15C; break;
        case 7: goto L_802AB13C; break;
        case 8: goto L_802AB57C; break;
        case 9: goto L_802AB5D0; break;
        case 10: goto L_802AB3DC; break;
        case 11: goto L_802AB3FC; break;
        case 12: goto L_802AB5D0; break;
        case 13: goto L_802AB59C; break;
        case 14: goto L_802AB09C; break;
        case 15: goto L_802AB5D0; break;
        case 16: goto L_802AB17C; break;
        case 17: goto L_802AB5D0; break;
        case 18: goto L_802AB19C; break;
        case 19: goto L_802AB27C; break;
        case 20: goto L_802AB5D0; break;
        case 21: goto L_802AB5D0; break;
        case 22: goto L_802AB07C; break;
        case 23: goto L_802AB5D0; break;
        case 24: goto L_802AB5D0; break;
        case 25: goto L_802AB29C; break;
        case 26: goto L_802AB15C; break;
        case 27: goto L_802AB4FC; break;
        case 28: goto L_802AB51C; break;
        case 29: goto L_802AB5D0; break;
        case 30: goto L_802AB0DC; break;
        case 31: goto L_802AB0FC; break;
        case 32: goto L_802AB1BC; break;
        case 33: goto L_802AB55C; break;
        case 34: goto L_802AB53C; break;
        case 35: goto L_802AB55C; break;
        case 36: goto L_802AB53C; break;
        case 37: goto L_802AB2FC; break;
        case 38: goto L_802AB39C; break;
        case 39: goto L_802AB3BC; break;
        case 40: goto L_802AB35C; break;
        case 41: goto L_802AB5D0; break;
        case 42: goto L_802AB37C; break;
        case 43: goto L_802AB5D0; break;
        case 44: goto L_802AB33C; break;
        case 45: goto L_802AB27C; break;
        case 46: goto L_802AB1DC; break;
        case 47: goto L_802AB1FC; break;
        case 48: goto L_802AB5D0; break;
        case 49: goto L_802AB25C; break;
        case 50: goto L_802AB23C; break;
        case 51: goto L_802AB2BC; break;
        case 52: goto L_802AB2DC; break;
        case 53: goto L_802AB21C; break;
        case 54: goto L_802AB41C; break;
        case 55: goto L_802AB5D0; break;
        case 56: goto L_802AB4DC; break;
        case 57: goto L_802AB45C; break;
        case 58: goto L_802AB47C; break;
        case 59: goto L_802AB43C; break;
        case 60: goto L_802AB5D0; break;
        case 61: goto L_802AB5D0; break;
        case 62: goto L_802AB5D0; break;
        case 63: goto L_802AB5D0; break;
        case 64: goto L_802AB31C; break;
        case 65: goto L_802AB5D0; break;
        case 66: goto L_802AB0BC; break;
        case 67: goto L_802AB5BC; break;
        default: switch_error(__func__, 0x802AB054, 0x803BB6DC);
    }
    // 0x802AB058: nop

L_802AB05C:
    // 0x802AB05C: jal         0x802EEA18
    // 0x802AB060: nop

    func_802EEA18_7000C8(rdram, ctx);
        goto after_55;
    // 0x802AB060: nop

    after_55:
    // 0x802AB064: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB068: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB06C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB070: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB074: b           L_802AB840
    // 0x802AB078: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB078: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB07C:
    // 0x802AB07C: jal         0x8032786C
    // 0x802AB080: nop

    bear_attack(rdram, ctx);
        goto after_56;
    // 0x802AB080: nop

    after_56:
    // 0x802AB084: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB088: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB08C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB090: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB094: b           L_802AB840
    // 0x802AB098: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB098: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB09C:
    // 0x802AB09C: jal         0x803144F8
    // 0x802AB0A0: nop

    func_803144F8_725BA8(rdram, ctx);
        goto after_57;
    // 0x802AB0A0: nop

    after_57:
    // 0x802AB0A4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB0A8: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB0AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB0B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB0B4: b           L_802AB840
    // 0x802AB0B8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB0B8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB0BC:
    // 0x802AB0BC: jal         0x80383804
    // 0x802AB0C0: nop

    func_80383804_794EB4(rdram, ctx);
        goto after_58;
    // 0x802AB0C0: nop

    after_58:
    // 0x802AB0C4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB0C8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB0CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB0D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB0D4: b           L_802AB840
    // 0x802AB0D8: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AB840;
    // 0x802AB0D8: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
L_802AB0DC:
    // 0x802AB0DC: jal         0x80382C9C
    // 0x802AB0E0: nop

    func_80382C9C_79434C(rdram, ctx);
        goto after_59;
    // 0x802AB0E0: nop

    after_59:
    // 0x802AB0E4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB0E8: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AB0EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB0F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB0F4: b           L_802AB840
    // 0x802AB0F8: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
        goto L_802AB840;
    // 0x802AB0F8: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
L_802AB0FC:
    // 0x802AB0FC: jal         0x802EEA54
    // 0x802AB100: nop

    func_802EEA54_700104(rdram, ctx);
        goto after_60;
    // 0x802AB100: nop

    after_60:
    // 0x802AB104: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AB108: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AB10C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB110: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB114: b           L_802AB840
    // 0x802AB118: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
        goto L_802AB840;
    // 0x802AB118: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
L_802AB11C:
    // 0x802AB11C: jal         0x802EEC44
    // 0x802AB120: nop

    func_802EEC44_7002F4(rdram, ctx);
        goto after_61;
    // 0x802AB120: nop

    after_61:
    // 0x802AB124: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB128: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB12C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB130: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB134: b           L_802AB840
    // 0x802AB138: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
        goto L_802AB840;
    // 0x802AB138: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
L_802AB13C:
    // 0x802AB13C: jal         0x802E8500
    // 0x802AB140: nop

    func_802E8500_6F9BB0(rdram, ctx);
        goto after_62;
    // 0x802AB140: nop

    after_62:
    // 0x802AB144: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB148: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AB14C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB150: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB154: b           L_802AB840
    // 0x802AB158: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AB840;
    // 0x802AB158: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
L_802AB15C:
    // 0x802AB15C: jal         0x802E86C8
    // 0x802AB160: nop

    func_802E86C8_6F9D78(rdram, ctx);
        goto after_63;
    // 0x802AB160: nop

    after_63:
    // 0x802AB164: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB168: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB16C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB170: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB174: b           L_802AB840
    // 0x802AB178: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB178: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB17C:
    // 0x802AB17C: jal         0x8031F87C
    // 0x802AB180: nop

    func_8031F87C_730F2C(rdram, ctx);
        goto after_64;
    // 0x802AB180: nop

    after_64:
    // 0x802AB184: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB188: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB18C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB190: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB194: b           L_802AB840
    // 0x802AB198: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB198: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB19C:
    // 0x802AB19C: jal         0x8031FA84
    // 0x802AB1A0: nop

    func_8031FA84_731134(rdram, ctx);
        goto after_65;
    // 0x802AB1A0: nop

    after_65:
    // 0x802AB1A4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB1A8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB1AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB1B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB1B4: b           L_802AB840
    // 0x802AB1B8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB1B8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB1BC:
    // 0x802AB1BC: jal         0x8035FA5C
    // 0x802AB1C0: nop

    func_8035FA5C_77110C(rdram, ctx);
        goto after_66;
    // 0x802AB1C0: nop

    after_66:
    // 0x802AB1C4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB1C8: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB1CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB1D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB1D4: b           L_802AB840
    // 0x802AB1D8: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB1D8: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB1DC:
    // 0x802AB1DC: jal         0x8036F3AC
    // 0x802AB1E0: nop

    func_8036F3AC_780A5C(rdram, ctx);
        goto after_67;
    // 0x802AB1E0: nop

    after_67:
    // 0x802AB1E4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB1E8: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB1EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB1F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB1F4: b           L_802AB840
    // 0x802AB1F8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB1F8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB1FC:
    // 0x802AB1FC: jal         0x8036F4CC
    // 0x802AB200: nop

    func_8036F4CC_780B7C(rdram, ctx);
        goto after_68;
    // 0x802AB200: nop

    after_68:
    // 0x802AB204: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB208: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB20C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB210: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB214: b           L_802AB840
    // 0x802AB218: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AB840;
    // 0x802AB218: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
L_802AB21C:
    // 0x802AB21C: jal         0x80379070
    // 0x802AB220: nop

    func_80379070_78A720(rdram, ctx);
        goto after_69;
    // 0x802AB220: nop

    after_69:
    // 0x802AB224: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB228: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AB22C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB230: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB234: b           L_802AB840
    // 0x802AB238: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
        goto L_802AB840;
    // 0x802AB238: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
L_802AB23C:
    // 0x802AB23C: jal         0x80372510
    // 0x802AB240: nop

    func_80372510_783BC0(rdram, ctx);
        goto after_70;
    // 0x802AB240: nop

    after_70:
    // 0x802AB244: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AB248: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AB24C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB250: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB254: b           L_802AB840
    // 0x802AB258: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
        goto L_802AB840;
    // 0x802AB258: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
L_802AB25C:
    // 0x802AB25C: jal         0x803725A4
    // 0x802AB260: nop

    func_803725A4_783C54(rdram, ctx);
        goto after_71;
    // 0x802AB260: nop

    after_71:
    // 0x802AB264: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB268: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB26C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB270: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB274: b           L_802AB840
    // 0x802AB278: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
        goto L_802AB840;
    // 0x802AB278: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
L_802AB27C:
    // 0x802AB27C: jal         0x8036D30C
    // 0x802AB280: nop

    func_8036D30C_77E9BC(rdram, ctx);
        goto after_72;
    // 0x802AB280: nop

    after_72:
    // 0x802AB284: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB288: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AB28C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB290: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB294: b           L_802AB840
    // 0x802AB298: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AB840;
    // 0x802AB298: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
L_802AB29C:
    // 0x802AB29C: jal         0x80381C60
    // 0x802AB2A0: nop

    func_80381C60_793310(rdram, ctx);
        goto after_73;
    // 0x802AB2A0: nop

    after_73:
    // 0x802AB2A4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB2A8: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB2AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB2B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB2B4: b           L_802AB840
    // 0x802AB2B8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB2B8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB2BC:
    // 0x802AB2BC: jal         0x80374470
    // 0x802AB2C0: nop

    func_80374470_785B20(rdram, ctx);
        goto after_74;
    // 0x802AB2C0: nop

    after_74:
    // 0x802AB2C4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB2C8: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB2CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB2D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB2D4: b           L_802AB840
    // 0x802AB2D8: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB2D8: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB2DC:
    // 0x802AB2DC: jal         0x803744C4
    // 0x802AB2E0: nop

    func_803744C4_785B74(rdram, ctx);
        goto after_75;
    // 0x802AB2E0: nop

    after_75:
    // 0x802AB2E4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB2E8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB2EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB2F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB2F4: b           L_802AB840
    // 0x802AB2F8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB2F8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB2FC:
    // 0x802AB2FC: jal         0x80365C28
    // 0x802AB300: nop

    func_80365C28_7772D8(rdram, ctx);
        goto after_76;
    // 0x802AB300: nop

    after_76:
    // 0x802AB304: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB308: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB30C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB310: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB314: b           L_802AB840
    // 0x802AB318: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB318: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB31C:
    // 0x802AB31C: jal         0x80365C7C
    // 0x802AB320: nop

    func_80365C7C_77732C(rdram, ctx);
        goto after_77;
    // 0x802AB320: nop

    after_77:
    // 0x802AB324: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB328: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB32C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB330: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB334: b           L_802AB840
    // 0x802AB338: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB338: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB33C:
    // 0x802AB33C: jal         0x803769E0
    // 0x802AB340: nop

    func_803769E0_788090(rdram, ctx);
        goto after_78;
    // 0x802AB340: nop

    after_78:
    // 0x802AB344: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB348: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB34C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB350: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB354: b           L_802AB840
    // 0x802AB358: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AB840;
    // 0x802AB358: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
L_802AB35C:
    // 0x802AB35C: jal         0x8036BBB8
    // 0x802AB360: nop

    func_8036BBB8_77D268(rdram, ctx);
        goto after_79;
    // 0x802AB360: nop

    after_79:
    // 0x802AB364: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB368: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AB36C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB370: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB374: b           L_802AB840
    // 0x802AB378: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
        goto L_802AB840;
    // 0x802AB378: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
L_802AB37C:
    // 0x802AB37C: jal         0x8036BCF8
    // 0x802AB380: nop

    func_8036BCF8_77D3A8(rdram, ctx);
        goto after_80;
    // 0x802AB380: nop

    after_80:
    // 0x802AB384: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AB388: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AB38C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB390: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB394: b           L_802AB840
    // 0x802AB398: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
        goto L_802AB840;
    // 0x802AB398: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
L_802AB39C:
    // 0x802AB39C: jal         0x80368AC4
    // 0x802AB3A0: nop

    func_80368AC4_77A174(rdram, ctx);
        goto after_81;
    // 0x802AB3A0: nop

    after_81:
    // 0x802AB3A4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB3A8: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB3AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB3B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB3B4: b           L_802AB840
    // 0x802AB3B8: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
        goto L_802AB840;
    // 0x802AB3B8: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
L_802AB3BC:
    // 0x802AB3BC: jal         0x80368BA0
    // 0x802AB3C0: nop

    func_80368BA0_77A250(rdram, ctx);
        goto after_82;
    // 0x802AB3C0: nop

    after_82:
    // 0x802AB3C4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB3C8: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AB3CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB3D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB3D4: b           L_802AB840
    // 0x802AB3D8: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AB840;
    // 0x802AB3D8: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
L_802AB3DC:
    // 0x802AB3DC: jal         0x80302018
    // 0x802AB3E0: nop

    func_80302018_7136C8(rdram, ctx);
        goto after_83;
    // 0x802AB3E0: nop

    after_83:
    // 0x802AB3E4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB3E8: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB3EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB3F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB3F4: b           L_802AB840
    // 0x802AB3F8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB3F8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB3FC:
    // 0x802AB3FC: jal         0x80302080
    // 0x802AB400: nop

    func_80302080_713730(rdram, ctx);
        goto after_84;
    // 0x802AB400: nop

    after_84:
    // 0x802AB404: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB408: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB40C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB410: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB414: b           L_802AB840
    // 0x802AB418: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB418: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB41C:
    // 0x802AB41C: jal         0x8037B590
    // 0x802AB420: nop

    func_8037B590_78CC40(rdram, ctx);
        goto after_85;
    // 0x802AB420: nop

    after_85:
    // 0x802AB424: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB428: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB42C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB430: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB434: b           L_802AB840
    // 0x802AB438: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB438: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB43C:
    // 0x802AB43C: jal         0x8035C08C
    // 0x802AB440: nop

    chameleon_hide(rdram, ctx);
        goto after_86;
    // 0x802AB440: nop

    after_86:
    // 0x802AB444: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB448: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB44C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB450: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB454: b           L_802AB840
    // 0x802AB458: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB458: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB45C:
    // 0x802AB45C: jal         0x8035A130
    // 0x802AB460: nop

    func_8035A130_76B7E0(rdram, ctx);
        goto after_87;
    // 0x802AB460: nop

    after_87:
    // 0x802AB464: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB468: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB46C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB470: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB474: b           L_802AB840
    // 0x802AB478: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB478: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB47C:
    // 0x802AB47C: jal         0x8035A2A8
    // 0x802AB480: nop

    func_8035A2A8_76B958(rdram, ctx);
        goto after_88;
    // 0x802AB480: nop

    after_88:
    // 0x802AB484: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB488: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB48C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB490: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB494: b           L_802AB840
    // 0x802AB498: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AB840;
    // 0x802AB498: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
L_802AB49C:
    // 0x802AB49C: jal         0x802F2A2C
    // 0x802AB4A0: nop

    func_802F2A2C_7040DC(rdram, ctx);
        goto after_89;
    // 0x802AB4A0: nop

    after_89:
    // 0x802AB4A4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB4A8: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AB4AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB4B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB4B4: b           L_802AB840
    // 0x802AB4B8: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
        goto L_802AB840;
    // 0x802AB4B8: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
L_802AB4BC:
    // 0x802AB4BC: jal         0x802F03B8
    // 0x802AB4C0: nop

    func_802F03B8_701A68(rdram, ctx);
        goto after_90;
    // 0x802AB4C0: nop

    after_90:
    // 0x802AB4C4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AB4C8: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AB4CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB4D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB4D4: b           L_802AB840
    // 0x802AB4D8: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
        goto L_802AB840;
    // 0x802AB4D8: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
L_802AB4DC:
    // 0x802AB4DC: jal         0x8037D138
    // 0x802AB4E0: nop

    func_8037D138_78E7E8(rdram, ctx);
        goto after_91;
    // 0x802AB4E0: nop

    after_91:
    // 0x802AB4E4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB4E8: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB4EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB4F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB4F4: b           L_802AB840
    // 0x802AB4F8: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
        goto L_802AB840;
    // 0x802AB4F8: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
L_802AB4FC:
    // 0x802AB4FC: jal         0x80355EFC
    // 0x802AB500: nop

    func_80355EFC_7675AC(rdram, ctx);
        goto after_92;
    // 0x802AB500: nop

    after_92:
    // 0x802AB504: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB508: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AB50C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB510: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB514: b           L_802AB840
    // 0x802AB518: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AB840;
    // 0x802AB518: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
L_802AB51C:
    // 0x802AB51C: jal         0x80355FFC
    // 0x802AB520: nop

    func_80355FFC_7676AC(rdram, ctx);
        goto after_93;
    // 0x802AB520: nop

    after_93:
    // 0x802AB524: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB528: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB52C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB530: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB534: b           L_802AB840
    // 0x802AB538: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB538: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB53C:
    // 0x802AB53C: jal         0x80362A10
    // 0x802AB540: nop

    springy_ram_headbutt(rdram, ctx);
        goto after_94;
    // 0x802AB540: nop

    after_94:
    // 0x802AB544: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB548: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB54C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB550: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB554: b           L_802AB840
    // 0x802AB558: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB558: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB55C:
    // 0x802AB55C: jal         0x803629B0
    // 0x802AB560: nop

    func_803629B0_774060(rdram, ctx);
        goto after_95;
    // 0x802AB560: nop

    after_95:
    // 0x802AB564: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB568: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB56C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB570: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB574: b           L_802AB840
    // 0x802AB578: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB578: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB57C:
    // 0x802AB57C: jal         0x80302D5C
    // 0x802AB580: nop

    func_80302D5C_71440C(rdram, ctx);
        goto after_96;
    // 0x802AB580: nop

    after_96:
    // 0x802AB584: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB588: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB58C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB590: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB594: b           L_802AB840
    // 0x802AB598: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB598: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB59C:
    // 0x802AB59C: jal         0x8035FB10
    // 0x802AB5A0: nop

    func_8035FB10_7711C0(rdram, ctx);
        goto after_97;
    // 0x802AB5A0: nop

    after_97:
    // 0x802AB5A4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB5A8: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB5AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB5B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB5B4: b           L_802AB840
    // 0x802AB5B8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB5B8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB5BC:
    // 0x802AB5BC: jal         0x8038B730
    // 0x802AB5C0: nop

    func_8038B730_79CDE0(rdram, ctx);
        goto after_98;
    // 0x802AB5C0: nop

    after_98:
    // 0x802AB5C4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB5C8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB5CC: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
L_802AB5D0:
    // 0x802AB5D0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB5D4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB5D8: b           L_802AB840
    // 0x802AB5DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802AB840;
    // 0x802AB5DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802AB5E0:
    // 0x802AB5E0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB5E4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB5E8: addiu       $t0, $a2, 0x7FFF
    ctx->r8 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AB5EC: lhu         $t0, 0x7FB7($t0)
    ctx->r8 = MEM_HU(ctx->r8, 0X7FB7);
    // 0x802AB5F0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AB5F4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AB5F8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB5FC: bne         $t0, $zero, L_802AB620
    if (ctx->r8 != 0) {
        // 0x802AB600: lh          $v1, 0x2E6($v0)
        ctx->r3 = MEM_H(ctx->r2, 0X2E6);
            goto L_802AB620;
    }
    // 0x802AB600: lh          $v1, 0x2E6($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E6);
    // 0x802AB604: addiu       $at, $zero, 0x7FFF
    ctx->r1 = ADD32(0, 0X7FFF);
    // 0x802AB608: bnel        $v1, $at, L_802AB624
    if (ctx->r3 != ctx->r1) {
        // 0x802AB60C: addiu       $at, $zero, 0x7FFE
        ctx->r1 = ADD32(0, 0X7FFE);
            goto L_802AB624;
    }
    goto skip_13;
    // 0x802AB60C: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    skip_13:
    // 0x802AB610: sh          $zero, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = 0;
    // 0x802AB614: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AB618: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AB61C: lh          $v1, 0x2E6($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E6);
L_802AB620:
    // 0x802AB620: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
L_802AB624:
    // 0x802AB624: bne         $v1, $at, L_802AB630
    if (ctx->r3 != ctx->r1) {
        // 0x802AB628: addiu       $t1, $zero, 0x7FFF
        ctx->r9 = ADD32(0, 0X7FFF);
            goto L_802AB630;
    }
    // 0x802AB628: addiu       $t1, $zero, 0x7FFF
    ctx->r9 = ADD32(0, 0X7FFF);
    // 0x802AB62C: sh          $t1, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = ctx->r9;
L_802AB630:
    // 0x802AB630: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB634: lhu         $v0, 0x9C($t2)
    ctx->r2 = MEM_HU(ctx->r10, 0X9C);
    // 0x802AB638: addiu       $t3, $v0, -0x6
    ctx->r11 = ADD32(ctx->r2, -0X6);
    // 0x802AB63C: sltiu       $at, $t3, 0x3E
    ctx->r1 = ctx->r11 < 0X3E ? 1 : 0;
    // 0x802AB640: beq         $at, $zero, L_802AB83C
    if (ctx->r1 == 0) {
        // 0x802AB644: sll         $t3, $t3, 2
        ctx->r11 = S32(ctx->r11 << 2);
            goto L_802AB83C;
    }
    // 0x802AB644: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802AB648: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AB64C: addu        $at, $at, $t3
    gpr jr_addend_802AB654 = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802AB650: lw          $t3, -0x4814($at)
    ctx->r11 = ADD32(ctx->r1, -0X4814);
    // 0x802AB654: jr          $t3
    // 0x802AB658: nop

    switch (jr_addend_802AB654 >> 2) {
        case 0: goto L_802AB65C; break;
        case 1: goto L_802AB83C; break;
        case 2: goto L_802AB83C; break;
        case 3: goto L_802AB77C; break;
        case 4: goto L_802AB83C; break;
        case 5: goto L_802AB83C; break;
        case 6: goto L_802AB83C; break;
        case 7: goto L_802AB7BC; break;
        case 8: goto L_802AB83C; break;
        case 9: goto L_802AB69C; break;
        case 10: goto L_802AB83C; break;
        case 11: goto L_802AB73C; break;
        case 12: goto L_802AB83C; break;
        case 13: goto L_802AB83C; break;
        case 14: goto L_802AB67C; break;
        case 15: goto L_802AB83C; break;
        case 16: goto L_802AB83C; break;
        case 17: goto L_802AB71C; break;
        case 18: goto L_802AB83C; break;
        case 19: goto L_802AB83C; break;
        case 20: goto L_802AB65C; break;
        case 21: goto L_802AB83C; break;
        case 22: goto L_802AB83C; break;
        case 23: goto L_802AB6BC; break;
        case 24: goto L_802AB7FC; break;
        case 25: goto L_802AB83C; break;
        case 26: goto L_802AB83C; break;
        case 27: goto L_802AB83C; break;
        case 28: goto L_802AB83C; break;
        case 29: goto L_802AB83C; break;
        case 30: goto L_802AB83C; break;
        case 31: goto L_802AB83C; break;
        case 32: goto L_802AB83C; break;
        case 33: goto L_802AB83C; break;
        case 34: goto L_802AB83C; break;
        case 35: goto L_802AB75C; break;
        case 36: goto L_802AB83C; break;
        case 37: goto L_802AB83C; break;
        case 38: goto L_802AB83C; break;
        case 39: goto L_802AB83C; break;
        case 40: goto L_802AB83C; break;
        case 41: goto L_802AB83C; break;
        case 42: goto L_802AB83C; break;
        case 43: goto L_802AB83C; break;
        case 44: goto L_802AB83C; break;
        case 45: goto L_802AB83C; break;
        case 46: goto L_802AB83C; break;
        case 47: goto L_802AB83C; break;
        case 48: goto L_802AB83C; break;
        case 49: goto L_802AB79C; break;
        case 50: goto L_802AB83C; break;
        case 51: goto L_802AB83C; break;
        case 52: goto L_802AB83C; break;
        case 53: goto L_802AB83C; break;
        case 54: goto L_802AB6FC; break;
        case 55: goto L_802AB83C; break;
        case 56: goto L_802AB83C; break;
        case 57: goto L_802AB83C; break;
        case 58: goto L_802AB7DC; break;
        case 59: goto L_802AB6DC; break;
        case 60: goto L_802AB83C; break;
        case 61: goto L_802AB81C; break;
        default: switch_error(__func__, 0x802AB654, 0x803BB7EC);
    }
    // 0x802AB658: nop

L_802AB65C:
    // 0x802AB65C: jal         0x802E8760
    // 0x802AB660: nop

    func_802E8760_6F9E10(rdram, ctx);
        goto after_99;
    // 0x802AB660: nop

    after_99:
    // 0x802AB664: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB668: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB66C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB670: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB674: b           L_802AB840
    // 0x802AB678: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB678: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB67C:
    // 0x802AB67C: jal         0x8031F89C
    // 0x802AB680: nop

    func_8031F89C_730F4C(rdram, ctx);
        goto after_100;
    // 0x802AB680: nop

    after_100:
    // 0x802AB684: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB688: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB68C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB690: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB694: b           L_802AB840
    // 0x802AB698: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB698: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB69C:
    // 0x802AB69C: jal         0x80314590
    // 0x802AB6A0: nop

    func_80314590_725C40(rdram, ctx);
        goto after_101;
    // 0x802AB6A0: nop

    after_101:
    // 0x802AB6A4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB6A8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB6AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB6B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB6B4: b           L_802AB840
    // 0x802AB6B8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB6B8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB6BC:
    // 0x802AB6BC: jal         0x80356064
    // 0x802AB6C0: nop

    func_80356064_767714(rdram, ctx);
        goto after_102;
    // 0x802AB6C0: nop

    after_102:
    // 0x802AB6C4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB6C8: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB6CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB6D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB6D4: b           L_802AB840
    // 0x802AB6D8: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB6D8: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB6DC:
    // 0x802AB6DC: jal         0x803560CC
    // 0x802AB6E0: nop

    func_803560CC_76777C(rdram, ctx);
        goto after_103;
    // 0x802AB6E0: nop

    after_103:
    // 0x802AB6E4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB6E8: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB6EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB6F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB6F4: b           L_802AB840
    // 0x802AB6F8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB6F8: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB6FC:
    // 0x802AB6FC: jal         0x8035C0CC
    // 0x802AB700: nop

    chameleon_unhide(rdram, ctx);
        goto after_104;
    // 0x802AB700: nop

    after_104:
    // 0x802AB704: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AB708: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AB70C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB710: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB714: b           L_802AB840
    // 0x802AB718: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AB840;
    // 0x802AB718: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
L_802AB71C:
    // 0x802AB71C: jal         0x803278D4
    // 0x802AB720: nop

    crazy_bear_attack(rdram, ctx);
        goto after_105;
    // 0x802AB720: nop

    after_105:
    // 0x802AB724: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB728: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AB72C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB730: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB734: b           L_802AB840
    // 0x802AB738: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
        goto L_802AB840;
    // 0x802AB738: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
L_802AB73C:
    // 0x802AB73C: jal         0x8031FAD8
    // 0x802AB740: nop

    func_8031FAD8_731188(rdram, ctx);
        goto after_106;
    // 0x802AB740: nop

    after_106:
    // 0x802AB744: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AB748: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AB74C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB750: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB754: b           L_802AB840
    // 0x802AB758: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
        goto L_802AB840;
    // 0x802AB758: lhu         $v1, 0x9C($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X9C);
L_802AB75C:
    // 0x802AB75C: jal         0x8036BE70
    // 0x802AB760: nop

    func_8036BE70_77D520(rdram, ctx);
        goto after_107;
    // 0x802AB760: nop

    after_107:
    // 0x802AB764: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB768: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AB76C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB770: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB774: b           L_802AB840
    // 0x802AB778: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
        goto L_802AB840;
    // 0x802AB778: lhu         $v1, 0x9C($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X9C);
L_802AB77C:
    // 0x802AB77C: jal         0x80368B04
    // 0x802AB780: nop

    func_80368B04_77A1B4(rdram, ctx);
        goto after_108;
    // 0x802AB780: nop

    after_108:
    // 0x802AB784: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB788: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AB78C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB790: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB794: b           L_802AB840
    // 0x802AB798: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AB840;
    // 0x802AB798: lhu         $v1, 0x9C($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X9C);
L_802AB79C:
    // 0x802AB79C: jal         0x80374518
    // 0x802AB7A0: nop

    func_80374518_785BC8(rdram, ctx);
        goto after_109;
    // 0x802AB7A0: nop

    after_109:
    // 0x802AB7A4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB7A8: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AB7AC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB7B0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB7B4: b           L_802AB840
    // 0x802AB7B8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
        goto L_802AB840;
    // 0x802AB7B8: lhu         $v1, 0x9C($t4)
    ctx->r3 = MEM_HU(ctx->r12, 0X9C);
L_802AB7BC:
    // 0x802AB7BC: jal         0x8035FC08
    // 0x802AB7C0: nop

    func_8035FC08_7712B8(rdram, ctx);
        goto after_110;
    // 0x802AB7C0: nop

    after_110:
    // 0x802AB7C4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB7C8: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AB7CC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB7D0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB7D4: b           L_802AB840
    // 0x802AB7D8: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AB840;
    // 0x802AB7D8: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
L_802AB7DC:
    // 0x802AB7DC: jal         0x80365D74
    // 0x802AB7E0: nop

    func_80365D74_777424(rdram, ctx);
        goto after_111;
    // 0x802AB7E0: nop

    after_111:
    // 0x802AB7E4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AB7E8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AB7EC: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB7F0: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB7F4: b           L_802AB840
    // 0x802AB7F8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AB840;
    // 0x802AB7F8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
L_802AB7FC:
    // 0x802AB7FC: jal         0x80382CB0
    // 0x802AB800: nop

    func_80382CB0_794360(rdram, ctx);
        goto after_112;
    // 0x802AB800: nop

    after_112:
    // 0x802AB804: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AB808: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AB80C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB810: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB814: b           L_802AB840
    // 0x802AB818: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
        goto L_802AB840;
    // 0x802AB818: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
L_802AB81C:
    // 0x802AB81C: jal         0x8038B774
    // 0x802AB820: nop

    func_8038B774_79CE24(rdram, ctx);
        goto after_113;
    // 0x802AB820: nop

    after_113:
    // 0x802AB824: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AB828: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AB82C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB830: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AB834: b           L_802AB840
    // 0x802AB838: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
        goto L_802AB840;
    // 0x802AB838: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
L_802AB83C:
    // 0x802AB83C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802AB840:
    // 0x802AB840: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802AB844: beq         $v1, $at, L_802AB864
    if (ctx->r3 == ctx->r1) {
        // 0x802AB848: addiu       $at, $zero, 0x1B
        ctx->r1 = ADD32(0, 0X1B);
            goto L_802AB864;
    }
    // 0x802AB848: addiu       $at, $zero, 0x1B
    ctx->r1 = ADD32(0, 0X1B);
    // 0x802AB84C: beq         $v1, $at, L_802AB878
    if (ctx->r3 == ctx->r1) {
        // 0x802AB850: addiu       $at, $zero, 0x36
        ctx->r1 = ADD32(0, 0X36);
            goto L_802AB878;
    }
    // 0x802AB850: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x802AB854: beq         $v1, $at, L_802AB88C
    if (ctx->r3 == ctx->r1) {
        // 0x802AB858: nop
    
            goto L_802AB88C;
    }
    // 0x802AB858: nop

    // 0x802AB85C: b           L_802AB8A0
    // 0x802AB860: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
        goto L_802AB8A0;
    // 0x802AB860: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
L_802AB864:
    // 0x802AB864: jal         0x80327908
    // 0x802AB868: nop

    func_80327908_738FB8(rdram, ctx);
        goto after_114;
    // 0x802AB868: nop

    after_114:
    // 0x802AB86C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB870: b           L_802AB89C
    // 0x802AB874: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AB89C;
    // 0x802AB874: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AB878:
    // 0x802AB878: jal         0x80355918
    // 0x802AB87C: nop

    func_80355918_766FC8(rdram, ctx);
        goto after_115;
    // 0x802AB87C: nop

    after_115:
    // 0x802AB880: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB884: b           L_802AB89C
    // 0x802AB888: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AB89C;
    // 0x802AB888: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AB88C:
    // 0x802AB88C: jal         0x8037B660
    // 0x802AB890: nop

    func_8037B660_78CD10(rdram, ctx);
        goto after_116;
    // 0x802AB890: nop

    after_116:
    // 0x802AB894: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AB898: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AB89C:
    // 0x802AB89C: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
L_802AB8A0:
    // 0x802AB8A0: lh          $t9, 0x7FDB($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X7FDB);
    // 0x802AB8A4: addiu       $t0, $a2, 0x7FFF
    ctx->r8 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AB8A8: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AB8AC: bne         $t9, $zero, L_802AB8D0
    if (ctx->r25 != 0) {
        // 0x802AB8B0: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_802AB8D0;
    }
    // 0x802AB8B0: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AB8B4: lhu         $t0, 0x7FB3($t0)
    ctx->r8 = MEM_HU(ctx->r8, 0X7FB3);
    // 0x802AB8B8: addiu       $t1, $a2, 0x7FFF
    ctx->r9 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AB8BC: bne         $t0, $zero, L_802AB8D0
    if (ctx->r8 != 0) {
        // 0x802AB8C0: nop
    
            goto L_802AB8D0;
    }
    // 0x802AB8C0: nop

    // 0x802AB8C4: lhu         $t1, 0x7FB7($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X7FB7);
    // 0x802AB8C8: beql        $t1, $zero, L_802AB8E0
    if (ctx->r9 == 0) {
        // 0x802AB8CC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AB8E0;
    }
    goto skip_14;
    // 0x802AB8CC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_14:
L_802AB8D0:
    // 0x802AB8D0: lhu         $t2, 0x5544($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X5544);
    // 0x802AB8D4: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802AB8D8: sh          $t2, 0x35E($t3)
    MEM_H(0X35E, ctx->r11) = ctx->r10;
    // 0x802AB8DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AB8E0:
    // 0x802AB8E0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AB8E4: jr          $ra
    // 0x802AB8E8: nop

    return;
    // 0x802AB8E8: nop

;}
RECOMP_FUNC void func_802AB8EC_6BCF9C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AB8EC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AB8F0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AB8F4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x802AB8F8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AB8FC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AB900: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802AB904: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802AB908: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x802AB90C: lb          $v1, 0x360($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X360);
    // 0x802AB910: sll         $t6, $a1, 24
    ctx->r14 = S32(ctx->r5 << 24);
    // 0x802AB914: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802AB918: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802AB91C: sra         $t7, $t6, 24
    ctx->r15 = S32(SIGNED(ctx->r14) >> 24);
    // 0x802AB920: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802AB924: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802AB928: beq         $v1, $zero, L_802AB970
    if (ctx->r3 == 0) {
        // 0x802AB92C: andi        $a3, $a0, 0xFF
        ctx->r7 = ctx->r4 & 0XFF;
            goto L_802AB970;
    }
    // 0x802AB92C: andi        $a3, $a0, 0xFF
    ctx->r7 = ctx->r4 & 0XFF;
    // 0x802AB930: addiu       $t1, $v1, -0x1
    ctx->r9 = ADD32(ctx->r3, -0X1);
    // 0x802AB934: sb          $t1, 0x360($v0)
    MEM_B(0X360, ctx->r2) = ctx->r9;
    // 0x802AB938: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AB93C: lb          $t2, 0x360($v0)
    ctx->r10 = MEM_B(ctx->r2, 0X360);
    // 0x802AB940: bnel        $t2, $zero, L_802AB974
    if (ctx->r10 != 0) {
        // 0x802AB944: lbu         $t3, 0x363($v0)
        ctx->r11 = MEM_BU(ctx->r2, 0X363);
            goto L_802AB974;
    }
    goto skip_0;
    // 0x802AB944: lbu         $t3, 0x363($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X363);
    skip_0:
    // 0x802AB948: lb          $a0, 0x361($v0)
    ctx->r4 = MEM_B(ctx->r2, 0X361);
    // 0x802AB94C: sb          $a3, 0x1B($sp)
    MEM_B(0X1B, ctx->r29) = ctx->r7;
    // 0x802AB950: sh          $t9, 0x22($sp)
    MEM_H(0X22, ctx->r29) = ctx->r25;
    // 0x802AB954: jal         0x802A467C
    // 0x802AB958: sb          $t7, 0x1F($sp)
    MEM_B(0X1F, ctx->r29) = ctx->r15;
    func_802A467C_6B5D2C(rdram, ctx);
        goto after_0;
    // 0x802AB958: sb          $t7, 0x1F($sp)
    MEM_B(0X1F, ctx->r29) = ctx->r15;
    after_0:
    // 0x802AB95C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AB960: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AB964: lb          $a1, 0x1F($sp)
    ctx->r5 = MEM_B(ctx->r29, 0X1F);
    // 0x802AB968: lh          $a2, 0x22($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X22);
    // 0x802AB96C: lbu         $a3, 0x1B($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X1B);
L_802AB970:
    // 0x802AB970: lbu         $t3, 0x363($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X363);
L_802AB974:
    // 0x802AB974: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AB978: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AB97C: beq         $t3, $zero, L_802AB98C
    if (ctx->r11 == 0) {
        // 0x802AB980: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802AB98C;
    }
    // 0x802AB980: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802AB984: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802AB988: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_802AB98C:
    // 0x802AB98C: beq         $a1, $zero, L_802AB9A4
    if (ctx->r5 == 0) {
        // 0x802AB990: sra         $t6, $a0, 16
        ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
            goto L_802AB9A4;
    }
    // 0x802AB990: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802AB994: beq         $a1, $at, L_802AB9A4
    if (ctx->r5 == ctx->r1) {
        // 0x802AB998: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_802AB9A4;
    }
    // 0x802AB998: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AB99C: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x802AB9A0: sh          $t4, 0x35E($v0)
    MEM_H(0X35E, ctx->r2) = ctx->r12;
L_802AB9A4:
    // 0x802AB9A4: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802AB9A8: lhu         $v0, 0x0($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X0);
    // 0x802AB9AC: slti        $at, $v0, 0x7
    ctx->r1 = SIGNED(ctx->r2) < 0X7 ? 1 : 0;
    // 0x802AB9B0: beql        $at, $zero, L_802AB9CC
    if (ctx->r1 == 0) {
        // 0x802AB9B4: slti        $at, $v0, 0x19
        ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
            goto L_802AB9CC;
    }
    goto skip_1;
    // 0x802AB9B4: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
    skip_1:
    // 0x802AB9B8: jal         0x802B0B00
    // 0x802AB9BC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_802B0B00_6C21B0(rdram, ctx);
        goto after_1;
    // 0x802AB9BC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_1:
    // 0x802AB9C0: b           L_802ABB04
    // 0x802AB9C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802AB9C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AB9C8: slti        $at, $v0, 0x19
    ctx->r1 = SIGNED(ctx->r2) < 0X19 ? 1 : 0;
L_802AB9CC:
    // 0x802AB9CC: beq         $at, $zero, L_802AB9E8
    if (ctx->r1 == 0) {
        // 0x802AB9D0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802AB9E8;
    }
    // 0x802AB9D0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802AB9D4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802AB9D8: jal         0x802B0F4C
    // 0x802AB9DC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    func_802B0F4C_6C25FC(rdram, ctx);
        goto after_2;
    // 0x802AB9DC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_2:
    // 0x802AB9E0: b           L_802ABB04
    // 0x802AB9E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802AB9E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AB9E8:
    // 0x802AB9E8: slti        $at, $v0, 0x2B
    ctx->r1 = SIGNED(ctx->r2) < 0X2B ? 1 : 0;
    // 0x802AB9EC: beq         $at, $zero, L_802ABA08
    if (ctx->r1 == 0) {
        // 0x802AB9F0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABA08;
    }
    // 0x802AB9F0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802AB9F4: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802AB9F8: jal         0x802B1210
    // 0x802AB9FC: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    func_802B1210_6C28C0(rdram, ctx);
        goto after_3;
    // 0x802AB9FC: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    after_3:
    // 0x802ABA00: b           L_802ABB04
    // 0x802ABA04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABA04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABA08:
    // 0x802ABA08: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    // 0x802ABA0C: beq         $at, $zero, L_802ABA28
    if (ctx->r1 == 0) {
        // 0x802ABA10: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABA28;
    }
    // 0x802ABA10: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABA14: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABA18: jal         0x802B1374
    // 0x802ABA1C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    func_802B1374_6C2A24(rdram, ctx);
        goto after_4;
    // 0x802ABA1C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    after_4:
    // 0x802ABA20: b           L_802ABB04
    // 0x802ABA24: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABA24: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABA28:
    // 0x802ABA28: slti        $at, $v0, 0x52
    ctx->r1 = SIGNED(ctx->r2) < 0X52 ? 1 : 0;
    // 0x802ABA2C: beq         $at, $zero, L_802ABA48
    if (ctx->r1 == 0) {
        // 0x802ABA30: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABA48;
    }
    // 0x802ABA30: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABA34: sra         $t1, $a0, 16
    ctx->r9 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABA38: jal         0x802B1654
    // 0x802ABA3C: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    func_802B1654_6C2D04(rdram, ctx);
        goto after_5;
    // 0x802ABA3C: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    after_5:
    // 0x802ABA40: b           L_802ABB04
    // 0x802ABA44: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABA44: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABA48:
    // 0x802ABA48: slti        $at, $v0, 0x6B
    ctx->r1 = SIGNED(ctx->r2) < 0X6B ? 1 : 0;
    // 0x802ABA4C: beq         $at, $zero, L_802ABA68
    if (ctx->r1 == 0) {
        // 0x802ABA50: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABA68;
    }
    // 0x802ABA50: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABA54: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABA58: jal         0x802B1E28
    // 0x802ABA5C: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    func_802B1E28_6C34D8(rdram, ctx);
        goto after_6;
    // 0x802ABA5C: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    after_6:
    // 0x802ABA60: b           L_802ABB04
    // 0x802ABA64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABA64: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABA68:
    // 0x802ABA68: slti        $at, $v0, 0x7C
    ctx->r1 = SIGNED(ctx->r2) < 0X7C ? 1 : 0;
    // 0x802ABA6C: beq         $at, $zero, L_802ABA88
    if (ctx->r1 == 0) {
        // 0x802ABA70: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABA88;
    }
    // 0x802ABA70: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABA74: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABA78: jal         0x802B1918
    // 0x802ABA7C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    func_802B1918_6C2FC8(rdram, ctx);
        goto after_7;
    // 0x802ABA7C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    after_7:
    // 0x802ABA80: b           L_802ABB04
    // 0x802ABA84: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABA84: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABA88:
    // 0x802ABA88: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
    // 0x802ABA8C: beq         $at, $zero, L_802ABAA8
    if (ctx->r1 == 0) {
        // 0x802ABA90: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABAA8;
    }
    // 0x802ABA90: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABA94: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABA98: jal         0x802B1B98
    // 0x802ABA9C: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    func_802B1B98_6C3248(rdram, ctx);
        goto after_8;
    // 0x802ABA9C: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    after_8:
    // 0x802ABAA0: b           L_802ABB04
    // 0x802ABAA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABAA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABAA8:
    // 0x802ABAA8: slti        $at, $v0, 0xA3
    ctx->r1 = SIGNED(ctx->r2) < 0XA3 ? 1 : 0;
    // 0x802ABAAC: beq         $at, $zero, L_802ABAC8
    if (ctx->r1 == 0) {
        // 0x802ABAB0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABAC8;
    }
    // 0x802ABAB0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABAB4: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABAB8: jal         0x802B1D00
    // 0x802ABABC: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    func_802B1D00_6C33B0(rdram, ctx);
        goto after_9;
    // 0x802ABABC: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    after_9:
    // 0x802ABAC0: b           L_802ABB04
    // 0x802ABAC4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABAC4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABAC8:
    // 0x802ABAC8: slti        $at, $v0, 0xBA
    ctx->r1 = SIGNED(ctx->r2) < 0XBA ? 1 : 0;
    // 0x802ABACC: beq         $at, $zero, L_802ABAE8
    if (ctx->r1 == 0) {
        // 0x802ABAD0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABAE8;
    }
    // 0x802ABAD0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABAD4: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABAD8: jal         0x802B0D4C
    // 0x802ABADC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_802B0D4C_6C23FC(rdram, ctx);
        goto after_10;
    // 0x802ABADC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_10:
    // 0x802ABAE0: b           L_802ABB04
    // 0x802ABAE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ABB04;
    // 0x802ABAE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABAE8:
    // 0x802ABAE8: slti        $at, $v0, 0xCD
    ctx->r1 = SIGNED(ctx->r2) < 0XCD ? 1 : 0;
    // 0x802ABAEC: beq         $at, $zero, L_802ABB00
    if (ctx->r1 == 0) {
        // 0x802ABAF0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802ABB00;
    }
    // 0x802ABAF0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802ABAF4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802ABAF8: jal         0x802B10B0
    // 0x802ABAFC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    func_802B10B0_6C2760(rdram, ctx);
        goto after_11;
    // 0x802ABAFC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_11:
L_802ABB00:
    // 0x802ABB00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ABB04:
    // 0x802ABB04: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802ABB08: jr          $ra
    // 0x802ABB0C: nop

    return;
    // 0x802ABB0C: nop

;}
RECOMP_FUNC void func_802ABB10_6BD1C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802ABB10: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802ABB14: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802ABB18: addiu       $t4, $t4, 0x5530
    ctx->r12 = ADD32(ctx->r12, 0X5530);
    // 0x802ABB1C: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    // 0x802ABB20: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802ABB24: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802ABB28: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x802ABB2C: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x802ABB30: lbu         $v0, 0x161($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X161);
    // 0x802ABB34: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802ABB38: lw          $t5, 0x1C($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X1C);
    // 0x802ABB3C: bne         $v0, $at, L_802ABD2C
    if (ctx->r2 != ctx->r1) {
        // 0x802ABB40: lw          $ra, 0x20($v1)
        ctx->r31 = MEM_W(ctx->r3, 0X20);
            goto L_802ABD2C;
    }
    // 0x802ABB40: lw          $ra, 0x20($v1)
    ctx->r31 = MEM_W(ctx->r3, 0X20);
    // 0x802ABB44: lw          $a0, 0x68($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X68);
    // 0x802ABB48: beql        $a0, $zero, L_802ABD24
    if (ctx->r4 == 0) {
        // 0x802ABB4C: lw          $a1, 0x20($sp)
        ctx->r5 = MEM_W(ctx->r29, 0X20);
            goto L_802ABD24;
    }
    goto skip_0;
    // 0x802ABB4C: lw          $a1, 0x20($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X20);
    skip_0:
    // 0x802ABB50: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
    // 0x802ABB54: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802ABB58: lbu         $t6, 0x2($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2);
    // 0x802ABB5C: bnel        $t6, $at, L_802ABC98
    if (ctx->r14 != ctx->r1) {
        // 0x802ABB60: lw          $v1, 0x0($t4)
        ctx->r3 = MEM_W(ctx->r12, 0X0);
            goto L_802ABC98;
    }
    goto skip_1;
    // 0x802ABB60: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    skip_1:
    // 0x802ABB64: lw          $t8, 0x16C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X16C);
    // 0x802ABB68: lb          $t7, 0xE6($v0)
    ctx->r15 = MEM_B(ctx->r2, 0XE6);
    // 0x802ABB6C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802ABB70: lb          $t9, 0xE6($t8)
    ctx->r25 = MEM_B(ctx->r24, 0XE6);
    // 0x802ABB74: slt         $at, $t7, $t9
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802ABB78: bnel        $at, $zero, L_802ABC98
    if (ctx->r1 != 0) {
        // 0x802ABB7C: lw          $v1, 0x0($t4)
        ctx->r3 = MEM_W(ctx->r12, 0X0);
            goto L_802ABC98;
    }
    goto skip_2;
    // 0x802ABB7C: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    skip_2:
    // 0x802ABB80: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802ABB84: lh          $t6, 0x302($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X302);
    // 0x802ABB88: sh          $t6, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r14;
    // 0x802ABB8C: lw          $t8, 0x0($t4)
    ctx->r24 = MEM_W(ctx->r12, 0X0);
    // 0x802ABB90: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802ABB94: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802ABB98: lw          $a0, 0x68($t8)
    ctx->r4 = MEM_W(ctx->r24, 0X68);
    // 0x802ABB9C: lh          $t7, 0x302($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X302);
    // 0x802ABBA0: lh          $t9, 0x304($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X304);
    // 0x802ABBA4: subu        $a1, $t7, $t9
    ctx->r5 = SUB32(ctx->r15, ctx->r25);
    // 0x802ABBA8: lh          $t7, 0x302($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X302);
    // 0x802ABBAC: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802ABBB0: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802ABBB4: addu        $t9, $t7, $a1
    ctx->r25 = ADD32(ctx->r15, ctx->r5);
    // 0x802ABBB8: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x802ABBBC: sh          $t6, 0x302($v0)
    MEM_H(0X302, ctx->r2) = ctx->r14;
    // 0x802ABBC0: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    // 0x802ABBC4: lh          $t8, 0x2C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2C);
    // 0x802ABBC8: addu        $t7, $t8, $a1
    ctx->r15 = ADD32(ctx->r24, ctx->r5);
    // 0x802ABBCC: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802ABBD0: beq         $a1, $zero, L_802ABC94
    if (ctx->r5 == 0) {
        // 0x802ABBD4: sh          $t9, 0x2C($v1)
        MEM_H(0X2C, ctx->r3) = ctx->r25;
            goto L_802ABC94;
    }
    // 0x802ABBD4: sh          $t9, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r25;
    // 0x802ABBD8: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    // 0x802ABBDC: andi        $t9, $a1, 0xFF
    ctx->r25 = ctx->r5 & 0XFF;
    // 0x802ABBE0: lw          $a0, 0x68($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X68);
    // 0x802ABBE4: lw          $t6, 0x4($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X4);
    // 0x802ABBE8: lw          $t8, 0x8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X8);
    // 0x802ABBEC: lw          $v0, 0x4($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X4);
    // 0x802ABBF0: lw          $t7, 0x8($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X8);
    // 0x802ABBF4: subu        $t2, $t6, $v0
    ctx->r10 = SUB32(ctx->r14, ctx->r2);
    // 0x802ABBF8: subu        $t3, $t8, $t7
    ctx->r11 = SUB32(ctx->r24, ctx->r15);
    // 0x802ABBFC: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x802ABC00: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x802ABC04: addiu       $t8, $t8, 0x2C78
    ctx->r24 = ADD32(ctx->r24, 0X2C78);
    // 0x802ABC08: addiu       $t7, $a1, 0x40
    ctx->r15 = ADD32(ctx->r5, 0X40);
    // 0x802ABC0C: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802ABC10: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    // 0x802ABC14: lh          $t7, 0x0($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X0);
    // 0x802ABC18: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x802ABC1C: sra         $a3, $t3, 8
    ctx->r7 = S32(SIGNED(ctx->r11) >> 8);
    // 0x802ABC20: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802ABC24: multu       $t9, $a3
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABC28: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x802ABC2C: addiu       $t8, $t8, 0x2C78
    ctx->r24 = ADD32(ctx->r24, 0X2C78);
    // 0x802ABC30: addu        $t1, $t6, $t8
    ctx->r9 = ADD32(ctx->r14, ctx->r24);
    // 0x802ABC34: lh          $t7, 0x0($t1)
    ctx->r15 = MEM_H(ctx->r9, 0X0);
    // 0x802ABC38: sra         $t0, $t2, 8
    ctx->r8 = S32(SIGNED(ctx->r10) >> 8);
    // 0x802ABC3C: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802ABC40: mflo        $t6
    ctx->r14 = lo;
    // 0x802ABC44: addu        $t8, $t6, $v0
    ctx->r24 = ADD32(ctx->r14, ctx->r2);
    // 0x802ABC48: nop

    // 0x802ABC4C: multu       $t0, $t9
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABC50: mflo        $t6
    ctx->r14 = lo;
    // 0x802ABC54: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x802ABC58: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x802ABC5C: lh          $t6, 0x0($t1)
    ctx->r14 = MEM_H(ctx->r9, 0X0);
    // 0x802ABC60: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    // 0x802ABC64: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802ABC68: multu       $a3, $t7
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABC6C: lw          $t9, 0x68($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X68);
    // 0x802ABC70: lh          $t7, 0x0($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X0);
    // 0x802ABC74: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802ABC78: mflo        $t9
    ctx->r25 = lo;
    // 0x802ABC7C: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x802ABC80: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802ABC84: multu       $t8, $t0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABC88: mflo        $t9
    ctx->r25 = lo;
    // 0x802ABC8C: subu        $t7, $t6, $t9
    ctx->r15 = SUB32(ctx->r14, ctx->r25);
    // 0x802ABC90: sw          $t7, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r15;
L_802ABC94:
    // 0x802ABC94: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
L_802ABC98:
    // 0x802ABC98: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802ABC9C: lw          $t9, 0x34($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X34);
    // 0x802ABCA0: lw          $a0, 0x68($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X68);
    // 0x802ABCA4: lbu         $v0, 0x161($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X161);
    // 0x802ABCA8: lw          $t8, 0x16C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X16C);
    // 0x802ABCAC: lhu         $t6, 0x0($t8)
    ctx->r14 = MEM_HU(ctx->r24, 0X0);
    // 0x802ABCB0: bnel        $t6, $at, L_802ABCF4
    if (ctx->r14 != ctx->r1) {
        // 0x802ABCB4: lw          $t6, 0x34($sp)
        ctx->r14 = MEM_W(ctx->r29, 0X34);
            goto L_802ABCF4;
    }
    goto skip_3;
    // 0x802ABCB4: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    skip_3:
    // 0x802ABCB8: lw          $t8, 0x1C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X1C);
    // 0x802ABCBC: lw          $t7, 0x0($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X0);
    // 0x802ABCC0: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802ABCC4: lw          $t8, 0x38($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X38);
    // 0x802ABCC8: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x802ABCCC: lw          $t6, 0x20($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X20);
    // 0x802ABCD0: lw          $t7, 0x0($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X0);
    // 0x802ABCD4: subu        $a3, $t9, $t5
    ctx->r7 = SUB32(ctx->r25, ctx->r13);
    // 0x802ABCD8: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x802ABCDC: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x802ABCE0: subu        $a1, $t8, $ra
    ctx->r5 = SUB32(ctx->r24, ctx->r31);
    // 0x802ABCE4: sw          $a1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r5;
    // 0x802ABCE8: b           L_802ABD20
    // 0x802ABCEC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
        goto L_802ABD20;
    // 0x802ABCEC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x802ABCF0: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
L_802ABCF4:
    // 0x802ABCF4: lw          $t9, 0x1C($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X1C);
    // 0x802ABCF8: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x802ABCFC: lw          $t6, 0x38($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X38);
    // 0x802ABD00: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x802ABD04: lw          $t9, 0x20($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X20);
    // 0x802ABD08: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x802ABD0C: subu        $a3, $t8, $t5
    ctx->r7 = SUB32(ctx->r24, ctx->r13);
    // 0x802ABD10: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x802ABD14: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x802ABD18: subu        $a1, $t8, $ra
    ctx->r5 = SUB32(ctx->r24, ctx->r31);
    // 0x802ABD1C: sw          $a1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r5;
L_802ABD20:
    // 0x802ABD20: lw          $a1, 0x20($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X20);
L_802ABD24:
    // 0x802ABD24: b           L_802ABD44
    // 0x802ABD28: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
        goto L_802ABD44;
    // 0x802ABD28: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
L_802ABD2C:
    // 0x802ABD2C: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x802ABD30: lw          $t9, 0x38($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X38);
    // 0x802ABD34: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x802ABD38: lw          $t8, 0x0($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X0);
    // 0x802ABD3C: subu        $a3, $t7, $t5
    ctx->r7 = SUB32(ctx->r15, ctx->r13);
    // 0x802ABD40: subu        $a1, $t8, $ra
    ctx->r5 = SUB32(ctx->r24, ctx->r31);
L_802ABD44:
    // 0x802ABD44: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802ABD48: bne         $v0, $at, L_802ABD64
    if (ctx->r2 != ctx->r1) {
        // 0x802ABD4C: or          $a0, $a3, $zero
        ctx->r4 = ctx->r7 | 0;
            goto L_802ABD64;
    }
    // 0x802ABD4C: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x802ABD50: lhu         $a2, 0x32($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X32);
    // 0x802ABD54: sll         $t6, $a2, 4
    ctx->r14 = S32(ctx->r6 << 4);
    // 0x802ABD58: subu        $t6, $t6, $a2
    ctx->r14 = SUB32(ctx->r14, ctx->r6);
    // 0x802ABD5C: b           L_802ABE2C
    // 0x802ABD60: sll         $a2, $t6, 2
    ctx->r6 = S32(ctx->r14 << 2);
        goto L_802ABE2C;
    // 0x802ABD60: sll         $a2, $t6, 2
    ctx->r6 = S32(ctx->r14 << 2);
L_802ABD64:
    // 0x802ABD64: lbu         $t7, 0x160($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X160);
    // 0x802ABD68: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802ABD6C: bnel        $t7, $at, L_802ABDD4
    if (ctx->r15 != ctx->r1) {
        // 0x802ABD70: lh          $t9, 0x4($v1)
        ctx->r25 = MEM_H(ctx->r3, 0X4);
            goto L_802ABDD4;
    }
    goto skip_4;
    // 0x802ABD70: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    skip_4:
    // 0x802ABD74: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x802ABD78: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x802ABD7C: sra         $t8, $t9, 6
    ctx->r24 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802ABD80: sll         $t6, $t8, 7
    ctx->r14 = S32(ctx->r24 << 7);
    // 0x802ABD84: addu        $t6, $t6, $t8
    ctx->r14 = ADD32(ctx->r14, ctx->r24);
    // 0x802ABD88: sra         $t9, $t7, 6
    ctx->r25 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802ABD8C: sll         $t8, $t9, 3
    ctx->r24 = S32(ctx->r25 << 3);
    // 0x802ABD90: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802ABD94: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x802ABD98: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x802ABD9C: addu        $t9, $t9, $t7
    ctx->r25 = ADD32(ctx->r25, ctx->r15);
    // 0x802ABDA0: lbu         $t9, 0x743($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X743);
    // 0x802ABDA4: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x802ABDA8: lhu         $t7, 0x32($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X32);
    // 0x802ABDAC: sll         $t6, $t9, 2
    ctx->r14 = S32(ctx->r25 << 2);
    // 0x802ABDB0: subu        $t6, $t6, $t9
    ctx->r14 = SUB32(ctx->r14, ctx->r25);
    // 0x802ABDB4: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802ABDB8: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x802ABDBC: lbu         $t8, 0x1D30($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X1D30);
    // 0x802ABDC0: multu       $t8, $t7
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABDC4: mflo        $a2
    ctx->r6 = lo;
    // 0x802ABDC8: b           L_802ABE2C
    // 0x802ABDCC: nop

        goto L_802ABE2C;
    // 0x802ABDCC: nop

    // 0x802ABDD0: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
L_802ABDD4:
    // 0x802ABDD4: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x802ABDD8: sra         $t6, $t9, 6
    ctx->r14 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802ABDDC: sll         $t8, $t6, 7
    ctx->r24 = S32(ctx->r14 << 7);
    // 0x802ABDE0: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x802ABDE4: sra         $t9, $t7, 6
    ctx->r25 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802ABDE8: sll         $t6, $t9, 3
    ctx->r14 = S32(ctx->r25 << 3);
    // 0x802ABDEC: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802ABDF0: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x802ABDF4: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x802ABDF8: addu        $t9, $t9, $t7
    ctx->r25 = ADD32(ctx->r25, ctx->r15);
    // 0x802ABDFC: lbu         $t9, 0x742($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X742);
    // 0x802ABE00: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x802ABE04: lhu         $t7, 0x32($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X32);
    // 0x802ABE08: sll         $t8, $t9, 2
    ctx->r24 = S32(ctx->r25 << 2);
    // 0x802ABE0C: subu        $t8, $t8, $t9
    ctx->r24 = SUB32(ctx->r24, ctx->r25);
    // 0x802ABE10: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802ABE14: addu        $t6, $t6, $t8
    ctx->r14 = ADD32(ctx->r14, ctx->r24);
    // 0x802ABE18: lbu         $t6, 0x1D30($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X1D30);
    // 0x802ABE1C: multu       $t6, $t7
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABE20: mflo        $a2
    ctx->r6 = lo;
    // 0x802ABE24: nop

    // 0x802ABE28: nop

L_802ABE2C:
    // 0x802ABE2C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802ABE30: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802ABE34: addiu       $at, $zero, 0x27
    ctx->r1 = ADD32(0, 0X27);
    // 0x802ABE38: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
    // 0x802ABE3C: beq         $v0, $at, L_802ABE4C
    if (ctx->r2 == ctx->r1) {
        // 0x802ABE40: addiu       $at, $zero, 0x1B
        ctx->r1 = ADD32(0, 0X1B);
            goto L_802ABE4C;
    }
    // 0x802ABE40: addiu       $at, $zero, 0x1B
    ctx->r1 = ADD32(0, 0X1B);
    // 0x802ABE44: bnel        $v0, $at, L_802ABE6C
    if (ctx->r2 != ctx->r1) {
        // 0x802ABE48: sw          $ra, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r31;
            goto L_802ABE6C;
    }
    goto skip_5;
    // 0x802ABE48: sw          $ra, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r31;
    skip_5:
L_802ABE4C:
    // 0x802ABE4C: bne         $a2, $zero, L_802ABE5C
    if (ctx->r6 != 0) {
        // 0x802ABE50: slti        $at, $a2, 0x1C3
        ctx->r1 = SIGNED(ctx->r6) < 0X1C3 ? 1 : 0;
            goto L_802ABE5C;
    }
    // 0x802ABE50: slti        $at, $a2, 0x1C3
    ctx->r1 = SIGNED(ctx->r6) < 0X1C3 ? 1 : 0;
    // 0x802ABE54: b           L_802ABE68
    // 0x802ABE58: addiu       $a2, $zero, 0x5A
    ctx->r6 = ADD32(0, 0X5A);
        goto L_802ABE68;
    // 0x802ABE58: addiu       $a2, $zero, 0x5A
    ctx->r6 = ADD32(0, 0X5A);
L_802ABE5C:
    // 0x802ABE5C: beql        $at, $zero, L_802ABE6C
    if (ctx->r1 == 0) {
        // 0x802ABE60: sw          $ra, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r31;
            goto L_802ABE6C;
    }
    goto skip_6;
    // 0x802ABE60: sw          $ra, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r31;
    skip_6:
    // 0x802ABE64: addiu       $a2, $zero, 0x1C2
    ctx->r6 = ADD32(0, 0X1C2);
L_802ABE68:
    // 0x802ABE68: sw          $ra, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r31;
L_802ABE6C:
    // 0x802ABE6C: sw          $a1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r5;
    // 0x802ABE70: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    // 0x802ABE74: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x802ABE78: jal         0x802AC928
    // 0x802ABE7C: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    func_802AC928_6BDFD8(rdram, ctx);
        goto after_0;
    // 0x802ABE7C: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    after_0:
    // 0x802ABE80: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x802ABE84: sra         $v1, $v0, 8
    ctx->r3 = S32(SIGNED(ctx->r2) >> 8);
    // 0x802ABE88: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x802ABE8C: lw          $a1, 0x20($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X20);
    // 0x802ABE90: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x802ABE94: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    // 0x802ABE98: lw          $t5, 0x2C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X2C);
    // 0x802ABE9C: bne         $v1, $zero, L_802ABEC0
    if (ctx->r3 != 0) {
        // 0x802ABEA0: lw          $ra, 0x28($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X28);
            goto L_802ABEC0;
    }
    // 0x802ABEA0: lw          $ra, 0x28($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X28);
    // 0x802ABEA4: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x802ABEA8: addu        $t8, $t5, $a3
    ctx->r24 = ADD32(ctx->r13, ctx->r7);
    // 0x802ABEAC: addu        $t7, $ra, $a1
    ctx->r15 = ADD32(ctx->r31, ctx->r5);
    // 0x802ABEB0: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
    // 0x802ABEB4: lw          $t9, 0x38($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X38);
    // 0x802ABEB8: b           L_802AC148
    // 0x802ABEBC: sw          $t7, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r15;
        goto L_802AC148;
    // 0x802ABEBC: sw          $t7, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r15;
L_802ABEC0:
    // 0x802ABEC0: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802ABEC4: beq         $at, $zero, L_802ABEE8
    if (ctx->r1 == 0) {
        // 0x802ABEC8: sll         $t8, $a2, 2
        ctx->r24 = S32(ctx->r6 << 2);
            goto L_802ABEE8;
    }
    // 0x802ABEC8: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x802ABECC: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x802ABED0: addu        $t8, $t5, $a3
    ctx->r24 = ADD32(ctx->r13, ctx->r7);
    // 0x802ABED4: addu        $t7, $ra, $a1
    ctx->r15 = ADD32(ctx->r31, ctx->r5);
    // 0x802ABED8: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
    // 0x802ABEDC: lw          $t9, 0x38($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X38);
    // 0x802ABEE0: b           L_802AC148
    // 0x802ABEE4: sw          $t7, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r15;
        goto L_802AC148;
    // 0x802ABEE4: sw          $t7, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r15;
L_802ABEE8:
    // 0x802ABEE8: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x802ABEEC: slt         $at, $v1, $t8
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802ABEF0: beql        $at, $zero, L_802AC028
    if (ctx->r1 == 0) {
        // 0x802ABEF4: sra         $t9, $a3, 8
        ctx->r25 = S32(SIGNED(ctx->r7) >> 8);
            goto L_802AC028;
    }
    goto skip_7;
    // 0x802ABEF4: sra         $t9, $a3, 8
    ctx->r25 = S32(SIGNED(ctx->r7) >> 8);
    skip_7:
    // 0x802ABEF8: sra         $t6, $a3, 8
    ctx->r14 = S32(SIGNED(ctx->r7) >> 8);
    // 0x802ABEFC: multu       $t6, $a2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABF00: sra         $t9, $a1, 8
    ctx->r25 = S32(SIGNED(ctx->r5) >> 8);
    // 0x802ABF04: mflo        $t7
    ctx->r15 = lo;
    // 0x802ABF08: nop

    // 0x802ABF0C: nop

    // 0x802ABF10: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x802ABF14: mflo        $a3
    ctx->r7 = lo;
    // 0x802ABF18: sll         $t6, $a3, 8
    ctx->r14 = S32(ctx->r7 << 8);
    // 0x802ABF1C: bne         $v1, $zero, L_802ABF28
    if (ctx->r3 != 0) {
        // 0x802ABF20: nop
    
            goto L_802ABF28;
    }
    // 0x802ABF20: nop

    // 0x802ABF24: break       7
    do_break(2150285092);
L_802ABF28:
    // 0x802ABF28: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ABF2C: bne         $v1, $at, L_802ABF40
    if (ctx->r3 != ctx->r1) {
        // 0x802ABF30: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ABF40;
    }
    // 0x802ABF30: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ABF34: bne         $t7, $at, L_802ABF40
    if (ctx->r15 != ctx->r1) {
        // 0x802ABF38: nop
    
            goto L_802ABF40;
    }
    // 0x802ABF38: nop

    // 0x802ABF3C: break       6
    do_break(2150285116);
L_802ABF40:
    // 0x802ABF40: multu       $t9, $a2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABF44: lw          $t9, 0x34($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X34);
    // 0x802ABF48: addu        $t7, $t6, $t5
    ctx->r15 = ADD32(ctx->r14, ctx->r13);
    // 0x802ABF4C: sw          $t7, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r15;
    // 0x802ABF50: lw          $t7, 0x38($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X38);
    // 0x802ABF54: mflo        $t8
    ctx->r24 = lo;
    // 0x802ABF58: nop

    // 0x802ABF5C: nop

    // 0x802ABF60: div         $zero, $t8, $v1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r3)));
    // 0x802ABF64: mflo        $a1
    ctx->r5 = lo;
    // 0x802ABF68: bne         $v1, $zero, L_802ABF74
    if (ctx->r3 != 0) {
        // 0x802ABF6C: nop
    
            goto L_802ABF74;
    }
    // 0x802ABF6C: nop

    // 0x802ABF70: break       7
    do_break(2150285168);
L_802ABF74:
    // 0x802ABF74: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ABF78: bne         $v1, $at, L_802ABF8C
    if (ctx->r3 != ctx->r1) {
        // 0x802ABF7C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ABF8C;
    }
    // 0x802ABF7C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ABF80: bne         $t8, $at, L_802ABF8C
    if (ctx->r24 != ctx->r1) {
        // 0x802ABF84: nop
    
            goto L_802ABF8C;
    }
    // 0x802ABF84: nop

    // 0x802ABF88: break       6
    do_break(2150285192);
L_802ABF8C:
    // 0x802ABF8C: multu       $t5, $a3
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABF90: sll         $t8, $a1, 8
    ctx->r24 = S32(ctx->r5 << 8);
    // 0x802ABF94: addu        $t6, $t8, $ra
    ctx->r14 = ADD32(ctx->r24, ctx->r31);
    // 0x802ABF98: sw          $t6, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r14;
    // 0x802ABF9C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802ABFA0: mflo        $t9
    ctx->r25 = lo;
    // 0x802ABFA4: bgtz        $t9, L_802ABFC0
    if (SIGNED(ctx->r25) > 0) {
        // 0x802ABFA8: nop
    
            goto L_802ABFC0;
    }
    // 0x802ABFA8: nop

    // 0x802ABFAC: multu       $ra, $a1
    result = U64(U32(ctx->r31)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802ABFB0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802ABFB4: mflo        $t8
    ctx->r24 = lo;
    // 0x802ABFB8: blez        $t8, L_802AC014
    if (SIGNED(ctx->r24) <= 0) {
        // 0x802ABFBC: nop
    
            goto L_802AC014;
    }
    // 0x802ABFBC: nop

L_802ABFC0:
    // 0x802ABFC0: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802ABFC4: lh          $v0, 0x302($t6)
    ctx->r2 = MEM_H(ctx->r14, 0X302);
    // 0x802ABFC8: andi        $t7, $v0, 0xFF
    ctx->r15 = ctx->r2 & 0XFF;
    // 0x802ABFCC: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x802ABFD0: addu        $t8, $t0, $t9
    ctx->r24 = ADD32(ctx->r8, ctx->r25);
    // 0x802ABFD4: lh          $t6, 0x0($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X0);
    // 0x802ABFD8: addiu       $t8, $v0, 0x40
    ctx->r24 = ADD32(ctx->r2, 0X40);
    // 0x802ABFDC: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802ABFE0: sll         $t9, $t7, 10
    ctx->r25 = S32(ctx->r15 << 10);
    // 0x802ABFE4: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x802ABFE8: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802ABFEC: subu        $a0, $t5, $t9
    ctx->r4 = SUB32(ctx->r13, ctx->r25);
    // 0x802ABFF0: addu        $t9, $t0, $t7
    ctx->r25 = ADD32(ctx->r8, ctx->r15);
    // 0x802ABFF4: lh          $t8, 0x0($t9)
    ctx->r24 = MEM_H(ctx->r25, 0X0);
    // 0x802ABFF8: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802ABFFC: sll         $t7, $t6, 10
    ctx->r15 = S32(ctx->r14 << 10);
    // 0x802AC000: subu        $a1, $ra, $t7
    ctx->r5 = SUB32(ctx->r31, ctx->r15);
    // 0x802AC004: jal         0x8034AE34
    // 0x802AC008: nop

    kick_up_dust_small(rdram, ctx);
        goto after_1;
    // 0x802AC008: nop

    after_1:
    // 0x802AC00C: b           L_802AC14C
    // 0x802AC010: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC14C;
    // 0x802AC010: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC014:
    // 0x802AC014: jal         0x8034AE34
    // 0x802AC018: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    kick_up_dust_small(rdram, ctx);
        goto after_2;
    // 0x802AC018: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_2:
    // 0x802AC01C: b           L_802AC14C
    // 0x802AC020: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC14C;
    // 0x802AC020: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AC024: sra         $t9, $a3, 8
    ctx->r25 = S32(SIGNED(ctx->r7) >> 8);
L_802AC028:
    // 0x802AC028: multu       $t9, $a2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC02C: sra         $t6, $a1, 8
    ctx->r14 = S32(SIGNED(ctx->r5) >> 8);
    // 0x802AC030: mflo        $t8
    ctx->r24 = lo;
    // 0x802AC034: nop

    // 0x802AC038: nop

    // 0x802AC03C: div         $zero, $t8, $v1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r3)));
    // 0x802AC040: mflo        $a3
    ctx->r7 = lo;
    // 0x802AC044: sll         $t9, $a3, 8
    ctx->r25 = S32(ctx->r7 << 8);
    // 0x802AC048: bne         $v1, $zero, L_802AC054
    if (ctx->r3 != 0) {
        // 0x802AC04C: nop
    
            goto L_802AC054;
    }
    // 0x802AC04C: nop

    // 0x802AC050: break       7
    do_break(2150285392);
L_802AC054:
    // 0x802AC054: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC058: bne         $v1, $at, L_802AC06C
    if (ctx->r3 != ctx->r1) {
        // 0x802AC05C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC06C;
    }
    // 0x802AC05C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC060: bne         $t8, $at, L_802AC06C
    if (ctx->r24 != ctx->r1) {
        // 0x802AC064: nop
    
            goto L_802AC06C;
    }
    // 0x802AC064: nop

    // 0x802AC068: break       6
    do_break(2150285416);
L_802AC06C:
    // 0x802AC06C: multu       $t6, $a2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC070: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x802AC074: addu        $t8, $t9, $t5
    ctx->r24 = ADD32(ctx->r25, ctx->r13);
    // 0x802AC078: sw          $t8, 0x0($t6)
    MEM_W(0X0, ctx->r14) = ctx->r24;
    // 0x802AC07C: lw          $t8, 0x38($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X38);
    // 0x802AC080: mflo        $t7
    ctx->r15 = lo;
    // 0x802AC084: nop

    // 0x802AC088: nop

    // 0x802AC08C: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x802AC090: mflo        $a1
    ctx->r5 = lo;
    // 0x802AC094: bne         $v1, $zero, L_802AC0A0
    if (ctx->r3 != 0) {
        // 0x802AC098: nop
    
            goto L_802AC0A0;
    }
    // 0x802AC098: nop

    // 0x802AC09C: break       7
    do_break(2150285468);
L_802AC0A0:
    // 0x802AC0A0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC0A4: bne         $v1, $at, L_802AC0B8
    if (ctx->r3 != ctx->r1) {
        // 0x802AC0A8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC0B8;
    }
    // 0x802AC0A8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC0AC: bne         $t7, $at, L_802AC0B8
    if (ctx->r15 != ctx->r1) {
        // 0x802AC0B0: nop
    
            goto L_802AC0B8;
    }
    // 0x802AC0B0: nop

    // 0x802AC0B4: break       6
    do_break(2150285492);
L_802AC0B8:
    // 0x802AC0B8: multu       $t5, $a3
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC0BC: sll         $t7, $a1, 8
    ctx->r15 = S32(ctx->r5 << 8);
    // 0x802AC0C0: addu        $t9, $t7, $ra
    ctx->r25 = ADD32(ctx->r15, ctx->r31);
    // 0x802AC0C4: sw          $t9, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r25;
    // 0x802AC0C8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AC0CC: mflo        $t6
    ctx->r14 = lo;
    // 0x802AC0D0: bgtz        $t6, L_802AC0EC
    if (SIGNED(ctx->r14) > 0) {
        // 0x802AC0D4: nop
    
            goto L_802AC0EC;
    }
    // 0x802AC0D4: nop

    // 0x802AC0D8: multu       $ra, $a1
    result = U64(U32(ctx->r31)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC0DC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802AC0E0: mflo        $t7
    ctx->r15 = lo;
    // 0x802AC0E4: blez        $t7, L_802AC140
    if (SIGNED(ctx->r15) <= 0) {
        // 0x802AC0E8: nop
    
            goto L_802AC140;
    }
    // 0x802AC0E8: nop

L_802AC0EC:
    // 0x802AC0EC: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802AC0F0: lh          $v0, 0x302($t9)
    ctx->r2 = MEM_H(ctx->r25, 0X302);
    // 0x802AC0F4: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x802AC0F8: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802AC0FC: addu        $t7, $t0, $t6
    ctx->r15 = ADD32(ctx->r8, ctx->r14);
    // 0x802AC100: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802AC104: addiu       $t7, $v0, 0x40
    ctx->r15 = ADD32(ctx->r2, 0X40);
    // 0x802AC108: sra         $t8, $t9, 7
    ctx->r24 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802AC10C: sll         $t6, $t8, 10
    ctx->r14 = S32(ctx->r24 << 10);
    // 0x802AC110: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802AC114: sll         $t8, $t9, 1
    ctx->r24 = S32(ctx->r25 << 1);
    // 0x802AC118: subu        $a0, $t5, $t6
    ctx->r4 = SUB32(ctx->r13, ctx->r14);
    // 0x802AC11C: addu        $t6, $t0, $t8
    ctx->r14 = ADD32(ctx->r8, ctx->r24);
    // 0x802AC120: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x802AC124: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802AC128: sll         $t8, $t9, 10
    ctx->r24 = S32(ctx->r25 << 10);
    // 0x802AC12C: subu        $a1, $ra, $t8
    ctx->r5 = SUB32(ctx->r31, ctx->r24);
    // 0x802AC130: jal         0x8034AF0C
    // 0x802AC134: nop

    kick_up_dust_big(rdram, ctx);
        goto after_3;
    // 0x802AC134: nop

    after_3:
    // 0x802AC138: b           L_802AC14C
    // 0x802AC13C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC14C;
    // 0x802AC13C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC140:
    // 0x802AC140: jal         0x8034AF0C
    // 0x802AC144: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    kick_up_dust_big(rdram, ctx);
        goto after_4;
    // 0x802AC144: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_4:
L_802AC148:
    // 0x802AC148: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC14C:
    // 0x802AC14C: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802AC150: jr          $ra
    // 0x802AC154: nop

    return;
    // 0x802AC154: nop

;}
RECOMP_FUNC void func_802AC158_6BD808(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC158: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802AC15C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AC160: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802AC164: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802AC168: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x802AC16C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x802AC170: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x802AC174: lbu         $t7, 0x161($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X161);
    // 0x802AC178: andi        $t6, $a0, 0xFFFF
    ctx->r14 = ctx->r4 & 0XFFFF;
    // 0x802AC17C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AC180: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802AC184: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x802AC188: or          $s1, $a2, $zero
    ctx->r17 = ctx->r6 | 0;
    // 0x802AC18C: lw          $t3, 0x1C($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X1C);
    // 0x802AC190: bne         $t7, $at, L_802AC1C8
    if (ctx->r15 != ctx->r1) {
        // 0x802AC194: lw          $t4, 0x20($v1)
        ctx->r12 = MEM_W(ctx->r3, 0X20);
            goto L_802AC1C8;
    }
    // 0x802AC194: lw          $t4, 0x20($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X20);
    // 0x802AC198: lw          $v0, 0x68($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X68);
    // 0x802AC19C: beql        $v0, $zero, L_802AC1CC
    if (ctx->r2 == 0) {
        // 0x802AC1A0: lw          $t9, 0x0($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X0);
            goto L_802AC1CC;
    }
    goto skip_0;
    // 0x802AC1A0: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    skip_0:
    // 0x802AC1A4: lw          $t8, 0x0($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X0);
    // 0x802AC1A8: lw          $t9, 0x1C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X1C);
    // 0x802AC1AC: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x802AC1B0: lw          $t7, 0x20($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X20);
    // 0x802AC1B4: addu        $t5, $t8, $t9
    ctx->r13 = ADD32(ctx->r24, ctx->r25);
    // 0x802AC1B8: subu        $a2, $t5, $t3
    ctx->r6 = SUB32(ctx->r13, ctx->r11);
    // 0x802AC1BC: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802AC1C0: b           L_802AC1D8
    // 0x802AC1C4: subu        $a3, $t8, $t4
    ctx->r7 = SUB32(ctx->r24, ctx->r12);
        goto L_802AC1D8;
    // 0x802AC1C4: subu        $a3, $t8, $t4
    ctx->r7 = SUB32(ctx->r24, ctx->r12);
L_802AC1C8:
    // 0x802AC1C8: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
L_802AC1CC:
    // 0x802AC1CC: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x802AC1D0: subu        $a2, $t9, $t3
    ctx->r6 = SUB32(ctx->r25, ctx->r11);
    // 0x802AC1D4: subu        $a3, $t5, $t4
    ctx->r7 = SUB32(ctx->r13, ctx->r12);
L_802AC1D8:
    // 0x802AC1D8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC1DC: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802AC1E0: lhu         $t7, 0x48($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X48);
    // 0x802AC1E4: sll         $t2, $a0, 2
    ctx->r10 = S32(ctx->r4 << 2);
    // 0x802AC1E8: or          $t0, $t2, $zero
    ctx->r8 = ctx->r10 | 0;
    // 0x802AC1EC: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802AC1F0: slti        $at, $t8, 0x5
    ctx->r1 = SIGNED(ctx->r24) < 0X5 ? 1 : 0;
    // 0x802AC1F4: beq         $at, $zero, L_802AC2BC
    if (ctx->r1 == 0) {
        // 0x802AC1F8: or          $t1, $a0, $zero
        ctx->r9 = ctx->r4 | 0;
            goto L_802AC2BC;
    }
    // 0x802AC1F8: or          $t1, $a0, $zero
    ctx->r9 = ctx->r4 | 0;
    // 0x802AC1FC: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802AC200: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802AC204: sw          $t4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r12;
    // 0x802AC208: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    // 0x802AC20C: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x802AC210: sw          $t1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r9;
    // 0x802AC214: sw          $t2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r10;
    // 0x802AC218: sw          $a3, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r7;
    // 0x802AC21C: jal         0x8031124C
    // 0x802AC220: sw          $a2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r6;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_0;
    // 0x802AC220: sw          $a2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r6;
    after_0:
    // 0x802AC224: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AC228: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802AC22C: sra         $t5, $v0, 16
    ctx->r13 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802AC230: lw          $a2, 0x3C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X3C);
    // 0x802AC234: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x802AC238: lw          $a3, 0x38($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X38);
    // 0x802AC23C: lw          $t0, 0x30($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X30);
    // 0x802AC240: subu        $t6, $t9, $t5
    ctx->r14 = SUB32(ctx->r25, ctx->r13);
    // 0x802AC244: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802AC248: lw          $t1, 0x24($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X24);
    // 0x802AC24C: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
    // 0x802AC250: lw          $t3, 0x44($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X44);
    // 0x802AC254: beq         $at, $zero, L_802AC2BC
    if (ctx->r1 == 0) {
        // 0x802AC258: lw          $t4, 0x40($sp)
        ctx->r12 = MEM_W(ctx->r29, 0X40);
            goto L_802AC2BC;
    }
    // 0x802AC258: lw          $t4, 0x40($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X40);
    // 0x802AC25C: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x802AC260: lh          $t5, 0x8($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X8);
    // 0x802AC264: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802AC268: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x802AC26C: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802AC270: sra         $t6, $t5, 6
    ctx->r14 = S32(SIGNED(ctx->r13) >> 6);
    // 0x802AC274: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802AC278: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802AC27C: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x802AC280: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x802AC284: addu        $t5, $t5, $t8
    ctx->r13 = ADD32(ctx->r13, ctx->r24);
    // 0x802AC288: lbu         $t5, 0x742($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X742);
    // 0x802AC28C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x802AC290: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x802AC294: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x802AC298: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802AC29C: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x802AC2A0: lbu         $t9, 0x1D30($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X1D30);
    // 0x802AC2A4: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC2A8: mflo        $v0
    ctx->r2 = lo;
    // 0x802AC2AC: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802AC2B0: bnel        $at, $zero, L_802AC2C0
    if (ctx->r1 != 0) {
        // 0x802AC2B4: or          $a0, $a2, $zero
        ctx->r4 = ctx->r6 | 0;
            goto L_802AC2C0;
    }
    goto skip_1;
    // 0x802AC2B4: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    skip_1:
    // 0x802AC2B8: or          $t0, $v0, $zero
    ctx->r8 = ctx->r2 | 0;
L_802AC2BC:
    // 0x802AC2BC: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
L_802AC2C0:
    // 0x802AC2C0: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC2C4: sw          $a2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r6;
    // 0x802AC2C8: sw          $a3, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r7;
    // 0x802AC2CC: sw          $t0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r8;
    // 0x802AC2D0: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    // 0x802AC2D4: jal         0x802AC928
    // 0x802AC2D8: sw          $t4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r12;
    func_802AC928_6BDFD8(rdram, ctx);
        goto after_1;
    // 0x802AC2D8: sw          $t4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r12;
    after_1:
    // 0x802AC2DC: sra         $v1, $v0, 8
    ctx->r3 = S32(SIGNED(ctx->r2) >> 8);
    // 0x802AC2E0: lw          $a2, 0x3C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X3C);
    // 0x802AC2E4: lw          $a3, 0x38($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X38);
    // 0x802AC2E8: lw          $t0, 0x30($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X30);
    // 0x802AC2EC: lw          $t3, 0x44($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X44);
    // 0x802AC2F0: bne         $v1, $zero, L_802AC30C
    if (ctx->r3 != 0) {
        // 0x802AC2F4: lw          $t4, 0x40($sp)
        ctx->r12 = MEM_W(ctx->r29, 0X40);
            goto L_802AC30C;
    }
    // 0x802AC2F4: lw          $t4, 0x40($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X40);
    // 0x802AC2F8: addu        $t7, $t3, $a2
    ctx->r15 = ADD32(ctx->r11, ctx->r6);
    // 0x802AC2FC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x802AC300: addu        $t8, $t4, $a3
    ctx->r24 = ADD32(ctx->r12, ctx->r7);
    // 0x802AC304: b           L_802AC470
    // 0x802AC308: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
        goto L_802AC470;
    // 0x802AC308: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
L_802AC30C:
    // 0x802AC30C: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AC310: beq         $at, $zero, L_802AC32C
    if (ctx->r1 == 0) {
        // 0x802AC314: sll         $t9, $t0, 2
        ctx->r25 = S32(ctx->r8 << 2);
            goto L_802AC32C;
    }
    // 0x802AC314: sll         $t9, $t0, 2
    ctx->r25 = S32(ctx->r8 << 2);
    // 0x802AC318: addu        $t5, $t3, $a2
    ctx->r13 = ADD32(ctx->r11, ctx->r6);
    // 0x802AC31C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x802AC320: addu        $t6, $t4, $a3
    ctx->r14 = ADD32(ctx->r12, ctx->r7);
    // 0x802AC324: b           L_802AC470
    // 0x802AC328: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
        goto L_802AC470;
    // 0x802AC328: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
L_802AC32C:
    // 0x802AC32C: addu        $t9, $t9, $t0
    ctx->r25 = ADD32(ctx->r25, ctx->r8);
    // 0x802AC330: slt         $at, $v1, $t9
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802AC334: beql        $at, $zero, L_802AC3DC
    if (ctx->r1 == 0) {
        // 0x802AC338: sra         $t6, $a2, 8
        ctx->r14 = S32(SIGNED(ctx->r6) >> 8);
            goto L_802AC3DC;
    }
    goto skip_2;
    // 0x802AC338: sra         $t6, $a2, 8
    ctx->r14 = S32(SIGNED(ctx->r6) >> 8);
    skip_2:
    // 0x802AC33C: sra         $t7, $a2, 8
    ctx->r15 = S32(SIGNED(ctx->r6) >> 8);
    // 0x802AC340: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC344: sra         $t5, $a3, 8
    ctx->r13 = S32(SIGNED(ctx->r7) >> 8);
    // 0x802AC348: mflo        $t8
    ctx->r24 = lo;
    // 0x802AC34C: nop

    // 0x802AC350: nop

    // 0x802AC354: div         $zero, $t8, $v1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r3)));
    // 0x802AC358: mflo        $a2
    ctx->r6 = lo;
    // 0x802AC35C: sll         $t9, $a2, 8
    ctx->r25 = S32(ctx->r6 << 8);
    // 0x802AC360: bne         $v1, $zero, L_802AC36C
    if (ctx->r3 != 0) {
        // 0x802AC364: nop
    
            goto L_802AC36C;
    }
    // 0x802AC364: nop

    // 0x802AC368: break       7
    do_break(2150286184);
L_802AC36C:
    // 0x802AC36C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC370: bne         $v1, $at, L_802AC384
    if (ctx->r3 != ctx->r1) {
        // 0x802AC374: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC384;
    }
    // 0x802AC374: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC378: bne         $t8, $at, L_802AC384
    if (ctx->r24 != ctx->r1) {
        // 0x802AC37C: nop
    
            goto L_802AC384;
    }
    // 0x802AC37C: nop

    // 0x802AC380: break       6
    do_break(2150286208);
L_802AC384:
    // 0x802AC384: multu       $t5, $t0
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC388: addu        $t7, $t9, $t3
    ctx->r15 = ADD32(ctx->r25, ctx->r11);
    // 0x802AC38C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x802AC390: mflo        $t6
    ctx->r14 = lo;
    // 0x802AC394: nop

    // 0x802AC398: nop

    // 0x802AC39C: div         $zero, $t6, $v1
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r3)));
    // 0x802AC3A0: mflo        $a3
    ctx->r7 = lo;
    // 0x802AC3A4: sll         $t8, $a3, 8
    ctx->r24 = S32(ctx->r7 << 8);
    // 0x802AC3A8: bne         $v1, $zero, L_802AC3B4
    if (ctx->r3 != 0) {
        // 0x802AC3AC: nop
    
            goto L_802AC3B4;
    }
    // 0x802AC3AC: nop

    // 0x802AC3B0: break       7
    do_break(2150286256);
L_802AC3B4:
    // 0x802AC3B4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC3B8: bne         $v1, $at, L_802AC3CC
    if (ctx->r3 != ctx->r1) {
        // 0x802AC3BC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC3CC;
    }
    // 0x802AC3BC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC3C0: bne         $t6, $at, L_802AC3CC
    if (ctx->r14 != ctx->r1) {
        // 0x802AC3C4: nop
    
            goto L_802AC3CC;
    }
    // 0x802AC3C4: nop

    // 0x802AC3C8: break       6
    do_break(2150286280);
L_802AC3CC:
    // 0x802AC3CC: addu        $t5, $t8, $t4
    ctx->r13 = ADD32(ctx->r24, ctx->r12);
    // 0x802AC3D0: b           L_802AC470
    // 0x802AC3D4: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
        goto L_802AC470;
    // 0x802AC3D4: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x802AC3D8: sra         $t6, $a2, 8
    ctx->r14 = S32(SIGNED(ctx->r6) >> 8);
L_802AC3DC:
    // 0x802AC3DC: multu       $t6, $t0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC3E0: sra         $t7, $a3, 8
    ctx->r15 = S32(SIGNED(ctx->r7) >> 8);
    // 0x802AC3E4: mflo        $t9
    ctx->r25 = lo;
    // 0x802AC3E8: nop

    // 0x802AC3EC: nop

    // 0x802AC3F0: div         $zero, $t9, $v1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r3)));
    // 0x802AC3F4: mflo        $a2
    ctx->r6 = lo;
    // 0x802AC3F8: sll         $t5, $a2, 8
    ctx->r13 = S32(ctx->r6 << 8);
    // 0x802AC3FC: bne         $v1, $zero, L_802AC408
    if (ctx->r3 != 0) {
        // 0x802AC400: nop
    
            goto L_802AC408;
    }
    // 0x802AC400: nop

    // 0x802AC404: break       7
    do_break(2150286340);
L_802AC408:
    // 0x802AC408: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC40C: bne         $v1, $at, L_802AC420
    if (ctx->r3 != ctx->r1) {
        // 0x802AC410: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC420;
    }
    // 0x802AC410: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC414: bne         $t9, $at, L_802AC420
    if (ctx->r25 != ctx->r1) {
        // 0x802AC418: nop
    
            goto L_802AC420;
    }
    // 0x802AC418: nop

    // 0x802AC41C: break       6
    do_break(2150286364);
L_802AC420:
    // 0x802AC420: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC424: addu        $t6, $t5, $t3
    ctx->r14 = ADD32(ctx->r13, ctx->r11);
    // 0x802AC428: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x802AC42C: mflo        $t8
    ctx->r24 = lo;
    // 0x802AC430: nop

    // 0x802AC434: nop

    // 0x802AC438: div         $zero, $t8, $v1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r3)));
    // 0x802AC43C: mflo        $a3
    ctx->r7 = lo;
    // 0x802AC440: sll         $t9, $a3, 8
    ctx->r25 = S32(ctx->r7 << 8);
    // 0x802AC444: addu        $t7, $t9, $t4
    ctx->r15 = ADD32(ctx->r25, ctx->r12);
    // 0x802AC448: bne         $v1, $zero, L_802AC454
    if (ctx->r3 != 0) {
        // 0x802AC44C: nop
    
            goto L_802AC454;
    }
    // 0x802AC44C: nop

    // 0x802AC450: break       7
    do_break(2150286416);
L_802AC454:
    // 0x802AC454: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC458: bne         $v1, $at, L_802AC46C
    if (ctx->r3 != ctx->r1) {
        // 0x802AC45C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC46C;
    }
    // 0x802AC45C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC460: bne         $t8, $at, L_802AC46C
    if (ctx->r24 != ctx->r1) {
        // 0x802AC464: nop
    
            goto L_802AC46C;
    }
    // 0x802AC464: nop

    // 0x802AC468: break       6
    do_break(2150286440);
L_802AC46C:
    // 0x802AC46C: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
L_802AC470:
    // 0x802AC470: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802AC474: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x802AC478: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x802AC47C: jr          $ra
    // 0x802AC480: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x802AC480: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void func_802AC484_6BDB34(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC484: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802AC488: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AC48C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AC490: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AC494: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    // 0x802AC498: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    // 0x802AC49C: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    // 0x802AC4A0: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x802AC4A4: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    // 0x802AC4A8: lw          $a3, 0x1C($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X1C);
    // 0x802AC4AC: lw          $t0, 0x20($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X20);
    // 0x802AC4B0: lhu         $t2, 0x42($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X42);
    // 0x802AC4B4: subu        $a0, $t7, $a3
    ctx->r4 = SUB32(ctx->r15, ctx->r7);
    // 0x802AC4B8: subu        $a1, $t9, $t0
    ctx->r5 = SUB32(ctx->r25, ctx->r8);
    // 0x802AC4BC: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x802AC4C0: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x802AC4C4: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x802AC4C8: sw          $t0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r8;
    // 0x802AC4CC: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x802AC4D0: jal         0x802AC928
    // 0x802AC4D4: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    func_802AC928_6BDFD8(rdram, ctx);
        goto after_0;
    // 0x802AC4D4: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    after_0:
    // 0x802AC4D8: sra         $v1, $v0, 8
    ctx->r3 = S32(SIGNED(ctx->r2) >> 8);
    // 0x802AC4DC: lw          $a0, 0x34($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X34);
    // 0x802AC4E0: lw          $a1, 0x30($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X30);
    // 0x802AC4E4: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    // 0x802AC4E8: lw          $t0, 0x38($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X38);
    // 0x802AC4EC: lw          $t1, 0x28($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X28);
    // 0x802AC4F0: beq         $v1, $zero, L_802AC5BC
    if (ctx->r3 == 0) {
        // 0x802AC4F4: lw          $t2, 0x1C($sp)
        ctx->r10 = MEM_W(ctx->r29, 0X1C);
            goto L_802AC5BC;
    }
    // 0x802AC4F4: lw          $t2, 0x1C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X1C);
    // 0x802AC4F8: slt         $at, $v1, $t2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802AC4FC: bnel        $at, $zero, L_802AC5C0
    if (ctx->r1 != 0) {
        // 0x802AC500: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AC5C0;
    }
    goto skip_0;
    // 0x802AC500: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AC504: bgez        $a0, L_802AC514
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802AC508: sra         $t3, $a0, 8
        ctx->r11 = S32(SIGNED(ctx->r4) >> 8);
            goto L_802AC514;
    }
    // 0x802AC508: sra         $t3, $a0, 8
    ctx->r11 = S32(SIGNED(ctx->r4) >> 8);
    // 0x802AC50C: addiu       $at, $a0, 0xFF
    ctx->r1 = ADD32(ctx->r4, 0XFF);
    // 0x802AC510: sra         $t3, $at, 8
    ctx->r11 = S32(SIGNED(ctx->r1) >> 8);
L_802AC514:
    // 0x802AC514: multu       $t3, $t1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC518: lw          $t9, 0x44($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X44);
    // 0x802AC51C: mflo        $t4
    ctx->r12 = lo;
    // 0x802AC520: nop

    // 0x802AC524: nop

    // 0x802AC528: div         $zero, $t4, $v1
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r3)));
    // 0x802AC52C: bne         $v1, $zero, L_802AC538
    if (ctx->r3 != 0) {
        // 0x802AC530: nop
    
            goto L_802AC538;
    }
    // 0x802AC530: nop

    // 0x802AC534: break       7
    do_break(2150286644);
L_802AC538:
    // 0x802AC538: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC53C: bne         $v1, $at, L_802AC550
    if (ctx->r3 != ctx->r1) {
        // 0x802AC540: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC550;
    }
    // 0x802AC540: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC544: bne         $t4, $at, L_802AC550
    if (ctx->r12 != ctx->r1) {
        // 0x802AC548: nop
    
            goto L_802AC550;
    }
    // 0x802AC548: nop

    // 0x802AC54C: break       6
    do_break(2150286668);
L_802AC550:
    // 0x802AC550: mflo        $a0
    ctx->r4 = lo;
    // 0x802AC554: sll         $t7, $a0, 8
    ctx->r15 = S32(ctx->r4 << 8);
    // 0x802AC558: bgez        $a1, L_802AC568
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802AC55C: sra         $t5, $a1, 8
        ctx->r13 = S32(SIGNED(ctx->r5) >> 8);
            goto L_802AC568;
    }
    // 0x802AC55C: sra         $t5, $a1, 8
    ctx->r13 = S32(SIGNED(ctx->r5) >> 8);
    // 0x802AC560: addiu       $at, $a1, 0xFF
    ctx->r1 = ADD32(ctx->r5, 0XFF);
    // 0x802AC564: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_802AC568:
    // 0x802AC568: multu       $t5, $t1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC56C: addu        $t8, $t7, $a3
    ctx->r24 = ADD32(ctx->r15, ctx->r7);
    // 0x802AC570: sw          $t8, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r24;
    // 0x802AC574: lw          $t5, 0x48($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X48);
    // 0x802AC578: mflo        $t6
    ctx->r14 = lo;
    // 0x802AC57C: nop

    // 0x802AC580: nop

    // 0x802AC584: div         $zero, $t6, $v1
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r3)));
    // 0x802AC588: mflo        $a1
    ctx->r5 = lo;
    // 0x802AC58C: sll         $t3, $a1, 8
    ctx->r11 = S32(ctx->r5 << 8);
    // 0x802AC590: addu        $t4, $t3, $t0
    ctx->r12 = ADD32(ctx->r11, ctx->r8);
    // 0x802AC594: bne         $v1, $zero, L_802AC5A0
    if (ctx->r3 != 0) {
        // 0x802AC598: nop
    
            goto L_802AC5A0;
    }
    // 0x802AC598: nop

    // 0x802AC59C: break       7
    do_break(2150286748);
L_802AC5A0:
    // 0x802AC5A0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AC5A4: bne         $v1, $at, L_802AC5B8
    if (ctx->r3 != ctx->r1) {
        // 0x802AC5A8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AC5B8;
    }
    // 0x802AC5A8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AC5AC: bne         $t6, $at, L_802AC5B8
    if (ctx->r14 != ctx->r1) {
        // 0x802AC5B0: nop
    
            goto L_802AC5B8;
    }
    // 0x802AC5B0: nop

    // 0x802AC5B4: break       6
    do_break(2150286772);
L_802AC5B8:
    // 0x802AC5B8: sw          $t4, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r12;
L_802AC5BC:
    // 0x802AC5BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC5C0:
    // 0x802AC5C0: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x802AC5C4: jr          $ra
    // 0x802AC5C8: nop

    return;
    // 0x802AC5C8: nop

;}
RECOMP_FUNC void func_802AC5CC_6BDC7C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC5CC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AC5D0: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x802AC5D4: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802AC5D8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AC5DC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AC5E0: lh          $t6, 0x2C($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2C);
    // 0x802AC5E4: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AC5E8: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x802AC5EC: bne         $t6, $at, L_802AC600
    if (ctx->r14 != ctx->r1) {
        // 0x802AC5F0: or          $a2, $a1, $zero
        ctx->r6 = ctx->r5 | 0;
            goto L_802AC600;
    }
    // 0x802AC5F0: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
    // 0x802AC5F4: sw          $zero, 0x0($a0)
    MEM_W(0X0, ctx->r4) = 0;
    // 0x802AC5F8: b           L_802AC890
    // 0x802AC5FC: sw          $zero, 0x0($a1)
    MEM_W(0X0, ctx->r5) = 0;
        goto L_802AC890;
    // 0x802AC5FC: sw          $zero, 0x0($a1)
    MEM_W(0X0, ctx->r5) = 0;
L_802AC600:
    // 0x802AC600: lhu         $t7, 0x0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X0);
    // 0x802AC604: addiu       $t8, $t7, -0x2
    ctx->r24 = ADD32(ctx->r15, -0X2);
    // 0x802AC608: sltiu       $at, $t8, 0xDC
    ctx->r1 = ctx->r24 < 0XDC ? 1 : 0;
    // 0x802AC60C: beq         $at, $zero, L_802AC888
    if (ctx->r1 == 0) {
        // 0x802AC610: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802AC888;
    }
    // 0x802AC610: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802AC614: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AC618: addu        $at, $at, $t8
    gpr jr_addend_802AC620 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802AC61C: lw          $t8, -0x471C($at)
    ctx->r24 = ADD32(ctx->r1, -0X471C);
    // 0x802AC620: jr          $t8
    // 0x802AC624: nop

    switch (jr_addend_802AC620 >> 2) {
        case 0: goto L_802AC628; break;
        case 1: goto L_802AC634; break;
        case 2: goto L_802AC6C0; break;
        case 3: goto L_802AC634; break;
        case 4: goto L_802AC678; break;
        case 5: goto L_802AC888; break;
        case 6: goto L_802AC888; break;
        case 7: goto L_802AC888; break;
        case 8: goto L_802AC888; break;
        case 9: goto L_802AC888; break;
        case 10: goto L_802AC888; break;
        case 11: goto L_802AC888; break;
        case 12: goto L_802AC888; break;
        case 13: goto L_802AC888; break;
        case 14: goto L_802AC888; break;
        case 15: goto L_802AC888; break;
        case 16: goto L_802AC888; break;
        case 17: goto L_802AC888; break;
        case 18: goto L_802AC888; break;
        case 19: goto L_802AC628; break;
        case 20: goto L_802AC634; break;
        case 21: goto L_802AC6C0; break;
        case 22: goto L_802AC678; break;
        case 23: goto L_802AC888; break;
        case 24: goto L_802AC888; break;
        case 25: goto L_802AC888; break;
        case 26: goto L_802AC888; break;
        case 27: goto L_802AC888; break;
        case 28: goto L_802AC888; break;
        case 29: goto L_802AC888; break;
        case 30: goto L_802AC888; break;
        case 31: goto L_802AC888; break;
        case 32: goto L_802AC888; break;
        case 33: goto L_802AC888; break;
        case 34: goto L_802AC888; break;
        case 35: goto L_802AC888; break;
        case 36: goto L_802AC888; break;
        case 37: goto L_802AC888; break;
        case 38: goto L_802AC888; break;
        case 39: goto L_802AC628; break;
        case 40: goto L_802AC6C0; break;
        case 41: goto L_802AC888; break;
        case 42: goto L_802AC888; break;
        case 43: goto L_802AC888; break;
        case 44: goto L_802AC888; break;
        case 45: goto L_802AC888; break;
        case 46: goto L_802AC888; break;
        case 47: goto L_802AC888; break;
        case 48: goto L_802AC888; break;
        case 49: goto L_802AC888; break;
        case 50: goto L_802AC888; break;
        case 51: goto L_802AC888; break;
        case 52: goto L_802AC888; break;
        case 53: goto L_802AC888; break;
        case 54: goto L_802AC888; break;
        case 55: goto L_802AC888; break;
        case 56: goto L_802AC888; break;
        case 57: goto L_802AC888; break;
        case 58: goto L_802AC888; break;
        case 59: goto L_802AC628; break;
        case 60: goto L_802AC634; break;
        case 61: goto L_802AC888; break;
        case 62: goto L_802AC888; break;
        case 63: goto L_802AC888; break;
        case 64: goto L_802AC888; break;
        case 65: goto L_802AC888; break;
        case 66: goto L_802AC888; break;
        case 67: goto L_802AC888; break;
        case 68: goto L_802AC888; break;
        case 69: goto L_802AC888; break;
        case 70: goto L_802AC888; break;
        case 71: goto L_802AC888; break;
        case 72: goto L_802AC888; break;
        case 73: goto L_802AC888; break;
        case 74: goto L_802AC888; break;
        case 75: goto L_802AC888; break;
        case 76: goto L_802AC888; break;
        case 77: goto L_802AC888; break;
        case 78: goto L_802AC888; break;
        case 79: goto L_802AC78C; break;
        case 80: goto L_802AC888; break;
        case 81: goto L_802AC888; break;
        case 82: goto L_802AC888; break;
        case 83: goto L_802AC888; break;
        case 84: goto L_802AC888; break;
        case 85: goto L_802AC888; break;
        case 86: goto L_802AC888; break;
        case 87: goto L_802AC888; break;
        case 88: goto L_802AC888; break;
        case 89: goto L_802AC888; break;
        case 90: goto L_802AC888; break;
        case 91: goto L_802AC888; break;
        case 92: goto L_802AC888; break;
        case 93: goto L_802AC888; break;
        case 94: goto L_802AC888; break;
        case 95: goto L_802AC888; break;
        case 96: goto L_802AC888; break;
        case 97: goto L_802AC888; break;
        case 98: goto L_802AC888; break;
        case 99: goto L_802AC628; break;
        case 100: goto L_802AC628; break;
        case 101: goto L_802AC628; break;
        case 102: goto L_802AC704; break;
        case 103: goto L_802AC748; break;
        case 104: goto L_802AC628; break;
        case 105: goto L_802AC888; break;
        case 106: goto L_802AC888; break;
        case 107: goto L_802AC888; break;
        case 108: goto L_802AC888; break;
        case 109: goto L_802AC888; break;
        case 110: goto L_802AC888; break;
        case 111: goto L_802AC888; break;
        case 112: goto L_802AC888; break;
        case 113: goto L_802AC888; break;
        case 114: goto L_802AC888; break;
        case 115: goto L_802AC888; break;
        case 116: goto L_802AC888; break;
        case 117: goto L_802AC888; break;
        case 118: goto L_802AC888; break;
        case 119: goto L_802AC628; break;
        case 120: goto L_802AC634; break;
        case 121: goto L_802AC628; break;
        case 122: goto L_802AC888; break;
        case 123: goto L_802AC888; break;
        case 124: goto L_802AC888; break;
        case 125: goto L_802AC888; break;
        case 126: goto L_802AC888; break;
        case 127: goto L_802AC888; break;
        case 128: goto L_802AC888; break;
        case 129: goto L_802AC888; break;
        case 130: goto L_802AC888; break;
        case 131: goto L_802AC888; break;
        case 132: goto L_802AC888; break;
        case 133: goto L_802AC888; break;
        case 134: goto L_802AC888; break;
        case 135: goto L_802AC888; break;
        case 136: goto L_802AC888; break;
        case 137: goto L_802AC888; break;
        case 138: goto L_802AC888; break;
        case 139: goto L_802AC628; break;
        case 140: goto L_802AC7BC; break;
        case 141: goto L_802AC844; break;
        case 142: goto L_802AC800; break;
        case 143: goto L_802AC888; break;
        case 144: goto L_802AC888; break;
        case 145: goto L_802AC888; break;
        case 146: goto L_802AC888; break;
        case 147: goto L_802AC888; break;
        case 148: goto L_802AC888; break;
        case 149: goto L_802AC888; break;
        case 150: goto L_802AC888; break;
        case 151: goto L_802AC888; break;
        case 152: goto L_802AC888; break;
        case 153: goto L_802AC888; break;
        case 154: goto L_802AC888; break;
        case 155: goto L_802AC888; break;
        case 156: goto L_802AC888; break;
        case 157: goto L_802AC888; break;
        case 158: goto L_802AC888; break;
        case 159: goto L_802AC628; break;
        case 160: goto L_802AC634; break;
        case 161: goto L_802AC888; break;
        case 162: goto L_802AC888; break;
        case 163: goto L_802AC888; break;
        case 164: goto L_802AC888; break;
        case 165: goto L_802AC888; break;
        case 166: goto L_802AC888; break;
        case 167: goto L_802AC888; break;
        case 168: goto L_802AC888; break;
        case 169: goto L_802AC888; break;
        case 170: goto L_802AC888; break;
        case 171: goto L_802AC888; break;
        case 172: goto L_802AC888; break;
        case 173: goto L_802AC888; break;
        case 174: goto L_802AC888; break;
        case 175: goto L_802AC888; break;
        case 176: goto L_802AC888; break;
        case 177: goto L_802AC888; break;
        case 178: goto L_802AC888; break;
        case 179: goto L_802AC628; break;
        case 180: goto L_802AC634; break;
        case 181: goto L_802AC6C0; break;
        case 182: goto L_802AC628; break;
        case 183: goto L_802AC888; break;
        case 184: goto L_802AC888; break;
        case 185: goto L_802AC888; break;
        case 186: goto L_802AC888; break;
        case 187: goto L_802AC888; break;
        case 188: goto L_802AC888; break;
        case 189: goto L_802AC888; break;
        case 190: goto L_802AC888; break;
        case 191: goto L_802AC888; break;
        case 192: goto L_802AC888; break;
        case 193: goto L_802AC888; break;
        case 194: goto L_802AC888; break;
        case 195: goto L_802AC888; break;
        case 196: goto L_802AC888; break;
        case 197: goto L_802AC888; break;
        case 198: goto L_802AC888; break;
        case 199: goto L_802AC628; break;
        case 200: goto L_802AC634; break;
        case 201: goto L_802AC6C0; break;
        case 202: goto L_802AC678; break;
        case 203: goto L_802AC888; break;
        case 204: goto L_802AC888; break;
        case 205: goto L_802AC888; break;
        case 206: goto L_802AC888; break;
        case 207: goto L_802AC888; break;
        case 208: goto L_802AC888; break;
        case 209: goto L_802AC888; break;
        case 210: goto L_802AC888; break;
        case 211: goto L_802AC888; break;
        case 212: goto L_802AC888; break;
        case 213: goto L_802AC888; break;
        case 214: goto L_802AC888; break;
        case 215: goto L_802AC888; break;
        case 216: goto L_802AC888; break;
        case 217: goto L_802AC888; break;
        case 218: goto L_802AC888; break;
        case 219: goto L_802AC628; break;
        default: switch_error(__func__, 0x802AC620, 0x803BB8E4);
    }
    // 0x802AC624: nop

L_802AC628:
    // 0x802AC628: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC62C: b           L_802AC890
    // 0x802AC630: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
        goto L_802AC890;
    // 0x802AC630: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
L_802AC634:
    // 0x802AC634: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC638: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AC63C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AC640: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802AC644: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AC648: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC64C: lb          $t2, 0x368($t1)
    ctx->r10 = MEM_B(ctx->r9, 0X368);
    // 0x802AC650: lhu         $t0, 0xA4($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0XA4);
    // 0x802AC654: multu       $t0, $t2
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC658: mflo        $t3
    ctx->r11 = lo;
    // 0x802AC65C: sll         $t4, $t3, 6
    ctx->r12 = S32(ctx->r11 << 6);
    // 0x802AC660: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x802AC664: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x802AC668: jal         0x802B90A0
    // 0x802AC66C: lbu         $a0, 0x2D($t5)
    ctx->r4 = MEM_BU(ctx->r13, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_0;
    // 0x802AC66C: lbu         $a0, 0x2D($t5)
    ctx->r4 = MEM_BU(ctx->r13, 0X2D);
    after_0:
    // 0x802AC670: b           L_802AC894
    // 0x802AC674: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC674: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC678:
    // 0x802AC678: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC67C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC680: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AC684: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802AC688: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AC68C: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC690: lb          $t9, 0x368($t8)
    ctx->r25 = MEM_B(ctx->r24, 0X368);
    // 0x802AC694: lhu         $t7, 0xA4($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA4);
    // 0x802AC698: multu       $t7, $t9
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC69C: mflo        $t1
    ctx->r9 = lo;
    // 0x802AC6A0: negu        $t0, $t1
    ctx->r8 = SUB32(0, ctx->r9);
    // 0x802AC6A4: sll         $t2, $t0, 6
    ctx->r10 = S32(ctx->r8 << 6);
    // 0x802AC6A8: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x802AC6AC: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802AC6B0: jal         0x802B90A0
    // 0x802AC6B4: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_1;
    // 0x802AC6B4: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    after_1:
    // 0x802AC6B8: b           L_802AC894
    // 0x802AC6BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC6BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC6C0:
    // 0x802AC6C0: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC6C4: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AC6C8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC6CC: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802AC6D0: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802AC6D4: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC6D8: lb          $t8, 0x368($t6)
    ctx->r24 = MEM_B(ctx->r14, 0X368);
    // 0x802AC6DC: lhu         $t5, 0xA4($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0XA4);
    // 0x802AC6E0: multu       $t5, $t8
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC6E4: mflo        $t7
    ctx->r15 = lo;
    // 0x802AC6E8: sll         $t9, $t7, 6
    ctx->r25 = S32(ctx->r15 << 6);
    // 0x802AC6EC: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x802AC6F0: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802AC6F4: jal         0x802B90A0
    // 0x802AC6F8: lbu         $a0, 0x2D($t1)
    ctx->r4 = MEM_BU(ctx->r9, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_2;
    // 0x802AC6F8: lbu         $a0, 0x2D($t1)
    ctx->r4 = MEM_BU(ctx->r9, 0X2D);
    after_2:
    // 0x802AC6FC: b           L_802AC894
    // 0x802AC700: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC700: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC704:
    // 0x802AC704: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC708: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AC70C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AC710: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802AC714: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x802AC718: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC71C: lb          $t4, 0x368($t3)
    ctx->r12 = MEM_B(ctx->r11, 0X368);
    // 0x802AC720: lhu         $t2, 0xAC($t0)
    ctx->r10 = MEM_HU(ctx->r8, 0XAC);
    // 0x802AC724: multu       $t2, $t4
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC728: mflo        $t6
    ctx->r14 = lo;
    // 0x802AC72C: sll         $t5, $t6, 6
    ctx->r13 = S32(ctx->r14 << 6);
    // 0x802AC730: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x802AC734: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802AC738: jal         0x802B90A0
    // 0x802AC73C: lbu         $a0, 0x2D($t8)
    ctx->r4 = MEM_BU(ctx->r24, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_3;
    // 0x802AC73C: lbu         $a0, 0x2D($t8)
    ctx->r4 = MEM_BU(ctx->r24, 0X2D);
    after_3:
    // 0x802AC740: b           L_802AC894
    // 0x802AC744: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC744: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC748:
    // 0x802AC748: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC74C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AC750: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AC754: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802AC758: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AC75C: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC760: lb          $t0, 0x368($t1)
    ctx->r8 = MEM_B(ctx->r9, 0X368);
    // 0x802AC764: lhu         $t9, 0xAC($t7)
    ctx->r25 = MEM_HU(ctx->r15, 0XAC);
    // 0x802AC768: multu       $t9, $t0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC76C: mflo        $t3
    ctx->r11 = lo;
    // 0x802AC770: sll         $t2, $t3, 6
    ctx->r10 = S32(ctx->r11 << 6);
    // 0x802AC774: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x802AC778: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802AC77C: jal         0x802B90A0
    // 0x802AC780: lbu         $a0, 0x2D($t4)
    ctx->r4 = MEM_BU(ctx->r12, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_4;
    // 0x802AC780: lbu         $a0, 0x2D($t4)
    ctx->r4 = MEM_BU(ctx->r12, 0X2D);
    after_4:
    // 0x802AC784: b           L_802AC894
    // 0x802AC788: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC788: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC78C:
    // 0x802AC78C: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC790: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC794: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AC798: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC79C: lhu         $t5, 0xAC($t6)
    ctx->r13 = MEM_HU(ctx->r14, 0XAC);
    // 0x802AC7A0: sll         $t8, $t5, 10
    ctx->r24 = S32(ctx->r13 << 10);
    // 0x802AC7A4: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x802AC7A8: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802AC7AC: jal         0x802B90A0
    // 0x802AC7B0: lbu         $a0, 0x2D($t7)
    ctx->r4 = MEM_BU(ctx->r15, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_5;
    // 0x802AC7B0: lbu         $a0, 0x2D($t7)
    ctx->r4 = MEM_BU(ctx->r15, 0X2D);
    after_5:
    // 0x802AC7B4: b           L_802AC894
    // 0x802AC7B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC7B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC7BC:
    // 0x802AC7BC: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC7C0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AC7C4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AC7C8: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x802AC7CC: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802AC7D0: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC7D4: lb          $t3, 0x368($t0)
    ctx->r11 = MEM_B(ctx->r8, 0X368);
    // 0x802AC7D8: lhu         $t9, 0xAA($t1)
    ctx->r25 = MEM_HU(ctx->r9, 0XAA);
    // 0x802AC7DC: multu       $t9, $t3
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC7E0: mflo        $t2
    ctx->r10 = lo;
    // 0x802AC7E4: sll         $t4, $t2, 6
    ctx->r12 = S32(ctx->r10 << 6);
    // 0x802AC7E8: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x802AC7EC: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802AC7F0: jal         0x802B90A0
    // 0x802AC7F4: lbu         $a0, 0x2D($t6)
    ctx->r4 = MEM_BU(ctx->r14, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_6;
    // 0x802AC7F4: lbu         $a0, 0x2D($t6)
    ctx->r4 = MEM_BU(ctx->r14, 0X2D);
    after_6:
    // 0x802AC7F8: b           L_802AC894
    // 0x802AC7FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC7FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC800:
    // 0x802AC800: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC804: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AC808: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AC80C: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802AC810: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AC814: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC818: lb          $t1, 0x368($t7)
    ctx->r9 = MEM_B(ctx->r15, 0X368);
    // 0x802AC81C: lhu         $t8, 0xAA($t5)
    ctx->r24 = MEM_HU(ctx->r13, 0XAA);
    // 0x802AC820: multu       $t8, $t1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC824: mflo        $t0
    ctx->r8 = lo;
    // 0x802AC828: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
    // 0x802AC82C: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x802AC830: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802AC834: jal         0x802B90A0
    // 0x802AC838: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_7;
    // 0x802AC838: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    after_7:
    // 0x802AC83C: b           L_802AC894
    // 0x802AC840: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC840: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC844:
    // 0x802AC844: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC848: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AC84C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC850: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802AC854: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802AC858: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC85C: lb          $t5, 0x368($t6)
    ctx->r13 = MEM_B(ctx->r14, 0X368);
    // 0x802AC860: lhu         $t4, 0xAA($t2)
    ctx->r12 = MEM_HU(ctx->r10, 0XAA);
    // 0x802AC864: multu       $t4, $t5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AC868: mflo        $t7
    ctx->r15 = lo;
    // 0x802AC86C: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x802AC870: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x802AC874: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802AC878: jal         0x802B90A0
    // 0x802AC87C: lbu         $a0, 0x2D($t1)
    ctx->r4 = MEM_BU(ctx->r9, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_8;
    // 0x802AC87C: lbu         $a0, 0x2D($t1)
    ctx->r4 = MEM_BU(ctx->r9, 0X2D);
    after_8:
    // 0x802AC880: b           L_802AC894
    // 0x802AC884: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC894;
    // 0x802AC884: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC888:
    // 0x802AC888: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802AC88C: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
L_802AC890:
    // 0x802AC890: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC894:
    // 0x802AC894: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AC898: jr          $ra
    // 0x802AC89C: nop

    return;
    // 0x802AC89C: nop

;}
RECOMP_FUNC void func_802AC8A0_6BDF50(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC8A0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AC8A4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AC8A8: sw          $zero, 0x0($a0)
    MEM_W(0X0, ctx->r4) = 0;
    // 0x802AC8AC: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AC8B0: lh          $v0, -0x614E($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X614E);
    // 0x802AC8B4: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x802AC8B8: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
    // 0x802AC8BC: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802AC8C0: bne         $at, $zero, L_802AC8E0
    if (ctx->r1 != 0) {
        // 0x802AC8C4: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_802AC8E0;
    }
    // 0x802AC8C4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AC8C8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AC8CC: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AC8D0: lhu         $t7, 0xA4($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA4);
    // 0x802AC8D4: sll         $t8, $t7, 10
    ctx->r24 = S32(ctx->r15 << 10);
    // 0x802AC8D8: b           L_802AC908
    // 0x802AC8DC: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
        goto L_802AC908;
    // 0x802AC8DC: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
L_802AC8E0:
    // 0x802AC8E0: blez        $v0, L_802AC904
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AC8E4: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_802AC904;
    }
    // 0x802AC8E4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AC8E8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AC8EC: lhu         $t0, 0xA4($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0XA4);
    // 0x802AC8F0: sll         $t1, $t0, 2
    ctx->r9 = S32(ctx->r8 << 2);
    // 0x802AC8F4: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x802AC8F8: sll         $t2, $t1, 7
    ctx->r10 = S32(ctx->r9 << 7);
    // 0x802AC8FC: b           L_802AC908
    // 0x802AC900: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
        goto L_802AC908;
    // 0x802AC900: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
L_802AC904:
    // 0x802AC904: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
L_802AC908:
    // 0x802AC908: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x802AC90C: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    // 0x802AC910: jal         0x802B90A0
    // 0x802AC914: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    func_802B90A0_6CA750(rdram, ctx);
        goto after_0;
    // 0x802AC914: lbu         $a0, 0x2D($t3)
    ctx->r4 = MEM_BU(ctx->r11, 0X2D);
    after_0:
    // 0x802AC918: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AC91C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AC920: jr          $ra
    // 0x802AC924: nop

    return;
    // 0x802AC924: nop

;}
RECOMP_FUNC void func_802AC928_6BDFD8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC928: bgez        $a0, L_802AC934
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802AC92C: nop
    
            goto L_802AC934;
    }
    // 0x802AC92C: nop

    // 0x802AC930: negu        $a0, $a0
    ctx->r4 = SUB32(0, ctx->r4);
L_802AC934:
    // 0x802AC934: bgezl       $a1, L_802AC944
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802AC938: slt         $at, $a1, $a0
        ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
            goto L_802AC944;
    }
    goto skip_0;
    // 0x802AC938: slt         $at, $a1, $a0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
    skip_0:
    // 0x802AC93C: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    // 0x802AC940: slt         $at, $a1, $a0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
L_802AC944:
    // 0x802AC944: bne         $at, $zero, L_802AC964
    if (ctx->r1 != 0) {
        // 0x802AC948: nop
    
            goto L_802AC964;
    }
    // 0x802AC948: nop

    // 0x802AC94C: bgez        $a0, L_802AC95C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802AC950: sra         $t6, $a0, 1
        ctx->r14 = S32(SIGNED(ctx->r4) >> 1);
            goto L_802AC95C;
    }
    // 0x802AC950: sra         $t6, $a0, 1
    ctx->r14 = S32(SIGNED(ctx->r4) >> 1);
    // 0x802AC954: addiu       $at, $a0, 0x1
    ctx->r1 = ADD32(ctx->r4, 0X1);
    // 0x802AC958: sra         $t6, $at, 1
    ctx->r14 = S32(SIGNED(ctx->r1) >> 1);
L_802AC95C:
    // 0x802AC95C: jr          $ra
    // 0x802AC960: addu        $v0, $t6, $a1
    ctx->r2 = ADD32(ctx->r14, ctx->r5);
    return;
    // 0x802AC960: addu        $v0, $t6, $a1
    ctx->r2 = ADD32(ctx->r14, ctx->r5);
L_802AC964:
    // 0x802AC964: bgez        $a1, L_802AC974
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802AC968: sra         $t7, $a1, 1
        ctx->r15 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802AC974;
    }
    // 0x802AC968: sra         $t7, $a1, 1
    ctx->r15 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802AC96C: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802AC970: sra         $t7, $at, 1
    ctx->r15 = S32(SIGNED(ctx->r1) >> 1);
L_802AC974:
    // 0x802AC974: addu        $v0, $t7, $a0
    ctx->r2 = ADD32(ctx->r15, ctx->r4);
    // 0x802AC978: jr          $ra
    // 0x802AC97C: nop

    return;
    // 0x802AC97C: nop

;}
RECOMP_FUNC void func_802AC980_6BE030(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC980: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x802AC984: lh          $t6, 0x2A98($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2A98);
    // 0x802AC988: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x802AC98C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AC990: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802AC994: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802AC998: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802AC99C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802AC9A0: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802AC9A4: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802AC9A8: lh          $t8, 0x28E0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X28E0);
    // 0x802AC9AC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AC9B0: addiu       $t9, $t8, -0x3
    ctx->r25 = ADD32(ctx->r24, -0X3);
    // 0x802AC9B4: sltiu       $at, $t9, 0x1A
    ctx->r1 = ctx->r25 < 0X1A ? 1 : 0;
    // 0x802AC9B8: beq         $at, $zero, L_802AC9E4
    if (ctx->r1 == 0) {
        // 0x802AC9BC: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802AC9E4;
    }
    // 0x802AC9BC: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802AC9C0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AC9C4: addu        $at, $at, $t9
    gpr jr_addend_802AC9CC = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802AC9C8: lw          $t9, -0x43AC($at)
    ctx->r25 = ADD32(ctx->r1, -0X43AC);
    // 0x802AC9CC: jr          $t9
    // 0x802AC9D0: nop

    switch (jr_addend_802AC9CC >> 2) {
        case 0: goto L_802AC9D4; break;
        case 1: goto L_802AC9E4; break;
        case 2: goto L_802AC9D4; break;
        case 3: goto L_802AC9D4; break;
        case 4: goto L_802AC9D4; break;
        case 5: goto L_802AC9E4; break;
        case 6: goto L_802AC9E4; break;
        case 7: goto L_802AC9E4; break;
        case 8: goto L_802AC9E4; break;
        case 9: goto L_802AC9E4; break;
        case 10: goto L_802AC9E4; break;
        case 11: goto L_802AC9E4; break;
        case 12: goto L_802AC9E4; break;
        case 13: goto L_802AC9E4; break;
        case 14: goto L_802AC9D4; break;
        case 15: goto L_802AC9E4; break;
        case 16: goto L_802AC9E4; break;
        case 17: goto L_802AC9E4; break;
        case 18: goto L_802AC9E4; break;
        case 19: goto L_802AC9E4; break;
        case 20: goto L_802AC9E4; break;
        case 21: goto L_802AC9E4; break;
        case 22: goto L_802AC9E4; break;
        case 23: goto L_802AC9E4; break;
        case 24: goto L_802AC9E4; break;
        case 25: goto L_802AC9D4; break;
        default: switch_error(__func__, 0x802AC9CC, 0x803BBC54);
    }
    // 0x802AC9D0: nop

L_802AC9D4:
    // 0x802AC9D4: jal         0x802AD0FC
    // 0x802AC9D8: nop

    func_802AD0FC_6BE7AC(rdram, ctx);
        goto after_0;
    // 0x802AC9D8: nop

    after_0:
    // 0x802AC9DC: b           L_802AC9F0
    // 0x802AC9E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AC9F0;
    // 0x802AC9E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC9E4:
    // 0x802AC9E4: jal         0x802AC9FC
    // 0x802AC9E8: nop

    func_802AC9FC_6BE0AC(rdram, ctx);
        goto after_1;
    // 0x802AC9E8: nop

    after_1:
    // 0x802AC9EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AC9F0:
    // 0x802AC9F0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AC9F4: jr          $ra
    // 0x802AC9F8: nop

    return;
    // 0x802AC9F8: nop

;}
RECOMP_FUNC void func_802AC9FC_6BE0AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AC9FC: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACA00: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACA04: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802ACA08: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802ACA0C: addiu       $a1, $a3, 0x7FFF
    ctx->r5 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACA10: lb          $a1, 0x7FD9($a1)
    ctx->r5 = MEM_B(ctx->r5, 0X7FD9);
    // 0x802ACA14: addiu       $a2, $a3, 0x7FFF
    ctx->r6 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACA18: lb          $a2, 0x7FDA($a2)
    ctx->r6 = MEM_B(ctx->r6, 0X7FDA);
    // 0x802ACA1C: bgezl       $a1, L_802ACA30
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802ACA20: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802ACA30;
    }
    goto skip_0;
    // 0x802ACA20: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    skip_0:
    // 0x802ACA24: b           L_802ACA30
    // 0x802ACA28: negu        $v0, $a1
    ctx->r2 = SUB32(0, ctx->r5);
        goto L_802ACA30;
    // 0x802ACA28: negu        $v0, $a1
    ctx->r2 = SUB32(0, ctx->r5);
    // 0x802ACA2C: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802ACA30:
    // 0x802ACA30: slti        $at, $v0, 0xB
    ctx->r1 = SIGNED(ctx->r2) < 0XB ? 1 : 0;
    // 0x802ACA34: beq         $at, $zero, L_802ACA44
    if (ctx->r1 == 0) {
        // 0x802ACA38: nop
    
            goto L_802ACA44;
    }
    // 0x802ACA38: nop

    // 0x802ACA3C: b           L_802ACA68
    // 0x802ACA40: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
        goto L_802ACA68;
    // 0x802ACA40: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_802ACA44:
    // 0x802ACA44: blezl       $a1, L_802ACA60
    if (SIGNED(ctx->r5) <= 0) {
        // 0x802ACA48: addiu       $a1, $a1, 0xA
        ctx->r5 = ADD32(ctx->r5, 0XA);
            goto L_802ACA60;
    }
    goto skip_1;
    // 0x802ACA48: addiu       $a1, $a1, 0xA
    ctx->r5 = ADD32(ctx->r5, 0XA);
    skip_1:
    // 0x802ACA4C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    // 0x802ACA50: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802ACA54: b           L_802ACA68
    // 0x802ACA58: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
        goto L_802ACA68;
    // 0x802ACA58: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802ACA5C: addiu       $a1, $a1, 0xA
    ctx->r5 = ADD32(ctx->r5, 0XA);
L_802ACA60:
    // 0x802ACA60: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802ACA64: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_802ACA68:
    // 0x802ACA68: mtc1        $a1, $f4
    ctx->f4.u32l = ctx->r5;
    // 0x802ACA6C: bgez        $a2, L_802ACA7C
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802ACA70: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802ACA7C;
    }
    // 0x802ACA70: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802ACA74: b           L_802ACA7C
    // 0x802ACA78: negu        $v0, $a2
    ctx->r2 = SUB32(0, ctx->r6);
        goto L_802ACA7C;
    // 0x802ACA78: negu        $v0, $a2
    ctx->r2 = SUB32(0, ctx->r6);
L_802ACA7C:
    // 0x802ACA7C: slti        $at, $v0, 0xB
    ctx->r1 = SIGNED(ctx->r2) < 0XB ? 1 : 0;
    // 0x802ACA80: beq         $at, $zero, L_802ACA90
    if (ctx->r1 == 0) {
        // 0x802ACA84: nop
    
            goto L_802ACA90;
    }
    // 0x802ACA84: nop

    // 0x802ACA88: b           L_802ACAB4
    // 0x802ACA8C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
        goto L_802ACAB4;
    // 0x802ACA8C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_802ACA90:
    // 0x802ACA90: blezl       $a2, L_802ACAAC
    if (SIGNED(ctx->r6) <= 0) {
        // 0x802ACA94: addiu       $a2, $a2, 0xA
        ctx->r6 = ADD32(ctx->r6, 0XA);
            goto L_802ACAAC;
    }
    goto skip_2;
    // 0x802ACA94: addiu       $a2, $a2, 0xA
    ctx->r6 = ADD32(ctx->r6, 0XA);
    skip_2:
    // 0x802ACA98: addiu       $a2, $a2, -0xA
    ctx->r6 = ADD32(ctx->r6, -0XA);
    // 0x802ACA9C: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x802ACAA0: b           L_802ACAB4
    // 0x802ACAA4: sra         $a2, $t1, 16
    ctx->r6 = S32(SIGNED(ctx->r9) >> 16);
        goto L_802ACAB4;
    // 0x802ACAA4: sra         $a2, $t1, 16
    ctx->r6 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802ACAA8: addiu       $a2, $a2, 0xA
    ctx->r6 = ADD32(ctx->r6, 0XA);
L_802ACAAC:
    // 0x802ACAAC: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802ACAB0: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
L_802ACAB4:
    // 0x802ACAB4: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802ACAB8: mtc1        $a2, $f6
    ctx->f6.u32l = ctx->r6;
    // 0x802ACABC: sh          $a1, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r5;
    // 0x802ACAC0: sh          $a2, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r6;
    // 0x802ACAC4: cvt.s.w     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    ctx->f2.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802ACAC8: mul.s       $f8, $f0, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x802ACACC: nop

    // 0x802ACAD0: mul.s       $f10, $f2, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x802ACAD4: jal         0x80137E10
    // 0x802ACAD8: add.s       $f12, $f8, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f10.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x802ACAD8: add.s       $f12, $f8, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f10.fl;
    after_0:
    // 0x802ACADC: trunc.w.s   $f16, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    ctx->f16.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802ACAE0: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACAE4: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACAE8: lh          $a1, 0x1A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1A);
    // 0x802ACAEC: mfc1        $v0, $f16
    ctx->r2 = (int32_t)ctx->f16.u32l;
    // 0x802ACAF0: lh          $a2, 0x18($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X18);
    // 0x802ACAF4: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACAF8: sh          $v0, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r2;
    // 0x802ACAFC: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802ACB00: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    // 0x802ACB04: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802ACB08: slti        $at, $t6, 0x12
    ctx->r1 = SIGNED(ctx->r14) < 0X12 ? 1 : 0;
    // 0x802ACB0C: bne         $at, $zero, L_802ACB20
    if (ctx->r1 != 0) {
        // 0x802ACB10: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_802ACB20;
    }
    // 0x802ACB10: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802ACB14: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802ACB18: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACB1C: sh          $t7, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r15;
L_802ACB20:
    // 0x802ACB20: slti        $at, $v1, 0x1A
    ctx->r1 = SIGNED(ctx->r3) < 0X1A ? 1 : 0;
    // 0x802ACB24: bnel        $at, $zero, L_802ACB3C
    if (ctx->r1 != 0) {
        // 0x802ACB28: slti        $at, $v1, 0x26
        ctx->r1 = SIGNED(ctx->r3) < 0X26 ? 1 : 0;
            goto L_802ACB3C;
    }
    goto skip_3;
    // 0x802ACB28: slti        $at, $v1, 0x26
    ctx->r1 = SIGNED(ctx->r3) < 0X26 ? 1 : 0;
    skip_3:
    // 0x802ACB2C: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x802ACB30: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACB34: sh          $t8, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r24;
    // 0x802ACB38: slti        $at, $v1, 0x26
    ctx->r1 = SIGNED(ctx->r3) < 0X26 ? 1 : 0;
L_802ACB3C:
    // 0x802ACB3C: bnel        $at, $zero, L_802ACB54
    if (ctx->r1 != 0) {
        // 0x802ACB40: slti        $at, $v1, 0x38
        ctx->r1 = SIGNED(ctx->r3) < 0X38 ? 1 : 0;
            goto L_802ACB54;
    }
    goto skip_4;
    // 0x802ACB40: slti        $at, $v1, 0x38
    ctx->r1 = SIGNED(ctx->r3) < 0X38 ? 1 : 0;
    skip_4:
    // 0x802ACB44: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x802ACB48: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACB4C: sh          $t9, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r25;
    // 0x802ACB50: slti        $at, $v1, 0x38
    ctx->r1 = SIGNED(ctx->r3) < 0X38 ? 1 : 0;
L_802ACB54:
    // 0x802ACB54: bne         $at, $zero, L_802ACB68
    if (ctx->r1 != 0) {
        // 0x802ACB58: nop
    
            goto L_802ACB68;
    }
    // 0x802ACB58: nop

    // 0x802ACB5C: addiu       $t1, $zero, 0x4
    ctx->r9 = ADD32(0, 0X4);
    // 0x802ACB60: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACB64: sh          $t1, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r9;
L_802ACB68:
    // 0x802ACB68: bne         $v1, $zero, L_802ACB7C
    if (ctx->r3 != 0) {
        // 0x802ACB6C: addiu       $at, $a3, 0x7FFF
        ctx->r1 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ACB7C;
    }
    // 0x802ACB6C: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACB70: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
    // 0x802ACB74: b           L_802ACD4C
    // 0x802ACB78: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
        goto L_802ACD4C;
    // 0x802ACB78: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
L_802ACB7C:
    // 0x802ACB7C: bgez        $a1, L_802ACB8C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802ACB80: or          $v1, $a1, $zero
        ctx->r3 = ctx->r5 | 0;
            goto L_802ACB8C;
    }
    // 0x802ACB80: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x802ACB84: b           L_802ACB8C
    // 0x802ACB88: negu        $v1, $a1
    ctx->r3 = SUB32(0, ctx->r5);
        goto L_802ACB8C;
    // 0x802ACB88: negu        $v1, $a1
    ctx->r3 = SUB32(0, ctx->r5);
L_802ACB8C:
    // 0x802ACB8C: bgez        $a2, L_802ACB9C
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802ACB90: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802ACB9C;
    }
    // 0x802ACB90: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802ACB94: b           L_802ACB9C
    // 0x802ACB98: negu        $v0, $a2
    ctx->r2 = SUB32(0, ctx->r6);
        goto L_802ACB9C;
    // 0x802ACB98: negu        $v0, $a2
    ctx->r2 = SUB32(0, ctx->r6);
L_802ACB9C:
    // 0x802ACB9C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802ACBA0: bne         $at, $zero, L_802ACC74
    if (ctx->r1 != 0) {
        // 0x802ACBA4: nop
    
            goto L_802ACC74;
    }
    // 0x802ACBA4: nop

    // 0x802ACBA8: bltzl       $a2, L_802ACC14
    if (SIGNED(ctx->r6) < 0) {
        // 0x802ACBAC: lh          $t7, 0x1E($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X1E);
            goto L_802ACC14;
    }
    goto skip_5;
    // 0x802ACBAC: lh          $t7, 0x1E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X1E);
    skip_5:
    // 0x802ACBB0: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
    // 0x802ACBB4: sll         $t2, $a1, 7
    ctx->r10 = S32(ctx->r5 << 7);
    // 0x802ACBB8: div         $zero, $t2, $t3
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r11)));
    // 0x802ACBBC: mflo        $a0
    ctx->r4 = lo;
    // 0x802ACBC0: addiu       $a0, $a0, 0x80
    ctx->r4 = ADD32(ctx->r4, 0X80);
    // 0x802ACBC4: andi        $t4, $a0, 0xFF
    ctx->r12 = ctx->r4 & 0XFF;
    // 0x802ACBC8: bne         $t3, $zero, L_802ACBD4
    if (ctx->r11 != 0) {
        // 0x802ACBCC: nop
    
            goto L_802ACBD4;
    }
    // 0x802ACBCC: nop

    // 0x802ACBD0: break       7
    do_break(2150288336);
L_802ACBD4:
    // 0x802ACBD4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ACBD8: bne         $t3, $at, L_802ACBEC
    if (ctx->r11 != ctx->r1) {
        // 0x802ACBDC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ACBEC;
    }
    // 0x802ACBDC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ACBE0: bne         $t2, $at, L_802ACBEC
    if (ctx->r10 != ctx->r1) {
        // 0x802ACBE4: nop
    
            goto L_802ACBEC;
    }
    // 0x802ACBE4: nop

    // 0x802ACBE8: break       6
    do_break(2150288360);
L_802ACBEC:
    // 0x802ACBEC: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x802ACBF0: jal         0x8012840C
    // 0x802ACBF4: nop

    func_8012840C(rdram, ctx);
        goto after_1;
    // 0x802ACBF4: nop

    after_1:
    // 0x802ACBF8: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802ACBFC: sra         $t5, $v1, 16
    ctx->r13 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802ACC00: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACC04: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACC08: b           L_802ACD3C
    // 0x802ACC0C: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
        goto L_802ACD3C;
    // 0x802ACC0C: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x802ACC10: lh          $t7, 0x1E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X1E);
L_802ACC14:
    // 0x802ACC14: sll         $t6, $a1, 7
    ctx->r14 = S32(ctx->r5 << 7);
    // 0x802ACC18: div         $zero, $t6, $t7
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r15))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r15)));
    // 0x802ACC1C: mflo        $a0
    ctx->r4 = lo;
    // 0x802ACC20: addiu       $a0, $a0, 0x80
    ctx->r4 = ADD32(ctx->r4, 0X80);
    // 0x802ACC24: andi        $t8, $a0, 0xFF
    ctx->r24 = ctx->r4 & 0XFF;
    // 0x802ACC28: bne         $t7, $zero, L_802ACC34
    if (ctx->r15 != 0) {
        // 0x802ACC2C: nop
    
            goto L_802ACC34;
    }
    // 0x802ACC2C: nop

    // 0x802ACC30: break       7
    do_break(2150288432);
L_802ACC34:
    // 0x802ACC34: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ACC38: bne         $t7, $at, L_802ACC4C
    if (ctx->r15 != ctx->r1) {
        // 0x802ACC3C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ACC4C;
    }
    // 0x802ACC3C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ACC40: bne         $t6, $at, L_802ACC4C
    if (ctx->r14 != ctx->r1) {
        // 0x802ACC44: nop
    
            goto L_802ACC4C;
    }
    // 0x802ACC44: nop

    // 0x802ACC48: break       6
    do_break(2150288456);
L_802ACC4C:
    // 0x802ACC4C: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x802ACC50: jal         0x8012840C
    // 0x802ACC54: nop

    func_8012840C(rdram, ctx);
        goto after_2;
    // 0x802ACC54: nop

    after_2:
    // 0x802ACC58: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x802ACC5C: subu        $v1, $t9, $v0
    ctx->r3 = SUB32(ctx->r25, ctx->r2);
    // 0x802ACC60: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x802ACC64: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACC68: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACC6C: b           L_802ACD3C
    // 0x802ACC70: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
        goto L_802ACD3C;
    // 0x802ACC70: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
L_802ACC74:
    // 0x802ACC74: bltzl       $a1, L_802ACCE4
    if (SIGNED(ctx->r5) < 0) {
        // 0x802ACC78: lh          $t1, 0x1E($sp)
        ctx->r9 = MEM_H(ctx->r29, 0X1E);
            goto L_802ACCE4;
    }
    goto skip_6;
    // 0x802ACC78: lh          $t1, 0x1E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X1E);
    skip_6:
    // 0x802ACC7C: lh          $t4, 0x1E($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X1E);
    // 0x802ACC80: sll         $t3, $a2, 7
    ctx->r11 = S32(ctx->r6 << 7);
    // 0x802ACC84: div         $zero, $t3, $t4
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r12)));
    // 0x802ACC88: mflo        $a0
    ctx->r4 = lo;
    // 0x802ACC8C: addiu       $a0, $a0, 0x80
    ctx->r4 = ADD32(ctx->r4, 0X80);
    // 0x802ACC90: andi        $t5, $a0, 0xFF
    ctx->r13 = ctx->r4 & 0XFF;
    // 0x802ACC94: bne         $t4, $zero, L_802ACCA0
    if (ctx->r12 != 0) {
        // 0x802ACC98: nop
    
            goto L_802ACCA0;
    }
    // 0x802ACC98: nop

    // 0x802ACC9C: break       7
    do_break(2150288540);
L_802ACCA0:
    // 0x802ACCA0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ACCA4: bne         $t4, $at, L_802ACCB8
    if (ctx->r12 != ctx->r1) {
        // 0x802ACCA8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ACCB8;
    }
    // 0x802ACCA8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ACCAC: bne         $t3, $at, L_802ACCB8
    if (ctx->r11 != ctx->r1) {
        // 0x802ACCB0: nop
    
            goto L_802ACCB8;
    }
    // 0x802ACCB0: nop

    // 0x802ACCB4: break       6
    do_break(2150288564);
L_802ACCB8:
    // 0x802ACCB8: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x802ACCBC: jal         0x8012840C
    // 0x802ACCC0: nop

    func_8012840C(rdram, ctx);
        goto after_3;
    // 0x802ACCC0: nop

    after_3:
    // 0x802ACCC4: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x802ACCC8: subu        $v1, $t6, $v0
    ctx->r3 = SUB32(ctx->r14, ctx->r2);
    // 0x802ACCCC: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802ACCD0: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACCD4: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACCD8: b           L_802ACD3C
    // 0x802ACCDC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802ACD3C;
    // 0x802ACCDC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802ACCE0: lh          $t1, 0x1E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X1E);
L_802ACCE4:
    // 0x802ACCE4: sll         $t9, $a2, 7
    ctx->r25 = S32(ctx->r6 << 7);
    // 0x802ACCE8: div         $zero, $t9, $t1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r9))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r9)));
    // 0x802ACCEC: mflo        $a0
    ctx->r4 = lo;
    // 0x802ACCF0: addiu       $a0, $a0, 0x80
    ctx->r4 = ADD32(ctx->r4, 0X80);
    // 0x802ACCF4: andi        $t2, $a0, 0xFF
    ctx->r10 = ctx->r4 & 0XFF;
    // 0x802ACCF8: bne         $t1, $zero, L_802ACD04
    if (ctx->r9 != 0) {
        // 0x802ACCFC: nop
    
            goto L_802ACD04;
    }
    // 0x802ACCFC: nop

    // 0x802ACD00: break       7
    do_break(2150288640);
L_802ACD04:
    // 0x802ACD04: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802ACD08: bne         $t1, $at, L_802ACD1C
    if (ctx->r9 != ctx->r1) {
        // 0x802ACD0C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802ACD1C;
    }
    // 0x802ACD0C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802ACD10: bne         $t9, $at, L_802ACD1C
    if (ctx->r25 != ctx->r1) {
        // 0x802ACD14: nop
    
            goto L_802ACD1C;
    }
    // 0x802ACD14: nop

    // 0x802ACD18: break       6
    do_break(2150288664);
L_802ACD1C:
    // 0x802ACD1C: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x802ACD20: jal         0x8012840C
    // 0x802ACD24: nop

    func_8012840C(rdram, ctx);
        goto after_4;
    // 0x802ACD24: nop

    after_4:
    // 0x802ACD28: addiu       $v1, $v0, 0xC0
    ctx->r3 = ADD32(ctx->r2, 0XC0);
    // 0x802ACD2C: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x802ACD30: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ACD34: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ACD38: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
L_802ACD3C:
    // 0x802ACD3C: andi        $t5, $v1, 0xFF
    ctx->r13 = ctx->r3 & 0XFF;
    // 0x802ACD40: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACD44: sh          $t5, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r13;
    // 0x802ACD48: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
L_802ACD4C:
    // 0x802ACD4C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802ACD50: lwc1        $f18, 0x2C3C($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X2C3C);
    // 0x802ACD54: lui         $at, 0x42B4
    ctx->r1 = S32(0X42B4 << 16);
    // 0x802ACD58: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802ACD5C: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802ACD60: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802ACD64: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x802ACD68: lui         $at, 0x43B4
    ctx->r1 = S32(0X43B4 << 16);
    // 0x802ACD6C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x802ACD70: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ACD74: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802ACD78: addiu       $a2, $a2, 0x5570
    ctx->r6 = ADD32(ctx->r6, 0X5570);
    // 0x802ACD7C: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACD80: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802ACD84: div.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f16.fl);
    // 0x802ACD88: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x802ACD8C: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x802ACD90: nop

    // 0x802ACD94: andi        $t1, $t9, 0xFF
    ctx->r9 = ctx->r25 & 0XFF;
    // 0x802ACD98: sh          $t1, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r9;
    // 0x802ACD9C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ACDA0: beq         $a1, $v0, L_802ACE6C
    if (ctx->r5 == ctx->r2) {
        // 0x802ACDA4: nop
    
            goto L_802ACE6C;
    }
    // 0x802ACDA4: nop

    // 0x802ACDA8: lh          $t2, 0x5574($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X5574);
    // 0x802ACDAC: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x802ACDB0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x802ACDB4: beq         $t2, $zero, L_802ACDF0
    if (ctx->r10 == 0) {
        // 0x802ACDB8: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_802ACDF0;
    }
    // 0x802ACDB8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x802ACDBC: lh          $t3, 0x2A98($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X2A98);
    // 0x802ACDC0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x802ACDC4: addiu       $t5, $t5, 0x28E0
    ctx->r13 = ADD32(ctx->r13, 0X28E0);
    // 0x802ACDC8: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x802ACDCC: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x802ACDD0: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x802ACDD4: subu        $t4, $t4, $t3
    ctx->r12 = SUB32(ctx->r12, ctx->r11);
    // 0x802ACDD8: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x802ACDDC: addu        $a0, $t4, $t5
    ctx->r4 = ADD32(ctx->r12, ctx->r13);
    // 0x802ACDE0: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
    // 0x802ACDE4: addiu       $t0, $zero, 0x1A
    ctx->r8 = ADD32(0, 0X1A);
    // 0x802ACDE8: bne         $t0, $v1, L_802ACE18
    if (ctx->r8 != ctx->r3) {
        // 0x802ACDEC: nop
    
            goto L_802ACE18;
    }
    // 0x802ACDEC: nop

L_802ACDF0:
    // 0x802ACDF0: lh          $t6, 0x2A98($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2A98);
    // 0x802ACDF4: addiu       $t8, $t8, 0x28E0
    ctx->r24 = ADD32(ctx->r24, 0X28E0);
    // 0x802ACDF8: addiu       $t0, $zero, 0x1A
    ctx->r8 = ADD32(0, 0X1A);
    // 0x802ACDFC: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802ACE00: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802ACE04: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802ACE08: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802ACE0C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802ACE10: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    // 0x802ACE14: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
L_802ACE18:
    // 0x802ACE18: beq         $t0, $v1, L_802ACE34
    if (ctx->r8 == ctx->r3) {
        // 0x802ACE1C: addiu       $t3, $a3, 0x7FFF
        ctx->r11 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ACE34;
    }
    // 0x802ACE1C: addiu       $t3, $a3, 0x7FFF
    ctx->r11 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACE20: lh          $t9, 0x0($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X0);
    // 0x802ACE24: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACE28: addu        $t1, $v0, $t9
    ctx->r9 = ADD32(ctx->r2, ctx->r25);
    // 0x802ACE2C: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x802ACE30: sh          $t2, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r10;
L_802ACE34:
    // 0x802ACE34: bne         $t0, $v1, L_802ACE6C
    if (ctx->r8 != ctx->r3) {
        // 0x802ACE38: nop
    
            goto L_802ACE6C;
    }
    // 0x802ACE38: nop

    // 0x802ACE3C: lh          $t3, 0x7FA9($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X7FA9);
    // 0x802ACE40: lwc1        $f6, 0x20($a0)
    ctx->f6.u32l = MEM_W(ctx->r4, 0X20);
    // 0x802ACE44: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACE48: mtc1        $t3, $f8
    ctx->f8.u32l = ctx->r11;
    // 0x802ACE4C: nop

    // 0x802ACE50: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802ACE54: add.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x802ACE58: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802ACE5C: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x802ACE60: nop

    // 0x802ACE64: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802ACE68: sh          $t8, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r24;
L_802ACE6C:
    // 0x802ACE6C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x802ACE70: lh          $t9, 0x2A98($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2A98);
    // 0x802ACE74: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x802ACE78: addiu       $t0, $zero, 0x1A
    ctx->r8 = ADD32(0, 0X1A);
    // 0x802ACE7C: sll         $t1, $t9, 3
    ctx->r9 = S32(ctx->r25 << 3);
    // 0x802ACE80: subu        $t1, $t1, $t9
    ctx->r9 = SUB32(ctx->r9, ctx->r25);
    // 0x802ACE84: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x802ACE88: subu        $t1, $t1, $t9
    ctx->r9 = SUB32(ctx->r9, ctx->r25);
    // 0x802ACE8C: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x802ACE90: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x802ACE94: lh          $t2, 0x28E0($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X28E0);
    // 0x802ACE98: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACE9C: beql        $t0, $t2, L_802ACFC4
    if (ctx->r8 == ctx->r10) {
        // 0x802ACEA0: lh          $t1, 0x1E($sp)
        ctx->r9 = MEM_H(ctx->r29, 0X1E);
            goto L_802ACFC4;
    }
    goto skip_7;
    // 0x802ACEA0: lh          $t1, 0x1E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X1E);
    skip_7:
    // 0x802ACEA4: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ACEA8: beq         $a1, $v0, L_802ACFC0
    if (ctx->r5 == ctx->r2) {
        // 0x802ACEAC: slti        $at, $v0, 0x41
        ctx->r1 = SIGNED(ctx->r2) < 0X41 ? 1 : 0;
            goto L_802ACFC0;
    }
    // 0x802ACEAC: slti        $at, $v0, 0x41
    ctx->r1 = SIGNED(ctx->r2) < 0X41 ? 1 : 0;
    // 0x802ACEB0: beq         $at, $zero, L_802ACEF0
    if (ctx->r1 == 0) {
        // 0x802ACEB4: lui         $a2, 0x8015
        ctx->r6 = S32(0X8015 << 16);
            goto L_802ACEF0;
    }
    // 0x802ACEB4: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x802ACEB8: sll         $t5, $v0, 1
    ctx->r13 = S32(ctx->r2 << 1);
    // 0x802ACEBC: addiu       $t6, $t5, 0x40
    ctx->r14 = ADD32(ctx->r13, 0X40);
    // 0x802ACEC0: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802ACEC4: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802ACEC8: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x802ACECC: addu        $t9, $a2, $t8
    ctx->r25 = ADD32(ctx->r6, ctx->r24);
    // 0x802ACED0: lh          $t1, 0x0($t9)
    ctx->r9 = MEM_H(ctx->r25, 0X0);
    // 0x802ACED4: addiu       $t4, $zero, 0x20
    ctx->r12 = ADD32(0, 0X20);
    // 0x802ACED8: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACEDC: sra         $t2, $t1, 7
    ctx->r10 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802ACEE0: sra         $t3, $t2, 3
    ctx->r11 = S32(SIGNED(ctx->r10) >> 3);
    // 0x802ACEE4: subu        $t5, $t4, $t3
    ctx->r13 = SUB32(ctx->r12, ctx->r11);
    // 0x802ACEE8: b           L_802ACFC0
    // 0x802ACEEC: sh          $t5, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r13;
        goto L_802ACFC0;
    // 0x802ACEEC: sh          $t5, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r13;
L_802ACEF0:
    // 0x802ACEF0: slti        $at, $v0, 0x81
    ctx->r1 = SIGNED(ctx->r2) < 0X81 ? 1 : 0;
    // 0x802ACEF4: beq         $at, $zero, L_802ACF38
    if (ctx->r1 == 0) {
        // 0x802ACEF8: addiu       $t6, $v0, -0x40
        ctx->r14 = ADD32(ctx->r2, -0X40);
            goto L_802ACF38;
    }
    // 0x802ACEF8: addiu       $t6, $v0, -0x40
    ctx->r14 = ADD32(ctx->r2, -0X40);
    // 0x802ACEFC: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x802ACF00: addiu       $t1, $t9, 0x40
    ctx->r9 = ADD32(ctx->r25, 0X40);
    // 0x802ACF04: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x802ACF08: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x802ACF0C: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x802ACF10: sll         $t4, $t2, 1
    ctx->r12 = S32(ctx->r10 << 1);
    // 0x802ACF14: addu        $t3, $a2, $t4
    ctx->r11 = ADD32(ctx->r6, ctx->r12);
    // 0x802ACF18: lh          $t5, 0x0($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X0);
    // 0x802ACF1C: addiu       $t8, $zero, 0x60
    ctx->r24 = ADD32(0, 0X60);
    // 0x802ACF20: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACF24: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802ACF28: sra         $t7, $t6, 3
    ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
    // 0x802ACF2C: subu        $t9, $t8, $t7
    ctx->r25 = SUB32(ctx->r24, ctx->r15);
    // 0x802ACF30: b           L_802ACFC0
    // 0x802ACF34: sh          $t9, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r25;
        goto L_802ACFC0;
    // 0x802ACF34: sh          $t9, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r25;
L_802ACF38:
    // 0x802ACF38: slti        $at, $v0, 0xC1
    ctx->r1 = SIGNED(ctx->r2) < 0XC1 ? 1 : 0;
    // 0x802ACF3C: beq         $at, $zero, L_802ACF80
    if (ctx->r1 == 0) {
        // 0x802ACF40: addiu       $t1, $v0, -0x80
        ctx->r9 = ADD32(ctx->r2, -0X80);
            goto L_802ACF80;
    }
    // 0x802ACF40: addiu       $t1, $v0, -0x80
    ctx->r9 = ADD32(ctx->r2, -0X80);
    // 0x802ACF44: sll         $t3, $t1, 1
    ctx->r11 = S32(ctx->r9 << 1);
    // 0x802ACF48: addiu       $t5, $t3, 0x40
    ctx->r13 = ADD32(ctx->r11, 0X40);
    // 0x802ACF4C: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802ACF50: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x802ACF54: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x802ACF58: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802ACF5C: addu        $t7, $a2, $t8
    ctx->r15 = ADD32(ctx->r6, ctx->r24);
    // 0x802ACF60: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802ACF64: addiu       $t4, $zero, 0xA0
    ctx->r12 = ADD32(0, 0XA0);
    // 0x802ACF68: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACF6C: sra         $t1, $t9, 7
    ctx->r9 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802ACF70: sra         $t2, $t1, 3
    ctx->r10 = S32(SIGNED(ctx->r9) >> 3);
    // 0x802ACF74: subu        $t3, $t4, $t2
    ctx->r11 = SUB32(ctx->r12, ctx->r10);
    // 0x802ACF78: b           L_802ACFC0
    // 0x802ACF7C: sh          $t3, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r11;
        goto L_802ACFC0;
    // 0x802ACF7C: sh          $t3, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r11;
L_802ACF80:
    // 0x802ACF80: addiu       $t5, $v0, -0xC0
    ctx->r13 = ADD32(ctx->r2, -0XC0);
    // 0x802ACF84: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x802ACF88: addiu       $t9, $t7, 0x40
    ctx->r25 = ADD32(ctx->r15, 0X40);
    // 0x802ACF8C: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x802ACF90: andi        $t1, $t9, 0xFF
    ctx->r9 = ctx->r25 & 0XFF;
    // 0x802ACF94: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x802ACF98: sll         $t4, $t1, 1
    ctx->r12 = S32(ctx->r9 << 1);
    // 0x802ACF9C: addu        $t2, $a2, $t4
    ctx->r10 = ADD32(ctx->r6, ctx->r12);
    // 0x802ACFA0: lh          $t3, 0x0($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X0);
    // 0x802ACFA4: addiu       $t8, $zero, 0xE0
    ctx->r24 = ADD32(0, 0XE0);
    // 0x802ACFA8: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACFAC: sra         $t5, $t3, 7
    ctx->r13 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802ACFB0: sra         $t6, $t5, 3
    ctx->r14 = S32(SIGNED(ctx->r13) >> 3);
    // 0x802ACFB4: subu        $t7, $t8, $t6
    ctx->r15 = SUB32(ctx->r24, ctx->r14);
    // 0x802ACFB8: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802ACFBC: sh          $t9, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r25;
L_802ACFC0:
    // 0x802ACFC0: lh          $t1, 0x1E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X1E);
L_802ACFC4:
    // 0x802ACFC4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x802ACFC8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ACFCC: addiu       $v1, $v1, 0x2C28
    ctx->r3 = ADD32(ctx->r3, 0X2C28);
    // 0x802ACFD0: sh          $t1, 0x5574($at)
    MEM_H(0X5574, ctx->r1) = ctx->r9;
    // 0x802ACFD4: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x802ACFD8: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x802ACFDC: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x802ACFE0: blez        $v0, L_802AD000
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802ACFE4: addiu       $t4, $v0, -0x1
        ctx->r12 = ADD32(ctx->r2, -0X1);
            goto L_802AD000;
    }
    // 0x802ACFE4: addiu       $t4, $v0, -0x1
    ctx->r12 = ADD32(ctx->r2, -0X1);
    // 0x802ACFE8: sh          $t4, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r12;
    // 0x802ACFEC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ACFF0: sh          $zero, 0x5574($at)
    MEM_H(0X5574, ctx->r1) = 0;
    // 0x802ACFF4: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ACFF8: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    // 0x802ACFFC: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
L_802AD000:
    // 0x802AD000: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD004: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AD008: beq         $a1, $v0, L_802AD06C
    if (ctx->r5 == ctx->r2) {
        // 0x802AD00C: lui         $t2, 0x803D
        ctx->r10 = S32(0X803D << 16);
            goto L_802AD06C;
    }
    // 0x802AD00C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AD010: lh          $t2, 0x5534($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X5534);
    // 0x802AD014: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AD018: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x802AD01C: addu        $t5, $a3, $t3
    ctx->r13 = ADD32(ctx->r7, ctx->r11);
    // 0x802AD020: lw          $t8, 0x3EB4($t5)
    ctx->r24 = MEM_W(ctx->r13, 0X3EB4);
    // 0x802AD024: lh          $v1, 0x348($t8)
    ctx->r3 = MEM_H(ctx->r24, 0X348);
    // 0x802AD028: beq         $v1, $zero, L_802AD06C
    if (ctx->r3 == 0) {
        // 0x802AD02C: nop
    
            goto L_802AD06C;
    }
    // 0x802AD02C: nop

    // 0x802AD030: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x802AD034: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD038: sll         $t1, $t6, 2
    ctx->r9 = S32(ctx->r14 << 2);
    // 0x802AD03C: andi        $t4, $t1, 0xFF
    ctx->r12 = ctx->r9 & 0XFF;
    // 0x802AD040: sll         $t2, $t4, 1
    ctx->r10 = S32(ctx->r12 << 1);
    // 0x802AD044: addu        $t3, $a2, $t2
    ctx->r11 = ADD32(ctx->r6, ctx->r10);
    // 0x802AD048: lh          $t5, 0x0($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X0);
    // 0x802AD04C: sra         $t6, $v1, 2
    ctx->r14 = S32(SIGNED(ctx->r3) >> 2);
    // 0x802AD050: sra         $t8, $t5, 7
    ctx->r24 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802AD054: multu       $t8, $t6
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD058: mflo        $t7
    ctx->r15 = lo;
    // 0x802AD05C: sra         $t9, $t7, 10
    ctx->r25 = S32(SIGNED(ctx->r15) >> 10);
    // 0x802AD060: addu        $t1, $t9, $v0
    ctx->r9 = ADD32(ctx->r25, ctx->r2);
    // 0x802AD064: andi        $t4, $t1, 0xFF
    ctx->r12 = ctx->r9 & 0XFF;
    // 0x802AD068: sh          $t4, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r12;
L_802AD06C:
    // 0x802AD06C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AD070: lh          $t2, 0x5534($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X5534);
    // 0x802AD074: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x802AD078: addu        $a0, $a3, $t3
    ctx->r4 = ADD32(ctx->r7, ctx->r11);
    // 0x802AD07C: lw          $v1, 0x3EB4($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X3EB4);
    // 0x802AD080: lbu         $t5, 0x363($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X363);
    // 0x802AD084: beq         $t5, $zero, L_802AD0D8
    if (ctx->r13 == 0) {
        // 0x802AD088: addiu       $v0, $a3, 0x7FFF
        ctx->r2 = ADD32(ctx->r7, 0X7FFF);
            goto L_802AD0D8;
    }
    // 0x802AD088: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD08C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AD090: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AD094: beql        $a1, $v0, L_802AD0DC
    if (ctx->r5 == ctx->r2) {
        // 0x802AD098: lb          $t9, 0x4A($v1)
        ctx->r25 = MEM_B(ctx->r3, 0X4A);
            goto L_802AD0DC;
    }
    goto skip_8;
    // 0x802AD098: lb          $t9, 0x4A($v1)
    ctx->r25 = MEM_B(ctx->r3, 0X4A);
    skip_8:
    // 0x802AD09C: lh          $t8, 0x5540($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5540);
    // 0x802AD0A0: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802AD0A4: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802AD0A8: andi        $t1, $t9, 0xFF
    ctx->r9 = ctx->r25 & 0XFF;
    // 0x802AD0AC: sll         $t4, $t1, 1
    ctx->r12 = S32(ctx->r9 << 1);
    // 0x802AD0B0: addu        $t2, $a2, $t4
    ctx->r10 = ADD32(ctx->r6, ctx->r12);
    // 0x802AD0B4: lh          $t3, 0x0($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X0);
    // 0x802AD0B8: sra         $t5, $t3, 7
    ctx->r13 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802AD0BC: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x802AD0C0: mflo        $t8
    ctx->r24 = lo;
    // 0x802AD0C4: addu        $t6, $t8, $v0
    ctx->r14 = ADD32(ctx->r24, ctx->r2);
    // 0x802AD0C8: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802AD0CC: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD0D0: sh          $t7, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r15;
    // 0x802AD0D4: lw          $v1, 0x3EB4($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X3EB4);
L_802AD0D8:
    // 0x802AD0D8: lb          $t9, 0x4A($v1)
    ctx->r25 = MEM_B(ctx->r3, 0X4A);
L_802AD0DC:
    // 0x802AD0DC: beq         $t9, $zero, L_802AD0EC
    if (ctx->r25 == 0) {
        // 0x802AD0E0: addiu       $at, $a3, 0x7FFF
        ctx->r1 = ADD32(ctx->r7, 0X7FFF);
            goto L_802AD0EC;
    }
    // 0x802AD0E0: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD0E4: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
    // 0x802AD0E8: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
L_802AD0EC:
    // 0x802AD0EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AD0F0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802AD0F4: jr          $ra
    // 0x802AD0F8: nop

    return;
    // 0x802AD0F8: nop

;}
RECOMP_FUNC void func_802AD0FC_6BE7AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AD0FC: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802AD100: addiu       $v0, $v0, -0x6128
    ctx->r2 = ADD32(ctx->r2, -0X6128);
    // 0x802AD104: addiu       $a1, $v0, 0x7FFF
    ctx->r5 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD108: lb          $a1, 0x7FD9($a1)
    ctx->r5 = MEM_B(ctx->r5, 0X7FD9);
    // 0x802AD10C: addiu       $v1, $v0, 0x7FFF
    ctx->r3 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD110: lb          $v1, 0x7FDA($v1)
    ctx->r3 = MEM_B(ctx->r3, 0X7FDA);
    // 0x802AD114: bgezl       $a1, L_802AD128
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802AD118: or          $a0, $a1, $zero
        ctx->r4 = ctx->r5 | 0;
            goto L_802AD128;
    }
    goto skip_0;
    // 0x802AD118: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    skip_0:
    // 0x802AD11C: b           L_802AD128
    // 0x802AD120: negu        $a0, $a1
    ctx->r4 = SUB32(0, ctx->r5);
        goto L_802AD128;
    // 0x802AD120: negu        $a0, $a1
    ctx->r4 = SUB32(0, ctx->r5);
    // 0x802AD124: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
L_802AD128:
    // 0x802AD128: slti        $at, $a0, 0xB
    ctx->r1 = SIGNED(ctx->r4) < 0XB ? 1 : 0;
    // 0x802AD12C: beq         $at, $zero, L_802AD15C
    if (ctx->r1 == 0) {
        // 0x802AD130: lui         $a2, 0x803D
        ctx->r6 = S32(0X803D << 16);
            goto L_802AD15C;
    }
    // 0x802AD130: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AD134: lh          $a2, 0x5576($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X5576);
    // 0x802AD138: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802AD13C: addiu       $a0, $a2, -0x2
    ctx->r4 = ADD32(ctx->r6, -0X2);
    // 0x802AD140: blez        $a0, L_802AD154
    if (SIGNED(ctx->r4) <= 0) {
        // 0x802AD144: sll         $a2, $a0, 16
        ctx->r6 = S32(ctx->r4 << 16);
            goto L_802AD154;
    }
    // 0x802AD144: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x802AD148: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802AD14C: b           L_802AD1A8
    // 0x802AD150: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
        goto L_802AD1A8;
    // 0x802AD150: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
L_802AD154:
    // 0x802AD154: b           L_802AD1A8
    // 0x802AD158: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
        goto L_802AD1A8;
    // 0x802AD158: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_802AD15C:
    // 0x802AD15C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AD160: lh          $a2, 0x5576($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X5576);
    // 0x802AD164: addiu       $a0, $a2, 0x1
    ctx->r4 = ADD32(ctx->r6, 0X1);
    // 0x802AD168: slti        $at, $a0, 0xE
    ctx->r1 = SIGNED(ctx->r4) < 0XE ? 1 : 0;
    // 0x802AD16C: beq         $at, $zero, L_802AD184
    if (ctx->r1 == 0) {
        // 0x802AD170: addiu       $a2, $zero, 0xE
        ctx->r6 = ADD32(0, 0XE);
            goto L_802AD184;
    }
    // 0x802AD170: addiu       $a2, $zero, 0xE
    ctx->r6 = ADD32(0, 0XE);
    // 0x802AD174: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x802AD178: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802AD17C: b           L_802AD184
    // 0x802AD180: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
        goto L_802AD184;
    // 0x802AD180: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
L_802AD184:
    // 0x802AD184: blezl       $a1, L_802AD1A0
    if (SIGNED(ctx->r5) <= 0) {
        // 0x802AD188: addiu       $a1, $a1, 0xA
        ctx->r5 = ADD32(ctx->r5, 0XA);
            goto L_802AD1A0;
    }
    goto skip_1;
    // 0x802AD188: addiu       $a1, $a1, 0xA
    ctx->r5 = ADD32(ctx->r5, 0XA);
    skip_1:
    // 0x802AD18C: addiu       $a1, $a1, -0xA
    ctx->r5 = ADD32(ctx->r5, -0XA);
    // 0x802AD190: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802AD194: b           L_802AD1A8
    // 0x802AD198: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802AD1A8;
    // 0x802AD198: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802AD19C: addiu       $a1, $a1, 0xA
    ctx->r5 = ADD32(ctx->r5, 0XA);
L_802AD1A0:
    // 0x802AD1A0: sll         $t1, $a1, 16
    ctx->r9 = S32(ctx->r5 << 16);
    // 0x802AD1A4: sra         $a1, $t1, 16
    ctx->r5 = S32(SIGNED(ctx->r9) >> 16);
L_802AD1A8:
    // 0x802AD1A8: bgez        $v1, L_802AD1B8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AD1AC: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802AD1B8;
    }
    // 0x802AD1AC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AD1B0: b           L_802AD1BC
    // 0x802AD1B4: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_802AD1BC;
    // 0x802AD1B4: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_802AD1B8:
    // 0x802AD1B8: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_802AD1BC:
    // 0x802AD1BC: slti        $at, $a0, 0xB
    ctx->r1 = SIGNED(ctx->r4) < 0XB ? 1 : 0;
    // 0x802AD1C0: beq         $at, $zero, L_802AD1D0
    if (ctx->r1 == 0) {
        // 0x802AD1C4: nop
    
            goto L_802AD1D0;
    }
    // 0x802AD1C4: nop

    // 0x802AD1C8: b           L_802AD1F4
    // 0x802AD1CC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802AD1F4;
    // 0x802AD1CC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802AD1D0:
    // 0x802AD1D0: blezl       $v1, L_802AD1EC
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802AD1D4: addiu       $v1, $v1, 0xA
        ctx->r3 = ADD32(ctx->r3, 0XA);
            goto L_802AD1EC;
    }
    goto skip_2;
    // 0x802AD1D4: addiu       $v1, $v1, 0xA
    ctx->r3 = ADD32(ctx->r3, 0XA);
    skip_2:
    // 0x802AD1D8: addiu       $v1, $v1, -0xA
    ctx->r3 = ADD32(ctx->r3, -0XA);
    // 0x802AD1DC: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x802AD1E0: b           L_802AD1F4
    // 0x802AD1E4: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
        goto L_802AD1F4;
    // 0x802AD1E4: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802AD1E8: addiu       $v1, $v1, 0xA
    ctx->r3 = ADD32(ctx->r3, 0XA);
L_802AD1EC:
    // 0x802AD1EC: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802AD1F0: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
L_802AD1F4:
    // 0x802AD1F4: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AD1F8: addiu       $at, $zero, 0x2C
    ctx->r1 = ADD32(0, 0X2C);
    // 0x802AD1FC: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x802AD200: bne         $t8, $at, L_802AD244
    if (ctx->r24 != ctx->r1) {
        // 0x802AD204: nop
    
            goto L_802AD244;
    }
    // 0x802AD204: nop

    // 0x802AD208: multu       $a1, $a2
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD20C: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x802AD210: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AD214: addiu       $a0, $a0, 0x5548
    ctx->r4 = ADD32(ctx->r4, 0X5548);
    // 0x802AD218: lh          $t9, 0x0($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X0);
    // 0x802AD21C: mflo        $t1
    ctx->r9 = lo;
    // 0x802AD220: nop

    // 0x802AD224: nop

    // 0x802AD228: div         $zero, $t1, $at
    lo = S32(S64(S32(ctx->r9)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r9)) % S64(S32(ctx->r1)));
    // 0x802AD22C: mflo        $t2
    ctx->r10 = lo;
    // 0x802AD230: addu        $t3, $t9, $t2
    ctx->r11 = ADD32(ctx->r25, ctx->r10);
    // 0x802AD234: sh          $t3, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r11;
    // 0x802AD238: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD23C: b           L_802AD27C
    // 0x802AD240: sh          $a2, 0x5576($at)
    MEM_H(0X5576, ctx->r1) = ctx->r6;
        goto L_802AD27C;
    // 0x802AD240: sh          $a2, 0x5576($at)
    MEM_H(0X5576, ctx->r1) = ctx->r6;
L_802AD244:
    // 0x802AD244: multu       $a1, $a2
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD248: addiu       $at, $zero, 0xE
    ctx->r1 = ADD32(0, 0XE);
    // 0x802AD24C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AD250: addiu       $a0, $a0, 0x5548
    ctx->r4 = ADD32(ctx->r4, 0X5548);
    // 0x802AD254: lh          $t4, 0x0($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X0);
    // 0x802AD258: mflo        $t5
    ctx->r13 = lo;
    // 0x802AD25C: nop

    // 0x802AD260: nop

    // 0x802AD264: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x802AD268: mflo        $t6
    ctx->r14 = lo;
    // 0x802AD26C: addu        $t7, $t4, $t6
    ctx->r15 = ADD32(ctx->r12, ctx->r14);
    // 0x802AD270: sh          $t7, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r15;
    // 0x802AD274: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD278: sh          $a2, 0x5576($at)
    MEM_H(0X5576, ctx->r1) = ctx->r6;
L_802AD27C:
    // 0x802AD27C: lh          $a2, 0x0($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X0);
    // 0x802AD280: addiu       $t0, $v0, 0x7FFF
    ctx->r8 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD284: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
    // 0x802AD288: sra         $a3, $a2, 4
    ctx->r7 = S32(SIGNED(ctx->r6) >> 4);
    // 0x802AD28C: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802AD290: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802AD294: sll         $t9, $a3, 4
    ctx->r25 = S32(ctx->r7 << 4);
    // 0x802AD298: subu        $t2, $a2, $t9
    ctx->r10 = SUB32(ctx->r6, ctx->r25);
    // 0x802AD29C: sh          $t2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r10;
    // 0x802AD2A0: lh          $t0, 0x7FA9($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X7FA9);
    // 0x802AD2A4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AD2A8: bne         $a1, $t0, L_802AD2D4
    if (ctx->r5 != ctx->r8) {
        // 0x802AD2AC: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_802AD2D4;
    }
    // 0x802AD2AC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AD2B0: lh          $t3, 0x5534($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X5534);
    // 0x802AD2B4: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD2B8: addiu       $t0, $v0, 0x7FFF
    ctx->r8 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD2BC: sll         $t5, $t3, 3
    ctx->r13 = S32(ctx->r11 << 3);
    // 0x802AD2C0: addu        $t4, $v0, $t5
    ctx->r12 = ADD32(ctx->r2, ctx->r13);
    // 0x802AD2C4: lw          $t6, 0x3EB4($t4)
    ctx->r14 = MEM_W(ctx->r12, 0X3EB4);
    // 0x802AD2C8: lh          $t7, 0x2C($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X2C);
    // 0x802AD2CC: sh          $t7, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r15;
    // 0x802AD2D0: lh          $t0, 0x7FA9($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X7FA9);
L_802AD2D4:
    // 0x802AD2D4: addu        $t8, $t0, $a3
    ctx->r24 = ADD32(ctx->r8, ctx->r7);
    // 0x802AD2D8: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD2DC: sh          $t8, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r24;
    // 0x802AD2E0: lh          $t1, 0x5534($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5534);
    // 0x802AD2E4: addiu       $t0, $v0, 0x7FFF
    ctx->r8 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD2E8: lh          $t0, 0x7FA9($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X7FA9);
    // 0x802AD2EC: sll         $t9, $t1, 3
    ctx->r25 = S32(ctx->r9 << 3);
    // 0x802AD2F0: addu        $a2, $v0, $t9
    ctx->r6 = ADD32(ctx->r2, ctx->r25);
    // 0x802AD2F4: bgez        $t0, L_802AD310
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802AD2F8: lui         $a3, 0x803F
        ctx->r7 = S32(0X803F << 16);
            goto L_802AD310;
    }
    // 0x802AD2F8: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x802AD2FC: addiu       $t2, $t0, 0x100
    ctx->r10 = ADD32(ctx->r8, 0X100);
    // 0x802AD300: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD304: sh          $t2, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r10;
    // 0x802AD308: addiu       $t0, $v0, 0x7FFF
    ctx->r8 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD30C: lh          $t0, 0x7FA9($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X7FA9);
L_802AD310:
    // 0x802AD310: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x802AD314: bne         $at, $zero, L_802AD328
    if (ctx->r1 != 0) {
        // 0x802AD318: addiu       $a3, $a3, 0x2C28
        ctx->r7 = ADD32(ctx->r7, 0X2C28);
            goto L_802AD328;
    }
    // 0x802AD318: addiu       $a3, $a3, 0x2C28
    ctx->r7 = ADD32(ctx->r7, 0X2C28);
    // 0x802AD31C: addiu       $t3, $t0, -0x100
    ctx->r11 = ADD32(ctx->r8, -0X100);
    // 0x802AD320: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD324: sh          $t3, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r11;
L_802AD328:
    // 0x802AD328: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD32C: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    // 0x802AD330: slti        $at, $v1, 0x12
    ctx->r1 = SIGNED(ctx->r3) < 0X12 ? 1 : 0;
    // 0x802AD334: bne         $at, $zero, L_802AD348
    if (ctx->r1 != 0) {
        // 0x802AD338: addiu       $t0, $v0, 0x7FFF
        ctx->r8 = ADD32(ctx->r2, 0X7FFF);
            goto L_802AD348;
    }
    // 0x802AD338: addiu       $t0, $v0, 0x7FFF
    ctx->r8 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD33C: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802AD340: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD344: sh          $t5, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r13;
L_802AD348:
    // 0x802AD348: slti        $at, $v1, 0x1A
    ctx->r1 = SIGNED(ctx->r3) < 0X1A ? 1 : 0;
    // 0x802AD34C: bne         $at, $zero, L_802AD35C
    if (ctx->r1 != 0) {
        // 0x802AD350: addiu       $t4, $zero, 0x2
        ctx->r12 = ADD32(0, 0X2);
            goto L_802AD35C;
    }
    // 0x802AD350: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x802AD354: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD358: sh          $t4, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r12;
L_802AD35C:
    // 0x802AD35C: slti        $at, $v1, 0x26
    ctx->r1 = SIGNED(ctx->r3) < 0X26 ? 1 : 0;
    // 0x802AD360: bne         $at, $zero, L_802AD370
    if (ctx->r1 != 0) {
        // 0x802AD364: addiu       $t6, $zero, 0x3
        ctx->r14 = ADD32(0, 0X3);
            goto L_802AD370;
    }
    // 0x802AD364: addiu       $t6, $zero, 0x3
    ctx->r14 = ADD32(0, 0X3);
    // 0x802AD368: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD36C: sh          $t6, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r14;
L_802AD370:
    // 0x802AD370: slti        $at, $v1, 0x38
    ctx->r1 = SIGNED(ctx->r3) < 0X38 ? 1 : 0;
    // 0x802AD374: bne         $at, $zero, L_802AD384
    if (ctx->r1 != 0) {
        // 0x802AD378: addiu       $t7, $zero, 0x4
        ctx->r15 = ADD32(0, 0X4);
            goto L_802AD384;
    }
    // 0x802AD378: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x802AD37C: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD380: sh          $t7, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r15;
L_802AD384:
    // 0x802AD384: slti        $at, $v1, -0x11
    ctx->r1 = SIGNED(ctx->r3) < -0X11 ? 1 : 0;
    // 0x802AD388: beq         $at, $zero, L_802AD398
    if (ctx->r1 == 0) {
        // 0x802AD38C: addiu       $t8, $zero, -0x1
        ctx->r24 = ADD32(0, -0X1);
            goto L_802AD398;
    }
    // 0x802AD38C: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x802AD390: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD394: sh          $t8, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r24;
L_802AD398:
    // 0x802AD398: slti        $at, $v1, -0x19
    ctx->r1 = SIGNED(ctx->r3) < -0X19 ? 1 : 0;
    // 0x802AD39C: beq         $at, $zero, L_802AD3AC
    if (ctx->r1 == 0) {
        // 0x802AD3A0: addiu       $t1, $zero, -0x2
        ctx->r9 = ADD32(0, -0X2);
            goto L_802AD3AC;
    }
    // 0x802AD3A0: addiu       $t1, $zero, -0x2
    ctx->r9 = ADD32(0, -0X2);
    // 0x802AD3A4: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD3A8: sh          $t1, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r9;
L_802AD3AC:
    // 0x802AD3AC: slti        $at, $v1, -0x25
    ctx->r1 = SIGNED(ctx->r3) < -0X25 ? 1 : 0;
    // 0x802AD3B0: beq         $at, $zero, L_802AD3C0
    if (ctx->r1 == 0) {
        // 0x802AD3B4: addiu       $t9, $zero, -0x3
        ctx->r25 = ADD32(0, -0X3);
            goto L_802AD3C0;
    }
    // 0x802AD3B4: addiu       $t9, $zero, -0x3
    ctx->r25 = ADD32(0, -0X3);
    // 0x802AD3B8: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD3BC: sh          $t9, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r25;
L_802AD3C0:
    // 0x802AD3C0: slti        $at, $v1, -0x37
    ctx->r1 = SIGNED(ctx->r3) < -0X37 ? 1 : 0;
    // 0x802AD3C4: beq         $at, $zero, L_802AD3D4
    if (ctx->r1 == 0) {
        // 0x802AD3C8: addiu       $t2, $zero, -0x4
        ctx->r10 = ADD32(0, -0X4);
            goto L_802AD3D4;
    }
    // 0x802AD3C8: addiu       $t2, $zero, -0x4
    ctx->r10 = ADD32(0, -0X4);
    // 0x802AD3CC: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD3D0: sh          $t2, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r10;
L_802AD3D4:
    // 0x802AD3D4: lh          $v1, 0x0($a3)
    ctx->r3 = MEM_H(ctx->r7, 0X0);
    // 0x802AD3D8: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD3DC: blez        $v1, L_802AD3F0
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802AD3E0: addiu       $t3, $v1, -0x1
        ctx->r11 = ADD32(ctx->r3, -0X1);
            goto L_802AD3F0;
    }
    // 0x802AD3E0: addiu       $t3, $v1, -0x1
    ctx->r11 = ADD32(ctx->r3, -0X1);
    // 0x802AD3E4: sh          $t3, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r11;
    // 0x802AD3E8: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    // 0x802AD3EC: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
L_802AD3F0:
    // 0x802AD3F0: lh          $t0, 0x7FA9($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X7FA9);
    // 0x802AD3F4: beql        $a1, $t0, L_802AD44C
    if (ctx->r5 == ctx->r8) {
        // 0x802AD3F8: lw          $v1, 0x3EB4($a2)
        ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
            goto L_802AD44C;
    }
    goto skip_3;
    // 0x802AD3F8: lw          $v1, 0x3EB4($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
    skip_3:
    // 0x802AD3FC: lw          $t5, 0x3EB4($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X3EB4);
    // 0x802AD400: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AD404: lh          $v1, 0x348($t5)
    ctx->r3 = MEM_H(ctx->r13, 0X348);
    // 0x802AD408: beql        $v1, $zero, L_802AD44C
    if (ctx->r3 == 0) {
        // 0x802AD40C: lw          $v1, 0x3EB4($a2)
        ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
            goto L_802AD44C;
    }
    goto skip_4;
    // 0x802AD40C: lw          $v1, 0x3EB4($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
    skip_4:
    // 0x802AD410: lh          $t4, 0x5540($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X5540);
    // 0x802AD414: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802AD418: lh          $t6, 0x0($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X0);
    // 0x802AD41C: sll         $t8, $t4, 2
    ctx->r24 = S32(ctx->r12 << 2);
    // 0x802AD420: andi        $t1, $t8, 0xFF
    ctx->r9 = ctx->r24 & 0XFF;
    // 0x802AD424: sll         $t9, $t1, 1
    ctx->r25 = S32(ctx->r9 << 1);
    // 0x802AD428: addu        $t2, $t2, $t9
    ctx->r10 = ADD32(ctx->r10, ctx->r25);
    // 0x802AD42C: lh          $t2, 0x2C78($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2C78);
    // 0x802AD430: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802AD434: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD438: mflo        $t5
    ctx->r13 = lo;
    // 0x802AD43C: sra         $t4, $t5, 13
    ctx->r12 = S32(SIGNED(ctx->r13) >> 13);
    // 0x802AD440: addu        $t7, $t4, $t6
    ctx->r15 = ADD32(ctx->r12, ctx->r14);
    // 0x802AD444: sh          $t7, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r15;
    // 0x802AD448: lw          $v1, 0x3EB4($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
L_802AD44C:
    // 0x802AD44C: lbu         $t8, 0x363($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X363);
    // 0x802AD450: beql        $t8, $zero, L_802AD480
    if (ctx->r24 == 0) {
        // 0x802AD454: lb          $t5, 0x4A($v1)
        ctx->r13 = MEM_B(ctx->r3, 0X4A);
            goto L_802AD480;
    }
    goto skip_5;
    // 0x802AD454: lb          $t5, 0x4A($v1)
    ctx->r13 = MEM_B(ctx->r3, 0X4A);
    skip_5:
    // 0x802AD458: beq         $a1, $t0, L_802AD47C
    if (ctx->r5 == ctx->r8) {
        // 0x802AD45C: lui         $t1, 0x803D
        ctx->r9 = S32(0X803D << 16);
            goto L_802AD47C;
    }
    // 0x802AD45C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AD460: lh          $t1, 0x5540($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5540);
    // 0x802AD464: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD468: sll         $t9, $t1, 1
    ctx->r25 = S32(ctx->r9 << 1);
    // 0x802AD46C: addu        $t2, $t0, $t9
    ctx->r10 = ADD32(ctx->r8, ctx->r25);
    // 0x802AD470: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x802AD474: sh          $t3, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r11;
    // 0x802AD478: lw          $v1, 0x3EB4($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X3EB4);
L_802AD47C:
    // 0x802AD47C: lb          $t5, 0x4A($v1)
    ctx->r13 = MEM_B(ctx->r3, 0X4A);
L_802AD480:
    // 0x802AD480: addiu       $at, $v0, 0x7FFF
    ctx->r1 = ADD32(ctx->r2, 0X7FFF);
    // 0x802AD484: beq         $t5, $zero, L_802AD494
    if (ctx->r13 == 0) {
        // 0x802AD488: nop
    
            goto L_802AD494;
    }
    // 0x802AD488: nop

    // 0x802AD48C: sh          $a1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r5;
    // 0x802AD490: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
L_802AD494:
    // 0x802AD494: jr          $ra
    // 0x802AD498: nop

    return;
    // 0x802AD498: nop

;}
RECOMP_FUNC void func_802AD49C_6BEB4C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AD49C: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802AD4A0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x802AD4A4: lh          $t6, 0x2D34($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2D34);
    // 0x802AD4A8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802AD4AC: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD4B0: addiu       $v1, $a3, 0x7FFF
    ctx->r3 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD4B4: lb          $v0, 0x7FD9($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7FD9);
    // 0x802AD4B8: beq         $t6, $zero, L_802AD4C8
    if (ctx->r14 == 0) {
        // 0x802AD4BC: lb          $v1, 0x7FDA($v1)
        ctx->r3 = MEM_B(ctx->r3, 0X7FDA);
            goto L_802AD4C8;
    }
    // 0x802AD4BC: lb          $v1, 0x7FDA($v1)
    ctx->r3 = MEM_B(ctx->r3, 0X7FDA);
    // 0x802AD4C0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x802AD4C4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802AD4C8:
    // 0x802AD4C8: bgez        $v0, L_802AD4D8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AD4CC: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802AD4D8;
    }
    // 0x802AD4CC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802AD4D0: b           L_802AD4D8
    // 0x802AD4D4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802AD4D8;
    // 0x802AD4D4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802AD4D8:
    // 0x802AD4D8: slti        $at, $a0, 0xB
    ctx->r1 = SIGNED(ctx->r4) < 0XB ? 1 : 0;
    // 0x802AD4DC: beq         $at, $zero, L_802AD510
    if (ctx->r1 == 0) {
        // 0x802AD4E0: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802AD510;
    }
    // 0x802AD4E0: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802AD4E4: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802AD4E8: lh          $a1, 0x5578($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X5578);
    // 0x802AD4EC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802AD4F0: addiu       $a0, $a1, -0x2
    ctx->r4 = ADD32(ctx->r5, -0X2);
    // 0x802AD4F4: blez        $a0, L_802AD508
    if (SIGNED(ctx->r4) <= 0) {
        // 0x802AD4F8: sll         $a1, $a0, 16
        ctx->r5 = S32(ctx->r4 << 16);
            goto L_802AD508;
    }
    // 0x802AD4F8: sll         $a1, $a0, 16
    ctx->r5 = S32(ctx->r4 << 16);
    // 0x802AD4FC: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802AD500: b           L_802AD558
    // 0x802AD504: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
        goto L_802AD558;
    // 0x802AD504: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
L_802AD508:
    // 0x802AD508: b           L_802AD558
    // 0x802AD50C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
        goto L_802AD558;
    // 0x802AD50C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_802AD510:
    // 0x802AD510: lh          $a1, 0x5578($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X5578);
    // 0x802AD514: addiu       $a0, $a1, 0x1
    ctx->r4 = ADD32(ctx->r5, 0X1);
    // 0x802AD518: slti        $at, $a0, 0xE
    ctx->r1 = SIGNED(ctx->r4) < 0XE ? 1 : 0;
    // 0x802AD51C: beq         $at, $zero, L_802AD534
    if (ctx->r1 == 0) {
        // 0x802AD520: addiu       $a1, $zero, 0xE
        ctx->r5 = ADD32(0, 0XE);
            goto L_802AD534;
    }
    // 0x802AD520: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x802AD524: sll         $a1, $a0, 16
    ctx->r5 = S32(ctx->r4 << 16);
    // 0x802AD528: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802AD52C: b           L_802AD534
    // 0x802AD530: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
        goto L_802AD534;
    // 0x802AD530: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
L_802AD534:
    // 0x802AD534: blezl       $v0, L_802AD550
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AD538: addiu       $v0, $v0, 0xA
        ctx->r2 = ADD32(ctx->r2, 0XA);
            goto L_802AD550;
    }
    goto skip_0;
    // 0x802AD538: addiu       $v0, $v0, 0xA
    ctx->r2 = ADD32(ctx->r2, 0XA);
    skip_0:
    // 0x802AD53C: addiu       $v0, $v0, -0xA
    ctx->r2 = ADD32(ctx->r2, -0XA);
    // 0x802AD540: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802AD544: b           L_802AD558
    // 0x802AD548: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
        goto L_802AD558;
    // 0x802AD548: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802AD54C: addiu       $v0, $v0, 0xA
    ctx->r2 = ADD32(ctx->r2, 0XA);
L_802AD550:
    // 0x802AD550: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x802AD554: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
L_802AD558:
    // 0x802AD558: bgez        $v1, L_802AD568
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AD55C: nop
    
            goto L_802AD568;
    }
    // 0x802AD55C: nop

    // 0x802AD560: b           L_802AD568
    // 0x802AD564: nop

        goto L_802AD568;
    // 0x802AD564: nop

L_802AD568:
    // 0x802AD568: multu       $v0, $a1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD56C: addiu       $at, $zero, 0x1C
    ctx->r1 = ADD32(0, 0X1C);
    // 0x802AD570: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AD574: addiu       $t0, $t0, 0x5548
    ctx->r8 = ADD32(ctx->r8, 0X5548);
    // 0x802AD578: lh          $t4, 0x0($t0)
    ctx->r12 = MEM_H(ctx->r8, 0X0);
    // 0x802AD57C: addiu       $t3, $a3, 0x7FFF
    ctx->r11 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD580: addiu       $a2, $a3, 0x7FFF
    ctx->r6 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD584: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x802AD588: mflo        $t5
    ctx->r13 = lo;
    // 0x802AD58C: nop

    // 0x802AD590: nop

    // 0x802AD594: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x802AD598: mflo        $t6
    ctx->r14 = lo;
    // 0x802AD59C: addu        $t7, $t4, $t6
    ctx->r15 = ADD32(ctx->r12, ctx->r14);
    // 0x802AD5A0: sh          $t7, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r15;
    // 0x802AD5A4: lh          $v1, 0x0($t0)
    ctx->r3 = MEM_H(ctx->r8, 0X0);
    // 0x802AD5A8: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD5AC: sra         $t9, $v1, 4
    ctx->r25 = S32(SIGNED(ctx->r3) >> 4);
    // 0x802AD5B0: sll         $t1, $t9, 4
    ctx->r9 = S32(ctx->r25 << 4);
    // 0x802AD5B4: subu        $t2, $v1, $t1
    ctx->r10 = SUB32(ctx->r3, ctx->r9);
    // 0x802AD5B8: sh          $t2, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r10;
    // 0x802AD5BC: lh          $t3, 0x7FA9($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X7FA9);
    // 0x802AD5C0: addu        $t5, $t3, $t9
    ctx->r13 = ADD32(ctx->r11, ctx->r25);
    // 0x802AD5C4: sh          $t5, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r13;
    // 0x802AD5C8: lh          $a2, 0x7FA9($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X7FA9);
    // 0x802AD5CC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD5D0: sh          $a1, 0x5578($at)
    MEM_H(0X5578, ctx->r1) = ctx->r5;
    // 0x802AD5D4: bgez        $a2, L_802AD5EC
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802AD5D8: addiu       $t4, $a2, 0x100
        ctx->r12 = ADD32(ctx->r6, 0X100);
            goto L_802AD5EC;
    }
    // 0x802AD5D8: addiu       $t4, $a2, 0x100
    ctx->r12 = ADD32(ctx->r6, 0X100);
    // 0x802AD5DC: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD5E0: sh          $t4, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r12;
    // 0x802AD5E4: addiu       $a2, $a3, 0x7FFF
    ctx->r6 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD5E8: lh          $a2, 0x7FA9($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X7FA9);
L_802AD5EC:
    // 0x802AD5EC: slti        $at, $a2, 0x100
    ctx->r1 = SIGNED(ctx->r6) < 0X100 ? 1 : 0;
    // 0x802AD5F0: bne         $at, $zero, L_802AD600
    if (ctx->r1 != 0) {
        // 0x802AD5F4: addiu       $t6, $a2, -0x100
        ctx->r14 = ADD32(ctx->r6, -0X100);
            goto L_802AD600;
    }
    // 0x802AD5F4: addiu       $t6, $a2, -0x100
    ctx->r14 = ADD32(ctx->r6, -0X100);
    // 0x802AD5F8: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD5FC: sh          $t6, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r14;
L_802AD600:
    // 0x802AD600: lw          $v0, 0x10D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X10D0);
    // 0x802AD604: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD608: beql        $v0, $zero, L_802AD634
    if (ctx->r2 == 0) {
        // 0x802AD60C: sh          $zero, 0x7FDB($at)
        MEM_H(0X7FDB, ctx->r1) = 0;
            goto L_802AD634;
    }
    goto skip_1;
    // 0x802AD60C: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    skip_1:
    // 0x802AD610: lhu         $t7, 0x0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X0);
    // 0x802AD614: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x802AD618: andi        $t8, $t7, 0x8000
    ctx->r24 = ctx->r15 & 0X8000;
    // 0x802AD61C: beql        $t8, $zero, L_802AD634
    if (ctx->r24 == 0) {
        // 0x802AD620: sh          $zero, 0x7FDB($at)
        MEM_H(0X7FDB, ctx->r1) = 0;
            goto L_802AD634;
    }
    goto skip_2;
    // 0x802AD620: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    skip_2:
    // 0x802AD624: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD628: jr          $ra
    // 0x802AD62C: sh          $t9, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r25;
    return;
    // 0x802AD62C: sh          $t9, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = ctx->r25;
    // 0x802AD630: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
L_802AD634:
    // 0x802AD634: jr          $ra
    // 0x802AD638: nop

    return;
    // 0x802AD638: nop

;}
RECOMP_FUNC void func_802AD63C_6BECEC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AD63C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802AD640: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802AD644: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD648: sh          $zero, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = 0;
    // 0x802AD64C: addiu       $v0, $a0, 0x7FFF
    ctx->r2 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD650: lb          $v0, 0x7FD9($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7FD9);
    // 0x802AD654: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AD658: addiu       $t8, $a0, 0x7FFF
    ctx->r24 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD65C: slti        $at, $v0, -0x11
    ctx->r1 = SIGNED(ctx->r2) < -0X11 ? 1 : 0;
    // 0x802AD660: beq         $at, $zero, L_802AD6EC
    if (ctx->r1 == 0) {
        // 0x802AD664: sll         $t6, $v0, 6
        ctx->r14 = S32(ctx->r2 << 6);
            goto L_802AD6EC;
    }
    // 0x802AD664: sll         $t6, $v0, 6
    ctx->r14 = S32(ctx->r2 << 6);
    // 0x802AD668: addiu       $at, $zero, 0x37
    ctx->r1 = ADD32(0, 0X37);
    // 0x802AD66C: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x802AD670: lh          $v1, 0x557A($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X557A);
    // 0x802AD674: mflo        $t7
    ctx->r15 = lo;
    // 0x802AD678: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD67C: sh          $t7, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r15;
    // 0x802AD680: lh          $t8, 0x7FDD($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X7FDD);
    // 0x802AD684: addiu       $at, $zero, 0xE
    ctx->r1 = ADD32(0, 0XE);
    // 0x802AD688: addiu       $t1, $a0, 0x7FFF
    ctx->r9 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD68C: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD690: addiu       $v0, $v1, 0x1
    ctx->r2 = ADD32(ctx->r3, 0X1);
    // 0x802AD694: addiu       $t2, $zero, -0x40
    ctx->r10 = ADD32(0, -0X40);
    // 0x802AD698: addiu       $v1, $zero, 0xE
    ctx->r3 = ADD32(0, 0XE);
    // 0x802AD69C: mflo        $t9
    ctx->r25 = lo;
    // 0x802AD6A0: nop

    // 0x802AD6A4: nop

    // 0x802AD6A8: div         $zero, $t9, $at
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r1)));
    // 0x802AD6AC: mflo        $t0
    ctx->r8 = lo;
    // 0x802AD6B0: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD6B4: sh          $t0, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r8;
    // 0x802AD6B8: lh          $t1, 0x7FDD($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X7FDD);
    // 0x802AD6BC: slti        $at, $t1, -0x40
    ctx->r1 = SIGNED(ctx->r9) < -0X40 ? 1 : 0;
    // 0x802AD6C0: beq         $at, $zero, L_802AD6CC
    if (ctx->r1 == 0) {
        // 0x802AD6C4: addiu       $at, $a0, 0x7FFF
        ctx->r1 = ADD32(ctx->r4, 0X7FFF);
            goto L_802AD6CC;
    }
    // 0x802AD6C4: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD6C8: sh          $t2, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r10;
L_802AD6CC:
    // 0x802AD6CC: slti        $at, $v0, 0xE
    ctx->r1 = SIGNED(ctx->r2) < 0XE ? 1 : 0;
    // 0x802AD6D0: beq         $at, $zero, L_802AD6E0
    if (ctx->r1 == 0) {
        // 0x802AD6D4: lui         $at, 0x803D
        ctx->r1 = S32(0X803D << 16);
            goto L_802AD6E0;
    }
    // 0x802AD6D4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD6D8: b           L_802AD7AC
    // 0x802AD6DC: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
        goto L_802AD7AC;
    // 0x802AD6DC: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
L_802AD6E0:
    // 0x802AD6E0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD6E4: b           L_802AD7AC
    // 0x802AD6E8: sh          $v1, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r3;
        goto L_802AD7AC;
    // 0x802AD6E8: sh          $v1, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r3;
L_802AD6EC:
    // 0x802AD6EC: slti        $at, $v0, 0x12
    ctx->r1 = SIGNED(ctx->r2) < 0X12 ? 1 : 0;
    // 0x802AD6F0: bne         $at, $zero, L_802AD788
    if (ctx->r1 != 0) {
        // 0x802AD6F4: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802AD788;
    }
    // 0x802AD6F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AD6F8: sll         $t4, $v0, 6
    ctx->r12 = S32(ctx->r2 << 6);
    // 0x802AD6FC: addiu       $at, $zero, 0x37
    ctx->r1 = ADD32(0, 0X37);
    // 0x802AD700: div         $zero, $t4, $at
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r1)));
    // 0x802AD704: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AD708: lh          $v1, 0x557A($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X557A);
    // 0x802AD70C: mflo        $t5
    ctx->r13 = lo;
    // 0x802AD710: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD714: sh          $t5, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r13;
    // 0x802AD718: addiu       $t6, $a0, 0x7FFF
    ctx->r14 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD71C: lh          $t6, 0x7FDD($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X7FDD);
    // 0x802AD720: addiu       $at, $zero, 0xE
    ctx->r1 = ADD32(0, 0XE);
    // 0x802AD724: addiu       $t9, $a0, 0x7FFF
    ctx->r25 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD728: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AD72C: addiu       $v0, $v1, 0x1
    ctx->r2 = ADD32(ctx->r3, 0X1);
    // 0x802AD730: addiu       $t0, $zero, 0x40
    ctx->r8 = ADD32(0, 0X40);
    // 0x802AD734: addiu       $v1, $zero, 0xE
    ctx->r3 = ADD32(0, 0XE);
    // 0x802AD738: mflo        $t7
    ctx->r15 = lo;
    // 0x802AD73C: nop

    // 0x802AD740: nop

    // 0x802AD744: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x802AD748: mflo        $t8
    ctx->r24 = lo;
    // 0x802AD74C: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD750: sh          $t8, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r24;
    // 0x802AD754: lh          $t9, 0x7FDD($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X7FDD);
    // 0x802AD758: slti        $at, $t9, 0x41
    ctx->r1 = SIGNED(ctx->r25) < 0X41 ? 1 : 0;
    // 0x802AD75C: bne         $at, $zero, L_802AD768
    if (ctx->r1 != 0) {
        // 0x802AD760: addiu       $at, $a0, 0x7FFF
        ctx->r1 = ADD32(ctx->r4, 0X7FFF);
            goto L_802AD768;
    }
    // 0x802AD760: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD764: sh          $t0, 0x7FDD($at)
    MEM_H(0X7FDD, ctx->r1) = ctx->r8;
L_802AD768:
    // 0x802AD768: slti        $at, $v0, 0xE
    ctx->r1 = SIGNED(ctx->r2) < 0XE ? 1 : 0;
    // 0x802AD76C: beq         $at, $zero, L_802AD77C
    if (ctx->r1 == 0) {
        // 0x802AD770: lui         $at, 0x803D
        ctx->r1 = S32(0X803D << 16);
            goto L_802AD77C;
    }
    // 0x802AD770: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD774: b           L_802AD7AC
    // 0x802AD778: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
        goto L_802AD7AC;
    // 0x802AD778: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
L_802AD77C:
    // 0x802AD77C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD780: b           L_802AD7AC
    // 0x802AD784: sh          $v1, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r3;
        goto L_802AD7AC;
    // 0x802AD784: sh          $v1, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r3;
L_802AD788:
    // 0x802AD788: lh          $v1, 0x557A($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X557A);
    // 0x802AD78C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD790: addiu       $v0, $v1, -0x2
    ctx->r2 = ADD32(ctx->r3, -0X2);
    // 0x802AD794: blez        $v0, L_802AD7A8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AD798: nop
    
            goto L_802AD7A8;
    }
    // 0x802AD798: nop

    // 0x802AD79C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD7A0: b           L_802AD7AC
    // 0x802AD7A4: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
        goto L_802AD7AC;
    // 0x802AD7A4: sh          $v0, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = ctx->r2;
L_802AD7A8:
    // 0x802AD7A8: sh          $zero, 0x557A($at)
    MEM_H(0X557A, ctx->r1) = 0;
L_802AD7AC:
    // 0x802AD7AC: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD7B0: sh          $zero, 0x7FDF($at)
    MEM_H(0X7FDF, ctx->r1) = 0;
    // 0x802AD7B4: addiu       $v0, $a0, 0x7FFF
    ctx->r2 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD7B8: lb          $v0, 0x7FDA($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X7FDA);
    // 0x802AD7BC: addiu       $t3, $zero, -0x11
    ctx->r11 = ADD32(0, -0X11);
    // 0x802AD7C0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AD7C4: slti        $at, $v0, -0x11
    ctx->r1 = SIGNED(ctx->r2) < -0X11 ? 1 : 0;
    // 0x802AD7C8: beq         $at, $zero, L_802AD7E0
    if (ctx->r1 == 0) {
        // 0x802AD7CC: subu        $t4, $t3, $v0
        ctx->r12 = SUB32(ctx->r11, ctx->r2);
            goto L_802AD7E0;
    }
    // 0x802AD7CC: subu        $t4, $t3, $v0
    ctx->r12 = SUB32(ctx->r11, ctx->r2);
    // 0x802AD7D0: sra         $t5, $t4, 1
    ctx->r13 = S32(SIGNED(ctx->r12) >> 1);
    // 0x802AD7D4: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD7D8: b           L_802AD7FC
    // 0x802AD7DC: sh          $t5, 0x7FDF($at)
    MEM_H(0X7FDF, ctx->r1) = ctx->r13;
        goto L_802AD7FC;
    // 0x802AD7DC: sh          $t5, 0x7FDF($at)
    MEM_H(0X7FDF, ctx->r1) = ctx->r13;
L_802AD7E0:
    // 0x802AD7E0: slti        $at, $v0, 0x12
    ctx->r1 = SIGNED(ctx->r2) < 0X12 ? 1 : 0;
    // 0x802AD7E4: bne         $at, $zero, L_802AD7FC
    if (ctx->r1 != 0) {
        // 0x802AD7E8: addiu       $t6, $zero, 0x11
        ctx->r14 = ADD32(0, 0X11);
            goto L_802AD7FC;
    }
    // 0x802AD7E8: addiu       $t6, $zero, 0x11
    ctx->r14 = ADD32(0, 0X11);
    // 0x802AD7EC: subu        $t7, $t6, $v0
    ctx->r15 = SUB32(ctx->r14, ctx->r2);
    // 0x802AD7F0: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802AD7F4: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD7F8: sh          $t8, 0x7FDF($at)
    MEM_H(0X7FDF, ctx->r1) = ctx->r24;
L_802AD7FC:
    // 0x802AD7FC: lh          $t9, 0x5534($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5534);
    // 0x802AD800: addiu       $at, $zero, 0xDD
    ctx->r1 = ADD32(0, 0XDD);
    // 0x802AD804: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802AD808: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x802AD80C: addu        $t1, $a0, $t0
    ctx->r9 = ADD32(ctx->r4, ctx->r8);
    // 0x802AD810: lw          $t2, 0x3EB4($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X3EB4);
    // 0x802AD814: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AD818: addiu       $t8, $a0, 0x7FFF
    ctx->r24 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD81C: lhu         $t3, 0x0($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X0);
    // 0x802AD820: bnel        $t3, $at, L_802AD864
    if (ctx->r11 != ctx->r1) {
        // 0x802AD824: lh          $t8, 0x7FA9($t8)
        ctx->r24 = MEM_H(ctx->r24, 0X7FA9);
            goto L_802AD864;
    }
    goto skip_0;
    // 0x802AD824: lh          $t8, 0x7FA9($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X7FA9);
    skip_0:
    // 0x802AD828: lh          $t4, 0x2A98($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2A98);
    // 0x802AD82C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802AD830: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x802AD834: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802AD838: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802AD83C: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802AD840: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802AD844: addu        $at, $at, $t5
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x802AD848: lwc1        $f4, 0x2900($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X2900);
    // 0x802AD84C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD850: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802AD854: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x802AD858: nop

    // 0x802AD85C: sh          $t7, 0x5570($at)
    MEM_H(0X5570, ctx->r1) = ctx->r15;
    // 0x802AD860: lh          $t8, 0x7FA9($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X7FA9);
L_802AD864:
    // 0x802AD864: lh          $t9, 0x5570($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5570);
    // 0x802AD868: addiu       $at, $a0, 0x7FFF
    ctx->r1 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AD86C: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x802AD870: andi        $t1, $t0, 0xFF
    ctx->r9 = ctx->r8 & 0XFF;
    // 0x802AD874: jr          $ra
    // 0x802AD878: sh          $t1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r9;
    return;
    // 0x802AD878: sh          $t1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r9;
;}
RECOMP_FUNC void func_802AD87C_6BEF2C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AD87C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AD880: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802AD884: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802AD888: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AD88C: lh          $t6, 0x2C($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2C);
    // 0x802AD890: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AD894: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AD898: sh          $t6, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r14;
    // 0x802AD89C: addiu       $at, $zero, 0x43
    ctx->r1 = ADD32(0, 0X43);
    // 0x802AD8A0: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x802AD8A4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AD8A8: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AD8AC: bne         $t8, $at, L_802AD8DC
    if (ctx->r24 != ctx->r1) {
        // 0x802AD8B0: nop
    
            goto L_802AD8DC;
    }
    // 0x802AD8B0: nop

    // 0x802AD8B4: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802AD8B8: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802AD8BC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802AD8C0: lh          $t2, 0x30C($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X30C);
    // 0x802AD8C4: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
    // 0x802AD8C8: slti        $at, $t2, 0x15
    ctx->r1 = SIGNED(ctx->r10) < 0X15 ? 1 : 0;
    // 0x802AD8CC: bne         $at, $zero, L_802AD8DC
    if (ctx->r1 != 0) {
        // 0x802AD8D0: addiu       $at, $a3, 0x7FFF
        ctx->r1 = ADD32(ctx->r7, 0X7FFF);
            goto L_802AD8DC;
    }
    // 0x802AD8D0: addiu       $at, $a3, 0x7FFF
    ctx->r1 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD8D4: sh          $zero, 0x7FDB($at)
    MEM_H(0X7FDB, ctx->r1) = 0;
    // 0x802AD8D8: sh          $t1, 0x7FA9($at)
    MEM_H(0X7FA9, ctx->r1) = ctx->r9;
L_802AD8DC:
    // 0x802AD8DC: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802AD8E0: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802AD8E4: addiu       $t3, $a3, 0x7FFF
    ctx->r11 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD8E8: lhu         $t3, 0x7FB9($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X7FB9);
    // 0x802AD8EC: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
    // 0x802AD8F0: bnel        $t3, $zero, L_802AD908
    if (ctx->r11 != 0) {
        // 0x802AD8F4: lbu         $v0, 0x162($v1)
        ctx->r2 = MEM_BU(ctx->r3, 0X162);
            goto L_802AD908;
    }
    goto skip_0;
    // 0x802AD8F4: lbu         $v0, 0x162($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X162);
    skip_0:
    // 0x802AD8F8: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x802AD8FC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD900: sh          $t4, 0x5572($at)
    MEM_H(0X5572, ctx->r1) = ctx->r12;
    // 0x802AD904: lbu         $v0, 0x162($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X162);
L_802AD908:
    // 0x802AD908: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AD90C: andi        $t5, $v0, 0xF
    ctx->r13 = ctx->r2 & 0XF;
    // 0x802AD910: beq         $t5, $at, L_802AD928
    if (ctx->r13 == ctx->r1) {
        // 0x802AD914: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_802AD928;
    }
    // 0x802AD914: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802AD918: beq         $t5, $at, L_802ADCD4
    if (ctx->r13 == ctx->r1) {
        // 0x802AD91C: addiu       $v0, $a3, 0x7FFF
        ctx->r2 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCD4;
    }
    // 0x802AD91C: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD920: b           L_802ADCF4
    // 0x802AD924: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
        goto L_802ADCF4;
    // 0x802AD924: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
L_802AD928:
    // 0x802AD928: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    // 0x802AD92C: addiu       $t7, $t6, -0x1
    ctx->r15 = ADD32(ctx->r14, -0X1);
    // 0x802AD930: sltiu       $at, $t7, 0x6
    ctx->r1 = ctx->r15 < 0X6 ? 1 : 0;
    // 0x802AD934: beq         $at, $zero, L_802ADCF0
    if (ctx->r1 == 0) {
        // 0x802AD938: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_802ADCF0;
    }
    // 0x802AD938: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802AD93C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AD940: addu        $at, $at, $t7
    gpr jr_addend_802AD948 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x802AD944: lw          $t7, -0x4344($at)
    ctx->r15 = ADD32(ctx->r1, -0X4344);
    // 0x802AD948: jr          $t7
    // 0x802AD94C: nop

    switch (jr_addend_802AD948 >> 2) {
        case 0: goto L_802AD950; break;
        case 1: goto L_802AD950; break;
        case 2: goto L_802ADA48; break;
        case 3: goto L_802ADB28; break;
        case 4: goto L_802ADCF0; break;
        case 5: goto L_802ADC14; break;
        default: switch_error(__func__, 0x802AD948, 0x803BBCBC);
    }
    // 0x802AD94C: nop

L_802AD950:
    // 0x802AD950: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AD954: lhu         $t8, 0x5544($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X5544);
    // 0x802AD958: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD95C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802AD960: sh          $t8, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r24;
    // 0x802AD964: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD968: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802AD96C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD970: sb          $zero, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = 0;
    // 0x802AD974: lw          $t9, 0x6C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X6C);
    // 0x802AD978: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AD97C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD980: addiu       $a0, $a0, 0x5564
    ctx->r4 = ADD32(ctx->r4, 0X5564);
    // 0x802AD984: sw          $t9, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r25;
    // 0x802AD988: lh          $t2, 0x0($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X0);
    // 0x802AD98C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802AD990: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD994: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802AD998: sh          $t2, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r10;
    // 0x802AD99C: lh          $t3, 0x0($a1)
    ctx->r11 = MEM_H(ctx->r5, 0X0);
    // 0x802AD9A0: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AD9A4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD9A8: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802AD9AC: sh          $t3, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r11;
    // 0x802AD9B0: lh          $t4, 0x0($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X0);
    // 0x802AD9B4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AD9B8: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD9BC: sh          $t4, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r12;
    // 0x802AD9C0: lh          $t5, 0x4($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X4);
    // 0x802AD9C4: sh          $t5, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r13;
    // 0x802AD9C8: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
    // 0x802AD9CC: addiu       $a0, $a3, 0x7FFF
    ctx->r4 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AD9D0: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
    // 0x802AD9D4: lbu         $t7, 0x160($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X160);
    // 0x802AD9D8: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x802AD9DC: sh          $t7, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r15;
    // 0x802AD9E0: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AD9E4: blez        $v0, L_802ADA08
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AD9E8: nop
    
            goto L_802ADA08;
    }
    // 0x802AD9E8: nop

    // 0x802AD9EC: jal         0x802A43E4
    // 0x802AD9F0: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    func_802A43E4_6B5A94(rdram, ctx);
        goto after_0;
    // 0x802AD9F0: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    after_0:
    // 0x802AD9F4: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802AD9F8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802AD9FC: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADA00: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802ADA04: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
L_802ADA08:
    // 0x802ADA08: bgez        $v0, L_802ADA28
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802ADA0C: addiu       $a0, $a3, 0x7FFF
        ctx->r4 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADA28;
    }
    // 0x802ADA0C: addiu       $a0, $a3, 0x7FFF
    ctx->r4 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADA10: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802ADA14: jal         0x802A44C4
    // 0x802ADA18: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A44C4_6B5B74(rdram, ctx);
        goto after_1;
    // 0x802ADA18: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_1:
    // 0x802ADA1C: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADA20: b           L_802ADCF0
    // 0x802ADA24: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
        goto L_802ADCF0;
    // 0x802ADA24: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
L_802ADA28:
    // 0x802ADA28: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADA2C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ADA30: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802ADA34: beql        $t1, $v0, L_802ADCF4
    if (ctx->r9 == ctx->r2) {
        // 0x802ADA38: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_1;
    // 0x802ADA38: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_1:
    // 0x802ADA3C: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802ADA40: b           L_802ADCF0
    // 0x802ADA44: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
        goto L_802ADCF0;
    // 0x802ADA44: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
L_802ADA48:
    // 0x802ADA48: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802ADA4C: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x802ADA50: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADA54: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802ADA58: sh          $t9, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r25;
    // 0x802ADA5C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADA60: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802ADA64: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADA68: sb          $t0, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = ctx->r8;
    // 0x802ADA6C: lw          $t2, 0x6C($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X6C);
    // 0x802ADA70: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802ADA74: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADA78: addiu       $a0, $a0, 0x5564
    ctx->r4 = ADD32(ctx->r4, 0X5564);
    // 0x802ADA7C: sw          $t2, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r10;
    // 0x802ADA80: lh          $t3, 0x0($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X0);
    // 0x802ADA84: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADA88: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADA8C: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802ADA90: sh          $t3, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r11;
    // 0x802ADA94: lh          $t4, 0x0($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X0);
    // 0x802ADA98: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ADA9C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADAA0: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802ADAA4: sh          $t4, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r12;
    // 0x802ADAA8: lh          $t5, 0x0($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X0);
    // 0x802ADAAC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADAB0: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADAB4: sh          $t5, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r13;
    // 0x802ADAB8: lh          $t6, 0x4($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X4);
    // 0x802ADABC: sh          $t6, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r14;
    // 0x802ADAC0: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x802ADAC4: sh          $t7, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r15;
    // 0x802ADAC8: lbu         $t8, 0x160($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X160);
    // 0x802ADACC: sh          $t8, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r24;
    // 0x802ADAD0: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802ADAD4: bgtz        $v0, L_802ADAF0
    if (SIGNED(ctx->r2) > 0) {
        // 0x802ADAD8: slti        $at, $v0, 0x4
        ctx->r1 = SIGNED(ctx->r2) < 0X4 ? 1 : 0;
            goto L_802ADAF0;
    }
    // 0x802ADAD8: slti        $at, $v0, 0x4
    ctx->r1 = SIGNED(ctx->r2) < 0X4 ? 1 : 0;
    // 0x802ADADC: jal         0x802A4390
    // 0x802ADAE0: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_2;
    // 0x802ADAE0: nop

    after_2:
    // 0x802ADAE4: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADAE8: b           L_802ADCF0
    // 0x802ADAEC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
        goto L_802ADCF0;
    // 0x802ADAEC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
L_802ADAF0:
    // 0x802ADAF0: bne         $at, $zero, L_802ADB14
    if (ctx->r1 != 0) {
        // 0x802ADAF4: addiu       $v0, $a3, 0x7FFF
        ctx->r2 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADB14;
    }
    // 0x802ADAF4: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADAF8: addiu       $a0, $a3, 0x7FFF
    ctx->r4 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADAFC: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802ADB00: jal         0x802A459C
    // 0x802ADB04: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802A459C_6B5C4C(rdram, ctx);
        goto after_3;
    // 0x802ADB04: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x802ADB08: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADB0C: b           L_802ADCF0
    // 0x802ADB10: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
        goto L_802ADCF0;
    // 0x802ADB10: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
L_802ADB14:
    // 0x802ADB14: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ADB18: beql        $t1, $v0, L_802ADCF4
    if (ctx->r9 == ctx->r2) {
        // 0x802ADB1C: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_2;
    // 0x802ADB1C: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_2:
    // 0x802ADB20: b           L_802ADCF0
    // 0x802ADB24: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802ADCF0;
    // 0x802ADB24: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802ADB28:
    // 0x802ADB28: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802ADB2C: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x802ADB30: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB34: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802ADB38: sh          $t9, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r25;
    // 0x802ADB3C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB40: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802ADB44: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB48: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x802ADB4C: sb          $t2, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = ctx->r10;
    // 0x802ADB50: lw          $t3, 0x6C($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X6C);
    // 0x802ADB54: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802ADB58: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB5C: addiu       $a0, $a0, 0x5564
    ctx->r4 = ADD32(ctx->r4, 0X5564);
    // 0x802ADB60: sw          $t3, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r11;
    // 0x802ADB64: lh          $t4, 0x0($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X0);
    // 0x802ADB68: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADB6C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB70: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802ADB74: sh          $t4, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r12;
    // 0x802ADB78: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x802ADB7C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ADB80: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB84: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802ADB88: sh          $t5, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r13;
    // 0x802ADB8C: lh          $t6, 0x0($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X0);
    // 0x802ADB90: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADB94: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADB98: sh          $t6, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r14;
    // 0x802ADB9C: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x802ADBA0: sh          $t7, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r15;
    // 0x802ADBA4: lh          $t8, 0x8($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X8);
    // 0x802ADBA8: sh          $t8, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r24;
    // 0x802ADBAC: lbu         $t9, 0x160($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X160);
    // 0x802ADBB0: sh          $t9, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r25;
    // 0x802ADBB4: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802ADBB8: bgtz        $v0, L_802ADBD8
    if (SIGNED(ctx->r2) > 0) {
        // 0x802ADBBC: slti        $at, $v0, 0x3
        ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
            goto L_802ADBD8;
    }
    // 0x802ADBBC: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802ADBC0: jal         0x802A4390
    // 0x802ADBC4: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_4;
    // 0x802ADBC4: nop

    after_4:
    // 0x802ADBC8: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADBCC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ADBD0: b           L_802ADBF4
    // 0x802ADBD4: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
        goto L_802ADBF4;
    // 0x802ADBD4: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
L_802ADBD8:
    // 0x802ADBD8: beq         $at, $zero, L_802ADBF4
    if (ctx->r1 == 0) {
        // 0x802ADBDC: lhu         $a0, 0x1E($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X1E);
            goto L_802ADBF4;
    }
    // 0x802ADBDC: lhu         $a0, 0x1E($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X1E);
    // 0x802ADBE0: jal         0x802A43E4
    // 0x802ADBE4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A43E4_6B5A94(rdram, ctx);
        goto after_5;
    // 0x802ADBE4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_5:
    // 0x802ADBE8: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADBEC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ADBF0: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
L_802ADBF4:
    // 0x802ADBF4: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADBF8: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ADBFC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802ADC00: beql        $t1, $v0, L_802ADCF4
    if (ctx->r9 == ctx->r2) {
        // 0x802ADC04: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_3;
    // 0x802ADC04: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_3:
    // 0x802ADC08: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x802ADC0C: b           L_802ADCF0
    // 0x802ADC10: sh          $v0, 0x2C($t2)
    MEM_H(0X2C, ctx->r10) = ctx->r2;
        goto L_802ADCF0;
    // 0x802ADC10: sh          $v0, 0x2C($t2)
    MEM_H(0X2C, ctx->r10) = ctx->r2;
L_802ADC14:
    // 0x802ADC14: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802ADC18: lhu         $t3, 0x5544($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X5544);
    // 0x802ADC1C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC20: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802ADC24: sh          $t3, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r11;
    // 0x802ADC28: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC2C: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802ADC30: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC34: sb          $t0, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = ctx->r8;
    // 0x802ADC38: lw          $t4, 0x6C($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X6C);
    // 0x802ADC3C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802ADC40: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC44: addiu       $a0, $a0, 0x5564
    ctx->r4 = ADD32(ctx->r4, 0X5564);
    // 0x802ADC48: sw          $t4, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r12;
    // 0x802ADC4C: lh          $t5, 0x0($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X0);
    // 0x802ADC50: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADC54: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC58: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802ADC5C: sh          $t5, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r13;
    // 0x802ADC60: lh          $t6, 0x0($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X0);
    // 0x802ADC64: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ADC68: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC6C: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802ADC70: sh          $t6, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r14;
    // 0x802ADC74: lh          $t7, 0x0($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X0);
    // 0x802ADC78: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADC7C: addiu       $t3, $a3, 0x7FFF
    ctx->r11 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADC80: sh          $t7, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r15;
    // 0x802ADC84: lh          $t8, 0x4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4);
    // 0x802ADC88: addiu       $v0, $a3, 0x7FFF
    ctx->r2 = ADD32(ctx->r7, 0X7FFF);
    // 0x802ADC8C: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
    // 0x802ADC90: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x802ADC94: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
    // 0x802ADC98: lbu         $t2, 0x160($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X160);
    // 0x802ADC9C: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
    // 0x802ADCA0: lh          $t3, 0x7FDB($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X7FDB);
    // 0x802ADCA4: bltzl       $t3, L_802ADCC4
    if (SIGNED(ctx->r11) < 0) {
        // 0x802ADCA8: lh          $v0, 0x7FA9($v0)
        ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
            goto L_802ADCC4;
    }
    goto skip_4;
    // 0x802ADCA8: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    skip_4:
    // 0x802ADCAC: jal         0x802A4390
    // 0x802ADCB0: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_6;
    // 0x802ADCB0: nop

    after_6:
    // 0x802ADCB4: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802ADCB8: b           L_802ADCF0
    // 0x802ADCBC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
        goto L_802ADCF0;
    // 0x802ADCBC: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802ADCC0: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
L_802ADCC4:
    // 0x802ADCC4: beql        $t1, $v0, L_802ADCF4
    if (ctx->r9 == ctx->r2) {
        // 0x802ADCC8: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_5;
    // 0x802ADCC8: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_5:
    // 0x802ADCCC: b           L_802ADCF0
    // 0x802ADCD0: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802ADCF0;
    // 0x802ADCD0: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802ADCD4:
    // 0x802ADCD4: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802ADCD8: lhu         $t4, 0x1E($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X1E);
    // 0x802ADCDC: beql        $t4, $v0, L_802ADCF4
    if (ctx->r12 == ctx->r2) {
        // 0x802ADCE0: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_6;
    // 0x802ADCE0: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_6:
    // 0x802ADCE4: beql        $t1, $v0, L_802ADCF4
    if (ctx->r9 == ctx->r2) {
        // 0x802ADCE8: addiu       $t5, $a3, 0x7FFF
        ctx->r13 = ADD32(ctx->r7, 0X7FFF);
            goto L_802ADCF4;
    }
    goto skip_7;
    // 0x802ADCE8: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
    skip_7:
    // 0x802ADCEC: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802ADCF0:
    // 0x802ADCF0: addiu       $t5, $a3, 0x7FFF
    ctx->r13 = ADD32(ctx->r7, 0X7FFF);
L_802ADCF4:
    // 0x802ADCF4: lhu         $t5, 0x7FB3($t5)
    ctx->r13 = MEM_HU(ctx->r13, 0X7FB3);
    // 0x802ADCF8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802ADCFC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802ADD00: beql        $t5, $zero, L_802ADDC4
    if (ctx->r13 == 0) {
        // 0x802ADD04: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802ADDC4;
    }
    goto skip_8;
    // 0x802ADD04: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x802ADD08: lhu         $v0, 0x5544($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X5544);
    // 0x802ADD0C: lhu         $t6, 0x5572($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5572);
    // 0x802ADD10: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802ADD14: subu        $t7, $v0, $t6
    ctx->r15 = SUB32(ctx->r2, ctx->r14);
    // 0x802ADD18: slti        $at, $t7, 0x8
    ctx->r1 = SIGNED(ctx->r15) < 0X8 ? 1 : 0;
    // 0x802ADD1C: beql        $at, $zero, L_802ADDC4
    if (ctx->r1 == 0) {
        // 0x802ADD20: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802ADDC4;
    }
    goto skip_9;
    // 0x802ADD20: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x802ADD24: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802ADD28: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802ADD2C: lhu         $t9, 0xA2($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0XA2);
    // 0x802ADD30: andi        $t2, $t9, 0x1
    ctx->r10 = ctx->r25 & 0X1;
    // 0x802ADD34: beql        $t2, $zero, L_802ADDC4
    if (ctx->r10 == 0) {
        // 0x802ADD38: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802ADDC4;
    }
    goto skip_10;
    // 0x802ADD38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_10:
    // 0x802ADD3C: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x802ADD40: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802ADD44: lbu         $t4, 0x367($t3)
    ctx->r12 = MEM_BU(ctx->r11, 0X367);
    // 0x802ADD48: bgtzl       $t4, L_802ADDC4
    if (SIGNED(ctx->r12) > 0) {
        // 0x802ADD4C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802ADDC4;
    }
    goto skip_11;
    // 0x802ADD4C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_11:
    // 0x802ADD50: lbu         $t5, 0x555C($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X555C);
    // 0x802ADD54: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802ADD58: beql        $t5, $zero, L_802ADDC4
    if (ctx->r13 == 0) {
        // 0x802ADD5C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802ADDC4;
    }
    goto skip_12;
    // 0x802ADD5C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_12:
    // 0x802ADD60: lhu         $t6, 0x555A($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X555A);
    // 0x802ADD64: subu        $t7, $v0, $t6
    ctx->r15 = SUB32(ctx->r2, ctx->r14);
    // 0x802ADD68: slti        $at, $t7, 0x4
    ctx->r1 = SIGNED(ctx->r15) < 0X4 ? 1 : 0;
    // 0x802ADD6C: beq         $at, $zero, L_802ADDC0
    if (ctx->r1 == 0) {
        // 0x802ADD70: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802ADDC0;
    }
    // 0x802ADD70: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802ADD74: lbu         $v0, 0x555D($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X555D);
    // 0x802ADD78: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADD7C: sb          $zero, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = 0;
    // 0x802ADD80: beq         $v0, $zero, L_802ADD98
    if (ctx->r2 == 0) {
        // 0x802ADD84: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802ADD98;
    }
    // 0x802ADD84: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802ADD88: beq         $v0, $at, L_802ADDA8
    if (ctx->r2 == ctx->r1) {
        // 0x802ADD8C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802ADDA8;
    }
    // 0x802ADD8C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802ADD90: beq         $v0, $at, L_802ADDB8
    if (ctx->r2 == ctx->r1) {
        // 0x802ADD94: nop
    
            goto L_802ADDB8;
    }
    // 0x802ADD94: nop

L_802ADD98:
    // 0x802ADD98: jal         0x802A6390
    // 0x802ADD9C: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_7;
    // 0x802ADD9C: nop

    after_7:
    // 0x802ADDA0: b           L_802ADDC4
    // 0x802ADDA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ADDC4;
    // 0x802ADDA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ADDA8:
    // 0x802ADDA8: jal         0x802A6390
    // 0x802ADDAC: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_8;
    // 0x802ADDAC: nop

    after_8:
    // 0x802ADDB0: b           L_802ADDC4
    // 0x802ADDB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802ADDC4;
    // 0x802ADDB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ADDB8:
    // 0x802ADDB8: jal         0x802A63C0
    // 0x802ADDBC: nop

    func_802A63C0_6B7A70(rdram, ctx);
        goto after_9;
    // 0x802ADDBC: nop

    after_9:
L_802ADDC0:
    // 0x802ADDC0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802ADDC4:
    // 0x802ADDC4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802ADDC8: jr          $ra
    // 0x802ADDCC: nop

    return;
    // 0x802ADDCC: nop

;}
RECOMP_FUNC void func_802ADDD0_6BF480(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802ADDD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802ADDD4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802ADDD8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802ADDDC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802ADDE0: lbu         $v1, 0x162($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X162);
    // 0x802ADDE4: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802ADDE8: lhu         $a3, 0x2C($v0)
    ctx->r7 = MEM_HU(ctx->r2, 0X2C);
    // 0x802ADDEC: andi        $t6, $v1, 0xF
    ctx->r14 = ctx->r3 & 0XF;
    // 0x802ADDF0: beq         $t6, $at, L_802ADE08
    if (ctx->r14 == ctx->r1) {
        // 0x802ADDF4: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_802ADE08;
    }
    // 0x802ADDF4: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x802ADDF8: beq         $t6, $at, L_802AE198
    if (ctx->r14 == ctx->r1) {
        // 0x802ADDFC: lui         $v1, 0x801F
        ctx->r3 = S32(0X801F << 16);
            goto L_802AE198;
    }
    // 0x802ADDFC: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802ADE00: b           L_802AE1AC
    // 0x802ADE04: nop

        goto L_802AE1AC;
    // 0x802ADE04: nop

L_802ADE08:
    // 0x802ADE08: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802ADE0C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802ADE10: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADE14: beq         $v1, $at, L_802ADE50
    if (ctx->r3 == ctx->r1) {
        // 0x802ADE18: addiu       $a1, $a1, 0x5568
        ctx->r5 = ADD32(ctx->r5, 0X5568);
            goto L_802ADE50;
    }
    // 0x802ADE18: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802ADE1C: addiu       $at, $zero, 0xB5
    ctx->r1 = ADD32(0, 0XB5);
    // 0x802ADE20: beq         $v1, $at, L_802ADE50
    if (ctx->r3 == ctx->r1) {
        // 0x802ADE24: addiu       $at, $zero, 0xB6
        ctx->r1 = ADD32(0, 0XB6);
            goto L_802ADE50;
    }
    // 0x802ADE24: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802ADE28: beq         $v1, $at, L_802ADF2C
    if (ctx->r3 == ctx->r1) {
        // 0x802ADE2C: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802ADF2C;
    }
    // 0x802ADE2C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADE30: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802ADE34: beq         $v1, $at, L_802AE004
    if (ctx->r3 == ctx->r1) {
        // 0x802ADE38: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802AE004;
    }
    // 0x802ADE38: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADE3C: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802ADE40: beq         $v1, $at, L_802AE0DC
    if (ctx->r3 == ctx->r1) {
        // 0x802ADE44: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802AE0DC;
    }
    // 0x802ADE44: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802ADE48: b           L_802AE1AC
    // 0x802ADE4C: nop

        goto L_802AE1AC;
    // 0x802ADE4C: nop

L_802ADE50:
    // 0x802ADE50: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802ADE54: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x802ADE58: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADE5C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802ADE60: sh          $t7, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r15;
    // 0x802ADE64: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADE68: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802ADE6C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADE70: sb          $zero, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = 0;
    // 0x802ADE74: lw          $t8, 0x6C($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X6C);
    // 0x802ADE78: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802ADE7C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADE80: addiu       $v1, $v1, 0x5564
    ctx->r3 = ADD32(ctx->r3, 0X5564);
    // 0x802ADE84: sw          $t8, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r24;
    // 0x802ADE88: lh          $t9, 0x0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X0);
    // 0x802ADE8C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADE90: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ADE94: sh          $t9, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r25;
    // 0x802ADE98: lh          $t1, 0x0($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X0);
    // 0x802ADE9C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADEA0: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802ADEA4: sh          $t1, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r9;
    // 0x802ADEA8: lh          $t2, 0x0($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X0);
    // 0x802ADEAC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADEB0: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802ADEB4: sh          $t2, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r10;
    // 0x802ADEB8: lh          $t3, 0x4($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X4);
    // 0x802ADEBC: sh          $t3, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r11;
    // 0x802ADEC0: lh          $t4, 0x8($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X8);
    // 0x802ADEC4: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
    // 0x802ADEC8: lbu         $t5, 0x160($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X160);
    // 0x802ADECC: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x802ADED0: sh          $t5, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r13;
    // 0x802ADED4: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x802ADED8: blez        $a0, L_802ADEF4
    if (SIGNED(ctx->r4) <= 0) {
        // 0x802ADEDC: nop
    
            goto L_802ADEF4;
    }
    // 0x802ADEDC: nop

    // 0x802ADEE0: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802ADEE4: jal         0x802A4EC8
    // 0x802ADEE8: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    func_802A4EC8_6B6578(rdram, ctx);
        goto after_0;
    // 0x802ADEE8: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    after_0:
    // 0x802ADEEC: b           L_802AE1AC
    // 0x802ADEF0: nop

        goto L_802AE1AC;
    // 0x802ADEF0: nop

L_802ADEF4:
    // 0x802ADEF4: bgez        $a0, L_802ADF14
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802ADEF8: lui         $v1, 0x801F
        ctx->r3 = S32(0X801F << 16);
            goto L_802ADF14;
    }
    // 0x802ADEF8: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802ADEFC: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802ADF00: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    // 0x802ADF04: jal         0x802A4F68
    // 0x802ADF08: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A4F68_6B6618(rdram, ctx);
        goto after_1;
    // 0x802ADF08: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_1:
    // 0x802ADF0C: b           L_802AE1AC
    // 0x802ADF10: nop

        goto L_802AE1AC;
    // 0x802ADF10: nop

L_802ADF14:
    // 0x802ADF14: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802ADF18: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802ADF1C: beq         $v1, $at, L_802AE1AC
    if (ctx->r3 == ctx->r1) {
        // 0x802ADF20: nop
    
            goto L_802AE1AC;
    }
    // 0x802ADF20: nop

    // 0x802ADF24: b           L_802AE1AC
    // 0x802ADF28: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
        goto L_802AE1AC;
    // 0x802ADF28: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
L_802ADF2C:
    // 0x802ADF2C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802ADF30: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802ADF34: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF38: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802ADF3C: sh          $t6, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r14;
    // 0x802ADF40: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF44: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802ADF48: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF4C: sb          $t0, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = ctx->r8;
    // 0x802ADF50: lw          $t7, 0x6C($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X6C);
    // 0x802ADF54: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802ADF58: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF5C: addiu       $v1, $v1, 0x5564
    ctx->r3 = ADD32(ctx->r3, 0X5564);
    // 0x802ADF60: sw          $t7, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r15;
    // 0x802ADF64: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x802ADF68: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF6C: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802ADF70: sh          $t8, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r24;
    // 0x802ADF74: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802ADF78: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802ADF7C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF80: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802ADF84: sh          $t9, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r25;
    // 0x802ADF88: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x802ADF8C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802ADF90: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802ADF94: sh          $t1, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r9;
    // 0x802ADF98: lh          $t2, 0x4($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X4);
    // 0x802ADF9C: sh          $t2, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r10;
    // 0x802ADFA0: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802ADFA4: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802ADFA8: sh          $t3, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r11;
    // 0x802ADFAC: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
    // 0x802ADFB0: sh          $t4, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r12;
    // 0x802ADFB4: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x802ADFB8: bgtz        $a0, L_802ADFD0
    if (SIGNED(ctx->r4) > 0) {
        // 0x802ADFBC: nop
    
            goto L_802ADFD0;
    }
    // 0x802ADFBC: nop

    // 0x802ADFC0: jal         0x802A4E74
    // 0x802ADFC4: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_2;
    // 0x802ADFC4: nop

    after_2:
    // 0x802ADFC8: b           L_802AE1AC
    // 0x802ADFCC: nop

        goto L_802AE1AC;
    // 0x802ADFCC: nop

L_802ADFD0:
    // 0x802ADFD0: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802ADFD4: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802ADFD8: beql        $v1, $at, L_802ADFEC
    if (ctx->r3 == ctx->r1) {
        // 0x802ADFDC: slti        $at, $a0, 0x3
        ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
            goto L_802ADFEC;
    }
    goto skip_0;
    // 0x802ADFDC: slti        $at, $a0, 0x3
    ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
    skip_0:
    // 0x802ADFE0: b           L_802AE1AC
    // 0x802ADFE4: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
        goto L_802AE1AC;
    // 0x802ADFE4: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
    // 0x802ADFE8: slti        $at, $a0, 0x3
    ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
L_802ADFEC:
    // 0x802ADFEC: bne         $at, $zero, L_802AE1AC
    if (ctx->r1 != 0) {
        // 0x802ADFF0: andi        $a0, $v1, 0xFFFF
        ctx->r4 = ctx->r3 & 0XFFFF;
            goto L_802AE1AC;
    }
    // 0x802ADFF0: andi        $a0, $v1, 0xFFFF
    ctx->r4 = ctx->r3 & 0XFFFF;
    // 0x802ADFF4: jal         0x802A5008
    // 0x802ADFF8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802A5008_6B66B8(rdram, ctx);
        goto after_3;
    // 0x802ADFF8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x802ADFFC: b           L_802AE1AC
    // 0x802AE000: nop

        goto L_802AE1AC;
    // 0x802AE000: nop

L_802AE004:
    // 0x802AE004: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AE008: lhu         $t5, 0x5544($t5)
    ctx->r13 = MEM_HU(ctx->r13, 0X5544);
    // 0x802AE00C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE010: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802AE014: sh          $t5, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r13;
    // 0x802AE018: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE01C: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802AE020: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE024: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802AE028: sb          $t6, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = ctx->r14;
    // 0x802AE02C: lw          $t7, 0x6C($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X6C);
    // 0x802AE030: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AE034: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE038: addiu       $v1, $v1, 0x5564
    ctx->r3 = ADD32(ctx->r3, 0X5564);
    // 0x802AE03C: sw          $t7, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r15;
    // 0x802AE040: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x802AE044: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE048: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802AE04C: sh          $t8, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r24;
    // 0x802AE050: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802AE054: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AE058: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE05C: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802AE060: sh          $t9, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r25;
    // 0x802AE064: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x802AE068: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE06C: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802AE070: sh          $t1, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r9;
    // 0x802AE074: lh          $t2, 0x4($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X4);
    // 0x802AE078: sh          $t2, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r10;
    // 0x802AE07C: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802AE080: sh          $t3, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r11;
    // 0x802AE084: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
    // 0x802AE088: sh          $t4, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r12;
    // 0x802AE08C: lh          $a0, -0x614E($a0)
    ctx->r4 = MEM_H(ctx->r4, -0X614E);
    // 0x802AE090: bgtz        $a0, L_802AE0A8
    if (SIGNED(ctx->r4) > 0) {
        // 0x802AE094: slti        $at, $a0, 0x3
        ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
            goto L_802AE0A8;
    }
    // 0x802AE094: slti        $at, $a0, 0x3
    ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
    // 0x802AE098: jal         0x802A4E74
    // 0x802AE09C: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_4;
    // 0x802AE09C: nop

    after_4:
    // 0x802AE0A0: b           L_802AE0B8
    // 0x802AE0A4: nop

        goto L_802AE0B8;
    // 0x802AE0A4: nop

L_802AE0A8:
    // 0x802AE0A8: beq         $at, $zero, L_802AE0B8
    if (ctx->r1 == 0) {
        // 0x802AE0AC: andi        $a0, $a3, 0xFFFF
        ctx->r4 = ctx->r7 & 0XFFFF;
            goto L_802AE0B8;
    }
    // 0x802AE0AC: andi        $a0, $a3, 0xFFFF
    ctx->r4 = ctx->r7 & 0XFFFF;
    // 0x802AE0B0: jal         0x802A4EC8
    // 0x802AE0B4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A4EC8_6B6578(rdram, ctx);
        goto after_5;
    // 0x802AE0B4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_5:
L_802AE0B8:
    // 0x802AE0B8: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AE0BC: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802AE0C0: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE0C4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AE0C8: beq         $v1, $at, L_802AE1AC
    if (ctx->r3 == ctx->r1) {
        // 0x802AE0CC: nop
    
            goto L_802AE1AC;
    }
    // 0x802AE0CC: nop

    // 0x802AE0D0: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802AE0D4: b           L_802AE1AC
    // 0x802AE0D8: sh          $v1, 0x2C($t5)
    MEM_H(0X2C, ctx->r13) = ctx->r3;
        goto L_802AE1AC;
    // 0x802AE0D8: sh          $v1, 0x2C($t5)
    MEM_H(0X2C, ctx->r13) = ctx->r3;
L_802AE0DC:
    // 0x802AE0DC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AE0E0: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802AE0E4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE0E8: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802AE0EC: sh          $t6, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r14;
    // 0x802AE0F0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE0F4: sb          $t0, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = ctx->r8;
    // 0x802AE0F8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE0FC: sb          $zero, 0x555D($at)
    MEM_B(0X555D, ctx->r1) = 0;
    // 0x802AE100: lw          $t7, 0x6C($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X6C);
    // 0x802AE104: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AE108: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE10C: addiu       $v1, $v1, 0x5564
    ctx->r3 = ADD32(ctx->r3, 0X5564);
    // 0x802AE110: sw          $t7, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r15;
    // 0x802AE114: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x802AE118: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE11C: addiu       $a1, $a1, 0x5568
    ctx->r5 = ADD32(ctx->r5, 0X5568);
    // 0x802AE120: sh          $t8, 0x5566($at)
    MEM_H(0X5566, ctx->r1) = ctx->r24;
    // 0x802AE124: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802AE128: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AE12C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE130: addiu       $a2, $a2, 0x556C
    ctx->r6 = ADD32(ctx->r6, 0X556C);
    // 0x802AE134: sh          $t9, 0x556A($at)
    MEM_H(0X556A, ctx->r1) = ctx->r25;
    // 0x802AE138: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x802AE13C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE140: lui         $t5, 0x801F
    ctx->r13 = S32(0X801F << 16);
    // 0x802AE144: sh          $t1, 0x556E($at)
    MEM_H(0X556E, ctx->r1) = ctx->r9;
    // 0x802AE148: lh          $t2, 0x4($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X4);
    // 0x802AE14C: sh          $t2, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r10;
    // 0x802AE150: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802AE154: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AE158: sh          $t3, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r11;
    // 0x802AE15C: lbu         $t4, 0x160($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X160);
    // 0x802AE160: sh          $t4, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r12;
    // 0x802AE164: lh          $t5, -0x614E($t5)
    ctx->r13 = MEM_H(ctx->r13, -0X614E);
    // 0x802AE168: bltz        $t5, L_802AE180
    if (SIGNED(ctx->r13) < 0) {
        // 0x802AE16C: nop
    
            goto L_802AE180;
    }
    // 0x802AE16C: nop

    // 0x802AE170: jal         0x802A4E74
    // 0x802AE174: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_6;
    // 0x802AE174: nop

    after_6:
    // 0x802AE178: b           L_802AE1AC
    // 0x802AE17C: nop

        goto L_802AE1AC;
    // 0x802AE17C: nop

L_802AE180:
    // 0x802AE180: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802AE184: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE188: beq         $v1, $at, L_802AE1AC
    if (ctx->r3 == ctx->r1) {
        // 0x802AE18C: nop
    
            goto L_802AE1AC;
    }
    // 0x802AE18C: nop

    // 0x802AE190: b           L_802AE1AC
    // 0x802AE194: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
        goto L_802AE1AC;
    // 0x802AE194: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
L_802AE198:
    // 0x802AE198: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802AE19C: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE1A0: beq         $v1, $at, L_802AE1AC
    if (ctx->r3 == ctx->r1) {
        // 0x802AE1A4: nop
    
            goto L_802AE1AC;
    }
    // 0x802AE1A4: nop

    // 0x802AE1A8: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
L_802AE1AC:
    // 0x802AE1AC: lui         $t6, 0x801F
    ctx->r14 = S32(0X801F << 16);
    // 0x802AE1B0: lhu         $t6, -0x6176($t6)
    ctx->r14 = MEM_HU(ctx->r14, -0X6176);
    // 0x802AE1B4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AE1B8: beql        $t6, $zero, L_802AE26C
    if (ctx->r14 == 0) {
        // 0x802AE1BC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE26C;
    }
    goto skip_1;
    // 0x802AE1BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802AE1C0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AE1C4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AE1C8: lhu         $t8, 0xA2($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XA2);
    // 0x802AE1CC: andi        $t9, $t8, 0x1
    ctx->r25 = ctx->r24 & 0X1;
    // 0x802AE1D0: beql        $t9, $zero, L_802AE26C
    if (ctx->r25 == 0) {
        // 0x802AE1D4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE26C;
    }
    goto skip_2;
    // 0x802AE1D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AE1D8: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802AE1DC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AE1E0: lbu         $t2, 0x367($t1)
    ctx->r10 = MEM_BU(ctx->r9, 0X367);
    // 0x802AE1E4: bgtzl       $t2, L_802AE26C
    if (SIGNED(ctx->r10) > 0) {
        // 0x802AE1E8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE26C;
    }
    goto skip_3;
    // 0x802AE1E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x802AE1EC: lbu         $t3, 0x555C($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X555C);
    // 0x802AE1F0: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AE1F4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AE1F8: beql        $t3, $zero, L_802AE26C
    if (ctx->r11 == 0) {
        // 0x802AE1FC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE26C;
    }
    goto skip_4;
    // 0x802AE1FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802AE200: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x802AE204: lhu         $t5, 0x555A($t5)
    ctx->r13 = MEM_HU(ctx->r13, 0X555A);
    // 0x802AE208: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AE20C: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x802AE210: slti        $at, $t6, 0x4
    ctx->r1 = SIGNED(ctx->r14) < 0X4 ? 1 : 0;
    // 0x802AE214: beql        $at, $zero, L_802AE26C
    if (ctx->r1 == 0) {
        // 0x802AE218: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE26C;
    }
    goto skip_5;
    // 0x802AE218: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AE21C: lbu         $v1, 0x555D($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X555D);
    // 0x802AE220: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE224: sb          $zero, 0x555C($at)
    MEM_B(0X555C, ctx->r1) = 0;
    // 0x802AE228: beq         $v1, $zero, L_802AE240
    if (ctx->r3 == 0) {
        // 0x802AE22C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802AE240;
    }
    // 0x802AE22C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AE230: beq         $v1, $at, L_802AE250
    if (ctx->r3 == ctx->r1) {
        // 0x802AE234: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802AE250;
    }
    // 0x802AE234: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802AE238: beq         $v1, $at, L_802AE260
    if (ctx->r3 == ctx->r1) {
        // 0x802AE23C: nop
    
            goto L_802AE260;
    }
    // 0x802AE23C: nop

L_802AE240:
    // 0x802AE240: jal         0x802A6390
    // 0x802AE244: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_7;
    // 0x802AE244: nop

    after_7:
    // 0x802AE248: b           L_802AE26C
    // 0x802AE24C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE26C;
    // 0x802AE24C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE250:
    // 0x802AE250: jal         0x802A6390
    // 0x802AE254: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_8;
    // 0x802AE254: nop

    after_8:
    // 0x802AE258: b           L_802AE26C
    // 0x802AE25C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE26C;
    // 0x802AE25C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE260:
    // 0x802AE260: jal         0x802A6390
    // 0x802AE264: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_9;
    // 0x802AE264: nop

    after_9:
    // 0x802AE268: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE26C:
    // 0x802AE26C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AE270: jr          $ra
    // 0x802AE274: nop

    return;
    // 0x802AE274: nop

;}
RECOMP_FUNC void func_802AE278_6BF928(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AE278: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AE27C: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802AE280: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AE284: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802AE288: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AE28C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE290: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AE294: sh          $t6, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r14;
    // 0x802AE298: lbu         $v0, 0x162($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X162);
    // 0x802AE29C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AE2A0: andi        $t7, $v0, 0xF
    ctx->r15 = ctx->r2 & 0XF;
    // 0x802AE2A4: beq         $t7, $at, L_802AE2BC
    if (ctx->r15 == ctx->r1) {
        // 0x802AE2A8: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_802AE2BC;
    }
    // 0x802AE2A8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802AE2AC: beq         $t7, $at, L_802AE45C
    if (ctx->r15 == ctx->r1) {
        // 0x802AE2B0: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE45C;
    }
    // 0x802AE2B0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE2B4: b           L_802AE47C
    // 0x802AE2B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE2B8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE2BC:
    // 0x802AE2BC: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802AE2C0: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x802AE2C4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE2C8: beq         $v0, $at, L_802AE2FC
    if (ctx->r2 == ctx->r1) {
        // 0x802AE2CC: addiu       $a2, $a2, -0x6128
        ctx->r6 = ADD32(ctx->r6, -0X6128);
            goto L_802AE2FC;
    }
    // 0x802AE2CC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE2D0: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802AE2D4: beq         $v0, $at, L_802AE35C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE2D8: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE35C;
    }
    // 0x802AE2D8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE2DC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x802AE2E0: beq         $v0, $at, L_802AE3B4
    if (ctx->r2 == ctx->r1) {
        // 0x802AE2E4: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE3B4;
    }
    // 0x802AE2E4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE2E8: addiu       $at, $zero, 0x18
    ctx->r1 = ADD32(0, 0X18);
    // 0x802AE2EC: beq         $v0, $at, L_802AE41C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE2F0: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE41C;
    }
    // 0x802AE2F0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE2F4: b           L_802AE47C
    // 0x802AE2F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE2F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE2FC:
    // 0x802AE2FC: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE300: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE304: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE308: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x802AE30C: blez        $v0, L_802AE324
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AE310: nop
    
            goto L_802AE324;
    }
    // 0x802AE310: nop

    // 0x802AE314: jal         0x802A4D0C
    // 0x802AE318: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    func_802A4D0C_6B63BC(rdram, ctx);
        goto after_0;
    // 0x802AE318: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    after_0:
    // 0x802AE31C: b           L_802AE47C
    // 0x802AE320: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE320: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE324:
    // 0x802AE324: bgez        $v0, L_802AE340
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AE328: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE340;
    }
    // 0x802AE328: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE32C: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE330: jal         0x802A4D80
    // 0x802AE334: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A4D80_6B6430(rdram, ctx);
        goto after_1;
    // 0x802AE334: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_1:
    // 0x802AE338: b           L_802AE47C
    // 0x802AE33C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE33C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE340:
    // 0x802AE340: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE344: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE348: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE34C: beql        $v0, $at, L_802AE47C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE350: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE47C;
    }
    goto skip_0;
    // 0x802AE350: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AE354: b           L_802AE478
    // 0x802AE358: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802AE478;
    // 0x802AE358: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE35C:
    // 0x802AE35C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE360: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE364: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE368: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE36C: beql        $v0, $at, L_802AE37C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE370: addiu       $v0, $a2, 0x7FFF
        ctx->r2 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE37C;
    }
    goto skip_1;
    // 0x802AE370: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    skip_1:
    // 0x802AE374: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
    // 0x802AE378: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
L_802AE37C:
    // 0x802AE37C: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE380: bgtz        $v0, L_802AE398
    if (SIGNED(ctx->r2) > 0) {
        // 0x802AE384: slti        $at, $v0, 0x3
        ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
            goto L_802AE398;
    }
    // 0x802AE384: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802AE388: jal         0x802A4CB8
    // 0x802AE38C: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_2;
    // 0x802AE38C: nop

    after_2:
    // 0x802AE390: b           L_802AE47C
    // 0x802AE394: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE394: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE398:
    // 0x802AE398: bne         $at, $zero, L_802AE478
    if (ctx->r1 != 0) {
        // 0x802AE39C: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE478;
    }
    // 0x802AE39C: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE3A0: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE3A4: jal         0x802A4DF4
    // 0x802AE3A8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802A4DF4_6B64A4(rdram, ctx);
        goto after_3;
    // 0x802AE3A8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x802AE3AC: b           L_802AE47C
    // 0x802AE3B0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE3B0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE3B4:
    // 0x802AE3B4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE3B8: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE3BC: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE3C0: bgtz        $v0, L_802AE3DC
    if (SIGNED(ctx->r2) > 0) {
        // 0x802AE3C4: slti        $at, $v0, 0x3
        ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
            goto L_802AE3DC;
    }
    // 0x802AE3C4: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802AE3C8: jal         0x802A4CB8
    // 0x802AE3CC: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_4;
    // 0x802AE3CC: nop

    after_4:
    // 0x802AE3D0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE3D4: b           L_802AE3F8
    // 0x802AE3D8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AE3F8;
    // 0x802AE3D8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AE3DC:
    // 0x802AE3DC: beq         $at, $zero, L_802AE3F8
    if (ctx->r1 == 0) {
        // 0x802AE3E0: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE3F8;
    }
    // 0x802AE3E0: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE3E4: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE3E8: jal         0x802A4D0C
    // 0x802AE3EC: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A4D0C_6B63BC(rdram, ctx);
        goto after_5;
    // 0x802AE3EC: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_5:
    // 0x802AE3F0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE3F4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AE3F8:
    // 0x802AE3F8: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE3FC: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE400: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE404: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AE408: beql        $v0, $at, L_802AE47C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE40C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE47C;
    }
    goto skip_2;
    // 0x802AE40C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AE410: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802AE414: b           L_802AE478
    // 0x802AE418: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
        goto L_802AE478;
    // 0x802AE418: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
L_802AE41C:
    // 0x802AE41C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE420: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE424: lh          $t9, 0x7FDB($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X7FDB);
    // 0x802AE428: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE42C: bltzl       $t9, L_802AE448
    if (SIGNED(ctx->r25) < 0) {
        // 0x802AE430: lh          $v0, 0x7FA9($v0)
        ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
            goto L_802AE448;
    }
    goto skip_3;
    // 0x802AE430: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    skip_3:
    // 0x802AE434: jal         0x802A4CB8
    // 0x802AE438: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_6;
    // 0x802AE438: nop

    after_6:
    // 0x802AE43C: b           L_802AE47C
    // 0x802AE440: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE47C;
    // 0x802AE440: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AE444: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
L_802AE448:
    // 0x802AE448: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE44C: beql        $v0, $at, L_802AE47C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE450: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE47C;
    }
    goto skip_4;
    // 0x802AE450: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802AE454: b           L_802AE478
    // 0x802AE458: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802AE478;
    // 0x802AE458: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE45C:
    // 0x802AE45C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE460: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE464: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE468: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE46C: beql        $v0, $at, L_802AE47C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE470: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE47C;
    }
    goto skip_5;
    // 0x802AE470: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AE474: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE478:
    // 0x802AE478: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE47C:
    // 0x802AE47C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AE480: jr          $ra
    // 0x802AE484: nop

    return;
    // 0x802AE484: nop

;}
RECOMP_FUNC void func_802AE488_6BFB38(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AE488: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AE48C: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x802AE490: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AE494: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802AE498: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AE49C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE4A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AE4A4: sh          $t6, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r14;
    // 0x802AE4A8: lbu         $v0, 0x162($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X162);
    // 0x802AE4AC: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802AE4B0: andi        $t7, $v0, 0xF
    ctx->r15 = ctx->r2 & 0XF;
    // 0x802AE4B4: beq         $t7, $at, L_802AE4CC
    if (ctx->r15 == ctx->r1) {
        // 0x802AE4B8: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_802AE4CC;
    }
    // 0x802AE4B8: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x802AE4BC: beq         $t7, $at, L_802AE66C
    if (ctx->r15 == ctx->r1) {
        // 0x802AE4C0: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE66C;
    }
    // 0x802AE4C0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE4C4: b           L_802AE68C
    // 0x802AE4C8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE4C8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE4CC:
    // 0x802AE4CC: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802AE4D0: addiu       $at, $zero, 0xC9
    ctx->r1 = ADD32(0, 0XC9);
    // 0x802AE4D4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE4D8: beq         $v0, $at, L_802AE50C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE4DC: addiu       $a2, $a2, -0x6128
        ctx->r6 = ADD32(ctx->r6, -0X6128);
            goto L_802AE50C;
    }
    // 0x802AE4DC: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE4E0: addiu       $at, $zero, 0xCA
    ctx->r1 = ADD32(0, 0XCA);
    // 0x802AE4E4: beq         $v0, $at, L_802AE56C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE4E8: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE56C;
    }
    // 0x802AE4E8: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE4EC: addiu       $at, $zero, 0xCB
    ctx->r1 = ADD32(0, 0XCB);
    // 0x802AE4F0: beq         $v0, $at, L_802AE5C4
    if (ctx->r2 == ctx->r1) {
        // 0x802AE4F4: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE5C4;
    }
    // 0x802AE4F4: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE4F8: addiu       $at, $zero, 0xCC
    ctx->r1 = ADD32(0, 0XCC);
    // 0x802AE4FC: beq         $v0, $at, L_802AE62C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE500: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AE62C;
    }
    // 0x802AE500: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE504: b           L_802AE68C
    // 0x802AE508: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE508: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE50C:
    // 0x802AE50C: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE510: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE514: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE518: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x802AE51C: blez        $v0, L_802AE534
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AE520: nop
    
            goto L_802AE534;
    }
    // 0x802AE520: nop

    // 0x802AE524: jal         0x802A55AC
    // 0x802AE528: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    func_802A55AC_6B6C5C(rdram, ctx);
        goto after_0;
    // 0x802AE528: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    after_0:
    // 0x802AE52C: b           L_802AE68C
    // 0x802AE530: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE530: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE534:
    // 0x802AE534: bgez        $v0, L_802AE550
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AE538: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE550;
    }
    // 0x802AE538: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE53C: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE540: jal         0x802A5620
    // 0x802AE544: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A5620_6B6CD0(rdram, ctx);
        goto after_1;
    // 0x802AE544: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_1:
    // 0x802AE548: b           L_802AE68C
    // 0x802AE54C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE54C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE550:
    // 0x802AE550: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE554: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE558: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE55C: beql        $v0, $at, L_802AE68C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE560: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE68C;
    }
    goto skip_0;
    // 0x802AE560: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AE564: b           L_802AE688
    // 0x802AE568: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802AE688;
    // 0x802AE568: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE56C:
    // 0x802AE56C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE570: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE574: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE578: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE57C: beql        $v0, $at, L_802AE58C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE580: addiu       $v0, $a2, 0x7FFF
        ctx->r2 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE58C;
    }
    goto skip_1;
    // 0x802AE580: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    skip_1:
    // 0x802AE584: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
    // 0x802AE588: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
L_802AE58C:
    // 0x802AE58C: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE590: bgtz        $v0, L_802AE5A8
    if (SIGNED(ctx->r2) > 0) {
        // 0x802AE594: slti        $at, $v0, 0x3
        ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
            goto L_802AE5A8;
    }
    // 0x802AE594: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802AE598: jal         0x802A5558
    // 0x802AE59C: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_2;
    // 0x802AE59C: nop

    after_2:
    // 0x802AE5A0: b           L_802AE68C
    // 0x802AE5A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE5A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE5A8:
    // 0x802AE5A8: bne         $at, $zero, L_802AE688
    if (ctx->r1 != 0) {
        // 0x802AE5AC: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE688;
    }
    // 0x802AE5AC: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE5B0: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE5B4: jal         0x802A5694
    // 0x802AE5B8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802A5694_6B6D44(rdram, ctx);
        goto after_3;
    // 0x802AE5B8: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x802AE5BC: b           L_802AE68C
    // 0x802AE5C0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE5C0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE5C4:
    // 0x802AE5C4: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE5C8: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE5CC: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AE5D0: bgtz        $v0, L_802AE5EC
    if (SIGNED(ctx->r2) > 0) {
        // 0x802AE5D4: slti        $at, $v0, 0x3
        ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
            goto L_802AE5EC;
    }
    // 0x802AE5D4: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x802AE5D8: jal         0x802A5558
    // 0x802AE5DC: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_4;
    // 0x802AE5DC: nop

    after_4:
    // 0x802AE5E0: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE5E4: b           L_802AE608
    // 0x802AE5E8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
        goto L_802AE608;
    // 0x802AE5E8: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AE5EC:
    // 0x802AE5EC: beq         $at, $zero, L_802AE608
    if (ctx->r1 == 0) {
        // 0x802AE5F0: addiu       $a0, $a2, 0x7FFF
        ctx->r4 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AE608;
    }
    // 0x802AE5F0: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE5F4: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AE5F8: jal         0x802A55AC
    // 0x802AE5FC: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A55AC_6B6C5C(rdram, ctx);
        goto after_5;
    // 0x802AE5FC: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_5:
    // 0x802AE600: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AE604: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
L_802AE608:
    // 0x802AE608: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE60C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE610: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE614: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AE618: beql        $v0, $at, L_802AE68C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE61C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE68C;
    }
    goto skip_2;
    // 0x802AE61C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AE620: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802AE624: b           L_802AE688
    // 0x802AE628: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
        goto L_802AE688;
    // 0x802AE628: sh          $v0, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r2;
L_802AE62C:
    // 0x802AE62C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE630: addiu       $t9, $a2, 0x7FFF
    ctx->r25 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE634: lh          $t9, 0x7FDB($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X7FDB);
    // 0x802AE638: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE63C: bltzl       $t9, L_802AE658
    if (SIGNED(ctx->r25) < 0) {
        // 0x802AE640: lh          $v0, 0x7FA9($v0)
        ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
            goto L_802AE658;
    }
    goto skip_3;
    // 0x802AE640: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    skip_3:
    // 0x802AE644: jal         0x802A5558
    // 0x802AE648: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_6;
    // 0x802AE648: nop

    after_6:
    // 0x802AE64C: b           L_802AE68C
    // 0x802AE650: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AE68C;
    // 0x802AE650: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AE654: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
L_802AE658:
    // 0x802AE658: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE65C: beql        $v0, $at, L_802AE68C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE660: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE68C;
    }
    goto skip_4;
    // 0x802AE660: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802AE664: b           L_802AE688
    // 0x802AE668: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
        goto L_802AE688;
    // 0x802AE668: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE66C:
    // 0x802AE66C: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AE670: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AE674: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AE678: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AE67C: beql        $v0, $at, L_802AE68C
    if (ctx->r2 == ctx->r1) {
        // 0x802AE680: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE68C;
    }
    goto skip_5;
    // 0x802AE680: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AE684: sh          $v0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r2;
L_802AE688:
    // 0x802AE688: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE68C:
    // 0x802AE68C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AE690: jr          $ra
    // 0x802AE694: nop

    return;
    // 0x802AE694: nop

;}
RECOMP_FUNC void func_802AE698_6BFD48(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AE698: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AE69C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802AE6A0: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE6A4: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802AE6A8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AE6AC: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802AE6B0: addiu       $at, $zero, 0x51
    ctx->r1 = ADD32(0, 0X51);
    // 0x802AE6B4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AE6B8: bne         $t6, $at, L_802AE9B4
    if (ctx->r14 != ctx->r1) {
        // 0x802AE6BC: lui         $a3, 0x801E
        ctx->r7 = S32(0X801E << 16);
            goto L_802AE9B4;
    }
    // 0x802AE6BC: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802AE6C0: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802AE6C4: addiu       $t7, $a3, 0x7FFF
    ctx->r15 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AE6C8: lh          $t7, 0x7FDD($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X7FDD);
    // 0x802AE6CC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802AE6D0: lh          $v0, 0x557C($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X557C);
    // 0x802AE6D4: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x802AE6D8: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x802AE6DC: mflo        $t9
    ctx->r25 = lo;
    // 0x802AE6E0: addu        $v0, $v0, $t9
    ctx->r2 = ADD32(ctx->r2, ctx->r25);
    // 0x802AE6E4: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802AE6E8: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802AE6EC: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
    // 0x802AE6F0: lh          $t4, 0x2C($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X2C);
    // 0x802AE6F4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AE6F8: addiu       $t2, $t2, 0x552C
    ctx->r10 = ADD32(ctx->r10, 0X552C);
    // 0x802AE6FC: bgez        $v0, L_802AE70C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AE700: sra         $v1, $v0, 5
        ctx->r3 = S32(SIGNED(ctx->r2) >> 5);
            goto L_802AE70C;
    }
    // 0x802AE700: sra         $v1, $v0, 5
    ctx->r3 = S32(SIGNED(ctx->r2) >> 5);
    // 0x802AE704: addiu       $at, $v0, 0x1F
    ctx->r1 = ADD32(ctx->r2, 0X1F);
    // 0x802AE708: sra         $v1, $at, 5
    ctx->r3 = S32(SIGNED(ctx->r1) >> 5);
L_802AE70C:
    // 0x802AE70C: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x802AE710: addu        $t5, $t4, $a2
    ctx->r13 = ADD32(ctx->r12, ctx->r6);
    // 0x802AE714: sh          $t5, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r13;
    // 0x802AE718: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE71C: sll         $t8, $v1, 5
    ctx->r24 = S32(ctx->r3 << 5);
    // 0x802AE720: subu        $v0, $v0, $t8
    ctx->r2 = SUB32(ctx->r2, ctx->r24);
    // 0x802AE724: lh          $t6, 0x2C($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2C);
    // 0x802AE728: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802AE72C: addiu       $t8, $a3, 0x7FFF
    ctx->r24 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AE730: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802AE734: sh          $t7, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r15;
    // 0x802AE738: lh          $t8, 0x7FDD($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X7FDD);
    // 0x802AE73C: sra         $t3, $t9, 16
    ctx->r11 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802AE740: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    // 0x802AE744: lw          $t3, 0x0($t2)
    ctx->r11 = MEM_W(ctx->r10, 0X0);
    // 0x802AE748: bgez        $t8, L_802AE758
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802AE74C: sra         $t9, $t8, 4
        ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
            goto L_802AE758;
    }
    // 0x802AE74C: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802AE750: addiu       $at, $t8, 0xF
    ctx->r1 = ADD32(ctx->r24, 0XF);
    // 0x802AE754: sra         $t9, $at, 4
    ctx->r25 = S32(SIGNED(ctx->r1) >> 4);
L_802AE758:
    // 0x802AE758: sh          $t9, 0x306($t3)
    MEM_H(0X306, ctx->r11) = ctx->r25;
    // 0x802AE75C: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE760: addiu       $t4, $a3, 0x7FFF
    ctx->r12 = ADD32(ctx->r7, 0X7FFF);
    // 0x802AE764: lh          $t4, 0x7FDF($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X7FDF);
    // 0x802AE768: lh          $t0, 0x28($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X28);
    // 0x802AE76C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AE770: sh          $v0, 0x557C($at)
    MEM_H(0X557C, ctx->r1) = ctx->r2;
    // 0x802AE774: subu        $a1, $t4, $t0
    ctx->r5 = SUB32(ctx->r12, ctx->r8);
    // 0x802AE778: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x802AE77C: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802AE780: blez        $t6, L_802AE7A8
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802AE784: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_802AE7A8;
    }
    // 0x802AE784: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802AE788: slti        $at, $t6, 0xA
    ctx->r1 = SIGNED(ctx->r14) < 0XA ? 1 : 0;
    // 0x802AE78C: beq         $at, $zero, L_802AE79C
    if (ctx->r1 == 0) {
        // 0x802AE790: addiu       $v1, $zero, 0xA
        ctx->r3 = ADD32(0, 0XA);
            goto L_802AE79C;
    }
    // 0x802AE790: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
    // 0x802AE794: b           L_802AE79C
    // 0x802AE798: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
        goto L_802AE79C;
    // 0x802AE798: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_802AE79C:
    // 0x802AE79C: addu        $t7, $t0, $v1
    ctx->r15 = ADD32(ctx->r8, ctx->r3);
    // 0x802AE7A0: b           L_802AE7C4
    // 0x802AE7A4: sh          $t7, 0x28($a0)
    MEM_H(0X28, ctx->r4) = ctx->r15;
        goto L_802AE7C4;
    // 0x802AE7A4: sh          $t7, 0x28($a0)
    MEM_H(0X28, ctx->r4) = ctx->r15;
L_802AE7A8:
    // 0x802AE7A8: slti        $at, $a1, -0x9
    ctx->r1 = SIGNED(ctx->r5) < -0X9 ? 1 : 0;
    // 0x802AE7AC: bne         $at, $zero, L_802AE7BC
    if (ctx->r1 != 0) {
        // 0x802AE7B0: addiu       $v1, $zero, -0xA
        ctx->r3 = ADD32(0, -0XA);
            goto L_802AE7BC;
    }
    // 0x802AE7B0: addiu       $v1, $zero, -0xA
    ctx->r3 = ADD32(0, -0XA);
    // 0x802AE7B4: b           L_802AE7BC
    // 0x802AE7B8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802AE7BC;
    // 0x802AE7B8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802AE7BC:
    // 0x802AE7BC: addu        $t8, $t0, $v1
    ctx->r24 = ADD32(ctx->r8, ctx->r3);
    // 0x802AE7C0: sh          $t8, 0x28($a0)
    MEM_H(0X28, ctx->r4) = ctx->r24;
L_802AE7C4:
    // 0x802AE7C4: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802AE7C8: lh          $a3, 0x28($t9)
    ctx->r7 = MEM_H(ctx->r25, 0X28);
    // 0x802AE7CC: sll         $t3, $a3, 15
    ctx->r11 = S32(ctx->r7 << 15);
    // 0x802AE7D0: jal         0x802B2580
    // 0x802AE7D4: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    get_distance_from_ground(rdram, ctx);
        goto after_0;
    // 0x802AE7D4: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    after_0:
    // 0x802AE7D8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AE7DC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AE7E0: slti        $at, $v0, 0xA81
    ctx->r1 = SIGNED(ctx->r2) < 0XA81 ? 1 : 0;
    // 0x802AE7E4: addiu       $t2, $t2, 0x552C
    ctx->r10 = ADD32(ctx->r10, 0X552C);
    // 0x802AE7E8: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802AE7EC: bne         $at, $zero, L_802AE808
    if (ctx->r1 != 0) {
        // 0x802AE7F0: lw          $a3, 0x1C($sp)
        ctx->r7 = MEM_W(ctx->r29, 0X1C);
            goto L_802AE808;
    }
    // 0x802AE7F0: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x802AE7F4: lui         $v1, 0xFFFF
    ctx->r3 = S32(0XFFFF << 16);
    // 0x802AE7F8: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802AE7FC: bnel        $at, $zero, L_802AE80C
    if (ctx->r1 != 0) {
        // 0x802AE800: slti        $at, $v0, 0xA01
        ctx->r1 = SIGNED(ctx->r2) < 0XA01 ? 1 : 0;
            goto L_802AE80C;
    }
    goto skip_0;
    // 0x802AE800: slti        $at, $v0, 0xA01
    ctx->r1 = SIGNED(ctx->r2) < 0XA01 ? 1 : 0;
    skip_0:
    // 0x802AE804: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
L_802AE808:
    // 0x802AE808: slti        $at, $v0, 0xA01
    ctx->r1 = SIGNED(ctx->r2) < 0XA01 ? 1 : 0;
L_802AE80C:
    // 0x802AE80C: bne         $at, $zero, L_802AE830
    if (ctx->r1 != 0) {
        // 0x802AE810: addiu       $t4, $zero, 0xA00
        ctx->r12 = ADD32(0, 0XA00);
            goto L_802AE830;
    }
    // 0x802AE810: addiu       $t4, $zero, 0xA00
    ctx->r12 = ADD32(0, 0XA00);
    // 0x802AE814: subu        $v1, $t4, $v0
    ctx->r3 = SUB32(ctx->r12, ctx->r2);
    // 0x802AE818: sll         $t5, $v1, 9
    ctx->r13 = S32(ctx->r3 << 9);
    // 0x802AE81C: slt         $at, $a3, $t5
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802AE820: bnel        $at, $zero, L_802AE850
    if (ctx->r1 != 0) {
        // 0x802AE824: lw          $a0, 0x0($t1)
        ctx->r4 = MEM_W(ctx->r9, 0X0);
            goto L_802AE850;
    }
    goto skip_1;
    // 0x802AE824: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    skip_1:
    // 0x802AE828: b           L_802AE84C
    // 0x802AE82C: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
        goto L_802AE84C;
    // 0x802AE82C: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
L_802AE830:
    // 0x802AE830: slti        $at, $v0, 0x981
    ctx->r1 = SIGNED(ctx->r2) < 0X981 ? 1 : 0;
    // 0x802AE834: bne         $at, $zero, L_802AE84C
    if (ctx->r1 != 0) {
        // 0x802AE838: sra         $v1, $a3, 1
        ctx->r3 = S32(SIGNED(ctx->r7) >> 1);
            goto L_802AE84C;
    }
    // 0x802AE838: sra         $v1, $a3, 1
    ctx->r3 = S32(SIGNED(ctx->r7) >> 1);
    // 0x802AE83C: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802AE840: bnel        $at, $zero, L_802AE850
    if (ctx->r1 != 0) {
        // 0x802AE844: lw          $a0, 0x0($t1)
        ctx->r4 = MEM_W(ctx->r9, 0X0);
            goto L_802AE850;
    }
    goto skip_2;
    // 0x802AE844: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    skip_2:
    // 0x802AE848: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
L_802AE84C:
    // 0x802AE84C: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
L_802AE850:
    // 0x802AE850: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
    // 0x802AE854: slti        $at, $v1, 0x15
    ctx->r1 = SIGNED(ctx->r3) < 0X15 ? 1 : 0;
    // 0x802AE858: bne         $at, $zero, L_802AE86C
    if (ctx->r1 != 0) {
        // 0x802AE85C: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_802AE86C;
    }
    // 0x802AE85C: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x802AE860: sh          $t6, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r14;
    // 0x802AE864: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE868: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
L_802AE86C:
    // 0x802AE86C: slti        $at, $v1, -0x14
    ctx->r1 = SIGNED(ctx->r3) < -0X14 ? 1 : 0;
    // 0x802AE870: beq         $at, $zero, L_802AE884
    if (ctx->r1 == 0) {
        // 0x802AE874: addiu       $t7, $v1, 0x1
        ctx->r15 = ADD32(ctx->r3, 0X1);
            goto L_802AE884;
    }
    // 0x802AE874: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x802AE878: sh          $t7, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r15;
    // 0x802AE87C: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE880: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
L_802AE884:
    // 0x802AE884: slti        $at, $v1, 0x11
    ctx->r1 = SIGNED(ctx->r3) < 0X11 ? 1 : 0;
    // 0x802AE888: bne         $at, $zero, L_802AE89C
    if (ctx->r1 != 0) {
        // 0x802AE88C: addiu       $t8, $v1, -0x1
        ctx->r24 = ADD32(ctx->r3, -0X1);
            goto L_802AE89C;
    }
    // 0x802AE88C: addiu       $t8, $v1, -0x1
    ctx->r24 = ADD32(ctx->r3, -0X1);
    // 0x802AE890: sh          $t8, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r24;
    // 0x802AE894: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE898: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
L_802AE89C:
    // 0x802AE89C: slti        $at, $v1, -0x10
    ctx->r1 = SIGNED(ctx->r3) < -0X10 ? 1 : 0;
    // 0x802AE8A0: beq         $at, $zero, L_802AE8B4
    if (ctx->r1 == 0) {
        // 0x802AE8A4: addiu       $t9, $v1, 0x1
        ctx->r25 = ADD32(ctx->r3, 0X1);
            goto L_802AE8B4;
    }
    // 0x802AE8A4: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x802AE8A8: sh          $t9, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r25;
    // 0x802AE8AC: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE8B0: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
L_802AE8B4:
    // 0x802AE8B4: slti        $at, $v1, 0xD
    ctx->r1 = SIGNED(ctx->r3) < 0XD ? 1 : 0;
    // 0x802AE8B8: bne         $at, $zero, L_802AE8CC
    if (ctx->r1 != 0) {
        // 0x802AE8BC: addiu       $t3, $v1, -0x1
        ctx->r11 = ADD32(ctx->r3, -0X1);
            goto L_802AE8CC;
    }
    // 0x802AE8BC: addiu       $t3, $v1, -0x1
    ctx->r11 = ADD32(ctx->r3, -0X1);
    // 0x802AE8C0: sh          $t3, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r11;
    // 0x802AE8C4: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE8C8: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
L_802AE8CC:
    // 0x802AE8CC: slti        $at, $v1, -0xC
    ctx->r1 = SIGNED(ctx->r3) < -0XC ? 1 : 0;
    // 0x802AE8D0: beq         $at, $zero, L_802AE8E0
    if (ctx->r1 == 0) {
        // 0x802AE8D4: addiu       $t4, $v1, 0x1
        ctx->r12 = ADD32(ctx->r3, 0X1);
            goto L_802AE8E0;
    }
    // 0x802AE8D4: addiu       $t4, $v1, 0x1
    ctx->r12 = ADD32(ctx->r3, 0X1);
    // 0x802AE8D8: sh          $t4, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r12;
    // 0x802AE8DC: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
L_802AE8E0:
    // 0x802AE8E0: lw          $a2, 0x24($a0)
    ctx->r6 = MEM_W(ctx->r4, 0X24);
    // 0x802AE8E4: ori         $at, $zero, 0xC001
    ctx->r1 = 0 | 0XC001;
    // 0x802AE8E8: subu        $a1, $a3, $a2
    ctx->r5 = SUB32(ctx->r7, ctx->r6);
    // 0x802AE8EC: blez        $a1, L_802AE914
    if (SIGNED(ctx->r5) <= 0) {
        // 0x802AE8F0: lui         $a3, 0xFFFF
        ctx->r7 = S32(0XFFFF << 16);
            goto L_802AE914;
    }
    // 0x802AE8F0: lui         $a3, 0xFFFF
    ctx->r7 = S32(0XFFFF << 16);
    // 0x802AE8F4: slt         $at, $a1, $at
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802AE8F8: bne         $at, $zero, L_802AE908
    if (ctx->r1 != 0) {
        // 0x802AE8FC: or          $v1, $a1, $zero
        ctx->r3 = ctx->r5 | 0;
            goto L_802AE908;
    }
    // 0x802AE8FC: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x802AE900: b           L_802AE908
    // 0x802AE904: ori         $v1, $zero, 0xC000
    ctx->r3 = 0 | 0XC000;
        goto L_802AE908;
    // 0x802AE904: ori         $v1, $zero, 0xC000
    ctx->r3 = 0 | 0XC000;
L_802AE908:
    // 0x802AE908: addu        $t5, $a2, $v1
    ctx->r13 = ADD32(ctx->r6, ctx->r3);
    // 0x802AE90C: b           L_802AE934
    // 0x802AE910: sw          $t5, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r13;
        goto L_802AE934;
    // 0x802AE910: sw          $t5, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r13;
L_802AE914:
    // 0x802AE914: ori         $a3, $a3, 0x4000
    ctx->r7 = ctx->r7 | 0X4000;
    // 0x802AE918: slt         $at, $a1, $a3
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802AE91C: beq         $at, $zero, L_802AE92C
    if (ctx->r1 == 0) {
        // 0x802AE920: or          $v1, $a1, $zero
        ctx->r3 = ctx->r5 | 0;
            goto L_802AE92C;
    }
    // 0x802AE920: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x802AE924: b           L_802AE92C
    // 0x802AE928: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
        goto L_802AE92C;
    // 0x802AE928: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
L_802AE92C:
    // 0x802AE92C: addu        $t6, $a2, $v1
    ctx->r14 = ADD32(ctx->r6, ctx->r3);
    // 0x802AE930: sw          $t6, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r14;
L_802AE934:
    // 0x802AE934: lw          $a1, 0x0($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X0);
    // 0x802AE938: addiu       $at, $zero, 0x2F
    ctx->r1 = ADD32(0, 0X2F);
    // 0x802AE93C: lbu         $t7, 0x365($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X365);
    // 0x802AE940: bne         $t7, $at, L_802AE980
    if (ctx->r15 != ctx->r1) {
        // 0x802AE944: slti        $at, $v0, 0x9E0
        ctx->r1 = SIGNED(ctx->r2) < 0X9E0 ? 1 : 0;
            goto L_802AE980;
    }
    // 0x802AE944: slti        $at, $v0, 0x9E0
    ctx->r1 = SIGNED(ctx->r2) < 0X9E0 ? 1 : 0;
    // 0x802AE948: bnel        $at, $zero, L_802AE968
    if (ctx->r1 != 0) {
        // 0x802AE94C: sb          $zero, 0x365($a1)
        MEM_B(0X365, ctx->r5) = 0;
            goto L_802AE968;
    }
    goto skip_3;
    // 0x802AE94C: sb          $zero, 0x365($a1)
    MEM_B(0X365, ctx->r5) = 0;
    skip_3:
    // 0x802AE950: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802AE954: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
    // 0x802AE958: slti        $at, $v1, -0x8
    ctx->r1 = SIGNED(ctx->r3) < -0X8 ? 1 : 0;
    // 0x802AE95C: beql        $at, $zero, L_802AE978
    if (ctx->r1 == 0) {
        // 0x802AE960: addiu       $t8, $v1, -0x2
        ctx->r24 = ADD32(ctx->r3, -0X2);
            goto L_802AE978;
    }
    goto skip_4;
    // 0x802AE960: addiu       $t8, $v1, -0x2
    ctx->r24 = ADD32(ctx->r3, -0X2);
    skip_4:
    // 0x802AE964: sb          $zero, 0x365($a1)
    MEM_B(0X365, ctx->r5) = 0;
L_802AE968:
    // 0x802AE968: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AE96C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x802AE970: lh          $v1, 0x24($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X24);
    // 0x802AE974: addiu       $t8, $v1, -0x2
    ctx->r24 = ADD32(ctx->r3, -0X2);
L_802AE978:
    // 0x802AE978: b           L_802AE9B4
    // 0x802AE97C: sh          $t8, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r24;
        goto L_802AE9B4;
    // 0x802AE97C: sh          $t8, 0x24($a0)
    MEM_H(0X24, ctx->r4) = ctx->r24;
L_802AE980:
    // 0x802AE980: slti        $at, $v0, 0x9F7
    ctx->r1 = SIGNED(ctx->r2) < 0X9F7 ? 1 : 0;
    // 0x802AE984: bnel        $at, $zero, L_802AE9B8
    if (ctx->r1 != 0) {
        // 0x802AE988: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE9B8;
    }
    goto skip_5;
    // 0x802AE988: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802AE98C: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802AE990: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AE994: lw          $t3, 0x24($t9)
    ctx->r11 = MEM_W(ctx->r25, 0X24);
    // 0x802AE998: blezl       $t3, L_802AE9B8
    if (SIGNED(ctx->r11) <= 0) {
        // 0x802AE99C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AE9B8;
    }
    goto skip_6;
    // 0x802AE99C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x802AE9A0: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x802AE9A4: addiu       $t5, $zero, 0x2F
    ctx->r13 = ADD32(0, 0X2F);
    // 0x802AE9A8: sh          $t4, 0x32A($a1)
    MEM_H(0X32A, ctx->r5) = ctx->r12;
    // 0x802AE9AC: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x802AE9B0: sb          $t5, 0x365($t6)
    MEM_B(0X365, ctx->r14) = ctx->r13;
L_802AE9B4:
    // 0x802AE9B4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AE9B8:
    // 0x802AE9B8: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802AE9BC: jr          $ra
    // 0x802AE9C0: nop

    return;
    // 0x802AE9C0: nop

;}
RECOMP_FUNC void func_802AE9C4_6C0074(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AE9C4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802AE9C8: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802AE9CC: lw          $t6, 0x0($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X0);
    // 0x802AE9D0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AE9D4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AE9D8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AE9DC: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802AE9E0: sh          $zero, 0x30E($t6)
    MEM_H(0X30E, ctx->r14) = 0;
    // 0x802AE9E4: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
    // 0x802AE9E8: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AE9EC: addiu       $at, $zero, 0x29
    ctx->r1 = ADD32(0, 0X29);
    // 0x802AE9F0: lbu         $t7, 0x162($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X162);
    // 0x802AE9F4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AE9F8: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x802AE9FC: bnel        $a1, $t8, L_802AEA20
    if (ctx->r5 != ctx->r24) {
        // 0x802AEA00: lhu         $v1, 0x0($a0)
        ctx->r3 = MEM_HU(ctx->r4, 0X0);
            goto L_802AEA20;
    }
    goto skip_0;
    // 0x802AEA00: lhu         $v1, 0x0($a0)
    ctx->r3 = MEM_HU(ctx->r4, 0X0);
    skip_0:
    // 0x802AEA04: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802AEA08: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
    // 0x802AEA0C: blez        $v0, L_802AEA1C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AEA10: addiu       $t9, $v0, -0x1
        ctx->r25 = ADD32(ctx->r2, -0X1);
            goto L_802AEA1C;
    }
    // 0x802AEA10: addiu       $t9, $v0, -0x1
    ctx->r25 = ADD32(ctx->r2, -0X1);
    // 0x802AEA14: sh          $t9, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r25;
    // 0x802AEA18: lw          $a0, 0x0($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X0);
L_802AEA1C:
    // 0x802AEA1C: lhu         $v1, 0x0($a0)
    ctx->r3 = MEM_HU(ctx->r4, 0X0);
L_802AEA20:
    // 0x802AEA20: beq         $v1, $a1, L_802AEA40
    if (ctx->r3 == ctx->r5) {
        // 0x802AEA24: nop
    
            goto L_802AEA40;
    }
    // 0x802AEA24: nop

    // 0x802AEA28: beq         $v1, $at, L_802AEA40
    if (ctx->r3 == ctx->r1) {
        // 0x802AEA2C: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_802AEA40;
    }
    // 0x802AEA2C: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x802AEA30: beq         $v1, $at, L_802AEB84
    if (ctx->r3 == ctx->r1) {
        // 0x802AEA34: lui         $a1, 0x801E
        ctx->r5 = S32(0X801E << 16);
            goto L_802AEB84;
    }
    // 0x802AEA34: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x802AEA38: b           L_802AEBA4
    // 0x802AEA3C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802AEBA4;
    // 0x802AEA3C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AEA40:
    // 0x802AEA40: lhu         $t1, 0x5544($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X5544);
    // 0x802AEA44: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AEA48: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x802AEA4C: sh          $t1, 0x555A($at)
    MEM_H(0X555A, ctx->r1) = ctx->r9;
    // 0x802AEA50: lw          $t2, 0x6C($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X6C);
    // 0x802AEA54: addiu       $a1, $a1, -0x6128
    ctx->r5 = ADD32(ctx->r5, -0X6128);
    // 0x802AEA58: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AEA5C: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEA60: sw          $t2, 0x5560($at)
    MEM_W(0X5560, ctx->r1) = ctx->r10;
    // 0x802AEA64: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AEA68: addiu       $a2, $zero, 0x100
    ctx->r6 = ADD32(0, 0X100);
    // 0x802AEA6C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802AEA70: beq         $a2, $v0, L_802AEAF8
    if (ctx->r6 == ctx->r2) {
        // 0x802AEA74: addiu       $t3, $a1, 0x7FFF
        ctx->r11 = ADD32(ctx->r5, 0X7FFF);
            goto L_802AEAF8;
    }
    // 0x802AEA74: addiu       $t3, $a1, 0x7FFF
    ctx->r11 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEA78: lhu         $t3, 0x7FB3($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X7FB3);
    // 0x802AEA7C: beq         $t3, $zero, L_802AEAF8
    if (ctx->r11 == 0) {
        // 0x802AEA80: nop
    
            goto L_802AEAF8;
    }
    // 0x802AEA80: nop

    // 0x802AEA84: lh          $t4, 0x30C($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X30C);
    // 0x802AEA88: bne         $t4, $zero, L_802AEAF8
    if (ctx->r12 != 0) {
        // 0x802AEA8C: nop
    
            goto L_802AEAF8;
    }
    // 0x802AEA8C: nop

    // 0x802AEA90: lbu         $t5, 0x367($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X367);
    // 0x802AEA94: bgtz        $t5, L_802AEAF8
    if (SIGNED(ctx->r13) > 0) {
        // 0x802AEA98: nop
    
            goto L_802AEAF8;
    }
    // 0x802AEA98: nop

    // 0x802AEA9C: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEAA0: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AEAA4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802AEAA8: bgez        $v0, L_802AEAB8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AEAAC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802AEAB8;
    }
    // 0x802AEAAC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802AEAB0: b           L_802AEAB8
    // 0x802AEAB4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802AEAB8;
    // 0x802AEAB4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802AEAB8:
    // 0x802AEAB8: sll         $a0, $v1, 16
    ctx->r4 = S32(ctx->r3 << 16);
    // 0x802AEABC: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802AEAC0: jal         0x802A5778
    // 0x802AEAC4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_802A5778_6B6E28(rdram, ctx);
        goto after_0;
    // 0x802AEAC4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_0:
    // 0x802AEAC8: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802AEACC: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802AEAD0: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802AEAD4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AEAD8: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802AEADC: lh          $t7, 0x30A($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X30A);
    // 0x802AEAE0: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x802AEAE4: addiu       $t8, $t7, 0x20
    ctx->r24 = ADD32(ctx->r15, 0X20);
    // 0x802AEAE8: sh          $t8, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = ctx->r24;
    // 0x802AEAEC: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x802AEAF0: b           L_802AEBA0
    // 0x802AEAF4: sb          $t9, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r25;
        goto L_802AEBA0;
    // 0x802AEAF4: sb          $t9, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r25;
L_802AEAF8:
    // 0x802AEAF8: bne         $a2, $v0, L_802AEB48
    if (ctx->r6 != ctx->r2) {
        // 0x802AEAFC: addiu       $t2, $a1, 0x7FFF
        ctx->r10 = ADD32(ctx->r5, 0X7FFF);
            goto L_802AEB48;
    }
    // 0x802AEAFC: addiu       $t2, $a1, 0x7FFF
    ctx->r10 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEB00: lhu         $t2, 0x7FB3($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X7FB3);
    // 0x802AEB04: beq         $t2, $zero, L_802AEB48
    if (ctx->r10 == 0) {
        // 0x802AEB08: nop
    
            goto L_802AEB48;
    }
    // 0x802AEB08: nop

    // 0x802AEB0C: lh          $t3, 0x30C($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X30C);
    // 0x802AEB10: bne         $t3, $zero, L_802AEB48
    if (ctx->r11 != 0) {
        // 0x802AEB14: nop
    
            goto L_802AEB48;
    }
    // 0x802AEB14: nop

    // 0x802AEB18: lbu         $t4, 0x367($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X367);
    // 0x802AEB1C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802AEB20: bgtz        $t4, L_802AEB48
    if (SIGNED(ctx->r12) > 0) {
        // 0x802AEB24: nop
    
            goto L_802AEB48;
    }
    // 0x802AEB24: nop

    // 0x802AEB28: jal         0x802A5778
    // 0x802AEB2C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_802A5778_6B6E28(rdram, ctx);
        goto after_1;
    // 0x802AEB2C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_1:
    // 0x802AEB30: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AEB34: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802AEB38: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x802AEB3C: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x802AEB40: b           L_802AEBA0
    // 0x802AEB44: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
        goto L_802AEBA0;
    // 0x802AEB44: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
L_802AEB48:
    // 0x802AEB48: beq         $a2, $v0, L_802AEB7C
    if (ctx->r6 == ctx->r2) {
        // 0x802AEB4C: addiu       $t7, $a1, 0x7FFF
        ctx->r15 = ADD32(ctx->r5, 0X7FFF);
            goto L_802AEB7C;
    }
    // 0x802AEB4C: addiu       $t7, $a1, 0x7FFF
    ctx->r15 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEB50: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEB54: lh          $v0, 0x7FDB($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDB);
    // 0x802AEB58: bgezl       $v0, L_802AEB6C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AEB5C: sh          $v0, 0x30E($v1)
        MEM_H(0X30E, ctx->r3) = ctx->r2;
            goto L_802AEB6C;
    }
    goto skip_1;
    // 0x802AEB5C: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
    skip_1:
    // 0x802AEB60: b           L_802AEB6C
    // 0x802AEB64: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
        goto L_802AEB6C;
    // 0x802AEB64: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
    // 0x802AEB68: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
L_802AEB6C:
    // 0x802AEB6C: lh          $t7, 0x7FA9($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X7FA9);
    // 0x802AEB70: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x802AEB74: b           L_802AEBA0
    // 0x802AEB78: sh          $t7, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r15;
        goto L_802AEBA0;
    // 0x802AEB78: sh          $t7, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r15;
L_802AEB7C:
    // 0x802AEB7C: b           L_802AEBA0
    // 0x802AEB80: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
        goto L_802AEBA0;
    // 0x802AEB80: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
L_802AEB84:
    // 0x802AEB84: addiu       $a1, $a1, -0x6128
    ctx->r5 = ADD32(ctx->r5, -0X6128);
    // 0x802AEB88: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEB8C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AEB90: addiu       $a2, $zero, 0x100
    ctx->r6 = ADD32(0, 0X100);
    // 0x802AEB94: beql        $a2, $v0, L_802AEBA4
    if (ctx->r6 == ctx->r2) {
        // 0x802AEB98: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AEBA4;
    }
    goto skip_2;
    // 0x802AEB98: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AEB9C: sh          $v0, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r2;
L_802AEBA0:
    // 0x802AEBA0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AEBA4:
    // 0x802AEBA4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AEBA8: jr          $ra
    // 0x802AEBAC: nop

    return;
    // 0x802AEBAC: nop

;}
RECOMP_FUNC void func_802AEBB0_6C0260(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AEBB0: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AEBB4: addiu       $a2, $a2, 0x552C
    ctx->r6 = ADD32(ctx->r6, 0X552C);
    // 0x802AEBB8: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x802AEBBC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AEBC0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AEBC4: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802AEBC8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802AEBCC: addiu       $a1, $a1, 0x5530
    ctx->r5 = ADD32(ctx->r5, 0X5530);
    // 0x802AEBD0: slti        $at, $v1, 0x5
    ctx->r1 = SIGNED(ctx->r3) < 0X5 ? 1 : 0;
    // 0x802AEBD4: bne         $at, $zero, L_802AEBE0
    if (ctx->r1 != 0) {
        // 0x802AEBD8: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_802AEBE0;
    }
    // 0x802AEBD8: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x802AEBDC: sh          $t6, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r14;
L_802AEBE0:
    // 0x802AEBE0: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802AEBE4: lui         $at, 0x6
    ctx->r1 = S32(0X6 << 16);
    // 0x802AEBE8: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802AEBEC: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802AEBF0: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802AEBF4: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802AEBF8: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802AEBFC: beq         $at, $zero, L_802AEC10
    if (ctx->r1 == 0) {
        // 0x802AEC00: sll         $t7, $v1, 3
        ctx->r15 = S32(ctx->r3 << 3);
            goto L_802AEC10;
    }
    // 0x802AEC00: sll         $t7, $v1, 3
    ctx->r15 = S32(ctx->r3 << 3);
    // 0x802AEC04: lui         $at, 0xFFFA
    ctx->r1 = S32(0XFFFA << 16);
    // 0x802AEC08: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802AEC0C: beq         $at, $zero, L_802AEC20
    if (ctx->r1 == 0) {
        // 0x802AEC10: subu        $t7, $t7, $v1
        ctx->r15 = SUB32(ctx->r15, ctx->r3);
            goto L_802AEC20;
    }
L_802AEC10:
    // 0x802AEC10: subu        $t7, $t7, $v1
    ctx->r15 = SUB32(ctx->r15, ctx->r3);
    // 0x802AEC14: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x802AEC18: sw          $t8, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r24;
    // 0x802AEC1C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
L_802AEC20:
    // 0x802AEC20: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802AEC24: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AEC28: addiu       $t9, $a0, 0x7FFF
    ctx->r25 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AEC2C: beq         $v1, $at, L_802AEC60
    if (ctx->r3 == ctx->r1) {
        // 0x802AEC30: addiu       $at, $zero, 0x79
        ctx->r1 = ADD32(0, 0X79);
            goto L_802AEC60;
    }
    // 0x802AEC30: addiu       $at, $zero, 0x79
    ctx->r1 = ADD32(0, 0X79);
    // 0x802AEC34: beq         $v1, $at, L_802AEC60
    if (ctx->r3 == ctx->r1) {
        // 0x802AEC38: addiu       $at, $zero, 0x7A
        ctx->r1 = ADD32(0, 0X7A);
            goto L_802AEC60;
    }
    // 0x802AEC38: addiu       $at, $zero, 0x7A
    ctx->r1 = ADD32(0, 0X7A);
    // 0x802AEC3C: beq         $v1, $at, L_802AEC9C
    if (ctx->r3 == ctx->r1) {
        // 0x802AEC40: lui         $a0, 0x801E
        ctx->r4 = S32(0X801E << 16);
            goto L_802AEC9C;
    }
    // 0x802AEC40: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802AEC44: addiu       $at, $zero, 0x7B
    ctx->r1 = ADD32(0, 0X7B);
    // 0x802AEC48: beq         $v1, $at, L_802AEC9C
    if (ctx->r3 == ctx->r1) {
        // 0x802AEC4C: nop
    
            goto L_802AEC9C;
    }
    // 0x802AEC4C: nop

    // 0x802AEC50: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AEC54: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AEC58: b           L_802AEDEC
    // 0x802AEC5C: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
        goto L_802AEDEC;
    // 0x802AEC5C: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802AEC60:
    // 0x802AEC60: addiu       $v1, $a0, 0x7FFF
    ctx->r3 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AEC64: lh          $v1, 0x7FA9($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7FA9);
    // 0x802AEC68: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AEC6C: beql        $v1, $at, L_802AEC7C
    if (ctx->r3 == ctx->r1) {
        // 0x802AEC70: lhu         $t9, 0x7FB3($t9)
        ctx->r25 = MEM_HU(ctx->r25, 0X7FB3);
            goto L_802AEC7C;
    }
    goto skip_0;
    // 0x802AEC70: lhu         $t9, 0x7FB3($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X7FB3);
    skip_0:
    // 0x802AEC74: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
    // 0x802AEC78: lhu         $t9, 0x7FB3($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X7FB3);
L_802AEC7C:
    // 0x802AEC7C: beq         $t9, $zero, L_802AEC8C
    if (ctx->r25 == 0) {
        // 0x802AEC80: nop
    
            goto L_802AEC8C;
    }
    // 0x802AEC80: nop

    // 0x802AEC84: jal         0x802A5CF4
    // 0x802AEC88: nop

    func_802A5CF4_6B73A4(rdram, ctx);
        goto after_0;
    // 0x802AEC88: nop

    after_0:
L_802AEC8C:
    // 0x802AEC8C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AEC90: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AEC94: b           L_802AEDEC
    // 0x802AEC98: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
        goto L_802AEDEC;
    // 0x802AEC98: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802AEC9C:
    // 0x802AEC9C: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802AECA0: addiu       $v1, $a0, 0x7FFF
    ctx->r3 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AECA4: lh          $v1, 0x7FA9($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7FA9);
    // 0x802AECA8: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AECAC: addiu       $t6, $zero, 0x7B
    ctx->r14 = ADD32(0, 0X7B);
    // 0x802AECB0: beq         $v1, $at, L_802AECE4
    if (ctx->r3 == ctx->r1) {
        // 0x802AECB4: addiu       $t8, $a0, 0x7FFF
        ctx->r24 = ADD32(ctx->r4, 0X7FFF);
            goto L_802AECE4;
    }
    // 0x802AECB4: addiu       $t8, $a0, 0x7FFF
    ctx->r24 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AECB8: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
    // 0x802AECBC: lw          $t1, 0x0($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X0);
    // 0x802AECC0: addiu       $t0, $zero, 0x7A
    ctx->r8 = ADD32(0, 0X7A);
    // 0x802AECC4: addiu       $t2, $a0, 0x7FFF
    ctx->r10 = ADD32(ctx->r4, 0X7FFF);
    // 0x802AECC8: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    // 0x802AECCC: lh          $t2, 0x7FDB($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X7FDB);
    // 0x802AECD0: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x802AECD4: sll         $t3, $t2, 4
    ctx->r11 = S32(ctx->r10 << 4);
    // 0x802AECD8: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802AECDC: b           L_802AECF0
    // 0x802AECE0: sb          $t4, 0x368($t5)
    MEM_B(0X368, ctx->r13) = ctx->r12;
        goto L_802AECF0;
    // 0x802AECE0: sb          $t4, 0x368($t5)
    MEM_B(0X368, ctx->r13) = ctx->r12;
L_802AECE4:
    // 0x802AECE4: sh          $t6, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r14;
    // 0x802AECE8: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    // 0x802AECEC: sb          $zero, 0x368($t7)
    MEM_B(0X368, ctx->r15) = 0;
L_802AECF0:
    // 0x802AECF0: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
    // 0x802AECF4: beql        $t8, $zero, L_802AEDC8
    if (ctx->r24 == 0) {
        // 0x802AECF8: lw          $v0, 0x0($a1)
        ctx->r2 = MEM_W(ctx->r5, 0X0);
            goto L_802AEDC8;
    }
    goto skip_1;
    // 0x802AECF8: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    skip_1:
    // 0x802AECFC: jal         0x802B2580
    // 0x802AED00: nop

    get_distance_from_ground(rdram, ctx);
        goto after_1;
    // 0x802AED00: nop

    after_1:
    // 0x802AED04: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802AED08: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AED0C: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802AED10: addiu       $a2, $a2, 0x552C
    ctx->r6 = ADD32(ctx->r6, 0X552C);
    // 0x802AED14: beq         $at, $zero, L_802AED3C
    if (ctx->r1 == 0) {
        // 0x802AED18: addiu       $a1, $a1, 0x5530
        ctx->r5 = ADD32(ctx->r5, 0X5530);
            goto L_802AED3C;
    }
    // 0x802AED18: addiu       $a1, $a1, 0x5530
    ctx->r5 = ADD32(ctx->r5, 0X5530);
    // 0x802AED1C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802AED20: lui         $t0, 0x803A
    ctx->r8 = S32(0X803A << 16);
    // 0x802AED24: lw          $t0, 0x5B0($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5B0);
    // 0x802AED28: lw          $t9, 0x24($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X24);
    // 0x802AED2C: sra         $t1, $t0, 3
    ctx->r9 = S32(SIGNED(ctx->r8) >> 3);
    // 0x802AED30: addu        $t2, $t9, $t1
    ctx->r10 = ADD32(ctx->r25, ctx->r9);
    // 0x802AED34: b           L_802AED98
    // 0x802AED38: sw          $t2, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r10;
        goto L_802AED98;
    // 0x802AED38: sw          $t2, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r10;
L_802AED3C:
    // 0x802AED3C: slti        $at, $v0, 0x180
    ctx->r1 = SIGNED(ctx->r2) < 0X180 ? 1 : 0;
    // 0x802AED40: beql        $at, $zero, L_802AED80
    if (ctx->r1 == 0) {
        // 0x802AED44: lw          $v0, 0x0($a1)
        ctx->r2 = MEM_W(ctx->r5, 0X0);
            goto L_802AED80;
    }
    goto skip_2;
    // 0x802AED44: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    skip_2:
    // 0x802AED48: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802AED4C: lui         $at, 0xFFFE
    ctx->r1 = S32(0XFFFE << 16);
    // 0x802AED50: ori         $at, $at, 0x8001
    ctx->r1 = ctx->r1 | 0X8001;
    // 0x802AED54: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x802AED58: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802AED5C: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802AED60: bnel        $at, $zero, L_802AED9C
    if (ctx->r1 != 0) {
        // 0x802AED64: lw          $v0, 0x0($a2)
        ctx->r2 = MEM_W(ctx->r6, 0X0);
            goto L_802AED9C;
    }
    goto skip_3;
    // 0x802AED64: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    skip_3:
    // 0x802AED68: lw          $t3, 0x5B0($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5B0);
    // 0x802AED6C: sra         $t4, $t3, 5
    ctx->r12 = S32(SIGNED(ctx->r11) >> 5);
    // 0x802AED70: subu        $t5, $v1, $t4
    ctx->r13 = SUB32(ctx->r3, ctx->r12);
    // 0x802AED74: b           L_802AED98
    // 0x802AED78: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
        goto L_802AED98;
    // 0x802AED78: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
    // 0x802AED7C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
L_802AED80:
    // 0x802AED80: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x802AED84: lw          $t7, 0x5B0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5B0);
    // 0x802AED88: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802AED8C: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x802AED90: subu        $t0, $t6, $t8
    ctx->r8 = SUB32(ctx->r14, ctx->r24);
    // 0x802AED94: sw          $t0, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r8;
L_802AED98:
    // 0x802AED98: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
L_802AED9C:
    // 0x802AED9C: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802AEDA0: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802AEDA4: addiu       $v1, $v1, 0x4
    ctx->r3 = ADD32(ctx->r3, 0X4);
    // 0x802AEDA8: slti        $at, $v1, 0x65
    ctx->r1 = SIGNED(ctx->r3) < 0X65 ? 1 : 0;
    // 0x802AEDAC: bne         $at, $zero, L_802AEDBC
    if (ctx->r1 != 0) {
        // 0x802AEDB0: nop
    
            goto L_802AEDBC;
    }
    // 0x802AEDB0: nop

    // 0x802AEDB4: b           L_802AEDE0
    // 0x802AEDB8: sh          $t9, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r25;
        goto L_802AEDE0;
    // 0x802AEDB8: sh          $t9, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r25;
L_802AEDBC:
    // 0x802AEDBC: b           L_802AEDE0
    // 0x802AEDC0: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
        goto L_802AEDE0;
    // 0x802AEDC0: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
    // 0x802AEDC4: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
L_802AEDC8:
    // 0x802AEDC8: lui         $t2, 0x803A
    ctx->r10 = S32(0X803A << 16);
    // 0x802AEDCC: lw          $t2, 0x5B0($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5B0);
    // 0x802AEDD0: lw          $t1, 0x24($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X24);
    // 0x802AEDD4: sra         $t3, $t2, 3
    ctx->r11 = S32(SIGNED(ctx->r10) >> 3);
    // 0x802AEDD8: subu        $t4, $t1, $t3
    ctx->r12 = SUB32(ctx->r9, ctx->r11);
    // 0x802AEDDC: sw          $t4, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r12;
L_802AEDE0:
    // 0x802AEDE0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AEDE4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AEDE8: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802AEDEC:
    // 0x802AEDEC: lh          $t5, 0x30C($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X30C);
    // 0x802AEDF0: sra         $t7, $v1, 2
    ctx->r15 = S32(SIGNED(ctx->r3) >> 2);
    // 0x802AEDF4: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x802AEDF8: addu        $t6, $t5, $t7
    ctx->r14 = ADD32(ctx->r13, ctx->r15);
    // 0x802AEDFC: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x802AEE00: mfhi        $t8
    ctx->r24 = hi;
    // 0x802AEE04: sh          $t8, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r24;
    // 0x802AEE08: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AEE0C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AEE10: jr          $ra
    // 0x802AEE14: nop

    return;
    // 0x802AEE14: nop

;}
RECOMP_FUNC void func_802AEE18_6C04C8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AEE18: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AEE1C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802AEE20: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AEE24: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802AEE28: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802AEE2C: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802AEE30: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AEE34: beq         $v1, $at, L_802AF2F8
    if (ctx->r3 == ctx->r1) {
        // 0x802AEE38: addiu       $at, $zero, 0x3D
        ctx->r1 = ADD32(0, 0X3D);
            goto L_802AF2F8;
    }
    // 0x802AEE38: addiu       $at, $zero, 0x3D
    ctx->r1 = ADD32(0, 0X3D);
    // 0x802AEE3C: beq         $v1, $at, L_802AF2F8
    if (ctx->r3 == ctx->r1) {
        // 0x802AEE40: addiu       $at, $zero, 0x3E
        ctx->r1 = ADD32(0, 0X3E);
            goto L_802AF2F8;
    }
    // 0x802AEE40: addiu       $at, $zero, 0x3E
    ctx->r1 = ADD32(0, 0X3E);
    // 0x802AEE44: beq         $v1, $at, L_802AEE60
    if (ctx->r3 == ctx->r1) {
        // 0x802AEE48: lui         $a1, 0x801E
        ctx->r5 = S32(0X801E << 16);
            goto L_802AEE60;
    }
    // 0x802AEE48: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x802AEE4C: addiu       $at, $zero, 0x3F
    ctx->r1 = ADD32(0, 0X3F);
    // 0x802AEE50: beql        $v1, $at, L_802AF2FC
    if (ctx->r3 == ctx->r1) {
        // 0x802AEE54: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802AF2FC;
    }
    goto skip_0;
    // 0x802AEE54: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x802AEE58: b           L_802AF2FC
    // 0x802AEE5C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_802AF2FC;
    // 0x802AEE5C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802AEE60:
    // 0x802AEE60: addiu       $a1, $a1, -0x6128
    ctx->r5 = ADD32(ctx->r5, -0X6128);
    // 0x802AEE64: addiu       $t7, $a1, 0x7FFF
    ctx->r15 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEE68: lh          $t7, 0x7FDD($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X7FDD);
    // 0x802AEE6C: lh          $t6, 0x2C($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2C);
    // 0x802AEE70: addiu       $t5, $a1, 0x7FFF
    ctx->r13 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEE74: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x802AEE78: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802AEE7C: sh          $t9, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r25;
    // 0x802AEE80: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AEE84: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x802AEE88: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802AEE8C: lh          $t3, 0x2C($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2C);
    // 0x802AEE90: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x802AEE94: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AEE98: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x802AEE9C: sh          $t4, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r12;
    // 0x802AEEA0: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802AEEA4: lh          $t5, 0x7FDF($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X7FDF);
    // 0x802AEEA8: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802AEEAC: sh          $t5, 0x28($t7)
    MEM_H(0X28, ctx->r15) = ctx->r13;
    // 0x802AEEB0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AEEB4: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802AEEB8: lh          $t3, 0x28($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X28);
    // 0x802AEEBC: multu       $t6, $a0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AEEC0: sll         $t4, $t3, 2
    ctx->r12 = S32(ctx->r11 << 2);
    // 0x802AEEC4: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x802AEEC8: sll         $t5, $t4, 8
    ctx->r13 = S32(ctx->r12 << 8);
    // 0x802AEECC: mflo        $t8
    ctx->r24 = lo;
    // 0x802AEED0: sra         $t9, $t8, 3
    ctx->r25 = S32(SIGNED(ctx->r24) >> 3);
    // 0x802AEED4: addu        $t7, $t9, $t5
    ctx->r15 = ADD32(ctx->r25, ctx->r13);
    // 0x802AEED8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AEEDC: sw          $t7, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r15;
    // 0x802AEEE0: lh          $t8, 0x5540($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5540);
    // 0x802AEEE4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AEEE8: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x802AEEEC: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x802AEEF0: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x802AEEF4: addu        $t8, $t2, $t7
    ctx->r24 = ADD32(ctx->r10, ctx->r15);
    // 0x802AEEF8: lh          $t3, 0x0($t8)
    ctx->r11 = MEM_H(ctx->r24, 0X0);
    // 0x802AEEFC: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x802AEF00: addiu       $t7, $a1, 0x7FFF
    ctx->r15 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEF04: sra         $t4, $t3, 7
    ctx->r12 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802AEF08: sll         $t9, $t4, 6
    ctx->r25 = S32(ctx->r12 << 6);
    // 0x802AEF0C: addu        $t5, $t6, $t9
    ctx->r13 = ADD32(ctx->r14, ctx->r25);
    // 0x802AEF10: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
    // 0x802AEF14: lh          $t7, 0x7FDD($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X7FDD);
    // 0x802AEF18: bne         $t7, $zero, L_802AEF30
    if (ctx->r15 != 0) {
        // 0x802AEF1C: nop
    
            goto L_802AEF30;
    }
    // 0x802AEF1C: nop

    // 0x802AEF20: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AEF24: lh          $t8, 0x30C($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X30C);
    // 0x802AEF28: beql        $t8, $zero, L_802AEF68
    if (ctx->r24 == 0) {
        // 0x802AEF2C: lh          $v0, 0x30E($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X30E);
            goto L_802AEF68;
    }
    goto skip_1;
    // 0x802AEF2C: lh          $v0, 0x30E($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30E);
    skip_1:
L_802AEF30:
    // 0x802AEF30: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AEF34: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802AEF38: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AEF3C: addiu       $t3, $zero, 0x10
    ctx->r11 = ADD32(0, 0X10);
    // 0x802AEF40: lh          $v0, 0x30E($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30E);
    // 0x802AEF44: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802AEF48: slti        $at, $v0, 0x11
    ctx->r1 = SIGNED(ctx->r2) < 0X11 ? 1 : 0;
    // 0x802AEF4C: bne         $at, $zero, L_802AEF5C
    if (ctx->r1 != 0) {
        // 0x802AEF50: nop
    
            goto L_802AEF5C;
    }
    // 0x802AEF50: nop

    // 0x802AEF54: b           L_802AEF80
    // 0x802AEF58: sh          $t3, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r11;
        goto L_802AEF80;
    // 0x802AEF58: sh          $t3, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r11;
L_802AEF5C:
    // 0x802AEF5C: b           L_802AEF80
    // 0x802AEF60: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
        goto L_802AEF80;
    // 0x802AEF60: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
    // 0x802AEF64: lh          $v0, 0x30E($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30E);
L_802AEF68:
    // 0x802AEF68: addiu       $v0, $v0, -0x2
    ctx->r2 = ADD32(ctx->r2, -0X2);
    // 0x802AEF6C: bgezl       $v0, L_802AEF80
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AEF70: sh          $v0, 0x30E($v1)
        MEM_H(0X30E, ctx->r3) = ctx->r2;
            goto L_802AEF80;
    }
    goto skip_2;
    // 0x802AEF70: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
    skip_2:
    // 0x802AEF74: b           L_802AEF80
    // 0x802AEF78: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
        goto L_802AEF80;
    // 0x802AEF78: sh          $zero, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = 0;
    // 0x802AEF7C: sh          $v0, 0x30E($v1)
    MEM_H(0X30E, ctx->r3) = ctx->r2;
L_802AEF80:
    // 0x802AEF80: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AEF84: lh          $v0, 0x7FDD($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDD);
    // 0x802AEF88: beql        $v0, $zero, L_802AF008
    if (ctx->r2 == 0) {
        // 0x802AEF8C: addiu       $t4, $a1, 0x7FFF
        ctx->r12 = ADD32(ctx->r5, 0X7FFF);
            goto L_802AF008;
    }
    goto skip_3;
    // 0x802AEF8C: addiu       $t4, $a1, 0x7FFF
    ctx->r12 = ADD32(ctx->r5, 0X7FFF);
    skip_3:
    // 0x802AEF90: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AEF94: lh          $t4, 0x30C($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X30C);
    // 0x802AEF98: bnel        $t4, $zero, L_802AF008
    if (ctx->r12 != 0) {
        // 0x802AEF9C: addiu       $t4, $a1, 0x7FFF
        ctx->r12 = ADD32(ctx->r5, 0X7FFF);
            goto L_802AF008;
    }
    goto skip_4;
    // 0x802AEF9C: addiu       $t4, $a1, 0x7FFF
    ctx->r12 = ADD32(ctx->r5, 0X7FFF);
    skip_4:
    // 0x802AEFA0: bgezl       $v0, L_802AEFDC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802AEFA4: lh          $v0, 0x310($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X310);
            goto L_802AEFDC;
    }
    goto skip_5;
    // 0x802AEFA4: lh          $v0, 0x310($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X310);
    skip_5:
    // 0x802AEFA8: lh          $v0, 0x310($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X310);
    // 0x802AEFAC: slti        $at, $v0, 0x301
    ctx->r1 = SIGNED(ctx->r2) < 0X301 ? 1 : 0;
    // 0x802AEFB0: beq         $at, $zero, L_802AEFCC
    if (ctx->r1 == 0) {
        // 0x802AEFB4: addiu       $t9, $v0, 0x14
        ctx->r25 = ADD32(ctx->r2, 0X14);
            goto L_802AEFCC;
    }
    // 0x802AEFB4: addiu       $t9, $v0, 0x14
    ctx->r25 = ADD32(ctx->r2, 0X14);
    // 0x802AEFB8: slti        $at, $v0, 0x2EA
    ctx->r1 = SIGNED(ctx->r2) < 0X2EA ? 1 : 0;
    // 0x802AEFBC: bne         $at, $zero, L_802AEFCC
    if (ctx->r1 != 0) {
        // 0x802AEFC0: addiu       $t6, $zero, 0x300
        ctx->r14 = ADD32(0, 0X300);
            goto L_802AEFCC;
    }
    // 0x802AEFC0: addiu       $t6, $zero, 0x300
    ctx->r14 = ADD32(0, 0X300);
    // 0x802AEFC4: b           L_802AF004
    // 0x802AEFC8: sh          $t6, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r14;
        goto L_802AF004;
    // 0x802AEFC8: sh          $t6, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r14;
L_802AEFCC:
    // 0x802AEFCC: andi        $t5, $t9, 0x3FF
    ctx->r13 = ctx->r25 & 0X3FF;
    // 0x802AEFD0: b           L_802AF004
    // 0x802AEFD4: sh          $t5, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r13;
        goto L_802AF004;
    // 0x802AEFD4: sh          $t5, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r13;
    // 0x802AEFD8: lh          $v0, 0x310($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X310);
L_802AEFDC:
    // 0x802AEFDC: slti        $at, $v0, 0x101
    ctx->r1 = SIGNED(ctx->r2) < 0X101 ? 1 : 0;
    // 0x802AEFE0: beq         $at, $zero, L_802AEFFC
    if (ctx->r1 == 0) {
        // 0x802AEFE4: addiu       $t8, $v0, 0x14
        ctx->r24 = ADD32(ctx->r2, 0X14);
            goto L_802AEFFC;
    }
    // 0x802AEFE4: addiu       $t8, $v0, 0x14
    ctx->r24 = ADD32(ctx->r2, 0X14);
    // 0x802AEFE8: slti        $at, $v0, 0xEB
    ctx->r1 = SIGNED(ctx->r2) < 0XEB ? 1 : 0;
    // 0x802AEFEC: bne         $at, $zero, L_802AEFFC
    if (ctx->r1 != 0) {
        // 0x802AEFF0: addiu       $t7, $zero, 0x100
        ctx->r15 = ADD32(0, 0X100);
            goto L_802AEFFC;
    }
    // 0x802AEFF0: addiu       $t7, $zero, 0x100
    ctx->r15 = ADD32(0, 0X100);
    // 0x802AEFF4: b           L_802AF004
    // 0x802AEFF8: sh          $t7, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r15;
        goto L_802AF004;
    // 0x802AEFF8: sh          $t7, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r15;
L_802AEFFC:
    // 0x802AEFFC: andi        $t3, $t8, 0x3FF
    ctx->r11 = ctx->r24 & 0X3FF;
    // 0x802AF000: sh          $t3, 0x310($v1)
    MEM_H(0X310, ctx->r3) = ctx->r11;
L_802AF004:
    // 0x802AF004: addiu       $t4, $a1, 0x7FFF
    ctx->r12 = ADD32(ctx->r5, 0X7FFF);
L_802AF008:
    // 0x802AF008: lhu         $t4, 0x7FB3($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X7FB3);
    // 0x802AF00C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF010: addiu       $t6, $a1, 0x7FFF
    ctx->r14 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AF014: beq         $t4, $zero, L_802AF064
    if (ctx->r12 == 0) {
        // 0x802AF018: lh          $v0, 0x30C($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X30C);
            goto L_802AF064;
    }
    // 0x802AF018: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
    // 0x802AF01C: lhu         $t6, 0x7FB9($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X7FB9);
    // 0x802AF020: addiu       $t9, $v0, 0x40
    ctx->r25 = ADD32(ctx->r2, 0X40);
    // 0x802AF024: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    // 0x802AF028: bne         $t6, $zero, L_802AF040
    if (ctx->r14 != 0) {
        // 0x802AF02C: nop
    
            goto L_802AF040;
    }
    // 0x802AF02C: nop

    // 0x802AF030: sh          $t9, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r25;
    // 0x802AF034: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF038: b           L_802AF064
    // 0x802AF03C: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
        goto L_802AF064;
    // 0x802AF03C: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
L_802AF040:
    // 0x802AF040: beq         $at, $zero, L_802AF058
    if (ctx->r1 == 0) {
        // 0x802AF044: addiu       $t5, $zero, 0x40
        ctx->r13 = ADD32(0, 0X40);
            goto L_802AF058;
    }
    // 0x802AF044: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x802AF048: sh          $t5, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r13;
    // 0x802AF04C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF050: b           L_802AF064
    // 0x802AF054: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
        goto L_802AF064;
    // 0x802AF054: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
L_802AF058:
    // 0x802AF058: sh          $v0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r2;
    // 0x802AF05C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF060: lh          $v0, 0x30C($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30C);
L_802AF064:
    // 0x802AF064: slti        $at, $v0, 0x32
    ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
    // 0x802AF068: beq         $at, $zero, L_802AF08C
    if (ctx->r1 == 0) {
        // 0x802AF06C: nop
    
            goto L_802AF08C;
    }
    // 0x802AF06C: nop

    // 0x802AF070: addiu       $a0, $v0, -0x6
    ctx->r4 = ADD32(ctx->r2, -0X6);
    // 0x802AF074: bgez        $a0, L_802AF084
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802AF078: nop
    
            goto L_802AF084;
    }
    // 0x802AF078: nop

    // 0x802AF07C: b           L_802AF09C
    // 0x802AF080: sh          $zero, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = 0;
        goto L_802AF09C;
    // 0x802AF080: sh          $zero, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = 0;
L_802AF084:
    // 0x802AF084: b           L_802AF09C
    // 0x802AF088: sh          $a0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r4;
        goto L_802AF09C;
    // 0x802AF088: sh          $a0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r4;
L_802AF08C:
    // 0x802AF08C: multu       $v0, $a0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF090: mflo        $t7
    ctx->r15 = lo;
    // 0x802AF094: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x802AF098: sh          $t8, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r24;
L_802AF09C:
    // 0x802AF09C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF0A0: addiu       $a0, $zero, 0x6E
    ctx->r4 = ADD32(0, 0X6E);
    // 0x802AF0A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF0A8: lh          $t4, 0x302($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X302);
    // 0x802AF0AC: lh          $t3, 0x30C($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X30C);
    // 0x802AF0B0: andi        $t6, $t4, 0xFF
    ctx->r14 = ctx->r12 & 0XFF;
    // 0x802AF0B4: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x802AF0B8: addu        $t5, $t2, $t9
    ctx->r13 = ADD32(ctx->r10, ctx->r25);
    // 0x802AF0BC: lh          $t7, 0x0($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X0);
    // 0x802AF0C0: lw          $t6, 0x1C($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X1C);
    // 0x802AF0C4: multu       $t3, $t7
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF0C8: mflo        $t8
    ctx->r24 = lo;
    // 0x802AF0CC: nop

    // 0x802AF0D0: nop

    // 0x802AF0D4: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x802AF0D8: mflo        $t4
    ctx->r12 = lo;
    // 0x802AF0DC: addu        $t9, $t6, $t4
    ctx->r25 = ADD32(ctx->r14, ctx->r12);
    // 0x802AF0E0: sw          $t9, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r25;
    // 0x802AF0E4: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x802AF0E8: bne         $a0, $zero, L_802AF0F4
    if (ctx->r4 != 0) {
        // 0x802AF0EC: nop
    
            goto L_802AF0F4;
    }
    // 0x802AF0EC: nop

    // 0x802AF0F0: break       7
    do_break(2150297840);
L_802AF0F4:
    // 0x802AF0F4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AF0F8: bne         $a0, $at, L_802AF10C
    if (ctx->r4 != ctx->r1) {
        // 0x802AF0FC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AF10C;
    }
    // 0x802AF0FC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AF100: bne         $t8, $at, L_802AF10C
    if (ctx->r24 != ctx->r1) {
        // 0x802AF104: nop
    
            goto L_802AF10C;
    }
    // 0x802AF104: nop

    // 0x802AF108: break       6
    do_break(2150297864);
L_802AF10C:
    // 0x802AF10C: lh          $t3, 0x302($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X302);
    // 0x802AF110: lh          $t5, 0x30C($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X30C);
    // 0x802AF114: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF118: addiu       $t7, $t3, 0x40
    ctx->r15 = ADD32(ctx->r11, 0X40);
    // 0x802AF11C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802AF120: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802AF124: addu        $t4, $t2, $t6
    ctx->r12 = ADD32(ctx->r10, ctx->r14);
    // 0x802AF128: lh          $t9, 0x0($t4)
    ctx->r25 = MEM_H(ctx->r12, 0X0);
    // 0x802AF12C: lw          $t8, 0x20($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X20);
    // 0x802AF130: multu       $t5, $t9
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF134: addiu       $t9, $a1, 0x7FFF
    ctx->r25 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AF138: mflo        $t3
    ctx->r11 = lo;
    // 0x802AF13C: nop

    // 0x802AF140: nop

    // 0x802AF144: div         $zero, $t3, $a0
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r4)));
    // 0x802AF148: mflo        $t7
    ctx->r15 = lo;
    // 0x802AF14C: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x802AF150: sw          $t6, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r14;
    // 0x802AF154: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802AF158: bne         $a0, $zero, L_802AF164
    if (ctx->r4 != 0) {
        // 0x802AF15C: nop
    
            goto L_802AF164;
    }
    // 0x802AF15C: nop

    // 0x802AF160: break       7
    do_break(2150297952);
L_802AF164:
    // 0x802AF164: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802AF168: bne         $a0, $at, L_802AF17C
    if (ctx->r4 != ctx->r1) {
        // 0x802AF16C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802AF17C;
    }
    // 0x802AF16C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802AF170: bne         $t3, $at, L_802AF17C
    if (ctx->r11 != ctx->r1) {
        // 0x802AF174: nop
    
            goto L_802AF17C;
    }
    // 0x802AF174: nop

    // 0x802AF178: break       6
    do_break(2150297976);
L_802AF17C:
    // 0x802AF17C: lbu         $t5, 0x365($t4)
    ctx->r13 = MEM_BU(ctx->r12, 0X365);
    // 0x802AF180: bnel        $t5, $zero, L_802AF2FC
    if (ctx->r13 != 0) {
        // 0x802AF184: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802AF2FC;
    }
    goto skip_6;
    // 0x802AF184: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_6:
    // 0x802AF188: lhu         $t9, 0x7FB7($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X7FB7);
    // 0x802AF18C: addiu       $t3, $a1, 0x7FFF
    ctx->r11 = ADD32(ctx->r5, 0X7FFF);
    // 0x802AF190: beql        $t9, $zero, L_802AF2FC
    if (ctx->r25 == 0) {
        // 0x802AF194: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802AF2FC;
    }
    goto skip_7;
    // 0x802AF194: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_7:
    // 0x802AF198: lhu         $t3, 0x7FBD($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X7FBD);
    // 0x802AF19C: bnel        $t3, $zero, L_802AF2FC
    if (ctx->r11 != 0) {
        // 0x802AF1A0: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802AF2FC;
    }
    goto skip_8;
    // 0x802AF1A0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_8:
    // 0x802AF1A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF1A8: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802AF1AC: jal         0x80298F78
    // 0x802AF1B0: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    func_80298F78_6AA628(rdram, ctx);
        goto after_0;
    // 0x802AF1B0: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    after_0:
    // 0x802AF1B4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AF1B8: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802AF1BC: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x802AF1C0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AF1C4: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802AF1C8: lh          $t7, 0xC($t8)
    ctx->r15 = MEM_H(ctx->r24, 0XC);
    // 0x802AF1CC: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x802AF1D0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802AF1D4: subu        $t6, $t7, $v0
    ctx->r14 = SUB32(ctx->r15, ctx->r2);
    // 0x802AF1D8: slti        $at, $t6, -0x3F
    ctx->r1 = SIGNED(ctx->r14) < -0X3F ? 1 : 0;
    // 0x802AF1DC: bne         $at, $zero, L_802AF2D0
    if (ctx->r1 != 0) {
        // 0x802AF1E0: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802AF2D0;
    }
    // 0x802AF1E0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AF1E4: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802AF1E8: addiu       $v1, $zero, 0x6
    ctx->r3 = ADD32(0, 0X6);
    // 0x802AF1EC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802AF1F0: sb          $zero, 0x369($t4)
    MEM_B(0X369, ctx->r12) = 0;
    // 0x802AF1F4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF1F8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802AF1FC: addiu       $a0, $zero, 0x2A
    ctx->r4 = ADD32(0, 0X2A);
    // 0x802AF200: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x802AF204: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802AF208: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802AF20C: addiu       $t9, $t5, 0x17
    ctx->r25 = ADD32(ctx->r13, 0X17);
    // 0x802AF210: sh          $t9, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r25;
    // 0x802AF214: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF218: lh          $t3, 0x24($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X24);
    // 0x802AF21C: addiu       $t8, $t3, 0x17
    ctx->r24 = ADD32(ctx->r11, 0X17);
    // 0x802AF220: sh          $t8, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r24;
    // 0x802AF224: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802AF228: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF22C: lh          $t4, 0x302($t6)
    ctx->r12 = MEM_H(ctx->r14, 0X302);
    // 0x802AF230: lw          $t7, 0x1C($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X1C);
    // 0x802AF234: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x802AF238: sll         $t9, $t5, 1
    ctx->r25 = S32(ctx->r13 << 1);
    // 0x802AF23C: addu        $t3, $t2, $t9
    ctx->r11 = ADD32(ctx->r10, ctx->r25);
    // 0x802AF240: lh          $t8, 0x0($t3)
    ctx->r24 = MEM_H(ctx->r11, 0X0);
    // 0x802AF244: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF248: mflo        $t6
    ctx->r14 = lo;
    // 0x802AF24C: addu        $t4, $t7, $t6
    ctx->r12 = ADD32(ctx->r15, ctx->r14);
    // 0x802AF250: sw          $t4, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r12;
    // 0x802AF254: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802AF258: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF25C: lh          $t3, 0x302($t9)
    ctx->r11 = MEM_H(ctx->r25, 0X302);
    // 0x802AF260: lw          $t5, 0x20($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X20);
    // 0x802AF264: addiu       $t8, $t3, 0x40
    ctx->r24 = ADD32(ctx->r11, 0X40);
    // 0x802AF268: andi        $t7, $t8, 0xFF
    ctx->r15 = ctx->r24 & 0XFF;
    // 0x802AF26C: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x802AF270: addu        $t4, $t2, $t6
    ctx->r12 = ADD32(ctx->r10, ctx->r14);
    // 0x802AF274: lh          $t9, 0x0($t4)
    ctx->r25 = MEM_H(ctx->r12, 0X0);
    // 0x802AF278: addiu       $t6, $zero, 0x3F
    ctx->r14 = ADD32(0, 0X3F);
    // 0x802AF27C: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF280: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x802AF284: mflo        $t3
    ctx->r11 = lo;
    // 0x802AF288: addu        $t8, $t5, $t3
    ctx->r24 = ADD32(ctx->r13, ctx->r11);
    // 0x802AF28C: sw          $t8, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r24;
    // 0x802AF290: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802AF294: sh          $zero, 0x308($t7)
    MEM_H(0X308, ctx->r15) = 0;
    // 0x802AF298: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x802AF29C: sh          $t6, 0x0($t4)
    MEM_H(0X0, ctx->r12) = ctx->r14;
    // 0x802AF2A0: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x802AF2A4: sb          $t9, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r25;
    // 0x802AF2A8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x802AF2AC: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802AF2B0: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x802AF2B4: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802AF2B8: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x802AF2BC: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x802AF2C0: jal         0x8032C360
    // 0x802AF2C4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802AF2C4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_1:
    // 0x802AF2C8: b           L_802AF2FC
    // 0x802AF2CC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_802AF2FC;
    // 0x802AF2CC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802AF2D0:
    // 0x802AF2D0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AF2D4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802AF2D8: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x802AF2DC: lhu         $t6, 0x9C($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X9C);
    // 0x802AF2E0: addiu       $a1, $zero, 0x4000
    ctx->r5 = ADD32(0, 0X4000);
    // 0x802AF2E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802AF2E8: beql        $t6, $at, L_802AF2FC
    if (ctx->r14 == ctx->r1) {
        // 0x802AF2EC: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802AF2FC;
    }
    goto skip_9;
    // 0x802AF2EC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_9:
    // 0x802AF2F0: jal         0x8032C508
    // 0x802AF2F4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    func_8032C508_73DBB8(rdram, ctx);
        goto after_2;
    // 0x802AF2F4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_2:
L_802AF2F8:
    // 0x802AF2F8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802AF2FC:
    // 0x802AF2FC: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802AF300: jr          $ra
    // 0x802AF304: nop

    return;
    // 0x802AF304: nop

;}
RECOMP_FUNC void func_802AF308_6C09B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AF308: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AF30C: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802AF310: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AF314: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AF318: lhu         $v0, 0x0($t1)
    ctx->r2 = MEM_HU(ctx->r9, 0X0);
    // 0x802AF31C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AF320: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AF324: beq         $v0, $at, L_802AF364
    if (ctx->r2 == ctx->r1) {
        // 0x802AF328: lhu         $a0, 0x2C($t1)
        ctx->r4 = MEM_HU(ctx->r9, 0X2C);
            goto L_802AF364;
    }
    // 0x802AF328: lhu         $a0, 0x2C($t1)
    ctx->r4 = MEM_HU(ctx->r9, 0X2C);
    // 0x802AF32C: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x802AF330: beq         $v0, $at, L_802AF364
    if (ctx->r2 == ctx->r1) {
        // 0x802AF334: addiu       $at, $zero, 0x8E
        ctx->r1 = ADD32(0, 0X8E);
            goto L_802AF364;
    }
    // 0x802AF334: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802AF338: beq         $v0, $at, L_802AF404
    if (ctx->r2 == ctx->r1) {
        // 0x802AF33C: lui         $a2, 0x801E
        ctx->r6 = S32(0X801E << 16);
            goto L_802AF404;
    }
    // 0x802AF33C: lui         $a2, 0x801E
    ctx->r6 = S32(0X801E << 16);
    // 0x802AF340: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802AF344: beq         $v0, $at, L_802AF46C
    if (ctx->r2 == ctx->r1) {
        // 0x802AF348: addiu       $at, $zero, 0x90
        ctx->r1 = ADD32(0, 0X90);
            goto L_802AF46C;
    }
    // 0x802AF348: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802AF34C: beq         $v0, $at, L_802AF4CC
    if (ctx->r2 == ctx->r1) {
        // 0x802AF350: lui         $t6, 0x801F
        ctx->r14 = S32(0X801F << 16);
            goto L_802AF4CC;
    }
    // 0x802AF350: lui         $t6, 0x801F
    ctx->r14 = S32(0X801F << 16);
    // 0x802AF354: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AF358: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802AF35C: b           L_802AF50C
    // 0x802AF360: lhu         $v0, 0x9C($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9C);
        goto L_802AF50C;
    // 0x802AF360: lhu         $v0, 0x9C($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9C);
L_802AF364:
    // 0x802AF364: lh          $v1, -0x614E($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X614E);
    // 0x802AF368: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AF36C: blez        $v1, L_802AF3A4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802AF370: nop
    
            goto L_802AF3A4;
    }
    // 0x802AF370: nop

    // 0x802AF374: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AF378: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802AF37C: lhu         $v0, 0x9C($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X9C);
    // 0x802AF380: beq         $v0, $at, L_802AF3F4
    if (ctx->r2 == ctx->r1) {
        // 0x802AF384: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802AF3F4;
    }
    // 0x802AF384: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802AF388: beq         $v0, $at, L_802AF3F4
    if (ctx->r2 == ctx->r1) {
        // 0x802AF38C: lui         $a0, 0x801F
        ctx->r4 = S32(0X801F << 16);
            goto L_802AF3F4;
    }
    // 0x802AF38C: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802AF390: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    // 0x802AF394: jal         0x802A5EF8
    // 0x802AF398: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A5EF8_6B75A8(rdram, ctx);
        goto after_0;
    // 0x802AF398: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_0:
    // 0x802AF39C: b           L_802AF3F4
    // 0x802AF3A0: nop

        goto L_802AF3F4;
    // 0x802AF3A0: nop

L_802AF3A4:
    // 0x802AF3A4: bgez        $v1, L_802AF3E0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AF3A8: lui         $v0, 0x801F
        ctx->r2 = S32(0X801F << 16);
            goto L_802AF3E0;
    }
    // 0x802AF3A8: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AF3AC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AF3B0: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AF3B4: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802AF3B8: lhu         $v0, 0x9C($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X9C);
    // 0x802AF3BC: beq         $v0, $at, L_802AF3F4
    if (ctx->r2 == ctx->r1) {
        // 0x802AF3C0: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802AF3F4;
    }
    // 0x802AF3C0: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802AF3C4: beq         $v0, $at, L_802AF3F4
    if (ctx->r2 == ctx->r1) {
        // 0x802AF3C8: lui         $a0, 0x801F
        ctx->r4 = S32(0X801F << 16);
            goto L_802AF3F4;
    }
    // 0x802AF3C8: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802AF3CC: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    // 0x802AF3D0: jal         0x802A5F9C
    // 0x802AF3D4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A5F9C_6B764C(rdram, ctx);
        goto after_1;
    // 0x802AF3D4: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_1:
    // 0x802AF3D8: b           L_802AF3F4
    // 0x802AF3DC: nop

        goto L_802AF3F4;
    // 0x802AF3DC: nop

L_802AF3E0:
    // 0x802AF3E0: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802AF3E4: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AF3E8: beq         $v0, $at, L_802AF3F4
    if (ctx->r2 == ctx->r1) {
        // 0x802AF3EC: nop
    
            goto L_802AF3F4;
    }
    // 0x802AF3EC: nop

    // 0x802AF3F0: sh          $v0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r2;
L_802AF3F4:
    // 0x802AF3F4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AF3F8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802AF3FC: b           L_802AF50C
    // 0x802AF400: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
        goto L_802AF50C;
    // 0x802AF400: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
L_802AF404:
    // 0x802AF404: addiu       $a2, $a2, -0x6128
    ctx->r6 = ADD32(ctx->r6, -0X6128);
    // 0x802AF408: addiu       $v1, $a2, 0x7FFF
    ctx->r3 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AF40C: lh          $v1, 0x7FDB($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7FDB);
    // 0x802AF410: bgtz        $v1, L_802AF428
    if (SIGNED(ctx->r3) > 0) {
        // 0x802AF414: slti        $at, $v1, 0x3
        ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
            goto L_802AF428;
    }
    // 0x802AF414: slti        $at, $v1, 0x3
    ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
    // 0x802AF418: jal         0x802A5EA4
    // 0x802AF41C: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_2;
    // 0x802AF41C: nop

    after_2:
    // 0x802AF420: b           L_802AF45C
    // 0x802AF424: nop

        goto L_802AF45C;
    // 0x802AF424: nop

L_802AF428:
    // 0x802AF428: bne         $at, $zero, L_802AF448
    if (ctx->r1 != 0) {
        // 0x802AF42C: addiu       $v0, $a2, 0x7FFF
        ctx->r2 = ADD32(ctx->r6, 0X7FFF);
            goto L_802AF448;
    }
    // 0x802AF42C: addiu       $v0, $a2, 0x7FFF
    ctx->r2 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AF430: addiu       $a0, $a2, 0x7FFF
    ctx->r4 = ADD32(ctx->r6, 0X7FFF);
    // 0x802AF434: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    // 0x802AF438: jal         0x802A6044
    // 0x802AF43C: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802A6044_6B76F4(rdram, ctx);
        goto after_3;
    // 0x802AF43C: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_3:
    // 0x802AF440: b           L_802AF45C
    // 0x802AF444: nop

        goto L_802AF45C;
    // 0x802AF444: nop

L_802AF448:
    // 0x802AF448: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AF44C: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AF450: beq         $v0, $at, L_802AF45C
    if (ctx->r2 == ctx->r1) {
        // 0x802AF454: nop
    
            goto L_802AF45C;
    }
    // 0x802AF454: nop

    // 0x802AF458: sh          $v0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r2;
L_802AF45C:
    // 0x802AF45C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AF460: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802AF464: b           L_802AF50C
    // 0x802AF468: lhu         $v0, 0x9C($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X9C);
        goto L_802AF50C;
    // 0x802AF468: lhu         $v0, 0x9C($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X9C);
L_802AF46C:
    // 0x802AF46C: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AF470: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802AF474: bne         $a0, $v0, L_802AF49C
    if (ctx->r4 != ctx->r2) {
        // 0x802AF478: lui         $t4, 0x801F
        ctx->r12 = S32(0X801F << 16);
            goto L_802AF49C;
    }
    // 0x802AF478: lui         $t4, 0x801F
    ctx->r12 = S32(0X801F << 16);
    // 0x802AF47C: lh          $t4, -0x614E($t4)
    ctx->r12 = MEM_H(ctx->r12, -0X614E);
    // 0x802AF480: slti        $at, $t4, 0x3
    ctx->r1 = SIGNED(ctx->r12) < 0X3 ? 1 : 0;
    // 0x802AF484: beq         $at, $zero, L_802AF4BC
    if (ctx->r1 == 0) {
        // 0x802AF488: nop
    
            goto L_802AF4BC;
    }
    // 0x802AF488: nop

    // 0x802AF48C: jal         0x802A5EF8
    // 0x802AF490: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    func_802A5EF8_6B75A8(rdram, ctx);
        goto after_4;
    // 0x802AF490: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    after_4:
    // 0x802AF494: b           L_802AF4BC
    // 0x802AF498: nop

        goto L_802AF4BC;
    // 0x802AF498: nop

L_802AF49C:
    // 0x802AF49C: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AF4A0: bnel        $v0, $at, L_802AF4BC
    if (ctx->r2 != ctx->r1) {
        // 0x802AF4A4: sh          $v0, 0x2C($t1)
        MEM_H(0X2C, ctx->r9) = ctx->r2;
            goto L_802AF4BC;
    }
    goto skip_0;
    // 0x802AF4A4: sh          $v0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r2;
    skip_0:
    // 0x802AF4A8: jal         0x802A5EA4
    // 0x802AF4AC: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_5;
    // 0x802AF4AC: nop

    after_5:
    // 0x802AF4B0: b           L_802AF4BC
    // 0x802AF4B4: nop

        goto L_802AF4BC;
    // 0x802AF4B4: nop

    // 0x802AF4B8: sh          $v0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r2;
L_802AF4BC:
    // 0x802AF4BC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AF4C0: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802AF4C4: b           L_802AF50C
    // 0x802AF4C8: lhu         $v0, 0x9C($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X9C);
        goto L_802AF50C;
    // 0x802AF4C8: lhu         $v0, 0x9C($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X9C);
L_802AF4CC:
    // 0x802AF4CC: lh          $t6, -0x614E($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X614E);
    // 0x802AF4D0: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AF4D4: bltz        $t6, L_802AF4EC
    if (SIGNED(ctx->r14) < 0) {
        // 0x802AF4D8: nop
    
            goto L_802AF4EC;
    }
    // 0x802AF4D8: nop

    // 0x802AF4DC: jal         0x802A5EA4
    // 0x802AF4E0: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_6;
    // 0x802AF4E0: nop

    after_6:
    // 0x802AF4E4: b           L_802AF500
    // 0x802AF4E8: nop

        goto L_802AF500;
    // 0x802AF4E8: nop

L_802AF4EC:
    // 0x802AF4EC: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802AF4F0: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802AF4F4: beq         $v0, $at, L_802AF500
    if (ctx->r2 == ctx->r1) {
        // 0x802AF4F8: nop
    
            goto L_802AF500;
    }
    // 0x802AF4F8: nop

    // 0x802AF4FC: sh          $v0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r2;
L_802AF500:
    // 0x802AF500: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AF504: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AF508: lhu         $v0, 0x9C($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X9C);
L_802AF50C:
    // 0x802AF50C: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802AF510: bne         $v0, $at, L_802AF7BC
    if (ctx->r2 != ctx->r1) {
        // 0x802AF514: lui         $t2, 0x801E
        ctx->r10 = S32(0X801E << 16);
            goto L_802AF7BC;
    }
    // 0x802AF514: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x802AF518: addiu       $t2, $t2, -0x6128
    ctx->r10 = ADD32(ctx->r10, -0X6128);
    // 0x802AF51C: addiu       $t8, $t2, 0x7FFF
    ctx->r24 = ADD32(ctx->r10, 0X7FFF);
    // 0x802AF520: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
    // 0x802AF524: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF528: beq         $t8, $zero, L_802AF7BC
    if (ctx->r24 == 0) {
        // 0x802AF52C: nop
    
            goto L_802AF7BC;
    }
    // 0x802AF52C: nop

    // 0x802AF530: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AF534: lh          $t9, 0x30C($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X30C);
    // 0x802AF538: bne         $t9, $zero, L_802AF7BC
    if (ctx->r25 != 0) {
        // 0x802AF53C: nop
    
            goto L_802AF7BC;
    }
    // 0x802AF53C: nop

    // 0x802AF540: lbu         $t3, 0x367($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X367);
    // 0x802AF544: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AF548: bgtz        $t3, L_802AF7BC
    if (SIGNED(ctx->r11) > 0) {
        // 0x802AF54C: nop
    
            goto L_802AF7BC;
    }
    // 0x802AF54C: nop

    // 0x802AF550: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802AF554: lh          $t4, 0x4($t1)
    ctx->r12 = MEM_H(ctx->r9, 0X4);
    // 0x802AF558: lh          $t7, 0x8($t1)
    ctx->r15 = MEM_H(ctx->r9, 0X8);
    // 0x802AF55C: sra         $t5, $t4, 6
    ctx->r13 = S32(SIGNED(ctx->r12) >> 6);
    // 0x802AF560: sll         $t6, $t5, 7
    ctx->r14 = S32(ctx->r13 << 7);
    // 0x802AF564: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x802AF568: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802AF56C: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802AF570: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802AF574: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802AF578: addiu       $t4, $t4, 0x740
    ctx->r12 = ADD32(ctx->r12, 0X740);
    // 0x802AF57C: addu        $t3, $t6, $t9
    ctx->r11 = ADD32(ctx->r14, ctx->r25);
    // 0x802AF580: addu        $v1, $t3, $t4
    ctx->r3 = ADD32(ctx->r11, ctx->r12);
    // 0x802AF584: lbu         $a3, 0x40E($v1)
    ctx->r7 = MEM_BU(ctx->r3, 0X40E);
    // 0x802AF588: lbu         $t0, 0x6($v1)
    ctx->r8 = MEM_BU(ctx->r3, 0X6);
    // 0x802AF58C: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x802AF590: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AF594: beq         $at, $zero, L_802AF5A4
    if (ctx->r1 == 0) {
        // 0x802AF598: nop
    
            goto L_802AF5A4;
    }
    // 0x802AF598: nop

    // 0x802AF59C: b           L_802AF5A4
    // 0x802AF5A0: or          $a2, $t0, $zero
    ctx->r6 = ctx->r8 | 0;
        goto L_802AF5A4;
    // 0x802AF5A0: or          $a2, $t0, $zero
    ctx->r6 = ctx->r8 | 0;
L_802AF5A4:
    // 0x802AF5A4: lbu         $a0, 0x416($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X416);
    // 0x802AF5A8: lbu         $a1, 0xE($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0XE);
    // 0x802AF5AC: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802AF5B0: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF5B4: beq         $at, $zero, L_802AF5C4
    if (ctx->r1 == 0) {
        // 0x802AF5B8: nop
    
            goto L_802AF5C4;
    }
    // 0x802AF5B8: nop

    // 0x802AF5BC: b           L_802AF5C4
    // 0x802AF5C0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802AF5C4;
    // 0x802AF5C0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802AF5C4:
    // 0x802AF5C4: slt         $at, $v0, $a2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802AF5C8: beq         $at, $zero, L_802AF5E8
    if (ctx->r1 == 0) {
        // 0x802AF5CC: slt         $at, $a3, $t0
        ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802AF5E8;
    }
    // 0x802AF5CC: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AF5D0: beq         $at, $zero, L_802AF5E0
    if (ctx->r1 == 0) {
        // 0x802AF5D4: or          $v1, $a3, $zero
        ctx->r3 = ctx->r7 | 0;
            goto L_802AF5E0;
    }
    // 0x802AF5D4: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x802AF5D8: b           L_802AF600
    // 0x802AF5DC: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
        goto L_802AF600;
    // 0x802AF5DC: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
L_802AF5E0:
    // 0x802AF5E0: b           L_802AF600
    // 0x802AF5E4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
        goto L_802AF600;
    // 0x802AF5E4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802AF5E8:
    // 0x802AF5E8: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF5EC: beq         $at, $zero, L_802AF5FC
    if (ctx->r1 == 0) {
        // 0x802AF5F0: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802AF5FC;
    }
    // 0x802AF5F0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802AF5F4: b           L_802AF5FC
    // 0x802AF5F8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802AF5FC;
    // 0x802AF5F8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802AF5FC:
    // 0x802AF5FC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802AF600:
    // 0x802AF600: lh          $t5, 0xC($t1)
    ctx->r13 = MEM_H(ctx->r9, 0XC);
    // 0x802AF604: sll         $t7, $v0, 2
    ctx->r15 = S32(ctx->r2 << 2);
    // 0x802AF608: addiu       $v1, $t2, 0x7FFF
    ctx->r3 = ADD32(ctx->r10, 0X7FFF);
    // 0x802AF60C: subu        $t8, $t5, $t7
    ctx->r24 = SUB32(ctx->r13, ctx->r15);
    // 0x802AF610: slti        $at, $t8, -0x27
    ctx->r1 = SIGNED(ctx->r24) < -0X27 ? 1 : 0;
    // 0x802AF614: bne         $at, $zero, L_802AF7BC
    if (ctx->r1 != 0) {
        // 0x802AF618: addiu       $a1, $zero, 0x1
        ctx->r5 = ADD32(0, 0X1);
            goto L_802AF7BC;
    }
    // 0x802AF618: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AF61C: lh          $v1, 0x7FDB($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7FDB);
    // 0x802AF620: bgez        $v1, L_802AF630
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AF624: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802AF630;
    }
    // 0x802AF624: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802AF628: b           L_802AF630
    // 0x802AF62C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802AF630;
    // 0x802AF62C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802AF630:
    // 0x802AF630: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x802AF634: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802AF638: jal         0x802A5778
    // 0x802AF63C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_802A5778_6B6E28(rdram, ctx);
        goto after_7;
    // 0x802AF63C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_7:
    // 0x802AF640: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF644: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AF648: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AF64C: addiu       $t4, $zero, 0x3
    ctx->r12 = ADD32(0, 0X3);
    // 0x802AF650: lh          $t9, 0x30A($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X30A);
    // 0x802AF654: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802AF658: addiu       $t3, $t9, 0x20
    ctx->r11 = ADD32(ctx->r25, 0X20);
    // 0x802AF65C: sh          $t3, 0x30A($v0)
    MEM_H(0X30A, ctx->r2) = ctx->r11;
    // 0x802AF660: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802AF664: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
    // 0x802AF668: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802AF66C: lh          $t7, 0x4($t1)
    ctx->r15 = MEM_H(ctx->r9, 0X4);
    // 0x802AF670: lh          $t9, 0x8($t1)
    ctx->r25 = MEM_H(ctx->r9, 0X8);
    // 0x802AF674: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x802AF678: sll         $t6, $t8, 7
    ctx->r14 = S32(ctx->r24 << 7);
    // 0x802AF67C: addu        $t6, $t6, $t8
    ctx->r14 = ADD32(ctx->r14, ctx->r24);
    // 0x802AF680: sra         $t3, $t9, 6
    ctx->r11 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802AF684: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x802AF688: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802AF68C: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x802AF690: addiu       $t7, $t7, 0x740
    ctx->r15 = ADD32(ctx->r15, 0X740);
    // 0x802AF694: addu        $t5, $t6, $t4
    ctx->r13 = ADD32(ctx->r14, ctx->r12);
    // 0x802AF698: addu        $v1, $t5, $t7
    ctx->r3 = ADD32(ctx->r13, ctx->r15);
    // 0x802AF69C: lbu         $a3, 0x40E($v1)
    ctx->r7 = MEM_BU(ctx->r3, 0X40E);
    // 0x802AF6A0: lbu         $t0, 0x6($v1)
    ctx->r8 = MEM_BU(ctx->r3, 0X6);
    // 0x802AF6A4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AF6A8: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x802AF6AC: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AF6B0: beq         $at, $zero, L_802AF6C0
    if (ctx->r1 == 0) {
        // 0x802AF6B4: nop
    
            goto L_802AF6C0;
    }
    // 0x802AF6B4: nop

    // 0x802AF6B8: b           L_802AF6C0
    // 0x802AF6BC: or          $a2, $t0, $zero
    ctx->r6 = ctx->r8 | 0;
        goto L_802AF6C0;
    // 0x802AF6BC: or          $a2, $t0, $zero
    ctx->r6 = ctx->r8 | 0;
L_802AF6C0:
    // 0x802AF6C0: lbu         $a0, 0x416($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X416);
    // 0x802AF6C4: lbu         $a1, 0xE($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0XE);
    // 0x802AF6C8: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802AF6CC: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF6D0: beq         $at, $zero, L_802AF6E0
    if (ctx->r1 == 0) {
        // 0x802AF6D4: nop
    
            goto L_802AF6E0;
    }
    // 0x802AF6D4: nop

    // 0x802AF6D8: b           L_802AF6E0
    // 0x802AF6DC: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802AF6E0;
    // 0x802AF6DC: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802AF6E0:
    // 0x802AF6E0: slt         $at, $v0, $a2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802AF6E4: beq         $at, $zero, L_802AF704
    if (ctx->r1 == 0) {
        // 0x802AF6E8: slt         $at, $a3, $t0
        ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802AF704;
    }
    // 0x802AF6E8: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AF6EC: beq         $at, $zero, L_802AF6FC
    if (ctx->r1 == 0) {
        // 0x802AF6F0: or          $v1, $a3, $zero
        ctx->r3 = ctx->r7 | 0;
            goto L_802AF6FC;
    }
    // 0x802AF6F0: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x802AF6F4: b           L_802AF71C
    // 0x802AF6F8: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
        goto L_802AF71C;
    // 0x802AF6F8: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
L_802AF6FC:
    // 0x802AF6FC: b           L_802AF71C
    // 0x802AF700: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
        goto L_802AF71C;
    // 0x802AF700: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802AF704:
    // 0x802AF704: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF708: beq         $at, $zero, L_802AF718
    if (ctx->r1 == 0) {
        // 0x802AF70C: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802AF718;
    }
    // 0x802AF70C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802AF710: b           L_802AF718
    // 0x802AF714: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802AF718;
    // 0x802AF714: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802AF718:
    // 0x802AF718: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802AF71C:
    // 0x802AF71C: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802AF720: lh          $v1, 0xC($t1)
    ctx->r3 = MEM_H(ctx->r9, 0XC);
    // 0x802AF724: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x802AF728: lhu         $a2, 0xB8($t8)
    ctx->r6 = MEM_HU(ctx->r24, 0XB8);
    // 0x802AF72C: subu        $t3, $t9, $a2
    ctx->r11 = SUB32(ctx->r25, ctx->r6);
    // 0x802AF730: addiu       $t6, $t3, 0xC
    ctx->r14 = ADD32(ctx->r11, 0XC);
    // 0x802AF734: slt         $at, $v1, $t6
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802AF738: beql        $at, $zero, L_802AF74C
    if (ctx->r1 == 0) {
        // 0x802AF73C: slt         $at, $a3, $t0
        ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802AF74C;
    }
    goto skip_1;
    // 0x802AF73C: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    skip_1:
    // 0x802AF740: b           L_802AF7BC
    // 0x802AF744: sh          $v1, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r3;
        goto L_802AF7BC;
    // 0x802AF744: sh          $v1, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r3;
    // 0x802AF748: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
L_802AF74C:
    // 0x802AF74C: beq         $at, $zero, L_802AF75C
    if (ctx->r1 == 0) {
        // 0x802AF750: or          $v1, $a3, $zero
        ctx->r3 = ctx->r7 | 0;
            goto L_802AF75C;
    }
    // 0x802AF750: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x802AF754: b           L_802AF75C
    // 0x802AF758: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
        goto L_802AF75C;
    // 0x802AF758: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
L_802AF75C:
    // 0x802AF75C: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF760: beq         $at, $zero, L_802AF770
    if (ctx->r1 == 0) {
        // 0x802AF764: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802AF770;
    }
    // 0x802AF764: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802AF768: b           L_802AF770
    // 0x802AF76C: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802AF770;
    // 0x802AF76C: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802AF770:
    // 0x802AF770: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802AF774: beq         $at, $zero, L_802AF794
    if (ctx->r1 == 0) {
        // 0x802AF778: slt         $at, $a3, $t0
        ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802AF794;
    }
    // 0x802AF778: slt         $at, $a3, $t0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802AF77C: beq         $at, $zero, L_802AF78C
    if (ctx->r1 == 0) {
        // 0x802AF780: or          $v0, $a3, $zero
        ctx->r2 = ctx->r7 | 0;
            goto L_802AF78C;
    }
    // 0x802AF780: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
    // 0x802AF784: b           L_802AF7AC
    // 0x802AF788: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
        goto L_802AF7AC;
    // 0x802AF788: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
L_802AF78C:
    // 0x802AF78C: b           L_802AF7AC
    // 0x802AF790: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802AF7AC;
    // 0x802AF790: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802AF794:
    // 0x802AF794: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802AF798: beq         $at, $zero, L_802AF7A8
    if (ctx->r1 == 0) {
        // 0x802AF79C: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802AF7A8;
    }
    // 0x802AF79C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802AF7A0: b           L_802AF7A8
    // 0x802AF7A4: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802AF7A8;
    // 0x802AF7A4: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802AF7A8:
    // 0x802AF7A8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802AF7AC:
    // 0x802AF7AC: sll         $t4, $v1, 2
    ctx->r12 = S32(ctx->r3 << 2);
    // 0x802AF7B0: subu        $t5, $t4, $a2
    ctx->r13 = SUB32(ctx->r12, ctx->r6);
    // 0x802AF7B4: addiu       $t7, $t5, 0xC
    ctx->r15 = ADD32(ctx->r13, 0XC);
    // 0x802AF7B8: sh          $t7, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r15;
L_802AF7BC:
    // 0x802AF7BC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF7C0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AF7C4: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802AF7C8: blez        $v1, L_802AF7D4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802AF7CC: addiu       $t8, $v1, -0x1
        ctx->r24 = ADD32(ctx->r3, -0X1);
            goto L_802AF7D4;
    }
    // 0x802AF7CC: addiu       $t8, $v1, -0x1
    ctx->r24 = ADD32(ctx->r3, -0X1);
    // 0x802AF7D0: sh          $t8, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r24;
L_802AF7D4:
    // 0x802AF7D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802AF7D8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AF7DC: jr          $ra
    // 0x802AF7E0: nop

    return;
    // 0x802AF7E0: nop

;}
RECOMP_FUNC void func_802AF7E4_6C0E94(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AF7E4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AF7E8: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x802AF7EC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802AF7F0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802AF7F4: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x802AF7F8: bne         $t7, $zero, L_802AF850
    if (ctx->r15 != 0) {
        // 0x802AF7FC: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802AF850;
    }
    // 0x802AF7FC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF800: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AF804: lb          $t8, 0x4A($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X4A);
    // 0x802AF808: bne         $t8, $zero, L_802AF850
    if (ctx->r24 != 0) {
        // 0x802AF80C: nop
    
            goto L_802AF850;
    }
    // 0x802AF80C: nop

    // 0x802AF810: lw          $t9, 0x4C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X4C);
    // 0x802AF814: sll         $t1, $t9, 26
    ctx->r9 = S32(ctx->r25 << 26);
    // 0x802AF818: bltz        $t1, L_802AF850
    if (SIGNED(ctx->r9) < 0) {
        // 0x802AF81C: nop
    
            goto L_802AF850;
    }
    // 0x802AF81C: nop

    // 0x802AF820: lh          $t2, 0x14C($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X14C);
    // 0x802AF824: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AF828: addiu       $t3, $t2, -0x1
    ctx->r11 = ADD32(ctx->r10, -0X1);
    // 0x802AF82C: sh          $t3, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r11;
    // 0x802AF830: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF834: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AF838: lh          $t4, 0x14C($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X14C);
    // 0x802AF83C: sh          $t4, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r12;
    // 0x802AF840: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802AF844: lb          $t5, 0x36B($v1)
    ctx->r13 = MEM_B(ctx->r3, 0X36B);
    // 0x802AF848: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x802AF84C: sb          $t6, 0x36B($v1)
    MEM_B(0X36B, ctx->r3) = ctx->r14;
L_802AF850:
    // 0x802AF850: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF854: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AF858: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802AF85C: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802AF860: beq         $v1, $at, L_802AF880
    if (ctx->r3 == ctx->r1) {
        // 0x802AF864: addiu       $at, $zero, 0xA1
        ctx->r1 = ADD32(0, 0XA1);
            goto L_802AF880;
    }
    // 0x802AF864: addiu       $at, $zero, 0xA1
    ctx->r1 = ADD32(0, 0XA1);
    // 0x802AF868: beq         $v1, $at, L_802AF880
    if (ctx->r3 == ctx->r1) {
        // 0x802AF86C: addiu       $at, $zero, 0xA2
        ctx->r1 = ADD32(0, 0XA2);
            goto L_802AF880;
    }
    // 0x802AF86C: addiu       $at, $zero, 0xA2
    ctx->r1 = ADD32(0, 0XA2);
    // 0x802AF870: beq         $v1, $at, L_802AF8C8
    if (ctx->r3 == ctx->r1) {
        // 0x802AF874: nop
    
            goto L_802AF8C8;
    }
    // 0x802AF874: nop

    // 0x802AF878: b           L_802AF8F8
    // 0x802AF87C: nop

        goto L_802AF8F8;
    // 0x802AF87C: nop

L_802AF880:
    // 0x802AF880: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AF884: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802AF888: lh          $v0, 0x308($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X308);
    // 0x802AF88C: blez        $v0, L_802AF89C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802AF890: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_802AF89C;
    }
    // 0x802AF890: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    // 0x802AF894: b           L_802AF8F8
    // 0x802AF898: sh          $t7, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r15;
        goto L_802AF8F8;
    // 0x802AF898: sh          $t7, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r15;
L_802AF89C:
    // 0x802AF89C: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AF8A0: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802AF8A4: addiu       $a0, $zero, 0x100
    ctx->r4 = ADD32(0, 0X100);
    // 0x802AF8A8: beq         $a0, $v1, L_802AF8F8
    if (ctx->r4 == ctx->r3) {
        // 0x802AF8AC: nop
    
            goto L_802AF8F8;
    }
    // 0x802AF8AC: nop

    // 0x802AF8B0: beq         $a0, $v1, L_802AF8F8
    if (ctx->r4 == ctx->r3) {
        // 0x802AF8B4: nop
    
            goto L_802AF8F8;
    }
    // 0x802AF8B4: nop

    // 0x802AF8B8: jal         0x802A5E1C
    // 0x802AF8BC: andi        $a0, $v1, 0xFFFF
    ctx->r4 = ctx->r3 & 0XFFFF;
    func_802A5E1C_6B74CC(rdram, ctx);
        goto after_0;
    // 0x802AF8BC: andi        $a0, $v1, 0xFFFF
    ctx->r4 = ctx->r3 & 0XFFFF;
    after_0:
    // 0x802AF8C0: b           L_802AF8F8
    // 0x802AF8C4: nop

        goto L_802AF8F8;
    // 0x802AF8C4: nop

L_802AF8C8:
    // 0x802AF8C8: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AF8CC: lh          $v1, -0x6180($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X6180);
    // 0x802AF8D0: addiu       $a0, $zero, 0x100
    ctx->r4 = ADD32(0, 0X100);
    // 0x802AF8D4: bne         $a0, $v1, L_802AF8EC
    if (ctx->r4 != ctx->r3) {
        // 0x802AF8D8: nop
    
            goto L_802AF8EC;
    }
    // 0x802AF8D8: nop

    // 0x802AF8DC: jal         0x802A5E64
    // 0x802AF8E0: nop

    func_802A5E64_6B7514(rdram, ctx);
        goto after_1;
    // 0x802AF8E0: nop

    after_1:
    // 0x802AF8E4: b           L_802AF8F8
    // 0x802AF8E8: nop

        goto L_802AF8F8;
    // 0x802AF8E8: nop

L_802AF8EC:
    // 0x802AF8EC: beq         $a0, $v1, L_802AF8F8
    if (ctx->r4 == ctx->r3) {
        // 0x802AF8F0: nop
    
            goto L_802AF8F8;
    }
    // 0x802AF8F0: nop

    // 0x802AF8F4: sh          $v1, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r3;
L_802AF8F8:
    // 0x802AF8F8: jal         0x8012826C
    // 0x802AF8FC: nop

    advance_random_seed(rdram, ctx);
        goto after_2;
    // 0x802AF8FC: nop

    after_2:
    // 0x802AF900: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802AF904: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x802AF908: andi        $t8, $v0, 0x1F
    ctx->r24 = ctx->r2 & 0X1F;
    // 0x802AF90C: addiu       $t9, $t8, -0xF
    ctx->r25 = ADD32(ctx->r24, -0XF);
    // 0x802AF910: lui         $t1, 0x801F
    ctx->r9 = S32(0X801F << 16);
    // 0x802AF914: sh          $t9, 0x30E($t0)
    MEM_H(0X30E, ctx->r8) = ctx->r25;
    // 0x802AF918: lhu         $t1, -0x6176($t1)
    ctx->r9 = MEM_HU(ctx->r9, -0X6176);
    // 0x802AF91C: lui         $t2, 0x801F
    ctx->r10 = S32(0X801F << 16);
    // 0x802AF920: beql        $t1, $zero, L_802AF9F0
    if (ctx->r9 == 0) {
        // 0x802AF924: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AF9F0;
    }
    goto skip_0;
    // 0x802AF924: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802AF928: lhu         $t2, -0x6170($t2)
    ctx->r10 = MEM_HU(ctx->r10, -0X6170);
    // 0x802AF92C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF930: bnel        $t2, $zero, L_802AF9F0
    if (ctx->r10 != 0) {
        // 0x802AF934: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AF9F0;
    }
    goto skip_1;
    // 0x802AF934: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802AF938: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AF93C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AF940: lh          $v1, 0x1C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X1C);
    // 0x802AF944: bgez        $v1, L_802AF954
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AF948: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_802AF954;
    }
    // 0x802AF948: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802AF94C: b           L_802AF954
    // 0x802AF950: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
        goto L_802AF954;
    // 0x802AF950: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
L_802AF954:
    // 0x802AF954: lh          $a0, 0x20($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X20);
    // 0x802AF958: bgez        $a0, L_802AF968
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802AF95C: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802AF968;
    }
    // 0x802AF95C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802AF960: b           L_802AF968
    // 0x802AF964: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_802AF968;
    // 0x802AF964: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
L_802AF968:
    // 0x802AF968: addu        $t3, $v1, $a1
    ctx->r11 = ADD32(ctx->r3, ctx->r5);
    // 0x802AF96C: slti        $at, $t3, 0xC
    ctx->r1 = SIGNED(ctx->r11) < 0XC ? 1 : 0;
    // 0x802AF970: beql        $at, $zero, L_802AF9F0
    if (ctx->r1 == 0) {
        // 0x802AF974: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802AF9F0;
    }
    goto skip_2;
    // 0x802AF974: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802AF978: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802AF97C: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802AF980: addiu       $v1, $v1, 0x2C78
    ctx->r3 = ADD32(ctx->r3, 0X2C78);
    // 0x802AF984: lh          $t6, 0x302($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X302);
    // 0x802AF988: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x802AF98C: lw          $t4, 0x1C($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X1C);
    // 0x802AF990: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802AF994: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802AF998: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x802AF99C: lh          $t0, 0x0($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X0);
    // 0x802AF9A0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802AF9A4: multu       $t0, $a0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF9A8: mflo        $t1
    ctx->r9 = lo;
    // 0x802AF9AC: addu        $t2, $t4, $t1
    ctx->r10 = ADD32(ctx->r12, ctx->r9);
    // 0x802AF9B0: sw          $t2, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->r10;
    // 0x802AF9B4: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802AF9B8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AF9BC: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802AF9C0: lh          $t6, 0x302($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X302);
    // 0x802AF9C4: lw          $t3, 0x20($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X20);
    // 0x802AF9C8: addiu       $t7, $t6, 0x40
    ctx->r15 = ADD32(ctx->r14, 0X40);
    // 0x802AF9CC: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802AF9D0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802AF9D4: addu        $t0, $v1, $t9
    ctx->r8 = ADD32(ctx->r3, ctx->r25);
    // 0x802AF9D8: lh          $t4, 0x0($t0)
    ctx->r12 = MEM_H(ctx->r8, 0X0);
    // 0x802AF9DC: multu       $t4, $a0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802AF9E0: mflo        $t1
    ctx->r9 = lo;
    // 0x802AF9E4: addu        $t2, $t3, $t1
    ctx->r10 = ADD32(ctx->r11, ctx->r9);
    // 0x802AF9E8: sw          $t2, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r10;
    // 0x802AF9EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802AF9F0:
    // 0x802AF9F0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802AF9F4: jr          $ra
    // 0x802AF9F8: nop

    return;
    // 0x802AF9F8: nop

;}
RECOMP_FUNC void func_802AF9FC_6C10AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802AF9FC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802AFA00: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802AFA04: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802AFA08: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802AFA0C: lh          $t6, 0x30E($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X30E);
    // 0x802AFA10: lui         $t8, 0x801F
    ctx->r24 = S32(0X801F << 16);
    // 0x802AFA14: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFA18: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802AFA1C: sh          $t7, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r15;
    // 0x802AFA20: lhu         $t8, -0x6170($t8)
    ctx->r24 = MEM_HU(ctx->r24, -0X6170);
    // 0x802AFA24: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFA28: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802AFA2C: bne         $t8, $zero, L_802AFA44
    if (ctx->r24 != 0) {
        // 0x802AFA30: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802AFA44;
    }
    // 0x802AFA30: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802AFA34: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AFA38: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x802AFA3C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFA40: sh          $t9, 0x5572($at)
    MEM_H(0X5572, ctx->r1) = ctx->r25;
L_802AFA44:
    // 0x802AFA44: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x802AFA48: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802AFA4C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFA50: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x802AFA54: lh          $t4, 0x2C($t0)
    ctx->r12 = MEM_H(ctx->r8, 0X2C);
    // 0x802AFA58: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
    // 0x802AFA5C: mfhi        $t7
    ctx->r15 = hi;
    // 0x802AFA60: sh          $t4, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r12;
    // 0x802AFA64: lh          $t5, 0xC2($a0)
    ctx->r13 = MEM_H(ctx->r4, 0XC2);
    // 0x802AFA68: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802AFA6C: beq         $t7, $at, L_802AFA88
    if (ctx->r15 == ctx->r1) {
        // 0x802AFA70: sh          $t5, 0x4C($sp)
        MEM_H(0X4C, ctx->r29) = ctx->r13;
            goto L_802AFA88;
    }
    // 0x802AFA70: sh          $t5, 0x4C($sp)
    MEM_H(0X4C, ctx->r29) = ctx->r13;
    // 0x802AFA74: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AFA78: addiu       $t3, $t3, 0x5558
    ctx->r11 = ADD32(ctx->r11, 0X5558);
    // 0x802AFA7C: lh          $t8, 0x0($t3)
    ctx->r24 = MEM_H(ctx->r11, 0X0);
    // 0x802AFA80: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x802AFA84: sh          $t9, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r25;
L_802AFA88:
    // 0x802AFA88: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802AFA8C: lh          $v0, 0xC($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XC);
    // 0x802AFA90: addiu       $t3, $t3, 0x5558
    ctx->r11 = ADD32(ctx->r11, 0X5558);
    // 0x802AFA94: lh          $v1, 0x0($t3)
    ctx->r3 = MEM_H(ctx->r11, 0X0);
    // 0x802AFA98: addiu       $v0, $v0, -0x40
    ctx->r2 = ADD32(ctx->r2, -0X40);
    // 0x802AFA9C: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802AFAA0: beql        $at, $zero, L_802AFAB4
    if (ctx->r1 == 0) {
        // 0x802AFAA4: sh          $v1, 0x0($t3)
        MEM_H(0X0, ctx->r11) = ctx->r3;
            goto L_802AFAB4;
    }
    goto skip_0;
    // 0x802AFAA4: sh          $v1, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r3;
    skip_0:
    // 0x802AFAA8: b           L_802AFAB4
    // 0x802AFAAC: sh          $v0, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r2;
        goto L_802AFAB4;
    // 0x802AFAAC: sh          $v0, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r2;
    // 0x802AFAB0: sh          $v1, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r3;
L_802AFAB4:
    // 0x802AFAB4: lhu         $t4, 0x9C($a0)
    ctx->r12 = MEM_HU(ctx->r4, 0X9C);
    // 0x802AFAB8: sltiu       $at, $t4, 0x2E
    ctx->r1 = ctx->r12 < 0X2E ? 1 : 0;
    // 0x802AFABC: beq         $at, $zero, L_802AFAF0
    if (ctx->r1 == 0) {
        // 0x802AFAC0: sll         $t4, $t4, 2
        ctx->r12 = S32(ctx->r12 << 2);
            goto L_802AFAF0;
    }
    // 0x802AFAC0: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x802AFAC4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AFAC8: addu        $at, $at, $t4
    gpr jr_addend_802AFAD0 = ctx->r12;
    ctx->r1 = ADD32(ctx->r1, ctx->r12);
    // 0x802AFACC: lw          $t4, -0x432C($at)
    ctx->r12 = ADD32(ctx->r1, -0X432C);
    // 0x802AFAD0: jr          $t4
    // 0x802AFAD4: nop

    switch (jr_addend_802AFAD0 >> 2) {
        case 0: goto L_802AFAD8; break;
        case 1: goto L_802AFAF0; break;
        case 2: goto L_802AFAF0; break;
        case 3: goto L_802AFAF0; break;
        case 4: goto L_802AFAF0; break;
        case 5: goto L_802AFAF0; break;
        case 6: goto L_802AFAF0; break;
        case 7: goto L_802AFAF0; break;
        case 8: goto L_802AFAF0; break;
        case 9: goto L_802AFAF0; break;
        case 10: goto L_802AFAF0; break;
        case 11: goto L_802AFAF0; break;
        case 12: goto L_802AFAF0; break;
        case 13: goto L_802AFAF0; break;
        case 14: goto L_802AFAE8; break;
        case 15: goto L_802AFAF0; break;
        case 16: goto L_802AFAF0; break;
        case 17: goto L_802AFAF0; break;
        case 18: goto L_802AFAF0; break;
        case 19: goto L_802AFAE0; break;
        case 20: goto L_802AFAF0; break;
        case 21: goto L_802AFAF0; break;
        case 22: goto L_802AFAF0; break;
        case 23: goto L_802AFAF0; break;
        case 24: goto L_802AFAF0; break;
        case 25: goto L_802AFAE0; break;
        case 26: goto L_802AFAF0; break;
        case 27: goto L_802AFAF0; break;
        case 28: goto L_802AFAF0; break;
        case 29: goto L_802AFAF0; break;
        case 30: goto L_802AFAF0; break;
        case 31: goto L_802AFAF0; break;
        case 32: goto L_802AFAF0; break;
        case 33: goto L_802AFAF0; break;
        case 34: goto L_802AFAF0; break;
        case 35: goto L_802AFAF0; break;
        case 36: goto L_802AFAF0; break;
        case 37: goto L_802AFAF0; break;
        case 38: goto L_802AFAF0; break;
        case 39: goto L_802AFAF0; break;
        case 40: goto L_802AFAF0; break;
        case 41: goto L_802AFAF0; break;
        case 42: goto L_802AFAF0; break;
        case 43: goto L_802AFAF0; break;
        case 44: goto L_802AFAF0; break;
        case 45: goto L_802AFAD8; break;
        default: switch_error(__func__, 0x802AFAD0, 0x803BBCD4);
    }
    // 0x802AFAD4: nop

L_802AFAD8:
    // 0x802AFAD8: b           L_802AFAF4
    // 0x802AFADC: addiu       $t1, $zero, 0x180
    ctx->r9 = ADD32(0, 0X180);
        goto L_802AFAF4;
    // 0x802AFADC: addiu       $t1, $zero, 0x180
    ctx->r9 = ADD32(0, 0X180);
L_802AFAE0:
    // 0x802AFAE0: b           L_802AFAF4
    // 0x802AFAE4: addiu       $t1, $zero, 0x120
    ctx->r9 = ADD32(0, 0X120);
        goto L_802AFAF4;
    // 0x802AFAE4: addiu       $t1, $zero, 0x120
    ctx->r9 = ADD32(0, 0X120);
L_802AFAE8:
    // 0x802AFAE8: b           L_802AFAF4
    // 0x802AFAEC: addiu       $t1, $zero, 0x280
    ctx->r9 = ADD32(0, 0X280);
        goto L_802AFAF4;
    // 0x802AFAEC: addiu       $t1, $zero, 0x280
    ctx->r9 = ADD32(0, 0X280);
L_802AFAF0:
    // 0x802AFAF0: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
L_802AFAF4:
    // 0x802AFAF4: lbu         $t5, 0x160($t0)
    ctx->r13 = MEM_BU(ctx->r8, 0X160);
    // 0x802AFAF8: lh          $a0, 0x4($t0)
    ctx->r4 = MEM_H(ctx->r8, 0X4);
    // 0x802AFAFC: lh          $a1, 0x8($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X8);
    // 0x802AFB00: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    // 0x802AFB04: addiu       $a2, $sp, 0x44
    ctx->r6 = ADD32(ctx->r29, 0X44);
    // 0x802AFB08: addiu       $a3, $sp, 0x42
    ctx->r7 = ADD32(ctx->r29, 0X42);
    // 0x802AFB0C: jal         0x80311A2C
    // 0x802AFB10: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_0;
    // 0x802AFB10: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_0:
    // 0x802AFB14: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFB18: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFB1C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFB20: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x802AFB24: lh          $v1, 0x44($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X44);
    // 0x802AFB28: lw          $t6, 0x68($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X68);
    // 0x802AFB2C: bnel        $t6, $zero, L_802AFB70
    if (ctx->r14 != 0) {
        // 0x802AFB30: lbu         $t7, 0x162($t0)
        ctx->r15 = MEM_BU(ctx->r8, 0X162);
            goto L_802AFB70;
    }
    goto skip_1;
    // 0x802AFB30: lbu         $t7, 0x162($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X162);
    skip_1:
    // 0x802AFB34: bgez        $v1, L_802AFB44
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AFB38: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802AFB44;
    }
    // 0x802AFB38: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802AFB3C: b           L_802AFB44
    // 0x802AFB40: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802AFB44;
    // 0x802AFB40: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802AFB44:
    // 0x802AFB44: slti        $at, $v0, 0x22
    ctx->r1 = SIGNED(ctx->r2) < 0X22 ? 1 : 0;
    // 0x802AFB48: beq         $at, $zero, L_802AFC1C
    if (ctx->r1 == 0) {
        // 0x802AFB4C: lh          $v1, 0x42($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X42);
            goto L_802AFC1C;
    }
    // 0x802AFB4C: lh          $v1, 0x42($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X42);
    // 0x802AFB50: bgez        $v1, L_802AFB60
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802AFB54: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802AFB60;
    }
    // 0x802AFB54: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802AFB58: b           L_802AFB60
    // 0x802AFB5C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802AFB60;
    // 0x802AFB5C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802AFB60:
    // 0x802AFB60: slti        $at, $v0, 0x22
    ctx->r1 = SIGNED(ctx->r2) < 0X22 ? 1 : 0;
    // 0x802AFB64: beql        $at, $zero, L_802AFC20
    if (ctx->r1 == 0) {
        // 0x802AFB68: lhu         $t6, 0x0($t0)
        ctx->r14 = MEM_HU(ctx->r8, 0X0);
            goto L_802AFC20;
    }
    goto skip_2;
    // 0x802AFB68: lhu         $t6, 0x0($t0)
    ctx->r14 = MEM_HU(ctx->r8, 0X0);
    skip_2:
    // 0x802AFB6C: lbu         $t7, 0x162($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X162);
L_802AFB70:
    // 0x802AFB70: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AFB74: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AFB78: bne         $a1, $t7, L_802AFBBC
    if (ctx->r5 != ctx->r15) {
        // 0x802AFB7C: addiu       $a0, $zero, 0x1
        ctx->r4 = ADD32(0, 0X1);
            goto L_802AFBBC;
    }
    // 0x802AFB7C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x802AFB80: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802AFB84: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AFB88: sh          $zero, 0x30E($t8)
    MEM_H(0X30E, ctx->r24) = 0;
    // 0x802AFB8C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFB90: lh          $v1, 0x5558($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X5558);
    // 0x802AFB94: lh          $t9, 0xC($t0)
    ctx->r25 = MEM_H(ctx->r8, 0XC);
    // 0x802AFB98: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802AFB9C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802AFBA0: beq         $at, $zero, L_802AFBB0
    if (ctx->r1 == 0) {
        // 0x802AFBA4: lui         $at, 0x803D
        ctx->r1 = S32(0X803D << 16);
            goto L_802AFBB0;
    }
    // 0x802AFBA4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFBA8: b           L_802AFC1C
    // 0x802AFBAC: sh          $v1, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r3;
        goto L_802AFC1C;
    // 0x802AFBAC: sh          $v1, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r3;
L_802AFBB0:
    // 0x802AFBB0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFBB4: b           L_802AFC1C
    // 0x802AFBB8: sh          $v0, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r2;
        goto L_802AFC1C;
    // 0x802AFBB8: sh          $v0, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r2;
L_802AFBBC:
    // 0x802AFBBC: jal         0x802B25B4
    // 0x802AFBC0: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    func_802B25B4_6C3C64(rdram, ctx);
        goto after_1;
    // 0x802AFBC0: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    after_1:
    // 0x802AFBC4: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x802AFBC8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802AFBCC: lh          $v1, 0x5558($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X5558);
    // 0x802AFBD0: addu        $t4, $v0, $t1
    ctx->r12 = ADD32(ctx->r2, ctx->r9);
    // 0x802AFBD4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFBD8: slt         $at, $t4, $v1
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802AFBDC: beq         $at, $zero, L_802AFBF4
    if (ctx->r1 == 0) {
        // 0x802AFBE0: addiu       $t2, $t2, 0x5530
        ctx->r10 = ADD32(ctx->r10, 0X5530);
            goto L_802AFBF4;
    }
    // 0x802AFBE0: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFBE4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFBE8: sh          $v1, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r3;
    // 0x802AFBEC: b           L_802AFC1C
    // 0x802AFBF0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
        goto L_802AFC1C;
    // 0x802AFBF0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFBF4:
    // 0x802AFBF4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x802AFBF8: jal         0x802B25B4
    // 0x802AFBFC: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    func_802B25B4_6C3C64(rdram, ctx);
        goto after_2;
    // 0x802AFBFC: sh          $t1, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r9;
    after_2:
    // 0x802AFC00: lh          $t1, 0x46($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X46);
    // 0x802AFC04: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFC08: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFC0C: addu        $t5, $v0, $t1
    ctx->r13 = ADD32(ctx->r2, ctx->r9);
    // 0x802AFC10: sh          $t5, 0x5558($at)
    MEM_H(0X5558, ctx->r1) = ctx->r13;
    // 0x802AFC14: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFC18: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFC1C:
    // 0x802AFC1C: lhu         $t6, 0x0($t0)
    ctx->r14 = MEM_HU(ctx->r8, 0X0);
L_802AFC20:
    // 0x802AFC20: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802AFC24: addiu       $t7, $t6, -0x65
    ctx->r15 = ADD32(ctx->r14, -0X65);
    // 0x802AFC28: sltiu       $at, $t7, 0x6
    ctx->r1 = ctx->r15 < 0X6 ? 1 : 0;
    // 0x802AFC2C: beq         $at, $zero, L_802B00F8
    if (ctx->r1 == 0) {
        // 0x802AFC30: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_802B00F8;
    }
    // 0x802AFC30: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802AFC34: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802AFC38: addu        $at, $at, $t7
    gpr jr_addend_802AFC40 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x802AFC3C: lw          $t7, -0x4274($at)
    ctx->r15 = ADD32(ctx->r1, -0X4274);
    // 0x802AFC40: jr          $t7
    // 0x802AFC44: nop

    switch (jr_addend_802AFC40 >> 2) {
        case 0: goto L_802AFC48; break;
        case 1: goto L_802AFEE0; break;
        case 2: goto L_802AFF2C; break;
        case 3: goto L_802AFF90; break;
        case 4: goto L_802B001C; break;
        case 5: goto L_802B00A8; break;
        default: switch_error(__func__, 0x802AFC40, 0x803BBD8C);
    }
    // 0x802AFC44: nop

L_802AFC48:
    // 0x802AFC48: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFC4C: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFC50: addiu       $t8, $t3, 0x7FFF
    ctx->r24 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFC54: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
    // 0x802AFC58: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AFC5C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AFC60: beq         $t8, $zero, L_802AFCB4
    if (ctx->r24 == 0) {
        // 0x802AFC64: addiu       $v0, $t3, 0x7FFF
        ctx->r2 = ADD32(ctx->r11, 0X7FFF);
            goto L_802AFCB4;
    }
    // 0x802AFC64: addiu       $v0, $t3, 0x7FFF
    ctx->r2 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFC68: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x802AFC6C: lhu         $t4, 0x5572($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5572);
    // 0x802AFC70: addiu       $a0, $t3, 0x7FFF
    ctx->r4 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFC74: subu        $t5, $t9, $t4
    ctx->r13 = SUB32(ctx->r25, ctx->r12);
    // 0x802AFC78: slti        $at, $t5, 0x8
    ctx->r1 = SIGNED(ctx->r13) < 0X8 ? 1 : 0;
    // 0x802AFC7C: bne         $at, $zero, L_802AFC90
    if (ctx->r1 != 0) {
        // 0x802AFC80: nop
    
            goto L_802AFC90;
    }
    // 0x802AFC80: nop

    // 0x802AFC84: lbu         $t6, 0x162($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X162);
    // 0x802AFC88: beql        $a1, $t6, L_802AFCB8
    if (ctx->r5 == ctx->r14) {
        // 0x802AFC8C: lh          $v0, 0x7FA9($v0)
        ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
            goto L_802AFCB8;
    }
    goto skip_3;
    // 0x802AFC8C: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    skip_3:
L_802AFC90:
    // 0x802AFC90: jal         0x802A613C
    // 0x802AFC94: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_3;
    // 0x802AFC94: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    after_3:
    // 0x802AFC98: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFC9C: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFCA0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFCA4: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFCA8: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFCAC: b           L_802AFDF0
    // 0x802AFCB0: lbu         $v1, 0x162($t0)
    ctx->r3 = MEM_BU(ctx->r8, 0X162);
        goto L_802AFDF0;
    // 0x802AFCB0: lbu         $v1, 0x162($t0)
    ctx->r3 = MEM_BU(ctx->r8, 0X162);
L_802AFCB4:
    // 0x802AFCB4: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
L_802AFCB8:
    // 0x802AFCB8: addiu       $a0, $zero, 0x100
    ctx->r4 = ADD32(0, 0X100);
    // 0x802AFCBC: beq         $a0, $v0, L_802AFCD4
    if (ctx->r4 == ctx->r2) {
        // 0x802AFCC0: nop
    
            goto L_802AFCD4;
    }
    // 0x802AFCC0: nop

    // 0x802AFCC4: sh          $v0, 0x2C($t0)
    MEM_H(0X2C, ctx->r8) = ctx->r2;
    // 0x802AFCC8: addiu       $v0, $t3, 0x7FFF
    ctx->r2 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFCCC: lh          $v0, 0x7FA9($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FA9);
    // 0x802AFCD0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFCD4:
    // 0x802AFCD4: beq         $a0, $v0, L_802AFDF0
    if (ctx->r4 == ctx->r2) {
        // 0x802AFCD8: lbu         $v1, 0x162($t0)
        ctx->r3 = MEM_BU(ctx->r8, 0X162);
            goto L_802AFDF0;
    }
    // 0x802AFCD8: lbu         $v1, 0x162($t0)
    ctx->r3 = MEM_BU(ctx->r8, 0X162);
    // 0x802AFCDC: bne         $a1, $v1, L_802AFDF0
    if (ctx->r5 != ctx->r3) {
        // 0x802AFCE0: addiu       $t7, $t3, 0x7FFF
        ctx->r15 = ADD32(ctx->r11, 0X7FFF);
            goto L_802AFDF0;
    }
    // 0x802AFCE0: addiu       $t7, $t3, 0x7FFF
    ctx->r15 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFCE4: lh          $t7, 0x7FDB($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X7FDB);
    // 0x802AFCE8: blezl       $t7, L_802AFDF4
    if (SIGNED(ctx->r15) <= 0) {
        // 0x802AFCEC: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_802AFDF4;
    }
    goto skip_4;
    // 0x802AFCEC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    skip_4:
    // 0x802AFCF0: lw          $t1, 0x1C($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X1C);
    // 0x802AFCF4: bnel        $t1, $zero, L_802AFDF4
    if (ctx->r9 != 0) {
        // 0x802AFCF8: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_802AFDF4;
    }
    goto skip_5;
    // 0x802AFCF8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    skip_5:
    // 0x802AFCFC: lw          $t8, 0x20($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X20);
    // 0x802AFD00: andi        $t9, $v0, 0xFF
    ctx->r25 = ctx->r2 & 0XFF;
    // 0x802AFD04: sll         $t4, $t9, 1
    ctx->r12 = S32(ctx->r25 << 1);
    // 0x802AFD08: bne         $t8, $zero, L_802AFDF0
    if (ctx->r24 != 0) {
        // 0x802AFD0C: lui         $t5, 0x8015
        ctx->r13 = S32(0X8015 << 16);
            goto L_802AFDF0;
    }
    // 0x802AFD0C: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x802AFD10: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802AFD14: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x802AFD18: addiu       $t9, $t3, 0x7FFF
    ctx->r25 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFD1C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802AFD20: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x802AFD24: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x802AFD28: sw          $t7, 0x1C($t0)
    MEM_W(0X1C, ctx->r8) = ctx->r15;
    // 0x802AFD2C: lh          $t9, 0x7FA9($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X7FA9);
    // 0x802AFD30: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFD34: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x802AFD38: addiu       $t4, $t9, 0x40
    ctx->r12 = ADD32(ctx->r25, 0X40);
    // 0x802AFD3C: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x802AFD40: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802AFD44: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x802AFD48: lh          $t7, 0x2C78($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C78);
    // 0x802AFD4C: lw          $t8, 0x20($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X20);
    // 0x802AFD50: lui         $t5, 0xA
    ctx->r13 = S32(0XA << 16);
    // 0x802AFD54: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x802AFD58: addu        $t4, $t8, $t9
    ctx->r12 = ADD32(ctx->r24, ctx->r25);
    // 0x802AFD5C: sw          $t4, 0x20($t0)
    MEM_W(0X20, ctx->r8) = ctx->r12;
    // 0x802AFD60: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x802AFD64: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AFD68: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802AFD6C: sw          $t5, 0x24($t6)
    MEM_W(0X24, ctx->r14) = ctx->r13;
    // 0x802AFD70: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFD74: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802AFD78: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802AFD7C: lh          $t9, 0x8($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X8);
    // 0x802AFD80: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
    // 0x802AFD84: lh          $a3, 0x4($t0)
    ctx->r7 = MEM_H(ctx->r8, 0X4);
    // 0x802AFD88: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802AFD8C: sll         $t8, $v1, 1
    ctx->r24 = S32(ctx->r3 << 1);
    // 0x802AFD90: lh          $t4, 0xC($t0)
    ctx->r12 = MEM_H(ctx->r8, 0XC);
    // 0x802AFD94: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802AFD98: addu        $a1, $a1, $t8
    ctx->r5 = ADD32(ctx->r5, ctx->r24);
    // 0x802AFD9C: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    // 0x802AFDA0: lh          $a0, 0x65D0($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X65D0);
    // 0x802AFDA4: lh          $a1, 0x6680($a1)
    ctx->r5 = MEM_H(ctx->r5, 0X6680);
    // 0x802AFDA8: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802AFDAC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802AFDB0: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x802AFDB4: jal         0x8032C360
    // 0x802AFDB8: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    play_sound_effect_at_location(rdram, ctx);
        goto after_4;
    // 0x802AFDB8: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_4:
    // 0x802AFDBC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFDC0: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFDC4: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x802AFDC8: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x802AFDCC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AFDD0: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
    // 0x802AFDD4: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802AFDD8: addiu       $t7, $zero, 0x1B
    ctx->r15 = ADD32(0, 0X1B);
    // 0x802AFDDC: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFDE0: sb          $t7, 0x367($t8)
    MEM_B(0X367, ctx->r24) = ctx->r15;
    // 0x802AFDE4: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802AFDE8: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFDEC: lbu         $v1, 0x162($t0)
    ctx->r3 = MEM_BU(ctx->r8, 0X162);
L_802AFDF0:
    // 0x802AFDF0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
L_802AFDF4:
    // 0x802AFDF4: bne         $v1, $at, L_802AFEB8
    if (ctx->r3 != ctx->r1) {
        // 0x802AFDF8: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_802AFEB8;
    }
    // 0x802AFDF8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AFDFC: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802AFE00: lbu         $t4, 0x367($t9)
    ctx->r12 = MEM_BU(ctx->r25, 0X367);
    // 0x802AFE04: bnel        $t4, $zero, L_802AFEBC
    if (ctx->r12 != 0) {
        // 0x802AFE08: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802AFEBC;
    }
    goto skip_6;
    // 0x802AFE08: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_6:
    // 0x802AFE0C: lh          $t5, 0x24($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X24);
    // 0x802AFE10: addiu       $a0, $t3, 0x7FFF
    ctx->r4 = ADD32(ctx->r11, 0X7FFF);
    // 0x802AFE14: slti        $at, $t5, -0xA
    ctx->r1 = SIGNED(ctx->r13) < -0XA ? 1 : 0;
    // 0x802AFE18: beql        $at, $zero, L_802AFEBC
    if (ctx->r1 == 0) {
        // 0x802AFE1C: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802AFEBC;
    }
    goto skip_7;
    // 0x802AFE1C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_7:
    // 0x802AFE20: jal         0x802A613C
    // 0x802AFE24: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_5;
    // 0x802AFE24: lhu         $a0, 0x7FA9($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X7FA9);
    after_5:
    // 0x802AFE28: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802AFE2C: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802AFE30: lh          $t7, 0x4C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X4C);
    // 0x802AFE34: addiu       $t6, $zero, 0x4
    ctx->r14 = ADD32(0, 0X4);
    // 0x802AFE38: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802AFE3C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFE40: sh          $t6, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r14;
    // 0x802AFE44: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFE48: sh          $t7, 0x30C($t8)
    MEM_H(0X30C, ctx->r24) = ctx->r15;
    // 0x802AFE4C: lw          $t4, 0x0($t2)
    ctx->r12 = MEM_W(ctx->r10, 0X0);
    // 0x802AFE50: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x802AFE54: jal         0x802B8AD8
    // 0x802AFE58: sb          $t9, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r25;
    func_802B8AD8_6CA188(rdram, ctx);
        goto after_6;
    // 0x802AFE58: sb          $t9, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r25;
    after_6:
    // 0x802AFE5C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AFE60: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802AFE64: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x802AFE68: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFE6C: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802AFE70: lhu         $v1, 0x9C($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X9C);
    // 0x802AFE74: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFE78: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802AFE7C: beq         $v1, $at, L_802AFE8C
    if (ctx->r3 == ctx->r1) {
        // 0x802AFE80: nop
    
            goto L_802AFE8C;
    }
    // 0x802AFE80: nop

    // 0x802AFE84: bne         $v1, $zero, L_802AFE9C
    if (ctx->r3 != 0) {
        // 0x802AFE88: addiu       $a1, $zero, 0x13
        ctx->r5 = ADD32(0, 0X13);
            goto L_802AFE9C;
    }
    // 0x802AFE88: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802AFE8C:
    // 0x802AFE8C: lw          $t7, 0x5528($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5528);
    // 0x802AFE90: addiu       $t6, $zero, 0xD
    ctx->r14 = ADD32(0, 0XD);
    // 0x802AFE94: b           L_802AFEB8
    // 0x802AFE98: sh          $t6, 0x3C4($t7)
    MEM_H(0X3C4, ctx->r15) = ctx->r14;
        goto L_802AFEB8;
    // 0x802AFE98: sh          $t6, 0x3C4($t7)
    MEM_H(0X3C4, ctx->r15) = ctx->r14;
L_802AFE9C:
    // 0x802AFE9C: beq         $a1, $v1, L_802AFEA8
    if (ctx->r5 == ctx->r3) {
        // 0x802AFEA0: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802AFEA8;
    }
    // 0x802AFEA0: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802AFEA4: bne         $v1, $at, L_802AFEB8
    if (ctx->r3 != ctx->r1) {
        // 0x802AFEA8: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_802AFEB8;
    }
L_802AFEA8:
    // 0x802AFEA8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802AFEAC: lw          $t9, 0x5528($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5528);
    // 0x802AFEB0: addiu       $t8, $zero, 0xE
    ctx->r24 = ADD32(0, 0XE);
    // 0x802AFEB4: sh          $t8, 0x3C4($t9)
    MEM_H(0X3C4, ctx->r25) = ctx->r24;
L_802AFEB8:
    // 0x802AFEB8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFEBC:
    // 0x802AFEBC: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AFEC0: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFEC4: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802AFEC8: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFECC: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802AFED0: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x802AFED4: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802AFED8: b           L_802B0118
    // 0x802AFEDC: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
        goto L_802B0118;
    // 0x802AFEDC: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
L_802AFEE0:
    // 0x802AFEE0: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802AFEE4: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802AFEE8: lbu         $t5, 0x365($t4)
    ctx->r13 = MEM_BU(ctx->r12, 0X365);
    // 0x802AFEEC: bne         $t5, $zero, L_802AFF08
    if (ctx->r13 != 0) {
        // 0x802AFEF0: nop
    
            goto L_802AFF08;
    }
    // 0x802AFEF0: nop

    // 0x802AFEF4: jal         0x802A60C4
    // 0x802AFEF8: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_7;
    // 0x802AFEF8: nop

    after_7:
    // 0x802AFEFC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFF00: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFF04: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFF08:
    // 0x802AFF08: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFF0C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AFF10: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802AFF14: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802AFF18: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802AFF1C: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFF20: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802AFF24: b           L_802B0118
    // 0x802AFF28: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
        goto L_802B0118;
    // 0x802AFF28: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802AFF2C:
    // 0x802AFF2C: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AFF30: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802AFF34: addiu       $a0, $zero, 0x100
    ctx->r4 = ADD32(0, 0X100);
    // 0x802AFF38: lui         $t6, 0x801F
    ctx->r14 = S32(0X801F << 16);
    // 0x802AFF3C: beq         $a0, $v0, L_802AFF48
    if (ctx->r4 == ctx->r2) {
        // 0x802AFF40: nop
    
            goto L_802AFF48;
    }
    // 0x802AFF40: nop

    // 0x802AFF44: sh          $v0, 0x2C($t0)
    MEM_H(0X2C, ctx->r8) = ctx->r2;
L_802AFF48:
    // 0x802AFF48: lh          $t6, -0x614E($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X614E);
    // 0x802AFF4C: lui         $a0, 0x801F
    ctx->r4 = S32(0X801F << 16);
    // 0x802AFF50: blezl       $t6, L_802AFF6C
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802AFF54: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802AFF6C;
    }
    goto skip_8;
    // 0x802AFF54: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_8:
    // 0x802AFF58: jal         0x802A613C
    // 0x802AFF5C: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_8;
    // 0x802AFF5C: lhu         $a0, -0x6180($a0)
    ctx->r4 = MEM_HU(ctx->r4, -0X6180);
    after_8:
    // 0x802AFF60: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFF64: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFF68: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFF6C:
    // 0x802AFF6C: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFF70: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802AFF74: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802AFF78: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802AFF7C: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802AFF80: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802AFF84: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x802AFF88: b           L_802B0118
    // 0x802AFF8C: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
        goto L_802B0118;
    // 0x802AFF8C: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
L_802AFF90:
    // 0x802AFF90: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802AFF94: lh          $v1, -0x614E($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X614E);
    // 0x802AFF98: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802AFF9C: lhu         $t7, 0x4E($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X4E);
    // 0x802AFFA0: bne         $v1, $zero, L_802AFFC0
    if (ctx->r3 != 0) {
        // 0x802AFFA4: nop
    
            goto L_802AFFC0;
    }
    // 0x802AFFA4: nop

    // 0x802AFFA8: jal         0x802A6100
    // 0x802AFFAC: nop

    func_802A6100_6B77B0(rdram, ctx);
        goto after_9;
    // 0x802AFFAC: nop

    after_9:
    // 0x802AFFB0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFFB4: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFFB8: b           L_802AFFF8
    // 0x802AFFBC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
        goto L_802AFFF8;
    // 0x802AFFBC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFFC0:
    // 0x802AFFC0: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802AFFC4: slti        $at, $v1, 0x3
    ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
    // 0x802AFFC8: beq         $t7, $v0, L_802AFFDC
    if (ctx->r15 == ctx->r2) {
        // 0x802AFFCC: nop
    
            goto L_802AFFDC;
    }
    // 0x802AFFCC: nop

    // 0x802AFFD0: sh          $v0, 0x2C($t0)
    MEM_H(0X2C, ctx->r8) = ctx->r2;
    // 0x802AFFD4: b           L_802AFFF8
    // 0x802AFFD8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
        goto L_802AFFF8;
    // 0x802AFFD8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFFDC:
    // 0x802AFFDC: bne         $at, $zero, L_802AFFF8
    if (ctx->r1 != 0) {
        // 0x802AFFE0: nop
    
            goto L_802AFFF8;
    }
    // 0x802AFFE0: nop

    // 0x802AFFE4: jal         0x802A6198
    // 0x802AFFE8: andi        $a0, $v0, 0xFFFF
    ctx->r4 = ctx->r2 & 0XFFFF;
    func_802A6198_6B7848(rdram, ctx);
        goto after_10;
    // 0x802AFFE8: andi        $a0, $v0, 0xFFFF
    ctx->r4 = ctx->r2 & 0XFFFF;
    after_10:
    // 0x802AFFEC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802AFFF0: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802AFFF4: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802AFFF8:
    // 0x802AFFF8: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802AFFFC: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B0000: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802B0004: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802B0008: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802B000C: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802B0010: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0014: b           L_802B0118
    // 0x802B0018: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
        goto L_802B0118;
    // 0x802B0018: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802B001C:
    // 0x802B001C: lui         $v0, 0x801F
    ctx->r2 = S32(0X801F << 16);
    // 0x802B0020: lh          $v0, -0x6180($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X6180);
    // 0x802B0024: lhu         $t8, 0x4E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X4E);
    // 0x802B0028: addiu       $a0, $zero, 0x100
    ctx->r4 = ADD32(0, 0X100);
    // 0x802B002C: lui         $t9, 0x801F
    ctx->r25 = S32(0X801F << 16);
    // 0x802B0030: beq         $t8, $v0, L_802B0060
    if (ctx->r24 == ctx->r2) {
        // 0x802B0034: nop
    
            goto L_802B0060;
    }
    // 0x802B0034: nop

    // 0x802B0038: bnel        $a0, $v0, L_802B0058
    if (ctx->r4 != ctx->r2) {
        // 0x802B003C: sh          $v0, 0x2C($t0)
        MEM_H(0X2C, ctx->r8) = ctx->r2;
            goto L_802B0058;
    }
    goto skip_9;
    // 0x802B003C: sh          $v0, 0x2C($t0)
    MEM_H(0X2C, ctx->r8) = ctx->r2;
    skip_9:
    // 0x802B0040: jal         0x802A6100
    // 0x802B0044: nop

    func_802A6100_6B77B0(rdram, ctx);
        goto after_11;
    // 0x802B0044: nop

    after_11:
    // 0x802B0048: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B004C: b           L_802B0058
    // 0x802B0050: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
        goto L_802B0058;
    // 0x802B0050: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802B0054: sh          $v0, 0x2C($t0)
    MEM_H(0X2C, ctx->r8) = ctx->r2;
L_802B0058:
    // 0x802B0058: b           L_802B0084
    // 0x802B005C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
        goto L_802B0084;
    // 0x802B005C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B0060:
    // 0x802B0060: lh          $t9, -0x614E($t9)
    ctx->r25 = MEM_H(ctx->r25, -0X614E);
    // 0x802B0064: slti        $at, $t9, 0x3
    ctx->r1 = SIGNED(ctx->r25) < 0X3 ? 1 : 0;
    // 0x802B0068: beq         $at, $zero, L_802B0084
    if (ctx->r1 == 0) {
        // 0x802B006C: nop
    
            goto L_802B0084;
    }
    // 0x802B006C: nop

    // 0x802B0070: jal         0x802A613C
    // 0x802B0074: andi        $a0, $v0, 0xFFFF
    ctx->r4 = ctx->r2 & 0XFFFF;
    func_802A613C_6B77EC(rdram, ctx);
        goto after_12;
    // 0x802B0074: andi        $a0, $v0, 0xFFFF
    ctx->r4 = ctx->r2 & 0XFFFF;
    after_12:
    // 0x802B0078: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B007C: addiu       $t2, $t2, 0x5530
    ctx->r10 = ADD32(ctx->r10, 0X5530);
    // 0x802B0080: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B0084:
    // 0x802B0084: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802B0088: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B008C: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802B0090: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802B0094: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802B0098: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802B009C: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B00A0: b           L_802B0118
    // 0x802B00A4: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
        goto L_802B0118;
    // 0x802B00A4: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802B00A8:
    // 0x802B00A8: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802B00AC: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802B00B0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x802B00B4: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B00B8: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802B00BC: negu        $at, $v1
    ctx->r1 = SUB32(0, ctx->r3);
    // 0x802B00C0: sll         $t4, $at, 4
    ctx->r12 = S32(ctx->r1 << 4);
    // 0x802B00C4: slt         $at, $t4, $v0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B00C8: beq         $at, $zero, L_802B00E8
    if (ctx->r1 == 0) {
        // 0x802B00CC: addiu       $t3, $t3, -0x6128
        ctx->r11 = ADD32(ctx->r11, -0X6128);
            goto L_802B00E8;
    }
    // 0x802B00CC: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802B00D0: subu        $t5, $v0, $v1
    ctx->r13 = SUB32(ctx->r2, ctx->r3);
    // 0x802B00D4: sra         $t6, $v1, 1
    ctx->r14 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802B00D8: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x802B00DC: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
    // 0x802B00E0: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B00E4: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
L_802B00E8:
    // 0x802B00E8: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B00EC: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802B00F0: b           L_802B0118
    // 0x802B00F4: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
        goto L_802B0118;
    // 0x802B00F4: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802B00F8:
    // 0x802B00F8: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802B00FC: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B0100: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802B0104: addiu       $a0, $a0, 0x5B0
    ctx->r4 = ADD32(ctx->r4, 0X5B0);
    // 0x802B0108: addiu       $a2, $a2, 0x5524
    ctx->r6 = ADD32(ctx->r6, 0X5524);
    // 0x802B010C: addiu       $t3, $t3, -0x6128
    ctx->r11 = ADD32(ctx->r11, -0X6128);
    // 0x802B0110: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0114: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
L_802B0118:
    // 0x802B0118: lui         $at, 0x6
    ctx->r1 = S32(0X6 << 16);
    // 0x802B011C: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B0120: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0124: beq         $at, $zero, L_802B0138
    if (ctx->r1 == 0) {
        // 0x802B0128: lui         $at, 0xFFFA
        ctx->r1 = S32(0XFFFA << 16);
            goto L_802B0138;
    }
    // 0x802B0128: lui         $at, 0xFFFA
    ctx->r1 = S32(0XFFFA << 16);
    // 0x802B012C: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0130: beql        $at, $zero, L_802B0160
    if (ctx->r1 == 0) {
        // 0x802B0134: lw          $t5, 0x0($a0)
        ctx->r13 = MEM_W(ctx->r4, 0X0);
            goto L_802B0160;
    }
    goto skip_10;
    // 0x802B0134: lw          $t5, 0x0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X0);
    skip_10:
L_802B0138:
    // 0x802B0138: lhu         $t8, 0x0($t0)
    ctx->r24 = MEM_HU(ctx->r8, 0X0);
    // 0x802B013C: addiu       $at, $zero, 0x6A
    ctx->r1 = ADD32(0, 0X6A);
    // 0x802B0140: sll         $t9, $v0, 3
    ctx->r25 = S32(ctx->r2 << 3);
    // 0x802B0144: beq         $t8, $at, L_802B015C
    if (ctx->r24 == ctx->r1) {
        // 0x802B0148: subu        $t9, $t9, $v0
        ctx->r25 = SUB32(ctx->r25, ctx->r2);
            goto L_802B015C;
    }
    // 0x802B0148: subu        $t9, $t9, $v0
    ctx->r25 = SUB32(ctx->r25, ctx->r2);
    // 0x802B014C: sra         $t4, $t9, 3
    ctx->r12 = S32(SIGNED(ctx->r25) >> 3);
    // 0x802B0150: sw          $t4, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r12;
    // 0x802B0154: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B0158: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
L_802B015C:
    // 0x802B015C: lw          $t5, 0x0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X0);
L_802B0160:
    // 0x802B0160: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B0164: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x802B0168: subu        $t7, $v0, $t6
    ctx->r15 = SUB32(ctx->r2, ctx->r14);
    // 0x802B016C: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
    // 0x802B0170: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x802B0174: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
    // 0x802B0178: beql        $v1, $at, L_802B019C
    if (ctx->r3 == ctx->r1) {
        // 0x802B017C: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B019C;
    }
    goto skip_11;
    // 0x802B017C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_11:
    // 0x802B0180: beql        $a1, $v1, L_802B019C
    if (ctx->r5 == ctx->r3) {
        // 0x802B0184: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B019C;
    }
    goto skip_12;
    // 0x802B0184: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_12:
    // 0x802B0188: beq         $v1, $zero, L_802B0198
    if (ctx->r3 == 0) {
        // 0x802B018C: addiu       $t1, $zero, 0x19
        ctx->r9 = ADD32(0, 0X19);
            goto L_802B0198;
    }
    // 0x802B018C: addiu       $t1, $zero, 0x19
    ctx->r9 = ADD32(0, 0X19);
    // 0x802B0190: bnel        $t1, $v1, L_802B01D0
    if (ctx->r9 != ctx->r3) {
        // 0x802B0194: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B01D0;
    }
    goto skip_13;
    // 0x802B0194: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_13:
L_802B0198:
    // 0x802B0198: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B019C:
    // 0x802B019C: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
    // 0x802B01A0: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B01A4: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B01A8: addiu       $t1, $zero, 0x19
    ctx->r9 = ADD32(0, 0X19);
    // 0x802B01AC: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B01B0: beq         $at, $zero, L_802B02A8
    if (ctx->r1 == 0) {
        // 0x802B01B4: nop
    
            goto L_802B02A8;
    }
    // 0x802B01B4: nop

    // 0x802B01B8: lw          $t9, 0x0($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X0);
    // 0x802B01BC: sra         $t4, $t9, 2
    ctx->r12 = S32(SIGNED(ctx->r25) >> 2);
    // 0x802B01C0: addu        $t5, $v0, $t4
    ctx->r13 = ADD32(ctx->r2, ctx->r12);
    // 0x802B01C4: b           L_802B02A8
    // 0x802B01C8: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
        goto L_802B02A8;
    // 0x802B01C8: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
    // 0x802B01CC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B01D0:
    // 0x802B01D0: lui         $at, 0xFFFB
    ctx->r1 = S32(0XFFFB << 16);
    // 0x802B01D4: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B01D8: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B01DC: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B01E0: beql        $at, $zero, L_802B0204
    if (ctx->r1 == 0) {
        // 0x802B01E4: lui         $at, 0xFFF9
        ctx->r1 = S32(0XFFF9 << 16);
            goto L_802B0204;
    }
    goto skip_14;
    // 0x802B01E4: lui         $at, 0xFFF9
    ctx->r1 = S32(0XFFF9 << 16);
    skip_14:
    // 0x802B01E8: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x802B01EC: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802B01F0: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x802B01F4: sw          $t8, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r24;
    // 0x802B01F8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B01FC: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0200: lui         $at, 0xFFF9
    ctx->r1 = S32(0XFFF9 << 16);
L_802B0204:
    // 0x802B0204: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B0208: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B020C: beql        $at, $zero, L_802B0230
    if (ctx->r1 == 0) {
        // 0x802B0210: lui         $at, 0xFFF8
        ctx->r1 = S32(0XFFF8 << 16);
            goto L_802B0230;
    }
    goto skip_15;
    // 0x802B0210: lui         $at, 0xFFF8
    ctx->r1 = S32(0XFFF8 << 16);
    skip_15:
    // 0x802B0214: lw          $t9, 0x0($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X0);
    // 0x802B0218: sra         $t4, $t9, 4
    ctx->r12 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B021C: addu        $t5, $v0, $t4
    ctx->r13 = ADD32(ctx->r2, ctx->r12);
    // 0x802B0220: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
    // 0x802B0224: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B0228: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B022C: lui         $at, 0xFFF8
    ctx->r1 = S32(0XFFF8 << 16);
L_802B0230:
    // 0x802B0230: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B0234: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0238: beql        $at, $zero, L_802B025C
    if (ctx->r1 == 0) {
        // 0x802B023C: lui         $at, 0xFFF7
        ctx->r1 = S32(0XFFF7 << 16);
            goto L_802B025C;
    }
    goto skip_16;
    // 0x802B023C: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
    skip_16:
    // 0x802B0240: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x802B0244: sra         $t7, $t6, 3
    ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
    // 0x802B0248: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x802B024C: sw          $t8, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r24;
    // 0x802B0250: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B0254: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0258: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
L_802B025C:
    // 0x802B025C: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B0260: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0264: beql        $at, $zero, L_802B0288
    if (ctx->r1 == 0) {
        // 0x802B0268: lui         $at, 0xFFF6
        ctx->r1 = S32(0XFFF6 << 16);
            goto L_802B0288;
    }
    goto skip_17;
    // 0x802B0268: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    skip_17:
    // 0x802B026C: lw          $t9, 0x0($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X0);
    // 0x802B0270: sra         $t4, $t9, 2
    ctx->r12 = S32(SIGNED(ctx->r25) >> 2);
    // 0x802B0274: addu        $t5, $v0, $t4
    ctx->r13 = ADD32(ctx->r2, ctx->r12);
    // 0x802B0278: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
    // 0x802B027C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B0280: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0284: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
L_802B0288:
    // 0x802B0288: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B028C: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0290: beq         $at, $zero, L_802B02A8
    if (ctx->r1 == 0) {
        // 0x802B0294: nop
    
            goto L_802B02A8;
    }
    // 0x802B0294: nop

    // 0x802B0298: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x802B029C: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802B02A0: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x802B02A4: sw          $t8, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r24;
L_802B02A8:
    // 0x802B02A8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B02AC: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802B02B0: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802B02B4: blezl       $v1, L_802B0518
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802B02B8: lw          $t9, 0x0($a2)
        ctx->r25 = MEM_W(ctx->r6, 0X0);
            goto L_802B0518;
    }
    goto skip_18;
    // 0x802B02B8: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
    skip_18:
    // 0x802B02BC: lh          $a3, 0x4C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X4C);
    // 0x802B02C0: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
    // 0x802B02C4: addu        $t9, $t9, $a3
    ctx->r25 = ADD32(ctx->r25, ctx->r7);
    // 0x802B02C8: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x802B02CC: sra         $t4, $t9, 4
    ctx->r12 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B02D0: slt         $at, $t4, $v1
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B02D4: beq         $at, $zero, L_802B04C0
    if (ctx->r1 == 0) {
        // 0x802B02D8: slt         $at, $a3, $v1
        ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_802B04C0;
    }
    // 0x802B02D8: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B02DC: bne         $at, $zero, L_802B04C0
    if (ctx->r1 != 0) {
        // 0x802B02E0: lui         $a0, 0x8015
        ctx->r4 = S32(0X8015 << 16);
            goto L_802B04C0;
    }
    // 0x802B02E0: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x802B02E4: lh          $t6, 0x302($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X302);
    // 0x802B02E8: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x802B02EC: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B02F0: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802B02F4: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802B02F8: addu        $t9, $a0, $t8
    ctx->r25 = ADD32(ctx->r4, ctx->r24);
    // 0x802B02FC: lh          $t4, 0x0($t9)
    ctx->r12 = MEM_H(ctx->r25, 0X0);
    // 0x802B0300: lw          $t5, 0x1C($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X1C);
    // 0x802B0304: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B0308: sll         $t6, $t4, 2
    ctx->r14 = S32(ctx->r12 << 2);
    // 0x802B030C: subu        $t6, $t6, $t4
    ctx->r14 = SUB32(ctx->r14, ctx->r12);
    // 0x802B0310: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802B0314: sw          $t7, 0x1C($t0)
    MEM_W(0X1C, ctx->r8) = ctx->r15;
    // 0x802B0318: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802B031C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B0320: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B0324: lh          $t4, 0x302($t9)
    ctx->r12 = MEM_H(ctx->r25, 0X302);
    // 0x802B0328: lw          $t8, 0x20($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X20);
    // 0x802B032C: addiu       $t5, $t4, 0x40
    ctx->r13 = ADD32(ctx->r12, 0X40);
    // 0x802B0330: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802B0334: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802B0338: addu        $t9, $a0, $t7
    ctx->r25 = ADD32(ctx->r4, ctx->r15);
    // 0x802B033C: lh          $t4, 0x0($t9)
    ctx->r12 = MEM_H(ctx->r25, 0X0);
    // 0x802B0340: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x802B0344: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802B0348: addu        $t6, $t8, $t5
    ctx->r14 = ADD32(ctx->r24, ctx->r13);
    // 0x802B034C: sw          $t6, 0x20($t0)
    MEM_W(0X20, ctx->r8) = ctx->r14;
    // 0x802B0350: lw          $t7, 0x0($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X0);
    // 0x802B0354: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
    // 0x802B0358: beql        $v1, $at, L_802B037C
    if (ctx->r3 == ctx->r1) {
        // 0x802B035C: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B037C;
    }
    goto skip_19;
    // 0x802B035C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_19:
    // 0x802B0360: beql        $a1, $v1, L_802B037C
    if (ctx->r5 == ctx->r3) {
        // 0x802B0364: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B037C;
    }
    goto skip_20;
    // 0x802B0364: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_20:
    // 0x802B0368: beql        $v1, $zero, L_802B037C
    if (ctx->r3 == 0) {
        // 0x802B036C: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B037C;
    }
    goto skip_21;
    // 0x802B036C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_21:
    // 0x802B0370: bnel        $t1, $v1, L_802B0478
    if (ctx->r9 != ctx->r3) {
        // 0x802B0374: lw          $t0, 0x0($t2)
        ctx->r8 = MEM_W(ctx->r10, 0X0);
            goto L_802B0478;
    }
    goto skip_22;
    // 0x802B0374: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    skip_22:
    // 0x802B0378: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B037C:
    // 0x802B037C: lui         $at, 0xFFFE
    ctx->r1 = S32(0XFFFE << 16);
    // 0x802B0380: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B0384: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0388: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B038C: beql        $at, $zero, L_802B03BC
    if (ctx->r1 == 0) {
        // 0x802B0390: lui         $at, 0x4
        ctx->r1 = S32(0X4 << 16);
            goto L_802B03BC;
    }
    goto skip_23;
    // 0x802B0390: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    skip_23:
    // 0x802B0394: lh          $t4, 0x5558($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X5558);
    // 0x802B0398: lh          $t9, 0xC($t0)
    ctx->r25 = MEM_H(ctx->r8, 0XC);
    // 0x802B039C: addiu       $t8, $t4, -0xC0
    ctx->r24 = ADD32(ctx->r12, -0XC0);
    // 0x802B03A0: slt         $at, $t9, $t8
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B03A4: beq         $at, $zero, L_802B03B8
    if (ctx->r1 == 0) {
        // 0x802B03A8: lui         $at, 0x2
        ctx->r1 = S32(0X2 << 16);
            goto L_802B03B8;
    }
    // 0x802B03A8: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x802B03AC: addu        $t5, $v0, $at
    ctx->r13 = ADD32(ctx->r2, ctx->r1);
    // 0x802B03B0: b           L_802B04C0
    // 0x802B03B4: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
        goto L_802B04C0;
    // 0x802B03B4: sw          $t5, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r13;
L_802B03B8:
    // 0x802B03B8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
L_802B03BC:
    // 0x802B03BC: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B03C0: beq         $at, $zero, L_802B03F0
    if (ctx->r1 == 0) {
        // 0x802B03C4: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802B03F0;
    }
    // 0x802B03C4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B03C8: lh          $t7, 0x5558($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5558);
    // 0x802B03CC: lh          $t6, 0xC($t0)
    ctx->r14 = MEM_H(ctx->r8, 0XC);
    // 0x802B03D0: addiu       $t4, $t7, -0xC0
    ctx->r12 = ADD32(ctx->r15, -0XC0);
    // 0x802B03D4: slt         $at, $t6, $t4
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802B03D8: beq         $at, $zero, L_802B03F0
    if (ctx->r1 == 0) {
        // 0x802B03DC: lui         $at, 0x1
        ctx->r1 = S32(0X1 << 16);
            goto L_802B03F0;
    }
    // 0x802B03DC: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B03E0: ori         $at, $at, 0x9000
    ctx->r1 = ctx->r1 | 0X9000;
    // 0x802B03E4: addu        $t9, $v0, $at
    ctx->r25 = ADD32(ctx->r2, ctx->r1);
    // 0x802B03E8: b           L_802B04C0
    // 0x802B03EC: sw          $t9, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r25;
        goto L_802B04C0;
    // 0x802B03EC: sw          $t9, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r25;
L_802B03F0:
    // 0x802B03F0: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x802B03F4: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B03F8: beq         $at, $zero, L_802B04C0
    if (ctx->r1 == 0) {
        // 0x802B03FC: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B04C0;
    }
    // 0x802B03FC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0400: lh          $v1, 0x5558($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X5558);
    // 0x802B0404: lh          $a0, 0xC($t0)
    ctx->r4 = MEM_H(ctx->r8, 0XC);
    // 0x802B0408: addiu       $t5, $v1, -0x40
    ctx->r13 = ADD32(ctx->r3, -0X40);
    // 0x802B040C: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802B0410: beq         $at, $zero, L_802B0424
    if (ctx->r1 == 0) {
        // 0x802B0414: ori         $at, $zero, 0xC000
        ctx->r1 = 0 | 0XC000;
            goto L_802B0424;
    }
    // 0x802B0414: ori         $at, $zero, 0xC000
    ctx->r1 = 0 | 0XC000;
    // 0x802B0418: addu        $t8, $v0, $at
    ctx->r24 = ADD32(ctx->r2, ctx->r1);
    // 0x802B041C: b           L_802B04C0
    // 0x802B0420: sw          $t8, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r24;
        goto L_802B04C0;
    // 0x802B0420: sw          $t8, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r24;
L_802B0424:
    // 0x802B0424: slt         $at, $t5, $a0
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802B0428: beq         $at, $zero, L_802B0444
    if (ctx->r1 == 0) {
        // 0x802B042C: addiu       $t6, $v1, -0x80
        ctx->r14 = ADD32(ctx->r3, -0X80);
            goto L_802B0444;
    }
    // 0x802B042C: addiu       $t6, $v1, -0x80
    ctx->r14 = ADD32(ctx->r3, -0X80);
    // 0x802B0430: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B0434: ori         $at, $at, 0x1000
    ctx->r1 = ctx->r1 | 0X1000;
    // 0x802B0438: addu        $t7, $v0, $at
    ctx->r15 = ADD32(ctx->r2, ctx->r1);
    // 0x802B043C: b           L_802B04C0
    // 0x802B0440: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
        goto L_802B04C0;
    // 0x802B0440: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
L_802B0444:
    // 0x802B0444: slt         $at, $t6, $a0
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802B0448: beq         $at, $zero, L_802B0460
    if (ctx->r1 == 0) {
        // 0x802B044C: lui         $at, 0x1
        ctx->r1 = S32(0X1 << 16);
            goto L_802B0460;
    }
    // 0x802B044C: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B0450: ori         $at, $at, 0x6000
    ctx->r1 = ctx->r1 | 0X6000;
    // 0x802B0454: addu        $t4, $v0, $at
    ctx->r12 = ADD32(ctx->r2, ctx->r1);
    // 0x802B0458: b           L_802B04C0
    // 0x802B045C: sw          $t4, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r12;
        goto L_802B04C0;
    // 0x802B045C: sw          $t4, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r12;
L_802B0460:
    // 0x802B0460: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B0464: ori         $at, $at, 0x9000
    ctx->r1 = ctx->r1 | 0X9000;
    // 0x802B0468: addu        $t9, $v0, $at
    ctx->r25 = ADD32(ctx->r2, ctx->r1);
    // 0x802B046C: b           L_802B04C0
    // 0x802B0470: sw          $t9, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r25;
        goto L_802B04C0;
    // 0x802B0470: sw          $t9, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r25;
    // 0x802B0474: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
L_802B0478:
    // 0x802B0478: lui         $at, 0xA
    ctx->r1 = S32(0XA << 16);
    // 0x802B047C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B0480: lw          $v0, 0x24($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X24);
    // 0x802B0484: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B0488: beq         $at, $zero, L_802B04C0
    if (ctx->r1 == 0) {
        // 0x802B048C: nop
    
            goto L_802B04C0;
    }
    // 0x802B048C: nop

    // 0x802B0490: lh          $t8, 0x5558($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5558);
    // 0x802B0494: lh          $t5, 0xC($t0)
    ctx->r13 = MEM_H(ctx->r8, 0XC);
    // 0x802B0498: slt         $at, $t8, $t5
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B049C: beq         $at, $zero, L_802B04B0
    if (ctx->r1 == 0) {
        // 0x802B04A0: ori         $at, $zero, 0x8000
        ctx->r1 = 0 | 0X8000;
            goto L_802B04B0;
    }
    // 0x802B04A0: ori         $at, $zero, 0x8000
    ctx->r1 = 0 | 0X8000;
    // 0x802B04A4: addu        $t7, $v0, $at
    ctx->r15 = ADD32(ctx->r2, ctx->r1);
    // 0x802B04A8: b           L_802B04C0
    // 0x802B04AC: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
        goto L_802B04C0;
    // 0x802B04AC: sw          $t7, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r15;
L_802B04B0:
    // 0x802B04B0: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B04B4: ori         $at, $at, 0xC000
    ctx->r1 = ctx->r1 | 0XC000;
    // 0x802B04B8: addu        $t6, $v0, $at
    ctx->r14 = ADD32(ctx->r2, ctx->r1);
    // 0x802B04BC: sw          $t6, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r14;
L_802B04C0:
    // 0x802B04C0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B04C4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802B04C8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B04CC: sra         $t8, $a3, 1
    ctx->r24 = S32(SIGNED(ctx->r7) >> 1);
    // 0x802B04D0: lh          $t4, 0x30C($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X30C);
    // 0x802B04D4: addiu       $t9, $t4, -0x1
    ctx->r25 = ADD32(ctx->r12, -0X1);
    // 0x802B04D8: sh          $t9, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r25;
    // 0x802B04DC: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802B04E0: lh          $t7, 0x30C($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X30C);
    // 0x802B04E4: bnel        $t8, $t7, L_802B0660
    if (ctx->r24 != ctx->r15) {
        // 0x802B04E8: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B0660;
    }
    goto skip_24;
    // 0x802B04E8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_24:
    // 0x802B04EC: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x802B04F0: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x802B04F4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B04F8: lhu         $v1, 0x9C($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X9C);
    // 0x802B04FC: beq         $a1, $v1, L_802B050C
    if (ctx->r5 == ctx->r3) {
        // 0x802B0500: nop
    
            goto L_802B050C;
    }
    // 0x802B0500: nop

    // 0x802B0504: bnel        $t1, $v1, L_802B0660
    if (ctx->r9 != ctx->r3) {
        // 0x802B0508: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B0660;
    }
    goto skip_25;
    // 0x802B0508: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_25:
L_802B050C:
    // 0x802B050C: b           L_802B065C
    // 0x802B0510: sh          $t4, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r12;
        goto L_802B065C;
    // 0x802B0510: sh          $t4, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r12;
    // 0x802B0514: lw          $t9, 0x0($a2)
    ctx->r25 = MEM_W(ctx->r6, 0X0);
L_802B0518:
    // 0x802B0518: addiu       $at, $zero, 0xE
    ctx->r1 = ADD32(0, 0XE);
    // 0x802B051C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802B0520: lhu         $t5, 0x9C($t9)
    ctx->r13 = MEM_HU(ctx->r25, 0X9C);
    // 0x802B0524: addiu       $t8, $t3, 0x7FFF
    ctx->r24 = ADD32(ctx->r11, 0X7FFF);
    // 0x802B0528: bnel        $t5, $at, L_802B0580
    if (ctx->r13 != ctx->r1) {
        // 0x802B052C: lhu         $t8, 0x7FB3($t8)
        ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
            goto L_802B0580;
    }
    goto skip_26;
    // 0x802B052C: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
    skip_26:
    // 0x802B0530: addiu       $t8, $t3, 0x7FFF
    ctx->r24 = ADD32(ctx->r11, 0X7FFF);
    // 0x802B0534: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
    // 0x802B0538: beq         $t8, $zero, L_802B058C
    if (ctx->r24 == 0) {
        // 0x802B053C: nop
    
            goto L_802B058C;
    }
    // 0x802B053C: nop

    // 0x802B0540: lw          $t7, 0x0($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X0);
    // 0x802B0544: addiu       $at, $zero, 0x6A
    ctx->r1 = ADD32(0, 0X6A);
    // 0x802B0548: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B054C: lhu         $t6, 0x0($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X0);
    // 0x802B0550: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B0554: beq         $t6, $at, L_802B058C
    if (ctx->r14 == ctx->r1) {
        // 0x802B0558: nop
    
            goto L_802B058C;
    }
    // 0x802B0558: nop

    // 0x802B055C: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x802B0560: lhu         $t9, 0x5572($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5572);
    // 0x802B0564: subu        $t5, $t4, $t9
    ctx->r13 = SUB32(ctx->r12, ctx->r25);
    // 0x802B0568: slti        $at, $t5, 0x8
    ctx->r1 = SIGNED(ctx->r13) < 0X8 ? 1 : 0;
    // 0x802B056C: beq         $at, $zero, L_802B058C
    if (ctx->r1 == 0) {
        // 0x802B0570: nop
    
            goto L_802B058C;
    }
    // 0x802B0570: nop

    // 0x802B0574: b           L_802B058C
    // 0x802B0578: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B058C;
    // 0x802B0578: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802B057C: lhu         $t8, 0x7FB3($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X7FB3);
L_802B0580:
    // 0x802B0580: beq         $t8, $zero, L_802B058C
    if (ctx->r24 == 0) {
        // 0x802B0584: nop
    
            goto L_802B058C;
    }
    // 0x802B0584: nop

    // 0x802B0588: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B058C:
    // 0x802B058C: beq         $v0, $zero, L_802B065C
    if (ctx->r2 == 0) {
        // 0x802B0590: addiu       $t7, $zero, 0x4
        ctx->r15 = ADD32(0, 0X4);
            goto L_802B065C;
    }
    // 0x802B0590: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x802B0594: addiu       $t9, $zero, 0x14
    ctx->r25 = ADD32(0, 0X14);
    // 0x802B0598: lh          $t4, 0x4C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X4C);
    // 0x802B059C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B05A0: sh          $t7, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r15;
    // 0x802B05A4: div         $zero, $t9, $t4
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r12)));
    // 0x802B05A8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x802B05AC: mflo        $t5
    ctx->r13 = lo;
    // 0x802B05B0: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x802B05B4: lw          $t6, 0x24($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X24);
    // 0x802B05B8: sllv        $t7, $t8, $t5
    ctx->r15 = S32(ctx->r24 << (ctx->r13 & 31));
    // 0x802B05BC: bne         $t4, $zero, L_802B05C8
    if (ctx->r12 != 0) {
        // 0x802B05C0: nop
    
            goto L_802B05C8;
    }
    // 0x802B05C0: nop

    // 0x802B05C4: break       7
    do_break(2150303172);
L_802B05C8:
    // 0x802B05C8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B05CC: bne         $t4, $at, L_802B05E0
    if (ctx->r12 != ctx->r1) {
        // 0x802B05D0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B05E0;
    }
    // 0x802B05D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B05D4: bne         $t9, $at, L_802B05E0
    if (ctx->r25 != ctx->r1) {
        // 0x802B05D8: nop
    
            goto L_802B05E0;
    }
    // 0x802B05D8: nop

    // 0x802B05DC: break       6
    do_break(2150303196);
L_802B05E0:
    // 0x802B05E0: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B05E4: sw          $t9, 0x24($t0)
    MEM_W(0X24, ctx->r8) = ctx->r25;
    // 0x802B05E8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B05EC: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802B05F0: lh          $t4, 0x4C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X4C);
    // 0x802B05F4: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x802B05F8: sh          $t4, 0x30C($t8)
    MEM_H(0X30C, ctx->r24) = ctx->r12;
    // 0x802B05FC: lw          $t6, 0x0($t2)
    ctx->r14 = MEM_W(ctx->r10, 0X0);
    // 0x802B0600: jal         0x802B8AD8
    // 0x802B0604: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
    func_802B8AD8_6CA188(rdram, ctx);
        goto after_13;
    // 0x802B0604: sb          $t5, 0x162($t6)
    MEM_B(0X162, ctx->r14) = ctx->r13;
    after_13:
    // 0x802B0608: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B060C: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802B0610: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B0614: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x802B0618: lhu         $v1, 0x9C($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X9C);
    // 0x802B061C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B0620: beq         $v1, $at, L_802B0630
    if (ctx->r3 == ctx->r1) {
        // 0x802B0624: nop
    
            goto L_802B0630;
    }
    // 0x802B0624: nop

    // 0x802B0628: bne         $v1, $zero, L_802B0640
    if (ctx->r3 != 0) {
        // 0x802B062C: nop
    
            goto L_802B0640;
    }
    // 0x802B062C: nop

L_802B0630:
    // 0x802B0630: lw          $t4, 0x5528($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5528);
    // 0x802B0634: addiu       $t9, $zero, 0xD
    ctx->r25 = ADD32(0, 0XD);
    // 0x802B0638: b           L_802B065C
    // 0x802B063C: sh          $t9, 0x3C4($t4)
    MEM_H(0X3C4, ctx->r12) = ctx->r25;
        goto L_802B065C;
    // 0x802B063C: sh          $t9, 0x3C4($t4)
    MEM_H(0X3C4, ctx->r12) = ctx->r25;
L_802B0640:
    // 0x802B0640: beq         $a1, $v1, L_802B064C
    if (ctx->r5 == ctx->r3) {
        // 0x802B0644: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802B064C;
    }
    // 0x802B0644: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802B0648: bne         $v1, $at, L_802B065C
    if (ctx->r3 != ctx->r1) {
        // 0x802B064C: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_802B065C;
    }
L_802B064C:
    // 0x802B064C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B0650: lw          $t5, 0x5528($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5528);
    // 0x802B0654: addiu       $t8, $zero, 0xE
    ctx->r24 = ADD32(0, 0XE);
    // 0x802B0658: sh          $t8, 0x3C4($t5)
    MEM_H(0X3C4, ctx->r13) = ctx->r24;
L_802B065C:
    // 0x802B065C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802B0660:
    // 0x802B0660: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802B0664: jr          $ra
    // 0x802B0668: nop

    return;
    // 0x802B0668: nop

;}
RECOMP_FUNC void func_802B066C_6C1D1C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B066C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0670: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802B0674: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802B0678: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B067C: lh          $t6, 0x308($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X308);
    // 0x802B0680: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x802B0684: addiu       $a1, $a1, -0x6128
    ctx->r5 = ADD32(ctx->r5, -0X6128);
    // 0x802B0688: addiu       $v0, $a1, 0x7FFF
    ctx->r2 = ADD32(ctx->r5, 0X7FFF);
    // 0x802B068C: sh          $t6, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r14;
    // 0x802B0690: lh          $v0, 0x7FDF($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X7FDF);
    // 0x802B0694: bgez        $v0, L_802B06B4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B0698: sra         $a0, $v0, 3
        ctx->r4 = S32(SIGNED(ctx->r2) >> 3);
            goto L_802B06B4;
    }
    // 0x802B0698: sra         $a0, $v0, 3
    ctx->r4 = S32(SIGNED(ctx->r2) >> 3);
    // 0x802B069C: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
    // 0x802B06A0: sra         $t7, $a0, 3
    ctx->r15 = S32(SIGNED(ctx->r4) >> 3);
    // 0x802B06A4: negu        $a0, $t7
    ctx->r4 = SUB32(0, ctx->r15);
    // 0x802B06A8: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x802B06AC: b           L_802B06BC
    // 0x802B06B0: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802B06BC;
    // 0x802B06B0: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
L_802B06B4:
    // 0x802B06B4: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802B06B8: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
L_802B06BC:
    // 0x802B06BC: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    // 0x802B06C0: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x802B06C4: addiu       $t6, $t6, 0xC0
    ctx->r14 = ADD32(ctx->r14, 0XC0);
    // 0x802B06C8: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802B06CC: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x802B06D0: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802B06D4: addu        $t0, $t9, $t6
    ctx->r8 = ADD32(ctx->r25, ctx->r14);
    // 0x802B06D8: lb          $t7, 0x35($t0)
    ctx->r15 = MEM_B(ctx->r8, 0X35);
    // 0x802B06DC: addiu       $t6, $zero, 0x3A
    ctx->r14 = ADD32(0, 0X3A);
    // 0x802B06E0: bnel        $t7, $zero, L_802B0700
    if (ctx->r15 != 0) {
        // 0x802B06E4: lh          $v0, 0x30A($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X30A);
            goto L_802B0700;
    }
    goto skip_0;
    // 0x802B06E4: lh          $v0, 0x30A($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30A);
    skip_0:
    // 0x802B06E8: lh          $t8, 0x30A($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X30A);
    // 0x802B06EC: addu        $t9, $t8, $a0
    ctx->r25 = ADD32(ctx->r24, ctx->r4);
    // 0x802B06F0: sh          $t9, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = ctx->r25;
    // 0x802B06F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B06F8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802B06FC: lh          $v0, 0x30A($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30A);
L_802B0700:
    // 0x802B0700: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802B0704: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B0708: slti        $at, $v0, 0x38
    ctx->r1 = SIGNED(ctx->r2) < 0X38 ? 1 : 0;
    // 0x802B070C: beq         $at, $zero, L_802B0724
    if (ctx->r1 == 0) {
        // 0x802B0710: addiu       $t4, $t4, 0x2A98
        ctx->r12 = ADD32(ctx->r12, 0X2A98);
            goto L_802B0724;
    }
    // 0x802B0710: addiu       $t4, $t4, 0x2A98
    ctx->r12 = ADD32(ctx->r12, 0X2A98);
    // 0x802B0714: sh          $t6, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = ctx->r14;
    // 0x802B0718: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B071C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802B0720: lh          $v0, 0x30A($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30A);
L_802B0724:
    // 0x802B0724: lh          $a0, 0x14($t0)
    ctx->r4 = MEM_H(ctx->r8, 0X14);
    // 0x802B0728: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x802B072C: sll         $t7, $a0, 4
    ctx->r15 = S32(ctx->r4 << 4);
    // 0x802B0730: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B0734: beql        $at, $zero, L_802B074C
    if (ctx->r1 == 0) {
        // 0x802B0738: sra         $t9, $v0, 4
        ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
            goto L_802B074C;
    }
    goto skip_1;
    // 0x802B0738: sra         $t9, $v0, 4
    ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
    skip_1:
    // 0x802B073C: sh          $t7, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = ctx->r15;
    // 0x802B0740: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x802B0744: lh          $v0, 0x30A($t8)
    ctx->r2 = MEM_H(ctx->r24, 0X30A);
    // 0x802B0748: sra         $t9, $v0, 4
    ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
L_802B074C:
    // 0x802B074C: sh          $t9, 0x34($sp)
    MEM_H(0X34, ctx->r29) = ctx->r25;
    // 0x802B0750: lh          $t8, 0x34($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X34);
    // 0x802B0754: addiu       $v1, $a1, 0x7FFF
    ctx->r3 = ADD32(ctx->r5, 0X7FFF);
    // 0x802B0758: andi        $t2, $v0, 0xF
    ctx->r10 = ctx->r2 & 0XF;
    // 0x802B075C: sb          $t8, 0x30($t0)
    MEM_B(0X30, ctx->r8) = ctx->r24;
    // 0x802B0760: lh          $v1, 0x7FDD($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7FDD);
    // 0x802B0764: sll         $t6, $t2, 16
    ctx->r14 = S32(ctx->r10 << 16);
    // 0x802B0768: sra         $t2, $t6, 16
    ctx->r10 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B076C: blez        $v1, L_802B07C0
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802B0770: nop
    
            goto L_802B07C0;
    }
    // 0x802B0770: nop

    // 0x802B0774: lh          $t9, 0x0($t4)
    ctx->r25 = MEM_H(ctx->r12, 0X0);
    // 0x802B0778: addiu       $t5, $zero, 0xDC
    ctx->r13 = ADD32(0, 0XDC);
    // 0x802B077C: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x802B0780: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0784: addiu       $t3, $t3, 0x28E0
    ctx->r11 = ADD32(ctx->r11, 0X28E0);
    // 0x802B0788: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B078C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B0790: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802B0794: mflo        $t6
    ctx->r14 = lo;
    // 0x802B0798: addu        $t7, $t3, $t6
    ctx->r15 = ADD32(ctx->r11, ctx->r14);
    // 0x802B079C: lwc1        $f4, 0x20($t7)
    ctx->f4.u32l = MEM_W(ctx->r15, 0X20);
    // 0x802B07A0: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802B07A4: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802B07A8: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x802B07AC: nop

    // 0x802B07B0: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x802B07B4: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x802B07B8: sh          $t9, 0x2C($t6)
    MEM_H(0X2C, ctx->r14) = ctx->r25;
    // 0x802B07BC: lh          $v1, -0x614C($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X614C);
L_802B07C0:
    // 0x802B07C0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B07C4: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x802B07C8: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802B07CC: addiu       $t4, $t4, 0x2A98
    ctx->r12 = ADD32(ctx->r12, 0X2A98);
    // 0x802B07D0: addiu       $t3, $t3, 0x28E0
    ctx->r11 = ADD32(ctx->r11, 0X28E0);
    // 0x802B07D4: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B07D8: bgez        $v1, L_802B0818
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B07DC: addiu       $t5, $zero, 0xDC
        ctx->r13 = ADD32(0, 0XDC);
            goto L_802B0818;
    }
    // 0x802B07DC: addiu       $t5, $zero, 0xDC
    ctx->r13 = ADD32(0, 0XDC);
    // 0x802B07E0: lh          $t7, 0x0($t4)
    ctx->r15 = MEM_H(ctx->r12, 0X0);
    // 0x802B07E4: lui         $v1, 0x801F
    ctx->r3 = S32(0X801F << 16);
    // 0x802B07E8: multu       $t7, $t5
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B07EC: mflo        $t8
    ctx->r24 = lo;
    // 0x802B07F0: addu        $t9, $t3, $t8
    ctx->r25 = ADD32(ctx->r11, ctx->r24);
    // 0x802B07F4: lwc1        $f8, 0x20($t9)
    ctx->f8.u32l = MEM_W(ctx->r25, 0X20);
    // 0x802B07F8: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x802B07FC: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802B0800: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x802B0804: nop

    // 0x802B0808: addiu       $t6, $t9, 0xC0
    ctx->r14 = ADD32(ctx->r25, 0XC0);
    // 0x802B080C: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802B0810: sh          $t7, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r15;
    // 0x802B0814: lh          $v1, -0x614C($v1)
    ctx->r3 = MEM_H(ctx->r3, -0X614C);
L_802B0818:
    // 0x802B0818: lh          $t9, 0x0($t4)
    ctx->r25 = MEM_H(ctx->r12, 0X0);
    // 0x802B081C: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x802B0820: addiu       $a1, $a1, 0x2C78
    ctx->r5 = ADD32(ctx->r5, 0X2C78);
    // 0x802B0824: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0828: lb          $a0, 0x35($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X35);
    // 0x802B082C: mflo        $t6
    ctx->r14 = lo;
    // 0x802B0830: addu        $t7, $t3, $t6
    ctx->r15 = ADD32(ctx->r11, ctx->r14);
    // 0x802B0834: lwc1        $f16, 0x20($t7)
    ctx->f16.u32l = MEM_W(ctx->r15, 0X20);
    // 0x802B0838: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802B083C: mfc1        $v0, $f18
    ctx->r2 = (int32_t)ctx->f18.u32l;
    // 0x802B0840: nop

    // 0x802B0844: addiu       $t7, $v0, 0x40
    ctx->r15 = ADD32(ctx->r2, 0X40);
    // 0x802B0848: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802B084C: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B0850: addu        $t6, $a1, $t9
    ctx->r14 = ADD32(ctx->r5, ctx->r25);
    // 0x802B0854: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x802B0858: andi        $t9, $v0, 0xFF
    ctx->r25 = ctx->r2 & 0XFF;
    // 0x802B085C: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x802B0860: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802B0864: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0868: addu        $t7, $a1, $t6
    ctx->r15 = ADD32(ctx->r5, ctx->r14);
    // 0x802B086C: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x802B0870: negu        $t6, $v1
    ctx->r14 = SUB32(0, ctx->r3);
    // 0x802B0874: lui         $t7, 0xFFFF
    ctx->r15 = S32(0XFFFF << 16);
    // 0x802B0878: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802B087C: lh          $a1, 0x34($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X34);
    // 0x802B0880: addiu       $t8, $a0, -0x1
    ctx->r24 = ADD32(ctx->r4, -0X1);
    // 0x802B0884: mflo        $a2
    ctx->r6 = lo;
    // 0x802B0888: nop

    // 0x802B088C: nop

    // 0x802B0890: multu       $t9, $t6
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0894: mflo        $a3
    ctx->r7 = lo;
    // 0x802B0898: bnel        $a0, $zero, L_802B08CC
    if (ctx->r4 != 0) {
        // 0x802B089C: sb          $t8, 0x35($t0)
        MEM_B(0X35, ctx->r8) = ctx->r24;
            goto L_802B08CC;
    }
    goto skip_2;
    // 0x802B089C: sb          $t8, 0x35($t0)
    MEM_B(0X35, ctx->r8) = ctx->r24;
    skip_2:
    // 0x802B08A0: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x802B08A4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802B08A8: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802B08AC: jal         0x802DE770
    // 0x802B08B0: sh          $t2, 0x32($sp)
    MEM_H(0X32, ctx->r29) = ctx->r10;
    func_802DE770_6EFE20(rdram, ctx);
        goto after_0;
    // 0x802B08B0: sh          $t2, 0x32($sp)
    MEM_H(0X32, ctx->r29) = ctx->r10;
    after_0:
    // 0x802B08B4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B08B8: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B08BC: lw          $t0, 0x20($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X20);
    // 0x802B08C0: b           L_802B08CC
    // 0x802B08C4: lh          $t2, 0x32($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X32);
        goto L_802B08CC;
    // 0x802B08C4: lh          $t2, 0x32($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X32);
    // 0x802B08C8: sb          $t8, 0x35($t0)
    MEM_B(0X35, ctx->r8) = ctx->r24;
L_802B08CC:
    // 0x802B08CC: bne         $t2, $zero, L_802B095C
    if (ctx->r10 != 0) {
        // 0x802B08D0: lui         $a1, 0x803E
        ctx->r5 = S32(0X803E << 16);
            goto L_802B095C;
    }
    // 0x802B08D0: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802B08D4: lh          $t6, 0x16($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X16);
    // 0x802B08D8: lh          $v1, 0x34($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X34);
    // 0x802B08DC: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802B08E0: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802B08E4: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802B08E8: sll         $t9, $v1, 2
    ctx->r25 = S32(ctx->r3 << 2);
    // 0x802B08EC: addiu       $a1, $a1, -0x5D00
    ctx->r5 = ADD32(ctx->r5, -0X5D00);
    // 0x802B08F0: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802B08F4: subu        $t9, $t9, $v1
    ctx->r25 = SUB32(ctx->r25, ctx->r3);
    // 0x802B08F8: sll         $v1, $t9, 3
    ctx->r3 = S32(ctx->r25 << 3);
    // 0x802B08FC: addu        $t8, $a1, $t7
    ctx->r24 = ADD32(ctx->r5, ctx->r15);
    // 0x802B0900: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x802B0904: lw          $t6, 0x0($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X0);
    // 0x802B0908: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802B090C: sw          $t6, 0x4($t7)
    MEM_W(0X4, ctx->r15) = ctx->r14;
    // 0x802B0910: lh          $t8, 0x16($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X16);
    // 0x802B0914: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x802B0918: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x802B091C: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802B0920: addu        $t6, $a1, $t9
    ctx->r14 = ADD32(ctx->r5, ctx->r25);
    // 0x802B0924: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x802B0928: lw          $t8, 0x4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X4);
    // 0x802B092C: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B0930: sw          $t8, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r24;
    // 0x802B0934: lh          $t6, 0x16($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X16);
    // 0x802B0938: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802B093C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802B0940: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802B0944: addu        $t8, $a1, $t7
    ctx->r24 = ADD32(ctx->r5, ctx->r15);
    // 0x802B0948: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x802B094C: lw          $t6, 0x8($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X8);
    // 0x802B0950: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802B0954: b           L_802B0A5C
    // 0x802B0958: sw          $t6, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r14;
        goto L_802B0A5C;
    // 0x802B0958: sw          $t6, 0xC($t7)
    MEM_W(0XC, ctx->r15) = ctx->r14;
L_802B095C:
    // 0x802B095C: lh          $t9, 0x16($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X16);
    // 0x802B0960: lh          $v1, 0x34($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X34);
    // 0x802B0964: addiu       $a1, $a1, -0x5D00
    ctx->r5 = ADD32(ctx->r5, -0X5D00);
    // 0x802B0968: sll         $t6, $t9, 2
    ctx->r14 = S32(ctx->r25 << 2);
    // 0x802B096C: subu        $t6, $t6, $t9
    ctx->r14 = SUB32(ctx->r14, ctx->r25);
    // 0x802B0970: sll         $t8, $v1, 2
    ctx->r24 = S32(ctx->r3 << 2);
    // 0x802B0974: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802B0978: subu        $t8, $t8, $v1
    ctx->r24 = SUB32(ctx->r24, ctx->r3);
    // 0x802B097C: sll         $v1, $t8, 3
    ctx->r3 = S32(ctx->r24 << 3);
    // 0x802B0980: addu        $t7, $a1, $t6
    ctx->r15 = ADD32(ctx->r5, ctx->r14);
    // 0x802B0984: addu        $v0, $t7, $v1
    ctx->r2 = ADD32(ctx->r15, ctx->r3);
    // 0x802B0988: lw          $t9, 0x18($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X18);
    // 0x802B098C: addiu       $t8, $zero, 0x10
    ctx->r24 = ADD32(0, 0X10);
    // 0x802B0990: subu        $a0, $t8, $t2
    ctx->r4 = SUB32(ctx->r24, ctx->r10);
    // 0x802B0994: sra         $t6, $t9, 4
    ctx->r14 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B0998: multu       $t6, $t2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B099C: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B09A0: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802B09A4: mflo        $t7
    ctx->r15 = lo;
    // 0x802B09A8: nop

    // 0x802B09AC: nop

    // 0x802B09B0: multu       $a0, $t9
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B09B4: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B09B8: mflo        $t6
    ctx->r14 = lo;
    // 0x802B09BC: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B09C0: sw          $t8, 0x4($t9)
    MEM_W(0X4, ctx->r25) = ctx->r24;
    // 0x802B09C4: lh          $t7, 0x16($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X16);
    // 0x802B09C8: sll         $t6, $t7, 2
    ctx->r14 = S32(ctx->r15 << 2);
    // 0x802B09CC: subu        $t6, $t6, $t7
    ctx->r14 = SUB32(ctx->r14, ctx->r15);
    // 0x802B09D0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802B09D4: addu        $t8, $a1, $t6
    ctx->r24 = ADD32(ctx->r5, ctx->r14);
    // 0x802B09D8: addu        $v0, $t8, $v1
    ctx->r2 = ADD32(ctx->r24, ctx->r3);
    // 0x802B09DC: lw          $t9, 0x1C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X1C);
    // 0x802B09E0: lw          $t8, 0x4($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X4);
    // 0x802B09E4: sra         $t7, $t9, 4
    ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B09E8: multu       $t7, $t2
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B09EC: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802B09F0: mflo        $t6
    ctx->r14 = lo;
    // 0x802B09F4: nop

    // 0x802B09F8: nop

    // 0x802B09FC: multu       $a0, $t9
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0A00: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B0A04: mflo        $t7
    ctx->r15 = lo;
    // 0x802B0A08: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B0A0C: sw          $t8, 0x8($t9)
    MEM_W(0X8, ctx->r25) = ctx->r24;
    // 0x802B0A10: lh          $t6, 0x16($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X16);
    // 0x802B0A14: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802B0A18: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802B0A1C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802B0A20: addu        $t8, $a1, $t7
    ctx->r24 = ADD32(ctx->r5, ctx->r15);
    // 0x802B0A24: addu        $v0, $t8, $v1
    ctx->r2 = ADD32(ctx->r24, ctx->r3);
    // 0x802B0A28: lw          $t9, 0x20($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X20);
    // 0x802B0A2C: lw          $t8, 0x8($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X8);
    // 0x802B0A30: sra         $t6, $t9, 4
    ctx->r14 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B0A34: multu       $t6, $t2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0A38: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802B0A3C: mflo        $t7
    ctx->r15 = lo;
    // 0x802B0A40: nop

    // 0x802B0A44: nop

    // 0x802B0A48: multu       $a0, $t9
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0A4C: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B0A50: mflo        $t6
    ctx->r14 = lo;
    // 0x802B0A54: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B0A58: sw          $t8, 0xC($t9)
    MEM_W(0XC, ctx->r25) = ctx->r24;
L_802B0A5C:
    // 0x802B0A5C: lw          $a0, 0x0($t1)
    ctx->r4 = MEM_W(ctx->r9, 0X0);
    // 0x802B0A60: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802B0A64: jal         0x803136B0
    // 0x802B0A68: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    func_803136B0_724D60(rdram, ctx);
        goto after_1;
    // 0x802B0A68: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    after_1:
    // 0x802B0A6C: lw          $t0, 0x20($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X20);
    // 0x802B0A70: lw          $v1, 0x24($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X24);
    // 0x802B0A74: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802B0A78: lh          $t7, 0x16($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X16);
    // 0x802B0A7C: addiu       $a1, $a1, -0x5D00
    ctx->r5 = ADD32(ctx->r5, -0X5D00);
    // 0x802B0A80: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B0A84: sll         $t6, $t7, 2
    ctx->r14 = S32(ctx->r15 << 2);
    // 0x802B0A88: subu        $t6, $t6, $t7
    ctx->r14 = SUB32(ctx->r14, ctx->r15);
    // 0x802B0A8C: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802B0A90: addu        $t8, $a1, $t6
    ctx->r24 = ADD32(ctx->r5, ctx->r14);
    // 0x802B0A94: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B0A98: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x802B0A9C: lw          $t7, 0xC($t9)
    ctx->r15 = MEM_W(ctx->r25, 0XC);
    // 0x802B0AA0: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802B0AA4: sw          $t7, 0x1C($t6)
    MEM_W(0X1C, ctx->r14) = ctx->r15;
    // 0x802B0AA8: lh          $t8, 0x16($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X16);
    // 0x802B0AAC: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x802B0AB0: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x802B0AB4: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x802B0AB8: addu        $t7, $a1, $t9
    ctx->r15 = ADD32(ctx->r5, ctx->r25);
    // 0x802B0ABC: addu        $t6, $t7, $v1
    ctx->r14 = ADD32(ctx->r15, ctx->r3);
    // 0x802B0AC0: lw          $t8, 0x10($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X10);
    // 0x802B0AC4: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B0AC8: sw          $t8, 0x20($t9)
    MEM_W(0X20, ctx->r25) = ctx->r24;
    // 0x802B0ACC: lh          $t7, 0x16($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X16);
    // 0x802B0AD0: sll         $t6, $t7, 2
    ctx->r14 = S32(ctx->r15 << 2);
    // 0x802B0AD4: subu        $t6, $t6, $t7
    ctx->r14 = SUB32(ctx->r14, ctx->r15);
    // 0x802B0AD8: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802B0ADC: addu        $t8, $a1, $t6
    ctx->r24 = ADD32(ctx->r5, ctx->r14);
    // 0x802B0AE0: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x802B0AE4: lw          $t7, 0x14($t9)
    ctx->r15 = MEM_W(ctx->r25, 0X14);
    // 0x802B0AE8: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802B0AEC: sw          $t7, 0x24($t6)
    MEM_W(0X24, ctx->r14) = ctx->r15;
    // 0x802B0AF0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B0AF4: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802B0AF8: jr          $ra
    // 0x802B0AFC: nop

    return;
    // 0x802B0AFC: nop

;}
RECOMP_FUNC void func_802B0B00_6C21B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B0B00: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B0B04: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B0B08: lw          $a2, 0x5530($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X5530);
    // 0x802B0B0C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B0B10: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B0B14: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B0B18: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B0B1C: lhu         $t7, 0x0($a2)
    ctx->r15 = MEM_HU(ctx->r6, 0X0);
    // 0x802B0B20: sll         $s0, $a1, 16
    ctx->r16 = S32(ctx->r5 << 16);
    // 0x802B0B24: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x802B0B28: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x802B0B2C: sltiu       $at, $t8, 0x5
    ctx->r1 = ctx->r24 < 0X5 ? 1 : 0;
    // 0x802B0B30: beq         $at, $zero, L_802B0D24
    if (ctx->r1 == 0) {
        // 0x802B0B34: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_802B0D24;
    }
    // 0x802B0B34: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x802B0B38: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802B0B3C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B0B40: addu        $at, $at, $t8
    gpr jr_addend_802B0B48 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802B0B44: lw          $t8, -0x425C($at)
    ctx->r24 = ADD32(ctx->r1, -0X425C);
    // 0x802B0B48: jr          $t8
    // 0x802B0B4C: nop

    switch (jr_addend_802B0B48 >> 2) {
        case 0: goto L_802B0B50; break;
        case 1: goto L_802B0B50; break;
        case 2: goto L_802B0B9C; break;
        case 3: goto L_802B0C54; break;
        case 4: goto L_802B0D24; break;
        default: switch_error(__func__, 0x802B0B48, 0x803BBDA4);
    }
    // 0x802B0B4C: nop

L_802B0B50:
    // 0x802B0B50: blez        $s0, L_802B0D24
    if (SIGNED(ctx->r16) <= 0) {
        // 0x802B0B54: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0D24;
    }
    // 0x802B0B54: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0B58: beq         $at, $zero, L_802B0B78
    if (ctx->r1 == 0) {
        // 0x802B0B5C: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B0B78;
    }
    // 0x802B0B5C: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B0B60: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0B64: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0B68: jal         0x802A43E4
    // 0x802B0B6C: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    func_802A43E4_6B5A94(rdram, ctx);
        goto after_0;
    // 0x802B0B6C: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    after_0:
    // 0x802B0B70: b           L_802B0D24
    // 0x802B0B74: nop

        goto L_802B0D24;
    // 0x802B0B74: nop

L_802B0B78:
    // 0x802B0B78: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0B7C: bne         $at, $zero, L_802B0D24
    if (ctx->r1 != 0) {
        // 0x802B0B80: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B0D24;
    }
    // 0x802B0B80: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B0B84: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0B88: sra         $t0, $a1, 24
    ctx->r8 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0B8C: jal         0x802A459C
    // 0x802B0B90: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    func_802A459C_6B5C4C(rdram, ctx);
        goto after_1;
    // 0x802B0B90: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    after_1:
    // 0x802B0B94: b           L_802B0D24
    // 0x802B0B98: nop

        goto L_802B0D24;
    // 0x802B0B98: nop

L_802B0B9C:
    // 0x802B0B9C: bgez        $s0, L_802B0BB4
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B0BA0: nop
    
            goto L_802B0BB4;
    }
    // 0x802B0BA0: nop

    // 0x802B0BA4: jal         0x802A4390
    // 0x802B0BA8: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_2;
    // 0x802B0BA8: nop

    after_2:
    // 0x802B0BAC: b           L_802B0D24
    // 0x802B0BB0: nop

        goto L_802B0D24;
    // 0x802B0BB0: nop

L_802B0BB4:
    // 0x802B0BB4: bne         $s0, $zero, L_802B0BCC
    if (ctx->r16 != 0) {
        // 0x802B0BB8: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0BCC;
    }
    // 0x802B0BB8: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0BBC: jal         0x802A4390
    // 0x802B0BC0: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_3;
    // 0x802B0BC0: nop

    after_3:
    // 0x802B0BC4: b           L_802B0D24
    // 0x802B0BC8: nop

        goto L_802B0D24;
    // 0x802B0BC8: nop

L_802B0BCC:
    // 0x802B0BCC: bne         $at, $zero, L_802B0BF0
    if (ctx->r1 != 0) {
        // 0x802B0BD0: lh          $t2, 0x22($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X22);
            goto L_802B0BF0;
    }
    // 0x802B0BD0: lh          $t2, 0x22($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X22);
    // 0x802B0BD4: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0BD8: sra         $t1, $a1, 24
    ctx->r9 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0BDC: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x802B0BE0: jal         0x802A459C
    // 0x802B0BE4: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A459C_6B5C4C(rdram, ctx);
        goto after_4;
    // 0x802B0BE4: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_4:
    // 0x802B0BE8: b           L_802B0D24
    // 0x802B0BEC: nop

        goto L_802B0D24;
    // 0x802B0BEC: nop

L_802B0BF0:
    // 0x802B0BF0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0BF4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B0BF8: sh          $t2, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r10;
    // 0x802B0BFC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C00: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B0C04: lb          $t3, 0x368($v0)
    ctx->r11 = MEM_B(ctx->r2, 0X368);
    // 0x802B0C08: beq         $s0, $t3, L_802B0D24
    if (ctx->r16 == ctx->r11) {
        // 0x802B0C0C: nop
    
            goto L_802B0D24;
    }
    // 0x802B0C0C: nop

    // 0x802B0C10: sb          $s0, 0x368($v0)
    MEM_B(0X368, ctx->r2) = ctx->r16;
    // 0x802B0C14: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802B0C18: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C1C: lhu         $t5, 0xA4($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0XA4);
    // 0x802B0C20: multu       $s0, $t5
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0C24: mflo        $t6
    ctx->r14 = lo;
    // 0x802B0C28: bgez        $t6, L_802B0C38
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802B0C2C: sra         $t7, $t6, 4
        ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
            goto L_802B0C38;
    }
    // 0x802B0C2C: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802B0C30: addiu       $at, $t6, 0xF
    ctx->r1 = ADD32(ctx->r14, 0XF);
    // 0x802B0C34: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_802B0C38:
    // 0x802B0C38: jal         0x802B8B74
    // 0x802B0C3C: sh          $t7, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = ctx->r15;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_5;
    // 0x802B0C3C: sh          $t7, 0x31A($t8)
    MEM_H(0X31A, ctx->r24) = ctx->r15;
    after_5:
    // 0x802B0C40: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0C44: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B0C48: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C4C: b           L_802B0D24
    // 0x802B0C50: sh          $v0, 0x2FA($t9)
    MEM_H(0X2FA, ctx->r25) = ctx->r2;
        goto L_802B0D24;
    // 0x802B0C50: sh          $v0, 0x2FA($t9)
    MEM_H(0X2FA, ctx->r25) = ctx->r2;
L_802B0C54:
    // 0x802B0C54: bgez        $s0, L_802B0C88
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B0C58: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B0C88;
    }
    // 0x802B0C58: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0C5C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B0C60: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C64: addiu       $t2, $zero, 0x3E8
    ctx->r10 = ADD32(0, 0X3E8);
    // 0x802B0C68: sb          $zero, 0x368($t0)
    MEM_B(0X368, ctx->r8) = 0;
    // 0x802B0C6C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C70: sh          $zero, 0x31A($t1)
    MEM_H(0X31A, ctx->r9) = 0;
    // 0x802B0C74: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x802B0C78: jal         0x802A4390
    // 0x802B0C7C: sh          $t2, 0x2FA($t3)
    MEM_H(0X2FA, ctx->r11) = ctx->r10;
    func_802A4390_6B5A40(rdram, ctx);
        goto after_6;
    // 0x802B0C7C: sh          $t2, 0x2FA($t3)
    MEM_H(0X2FA, ctx->r11) = ctx->r10;
    after_6:
    // 0x802B0C80: b           L_802B0D24
    // 0x802B0C84: nop

        goto L_802B0D24;
    // 0x802B0C84: nop

L_802B0C88:
    // 0x802B0C88: bne         $s0, $zero, L_802B0CA0
    if (ctx->r16 != 0) {
        // 0x802B0C8C: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0CA0;
    }
    // 0x802B0C8C: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0C90: jal         0x802A4390
    // 0x802B0C94: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_7;
    // 0x802B0C94: nop

    after_7:
    // 0x802B0C98: b           L_802B0D24
    // 0x802B0C9C: nop

        goto L_802B0D24;
    // 0x802B0C9C: nop

L_802B0CA0:
    // 0x802B0CA0: beq         $at, $zero, L_802B0CC4
    if (ctx->r1 == 0) {
        // 0x802B0CA4: lh          $t5, 0x22($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X22);
            goto L_802B0CC4;
    }
    // 0x802B0CA4: lh          $t5, 0x22($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X22);
    // 0x802B0CA8: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0CAC: sra         $t4, $a1, 24
    ctx->r12 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0CB0: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x802B0CB4: jal         0x802A43E4
    // 0x802B0CB8: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A43E4_6B5A94(rdram, ctx);
        goto after_8;
    // 0x802B0CB8: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_8:
    // 0x802B0CBC: b           L_802B0D24
    // 0x802B0CC0: nop

        goto L_802B0D24;
    // 0x802B0CC0: nop

L_802B0CC4:
    // 0x802B0CC4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0CC8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B0CCC: sh          $t5, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r13;
    // 0x802B0CD0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B0CD4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B0CD8: lb          $t6, 0x368($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X368);
    // 0x802B0CDC: beq         $s0, $t6, L_802B0D24
    if (ctx->r16 == ctx->r14) {
        // 0x802B0CE0: nop
    
            goto L_802B0D24;
    }
    // 0x802B0CE0: nop

    // 0x802B0CE4: sb          $s0, 0x368($v0)
    MEM_B(0X368, ctx->r2) = ctx->r16;
    // 0x802B0CE8: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802B0CEC: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802B0CF0: lhu         $t8, 0xA4($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XA4);
    // 0x802B0CF4: multu       $s0, $t8
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0CF8: mflo        $t9
    ctx->r25 = lo;
    // 0x802B0CFC: bgez        $t9, L_802B0D0C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802B0D00: sra         $t0, $t9, 4
        ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
            goto L_802B0D0C;
    }
    // 0x802B0D00: sra         $t0, $t9, 4
    ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B0D04: addiu       $at, $t9, 0xF
    ctx->r1 = ADD32(ctx->r25, 0XF);
    // 0x802B0D08: sra         $t0, $at, 4
    ctx->r8 = S32(SIGNED(ctx->r1) >> 4);
L_802B0D0C:
    // 0x802B0D0C: jal         0x802B8B74
    // 0x802B0D10: sh          $t0, 0x31A($t1)
    MEM_H(0X31A, ctx->r9) = ctx->r8;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_9;
    // 0x802B0D10: sh          $t0, 0x31A($t1)
    MEM_H(0X31A, ctx->r9) = ctx->r8;
    after_9:
    // 0x802B0D14: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0D18: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B0D1C: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x802B0D20: sh          $v0, 0x2FA($t2)
    MEM_H(0X2FA, ctx->r10) = ctx->r2;
L_802B0D24:
    // 0x802B0D24: bgez        $s0, L_802B0D38
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B0D28: lh          $t3, 0x22($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X22);
            goto L_802B0D38;
    }
    // 0x802B0D28: lh          $t3, 0x22($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X22);
    // 0x802B0D2C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B0D30: lw          $t4, 0x5530($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5530);
    // 0x802B0D34: sh          $t3, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r11;
L_802B0D38:
    // 0x802B0D38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B0D3C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B0D40: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B0D44: jr          $ra
    // 0x802B0D48: nop

    return;
    // 0x802B0D48: nop

;}
RECOMP_FUNC void func_802B0D4C_6C23FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B0D4C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B0D50: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0D54: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B0D58: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B0D5C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B0D60: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B0D64: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B0D68: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802B0D6C: sll         $s0, $a1, 16
    ctx->r16 = S32(ctx->r5 << 16);
    // 0x802B0D70: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x802B0D74: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B0D78: beq         $v0, $at, L_802B0DA4
    if (ctx->r2 == ctx->r1) {
        // 0x802B0D7C: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_802B0DA4;
    }
    // 0x802B0D7C: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x802B0D80: addiu       $at, $zero, 0xB5
    ctx->r1 = ADD32(0, 0XB5);
    // 0x802B0D84: beq         $v0, $at, L_802B0DA4
    if (ctx->r2 == ctx->r1) {
        // 0x802B0D88: addiu       $at, $zero, 0xB6
        ctx->r1 = ADD32(0, 0XB6);
            goto L_802B0DA4;
    }
    // 0x802B0D88: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B0D8C: beq         $v0, $at, L_802B0DF0
    if (ctx->r2 == ctx->r1) {
        // 0x802B0D90: addiu       $at, $zero, 0xB7
        ctx->r1 = ADD32(0, 0XB7);
            goto L_802B0DF0;
    }
    // 0x802B0D90: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B0D94: beq         $v0, $at, L_802B0E8C
    if (ctx->r2 == ctx->r1) {
        // 0x802B0D98: nop
    
            goto L_802B0E8C;
    }
    // 0x802B0D98: nop

    // 0x802B0D9C: b           L_802B0F24
    // 0x802B0DA0: nop

        goto L_802B0F24;
    // 0x802B0DA0: nop

L_802B0DA4:
    // 0x802B0DA4: blez        $s0, L_802B0F24
    if (SIGNED(ctx->r16) <= 0) {
        // 0x802B0DA8: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0F24;
    }
    // 0x802B0DA8: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0DAC: beq         $at, $zero, L_802B0DCC
    if (ctx->r1 == 0) {
        // 0x802B0DB0: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B0DCC;
    }
    // 0x802B0DB0: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B0DB4: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0DB8: sra         $t7, $a1, 24
    ctx->r15 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0DBC: jal         0x802A4EC8
    // 0x802B0DC0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    func_802A4EC8_6B6578(rdram, ctx);
        goto after_0;
    // 0x802B0DC0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_0:
    // 0x802B0DC4: b           L_802B0F24
    // 0x802B0DC8: nop

        goto L_802B0F24;
    // 0x802B0DC8: nop

L_802B0DCC:
    // 0x802B0DCC: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0DD0: bne         $at, $zero, L_802B0F24
    if (ctx->r1 != 0) {
        // 0x802B0DD4: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B0F24;
    }
    // 0x802B0DD4: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B0DD8: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0DDC: sra         $t8, $a1, 24
    ctx->r24 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0DE0: jal         0x802A5008
    // 0x802B0DE4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_802A5008_6B66B8(rdram, ctx);
        goto after_1;
    // 0x802B0DE4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_1:
    // 0x802B0DE8: b           L_802B0F24
    // 0x802B0DEC: nop

        goto L_802B0F24;
    // 0x802B0DEC: nop

L_802B0DF0:
    // 0x802B0DF0: bgtz        $s0, L_802B0E08
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B0DF4: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0E08;
    }
    // 0x802B0DF4: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0DF8: jal         0x802A4E74
    // 0x802B0DFC: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_2;
    // 0x802B0DFC: nop

    after_2:
    // 0x802B0E00: b           L_802B0F24
    // 0x802B0E04: nop

        goto L_802B0F24;
    // 0x802B0E04: nop

L_802B0E08:
    // 0x802B0E08: bne         $at, $zero, L_802B0E2C
    if (ctx->r1 != 0) {
        // 0x802B0E0C: lh          $t0, 0x22($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X22);
            goto L_802B0E2C;
    }
    // 0x802B0E0C: lh          $t0, 0x22($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X22);
    // 0x802B0E10: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0E14: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0E18: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x802B0E1C: jal         0x802A5008
    // 0x802B0E20: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A5008_6B66B8(rdram, ctx);
        goto after_3;
    // 0x802B0E20: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_3:
    // 0x802B0E24: b           L_802B0F24
    // 0x802B0E28: nop

        goto L_802B0F24;
    // 0x802B0E28: nop

L_802B0E2C:
    // 0x802B0E2C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B0E30: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802B0E34: sh          $t0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r8;
    // 0x802B0E38: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B0E3C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B0E40: lb          $t1, 0x368($v0)
    ctx->r9 = MEM_B(ctx->r2, 0X368);
    // 0x802B0E44: beq         $s0, $t1, L_802B0F24
    if (ctx->r16 == ctx->r9) {
        // 0x802B0E48: nop
    
            goto L_802B0F24;
    }
    // 0x802B0E48: nop

    // 0x802B0E4C: sb          $s0, 0x368($v0)
    MEM_B(0X368, ctx->r2) = ctx->r16;
    // 0x802B0E50: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802B0E54: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x802B0E58: lhu         $t3, 0xA4($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XA4);
    // 0x802B0E5C: multu       $s0, $t3
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0E60: mflo        $t4
    ctx->r12 = lo;
    // 0x802B0E64: bgez        $t4, L_802B0E74
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802B0E68: sra         $t5, $t4, 4
        ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
            goto L_802B0E74;
    }
    // 0x802B0E68: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802B0E6C: addiu       $at, $t4, 0xF
    ctx->r1 = ADD32(ctx->r12, 0XF);
    // 0x802B0E70: sra         $t5, $at, 4
    ctx->r13 = S32(SIGNED(ctx->r1) >> 4);
L_802B0E74:
    // 0x802B0E74: jal         0x802B8B74
    // 0x802B0E78: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_4;
    // 0x802B0E78: sh          $t5, 0x31A($t6)
    MEM_H(0X31A, ctx->r14) = ctx->r13;
    after_4:
    // 0x802B0E7C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B0E80: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802B0E84: b           L_802B0F24
    // 0x802B0E88: sh          $v0, 0x2FA($t7)
    MEM_H(0X2FA, ctx->r15) = ctx->r2;
        goto L_802B0F24;
    // 0x802B0E88: sh          $v0, 0x2FA($t7)
    MEM_H(0X2FA, ctx->r15) = ctx->r2;
L_802B0E8C:
    // 0x802B0E8C: bgtz        $s0, L_802B0EA4
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B0E90: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B0EA4;
    }
    // 0x802B0E90: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0E94: jal         0x802A4E74
    // 0x802B0E98: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_5;
    // 0x802B0E98: nop

    after_5:
    // 0x802B0E9C: b           L_802B0F24
    // 0x802B0EA0: nop

        goto L_802B0F24;
    // 0x802B0EA0: nop

L_802B0EA4:
    // 0x802B0EA4: beq         $at, $zero, L_802B0EC8
    if (ctx->r1 == 0) {
        // 0x802B0EA8: lh          $t9, 0x22($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X22);
            goto L_802B0EC8;
    }
    // 0x802B0EA8: lh          $t9, 0x22($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X22);
    // 0x802B0EAC: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0EB0: sra         $t8, $a1, 24
    ctx->r24 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0EB4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802B0EB8: jal         0x802A4EC8
    // 0x802B0EBC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A4EC8_6B6578(rdram, ctx);
        goto after_6;
    // 0x802B0EBC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_6:
    // 0x802B0EC0: b           L_802B0F24
    // 0x802B0EC4: nop

        goto L_802B0F24;
    // 0x802B0EC4: nop

L_802B0EC8:
    // 0x802B0EC8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B0ECC: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802B0ED0: sh          $t9, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r25;
    // 0x802B0ED4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B0ED8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B0EDC: lb          $t0, 0x368($v0)
    ctx->r8 = MEM_B(ctx->r2, 0X368);
    // 0x802B0EE0: beq         $s0, $t0, L_802B0F24
    if (ctx->r16 == ctx->r8) {
        // 0x802B0EE4: nop
    
            goto L_802B0F24;
    }
    // 0x802B0EE4: nop

    // 0x802B0EE8: sb          $s0, 0x368($v0)
    MEM_B(0X368, ctx->r2) = ctx->r16;
    // 0x802B0EEC: lw          $t1, 0x5524($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5524);
    // 0x802B0EF0: lw          $t5, 0x0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X0);
    // 0x802B0EF4: lhu         $t2, 0xA4($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0XA4);
    // 0x802B0EF8: multu       $s0, $t2
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B0EFC: mflo        $t3
    ctx->r11 = lo;
    // 0x802B0F00: bgez        $t3, L_802B0F10
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802B0F04: sra         $t4, $t3, 4
        ctx->r12 = S32(SIGNED(ctx->r11) >> 4);
            goto L_802B0F10;
    }
    // 0x802B0F04: sra         $t4, $t3, 4
    ctx->r12 = S32(SIGNED(ctx->r11) >> 4);
    // 0x802B0F08: addiu       $at, $t3, 0xF
    ctx->r1 = ADD32(ctx->r11, 0XF);
    // 0x802B0F0C: sra         $t4, $at, 4
    ctx->r12 = S32(SIGNED(ctx->r1) >> 4);
L_802B0F10:
    // 0x802B0F10: jal         0x802B8B74
    // 0x802B0F14: sh          $t4, 0x31A($t5)
    MEM_H(0X31A, ctx->r13) = ctx->r12;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_7;
    // 0x802B0F14: sh          $t4, 0x31A($t5)
    MEM_H(0X31A, ctx->r13) = ctx->r12;
    after_7:
    // 0x802B0F18: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B0F1C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x802B0F20: sh          $v0, 0x2FA($t6)
    MEM_H(0X2FA, ctx->r14) = ctx->r2;
L_802B0F24:
    // 0x802B0F24: bgez        $s0, L_802B0F38
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B0F28: lh          $t7, 0x22($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X22);
            goto L_802B0F38;
    }
    // 0x802B0F28: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
    // 0x802B0F2C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B0F30: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802B0F34: sh          $t7, 0x2C($t8)
    MEM_H(0X2C, ctx->r24) = ctx->r15;
L_802B0F38:
    // 0x802B0F38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B0F3C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B0F40: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B0F44: jr          $ra
    // 0x802B0F48: nop

    return;
    // 0x802B0F48: nop

;}
RECOMP_FUNC void func_802B0F4C_6C25FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B0F4C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B0F50: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B0F54: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B0F58: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B0F5C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B0F60: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B0F64: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B0F68: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802B0F6C: sll         $s0, $a1, 16
    ctx->r16 = S32(ctx->r5 << 16);
    // 0x802B0F70: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x802B0F74: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B0F78: beq         $v0, $at, L_802B0FA4
    if (ctx->r2 == ctx->r1) {
        // 0x802B0F7C: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_802B0FA4;
    }
    // 0x802B0F7C: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x802B0F80: addiu       $at, $zero, 0x15
    ctx->r1 = ADD32(0, 0X15);
    // 0x802B0F84: beq         $v0, $at, L_802B0FA4
    if (ctx->r2 == ctx->r1) {
        // 0x802B0F88: addiu       $at, $zero, 0x16
        ctx->r1 = ADD32(0, 0X16);
            goto L_802B0FA4;
    }
    // 0x802B0F88: addiu       $at, $zero, 0x16
    ctx->r1 = ADD32(0, 0X16);
    // 0x802B0F8C: beq         $v0, $at, L_802B0FE8
    if (ctx->r2 == ctx->r1) {
        // 0x802B0F90: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_802B0FE8;
    }
    // 0x802B0F90: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x802B0F94: beq         $v0, $at, L_802B1038
    if (ctx->r2 == ctx->r1) {
        // 0x802B0F98: nop
    
            goto L_802B1038;
    }
    // 0x802B0F98: nop

    // 0x802B0F9C: b           L_802B1088
    // 0x802B0FA0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B0FA0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B0FA4:
    // 0x802B0FA4: blez        $s0, L_802B1084
    if (SIGNED(ctx->r16) <= 0) {
        // 0x802B0FA8: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1084;
    }
    // 0x802B0FA8: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0FAC: beq         $at, $zero, L_802B0FD0
    if (ctx->r1 == 0) {
        // 0x802B0FB0: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B0FD0;
    }
    // 0x802B0FB0: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B0FB4: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0FB8: sra         $t7, $a1, 24
    ctx->r15 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0FBC: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802B0FC0: jal         0x802A4D0C
    // 0x802B0FC4: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A4D0C_6B63BC(rdram, ctx);
        goto after_0;
    // 0x802B0FC4: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_0:
    // 0x802B0FC8: b           L_802B1088
    // 0x802B0FCC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B0FCC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B0FD0:
    // 0x802B0FD0: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B0FD4: sra         $t8, $a1, 24
    ctx->r24 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B0FD8: jal         0x802A4DF4
    // 0x802B0FDC: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_802A4DF4_6B64A4(rdram, ctx);
        goto after_1;
    // 0x802B0FDC: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_1:
    // 0x802B0FE0: b           L_802B1088
    // 0x802B0FE4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B0FE4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B0FE8:
    // 0x802B0FE8: bgtz        $s0, L_802B1000
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B0FEC: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1000;
    }
    // 0x802B0FEC: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B0FF0: jal         0x802A4CB8
    // 0x802B0FF4: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_2;
    // 0x802B0FF4: nop

    after_2:
    // 0x802B0FF8: b           L_802B1088
    // 0x802B0FFC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B0FFC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1000:
    // 0x802B1000: bne         $at, $zero, L_802B1024
    if (ctx->r1 != 0) {
        // 0x802B1004: lh          $t0, 0x22($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X22);
            goto L_802B1024;
    }
    // 0x802B1004: lh          $t0, 0x22($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X22);
    // 0x802B1008: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B100C: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1010: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x802B1014: jal         0x802A4DF4
    // 0x802B1018: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A4DF4_6B64A4(rdram, ctx);
        goto after_3;
    // 0x802B1018: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_3:
    // 0x802B101C: b           L_802B1088
    // 0x802B1020: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B1020: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1024:
    // 0x802B1024: sh          $t0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r8;
    // 0x802B1028: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B102C: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802B1030: b           L_802B1084
    // 0x802B1034: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
        goto L_802B1084;
    // 0x802B1034: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
L_802B1038:
    // 0x802B1038: bgtz        $s0, L_802B1050
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B103C: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1050;
    }
    // 0x802B103C: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1040: jal         0x802A4CB8
    // 0x802B1044: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_4;
    // 0x802B1044: nop

    after_4:
    // 0x802B1048: b           L_802B1088
    // 0x802B104C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B104C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1050:
    // 0x802B1050: beq         $at, $zero, L_802B1074
    if (ctx->r1 == 0) {
        // 0x802B1054: lh          $t3, 0x22($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X22);
            goto L_802B1074;
    }
    // 0x802B1054: lh          $t3, 0x22($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X22);
    // 0x802B1058: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B105C: sra         $t2, $a1, 24
    ctx->r10 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1060: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x802B1064: jal         0x802A4D0C
    // 0x802B1068: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A4D0C_6B63BC(rdram, ctx);
        goto after_5;
    // 0x802B1068: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_5:
    // 0x802B106C: b           L_802B1088
    // 0x802B1070: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1088;
    // 0x802B1070: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1074:
    // 0x802B1074: sh          $t3, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r11;
    // 0x802B1078: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B107C: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802B1080: sb          $s0, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r16;
L_802B1084:
    // 0x802B1084: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1088:
    // 0x802B1088: bne         $s0, $at, L_802B109C
    if (ctx->r16 != ctx->r1) {
        // 0x802B108C: lh          $t5, 0x22($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X22);
            goto L_802B109C;
    }
    // 0x802B108C: lh          $t5, 0x22($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X22);
    // 0x802B1090: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B1094: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B1098: sh          $t5, 0x2C($t6)
    MEM_H(0X2C, ctx->r14) = ctx->r13;
L_802B109C:
    // 0x802B109C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B10A0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B10A4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B10A8: jr          $ra
    // 0x802B10AC: nop

    return;
    // 0x802B10AC: nop

;}
RECOMP_FUNC void func_802B10B0_6C2760(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B10B0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B10B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B10B8: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B10BC: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B10C0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B10C4: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B10C8: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B10CC: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802B10D0: sll         $s0, $a1, 16
    ctx->r16 = S32(ctx->r5 << 16);
    // 0x802B10D4: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x802B10D8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B10DC: beq         $v0, $at, L_802B1108
    if (ctx->r2 == ctx->r1) {
        // 0x802B10E0: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_802B1108;
    }
    // 0x802B10E0: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x802B10E4: addiu       $at, $zero, 0xC9
    ctx->r1 = ADD32(0, 0XC9);
    // 0x802B10E8: beq         $v0, $at, L_802B1108
    if (ctx->r2 == ctx->r1) {
        // 0x802B10EC: addiu       $at, $zero, 0xCA
        ctx->r1 = ADD32(0, 0XCA);
            goto L_802B1108;
    }
    // 0x802B10EC: addiu       $at, $zero, 0xCA
    ctx->r1 = ADD32(0, 0XCA);
    // 0x802B10F0: beq         $v0, $at, L_802B114C
    if (ctx->r2 == ctx->r1) {
        // 0x802B10F4: addiu       $at, $zero, 0xCB
        ctx->r1 = ADD32(0, 0XCB);
            goto L_802B114C;
    }
    // 0x802B10F4: addiu       $at, $zero, 0xCB
    ctx->r1 = ADD32(0, 0XCB);
    // 0x802B10F8: beq         $v0, $at, L_802B119C
    if (ctx->r2 == ctx->r1) {
        // 0x802B10FC: nop
    
            goto L_802B119C;
    }
    // 0x802B10FC: nop

    // 0x802B1100: b           L_802B11E8
    // 0x802B1104: nop

        goto L_802B11E8;
    // 0x802B1104: nop

L_802B1108:
    // 0x802B1108: blez        $s0, L_802B11E8
    if (SIGNED(ctx->r16) <= 0) {
        // 0x802B110C: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B11E8;
    }
    // 0x802B110C: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1110: beq         $at, $zero, L_802B1134
    if (ctx->r1 == 0) {
        // 0x802B1114: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B1134;
    }
    // 0x802B1114: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B1118: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B111C: sra         $t7, $a1, 24
    ctx->r15 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1120: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802B1124: jal         0x802A55AC
    // 0x802B1128: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A55AC_6B6C5C(rdram, ctx);
        goto after_0;
    // 0x802B1128: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_0:
    // 0x802B112C: b           L_802B11E8
    // 0x802B1130: nop

        goto L_802B11E8;
    // 0x802B1130: nop

L_802B1134:
    // 0x802B1134: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1138: sra         $t8, $a1, 24
    ctx->r24 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B113C: jal         0x802A5694
    // 0x802B1140: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_802A5694_6B6D44(rdram, ctx);
        goto after_1;
    // 0x802B1140: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_1:
    // 0x802B1144: b           L_802B11E8
    // 0x802B1148: nop

        goto L_802B11E8;
    // 0x802B1148: nop

L_802B114C:
    // 0x802B114C: bgtz        $s0, L_802B1164
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B1150: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1164;
    }
    // 0x802B1150: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1154: jal         0x802A5558
    // 0x802B1158: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_2;
    // 0x802B1158: nop

    after_2:
    // 0x802B115C: b           L_802B11E8
    // 0x802B1160: nop

        goto L_802B11E8;
    // 0x802B1160: nop

L_802B1164:
    // 0x802B1164: bne         $at, $zero, L_802B1188
    if (ctx->r1 != 0) {
        // 0x802B1168: lh          $t0, 0x22($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X22);
            goto L_802B1188;
    }
    // 0x802B1168: lh          $t0, 0x22($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X22);
    // 0x802B116C: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1170: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1174: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x802B1178: jal         0x802A5694
    // 0x802B117C: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A5694_6B6D44(rdram, ctx);
        goto after_3;
    // 0x802B117C: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_3:
    // 0x802B1180: b           L_802B11E8
    // 0x802B1184: nop

        goto L_802B11E8;
    // 0x802B1184: nop

L_802B1188:
    // 0x802B1188: sh          $t0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r8;
    // 0x802B118C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1190: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802B1194: b           L_802B11E8
    // 0x802B1198: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
        goto L_802B11E8;
    // 0x802B1198: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
L_802B119C:
    // 0x802B119C: bgtz        $s0, L_802B11B4
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B11A0: slti        $at, $s0, 0xD
        ctx->r1 = SIGNED(ctx->r16) < 0XD ? 1 : 0;
            goto L_802B11B4;
    }
    // 0x802B11A0: slti        $at, $s0, 0xD
    ctx->r1 = SIGNED(ctx->r16) < 0XD ? 1 : 0;
    // 0x802B11A4: jal         0x802A5558
    // 0x802B11A8: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_4;
    // 0x802B11A8: nop

    after_4:
    // 0x802B11AC: b           L_802B11E8
    // 0x802B11B0: nop

        goto L_802B11E8;
    // 0x802B11B0: nop

L_802B11B4:
    // 0x802B11B4: beq         $at, $zero, L_802B11D8
    if (ctx->r1 == 0) {
        // 0x802B11B8: lh          $t3, 0x22($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X22);
            goto L_802B11D8;
    }
    // 0x802B11B8: lh          $t3, 0x22($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X22);
    // 0x802B11BC: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B11C0: sra         $t2, $a1, 24
    ctx->r10 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B11C4: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x802B11C8: jal         0x802A5694
    // 0x802B11CC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A5694_6B6D44(rdram, ctx);
        goto after_5;
    // 0x802B11CC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_5:
    // 0x802B11D0: b           L_802B11E8
    // 0x802B11D4: nop

        goto L_802B11E8;
    // 0x802B11D4: nop

L_802B11D8:
    // 0x802B11D8: sh          $t3, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r11;
    // 0x802B11DC: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B11E0: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802B11E4: sb          $s0, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r16;
L_802B11E8:
    // 0x802B11E8: bgez        $s0, L_802B11FC
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B11EC: lh          $t5, 0x22($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X22);
            goto L_802B11FC;
    }
    // 0x802B11EC: lh          $t5, 0x22($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X22);
    // 0x802B11F0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B11F4: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B11F8: sh          $t5, 0x2C($t6)
    MEM_H(0X2C, ctx->r14) = ctx->r13;
L_802B11FC:
    // 0x802B11FC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B1200: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B1204: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B1208: jr          $ra
    // 0x802B120C: nop

    return;
    // 0x802B120C: nop

;}
RECOMP_FUNC void func_802B1210_6C28C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1210: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1214: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B1218: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B121C: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
    // 0x802B1220: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B1224: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802B1228: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B122C: lbu         $t7, 0x162($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X162);
    // 0x802B1230: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x802B1234: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802B1238: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802B123C: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x802B1240: bne         $t0, $t8, L_802B126C
    if (ctx->r8 != ctx->r24) {
        // 0x802B1244: or          $a3, $t6, $zero
        ctx->r7 = ctx->r14 | 0;
            goto L_802B126C;
    }
    // 0x802B1244: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802B1248: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B124C: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802B1250: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B1254: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802B1258: blez        $v1, L_802B12A0
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802B125C: addiu       $t9, $v1, -0x1
        ctx->r25 = ADD32(ctx->r3, -0X1);
            goto L_802B12A0;
    }
    // 0x802B125C: addiu       $t9, $v1, -0x1
    ctx->r25 = ADD32(ctx->r3, -0X1);
    // 0x802B1260: sh          $t9, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r25;
    // 0x802B1264: b           L_802B12A0
    // 0x802B1268: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
        goto L_802B12A0;
    // 0x802B1268: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
L_802B126C:
    // 0x802B126C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B1270: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x802B1274: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B1278: addiu       $t2, $zero, 0x19
    ctx->r10 = ADD32(0, 0X19);
    // 0x802B127C: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802B1280: slti        $at, $v1, 0x1A
    ctx->r1 = SIGNED(ctx->r3) < 0X1A ? 1 : 0;
    // 0x802B1284: bnel        $at, $zero, L_802B129C
    if (ctx->r1 != 0) {
        // 0x802B1288: sh          $t2, 0x30C($v0)
        MEM_H(0X30C, ctx->r2) = ctx->r10;
            goto L_802B129C;
    }
    goto skip_0;
    // 0x802B1288: sh          $t2, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r10;
    skip_0:
    // 0x802B128C: sh          $v1, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r3;
    // 0x802B1290: b           L_802B12A0
    // 0x802B1294: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
        goto L_802B12A0;
    // 0x802B1294: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
    // 0x802B1298: sh          $t2, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r10;
L_802B129C:
    // 0x802B129C: lw          $a2, 0x0($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X0);
L_802B12A0:
    // 0x802B12A0: lhu         $v0, 0x0($a2)
    ctx->r2 = MEM_HU(ctx->r6, 0X0);
    // 0x802B12A4: addiu       $at, $zero, 0x29
    ctx->r1 = ADD32(0, 0X29);
    // 0x802B12A8: beql        $v0, $t0, L_802B12CC
    if (ctx->r2 == ctx->r8) {
        // 0x802B12AC: sh          $a3, 0x2C($a2)
        MEM_H(0X2C, ctx->r6) = ctx->r7;
            goto L_802B12CC;
    }
    goto skip_1;
    // 0x802B12AC: sh          $a3, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r7;
    skip_1:
    // 0x802B12B0: beq         $v0, $at, L_802B12C8
    if (ctx->r2 == ctx->r1) {
        // 0x802B12B4: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_802B12C8;
    }
    // 0x802B12B4: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x802B12B8: beql        $v0, $at, L_802B1348
    if (ctx->r2 == ctx->r1) {
        // 0x802B12BC: sh          $a3, 0x2C($a2)
        MEM_H(0X2C, ctx->r6) = ctx->r7;
            goto L_802B1348;
    }
    goto skip_2;
    // 0x802B12BC: sh          $a3, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r7;
    skip_2:
    // 0x802B12C0: b           L_802B1354
    // 0x802B12C4: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
        goto L_802B1354;
    // 0x802B12C4: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
L_802B12C8:
    // 0x802B12C8: sh          $a3, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r7;
L_802B12CC:
    // 0x802B12CC: lw          $t3, 0x0($a0)
    ctx->r11 = MEM_W(ctx->r4, 0X0);
    // 0x802B12D0: sh          $a3, 0x302($t3)
    MEM_H(0X302, ctx->r11) = ctx->r7;
    // 0x802B12D4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B12D8: lh          $t4, 0x30C($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X30C);
    // 0x802B12DC: bnel        $t4, $zero, L_802B1354
    if (ctx->r12 != 0) {
        // 0x802B12E0: lh          $t3, 0x1E($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X1E);
            goto L_802B1354;
    }
    goto skip_3;
    // 0x802B12E0: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
    skip_3:
    // 0x802B12E4: lbu         $t5, 0x367($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X367);
    // 0x802B12E8: lh          $t6, 0x1E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X1E);
    // 0x802B12EC: bgtzl       $t5, L_802B1354
    if (SIGNED(ctx->r13) > 0) {
        // 0x802B12F0: lh          $t3, 0x1E($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X1E);
            goto L_802B1354;
    }
    goto skip_4;
    // 0x802B12F0: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
    skip_4:
    // 0x802B12F4: blez        $t6, L_802B1350
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802B12F8: sra         $v1, $t6, 2
        ctx->r3 = S32(SIGNED(ctx->r14) >> 2);
            goto L_802B1350;
    }
    // 0x802B12F8: sra         $v1, $t6, 2
    ctx->r3 = S32(SIGNED(ctx->r14) >> 2);
    // 0x802B12FC: slti        $at, $v1, 0x3
    ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
    // 0x802B1300: beq         $at, $zero, L_802B1310
    if (ctx->r1 == 0) {
        // 0x802B1304: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_802B1310;
    }
    // 0x802B1304: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B1308: b           L_802B1314
    // 0x802B130C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
        goto L_802B1314;
    // 0x802B130C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802B1310:
    // 0x802B1310: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
L_802B1314:
    // 0x802B1314: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x802B1318: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802B131C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802B1320: jal         0x802A5778
    // 0x802B1324: sh          $a3, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r7;
    func_802A5778_6B6E28(rdram, ctx);
        goto after_0;
    // 0x802B1324: sh          $a3, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B1328: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B132C: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x802B1330: lw          $t9, 0x0($t1)
    ctx->r25 = MEM_W(ctx->r9, 0X0);
    // 0x802B1334: lh          $a3, 0x1A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X1A);
    // 0x802B1338: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x802B133C: b           L_802B1350
    // 0x802B1340: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
        goto L_802B1350;
    // 0x802B1340: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
    // 0x802B1344: sh          $a3, 0x2C($a2)
    MEM_H(0X2C, ctx->r6) = ctx->r7;
L_802B1348:
    // 0x802B1348: lw          $t2, 0x0($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X0);
    // 0x802B134C: sh          $a3, 0x302($t2)
    MEM_H(0X302, ctx->r10) = ctx->r7;
L_802B1350:
    // 0x802B1350: lh          $t3, 0x1E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1E);
L_802B1354:
    // 0x802B1354: bgezl       $t3, L_802B1368
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802B1358: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B1368;
    }
    goto skip_5;
    // 0x802B1358: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x802B135C: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802B1360: sh          $a3, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r7;
    // 0x802B1364: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B1368:
    // 0x802B1368: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B136C: jr          $ra
    // 0x802B1370: nop

    return;
    // 0x802B1370: nop

;}
RECOMP_FUNC void func_802B1374_6C2A24(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1374: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802B1378: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B137C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B1380: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B1384: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B1388: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x802B138C: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x802B1390: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x802B1394: lh          $t8, 0x30C($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X30C);
    // 0x802B1398: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B139C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B13A0: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x802B13A4: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x802B13A8: sh          $t2, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r10;
    // 0x802B13AC: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x802B13B0: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802B13B4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B13B8: lhu         $v1, 0x0($t3)
    ctx->r3 = MEM_HU(ctx->r11, 0X0);
    // 0x802B13BC: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B13C0: beq         $v1, $at, L_802B162C
    if (ctx->r3 == ctx->r1) {
        // 0x802B13C4: addiu       $at, $zero, 0x3D
        ctx->r1 = ADD32(0, 0X3D);
            goto L_802B162C;
    }
    // 0x802B13C4: addiu       $at, $zero, 0x3D
    ctx->r1 = ADD32(0, 0X3D);
    // 0x802B13C8: beq         $v1, $at, L_802B162C
    if (ctx->r3 == ctx->r1) {
        // 0x802B13CC: addiu       $at, $zero, 0x3E
        ctx->r1 = ADD32(0, 0X3E);
            goto L_802B162C;
    }
    // 0x802B13CC: addiu       $at, $zero, 0x3E
    ctx->r1 = ADD32(0, 0X3E);
    // 0x802B13D0: bne         $v1, $at, L_802B162C
    if (ctx->r3 != ctx->r1) {
        // 0x802B13D4: lh          $t4, 0x2E($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X2E);
            goto L_802B162C;
    }
    // 0x802B13D4: lh          $t4, 0x2E($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X2E);
    // 0x802B13D8: bgtz        $t4, L_802B140C
    if (SIGNED(ctx->r12) > 0) {
        // 0x802B13DC: lh          $t6, 0x2E($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X2E);
            goto L_802B140C;
    }
    // 0x802B13DC: lh          $t6, 0x2E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2E);
    // 0x802B13E0: lw          $t5, 0x0($t1)
    ctx->r13 = MEM_W(ctx->r9, 0X0);
    // 0x802B13E4: sh          $zero, 0x30C($t5)
    MEM_H(0X30C, ctx->r13) = 0;
    // 0x802B13E8: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B13EC: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802B13F0: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x802B13F4: blez        $v1, L_802B1404
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802B13F8: nop
    
            goto L_802B1404;
    }
    // 0x802B13F8: nop

    // 0x802B13FC: b           L_802B1494
    // 0x802B1400: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
        goto L_802B1494;
    // 0x802B1400: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
L_802B1404:
    // 0x802B1404: b           L_802B1494
    // 0x802B1408: sh          $zero, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = 0;
        goto L_802B1494;
    // 0x802B1408: sh          $zero, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = 0;
L_802B140C:
    // 0x802B140C: slti        $at, $t6, 0xE
    ctx->r1 = SIGNED(ctx->r14) < 0XE ? 1 : 0;
    // 0x802B1410: beq         $at, $zero, L_802B1458
    if (ctx->r1 == 0) {
        // 0x802B1414: lh          $t2, 0x2E($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X2E);
            goto L_802B1458;
    }
    // 0x802B1414: lh          $t2, 0x2E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1418: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x802B141C: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802B1420: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802B1424: sll         $t7, $t7, 1
    ctx->r15 = S32(ctx->r15 << 1);
    // 0x802B1428: sh          $t7, 0x30C($t8)
    MEM_H(0X30C, ctx->r24) = ctx->r15;
    // 0x802B142C: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B1430: addiu       $t9, $zero, 0xA
    ctx->r25 = ADD32(0, 0XA);
    // 0x802B1434: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802B1438: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x802B143C: slti        $at, $v1, 0xA
    ctx->r1 = SIGNED(ctx->r3) < 0XA ? 1 : 0;
    // 0x802B1440: beq         $at, $zero, L_802B1450
    if (ctx->r1 == 0) {
        // 0x802B1444: nop
    
            goto L_802B1450;
    }
    // 0x802B1444: nop

    // 0x802B1448: b           L_802B1494
    // 0x802B144C: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
        goto L_802B1494;
    // 0x802B144C: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
L_802B1450:
    // 0x802B1450: b           L_802B1494
    // 0x802B1454: sh          $t9, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r25;
        goto L_802B1494;
    // 0x802B1454: sh          $t9, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r25;
L_802B1458:
    // 0x802B1458: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802B145C: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x802B1460: subu        $t3, $t3, $t2
    ctx->r11 = SUB32(ctx->r11, ctx->r10);
    // 0x802B1464: sll         $t3, $t3, 1
    ctx->r11 = S32(ctx->r11 << 1);
    // 0x802B1468: sh          $t3, 0x30C($t4)
    MEM_H(0X30C, ctx->r12) = ctx->r11;
    // 0x802B146C: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B1470: addiu       $t5, $zero, 0x10
    ctx->r13 = ADD32(0, 0X10);
    // 0x802B1474: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802B1478: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x802B147C: slti        $at, $v1, 0x10
    ctx->r1 = SIGNED(ctx->r3) < 0X10 ? 1 : 0;
    // 0x802B1480: beql        $at, $zero, L_802B1494
    if (ctx->r1 == 0) {
        // 0x802B1484: sh          $t5, 0x30E($v0)
        MEM_H(0X30E, ctx->r2) = ctx->r13;
            goto L_802B1494;
    }
    goto skip_0;
    // 0x802B1484: sh          $t5, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r13;
    skip_0:
    // 0x802B1488: b           L_802B1494
    // 0x802B148C: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
        goto L_802B1494;
    // 0x802B148C: sh          $v1, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r3;
    // 0x802B1490: sh          $t5, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r13;
L_802B1494:
    // 0x802B1494: lh          $t6, 0x2A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2A);
    // 0x802B1498: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802B149C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B14A0: sh          $t6, 0x2C($t7)
    MEM_H(0X2C, ctx->r15) = ctx->r14;
    // 0x802B14A4: lh          $t8, 0x2E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X2E);
    // 0x802B14A8: blez        $t8, L_802B1520
    if (SIGNED(ctx->r24) <= 0) {
        // 0x802B14AC: nop
    
            goto L_802B1520;
    }
    // 0x802B14AC: nop

    // 0x802B14B0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B14B4: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x802B14B8: sll         $v0, $t8, 4
    ctx->r2 = S32(ctx->r24 << 4);
    // 0x802B14BC: lh          $t2, 0x2C($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X2C);
    // 0x802B14C0: lw          $t9, 0x1C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X1C);
    // 0x802B14C4: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x802B14C8: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x802B14CC: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802B14D0: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x802B14D4: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802B14D8: multu       $v0, $t6
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B14DC: mflo        $t7
    ctx->r15 = lo;
    // 0x802B14E0: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x802B14E4: sw          $t8, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r24;
    // 0x802B14E8: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B14EC: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x802B14F0: lh          $t3, 0x2C($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2C);
    // 0x802B14F4: lw          $t2, 0x20($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X20);
    // 0x802B14F8: addiu       $t4, $t3, 0x40
    ctx->r12 = ADD32(ctx->r11, 0X40);
    // 0x802B14FC: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x802B1500: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802B1504: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x802B1508: lh          $t9, 0x2C78($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2C78);
    // 0x802B150C: sra         $t7, $t9, 7
    ctx->r15 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802B1510: multu       $v0, $t7
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B1514: mflo        $t8
    ctx->r24 = lo;
    // 0x802B1518: addu        $t3, $t2, $t8
    ctx->r11 = ADD32(ctx->r10, ctx->r24);
    // 0x802B151C: sw          $t3, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r11;
L_802B1520:
    // 0x802B1520: bgezl       $a2, L_802B1590
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802B1524: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_802B1590;
    }
    goto skip_1;
    // 0x802B1524: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_1:
    // 0x802B1528: bne         $a2, $at, L_802B1538
    if (ctx->r6 != ctx->r1) {
        // 0x802B152C: negu        $a3, $a2
        ctx->r7 = SUB32(0, ctx->r6);
            goto L_802B1538;
    }
    // 0x802B152C: negu        $a3, $a2
    ctx->r7 = SUB32(0, ctx->r6);
    // 0x802B1530: b           L_802B1540
    // 0x802B1534: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
        goto L_802B1540;
    // 0x802B1534: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
L_802B1538:
    // 0x802B1538: sll         $t4, $a3, 16
    ctx->r12 = S32(ctx->r7 << 16);
    // 0x802B153C: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
L_802B1540:
    // 0x802B1540: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1544: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802B1548: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802B154C: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    // 0x802B1550: jal         0x80310EE4
    // 0x802B1554: sh          $a3, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r7;
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x802B1554: sh          $a3, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B1558: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B155C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1560: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1564: lh          $a3, 0x1C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X1C);
    // 0x802B1568: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B156C: lh          $t9, 0xC($v1)
    ctx->r25 = MEM_H(ctx->r3, 0XC);
    // 0x802B1570: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1574: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B1578: subu        $t7, $t6, $t9
    ctx->r15 = SUB32(ctx->r14, ctx->r25);
    // 0x802B157C: addu        $a3, $t7, $a3
    ctx->r7 = ADD32(ctx->r15, ctx->r7);
    // 0x802B1580: sll         $t2, $a3, 16
    ctx->r10 = S32(ctx->r7 << 16);
    // 0x802B1584: b           L_802B15A0
    // 0x802B1588: sra         $a3, $t2, 16
    ctx->r7 = S32(SIGNED(ctx->r10) >> 16);
        goto L_802B15A0;
    // 0x802B1588: sra         $a3, $t2, 16
    ctx->r7 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802B158C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_802B1590:
    // 0x802B1590: lh          $t3, 0xC($v1)
    ctx->r11 = MEM_H(ctx->r3, 0XC);
    // 0x802B1594: subu        $a3, $a2, $t3
    ctx->r7 = SUB32(ctx->r6, ctx->r11);
    // 0x802B1598: sll         $t4, $a3, 16
    ctx->r12 = S32(ctx->r7 << 16);
    // 0x802B159C: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
L_802B15A0:
    // 0x802B15A0: slti        $at, $a3, 0x51
    ctx->r1 = SIGNED(ctx->r7) < 0X51 ? 1 : 0;
    // 0x802B15A4: bnel        $at, $zero, L_802B15B4
    if (ctx->r1 != 0) {
        // 0x802B15A8: slti        $at, $a3, -0x50
        ctx->r1 = SIGNED(ctx->r7) < -0X50 ? 1 : 0;
            goto L_802B15B4;
    }
    goto skip_2;
    // 0x802B15A8: slti        $at, $a3, -0x50
    ctx->r1 = SIGNED(ctx->r7) < -0X50 ? 1 : 0;
    skip_2:
    // 0x802B15AC: addiu       $a3, $zero, 0x50
    ctx->r7 = ADD32(0, 0X50);
    // 0x802B15B0: slti        $at, $a3, -0x50
    ctx->r1 = SIGNED(ctx->r7) < -0X50 ? 1 : 0;
L_802B15B4:
    // 0x802B15B4: beql        $at, $zero, L_802B15C4
    if (ctx->r1 == 0) {
        // 0x802B15B8: sh          $a3, 0x28($v1)
        MEM_H(0X28, ctx->r3) = ctx->r7;
            goto L_802B15C4;
    }
    goto skip_3;
    // 0x802B15B8: sh          $a3, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r7;
    skip_3:
    // 0x802B15BC: addiu       $a3, $zero, -0x50
    ctx->r7 = ADD32(0, -0X50);
    // 0x802B15C0: sh          $a3, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r7;
L_802B15C4:
    // 0x802B15C4: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B15C8: lw          $t6, 0x24($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X24);
    // 0x802B15CC: lh          $t2, 0x28($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X28);
    // 0x802B15D0: sll         $t9, $t6, 3
    ctx->r25 = S32(ctx->r14 << 3);
    // 0x802B15D4: subu        $t9, $t9, $t6
    ctx->r25 = SUB32(ctx->r25, ctx->r14);
    // 0x802B15D8: sra         $t7, $t9, 3
    ctx->r15 = S32(SIGNED(ctx->r25) >> 3);
    // 0x802B15DC: sll         $t8, $t2, 9
    ctx->r24 = S32(ctx->r10 << 9);
    // 0x802B15E0: addu        $t3, $t7, $t8
    ctx->r11 = ADD32(ctx->r15, ctx->r24);
    // 0x802B15E4: sw          $t3, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r11;
    // 0x802B15E8: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802B15EC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B15F0: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x802B15F4: lhu         $t5, 0x31C($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0X31C);
    // 0x802B15F8: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B15FC: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x802B1600: addu        $t8, $t5, $t9
    ctx->r24 = ADD32(ctx->r13, ctx->r25);
    // 0x802B1604: andi        $t3, $t8, 0xFF
    ctx->r11 = ctx->r24 & 0XFF;
    // 0x802B1608: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x802B160C: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x802B1610: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802B1614: lh          $t6, 0x2C78($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C78);
    // 0x802B1618: lw          $t2, 0x24($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X24);
    // 0x802B161C: sra         $t5, $t6, 7
    ctx->r13 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802B1620: sll         $t9, $t5, 6
    ctx->r25 = S32(ctx->r13 << 6);
    // 0x802B1624: addu        $t7, $t2, $t9
    ctx->r15 = ADD32(ctx->r10, ctx->r25);
    // 0x802B1628: sw          $t7, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r15;
L_802B162C:
    // 0x802B162C: lh          $t8, 0x2E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1630: lh          $t3, 0x2A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X2A);
    // 0x802B1634: bgezl       $t8, L_802B1648
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802B1638: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B1648;
    }
    goto skip_4;
    // 0x802B1638: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802B163C: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x802B1640: sh          $t3, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r11;
    // 0x802B1644: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B1648:
    // 0x802B1648: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802B164C: jr          $ra
    // 0x802B1650: nop

    return;
    // 0x802B1650: nop

;}
RECOMP_FUNC void func_802B1654_6C2D04(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1654: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B1658: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B165C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1660: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1664: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B1668: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B166C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B1670: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802B1674: lhu         $t8, 0x0($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X0);
    // 0x802B1678: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802B167C: addiu       $at, $zero, 0x51
    ctx->r1 = ADD32(0, 0X51);
    // 0x802B1680: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B1684: bne         $t8, $at, L_802B1908
    if (ctx->r24 != ctx->r1) {
        // 0x802B1688: lh          $a1, 0x22($sp)
        ctx->r5 = MEM_H(ctx->r29, 0X22);
            goto L_802B1908;
    }
    // 0x802B1688: lh          $a1, 0x22($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X22);
    // 0x802B168C: lh          $a0, 0x2C($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2C);
    // 0x802B1690: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B1694: subu        $v0, $a1, $a0
    ctx->r2 = SUB32(ctx->r5, ctx->r4);
    // 0x802B1698: andi        $t9, $v0, 0xFF
    ctx->r25 = ctx->r2 & 0XFF;
    // 0x802B169C: sll         $t1, $t9, 16
    ctx->r9 = S32(ctx->r25 << 16);
    // 0x802B16A0: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802B16A4: slti        $at, $t2, 0x81
    ctx->r1 = SIGNED(ctx->r10) < 0X81 ? 1 : 0;
    // 0x802B16A8: bne         $at, $zero, L_802B16BC
    if (ctx->r1 != 0) {
        // 0x802B16AC: or          $v0, $t2, $zero
        ctx->r2 = ctx->r10 | 0;
            goto L_802B16BC;
    }
    // 0x802B16AC: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    // 0x802B16B0: addiu       $v0, $t2, -0x100
    ctx->r2 = ADD32(ctx->r10, -0X100);
    // 0x802B16B4: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802B16B8: sra         $v0, $t3, 16
    ctx->r2 = S32(SIGNED(ctx->r11) >> 16);
L_802B16BC:
    // 0x802B16BC: slti        $at, $v0, 0x5
    ctx->r1 = SIGNED(ctx->r2) < 0X5 ? 1 : 0;
    // 0x802B16C0: bnel        $at, $zero, L_802B16D0
    if (ctx->r1 != 0) {
        // 0x802B16C4: slti        $at, $v0, -0x4
        ctx->r1 = SIGNED(ctx->r2) < -0X4 ? 1 : 0;
            goto L_802B16D0;
    }
    goto skip_0;
    // 0x802B16C4: slti        $at, $v0, -0x4
    ctx->r1 = SIGNED(ctx->r2) < -0X4 ? 1 : 0;
    skip_0:
    // 0x802B16C8: addiu       $v0, $zero, 0x4
    ctx->r2 = ADD32(0, 0X4);
    // 0x802B16CC: slti        $at, $v0, -0x4
    ctx->r1 = SIGNED(ctx->r2) < -0X4 ? 1 : 0;
L_802B16D0:
    // 0x802B16D0: beql        $at, $zero, L_802B16E0
    if (ctx->r1 == 0) {
        // 0x802B16D4: addu        $t5, $a0, $v0
        ctx->r13 = ADD32(ctx->r4, ctx->r2);
            goto L_802B16E0;
    }
    goto skip_1;
    // 0x802B16D4: addu        $t5, $a0, $v0
    ctx->r13 = ADD32(ctx->r4, ctx->r2);
    skip_1:
    // 0x802B16D8: addiu       $v0, $zero, -0x4
    ctx->r2 = ADD32(0, -0X4);
    // 0x802B16DC: addu        $t5, $a0, $v0
    ctx->r13 = ADD32(ctx->r4, ctx->r2);
L_802B16E0:
    // 0x802B16E0: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802B16E4: sh          $t6, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r14;
    // 0x802B16E8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x802B16EC: bgez        $a2, L_802B1754
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802B16F0: sh          $v0, 0x306($t7)
        MEM_H(0X306, ctx->r15) = ctx->r2;
            goto L_802B1754;
    }
    // 0x802B16F0: sh          $v0, 0x306($t7)
    MEM_H(0X306, ctx->r15) = ctx->r2;
    // 0x802B16F4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B16F8: bne         $a2, $at, L_802B1708
    if (ctx->r6 != ctx->r1) {
        // 0x802B16FC: negu        $a3, $a2
        ctx->r7 = SUB32(0, ctx->r6);
            goto L_802B1708;
    }
    // 0x802B16FC: negu        $a3, $a2
    ctx->r7 = SUB32(0, ctx->r6);
    // 0x802B1700: b           L_802B1710
    // 0x802B1704: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
        goto L_802B1710;
    // 0x802B1704: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
L_802B1708:
    // 0x802B1708: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802B170C: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
L_802B1710:
    // 0x802B1710: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1714: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802B1718: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802B171C: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    // 0x802B1720: jal         0x80310EE4
    // 0x802B1724: sh          $a3, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r7;
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x802B1724: sh          $a3, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B1728: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B172C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1730: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x802B1734: lh          $a3, 0x18($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X18);
    // 0x802B1738: sra         $t1, $v0, 16
    ctx->r9 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B173C: lh          $t3, 0xC($t2)
    ctx->r11 = MEM_H(ctx->r10, 0XC);
    // 0x802B1740: subu        $t4, $t1, $t3
    ctx->r12 = SUB32(ctx->r9, ctx->r11);
    // 0x802B1744: addu        $a3, $t4, $a3
    ctx->r7 = ADD32(ctx->r12, ctx->r7);
    // 0x802B1748: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x802B174C: b           L_802B1768
    // 0x802B1750: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
        goto L_802B1768;
    // 0x802B1750: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
L_802B1754:
    // 0x802B1754: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802B1758: lh          $t8, 0xC($t7)
    ctx->r24 = MEM_H(ctx->r15, 0XC);
    // 0x802B175C: subu        $a3, $a2, $t8
    ctx->r7 = SUB32(ctx->r6, ctx->r24);
    // 0x802B1760: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x802B1764: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
L_802B1768:
    // 0x802B1768: sra         $t4, $a3, 2
    ctx->r12 = S32(SIGNED(ctx->r7) >> 2);
    // 0x802B176C: jal         0x802B2580
    // 0x802B1770: sh          $t4, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r12;
    get_distance_from_ground(rdram, ctx);
        goto after_1;
    // 0x802B1770: sh          $t4, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r12;
    after_1:
    // 0x802B1774: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1778: slti        $at, $v0, 0x941
    ctx->r1 = SIGNED(ctx->r2) < 0X941 ? 1 : 0;
    // 0x802B177C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1780: bne         $at, $zero, L_802B1794
    if (ctx->r1 != 0) {
        // 0x802B1784: lh          $a3, 0x18($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X18);
            goto L_802B1794;
    }
    // 0x802B1784: lh          $a3, 0x18($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X18);
    // 0x802B1788: blezl       $a3, L_802B1798
    if (SIGNED(ctx->r7) <= 0) {
        // 0x802B178C: slti        $at, $a3, 0x29
        ctx->r1 = SIGNED(ctx->r7) < 0X29 ? 1 : 0;
            goto L_802B1798;
    }
    goto skip_2;
    // 0x802B178C: slti        $at, $a3, 0x29
    ctx->r1 = SIGNED(ctx->r7) < 0X29 ? 1 : 0;
    skip_2:
    // 0x802B1790: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
L_802B1794:
    // 0x802B1794: slti        $at, $a3, 0x29
    ctx->r1 = SIGNED(ctx->r7) < 0X29 ? 1 : 0;
L_802B1798:
    // 0x802B1798: bnel        $at, $zero, L_802B17A8
    if (ctx->r1 != 0) {
        // 0x802B179C: slti        $at, $a3, -0x28
        ctx->r1 = SIGNED(ctx->r7) < -0X28 ? 1 : 0;
            goto L_802B17A8;
    }
    goto skip_3;
    // 0x802B179C: slti        $at, $a3, -0x28
    ctx->r1 = SIGNED(ctx->r7) < -0X28 ? 1 : 0;
    skip_3:
    // 0x802B17A0: addiu       $a3, $zero, 0x28
    ctx->r7 = ADD32(0, 0X28);
    // 0x802B17A4: slti        $at, $a3, -0x28
    ctx->r1 = SIGNED(ctx->r7) < -0X28 ? 1 : 0;
L_802B17A8:
    // 0x802B17A8: beql        $at, $zero, L_802B17B8
    if (ctx->r1 == 0) {
        // 0x802B17AC: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_802B17B8;
    }
    goto skip_4;
    // 0x802B17AC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_4:
    // 0x802B17B0: addiu       $a3, $zero, -0x28
    ctx->r7 = ADD32(0, -0X28);
    // 0x802B17B4: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_802B17B8:
    // 0x802B17B8: lh          $a1, 0x28($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X28);
    // 0x802B17BC: subu        $v0, $a3, $a1
    ctx->r2 = SUB32(ctx->r7, ctx->r5);
    // 0x802B17C0: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x802B17C4: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B17C8: blez        $t6, L_802B17F0
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802B17CC: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_802B17F0;
    }
    // 0x802B17CC: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802B17D0: slti        $at, $t6, 0xC
    ctx->r1 = SIGNED(ctx->r14) < 0XC ? 1 : 0;
    // 0x802B17D4: beq         $at, $zero, L_802B17E4
    if (ctx->r1 == 0) {
        // 0x802B17D8: addiu       $a0, $zero, 0xC
        ctx->r4 = ADD32(0, 0XC);
            goto L_802B17E4;
    }
    // 0x802B17D8: addiu       $a0, $zero, 0xC
    ctx->r4 = ADD32(0, 0XC);
    // 0x802B17DC: b           L_802B17E4
    // 0x802B17E0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
        goto L_802B17E4;
    // 0x802B17E0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
L_802B17E4:
    // 0x802B17E4: addu        $t7, $a1, $a0
    ctx->r15 = ADD32(ctx->r5, ctx->r4);
    // 0x802B17E8: b           L_802B180C
    // 0x802B17EC: sh          $t7, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r15;
        goto L_802B180C;
    // 0x802B17EC: sh          $t7, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r15;
L_802B17F0:
    // 0x802B17F0: slti        $at, $v0, -0xB
    ctx->r1 = SIGNED(ctx->r2) < -0XB ? 1 : 0;
    // 0x802B17F4: bne         $at, $zero, L_802B1804
    if (ctx->r1 != 0) {
        // 0x802B17F8: addiu       $a0, $zero, -0xC
        ctx->r4 = ADD32(0, -0XC);
            goto L_802B1804;
    }
    // 0x802B17F8: addiu       $a0, $zero, -0xC
    ctx->r4 = ADD32(0, -0XC);
    // 0x802B17FC: b           L_802B1804
    // 0x802B1800: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
        goto L_802B1804;
    // 0x802B1800: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_802B1804:
    // 0x802B1804: addu        $t8, $a1, $a0
    ctx->r24 = ADD32(ctx->r5, ctx->r4);
    // 0x802B1808: sh          $t8, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r24;
L_802B180C:
    // 0x802B180C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1810: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
    // 0x802B1814: slti        $at, $v0, 0x15
    ctx->r1 = SIGNED(ctx->r2) < 0X15 ? 1 : 0;
    // 0x802B1818: bne         $at, $zero, L_802B1830
    if (ctx->r1 != 0) {
        // 0x802B181C: addiu       $t9, $v0, -0x1
        ctx->r25 = ADD32(ctx->r2, -0X1);
            goto L_802B1830;
    }
    // 0x802B181C: addiu       $t9, $v0, -0x1
    ctx->r25 = ADD32(ctx->r2, -0X1);
    // 0x802B1820: sh          $t9, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r25;
    // 0x802B1824: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1828: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B182C: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
L_802B1830:
    // 0x802B1830: slti        $at, $v0, -0x14
    ctx->r1 = SIGNED(ctx->r2) < -0X14 ? 1 : 0;
    // 0x802B1834: beq         $at, $zero, L_802B184C
    if (ctx->r1 == 0) {
        // 0x802B1838: addiu       $t2, $v0, 0x1
        ctx->r10 = ADD32(ctx->r2, 0X1);
            goto L_802B184C;
    }
    // 0x802B1838: addiu       $t2, $v0, 0x1
    ctx->r10 = ADD32(ctx->r2, 0X1);
    // 0x802B183C: sh          $t2, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r10;
    // 0x802B1840: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1844: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B1848: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
L_802B184C:
    // 0x802B184C: slti        $at, $v0, 0x11
    ctx->r1 = SIGNED(ctx->r2) < 0X11 ? 1 : 0;
    // 0x802B1850: bne         $at, $zero, L_802B1868
    if (ctx->r1 != 0) {
        // 0x802B1854: addiu       $t1, $v0, -0x1
        ctx->r9 = ADD32(ctx->r2, -0X1);
            goto L_802B1868;
    }
    // 0x802B1854: addiu       $t1, $v0, -0x1
    ctx->r9 = ADD32(ctx->r2, -0X1);
    // 0x802B1858: sh          $t1, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r9;
    // 0x802B185C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1860: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B1864: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
L_802B1868:
    // 0x802B1868: slti        $at, $v0, -0x10
    ctx->r1 = SIGNED(ctx->r2) < -0X10 ? 1 : 0;
    // 0x802B186C: beq         $at, $zero, L_802B1884
    if (ctx->r1 == 0) {
        // 0x802B1870: addiu       $t3, $v0, 0x1
        ctx->r11 = ADD32(ctx->r2, 0X1);
            goto L_802B1884;
    }
    // 0x802B1870: addiu       $t3, $v0, 0x1
    ctx->r11 = ADD32(ctx->r2, 0X1);
    // 0x802B1874: sh          $t3, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r11;
    // 0x802B1878: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B187C: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B1880: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
L_802B1884:
    // 0x802B1884: slti        $at, $v0, 0xD
    ctx->r1 = SIGNED(ctx->r2) < 0XD ? 1 : 0;
    // 0x802B1888: bne         $at, $zero, L_802B18A0
    if (ctx->r1 != 0) {
        // 0x802B188C: addiu       $t4, $v0, -0x1
        ctx->r12 = ADD32(ctx->r2, -0X1);
            goto L_802B18A0;
    }
    // 0x802B188C: addiu       $t4, $v0, -0x1
    ctx->r12 = ADD32(ctx->r2, -0X1);
    // 0x802B1890: sh          $t4, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r12;
    // 0x802B1894: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1898: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B189C: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
L_802B18A0:
    // 0x802B18A0: slti        $at, $v0, -0xC
    ctx->r1 = SIGNED(ctx->r2) < -0XC ? 1 : 0;
    // 0x802B18A4: beq         $at, $zero, L_802B18B8
    if (ctx->r1 == 0) {
        // 0x802B18A8: addiu       $t5, $v0, 0x1
        ctx->r13 = ADD32(ctx->r2, 0X1);
            goto L_802B18B8;
    }
    // 0x802B18A8: addiu       $t5, $v0, 0x1
    ctx->r13 = ADD32(ctx->r2, 0X1);
    // 0x802B18AC: sh          $t5, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r13;
    // 0x802B18B0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B18B4: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
L_802B18B8:
    // 0x802B18B8: lh          $t6, 0x28($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X28);
    // 0x802B18BC: lw          $a1, 0x24($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X24);
    // 0x802B18C0: sll         $t7, $t6, 14
    ctx->r15 = S32(ctx->r14 << 14);
    // 0x802B18C4: subu        $v0, $t7, $a1
    ctx->r2 = SUB32(ctx->r15, ctx->r5);
    // 0x802B18C8: blez        $v0, L_802B18F0
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802B18CC: slti        $at, $v0, -0x4000
        ctx->r1 = SIGNED(ctx->r2) < -0X4000 ? 1 : 0;
            goto L_802B18F0;
    }
    // 0x802B18CC: slti        $at, $v0, -0x4000
    ctx->r1 = SIGNED(ctx->r2) < -0X4000 ? 1 : 0;
    // 0x802B18D0: slti        $at, $v0, 0x4001
    ctx->r1 = SIGNED(ctx->r2) < 0X4001 ? 1 : 0;
    // 0x802B18D4: bne         $at, $zero, L_802B18E4
    if (ctx->r1 != 0) {
        // 0x802B18D8: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802B18E4;
    }
    // 0x802B18D8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802B18DC: b           L_802B18E4
    // 0x802B18E0: addiu       $a0, $zero, 0x4000
    ctx->r4 = ADD32(0, 0X4000);
        goto L_802B18E4;
    // 0x802B18E0: addiu       $a0, $zero, 0x4000
    ctx->r4 = ADD32(0, 0X4000);
L_802B18E4:
    // 0x802B18E4: addu        $t8, $a1, $a0
    ctx->r24 = ADD32(ctx->r5, ctx->r4);
    // 0x802B18E8: b           L_802B1908
    // 0x802B18EC: sw          $t8, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r24;
        goto L_802B1908;
    // 0x802B18EC: sw          $t8, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r24;
L_802B18F0:
    // 0x802B18F0: beq         $at, $zero, L_802B1900
    if (ctx->r1 == 0) {
        // 0x802B18F4: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802B1900;
    }
    // 0x802B18F4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802B18F8: b           L_802B1900
    // 0x802B18FC: addiu       $a0, $zero, -0x4000
    ctx->r4 = ADD32(0, -0X4000);
        goto L_802B1900;
    // 0x802B18FC: addiu       $a0, $zero, -0x4000
    ctx->r4 = ADD32(0, -0X4000);
L_802B1900:
    // 0x802B1900: addu        $t9, $a1, $a0
    ctx->r25 = ADD32(ctx->r5, ctx->r4);
    // 0x802B1904: sw          $t9, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r25;
L_802B1908:
    // 0x802B1908: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B190C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B1910: jr          $ra
    // 0x802B1914: nop

    return;
    // 0x802B1914: nop

;}
RECOMP_FUNC void func_802B1918_6C2FC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1918: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B191C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1920: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1924: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1928: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B192C: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B1930: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B1934: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802B1938: lw          $v0, 0x24($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X24);
    // 0x802B193C: lui         $at, 0x6
    ctx->r1 = S32(0X6 << 16);
    // 0x802B1940: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B1944: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802B1948: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B194C: beq         $at, $zero, L_802B1960
    if (ctx->r1 == 0) {
        // 0x802B1950: sra         $a2, $t6, 16
        ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
            goto L_802B1960;
    }
    // 0x802B1950: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B1954: lui         $at, 0xFFFA
    ctx->r1 = S32(0XFFFA << 16);
    // 0x802B1958: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B195C: beq         $at, $zero, L_802B1970
    if (ctx->r1 == 0) {
        // 0x802B1960: sll         $t8, $v0, 3
        ctx->r24 = S32(ctx->r2 << 3);
            goto L_802B1970;
    }
L_802B1960:
    // 0x802B1960: sll         $t8, $v0, 3
    ctx->r24 = S32(ctx->r2 << 3);
    // 0x802B1964: subu        $t8, $t8, $v0
    ctx->r24 = SUB32(ctx->r24, ctx->r2);
    // 0x802B1968: sra         $t9, $t8, 3
    ctx->r25 = S32(SIGNED(ctx->r24) >> 3);
    // 0x802B196C: sw          $t9, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r25;
L_802B1970:
    // 0x802B1970: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1974: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B1978: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B197C: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
    // 0x802B1980: slti        $at, $v1, 0x9
    ctx->r1 = SIGNED(ctx->r3) < 0X9 ? 1 : 0;
    // 0x802B1984: bne         $at, $zero, L_802B1990
    if (ctx->r1 != 0) {
        // 0x802B1988: addiu       $t2, $v1, -0x1
        ctx->r10 = ADD32(ctx->r3, -0X1);
            goto L_802B1990;
    }
    // 0x802B1988: addiu       $t2, $v1, -0x1
    ctx->r10 = ADD32(ctx->r3, -0X1);
    // 0x802B198C: sh          $t2, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r10;
L_802B1990:
    // 0x802B1990: bgez        $a2, L_802B19FC
    if (SIGNED(ctx->r6) >= 0) {
        // 0x802B1994: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_802B19FC;
    }
    // 0x802B1994: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1998: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B199C: bne         $a2, $at, L_802B19AC
    if (ctx->r6 != ctx->r1) {
        // 0x802B19A0: negu        $a3, $a2
        ctx->r7 = SUB32(0, ctx->r6);
            goto L_802B19AC;
    }
    // 0x802B19A0: negu        $a3, $a2
    ctx->r7 = SUB32(0, ctx->r6);
    // 0x802B19A4: b           L_802B19B4
    // 0x802B19A8: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
        goto L_802B19B4;
    // 0x802B19A8: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
L_802B19AC:
    // 0x802B19AC: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x802B19B0: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
L_802B19B4:
    // 0x802B19B4: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802B19B8: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802B19BC: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    // 0x802B19C0: jal         0x80310EE4
    // 0x802B19C4: sh          $a3, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r7;
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x802B19C4: sh          $a3, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B19C8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B19CC: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B19D0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B19D4: lh          $a3, 0x1A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X1A);
    // 0x802B19D8: sra         $t5, $v0, 16
    ctx->r13 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B19DC: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x802B19E0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B19E4: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B19E8: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x802B19EC: addu        $a3, $t7, $a3
    ctx->r7 = ADD32(ctx->r15, ctx->r7);
    // 0x802B19F0: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802B19F4: b           L_802B1A0C
    // 0x802B19F8: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802B1A0C;
    // 0x802B19F8: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
L_802B19FC:
    // 0x802B19FC: lh          $t2, 0xC($v1)
    ctx->r10 = MEM_H(ctx->r3, 0XC);
    // 0x802B1A00: subu        $a3, $a2, $t2
    ctx->r7 = SUB32(ctx->r6, ctx->r10);
    // 0x802B1A04: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x802B1A08: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
L_802B1A0C:
    // 0x802B1A0C: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802B1A10: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B1A14: lh          $t5, 0x26($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X26);
    // 0x802B1A18: beq         $v0, $at, L_802B1A48
    if (ctx->r2 == ctx->r1) {
        // 0x802B1A1C: addiu       $at, $zero, 0x79
        ctx->r1 = ADD32(0, 0X79);
            goto L_802B1A48;
    }
    // 0x802B1A1C: addiu       $at, $zero, 0x79
    ctx->r1 = ADD32(0, 0X79);
    // 0x802B1A20: beq         $v0, $at, L_802B1A48
    if (ctx->r2 == ctx->r1) {
        // 0x802B1A24: addiu       $at, $zero, 0x7A
        ctx->r1 = ADD32(0, 0X7A);
            goto L_802B1A48;
    }
    // 0x802B1A24: addiu       $at, $zero, 0x7A
    ctx->r1 = ADD32(0, 0X7A);
    // 0x802B1A28: beq         $v0, $at, L_802B1A84
    if (ctx->r2 == ctx->r1) {
        // 0x802B1A2C: lh          $t8, 0x26($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X26);
            goto L_802B1A84;
    }
    // 0x802B1A2C: lh          $t8, 0x26($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X26);
    // 0x802B1A30: addiu       $at, $zero, 0x7B
    ctx->r1 = ADD32(0, 0X7B);
    // 0x802B1A34: beq         $v0, $at, L_802B1A84
    if (ctx->r2 == ctx->r1) {
        // 0x802B1A38: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802B1A84;
    }
    // 0x802B1A38: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1A3C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802B1A40: b           L_802B1B54
    // 0x802B1A44: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
        goto L_802B1B54;
    // 0x802B1A44: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802B1A48:
    // 0x802B1A48: bgtz        $t5, L_802B1A58
    if (SIGNED(ctx->r13) > 0) {
        // 0x802B1A4C: nop
    
            goto L_802B1A58;
    }
    // 0x802B1A4C: nop

    // 0x802B1A50: blez        $a3, L_802B1A74
    if (SIGNED(ctx->r7) <= 0) {
        // 0x802B1A54: nop
    
            goto L_802B1A74;
    }
    // 0x802B1A54: nop

L_802B1A58:
    // 0x802B1A58: jal         0x802A5CF4
    // 0x802B1A5C: nop

    func_802A5CF4_6B73A4(rdram, ctx);
        goto after_1;
    // 0x802B1A5C: nop

    after_1:
    // 0x802B1A60: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1A64: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1A68: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x802B1A6C: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802B1A70: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
L_802B1A74:
    // 0x802B1A74: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1A78: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802B1A7C: b           L_802B1B54
    // 0x802B1A80: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
        goto L_802B1B54;
    // 0x802B1A80: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802B1A84:
    // 0x802B1A84: bne         $t8, $zero, L_802B1AA0
    if (ctx->r24 != 0) {
        // 0x802B1A88: lh          $t3, 0x26($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X26);
            goto L_802B1AA0;
    }
    // 0x802B1A88: lh          $t3, 0x26($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X26);
    // 0x802B1A8C: addiu       $t9, $zero, 0x7B
    ctx->r25 = ADD32(0, 0X7B);
    // 0x802B1A90: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
    // 0x802B1A94: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x802B1A98: b           L_802B1AE8
    // 0x802B1A9C: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
        goto L_802B1AE8;
    // 0x802B1A9C: sb          $zero, 0x368($t2)
    MEM_B(0X368, ctx->r10) = 0;
L_802B1AA0:
    // 0x802B1AA0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B1AA4: bne         $t3, $at, L_802B1ACC
    if (ctx->r11 != ctx->r1) {
        // 0x802B1AA8: lh          $t8, 0x22($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X22);
            goto L_802B1ACC;
    }
    // 0x802B1AA8: lh          $t8, 0x22($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X22);
    // 0x802B1AAC: addiu       $t4, $zero, 0x7B
    ctx->r12 = ADD32(0, 0X7B);
    // 0x802B1AB0: sh          $t4, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r12;
    // 0x802B1AB4: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x802B1AB8: lh          $t5, 0x22($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X22);
    // 0x802B1ABC: sh          $t5, 0x2C($t6)
    MEM_H(0X2C, ctx->r14) = ctx->r13;
    // 0x802B1AC0: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802B1AC4: b           L_802B1AE8
    // 0x802B1AC8: sb          $zero, 0x368($t7)
    MEM_B(0X368, ctx->r15) = 0;
        goto L_802B1AE8;
    // 0x802B1AC8: sb          $zero, 0x368($t7)
    MEM_B(0X368, ctx->r15) = 0;
L_802B1ACC:
    // 0x802B1ACC: sh          $t8, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r24;
    // 0x802B1AD0: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x802B1AD4: addiu       $t9, $zero, 0x7A
    ctx->r25 = ADD32(0, 0X7A);
    // 0x802B1AD8: sh          $t9, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r25;
    // 0x802B1ADC: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x802B1AE0: lh          $t3, 0x26($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X26);
    // 0x802B1AE4: sb          $t3, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r11;
L_802B1AE8:
    // 0x802B1AE8: bgtz        $a3, L_802B1B10
    if (SIGNED(ctx->r7) > 0) {
        // 0x802B1AEC: lui         $a0, 0x803A
        ctx->r4 = S32(0X803A << 16);
            goto L_802B1B10;
    }
    // 0x802B1AEC: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x802B1AF0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1AF4: lw          $a0, 0x5B0($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5B0);
    // 0x802B1AF8: lw          $v0, 0x24($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X24);
    // 0x802B1AFC: negu        $at, $a0
    ctx->r1 = SUB32(0, ctx->r4);
    // 0x802B1B00: sll         $t5, $at, 1
    ctx->r13 = S32(ctx->r1 << 1);
    // 0x802B1B04: slt         $at, $v0, $t5
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B1B08: beql        $at, $zero, L_802B1B40
    if (ctx->r1 == 0) {
        // 0x802B1B0C: sra         $t4, $a0, 3
        ctx->r12 = S32(SIGNED(ctx->r4) >> 3);
            goto L_802B1B40;
    }
    goto skip_0;
    // 0x802B1B0C: sra         $t4, $a0, 3
    ctx->r12 = S32(SIGNED(ctx->r4) >> 3);
    skip_0:
L_802B1B10:
    // 0x802B1B10: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x802B1B14: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x802B1B18: lw          $t7, 0x5B0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5B0);
    // 0x802B1B1C: lw          $t6, 0x24($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X24);
    // 0x802B1B20: addiu       $t2, $zero, 0x32
    ctx->r10 = ADD32(0, 0X32);
    // 0x802B1B24: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x802B1B28: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802B1B2C: sw          $t9, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r25;
    // 0x802B1B30: lw          $t3, 0x0($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X0);
    // 0x802B1B34: b           L_802B1B48
    // 0x802B1B38: sh          $t2, 0x30E($t3)
    MEM_H(0X30E, ctx->r11) = ctx->r10;
        goto L_802B1B48;
    // 0x802B1B38: sh          $t2, 0x30E($t3)
    MEM_H(0X30E, ctx->r11) = ctx->r10;
    // 0x802B1B3C: sra         $t4, $a0, 3
    ctx->r12 = S32(SIGNED(ctx->r4) >> 3);
L_802B1B40:
    // 0x802B1B40: subu        $t5, $v0, $t4
    ctx->r13 = SUB32(ctx->r2, ctx->r12);
    // 0x802B1B44: sw          $t5, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r13;
L_802B1B48:
    // 0x802B1B48: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1B4C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x802B1B50: lh          $v1, 0x30E($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30E);
L_802B1B54:
    // 0x802B1B54: lh          $t7, 0x30C($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X30C);
    // 0x802B1B58: sra         $t6, $v1, 1
    ctx->r14 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802B1B5C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802B1B60: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B1B64: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x802B1B68: mfhi        $t9
    ctx->r25 = hi;
    // 0x802B1B6C: sh          $t9, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r25;
    // 0x802B1B70: lh          $t2, 0x26($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X26);
    // 0x802B1B74: lh          $t3, 0x22($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X22);
    // 0x802B1B78: bgezl       $t2, L_802B1B8C
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802B1B7C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B1B8C;
    }
    goto skip_1;
    // 0x802B1B7C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802B1B80: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x802B1B84: sh          $t3, 0x2C($t4)
    MEM_H(0X2C, ctx->r12) = ctx->r11;
    // 0x802B1B88: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B1B8C:
    // 0x802B1B8C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B1B90: jr          $ra
    // 0x802B1B94: nop

    return;
    // 0x802B1B94: nop

;}
RECOMP_FUNC void func_802B1B98_6C3248(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1B98: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B1B9C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1BA0: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B1BA4: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B1BA8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B1BAC: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B1BB0: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B1BB4: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x802B1BB8: sll         $s0, $a1, 16
    ctx->r16 = S32(ctx->r5 << 16);
    // 0x802B1BBC: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x802B1BC0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B1BC4: beq         $v0, $at, L_802B1BF0
    if (ctx->r2 == ctx->r1) {
        // 0x802B1BC8: or          $s0, $t6, $zero
        ctx->r16 = ctx->r14 | 0;
            goto L_802B1BF0;
    }
    // 0x802B1BC8: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x802B1BCC: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x802B1BD0: beq         $v0, $at, L_802B1BF0
    if (ctx->r2 == ctx->r1) {
        // 0x802B1BD4: addiu       $at, $zero, 0x8E
        ctx->r1 = ADD32(0, 0X8E);
            goto L_802B1BF0;
    }
    // 0x802B1BD4: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802B1BD8: beq         $v0, $at, L_802B1C3C
    if (ctx->r2 == ctx->r1) {
        // 0x802B1BDC: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_802B1C3C;
    }
    // 0x802B1BDC: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802B1BE0: beq         $v0, $at, L_802B1C8C
    if (ctx->r2 == ctx->r1) {
        // 0x802B1BE4: nop
    
            goto L_802B1C8C;
    }
    // 0x802B1BE4: nop

    // 0x802B1BE8: b           L_802B1CD8
    // 0x802B1BEC: nop

        goto L_802B1CD8;
    // 0x802B1BEC: nop

L_802B1BF0:
    // 0x802B1BF0: blez        $s0, L_802B1CD8
    if (SIGNED(ctx->r16) <= 0) {
        // 0x802B1BF4: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1CD8;
    }
    // 0x802B1BF4: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1BF8: beq         $at, $zero, L_802B1C18
    if (ctx->r1 == 0) {
        // 0x802B1BFC: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B1C18;
    }
    // 0x802B1BFC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B1C00: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1C04: sra         $t7, $a1, 24
    ctx->r15 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1C08: jal         0x802A5EF8
    // 0x802B1C0C: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    func_802A5EF8_6B75A8(rdram, ctx);
        goto after_0;
    // 0x802B1C0C: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_0:
    // 0x802B1C10: b           L_802B1CD8
    // 0x802B1C14: nop

        goto L_802B1CD8;
    // 0x802B1C14: nop

L_802B1C18:
    // 0x802B1C18: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1C1C: bne         $at, $zero, L_802B1CD8
    if (ctx->r1 != 0) {
        // 0x802B1C20: lhu         $a0, 0x22($sp)
        ctx->r4 = MEM_HU(ctx->r29, 0X22);
            goto L_802B1CD8;
    }
    // 0x802B1C20: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    // 0x802B1C24: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1C28: sra         $t8, $a1, 24
    ctx->r24 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1C2C: jal         0x802A6044
    // 0x802B1C30: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_802A6044_6B76F4(rdram, ctx);
        goto after_1;
    // 0x802B1C30: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_1:
    // 0x802B1C34: b           L_802B1CD8
    // 0x802B1C38: nop

        goto L_802B1CD8;
    // 0x802B1C38: nop

L_802B1C3C:
    // 0x802B1C3C: bgtz        $s0, L_802B1C54
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B1C40: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1C54;
    }
    // 0x802B1C40: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1C44: jal         0x802A5EA4
    // 0x802B1C48: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_2;
    // 0x802B1C48: nop

    after_2:
    // 0x802B1C4C: b           L_802B1CD8
    // 0x802B1C50: nop

        goto L_802B1CD8;
    // 0x802B1C50: nop

L_802B1C54:
    // 0x802B1C54: bne         $at, $zero, L_802B1C78
    if (ctx->r1 != 0) {
        // 0x802B1C58: lh          $t0, 0x22($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X22);
            goto L_802B1C78;
    }
    // 0x802B1C58: lh          $t0, 0x22($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X22);
    // 0x802B1C5C: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1C60: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1C64: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x802B1C68: jal         0x802A6044
    // 0x802B1C6C: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A6044_6B76F4(rdram, ctx);
        goto after_3;
    // 0x802B1C6C: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_3:
    // 0x802B1C70: b           L_802B1CD8
    // 0x802B1C74: nop

        goto L_802B1CD8;
    // 0x802B1C74: nop

L_802B1C78:
    // 0x802B1C78: sh          $t0, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r8;
    // 0x802B1C7C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1C80: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x802B1C84: b           L_802B1CD8
    // 0x802B1C88: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
        goto L_802B1CD8;
    // 0x802B1C88: sb          $s0, 0x368($t1)
    MEM_B(0X368, ctx->r9) = ctx->r16;
L_802B1C8C:
    // 0x802B1C8C: bgtz        $s0, L_802B1CA4
    if (SIGNED(ctx->r16) > 0) {
        // 0x802B1C90: slti        $at, $s0, 0xE
        ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
            goto L_802B1CA4;
    }
    // 0x802B1C90: slti        $at, $s0, 0xE
    ctx->r1 = SIGNED(ctx->r16) < 0XE ? 1 : 0;
    // 0x802B1C94: jal         0x802A5EA4
    // 0x802B1C98: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_4;
    // 0x802B1C98: nop

    after_4:
    // 0x802B1C9C: b           L_802B1CD8
    // 0x802B1CA0: nop

        goto L_802B1CD8;
    // 0x802B1CA0: nop

L_802B1CA4:
    // 0x802B1CA4: beq         $at, $zero, L_802B1CC8
    if (ctx->r1 == 0) {
        // 0x802B1CA8: lh          $t3, 0x22($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X22);
            goto L_802B1CC8;
    }
    // 0x802B1CA8: lh          $t3, 0x22($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X22);
    // 0x802B1CAC: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x802B1CB0: sra         $t2, $a1, 24
    ctx->r10 = S32(SIGNED(ctx->r5) >> 24);
    // 0x802B1CB4: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x802B1CB8: jal         0x802A5EF8
    // 0x802B1CBC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    func_802A5EF8_6B75A8(rdram, ctx);
        goto after_5;
    // 0x802B1CBC: lhu         $a0, 0x22($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X22);
    after_5:
    // 0x802B1CC0: b           L_802B1CD8
    // 0x802B1CC4: nop

        goto L_802B1CD8;
    // 0x802B1CC4: nop

L_802B1CC8:
    // 0x802B1CC8: sh          $t3, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r11;
    // 0x802B1CCC: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B1CD0: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x802B1CD4: sb          $s0, 0x368($t4)
    MEM_B(0X368, ctx->r12) = ctx->r16;
L_802B1CD8:
    // 0x802B1CD8: bgez        $s0, L_802B1CEC
    if (SIGNED(ctx->r16) >= 0) {
        // 0x802B1CDC: lh          $t5, 0x22($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X22);
            goto L_802B1CEC;
    }
    // 0x802B1CDC: lh          $t5, 0x22($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X22);
    // 0x802B1CE0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B1CE4: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B1CE8: sh          $t5, 0x2C($t6)
    MEM_H(0X2C, ctx->r14) = ctx->r13;
L_802B1CEC:
    // 0x802B1CEC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B1CF0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B1CF4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B1CF8: jr          $ra
    // 0x802B1CFC: nop

    return;
    // 0x802B1CFC: nop

;}
RECOMP_FUNC void func_802B1D00_6C33B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1D00: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B1D04: lh          $t8, 0x5540($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5540);
    // 0x802B1D08: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B1D0C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B1D10: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802B1D14: andi        $t9, $t8, 0x3
    ctx->r25 = ctx->r24 & 0X3;
    // 0x802B1D18: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B1D1C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B1D20: bne         $t9, $zero, L_802B1D7C
    if (ctx->r25 != 0) {
        // 0x802B1D24: sw          $a0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r4;
            goto L_802B1D7C;
    }
    // 0x802B1D24: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802B1D28: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1D2C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B1D30: lb          $t0, 0x4A($v0)
    ctx->r8 = MEM_B(ctx->r2, 0X4A);
    // 0x802B1D34: bne         $t0, $zero, L_802B1D7C
    if (ctx->r8 != 0) {
        // 0x802B1D38: nop
    
            goto L_802B1D7C;
    }
    // 0x802B1D38: nop

    // 0x802B1D3C: lw          $t1, 0x4C($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X4C);
    // 0x802B1D40: sll         $t3, $t1, 26
    ctx->r11 = S32(ctx->r9 << 26);
    // 0x802B1D44: bltz        $t3, L_802B1D7C
    if (SIGNED(ctx->r11) < 0) {
        // 0x802B1D48: nop
    
            goto L_802B1D7C;
    }
    // 0x802B1D48: nop

    // 0x802B1D4C: lh          $t4, 0x14C($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X14C);
    // 0x802B1D50: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B1D54: addiu       $t5, $t4, -0x1
    ctx->r13 = ADD32(ctx->r12, -0X1);
    // 0x802B1D58: sh          $t5, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r13;
    // 0x802B1D5C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1D60: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B1D64: lh          $t6, 0x14C($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X14C);
    // 0x802B1D68: sh          $t6, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r14;
    // 0x802B1D6C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x802B1D70: lb          $t7, 0x36B($v1)
    ctx->r15 = MEM_B(ctx->r3, 0X36B);
    // 0x802B1D74: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x802B1D78: sb          $t8, 0x36B($v1)
    MEM_B(0X36B, ctx->r3) = ctx->r24;
L_802B1D7C:
    // 0x802B1D7C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1D80: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B1D84: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x802B1D88: addiu       $at, $zero, 0xA1
    ctx->r1 = ADD32(0, 0XA1);
    // 0x802B1D8C: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802B1D90: beq         $v1, $a0, L_802B1DB0
    if (ctx->r3 == ctx->r4) {
        // 0x802B1D94: nop
    
            goto L_802B1DB0;
    }
    // 0x802B1D94: nop

    // 0x802B1D98: beq         $v1, $at, L_802B1DB0
    if (ctx->r3 == ctx->r1) {
        // 0x802B1D9C: addiu       $at, $zero, 0xA2
        ctx->r1 = ADD32(0, 0XA2);
            goto L_802B1DB0;
    }
    // 0x802B1D9C: addiu       $at, $zero, 0xA2
    ctx->r1 = ADD32(0, 0XA2);
    // 0x802B1DA0: beq         $v1, $at, L_802B1DD4
    if (ctx->r3 == ctx->r1) {
        // 0x802B1DA4: nop
    
            goto L_802B1DD4;
    }
    // 0x802B1DA4: nop

    // 0x802B1DA8: b           L_802B1E04
    // 0x802B1DAC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
        goto L_802B1E04;
    // 0x802B1DAC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1DB0:
    // 0x802B1DB0: beq         $a1, $a0, L_802B1DC0
    if (ctx->r5 == ctx->r4) {
        // 0x802B1DB4: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802B1DC0;
    }
    // 0x802B1DB4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B1DB8: bnel        $a1, $at, L_802B1E04
    if (ctx->r5 != ctx->r1) {
        // 0x802B1DBC: addiu       $at, $zero, -0x1
        ctx->r1 = ADD32(0, -0X1);
            goto L_802B1E04;
    }
    goto skip_0;
    // 0x802B1DBC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    skip_0:
L_802B1DC0:
    // 0x802B1DC0: lhu         $a0, 0x1A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X1A);
    // 0x802B1DC4: jal         0x802A5E1C
    // 0x802B1DC8: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    func_802A5E1C_6B74CC(rdram, ctx);
        goto after_0;
    // 0x802B1DC8: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    after_0:
    // 0x802B1DCC: b           L_802B1E00
    // 0x802B1DD0: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
        goto L_802B1E00;
    // 0x802B1DD0: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
L_802B1DD4:
    // 0x802B1DD4: beq         $a1, $zero, L_802B1DE4
    if (ctx->r5 == 0) {
        // 0x802B1DD8: addiu       $at, $zero, -0x1
        ctx->r1 = ADD32(0, -0X1);
            goto L_802B1DE4;
    }
    // 0x802B1DD8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B1DDC: bnel        $a1, $at, L_802B1DFC
    if (ctx->r5 != ctx->r1) {
        // 0x802B1DE0: lh          $t9, 0x1A($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X1A);
            goto L_802B1DFC;
    }
    goto skip_1;
    // 0x802B1DE0: lh          $t9, 0x1A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X1A);
    skip_1:
L_802B1DE4:
    // 0x802B1DE4: jal         0x802A5E64
    // 0x802B1DE8: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    func_802A5E64_6B7514(rdram, ctx);
        goto after_1;
    // 0x802B1DE8: sh          $a1, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r5;
    after_1:
    // 0x802B1DEC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B1DF0: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B1DF4: lh          $a1, 0x1E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X1E);
    // 0x802B1DF8: lh          $t9, 0x1A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X1A);
L_802B1DFC:
    // 0x802B1DFC: sh          $t9, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r25;
L_802B1E00:
    // 0x802B1E00: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
L_802B1E04:
    // 0x802B1E04: bne         $a1, $at, L_802B1E18
    if (ctx->r5 != ctx->r1) {
        // 0x802B1E08: lh          $t0, 0x1A($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X1A);
            goto L_802B1E18;
    }
    // 0x802B1E08: lh          $t0, 0x1A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X1A);
    // 0x802B1E0C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B1E10: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802B1E14: sh          $t0, 0x2C($t1)
    MEM_H(0X2C, ctx->r9) = ctx->r8;
L_802B1E18:
    // 0x802B1E18: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B1E1C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B1E20: jr          $ra
    // 0x802B1E24: nop

    return;
    // 0x802B1E24: nop

;}
RECOMP_FUNC void func_802B1E28_6C34D8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B1E28: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802B1E2C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1E30: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1E34: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1E38: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B1E3C: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x802B1E40: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x802B1E44: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x802B1E48: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B1E4C: lui         $at, 0x6
    ctx->r1 = S32(0X6 << 16);
    // 0x802B1E50: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B1E54: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B1E58: beq         $at, $zero, L_802B1E6C
    if (ctx->r1 == 0) {
        // 0x802B1E5C: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_802B1E6C;
    }
    // 0x802B1E5C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B1E60: lui         $at, 0xFFFA
    ctx->r1 = S32(0XFFFA << 16);
    // 0x802B1E64: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B1E68: beq         $at, $zero, L_802B1E80
    if (ctx->r1 == 0) {
        // 0x802B1E6C: sll         $t6, $v1, 3
        ctx->r14 = S32(ctx->r3 << 3);
            goto L_802B1E80;
    }
L_802B1E6C:
    // 0x802B1E6C: sll         $t6, $v1, 3
    ctx->r14 = S32(ctx->r3 << 3);
    // 0x802B1E70: subu        $t6, $t6, $v1
    ctx->r14 = SUB32(ctx->r14, ctx->r3);
    // 0x802B1E74: sra         $t7, $t6, 3
    ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
    // 0x802B1E78: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
    // 0x802B1E7C: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
L_802B1E80:
    // 0x802B1E80: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802B1E84: lh          $t9, 0xC2($t8)
    ctx->r25 = MEM_H(ctx->r24, 0XC2);
    // 0x802B1E88: sh          $t9, 0x18($sp)
    MEM_H(0X18, ctx->r29) = ctx->r25;
    // 0x802B1E8C: lhu         $t2, 0x0($a3)
    ctx->r10 = MEM_HU(ctx->r7, 0X0);
    // 0x802B1E90: addiu       $t3, $t2, -0x65
    ctx->r11 = ADD32(ctx->r10, -0X65);
    // 0x802B1E94: sltiu       $at, $t3, 0x6
    ctx->r1 = ctx->r11 < 0X6 ? 1 : 0;
    // 0x802B1E98: beq         $at, $zero, L_802B2054
    if (ctx->r1 == 0) {
        // 0x802B1E9C: sll         $t3, $t3, 2
        ctx->r11 = S32(ctx->r11 << 2);
            goto L_802B2054;
    }
    // 0x802B1E9C: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802B1EA0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B1EA4: addu        $at, $at, $t3
    gpr jr_addend_802B1EAC = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802B1EA8: lw          $t3, -0x4248($at)
    ctx->r11 = ADD32(ctx->r1, -0X4248);
    // 0x802B1EAC: jr          $t3
    // 0x802B1EB0: nop

    switch (jr_addend_802B1EAC >> 2) {
        case 0: goto L_802B1EB4; break;
        case 1: goto L_802B2054; break;
        case 2: goto L_802B1F14; break;
        case 3: goto L_802B1F58; break;
        case 4: goto L_802B1FCC; break;
        case 5: goto L_802B2014; break;
        default: switch_error(__func__, 0x802B1EAC, 0x803BBDB8);
    }
    // 0x802B1EB0: nop

L_802B1EB4:
    // 0x802B1EB4: lh          $t4, 0x2E($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1EB8: blezl       $t4, L_802B1EF4
    if (SIGNED(ctx->r12) <= 0) {
        // 0x802B1EBC: lh          $t9, 0x2A($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X2A);
            goto L_802B1EF4;
    }
    goto skip_0;
    // 0x802B1EBC: lh          $t9, 0x2A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2A);
    skip_0:
    // 0x802B1EC0: jal         0x802A613C
    // 0x802B1EC4: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_0;
    // 0x802B1EC4: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    after_0:
    // 0x802B1EC8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1ECC: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1ED0: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1ED4: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x802B1ED8: lh          $t5, 0x24($a3)
    ctx->r13 = MEM_H(ctx->r7, 0X24);
    // 0x802B1EDC: addiu       $t6, $t5, 0x2
    ctx->r14 = ADD32(ctx->r13, 0X2);
    // 0x802B1EE0: sh          $t6, 0x24($a3)
    MEM_H(0X24, ctx->r7) = ctx->r14;
    // 0x802B1EE4: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x802B1EE8: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
    // 0x802B1EEC: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1EF0: lh          $t9, 0x2A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2A);
L_802B1EF4:
    // 0x802B1EF4: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B1EF8: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B1EFC: sh          $t9, 0x2C($a3)
    MEM_H(0X2C, ctx->r7) = ctx->r25;
    // 0x802B1F00: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1F04: lw          $v0, 0x5B0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5B0);
    // 0x802B1F08: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B1F0C: b           L_802B2068
    // 0x802B1F10: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
        goto L_802B2068;
    // 0x802B1F10: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B1F14:
    // 0x802B1F14: lh          $t2, 0x2E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1F18: blezl       $t2, L_802B1F38
    if (SIGNED(ctx->r10) <= 0) {
        // 0x802B1F1C: lh          $t3, 0x2A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X2A);
            goto L_802B1F38;
    }
    goto skip_1;
    // 0x802B1F1C: lh          $t3, 0x2A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X2A);
    skip_1:
    // 0x802B1F20: jal         0x802A613C
    // 0x802B1F24: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_1;
    // 0x802B1F24: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    after_1:
    // 0x802B1F28: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1F2C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1F30: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1F34: lh          $t3, 0x2A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X2A);
L_802B1F38:
    // 0x802B1F38: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B1F3C: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B1F40: sh          $t3, 0x2C($a3)
    MEM_H(0X2C, ctx->r7) = ctx->r11;
    // 0x802B1F44: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1F48: lw          $v0, 0x5B0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5B0);
    // 0x802B1F4C: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B1F50: b           L_802B2068
    // 0x802B1F54: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
        goto L_802B2068;
    // 0x802B1F54: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B1F58:
    // 0x802B1F58: lh          $t4, 0x2E($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1F5C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B1F60: beq         $t4, $zero, L_802B1F70
    if (ctx->r12 == 0) {
        // 0x802B1F64: nop
    
            goto L_802B1F70;
    }
    // 0x802B1F64: nop

    // 0x802B1F68: bne         $t4, $at, L_802B1F88
    if (ctx->r12 != ctx->r1) {
        // 0x802B1F6C: lh          $t5, 0x2E($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X2E);
            goto L_802B1F88;
    }
    // 0x802B1F6C: lh          $t5, 0x2E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2E);
L_802B1F70:
    // 0x802B1F70: jal         0x802A60C4
    // 0x802B1F74: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_2;
    // 0x802B1F74: nop

    after_2:
    // 0x802B1F78: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1F7C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1F80: b           L_802B1FA8
    // 0x802B1F84: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
        goto L_802B1FA8;
    // 0x802B1F84: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
L_802B1F88:
    // 0x802B1F88: slti        $at, $t5, 0xA
    ctx->r1 = SIGNED(ctx->r13) < 0XA ? 1 : 0;
    // 0x802B1F8C: bnel        $at, $zero, L_802B1FAC
    if (ctx->r1 != 0) {
        // 0x802B1F90: lh          $t6, 0x2A($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X2A);
            goto L_802B1FAC;
    }
    goto skip_2;
    // 0x802B1F90: lh          $t6, 0x2A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2A);
    skip_2:
    // 0x802B1F94: jal         0x802A6198
    // 0x802B1F98: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    func_802A6198_6B7848(rdram, ctx);
        goto after_3;
    // 0x802B1F98: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    after_3:
    // 0x802B1F9C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1FA0: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1FA4: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
L_802B1FA8:
    // 0x802B1FA8: lh          $t6, 0x2A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2A);
L_802B1FAC:
    // 0x802B1FAC: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B1FB0: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B1FB4: sh          $t6, 0x2C($a3)
    MEM_H(0X2C, ctx->r7) = ctx->r14;
    // 0x802B1FB8: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1FBC: lw          $v0, 0x5B0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5B0);
    // 0x802B1FC0: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B1FC4: b           L_802B2068
    // 0x802B1FC8: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
        goto L_802B2068;
    // 0x802B1FC8: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B1FCC:
    // 0x802B1FCC: lh          $t7, 0x2E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2E);
    // 0x802B1FD0: slti        $at, $t7, 0xA
    ctx->r1 = SIGNED(ctx->r15) < 0XA ? 1 : 0;
    // 0x802B1FD4: beql        $at, $zero, L_802B1FF4
    if (ctx->r1 == 0) {
        // 0x802B1FD8: lh          $t8, 0x2A($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X2A);
            goto L_802B1FF4;
    }
    goto skip_3;
    // 0x802B1FD8: lh          $t8, 0x2A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X2A);
    skip_3:
    // 0x802B1FDC: jal         0x802A613C
    // 0x802B1FE0: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    func_802A613C_6B77EC(rdram, ctx);
        goto after_4;
    // 0x802B1FE0: lhu         $a0, 0x2A($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X2A);
    after_4:
    // 0x802B1FE4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B1FE8: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B1FEC: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B1FF0: lh          $t8, 0x2A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X2A);
L_802B1FF4:
    // 0x802B1FF4: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B1FF8: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B1FFC: sh          $t8, 0x2C($a3)
    MEM_H(0X2C, ctx->r7) = ctx->r24;
    // 0x802B2000: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2004: lw          $v0, 0x5B0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5B0);
    // 0x802B2008: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B200C: b           L_802B2068
    // 0x802B2010: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
        goto L_802B2068;
    // 0x802B2010: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B2014:
    // 0x802B2014: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B2018: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B201C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B2020: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B2024: negu        $at, $v0
    ctx->r1 = SUB32(0, ctx->r2);
    // 0x802B2028: sll         $t9, $at, 5
    ctx->r25 = S32(ctx->r1 << 5);
    // 0x802B202C: slt         $at, $t9, $v1
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B2030: beq         $at, $zero, L_802B2068
    if (ctx->r1 == 0) {
        // 0x802B2034: sra         $t3, $v0, 1
        ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
            goto L_802B2068;
    }
    // 0x802B2034: sra         $t3, $v0, 1
    ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802B2038: subu        $t2, $v1, $v0
    ctx->r10 = SUB32(ctx->r3, ctx->r2);
    // 0x802B203C: subu        $t4, $t2, $t3
    ctx->r12 = SUB32(ctx->r10, ctx->r11);
    // 0x802B2040: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
    // 0x802B2044: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2048: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B204C: b           L_802B2068
    // 0x802B2050: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
        goto L_802B2068;
    // 0x802B2050: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B2054:
    // 0x802B2054: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B2058: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x802B205C: addiu       $a1, $a1, 0x5B0
    ctx->r5 = ADD32(ctx->r5, 0X5B0);
    // 0x802B2060: lw          $v0, 0x5B0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5B0);
    // 0x802B2064: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
L_802B2068:
    // 0x802B2068: sra         $t5, $v0, 3
    ctx->r13 = S32(SIGNED(ctx->r2) >> 3);
    // 0x802B206C: subu        $t6, $v1, $t5
    ctx->r14 = SUB32(ctx->r3, ctx->r13);
    // 0x802B2070: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
    // 0x802B2074: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B2078: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802B207C: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B2080: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B2084: lhu         $a0, 0x9C($t7)
    ctx->r4 = MEM_HU(ctx->r15, 0X9C);
    // 0x802B2088: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B208C: beq         $a0, $at, L_802B20AC
    if (ctx->r4 == ctx->r1) {
        // 0x802B2090: addiu       $at, $zero, 0x13
        ctx->r1 = ADD32(0, 0X13);
            goto L_802B20AC;
    }
    // 0x802B2090: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802B2094: beql        $a0, $at, L_802B20B0
    if (ctx->r4 == ctx->r1) {
        // 0x802B2098: lw          $a3, 0x0($t0)
        ctx->r7 = MEM_W(ctx->r8, 0X0);
            goto L_802B20B0;
    }
    goto skip_4;
    // 0x802B2098: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    skip_4:
    // 0x802B209C: beq         $a0, $zero, L_802B20AC
    if (ctx->r4 == 0) {
        // 0x802B20A0: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802B20AC;
    }
    // 0x802B20A0: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802B20A4: bnel        $a0, $at, L_802B20E0
    if (ctx->r4 != ctx->r1) {
        // 0x802B20A8: lw          $a3, 0x0($t0)
        ctx->r7 = MEM_W(ctx->r8, 0X0);
            goto L_802B20E0;
    }
    goto skip_5;
    // 0x802B20A8: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    skip_5:
L_802B20AC:
    // 0x802B20AC: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
L_802B20B0:
    // 0x802B20B0: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
    // 0x802B20B4: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B20B8: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B20BC: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B20C0: beql        $at, $zero, L_802B21BC
    if (ctx->r1 == 0) {
        // 0x802B20C4: lw          $v0, 0x0($t1)
        ctx->r2 = MEM_W(ctx->r9, 0X0);
            goto L_802B21BC;
    }
    goto skip_6;
    // 0x802B20C4: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    skip_6:
    // 0x802B20C8: lw          $t8, 0x0($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X0);
    // 0x802B20CC: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x802B20D0: addu        $t2, $v1, $t9
    ctx->r10 = ADD32(ctx->r3, ctx->r25);
    // 0x802B20D4: b           L_802B21B8
    // 0x802B20D8: sw          $t2, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r10;
        goto L_802B21B8;
    // 0x802B20D8: sw          $t2, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r10;
    // 0x802B20DC: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
L_802B20E0:
    // 0x802B20E0: lui         $at, 0xFFFB
    ctx->r1 = S32(0XFFFB << 16);
    // 0x802B20E4: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B20E8: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B20EC: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B20F0: beql        $at, $zero, L_802B2114
    if (ctx->r1 == 0) {
        // 0x802B20F4: lui         $at, 0xFFF9
        ctx->r1 = S32(0XFFF9 << 16);
            goto L_802B2114;
    }
    goto skip_7;
    // 0x802B20F4: lui         $at, 0xFFF9
    ctx->r1 = S32(0XFFF9 << 16);
    skip_7:
    // 0x802B20F8: lw          $t3, 0x0($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X0);
    // 0x802B20FC: sra         $t4, $t3, 4
    ctx->r12 = S32(SIGNED(ctx->r11) >> 4);
    // 0x802B2100: addu        $t5, $v1, $t4
    ctx->r13 = ADD32(ctx->r3, ctx->r12);
    // 0x802B2104: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
    // 0x802B2108: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B210C: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B2110: lui         $at, 0xFFF9
    ctx->r1 = S32(0XFFF9 << 16);
L_802B2114:
    // 0x802B2114: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B2118: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B211C: beql        $at, $zero, L_802B2140
    if (ctx->r1 == 0) {
        // 0x802B2120: lui         $at, 0xFFF8
        ctx->r1 = S32(0XFFF8 << 16);
            goto L_802B2140;
    }
    goto skip_8;
    // 0x802B2120: lui         $at, 0xFFF8
    ctx->r1 = S32(0XFFF8 << 16);
    skip_8:
    // 0x802B2124: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x802B2128: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802B212C: addu        $t8, $v1, $t7
    ctx->r24 = ADD32(ctx->r3, ctx->r15);
    // 0x802B2130: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
    // 0x802B2134: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2138: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B213C: lui         $at, 0xFFF8
    ctx->r1 = S32(0XFFF8 << 16);
L_802B2140:
    // 0x802B2140: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B2144: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B2148: beql        $at, $zero, L_802B216C
    if (ctx->r1 == 0) {
        // 0x802B214C: lui         $at, 0xFFF7
        ctx->r1 = S32(0XFFF7 << 16);
            goto L_802B216C;
    }
    goto skip_9;
    // 0x802B214C: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
    skip_9:
    // 0x802B2150: lw          $t9, 0x0($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X0);
    // 0x802B2154: sra         $t2, $t9, 3
    ctx->r10 = S32(SIGNED(ctx->r25) >> 3);
    // 0x802B2158: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x802B215C: sw          $t3, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r11;
    // 0x802B2160: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2164: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B2168: lui         $at, 0xFFF7
    ctx->r1 = S32(0XFFF7 << 16);
L_802B216C:
    // 0x802B216C: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B2170: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B2174: beql        $at, $zero, L_802B2198
    if (ctx->r1 == 0) {
        // 0x802B2178: lui         $at, 0xFFF6
        ctx->r1 = S32(0XFFF6 << 16);
            goto L_802B2198;
    }
    goto skip_10;
    // 0x802B2178: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    skip_10:
    // 0x802B217C: lw          $t4, 0x0($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X0);
    // 0x802B2180: sra         $t5, $t4, 2
    ctx->r13 = S32(SIGNED(ctx->r12) >> 2);
    // 0x802B2184: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x802B2188: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
    // 0x802B218C: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2190: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B2194: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
L_802B2198:
    // 0x802B2198: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x802B219C: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B21A0: beql        $at, $zero, L_802B21BC
    if (ctx->r1 == 0) {
        // 0x802B21A4: lw          $v0, 0x0($t1)
        ctx->r2 = MEM_W(ctx->r9, 0X0);
            goto L_802B21BC;
    }
    goto skip_11;
    // 0x802B21A4: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    skip_11:
    // 0x802B21A8: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x802B21AC: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802B21B0: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x802B21B4: sw          $t9, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r25;
L_802B21B8:
    // 0x802B21B8: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
L_802B21BC:
    // 0x802B21BC: lh          $t7, 0x32($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X32);
    // 0x802B21C0: lh          $v1, 0x30C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X30C);
    // 0x802B21C4: blez        $v1, L_802B23A4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802B21C8: nop
    
            goto L_802B23A4;
    }
    // 0x802B21C8: nop

    // 0x802B21CC: lh          $t2, 0x18($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X18);
    // 0x802B21D0: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x802B21D4: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x802B21D8: sll         $t3, $t3, 1
    ctx->r11 = S32(ctx->r11 << 1);
    // 0x802B21DC: sra         $t4, $t3, 4
    ctx->r12 = S32(SIGNED(ctx->r11) >> 4);
    // 0x802B21E0: slt         $at, $t4, $v1
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B21E4: beq         $at, $zero, L_802B2388
    if (ctx->r1 == 0) {
        // 0x802B21E8: slt         $at, $t2, $v1
        ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_802B2388;
    }
    // 0x802B21E8: slt         $at, $t2, $v1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B21EC: bne         $at, $zero, L_802B2388
    if (ctx->r1 != 0) {
        // 0x802B21F0: nop
    
            goto L_802B2388;
    }
    // 0x802B21F0: nop

    // 0x802B21F4: lh          $t6, 0x302($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X302);
    // 0x802B21F8: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802B21FC: addiu       $v1, $v1, 0x2C78
    ctx->r3 = ADD32(ctx->r3, 0X2C78);
    // 0x802B2200: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802B2204: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802B2208: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x802B220C: lh          $t3, 0x0($t9)
    ctx->r11 = MEM_H(ctx->r25, 0X0);
    // 0x802B2210: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802B2214: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2218: multu       $t3, $a1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B221C: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B2220: lw          $t5, 0x1C($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X1C);
    // 0x802B2224: mflo        $t4
    ctx->r12 = lo;
    // 0x802B2228: addu        $t2, $t5, $t4
    ctx->r10 = ADD32(ctx->r13, ctx->r12);
    // 0x802B222C: sw          $t2, 0x1C($a3)
    MEM_W(0X1C, ctx->r7) = ctx->r10;
    // 0x802B2230: lw          $t7, 0x0($t1)
    ctx->r15 = MEM_W(ctx->r9, 0X0);
    // 0x802B2234: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2238: lh          $t8, 0x302($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X302);
    // 0x802B223C: lw          $t6, 0x20($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X20);
    // 0x802B2240: addiu       $t9, $t8, 0x40
    ctx->r25 = ADD32(ctx->r24, 0X40);
    // 0x802B2244: andi        $t3, $t9, 0xFF
    ctx->r11 = ctx->r25 & 0XFF;
    // 0x802B2248: sll         $t5, $t3, 1
    ctx->r13 = S32(ctx->r11 << 1);
    // 0x802B224C: addu        $t4, $v1, $t5
    ctx->r12 = ADD32(ctx->r3, ctx->r13);
    // 0x802B2250: lh          $t2, 0x0($t4)
    ctx->r10 = MEM_H(ctx->r12, 0X0);
    // 0x802B2254: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B2258: multu       $t2, $a1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B225C: mflo        $t7
    ctx->r15 = lo;
    // 0x802B2260: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B2264: sw          $t8, 0x20($a3)
    MEM_W(0X20, ctx->r7) = ctx->r24;
    // 0x802B2268: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x802B226C: lhu         $a0, 0x9C($t9)
    ctx->r4 = MEM_HU(ctx->r25, 0X9C);
    // 0x802B2270: beq         $a0, $at, L_802B2290
    if (ctx->r4 == ctx->r1) {
        // 0x802B2274: addiu       $at, $zero, 0x13
        ctx->r1 = ADD32(0, 0X13);
            goto L_802B2290;
    }
    // 0x802B2274: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802B2278: beq         $a0, $at, L_802B2290
    if (ctx->r4 == ctx->r1) {
        // 0x802B227C: nop
    
            goto L_802B2290;
    }
    // 0x802B227C: nop

    // 0x802B2280: beq         $a0, $zero, L_802B2290
    if (ctx->r4 == 0) {
        // 0x802B2284: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802B2290;
    }
    // 0x802B2284: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802B2288: bne         $a0, $at, L_802B2344
    if (ctx->r4 != ctx->r1) {
        // 0x802B228C: nop
    
            goto L_802B2344;
    }
    // 0x802B228C: nop

L_802B2290:
    // 0x802B2290: jal         0x802B2580
    // 0x802B2294: nop

    get_distance_from_ground(rdram, ctx);
        goto after_5;
    // 0x802B2294: nop

    after_5:
    // 0x802B2298: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B229C: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802B22A0: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x802B22A4: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B22A8: lhu         $a0, 0x9C($t5)
    ctx->r4 = MEM_HU(ctx->r13, 0X9C);
    // 0x802B22AC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B22B0: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802B22B4: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B22B8: beq         $a0, $at, L_802B22C8
    if (ctx->r4 == ctx->r1) {
        // 0x802B22BC: or          $a1, $t3, $zero
        ctx->r5 = ctx->r11 | 0;
            goto L_802B22C8;
    }
    // 0x802B22BC: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x802B22C0: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802B22C4: bne         $a0, $at, L_802B22D8
    if (ctx->r4 != ctx->r1) {
        // 0x802B22C8: sra         $t4, $v0, 1
        ctx->r12 = S32(SIGNED(ctx->r2) >> 1);
            goto L_802B22D8;
    }
L_802B22C8:
    // 0x802B22C8: sra         $t4, $v0, 1
    ctx->r12 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802B22CC: addu        $a1, $v0, $t4
    ctx->r5 = ADD32(ctx->r2, ctx->r12);
    // 0x802B22D0: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x802B22D4: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
L_802B22D8:
    // 0x802B22D8: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B22DC: lui         $at, 0xA
    ctx->r1 = S32(0XA << 16);
    // 0x802B22E0: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B22E4: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B22E8: beq         $at, $zero, L_802B2388
    if (ctx->r1 == 0) {
        // 0x802B22EC: slti        $at, $a1, 0x1C1
        ctx->r1 = SIGNED(ctx->r5) < 0X1C1 ? 1 : 0;
            goto L_802B2388;
    }
    // 0x802B22EC: slti        $at, $a1, 0x1C1
    ctx->r1 = SIGNED(ctx->r5) < 0X1C1 ? 1 : 0;
    // 0x802B22F0: bne         $at, $zero, L_802B2304
    if (ctx->r1 != 0) {
        // 0x802B22F4: ori         $at, $zero, 0x9000
        ctx->r1 = 0 | 0X9000;
            goto L_802B2304;
    }
    // 0x802B22F4: ori         $at, $zero, 0x9000
    ctx->r1 = 0 | 0X9000;
    // 0x802B22F8: addu        $t7, $v1, $at
    ctx->r15 = ADD32(ctx->r3, ctx->r1);
    // 0x802B22FC: b           L_802B2388
    // 0x802B2300: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
        goto L_802B2388;
    // 0x802B2300: sw          $t7, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r15;
L_802B2304:
    // 0x802B2304: slti        $at, $a1, 0x141
    ctx->r1 = SIGNED(ctx->r5) < 0X141 ? 1 : 0;
    // 0x802B2308: bne         $at, $zero, L_802B231C
    if (ctx->r1 != 0) {
        // 0x802B230C: ori         $at, $zero, 0xB000
        ctx->r1 = 0 | 0XB000;
            goto L_802B231C;
    }
    // 0x802B230C: ori         $at, $zero, 0xB000
    ctx->r1 = 0 | 0XB000;
    // 0x802B2310: addu        $t8, $v1, $at
    ctx->r24 = ADD32(ctx->r3, ctx->r1);
    // 0x802B2314: b           L_802B2388
    // 0x802B2318: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
        goto L_802B2388;
    // 0x802B2318: sw          $t8, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r24;
L_802B231C:
    // 0x802B231C: slti        $at, $a1, 0xC1
    ctx->r1 = SIGNED(ctx->r5) < 0XC1 ? 1 : 0;
    // 0x802B2320: bne         $at, $zero, L_802B2334
    if (ctx->r1 != 0) {
        // 0x802B2324: ori         $at, $zero, 0xC000
        ctx->r1 = 0 | 0XC000;
            goto L_802B2334;
    }
    // 0x802B2324: ori         $at, $zero, 0xC000
    ctx->r1 = 0 | 0XC000;
    // 0x802B2328: addu        $t9, $v1, $at
    ctx->r25 = ADD32(ctx->r3, ctx->r1);
    // 0x802B232C: b           L_802B2388
    // 0x802B2330: sw          $t9, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r25;
        goto L_802B2388;
    // 0x802B2330: sw          $t9, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r25;
L_802B2334:
    // 0x802B2334: ori         $at, $zero, 0xE000
    ctx->r1 = 0 | 0XE000;
    // 0x802B2338: addu        $t3, $v1, $at
    ctx->r11 = ADD32(ctx->r3, ctx->r1);
    // 0x802B233C: b           L_802B2388
    // 0x802B2340: sw          $t3, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r11;
        goto L_802B2388;
    // 0x802B2340: sw          $t3, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r11;
L_802B2344:
    // 0x802B2344: jal         0x802B2580
    // 0x802B2348: nop

    get_distance_from_ground(rdram, ctx);
        goto after_6;
    // 0x802B2348: nop

    after_6:
    // 0x802B234C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B2350: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B2354: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B2358: lui         $at, 0xA
    ctx->r1 = S32(0XA << 16);
    // 0x802B235C: lw          $v1, 0x24($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X24);
    // 0x802B2360: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x802B2364: beq         $at, $zero, L_802B2388
    if (ctx->r1 == 0) {
        // 0x802B2368: slti        $at, $v0, 0x281
        ctx->r1 = SIGNED(ctx->r2) < 0X281 ? 1 : 0;
            goto L_802B2388;
    }
    // 0x802B2368: slti        $at, $v0, 0x281
    ctx->r1 = SIGNED(ctx->r2) < 0X281 ? 1 : 0;
    // 0x802B236C: bne         $at, $zero, L_802B237C
    if (ctx->r1 != 0) {
        // 0x802B2370: addiu       $t5, $v1, 0x4000
        ctx->r13 = ADD32(ctx->r3, 0X4000);
            goto L_802B237C;
    }
    // 0x802B2370: addiu       $t5, $v1, 0x4000
    ctx->r13 = ADD32(ctx->r3, 0X4000);
    // 0x802B2374: b           L_802B2388
    // 0x802B2378: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
        goto L_802B2388;
    // 0x802B2378: sw          $t5, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r13;
L_802B237C:
    // 0x802B237C: ori         $at, $zero, 0xE000
    ctx->r1 = 0 | 0XE000;
    // 0x802B2380: addu        $t4, $v1, $at
    ctx->r12 = ADD32(ctx->r3, ctx->r1);
    // 0x802B2384: sw          $t4, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r12;
L_802B2388:
    // 0x802B2388: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B238C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x802B2390: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x802B2394: lh          $t2, 0x30C($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X30C);
    // 0x802B2398: addiu       $t6, $t2, -0x1
    ctx->r14 = ADD32(ctx->r10, -0X1);
    // 0x802B239C: b           L_802B2554
    // 0x802B23A0: sh          $t6, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r14;
        goto L_802B2554;
    // 0x802B23A0: sh          $t6, 0x30C($v0)
    MEM_H(0X30C, ctx->r2) = ctx->r14;
L_802B23A4:
    // 0x802B23A4: bgez        $t7, L_802B23F4
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802B23A8: lw          $a3, 0x0($t0)
        ctx->r7 = MEM_W(ctx->r8, 0X0);
            goto L_802B23F4;
    }
    // 0x802B23A8: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B23AC: lh          $a0, 0x4($a3)
    ctx->r4 = MEM_H(ctx->r7, 0X4);
    // 0x802B23B0: lh          $a1, 0x8($a3)
    ctx->r5 = MEM_H(ctx->r7, 0X8);
    // 0x802B23B4: jal         0x80310EE4
    // 0x802B23B8: lbu         $a2, 0x160($a3)
    ctx->r6 = MEM_BU(ctx->r7, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_7;
    // 0x802B23B8: lbu         $a2, 0x160($a3)
    ctx->r6 = MEM_BU(ctx->r7, 0X160);
    after_7:
    // 0x802B23BC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B23C0: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B23C4: lw          $a3, 0x0($t0)
    ctx->r7 = MEM_W(ctx->r8, 0X0);
    // 0x802B23C8: lh          $t9, 0x32($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X32);
    // 0x802B23CC: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B23D0: lh          $t5, 0xC($a3)
    ctx->r13 = MEM_H(ctx->r7, 0XC);
    // 0x802B23D4: subu        $t3, $t8, $t9
    ctx->r11 = SUB32(ctx->r24, ctx->r25);
    // 0x802B23D8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B23DC: subu        $v1, $t3, $t5
    ctx->r3 = SUB32(ctx->r11, ctx->r13);
    // 0x802B23E0: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x802B23E4: sra         $t2, $t4, 16
    ctx->r10 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802B23E8: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
    // 0x802B23EC: b           L_802B2408
    // 0x802B23F0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
        goto L_802B2408;
    // 0x802B23F0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
L_802B23F4:
    // 0x802B23F4: lh          $t6, 0x32($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X32);
    // 0x802B23F8: lh          $t7, 0xC($a3)
    ctx->r15 = MEM_H(ctx->r7, 0XC);
    // 0x802B23FC: subu        $v1, $t6, $t7
    ctx->r3 = SUB32(ctx->r14, ctx->r15);
    // 0x802B2400: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802B2404: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_802B2408:
    // 0x802B2408: lhu         $t3, 0x0($a3)
    ctx->r11 = MEM_HU(ctx->r7, 0X0);
    // 0x802B240C: addiu       $at, $zero, 0x6A
    ctx->r1 = ADD32(0, 0X6A);
    // 0x802B2410: beq         $t3, $at, L_802B2554
    if (ctx->r11 == ctx->r1) {
        // 0x802B2414: slti        $at, $v1, -0x100
        ctx->r1 = SIGNED(ctx->r3) < -0X100 ? 1 : 0;
            goto L_802B2554;
    }
    // 0x802B2414: slti        $at, $v1, -0x100
    ctx->r1 = SIGNED(ctx->r3) < -0X100 ? 1 : 0;
    // 0x802B2418: bne         $at, $zero, L_802B2498
    if (ctx->r1 != 0) {
        // 0x802B241C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802B2498;
    }
    // 0x802B241C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802B2420: slti        $at, $v1, -0x80
    ctx->r1 = SIGNED(ctx->r3) < -0X80 ? 1 : 0;
    // 0x802B2424: beq         $at, $zero, L_802B2444
    if (ctx->r1 == 0) {
        // 0x802B2428: nop
    
            goto L_802B2444;
    }
    // 0x802B2428: nop

    // 0x802B242C: lh          $t5, 0x24($a3)
    ctx->r13 = MEM_H(ctx->r7, 0X24);
    // 0x802B2430: slti        $at, $t5, -0xA
    ctx->r1 = SIGNED(ctx->r13) < -0XA ? 1 : 0;
    // 0x802B2434: beq         $at, $zero, L_802B2498
    if (ctx->r1 == 0) {
        // 0x802B2438: nop
    
            goto L_802B2498;
    }
    // 0x802B2438: nop

    // 0x802B243C: b           L_802B2498
    // 0x802B2440: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2498;
    // 0x802B2440: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2444:
    // 0x802B2444: bgez        $v1, L_802B2464
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B2448: slti        $at, $v1, 0x40
        ctx->r1 = SIGNED(ctx->r3) < 0X40 ? 1 : 0;
            goto L_802B2464;
    }
    // 0x802B2448: slti        $at, $v1, 0x40
    ctx->r1 = SIGNED(ctx->r3) < 0X40 ? 1 : 0;
    // 0x802B244C: lh          $t4, 0x24($a3)
    ctx->r12 = MEM_H(ctx->r7, 0X24);
    // 0x802B2450: slti        $at, $t4, -0x5
    ctx->r1 = SIGNED(ctx->r12) < -0X5 ? 1 : 0;
    // 0x802B2454: beq         $at, $zero, L_802B2498
    if (ctx->r1 == 0) {
        // 0x802B2458: nop
    
            goto L_802B2498;
    }
    // 0x802B2458: nop

    // 0x802B245C: b           L_802B2498
    // 0x802B2460: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2498;
    // 0x802B2460: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2464:
    // 0x802B2464: beql        $at, $zero, L_802B2488
    if (ctx->r1 == 0) {
        // 0x802B2468: lh          $t6, 0x24($a3)
        ctx->r14 = MEM_H(ctx->r7, 0X24);
            goto L_802B2488;
    }
    goto skip_12;
    // 0x802B2468: lh          $t6, 0x24($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X24);
    skip_12:
    // 0x802B246C: lh          $t2, 0x24($a3)
    ctx->r10 = MEM_H(ctx->r7, 0X24);
    // 0x802B2470: slti        $at, $t2, 0x2
    ctx->r1 = SIGNED(ctx->r10) < 0X2 ? 1 : 0;
    // 0x802B2474: beq         $at, $zero, L_802B2498
    if (ctx->r1 == 0) {
        // 0x802B2478: nop
    
            goto L_802B2498;
    }
    // 0x802B2478: nop

    // 0x802B247C: b           L_802B2498
    // 0x802B2480: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2498;
    // 0x802B2480: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802B2484: lh          $t6, 0x24($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X24);
L_802B2488:
    // 0x802B2488: slti        $at, $t6, 0xA
    ctx->r1 = SIGNED(ctx->r14) < 0XA ? 1 : 0;
    // 0x802B248C: beq         $at, $zero, L_802B2498
    if (ctx->r1 == 0) {
        // 0x802B2490: nop
    
            goto L_802B2498;
    }
    // 0x802B2490: nop

    // 0x802B2494: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2498:
    // 0x802B2498: beq         $v0, $zero, L_802B2554
    if (ctx->r2 == 0) {
        // 0x802B249C: addiu       $t7, $zero, 0x4
        ctx->r15 = ADD32(0, 0X4);
            goto L_802B2554;
    }
    // 0x802B249C: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x802B24A0: lh          $t9, 0x18($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X18);
    // 0x802B24A4: addiu       $t3, $zero, 0x14
    ctx->r11 = ADD32(0, 0X14);
    // 0x802B24A8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B24AC: div         $zero, $t3, $t9
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r25))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r25)));
    // 0x802B24B0: sh          $t7, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = ctx->r15;
    // 0x802B24B4: lw          $t8, 0x24($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X24);
    // 0x802B24B8: mflo        $t5
    ctx->r13 = lo;
    // 0x802B24BC: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x802B24C0: sllv        $t2, $t4, $t5
    ctx->r10 = S32(ctx->r12 << (ctx->r13 & 31));
    // 0x802B24C4: addu        $t6, $t8, $t2
    ctx->r14 = ADD32(ctx->r24, ctx->r10);
    // 0x802B24C8: sw          $t6, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r14;
    // 0x802B24CC: bne         $t9, $zero, L_802B24D8
    if (ctx->r25 != 0) {
        // 0x802B24D0: nop
    
            goto L_802B24D8;
    }
    // 0x802B24D0: nop

    // 0x802B24D4: break       7
    do_break(2150311124);
L_802B24D8:
    // 0x802B24D8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B24DC: bne         $t9, $at, L_802B24F0
    if (ctx->r25 != ctx->r1) {
        // 0x802B24E0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B24F0;
    }
    // 0x802B24E0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B24E4: bne         $t3, $at, L_802B24F0
    if (ctx->r11 != ctx->r1) {
        // 0x802B24E8: nop
    
            goto L_802B24F0;
    }
    // 0x802B24E8: nop

    // 0x802B24EC: break       6
    do_break(2150311148);
L_802B24F0:
    // 0x802B24F0: lw          $t3, 0x0($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X0);
    // 0x802B24F4: lh          $t7, 0x18($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X18);
    // 0x802B24F8: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x802B24FC: sh          $t7, 0x30C($t3)
    MEM_H(0X30C, ctx->r11) = ctx->r15;
    // 0x802B2500: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x802B2504: jal         0x802B8AD8
    // 0x802B2508: sb          $t9, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r25;
    func_802B8AD8_6CA188(rdram, ctx);
        goto after_8;
    // 0x802B2508: sb          $t9, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r25;
    after_8:
    // 0x802B250C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B2510: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x802B2514: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B2518: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x802B251C: lhu         $a0, 0x9C($t5)
    ctx->r4 = MEM_HU(ctx->r13, 0X9C);
    // 0x802B2520: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x802B2524: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B2528: beq         $a0, $at, L_802B2548
    if (ctx->r4 == ctx->r1) {
        // 0x802B252C: addiu       $at, $zero, 0x13
        ctx->r1 = ADD32(0, 0X13);
            goto L_802B2548;
    }
    // 0x802B252C: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x802B2530: beq         $a0, $at, L_802B2548
    if (ctx->r4 == ctx->r1) {
        // 0x802B2534: nop
    
            goto L_802B2548;
    }
    // 0x802B2534: nop

    // 0x802B2538: beq         $a0, $zero, L_802B2548
    if (ctx->r4 == 0) {
        // 0x802B253C: addiu       $at, $zero, 0x19
        ctx->r1 = ADD32(0, 0X19);
            goto L_802B2548;
    }
    // 0x802B253C: addiu       $at, $zero, 0x19
    ctx->r1 = ADD32(0, 0X19);
    // 0x802B2540: bnel        $a0, $at, L_802B2558
    if (ctx->r4 != ctx->r1) {
        // 0x802B2544: lh          $t6, 0x2E($sp)
        ctx->r14 = MEM_H(ctx->r29, 0X2E);
            goto L_802B2558;
    }
    goto skip_13;
    // 0x802B2544: lh          $t6, 0x2E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2E);
    skip_13:
L_802B2548:
    // 0x802B2548: lw          $t2, 0x5528($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5528);
    // 0x802B254C: addiu       $t8, $zero, 0xD
    ctx->r24 = ADD32(0, 0XD);
    // 0x802B2550: sh          $t8, 0x3C4($t2)
    MEM_H(0X3C4, ctx->r10) = ctx->r24;
L_802B2554:
    // 0x802B2554: lh          $t6, 0x2E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2E);
L_802B2558:
    // 0x802B2558: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B255C: lh          $t7, 0x2A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2A);
    // 0x802B2560: bnel        $t6, $at, L_802B2574
    if (ctx->r14 != ctx->r1) {
        // 0x802B2564: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B2574;
    }
    goto skip_14;
    // 0x802B2564: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_14:
    // 0x802B2568: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x802B256C: sh          $t7, 0x2C($t3)
    MEM_H(0X2C, ctx->r11) = ctx->r15;
    // 0x802B2570: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2574:
    // 0x802B2574: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802B2578: jr          $ra
    // 0x802B257C: nop

    return;
    // 0x802B257C: nop

;}
RECOMP_FUNC void get_distance_from_ground(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2580: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B2584: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B2588: jal         0x802B25B4
    // 0x802B258C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_802B25B4_6C3C64(rdram, ctx);
        goto after_0;
    // 0x802B258C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_0:
    // 0x802B2590: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B2594: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B2598: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B259C: lh          $t7, 0xC($t6)
    ctx->r15 = MEM_H(ctx->r14, 0XC);
    // 0x802B25A0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B25A4: subu        $v0, $t7, $v0
    ctx->r2 = SUB32(ctx->r15, ctx->r2);
    // 0x802B25A8: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B25AC: jr          $ra
    // 0x802B25B0: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    return;
    // 0x802B25B0: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
;}
RECOMP_FUNC void func_802B25B4_6C3C64(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B25B4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B25B8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B25BC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802B25C0: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x802B25C4: lh          $a1, 0x4($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X4);
    // 0x802B25C8: lh          $a3, 0x8($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X8);
    // 0x802B25CC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802B25D0: sra         $v1, $a1, 6
    ctx->r3 = S32(SIGNED(ctx->r5) >> 6);
    // 0x802B25D4: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802B25D8: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B25DC: lbu         $t7, 0x160($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X160);
    // 0x802B25E0: sra         $a2, $a3, 6
    ctx->r6 = S32(SIGNED(ctx->r7) >> 6);
    // 0x802B25E4: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802B25E8: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B25EC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B25F0: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802B25F4: bne         $t7, $at, L_802B26B4
    if (ctx->r15 != ctx->r1) {
        // 0x802B25F8: or          $a2, $t6, $zero
        ctx->r6 = ctx->r14 | 0;
            goto L_802B26B4;
    }
    // 0x802B25F8: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x802B25FC: sll         $t8, $t8, 7
    ctx->r24 = S32(ctx->r24 << 7);
    // 0x802B2600: addu        $t8, $t8, $v1
    ctx->r24 = ADD32(ctx->r24, ctx->r3);
    // 0x802B2604: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802B2608: sll         $t9, $t6, 3
    ctx->r25 = S32(ctx->r14 << 3);
    // 0x802B260C: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x802B2610: addiu       $t7, $t7, 0x740
    ctx->r15 = ADD32(ctx->r15, 0X740);
    // 0x802B2614: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x802B2618: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x802B261C: lbu         $a1, 0x1($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X1);
    // 0x802B2620: lbu         $a3, 0x409($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0X409);
    // 0x802B2624: slt         $at, $a1, $a3
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B2628: beq         $at, $zero, L_802B2638
    if (ctx->r1 == 0) {
        // 0x802B262C: or          $v1, $a3, $zero
        ctx->r3 = ctx->r7 | 0;
            goto L_802B2638;
    }
    // 0x802B262C: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x802B2630: b           L_802B2638
    // 0x802B2634: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802B2638;
    // 0x802B2634: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802B2638:
    // 0x802B2638: lbu         $a2, 0x9($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X9);
    // 0x802B263C: lbu         $t0, 0x411($v0)
    ctx->r8 = MEM_BU(ctx->r2, 0X411);
    // 0x802B2640: slt         $at, $a2, $t0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802B2644: beq         $at, $zero, L_802B2654
    if (ctx->r1 == 0) {
        // 0x802B2648: or          $t1, $t0, $zero
        ctx->r9 = ctx->r8 | 0;
            goto L_802B2654;
    }
    // 0x802B2648: or          $t1, $t0, $zero
    ctx->r9 = ctx->r8 | 0;
    // 0x802B264C: b           L_802B2654
    // 0x802B2650: or          $t1, $a2, $zero
    ctx->r9 = ctx->r6 | 0;
        goto L_802B2654;
    // 0x802B2650: or          $t1, $a2, $zero
    ctx->r9 = ctx->r6 | 0;
L_802B2654:
    // 0x802B2654: slt         $at, $v1, $t1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B2658: beq         $at, $zero, L_802B2688
    if (ctx->r1 == 0) {
        // 0x802B265C: slt         $at, $a1, $a3
        ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r7) ? 1 : 0;
            goto L_802B2688;
    }
    // 0x802B265C: slt         $at, $a1, $a3
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B2660: beq         $at, $zero, L_802B2678
    if (ctx->r1 == 0) {
        // 0x802B2664: or          $v1, $a3, $zero
        ctx->r3 = ctx->r7 | 0;
            goto L_802B2678;
    }
    // 0x802B2664: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x802B2668: sll         $a1, $a1, 16
    ctx->r5 = S32(ctx->r5 << 16);
    // 0x802B266C: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B2670: b           L_802B27DC
    // 0x802B2674: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
        goto L_802B27DC;
    // 0x802B2674: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
L_802B2678:
    // 0x802B2678: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802B267C: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B2680: b           L_802B27DC
    // 0x802B2684: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
        goto L_802B27DC;
    // 0x802B2684: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
L_802B2688:
    // 0x802B2688: slt         $at, $a2, $t0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802B268C: beq         $at, $zero, L_802B26A4
    if (ctx->r1 == 0) {
        // 0x802B2690: or          $v1, $t0, $zero
        ctx->r3 = ctx->r8 | 0;
            goto L_802B26A4;
    }
    // 0x802B2690: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
    // 0x802B2694: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
    // 0x802B2698: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B269C: b           L_802B27DC
    // 0x802B26A0: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
        goto L_802B27DC;
    // 0x802B26A0: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802B26A4:
    // 0x802B26A4: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802B26A8: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B26AC: b           L_802B27DC
    // 0x802B26B0: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
        goto L_802B27DC;
    // 0x802B26B0: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802B26B4:
    // 0x802B26B4: andi        $t0, $a1, 0x3F
    ctx->r8 = ctx->r5 & 0X3F;
    // 0x802B26B8: sll         $t6, $t0, 16
    ctx->r14 = S32(ctx->r8 << 16);
    // 0x802B26BC: sra         $t0, $t6, 16
    ctx->r8 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B26C0: andi        $t1, $a3, 0x3F
    ctx->r9 = ctx->r7 & 0X3F;
    // 0x802B26C4: sll         $t6, $v1, 7
    ctx->r14 = S32(ctx->r3 << 7);
    // 0x802B26C8: sll         $t8, $t1, 16
    ctx->r24 = S32(ctx->r9 << 16);
    // 0x802B26CC: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x802B26D0: sra         $t1, $t8, 16
    ctx->r9 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B26D4: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802B26D8: sll         $t7, $a2, 3
    ctx->r15 = S32(ctx->r6 << 3);
    // 0x802B26DC: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x802B26E0: addiu       $t9, $t9, 0x740
    ctx->r25 = ADD32(ctx->r25, 0X740);
    // 0x802B26E4: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B26E8: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x802B26EC: lbu         $t6, 0x4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X4);
    // 0x802B26F0: lbu         $t2, 0x0($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X0);
    // 0x802B26F4: lbu         $t3, 0x8($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X8);
    // 0x802B26F8: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x802B26FC: lbu         $t4, 0x408($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X408);
    // 0x802B2700: beq         $t7, $zero, L_802B2734
    if (ctx->r15 == 0) {
        // 0x802B2704: lbu         $t5, 0x410($v0)
        ctx->r13 = MEM_BU(ctx->r2, 0X410);
            goto L_802B2734;
    }
    // 0x802B2704: lbu         $t5, 0x410($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X410);
    // 0x802B2708: slt         $at, $t0, $t1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B270C: beql        $at, $zero, L_802B2728
    if (ctx->r1 == 0) {
        // 0x802B2710: sll         $t3, $t2, 16
        ctx->r11 = S32(ctx->r10 << 16);
            goto L_802B2728;
    }
    goto skip_0;
    // 0x802B2710: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    skip_0:
    // 0x802B2714: sll         $t4, $t2, 16
    ctx->r12 = S32(ctx->r10 << 16);
    // 0x802B2718: sra         $t8, $t4, 16
    ctx->r24 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802B271C: b           L_802B2760
    // 0x802B2720: or          $t4, $t8, $zero
    ctx->r12 = ctx->r24 | 0;
        goto L_802B2760;
    // 0x802B2720: or          $t4, $t8, $zero
    ctx->r12 = ctx->r24 | 0;
    // 0x802B2724: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
L_802B2728:
    // 0x802B2728: sra         $t9, $t3, 16
    ctx->r25 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802B272C: b           L_802B2760
    // 0x802B2730: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
        goto L_802B2760;
    // 0x802B2730: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
L_802B2734:
    // 0x802B2734: addu        $t6, $t0, $t1
    ctx->r14 = ADD32(ctx->r8, ctx->r9);
    // 0x802B2738: slti        $at, $t6, 0x40
    ctx->r1 = SIGNED(ctx->r14) < 0X40 ? 1 : 0;
    // 0x802B273C: beql        $at, $zero, L_802B2758
    if (ctx->r1 == 0) {
        // 0x802B2740: sll         $t2, $t5, 16
        ctx->r10 = S32(ctx->r13 << 16);
            goto L_802B2758;
    }
    goto skip_1;
    // 0x802B2740: sll         $t2, $t5, 16
    ctx->r10 = S32(ctx->r13 << 16);
    skip_1:
    // 0x802B2744: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x802B2748: sra         $t7, $t5, 16
    ctx->r15 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B274C: b           L_802B2760
    // 0x802B2750: or          $t5, $t7, $zero
    ctx->r13 = ctx->r15 | 0;
        goto L_802B2760;
    // 0x802B2750: or          $t5, $t7, $zero
    ctx->r13 = ctx->r15 | 0;
    // 0x802B2754: sll         $t2, $t5, 16
    ctx->r10 = S32(ctx->r13 << 16);
L_802B2758:
    // 0x802B2758: sra         $t8, $t2, 16
    ctx->r24 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802B275C: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
L_802B2760:
    // 0x802B2760: slt         $at, $t2, $t4
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802B2764: beq         $at, $zero, L_802B2774
    if (ctx->r1 == 0) {
        // 0x802B2768: or          $v1, $t4, $zero
        ctx->r3 = ctx->r12 | 0;
            goto L_802B2774;
    }
    // 0x802B2768: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x802B276C: b           L_802B2774
    // 0x802B2770: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
        goto L_802B2774;
    // 0x802B2770: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
L_802B2774:
    // 0x802B2774: slt         $at, $t3, $t5
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B2778: beq         $at, $zero, L_802B2788
    if (ctx->r1 == 0) {
        // 0x802B277C: or          $t1, $t5, $zero
        ctx->r9 = ctx->r13 | 0;
            goto L_802B2788;
    }
    // 0x802B277C: or          $t1, $t5, $zero
    ctx->r9 = ctx->r13 | 0;
    // 0x802B2780: b           L_802B2788
    // 0x802B2784: or          $t1, $t3, $zero
    ctx->r9 = ctx->r11 | 0;
        goto L_802B2788;
    // 0x802B2784: or          $t1, $t3, $zero
    ctx->r9 = ctx->r11 | 0;
L_802B2788:
    // 0x802B2788: slt         $at, $v1, $t1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B278C: beq         $at, $zero, L_802B27BC
    if (ctx->r1 == 0) {
        // 0x802B2790: slt         $at, $t2, $t4
        ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r12) ? 1 : 0;
            goto L_802B27BC;
    }
    // 0x802B2790: slt         $at, $t2, $t4
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802B2794: beq         $at, $zero, L_802B27AC
    if (ctx->r1 == 0) {
        // 0x802B2798: or          $v1, $t4, $zero
        ctx->r3 = ctx->r12 | 0;
            goto L_802B27AC;
    }
    // 0x802B2798: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x802B279C: sll         $a1, $t2, 16
    ctx->r5 = S32(ctx->r10 << 16);
    // 0x802B27A0: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B27A4: b           L_802B27DC
    // 0x802B27A8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
        goto L_802B27DC;
    // 0x802B27A8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802B27AC:
    // 0x802B27AC: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802B27B0: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B27B4: b           L_802B27DC
    // 0x802B27B8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
        goto L_802B27DC;
    // 0x802B27B8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802B27BC:
    // 0x802B27BC: slt         $at, $t3, $t5
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B27C0: beq         $at, $zero, L_802B27D0
    if (ctx->r1 == 0) {
        // 0x802B27C4: or          $v1, $t5, $zero
        ctx->r3 = ctx->r13 | 0;
            goto L_802B27D0;
    }
    // 0x802B27C4: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x802B27C8: b           L_802B27D0
    // 0x802B27CC: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
        goto L_802B27D0;
    // 0x802B27CC: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
L_802B27D0:
    // 0x802B27D0: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802B27D4: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B27D8: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
L_802B27DC:
    // 0x802B27DC: beql        $a0, $zero, L_802B2824
    if (ctx->r4 == 0) {
        // 0x802B27E0: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802B2824;
    }
    goto skip_2;
    // 0x802B27E0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    skip_2:
    // 0x802B27E4: lbu         $v1, 0x6($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X6);
    // 0x802B27E8: sll         $a0, $a1, 3
    ctx->r4 = S32(ctx->r5 << 3);
    // 0x802B27EC: sll         $v0, $a0, 16
    ctx->r2 = S32(ctx->r4 << 16);
    // 0x802B27F0: sll         $t7, $v1, 2
    ctx->r15 = S32(ctx->r3 << 2);
    // 0x802B27F4: slt         $at, $t7, $a0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802B27F8: beq         $at, $zero, L_802B280C
    if (ctx->r1 == 0) {
        // 0x802B27FC: or          $v1, $t7, $zero
        ctx->r3 = ctx->r15 | 0;
            goto L_802B280C;
    }
    // 0x802B27FC: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x802B2800: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B2804: jr          $ra
    // 0x802B2808: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    return;
    // 0x802B2808: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
L_802B280C:
    // 0x802B280C: or          $t1, $v1, $zero
    ctx->r9 = ctx->r3 | 0;
    // 0x802B2810: sll         $v0, $t1, 16
    ctx->r2 = S32(ctx->r9 << 16);
    // 0x802B2814: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B2818: jr          $ra
    // 0x802B281C: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    return;
    // 0x802B281C: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x802B2820: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802B2824:
    // 0x802B2824: sll         $t9, $v0, 19
    ctx->r25 = S32(ctx->r2 << 19);
    // 0x802B2828: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B282C: jr          $ra
    // 0x802B2830: nop

    return;
    // 0x802B2830: nop

;}
RECOMP_FUNC void func_802B2834_6C3EE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2834: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B2838: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B283C: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802B2840: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B2844: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x802B2848: lh          $t8, 0x8($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X8);
    // 0x802B284C: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x802B2850: sra         $a0, $a3, 6
    ctx->r4 = S32(SIGNED(ctx->r7) >> 6);
    // 0x802B2854: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802B2858: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B285C: sra         $t9, $t8, 6
    ctx->r25 = S32(SIGNED(ctx->r24) >> 6);
    // 0x802B2860: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x802B2864: sll         $t2, $t7, 7
    ctx->r10 = S32(ctx->r15 << 7);
    // 0x802B2868: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B286C: addu        $t2, $t2, $t7
    ctx->r10 = ADD32(ctx->r10, ctx->r15);
    // 0x802B2870: sll         $t2, $t2, 3
    ctx->r10 = S32(ctx->r10 << 3);
    // 0x802B2874: sll         $t3, $t1, 3
    ctx->r11 = S32(ctx->r9 << 3);
    // 0x802B2878: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x802B287C: addiu       $t5, $t5, 0x740
    ctx->r13 = ADD32(ctx->r13, 0X740);
    // 0x802B2880: addu        $v0, $t4, $t5
    ctx->r2 = ADD32(ctx->r12, ctx->r13);
    // 0x802B2884: lbu         $t6, 0x6($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X6);
    // 0x802B2888: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802B288C: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802B2890: bne         $t6, $zero, L_802B28B8
    if (ctx->r14 != 0) {
        // 0x802B2894: sw          $t8, 0x20($sp)
        MEM_W(0X20, ctx->r29) = ctx->r24;
            goto L_802B28B8;
    }
    // 0x802B2894: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x802B2898: lbu         $t7, 0x40E($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X40E);
    // 0x802B289C: bne         $t7, $zero, L_802B28B8
    if (ctx->r15 != 0) {
        // 0x802B28A0: nop
    
            goto L_802B28B8;
    }
    // 0x802B28A0: nop

    // 0x802B28A4: lbu         $t8, 0xE($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0XE);
    // 0x802B28A8: bne         $t8, $zero, L_802B28B8
    if (ctx->r24 != 0) {
        // 0x802B28AC: nop
    
            goto L_802B28B8;
    }
    // 0x802B28AC: nop

    // 0x802B28B0: lbu         $t9, 0x416($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X416);
    // 0x802B28B4: beq         $t9, $zero, L_802B2954
    if (ctx->r25 == 0) {
        // 0x802B28B8: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802B2954;
    }
L_802B28B8:
    // 0x802B28B8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B28BC: lw          $v0, 0x5524($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5524);
    // 0x802B28C0: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x802B28C4: lh          $a1, 0x22($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X22);
    // 0x802B28C8: lhu         $t0, 0xA0($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0XA0);
    // 0x802B28CC: andi        $t1, $t0, 0xC00
    ctx->r9 = ctx->r8 & 0XC00;
    // 0x802B28D0: beql        $t1, $zero, L_802B28E4
    if (ctx->r9 == 0) {
        // 0x802B28D4: lh          $a2, 0xB8($v0)
        ctx->r6 = MEM_H(ctx->r2, 0XB8);
            goto L_802B28E4;
    }
    goto skip_0;
    // 0x802B28D4: lh          $a2, 0xB8($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XB8);
    skip_0:
    // 0x802B28D8: b           L_802B28E4
    // 0x802B28DC: lh          $a2, 0xBA($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XBA);
        goto L_802B28E4;
    // 0x802B28DC: lh          $a2, 0xBA($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XBA);
    // 0x802B28E0: lh          $a2, 0xB8($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XB8);
L_802B28E4:
    // 0x802B28E4: jal         0x80298F78
    // 0x802B28E8: sh          $a2, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r6;
    func_80298F78_6AA628(rdram, ctx);
        goto after_0;
    // 0x802B28E8: sh          $a2, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r6;
    after_0:
    // 0x802B28EC: beq         $v0, $zero, L_802B2954
    if (ctx->r2 == 0) {
        // 0x802B28F0: lh          $a2, 0x2E($sp)
        ctx->r6 = MEM_H(ctx->r29, 0X2E);
            goto L_802B2954;
    }
    // 0x802B28F0: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B28F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B28F8: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B28FC: lh          $t3, 0xC($v1)
    ctx->r11 = MEM_H(ctx->r3, 0XC);
    // 0x802B2900: addu        $t4, $t3, $a2
    ctx->r12 = ADD32(ctx->r11, ctx->r6);
    // 0x802B2904: slt         $at, $t4, $v0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B2908: beql        $at, $zero, L_802B2958
    if (ctx->r1 == 0) {
        // 0x802B290C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_802B2958;
    }
    goto skip_1;
    // 0x802B290C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x802B2910: lhu         $t5, 0x0($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X0);
    // 0x802B2914: addiu       $at, $zero, 0xDD
    ctx->r1 = ADD32(0, 0XDD);
    // 0x802B2918: beq         $t5, $at, L_802B2928
    if (ctx->r13 == ctx->r1) {
        // 0x802B291C: nop
    
            goto L_802B2928;
    }
    // 0x802B291C: nop

    // 0x802B2920: jal         0x802B315C
    // 0x802B2924: nop

    func_802B315C_6C480C(rdram, ctx);
        goto after_1;
    // 0x802B2924: nop

    after_1:
L_802B2928:
    // 0x802B2928: jal         0x802B8B1C
    // 0x802B292C: nop

    func_802B8B1C_6CA1CC(rdram, ctx);
        goto after_2;
    // 0x802B292C: nop

    after_2:
    // 0x802B2930: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B2934: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x802B2938: lh          $t6, 0x24($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X24);
    // 0x802B293C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802B2940: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x802B2944: lh          $a2, 0xC($v1)
    ctx->r6 = MEM_H(ctx->r3, 0XC);
    // 0x802B2948: lh          $a3, 0x30($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X30);
    // 0x802B294C: jal         0x802D760C
    // 0x802B2950: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_802D760C_6E8CBC(rdram, ctx);
        goto after_3;
    // 0x802B2950: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_3:
L_802B2954:
    // 0x802B2954: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_802B2958:
    // 0x802B2958: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802B295C: jr          $ra
    // 0x802B2960: nop

    return;
    // 0x802B2960: nop

;}
RECOMP_FUNC void func_802B2964_6C4014(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2964: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2968: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B296C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B2970: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B2974: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802B2978: jal         0x80298F78
    // 0x802B297C: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    func_80298F78_6AA628(rdram, ctx);
        goto after_0;
    // 0x802B297C: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    after_0:
    // 0x802B2980: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B2984: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x802B2988: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802B298C: sra         $t6, $t0, 16
    ctx->r14 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B2990: lhu         $t7, 0xA0($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0XA0);
    // 0x802B2994: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x802B2998: andi        $t8, $t7, 0xC00
    ctx->r24 = ctx->r15 & 0XC00;
    // 0x802B299C: beql        $t8, $zero, L_802B29B0
    if (ctx->r24 == 0) {
        // 0x802B29A0: lh          $a3, 0xB8($v1)
        ctx->r7 = MEM_H(ctx->r3, 0XB8);
            goto L_802B29B0;
    }
    goto skip_0;
    // 0x802B29A0: lh          $a3, 0xB8($v1)
    ctx->r7 = MEM_H(ctx->r3, 0XB8);
    skip_0:
    // 0x802B29A4: b           L_802B29B0
    // 0x802B29A8: lh          $a3, 0xBA($v1)
    ctx->r7 = MEM_H(ctx->r3, 0XBA);
        goto L_802B29B0;
    // 0x802B29A8: lh          $a3, 0xBA($v1)
    ctx->r7 = MEM_H(ctx->r3, 0XBA);
    // 0x802B29AC: lh          $a3, 0xB8($v1)
    ctx->r7 = MEM_H(ctx->r3, 0XB8);
L_802B29B0:
    // 0x802B29B0: beq         $v0, $zero, L_802B29F0
    if (ctx->r2 == 0) {
        // 0x802B29B4: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802B29F0;
    }
    // 0x802B29B4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B29B8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B29BC: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802B29C0: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802B29C4: lbu         $a2, 0x160($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X160);
    // 0x802B29C8: sh          $t0, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r8;
    // 0x802B29CC: jal         0x80310EE4
    // 0x802B29D0: sh          $a3, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r7;
    func_80310EE4_722594(rdram, ctx);
        goto after_1;
    // 0x802B29D0: sh          $a3, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r7;
    after_1:
    // 0x802B29D4: lh          $a3, 0x1E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X1E);
    // 0x802B29D8: lh          $t0, 0x1C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X1C);
    // 0x802B29DC: sra         $t9, $v0, 16
    ctx->r25 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B29E0: addu        $t1, $t9, $a3
    ctx->r9 = ADD32(ctx->r25, ctx->r7);
    // 0x802B29E4: slt         $at, $t0, $t1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B29E8: beq         $at, $zero, L_802B2A00
    if (ctx->r1 == 0) {
        // 0x802B29EC: lui         $t2, 0x803D
        ctx->r10 = S32(0X803D << 16);
            goto L_802B2A00;
    }
    // 0x802B29EC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
L_802B29F0:
    // 0x802B29F0: jal         0x802B2EA8
    // 0x802B29F4: nop

    func_802B2EA8_6C4558(rdram, ctx);
        goto after_2;
    // 0x802B29F4: nop

    after_2:
    // 0x802B29F8: b           L_802B2AE4
    // 0x802B29FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802B2AE4;
    // 0x802B29FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2A00:
    // 0x802B2A00: lbu         $t2, 0x5538($t2)
    ctx->r10 = MEM_BU(ctx->r10, 0X5538);
    // 0x802B2A04: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802B2A08: beq         $t2, $zero, L_802B2AB8
    if (ctx->r10 == 0) {
        // 0x802B2A0C: nop
    
            goto L_802B2AB8;
    }
    // 0x802B2A0C: nop

    // 0x802B2A10: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x802B2A14: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x802B2A18: addiu       $v1, $v1, -0x6128
    ctx->r3 = ADD32(ctx->r3, -0X6128);
    // 0x802B2A1C: lhu         $v0, 0x9E($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X9E);
    // 0x802B2A20: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x802B2A24: addiu       $t4, $v1, 0x7FFF
    ctx->r12 = ADD32(ctx->r3, 0X7FFF);
    // 0x802B2A28: bne         $v0, $at, L_802B2A48
    if (ctx->r2 != ctx->r1) {
        // 0x802B2A2C: nop
    
            goto L_802B2A48;
    }
    // 0x802B2A2C: nop

    // 0x802B2A30: lhu         $t4, 0x7FB9($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X7FB9);
    // 0x802B2A34: addiu       $t5, $v1, 0x7FFF
    ctx->r13 = ADD32(ctx->r3, 0X7FFF);
    // 0x802B2A38: bne         $t4, $zero, L_802B2A48
    if (ctx->r12 != 0) {
        // 0x802B2A3C: nop
    
            goto L_802B2A48;
    }
    // 0x802B2A3C: nop

    // 0x802B2A40: lhu         $t5, 0x7FB3($t5)
    ctx->r13 = MEM_HU(ctx->r13, 0X7FB3);
    // 0x802B2A44: bne         $t5, $zero, L_802B2A64
    if (ctx->r13 != 0) {
        // 0x802B2A48: lui         $v1, 0x801E
        ctx->r3 = S32(0X801E << 16);
            goto L_802B2A64;
    }
L_802B2A48:
    // 0x802B2A48: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x802B2A4C: addiu       $at, $zero, 0x80
    ctx->r1 = ADD32(0, 0X80);
    // 0x802B2A50: bne         $v0, $at, L_802B2AB8
    if (ctx->r2 != ctx->r1) {
        // 0x802B2A54: addiu       $v1, $v1, -0x6128
        ctx->r3 = ADD32(ctx->r3, -0X6128);
            goto L_802B2AB8;
    }
    // 0x802B2A54: addiu       $v1, $v1, -0x6128
    ctx->r3 = ADD32(ctx->r3, -0X6128);
    // 0x802B2A58: addiu       $t6, $v1, 0x7FFF
    ctx->r14 = ADD32(ctx->r3, 0X7FFF);
    // 0x802B2A5C: lhu         $t6, 0x7FB3($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X7FB3);
    // 0x802B2A60: beq         $t6, $zero, L_802B2AB8
    if (ctx->r14 == 0) {
        // 0x802B2A64: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802B2AB8;
    }
L_802B2A64:
    // 0x802B2A64: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B2A68: addiu       $a1, $a1, 0x5530
    ctx->r5 = ADD32(ctx->r5, 0X5530);
    // 0x802B2A6C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B2A70: subu        $a0, $t0, $a3
    ctx->r4 = SUB32(ctx->r8, ctx->r7);
    // 0x802B2A74: lh          $v1, 0xC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0XC);
    // 0x802B2A78: addu        $t7, $v1, $a3
    ctx->r15 = ADD32(ctx->r3, ctx->r7);
    // 0x802B2A7C: subu        $t8, $t7, $t0
    ctx->r24 = SUB32(ctx->r15, ctx->r8);
    // 0x802B2A80: slti        $at, $t8, -0x6
    ctx->r1 = SIGNED(ctx->r24) < -0X6 ? 1 : 0;
    // 0x802B2A84: bne         $at, $zero, L_802B2AB8
    if (ctx->r1 != 0) {
        // 0x802B2A88: slt         $at, $a0, $v1
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_802B2AB8;
    }
    // 0x802B2A88: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B2A8C: beql        $at, $zero, L_802B2AA0
    if (ctx->r1 == 0) {
        // 0x802B2A90: sh          $a0, 0xC($v0)
        MEM_H(0XC, ctx->r2) = ctx->r4;
            goto L_802B2AA0;
    }
    goto skip_1;
    // 0x802B2A90: sh          $a0, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r4;
    skip_1:
    // 0x802B2A94: b           L_802B2AA0
    // 0x802B2A98: sh          $v1, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r3;
        goto L_802B2AA0;
    // 0x802B2A98: sh          $v1, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r3;
    // 0x802B2A9C: sh          $a0, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r4;
L_802B2AA0:
    // 0x802B2AA0: lw          $t1, 0x0($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X0);
    // 0x802B2AA4: lui         $t9, 0x4
    ctx->r25 = S32(0X4 << 16);
    // 0x802B2AA8: sw          $t9, 0x24($t1)
    MEM_W(0X24, ctx->r9) = ctx->r25;
    // 0x802B2AAC: jal         0x802B2EA8
    // 0x802B2AB0: sh          $t0, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r8;
    func_802B2EA8_6C4558(rdram, ctx);
        goto after_3;
    // 0x802B2AB0: sh          $t0, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r8;
    after_3:
    // 0x802B2AB4: lh          $t0, 0x1C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X1C);
L_802B2AB8:
    // 0x802B2AB8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B2ABC: addiu       $a1, $a1, 0x5530
    ctx->r5 = ADD32(ctx->r5, 0X5530);
    // 0x802B2AC0: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
    // 0x802B2AC4: addiu       $t4, $t0, 0x10
    ctx->r12 = ADD32(ctx->r8, 0X10);
    // 0x802B2AC8: lh          $t3, 0xC($t2)
    ctx->r11 = MEM_H(ctx->r10, 0XC);
    // 0x802B2ACC: slt         $at, $t4, $t3
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B2AD0: beql        $at, $zero, L_802B2AE4
    if (ctx->r1 == 0) {
        // 0x802B2AD4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B2AE4;
    }
    goto skip_2;
    // 0x802B2AD4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802B2AD8: jal         0x802B2FF4
    // 0x802B2ADC: nop

    func_802B2FF4_6C46A4(rdram, ctx);
        goto after_4;
    // 0x802B2ADC: nop

    after_4:
    // 0x802B2AE0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2AE4:
    // 0x802B2AE4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802B2AE8: jr          $ra
    // 0x802B2AEC: nop

    return;
    // 0x802B2AEC: nop

;}
RECOMP_FUNC void func_802B2AF0_6C41A0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2AF0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B2AF4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B2AF8: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B2AFC: bgtz        $a0, L_802B2B44
    if (SIGNED(ctx->r4) > 0) {
        // 0x802B2B00: or          $a2, $a0, $zero
        ctx->r6 = ctx->r4 | 0;
            goto L_802B2B44;
    }
    // 0x802B2B00: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802B2B04: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2B08: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B2B0C: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802B2B10: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B2B14: lhu         $t8, 0xBE($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0XBE);
    // 0x802B2B18: lh          $t6, 0x4($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X4);
    // 0x802B2B1C: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802B2B20: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    // 0x802B2B24: subu        $a0, $t6, $t8
    ctx->r4 = SUB32(ctx->r14, ctx->r24);
    // 0x802B2B28: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x802B2B2C: jal         0x802B2C20
    // 0x802B2B30: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    func_802B2C20_6C42D0(rdram, ctx);
        goto after_0;
    // 0x802B2B30: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    after_0:
    // 0x802B2B34: beq         $v0, $zero, L_802B2B44
    if (ctx->r2 == 0) {
        // 0x802B2B38: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_802B2B44;
    }
    // 0x802B2B38: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x802B2B3C: b           L_802B2C10
    // 0x802B2B40: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2C10;
    // 0x802B2B40: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2B44:
    // 0x802B2B44: bltz        $a2, L_802B2B84
    if (SIGNED(ctx->r6) < 0) {
        // 0x802B2B48: lui         $t2, 0x803D
        ctx->r10 = S32(0X803D << 16);
            goto L_802B2B84;
    }
    // 0x802B2B48: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B2B4C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2B50: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B2B54: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x802B2B58: lh          $t1, 0x4($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X4);
    // 0x802B2B5C: lhu         $t3, 0xBE($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0XBE);
    // 0x802B2B60: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x802B2B64: addu        $a0, $t1, $t3
    ctx->r4 = ADD32(ctx->r9, ctx->r11);
    // 0x802B2B68: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x802B2B6C: jal         0x802B2C20
    // 0x802B2B70: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    func_802B2C20_6C42D0(rdram, ctx);
        goto after_1;
    // 0x802B2B70: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    after_1:
    // 0x802B2B74: beql        $v0, $zero, L_802B2B88
    if (ctx->r2 == 0) {
        // 0x802B2B78: lw          $t7, 0x1C($sp)
        ctx->r15 = MEM_W(ctx->r29, 0X1C);
            goto L_802B2B88;
    }
    goto skip_0;
    // 0x802B2B78: lw          $t7, 0x1C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x802B2B7C: b           L_802B2C10
    // 0x802B2B80: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2C10;
    // 0x802B2B80: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2B84:
    // 0x802B2B84: lw          $t7, 0x1C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X1C);
L_802B2B88:
    // 0x802B2B88: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B2B8C: bgtzl       $t7, L_802B2BD0
    if (SIGNED(ctx->r15) > 0) {
        // 0x802B2B90: lw          $t1, 0x1C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X1C);
            goto L_802B2BD0;
    }
    goto skip_1;
    // 0x802B2B90: lw          $t1, 0x1C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x802B2B94: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2B98: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B2B9C: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802B2BA0: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    // 0x802B2BA4: lhu         $t9, 0xBE($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0XBE);
    // 0x802B2BA8: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802B2BAC: subu        $a1, $t6, $t9
    ctx->r5 = SUB32(ctx->r14, ctx->r25);
    // 0x802B2BB0: sll         $t0, $a1, 16
    ctx->r8 = S32(ctx->r5 << 16);
    // 0x802B2BB4: jal         0x802B2C20
    // 0x802B2BB8: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
    func_802B2C20_6C42D0(rdram, ctx);
        goto after_2;
    // 0x802B2BB8: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
    after_2:
    // 0x802B2BBC: beql        $v0, $zero, L_802B2BD0
    if (ctx->r2 == 0) {
        // 0x802B2BC0: lw          $t1, 0x1C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X1C);
            goto L_802B2BD0;
    }
    goto skip_2;
    // 0x802B2BC0: lw          $t1, 0x1C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x802B2BC4: b           L_802B2C10
    // 0x802B2BC8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2C10;
    // 0x802B2BC8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802B2BCC: lw          $t1, 0x1C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X1C);
L_802B2BD0:
    // 0x802B2BD0: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B2BD4: bltzl       $t1, L_802B2C14
    if (SIGNED(ctx->r9) < 0) {
        // 0x802B2BD8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B2C14;
    }
    goto skip_3;
    // 0x802B2BD8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x802B2BDC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2BE0: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B2BE4: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x802B2BE8: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802B2BEC: lhu         $t5, 0xBE($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0XBE);
    // 0x802B2BF0: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x802B2BF4: addu        $a1, $t3, $t5
    ctx->r5 = ADD32(ctx->r11, ctx->r13);
    // 0x802B2BF8: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802B2BFC: jal         0x802B2C20
    // 0x802B2C00: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    func_802B2C20_6C42D0(rdram, ctx);
        goto after_3;
    // 0x802B2C00: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    after_3:
    // 0x802B2C04: beql        $v0, $zero, L_802B2C14
    if (ctx->r2 == 0) {
        // 0x802B2C08: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802B2C14;
    }
    goto skip_4;
    // 0x802B2C08: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x802B2C0C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2C10:
    // 0x802B2C10: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2C14:
    // 0x802B2C14: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B2C18: jr          $ra
    // 0x802B2C1C: nop

    return;
    // 0x802B2C1C: nop

;}
RECOMP_FUNC void func_802B2C20_6C42D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2C20: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802B2C24: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x802B2C28: lh          $t6, 0x5A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2C2C: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    // 0x802B2C30: lh          $t9, 0x5E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2C34: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x802B2C38: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802B2C3C: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802B2C40: sra         $t0, $t9, 6
    ctx->r8 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802B2C44: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x802B2C48: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802B2C4C: lui         $t3, 0x803C
    ctx->r11 = S32(0X803C << 16);
    // 0x802B2C50: addiu       $t3, $t3, 0x740
    ctx->r11 = ADD32(ctx->r11, 0X740);
    // 0x802B2C54: addu        $t2, $t8, $t1
    ctx->r10 = ADD32(ctx->r24, ctx->r9);
    // 0x802B2C58: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x802B2C5C: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802B2C60: lbu         $a2, 0x6($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X6);
    // 0x802B2C64: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B2C68: lh          $t5, 0x5E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2C6C: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802B2C70: beq         $at, $zero, L_802B2C80
    if (ctx->r1 == 0) {
        // 0x802B2C74: lh          $t4, 0x5A($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X5A);
            goto L_802B2C80;
    }
    // 0x802B2C74: lh          $t4, 0x5A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2C78: b           L_802B2C84
    // 0x802B2C7C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
        goto L_802B2C84;
    // 0x802B2C7C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
L_802B2C80:
    // 0x802B2C80: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
L_802B2C84:
    // 0x802B2C84: lbu         $a0, 0x416($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X416);
    // 0x802B2C88: lbu         $a1, 0xE($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0XE);
    // 0x802B2C8C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802B2C90: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802B2C94: beq         $at, $zero, L_802B2CA4
    if (ctx->r1 == 0) {
        // 0x802B2C98: nop
    
            goto L_802B2CA4;
    }
    // 0x802B2C98: nop

    // 0x802B2C9C: b           L_802B2CA4
    // 0x802B2CA0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802B2CA4;
    // 0x802B2CA0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802B2CA4:
    // 0x802B2CA4: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B2CA8: beq         $at, $zero, L_802B2CC8
    if (ctx->r1 == 0) {
        // 0x802B2CAC: slt         $at, $v1, $a2
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
            goto L_802B2CC8;
    }
    // 0x802B2CAC: slt         $at, $v1, $a2
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802B2CB0: beq         $at, $zero, L_802B2CC0
    if (ctx->r1 == 0) {
        // 0x802B2CB4: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802B2CC0;
    }
    // 0x802B2CB4: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802B2CB8: b           L_802B2CE0
    // 0x802B2CBC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802B2CE0;
    // 0x802B2CBC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802B2CC0:
    // 0x802B2CC0: b           L_802B2CE0
    // 0x802B2CC4: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
        goto L_802B2CE0;
    // 0x802B2CC4: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_802B2CC8:
    // 0x802B2CC8: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802B2CCC: beq         $at, $zero, L_802B2CDC
    if (ctx->r1 == 0) {
        // 0x802B2CD0: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802B2CDC;
    }
    // 0x802B2CD0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802B2CD4: b           L_802B2CDC
    // 0x802B2CD8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802B2CDC;
    // 0x802B2CD8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802B2CDC:
    // 0x802B2CDC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802B2CE0:
    // 0x802B2CE0: multu       $t4, $t5
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B2CE4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x802B2CE8: addiu       $a1, $a1, 0x430
    ctx->r5 = ADD32(ctx->r5, 0X430);
    // 0x802B2CEC: lhu         $t0, 0x204($a1)
    ctx->r8 = MEM_HU(ctx->r5, 0X204);
    // 0x802B2CF0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B2CF4: lw          $a0, 0x5524($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5524);
    // 0x802B2CF8: mflo        $v1
    ctx->r3 = lo;
    // 0x802B2CFC: andi        $t3, $v1, 0x7
    ctx->r11 = ctx->r3 & 0X7;
    // 0x802B2D00: sll         $t5, $t3, 6
    ctx->r13 = S32(ctx->r11 << 6);
    // 0x802B2D04: multu       $t4, $t4
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B2D08: addu        $t4, $a1, $t5
    ctx->r12 = ADD32(ctx->r5, ctx->r13);
    // 0x802B2D0C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B2D10: mflo        $t6
    ctx->r14 = lo;
    // 0x802B2D14: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x802B2D18: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x802B2D1C: addu        $t1, $t0, $t9
    ctx->r9 = ADD32(ctx->r8, ctx->r25);
    // 0x802B2D20: andi        $t2, $t1, 0x3F
    ctx->r10 = ctx->r9 & 0X3F;
    // 0x802B2D24: addu        $t6, $t4, $t2
    ctx->r14 = ADD32(ctx->r12, ctx->r10);
    // 0x802B2D28: lb          $t7, 0x0($t6)
    ctx->r15 = MEM_B(ctx->r14, 0X0);
    // 0x802B2D2C: lhu         $t1, 0xA0($a0)
    ctx->r9 = MEM_HU(ctx->r4, 0XA0);
    // 0x802B2D30: sll         $t0, $v0, 2
    ctx->r8 = S32(ctx->r2 << 2);
    // 0x802B2D34: addu        $a3, $t7, $t0
    ctx->r7 = ADD32(ctx->r15, ctx->r8);
    // 0x802B2D38: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x802B2D3C: andi        $t3, $t1, 0xC00
    ctx->r11 = ctx->r9 & 0XC00;
    // 0x802B2D40: beq         $t3, $zero, L_802B2D50
    if (ctx->r11 == 0) {
        // 0x802B2D44: sra         $a3, $t9, 16
        ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
            goto L_802B2D50;
    }
    // 0x802B2D44: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B2D48: b           L_802B2D54
    // 0x802B2D4C: lh          $v1, 0xBA($a0)
    ctx->r3 = MEM_H(ctx->r4, 0XBA);
        goto L_802B2D54;
    // 0x802B2D4C: lh          $v1, 0xBA($a0)
    ctx->r3 = MEM_H(ctx->r4, 0XBA);
L_802B2D50:
    // 0x802B2D50: lh          $v1, 0xB8($a0)
    ctx->r3 = MEM_H(ctx->r4, 0XB8);
L_802B2D54:
    // 0x802B2D54: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B2D58: lh          $a0, 0x5A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2D5C: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2D60: lbu         $a2, 0x160($t5)
    ctx->r6 = MEM_BU(ctx->r13, 0X160);
    // 0x802B2D64: sh          $a3, 0x50($sp)
    MEM_H(0X50, ctx->r29) = ctx->r7;
    // 0x802B2D68: jal         0x80310EE4
    // 0x802B2D6C: sh          $v1, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r3;
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x802B2D6C: sh          $v1, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r3;
    after_0:
    // 0x802B2D70: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x802B2D74: lh          $v1, 0x52($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X52);
    // 0x802B2D78: bne         $v0, $at, L_802B2E14
    if (ctx->r2 != ctx->r1) {
        // 0x802B2D7C: lh          $a3, 0x50($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X50);
            goto L_802B2E14;
    }
    // 0x802B2D7C: lh          $a3, 0x50($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X50);
    // 0x802B2D80: lh          $a0, 0x5A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2D84: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2D88: sh          $v1, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r3;
    // 0x802B2D8C: jal         0x8031124C
    // 0x802B2D90: sh          $a3, 0x50($sp)
    MEM_H(0X50, ctx->r29) = ctx->r7;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_1;
    // 0x802B2D90: sh          $a3, 0x50($sp)
    MEM_H(0X50, ctx->r29) = ctx->r7;
    after_1:
    // 0x802B2D94: lh          $v1, 0x52($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X52);
    // 0x802B2D98: lh          $a3, 0x50($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X50);
    // 0x802B2D9C: sra         $t4, $v0, 16
    ctx->r12 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B2DA0: addu        $t2, $t4, $v1
    ctx->r10 = ADD32(ctx->r12, ctx->r3);
    // 0x802B2DA4: slt         $at, $a3, $t2
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802B2DA8: beq         $at, $zero, L_802B2E0C
    if (ctx->r1 == 0) {
        // 0x802B2DAC: lh          $a0, 0x5A($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X5A);
            goto L_802B2E0C;
    }
    // 0x802B2DAC: lh          $a0, 0x5A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2DB0: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2DB4: addiu       $a2, $sp, 0x4E
    ctx->r6 = ADD32(ctx->r29, 0X4E);
    // 0x802B2DB8: jal         0x80311BF8
    // 0x802B2DBC: addiu       $a3, $sp, 0x4C
    ctx->r7 = ADD32(ctx->r29, 0X4C);
    func_80311BF8_7232A8(rdram, ctx);
        goto after_2;
    // 0x802B2DBC: addiu       $a3, $sp, 0x4C
    ctx->r7 = ADD32(ctx->r29, 0X4C);
    after_2:
    // 0x802B2DC0: lh          $v1, 0x4E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X4E);
    // 0x802B2DC4: bgez        $v1, L_802B2DD4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B2DC8: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802B2DD4;
    }
    // 0x802B2DC8: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802B2DCC: b           L_802B2DD4
    // 0x802B2DD0: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802B2DD4;
    // 0x802B2DD0: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802B2DD4:
    // 0x802B2DD4: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802B2DD8: bne         $at, $zero, L_802B2DE8
    if (ctx->r1 != 0) {
        // 0x802B2DDC: lh          $v1, 0x4C($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X4C);
            goto L_802B2DE8;
    }
    // 0x802B2DDC: lh          $v1, 0x4C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X4C);
    // 0x802B2DE0: b           L_802B2E98
    // 0x802B2DE4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2E98;
    // 0x802B2DE4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2DE8:
    // 0x802B2DE8: bgez        $v1, L_802B2DF8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B2DEC: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802B2DF8;
    }
    // 0x802B2DEC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802B2DF0: b           L_802B2DF8
    // 0x802B2DF4: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802B2DF8;
    // 0x802B2DF4: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802B2DF8:
    // 0x802B2DF8: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802B2DFC: bne         $at, $zero, L_802B2E0C
    if (ctx->r1 != 0) {
        // 0x802B2E00: nop
    
            goto L_802B2E0C;
    }
    // 0x802B2E00: nop

    // 0x802B2E04: b           L_802B2E98
    // 0x802B2E08: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2E98;
    // 0x802B2E08: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2E0C:
    // 0x802B2E0C: b           L_802B2E98
    // 0x802B2E10: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802B2E98;
    // 0x802B2E10: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802B2E14:
    // 0x802B2E14: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B2E18: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x802B2E1C: slt         $at, $a3, $t7
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802B2E20: beq         $at, $zero, L_802B2E94
    if (ctx->r1 == 0) {
        // 0x802B2E24: lh          $a0, 0x5A($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X5A);
            goto L_802B2E94;
    }
    // 0x802B2E24: lh          $a0, 0x5A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5A);
    // 0x802B2E28: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B2E2C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x802B2E30: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    // 0x802B2E34: addiu       $a2, $sp, 0x4E
    ctx->r6 = ADD32(ctx->r29, 0X4E);
    // 0x802B2E38: lbu         $t9, 0x160($t0)
    ctx->r25 = MEM_BU(ctx->r8, 0X160);
    // 0x802B2E3C: addiu       $a3, $sp, 0x4C
    ctx->r7 = ADD32(ctx->r29, 0X4C);
    // 0x802B2E40: jal         0x80311A2C
    // 0x802B2E44: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_80311A2C_7230DC(rdram, ctx);
        goto after_3;
    // 0x802B2E44: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_3:
    // 0x802B2E48: lh          $v1, 0x4E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X4E);
    // 0x802B2E4C: bgez        $v1, L_802B2E5C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B2E50: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802B2E5C;
    }
    // 0x802B2E50: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802B2E54: b           L_802B2E5C
    // 0x802B2E58: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802B2E5C;
    // 0x802B2E58: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802B2E5C:
    // 0x802B2E5C: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802B2E60: bne         $at, $zero, L_802B2E70
    if (ctx->r1 != 0) {
        // 0x802B2E64: lh          $v1, 0x4C($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X4C);
            goto L_802B2E70;
    }
    // 0x802B2E64: lh          $v1, 0x4C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X4C);
    // 0x802B2E68: b           L_802B2E98
    // 0x802B2E6C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2E98;
    // 0x802B2E6C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2E70:
    // 0x802B2E70: bgez        $v1, L_802B2E80
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B2E74: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802B2E80;
    }
    // 0x802B2E74: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802B2E78: b           L_802B2E80
    // 0x802B2E7C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802B2E80;
    // 0x802B2E7C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802B2E80:
    // 0x802B2E80: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x802B2E84: bnel        $at, $zero, L_802B2E98
    if (ctx->r1 != 0) {
        // 0x802B2E88: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802B2E98;
    }
    goto skip_0;
    // 0x802B2E88: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802B2E8C: b           L_802B2E98
    // 0x802B2E90: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B2E98;
    // 0x802B2E90: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B2E94:
    // 0x802B2E94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802B2E98:
    // 0x802B2E98: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B2E9C: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802B2EA0: jr          $ra
    // 0x802B2EA4: nop

    return;
    // 0x802B2EA4: nop

;}
RECOMP_FUNC void func_802B2EA8_6C4558(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2EA8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B2EAC: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802B2EB0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B2EB4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B2EB8: lhu         $v0, 0x9E($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9E);
    // 0x802B2EBC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B2EC0: beq         $v0, $at, L_802B2F04
    if (ctx->r2 == ctx->r1) {
        // 0x802B2EC4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B2F04;
    }
    // 0x802B2EC4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B2EC8: beq         $v0, $at, L_802B2F20
    if (ctx->r2 == ctx->r1) {
        // 0x802B2ECC: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_802B2F20;
    }
    // 0x802B2ECC: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802B2ED0: beq         $v0, $at, L_802B2F3C
    if (ctx->r2 == ctx->r1) {
        // 0x802B2ED4: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_802B2F3C;
    }
    // 0x802B2ED4: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x802B2ED8: beq         $v0, $at, L_802B2F80
    if (ctx->r2 == ctx->r1) {
        // 0x802B2EDC: addiu       $at, $zero, 0x40
        ctx->r1 = ADD32(0, 0X40);
            goto L_802B2F80;
    }
    // 0x802B2EDC: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x802B2EE0: beq         $v0, $at, L_802B2F58
    if (ctx->r2 == ctx->r1) {
        // 0x802B2EE4: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_802B2F58;
    }
    // 0x802B2EE4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802B2EE8: addiu       $at, $zero, 0x80
    ctx->r1 = ADD32(0, 0X80);
    // 0x802B2EEC: beq         $v0, $at, L_802B2F9C
    if (ctx->r2 == ctx->r1) {
        // 0x802B2EF0: addiu       $at, $zero, 0x100
        ctx->r1 = ADD32(0, 0X100);
            goto L_802B2F9C;
    }
    // 0x802B2EF0: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802B2EF4: beq         $v0, $at, L_802B2FB8
    if (ctx->r2 == ctx->r1) {
        // 0x802B2EF8: nop
    
            goto L_802B2FB8;
    }
    // 0x802B2EF8: nop

    // 0x802B2EFC: b           L_802B2FE8
    // 0x802B2F00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802B2FE8;
    // 0x802B2F00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2F04:
    // 0x802B2F04: jal         0x802A4390
    // 0x802B2F08: nop

    func_802A4390_6B5A40(rdram, ctx);
        goto after_0;
    // 0x802B2F08: nop

    after_0:
    // 0x802B2F0C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B2F10: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x802B2F14: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B2F18: b           L_802B2FE4
    // 0x802B2F1C: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
        goto L_802B2FE4;
    // 0x802B2F1C: sb          $t7, 0x162($t8)
    MEM_B(0X162, ctx->r24) = ctx->r15;
L_802B2F20:
    // 0x802B2F20: jal         0x802A4CB8
    // 0x802B2F24: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_1;
    // 0x802B2F24: nop

    after_1:
    // 0x802B2F28: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B2F2C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x802B2F30: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802B2F34: b           L_802B2FE4
    // 0x802B2F38: sb          $t9, 0x162($t0)
    MEM_B(0X162, ctx->r8) = ctx->r25;
        goto L_802B2FE4;
    // 0x802B2F38: sb          $t9, 0x162($t0)
    MEM_B(0X162, ctx->r8) = ctx->r25;
L_802B2F3C:
    // 0x802B2F3C: jal         0x802A5C80
    // 0x802B2F40: nop

    func_802A5C80_6B7330(rdram, ctx);
        goto after_2;
    // 0x802B2F40: nop

    after_2:
    // 0x802B2F44: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B2F48: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x802B2F4C: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802B2F50: b           L_802B2FE4
    // 0x802B2F54: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
        goto L_802B2FE4;
    // 0x802B2F54: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
L_802B2F58:
    // 0x802B2F58: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x802B2F5C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B2F60: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x802B2F64: jal         0x802A5708
    // 0x802B2F68: lh          $a0, 0x2C($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X2C);
    func_802A5708_6B6DB8(rdram, ctx);
        goto after_3;
    // 0x802B2F68: lh          $a0, 0x2C($t3)
    ctx->r4 = MEM_H(ctx->r11, 0X2C);
    after_3:
    // 0x802B2F6C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B2F70: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B2F74: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x802B2F78: b           L_802B2FE4
    // 0x802B2F7C: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
        goto L_802B2FE4;
    // 0x802B2F7C: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
L_802B2F80:
    // 0x802B2F80: jal         0x802A60C4
    // 0x802B2F84: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_4;
    // 0x802B2F84: nop

    after_4:
    // 0x802B2F88: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B2F8C: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802B2F90: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B2F94: b           L_802B2FE4
    // 0x802B2F98: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
        goto L_802B2FE4;
    // 0x802B2F98: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
L_802B2F9C:
    // 0x802B2F9C: jal         0x802A5D64
    // 0x802B2FA0: nop

    func_802A5D64_6B7414(rdram, ctx);
        goto after_5;
    // 0x802B2FA0: nop

    after_5:
    // 0x802B2FA4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B2FA8: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x802B2FAC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802B2FB0: b           L_802B2FE4
    // 0x802B2FB4: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
        goto L_802B2FE4;
    // 0x802B2FB4: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
L_802B2FB8:
    // 0x802B2FB8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B2FBC: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B2FC0: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B2FC4: sw          $zero, 0x1C($t0)
    MEM_W(0X1C, ctx->r8) = 0;
    // 0x802B2FC8: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B2FCC: jal         0x802A5E64
    // 0x802B2FD0: sw          $zero, 0x20($t1)
    MEM_W(0X20, ctx->r9) = 0;
    func_802A5E64_6B7514(rdram, ctx);
        goto after_6;
    // 0x802B2FD0: sw          $zero, 0x20($t1)
    MEM_W(0X20, ctx->r9) = 0;
    after_6:
    // 0x802B2FD4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802B2FD8: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x802B2FDC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802B2FE0: sb          $t2, 0x162($t3)
    MEM_B(0X162, ctx->r11) = ctx->r10;
L_802B2FE4:
    // 0x802B2FE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B2FE8:
    // 0x802B2FE8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B2FEC: jr          $ra
    // 0x802B2FF0: nop

    return;
    // 0x802B2FF0: nop

;}
RECOMP_FUNC void func_802B2FF4_6C46A4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B2FF4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B2FF8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802B2FFC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B3000: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B3004: lhu         $v0, 0x9E($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9E);
    // 0x802B3008: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B300C: beq         $v0, $at, L_802B304C
    if (ctx->r2 == ctx->r1) {
        // 0x802B3010: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B304C;
    }
    // 0x802B3010: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B3014: beq         $v0, $at, L_802B3070
    if (ctx->r2 == ctx->r1) {
        // 0x802B3018: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_802B3070;
    }
    // 0x802B3018: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802B301C: beq         $v0, $at, L_802B3090
    if (ctx->r2 == ctx->r1) {
        // 0x802B3020: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_802B3090;
    }
    // 0x802B3020: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x802B3024: beq         $v0, $at, L_802B30E0
    if (ctx->r2 == ctx->r1) {
        // 0x802B3028: addiu       $at, $zero, 0x40
        ctx->r1 = ADD32(0, 0X40);
            goto L_802B30E0;
    }
    // 0x802B3028: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x802B302C: beq         $v0, $at, L_802B30B0
    if (ctx->r2 == ctx->r1) {
        // 0x802B3030: addiu       $at, $zero, 0x80
        ctx->r1 = ADD32(0, 0X80);
            goto L_802B30B0;
    }
    // 0x802B3030: addiu       $at, $zero, 0x80
    ctx->r1 = ADD32(0, 0X80);
    // 0x802B3034: beq         $v0, $at, L_802B3100
    if (ctx->r2 == ctx->r1) {
        // 0x802B3038: addiu       $at, $zero, 0x100
        ctx->r1 = ADD32(0, 0X100);
            goto L_802B3100;
    }
    // 0x802B3038: addiu       $at, $zero, 0x100
    ctx->r1 = ADD32(0, 0X100);
    // 0x802B303C: beq         $v0, $at, L_802B311C
    if (ctx->r2 == ctx->r1) {
        // 0x802B3040: nop
    
            goto L_802B311C;
    }
    // 0x802B3040: nop

    // 0x802B3044: b           L_802B3150
    // 0x802B3048: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802B3150;
    // 0x802B3048: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B304C:
    // 0x802B304C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B3050: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B3054: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B3058: addiu       $t7, $zero, 0x5
    ctx->r15 = ADD32(0, 0X5);
    // 0x802B305C: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x802B3060: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    // 0x802B3064: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B3068: b           L_802B314C
    // 0x802B306C: sb          $t9, 0x162($t0)
    MEM_B(0X162, ctx->r8) = ctx->r25;
        goto L_802B314C;
    // 0x802B306C: sb          $t9, 0x162($t0)
    MEM_B(0X162, ctx->r8) = ctx->r25;
L_802B3070:
    // 0x802B3070: jal         0x802A4CB8
    // 0x802B3074: nop

    func_802A4CB8_6B6368(rdram, ctx);
        goto after_0;
    // 0x802B3074: nop

    after_0:
    // 0x802B3078: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B307C: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B3080: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B3084: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x802B3088: b           L_802B314C
    // 0x802B308C: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
        goto L_802B314C;
    // 0x802B308C: sb          $t1, 0x162($t2)
    MEM_B(0X162, ctx->r10) = ctx->r9;
L_802B3090:
    // 0x802B3090: jal         0x802A5C80
    // 0x802B3094: nop

    func_802A5C80_6B7330(rdram, ctx);
        goto after_1;
    // 0x802B3094: nop

    after_1:
    // 0x802B3098: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B309C: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B30A0: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B30A4: addiu       $t3, $zero, 0x3
    ctx->r11 = ADD32(0, 0X3);
    // 0x802B30A8: b           L_802B314C
    // 0x802B30AC: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
        goto L_802B314C;
    // 0x802B30AC: sb          $t3, 0x162($t4)
    MEM_B(0X162, ctx->r12) = ctx->r11;
L_802B30B0:
    // 0x802B30B0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B30B4: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B30B8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B30BC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x802B30C0: jal         0x802A5708
    // 0x802B30C4: lh          $a0, 0x2C($t5)
    ctx->r4 = MEM_H(ctx->r13, 0X2C);
    func_802A5708_6B6DB8(rdram, ctx);
        goto after_2;
    // 0x802B30C4: lh          $a0, 0x2C($t5)
    ctx->r4 = MEM_H(ctx->r13, 0X2C);
    after_2:
    // 0x802B30C8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B30CC: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B30D0: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B30D4: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x802B30D8: b           L_802B314C
    // 0x802B30DC: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
        goto L_802B314C;
    // 0x802B30DC: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
L_802B30E0:
    // 0x802B30E0: jal         0x802A60C4
    // 0x802B30E4: nop

    func_802A60C4_6B7774(rdram, ctx);
        goto after_3;
    // 0x802B30E4: nop

    after_3:
    // 0x802B30E8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B30EC: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B30F0: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B30F4: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x802B30F8: b           L_802B314C
    // 0x802B30FC: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
        goto L_802B314C;
    // 0x802B30FC: sb          $t8, 0x162($t9)
    MEM_B(0X162, ctx->r25) = ctx->r24;
L_802B3100:
    // 0x802B3100: jal         0x802A5CF4
    // 0x802B3104: nop

    func_802A5CF4_6B73A4(rdram, ctx);
        goto after_4;
    // 0x802B3104: nop

    after_4:
    // 0x802B3108: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B310C: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802B3110: addiu       $t0, $zero, 0x3
    ctx->r8 = ADD32(0, 0X3);
    // 0x802B3114: b           L_802B314C
    // 0x802B3118: sb          $t0, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r8;
        goto L_802B314C;
    // 0x802B3118: sb          $t0, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r8;
L_802B311C:
    // 0x802B311C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B3120: addiu       $v0, $v0, 0x5530
    ctx->r2 = ADD32(ctx->r2, 0X5530);
    // 0x802B3124: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B3128: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802B312C: sw          $zero, 0x1C($t2)
    MEM_W(0X1C, ctx->r10) = 0;
    // 0x802B3130: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B3134: jal         0x802A5E1C
    // 0x802B3138: sw          $zero, 0x20($t3)
    MEM_W(0X20, ctx->r11) = 0;
    func_802A5E1C_6B74CC(rdram, ctx);
        goto after_5;
    // 0x802B3138: sw          $zero, 0x20($t3)
    MEM_W(0X20, ctx->r11) = 0;
    after_5:
    // 0x802B313C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B3140: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B3144: addiu       $t4, $zero, 0x3
    ctx->r12 = ADD32(0, 0X3);
    // 0x802B3148: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
L_802B314C:
    // 0x802B314C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802B3150:
    // 0x802B3150: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B3154: jr          $ra
    // 0x802B3158: nop

    return;
    // 0x802B3158: nop

;}
RECOMP_FUNC void func_802B315C_6C480C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B315C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B3160: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802B3164: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B3168: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B316C: lhu         $t7, 0xA0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA0);
    // 0x802B3170: andi        $t8, $t7, 0x3FF
    ctx->r24 = ctx->r15 & 0X3FF;
    // 0x802B3174: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x802B3178: sltiu       $at, $t9, 0x10
    ctx->r1 = ctx->r25 < 0X10 ? 1 : 0;
    // 0x802B317C: beq         $at, $zero, L_802B3220
    if (ctx->r1 == 0) {
        // 0x802B3180: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802B3220;
    }
    // 0x802B3180: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802B3184: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B3188: addu        $at, $at, $t9
    gpr jr_addend_802B3190 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802B318C: lw          $t9, -0x4230($at)
    ctx->r25 = ADD32(ctx->r1, -0X4230);
    // 0x802B3190: jr          $t9
    // 0x802B3194: nop

    switch (jr_addend_802B3190 >> 2) {
        case 0: goto L_802B3208; break;
        case 1: goto L_802B3198; break;
        case 2: goto L_802B3220; break;
        case 3: goto L_802B31B4; break;
        case 4: goto L_802B3220; break;
        case 5: goto L_802B3220; break;
        case 6: goto L_802B3220; break;
        case 7: goto L_802B31D0; break;
        case 8: goto L_802B3220; break;
        case 9: goto L_802B3220; break;
        case 10: goto L_802B3220; break;
        case 11: goto L_802B3220; break;
        case 12: goto L_802B3220; break;
        case 13: goto L_802B3220; break;
        case 14: goto L_802B3220; break;
        case 15: goto L_802B31EC; break;
        default: switch_error(__func__, 0x802B3190, 0x803BBDD0);
    }
    // 0x802B3194: nop

L_802B3198:
    // 0x802B3198: jal         0x802A5EA4
    // 0x802B319C: nop

    func_802A5EA4_6B7554(rdram, ctx);
        goto after_0;
    // 0x802B319C: nop

    after_0:
    // 0x802B31A0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B31A4: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x802B31A8: addiu       $t0, $zero, 0x5
    ctx->r8 = ADD32(0, 0X5);
    // 0x802B31AC: b           L_802B3220
    // 0x802B31B0: sb          $t0, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r8;
        goto L_802B3220;
    // 0x802B31B0: sb          $t0, 0x162($t1)
    MEM_B(0X162, ctx->r9) = ctx->r8;
L_802B31B4:
    // 0x802B31B4: jal         0x802A5DD0
    // 0x802B31B8: nop

    func_802A5DD0_6B7480(rdram, ctx);
        goto after_1;
    // 0x802B31B8: nop

    after_1:
    // 0x802B31BC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802B31C0: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x802B31C4: addiu       $t2, $zero, 0x4
    ctx->r10 = ADD32(0, 0X4);
    // 0x802B31C8: b           L_802B3220
    // 0x802B31CC: sb          $t2, 0x162($t3)
    MEM_B(0X162, ctx->r11) = ctx->r10;
        goto L_802B3220;
    // 0x802B31CC: sb          $t2, 0x162($t3)
    MEM_B(0X162, ctx->r11) = ctx->r10;
L_802B31D0:
    // 0x802B31D0: jal         0x802A4E74
    // 0x802B31D4: nop

    func_802A4E74_6B6524(rdram, ctx);
        goto after_2;
    // 0x802B31D4: nop

    after_2:
    // 0x802B31D8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B31DC: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B31E0: addiu       $t4, $zero, 0x6
    ctx->r12 = ADD32(0, 0X6);
    // 0x802B31E4: b           L_802B3220
    // 0x802B31E8: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
        goto L_802B3220;
    // 0x802B31E8: sb          $t4, 0x162($t5)
    MEM_B(0X162, ctx->r13) = ctx->r12;
L_802B31EC:
    // 0x802B31EC: jal         0x802A5558
    // 0x802B31F0: nop

    func_802A5558_6B6C08(rdram, ctx);
        goto after_3;
    // 0x802B31F0: nop

    after_3:
    // 0x802B31F4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B31F8: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802B31FC: addiu       $t6, $zero, 0x6
    ctx->r14 = ADD32(0, 0X6);
    // 0x802B3200: b           L_802B3220
    // 0x802B3204: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
        goto L_802B3220;
    // 0x802B3204: sb          $t6, 0x162($t7)
    MEM_B(0X162, ctx->r15) = ctx->r14;
L_802B3208:
    // 0x802B3208: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B320C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B3210: lui         $at, 0x5
    ctx->r1 = S32(0X5 << 16);
    // 0x802B3214: lw          $t8, 0x24($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X24);
    // 0x802B3218: addu        $t9, $t8, $at
    ctx->r25 = ADD32(ctx->r24, ctx->r1);
    // 0x802B321C: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
L_802B3220:
    // 0x802B3220: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B3224: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B3228: jr          $ra
    // 0x802B322C: nop

    return;
    // 0x802B322C: nop

;}
RECOMP_FUNC void func_802B3230_6C48E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3230: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B3234: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x802B3238: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802B323C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802B3240: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x802B3244: lhu         $t7, 0xA0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA0);
    // 0x802B3248: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802B324C: andi        $t8, $t7, 0xC00
    ctx->r24 = ctx->r15 & 0XC00;
    // 0x802B3250: beql        $t8, $zero, L_802B33C0
    if (ctx->r24 == 0) {
        // 0x802B3254: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B33C0;
    }
    goto skip_0;
    // 0x802B3254: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x802B3258: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802B325C: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x802B3260: slti        $at, $v0, 0x8F
    ctx->r1 = SIGNED(ctx->r2) < 0X8F ? 1 : 0;
    // 0x802B3264: bne         $at, $zero, L_802B32B0
    if (ctx->r1 != 0) {
        // 0x802B3268: slti        $at, $v0, 0x91
        ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
            goto L_802B32B0;
    }
    // 0x802B3268: slti        $at, $v0, 0x91
    ctx->r1 = SIGNED(ctx->r2) < 0X91 ? 1 : 0;
    // 0x802B326C: bne         $at, $zero, L_802B3294
    if (ctx->r1 != 0) {
        // 0x802B3270: addiu       $t9, $v0, -0xB5
        ctx->r25 = ADD32(ctx->r2, -0XB5);
            goto L_802B3294;
    }
    // 0x802B3270: addiu       $t9, $v0, -0xB5
    ctx->r25 = ADD32(ctx->r2, -0XB5);
    // 0x802B3274: sltiu       $at, $t9, 0x18
    ctx->r1 = ctx->r25 < 0X18 ? 1 : 0;
    // 0x802B3278: beq         $at, $zero, L_802B33BC
    if (ctx->r1 == 0) {
        // 0x802B327C: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802B33BC;
    }
    // 0x802B327C: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802B3280: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B3284: addu        $at, $at, $t9
    gpr jr_addend_802B328C = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802B3288: lw          $t9, -0x41F0($at)
    ctx->r25 = ADD32(ctx->r1, -0X41F0);
    // 0x802B328C: jr          $t9
    // 0x802B3290: nop

    switch (jr_addend_802B328C >> 2) {
        case 0: goto L_802B32D4; break;
        case 1: goto L_802B32D4; break;
        case 2: goto L_802B32D4; break;
        case 3: goto L_802B32D4; break;
        case 4: goto L_802B32D4; break;
        case 5: goto L_802B33BC; break;
        case 6: goto L_802B33BC; break;
        case 7: goto L_802B33BC; break;
        case 8: goto L_802B33BC; break;
        case 9: goto L_802B33BC; break;
        case 10: goto L_802B33BC; break;
        case 11: goto L_802B33BC; break;
        case 12: goto L_802B33BC; break;
        case 13: goto L_802B33BC; break;
        case 14: goto L_802B33BC; break;
        case 15: goto L_802B33BC; break;
        case 16: goto L_802B33BC; break;
        case 17: goto L_802B33BC; break;
        case 18: goto L_802B33BC; break;
        case 19: goto L_802B33BC; break;
        case 20: goto L_802B32D4; break;
        case 21: goto L_802B32D4; break;
        case 22: goto L_802B32D4; break;
        case 23: goto L_802B32D4; break;
        default: switch_error(__func__, 0x802B328C, 0x803BBE10);
    }
    // 0x802B3290: nop

L_802B3294:
    // 0x802B3294: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802B3298: beq         $v0, $at, L_802B32D4
    if (ctx->r2 == ctx->r1) {
        // 0x802B329C: addiu       $at, $zero, 0x90
        ctx->r1 = ADD32(0, 0X90);
            goto L_802B32D4;
    }
    // 0x802B329C: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802B32A0: beql        $v0, $at, L_802B32D8
    if (ctx->r2 == ctx->r1) {
        // 0x802B32A4: lh          $a0, 0x4($s0)
        ctx->r4 = MEM_H(ctx->r16, 0X4);
            goto L_802B32D8;
    }
    goto skip_1;
    // 0x802B32A4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    skip_1:
    // 0x802B32A8: b           L_802B33C0
    // 0x802B32AC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_802B33C0;
    // 0x802B32AC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802B32B0:
    // 0x802B32B0: addiu       $at, $zero, 0x3D
    ctx->r1 = ADD32(0, 0X3D);
    // 0x802B32B4: beq         $v0, $at, L_802B32D4
    if (ctx->r2 == ctx->r1) {
        // 0x802B32B8: addiu       $at, $zero, 0x3E
        ctx->r1 = ADD32(0, 0X3E);
            goto L_802B32D4;
    }
    // 0x802B32B8: addiu       $at, $zero, 0x3E
    ctx->r1 = ADD32(0, 0X3E);
    // 0x802B32BC: beq         $v0, $at, L_802B32D4
    if (ctx->r2 == ctx->r1) {
        // 0x802B32C0: addiu       $at, $zero, 0x8D
        ctx->r1 = ADD32(0, 0X8D);
            goto L_802B32D4;
    }
    // 0x802B32C0: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x802B32C4: beq         $v0, $at, L_802B32D4
    if (ctx->r2 == ctx->r1) {
        // 0x802B32C8: addiu       $at, $zero, 0x8E
        ctx->r1 = ADD32(0, 0X8E);
            goto L_802B32D4;
    }
    // 0x802B32C8: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802B32CC: bnel        $v0, $at, L_802B33C0
    if (ctx->r2 != ctx->r1) {
        // 0x802B32D0: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B33C0;
    }
    goto skip_2;
    // 0x802B32D0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_2:
L_802B32D4:
    // 0x802B32D4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
L_802B32D8:
    // 0x802B32D8: jal         0x80298F78
    // 0x802B32DC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    func_80298F78_6AA628(rdram, ctx);
        goto after_0;
    // 0x802B32DC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_0:
    // 0x802B32E0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802B32E4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802B32E8: sh          $v0, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r2;
    // 0x802B32EC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B32F0: jal         0x8031124C
    // 0x802B32F4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_1;
    // 0x802B32F4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    after_1:
    // 0x802B32F8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B32FC: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x802B3300: lh          $t1, 0x2E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X2E);
    // 0x802B3304: sra         $t2, $v0, 16
    ctx->r10 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B3308: lhu         $t0, 0xBA($v1)
    ctx->r8 = MEM_HU(ctx->r3, 0XBA);
    // 0x802B330C: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x802B3310: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802B3314: slt         $at, $t0, $t3
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B3318: beql        $at, $zero, L_802B33C0
    if (ctx->r1 == 0) {
        // 0x802B331C: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B33C0;
    }
    goto skip_3;
    // 0x802B331C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_3:
    // 0x802B3320: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802B3324: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B3328: lw          $t4, 0x4C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4C);
    // 0x802B332C: sll         $t6, $t4, 26
    ctx->r14 = S32(ctx->r12 << 26);
    // 0x802B3330: bltz        $t6, L_802B3384
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B3334: nop
    
            goto L_802B3384;
    }
    // 0x802B3334: nop

    // 0x802B3338: lh          $t7, 0x5540($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5540);
    // 0x802B333C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B3340: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x802B3344: andi        $t8, $t7, 0x3
    ctx->r24 = ctx->r15 & 0X3;
    // 0x802B3348: bne         $t8, $zero, L_802B3384
    if (ctx->r24 != 0) {
        // 0x802B334C: nop
    
            goto L_802B3384;
    }
    // 0x802B334C: nop

    // 0x802B3350: lhu         $v0, 0xA0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0XA0);
    // 0x802B3354: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B3358: andi        $t9, $v0, 0x400
    ctx->r25 = ctx->r2 & 0X400;
    // 0x802B335C: beq         $t9, $zero, L_802B3368
    if (ctx->r25 == 0) {
        // 0x802B3360: andi        $t1, $v0, 0x800
        ctx->r9 = ctx->r2 & 0X800;
            goto L_802B3368;
    }
    // 0x802B3360: andi        $t1, $v0, 0x800
    ctx->r9 = ctx->r2 & 0X800;
    // 0x802B3364: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
L_802B3368:
    // 0x802B3368: beq         $t1, $zero, L_802B337C
    if (ctx->r9 == 0) {
        // 0x802B336C: nop
    
            goto L_802B337C;
    }
    // 0x802B336C: nop

    // 0x802B3370: addiu       $a1, $a1, 0x2
    ctx->r5 = ADD32(ctx->r5, 0X2);
    // 0x802B3374: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x802B3378: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
L_802B337C:
    // 0x802B337C: jal         0x802B38FC
    // 0x802B3380: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B38FC_6C4FAC(rdram, ctx);
        goto after_2;
    // 0x802B3380: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_2:
L_802B3384:
    // 0x802B3384: jal         0x8012826C
    // 0x802B3388: nop

    advance_random_seed(rdram, ctx);
        goto after_3;
    // 0x802B3388: nop

    after_3:
    // 0x802B338C: andi        $t3, $v0, 0xF
    ctx->r11 = ctx->r2 & 0XF;
    // 0x802B3390: addiu       $at, $zero, 0xC
    ctx->r1 = ADD32(0, 0XC);
    // 0x802B3394: bne         $t3, $at, L_802B33BC
    if (ctx->r11 != ctx->r1) {
        // 0x802B3398: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_802B33BC;
    }
    // 0x802B3398: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x802B339C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x802B33A0: ori         $t4, $zero, 0xE721
    ctx->r12 = 0 | 0XE721;
    // 0x802B33A4: addiu       $a3, $zero, 0x21
    ctx->r7 = ADD32(0, 0X21);
    // 0x802B33A8: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802B33AC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B33B0: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802B33B4: jal         0x802D9C64
    // 0x802B33B8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    create_sparks(rdram, ctx);
        goto after_4;
    // 0x802B33B8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_4:
L_802B33BC:
    // 0x802B33BC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802B33C0:
    // 0x802B33C0: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x802B33C4: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802B33C8: jr          $ra
    // 0x802B33CC: nop

    return;
    // 0x802B33CC: nop

;}
