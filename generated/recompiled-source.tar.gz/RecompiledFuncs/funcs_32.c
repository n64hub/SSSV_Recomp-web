#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_80395088_7A6738(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395088: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8039508C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80395090: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80395094: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395098: or          $t6, $a1, $zero
    ctx->r14 = ctx->r5 | 0;
    // 0x8039509C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803950A0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803950A4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x803950A8: lui         $v1, 0xE700
    ctx->r3 = S32(0XE700 << 16);
    // 0x803950AC: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x803950B0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803950B4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803950B8: or          $t8, $a2, $zero
    ctx->r24 = ctx->r6 | 0;
    // 0x803950BC: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x803950C0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803950C4: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803950C8: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x803950CC: lui         $t9, 0xC19
    ctx->r25 = S32(0XC19 << 16);
    // 0x803950D0: ori         $t9, $t9, 0x2048
    ctx->r25 = ctx->r25 | 0X2048;
    // 0x803950D4: ori         $t8, $t8, 0x31D
    ctx->r24 = ctx->r24 | 0X31D;
    // 0x803950D8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803950DC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x803950E0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803950E4: or          $t4, $a3, $zero
    ctx->r12 = ctx->r7 | 0;
    // 0x803950E8: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x803950EC: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x803950F0: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x803950F4: lui         $t6, 0x2
    ctx->r14 = S32(0X2 << 16);
    // 0x803950F8: ori         $t6, $t6, 0x2200
    ctx->r14 = ctx->r14 | 0X2200;
    // 0x803950FC: lui         $t5, 0xB600
    ctx->r13 = S32(0XB600 << 16);
    // 0x80395100: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80395104: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80395108: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039510C: lui         $t8, 0xFC71
    ctx->r24 = S32(0XFC71 << 16);
    // 0x80395110: ori         $t8, $t8, 0xFEE3
    ctx->r24 = ctx->r24 | 0XFEE3;
    // 0x80395114: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80395118: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039511C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x80395120: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80395124: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80395128: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039512C: lui         $t5, 0xFA00
    ctx->r13 = S32(0XFA00 << 16);
    // 0x80395130: lui         $at, 0xF600
    ctx->r1 = S32(0XF600 << 16);
    // 0x80395134: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80395138: sw          $t4, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r12;
    // 0x8039513C: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80395140: lbu         $t6, 0x17($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X17);
    // 0x80395144: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x80395148: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8039514C: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80395150: sll         $t4, $t6, 8
    ctx->r12 = S32(ctx->r14 << 8);
    // 0x80395154: or          $t5, $t9, $t4
    ctx->r13 = ctx->r25 | ctx->r12;
    // 0x80395158: ori         $t6, $t5, 0x80
    ctx->r14 = ctx->r13 | 0X80;
    // 0x8039515C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80395160: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395164: andi        $t9, $a3, 0x3FF
    ctx->r25 = ctx->r7 & 0X3FF;
    // 0x80395168: sll         $t4, $t9, 14
    ctx->r12 = S32(ctx->r25 << 14);
    // 0x8039516C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80395170: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80395174: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395178: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8039517C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395180: or          $t5, $t4, $at
    ctx->r13 = ctx->r12 | ctx->r1;
    // 0x80395184: andi        $t4, $a1, 0x3FF
    ctx->r12 = ctx->r5 & 0X3FF;
    // 0x80395188: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039518C: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80395190: lh          $t6, 0x12($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X12);
    // 0x80395194: andi        $t7, $t6, 0x3FF
    ctx->r15 = ctx->r14 & 0X3FF;
    // 0x80395198: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8039519C: or          $t9, $t5, $t8
    ctx->r25 = ctx->r13 | ctx->r24;
    // 0x803951A0: andi        $t7, $a2, 0x3FF
    ctx->r15 = ctx->r6 & 0X3FF;
    // 0x803951A4: sll         $t5, $t7, 2
    ctx->r13 = S32(ctx->r15 << 2);
    // 0x803951A8: sll         $t6, $t4, 14
    ctx->r14 = S32(ctx->r12 << 14);
    // 0x803951AC: or          $t8, $t6, $t5
    ctx->r24 = ctx->r14 | ctx->r13;
    // 0x803951B0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803951B4: jr          $ra
    // 0x803951B8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    return;
    // 0x803951B8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
;}
RECOMP_FUNC void render_tv_body(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803951BC: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x803951C0: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803951C4: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x803951C8: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x803951CC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x803951D0: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x803951D4: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x803951D8: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x803951DC: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x803951E0: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x803951E4: lw          $t6, -0x76E8($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76E8);
    // 0x803951E8: lh          $a3, 0x46($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X46);
    // 0x803951EC: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x803951F0: lh          $a1, 0x3E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X3E);
    // 0x803951F4: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x803951F8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803951FC: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80395200: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80395204: ori         $t3, $zero, 0x8000
    ctx->r11 = 0 | 0X8000;
    // 0x80395208: ori         $t4, $zero, 0x8000
    ctx->r12 = 0 | 0X8000;
    // 0x8039520C: ori         $t5, $zero, 0x9000
    ctx->r13 = 0 | 0X9000;
    // 0x80395210: addu        $a0, $v1, $t7
    ctx->r4 = ADD32(ctx->r3, ctx->r15);
    // 0x80395214: sll         $t2, $a3, 16
    ctx->r10 = S32(ctx->r7 << 16);
    // 0x80395218: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8039521C: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80395220: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80395224: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x80395228: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x8039522C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80395230: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x80395234: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80395238: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x8039523C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80395240: jal         0x80125FE0
    // 0x80395244: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80125FE0(rdram, ctx);
        goto after_0;
    // 0x80395244: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_0:
    // 0x80395248: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039524C: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x80395250: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80395254: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80395258: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039525C: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x80395260: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x80395264: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80395268: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8039526C: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x80395270: ori         $t1, $t1, 0x8000
    ctx->r9 = ctx->r9 | 0X8000;
    // 0x80395274: addu        $t8, $v1, $t1
    ctx->r24 = ADD32(ctx->r3, ctx->r9);
    // 0x80395278: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8039527C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395280: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80395284: sll         $t2, $t9, 6
    ctx->r10 = S32(ctx->r25 << 6);
    // 0x80395288: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x8039528C: addu        $t4, $t3, $at
    ctx->r12 = ADD32(ctx->r11, ctx->r1);
    // 0x80395290: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80395294: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80395298: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039529C: lui         $t2, 0x400
    ctx->r10 = S32(0X400 << 16);
    // 0x803952A0: addu        $t5, $v1, $t1
    ctx->r13 = ADD32(ctx->r3, ctx->r9);
    // 0x803952A4: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x803952A8: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x803952AC: addiu       $t2, $t2, 0x6D00
    ctx->r10 = ADD32(ctx->r10, 0X6D00);
    // 0x803952B0: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x803952B4: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x803952B8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803952BC: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x803952C0: lui         $t4, 0xBD00
    ctx->r12 = S32(0XBD00 << 16);
    // 0x803952C4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803952C8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x803952CC: sw          $t2, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r10;
    // 0x803952D0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803952D4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803952D8: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x803952DC: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x803952E0: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x803952E4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803952E8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x803952EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803952F0: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x803952F4: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x803952F8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803952FC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80395300: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80395304: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80395308: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x8039530C: jr          $ra
    // 0x80395310: nop

    return;
    // 0x80395310: nop

;}
RECOMP_FUNC void render_tv_glass(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395314: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80395318: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8039531C: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80395320: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x80395324: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80395328: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8039532C: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x80395330: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x80395334: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x80395338: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x8039533C: lw          $t6, -0x76E8($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76E8);
    // 0x80395340: lh          $a3, 0x46($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X46);
    // 0x80395344: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x80395348: lh          $a1, 0x3E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X3E);
    // 0x8039534C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80395350: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395354: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80395358: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039535C: ori         $t3, $zero, 0x8000
    ctx->r11 = 0 | 0X8000;
    // 0x80395360: ori         $t4, $zero, 0x8000
    ctx->r12 = 0 | 0X8000;
    // 0x80395364: ori         $t5, $zero, 0x9000
    ctx->r13 = 0 | 0X9000;
    // 0x80395368: addu        $a0, $v1, $t7
    ctx->r4 = ADD32(ctx->r3, ctx->r15);
    // 0x8039536C: sll         $t2, $a3, 16
    ctx->r10 = S32(ctx->r7 << 16);
    // 0x80395370: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x80395374: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80395378: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x8039537C: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x80395380: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80395384: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80395388: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x8039538C: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80395390: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x80395394: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80395398: jal         0x80125FE0
    // 0x8039539C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80125FE0(rdram, ctx);
        goto after_0;
    // 0x8039539C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_0:
    // 0x803953A0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803953A4: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x803953A8: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x803953AC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803953B0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803953B4: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x803953B8: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x803953BC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803953C0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803953C4: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x803953C8: ori         $t1, $t1, 0x8000
    ctx->r9 = ctx->r9 | 0X8000;
    // 0x803953CC: addu        $t8, $v1, $t1
    ctx->r24 = ADD32(ctx->r3, ctx->r9);
    // 0x803953D0: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x803953D4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803953D8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803953DC: sll         $t2, $t9, 6
    ctx->r10 = S32(ctx->r25 << 6);
    // 0x803953E0: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x803953E4: addu        $t4, $t3, $at
    ctx->r12 = ADD32(ctx->r11, ctx->r1);
    // 0x803953E8: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x803953EC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803953F0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803953F4: lui         $t2, 0x401
    ctx->r10 = S32(0X401 << 16);
    // 0x803953F8: addu        $t5, $v1, $t1
    ctx->r13 = ADD32(ctx->r3, ctx->r9);
    // 0x803953FC: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x80395400: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80395404: addiu       $t2, $t2, -0x5620
    ctx->r10 = ADD32(ctx->r10, -0X5620);
    // 0x80395408: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8039540C: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x80395410: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395414: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x80395418: lui         $t4, 0xBD00
    ctx->r12 = S32(0XBD00 << 16);
    // 0x8039541C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80395420: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80395424: sw          $t2, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r10;
    // 0x80395428: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039542C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395430: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x80395434: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80395438: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039543C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395440: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80395444: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395448: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8039544C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80395450: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395454: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80395458: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8039545C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80395460: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x80395464: jr          $ra
    // 0x80395468: nop

    return;
    // 0x80395468: nop

;}
RECOMP_FUNC void func_8039546C_7A6B1C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039546C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80395470: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80395474: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80395478: jr          $ra
    // 0x8039547C: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    return;
    // 0x8039547C: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
;}
RECOMP_FUNC void setup_pause_menu_perspective_a_7A6B30(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395480: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x80395484: lh          $v0, 0x3FD0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X3FD0);
    // 0x80395488: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8039548C: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80395490: addiu       $a3, $a3, 0x66F0
    ctx->r7 = ADD32(ctx->r7, 0X66F0);
    // 0x80395494: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x80395498: sll         $t6, $v0, 1
    ctx->r14 = S32(ctx->r2 << 1);
    // 0x8039549C: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x803954A0: sh          $t6, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r14;
    // 0x803954A4: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803954A8: lh          $v1, 0x3FD2($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X3FD2);
    // 0x803954AC: addiu       $s1, $s1, -0x6184
    ctx->r17 = ADD32(ctx->r17, -0X6184);
    // 0x803954B0: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x803954B4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803954B8: sll         $t7, $v1, 1
    ctx->r15 = S32(ctx->r3 << 1);
    // 0x803954BC: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x803954C0: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803954C4: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x803954C8: sdc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X30, ctx->r29);
    // 0x803954CC: sh          $t7, 0x2($a3)
    MEM_H(0X2, ctx->r7) = ctx->r15;
    // 0x803954D0: sh          $t6, 0x8($a3)
    MEM_H(0X8, ctx->r7) = ctx->r14;
    // 0x803954D4: sh          $t7, 0xA($a3)
    MEM_H(0XA, ctx->r7) = ctx->r15;
    // 0x803954D8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x803954DC: lui         $s2, 0x8020
    ctx->r18 = S32(0X8020 << 16);
    // 0x803954E0: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x803954E4: addiu       $s2, $s2, 0x4278
    ctx->r18 = ADD32(ctx->r18, 0X4278);
    // 0x803954E8: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803954EC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x803954F0: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    // 0x803954F4: jal         0x80129594
    // 0x803954F8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    init_f3dex_render(rdram, ctx);
        goto after_0;
    // 0x803954F8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_0:
    // 0x803954FC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395500: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x80395504: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80395508: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x8039550C: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x80395510: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x80395514: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80395518: jal         0x80129300
    // 0x8039551C: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    load_segments(rdram, ctx);
        goto after_1;
    // 0x8039551C: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    after_1:
    // 0x80395520: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395524: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x80395528: ori         $t8, $t8, 0x1006
    ctx->r24 = ctx->r24 | 0X1006;
    // 0x8039552C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x80395530: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80395534: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80395538: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039553C: lw          $a0, -0x6194($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6194);
    // 0x80395540: jal         0x80138130
    // 0x80395544: sw          $s0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_2;
    // 0x80395544: sw          $s0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r16;
    after_2:
    // 0x80395548: lw          $a1, 0x54($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X54);
    // 0x8039554C: lui         $t5, 0x380
    ctx->r13 = S32(0X380 << 16);
    // 0x80395550: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80395554: sw          $v0, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r2;
    // 0x80395558: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8039555C: addiu       $t6, $t6, 0x66F0
    ctx->r14 = ADD32(ctx->r14, 0X66F0);
    // 0x80395560: ori         $t5, $t5, 0x10
    ctx->r13 = ctx->r13 | 0X10;
    // 0x80395564: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x80395568: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8039556C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80395570: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x80395574: jal         0x80129430
    // 0x80395578: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    clear_depth_buffer(rdram, ctx);
        goto after_3;
    // 0x80395578: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    after_3:
    // 0x8039557C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395580: lui         $t8, 0xFF10
    ctx->r24 = S32(0XFF10 << 16);
    // 0x80395584: ori         $t8, $t8, 0x13F
    ctx->r24 = ctx->r24 | 0X13F;
    // 0x80395588: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x8039558C: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80395590: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80395594: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80395598: lw          $t9, 0x4274($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4274);
    // 0x8039559C: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x803955A0: addu        $a0, $a0, $t9
    ctx->r4 = ADD32(ctx->r4, ctx->r25);
    // 0x803955A4: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x803955A8: jal         0x80138130
    // 0x803955AC: sw          $s0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_4;
    // 0x803955AC: sw          $s0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r16;
    after_4:
    // 0x803955B0: lw          $v1, 0x4C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X4C);
    // 0x803955B4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803955B8: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x803955BC: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
    // 0x803955C0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x803955C4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803955C8: ori         $at, $at, 0x7410
    ctx->r1 = ctx->r1 | 0X7410;
    // 0x803955CC: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x803955D0: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x803955D4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x803955D8: lui         $at, 0x44FA
    ctx->r1 = S32(0X44FA << 16);
    // 0x803955DC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803955E0: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803955E4: mfc1        $a3, $f20
    ctx->r7 = (int32_t)ctx->f20.u32l;
    // 0x803955E8: addiu       $a1, $a1, 0x658
    ctx->r5 = ADD32(ctx->r5, 0X658);
    // 0x803955EC: lui         $a2, 0x4234
    ctx->r6 = S32(0X4234 << 16);
    // 0x803955F0: swc1        $f20, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f20.u32l;
    // 0x803955F4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x803955F8: jal         0x8013F5B0
    // 0x803955FC: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    guPerspective(rdram, ctx);
        goto after_5;
    // 0x803955FC: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_5:
    // 0x80395600: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80395604: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80395608: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8039560C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395610: ori         $at, $at, 0x7450
    ctx->r1 = ctx->r1 | 0X7450;
    // 0x80395614: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x80395618: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x8039561C: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x80395620: jal         0x8013F664
    // 0x80395624: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    guScale(rdram, ctx);
        goto after_6;
    // 0x80395624: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    after_6:
    // 0x80395628: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8039562C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395630: ori         $at, $at, 0x74D0
    ctx->r1 = ctx->r1 | 0X74D0;
    // 0x80395634: mfc1        $a1, $f20
    ctx->r5 = (int32_t)ctx->f20.u32l;
    // 0x80395638: mfc1        $a2, $f20
    ctx->r6 = (int32_t)ctx->f20.u32l;
    // 0x8039563C: mfc1        $a3, $f20
    ctx->r7 = (int32_t)ctx->f20.u32l;
    // 0x80395640: jal         0x8013F664
    // 0x80395644: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    guScale(rdram, ctx);
        goto after_7;
    // 0x80395644: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    after_7:
    // 0x80395648: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8039564C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395650: ori         $at, $at, 0x7490
    ctx->r1 = ctx->r1 | 0X7490;
    // 0x80395654: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80395658: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039565C: lwc1        $f8, 0x6700($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X6700);
    // 0x80395660: lui         $at, 0x442F
    ctx->r1 = S32(0X442F << 16);
    // 0x80395664: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80395668: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x8039566C: addiu       $v0, $v0, 0x683C
    ctx->r2 = ADD32(ctx->r2, 0X683C);
    // 0x80395670: div.s       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f8.fl, ctx->f10.fl);
    // 0x80395674: lwc1        $f18, 0x4($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X4);
    // 0x80395678: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x8039567C: lwc1        $f10, 0x14($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0X14);
    // 0x80395680: lwc1        $f8, 0x10($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X10);
    // 0x80395684: lwc1        $f6, 0xC($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0XC);
    // 0x80395688: lw          $a1, 0x0($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X0);
    // 0x8039568C: lw          $a3, 0x8($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X8);
    // 0x80395690: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    // 0x80395694: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
    // 0x80395698: swc1        $f0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f0.u32l;
    // 0x8039569C: swc1        $f0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f0.u32l;
    // 0x803956A0: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    // 0x803956A4: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x803956A8: add.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f16.fl + ctx->f18.fl;
    // 0x803956AC: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x803956B0: jal         0x8013F968
    // 0x803956B4: nop

    guLookAt(rdram, ctx);
        goto after_8;
    // 0x803956B4: nop

    after_8:
    // 0x803956B8: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x803956BC: jal         0x80299AA8
    // 0x803956C0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    setup_frame_render_state(rdram, ctx);
        goto after_9;
    // 0x803956C0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_9:
    // 0x803956C4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803956C8: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x803956CC: lui         $t7, 0x7D00
    ctx->r15 = S32(0X7D00 << 16);
    // 0x803956D0: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x803956D4: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x803956D8: ori         $t7, $t7, 0x8440
    ctx->r15 = ctx->r15 | 0X8440;
    // 0x803956DC: ori         $t6, $t6, 0x8
    ctx->r14 = ctx->r14 | 0X8;
    // 0x803956E0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803956E4: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x803956E8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803956EC: addiu       $t5, $zero, -0x100
    ctx->r13 = ADD32(0, -0X100);
    // 0x803956F0: lui         $t9, 0xF800
    ctx->r25 = S32(0XF800 << 16);
    // 0x803956F4: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803956F8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x803956FC: sw          $t5, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r13;
    // 0x80395700: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80395704: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395708: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8039570C: addiu       $t8, $t8, 0x4270
    ctx->r24 = ADD32(ctx->r24, 0X4270);
    // 0x80395710: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x80395714: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80395718: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8039571C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80395720: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x80395724: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395728: lui         $t6, 0x1
    ctx->r14 = S32(0X1 << 16);
    // 0x8039572C: lui         $t5, 0xB600
    ctx->r13 = S32(0XB600 << 16);
    // 0x80395730: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x80395734: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x80395738: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x8039573C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80395740: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395744: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x80395748: addiu       $t3, $zero, 0x3
    ctx->r11 = ADD32(0, 0X3);
    // 0x8039574C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x80395750: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80395754: ori         $t8, $t8, 0x404
    ctx->r24 = ctx->r24 | 0X404;
    // 0x80395758: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039575C: sw          $t3, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r11;
    // 0x80395760: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395764: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x80395768: ori         $t5, $t5, 0xC04
    ctx->r13 = ctx->r13 | 0XC04;
    // 0x8039576C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x80395770: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x80395774: sw          $t3, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r11;
    // 0x80395778: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8039577C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395780: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x80395784: ori         $t4, $zero, 0xFFFD
    ctx->r12 = 0 | 0XFFFD;
    // 0x80395788: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x8039578C: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80395790: ori         $t7, $t7, 0x1404
    ctx->r15 = ctx->r15 | 0X1404;
    // 0x80395794: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80395798: sw          $t4, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r12;
    // 0x8039579C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803957A0: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x803957A4: ori         $t9, $t9, 0x1C04
    ctx->r25 = ctx->r25 | 0X1C04;
    // 0x803957A8: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803957AC: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x803957B0: sw          $t4, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r12;
    // 0x803957B4: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803957B8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803957BC: lui         $t6, 0xED02
    ctx->r14 = S32(0XED02 << 16);
    // 0x803957C0: ori         $t6, $t6, 0x20
    ctx->r14 = ctx->r14 | 0X20;
    // 0x803957C4: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x803957C8: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x803957CC: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x803957D0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803957D4: lh          $t7, 0x3FD0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FD0);
    // 0x803957D8: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x803957DC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x803957E0: addiu       $t8, $t7, -0x8
    ctx->r24 = ADD32(ctx->r15, -0X8);
    // 0x803957E4: mtc1        $t8, $f16
    ctx->f16.u32l = ctx->r24;
    // 0x803957E8: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x803957EC: lh          $t8, 0x3FD2($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD2);
    // 0x803957F0: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x803957F4: addiu       $t9, $t8, -0x8
    ctx->r25 = ADD32(ctx->r24, -0X8);
    // 0x803957F8: mtc1        $t9, $f8
    ctx->f8.u32l = ctx->r25;
    // 0x803957FC: nop

    // 0x80395800: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80395804: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80395808: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039580C: mul.s       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x80395810: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x80395814: nop

    // 0x80395818: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x8039581C: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80395820: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x80395824: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x80395828: nop

    // 0x8039582C: andi        $t8, $t6, 0xFFF
    ctx->r24 = ctx->r14 & 0XFFF;
    // 0x80395830: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80395834: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x80395838: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8039583C: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x80395840: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x80395844: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x80395848: ldc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X30);
    // 0x8039584C: jr          $ra
    // 0x80395850: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x80395850: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void setup_pause_menu_perspective_b_7A6F04(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395854: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x80395858: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x8039585C: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x80395860: addiu       $s1, $s1, -0x6184
    ctx->r17 = ADD32(ctx->r17, -0X6184);
    // 0x80395864: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80395868: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8039586C: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x80395870: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80395874: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x80395878: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8039587C: lui         $s2, 0x8020
    ctx->r18 = S32(0X8020 << 16);
    // 0x80395880: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80395884: addiu       $s2, $s2, 0x4278
    ctx->r18 = ADD32(ctx->r18, 0X4278);
    // 0x80395888: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039588C: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x80395890: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    // 0x80395894: jal         0x80129594
    // 0x80395898: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    init_f3dex_render(rdram, ctx);
        goto after_0;
    // 0x80395898: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_0:
    // 0x8039589C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803958A0: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x803958A4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x803958A8: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x803958AC: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x803958B0: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x803958B4: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803958B8: jal         0x80129300
    // 0x803958BC: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    load_segments(rdram, ctx);
        goto after_1;
    // 0x803958BC: lw          $a1, 0x0($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X0);
    after_1:
    // 0x803958C0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803958C4: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x803958C8: ori         $t4, $t4, 0x1006
    ctx->r12 = ctx->r12 | 0X1006;
    // 0x803958CC: addiu       $t3, $s0, 0x8
    ctx->r11 = ADD32(ctx->r16, 0X8);
    // 0x803958D0: sw          $t3, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r11;
    // 0x803958D4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803958D8: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x803958DC: lw          $a0, -0x6194($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6194);
    // 0x803958E0: jal         0x80138130
    // 0x803958E4: sw          $s0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_2;
    // 0x803958E4: sw          $s0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r16;
    after_2:
    // 0x803958E8: lw          $t0, 0x44($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X44);
    // 0x803958EC: lui         $t6, 0x380
    ctx->r14 = S32(0X380 << 16);
    // 0x803958F0: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x803958F4: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x803958F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803958FC: addiu       $t7, $t7, 0x66F0
    ctx->r15 = ADD32(ctx->r15, 0X66F0);
    // 0x80395900: ori         $t6, $t6, 0x10
    ctx->r14 = ctx->r14 | 0X10;
    // 0x80395904: addiu       $t5, $s0, 0x8
    ctx->r13 = ADD32(ctx->r16, 0X8);
    // 0x80395908: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x8039590C: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x80395910: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80395914: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80395918: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039591C: ori         $at, $at, 0x7410
    ctx->r1 = ctx->r1 | 0X7410;
    // 0x80395920: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80395924: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80395928: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039592C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80395930: lwc1        $f6, 0x388($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X388);
    // 0x80395934: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80395938: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039593C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80395940: lui         $a3, 0x3F6B
    ctx->r7 = S32(0X3F6B << 16);
    // 0x80395944: ori         $a3, $a3, 0x851F
    ctx->r7 = ctx->r7 | 0X851F;
    // 0x80395948: addiu       $a1, $a1, 0x658
    ctx->r5 = ADD32(ctx->r5, 0X658);
    // 0x8039594C: lui         $a2, 0x4234
    ctx->r6 = S32(0X4234 << 16);
    // 0x80395950: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x80395954: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x80395958: jal         0x8013F5B0
    // 0x8039595C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    guPerspective(rdram, ctx);
        goto after_3;
    // 0x8039595C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_3:
    // 0x80395960: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80395964: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80395968: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x8039596C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395970: ori         $at, $at, 0x7450
    ctx->r1 = ctx->r1 | 0X7450;
    // 0x80395974: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x80395978: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x8039597C: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x80395980: jal         0x8013F664
    // 0x80395984: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    guScale(rdram, ctx);
        goto after_4;
    // 0x80395984: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    after_4:
    // 0x80395988: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039598C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80395990: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80395994: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395998: ori         $at, $at, 0x74D0
    ctx->r1 = ctx->r1 | 0X74D0;
    // 0x8039599C: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x803959A0: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x803959A4: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x803959A8: jal         0x8013F664
    // 0x803959AC: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    guScale(rdram, ctx);
        goto after_5;
    // 0x803959AC: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    after_5:
    // 0x803959B0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x803959B4: lui         $v0, 0x803B
    ctx->r2 = S32(0X803B << 16);
    // 0x803959B8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803959BC: addiu       $v0, $v0, 0x683C
    ctx->r2 = ADD32(ctx->r2, 0X683C);
    // 0x803959C0: ori         $at, $at, 0x7490
    ctx->r1 = ctx->r1 | 0X7490;
    // 0x803959C4: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x803959C8: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x803959CC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803959D0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x803959D4: lwc1        $f10, 0xC($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XC);
    // 0x803959D8: lwc1        $f16, 0x10($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X10);
    // 0x803959DC: lwc1        $f18, 0x14($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X14);
    // 0x803959E0: lw          $a1, 0x0($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X0);
    // 0x803959E4: lw          $a2, 0x4($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X4);
    // 0x803959E8: lw          $a3, 0x8($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X8);
    // 0x803959EC: swc1        $f0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f0.u32l;
    // 0x803959F0: swc1        $f0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f0.u32l;
    // 0x803959F4: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x803959F8: swc1        $f4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f4.u32l;
    // 0x803959FC: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    // 0x80395A00: jal         0x8013F968
    // 0x80395A04: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    guLookAt(rdram, ctx);
        goto after_6;
    // 0x80395A04: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    after_6:
    // 0x80395A08: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80395A0C: jal         0x80299AA8
    // 0x80395A10: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    setup_frame_render_state(rdram, ctx);
        goto after_7;
    // 0x80395A10: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_7:
    // 0x80395A14: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395A18: lui         $t3, 0x100
    ctx->r11 = S32(0X100 << 16);
    // 0x80395A1C: addiu       $t3, $t3, 0x4270
    ctx->r11 = ADD32(ctx->r11, 0X4270);
    // 0x80395A20: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x80395A24: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80395A28: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x80395A2C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80395A30: sw          $t3, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r11;
    // 0x80395A34: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395A38: lui         $t5, 0xB600
    ctx->r13 = S32(0XB600 << 16);
    // 0x80395A3C: lui         $t6, 0x1
    ctx->r14 = S32(0X1 << 16);
    // 0x80395A40: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x80395A44: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x80395A48: sw          $t6, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r14;
    // 0x80395A4C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80395A50: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395A54: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x80395A58: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x80395A5C: addiu       $t7, $s0, 0x8
    ctx->r15 = ADD32(ctx->r16, 0X8);
    // 0x80395A60: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80395A64: ori         $t8, $t8, 0x404
    ctx->r24 = ctx->r24 | 0X404;
    // 0x80395A68: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80395A6C: sw          $t1, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r9;
    // 0x80395A70: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395A74: lui         $t3, 0xBC00
    ctx->r11 = S32(0XBC00 << 16);
    // 0x80395A78: ori         $t3, $t3, 0xC04
    ctx->r11 = ctx->r11 | 0XC04;
    // 0x80395A7C: addiu       $t9, $s0, 0x8
    ctx->r25 = ADD32(ctx->r16, 0X8);
    // 0x80395A80: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x80395A84: sw          $t1, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r9;
    // 0x80395A88: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80395A8C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395A90: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x80395A94: ori         $t2, $zero, 0xFFFD
    ctx->r10 = 0 | 0XFFFD;
    // 0x80395A98: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x80395A9C: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x80395AA0: ori         $t5, $t5, 0x1404
    ctx->r13 = ctx->r13 | 0X1404;
    // 0x80395AA4: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80395AA8: sw          $t2, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r10;
    // 0x80395AAC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395AB0: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x80395AB4: ori         $t7, $t7, 0x1C04
    ctx->r15 = ctx->r15 | 0X1C04;
    // 0x80395AB8: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x80395ABC: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80395AC0: sw          $t2, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r10;
    // 0x80395AC4: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80395AC8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80395ACC: lui         $t9, 0xED02
    ctx->r25 = S32(0XED02 << 16);
    // 0x80395AD0: ori         $t9, $t9, 0x20
    ctx->r25 = ctx->r25 | 0X20;
    // 0x80395AD4: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x80395AD8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80395ADC: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x80395AE0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80395AE4: lh          $t3, 0x3FD0($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X3FD0);
    // 0x80395AE8: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80395AEC: lh          $t9, 0x3FD2($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FD2);
    // 0x80395AF0: addiu       $t4, $t3, -0x8
    ctx->r12 = ADD32(ctx->r11, -0X8);
    // 0x80395AF4: mtc1        $t4, $f6
    ctx->f6.u32l = ctx->r12;
    // 0x80395AF8: addiu       $t3, $t9, -0x8
    ctx->r11 = ADD32(ctx->r25, -0X8);
    // 0x80395AFC: mtc1        $t3, $f18
    ctx->f18.u32l = ctx->r11;
    // 0x80395B00: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80395B04: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80395B08: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80395B0C: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80395B10: mul.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x80395B14: nop

    // 0x80395B18: mul.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80395B1C: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80395B20: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80395B24: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    // 0x80395B28: mfc1        $t5, $f8
    ctx->r13 = (int32_t)ctx->f8.u32l;
    // 0x80395B2C: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x80395B30: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x80395B34: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x80395B38: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x80395B3C: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x80395B40: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80395B44: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x80395B48: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x80395B4C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80395B50: jr          $ra
    // 0x80395B54: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    return;
    // 0x80395B54: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
;}
RECOMP_FUNC void func_80395B58_7A7208(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395B58: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80395B5C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80395B60: lui         $at, 0x4220
    ctx->r1 = S32(0X4220 << 16);
    // 0x80395B64: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80395B68: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80395B6C: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x80395B70: mul.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80395B74: lui         $v1, 0x3
    ctx->r3 = S32(0X3 << 16);
    // 0x80395B78: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x80395B7C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80395B80: lh          $t0, 0x670E($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X670E);
    // 0x80395B84: addiu       $a3, $a3, -0x6184
    ctx->r7 = ADD32(ctx->r7, -0X6184);
    // 0x80395B88: ori         $v1, $v1, 0x8000
    ctx->r3 = ctx->r3 | 0X8000;
    // 0x80395B8C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80395B90: ctc1        $a1, $FpcCsr
    set_cop1_cs(ctx->r5);
    // 0x80395B94: addiu       $v0, $v0, 0x4278
    ctx->r2 = ADD32(ctx->r2, 0X4278);
    // 0x80395B98: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80395B9C: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x80395BA0: cfc1        $a1, $FpcCsr
    ctx->r5 = get_cop1_cs();
    // 0x80395BA4: nop

    // 0x80395BA8: andi        $a1, $a1, 0x78
    ctx->r5 = ctx->r5 & 0X78;
    // 0x80395BAC: beql        $a1, $zero, L_80395BFC
    if (ctx->r5 == 0) {
        // 0x80395BB0: mfc1        $a1, $f8
        ctx->r5 = (int32_t)ctx->f8.u32l;
            goto L_80395BFC;
    }
    goto skip_0;
    // 0x80395BB0: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
    skip_0:
    // 0x80395BB4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80395BB8: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80395BBC: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x80395BC0: ctc1        $a1, $FpcCsr
    set_cop1_cs(ctx->r5);
    // 0x80395BC4: nop

    // 0x80395BC8: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80395BCC: cfc1        $a1, $FpcCsr
    ctx->r5 = get_cop1_cs();
    // 0x80395BD0: nop

    // 0x80395BD4: andi        $a1, $a1, 0x78
    ctx->r5 = ctx->r5 & 0X78;
    // 0x80395BD8: bne         $a1, $zero, L_80395BF0
    if (ctx->r5 != 0) {
        // 0x80395BDC: nop
    
            goto L_80395BF0;
    }
    // 0x80395BDC: nop

    // 0x80395BE0: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
    // 0x80395BE4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80395BE8: b           L_80395C08
    // 0x80395BEC: or          $a1, $a1, $at
    ctx->r5 = ctx->r5 | ctx->r1;
        goto L_80395C08;
    // 0x80395BEC: or          $a1, $a1, $at
    ctx->r5 = ctx->r5 | ctx->r1;
L_80395BF0:
    // 0x80395BF0: b           L_80395C08
    // 0x80395BF4: addiu       $a1, $zero, -0x1
    ctx->r5 = ADD32(0, -0X1);
        goto L_80395C08;
    // 0x80395BF4: addiu       $a1, $zero, -0x1
    ctx->r5 = ADD32(0, -0X1);
    // 0x80395BF8: mfc1        $a1, $f8
    ctx->r5 = (int32_t)ctx->f8.u32l;
L_80395BFC:
    // 0x80395BFC: nop

    // 0x80395C00: bltz        $a1, L_80395BF0
    if (SIGNED(ctx->r5) < 0) {
        // 0x80395C04: nop
    
            goto L_80395BF0;
    }
    // 0x80395C04: nop

L_80395C08:
    // 0x80395C08: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395C0C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80395C10: lui         $at, 0x4348
    ctx->r1 = S32(0X4348 << 16);
    // 0x80395C14: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x80395C18: sb          $a1, 0x363C($t8)
    MEM_B(0X363C, ctx->r24) = ctx->r5;
    // 0x80395C1C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395C20: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80395C24: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80395C28: addu        $t6, $t9, $v1
    ctx->r14 = ADD32(ctx->r25, ctx->r3);
    // 0x80395C2C: sb          $a1, 0x3638($t6)
    MEM_B(0X3638, ctx->r14) = ctx->r5;
    // 0x80395C30: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395C34: mul.s       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x80395C38: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80395C3C: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x80395C40: sb          $a1, 0x363D($t8)
    MEM_B(0X363D, ctx->r24) = ctx->r5;
    // 0x80395C44: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395C48: addu        $t6, $t9, $v1
    ctx->r14 = ADD32(ctx->r25, ctx->r3);
    // 0x80395C4C: sb          $a1, 0x3639($t6)
    MEM_B(0X3639, ctx->r14) = ctx->r5;
    // 0x80395C50: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395C54: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x80395C58: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80395C5C: ctc1        $a2, $FpcCsr
    set_cop1_cs(ctx->r6);
    // 0x80395C60: sb          $a1, 0x363E($t8)
    MEM_B(0X363E, ctx->r24) = ctx->r5;
    // 0x80395C64: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395C68: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80395C6C: addu        $t6, $t9, $v1
    ctx->r14 = ADD32(ctx->r25, ctx->r3);
    // 0x80395C70: sb          $a1, 0x363A($t6)
    MEM_B(0X363A, ctx->r14) = ctx->r5;
    // 0x80395C74: cfc1        $a2, $FpcCsr
    ctx->r6 = get_cop1_cs();
    // 0x80395C78: nop

    // 0x80395C7C: andi        $a2, $a2, 0x78
    ctx->r6 = ctx->r6 & 0X78;
    // 0x80395C80: beql        $a2, $zero, L_80395CD0
    if (ctx->r6 == 0) {
        // 0x80395C84: mfc1        $a2, $f18
        ctx->r6 = (int32_t)ctx->f18.u32l;
            goto L_80395CD0;
    }
    goto skip_1;
    // 0x80395C84: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
    skip_1:
    // 0x80395C88: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80395C8C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80395C90: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x80395C94: ctc1        $a2, $FpcCsr
    set_cop1_cs(ctx->r6);
    // 0x80395C98: nop

    // 0x80395C9C: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x80395CA0: cfc1        $a2, $FpcCsr
    ctx->r6 = get_cop1_cs();
    // 0x80395CA4: nop

    // 0x80395CA8: andi        $a2, $a2, 0x78
    ctx->r6 = ctx->r6 & 0X78;
    // 0x80395CAC: bne         $a2, $zero, L_80395CC4
    if (ctx->r6 != 0) {
        // 0x80395CB0: nop
    
            goto L_80395CC4;
    }
    // 0x80395CB0: nop

    // 0x80395CB4: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
    // 0x80395CB8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80395CBC: b           L_80395CDC
    // 0x80395CC0: or          $a2, $a2, $at
    ctx->r6 = ctx->r6 | ctx->r1;
        goto L_80395CDC;
    // 0x80395CC0: or          $a2, $a2, $at
    ctx->r6 = ctx->r6 | ctx->r1;
L_80395CC4:
    // 0x80395CC4: b           L_80395CDC
    // 0x80395CC8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
        goto L_80395CDC;
    // 0x80395CC8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80395CCC: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
L_80395CD0:
    // 0x80395CD0: nop

    // 0x80395CD4: bltz        $a2, L_80395CC4
    if (SIGNED(ctx->r6) < 0) {
        // 0x80395CD8: nop
    
            goto L_80395CC4;
    }
    // 0x80395CD8: nop

L_80395CDC:
    // 0x80395CDC: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395CE0: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80395CE4: addiu       $t0, $t0, 0x2
    ctx->r8 = ADD32(ctx->r8, 0X2);
    // 0x80395CE8: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x80395CEC: sb          $a2, 0x3644($t9)
    MEM_B(0X3644, ctx->r25) = ctx->r6;
    // 0x80395CF0: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395CF4: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80395CF8: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80395CFC: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80395D00: sb          $a2, 0x3640($t7)
    MEM_B(0X3640, ctx->r15) = ctx->r6;
    // 0x80395D04: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395D08: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x80395D0C: sb          $a2, 0x3645($t9)
    MEM_B(0X3645, ctx->r25) = ctx->r6;
    // 0x80395D10: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395D14: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80395D18: sb          $a2, 0x3641($t7)
    MEM_B(0X3641, ctx->r15) = ctx->r6;
    // 0x80395D1C: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395D20: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x80395D24: sb          $a2, 0x3646($t9)
    MEM_B(0X3646, ctx->r25) = ctx->r6;
    // 0x80395D28: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395D2C: addiu       $t8, $zero, -0x6D
    ctx->r24 = ADD32(0, -0X6D);
    // 0x80395D30: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80395D34: sb          $a2, 0x3642($t7)
    MEM_B(0X3642, ctx->r15) = ctx->r6;
    // 0x80395D38: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395D3C: addiu       $t7, $zero, 0x5C
    ctx->r15 = ADD32(0, 0X5C);
    // 0x80395D40: addu        $t6, $t9, $v1
    ctx->r14 = ADD32(ctx->r25, ctx->r3);
    // 0x80395D44: sb          $t8, 0x3648($t6)
    MEM_B(0X3648, ctx->r14) = ctx->r24;
    // 0x80395D48: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395D4C: addiu       $t6, $zero, 0x70
    ctx->r14 = ADD32(0, 0X70);
    // 0x80395D50: addu        $t8, $t9, $v1
    ctx->r24 = ADD32(ctx->r25, ctx->r3);
    // 0x80395D54: sb          $t7, 0x3649($t8)
    MEM_B(0X3649, ctx->r24) = ctx->r15;
    // 0x80395D58: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395D5C: sll         $t8, $t0, 16
    ctx->r24 = S32(ctx->r8 << 16);
    // 0x80395D60: addu        $t7, $t9, $v1
    ctx->r15 = ADD32(ctx->r25, ctx->r3);
    // 0x80395D64: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80395D68: div         $zero, $t9, $at
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r1)));
    // 0x80395D6C: sb          $t6, 0x364A($t7)
    MEM_B(0X364A, ctx->r15) = ctx->r14;
    // 0x80395D70: mfhi        $t6
    ctx->r14 = hi;
    // 0x80395D74: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80395D78: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80395D7C: sll         $t9, $t0, 1
    ctx->r25 = S32(ctx->r8 << 1);
    // 0x80395D80: addu        $t5, $t5, $t9
    ctx->r13 = ADD32(ctx->r13, ctx->r25);
    // 0x80395D84: lh          $t5, 0x2350($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2350);
    // 0x80395D88: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80395D8C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80395D90: addiu       $t5, $t5, 0xFF
    ctx->r13 = ADD32(ctx->r13, 0XFF);
    // 0x80395D94: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x80395D98: mflo        $t1
    ctx->r9 = lo;
    // 0x80395D9C: addu        $t6, $t9, $v1
    ctx->r14 = ADD32(ctx->r25, ctx->r3);
    // 0x80395DA0: sb          $t1, 0x3650($t6)
    MEM_B(0X3650, ctx->r14) = ctx->r9;
    // 0x80395DA4: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395DA8: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    // 0x80395DAC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395DB0: addu        $t9, $t8, $v1
    ctx->r25 = ADD32(ctx->r24, ctx->r3);
    // 0x80395DB4: sb          $t7, 0x3651($t9)
    MEM_B(0X3651, ctx->r25) = ctx->r15;
    // 0x80395DB8: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395DBC: ori         $at, $at, 0xB640
    ctx->r1 = ctx->r1 | 0XB640;
    // 0x80395DC0: addu        $t8, $t6, $v1
    ctx->r24 = ADD32(ctx->r14, ctx->r3);
    // 0x80395DC4: sb          $zero, 0x3652($t8)
    MEM_B(0X3652, ctx->r24) = 0;
    // 0x80395DC8: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395DCC: addu        $t9, $t7, $v1
    ctx->r25 = ADD32(ctx->r15, ctx->r3);
    // 0x80395DD0: sb          $t1, 0x3654($t9)
    MEM_B(0X3654, ctx->r25) = ctx->r9;
    // 0x80395DD4: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395DD8: addu        $t8, $t6, $v1
    ctx->r24 = ADD32(ctx->r14, ctx->r3);
    // 0x80395DDC: sb          $zero, 0x3655($t8)
    MEM_B(0X3655, ctx->r24) = 0;
    // 0x80395DE0: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395DE4: addiu       $t6, $zero, 0x57
    ctx->r14 = ADD32(0, 0X57);
    // 0x80395DE8: addu        $t9, $t7, $v1
    ctx->r25 = ADD32(ctx->r15, ctx->r3);
    // 0x80395DEC: sb          $zero, 0x3656($t9)
    MEM_B(0X3656, ctx->r25) = 0;
    // 0x80395DF0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395DF4: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x80395DF8: addu        $t7, $t8, $v1
    ctx->r15 = ADD32(ctx->r24, ctx->r3);
    // 0x80395DFC: sb          $t6, 0x3658($t7)
    MEM_B(0X3658, ctx->r15) = ctx->r14;
    // 0x80395E00: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x80395E04: addu        $t6, $t8, $v1
    ctx->r14 = ADD32(ctx->r24, ctx->r3);
    // 0x80395E08: sb          $t9, 0x3659($t6)
    MEM_B(0X3659, ctx->r14) = ctx->r25;
    // 0x80395E0C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80395E10: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x80395E14: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x80395E18: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x80395E1C: sb          $zero, 0x365A($t8)
    MEM_B(0X365A, ctx->r24) = 0;
    // 0x80395E20: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x80395E24: lui         $t7, 0x8000
    ctx->r15 = S32(0X8000 << 16);
    // 0x80395E28: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x80395E2C: addiu       $t9, $a0, 0x8
    ctx->r25 = ADD32(ctx->r4, 0X8);
    // 0x80395E30: sw          $t9, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r25;
    // 0x80395E34: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80395E38: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80395E3C: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x80395E40: lui         $t9, 0x386
    ctx->r25 = S32(0X386 << 16);
    // 0x80395E44: ori         $t9, $t9, 0x10
    ctx->r25 = ctx->r25 | 0X10;
    // 0x80395E48: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x80395E4C: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x80395E50: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80395E54: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395E58: lui         $t9, 0x388
    ctx->r25 = S32(0X388 << 16);
    // 0x80395E5C: ori         $t9, $t9, 0x10
    ctx->r25 = ctx->r25 | 0X10;
    // 0x80395E60: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x80395E64: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80395E68: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x80395E6C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80395E70: ori         $at, $at, 0xB638
    ctx->r1 = ctx->r1 | 0XB638;
    // 0x80395E74: addiu       $t8, $a0, 0x8
    ctx->r24 = ADD32(ctx->r4, 0X8);
    // 0x80395E78: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x80395E7C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80395E80: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x80395E84: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x80395E88: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80395E8C: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80395E90: jr          $ra
    // 0x80395E94: sh          $t0, 0x670E($at)
    MEM_H(0X670E, ctx->r1) = ctx->r8;
    return;
    // 0x80395E94: sh          $t0, 0x670E($at)
    MEM_H(0X670E, ctx->r1) = ctx->r8;
;}
RECOMP_FUNC void func_80395E98_7A7548(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80395E98: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80395E9C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80395EA0: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80395EA4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395EA8: lui         $t0, 0xE700
    ctx->r8 = S32(0XE700 << 16);
    // 0x80395EAC: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x80395EB0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80395EB4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80395EB8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395EBC: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80395EC0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395EC4: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x80395EC8: lui         $t9, 0x10
    ctx->r25 = S32(0X10 << 16);
    // 0x80395ECC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80395ED0: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80395ED4: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80395ED8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80395EDC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395EE0: lui         $t4, 0x100
    ctx->r12 = S32(0X100 << 16);
    // 0x80395EE4: addiu       $t4, $t4, 0x4AF8
    ctx->r12 = ADD32(ctx->r12, 0X4AF8);
    // 0x80395EE8: addiu       $t1, $v0, 0x8
    ctx->r9 = ADD32(ctx->r2, 0X8);
    // 0x80395EEC: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
    // 0x80395EF0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395EF4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80395EF8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395EFC: lui         $t3, 0x600
    ctx->r11 = S32(0X600 << 16);
    // 0x80395F00: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x80395F04: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x80395F08: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x80395F0C: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80395F10: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80395F14: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395F18: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x80395F1C: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x80395F20: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80395F24: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x80395F28: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80395F2C: lw          $t9, 0x644($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X644);
    // 0x80395F30: lui         $at, 0x11
    ctx->r1 = S32(0X11 << 16);
    // 0x80395F34: ori         $at, $at, 0x2078
    ctx->r1 = ctx->r1 | 0X2078;
    // 0x80395F38: or          $t3, $t9, $at
    ctx->r11 = ctx->r25 | ctx->r1;
    // 0x80395F3C: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x80395F40: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80395F44: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80395F48: lui         $t5, 0x103
    ctx->r13 = S32(0X103 << 16);
    // 0x80395F4C: addiu       $t1, $v0, 0x8
    ctx->r9 = ADD32(ctx->r2, 0X8);
    // 0x80395F50: sw          $t1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r9;
    // 0x80395F54: addiu       $t5, $t5, 0x810
    ctx->r13 = ADD32(ctx->r13, 0X810);
    // 0x80395F58: lui         $t4, 0xFD10
    ctx->r12 = S32(0XFD10 << 16);
    // 0x80395F5C: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80395F60: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80395F64: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395F68: lui         $t9, 0x701
    ctx->r25 = S32(0X701 << 16);
    // 0x80395F6C: ori         $t9, $t9, 0x4050
    ctx->r25 = ctx->r25 | 0X4050;
    // 0x80395F70: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80395F74: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80395F78: lui         $t8, 0xF510
    ctx->r24 = S32(0XF510 << 16);
    // 0x80395F7C: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80395F80: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80395F84: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395F88: lui         $t3, 0xE600
    ctx->r11 = S32(0XE600 << 16);
    // 0x80395F8C: lui         $t4, 0x73F
    ctx->r12 = S32(0X73F << 16);
    // 0x80395F90: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x80395F94: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x80395F98: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395F9C: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80395FA0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395FA4: ori         $t4, $t4, 0xF100
    ctx->r12 = ctx->r12 | 0XF100;
    // 0x80395FA8: lui         $t1, 0xF300
    ctx->r9 = S32(0XF300 << 16);
    // 0x80395FAC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80395FB0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80395FB4: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80395FB8: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x80395FBC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395FC0: lui         $t9, 0x1
    ctx->r25 = S32(0X1 << 16);
    // 0x80395FC4: ori         $t9, $t9, 0x4050
    ctx->r25 = ctx->r25 | 0X4050;
    // 0x80395FC8: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80395FCC: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80395FD0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80395FD4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80395FD8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395FDC: ori         $t8, $t8, 0x1000
    ctx->r24 = ctx->r24 | 0X1000;
    // 0x80395FE0: lui         $t7, 0x7
    ctx->r15 = S32(0X7 << 16);
    // 0x80395FE4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80395FE8: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80395FEC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80395FF0: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80395FF4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80395FF8: ori         $t7, $t7, 0xC07C
    ctx->r15 = ctx->r15 | 0XC07C;
    // 0x80395FFC: lui         $t3, 0xF200
    ctx->r11 = S32(0XF200 << 16);
    // 0x80396000: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x80396004: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x80396008: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8039600C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80396010: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80396014: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80396018: lui         $t1, 0x4
    ctx->r9 = S32(0X4 << 16);
    // 0x8039601C: lui         $v0, 0xC
    ctx->r2 = S32(0XC << 16);
    // 0x80396020: addu        $t1, $t1, $v1
    ctx->r9 = ADD32(ctx->r9, ctx->r3);
    // 0x80396024: lw          $t1, -0x76E8($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X76E8);
    // 0x80396028: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039602C: lui         $a1, 0x3E8
    ctx->r5 = S32(0X3E8 << 16);
    // 0x80396030: sll         $t4, $t1, 6
    ctx->r12 = S32(ctx->r9 << 6);
    // 0x80396034: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80396038: addu        $a0, $v1, $t4
    ctx->r4 = ADD32(ctx->r3, ctx->r12);
    // 0x8039603C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80396040: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
    // 0x80396044: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
    // 0x80396048: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x8039604C: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    // 0x80396050: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    // 0x80396054: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80396058: jal         0x80125FE0
    // 0x8039605C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80125FE0(rdram, ctx);
        goto after_0;
    // 0x8039605C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_0:
    // 0x80396060: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396064: lui         $t6, 0x104
    ctx->r14 = S32(0X104 << 16);
    // 0x80396068: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8039606C: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80396070: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80396074: ori         $t6, $t6, 0x40
    ctx->r14 = ctx->r14 | 0X40;
    // 0x80396078: addiu       $a2, $a2, 0x4278
    ctx->r6 = ADD32(ctx->r6, 0X4278);
    // 0x8039607C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80396080: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80396084: lui         $a3, 0x3
    ctx->r7 = S32(0X3 << 16);
    // 0x80396088: ori         $a3, $a3, 0x8000
    ctx->r7 = ctx->r7 | 0X8000;
    // 0x8039608C: addu        $t8, $v1, $a3
    ctx->r24 = ADD32(ctx->r3, ctx->r7);
    // 0x80396090: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x80396094: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80396098: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039609C: sll         $t2, $t9, 6
    ctx->r10 = S32(ctx->r25 << 6);
    // 0x803960A0: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x803960A4: addu        $t7, $t3, $at
    ctx->r15 = ADD32(ctx->r11, ctx->r1);
    // 0x803960A8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x803960AC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x803960B0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803960B4: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x803960B8: addu        $t1, $v1, $a3
    ctx->r9 = ADD32(ctx->r3, ctx->r7);
    // 0x803960BC: lw          $t4, 0x918($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X918);
    // 0x803960C0: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x803960C4: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x803960C8: sw          $t5, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r13;
    // 0x803960CC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803960D0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803960D4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x803960D8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803960DC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803960E0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x803960E4: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x803960E8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x803960EC: jr          $ra
    // 0x803960F0: nop

    return;
    // 0x803960F0: nop

;}
RECOMP_FUNC void render_spaceship_interior(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803960F4: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x803960F8: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x803960FC: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80396100: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80396104: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x80396108: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8039610C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80396110: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80396114: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80396118: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039611C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80396120: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x80396124: lui         $t9, 0x10
    ctx->r25 = S32(0X10 << 16);
    // 0x80396128: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039612C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80396130: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80396134: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80396138: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039613C: lui         $t7, 0xBB00
    ctx->r15 = S32(0XBB00 << 16);
    // 0x80396140: lui         $t9, 0xFC41
    ctx->r25 = S32(0XFC41 << 16);
    // 0x80396144: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80396148: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8039614C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80396150: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80396154: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80396158: lui         $t5, 0xFF8F
    ctx->r13 = S32(0XFF8F << 16);
    // 0x8039615C: ori         $t5, $t5, 0xFFFF
    ctx->r13 = ctx->r13 | 0XFFFF;
    // 0x80396160: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80396164: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80396168: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039616C: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80396170: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80396174: ori         $t9, $t9, 0xC683
    ctx->r25 = ctx->r25 | 0XC683;
    // 0x80396178: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8039617C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80396180: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80396184: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80396188: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039618C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80396190: lui         $t8, 0xC19
    ctx->r24 = S32(0XC19 << 16);
    // 0x80396194: ori         $t8, $t8, 0x2078
    ctx->r24 = ctx->r24 | 0X2078;
    // 0x80396198: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039619C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x803961A0: ori         $t7, $t7, 0x31D
    ctx->r15 = ctx->r15 | 0X31D;
    // 0x803961A4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803961A8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803961AC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803961B0: lui         $t6, 0x2
    ctx->r14 = S32(0X2 << 16);
    // 0x803961B4: ori         $t6, $t6, 0x2000
    ctx->r14 = ctx->r14 | 0X2000;
    // 0x803961B8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803961BC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x803961C0: lui         $t5, 0xB700
    ctx->r13 = S32(0XB700 << 16);
    // 0x803961C4: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803961C8: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x803961CC: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803961D0: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x803961D4: lui         $t7, 0x4
    ctx->r15 = S32(0X4 << 16);
    // 0x803961D8: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x803961DC: addu        $t7, $t7, $v1
    ctx->r15 = ADD32(ctx->r15, ctx->r3);
    // 0x803961E0: lw          $t7, -0x76E8($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X76E8);
    // 0x803961E4: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803961E8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803961EC: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x803961F0: lui         $a1, 0x3E8
    ctx->r5 = S32(0X3E8 << 16);
    // 0x803961F4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803961F8: addu        $a0, $v1, $t8
    ctx->r4 = ADD32(ctx->r3, ctx->r24);
    // 0x803961FC: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80396200: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
    // 0x80396204: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
    // 0x80396208: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x8039620C: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x80396210: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    // 0x80396214: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80396218: jal         0x80125FE0
    // 0x8039621C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80125FE0(rdram, ctx);
        goto after_0;
    // 0x8039621C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_0:
    // 0x80396220: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396224: lui         $t5, 0x104
    ctx->r13 = S32(0X104 << 16);
    // 0x80396228: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8039622C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80396230: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80396234: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x80396238: addiu       $t0, $t0, 0x4278
    ctx->r8 = ADD32(ctx->r8, 0X4278);
    // 0x8039623C: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80396240: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80396244: lui         $t1, 0x3
    ctx->r9 = S32(0X3 << 16);
    // 0x80396248: ori         $t1, $t1, 0x8000
    ctx->r9 = ctx->r9 | 0X8000;
    // 0x8039624C: addu        $t6, $v1, $t1
    ctx->r14 = ADD32(ctx->r3, ctx->r9);
    // 0x80396250: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x80396254: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80396258: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039625C: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x80396260: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x80396264: addu        $t5, $t9, $at
    ctx->r13 = ADD32(ctx->r25, ctx->r1);
    // 0x80396268: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8039626C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80396270: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80396274: lui         $t5, 0x600
    ctx->r13 = S32(0X600 << 16);
    // 0x80396278: addu        $t6, $v1, $t1
    ctx->r14 = ADD32(ctx->r3, ctx->r9);
    // 0x8039627C: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x80396280: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80396284: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80396288: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8039628C: sw          $t8, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r24;
    // 0x80396290: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396294: addiu       $t6, $t6, 0x5B60
    ctx->r14 = ADD32(ctx->r14, 0X5B60);
    // 0x80396298: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x8039629C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803962A0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803962A4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803962A8: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x803962AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803962B0: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x803962B4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x803962B8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x803962BC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803962C0: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803962C4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803962C8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803962CC: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803962D0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803962D4: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x803962D8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x803962DC: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x803962E0: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x803962E4: jr          $ra
    // 0x803962E8: nop

    return;
    // 0x803962E8: nop

;}
RECOMP_FUNC void func_803962EC_7A799C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803962EC: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x803962F0: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803962F4: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x803962F8: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x803962FC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80396300: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80396304: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x80396308: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x8039630C: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x80396310: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x80396314: lw          $t6, -0x76EC($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76EC);
    // 0x80396318: lhu         $a3, 0x52($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X52);
    // 0x8039631C: lhu         $t8, 0x56($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X56);
    // 0x80396320: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80396324: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x80396328: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8039632C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80396330: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80396334: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x80396338: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x8039633C: addu        $a0, $v1, $t7
    ctx->r4 = ADD32(ctx->r3, ctx->r15);
    // 0x80396340: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80396344: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80396348: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8039634C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80396350: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396354: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80396358: lw          $a1, 0x4C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4C);
    // 0x8039635C: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80396360: jal         0x8013E360
    // 0x80396364: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    guSprite2DInit(rdram, ctx);
        goto after_0;
    // 0x80396364: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_0:
    // 0x80396368: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039636C: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x80396370: lh          $t0, 0x42($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X42);
    // 0x80396374: lui         $t4, 0x900
    ctx->r12 = S32(0X900 << 16);
    // 0x80396378: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x8039637C: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x80396380: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80396384: ori         $t4, $t4, 0x18
    ctx->r12 = ctx->r12 | 0X18;
    // 0x80396388: addiu       $t1, $t1, 0x4278
    ctx->r9 = ADD32(ctx->r9, 0X4278);
    // 0x8039638C: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80396390: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x80396394: lui         $t2, 0x3
    ctx->r10 = S32(0X3 << 16);
    // 0x80396398: ori         $t2, $t2, 0x8000
    ctx->r10 = ctx->r10 | 0X8000;
    // 0x8039639C: addu        $t5, $v1, $t2
    ctx->r13 = ADD32(ctx->r3, ctx->r10);
    // 0x803963A0: lw          $t6, 0x914($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X914);
    // 0x803963A4: lui         $at, 0x3FD0
    ctx->r1 = S32(0X3FD0 << 16);
    // 0x803963A8: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x803963AC: lui         $at, 0x4090
    ctx->r1 = S32(0X4090 << 16);
    // 0x803963B0: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x803963B4: mtc1        $at, $f3
    ctx->f_odd[(3 - 1) * 2] = ctx->r1;
    // 0x803963B8: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x803963BC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x803963C0: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803963C4: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x803963C8: addu        $t8, $v1, $t7
    ctx->r24 = ADD32(ctx->r3, ctx->r15);
    // 0x803963CC: addu        $t9, $t8, $at
    ctx->r25 = ADD32(ctx->r24, ctx->r1);
    // 0x803963D0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x803963D4: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x803963D8: lui         $t4, 0xBE00
    ctx->r12 = S32(0XBE00 << 16);
    // 0x803963DC: mtc1        $a3, $f8
    ctx->f8.u32l = ctx->r7;
    // 0x803963E0: addiu       $t3, $a1, 0x8
    ctx->r11 = ADD32(ctx->r5, 0X8);
    // 0x803963E4: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x803963E8: sw          $t4, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r12;
    // 0x803963EC: lh          $t5, 0x46($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X46);
    // 0x803963F0: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x803963F4: lhu         $t6, 0x52($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X52);
    // 0x803963F8: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x803963FC: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80396400: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80396404: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80396408: mtc1        $zero, $f2
    ctx->f2.u32l = 0;
    // 0x8039640C: lh          $t4, 0x4A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X4A);
    // 0x80396410: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80396414: sub.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x80396418: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8039641C: cvt.d.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f18.d = CVT_D_S(ctx->f16.fl);
    // 0x80396420: mul.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = MUL_D(ctx->f18.d, ctx->f0.d);
    // 0x80396424: bgezl       $t6, L_8039643C
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80396428: cvt.d.s     $f16, $f6
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f16.d = CVT_D_S(ctx->f6.fl);
            goto L_8039643C;
    }
    goto skip_0;
    // 0x80396428: cvt.d.s     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f16.d = CVT_D_S(ctx->f6.fl);
    skip_0:
    // 0x8039642C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80396430: nop

    // 0x80396434: add.s       $f6, $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x80396438: cvt.d.s     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f16.d = CVT_D_S(ctx->f6.fl);
L_8039643C:
    // 0x8039643C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80396440: div.d       $f18, $f16, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f4.d); 
    ctx->f18.d = DIV_D(ctx->f16.d, ctx->f4.d);
    // 0x80396444: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80396448: mul.d       $f8, $f18, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f2.d); 
    ctx->f8.d = MUL_D(ctx->f18.d, ctx->f2.d);
    // 0x8039644C: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x80396450: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80396454: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80396458: nop

    // 0x8039645C: cvt.w.s     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.u32l = CVT_W_S(ctx->f10.fl);
    // 0x80396460: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80396464: nop

    // 0x80396468: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x8039646C: beql        $t8, $zero, L_803964BC
    if (ctx->r24 == 0) {
        // 0x80396470: mfc1        $t8, $f6
        ctx->r24 = (int32_t)ctx->f6.u32l;
            goto L_803964BC;
    }
    goto skip_1;
    // 0x80396470: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    skip_1:
    // 0x80396474: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80396478: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8039647C: sub.s       $f6, $f10, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f10.fl - ctx->f6.fl;
    // 0x80396480: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80396484: nop

    // 0x80396488: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8039648C: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80396490: nop

    // 0x80396494: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x80396498: bne         $t8, $zero, L_803964B0
    if (ctx->r24 != 0) {
        // 0x8039649C: nop
    
            goto L_803964B0;
    }
    // 0x8039649C: nop

    // 0x803964A0: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x803964A4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803964A8: b           L_803964C8
    // 0x803964AC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_803964C8;
    // 0x803964AC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_803964B0:
    // 0x803964B0: b           L_803964C8
    // 0x803964B4: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_803964C8;
    // 0x803964B4: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x803964B8: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
L_803964BC:
    // 0x803964BC: nop

    // 0x803964C0: bltz        $t8, L_803964B0
    if (SIGNED(ctx->r24) < 0) {
        // 0x803964C4: nop
    
            goto L_803964B0;
    }
    // 0x803964C4: nop

L_803964C8:
    // 0x803964C8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x803964CC: mtc1        $t4, $f16
    ctx->f16.u32l = ctx->r12;
    // 0x803964D0: mtc1        $t0, $f18
    ctx->f18.u32l = ctx->r8;
    // 0x803964D4: lhu         $t5, 0x56($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X56);
    // 0x803964D8: cvt.s.w     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.fl = CVT_S_W(ctx->f16.u32l);
    // 0x803964DC: sll         $t3, $t8, 16
    ctx->r11 = S32(ctx->r24 << 16);
    // 0x803964E0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x803964E4: cvt.s.w     $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    ctx->f8.fl = CVT_S_W(ctx->f18.u32l);
    // 0x803964E8: mtc1        $t5, $f18
    ctx->f18.u32l = ctx->r13;
    // 0x803964EC: sub.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x803964F0: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x803964F4: cvt.d.s     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f6.d = CVT_D_S(ctx->f10.fl);
    // 0x803964F8: mul.d       $f16, $f6, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = MUL_D(ctx->f6.d, ctx->f0.d);
    // 0x803964FC: bgezl       $t5, L_80396514
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80396500: cvt.d.s     $f10, $f4
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
            goto L_80396514;
    }
    goto skip_2;
    // 0x80396500: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
    skip_2:
    // 0x80396504: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80396508: nop

    // 0x8039650C: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x80396510: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
L_80396514:
    // 0x80396514: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80396518: div.d       $f6, $f10, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f6.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x8039651C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80396520: lui         $t5, 0xBD00
    ctx->r13 = S32(0XBD00 << 16);
    // 0x80396524: mul.d       $f18, $f6, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f2.d); 
    ctx->f18.d = MUL_D(ctx->f6.d, ctx->f2.d);
    // 0x80396528: cvt.s.d     $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f8.fl = CVT_S_D(ctx->f18.d);
    // 0x8039652C: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80396530: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80396534: nop

    // 0x80396538: cvt.w.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8039653C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80396540: nop

    // 0x80396544: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80396548: beql        $t7, $zero, L_80396598
    if (ctx->r15 == 0) {
        // 0x8039654C: mfc1        $t7, $f4
        ctx->r15 = (int32_t)ctx->f4.u32l;
            goto L_80396598;
    }
    goto skip_3;
    // 0x8039654C: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    skip_3:
    // 0x80396550: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80396554: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80396558: sub.s       $f4, $f8, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f4.fl;
    // 0x8039655C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80396560: nop

    // 0x80396564: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80396568: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x8039656C: nop

    // 0x80396570: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80396574: bne         $t7, $zero, L_8039658C
    if (ctx->r15 != 0) {
        // 0x80396578: nop
    
            goto L_8039658C;
    }
    // 0x80396578: nop

    // 0x8039657C: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    // 0x80396580: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80396584: b           L_803965A4
    // 0x80396588: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_803965A4;
    // 0x80396588: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_8039658C:
    // 0x8039658C: b           L_803965A4
    // 0x80396590: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_803965A4;
    // 0x80396590: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80396594: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
L_80396598:
    // 0x80396598: nop

    // 0x8039659C: bltz        $t7, L_8039658C
    if (SIGNED(ctx->r15) < 0) {
        // 0x803965A0: nop
    
            goto L_8039658C;
    }
    // 0x803965A0: nop

L_803965A4:
    // 0x803965A4: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x803965A8: or          $t9, $t3, $t8
    ctx->r25 = ctx->r11 | ctx->r24;
    // 0x803965AC: sw          $t9, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r25;
    // 0x803965B0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803965B4: andi        $t3, $t0, 0xFFFF
    ctx->r11 = ctx->r8 & 0XFFFF;
    // 0x803965B8: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x803965BC: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x803965C0: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x803965C4: or          $t8, $t7, $t3
    ctx->r24 = ctx->r15 | ctx->r11;
    // 0x803965C8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803965CC: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x803965D0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803965D4: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x803965D8: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x803965DC: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803965E0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x803965E4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x803965E8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x803965EC: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x803965F0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803965F4: addu        $t5, $v1, $t2
    ctx->r13 = ADD32(ctx->r3, ctx->r10);
    // 0x803965F8: lw          $t6, 0x914($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X914);
    // 0x803965FC: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80396600: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80396604: sw          $t7, -0x76EC($at)
    MEM_W(-0X76EC, ctx->r1) = ctx->r15;
    // 0x80396608: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8039660C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80396610: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x80396614: jr          $ra
    // 0x80396618: nop

    return;
    // 0x80396618: nop

;}
RECOMP_FUNC void func_8039661C_7A7CCC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039661C: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x80396620: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80396624: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80396628: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8039662C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80396630: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80396634: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80396638: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039663C: beq         $t2, $zero, L_80396658
    if (ctx->r10 == 0) {
        // 0x80396640: sw          $a2, 0x8($sp)
        MEM_W(0X8, ctx->r29) = ctx->r6;
            goto L_80396658;
    }
    // 0x80396640: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80396644: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80396648: addiu       $v1, $v1, 0x66B8
    ctx->r3 = ADD32(ctx->r3, 0X66B8);
    // 0x8039664C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80396650: b           L_80396668
    // 0x80396654: sh          $a2, 0x44($v1)
    MEM_H(0X44, ctx->r3) = ctx->r6;
        goto L_80396668;
    // 0x80396654: sh          $a2, 0x44($v1)
    MEM_H(0X44, ctx->r3) = ctx->r6;
L_80396658:
    // 0x80396658: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039665C: addiu       $v1, $v1, 0x66B8
    ctx->r3 = ADD32(ctx->r3, 0X66B8);
    // 0x80396660: sh          $zero, 0x44($v1)
    MEM_H(0X44, ctx->r3) = 0;
    // 0x80396664: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
L_80396668:
    // 0x80396668: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8039666C: addiu       $a3, $a3, 0x683C
    ctx->r7 = ADD32(ctx->r7, 0X683C);
    // 0x80396670: sll         $t3, $a0, 2
    ctx->r11 = S32(ctx->r4 << 2);
    // 0x80396674: subu        $t3, $t3, $a0
    ctx->r11 = SUB32(ctx->r11, ctx->r4);
    // 0x80396678: lui         $t4, 0x803B
    ctx->r12 = S32(0X803B << 16);
    // 0x8039667C: addiu       $t4, $t4, 0x6700
    ctx->r12 = ADD32(ctx->r12, 0X6700);
    // 0x80396680: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x80396684: addu        $v0, $t3, $t4
    ctx->r2 = ADD32(ctx->r11, ctx->r12);
    // 0x80396688: lwc1        $f4, 0x0($a3)
    ctx->f4.u32l = MEM_W(ctx->r7, 0X0);
    // 0x8039668C: lwc1        $f6, 0x4($a3)
    ctx->f6.u32l = MEM_W(ctx->r7, 0X4);
    // 0x80396690: lwc1        $f8, 0x8($a3)
    ctx->f8.u32l = MEM_W(ctx->r7, 0X8);
    // 0x80396694: lwc1        $f10, 0xC($a3)
    ctx->f10.u32l = MEM_W(ctx->r7, 0XC);
    // 0x80396698: lwc1        $f16, 0x10($a3)
    ctx->f16.u32l = MEM_W(ctx->r7, 0X10);
    // 0x8039669C: lwc1        $f18, 0x14($a3)
    ctx->f18.u32l = MEM_W(ctx->r7, 0X14);
    // 0x803966A0: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x803966A4: addiu       $t0, $t0, 0x6680
    ctx->r8 = ADD32(ctx->r8, 0X6680);
    // 0x803966A8: swc1        $f4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->f4.u32l;
    // 0x803966AC: swc1        $f6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->f6.u32l;
    // 0x803966B0: swc1        $f8, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->f8.u32l;
    // 0x803966B4: swc1        $f10, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->f10.u32l;
    // 0x803966B8: swc1        $f16, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->f16.u32l;
    // 0x803966BC: swc1        $f18, 0x14($v1)
    MEM_W(0X14, ctx->r3) = ctx->f18.u32l;
    // 0x803966C0: lwc1        $f4, 0x0($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X0);
    // 0x803966C4: lwc1        $f6, 0x4($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0X4);
    // 0x803966C8: lwc1        $f8, 0x8($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X8);
    // 0x803966CC: lwc1        $f10, 0xC($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XC);
    // 0x803966D0: lwc1        $f16, 0x10($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X10);
    // 0x803966D4: lwc1        $f18, 0x14($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X14);
    // 0x803966D8: lh          $t5, 0x8($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X8);
    // 0x803966DC: sw          $zero, 0x30($v1)
    MEM_W(0X30, ctx->r3) = 0;
    // 0x803966E0: sw          $zero, 0x34($v1)
    MEM_W(0X34, ctx->r3) = 0;
    // 0x803966E4: sw          $a1, 0x38($v1)
    MEM_W(0X38, ctx->r3) = ctx->r5;
    // 0x803966E8: sw          $a1, 0x3C($v1)
    MEM_W(0X3C, ctx->r3) = ctx->r5;
    // 0x803966EC: sh          $a2, 0x40($v1)
    MEM_H(0X40, ctx->r3) = ctx->r6;
    // 0x803966F0: sh          $a2, 0x42($v1)
    MEM_H(0X42, ctx->r3) = ctx->r6;
    // 0x803966F4: swc1        $f4, 0x18($v1)
    MEM_W(0X18, ctx->r3) = ctx->f4.u32l;
    // 0x803966F8: swc1        $f6, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->f6.u32l;
    // 0x803966FC: swc1        $f8, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->f8.u32l;
    // 0x80396700: swc1        $f10, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->f10.u32l;
    // 0x80396704: swc1        $f16, 0x28($v1)
    MEM_W(0X28, ctx->r3) = ctx->f16.u32l;
    // 0x80396708: swc1        $f18, 0x2C($v1)
    MEM_W(0X2C, ctx->r3) = ctx->f18.u32l;
    // 0x8039670C: jr          $ra
    // 0x80396710: sh          $t5, 0x6($t0)
    MEM_H(0X6, ctx->r8) = ctx->r13;
    return;
    // 0x80396710: sh          $t5, 0x6($t0)
    MEM_H(0X6, ctx->r8) = ctx->r13;
;}
RECOMP_FUNC void func_80396714_7A7DC4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80396714: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80396718: addiu       $v0, $v0, 0x66B8
    ctx->r2 = ADD32(ctx->r2, 0X66B8);
    // 0x8039671C: lh          $t6, 0x40($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X40);
    // 0x80396720: bnel        $t6, $zero, L_80396740
    if (ctx->r14 != 0) {
        // 0x80396724: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80396740;
    }
    goto skip_0;
    // 0x80396724: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80396728: lh          $t7, 0x42($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X42);
    // 0x8039672C: bnel        $t7, $zero, L_80396740
    if (ctx->r15 != 0) {
        // 0x80396730: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80396740;
    }
    goto skip_1;
    // 0x80396730: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x80396734: jr          $ra
    // 0x80396738: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80396738: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8039673C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80396740:
    // 0x80396740: jr          $ra
    // 0x80396744: nop

    return;
    // 0x80396744: nop

;}
RECOMP_FUNC void func_80396748_7A7DF8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80396748: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8039674C: lw          $t6, 0x10D0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X10D0);
    // 0x80396750: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80396754: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80396758: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x8039675C: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80396760: andi        $t7, $v0, 0x1000
    ctx->r15 = ctx->r2 & 0X1000;
    // 0x80396764: beq         $t7, $zero, L_8039677C
    if (ctx->r15 == 0) {
        // 0x80396768: andi        $t9, $v0, 0x8000
        ctx->r25 = ctx->r2 & 0X8000;
            goto L_8039677C;
    }
    // 0x80396768: andi        $t9, $v0, 0x8000
    ctx->r25 = ctx->r2 & 0X8000;
    // 0x8039676C: lbu         $t8, 0x12DE($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12DE);
    // 0x80396770: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80396774: beql        $t8, $at, L_80396794
    if (ctx->r24 == ctx->r1) {
        // 0x80396778: addiu       $t1, $zero, 0x40
        ctx->r9 = ADD32(0, 0X40);
            goto L_80396794;
    }
    goto skip_0;
    // 0x80396778: addiu       $t1, $zero, 0x40
    ctx->r9 = ADD32(0, 0X40);
    skip_0:
L_8039677C:
    // 0x8039677C: beq         $t9, $zero, L_803967C0
    if (ctx->r25 == 0) {
        // 0x80396780: lui         $t0, 0x8029
        ctx->r8 = S32(0X8029 << 16);
            goto L_803967C0;
    }
    // 0x80396780: lui         $t0, 0x8029
    ctx->r8 = S32(0X8029 << 16);
    // 0x80396784: lbu         $t0, 0x12DF($t0)
    ctx->r8 = MEM_BU(ctx->r8, 0X12DF);
    // 0x80396788: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039678C: bne         $t0, $at, L_803967C0
    if (ctx->r8 != ctx->r1) {
        // 0x80396790: addiu       $t1, $zero, 0x40
        ctx->r9 = ADD32(0, 0X40);
            goto L_803967C0;
    }
    // 0x80396790: addiu       $t1, $zero, 0x40
    ctx->r9 = ADD32(0, 0X40);
L_80396794:
    // 0x80396794: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80396798: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039679C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803967A0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803967A4: jal         0x8013307C
    // 0x803967A8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_0;
    // 0x803967A8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_0:
    // 0x803967AC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x803967B0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803967B4: sb          $t2, 0x66AF($at)
    MEM_B(0X66AF, ctx->r1) = ctx->r10;
    // 0x803967B8: b           L_803967C4
    // 0x803967BC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803967C4;
    // 0x803967BC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803967C0:
    // 0x803967C0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803967C4:
    // 0x803967C4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x803967C8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x803967CC: jr          $ra
    // 0x803967D0: nop

    return;
    // 0x803967D0: nop

;}
RECOMP_FUNC void func_803967D4_7A7E84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803967D4: addiu       $sp, $sp, -0xA0
    ctx->r29 = ADD32(ctx->r29, -0XA0);
    // 0x803967D8: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x803967DC: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x803967E0: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x803967E4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803967E8: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x803967EC: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x803967F0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803967F4: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x803967F8: sw          $a0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r4;
    // 0x803967FC: sw          $a1, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r5;
    // 0x80396800: sw          $a2, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->r6;
    // 0x80396804: sw          $a3, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r7;
    // 0x80396808: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039680C: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x80396810: ori         $t7, $t7, 0x602
    ctx->r15 = ctx->r15 | 0X602;
    // 0x80396814: addiu       $t8, $zero, 0xC0
    ctx->r24 = ADD32(0, 0XC0);
    // 0x80396818: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039681C: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80396820: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396824: lui         $t3, 0xBA00
    ctx->r11 = S32(0XBA00 << 16);
    // 0x80396828: ori         $t3, $t3, 0x402
    ctx->r11 = ctx->r11 | 0X402;
    // 0x8039682C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80396830: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80396834: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80396838: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x8039683C: lh          $t4, 0xC6($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XC6);
    // 0x80396840: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80396844: andi        $s1, $a2, 0xFF
    ctx->r17 = ctx->r6 & 0XFF;
    // 0x80396848: bne         $t4, $at, L_80396C04
    if (ctx->r12 != ctx->r1) {
        // 0x8039684C: andi        $s2, $a3, 0xFF
        ctx->r18 = ctx->r7 & 0XFF;
            goto L_80396C04;
    }
    // 0x8039684C: andi        $s2, $a3, 0xFF
    ctx->r18 = ctx->r7 & 0XFF;
    // 0x80396850: lh          $t5, 0xB6($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XB6);
    // 0x80396854: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80396858: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039685C: beq         $t5, $zero, L_803968A0
    if (ctx->r13 == 0) {
        // 0x80396860: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_803968A0;
    }
    // 0x80396860: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396864: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396868: lbu         $t5, 0xB3($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0XB3);
    // 0x8039686C: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x80396870: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80396874: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80396878: sll         $t3, $t9, 16
    ctx->r11 = S32(ctx->r25 << 16);
    // 0x8039687C: sll         $t8, $s1, 24
    ctx->r24 = S32(ctx->r17 << 24);
    // 0x80396880: or          $t4, $t8, $t3
    ctx->r12 = ctx->r24 | ctx->r11;
    // 0x80396884: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x80396888: or          $t7, $t4, $t6
    ctx->r15 = ctx->r12 | ctx->r14;
    // 0x8039688C: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396890: ori         $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 | 0XFF;
    // 0x80396894: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80396898: b           L_803968D8
    // 0x8039689C: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_803968D8;
    // 0x8039689C: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_803968A0:
    // 0x803968A0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803968A4: lbu         $t9, 0xB3($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0XB3);
    // 0x803968A8: andi        $t4, $s2, 0xFF
    ctx->r12 = ctx->r18 & 0XFF;
    // 0x803968AC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803968B0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x803968B4: sll         $t6, $t4, 16
    ctx->r14 = S32(ctx->r12 << 16);
    // 0x803968B8: sll         $t5, $s1, 24
    ctx->r13 = S32(ctx->r17 << 24);
    // 0x803968BC: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x803968C0: sll         $t8, $t9, 8
    ctx->r24 = S32(ctx->r25 << 8);
    // 0x803968C4: or          $t3, $t7, $t8
    ctx->r11 = ctx->r15 | ctx->r24;
    // 0x803968C8: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x803968CC: ori         $t4, $t3, 0x14
    ctx->r12 = ctx->r11 | 0X14;
    // 0x803968D0: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x803968D4: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_803968D8:
    // 0x803968D8: lh          $t5, 0xA6($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA6);
    // 0x803968DC: lhu         $t0, 0xA2($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0XA2);
    // 0x803968E0: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803968E4: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x803968E8: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x803968EC: addiu       $a1, $a1, 0x3A40
    ctx->r5 = ADD32(ctx->r5, 0X3A40);
    // 0x803968F0: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x803968F4: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x803968F8: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x803968FC: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396900: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396904: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396908: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x8039690C: jal         0x8039C834
    // 0x80396910: sw          $t0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r8;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_0;
    // 0x80396910: sw          $t0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r8;
    after_0:
    // 0x80396914: lh          $t9, 0xBA($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XBA);
    // 0x80396918: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039691C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396920: lw          $t0, 0x4C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X4C);
    // 0x80396924: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396928: beq         $t9, $zero, L_80396968
    if (ctx->r25 == 0) {
        // 0x8039692C: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80396968;
    }
    // 0x8039692C: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396930: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396934: andi        $t4, $s2, 0xFF
    ctx->r12 = ctx->r18 & 0XFF;
    // 0x80396938: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x8039693C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80396940: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80396944: sll         $t3, $s1, 24
    ctx->r11 = S32(ctx->r17 << 24);
    // 0x80396948: andi        $t9, $t1, 0xFF
    ctx->r25 = ctx->r9 & 0XFF;
    // 0x8039694C: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x80396950: or          $t6, $t3, $t5
    ctx->r14 = ctx->r11 | ctx->r13;
    // 0x80396954: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80396958: ori         $t4, $t8, 0xFF
    ctx->r12 = ctx->r24 | 0XFF;
    // 0x8039695C: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80396960: b           L_8039699C
    // 0x80396964: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_8039699C;
    // 0x80396964: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396968:
    // 0x80396968: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039696C: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x80396970: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80396974: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80396978: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039697C: sll         $t9, $s1, 24
    ctx->r25 = S32(ctx->r17 << 24);
    // 0x80396980: andi        $t4, $t1, 0xFF
    ctx->r12 = ctx->r9 & 0XFF;
    // 0x80396984: sll         $t3, $t4, 8
    ctx->r11 = S32(ctx->r12 << 8);
    // 0x80396988: or          $t8, $t9, $t7
    ctx->r24 = ctx->r25 | ctx->r15;
    // 0x8039698C: or          $t5, $t8, $t3
    ctx->r13 = ctx->r24 | ctx->r11;
    // 0x80396990: ori         $t6, $t5, 0x14
    ctx->r14 = ctx->r13 | 0X14;
    // 0x80396994: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80396998: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_8039699C:
    // 0x8039699C: lh          $t9, 0xA6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA6);
    // 0x803969A0: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803969A4: addiu       $a1, $a1, 0x4A40
    ctx->r5 = ADD32(ctx->r5, 0X4A40);
    // 0x803969A8: addiu       $t7, $t9, 0x20
    ctx->r15 = ADD32(ctx->r25, 0X20);
    // 0x803969AC: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803969B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803969B4: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x803969B8: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x803969BC: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x803969C0: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x803969C4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803969C8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803969CC: jal         0x8039C834
    // 0x803969D0: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_1;
    // 0x803969D0: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    after_1:
    // 0x803969D4: lh          $t4, 0xC2($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XC2);
    // 0x803969D8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803969DC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x803969E0: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x803969E4: beq         $t4, $zero, L_80396A24
    if (ctx->r12 == 0) {
        // 0x803969E8: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80396A24;
    }
    // 0x803969E8: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x803969EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803969F0: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x803969F4: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x803969F8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x803969FC: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80396A00: sll         $t5, $s1, 24
    ctx->r13 = S32(ctx->r17 << 24);
    // 0x80396A04: andi        $t4, $t1, 0xFF
    ctx->r12 = ctx->r9 & 0XFF;
    // 0x80396A08: sll         $t8, $t4, 8
    ctx->r24 = S32(ctx->r12 << 8);
    // 0x80396A0C: or          $t7, $t5, $t9
    ctx->r15 = ctx->r13 | ctx->r25;
    // 0x80396A10: or          $t3, $t7, $t8
    ctx->r11 = ctx->r15 | ctx->r24;
    // 0x80396A14: ori         $t6, $t3, 0xFF
    ctx->r14 = ctx->r11 | 0XFF;
    // 0x80396A18: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80396A1C: b           L_80396A58
    // 0x80396A20: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_80396A58;
    // 0x80396A20: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396A24:
    // 0x80396A24: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396A28: andi        $t7, $s2, 0xFF
    ctx->r15 = ctx->r18 & 0XFF;
    // 0x80396A2C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80396A30: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80396A34: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80396A38: sll         $t4, $s1, 24
    ctx->r12 = S32(ctx->r17 << 24);
    // 0x80396A3C: andi        $t6, $t1, 0xFF
    ctx->r14 = ctx->r9 & 0XFF;
    // 0x80396A40: sll         $t5, $t6, 8
    ctx->r13 = S32(ctx->r14 << 8);
    // 0x80396A44: or          $t3, $t4, $t8
    ctx->r11 = ctx->r12 | ctx->r24;
    // 0x80396A48: or          $t9, $t3, $t5
    ctx->r25 = ctx->r11 | ctx->r13;
    // 0x80396A4C: ori         $t7, $t9, 0x14
    ctx->r15 = ctx->r25 | 0X14;
    // 0x80396A50: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80396A54: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396A58:
    // 0x80396A58: lh          $v0, 0xA6($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA6);
    // 0x80396A5C: lh          $t4, 0xA2($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XA2);
    // 0x80396A60: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80396A64: addiu       $v0, $v0, 0x3A
    ctx->r2 = ADD32(ctx->r2, 0X3A);
    // 0x80396A68: andi        $t6, $v0, 0xFFFF
    ctx->r14 = ctx->r2 & 0XFFFF;
    // 0x80396A6C: addiu       $t8, $t4, 0xC
    ctx->r24 = ADD32(ctx->r12, 0XC);
    // 0x80396A70: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80396A74: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x80396A78: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80396A7C: sw          $t6, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r14;
    // 0x80396A80: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x80396A84: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396A88: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396A8C: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396A90: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396A94: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396A98: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396A9C: jal         0x8039C834
    // 0x80396AA0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_2;
    // 0x80396AA0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_2:
    // 0x80396AA4: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
    // 0x80396AA8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80396AAC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396AB0: lw          $v0, 0x4C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X4C);
    // 0x80396AB4: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80396AB8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80396ABC: addiu       $t9, $t5, -0xC
    ctx->r25 = ADD32(ctx->r13, -0XC);
    // 0x80396AC0: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x80396AC4: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x80396AC8: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x80396ACC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396AD0: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396AD4: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396AD8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396ADC: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x80396AE0: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396AE4: jal         0x8039C834
    // 0x80396AE8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_3;
    // 0x80396AE8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_3:
    // 0x80396AEC: lh          $t7, 0xBE($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XBE);
    // 0x80396AF0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80396AF4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396AF8: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396AFC: beq         $t7, $zero, L_80396B3C
    if (ctx->r15 == 0) {
        // 0x80396B00: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80396B3C;
    }
    // 0x80396B00: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396B04: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396B08: andi        $t3, $s2, 0xFF
    ctx->r11 = ctx->r18 & 0XFF;
    // 0x80396B0C: sll         $t5, $t3, 16
    ctx->r13 = S32(ctx->r11 << 16);
    // 0x80396B10: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80396B14: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x80396B18: sll         $t6, $s1, 24
    ctx->r14 = S32(ctx->r17 << 24);
    // 0x80396B1C: andi        $t7, $t1, 0xFF
    ctx->r15 = ctx->r9 & 0XFF;
    // 0x80396B20: sll         $t4, $t7, 8
    ctx->r12 = S32(ctx->r15 << 8);
    // 0x80396B24: or          $t9, $t6, $t5
    ctx->r25 = ctx->r14 | ctx->r13;
    // 0x80396B28: or          $t8, $t9, $t4
    ctx->r24 = ctx->r25 | ctx->r12;
    // 0x80396B2C: ori         $t3, $t8, 0xFF
    ctx->r11 = ctx->r24 | 0XFF;
    // 0x80396B30: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x80396B34: b           L_80396B70
    // 0x80396B38: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_80396B70;
    // 0x80396B38: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396B3C:
    // 0x80396B3C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396B40: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x80396B44: sll         $t4, $t9, 16
    ctx->r12 = S32(ctx->r25 << 16);
    // 0x80396B48: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80396B4C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80396B50: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x80396B54: andi        $t3, $t1, 0xFF
    ctx->r11 = ctx->r9 & 0XFF;
    // 0x80396B58: sll         $t6, $t3, 8
    ctx->r14 = S32(ctx->r11 << 8);
    // 0x80396B5C: or          $t8, $t7, $t4
    ctx->r24 = ctx->r15 | ctx->r12;
    // 0x80396B60: or          $t5, $t8, $t6
    ctx->r13 = ctx->r24 | ctx->r14;
    // 0x80396B64: ori         $t9, $t5, 0x14
    ctx->r25 = ctx->r13 | 0X14;
    // 0x80396B68: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80396B6C: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396B70:
    // 0x80396B70: lh          $s1, 0xA6($sp)
    ctx->r17 = MEM_H(ctx->r29, 0XA6);
    // 0x80396B74: lh          $t7, 0xA2($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XA2);
    // 0x80396B78: lui         $s2, 0x800C
    ctx->r18 = S32(0X800C << 16);
    // 0x80396B7C: addiu       $s1, $s1, 0x1C
    ctx->r17 = ADD32(ctx->r17, 0X1C);
    // 0x80396B80: addiu       $s2, $s2, 0x5240
    ctx->r18 = ADD32(ctx->r18, 0X5240);
    // 0x80396B84: andi        $t3, $s1, 0xFFFF
    ctx->r11 = ctx->r17 & 0XFFFF;
    // 0x80396B88: addiu       $t4, $t7, 0x1A
    ctx->r12 = ADD32(ctx->r15, 0X1A);
    // 0x80396B8C: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x80396B90: or          $s1, $t3, $zero
    ctx->r17 = ctx->r11 | 0;
    // 0x80396B94: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x80396B98: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80396B9C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396BA0: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396BA4: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396BA8: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396BAC: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396BB0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396BB4: jal         0x8039C834
    // 0x80396BB8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_4;
    // 0x80396BB8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_4:
    // 0x80396BBC: lh          $t6, 0xA2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XA2);
    // 0x80396BC0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80396BC4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396BC8: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80396BCC: addiu       $t5, $t6, -0x1A
    ctx->r13 = ADD32(ctx->r14, -0X1A);
    // 0x80396BD0: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x80396BD4: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80396BD8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396BDC: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80396BE0: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396BE4: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396BE8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396BEC: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x80396BF0: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396BF4: jal         0x8039C834
    // 0x80396BF8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_5;
    // 0x80396BF8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_5:
    // 0x80396BFC: b           L_80397388
    // 0x80396C00: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
        goto L_80397388;
    // 0x80396C00: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80396C04:
    // 0x80396C04: lh          $t9, 0xB6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XB6);
    // 0x80396C08: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80396C0C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396C10: beq         $t9, $zero, L_80396C54
    if (ctx->r25 == 0) {
        // 0x80396C14: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_80396C54;
    }
    // 0x80396C14: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396C18: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396C1C: lbu         $t9, 0xB3($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396C20: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x80396C24: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80396C28: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80396C2C: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80396C30: sll         $t3, $s1, 24
    ctx->r11 = S32(ctx->r17 << 24);
    // 0x80396C34: or          $t5, $t3, $t6
    ctx->r13 = ctx->r11 | ctx->r14;
    // 0x80396C38: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x80396C3C: or          $t4, $t5, $t7
    ctx->r12 = ctx->r13 | ctx->r15;
    // 0x80396C40: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396C44: ori         $t8, $t4, 0xFF
    ctx->r24 = ctx->r12 | 0XFF;
    // 0x80396C48: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80396C4C: b           L_80396C8C
    // 0x80396C50: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_80396C8C;
    // 0x80396C50: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396C54:
    // 0x80396C54: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396C58: lbu         $t8, 0xB3($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396C5C: andi        $t5, $s2, 0xFF
    ctx->r13 = ctx->r18 & 0XFF;
    // 0x80396C60: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80396C64: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80396C68: sll         $t7, $t5, 16
    ctx->r15 = S32(ctx->r13 << 16);
    // 0x80396C6C: sll         $t9, $s1, 24
    ctx->r25 = S32(ctx->r17 << 24);
    // 0x80396C70: or          $t4, $t9, $t7
    ctx->r12 = ctx->r25 | ctx->r15;
    // 0x80396C74: sll         $t3, $t8, 8
    ctx->r11 = S32(ctx->r24 << 8);
    // 0x80396C78: or          $t6, $t4, $t3
    ctx->r14 = ctx->r12 | ctx->r11;
    // 0x80396C7C: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396C80: ori         $t5, $t6, 0x14
    ctx->r13 = ctx->r14 | 0X14;
    // 0x80396C84: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80396C88: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396C8C:
    // 0x80396C8C: lhu         $t0, 0xA2($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0XA2);
    // 0x80396C90: lh          $t9, 0xA6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA6);
    // 0x80396C94: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80396C98: addiu       $a1, $a1, 0x3A40
    ctx->r5 = ADD32(ctx->r5, 0X3A40);
    // 0x80396C9C: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396CA0: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396CA4: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396CA8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396CAC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396CB0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396CB4: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x80396CB8: sw          $t0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r8;
    // 0x80396CBC: jal         0x8039C834
    // 0x80396CC0: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_6;
    // 0x80396CC0: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    after_6:
    // 0x80396CC4: lh          $t7, 0xBA($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XBA);
    // 0x80396CC8: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80396CCC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396CD0: lw          $t0, 0x4C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X4C);
    // 0x80396CD4: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396CD8: beq         $t7, $zero, L_80396D18
    if (ctx->r15 == 0) {
        // 0x80396CDC: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80396D18;
    }
    // 0x80396CDC: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396CE0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396CE4: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x80396CE8: sll         $t5, $t6, 16
    ctx->r13 = S32(ctx->r14 << 16);
    // 0x80396CEC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80396CF0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80396CF4: sll         $t3, $s1, 24
    ctx->r11 = S32(ctx->r17 << 24);
    // 0x80396CF8: andi        $t7, $t1, 0xFF
    ctx->r15 = ctx->r9 & 0XFF;
    // 0x80396CFC: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x80396D00: or          $t9, $t3, $t5
    ctx->r25 = ctx->r11 | ctx->r13;
    // 0x80396D04: or          $t4, $t9, $t8
    ctx->r12 = ctx->r25 | ctx->r24;
    // 0x80396D08: ori         $t6, $t4, 0xFF
    ctx->r14 = ctx->r12 | 0XFF;
    // 0x80396D0C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80396D10: b           L_80396D4C
    // 0x80396D14: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_80396D4C;
    // 0x80396D14: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396D18:
    // 0x80396D18: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396D1C: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x80396D20: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x80396D24: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80396D28: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80396D2C: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x80396D30: andi        $t6, $t1, 0xFF
    ctx->r14 = ctx->r9 & 0XFF;
    // 0x80396D34: sll         $t3, $t6, 8
    ctx->r11 = S32(ctx->r14 << 8);
    // 0x80396D38: or          $t4, $t7, $t8
    ctx->r12 = ctx->r15 | ctx->r24;
    // 0x80396D3C: or          $t5, $t4, $t3
    ctx->r13 = ctx->r12 | ctx->r11;
    // 0x80396D40: ori         $t9, $t5, 0x14
    ctx->r25 = ctx->r13 | 0X14;
    // 0x80396D44: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80396D48: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396D4C:
    // 0x80396D4C: lh          $t7, 0xA6($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XA6);
    // 0x80396D50: lui         $at, 0x4200
    ctx->r1 = S32(0X4200 << 16);
    // 0x80396D54: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80396D58: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x80396D5C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80396D60: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80396D64: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80396D68: addiu       $a1, $a1, 0x4A40
    ctx->r5 = ADD32(ctx->r5, 0X4A40);
    // 0x80396D6C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396D70: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396D74: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396D78: cvt.s.w     $f2, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    ctx->f2.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80396D7C: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396D80: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396D84: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396D88: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396D8C: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x80396D90: add.s       $f10, $f2, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f2.fl + ctx->f8.fl;
    // 0x80396D94: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80396D98: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80396D9C: nop

    // 0x80396DA0: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x80396DA4: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80396DA8: nop

    // 0x80396DAC: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80396DB0: beq         $t6, $zero, L_80396DFC
    if (ctx->r14 == 0) {
        // 0x80396DB4: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_80396DFC;
    }
    // 0x80396DB4: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80396DB8: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80396DBC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80396DC0: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x80396DC4: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80396DC8: nop

    // 0x80396DCC: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80396DD0: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80396DD4: nop

    // 0x80396DD8: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80396DDC: bne         $t6, $zero, L_80396DF4
    if (ctx->r14 != 0) {
        // 0x80396DE0: nop
    
            goto L_80396DF4;
    }
    // 0x80396DE0: nop

    // 0x80396DE4: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    // 0x80396DE8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80396DEC: b           L_80396E0C
    // 0x80396DF0: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_80396E0C;
    // 0x80396DF0: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_80396DF4:
    // 0x80396DF4: b           L_80396E0C
    // 0x80396DF8: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_80396E0C;
    // 0x80396DF8: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
L_80396DFC:
    // 0x80396DFC: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    // 0x80396E00: nop

    // 0x80396E04: bltz        $t6, L_80396DF4
    if (SIGNED(ctx->r14) < 0) {
        // 0x80396E08: nop
    
            goto L_80396DF4;
    }
    // 0x80396E08: nop

L_80396E0C:
    // 0x80396E0C: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80396E10: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80396E14: jal         0x8039C834
    // 0x80396E18: swc1        $f2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->f2.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_7;
    // 0x80396E18: swc1        $f2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->f2.u32l;
    after_7:
    // 0x80396E1C: lh          $t4, 0xC2($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XC2);
    // 0x80396E20: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80396E24: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80396E28: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x80396E2C: beq         $t4, $zero, L_80396E6C
    if (ctx->r12 == 0) {
        // 0x80396E30: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80396E6C;
    }
    // 0x80396E30: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x80396E34: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396E38: andi        $t7, $s2, 0xFF
    ctx->r15 = ctx->r18 & 0XFF;
    // 0x80396E3C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80396E40: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x80396E44: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80396E48: sll         $t9, $s1, 24
    ctx->r25 = S32(ctx->r17 << 24);
    // 0x80396E4C: andi        $t4, $t1, 0xFF
    ctx->r12 = ctx->r9 & 0XFF;
    // 0x80396E50: sll         $t3, $t4, 8
    ctx->r11 = S32(ctx->r12 << 8);
    // 0x80396E54: or          $t6, $t9, $t8
    ctx->r14 = ctx->r25 | ctx->r24;
    // 0x80396E58: or          $t5, $t6, $t3
    ctx->r13 = ctx->r14 | ctx->r11;
    // 0x80396E5C: ori         $t7, $t5, 0xFF
    ctx->r15 = ctx->r13 | 0XFF;
    // 0x80396E60: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80396E64: b           L_80396EA0
    // 0x80396E68: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_80396EA0;
    // 0x80396E68: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396E6C:
    // 0x80396E6C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80396E70: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x80396E74: sll         $t3, $t6, 16
    ctx->r11 = S32(ctx->r14 << 16);
    // 0x80396E78: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80396E7C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80396E80: sll         $t4, $s1, 24
    ctx->r12 = S32(ctx->r17 << 24);
    // 0x80396E84: andi        $t7, $t1, 0xFF
    ctx->r15 = ctx->r9 & 0XFF;
    // 0x80396E88: sll         $t9, $t7, 8
    ctx->r25 = S32(ctx->r15 << 8);
    // 0x80396E8C: or          $t5, $t4, $t3
    ctx->r13 = ctx->r12 | ctx->r11;
    // 0x80396E90: or          $t8, $t5, $t9
    ctx->r24 = ctx->r13 | ctx->r25;
    // 0x80396E94: ori         $t6, $t8, 0x14
    ctx->r14 = ctx->r24 | 0X14;
    // 0x80396E98: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80396E9C: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80396EA0:
    // 0x80396EA0: lh          $t4, 0xA2($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XA2);
    // 0x80396EA4: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x80396EA8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80396EAC: mtc1        $t4, $f18
    ctx->f18.u32l = ctx->r12;
    // 0x80396EB0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80396EB4: mul.s       $f2, $f4, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80396EB8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80396EBC: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x80396EC0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80396EC4: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80396EC8: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80396ECC: cvt.s.w     $f12, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    ctx->f12.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80396ED0: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80396ED4: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80396ED8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80396EDC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80396EE0: add.s       $f6, $f12, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = ctx->f12.fl + ctx->f2.fl;
    // 0x80396EE4: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80396EE8: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80396EEC: nop

    // 0x80396EF0: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x80396EF4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80396EF8: nop

    // 0x80396EFC: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80396F00: beq         $t7, $zero, L_80396F4C
    if (ctx->r15 == 0) {
        // 0x80396F04: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_80396F4C;
    }
    // 0x80396F04: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80396F08: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80396F0C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80396F10: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x80396F14: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80396F18: nop

    // 0x80396F1C: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80396F20: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80396F24: nop

    // 0x80396F28: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80396F2C: bne         $t7, $zero, L_80396F44
    if (ctx->r15 != 0) {
        // 0x80396F30: nop
    
            goto L_80396F44;
    }
    // 0x80396F30: nop

    // 0x80396F34: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x80396F38: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80396F3C: b           L_80396F5C
    // 0x80396F40: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_80396F5C;
    // 0x80396F40: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_80396F44:
    // 0x80396F44: b           L_80396F5C
    // 0x80396F48: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_80396F5C;
    // 0x80396F48: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
L_80396F4C:
    // 0x80396F4C: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x80396F50: nop

    // 0x80396F54: bltz        $t7, L_80396F44
    if (SIGNED(ctx->r15) < 0) {
        // 0x80396F58: nop
    
            goto L_80396F44;
    }
    // 0x80396F58: nop

L_80396F5C:
    // 0x80396F5C: lui         $at, 0x4268
    ctx->r1 = S32(0X4268 << 16);
    // 0x80396F60: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80396F64: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80396F68: lwc1        $f10, 0x48($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X48);
    // 0x80396F6C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80396F70: mul.s       $f18, $f16, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = MUL_S(ctx->f16.fl, ctx->f0.fl);
    // 0x80396F74: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80396F78: add.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f18.fl;
    // 0x80396F7C: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x80396F80: ctc1        $v0, $FpcCsr
    set_cop1_cs(ctx->r2);
    // 0x80396F84: nop

    // 0x80396F88: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80396F8C: cfc1        $v0, $FpcCsr
    ctx->r2 = get_cop1_cs();
    // 0x80396F90: nop

    // 0x80396F94: andi        $v0, $v0, 0x78
    ctx->r2 = ctx->r2 & 0X78;
    // 0x80396F98: beq         $v0, $zero, L_80396FE4
    if (ctx->r2 == 0) {
        // 0x80396F9C: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_80396FE4;
    }
    // 0x80396F9C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80396FA0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80396FA4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80396FA8: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x80396FAC: ctc1        $v0, $FpcCsr
    set_cop1_cs(ctx->r2);
    // 0x80396FB0: nop

    // 0x80396FB4: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x80396FB8: cfc1        $v0, $FpcCsr
    ctx->r2 = get_cop1_cs();
    // 0x80396FBC: nop

    // 0x80396FC0: andi        $v0, $v0, 0x78
    ctx->r2 = ctx->r2 & 0X78;
    // 0x80396FC4: bne         $v0, $zero, L_80396FDC
    if (ctx->r2 != 0) {
        // 0x80396FC8: nop
    
            goto L_80396FDC;
    }
    // 0x80396FC8: nop

    // 0x80396FCC: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x80396FD0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80396FD4: b           L_80396FF4
    // 0x80396FD8: or          $v0, $v0, $at
    ctx->r2 = ctx->r2 | ctx->r1;
        goto L_80396FF4;
    // 0x80396FD8: or          $v0, $v0, $at
    ctx->r2 = ctx->r2 | ctx->r1;
L_80396FDC:
    // 0x80396FDC: b           L_80396FF4
    // 0x80396FE0: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
        goto L_80396FF4;
    // 0x80396FE0: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_80396FE4:
    // 0x80396FE4: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x80396FE8: nop

    // 0x80396FEC: bltz        $v0, L_80396FDC
    if (SIGNED(ctx->r2) < 0) {
        // 0x80396FF0: nop
    
            goto L_80396FDC;
    }
    // 0x80396FF0: nop

L_80396FF4:
    // 0x80396FF4: andi        $t9, $v0, 0xFFFF
    ctx->r25 = ctx->r2 & 0XFFFF;
    // 0x80396FF8: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x80396FFC: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x80397000: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80397004: sw          $t9, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r25;
    // 0x80397008: swc1        $f2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->f2.u32l;
    // 0x8039700C: jal         0x8039C834
    // 0x80397010: swc1        $f12, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->f12.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_8;
    // 0x80397010: swc1        $f12, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->f12.u32l;
    after_8:
    // 0x80397014: lwc1        $f2, 0x44($sp)
    ctx->f2.u32l = MEM_W(ctx->r29, 0X44);
    // 0x80397018: lwc1        $f8, 0x4C($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4C);
    // 0x8039701C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80397020: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x80397024: sub.s       $f16, $f8, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = ctx->f8.fl - ctx->f2.fl;
    // 0x80397028: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039702C: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x80397030: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80397034: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80397038: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x8039703C: lw          $v0, 0x40($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X40);
    // 0x80397040: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80397044: cvt.w.s     $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    ctx->f10.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80397048: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x8039704C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80397050: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80397054: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x80397058: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x8039705C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80397060: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x80397064: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80397068: beq         $t4, $zero, L_803970B8
    if (ctx->r12 == 0) {
        // 0x8039706C: swc1        $f0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
            goto L_803970B8;
    }
    // 0x8039706C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80397070: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80397074: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80397078: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8039707C: sub.s       $f10, $f16, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f16.fl - ctx->f10.fl;
    // 0x80397080: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x80397084: nop

    // 0x80397088: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8039708C: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x80397090: nop

    // 0x80397094: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x80397098: bne         $t4, $zero, L_803970B0
    if (ctx->r12 != 0) {
        // 0x8039709C: nop
    
            goto L_803970B0;
    }
    // 0x8039709C: nop

    // 0x803970A0: mfc1        $t4, $f10
    ctx->r12 = (int32_t)ctx->f10.u32l;
    // 0x803970A4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803970A8: b           L_803970C8
    // 0x803970AC: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
        goto L_803970C8;
    // 0x803970AC: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
L_803970B0:
    // 0x803970B0: b           L_803970C8
    // 0x803970B4: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
        goto L_803970C8;
    // 0x803970B4: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
L_803970B8:
    // 0x803970B8: mfc1        $t4, $f10
    ctx->r12 = (int32_t)ctx->f10.u32l;
    // 0x803970BC: nop

    // 0x803970C0: bltz        $t4, L_803970B0
    if (SIGNED(ctx->r12) < 0) {
        // 0x803970C4: nop
    
            goto L_803970B0;
    }
    // 0x803970C4: nop

L_803970C8:
    // 0x803970C8: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x803970CC: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x803970D0: jal         0x8039C834
    // 0x803970D4: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_9;
    // 0x803970D4: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    after_9:
    // 0x803970D8: lh          $t3, 0xBE($sp)
    ctx->r11 = MEM_H(ctx->r29, 0XBE);
    // 0x803970DC: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x803970E0: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x803970E4: lbu         $t1, 0xB3($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB3);
    // 0x803970E8: beq         $t3, $zero, L_80397128
    if (ctx->r11 == 0) {
        // 0x803970EC: lui         $t2, 0xFA00
        ctx->r10 = S32(0XFA00 << 16);
            goto L_80397128;
    }
    // 0x803970EC: lui         $t2, 0xFA00
    ctx->r10 = S32(0XFA00 << 16);
    // 0x803970F0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803970F4: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x803970F8: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x803970FC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80397100: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80397104: sll         $t9, $s1, 24
    ctx->r25 = S32(ctx->r17 << 24);
    // 0x80397108: andi        $t3, $t1, 0xFF
    ctx->r11 = ctx->r9 & 0XFF;
    // 0x8039710C: sll         $t7, $t3, 8
    ctx->r15 = S32(ctx->r11 << 8);
    // 0x80397110: or          $t4, $t9, $t6
    ctx->r12 = ctx->r25 | ctx->r14;
    // 0x80397114: or          $t5, $t4, $t7
    ctx->r13 = ctx->r12 | ctx->r15;
    // 0x80397118: ori         $t8, $t5, 0xFF
    ctx->r24 = ctx->r13 | 0XFF;
    // 0x8039711C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80397120: b           L_8039715C
    // 0x80397124: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
        goto L_8039715C;
    // 0x80397124: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_80397128:
    // 0x80397128: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039712C: andi        $t4, $s2, 0xFF
    ctx->r12 = ctx->r18 & 0XFF;
    // 0x80397130: sll         $t7, $t4, 16
    ctx->r15 = S32(ctx->r12 << 16);
    // 0x80397134: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80397138: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039713C: sll         $t3, $s1, 24
    ctx->r11 = S32(ctx->r17 << 24);
    // 0x80397140: andi        $t8, $t1, 0xFF
    ctx->r24 = ctx->r9 & 0XFF;
    // 0x80397144: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x80397148: or          $t5, $t3, $t7
    ctx->r13 = ctx->r11 | ctx->r15;
    // 0x8039714C: or          $t6, $t5, $t9
    ctx->r14 = ctx->r13 | ctx->r25;
    // 0x80397150: ori         $t4, $t6, 0x14
    ctx->r12 = ctx->r14 | 0X14;
    // 0x80397154: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80397158: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
L_8039715C:
    // 0x8039715C: lui         $at, 0x41D0
    ctx->r1 = S32(0X41D0 << 16);
    // 0x80397160: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80397164: lwc1        $f4, 0x4C($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X4C);
    // 0x80397168: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8039716C: mul.s       $f2, $f18, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80397170: lui         $s2, 0x800C
    ctx->r18 = S32(0X800C << 16);
    // 0x80397174: addiu       $s2, $s2, 0x5240
    ctx->r18 = ADD32(ctx->r18, 0X5240);
    // 0x80397178: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x8039717C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80397180: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80397184: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80397188: add.s       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f2.fl;
    // 0x8039718C: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80397190: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80397194: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80397198: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x8039719C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x803971A0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803971A4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803971A8: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x803971AC: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x803971B0: nop

    // 0x803971B4: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x803971B8: beql        $t7, $zero, L_80397208
    if (ctx->r15 == 0) {
        // 0x803971BC: mfc1        $t7, $f8
        ctx->r15 = (int32_t)ctx->f8.u32l;
            goto L_80397208;
    }
    goto skip_0;
    // 0x803971BC: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    skip_0:
    // 0x803971C0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x803971C4: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x803971C8: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x803971CC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x803971D0: nop

    // 0x803971D4: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x803971D8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x803971DC: nop

    // 0x803971E0: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x803971E4: bne         $t7, $zero, L_803971FC
    if (ctx->r15 != 0) {
        // 0x803971E8: nop
    
            goto L_803971FC;
    }
    // 0x803971E8: nop

    // 0x803971EC: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x803971F0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803971F4: b           L_80397214
    // 0x803971F8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_80397214;
    // 0x803971F8: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_803971FC:
    // 0x803971FC: b           L_80397214
    // 0x80397200: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_80397214;
    // 0x80397200: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80397204: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
L_80397208:
    // 0x80397208: nop

    // 0x8039720C: bltz        $t7, L_803971FC
    if (SIGNED(ctx->r15) < 0) {
        // 0x80397210: nop
    
            goto L_803971FC;
    }
    // 0x80397210: nop

L_80397214:
    // 0x80397214: lui         $at, 0x41E0
    ctx->r1 = S32(0X41E0 << 16);
    // 0x80397218: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x8039721C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80397220: lwc1        $f16, 0x48($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X48);
    // 0x80397224: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    // 0x80397228: mul.s       $f18, $f10, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x8039722C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80397230: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80397234: add.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f16.fl + ctx->f18.fl;
    // 0x80397238: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8039723C: ctc1        $s1, $FpcCsr
    set_cop1_cs(ctx->r17);
    // 0x80397240: nop

    // 0x80397244: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80397248: cfc1        $s1, $FpcCsr
    ctx->r17 = get_cop1_cs();
    // 0x8039724C: nop

    // 0x80397250: andi        $s1, $s1, 0x78
    ctx->r17 = ctx->r17 & 0X78;
    // 0x80397254: beql        $s1, $zero, L_803972A4
    if (ctx->r17 == 0) {
        // 0x80397258: mfc1        $s1, $f6
        ctx->r17 = (int32_t)ctx->f6.u32l;
            goto L_803972A4;
    }
    goto skip_1;
    // 0x80397258: mfc1        $s1, $f6
    ctx->r17 = (int32_t)ctx->f6.u32l;
    skip_1:
    // 0x8039725C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80397260: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    // 0x80397264: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x80397268: ctc1        $s1, $FpcCsr
    set_cop1_cs(ctx->r17);
    // 0x8039726C: nop

    // 0x80397270: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x80397274: cfc1        $s1, $FpcCsr
    ctx->r17 = get_cop1_cs();
    // 0x80397278: nop

    // 0x8039727C: andi        $s1, $s1, 0x78
    ctx->r17 = ctx->r17 & 0X78;
    // 0x80397280: bne         $s1, $zero, L_80397298
    if (ctx->r17 != 0) {
        // 0x80397284: nop
    
            goto L_80397298;
    }
    // 0x80397284: nop

    // 0x80397288: mfc1        $s1, $f6
    ctx->r17 = (int32_t)ctx->f6.u32l;
    // 0x8039728C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80397290: b           L_803972B0
    // 0x80397294: or          $s1, $s1, $at
    ctx->r17 = ctx->r17 | ctx->r1;
        goto L_803972B0;
    // 0x80397294: or          $s1, $s1, $at
    ctx->r17 = ctx->r17 | ctx->r1;
L_80397298:
    // 0x80397298: b           L_803972B0
    // 0x8039729C: addiu       $s1, $zero, -0x1
    ctx->r17 = ADD32(0, -0X1);
        goto L_803972B0;
    // 0x8039729C: addiu       $s1, $zero, -0x1
    ctx->r17 = ADD32(0, -0X1);
    // 0x803972A0: mfc1        $s1, $f6
    ctx->r17 = (int32_t)ctx->f6.u32l;
L_803972A4:
    // 0x803972A4: nop

    // 0x803972A8: bltz        $s1, L_80397298
    if (SIGNED(ctx->r17) < 0) {
        // 0x803972AC: nop
    
            goto L_80397298;
    }
    // 0x803972AC: nop

L_803972B0:
    // 0x803972B0: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x803972B4: andi        $t5, $s1, 0xFFFF
    ctx->r13 = ctx->r17 & 0XFFFF;
    // 0x803972B8: or          $s1, $t5, $zero
    ctx->r17 = ctx->r13 | 0;
    // 0x803972BC: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x803972C0: jal         0x8039C834
    // 0x803972C4: swc1        $f2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->f2.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_10;
    // 0x803972C4: swc1        $f2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->f2.u32l;
    after_10:
    // 0x803972C8: lwc1        $f2, 0x44($sp)
    ctx->f2.u32l = MEM_W(ctx->r29, 0X44);
    // 0x803972CC: lwc1        $f8, 0x4C($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4C);
    // 0x803972D0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x803972D4: lui         $at, 0x3F00
    ctx->r1 = S32(0X3F00 << 16);
    // 0x803972D8: sub.s       $f10, $f8, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f2.fl;
    // 0x803972DC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x803972E0: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x803972E4: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x803972E8: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x803972EC: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x803972F0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x803972F4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803972F8: cvt.w.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = CVT_W_S(ctx->f10.fl);
    // 0x803972FC: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80397300: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    // 0x80397304: addiu       $a3, $zero, 0x20
    ctx->r7 = ADD32(0, 0X20);
    // 0x80397308: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x8039730C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80397310: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80397314: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x80397318: beq         $t4, $zero, L_80397364
    if (ctx->r12 == 0) {
        // 0x8039731C: swc1        $f0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
            goto L_80397364;
    }
    // 0x8039731C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x80397320: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80397324: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80397328: sub.s       $f16, $f10, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x8039732C: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x80397330: nop

    // 0x80397334: cvt.w.s     $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    ctx->f16.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80397338: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x8039733C: nop

    // 0x80397340: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x80397344: bne         $t4, $zero, L_8039735C
    if (ctx->r12 != 0) {
        // 0x80397348: nop
    
            goto L_8039735C;
    }
    // 0x80397348: nop

    // 0x8039734C: mfc1        $t4, $f16
    ctx->r12 = (int32_t)ctx->f16.u32l;
    // 0x80397350: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80397354: b           L_80397374
    // 0x80397358: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
        goto L_80397374;
    // 0x80397358: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
L_8039735C:
    // 0x8039735C: b           L_80397374
    // 0x80397360: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
        goto L_80397374;
    // 0x80397360: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
L_80397364:
    // 0x80397364: mfc1        $t4, $f16
    ctx->r12 = (int32_t)ctx->f16.u32l;
    // 0x80397368: nop

    // 0x8039736C: bltz        $t4, L_8039735C
    if (SIGNED(ctx->r12) < 0) {
        // 0x80397370: nop
    
            goto L_8039735C;
    }
    // 0x80397370: nop

L_80397374:
    // 0x80397374: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80397378: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x8039737C: jal         0x8039C834
    // 0x80397380: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_11;
    // 0x80397380: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    after_11:
    // 0x80397384: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80397388:
    // 0x80397388: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8039738C: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x80397390: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x80397394: jr          $ra
    // 0x80397398: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
    return;
    // 0x80397398: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
;}
RECOMP_FUNC void func_803973A0_7A8A50(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803973A0: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x803973A4: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x803973A8: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x803973AC: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x803973B0: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x803973B4: addiu       $t8, $t8, 0x6890
    ctx->r24 = ADD32(ctx->r24, 0X6890);
    // 0x803973B8: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803973BC: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x803973C0: lw          $t9, 0x4($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X4);
    // 0x803973C4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x803973C8: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x803973CC: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x803973D0: lw          $a0, 0x8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X8);
    // 0x803973D4: lw          $t2, 0xC($v0)
    ctx->r10 = MEM_W(ctx->r2, 0XC);
    // 0x803973D8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803973DC: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x803973E0: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x803973E4: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    // 0x803973E8: jal         0x80139480
    // 0x803973EC: subu        $a1, $t2, $a0
    ctx->r5 = SUB32(ctx->r10, ctx->r4);
    osInvalDCache_recomp(rdram, ctx);
        goto after_0;
    // 0x803973EC: subu        $a1, $t2, $a0
    ctx->r5 = SUB32(ctx->r10, ctx->r4);
    after_0:
    // 0x803973F0: lw          $v0, 0x18($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X18);
    // 0x803973F4: lw          $a2, 0x1C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X1C);
    // 0x803973F8: lw          $a0, 0x0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X0);
    // 0x803973FC: jal         0x80129290
    // 0x80397400: lw          $a1, 0x10($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X10);
    dma_read(rdram, ctx);
        goto after_1;
    // 0x80397400: lw          $a1, 0x10($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X10);
    after_1:
    // 0x80397404: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80397408: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8039740C: jr          $ra
    // 0x80397410: nop

    return;
    // 0x80397410: nop

;}
RECOMP_FUNC void append_rig_modelview_transform_xlu(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397414: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80397418: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x8039741C: lui         $s1, 0x8020
    ctx->r17 = S32(0X8020 << 16);
    // 0x80397420: addiu       $s1, $s1, 0x4278
    ctx->r17 = ADD32(ctx->r17, 0X4278);
    // 0x80397424: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80397428: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8039742C: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x80397430: lui         $s2, 0x3
    ctx->r18 = S32(0X3 << 16);
    // 0x80397434: ori         $s2, $s2, 0x8000
    ctx->r18 = ctx->r18 | 0X8000;
    // 0x80397438: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8039743C: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x80397440: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80397444: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x80397448: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x8039744C: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x80397450: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x80397454: mtc1        $a1, $f12
    ctx->f12.u32l = ctx->r5;
    // 0x80397458: mtc1        $a2, $f14
    ctx->f14.u32l = ctx->r6;
    // 0x8039745C: lui         $s3, 0x3
    ctx->r19 = S32(0X3 << 16);
    // 0x80397460: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x80397464: ori         $s3, $s3, 0x3590
    ctx->r19 = ctx->r19 | 0X3590;
    // 0x80397468: andi        $s4, $a0, 0xFF
    ctx->r20 = ctx->r4 & 0XFF;
    // 0x8039746C: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x80397470: mfc1        $a1, $f12
    ctx->r5 = (int32_t)ctx->f12.u32l;
    // 0x80397474: mfc1        $a2, $f14
    ctx->r6 = (int32_t)ctx->f14.u32l;
    // 0x80397478: jal         0x8013F328
    // 0x8039747C: addu        $a0, $t9, $s3
    ctx->r4 = ADD32(ctx->r25, ctx->r19);
    guTranslate(rdram, ctx);
        goto after_0;
    // 0x8039747C: addu        $a0, $t9, $s3
    ctx->r4 = ADD32(ctx->r25, ctx->r19);
    after_0:
    // 0x80397480: beq         $s4, $zero, L_803974E4
    if (ctx->r20 == 0) {
        // 0x80397484: lui         $a3, 0x3F80
        ctx->r7 = S32(0X3F80 << 16);
            goto L_803974E4;
    }
    // 0x80397484: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x80397488: lui         $s4, 0x801E
    ctx->r20 = S32(0X801E << 16);
    // 0x8039748C: addiu       $s4, $s4, -0x6174
    ctx->r20 = ADD32(ctx->r20, -0X6174);
    // 0x80397490: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x80397494: lui         $t1, 0x104
    ctx->r9 = S32(0X104 << 16);
    // 0x80397498: ori         $t1, $t1, 0x40
    ctx->r9 = ctx->r9 | 0X40;
    // 0x8039749C: addiu       $t0, $v0, 0x8
    ctx->r8 = ADD32(ctx->r2, 0X8);
    // 0x803974A0: sw          $t0, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r8;
    // 0x803974A4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x803974A8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803974AC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803974B0: addu        $t2, $s0, $s2
    ctx->r10 = ADD32(ctx->r16, ctx->r18);
    // 0x803974B4: lw          $t3, 0x918($t2)
    ctx->r11 = MEM_W(ctx->r10, 0X918);
    // 0x803974B8: sll         $t4, $t3, 6
    ctx->r12 = S32(ctx->r11 << 6);
    // 0x803974BC: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    // 0x803974C0: addu        $t6, $t5, $s3
    ctx->r14 = ADD32(ctx->r13, ctx->r19);
    // 0x803974C4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803974C8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803974CC: addu        $t7, $s0, $s2
    ctx->r15 = ADD32(ctx->r16, ctx->r18);
    // 0x803974D0: lw          $t8, 0x918($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X918);
    // 0x803974D4: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x803974D8: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x803974DC: b           L_8039753C
    // 0x803974E0: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
        goto L_8039753C;
    // 0x803974E0: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
L_803974E4:
    // 0x803974E4: lui         $s4, 0x801E
    ctx->r20 = S32(0X801E << 16);
    // 0x803974E8: addiu       $s4, $s4, -0x6174
    ctx->r20 = ADD32(ctx->r20, -0X6174);
    // 0x803974EC: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x803974F0: lui         $t1, 0x100
    ctx->r9 = S32(0X100 << 16);
    // 0x803974F4: ori         $t1, $t1, 0x40
    ctx->r9 = ctx->r9 | 0X40;
    // 0x803974F8: addiu       $t0, $v0, 0x8
    ctx->r8 = ADD32(ctx->r2, 0X8);
    // 0x803974FC: sw          $t0, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r8;
    // 0x80397500: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x80397504: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397508: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039750C: addu        $t2, $s0, $s2
    ctx->r10 = ADD32(ctx->r16, ctx->r18);
    // 0x80397510: lw          $t3, 0x918($t2)
    ctx->r11 = MEM_W(ctx->r10, 0X918);
    // 0x80397514: sll         $t4, $t3, 6
    ctx->r12 = S32(ctx->r11 << 6);
    // 0x80397518: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    // 0x8039751C: addu        $t6, $t5, $s3
    ctx->r14 = ADD32(ctx->r13, ctx->r19);
    // 0x80397520: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80397524: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397528: addu        $t7, $s0, $s2
    ctx->r15 = ADD32(ctx->r16, ctx->r18);
    // 0x8039752C: lw          $t8, 0x918($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X918);
    // 0x80397530: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80397534: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80397538: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
L_8039753C:
    // 0x8039753C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397540: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80397544: lw          $a1, 0x4C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4C);
    // 0x80397548: addu        $t0, $s0, $s2
    ctx->r8 = ADD32(ctx->r16, ctx->r18);
    // 0x8039754C: lw          $t1, 0x918($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X918);
    // 0x80397550: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x80397554: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80397558: sll         $t2, $t1, 6
    ctx->r10 = S32(ctx->r9 << 6);
    // 0x8039755C: addu        $t3, $s0, $t2
    ctx->r11 = ADD32(ctx->r16, ctx->r10);
    // 0x80397560: jal         0x8013FB74
    // 0x80397564: addu        $a0, $t3, $s3
    ctx->r4 = ADD32(ctx->r11, ctx->r19);
    guRotate(rdram, ctx);
        goto after_1;
    // 0x80397564: addu        $a0, $t3, $s3
    ctx->r4 = ADD32(ctx->r11, ctx->r19);
    after_1:
    // 0x80397568: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x8039756C: lui         $t5, 0x100
    ctx->r13 = S32(0X100 << 16);
    // 0x80397570: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x80397574: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80397578: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8039757C: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80397580: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397584: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80397588: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x8039758C: addu        $t6, $s0, $s2
    ctx->r14 = ADD32(ctx->r16, ctx->r18);
    // 0x80397590: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x80397594: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x80397598: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x8039759C: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x803975A0: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x803975A4: addu        $t0, $t9, $s3
    ctx->r8 = ADD32(ctx->r25, ctx->r19);
    // 0x803975A8: sw          $t0, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r8;
    // 0x803975AC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803975B0: addu        $t1, $s0, $s2
    ctx->r9 = ADD32(ctx->r16, ctx->r18);
    // 0x803975B4: lw          $t2, 0x918($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X918);
    // 0x803975B8: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x803975BC: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x803975C0: sw          $t3, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r11;
    // 0x803975C4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803975C8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803975CC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x803975D0: addu        $t4, $s0, $s2
    ctx->r12 = ADD32(ctx->r16, ctx->r18);
    // 0x803975D4: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x803975D8: lw          $a1, 0x50($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X50);
    // 0x803975DC: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x803975E0: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x803975E4: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x803975E8: jal         0x8013FB74
    // 0x803975EC: addu        $a0, $t7, $s3
    ctx->r4 = ADD32(ctx->r15, ctx->r19);
    guRotate(rdram, ctx);
        goto after_2;
    // 0x803975EC: addu        $a0, $t7, $s3
    ctx->r4 = ADD32(ctx->r15, ctx->r19);
    after_2:
    // 0x803975F0: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x803975F4: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x803975F8: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x803975FC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80397600: sw          $t8, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r24;
    // 0x80397604: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80397608: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8039760C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80397610: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80397614: addu        $t0, $s0, $s2
    ctx->r8 = ADD32(ctx->r16, ctx->r18);
    // 0x80397618: lw          $t1, 0x918($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X918);
    // 0x8039761C: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x80397620: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    // 0x80397624: sll         $t2, $t1, 6
    ctx->r10 = S32(ctx->r9 << 6);
    // 0x80397628: addu        $t3, $s0, $t2
    ctx->r11 = ADD32(ctx->r16, ctx->r10);
    // 0x8039762C: addu        $t4, $t3, $s3
    ctx->r12 = ADD32(ctx->r11, ctx->r19);
    // 0x80397630: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80397634: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397638: addu        $t5, $s0, $s2
    ctx->r13 = ADD32(ctx->r16, ctx->r18);
    // 0x8039763C: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x80397640: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80397644: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80397648: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x8039764C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80397650: lw          $a1, 0x48($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X48);
    // 0x80397654: addu        $t8, $s0, $s2
    ctx->r24 = ADD32(ctx->r16, ctx->r18);
    // 0x80397658: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x8039765C: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x80397660: sll         $t0, $t9, 6
    ctx->r8 = S32(ctx->r25 << 6);
    // 0x80397664: addu        $t1, $s0, $t0
    ctx->r9 = ADD32(ctx->r16, ctx->r8);
    // 0x80397668: jal         0x8013FB74
    // 0x8039766C: addu        $a0, $t1, $s3
    ctx->r4 = ADD32(ctx->r9, ctx->r19);
    guRotate(rdram, ctx);
        goto after_3;
    // 0x8039766C: addu        $a0, $t1, $s3
    ctx->r4 = ADD32(ctx->r9, ctx->r19);
    after_3:
    // 0x80397670: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x80397674: lui         $t3, 0x100
    ctx->r11 = S32(0X100 << 16);
    // 0x80397678: ori         $t3, $t3, 0x40
    ctx->r11 = ctx->r11 | 0X40;
    // 0x8039767C: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x80397680: sw          $t2, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r10;
    // 0x80397684: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80397688: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8039768C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80397690: addu        $t4, $s0, $s2
    ctx->r12 = ADD32(ctx->r16, ctx->r18);
    // 0x80397694: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x80397698: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x8039769C: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x803976A0: addu        $t8, $t7, $s3
    ctx->r24 = ADD32(ctx->r15, ctx->r19);
    // 0x803976A4: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803976A8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803976AC: addu        $t9, $s0, $s2
    ctx->r25 = ADD32(ctx->r16, ctx->r18);
    // 0x803976B0: lw          $t0, 0x918($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X918);
    // 0x803976B4: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x803976B8: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x803976BC: sw          $t1, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r9;
    // 0x803976C0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x803976C4: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x803976C8: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x803976CC: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x803976D0: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x803976D4: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x803976D8: jr          $ra
    // 0x803976DC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x803976DC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void func_803976E0_7A8D90(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803976E0: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803976E4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803976E8: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803976EC: addiu       $a0, $a0, 0x713C
    ctx->r4 = ADD32(ctx->r4, 0X713C);
    // 0x803976F0: addiu       $a1, $a1, 0x7144
    ctx->r5 = ADD32(ctx->r5, 0X7144);
    // 0x803976F4: addiu       $a2, $a2, 0x714C
    ctx->r6 = ADD32(ctx->r6, 0X714C);
    // 0x803976F8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803976FC:
    // 0x803976FC: sll         $v1, $v0, 1
    ctx->r3 = S32(ctx->r2 << 1);
    // 0x80397700: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80397704: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x80397708: addu        $t6, $a0, $v1
    ctx->r14 = ADD32(ctx->r4, ctx->r3);
    // 0x8039770C: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80397710: sh          $zero, 0x0($t6)
    MEM_H(0X0, ctx->r14) = 0;
    // 0x80397714: addu        $t7, $a1, $v1
    ctx->r15 = ADD32(ctx->r5, ctx->r3);
    // 0x80397718: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x8039771C: sh          $zero, 0x0($t7)
    MEM_H(0X0, ctx->r15) = 0;
    // 0x80397720: addu        $t8, $a2, $v1
    ctx->r24 = ADD32(ctx->r6, ctx->r3);
    // 0x80397724: bne         $at, $zero, L_803976FC
    if (ctx->r1 != 0) {
        // 0x80397728: sh          $zero, 0x0($t8)
        MEM_H(0X0, ctx->r24) = 0;
            goto L_803976FC;
    }
    // 0x80397728: sh          $zero, 0x0($t8)
    MEM_H(0X0, ctx->r24) = 0;
    // 0x8039772C: jr          $ra
    // 0x80397730: nop

    return;
    // 0x80397730: nop

;}
RECOMP_FUNC void func_80397734_7A8DE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397734: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80397738: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x8039773C: lbu         $a3, 0x27($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X27);
    // 0x80397740: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x80397744: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80397748: sll         $t8, $a3, 1
    ctx->r24 = S32(ctx->r7 << 1);
    // 0x8039774C: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80397750: lh          $t9, 0x6B24($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6B24);
    // 0x80397754: or          $t7, $a0, $zero
    ctx->r15 = ctx->r4 | 0;
    // 0x80397758: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8039775C: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    // 0x80397760: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80397764: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80397768: sh          $a0, 0x22($sp)
    MEM_H(0X22, ctx->r29) = ctx->r4;
    // 0x8039776C: jal         0x803973A0
    // 0x80397770: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    func_803973A0_7A8A50(rdram, ctx);
        goto after_0;
    // 0x80397770: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    after_0:
    // 0x80397774: lbu         $v0, 0x27($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X27);
    // 0x80397778: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8039777C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80397780: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80397784: subu        $t4, $t4, $v0
    ctx->r12 = SUB32(ctx->r12, ctx->r2);
    // 0x80397788: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x8039778C: addu        $t4, $t4, $v0
    ctx->r12 = ADD32(ctx->r12, ctx->r2);
    // 0x80397790: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x80397794: sll         $t2, $v0, 2
    ctx->r10 = S32(ctx->r2 << 2);
    // 0x80397798: addu        $t2, $t2, $v0
    ctx->r10 = ADD32(ctx->r10, ctx->r2);
    // 0x8039779C: addu        $t4, $t4, $v0
    ctx->r12 = ADD32(ctx->r12, ctx->r2);
    // 0x803977A0: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x803977A4: sll         $t2, $t2, 2
    ctx->r10 = S32(ctx->r10 << 2);
    // 0x803977A8: addiu       $t5, $t5, 0x6720
    ctx->r13 = ADD32(ctx->r13, 0X6720);
    // 0x803977AC: addiu       $t3, $t3, 0x70F8
    ctx->r11 = ADD32(ctx->r11, 0X70F8);
    // 0x803977B0: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x803977B4: lw          $a3, 0x18($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X18);
    // 0x803977B8: addu        $a1, $t2, $t3
    ctx->r5 = ADD32(ctx->r10, ctx->r11);
    // 0x803977BC: addu        $a2, $t4, $t5
    ctx->r6 = ADD32(ctx->r12, ctx->r13);
    // 0x803977C0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x803977C4: addiu       $a0, $zero, 0x54
    ctx->r4 = ADD32(0, 0X54);
L_803977C8:
    // 0x803977C8: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803977CC: sll         $t6, $v1, 1
    ctx->r14 = S32(ctx->r3 << 1);
    // 0x803977D0: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x803977D4: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x803977D8: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803977DC: addu        $t7, $a1, $t6
    ctx->r15 = ADD32(ctx->r5, ctx->r14);
    // 0x803977E0: slti        $at, $v1, 0xA
    ctx->r1 = SIGNED(ctx->r3) < 0XA ? 1 : 0;
    // 0x803977E4: sh          $zero, 0x0($t7)
    MEM_H(0X0, ctx->r15) = 0;
    // 0x803977E8: mflo        $t8
    ctx->r24 = lo;
    // 0x803977EC: addu        $v0, $a2, $t8
    ctx->r2 = ADD32(ctx->r6, ctx->r24);
    // 0x803977F0: swc1        $f0, 0x48($v0)
    MEM_W(0X48, ctx->r2) = ctx->f0.u32l;
    // 0x803977F4: bne         $at, $zero, L_803977C8
    if (ctx->r1 != 0) {
        // 0x803977F8: swc1        $f0, 0x4C($v0)
        MEM_W(0X4C, ctx->r2) = ctx->f0.u32l;
            goto L_803977C8;
    }
    // 0x803977F8: swc1        $f0, 0x4C($v0)
    MEM_W(0X4C, ctx->r2) = ctx->f0.u32l;
    // 0x803977FC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80397800: addu        $at, $at, $a3
    ctx->r1 = ADD32(ctx->r1, ctx->r7);
    // 0x80397804: addiu       $t1, $zero, 0x3FF
    ctx->r9 = ADD32(0, 0X3FF);
    // 0x80397808: sh          $t1, 0x713C($at)
    MEM_H(0X713C, ctx->r1) = ctx->r9;
    // 0x8039780C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80397810: addu        $at, $at, $a3
    ctx->r1 = ADD32(ctx->r1, ctx->r7);
    // 0x80397814: sh          $zero, 0x714C($at)
    MEM_H(0X714C, ctx->r1) = 0;
    // 0x80397818: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039781C: addu        $at, $at, $a3
    ctx->r1 = ADD32(ctx->r1, ctx->r7);
    // 0x80397820: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80397824: sh          $zero, 0x7144($at)
    MEM_H(0X7144, ctx->r1) = 0;
    // 0x80397828: lh          $t2, 0x22($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X22);
    // 0x8039782C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80397830: addu        $at, $at, $a3
    ctx->r1 = ADD32(ctx->r1, ctx->r7);
    // 0x80397834: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80397838: jr          $ra
    // 0x8039783C: sh          $t2, 0x7134($at)
    MEM_H(0X7134, ctx->r1) = ctx->r10;
    return;
    // 0x8039783C: sh          $t2, 0x7134($at)
    MEM_H(0X7134, ctx->r1) = ctx->r10;
;}
RECOMP_FUNC void func_80397840_7A8EF0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397840: addiu       $sp, $sp, -0x68
    ctx->r29 = ADD32(ctx->r29, -0X68);
    // 0x80397844: sdc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X38, ctx->r29);
    // 0x80397848: lui         $at, 0x4700
    ctx->r1 = S32(0X4700 << 16);
    // 0x8039784C: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x80397850: sw          $s5, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r21;
    // 0x80397854: sdc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X30, ctx->r29);
    // 0x80397858: lui         $at, 0x4334
    ctx->r1 = S32(0X4334 << 16);
    // 0x8039785C: sw          $fp, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r30;
    // 0x80397860: sw          $s4, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r20;
    // 0x80397864: lui         $s5, 0x803B
    ctx->r21 = S32(0X803B << 16);
    // 0x80397868: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8039786C: sw          $ra, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r31;
    // 0x80397870: sw          $s7, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r23;
    // 0x80397874: sw          $s6, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r22;
    // 0x80397878: sw          $s3, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r19;
    // 0x8039787C: sw          $s2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r18;
    // 0x80397880: sw          $s1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r17;
    // 0x80397884: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x80397888: addiu       $s5, $s5, 0x7000
    ctx->r21 = ADD32(ctx->r21, 0X7000);
    // 0x8039788C: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x80397890: addiu       $fp, $zero, 0xC
    ctx->r30 = ADD32(0, 0XC);
L_80397894:
    // 0x80397894: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80397898: addiu       $t6, $t6, 0x713C
    ctx->r14 = ADD32(ctx->r14, 0X713C);
    // 0x8039789C: sll         $s1, $s4, 1
    ctx->r17 = S32(ctx->r20 << 1);
    // 0x803978A0: addu        $s2, $s1, $t6
    ctx->r18 = ADD32(ctx->r17, ctx->r14);
    // 0x803978A4: lhu         $t7, 0x0($s2)
    ctx->r15 = MEM_HU(ctx->r18, 0X0);
    // 0x803978A8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803978AC: addiu       $t8, $t8, 0x7134
    ctx->r24 = ADD32(ctx->r24, 0X7134);
    // 0x803978B0: beq         $t7, $zero, L_80397B34
    if (ctx->r15 == 0) {
        // 0x803978B4: addu        $s3, $s1, $t8
        ctx->r19 = ADD32(ctx->r17, ctx->r24);
            goto L_80397B34;
    }
    // 0x803978B4: addu        $s3, $s1, $t8
    ctx->r19 = ADD32(ctx->r17, ctx->r24);
    // 0x803978B8: lh          $t9, 0x0($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X0);
    // 0x803978BC: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x803978C0: addiu       $t3, $t3, 0x7144
    ctx->r11 = ADD32(ctx->r11, 0X7144);
    // 0x803978C4: sll         $t1, $t9, 3
    ctx->r9 = S32(ctx->r25 << 3);
    // 0x803978C8: addu        $t2, $s5, $t1
    ctx->r10 = ADD32(ctx->r21, ctx->r9);
    // 0x803978CC: lw          $v1, 0x4($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X4);
    // 0x803978D0: addu        $s0, $s1, $t3
    ctx->r16 = ADD32(ctx->r17, ctx->r11);
    // 0x803978D4: beq         $v1, $zero, L_80397960
    if (ctx->r3 == 0) {
        // 0x803978D8: nop
    
            goto L_80397960;
    }
    // 0x803978D8: nop

    // 0x803978DC: lh          $t4, 0x0($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X0);
    // 0x803978E0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803978E4: addiu       $t6, $t6, 0x714C
    ctx->r14 = ADD32(ctx->r14, 0X714C);
    // 0x803978E8: multu       $t4, $fp
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r30)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803978EC: addu        $s6, $s1, $t6
    ctx->r22 = ADD32(ctx->r17, ctx->r14);
    // 0x803978F0: lh          $t8, 0x0($s6)
    ctx->r24 = MEM_H(ctx->r22, 0X0);
    // 0x803978F4: mflo        $t5
    ctx->r13 = lo;
    // 0x803978F8: addu        $v0, $v1, $t5
    ctx->r2 = ADD32(ctx->r3, ctx->r13);
    // 0x803978FC: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x80397900: bne         $t7, $t8, L_80397960
    if (ctx->r15 != ctx->r24) {
        // 0x80397904: nop
    
            goto L_80397960;
    }
    // 0x80397904: nop

    // 0x80397908: lh          $a0, 0x2($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X2);
L_8039790C:
    // 0x8039790C: lh          $a1, 0x4($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X4);
    // 0x80397910: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80397914: jal         0x8032C508
    // 0x80397918: lw          $a3, 0x8($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X8);
    func_8032C508_73DBB8(rdram, ctx);
        goto after_0;
    // 0x80397918: lw          $a3, 0x8($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X8);
    after_0:
    // 0x8039791C: lh          $t2, 0x0($s3)
    ctx->r10 = MEM_H(ctx->r19, 0X0);
    // 0x80397920: lh          $t9, 0x0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X0);
    // 0x80397924: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x80397928: addu        $t4, $s5, $t3
    ctx->r12 = ADD32(ctx->r21, ctx->r11);
    // 0x8039792C: lw          $v1, 0x4($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X4);
    // 0x80397930: addiu       $t1, $t9, 0x1
    ctx->r9 = ADD32(ctx->r25, 0X1);
    // 0x80397934: sh          $t1, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r9;
    // 0x80397938: beq         $v1, $zero, L_80397960
    if (ctx->r3 == 0) {
        // 0x8039793C: nop
    
            goto L_80397960;
    }
    // 0x8039793C: nop

    // 0x80397940: lh          $t5, 0x0($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X0);
    // 0x80397944: lh          $t8, 0x0($s6)
    ctx->r24 = MEM_H(ctx->r22, 0X0);
    // 0x80397948: multu       $t5, $fp
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r30)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039794C: mflo        $t6
    ctx->r14 = lo;
    // 0x80397950: addu        $v0, $v1, $t6
    ctx->r2 = ADD32(ctx->r3, ctx->r14);
    // 0x80397954: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x80397958: beql        $t7, $t8, L_8039790C
    if (ctx->r15 == ctx->r24) {
        // 0x8039795C: lh          $a0, 0x2($v0)
        ctx->r4 = MEM_H(ctx->r2, 0X2);
            goto L_8039790C;
    }
    goto skip_0;
    // 0x8039795C: lh          $a0, 0x2($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X2);
    skip_0:
L_80397960:
    // 0x80397960: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80397964: addiu       $t9, $t9, 0x714C
    ctx->r25 = ADD32(ctx->r25, 0X714C);
    // 0x80397968: addu        $s6, $s1, $t9
    ctx->r22 = ADD32(ctx->r17, ctx->r25);
    // 0x8039796C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80397970: andi        $s7, $s4, 0xFF
    ctx->r23 = ctx->r20 & 0XFF;
    // 0x80397974: lhu         $v1, 0x0($s2)
    ctx->r3 = MEM_HU(ctx->r18, 0X0);
L_80397978:
    // 0x80397978: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8039797C: sllv        $a0, $t1, $s0
    ctx->r4 = S32(ctx->r9 << (ctx->r16 & 31));
    // 0x80397980: and         $t2, $v1, $a0
    ctx->r10 = ctx->r3 & ctx->r4;
    // 0x80397984: beq         $t2, $zero, L_80397B08
    if (ctx->r10 == 0) {
        // 0x80397988: sll         $t3, $s4, 2
        ctx->r11 = S32(ctx->r20 << 2);
            goto L_80397B08;
    }
    // 0x80397988: sll         $t3, $s4, 2
    ctx->r11 = S32(ctx->r20 << 2);
    // 0x8039798C: subu        $t3, $t3, $s4
    ctx->r11 = SUB32(ctx->r11, ctx->r20);
    // 0x80397990: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x80397994: sll         $t4, $s0, 2
    ctx->r12 = S32(ctx->r16 << 2);
    // 0x80397998: addu        $t4, $t4, $s0
    ctx->r12 = ADD32(ctx->r12, ctx->r16);
    // 0x8039799C: addu        $t3, $t3, $s4
    ctx->r11 = ADD32(ctx->r11, ctx->r20);
    // 0x803979A0: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x803979A4: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x803979A8: addu        $t4, $t4, $s0
    ctx->r12 = ADD32(ctx->r12, ctx->r16);
    // 0x803979AC: addu        $t3, $t3, $s4
    ctx->r11 = ADD32(ctx->r11, ctx->r20);
    // 0x803979B0: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x803979B4: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x803979B8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803979BC: addiu       $t6, $t6, 0x6720
    ctx->r14 = ADD32(ctx->r14, 0X6720);
    // 0x803979C0: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x803979C4: addu        $v0, $t5, $t6
    ctx->r2 = ADD32(ctx->r13, ctx->r14);
    // 0x803979C8: lwc1        $f4, 0x48($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X48);
    // 0x803979CC: lwc1        $f6, 0x4C($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0X4C);
    // 0x803979D0: sll         $t7, $s4, 2
    ctx->r15 = S32(ctx->r20 << 2);
    // 0x803979D4: addu        $t7, $t7, $s4
    ctx->r15 = ADD32(ctx->r15, ctx->r20);
    // 0x803979D8: c.le.s      $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f6.fl <= ctx->f4.fl;
    // 0x803979DC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803979E0: sll         $t8, $s0, 1
    ctx->r24 = S32(ctx->r16 << 1);
    // 0x803979E4: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x803979E8: bc1f        L_80397B08
    if (!c1cs) {
        // 0x803979EC: lui         $t1, 0x803F
        ctx->r9 = S32(0X803F << 16);
            goto L_80397B08;
    }
    // 0x803979EC: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803979F0: lh          $t2, 0x0($s3)
    ctx->r10 = MEM_H(ctx->r19, 0X0);
    // 0x803979F4: addiu       $t1, $t1, 0x70F8
    ctx->r9 = ADD32(ctx->r9, 0X70F8);
    // 0x803979F8: sll         $t5, $s0, 3
    ctx->r13 = S32(ctx->r16 << 3);
    // 0x803979FC: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x80397A00: addu        $t4, $s5, $t3
    ctx->r12 = ADD32(ctx->r21, ctx->r11);
    // 0x80397A04: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x80397A08: addu        $s1, $t9, $t1
    ctx->r17 = ADD32(ctx->r25, ctx->r9);
    // 0x80397A0C: lh          $a1, 0x0($s1)
    ctx->r5 = MEM_H(ctx->r17, 0X0);
    // 0x80397A10: addu        $t0, $v0, $t5
    ctx->r8 = ADD32(ctx->r2, ctx->r13);
    // 0x80397A14: lh          $t6, 0x8($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X8);
    // 0x80397A18: nor         $t7, $a0, $zero
    ctx->r15 = ~(ctx->r4 | 0);
    // 0x80397A1C: and         $t8, $v1, $t7
    ctx->r24 = ctx->r3 & ctx->r15;
    // 0x80397A20: slt         $at, $a1, $t6
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80397A24: bne         $at, $zero, L_80397A34
    if (ctx->r1 != 0) {
        // 0x80397A28: sll         $t1, $a1, 3
        ctx->r9 = S32(ctx->r5 << 3);
            goto L_80397A34;
    }
    // 0x80397A28: sll         $t1, $a1, 3
    ctx->r9 = S32(ctx->r5 << 3);
    // 0x80397A2C: b           L_80397B08
    // 0x80397A30: sh          $t8, 0x0($s2)
    MEM_H(0X0, ctx->r18) = ctx->r24;
        goto L_80397B08;
    // 0x80397A30: sh          $t8, 0x0($s2)
    MEM_H(0X0, ctx->r18) = ctx->r24;
L_80397A34:
    // 0x80397A34: lw          $t9, 0x4($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X4);
    // 0x80397A38: subu        $t1, $t1, $a1
    ctx->r9 = SUB32(ctx->r9, ctx->r5);
    // 0x80397A3C: sll         $t1, $t1, 1
    ctx->r9 = S32(ctx->r9 << 1);
    // 0x80397A40: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x80397A44: lh          $t2, 0x4($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X4);
    // 0x80397A48: lh          $t3, 0x0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X0);
    // 0x80397A4C: lh          $t4, 0x2($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2);
    // 0x80397A50: mtc1        $t2, $f8
    ctx->f8.u32l = ctx->r10;
    // 0x80397A54: mtc1        $t3, $f6
    ctx->f6.u32l = ctx->r11;
    // 0x80397A58: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    // 0x80397A5C: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80397A60: lh          $t7, 0xA($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XA);
    // 0x80397A64: lh          $t5, 0x6($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X6);
    // 0x80397A68: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80397A6C: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80397A70: mul.s       $f4, $f10, $f20
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f20.fl);
    // 0x80397A74: div.s       $f12, $f4, $f22
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f12.fl = DIV_S(ctx->f4.fl, ctx->f22.fl);
    // 0x80397A78: mtc1        $t4, $f4
    ctx->f4.u32l = ctx->r12;
    // 0x80397A7C: nop

    // 0x80397A80: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80397A84: mul.s       $f10, $f8, $f20
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f20.fl);
    // 0x80397A88: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80397A8C: mul.s       $f8, $f6, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f20.fl);
    // 0x80397A90: div.s       $f14, $f10, $f22
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f14.fl = DIV_S(ctx->f10.fl, ctx->f22.fl);
    // 0x80397A94: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x80397A98: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x80397A9C: cvt.s.w     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80397AA0: cvt.s.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80397AA4: div.s       $f0, $f8, $f22
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f0.fl = DIV_S(ctx->f8.fl, ctx->f22.fl);
    // 0x80397AA8: neg.s       $f16, $f16
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f16.fl = -ctx->f16.fl;
    // 0x80397AAC: neg.s       $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = -ctx->f18.fl;
    // 0x80397AB0: cvt.s.w     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80397AB4: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    // 0x80397AB8: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x80397ABC: lhu         $t8, 0xC($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XC);
    // 0x80397AC0: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x80397AC4: mfc1        $a3, $f2
    ctx->r7 = (int32_t)ctx->f2.u32l;
    // 0x80397AC8: neg.s       $f14, $f14
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f14.fl = -ctx->f14.fl;
    // 0x80397ACC: neg.s       $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = -ctx->f0.fl;
    // 0x80397AD0: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80397AD4: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x80397AD8: bgezl       $t8, L_80397AF0
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80397ADC: swc1        $f10, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
            goto L_80397AF0;
    }
    goto skip_1;
    // 0x80397ADC: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
    skip_1:
    // 0x80397AE0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80397AE4: nop

    // 0x80397AE8: add.s       $f10, $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f4.fl;
    // 0x80397AEC: swc1        $f10, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f10.u32l;
L_80397AF0:
    // 0x80397AF0: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x80397AF4: jal         0x80397C58
    // 0x80397AF8: sw          $s7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r23;
    func_80397C58_7A9308(rdram, ctx);
        goto after_1;
    // 0x80397AF8: sw          $s7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r23;
    after_1:
    // 0x80397AFC: lh          $t9, 0x0($s1)
    ctx->r25 = MEM_H(ctx->r17, 0X0);
    // 0x80397B00: addiu       $t1, $t9, 0x1
    ctx->r9 = ADD32(ctx->r25, 0X1);
    // 0x80397B04: sh          $t1, 0x0($s1)
    MEM_H(0X0, ctx->r17) = ctx->r9;
L_80397B08:
    // 0x80397B08: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80397B0C: sll         $t2, $s0, 16
    ctx->r10 = S32(ctx->r16 << 16);
    // 0x80397B10: sra         $s0, $t2, 16
    ctx->r16 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80397B14: slti        $at, $s0, 0xA
    ctx->r1 = SIGNED(ctx->r16) < 0XA ? 1 : 0;
    // 0x80397B18: bnel        $at, $zero, L_80397978
    if (ctx->r1 != 0) {
        // 0x80397B1C: lhu         $v1, 0x0($s2)
        ctx->r3 = MEM_HU(ctx->r18, 0X0);
            goto L_80397978;
    }
    goto skip_2;
    // 0x80397B1C: lhu         $v1, 0x0($s2)
    ctx->r3 = MEM_HU(ctx->r18, 0X0);
    skip_2:
    // 0x80397B20: jal         0x80397D1C
    // 0x80397B24: andi        $a0, $s7, 0xFF
    ctx->r4 = ctx->r23 & 0XFF;
    func_80397D1C_7A93CC(rdram, ctx);
        goto after_2;
    // 0x80397B24: andi        $a0, $s7, 0xFF
    ctx->r4 = ctx->r23 & 0XFF;
    after_2:
    // 0x80397B28: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    // 0x80397B2C: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x80397B30: sh          $t5, 0x0($s6)
    MEM_H(0X0, ctx->r22) = ctx->r13;
L_80397B34:
    // 0x80397B34: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    // 0x80397B38: sll         $t6, $s4, 16
    ctx->r14 = S32(ctx->r20 << 16);
    // 0x80397B3C: sra         $s4, $t6, 16
    ctx->r20 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80397B40: slti        $at, $s4, 0x3
    ctx->r1 = SIGNED(ctx->r20) < 0X3 ? 1 : 0;
    // 0x80397B44: bne         $at, $zero, L_80397894
    if (ctx->r1 != 0) {
        // 0x80397B48: nop
    
            goto L_80397894;
    }
    // 0x80397B48: nop

    // 0x80397B4C: lw          $ra, 0x64($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X64);
    // 0x80397B50: ldc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X30);
    // 0x80397B54: ldc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X38);
    // 0x80397B58: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x80397B5C: lw          $s1, 0x44($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X44);
    // 0x80397B60: lw          $s2, 0x48($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X48);
    // 0x80397B64: lw          $s3, 0x4C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X4C);
    // 0x80397B68: lw          $s4, 0x50($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X50);
    // 0x80397B6C: lw          $s5, 0x54($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X54);
    // 0x80397B70: lw          $s6, 0x58($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X58);
    // 0x80397B74: lw          $s7, 0x5C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X5C);
    // 0x80397B78: lw          $fp, 0x60($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X60);
    // 0x80397B7C: jr          $ra
    // 0x80397B80: addiu       $sp, $sp, 0x68
    ctx->r29 = ADD32(ctx->r29, 0X68);
    return;
    // 0x80397B80: addiu       $sp, $sp, 0x68
    ctx->r29 = ADD32(ctx->r29, 0X68);
;}
RECOMP_FUNC void func_80397B84_7A9234(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397B84: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80397B88: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80397B8C: addiu       $t0, $zero, 0x54
    ctx->r8 = ADD32(0, 0X54);
    // 0x80397B90: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
L_80397B94:
    // 0x80397B94: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x80397B98: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80397B9C: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x80397BA0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80397BA4: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x80397BA8: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80397BAC: addiu       $t7, $t7, 0x6720
    ctx->r15 = ADD32(ctx->r15, 0X6720);
    // 0x80397BB0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80397BB4: addu        $a1, $t6, $t7
    ctx->r5 = ADD32(ctx->r14, ctx->r15);
    // 0x80397BB8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_80397BBC:
    // 0x80397BBC: sll         $t8, $v1, 2
    ctx->r24 = S32(ctx->r3 << 2);
    // 0x80397BC0: addu        $t8, $t8, $v1
    ctx->r24 = ADD32(ctx->r24, ctx->r3);
    // 0x80397BC4: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80397BC8: addu        $t8, $t8, $v1
    ctx->r24 = ADD32(ctx->r24, ctx->r3);
    // 0x80397BCC: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80397BD0: addu        $a2, $a1, $t8
    ctx->r6 = ADD32(ctx->r5, ctx->r24);
    // 0x80397BD4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80397BD8:
    // 0x80397BD8: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x80397BDC: addu        $a3, $a2, $t9
    ctx->r7 = ADD32(ctx->r6, ctx->r25);
    // 0x80397BE0: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80397BE4: sll         $t1, $a0, 16
    ctx->r9 = S32(ctx->r4 << 16);
    // 0x80397BE8: sra         $a0, $t1, 16
    ctx->r4 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80397BEC: slti        $at, $a0, 0x3
    ctx->r1 = SIGNED(ctx->r4) < 0X3 ? 1 : 0;
    // 0x80397BF0: swc1        $f0, 0x18($a3)
    MEM_W(0X18, ctx->r7) = ctx->f0.u32l;
    // 0x80397BF4: swc1        $f0, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->f0.u32l;
    // 0x80397BF8: swc1        $f0, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->f0.u32l;
    // 0x80397BFC: swc1        $f0, 0xC($a3)
    MEM_W(0XC, ctx->r7) = ctx->f0.u32l;
    // 0x80397C00: swc1        $f0, 0x30($a3)
    MEM_W(0X30, ctx->r7) = ctx->f0.u32l;
    // 0x80397C04: bne         $at, $zero, L_80397BD8
    if (ctx->r1 != 0) {
        // 0x80397C08: swc1        $f0, 0x3C($a3)
        MEM_W(0X3C, ctx->r7) = ctx->f0.u32l;
            goto L_80397BD8;
    }
    // 0x80397C08: swc1        $f0, 0x3C($a3)
    MEM_W(0X3C, ctx->r7) = ctx->f0.u32l;
    // 0x80397C0C: multu       $v1, $t0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80397C10: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80397C14: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x80397C18: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80397C1C: slti        $at, $v1, 0xA
    ctx->r1 = SIGNED(ctx->r3) < 0XA ? 1 : 0;
    // 0x80397C20: mflo        $t3
    ctx->r11 = lo;
    // 0x80397C24: addu        $a0, $a1, $t3
    ctx->r4 = ADD32(ctx->r5, ctx->r11);
    // 0x80397C28: swc1        $f0, 0x48($a0)
    MEM_W(0X48, ctx->r4) = ctx->f0.u32l;
    // 0x80397C2C: swc1        $f0, 0x4C($a0)
    MEM_W(0X4C, ctx->r4) = ctx->f0.u32l;
    // 0x80397C30: bne         $at, $zero, L_80397BBC
    if (ctx->r1 != 0) {
        // 0x80397C34: sh          $zero, 0x50($a0)
        MEM_H(0X50, ctx->r4) = 0;
            goto L_80397BBC;
    }
    // 0x80397C34: sh          $zero, 0x50($a0)
    MEM_H(0X50, ctx->r4) = 0;
    // 0x80397C38: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80397C3C: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x80397C40: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80397C44: slti        $at, $v0, 0x3
    ctx->r1 = SIGNED(ctx->r2) < 0X3 ? 1 : 0;
    // 0x80397C48: bnel        $at, $zero, L_80397B94
    if (ctx->r1 != 0) {
        // 0x80397C4C: sll         $t6, $v0, 2
        ctx->r14 = S32(ctx->r2 << 2);
            goto L_80397B94;
    }
    goto skip_0;
    // 0x80397C4C: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    skip_0:
    // 0x80397C50: jr          $ra
    // 0x80397C54: nop

    return;
    // 0x80397C54: nop

;}
RECOMP_FUNC void func_80397C58_7A9308(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397C58: lbu         $t6, 0x23($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X23);
    // 0x80397C5C: lh          $t8, 0x1E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X1E);
    // 0x80397C60: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80397C64: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80397C68: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x80397C6C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80397C70: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x80397C74: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80397C78: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80397C7C: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80397C80: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80397C84: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80397C88: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80397C8C: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80397C90: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80397C94: addu        $t0, $t7, $t9
    ctx->r8 = ADD32(ctx->r15, ctx->r25);
    // 0x80397C98: addiu       $t1, $t1, 0x6720
    ctx->r9 = ADD32(ctx->r9, 0X6720);
    // 0x80397C9C: addu        $v0, $t0, $t1
    ctx->r2 = ADD32(ctx->r8, ctx->r9);
    // 0x80397CA0: lwc1        $f4, 0x0($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X0);
    // 0x80397CA4: lwc1        $f6, 0x4($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0X4);
    // 0x80397CA8: lwc1        $f8, 0x8($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X8);
    // 0x80397CAC: lwc1        $f10, 0xC($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XC);
    // 0x80397CB0: lwc1        $f16, 0x10($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X10);
    // 0x80397CB4: lwc1        $f18, 0x14($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X14);
    // 0x80397CB8: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80397CBC: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80397CC0: swc1        $f4, 0x18($v0)
    MEM_W(0X18, ctx->r2) = ctx->f4.u32l;
    // 0x80397CC4: swc1        $f6, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = ctx->f6.u32l;
    // 0x80397CC8: swc1        $f8, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->f8.u32l;
    // 0x80397CCC: swc1        $f10, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->f10.u32l;
    // 0x80397CD0: swc1        $f16, 0x28($v0)
    MEM_W(0X28, ctx->r2) = ctx->f16.u32l;
    // 0x80397CD4: swc1        $f18, 0x2C($v0)
    MEM_W(0X2C, ctx->r2) = ctx->f18.u32l;
    // 0x80397CD8: lwc1        $f4, 0x8($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X8);
    // 0x80397CDC: lwc1        $f6, 0xC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XC);
    // 0x80397CE0: lwc1        $f8, 0x10($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X10);
    // 0x80397CE4: lwc1        $f10, 0x14($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X14);
    // 0x80397CE8: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x80397CEC: lwc1        $f18, 0x18($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X18);
    // 0x80397CF0: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80397CF4: swc1        $f12, 0x30($v0)
    MEM_W(0X30, ctx->r2) = ctx->f12.u32l;
    // 0x80397CF8: swc1        $f14, 0x34($v0)
    MEM_W(0X34, ctx->r2) = ctx->f14.u32l;
    // 0x80397CFC: sh          $t2, 0x50($v0)
    MEM_H(0X50, ctx->r2) = ctx->r10;
    // 0x80397D00: swc1        $f4, 0x38($v0)
    MEM_W(0X38, ctx->r2) = ctx->f4.u32l;
    // 0x80397D04: swc1        $f6, 0x3C($v0)
    MEM_W(0X3C, ctx->r2) = ctx->f6.u32l;
    // 0x80397D08: swc1        $f8, 0x40($v0)
    MEM_W(0X40, ctx->r2) = ctx->f8.u32l;
    // 0x80397D0C: swc1        $f10, 0x44($v0)
    MEM_W(0X44, ctx->r2) = ctx->f10.u32l;
    // 0x80397D10: swc1        $f16, 0x48($v0)
    MEM_W(0X48, ctx->r2) = ctx->f16.u32l;
    // 0x80397D14: jr          $ra
    // 0x80397D18: swc1        $f18, 0x4C($v0)
    MEM_W(0X4C, ctx->r2) = ctx->f18.u32l;
    return;
    // 0x80397D18: swc1        $f18, 0x4C($v0)
    MEM_W(0X4C, ctx->r2) = ctx->f18.u32l;
;}
RECOMP_FUNC void func_80397D1C_7A93CC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397D1C: addiu       $sp, $sp, -0x78
    ctx->r29 = ADD32(ctx->r29, -0X78);
    // 0x80397D20: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80397D24: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80397D28: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x80397D2C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80397D30: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80397D34: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80397D38: sdc1        $f20, 0x10($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X10, ctx->r29);
    // 0x80397D3C: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80397D40: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80397D44: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80397D48: sw          $s3, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r19;
    // 0x80397D4C: sw          $s2, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r18;
    // 0x80397D50: sw          $s1, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r17;
    // 0x80397D54: addiu       $t8, $t8, 0x6720
    ctx->r24 = ADD32(ctx->r24, 0X6720);
    // 0x80397D58: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80397D5C: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x80397D60: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x80397D64: sw          $s0, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r16;
    // 0x80397D68: sdc1        $f30, 0x38($sp)
    CHECK_FR(ctx, 30);
    SD(ctx->f30.u64, 0X38, ctx->r29);
    // 0x80397D6C: sdc1        $f28, 0x30($sp)
    CHECK_FR(ctx, 28);
    SD(ctx->f28.u64, 0X30, ctx->r29);
    // 0x80397D70: sdc1        $f26, 0x28($sp)
    CHECK_FR(ctx, 26);
    SD(ctx->f26.u64, 0X28, ctx->r29);
    // 0x80397D74: sdc1        $f24, 0x20($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X20, ctx->r29);
    // 0x80397D78: sdc1        $f22, 0x18($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X18, ctx->r29);
    // 0x80397D7C: sw          $a0, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r4;
    // 0x80397D80: addu        $s3, $t7, $t8
    ctx->r19 = ADD32(ctx->r15, ctx->r24);
    // 0x80397D84: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80397D88: addiu       $s2, $zero, 0x54
    ctx->r18 = ADD32(0, 0X54);
L_80397D8C:
    // 0x80397D8C: multu       $s1, $s2
    result = U64(U32(ctx->r17)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80397D90: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80397D94: mflo        $t9
    ctx->r25 = lo;
    // 0x80397D98: addu        $s0, $s3, $t9
    ctx->r16 = ADD32(ctx->r19, ctx->r25);
    // 0x80397D9C: lh          $t0, 0x50($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X50);
    // 0x80397DA0: beql        $t0, $zero, L_80397F14
    if (ctx->r8 == 0) {
        // 0x80397DA4: addiu       $s1, $s1, 0x1
        ctx->r17 = ADD32(ctx->r17, 0X1);
            goto L_80397F14;
    }
    goto skip_0;
    // 0x80397DA4: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    skip_0:
    // 0x80397DA8: lwc1        $f4, 0x48($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X48);
    // 0x80397DAC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80397DB0: lwc1        $f14, 0x4C($s0)
    ctx->f14.u32l = MEM_W(ctx->r16, 0X4C);
    // 0x80397DB4: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x80397DB8: swc1        $f8, 0x48($s0)
    MEM_W(0X48, ctx->r16) = ctx->f8.u32l;
    // 0x80397DBC: lwc1        $f2, 0x48($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X48);
    // 0x80397DC0: c.le.s      $f14, $f2
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f14.fl <= ctx->f2.fl;
    // 0x80397DC4: nop

    // 0x80397DC8: bc1fl       L_80397E0C
    if (!c1cs) {
        // 0x80397DCC: lwc1        $f18, 0x30($s0)
        ctx->f18.u32l = MEM_W(ctx->r16, 0X30);
            goto L_80397E0C;
    }
    goto skip_1;
    // 0x80397DCC: lwc1        $f18, 0x30($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X30);
    skip_1:
    // 0x80397DD0: lwc1        $f10, 0x30($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X30);
    // 0x80397DD4: lwc1        $f18, 0x34($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X34);
    // 0x80397DD8: lwc1        $f4, 0x38($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X38);
    // 0x80397DDC: swc1        $f10, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f10.u32l;
    // 0x80397DE0: lwc1        $f6, 0x3C($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X3C);
    // 0x80397DE4: lwc1        $f8, 0x40($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X40);
    // 0x80397DE8: lwc1        $f10, 0x44($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X44);
    // 0x80397DEC: sh          $zero, 0x50($s0)
    MEM_H(0X50, ctx->r16) = 0;
    // 0x80397DF0: swc1        $f18, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f18.u32l;
    // 0x80397DF4: swc1        $f4, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->f4.u32l;
    // 0x80397DF8: swc1        $f6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f6.u32l;
    // 0x80397DFC: swc1        $f8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f8.u32l;
    // 0x80397E00: b           L_80397F10
    // 0x80397E04: swc1        $f10, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f10.u32l;
        goto L_80397F10;
    // 0x80397E04: swc1        $f10, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f10.u32l;
    // 0x80397E08: lwc1        $f18, 0x30($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X30);
L_80397E0C:
    // 0x80397E0C: lwc1        $f4, 0x18($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X18);
    // 0x80397E10: lwc1        $f8, 0x34($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X34);
    // 0x80397E14: lwc1        $f10, 0x1C($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x80397E18: sub.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x80397E1C: lwc1        $f4, 0x38($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X38);
    // 0x80397E20: lui         $at, 0x4334
    ctx->r1 = S32(0X4334 << 16);
    // 0x80397E24: sub.s       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x80397E28: lwc1        $f10, 0x3C($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X3C);
    // 0x80397E2C: div.s       $f22, $f6, $f20
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f22.fl = DIV_S(ctx->f6.fl, ctx->f20.fl);
    // 0x80397E30: lwc1        $f6, 0x20($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X20);
    // 0x80397E34: sub.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x80397E38: lwc1        $f6, 0x40($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X40);
    // 0x80397E3C: div.s       $f24, $f18, $f20
    CHECK_FR(ctx, 24);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f24.fl = DIV_S(ctx->f18.fl, ctx->f20.fl);
    // 0x80397E40: lwc1        $f18, 0x24($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X24);
    // 0x80397E44: sub.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f18.fl;
    // 0x80397E48: lwc1        $f18, 0x44($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X44);
    // 0x80397E4C: div.s       $f26, $f8, $f20
    CHECK_FR(ctx, 26);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f26.fl = DIV_S(ctx->f8.fl, ctx->f20.fl);
    // 0x80397E50: lwc1        $f8, 0x28($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80397E54: sub.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x80397E58: div.s       $f8, $f2, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = DIV_S(ctx->f2.fl, ctx->f14.fl);
    // 0x80397E5C: div.s       $f28, $f4, $f20
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f28.fl = DIV_S(ctx->f4.fl, ctx->f20.fl);
    // 0x80397E60: lwc1        $f4, 0x2C($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X2C);
    // 0x80397E64: sub.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x80397E68: div.s       $f16, $f6, $f20
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f16.fl = DIV_S(ctx->f6.fl, ctx->f20.fl);
    // 0x80397E6C: div.s       $f30, $f10, $f20
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f30.fl = DIV_S(ctx->f10.fl, ctx->f20.fl);
    // 0x80397E70: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80397E74: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80397E78: ldc1        $f4, 0x390($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, 0X390);
    // 0x80397E7C: mul.s       $f0, $f8, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f0.fl = MUL_S(ctx->f8.fl, ctx->f10.fl);
    // 0x80397E80: swc1        $f16, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->f16.u32l;
    // 0x80397E84: cvt.d.s     $f18, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f18.d = CVT_D_S(ctx->f0.fl);
    // 0x80397E88: mul.d       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = MUL_D(ctx->f18.d, ctx->f4.d);
    // 0x80397E8C: jal         0x8013FD70
    // 0x80397E90: cvt.s.d     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f12.fl = CVT_S_D(ctx->f6.d);
    __cosf_recomp(rdram, ctx);
        goto after_0;
    // 0x80397E90: cvt.s.d     $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f12.fl = CVT_S_D(ctx->f6.d);
    after_0:
    // 0x80397E94: mul.s       $f18, $f22, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f22.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = MUL_S(ctx->f22.fl, ctx->f0.fl);
    // 0x80397E98: lwc1        $f8, 0x18($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X18);
    // 0x80397E9C: lwc1        $f6, 0x1C($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x80397EA0: lwc1        $f16, 0x5C($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X5C);
    // 0x80397EA4: add.s       $f10, $f8, $f22
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f22.fl;
    // 0x80397EA8: add.s       $f8, $f6, $f24
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f24.fl;
    // 0x80397EAC: sub.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f18.fl;
    // 0x80397EB0: mul.s       $f10, $f24, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 24);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f24.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f24.fl, ctx->f0.fl);
    // 0x80397EB4: swc1        $f4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f4.u32l;
    // 0x80397EB8: lwc1        $f4, 0x20($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X20);
    // 0x80397EBC: sub.s       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x80397EC0: mul.s       $f8, $f26, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 26);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f26.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f26.fl, ctx->f0.fl);
    // 0x80397EC4: add.s       $f6, $f4, $f26
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 26);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f26.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f26.fl;
    // 0x80397EC8: swc1        $f18, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f18.u32l;
    // 0x80397ECC: lwc1        $f18, 0x24($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X24);
    // 0x80397ED0: sub.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x80397ED4: mul.s       $f6, $f28, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f28.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f28.fl, ctx->f0.fl);
    // 0x80397ED8: add.s       $f4, $f18, $f28
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 28);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f28.fl); 
    ctx->f4.fl = ctx->f18.fl + ctx->f28.fl;
    // 0x80397EDC: swc1        $f10, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->f10.u32l;
    // 0x80397EE0: lwc1        $f10, 0x28($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80397EE4: sub.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x80397EE8: mul.s       $f4, $f30, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f30.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f30.fl, ctx->f0.fl);
    // 0x80397EEC: add.s       $f18, $f10, $f30
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 30);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f30.fl); 
    ctx->f18.fl = ctx->f10.fl + ctx->f30.fl;
    // 0x80397EF0: swc1        $f8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f8.u32l;
    // 0x80397EF4: lwc1        $f8, 0x2C($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X2C);
    // 0x80397EF8: sub.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl - ctx->f4.fl;
    // 0x80397EFC: mul.s       $f18, $f16, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = MUL_S(ctx->f16.fl, ctx->f0.fl);
    // 0x80397F00: add.s       $f10, $f8, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f16.fl;
    // 0x80397F04: swc1        $f6, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f6.u32l;
    // 0x80397F08: sub.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f18.fl;
    // 0x80397F0C: swc1        $f4, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f4.u32l;
L_80397F10:
    // 0x80397F10: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
L_80397F14:
    // 0x80397F14: sll         $t1, $s1, 16
    ctx->r9 = S32(ctx->r17 << 16);
    // 0x80397F18: sra         $s1, $t1, 16
    ctx->r17 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80397F1C: slti        $at, $s1, 0xA
    ctx->r1 = SIGNED(ctx->r17) < 0XA ? 1 : 0;
    // 0x80397F20: bne         $at, $zero, L_80397D8C
    if (ctx->r1 != 0) {
        // 0x80397F24: nop
    
            goto L_80397D8C;
    }
    // 0x80397F24: nop

    // 0x80397F28: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x80397F2C: ldc1        $f20, 0x10($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X10);
    // 0x80397F30: ldc1        $f22, 0x18($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X18);
    // 0x80397F34: ldc1        $f24, 0x20($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X20);
    // 0x80397F38: ldc1        $f26, 0x28($sp)
    CHECK_FR(ctx, 26);
    ctx->f26.u64 = LD(ctx->r29, 0X28);
    // 0x80397F3C: ldc1        $f28, 0x30($sp)
    CHECK_FR(ctx, 28);
    ctx->f28.u64 = LD(ctx->r29, 0X30);
    // 0x80397F40: ldc1        $f30, 0x38($sp)
    CHECK_FR(ctx, 30);
    ctx->f30.u64 = LD(ctx->r29, 0X38);
    // 0x80397F44: lw          $s0, 0x44($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X44);
    // 0x80397F48: lw          $s1, 0x48($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X48);
    // 0x80397F4C: lw          $s2, 0x4C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X4C);
    // 0x80397F50: lw          $s3, 0x50($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X50);
    // 0x80397F54: jr          $ra
    // 0x80397F58: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
    return;
    // 0x80397F58: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
;}
RECOMP_FUNC void render_rig_instance_xlu(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80397F5C: addiu       $sp, $sp, -0xB8
    ctx->r29 = ADD32(ctx->r29, -0XB8);
    // 0x80397F60: sw          $fp, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r30;
    // 0x80397F64: lbu         $fp, 0xD7($sp)
    ctx->r30 = MEM_BU(ctx->r29, 0XD7);
    // 0x80397F68: sw          $s7, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r23;
    // 0x80397F6C: sll         $s7, $a3, 16
    ctx->r23 = S32(ctx->r7 << 16);
    // 0x80397F70: sra         $t6, $s7, 16
    ctx->r14 = S32(SIGNED(ctx->r23) >> 16);
    // 0x80397F74: sw          $s4, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r20;
    // 0x80397F78: sw          $s3, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r19;
    // 0x80397F7C: sw          $s2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r18;
    // 0x80397F80: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80397F84: or          $s2, $a0, $zero
    ctx->r18 = ctx->r4 | 0;
    // 0x80397F88: or          $s3, $a1, $zero
    ctx->r19 = ctx->r5 | 0;
    // 0x80397F8C: or          $s4, $a2, $zero
    ctx->r20 = ctx->r6 | 0;
    // 0x80397F90: or          $s7, $t6, $zero
    ctx->r23 = ctx->r14 | 0;
    // 0x80397F94: sw          $ra, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r31;
    // 0x80397F98: sw          $s6, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r22;
    // 0x80397F9C: sw          $s5, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r21;
    // 0x80397FA0: sw          $s1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r17;
    // 0x80397FA4: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x80397FA8: sw          $a3, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r7;
    // 0x80397FAC: bne         $fp, $at, L_803980D8
    if (ctx->r30 != ctx->r1) {
        // 0x80397FB0: sw          $fp, 0x70($sp)
        MEM_W(0X70, ctx->r29) = ctx->r30;
            goto L_803980D8;
    }
    // 0x80397FB0: sw          $fp, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r30;
    // 0x80397FB4: sll         $t8, $fp, 2
    ctx->r24 = S32(ctx->r30 << 2);
    // 0x80397FB8: subu        $t8, $t8, $fp
    ctx->r24 = SUB32(ctx->r24, ctx->r30);
    // 0x80397FBC: sra         $t0, $a0, 16
    ctx->r8 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80397FC0: mtc1        $t0, $f6
    ctx->f6.u32l = ctx->r8;
    // 0x80397FC4: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80397FC8: addu        $t8, $t8, $fp
    ctx->r24 = ADD32(ctx->r24, ctx->r30);
    // 0x80397FCC: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x80397FD0: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80397FD4: addu        $t8, $t8, $fp
    ctx->r24 = ADD32(ctx->r24, ctx->r30);
    // 0x80397FD8: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80397FDC: addiu       $t9, $t9, 0x6720
    ctx->r25 = ADD32(ctx->r25, 0X6720);
    // 0x80397FE0: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x80397FE4: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x80397FE8: lwc1        $f4, 0xC($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0XC);
    // 0x80397FEC: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80397FF0: mtc1        $t4, $f6
    ctx->f6.u32l = ctx->r12;
    // 0x80397FF4: add.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x80397FF8: lwc1        $f18, 0x10($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X10);
    // 0x80397FFC: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80398000: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80398004: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x80398008: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x8039800C: lw          $s1, 0xCC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XCC);
    // 0x80398010: addiu       $t1, $zero, 0x9B
    ctx->r9 = ADD32(0, 0X9B);
    // 0x80398014: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80398018: sll         $t7, $s1, 3
    ctx->r15 = S32(ctx->r17 << 3);
    // 0x8039801C: sll         $t9, $s1, 4
    ctx->r25 = S32(ctx->r17 << 4);
    // 0x80398020: add.s       $f8, $f18, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x80398024: mfc1        $a0, $f16
    ctx->r4 = (int32_t)ctx->f16.u32l;
    // 0x80398028: lwc1        $f16, 0x14($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X14);
    // 0x8039802C: cvt.s.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80398030: sll         $t2, $a0, 16
    ctx->r10 = S32(ctx->r4 << 16);
    // 0x80398034: sra         $a0, $t2, 16
    ctx->r4 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80398038: lh          $t2, 0xCA($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XCA);
    // 0x8039803C: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80398040: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80398044: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80398048: sw          $t3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r11;
    // 0x8039804C: add.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f16.fl + ctx->f18.fl;
    // 0x80398050: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x80398054: mtc1        $t2, $f10
    ctx->f10.u32l = ctx->r10;
    // 0x80398058: lwc1        $f16, 0x8($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X8);
    // 0x8039805C: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80398060: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80398064: lui         $at, 0x43B4
    ctx->r1 = S32(0X43B4 << 16);
    // 0x80398068: cvt.s.w     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039806C: mfc1        $a2, $f8
    ctx->r6 = (int32_t)ctx->f8.u32l;
    // 0x80398070: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80398074: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80398078: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039807C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80398080: sub.s       $f18, $f6, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f6.fl - ctx->f16.fl;
    // 0x80398084: sll         $t0, $a2, 16
    ctx->r8 = S32(ctx->r6 << 16);
    // 0x80398088: lw          $t6, -0x7C8C($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X7C8C);
    // 0x8039808C: sra         $a2, $t0, 16
    ctx->r6 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80398090: mul.s       $f8, $f18, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80398094: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80398098: addiu       $t2, $zero, 0x8
    ctx->r10 = ADD32(0, 0X8);
    // 0x8039809C: sw          $t2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r10;
    // 0x803980A0: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x803980A4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x803980A8: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x803980AC: div.s       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = DIV_S(ctx->f8.fl, ctx->f10.fl);
    // 0x803980B0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803980B4: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x803980B8: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x803980BC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803980C0: trunc.w.s   $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    ctx->f16.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x803980C4: mfc1        $a3, $f16
    ctx->r7 = (int32_t)ctx->f16.u32l;
    // 0x803980C8: nop

    // 0x803980CC: sll         $t4, $a3, 16
    ctx->r12 = S32(ctx->r7 << 16);
    // 0x803980D0: jal         0x8034C8F8
    // 0x803980D4: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
    func_8034C8F8_75DFA8(rdram, ctx);
        goto after_0;
    // 0x803980D4: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
    after_0:
L_803980D8:
    // 0x803980D8: lw          $s1, 0xCC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XCC);
    // 0x803980DC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803980E0: lui         $s5, 0x8020
    ctx->r21 = S32(0X8020 << 16);
    // 0x803980E4: div         $zero, $s1, $at
    lo = S32(S64(S32(ctx->r17)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r17)) % S64(S32(ctx->r1)));
    // 0x803980E8: addiu       $s5, $s5, 0x4278
    ctx->r21 = ADD32(ctx->r21, 0X4278);
    // 0x803980EC: lw          $s0, 0x0($s5)
    ctx->r16 = MEM_W(ctx->r21, 0X0);
    // 0x803980F0: lui         $s6, 0x3
    ctx->r22 = S32(0X3 << 16);
    // 0x803980F4: ori         $s6, $s6, 0x8000
    ctx->r22 = ctx->r22 | 0X8000;
    // 0x803980F8: sll         $t9, $fp, 2
    ctx->r25 = S32(ctx->r30 << 2);
    // 0x803980FC: subu        $t9, $t9, $fp
    ctx->r25 = SUB32(ctx->r25, ctx->r30);
    // 0x80398100: addu        $t5, $s0, $s6
    ctx->r13 = ADD32(ctx->r16, ctx->r22);
    // 0x80398104: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x80398108: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039810C: addu        $t9, $t9, $fp
    ctx->r25 = ADD32(ctx->r25, ctx->r30);
    // 0x80398110: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80398114: mflo        $t4
    ctx->r12 = lo;
    // 0x80398118: addu        $t9, $t9, $fp
    ctx->r25 = ADD32(ctx->r25, ctx->r30);
    // 0x8039811C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80398120: lh          $t8, 0xCA($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XCA);
    // 0x80398124: addiu       $t0, $t0, 0x6720
    ctx->r8 = ADD32(ctx->r8, 0X6720);
    // 0x80398128: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8039812C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80398130: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80398134: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80398138: addu        $t1, $t9, $t0
    ctx->r9 = ADD32(ctx->r25, ctx->r8);
    // 0x8039813C: addu        $a0, $s0, $t7
    ctx->r4 = ADD32(ctx->r16, ctx->r15);
    // 0x80398140: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80398144: sw          $t1, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r9;
    // 0x80398148: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8039814C: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80398150: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x80398154: sw          $s7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r23;
    // 0x80398158: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x8039815C: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    // 0x80398160: or          $a3, $s4, $zero
    ctx->r7 = ctx->r20 | 0;
    // 0x80398164: jal         0x80125FE0
    // 0x80398168: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_80125FE0(rdram, ctx);
        goto after_1;
    // 0x80398168: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_1:
    // 0x8039816C: lui         $s4, 0x801E
    ctx->r20 = S32(0X801E << 16);
    // 0x80398170: addiu       $s4, $s4, -0x6174
    ctx->r20 = ADD32(ctx->r20, -0X6174);
    // 0x80398174: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398178: lui         $t3, 0x104
    ctx->r11 = S32(0X104 << 16);
    // 0x8039817C: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    // 0x80398180: addiu       $t2, $s1, 0x8
    ctx->r10 = ADD32(ctx->r17, 0X8);
    // 0x80398184: sw          $t2, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r10;
    // 0x80398188: ori         $t3, $t3, 0x40
    ctx->r11 = ctx->r11 | 0X40;
    // 0x8039818C: sw          $t3, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r11;
    // 0x80398190: lw          $s0, 0x0($s5)
    ctx->r16 = MEM_W(ctx->r21, 0X0);
    // 0x80398194: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80398198: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8039819C: addu        $t4, $s0, $s6
    ctx->r12 = ADD32(ctx->r16, ctx->r22);
    // 0x803981A0: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x803981A4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803981A8: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x803981AC: addu        $t7, $s0, $t6
    ctx->r15 = ADD32(ctx->r16, ctx->r14);
    // 0x803981B0: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x803981B4: sw          $t8, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r24;
    // 0x803981B8: lw          $s0, 0x0($s5)
    ctx->r16 = MEM_W(ctx->r21, 0X0);
    // 0x803981BC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803981C0: addu        $t9, $s0, $s6
    ctx->r25 = ADD32(ctx->r16, ctx->r22);
    // 0x803981C4: lw          $t0, 0x918($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X918);
    // 0x803981C8: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x803981CC: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x803981D0: sw          $t1, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r9;
    // 0x803981D4: lwc1        $f8, 0x8($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X8);
    // 0x803981D8: lwc1        $f4, 0x4($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X4);
    // 0x803981DC: lwc1        $f18, 0x0($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X0);
    // 0x803981E0: lw          $a3, 0x14($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X14);
    // 0x803981E4: lw          $a2, 0x10($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X10);
    // 0x803981E8: lw          $a1, 0xC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0XC);
    // 0x803981EC: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x803981F0: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x803981F4: jal         0x80397414
    // 0x803981F8: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_2;
    // 0x803981F8: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    after_2:
    // 0x803981FC: lbu         $v1, 0xD3($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0XD3);
    // 0x80398200: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398204: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x80398208: sll         $t4, $v1, 2
    ctx->r12 = S32(ctx->r3 << 2);
    // 0x8039820C: addu        $t4, $t4, $v1
    ctx->r12 = ADD32(ctx->r12, ctx->r3);
    // 0x80398210: addiu       $t2, $s1, 0x8
    ctx->r10 = ADD32(ctx->r17, 0X8);
    // 0x80398214: sw          $t2, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r10;
    // 0x80398218: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x8039821C: addiu       $t5, $t5, 0x7108
    ctx->r13 = ADD32(ctx->r13, 0X7108);
    // 0x80398220: lui         $t3, 0x600
    ctx->r11 = S32(0X600 << 16);
    // 0x80398224: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x80398228: sw          $t3, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r11;
    // 0x8039822C: sw          $t6, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r14;
    // 0x80398230: lw          $t7, 0x18($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X18);
    // 0x80398234: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80398238: addiu       $s2, $zero, 0x4
    ctx->r18 = ADD32(0, 0X4);
    // 0x8039823C: sw          $t7, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r15;
    // 0x80398240: lw          $t8, 0x70($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X70);
    // 0x80398244: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    // 0x80398248: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x8039824C: beq         $t8, $at, L_8039841C
    if (ctx->r24 == ctx->r1) {
        // 0x80398250: sll         $t9, $fp, 2
        ctx->r25 = S32(ctx->r30 << 2);
            goto L_8039841C;
    }
    // 0x80398250: sll         $t9, $fp, 2
    ctx->r25 = S32(ctx->r30 << 2);
    // 0x80398254: subu        $t9, $t9, $fp
    ctx->r25 = SUB32(ctx->r25, ctx->r30);
    // 0x80398258: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039825C: addu        $t9, $t9, $fp
    ctx->r25 = ADD32(ctx->r25, ctx->r30);
    // 0x80398260: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80398264: sll         $t1, $v1, 2
    ctx->r9 = S32(ctx->r3 << 2);
    // 0x80398268: addu        $t1, $t1, $v1
    ctx->r9 = ADD32(ctx->r9, ctx->r3);
    // 0x8039826C: addu        $t9, $t9, $fp
    ctx->r25 = ADD32(ctx->r25, ctx->r30);
    // 0x80398270: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80398274: lui         $t2, 0x803B
    ctx->r10 = S32(0X803B << 16);
    // 0x80398278: addiu       $t2, $t2, 0x7108
    ctx->r10 = ADD32(ctx->r10, 0X7108);
    // 0x8039827C: addiu       $t0, $t0, 0x6720
    ctx->r8 = ADD32(ctx->r8, 0X6720);
    // 0x80398280: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80398284: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x80398288: addu        $s7, $t1, $t2
    ctx->r23 = ADD32(ctx->r9, ctx->r10);
    // 0x8039828C: addu        $s6, $t9, $t0
    ctx->r22 = ADD32(ctx->r25, ctx->r8);
    // 0x80398290: addiu       $fp, $zero, 0x54
    ctx->r30 = ADD32(0, 0X54);
L_80398294:
    // 0x80398294: multu       $s2, $fp
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r30)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80398298: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8039829C: mflo        $t3
    ctx->r11 = lo;
    // 0x803982A0: addu        $s0, $s6, $t3
    ctx->r16 = ADD32(ctx->r22, ctx->r11);
    // 0x803982A4: lwc1        $f10, 0x0($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X0);
    // 0x803982A8: lwc1        $f6, 0x4($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X4);
    // 0x803982AC: lwc1        $f16, 0x8($s0)
    ctx->f16.u32l = MEM_W(ctx->r16, 0X8);
    // 0x803982B0: lw          $a1, 0xC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0XC);
    // 0x803982B4: lw          $a2, 0x10($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X10);
    // 0x803982B8: lw          $a3, 0x14($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X14);
    // 0x803982BC: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x803982C0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x803982C4: jal         0x80397414
    // 0x803982C8: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_3;
    // 0x803982C8: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    after_3:
    // 0x803982CC: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x803982D0: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x803982D4: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803982D8: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803982DC: multu       $s2, $fp
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r30)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803982E0: addiu       $t4, $s1, 0x8
    ctx->r12 = ADD32(ctx->r17, 0X8);
    // 0x803982E4: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x803982E8: lui         $t5, 0x600
    ctx->r13 = S32(0X600 << 16);
    // 0x803982EC: sll         $t6, $s3, 2
    ctx->r14 = S32(ctx->r19 << 2);
    // 0x803982F0: addu        $t7, $s7, $t6
    ctx->r15 = ADD32(ctx->r23, ctx->r14);
    // 0x803982F4: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x803982F8: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x803982FC: addiu       $s3, $s3, 0x1
    ctx->r19 = ADD32(ctx->r19, 0X1);
    // 0x80398300: sll         $t1, $s3, 16
    ctx->r9 = S32(ctx->r19 << 16);
    // 0x80398304: sw          $t8, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r24;
    // 0x80398308: mflo        $t3
    ctx->r11 = lo;
    // 0x8039830C: addu        $s0, $s6, $t3
    ctx->r16 = ADD32(ctx->r22, ctx->r11);
    // 0x80398310: lwc1        $f18, 0x0($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80398314: lwc1        $f4, 0x4($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X4);
    // 0x80398318: lwc1        $f8, 0x8($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X8);
    // 0x8039831C: sra         $s3, $t1, 16
    ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80398320: lw          $a1, 0xC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0XC);
    // 0x80398324: lw          $a2, 0x10($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X10);
    // 0x80398328: lw          $a3, 0x14($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X14);
    // 0x8039832C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80398330: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80398334: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x80398338: jal         0x80397414
    // 0x8039833C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_4;
    // 0x8039833C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_4:
    // 0x80398340: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x80398344: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x80398348: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x8039834C: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80398350: multu       $s2, $fp
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r30)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80398354: addiu       $t4, $s1, 0x8
    ctx->r12 = ADD32(ctx->r17, 0X8);
    // 0x80398358: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x8039835C: lui         $t5, 0x600
    ctx->r13 = S32(0X600 << 16);
    // 0x80398360: sll         $t6, $s3, 2
    ctx->r14 = S32(ctx->r19 << 2);
    // 0x80398364: addu        $t7, $s7, $t6
    ctx->r15 = ADD32(ctx->r23, ctx->r14);
    // 0x80398368: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x8039836C: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x80398370: addiu       $s3, $s3, 0x1
    ctx->r19 = ADD32(ctx->r19, 0X1);
    // 0x80398374: sll         $t1, $s3, 16
    ctx->r9 = S32(ctx->r19 << 16);
    // 0x80398378: sw          $t8, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r24;
    // 0x8039837C: mflo        $t3
    ctx->r11 = lo;
    // 0x80398380: addu        $s0, $s6, $t3
    ctx->r16 = ADD32(ctx->r22, ctx->r11);
    // 0x80398384: lwc1        $f10, 0x0($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80398388: lwc1        $f6, 0x4($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X4);
    // 0x8039838C: lwc1        $f16, 0x8($s0)
    ctx->f16.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80398390: sra         $s3, $t1, 16
    ctx->r19 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80398394: lw          $a1, 0xC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0XC);
    // 0x80398398: lw          $a2, 0x10($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X10);
    // 0x8039839C: lw          $a3, 0x14($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X14);
    // 0x803983A0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803983A4: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x803983A8: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x803983AC: jal         0x80397414
    // 0x803983B0: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_5;
    // 0x803983B0: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    after_5:
    // 0x803983B4: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803983B8: lui         $s0, 0x600
    ctx->r16 = S32(0X600 << 16);
    // 0x803983BC: sll         $t5, $s3, 2
    ctx->r13 = S32(ctx->r19 << 2);
    // 0x803983C0: addiu       $t4, $s1, 0x8
    ctx->r12 = ADD32(ctx->r17, 0X8);
    // 0x803983C4: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x803983C8: addu        $t6, $s7, $t5
    ctx->r14 = ADD32(ctx->r23, ctx->r13);
    // 0x803983CC: sw          $s0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r16;
    // 0x803983D0: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x803983D4: addiu       $s5, $s5, 0x1
    ctx->r21 = ADD32(ctx->r21, 0X1);
    // 0x803983D8: sll         $t4, $s5, 16
    ctx->r12 = S32(ctx->r21 << 16);
    // 0x803983DC: sw          $t7, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r15;
    // 0x803983E0: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803983E4: sra         $s5, $t4, 16
    ctx->r21 = S32(SIGNED(ctx->r12) >> 16);
    // 0x803983E8: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x803983EC: addiu       $s3, $s3, 0x1
    ctx->r19 = ADD32(ctx->r19, 0X1);
    // 0x803983F0: addiu       $t2, $s1, 0x8
    ctx->r10 = ADD32(ctx->r17, 0X8);
    // 0x803983F4: slti        $at, $s5, 0x2
    ctx->r1 = SIGNED(ctx->r21) < 0X2 ? 1 : 0;
    // 0x803983F8: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x803983FC: sll         $t0, $s3, 16
    ctx->r8 = S32(ctx->r19 << 16);
    // 0x80398400: sw          $t2, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r10;
    // 0x80398404: lui         $t3, 0xBD00
    ctx->r11 = S32(0XBD00 << 16);
    // 0x80398408: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039840C: sra         $s3, $t0, 16
    ctx->r19 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80398410: sw          $t3, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r11;
    // 0x80398414: bne         $at, $zero, L_80398294
    if (ctx->r1 != 0) {
        // 0x80398418: sw          $zero, 0x4($s1)
        MEM_W(0X4, ctx->r17) = 0;
            goto L_80398294;
    }
    // 0x80398418: sw          $zero, 0x4($s1)
    MEM_W(0X4, ctx->r17) = 0;
L_8039841C:
    // 0x8039841C: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    // 0x80398420: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80398424: lwc1        $f18, 0x54($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X54);
    // 0x80398428: lwc1        $f4, 0x58($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X58);
    // 0x8039842C: lwc1        $f8, 0x5C($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X5C);
    // 0x80398430: lw          $a1, 0x60($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X60);
    // 0x80398434: lw          $a2, 0x64($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X64);
    // 0x80398438: lw          $a3, 0x68($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X68);
    // 0x8039843C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80398440: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x80398444: jal         0x80397414
    // 0x80398448: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_6;
    // 0x80398448: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_6:
    // 0x8039844C: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398450: lui         $s0, 0x600
    ctx->r16 = S32(0X600 << 16);
    // 0x80398454: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80398458: addiu       $t6, $s1, 0x8
    ctx->r14 = ADD32(ctx->r17, 0X8);
    // 0x8039845C: sw          $t6, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r14;
    // 0x80398460: sw          $s0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r16;
    // 0x80398464: lw          $t7, 0x68($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X68);
    // 0x80398468: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8039846C: lw          $t8, 0x1C($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X1C);
    // 0x80398470: sw          $t8, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r24;
    // 0x80398474: lw          $t9, 0x70($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X70);
    // 0x80398478: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    // 0x8039847C: beql        $t9, $at, L_803984E4
    if (ctx->r25 == ctx->r1) {
        // 0x80398480: lw          $v0, 0x6C($sp)
        ctx->r2 = MEM_W(ctx->r29, 0X6C);
            goto L_803984E4;
    }
    goto skip_0;
    // 0x80398480: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    skip_0:
    // 0x80398484: lwc1        $f10, 0xA8($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XA8);
    // 0x80398488: lwc1        $f6, 0xAC($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0XAC);
    // 0x8039848C: lwc1        $f16, 0xB0($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0XB0);
    // 0x80398490: lw          $a1, 0xB4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0XB4);
    // 0x80398494: lw          $a2, 0xB8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0XB8);
    // 0x80398498: lw          $a3, 0xBC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XBC);
    // 0x8039849C: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x803984A0: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x803984A4: jal         0x80397414
    // 0x803984A8: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_7;
    // 0x803984A8: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    after_7:
    // 0x803984AC: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803984B0: lui         $t4, 0xBD00
    ctx->r12 = S32(0XBD00 << 16);
    // 0x803984B4: addiu       $t0, $s1, 0x8
    ctx->r8 = ADD32(ctx->r17, 0X8);
    // 0x803984B8: sw          $t0, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r8;
    // 0x803984BC: sw          $s0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r16;
    // 0x803984C0: lw          $t1, 0x68($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X68);
    // 0x803984C4: lw          $t2, 0x20($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X20);
    // 0x803984C8: sw          $t2, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r10;
    // 0x803984CC: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803984D0: addiu       $t3, $s1, 0x8
    ctx->r11 = ADD32(ctx->r17, 0X8);
    // 0x803984D4: sw          $t3, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r11;
    // 0x803984D8: sw          $zero, 0x4($s1)
    MEM_W(0X4, ctx->r17) = 0;
    // 0x803984DC: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x803984E0: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
L_803984E4:
    // 0x803984E4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803984E8: lwc1        $f18, 0x54($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0X54);
    // 0x803984EC: lwc1        $f4, 0x58($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0X58);
    // 0x803984F0: lwc1        $f8, 0x5C($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0X5C);
    // 0x803984F4: lw          $a1, 0x60($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X60);
    // 0x803984F8: lw          $a2, 0x64($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X64);
    // 0x803984FC: lw          $a3, 0x68($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X68);
    // 0x80398500: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80398504: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x80398508: jal         0x80397414
    // 0x8039850C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_8;
    // 0x8039850C: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_8:
    // 0x80398510: lw          $t5, 0x70($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X70);
    // 0x80398514: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80398518: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8039851C: bne         $t5, $at, L_80398560
    if (ctx->r13 != ctx->r1) {
        // 0x80398520: lui         $t8, 0xEAE6
        ctx->r24 = S32(0XEAE6 << 16);
            goto L_80398560;
    }
    // 0x80398520: lui         $t8, 0xEAE6
    ctx->r24 = S32(0XEAE6 << 16);
    // 0x80398524: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398528: ori         $t8, $t8, 0xFFFF
    ctx->r24 = ctx->r24 | 0XFFFF;
    // 0x8039852C: lui         $t0, 0xFC41
    ctx->r8 = S32(0XFC41 << 16);
    // 0x80398530: addiu       $t6, $s1, 0x8
    ctx->r14 = ADD32(ctx->r17, 0X8);
    // 0x80398534: sw          $t6, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r14;
    // 0x80398538: sw          $t8, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r24;
    // 0x8039853C: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80398540: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398544: lui         $t1, 0xFF8F
    ctx->r9 = S32(0XFF8F << 16);
    // 0x80398548: ori         $t1, $t1, 0xFFFF
    ctx->r9 = ctx->r9 | 0XFFFF;
    // 0x8039854C: addiu       $t9, $s1, 0x8
    ctx->r25 = ADD32(ctx->r17, 0X8);
    // 0x80398550: sw          $t9, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r25;
    // 0x80398554: ori         $t0, $t0, 0xC683
    ctx->r8 = ctx->r8 | 0XC683;
    // 0x80398558: sw          $t0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r8;
    // 0x8039855C: sw          $t1, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r9;
L_80398560:
    // 0x80398560: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    // 0x80398564: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80398568: lwc1        $f10, 0xFC($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XFC);
    // 0x8039856C: lwc1        $f6, 0x100($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0X100);
    // 0x80398570: lwc1        $f16, 0x104($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X104);
    // 0x80398574: lw          $a1, 0x108($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X108);
    // 0x80398578: lw          $a2, 0x10C($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X10C);
    // 0x8039857C: lw          $a3, 0x110($v0)
    ctx->r7 = MEM_W(ctx->r2, 0X110);
    // 0x80398580: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80398584: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    // 0x80398588: jal         0x80397414
    // 0x8039858C: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    append_rig_modelview_transform_xlu(rdram, ctx);
        goto after_9;
    // 0x8039858C: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    after_9:
    // 0x80398590: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x80398594: lui         $t6, 0xBD00
    ctx->r14 = S32(0XBD00 << 16);
    // 0x80398598: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x8039859C: addiu       $t2, $s1, 0x8
    ctx->r10 = ADD32(ctx->r17, 0X8);
    // 0x803985A0: sw          $t2, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r10;
    // 0x803985A4: sw          $s0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r16;
    // 0x803985A8: lw          $t3, 0x68($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X68);
    // 0x803985AC: lui         $t0, 0xBD00
    ctx->r8 = S32(0XBD00 << 16);
    // 0x803985B0: lw          $t4, 0x24($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X24);
    // 0x803985B4: sw          $t4, 0x4($s1)
    MEM_W(0X4, ctx->r17) = ctx->r12;
    // 0x803985B8: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803985BC: addiu       $t5, $s1, 0x8
    ctx->r13 = ADD32(ctx->r17, 0X8);
    // 0x803985C0: sw          $t5, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r13;
    // 0x803985C4: sw          $zero, 0x4($s1)
    MEM_W(0X4, ctx->r17) = 0;
    // 0x803985C8: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x803985CC: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803985D0: addiu       $t7, $s1, 0x8
    ctx->r15 = ADD32(ctx->r17, 0X8);
    // 0x803985D4: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x803985D8: sw          $zero, 0x4($s1)
    MEM_W(0X4, ctx->r17) = 0;
    // 0x803985DC: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x803985E0: lw          $s1, 0x0($s4)
    ctx->r17 = MEM_W(ctx->r20, 0X0);
    // 0x803985E4: addiu       $t9, $s1, 0x8
    ctx->r25 = ADD32(ctx->r17, 0X8);
    // 0x803985E8: sw          $t9, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r25;
    // 0x803985EC: sw          $zero, 0x4($s1)
    MEM_W(0X4, ctx->r17) = 0;
    // 0x803985F0: sw          $t0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r8;
    // 0x803985F4: lw          $ra, 0x64($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X64);
    // 0x803985F8: lw          $fp, 0x60($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X60);
    // 0x803985FC: lw          $s7, 0x5C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X5C);
    // 0x80398600: lw          $s6, 0x58($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X58);
    // 0x80398604: lw          $s5, 0x54($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X54);
    // 0x80398608: lw          $s4, 0x50($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X50);
    // 0x8039860C: lw          $s3, 0x4C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X4C);
    // 0x80398610: lw          $s2, 0x48($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X48);
    // 0x80398614: lw          $s1, 0x44($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X44);
    // 0x80398618: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x8039861C: jr          $ra
    // 0x80398620: addiu       $sp, $sp, 0xB8
    ctx->r29 = ADD32(ctx->r29, 0XB8);
    return;
    // 0x80398620: addiu       $sp, $sp, 0xB8
    ctx->r29 = ADD32(ctx->r29, 0XB8);
;}
RECOMP_FUNC void func_80398630_7A9CE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80398630: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80398634: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80398638: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8039863C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80398640: jal         0x803800F0
    // 0x80398644: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    load_data_section(rdram, ctx);
        goto after_0;
    // 0x80398644: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    after_0:
    // 0x80398648: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x8039864C: addiu       $s1, $s1, -0x6194
    ctx->r17 = ADD32(ctx->r17, -0X6194);
    // 0x80398650: lui         $s0, 0xFF
    ctx->r16 = S32(0XFF << 16);
    // 0x80398654: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80398658: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x8039865C: ori         $s0, $s0, 0xFFFF
    ctx->r16 = ctx->r16 | 0XFFFF;
    // 0x80398660: addiu       $t6, $t6, 0x6EC0
    ctx->r14 = ADD32(ctx->r14, 0X6EC0);
    // 0x80398664: and         $t7, $t6, $s0
    ctx->r15 = ctx->r14 & ctx->r16;
    // 0x80398668: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039866C: addiu       $a1, $a1, -0x58A0
    ctx->r5 = ADD32(ctx->r5, -0X58A0);
    // 0x80398670: jal         0x8012B0F0
    // 0x80398674: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    UnpackRNC(rdram, ctx);
        goto after_1;
    // 0x80398674: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    after_1:
    // 0x80398678: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x8039867C: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x80398680: addiu       $t9, $t9, 0x7FA0
    ctx->r25 = ADD32(ctx->r25, 0X7FA0);
    // 0x80398684: and         $t0, $t9, $s0
    ctx->r8 = ctx->r25 & ctx->r16;
    // 0x80398688: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039868C: addiu       $a1, $a1, -0x2380
    ctx->r5 = ADD32(ctx->r5, -0X2380);
    // 0x80398690: jal         0x8012B0F0
    // 0x80398694: addu        $a0, $t0, $t1
    ctx->r4 = ADD32(ctx->r8, ctx->r9);
    UnpackRNC(rdram, ctx);
        goto after_2;
    // 0x80398694: addu        $a0, $t0, $t1
    ctx->r4 = ADD32(ctx->r8, ctx->r9);
    after_2:
    // 0x80398698: lui         $t2, 0x400
    ctx->r10 = S32(0X400 << 16);
    // 0x8039869C: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x803986A0: addiu       $t2, $t2, 0x0
    ctx->r10 = ADD32(ctx->r10, 0X0);
    // 0x803986A4: and         $t3, $t2, $s0
    ctx->r11 = ctx->r10 & ctx->r16;
    // 0x803986A8: lui         $a1, 0x800E
    ctx->r5 = S32(0X800E << 16);
    // 0x803986AC: addiu       $a1, $a1, -0x1C70
    ctx->r5 = ADD32(ctx->r5, -0X1C70);
    // 0x803986B0: jal         0x8012B0F0
    // 0x803986B4: addu        $a0, $t3, $t4
    ctx->r4 = ADD32(ctx->r11, ctx->r12);
    UnpackRNC(rdram, ctx);
        goto after_3;
    // 0x803986B4: addu        $a0, $t3, $t4
    ctx->r4 = ADD32(ctx->r11, ctx->r12);
    after_3:
    // 0x803986B8: lui         $t5, 0x401
    ctx->r13 = S32(0X401 << 16);
    // 0x803986BC: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x803986C0: addiu       $t5, $t5, 0x3060
    ctx->r13 = ADD32(ctx->r13, 0X3060);
    // 0x803986C4: and         $t6, $t5, $s0
    ctx->r14 = ctx->r13 & ctx->r16;
    // 0x803986C8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803986CC: addiu       $a1, $a1, 0x3A40
    ctx->r5 = ADD32(ctx->r5, 0X3A40);
    // 0x803986D0: jal         0x8012B0F0
    // 0x803986D4: addu        $a0, $t6, $t7
    ctx->r4 = ADD32(ctx->r14, ctx->r15);
    UnpackRNC(rdram, ctx);
        goto after_4;
    // 0x803986D4: addu        $a0, $t6, $t7
    ctx->r4 = ADD32(ctx->r14, ctx->r15);
    after_4:
    // 0x803986D8: lui         $t8, 0x401
    ctx->r24 = S32(0X401 << 16);
    // 0x803986DC: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x803986E0: addiu       $t8, $t8, 0x33C0
    ctx->r24 = ADD32(ctx->r24, 0X33C0);
    // 0x803986E4: and         $t9, $t8, $s0
    ctx->r25 = ctx->r24 & ctx->r16;
    // 0x803986E8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803986EC: addiu       $a1, $a1, 0x5240
    ctx->r5 = ADD32(ctx->r5, 0X5240);
    // 0x803986F0: jal         0x8012B0F0
    // 0x803986F4: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    UnpackRNC(rdram, ctx);
        goto after_5;
    // 0x803986F4: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    after_5:
    // 0x803986F8: lui         $t1, 0x401
    ctx->r9 = S32(0X401 << 16);
    // 0x803986FC: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x80398700: addiu       $t1, $t1, 0x31B0
    ctx->r9 = ADD32(ctx->r9, 0X31B0);
    // 0x80398704: and         $t2, $t1, $s0
    ctx->r10 = ctx->r9 & ctx->r16;
    // 0x80398708: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039870C: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x80398710: jal         0x8012B0F0
    // 0x80398714: addu        $a0, $t2, $t3
    ctx->r4 = ADD32(ctx->r10, ctx->r11);
    UnpackRNC(rdram, ctx);
        goto after_6;
    // 0x80398714: addu        $a0, $t2, $t3
    ctx->r4 = ADD32(ctx->r10, ctx->r11);
    after_6:
    // 0x80398718: lui         $t4, 0x401
    ctx->r12 = S32(0X401 << 16);
    // 0x8039871C: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x80398720: addiu       $t4, $t4, 0x3580
    ctx->r12 = ADD32(ctx->r12, 0X3580);
    // 0x80398724: and         $t5, $t4, $s0
    ctx->r13 = ctx->r12 & ctx->r16;
    // 0x80398728: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039872C: addiu       $a1, $a1, 0x4A40
    ctx->r5 = ADD32(ctx->r5, 0X4A40);
    // 0x80398730: jal         0x8012B0F0
    // 0x80398734: addu        $a0, $t5, $t6
    ctx->r4 = ADD32(ctx->r13, ctx->r14);
    UnpackRNC(rdram, ctx);
        goto after_7;
    // 0x80398734: addu        $a0, $t5, $t6
    ctx->r4 = ADD32(ctx->r13, ctx->r14);
    after_7:
    // 0x80398738: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x8039873C: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x80398740: addiu       $t7, $t7, 0x7700
    ctx->r15 = ADD32(ctx->r15, 0X7700);
    // 0x80398744: and         $t8, $t7, $s0
    ctx->r24 = ctx->r15 & ctx->r16;
    // 0x80398748: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039874C: addiu       $a1, $a1, -0x4900
    ctx->r5 = ADD32(ctx->r5, -0X4900);
    // 0x80398750: jal         0x8012B0F0
    // 0x80398754: addu        $a0, $t8, $t9
    ctx->r4 = ADD32(ctx->r24, ctx->r25);
    UnpackRNC(rdram, ctx);
        goto after_8;
    // 0x80398754: addu        $a0, $t8, $t9
    ctx->r4 = ADD32(ctx->r24, ctx->r25);
    after_8:
    // 0x80398758: lui         $t0, 0x400
    ctx->r8 = S32(0X400 << 16);
    // 0x8039875C: lw          $t2, 0x0($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X0);
    // 0x80398760: addiu       $t0, $t0, 0x77A0
    ctx->r8 = ADD32(ctx->r8, 0X77A0);
    // 0x80398764: and         $t1, $t0, $s0
    ctx->r9 = ctx->r8 & ctx->r16;
    // 0x80398768: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039876C: addiu       $a1, $a1, -0x4450
    ctx->r5 = ADD32(ctx->r5, -0X4450);
    // 0x80398770: jal         0x8012B0F0
    // 0x80398774: addu        $a0, $t1, $t2
    ctx->r4 = ADD32(ctx->r9, ctx->r10);
    UnpackRNC(rdram, ctx);
        goto after_9;
    // 0x80398774: addu        $a0, $t1, $t2
    ctx->r4 = ADD32(ctx->r9, ctx->r10);
    after_9:
    // 0x80398778: lui         $t3, 0x400
    ctx->r11 = S32(0X400 << 16);
    // 0x8039877C: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x80398780: addiu       $t3, $t3, 0x78C0
    ctx->r11 = ADD32(ctx->r11, 0X78C0);
    // 0x80398784: and         $t4, $t3, $s0
    ctx->r12 = ctx->r11 & ctx->r16;
    // 0x80398788: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039878C: addiu       $a1, $a1, -0x3FA0
    ctx->r5 = ADD32(ctx->r5, -0X3FA0);
    // 0x80398790: jal         0x8012B0F0
    // 0x80398794: addu        $a0, $t4, $t5
    ctx->r4 = ADD32(ctx->r12, ctx->r13);
    UnpackRNC(rdram, ctx);
        goto after_10;
    // 0x80398794: addu        $a0, $t4, $t5
    ctx->r4 = ADD32(ctx->r12, ctx->r13);
    after_10:
    // 0x80398798: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x8039879C: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x803987A0: addiu       $t6, $t6, 0x79F0
    ctx->r14 = ADD32(ctx->r14, 0X79F0);
    // 0x803987A4: and         $t7, $t6, $s0
    ctx->r15 = ctx->r14 & ctx->r16;
    // 0x803987A8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803987AC: addiu       $a1, $a1, -0x3AF0
    ctx->r5 = ADD32(ctx->r5, -0X3AF0);
    // 0x803987B0: jal         0x8012B0F0
    // 0x803987B4: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    UnpackRNC(rdram, ctx);
        goto after_11;
    // 0x803987B4: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    after_11:
    // 0x803987B8: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803987BC: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x803987C0: addiu       $t9, $t9, 0x7B40
    ctx->r25 = ADD32(ctx->r25, 0X7B40);
    // 0x803987C4: and         $t0, $t9, $s0
    ctx->r8 = ctx->r25 & ctx->r16;
    // 0x803987C8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803987CC: addiu       $a1, $a1, -0x3640
    ctx->r5 = ADD32(ctx->r5, -0X3640);
    // 0x803987D0: jal         0x8012B0F0
    // 0x803987D4: addu        $a0, $t0, $t1
    ctx->r4 = ADD32(ctx->r8, ctx->r9);
    UnpackRNC(rdram, ctx);
        goto after_12;
    // 0x803987D4: addu        $a0, $t0, $t1
    ctx->r4 = ADD32(ctx->r8, ctx->r9);
    after_12:
    // 0x803987D8: lui         $t2, 0x400
    ctx->r10 = S32(0X400 << 16);
    // 0x803987DC: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x803987E0: addiu       $t2, $t2, 0x7C60
    ctx->r10 = ADD32(ctx->r10, 0X7C60);
    // 0x803987E4: and         $t3, $t2, $s0
    ctx->r11 = ctx->r10 & ctx->r16;
    // 0x803987E8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x803987EC: addiu       $a1, $a1, -0x3190
    ctx->r5 = ADD32(ctx->r5, -0X3190);
    // 0x803987F0: jal         0x8012B0F0
    // 0x803987F4: addu        $a0, $t3, $t4
    ctx->r4 = ADD32(ctx->r11, ctx->r12);
    UnpackRNC(rdram, ctx);
        goto after_13;
    // 0x803987F4: addu        $a0, $t3, $t4
    ctx->r4 = ADD32(ctx->r11, ctx->r12);
    after_13:
    // 0x803987F8: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x803987FC: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x80398800: addiu       $t5, $t5, 0x7D90
    ctx->r13 = ADD32(ctx->r13, 0X7D90);
    // 0x80398804: and         $t6, $t5, $s0
    ctx->r14 = ctx->r13 & ctx->r16;
    // 0x80398808: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039880C: addiu       $a1, $a1, -0x2CE0
    ctx->r5 = ADD32(ctx->r5, -0X2CE0);
    // 0x80398810: jal         0x8012B0F0
    // 0x80398814: addu        $a0, $t6, $t7
    ctx->r4 = ADD32(ctx->r14, ctx->r15);
    UnpackRNC(rdram, ctx);
        goto after_14;
    // 0x80398814: addu        $a0, $t6, $t7
    ctx->r4 = ADD32(ctx->r14, ctx->r15);
    after_14:
    // 0x80398818: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x8039881C: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x80398820: addiu       $t8, $t8, 0x7EC0
    ctx->r24 = ADD32(ctx->r24, 0X7EC0);
    // 0x80398824: and         $t9, $t8, $s0
    ctx->r25 = ctx->r24 & ctx->r16;
    // 0x80398828: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039882C: addiu       $a1, $a1, -0x2830
    ctx->r5 = ADD32(ctx->r5, -0X2830);
    // 0x80398830: jal         0x8012B0F0
    // 0x80398834: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    UnpackRNC(rdram, ctx);
        goto after_15;
    // 0x80398834: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    after_15:
    // 0x80398838: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8039883C: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80398840: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80398844: jr          $ra
    // 0x80398848: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x80398848: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void func_8039884C_7A9EFC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039884C: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x80398850: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80398854: jal         0x8039D6A4
    // 0x80398858: nop

    determine_available_levels(rdram, ctx);
        goto after_0;
    // 0x80398858: nop

    after_0:
    // 0x8039885C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80398860: addiu       $v0, $v0, 0x7D78
    ctx->r2 = ADD32(ctx->r2, 0X7D78);
    // 0x80398864: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80398868: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039886C: addiu       $v1, $v1, 0x7DA8
    ctx->r3 = ADD32(ctx->r3, 0X7DA8);
    // 0x80398870: addiu       $t6, $zero, 0x63
    ctx->r14 = ADD32(0, 0X63);
    // 0x80398874: sb          $t6, 0x32($v1)
    MEM_B(0X32, ctx->r3) = ctx->r14;
    // 0x80398878: sw          $zero, 0x18($v0)
    MEM_W(0X18, ctx->r2) = 0;
    // 0x8039887C: sw          $zero, 0x1C($v0)
    MEM_W(0X1C, ctx->r2) = 0;
    // 0x80398880: sh          $zero, 0x20($v0)
    MEM_H(0X20, ctx->r2) = 0;
    // 0x80398884: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80398888: swc1        $f0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f0.u32l;
    // 0x8039888C: swc1        $f0, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->f0.u32l;
    // 0x80398890: swc1        $f0, 0x8($v0)
    MEM_W(0X8, ctx->r2) = ctx->f0.u32l;
    // 0x80398894: swc1        $f0, 0xC($v0)
    MEM_W(0XC, ctx->r2) = ctx->f0.u32l;
    // 0x80398898: swc1        $f0, 0x10($v0)
    MEM_W(0X10, ctx->r2) = ctx->f0.u32l;
    // 0x8039889C: swc1        $f0, 0x14($v0)
    MEM_W(0X14, ctx->r2) = ctx->f0.u32l;
    // 0x803988A0: lwc1        $f4, 0x3F4($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X3F4);
    // 0x803988A4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803988A8: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x803988AC: addiu       $a1, $a1, 0x2E34
    ctx->r5 = ADD32(ctx->r5, 0X2E34);
    // 0x803988B0: addiu       $a0, $sp, 0x18
    ctx->r4 = ADD32(ctx->r29, 0X18);
    // 0x803988B4: jal         0x801308B4
    // 0x803988B8: swc1        $f4, 0x7D70($at)
    MEM_W(0X7D70, ctx->r1) = ctx->f4.u32l;
    prepare_text(rdram, ctx);
        goto after_1;
    // 0x803988B8: swc1        $f4, 0x7D70($at)
    MEM_W(0X7D70, ctx->r1) = ctx->f4.u32l;
    after_1:
    // 0x803988BC: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803988C0: addiu       $v1, $v1, 0x7DA8
    ctx->r3 = ADD32(ctx->r3, 0X7DA8);
    // 0x803988C4: lb          $t7, 0x2D($v1)
    ctx->r15 = MEM_B(ctx->r3, 0X2D);
    // 0x803988C8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803988CC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803988D0: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x803988D4: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x803988D8: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x803988DC: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x803988E0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x803988E4: swc1        $f6, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->f6.u32l;
    // 0x803988E8: cvt.s.w     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    ctx->f0.fl = CVT_S_W(ctx->f8.u32l);
    // 0x803988EC: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
    // 0x803988F0: swc1        $f0, 0x7468($at)
    MEM_W(0X7468, ctx->r1) = ctx->f0.u32l;
    // 0x803988F4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803988F8: swc1        $f0, 0x7D68($at)
    MEM_W(0X7D68, ctx->r1) = ctx->f0.u32l;
    // 0x803988FC: lui         $at, 0x4220
    ctx->r1 = S32(0X4220 << 16);
    // 0x80398900: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80398904: lui         $at, 0x41F0
    ctx->r1 = S32(0X41F0 << 16);
    // 0x80398908: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039890C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398910: swc1        $f10, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->f10.u32l;
    // 0x80398914: swc1        $f16, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->f16.u32l;
    // 0x80398918: sh          $zero, 0x7D9C($at)
    MEM_H(0X7D9C, ctx->r1) = 0;
    // 0x8039891C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398920: sh          $zero, 0x7D9E($at)
    MEM_H(0X7D9E, ctx->r1) = 0;
    // 0x80398924: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398928: sb          $v0, 0x7DA0($at)
    MEM_B(0X7DA0, ctx->r1) = ctx->r2;
    // 0x8039892C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398930: sb          $v0, 0x7DA1($at)
    MEM_B(0X7DA1, ctx->r1) = ctx->r2;
    // 0x80398934: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398938: sb          $zero, 0x7DA2($at)
    MEM_B(0X7DA2, ctx->r1) = 0;
    // 0x8039893C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398940: jal         0x80296320
    // 0x80398944: sb          $zero, 0x7DA3($at)
    MEM_B(0X7DA3, ctx->r1) = 0;
    get_evo_suit_color(rdram, ctx);
        goto after_2;
    // 0x80398944: sb          $zero, 0x7DA3($at)
    MEM_B(0X7DA3, ctx->r1) = 0;
    after_2:
    // 0x80398948: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8039894C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398950: sh          $v0, 0x2E1E($at)
    MEM_H(0X2E1E, ctx->r1) = ctx->r2;
    // 0x80398954: jr          $ra
    // 0x80398958: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    return;
    // 0x80398958: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
;}
RECOMP_FUNC void func_8039895C_7AA00C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039895C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398960: sh          $zero, 0x7D9C($at)
    MEM_H(0X7D9C, ctx->r1) = 0;
    // 0x80398964: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80398968: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039896C: sh          $zero, 0x7D9E($at)
    MEM_H(0X7D9E, ctx->r1) = 0;
    // 0x80398970: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80398974: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398978: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8039897C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80398980: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80398984: jal         0x8039D580
    // 0x80398988: sb          $zero, 0x7DD7($at)
    MEM_B(0X7DD7, ctx->r1) = 0;
    generate_stars(rdram, ctx);
        goto after_0;
    // 0x80398988: sb          $zero, 0x7DD7($at)
    MEM_B(0X7DD7, ctx->r1) = 0;
    after_0:
    // 0x8039898C: lui         $s2, 0x8024
    ctx->r18 = S32(0X8024 << 16);
    // 0x80398990: lui         $s1, 0x8024
    ctx->r17 = S32(0X8024 << 16);
    // 0x80398994: addiu       $s1, $s1, -0xDA0
    ctx->r17 = ADD32(ctx->r17, -0XDA0);
    // 0x80398998: addiu       $s2, $s2, -0xD20
    ctx->r18 = ADD32(ctx->r18, -0XD20);
    // 0x8039899C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x803989A0: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
L_803989A4:
    // 0x803989A4: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803989A8: jal         0x80130CD4
    // 0x803989AC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    read_eeprom(rdram, ctx);
        goto after_1;
    // 0x803989AC: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_1:
    // 0x803989B0: sll         $t7, $s0, 6
    ctx->r15 = S32(ctx->r16 << 6);
    // 0x803989B4: addu        $a1, $s2, $t7
    ctx->r5 = ADD32(ctx->r18, ctx->r15);
    // 0x803989B8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x803989BC: jal         0x80129158
    // 0x803989C0: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_2;
    // 0x803989C0: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_2:
    // 0x803989C4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x803989C8: sll         $t8, $s0, 16
    ctx->r24 = S32(ctx->r16 << 16);
    // 0x803989CC: sra         $s0, $t8, 16
    ctx->r16 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803989D0: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x803989D4: bnel        $at, $zero, L_803989A4
    if (ctx->r1 != 0) {
        // 0x803989D8: sll         $a0, $s0, 16
        ctx->r4 = S32(ctx->r16 << 16);
            goto L_803989A4;
    }
    goto skip_0;
    // 0x803989D8: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
    skip_0:
    // 0x803989DC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803989E0: jal         0x80130CD4
    // 0x803989E4: lb          $a0, 0x7DD6($a0)
    ctx->r4 = MEM_B(ctx->r4, 0X7DD6);
    read_eeprom(rdram, ctx);
        goto after_3;
    // 0x803989E4: lb          $a0, 0x7DD6($a0)
    ctx->r4 = MEM_B(ctx->r4, 0X7DD6);
    after_3:
    // 0x803989E8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x803989EC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803989F0: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x803989F4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x803989F8: jr          $ra
    // 0x803989FC: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x803989FC: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void func_80398A00_7AA0B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80398A00: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398A04: jr          $ra
    // 0x80398A08: sb          $zero, 0x7DD8($at)
    MEM_B(0X7DD8, ctx->r1) = 0;
    return;
    // 0x80398A08: sb          $zero, 0x7DD8($at)
    MEM_B(0X7DD8, ctx->r1) = 0;
;}
RECOMP_FUNC void display_zone_select_screen(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80398A0C: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x80398A10: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80398A14: addiu       $v1, $v1, 0x645C
    ctx->r3 = ADD32(ctx->r3, 0X645C);
    // 0x80398A18: sw          $zero, 0x4D2C($at)
    MEM_W(0X4D2C, ctx->r1) = 0;
    // 0x80398A1C: lh          $t6, 0x0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X0);
    // 0x80398A20: addiu       $sp, $sp, -0x140
    ctx->r29 = ADD32(ctx->r29, -0X140);
    // 0x80398A24: addiu       $v0, $zero, 0x19
    ctx->r2 = ADD32(0, 0X19);
    // 0x80398A28: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80398A2C: sw          $s1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r17;
    // 0x80398A30: beq         $v0, $t6, L_80398A64
    if (ctx->r2 == ctx->r14) {
        // 0x80398A34: sw          $s0, 0x34($sp)
        MEM_W(0X34, ctx->r29) = ctx->r16;
            goto L_80398A64;
    }
    // 0x80398A34: sw          $s0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r16;
    // 0x80398A38: sh          $v0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r2;
    // 0x80398A3C: addiu       $t7, $zero, 0x640
    ctx->r15 = ADD32(0, 0X640);
    // 0x80398A40: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80398A44: sh          $t7, 0x46D8($at)
    MEM_H(0X46D8, ctx->r1) = ctx->r15;
    // 0x80398A48: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80398A4C: addiu       $t8, $zero, 0x800
    ctx->r24 = ADD32(0, 0X800);
    // 0x80398A50: sh          $t8, 0x46E0($at)
    MEM_H(0X46E0, ctx->r1) = ctx->r24;
    // 0x80398A54: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80398A58: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80398A5C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80398A60: swc1        $f4, 0x517C($at)
    MEM_W(0X517C, ctx->r1) = ctx->f4.u32l;
L_80398A64:
    // 0x80398A64: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x80398A68: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80398A6C: lui         $v1, 0x803B
    ctx->r3 = S32(0X803B << 16);
    // 0x80398A70: addiu       $v1, $v1, 0x74C4
    ctx->r3 = ADD32(ctx->r3, 0X74C4);
    // 0x80398A74: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80398A78: swc1        $f6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->f6.u32l;
    // 0x80398A7C: lb          $v0, -0xD52($v0)
    ctx->r2 = MEM_B(ctx->r2, -0XD52);
    // 0x80398A80: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80398A84: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x80398A88: beq         $v0, $at, L_80398AA8
    if (ctx->r2 == ctx->r1) {
        // 0x80398A8C: addiu       $s1, $s1, -0x6184
        ctx->r17 = ADD32(ctx->r17, -0X6184);
            goto L_80398AA8;
    }
    // 0x80398A8C: addiu       $s1, $s1, -0x6184
    ctx->r17 = ADD32(ctx->r17, -0X6184);
    // 0x80398A90: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80398A94: beq         $v0, $at, L_80398AA8
    if (ctx->r2 == ctx->r1) {
        // 0x80398A98: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_80398AA8;
    }
    // 0x80398A98: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x80398A9C: beq         $v0, $at, L_80398AA8
    if (ctx->r2 == ctx->r1) {
        // 0x80398AA0: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_80398AA8;
    }
    // 0x80398AA0: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80398AA4: bne         $v0, $at, L_80398AB4
    if (ctx->r2 != ctx->r1) {
        // 0x80398AA8: lui         $at, 0x803C
        ctx->r1 = S32(0X803C << 16);
            goto L_80398AB4;
    }
L_80398AA8:
    // 0x80398AA8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80398AAC: lwc1        $f8, 0x3F8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X3F8);
    // 0x80398AB0: swc1        $f8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->f8.u32l;
L_80398AB4:
    // 0x80398AB4: jal         0x8039CE38
    // 0x80398AB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_8039CE38_7AE4E8(rdram, ctx);
        goto after_0;
    // 0x80398AB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_0:
    sssv_file_select_layout_hook(rdram, ctx, 0);
    // 0x80398ABC: jal         0x8039CAB8
    // 0x80398AC0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_8039CAB8_7AE168(rdram, ctx);
        goto after_1;
    // 0x80398AC0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    sssv_file_select_layout_hook(rdram, ctx, 1);
    // 0x80398AC4: jal         0x8039D30C
    // 0x80398AC8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    render_stars(rdram, ctx);
        goto after_2;
    // 0x80398AC8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_2:
    sssv_file_select_layout_hook(rdram, ctx, 2);
    // 0x80398ACC: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398AD0: lui         $a2, 0xE700
    ctx->r6 = S32(0XE700 << 16);
    // 0x80398AD4: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x80398AD8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80398ADC: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x80398AE0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398AE4: sw          $a2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r6;
    // 0x80398AE8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398AEC: ori         $t6, $t6, 0x1402
    ctx->r14 = ctx->r14 | 0X1402;
    // 0x80398AF0: lui         $at, 0x42BC
    ctx->r1 = S32(0X42BC << 16);
    // 0x80398AF4: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80398AF8: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x80398AFC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398B00: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80398B04: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398B08: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80398B0C: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x80398B10: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80398B14: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80398B18: lui         $at, 0x4306
    ctx->r1 = S32(0X4306 << 16);
    // 0x80398B1C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80398B20: addiu       $s0, $s0, 0x7DA8
    ctx->r16 = ADD32(ctx->r16, 0X7DA8);
    // 0x80398B24: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398B28: sw          $a2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r6;
    // 0x80398B2C: swc1        $f14, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f14.u32l;
    // 0x80398B30: lwc1        $f12, 0x0($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80398B34: jal         0x8039CDE8
    // 0x80398B38: swc1        $f10, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f10.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_3;
    // 0x80398B38: swc1        $f10, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f10.u32l;
    after_3:
    // 0x80398B3C: lui         $at, 0x4306
    ctx->r1 = S32(0X4306 << 16);
    // 0x80398B40: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80398B44: swc1        $f0, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f0.u32l;
    // 0x80398B48: jal         0x8039CDE8
    // 0x80398B4C: lwc1        $f12, 0x4($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X4);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_4;
    // 0x80398B4C: lwc1        $f12, 0x4($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X4);
    after_4:
    // 0x80398B50: lwc1        $f18, 0x8($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80398B54: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80398B58: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x80398B5C: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80398B60: cvt.d.s     $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f2.d = CVT_D_S(ctx->f18.fl);
    // 0x80398B64: lui         $at, 0x4030
    ctx->r1 = S32(0X4030 << 16);
    // 0x80398B68: sub.d       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = ctx->f4.d - ctx->f2.d;
    // 0x80398B6C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80398B70: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80398B74: swc1        $f0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f0.u32l;
    // 0x80398B78: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80398B7C: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x80398B80: add.d       $f18, $f2, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = ctx->f2.d + ctx->f10.d;
    // 0x80398B84: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x80398B88: swc1        $f4, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->f4.u32l;
    // 0x80398B8C: lwc1        $f12, 0x8($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80398B90: ldc1        $f6, 0x400($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, 0X400);
    // 0x80398B94: cvt.d.s     $f2, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f2.d = CVT_D_S(ctx->f12.fl);
    // 0x80398B98: c.lt.d      $f6, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f6.d < ctx->f2.d;
    // 0x80398B9C: nop

    // 0x80398BA0: bc1f        L_80398BD0
    if (!c1cs) {
        // 0x80398BA4: lui         $at, 0x803C
        ctx->r1 = S32(0X803C << 16);
            goto L_80398BD0;
    }
    // 0x80398BA4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80398BA8: ldc1        $f8, 0x408($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, 0X408);
    // 0x80398BAC: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80398BB0: c.lt.d      $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f2.d < ctx->f8.d;
    // 0x80398BB4: nop

    // 0x80398BB8: bc1fl       L_80398BD4
    if (!c1cs) {
        // 0x80398BBC: lui         $at, 0x41AC
        ctx->r1 = S32(0X41AC << 16);
            goto L_80398BD4;
    }
    goto skip_0;
    // 0x80398BBC: lui         $at, 0x41AC
    ctx->r1 = S32(0X41AC << 16);
    skip_0:
    // 0x80398BC0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80398BC4: nop

    // 0x80398BC8: swc1        $f10, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->f10.u32l;
    // 0x80398BCC: lwc1        $f12, 0x8($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X8);
L_80398BD0:
    // 0x80398BD0: lui         $at, 0x41AC
    ctx->r1 = S32(0X41AC << 16);
L_80398BD4:
    // 0x80398BD4: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80398BD8: lwc1        $f4, 0x0($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80398BDC: lwc1        $f8, 0x4($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X4);
    // 0x80398BE0: mul.s       $f0, $f18, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f0.fl = MUL_S(ctx->f18.fl, ctx->f12.fl);
    // 0x80398BE4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398BE8: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x80398BEC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80398BF0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398BF4: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398BF8: sub.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f0.fl;
    // 0x80398BFC: sub.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f0.fl;
    // 0x80398C00: swc1        $f6, 0xE0($sp)
    MEM_W(0XE0, ctx->r29) = ctx->f6.u32l;
    // 0x80398C04: swc1        $f10, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->f10.u32l;
    // 0x80398C08: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398C0C: jal         0x8012C1F0
    // 0x80398C10: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    load_default_display_list(rdram, ctx);
        goto after_5;
    // 0x80398C10: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    after_5:
    // 0x80398C14: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80398C18: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80398C1C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80398C20: jal         0x8012C248
    // 0x80398C24: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_6;
    // 0x80398C24: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_6:
    // 0x80398C28: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80398C2C: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80398C30: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80398C34: jal         0x8012C214
    // 0x80398C38: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_7;
    // 0x80398C38: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_7:
    // 0x80398C3C: jal         0x80130A90
    // 0x80398C40: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    get_message_address_by_id(rdram, ctx);
        goto after_8;
    // 0x80398C40: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_8:
    // 0x80398C44: lui         $at, 0x41C0
    ctx->r1 = S32(0X41C0 << 16);
    // 0x80398C48: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80398C4C: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x80398C50: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80398C54: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x80398C58: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80398C5C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80398C60: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80398C64: addiu       $a2, $zero, 0x18
    ctx->r6 = ADD32(0, 0X18);
    // 0x80398C68: addiu       $a3, $zero, 0x1F
    ctx->r7 = ADD32(0, 0X1F);
    // 0x80398C6C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    sssv_hd_menu_title_hook(rdram, ctx);
    // 0x80398C70: jal         0x8012D374
    // 0x80398C74: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    func_8012D374(rdram, ctx);
        goto after_9;
    // 0x80398C74: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_9:
    // 0x80398C78: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398C7C: lui         $t1, 0x8016
    ctx->r9 = S32(0X8016 << 16);
    // 0x80398C80: addiu       $t1, $t1, -0x7B60
    ctx->r9 = ADD32(ctx->r9, -0X7B60);
    // 0x80398C84: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80398C88: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80398C8C: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x80398C90: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80398C94: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
    // 0x80398C98: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398C9C: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x80398CA0: ori         $t9, $t9, 0x602
    ctx->r25 = ctx->r25 | 0X602;
    // 0x80398CA4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398CA8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398CAC: addiu       $t5, $zero, 0xC0
    ctx->r13 = ADD32(0, 0XC0);
    // 0x80398CB0: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80398CB4: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398CB8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398CBC: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x80398CC0: ori         $t7, $t7, 0x402
    ctx->r15 = ctx->r15 | 0X402;
    // 0x80398CC4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80398CC8: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80398CCC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398CD0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80398CD4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398CD8: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x80398CDC: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x80398CE0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398CE4: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398CE8: lui         $t8, 0x801E
    ctx->r24 = S32(0X801E << 16);
    // 0x80398CEC: lui         $t6, 0x401
    ctx->r14 = S32(0X401 << 16);
    // 0x80398CF0: lui         $at, 0xFF
    ctx->r1 = S32(0XFF << 16);
    // 0x80398CF4: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80398CF8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398CFC: lw          $t8, -0x6194($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X6194);
    // 0x80398D00: ori         $at, $at, 0xFFFF
    ctx->r1 = ctx->r1 | 0XFFFF;
    // 0x80398D04: addiu       $t6, $t6, 0x2B20
    ctx->r14 = ADD32(ctx->r14, 0X2B20);
    // 0x80398D08: and         $t7, $t6, $at
    ctx->r15 = ctx->r14 & ctx->r1;
    // 0x80398D0C: lui         $a1, 0x800E
    ctx->r5 = S32(0X800E << 16);
    // 0x80398D10: addiu       $a1, $a1, -0x2C10
    ctx->r5 = ADD32(ctx->r5, -0X2C10);
    // 0x80398D14: sw          $t1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r9;
    // 0x80398D18: jal         0x8012B0F0
    // 0x80398D1C: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    UnpackRNC(rdram, ctx);
        goto after_10;
    // 0x80398D1C: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    after_10:
    // 0x80398D20: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x80398D24: lb          $t9, 0x32($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X32);
    // 0x80398D28: beq         $a3, $t9, L_80398DD8
    if (ctx->r7 == ctx->r25) {
        // 0x80398D2C: lui         $t7, 0x803B
        ctx->r15 = S32(0X803B << 16);
            goto L_80398DD8;
    }
    // 0x80398D2C: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80398D30: addiu       $t7, $t7, 0x7268
    ctx->r15 = ADD32(ctx->r15, 0X7268);
    // 0x80398D34: sll         $t6, $a3, 3
    ctx->r14 = S32(ctx->r7 << 3);
    // 0x80398D38: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x80398D3C: lw          $a0, 0x0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X0);
    // 0x80398D40: lw          $t8, 0x4($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X4);
    // 0x80398D44: lui         $a1, 0x800B
    ctx->r5 = S32(0X800B << 16);
    // 0x80398D48: addiu       $a1, $a1, 0xB20
    ctx->r5 = ADD32(ctx->r5, 0XB20);
    // 0x80398D4C: jal         0x80129290
    // 0x80398D50: subu        $a2, $t8, $a0
    ctx->r6 = SUB32(ctx->r24, ctx->r4);
    dma_read(rdram, ctx);
        goto after_11;
    // 0x80398D50: subu        $a2, $t8, $a0
    ctx->r6 = SUB32(ctx->r24, ctx->r4);
    after_11:
    // 0x80398D54: lui         $a0, 0x800B
    ctx->r4 = S32(0X800B << 16);
    // 0x80398D58: lui         $a1, 0x800B
    ctx->r5 = S32(0X800B << 16);
    // 0x80398D5C: addiu       $a1, $a1, 0x49A0
    ctx->r5 = ADD32(ctx->r5, 0X49A0);
    // 0x80398D60: jal         0x8012B0F0
    // 0x80398D64: addiu       $a0, $a0, 0xB20
    ctx->r4 = ADD32(ctx->r4, 0XB20);
    UnpackRNC(rdram, ctx);
        goto after_12;
    // 0x80398D64: addiu       $a0, $a0, 0xB20
    ctx->r4 = ADD32(ctx->r4, 0XB20);
    after_12:
    // 0x80398D68: lb          $t9, 0x2D($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2D);
    // 0x80398D6C: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80398D70: addiu       $t6, $t6, 0x7368
    ctx->r14 = ADD32(ctx->r14, 0X7368);
    // 0x80398D74: sll         $t5, $t9, 3
    ctx->r13 = S32(ctx->r25 << 3);
    // 0x80398D78: addu        $v1, $t5, $t6
    ctx->r3 = ADD32(ctx->r13, ctx->r14);
    // 0x80398D7C: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80398D80: lw          $t7, 0x4($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X4);
    // 0x80398D84: lui         $a1, 0x800B
    ctx->r5 = S32(0X800B << 16);
    // 0x80398D88: addiu       $a1, $a1, 0xB20
    ctx->r5 = ADD32(ctx->r5, 0XB20);
    // 0x80398D8C: sb          $t9, 0x32($s0)
    MEM_B(0X32, ctx->r16) = ctx->r25;
    // 0x80398D90: jal         0x80129290
    // 0x80398D94: subu        $a2, $t7, $a0
    ctx->r6 = SUB32(ctx->r15, ctx->r4);
    dma_read(rdram, ctx);
        goto after_13;
    // 0x80398D94: subu        $a2, $t7, $a0
    ctx->r6 = SUB32(ctx->r15, ctx->r4);
    after_13:
    // 0x80398D98: lui         $a0, 0x800B
    ctx->r4 = S32(0X800B << 16);
    // 0x80398D9C: lui         $a1, 0x800B
    ctx->r5 = S32(0X800B << 16);
    // 0x80398DA0: addiu       $a1, $a1, 0x68E0
    ctx->r5 = ADD32(ctx->r5, 0X68E0);
    // 0x80398DA4: jal         0x8012B0F0
    // 0x80398DA8: addiu       $a0, $a0, 0xB20
    ctx->r4 = ADD32(ctx->r4, 0XB20);
    UnpackRNC(rdram, ctx);
        goto after_14;
    // 0x80398DA8: addiu       $a0, $a0, 0xB20
    ctx->r4 = ADD32(ctx->r4, 0XB20);
    after_14:
    // 0x80398DAC: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x80398DB0: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80398DB4: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80398DB8: addiu       $a3, $a3, 0x34C0
    ctx->r7 = ADD32(ctx->r7, 0X34C0);
    // 0x80398DBC: addiu       $a2, $a2, 0x3330
    ctx->r6 = ADD32(ctx->r6, 0X3330);
    // 0x80398DC0: lb          $a0, -0xD52($a0)
    ctx->r4 = MEM_B(ctx->r4, -0XD52);
    // 0x80398DC4: jal         0x801308E8
    // 0x80398DC8: lb          $a1, 0x2D($s0)
    ctx->r5 = MEM_B(ctx->r16, 0X2D);
    load_level_text_data(rdram, ctx);
        goto after_15;
    // 0x80398DC8: lb          $a1, 0x2D($s0)
    ctx->r5 = MEM_B(ctx->r16, 0X2D);
    after_15:
    // 0x80398DCC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80398DD0: jal         0x8039DBC8
    // 0x80398DD4: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    static_2_8039DBC8(rdram, ctx);
        goto after_16;
    // 0x80398DD4: sh          $v0, 0x63C0($at)
    MEM_H(0X63C0, ctx->r1) = ctx->r2;
    after_16:
L_80398DD8:
    // 0x80398DD8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398DDC: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x80398DE0: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x80398DE4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398DE8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398DEC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398DF0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398DF4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398DF8: addiu       $t7, $zero, -0x80
    ctx->r15 = ADD32(0, -0X80);
    // 0x80398DFC: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x80398E00: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80398E04: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x80398E08: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80398E0C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80398E10: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398E14: ori         $t9, $t9, 0x2
    ctx->r25 = ctx->r25 | 0X2;
    // 0x80398E18: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x80398E1C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398E20: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398E24: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398E28: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398E2C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398E30: lui         $t7, 0x50
    ctx->r15 = S32(0X50 << 16);
    // 0x80398E34: ori         $t7, $t7, 0x4240
    ctx->r15 = ctx->r15 | 0X4240;
    // 0x80398E38: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80398E3C: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x80398E40: ori         $t6, $t6, 0x31D
    ctx->r14 = ctx->r14 | 0X31D;
    // 0x80398E44: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80398E48: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80398E4C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398E50: lui         $t5, 0xFF2F
    ctx->r13 = S32(0XFF2F << 16);
    // 0x80398E54: lui         $t9, 0xFC11
    ctx->r25 = S32(0XFC11 << 16);
    // 0x80398E58: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398E5C: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398E60: ori         $t9, $t9, 0x9623
    ctx->r25 = ctx->r25 | 0X9623;
    // 0x80398E64: ori         $t5, $t5, 0xFFFF
    ctx->r13 = ctx->r13 | 0XFFFF;
    // 0x80398E68: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80398E6C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398E70: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398E74: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80398E78: lui         $t9, 0x800B
    ctx->r25 = S32(0X800B << 16);
    // 0x80398E7C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80398E80: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80398E84: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80398E88: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80398E8C: addiu       $t6, $zero, 0x2F
    ctx->r14 = ADD32(0, 0X2F);
    // 0x80398E90: addiu       $t9, $t9, 0x49A0
    ctx->r25 = ADD32(ctx->r25, 0X49A0);
    // 0x80398E94: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x80398E98: addiu       $t8, $zero, 0x378
    ctx->r24 = ADD32(0, 0X378);
    // 0x80398E9C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80398EA0: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80398EA4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80398EA8: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80398EAC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80398EB0: addiu       $a1, $zero, 0x320
    ctx->r5 = ADD32(0, 0X320);
    // 0x80398EB4: addiu       $a2, $zero, 0x250
    ctx->r6 = ADD32(0, 0X250);
    // 0x80398EB8: jal         0x803962EC
    // 0x80398EBC: addiu       $a3, $zero, 0x4B0
    ctx->r7 = ADD32(0, 0X4B0);
    func_803962EC_7A799C(rdram, ctx);
        goto after_17;
    // 0x80398EBC: addiu       $a3, $zero, 0x4B0
    ctx->r7 = ADD32(0, 0X4B0);
    after_17:
    // 0x80398EC0: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398EC4: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x80398EC8: lui         $t9, 0x50
    ctx->r25 = S32(0X50 << 16);
    // 0x80398ECC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80398ED0: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x80398ED4: ori         $t9, $t9, 0x4240
    ctx->r25 = ctx->r25 | 0X4240;
    // 0x80398ED8: ori         $t8, $t8, 0x31D
    ctx->r24 = ctx->r24 | 0X31D;
    // 0x80398EDC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80398EE0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80398EE4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398EE8: lui         $t7, 0xFF2F
    ctx->r15 = S32(0XFF2F << 16);
    // 0x80398EEC: lui         $t6, 0xFC11
    ctx->r14 = S32(0XFC11 << 16);
    // 0x80398EF0: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80398EF4: sw          $t5, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r13;
    // 0x80398EF8: ori         $t6, $t6, 0x9623
    ctx->r14 = ctx->r14 | 0X9623;
    // 0x80398EFC: ori         $t7, $t7, 0xFFFF
    ctx->r15 = ctx->r15 | 0XFFFF;
    // 0x80398F00: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80398F04: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80398F08: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80398F0C: addiu       $t5, $zero, -0xE6
    ctx->r13 = ADD32(0, -0XE6);
    // 0x80398F10: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x80398F14: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80398F18: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80398F1C: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80398F20: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80398F24: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x80398F28: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x80398F2C: addiu       $a2, $a3, 0x1
    ctx->r6 = ADD32(ctx->r7, 0X1);
    // 0x80398F30: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x80398F34: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80398F38: beq         $t7, $at, L_80398F60
    if (ctx->r15 == ctx->r1) {
        // 0x80398F3C: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80398F60;
    }
    // 0x80398F3C: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80398F40: beq         $t7, $at, L_80398F60
    if (ctx->r15 == ctx->r1) {
        // 0x80398F44: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_80398F60;
    }
    // 0x80398F44: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x80398F48: beq         $t7, $at, L_80398F60
    if (ctx->r15 == ctx->r1) {
        // 0x80398F4C: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_80398F60;
    }
    // 0x80398F4C: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80398F50: beq         $t7, $at, L_80398F60
    if (ctx->r15 == ctx->r1) {
        // 0x80398F54: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_80398F60;
    }
    // 0x80398F54: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80398F58: bne         $t7, $at, L_80399020
    if (ctx->r15 != ctx->r1) {
        // 0x80398F5C: lui         $t6, 0x8024
        ctx->r14 = S32(0X8024 << 16);
            goto L_80399020;
    }
    // 0x80398F5C: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
L_80398F60:
    // 0x80398F60: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80398F64: lh          $v0, 0x2E1E($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2E1E);
    // 0x80398F68: addiu       $t8, $zero, 0xC8
    ctx->r24 = ADD32(0, 0XC8);
    // 0x80398F6C: addiu       $a0, $zero, 0x114
    ctx->r4 = ADD32(0, 0X114);
    // 0x80398F70: beq         $v0, $zero, L_80398F98
    if (ctx->r2 == 0) {
        // 0x80398F74: addiu       $a1, $zero, 0x66
        ctx->r5 = ADD32(0, 0X66);
            goto L_80398F98;
    }
    // 0x80398F74: addiu       $a1, $zero, 0x66
    ctx->r5 = ADD32(0, 0X66);
    // 0x80398F78: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80398F7C: beq         $v0, $at, L_80398FAC
    if (ctx->r2 == ctx->r1) {
        // 0x80398F80: addiu       $t5, $zero, 0xB4
        ctx->r13 = ADD32(0, 0XB4);
            goto L_80398FAC;
    }
    // 0x80398F80: addiu       $t5, $zero, 0xB4
    ctx->r13 = ADD32(0, 0XB4);
    // 0x80398F84: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80398F88: beq         $v0, $at, L_80398FC4
    if (ctx->r2 == ctx->r1) {
        // 0x80398F8C: addiu       $t8, $zero, 0xFF
        ctx->r24 = ADD32(0, 0XFF);
            goto L_80398FC4;
    }
    // 0x80398F8C: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x80398F90: b           L_80398FD8
    // 0x80398F94: nop

        goto L_80398FD8;
    // 0x80398F94: nop

L_80398F98:
    // 0x80398F98: addiu       $t9, $zero, 0xC8
    ctx->r25 = ADD32(0, 0XC8);
    // 0x80398F9C: sb          $t8, 0xC7($sp)
    MEM_B(0XC7, ctx->r29) = ctx->r24;
    // 0x80398FA0: sb          $t9, 0xC5($sp)
    MEM_B(0XC5, ctx->r29) = ctx->r25;
    // 0x80398FA4: b           L_80398FD8
    // 0x80398FA8: sb          $zero, 0xC6($sp)
    MEM_B(0XC6, ctx->r29) = 0;
        goto L_80398FD8;
    // 0x80398FA8: sb          $zero, 0xC6($sp)
    MEM_B(0XC6, ctx->r29) = 0;
L_80398FAC:
    // 0x80398FAC: addiu       $t6, $zero, 0xB4
    ctx->r14 = ADD32(0, 0XB4);
    // 0x80398FB0: addiu       $t7, $zero, 0xB4
    ctx->r15 = ADD32(0, 0XB4);
    // 0x80398FB4: sb          $t5, 0xC7($sp)
    MEM_B(0XC7, ctx->r29) = ctx->r13;
    // 0x80398FB8: sb          $t6, 0xC5($sp)
    MEM_B(0XC5, ctx->r29) = ctx->r14;
    // 0x80398FBC: b           L_80398FD8
    // 0x80398FC0: sb          $t7, 0xC6($sp)
    MEM_B(0XC6, ctx->r29) = ctx->r15;
        goto L_80398FD8;
    // 0x80398FC0: sb          $t7, 0xC6($sp)
    MEM_B(0XC6, ctx->r29) = ctx->r15;
L_80398FC4:
    // 0x80398FC4: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x80398FC8: addiu       $t5, $zero, 0x14
    ctx->r13 = ADD32(0, 0X14);
    // 0x80398FCC: sb          $t8, 0xC7($sp)
    MEM_B(0XC7, ctx->r29) = ctx->r24;
    // 0x80398FD0: sb          $t9, 0xC5($sp)
    MEM_B(0XC5, ctx->r29) = ctx->r25;
    // 0x80398FD4: sb          $t5, 0xC6($sp)
    MEM_B(0XC6, ctx->r29) = ctx->r13;
L_80398FD8:
    // 0x80398FD8: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80398FDC: lb          $v0, -0xD65($v0)
    ctx->r2 = MEM_B(ctx->r2, -0XD65);
    // 0x80398FE0: lbu         $t6, 0xC6($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XC6);
    // 0x80398FE4: lbu         $a2, 0xC7($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0XC7);
    // 0x80398FE8: andi        $t7, $v0, 0x2
    ctx->r15 = ctx->r2 & 0X2;
    // 0x80398FEC: andi        $t8, $v0, 0x1
    ctx->r24 = ctx->r2 & 0X1;
    // 0x80398FF0: andi        $t9, $v0, 0x4
    ctx->r25 = ctx->r2 & 0X4;
    // 0x80398FF4: andi        $t5, $v0, 0x8
    ctx->r13 = ctx->r2 & 0X8;
    // 0x80398FF8: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x80398FFC: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80399000: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80399004: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80399008: lbu         $a3, 0xC5($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XC5);
    // 0x8039900C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80399010: jal         0x803967D4
    // 0x80399014: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_803967D4_7A7E84(rdram, ctx);
        goto after_18;
    // 0x80399014: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_18:
    // 0x80399018: b           L_80399084
    // 0x8039901C: nop

        goto L_80399084;
    // 0x8039901C: nop

L_80399020:
    // 0x80399020: addu        $t6, $t6, $a3
    ctx->r14 = ADD32(ctx->r14, ctx->r7);
    // 0x80399024: lbu         $t6, -0xD9C($t6)
    ctx->r14 = MEM_BU(ctx->r14, -0XD9C);
    // 0x80399028: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039902C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x80399030: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x80399034: beq         $t7, $zero, L_80399084
    if (ctx->r15 == 0) {
        // 0x80399038: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80399084;
    }
    // 0x80399038: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039903C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80399040: lui         $t7, 0x800B
    ctx->r15 = S32(0X800B << 16);
    // 0x80399044: addiu       $t7, $t7, 0x68E0
    ctx->r15 = ADD32(ctx->r15, 0X68E0);
    // 0x80399048: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039904C: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x80399050: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80399054: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80399058: addiu       $t9, $zero, 0x1F
    ctx->r25 = ADD32(0, 0X1F);
    // 0x8039905C: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x80399060: addiu       $t6, $zero, 0x240
    ctx->r14 = ADD32(0, 0X240);
    // 0x80399064: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80399068: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8039906C: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80399070: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80399074: addiu       $a1, $zero, 0x430
    ctx->r5 = ADD32(0, 0X430);
    // 0x80399078: addiu       $a2, $zero, 0x1C0
    ctx->r6 = ADD32(0, 0X1C0);
    // 0x8039907C: jal         0x803962EC
    // 0x80399080: addiu       $a3, $zero, 0x4B0
    ctx->r7 = ADD32(0, 0X4B0);
    func_803962EC_7A799C(rdram, ctx);
        goto after_19;
    // 0x80399080: addiu       $a3, $zero, 0x4B0
    ctx->r7 = ADD32(0, 0X4B0);
    after_19:
L_80399084:
    // 0x80399084: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80399088: addiu       $a2, $a2, 0x7DA2
    ctx->r6 = ADD32(ctx->r6, 0X7DA2);
    // 0x8039908C: lb          $v0, 0x0($a2)
    ctx->r2 = MEM_B(ctx->r6, 0X0);
    // 0x80399090: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80399094: addiu       $t0, $t0, 0x7DA3
    ctx->r8 = ADD32(ctx->r8, 0X7DA3);
    // 0x80399098: beq         $v0, $zero, L_803990A8
    if (ctx->r2 == 0) {
        // 0x8039909C: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_803990A8;
    }
    // 0x8039909C: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x803990A0: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x803990A4: sb          $t5, 0x0($a2)
    MEM_B(0X0, ctx->r6) = ctx->r13;
L_803990A8:
    // 0x803990A8: lb          $v0, 0x0($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X0);
    // 0x803990AC: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x803990B0: beq         $v0, $zero, L_803990BC
    if (ctx->r2 == 0) {
        // 0x803990B4: addiu       $t6, $v0, -0x1
        ctx->r14 = ADD32(ctx->r2, -0X1);
            goto L_803990BC;
    }
    // 0x803990B4: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x803990B8: sb          $t6, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r14;
L_803990BC:
    // 0x803990BC: lbu         $t7, 0x12E4($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12E4);
    // 0x803990C0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803990C4: bne         $t7, $at, L_803990E4
    if (ctx->r15 != ctx->r1) {
        // 0x803990C8: lui         $t8, 0x8029
        ctx->r24 = S32(0X8029 << 16);
            goto L_803990E4;
    }
    // 0x803990C8: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x803990CC: lw          $t8, 0x10D0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X10D0);
    // 0x803990D0: lb          $t9, 0x2($t8)
    ctx->r25 = MEM_B(ctx->r24, 0X2);
    // 0x803990D4: slti        $at, $t9, 0x15
    ctx->r1 = SIGNED(ctx->r25) < 0X15 ? 1 : 0;
    // 0x803990D8: beq         $at, $zero, L_803990E4
    if (ctx->r1 == 0) {
        // 0x803990DC: nop
    
            goto L_803990E4;
    }
    // 0x803990DC: nop

    // 0x803990E0: sb          $zero, 0x0($t0)
    MEM_B(0X0, ctx->r8) = 0;
L_803990E4:
    // 0x803990E4: lbu         $t5, 0x12E3($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X12E3);
    // 0x803990E8: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x803990EC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803990F0: bne         $t5, $at, L_8039910C
    if (ctx->r13 != ctx->r1) {
        // 0x803990F4: lw          $v0, 0x10D0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X10D0);
            goto L_8039910C;
    }
    // 0x803990F4: lw          $v0, 0x10D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X10D0);
    // 0x803990F8: lb          $t6, 0x2($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X2);
    // 0x803990FC: slti        $at, $t6, -0x14
    ctx->r1 = SIGNED(ctx->r14) < -0X14 ? 1 : 0;
    // 0x80399100: bnel        $at, $zero, L_80399110
    if (ctx->r1 != 0) {
        // 0x80399104: lhu         $v1, 0x0($v0)
        ctx->r3 = MEM_HU(ctx->r2, 0X0);
            goto L_80399110;
    }
    goto skip_1;
    // 0x80399104: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    skip_1:
    // 0x80399108: sb          $zero, 0x0($a2)
    MEM_B(0X0, ctx->r6) = 0;
L_8039910C:
    // 0x8039910C: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
L_80399110:
    // 0x80399110: andi        $t7, $v1, 0x200
    ctx->r15 = ctx->r3 & 0X200;
    // 0x80399114: bnel        $t7, $zero, L_80399130
    if (ctx->r15 != 0) {
        // 0x80399118: lb          $t9, 0x0($a2)
        ctx->r25 = MEM_B(ctx->r6, 0X0);
            goto L_80399130;
    }
    goto skip_2;
    // 0x80399118: lb          $t9, 0x0($a2)
    ctx->r25 = MEM_B(ctx->r6, 0X0);
    skip_2:
    // 0x8039911C: lb          $t8, 0x2($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X2);
    // 0x80399120: slti        $at, $t8, -0x14
    ctx->r1 = SIGNED(ctx->r24) < -0X14 ? 1 : 0;
    // 0x80399124: beql        $at, $zero, L_8039926C
    if (ctx->r1 == 0) {
        // 0x80399128: andi        $t6, $v1, 0x100
        ctx->r14 = ctx->r3 & 0X100;
            goto L_8039926C;
    }
    goto skip_3;
    // 0x80399128: andi        $t6, $v1, 0x100
    ctx->r14 = ctx->r3 & 0X100;
    skip_3:
    // 0x8039912C: lb          $t9, 0x0($a2)
    ctx->r25 = MEM_B(ctx->r6, 0X0);
L_80399130:
    // 0x80399130: addiu       $a1, $zero, -0x1
    ctx->r5 = ADD32(0, -0X1);
    // 0x80399134: bnel        $t9, $zero, L_8039926C
    if (ctx->r25 != 0) {
        // 0x80399138: andi        $t6, $v1, 0x100
        ctx->r14 = ctx->r3 & 0X100;
            goto L_8039926C;
    }
    goto skip_4;
    // 0x80399138: andi        $t6, $v1, 0x100
    ctx->r14 = ctx->r3 & 0X100;
    skip_4:
    // 0x8039913C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80399140: addiu       $v1, $v1, 0x7DA0
    ctx->r3 = ADD32(ctx->r3, 0X7DA0);
    // 0x80399144: lb          $v0, 0x0($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X0);
    // 0x80399148: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x8039914C: addiu       $t5, $zero, 0x8
    ctx->r13 = ADD32(0, 0X8);
    // 0x80399150: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x80399154: beq         $at, $zero, L_80399164
    if (ctx->r1 == 0) {
        // 0x80399158: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_80399164;
    }
    // 0x80399158: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x8039915C: b           L_8039916C
    // 0x80399160: sb          $t5, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r13;
        goto L_8039916C;
    // 0x80399160: sb          $t5, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r13;
L_80399164:
    // 0x80399164: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x80399168: sb          $t6, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r14;
L_8039916C:
    // 0x8039916C: lb          $t7, 0x0($v1)
    ctx->r15 = MEM_B(ctx->r3, 0X0);
    // 0x80399170: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80399174: sh          $a3, 0xD2($sp)
    MEM_H(0XD2, ctx->r29) = ctx->r7;
    // 0x80399178: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x8039917C: jal         0x8039DAAC
    // 0x80399180: sb          $t7, 0x0($a2)
    MEM_B(0X0, ctx->r6) = ctx->r15;
    get_next_available_level(rdram, ctx);
        goto after_20;
    // 0x80399180: sb          $t7, 0x0($a2)
    MEM_B(0X0, ctx->r6) = ctx->r15;
    after_20:
    // 0x80399184: sb          $v0, 0x2D($s0)
    MEM_B(0X2D, ctx->r16) = ctx->r2;
    // 0x80399188: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x8039918C: lh          $t9, 0xD2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD2);
    // 0x80399190: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80399194: beql        $t9, $a3, L_80399224
    if (ctx->r25 == ctx->r7) {
        // 0x80399198: lh          $t5, 0xD2($sp)
        ctx->r13 = MEM_H(ctx->r29, 0XD2);
            goto L_80399224;
    }
    goto skip_5;
    // 0x80399198: lh          $t5, 0xD2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XD2);
    skip_5:
    // 0x8039919C: bne         $a3, $at, L_803991C8
    if (ctx->r7 != ctx->r1) {
        // 0x803991A0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_803991C8;
    }
    // 0x803991A0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x803991A4: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x803991A8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x803991AC: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x803991B0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803991B4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803991B8: jal         0x8013307C
    // 0x803991BC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_21;
    // 0x803991BC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_21:
    // 0x803991C0: b           L_80399220
    // 0x803991C4: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
        goto L_80399220;
    // 0x803991C4: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_803991C8:
    // 0x803991C8: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803991CC: jal         0x8039DCC0
    // 0x803991D0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    get_biome_for_level(rdram, ctx);
        goto after_22;
    // 0x803991D0: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_22:
    // 0x803991D4: lb          $t7, 0x2C($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2C);
    // 0x803991D8: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x803991DC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803991E0: beq         $v0, $t7, L_8039920C
    if (ctx->r2 == ctx->r15) {
        // 0x803991E4: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039920C;
    }
    // 0x803991E4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803991E8: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x803991EC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803991F0: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x803991F4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803991F8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803991FC: jal         0x8013307C
    // 0x80399200: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_23;
    // 0x80399200: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_23:
    // 0x80399204: b           L_80399220
    // 0x80399208: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
        goto L_80399220;
    // 0x80399208: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_8039920C:
    // 0x8039920C: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x80399210: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80399214: jal         0x8013307C
    // 0x80399218: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_24;
    // 0x80399218: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_24:
    // 0x8039921C: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_80399220:
    // 0x80399220: lh          $t5, 0xD2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XD2);
L_80399224:
    // 0x80399224: beq         $t5, $a3, L_8039924C
    if (ctx->r13 == ctx->r7) {
        // 0x80399228: nop
    
            goto L_8039924C;
    }
    // 0x80399228: nop

    // 0x8039922C: jal         0x80395074
    // 0x80399230: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_25;
    // 0x80399230: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_25:
    // 0x80399234: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x80399238: lw          $v0, 0x10D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X10D0);
    // 0x8039923C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80399240: addiu       $t0, $t0, 0x7DA3
    ctx->r8 = ADD32(ctx->r8, 0X7DA3);
    // 0x80399244: b           L_80399268
    // 0x80399248: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
        goto L_80399268;
    // 0x80399248: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
L_8039924C:
    // 0x8039924C: jal         0x80395074
    // 0x80399250: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_80395074_7A6724(rdram, ctx);
        goto after_26;
    // 0x80399250: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_26:
    // 0x80399254: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x80399258: lw          $v0, 0x10D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X10D0);
    // 0x8039925C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80399260: addiu       $t0, $t0, 0x7DA3
    ctx->r8 = ADD32(ctx->r8, 0X7DA3);
    // 0x80399264: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
L_80399268:
    // 0x80399268: andi        $t6, $v1, 0x100
    ctx->r14 = ctx->r3 & 0X100;
L_8039926C:
    // 0x8039926C: bnel        $t6, $zero, L_80399288
    if (ctx->r14 != 0) {
        // 0x80399270: lb          $t8, 0x0($t0)
        ctx->r24 = MEM_B(ctx->r8, 0X0);
            goto L_80399288;
    }
    goto skip_6;
    // 0x80399270: lb          $t8, 0x0($t0)
    ctx->r24 = MEM_B(ctx->r8, 0X0);
    skip_6:
    // 0x80399274: lb          $t7, 0x2($v0)
    ctx->r15 = MEM_B(ctx->r2, 0X2);
    // 0x80399278: slti        $at, $t7, 0x15
    ctx->r1 = SIGNED(ctx->r15) < 0X15 ? 1 : 0;
    // 0x8039927C: bnel        $at, $zero, L_803993B4
    if (ctx->r1 != 0) {
        // 0x80399280: andi        $t7, $v1, 0x1000
        ctx->r15 = ctx->r3 & 0X1000;
            goto L_803993B4;
    }
    goto skip_7;
    // 0x80399280: andi        $t7, $v1, 0x1000
    ctx->r15 = ctx->r3 & 0X1000;
    skip_7:
    // 0x80399284: lb          $t8, 0x0($t0)
    ctx->r24 = MEM_B(ctx->r8, 0X0);
L_80399288:
    // 0x80399288: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8039928C: bnel        $t8, $zero, L_803993B4
    if (ctx->r24 != 0) {
        // 0x80399290: andi        $t7, $v1, 0x1000
        ctx->r15 = ctx->r3 & 0X1000;
            goto L_803993B4;
    }
    goto skip_8;
    // 0x80399290: andi        $t7, $v1, 0x1000
    ctx->r15 = ctx->r3 & 0X1000;
    skip_8:
    // 0x80399294: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80399298: addiu       $v1, $v1, 0x7DA1
    ctx->r3 = ADD32(ctx->r3, 0X7DA1);
    // 0x8039929C: lb          $v0, 0x0($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X0);
    // 0x803992A0: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x803992A4: addiu       $t9, $zero, 0x8
    ctx->r25 = ADD32(0, 0X8);
    // 0x803992A8: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x803992AC: beq         $at, $zero, L_803992BC
    if (ctx->r1 == 0) {
        // 0x803992B0: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_803992BC;
    }
    // 0x803992B0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x803992B4: b           L_803992C4
    // 0x803992B8: sb          $t9, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r25;
        goto L_803992C4;
    // 0x803992B8: sb          $t9, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r25;
L_803992BC:
    // 0x803992BC: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x803992C0: sb          $t5, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r13;
L_803992C4:
    // 0x803992C4: lb          $t6, 0x0($v1)
    ctx->r14 = MEM_B(ctx->r3, 0X0);
    // 0x803992C8: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803992CC: sh          $a3, 0xD2($sp)
    MEM_H(0XD2, ctx->r29) = ctx->r7;
    // 0x803992D0: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x803992D4: jal         0x8039DAAC
    // 0x803992D8: sb          $t6, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r14;
    get_next_available_level(rdram, ctx);
        goto after_27;
    // 0x803992D8: sb          $t6, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r14;
    after_27:
    // 0x803992DC: sb          $v0, 0x2D($s0)
    MEM_B(0X2D, ctx->r16) = ctx->r2;
    // 0x803992E0: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x803992E4: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
    // 0x803992E8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x803992EC: beql        $t8, $a3, L_8039937C
    if (ctx->r24 == ctx->r7) {
        // 0x803992F0: lh          $t9, 0xD2($sp)
        ctx->r25 = MEM_H(ctx->r29, 0XD2);
            goto L_8039937C;
    }
    goto skip_9;
    // 0x803992F0: lh          $t9, 0xD2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD2);
    skip_9:
    // 0x803992F4: bne         $a3, $at, L_80399320
    if (ctx->r7 != ctx->r1) {
        // 0x803992F8: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_80399320;
    }
    // 0x803992F8: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x803992FC: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x80399300: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80399304: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x80399308: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039930C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80399310: jal         0x8013307C
    // 0x80399314: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_28;
    // 0x80399314: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_28:
    // 0x80399318: b           L_80399378
    // 0x8039931C: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
        goto L_80399378;
    // 0x8039931C: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_80399320:
    // 0x80399320: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80399324: jal         0x8039DCC0
    // 0x80399328: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    get_biome_for_level(rdram, ctx);
        goto after_29;
    // 0x80399328: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    after_29:
    // 0x8039932C: lb          $t6, 0x2C($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X2C);
    // 0x80399330: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x80399334: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80399338: beq         $v0, $t6, L_80399364
    if (ctx->r2 == ctx->r14) {
        // 0x8039933C: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_80399364;
    }
    // 0x8039933C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80399340: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x80399344: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80399348: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x8039934C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80399350: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80399354: jal         0x8013307C
    // 0x80399358: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_30;
    // 0x80399358: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_30:
    // 0x8039935C: b           L_80399378
    // 0x80399360: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
        goto L_80399378;
    // 0x80399360: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_80399364:
    // 0x80399364: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80399368: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039936C: jal         0x8013307C
    // 0x80399370: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_31;
    // 0x80399370: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_31:
    // 0x80399374: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
L_80399378:
    // 0x80399378: lh          $t9, 0xD2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD2);
L_8039937C:
    // 0x8039937C: beq         $t9, $a3, L_8039939C
    if (ctx->r25 == ctx->r7) {
        // 0x80399380: nop
    
            goto L_8039939C;
    }
    // 0x80399380: nop

    // 0x80399384: jal         0x80395074
    // 0x80399388: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_32;
    // 0x80399388: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_32:
    // 0x8039938C: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x80399390: lw          $t5, 0x10D0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X10D0);
    // 0x80399394: b           L_803993B0
    // 0x80399398: lhu         $v1, 0x0($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X0);
        goto L_803993B0;
    // 0x80399398: lhu         $v1, 0x0($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X0);
L_8039939C:
    // 0x8039939C: jal         0x80395074
    // 0x803993A0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_80395074_7A6724(rdram, ctx);
        goto after_33;
    // 0x803993A0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_33:
    // 0x803993A4: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x803993A8: lw          $t6, 0x10D0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X10D0);
    // 0x803993AC: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
L_803993B0:
    // 0x803993B0: andi        $t7, $v1, 0x1000
    ctx->r15 = ctx->r3 & 0X1000;
L_803993B4:
    // 0x803993B4: beq         $t7, $zero, L_803993C8
    if (ctx->r15 == 0) {
        // 0x803993B8: lui         $t8, 0x8029
        ctx->r24 = S32(0X8029 << 16);
            goto L_803993C8;
    }
    // 0x803993B8: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x803993BC: lbu         $t8, 0x12DE($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12DE);
    // 0x803993C0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803993C4: beq         $t8, $at, L_803993E0
    if (ctx->r24 == ctx->r1) {
        // 0x803993C8: andi        $t9, $v1, 0x8000
        ctx->r25 = ctx->r3 & 0X8000;
            goto L_803993E0;
    }
L_803993C8:
    // 0x803993C8: andi        $t9, $v1, 0x8000
    ctx->r25 = ctx->r3 & 0X8000;
    // 0x803993CC: beq         $t9, $zero, L_80399434
    if (ctx->r25 == 0) {
        // 0x803993D0: lui         $t5, 0x8029
        ctx->r13 = S32(0X8029 << 16);
            goto L_80399434;
    }
    // 0x803993D0: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x803993D4: lbu         $t5, 0x12DF($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X12DF);
    // 0x803993D8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803993DC: bne         $t5, $at, L_80399434
    if (ctx->r13 != ctx->r1) {
        // 0x803993E0: addiu       $t6, $zero, 0x40
        ctx->r14 = ADD32(0, 0X40);
            goto L_80399434;
    }
L_803993E0:
    // 0x803993E0: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x803993E4: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803993E8: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x803993EC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803993F0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x803993F4: jal         0x8013307C
    // 0x803993F8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_34;
    // 0x803993F8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_34:
    // 0x803993FC: jal         0x80395074
    // 0x80399400: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_35;
    // 0x80399400: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_35:
    // 0x80399404: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80399408: lh          $t7, 0x6698($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6698);
    // 0x8039940C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80399410: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x80399414: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80399418: sh          $t8, 0x6698($at)
    MEM_H(0X6698, ctx->r1) = ctx->r24;
    // 0x8039941C: lb          $t9, 0x2D($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2D);
    // 0x80399420: lw          $t6, 0x10D0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X10D0);
    // 0x80399424: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80399428: addiu       $t5, $t9, 0x1
    ctx->r13 = ADD32(ctx->r25, 0X1);
    // 0x8039942C: sh          $t5, 0x2D38($at)
    MEM_H(0X2D38, ctx->r1) = ctx->r13;
    // 0x80399430: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
L_80399434:
    // 0x80399434: andi        $t7, $v1, 0x4000
    ctx->r15 = ctx->r3 & 0X4000;
    // 0x80399438: beq         $t7, $zero, L_80399488
    if (ctx->r15 == 0) {
        // 0x8039943C: lui         $t8, 0x8029
        ctx->r24 = S32(0X8029 << 16);
            goto L_80399488;
    }
    // 0x8039943C: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80399440: lbu         $t8, 0x12E0($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12E0);
    // 0x80399444: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80399448: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039944C: bne         $t8, $at, L_80399488
    if (ctx->r24 != ctx->r1) {
        // 0x80399450: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_80399488;
    }
    // 0x80399450: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80399454: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x80399458: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039945C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80399460: jal         0x8013307C
    // 0x80399464: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_36;
    // 0x80399464: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_36:
    // 0x80399468: jal         0x80395074
    // 0x8039946C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_37;
    // 0x8039946C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_37:
    // 0x80399470: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80399474: addiu       $v0, $v0, 0x6680
    ctx->r2 = ADD32(ctx->r2, 0X6680);
    // 0x80399478: lh          $t5, 0x18($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X18);
    // 0x8039947C: addiu       $t6, $t5, -0x1
    ctx->r14 = ADD32(ctx->r13, -0X1);
    // 0x80399480: jal         0x8039895C
    // 0x80399484: sh          $t6, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r14;
    func_8039895C_7AA00C(rdram, ctx);
        goto after_38;
    // 0x80399484: sh          $t6, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r14;
    after_38:
L_80399488:
    // 0x80399488: jal         0x8039DCC0
    // 0x8039948C: lb          $a0, 0x2D($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X2D);
    get_biome_for_level(rdram, ctx);
        goto after_39;
    // 0x8039948C: lb          $a0, 0x2D($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X2D);
    after_39:
    // 0x80399490: sb          $v0, 0x2C($s0)
    MEM_B(0X2C, ctx->r16) = ctx->r2;
    // 0x80399494: lb          $t7, 0x2C($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2C);
    // 0x80399498: bne         $t7, $zero, L_80399524
    if (ctx->r15 != 0) {
        // 0x8039949C: lui         $at, 0x4000
        ctx->r1 = S32(0X4000 << 16);
            goto L_80399524;
    }
    // 0x8039949C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x803994A0: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x803994A4: lwc1        $f6, 0xC($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0XC);
    // 0x803994A8: lui         $at, 0xC018
    ctx->r1 = S32(0XC018 << 16);
    // 0x803994AC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x803994B0: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x803994B4: cvt.d.s     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f0.d = CVT_D_S(ctx->f6.fl);
    // 0x803994B8: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x803994BC: sub.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = ctx->f8.d - ctx->f0.d;
    // 0x803994C0: lwc1        $f8, 0x10($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X10);
    // 0x803994C4: lui         $at, 0xC028
    ctx->r1 = S32(0XC028 << 16);
    // 0x803994C8: div.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x803994CC: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x803994D0: mtc1        $at, $f11
    ctx->f_odd[(11 - 1) * 2] = ctx->r1;
    // 0x803994D4: lui         $at, 0xC0C0
    ctx->r1 = S32(0XC0C0 << 16);
    // 0x803994D8: cvt.d.s     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f2.d = CVT_D_S(ctx->f8.fl);
    // 0x803994DC: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803994E0: add.d       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f0.d + ctx->f18.d;
    // 0x803994E4: sub.d       $f18, $f10, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f2.d); 
    ctx->f18.d = ctx->f10.d - ctx->f2.d;
    // 0x803994E8: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x803994EC: div.d       $f4, $f18, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f16.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f16.d);
    // 0x803994F0: swc1        $f6, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f6.u32l;
    // 0x803994F4: lwc1        $f12, 0xC($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0XC);
    // 0x803994F8: add.d       $f6, $f2, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f2.d + ctx->f4.d;
    // 0x803994FC: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x80399500: jal         0x8039CDE8
    // 0x80399504: swc1        $f8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f8.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_40;
    // 0x80399504: swc1        $f8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f8.u32l;
    after_40:
    // 0x80399508: lui         $at, 0xC140
    ctx->r1 = S32(0XC140 << 16);
    // 0x8039950C: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80399510: swc1        $f0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f0.u32l;
    // 0x80399514: jal         0x8039CDE8
    // 0x80399518: lwc1        $f12, 0x10($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X10);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_41;
    // 0x80399518: lwc1        $f12, 0x10($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X10);
    after_41:
    // 0x8039951C: b           L_80399580
    // 0x80399520: swc1        $f0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f0.u32l;
        goto L_80399580;
    // 0x80399520: swc1        $f0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f0.u32l;
L_80399524:
    // 0x80399524: lwc1        $f0, 0xC($s0)
    ctx->f0.u32l = MEM_W(ctx->r16, 0XC);
    // 0x80399528: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x8039952C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399530: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80399534: sub.s       $f18, $f10, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = ctx->f10.fl - ctx->f0.fl;
    // 0x80399538: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x8039953C: lwc1        $f2, 0x10($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X10);
    // 0x80399540: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80399544: div.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80399548: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039954C: sub.s       $f18, $f10, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = ctx->f10.fl - ctx->f2.fl;
    // 0x80399550: add.s       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f0.fl + ctx->f6.fl;
    // 0x80399554: div.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80399558: swc1        $f8, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f8.u32l;
    // 0x8039955C: lwc1        $f12, 0xC($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0XC);
    // 0x80399560: add.s       $f8, $f2, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f2.fl + ctx->f6.fl;
    // 0x80399564: jal         0x8039CDE8
    // 0x80399568: swc1        $f8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f8.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_42;
    // 0x80399568: swc1        $f8, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f8.u32l;
    after_42:
    // 0x8039956C: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80399570: swc1        $f0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->f0.u32l;
    // 0x80399574: jal         0x8039CDE8
    // 0x80399578: lwc1        $f12, 0x10($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X10);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_43;
    // 0x80399578: lwc1        $f12, 0x10($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X10);
    after_43:
    // 0x8039957C: swc1        $f0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->f0.u32l;
L_80399580:
    // 0x80399580: lb          $t8, 0x2C($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X2C);
    // 0x80399584: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80399588: bne         $t8, $at, L_80399614
    if (ctx->r24 != ctx->r1) {
        // 0x8039958C: lui         $at, 0x4000
        ctx->r1 = S32(0X4000 << 16);
            goto L_80399614;
    }
    // 0x8039958C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399590: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x80399594: lwc1        $f10, 0x24($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X24);
    // 0x80399598: lui         $at, 0x4028
    ctx->r1 = S32(0X4028 << 16);
    // 0x8039959C: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x803995A0: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x803995A4: cvt.d.s     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f0.d = CVT_D_S(ctx->f10.fl);
    // 0x803995A8: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x803995AC: sub.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = ctx->f18.d - ctx->f0.d;
    // 0x803995B0: lwc1        $f18, 0x28($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X28);
    // 0x803995B4: lui         $at, 0xC010
    ctx->r1 = S32(0XC010 << 16);
    // 0x803995B8: div.d       $f6, $f4, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f16.d); 
    ctx->f6.d = DIV_D(ctx->f4.d, ctx->f16.d);
    // 0x803995BC: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x803995C0: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x803995C4: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x803995C8: cvt.d.s     $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f2.d = CVT_D_S(ctx->f18.fl);
    // 0x803995CC: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803995D0: add.d       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f0.d + ctx->f6.d;
    // 0x803995D4: sub.d       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = ctx->f4.d - ctx->f2.d;
    // 0x803995D8: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x803995DC: div.d       $f8, $f6, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f16.d); 
    ctx->f8.d = DIV_D(ctx->f6.d, ctx->f16.d);
    // 0x803995E0: swc1        $f10, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->f10.u32l;
    // 0x803995E4: lwc1        $f12, 0x24($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X24);
    // 0x803995E8: add.d       $f10, $f2, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = ctx->f2.d + ctx->f8.d;
    // 0x803995EC: cvt.s.d     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f18.fl = CVT_S_D(ctx->f10.d);
    // 0x803995F0: jal         0x8039CDE8
    // 0x803995F4: swc1        $f18, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f18.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_44;
    // 0x803995F4: swc1        $f18, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f18.u32l;
    after_44:
    // 0x803995F8: lui         $at, 0xC080
    ctx->r1 = S32(0XC080 << 16);
    // 0x803995FC: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x80399600: swc1        $f0, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->f0.u32l;
    // 0x80399604: jal         0x8039CDE8
    // 0x80399608: lwc1        $f12, 0x28($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X28);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_45;
    // 0x80399608: lwc1        $f12, 0x28($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X28);
    after_45:
    // 0x8039960C: b           L_80399664
    // 0x80399610: swc1        $f0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f0.u32l;
        goto L_80399664;
    // 0x80399610: swc1        $f0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f0.u32l;
L_80399614:
    // 0x80399614: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80399618: lwc1        $f0, 0x24($s0)
    ctx->f0.u32l = MEM_W(ctx->r16, 0X24);
    // 0x8039961C: lwc1        $f2, 0x28($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80399620: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399624: sub.s       $f4, $f14, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = ctx->f14.fl - ctx->f0.fl;
    // 0x80399628: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039962C: sub.s       $f10, $f14, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = ctx->f14.fl - ctx->f2.fl;
    // 0x80399630: div.s       $f6, $f4, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = DIV_S(ctx->f4.fl, ctx->f16.fl);
    // 0x80399634: div.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80399638: add.s       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f0.fl + ctx->f6.fl;
    // 0x8039963C: swc1        $f8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->f8.u32l;
    // 0x80399640: lwc1        $f12, 0x24($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X24);
    // 0x80399644: add.s       $f4, $f2, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f2.fl + ctx->f18.fl;
    // 0x80399648: jal         0x8039CDE8
    // 0x8039964C: swc1        $f4, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f4.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_46;
    // 0x8039964C: swc1        $f4, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f4.u32l;
    after_46:
    // 0x80399650: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80399654: swc1        $f0, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->f0.u32l;
    // 0x80399658: jal         0x8039CDE8
    // 0x8039965C: lwc1        $f12, 0x28($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X28);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_47;
    // 0x8039965C: lwc1        $f12, 0x28($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X28);
    after_47:
    // 0x80399660: swc1        $f0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f0.u32l;
L_80399664:
    // 0x80399664: lb          $t9, 0x2C($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2C);
    // 0x80399668: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039966C: bne         $t9, $at, L_803996F8
    if (ctx->r25 != ctx->r1) {
        // 0x80399670: lui         $at, 0x4000
        ctx->r1 = S32(0X4000 << 16);
            goto L_803996F8;
    }
    // 0x80399670: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399674: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x80399678: lwc1        $f6, 0x1C($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x8039967C: lui         $at, 0x4008
    ctx->r1 = S32(0X4008 << 16);
    // 0x80399680: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80399684: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80399688: cvt.d.s     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f0.d = CVT_D_S(ctx->f6.fl);
    // 0x8039968C: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x80399690: sub.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = ctx->f8.d - ctx->f0.d;
    // 0x80399694: lwc1        $f8, 0x20($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X20);
    // 0x80399698: lui         $at, 0x4028
    ctx->r1 = S32(0X4028 << 16);
    // 0x8039969C: div.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x803996A0: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x803996A4: mtc1        $at, $f11
    ctx->f_odd[(11 - 1) * 2] = ctx->r1;
    // 0x803996A8: lui         $at, 0x4040
    ctx->r1 = S32(0X4040 << 16);
    // 0x803996AC: cvt.d.s     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f2.d = CVT_D_S(ctx->f8.fl);
    // 0x803996B0: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803996B4: add.d       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f0.d + ctx->f18.d;
    // 0x803996B8: sub.d       $f18, $f10, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f2.d); 
    ctx->f18.d = ctx->f10.d - ctx->f2.d;
    // 0x803996BC: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x803996C0: div.d       $f4, $f18, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f16.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f16.d);
    // 0x803996C4: swc1        $f6, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->f6.u32l;
    // 0x803996C8: lwc1        $f12, 0x1C($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x803996CC: add.d       $f6, $f2, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f2.d + ctx->f4.d;
    // 0x803996D0: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x803996D4: jal         0x8039CDE8
    // 0x803996D8: swc1        $f8, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f8.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_48;
    // 0x803996D8: swc1        $f8, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f8.u32l;
    after_48:
    // 0x803996DC: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x803996E0: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803996E4: swc1        $f0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->f0.u32l;
    // 0x803996E8: jal         0x8039CDE8
    // 0x803996EC: lwc1        $f12, 0x20($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X20);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_49;
    // 0x803996EC: lwc1        $f12, 0x20($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X20);
    after_49:
    // 0x803996F0: b           L_80399748
    // 0x803996F4: swc1        $f0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f0.u32l;
        goto L_80399748;
    // 0x803996F4: swc1        $f0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f0.u32l;
L_803996F8:
    // 0x803996F8: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x803996FC: lwc1        $f0, 0x1C($s0)
    ctx->f0.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x80399700: lwc1        $f2, 0x20($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X20);
    // 0x80399704: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399708: sub.s       $f10, $f14, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = ctx->f14.fl - ctx->f0.fl;
    // 0x8039970C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80399710: sub.s       $f6, $f14, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = ctx->f14.fl - ctx->f2.fl;
    // 0x80399714: div.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80399718: div.s       $f8, $f6, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = DIV_S(ctx->f6.fl, ctx->f16.fl);
    // 0x8039971C: add.s       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f0.fl + ctx->f18.fl;
    // 0x80399720: swc1        $f4, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->f4.u32l;
    // 0x80399724: lwc1        $f12, 0x1C($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x80399728: add.s       $f10, $f2, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f2.fl + ctx->f8.fl;
    // 0x8039972C: jal         0x8039CDE8
    // 0x80399730: swc1        $f10, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f10.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_50;
    // 0x80399730: swc1        $f10, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f10.u32l;
    after_50:
    // 0x80399734: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80399738: swc1        $f0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->f0.u32l;
    // 0x8039973C: jal         0x8039CDE8
    // 0x80399740: lwc1        $f12, 0x20($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X20);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_51;
    // 0x80399740: lwc1        $f12, 0x20($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X20);
    after_51:
    // 0x80399744: swc1        $f0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->f0.u32l;
L_80399748:
    // 0x80399748: lb          $t5, 0x2C($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X2C);
    // 0x8039974C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80399750: bnel        $t5, $at, L_803997F0
    if (ctx->r13 != ctx->r1) {
        // 0x80399754: mtc1        $zero, $f14
        ctx->f14.u32l = 0;
            goto L_803997F0;
    }
    goto skip_10;
    // 0x80399754: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    skip_10:
    // 0x80399758: lwc1        $f18, 0x14($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X14);
    // 0x8039975C: lui         $at, 0xC028
    ctx->r1 = S32(0XC028 << 16);
    // 0x80399760: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x80399764: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80399768: cvt.d.s     $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f0.d = CVT_D_S(ctx->f18.fl);
    // 0x8039976C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399770: sub.d       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f0.d); 
    ctx->f6.d = ctx->f4.d - ctx->f0.d;
    // 0x80399774: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80399778: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8039977C: lui         $at, 0x4018
    ctx->r1 = S32(0X4018 << 16);
    // 0x80399780: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x80399784: lwc1        $f6, 0x18($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X18);
    // 0x80399788: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8039978C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80399790: cvt.d.s     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f2.d = CVT_D_S(ctx->f6.fl);
    // 0x80399794: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80399798: add.d       $f18, $f0, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = ctx->f0.d + ctx->f10.d;
    // 0x8039979C: sub.d       $f10, $f8, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f2.d); 
    ctx->f10.d = ctx->f8.d - ctx->f2.d;
    // 0x803997A0: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x803997A4: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x803997A8: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x803997AC: lui         $at, 0xC140
    ctx->r1 = S32(0XC140 << 16);
    // 0x803997B0: swc1        $f4, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f4.u32l;
    // 0x803997B4: div.d       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = DIV_D(ctx->f10.d, ctx->f18.d);
    // 0x803997B8: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803997BC: lwc1        $f12, 0x14($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X14);
    // 0x803997C0: add.d       $f6, $f2, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f2.d + ctx->f4.d;
    // 0x803997C4: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x803997C8: jal         0x8039CDE8
    // 0x803997CC: swc1        $f8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f8.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_52;
    // 0x803997CC: swc1        $f8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f8.u32l;
    after_52:
    // 0x803997D0: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x803997D4: mtc1        $at, $f14
    ctx->f14.u32l = ctx->r1;
    // 0x803997D8: swc1        $f0, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f0.u32l;
    // 0x803997DC: jal         0x8039CDE8
    // 0x803997E0: lwc1        $f12, 0x18($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X18);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_53;
    // 0x803997E0: lwc1        $f12, 0x18($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X18);
    after_53:
    // 0x803997E4: b           L_8039983C
    // 0x803997E8: swc1        $f0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f0.u32l;
        goto L_8039983C;
    // 0x803997E8: swc1        $f0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f0.u32l;
    // 0x803997EC: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
L_803997F0:
    // 0x803997F0: lwc1        $f0, 0x14($s0)
    ctx->f0.u32l = MEM_W(ctx->r16, 0X14);
    // 0x803997F4: lwc1        $f2, 0x18($s0)
    ctx->f2.u32l = MEM_W(ctx->r16, 0X18);
    // 0x803997F8: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x803997FC: sub.s       $f10, $f14, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = ctx->f14.fl - ctx->f0.fl;
    // 0x80399800: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80399804: sub.s       $f6, $f14, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = ctx->f14.fl - ctx->f2.fl;
    // 0x80399808: div.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f16.fl);
    // 0x8039980C: div.s       $f8, $f6, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = DIV_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80399810: add.s       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f0.fl + ctx->f18.fl;
    // 0x80399814: swc1        $f4, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f4.u32l;
    // 0x80399818: lwc1        $f12, 0x14($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X14);
    // 0x8039981C: add.s       $f10, $f2, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f2.fl + ctx->f8.fl;
    // 0x80399820: jal         0x8039CDE8
    // 0x80399824: swc1        $f10, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f10.u32l;
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_54;
    // 0x80399824: swc1        $f10, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f10.u32l;
    after_54:
    // 0x80399828: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x8039982C: swc1        $f0, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->f0.u32l;
    // 0x80399830: jal         0x8039CDE8
    // 0x80399834: lwc1        $f12, 0x18($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X18);
    func_8039CDE8_7AE498(rdram, ctx);
        goto after_55;
    // 0x80399834: lwc1        $f12, 0x18($s0)
    ctx->f12.u32l = MEM_W(ctx->r16, 0X18);
    after_55:
    // 0x80399838: swc1        $f0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->f0.u32l;
L_8039983C:
    // 0x8039983C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80399840: lui         $t7, 0xED02
    ctx->r15 = S32(0XED02 << 16);
    // 0x80399844: ori         $t7, $t7, 0x20
    ctx->r15 = ctx->r15 | 0X20;
    // 0x80399848: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039984C: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80399850: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x80399854: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80399858: lh          $t8, 0x3FD0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD0);
    // 0x8039985C: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80399860: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80399864: addiu       $t9, $t8, -0x8
    ctx->r25 = ADD32(ctx->r24, -0X8);
    // 0x80399868: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8039986C: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80399870: lh          $t9, 0x3FD2($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FD2);
    // 0x80399874: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80399878: addiu       $a0, $zero, 0xB4
    ctx->r4 = ADD32(0, 0XB4);
    // 0x8039987C: addiu       $t5, $t9, -0x8
    ctx->r13 = ADD32(ctx->r25, -0X8);
    // 0x80399880: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x80399884: addiu       $a1, $zero, 0xB4
    ctx->r5 = ADD32(0, 0XB4);
    // 0x80399888: addiu       $a2, $zero, 0xB4
    ctx->r6 = ADD32(0, 0XB4);
    // 0x8039988C: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80399890: mul.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80399894: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x80399898: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039989C: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x803998A0: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x803998A4: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
    // 0x803998A8: nop

    // 0x803998AC: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x803998B0: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x803998B4: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x803998B8: addiu       $t6, $zero, 0x1E
    ctx->r14 = ADD32(0, 0X1E);
    // 0x803998BC: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x803998C0: or          $t5, $t8, $t9
    ctx->r13 = ctx->r24 | ctx->r25;
    // 0x803998C4: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x803998C8: lwc1        $f18, 0xDC($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x803998CC: lwc1        $f8, 0xE0($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XE0);
    // 0x803998D0: lui         $t8, 0x8024
    ctx->r24 = S32(0X8024 << 16);
    // 0x803998D4: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x803998D8: addiu       $t8, $t8, -0xDA0
    ctx->r24 = ADD32(ctx->r24, -0XDA0);
    // 0x803998DC: addiu       $t7, $zero, 0x1E
    ctx->r15 = ADD32(0, 0X1E);
    // 0x803998E0: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x803998E4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x803998E8: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x803998EC: lb          $t8, 0x2D($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X2D);
    // 0x803998F0: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    // 0x803998F4: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x803998F8: lwc1        $f6, 0x8($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X8);
    // 0x803998FC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80399900: sw          $t8, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r24;
    // 0x80399904: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80399908: swc1        $f6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f6.u32l;
    // 0x8039990C: jal         0x8039BE98
    // 0x80399910: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    draw_level_rings_segment(rdram, ctx);
        goto after_56;
    // 0x80399910: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    after_56:
    // 0x80399914: lwc1        $f8, 0x0($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80399918: lwc1        $f10, 0xC($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0XC);
    // 0x8039991C: lwc1        $f6, 0x4($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X4);
    // 0x80399920: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x80399924: add.s       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x80399928: lwc1        $f8, 0x10($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X10);
    // 0x8039992C: addiu       $t5, $t5, -0xDA0
    ctx->r13 = ADD32(ctx->r13, -0XDA0);
    // 0x80399930: addiu       $t9, $zero, 0x9
    ctx->r25 = ADD32(0, 0X9);
    // 0x80399934: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x80399938: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8039993C: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80399940: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80399944: lb          $t5, 0x2D($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X2D);
    // 0x80399948: addiu       $a0, $zero, 0xB4
    ctx->r4 = ADD32(0, 0XB4);
    // 0x8039994C: trunc.w.s   $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80399950: mfc1        $t7, $f4
    ctx->r15 = (int32_t)ctx->f4.u32l;
    // 0x80399954: lwc1        $f4, 0x8($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80399958: addiu       $a1, $zero, 0x28
    ctx->r5 = ADD32(0, 0X28);
    // 0x8039995C: mfc1        $t9, $f18
    ctx->r25 = (int32_t)ctx->f18.u32l;
    // 0x80399960: addiu       $a2, $zero, 0x78
    ctx->r6 = ADD32(0, 0X78);
    // 0x80399964: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x80399968: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8039996C: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    // 0x80399970: swc1        $f4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f4.u32l;
    // 0x80399974: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80399978: jal         0x8039BE98
    // 0x8039997C: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    draw_level_rings_segment(rdram, ctx);
        goto after_57;
    // 0x8039997C: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    after_57:
    // 0x80399980: lwc1        $f6, 0x0($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80399984: lwc1        $f8, 0x24($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X24);
    // 0x80399988: lwc1        $f4, 0x4($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X4);
    // 0x8039998C: lui         $t8, 0x8024
    ctx->r24 = S32(0X8024 << 16);
    // 0x80399990: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x80399994: lwc1        $f6, 0x28($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80399998: addiu       $t8, $t8, -0xDA0
    ctx->r24 = ADD32(ctx->r24, -0XDA0);
    // 0x8039999C: addiu       $t7, $zero, 0x10
    ctx->r15 = ADD32(0, 0X10);
    // 0x803999A0: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x803999A4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x803999A8: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x803999AC: trunc.w.s   $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x803999B0: lb          $t8, 0x2D($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X2D);
    // 0x803999B4: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x803999B8: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x803999BC: mfc1        $t5, $f18
    ctx->r13 = (int32_t)ctx->f18.u32l;
    // 0x803999C0: lwc1        $f18, 0x8($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X8);
    // 0x803999C4: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803999C8: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x803999CC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803999D0: addiu       $a1, $zero, 0xB4
    ctx->r5 = ADD32(0, 0XB4);
    // 0x803999D4: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x803999D8: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x803999DC: sw          $t8, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r24;
    // 0x803999E0: swc1        $f18, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f18.u32l;
    // 0x803999E4: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x803999E8: jal         0x8039BE98
    // 0x803999EC: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    draw_level_rings_segment(rdram, ctx);
        goto after_58;
    // 0x803999EC: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    after_58:
    // 0x803999F0: lwc1        $f4, 0x0($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X0);
    // 0x803999F4: lwc1        $f6, 0x1C($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X1C);
    // 0x803999F8: lwc1        $f18, 0x4($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X4);
    // 0x803999FC: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x80399A00: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x80399A04: lwc1        $f4, 0x20($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X20);
    // 0x80399A08: addiu       $t6, $t6, -0xDA0
    ctx->r14 = ADD32(ctx->r14, -0XDA0);
    // 0x80399A0C: addiu       $t5, $zero, 0x16
    ctx->r13 = ADD32(0, 0X16);
    // 0x80399A10: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x80399A14: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x80399A18: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80399A1C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80399A20: lb          $t6, 0x2D($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X2D);
    // 0x80399A24: addiu       $t9, $zero, 0x11
    ctx->r25 = ADD32(0, 0X11);
    // 0x80399A28: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80399A2C: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x80399A30: lwc1        $f10, 0x8($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80399A34: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80399A38: mfc1        $t5, $f8
    ctx->r13 = (int32_t)ctx->f8.u32l;
    // 0x80399A3C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80399A40: addiu       $a1, $zero, 0xA0
    ctx->r5 = ADD32(0, 0XA0);
    // 0x80399A44: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80399A48: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x80399A4C: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x80399A50: swc1        $f10, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f10.u32l;
    // 0x80399A54: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80399A58: jal         0x8039BE98
    // 0x80399A5C: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    draw_level_rings_segment(rdram, ctx);
        goto after_59;
    // 0x80399A5C: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    after_59:
    // 0x80399A60: lwc1        $f18, 0x0($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80399A64: lwc1        $f4, 0x14($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X14);
    // 0x80399A68: lwc1        $f10, 0x4($s0)
    ctx->f10.u32l = MEM_W(ctx->r16, 0X4);
    // 0x80399A6C: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x80399A70: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x80399A74: lwc1        $f18, 0x18($s0)
    ctx->f18.u32l = MEM_W(ctx->r16, 0X18);
    // 0x80399A78: addiu       $t9, $t9, -0xDA0
    ctx->r25 = ADD32(ctx->r25, -0XDA0);
    // 0x80399A7C: addiu       $t8, $zero, 0x1D
    ctx->r24 = ADD32(0, 0X1D);
    // 0x80399A80: add.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f18.fl;
    // 0x80399A84: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80399A88: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80399A8C: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80399A90: lb          $t9, 0x2D($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2D);
    // 0x80399A94: addiu       $t7, $zero, 0x17
    ctx->r15 = ADD32(0, 0X17);
    // 0x80399A98: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80399A9C: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
    // 0x80399AA0: lwc1        $f8, 0x8($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X8);
    // 0x80399AA4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80399AA8: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x80399AAC: addiu       $a0, $zero, 0xC8
    ctx->r4 = ADD32(0, 0XC8);
    // 0x80399AB0: addiu       $a1, $zero, 0xC8
    ctx->r5 = ADD32(0, 0XC8);
    // 0x80399AB4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80399AB8: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x80399ABC: sw          $t9, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r25;
    // 0x80399AC0: swc1        $f8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f8.u32l;
    // 0x80399AC4: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80399AC8: jal         0x8039BE98
    // 0x80399ACC: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    draw_level_rings_segment(rdram, ctx);
        goto after_60;
    // 0x80399ACC: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    after_60:
    // 0x80399AD0: jal         0x8012C1F0
    // 0x80399AD4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    load_default_display_list(rdram, ctx);
        goto after_61;
    // 0x80399AD4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_61:
    // 0x80399AD8: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x80399ADC: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x80399AE0: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x80399AE4: jal         0x8012C214
    // 0x80399AE8: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_62;
    // 0x80399AE8: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_62:
    // 0x80399AEC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80399AF0: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80399AF4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80399AF8: jal         0x8012C248
    // 0x80399AFC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_63;
    // 0x80399AFC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_63:
    // 0x80399B00: lb          $a3, 0x2D($s0)
    ctx->r7 = MEM_B(ctx->r16, 0X2D);
    // 0x80399B04: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80399B08: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399B0C: beq         $a3, $at, L_80399B44
    if (ctx->r7 == ctx->r1) {
        // 0x80399B10: lui         $a1, 0x803F
        ctx->r5 = S32(0X803F << 16);
            goto L_80399B44;
    }
    // 0x80399B10: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80399B14: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399B18: lwc1        $f10, 0x74BC($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x80399B1C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399B20: lwc1        $f18, 0x74C0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399B24: addiu       $a1, $a1, 0x2E34
    ctx->r5 = ADD32(ctx->r5, 0X2E34);
    // 0x80399B28: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399B2C: addiu       $a3, $zero, 0x3C
    ctx->r7 = ADD32(0, 0X3C);
    // 0x80399B30: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80399B34: jal         0x8012DEF8
    // 0x80399B38: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_64;
    // 0x80399B38: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_64:
    // 0x80399B3C: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80399B40: lb          $a3, 0x7DD5($a3)
    ctx->r7 = MEM_B(ctx->r7, 0X7DD5);
L_80399B44:
    // 0x80399B44: addiu       $t5, $zero, 0x3C
    ctx->r13 = ADD32(0, 0X3C);
    // 0x80399B48: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x80399B4C: lui         $s0, 0x803B
    ctx->r16 = S32(0X803B << 16);
    // 0x80399B50: addiu       $s0, $s0, 0x74B0
    ctx->r16 = ADD32(ctx->r16, 0X74B0);
    // 0x80399B54: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80399B58: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80399B5C: lwc1        $f4, 0x0($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80399B60: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80399B64: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80399B68: lui         $t8, 0x8024
    ctx->r24 = S32(0X8024 << 16);
    // 0x80399B6C: addu        $t8, $t8, $a3
    ctx->r24 = ADD32(ctx->r24, ctx->r7);
    // 0x80399B70: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x80399B74: add.s       $f4, $f18, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f18.fl + ctx->f8.fl;
    // 0x80399B78: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80399B7C: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x80399B80: beq         $a3, $at, L_80399C48
    if (ctx->r7 == ctx->r1) {
        // 0x80399B84: sh          $t7, 0xDA($sp)
        MEM_H(0XDA, ctx->r29) = ctx->r15;
            goto L_80399C48;
    }
    // 0x80399B84: sh          $t7, 0xDA($sp)
    MEM_H(0XDA, ctx->r29) = ctx->r15;
    // 0x80399B88: lbu         $t8, -0xD9C($t8)
    ctx->r24 = MEM_BU(ctx->r24, -0XD9C);
    // 0x80399B8C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80399B90: sll         $t9, $t8, 30
    ctx->r25 = S32(ctx->r24 << 30);
    // 0x80399B94: srl         $t5, $t9, 31
    ctx->r13 = S32(U32(ctx->r25) >> 31);
    // 0x80399B98: bne         $t5, $at, L_80399BDC
    if (ctx->r13 != ctx->r1) {
        // 0x80399B9C: nop
    
            goto L_80399BDC;
    }
    // 0x80399B9C: nop

    // 0x80399BA0: jal         0x80130A90
    // 0x80399BA4: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    get_message_address_by_id(rdram, ctx);
        goto after_65;
    // 0x80399BA4: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_65:
    // 0x80399BA8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399BAC: lwc1        $f10, 0x74BC($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x80399BB0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399BB4: lwc1        $f18, 0x74C0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399BB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399BBC: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399BC0: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399BC4: lhu         $a3, 0xDA($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0XDA);
    // 0x80399BC8: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80399BCC: jal         0x8012DEF8
    // 0x80399BD0: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_66;
    // 0x80399BD0: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_66:
    // 0x80399BD4: b           L_80399C14
    // 0x80399BD8: lh          $t6, 0xDA($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XDA);
        goto L_80399C14;
    // 0x80399BD8: lh          $t6, 0xDA($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XDA);
L_80399BDC:
    // 0x80399BDC: jal         0x80130A90
    // 0x80399BE0: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    get_message_address_by_id(rdram, ctx);
        goto after_67;
    // 0x80399BE0: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    after_67:
    // 0x80399BE4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399BE8: lwc1        $f8, 0x74BC($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x80399BEC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399BF0: lwc1        $f4, 0x74C0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399BF4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399BF8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399BFC: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399C00: lhu         $a3, 0xDA($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0XDA);
    // 0x80399C04: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x80399C08: jal         0x8012DEF8
    // 0x80399C0C: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text(rdram, ctx);
        goto after_68;
    // 0x80399C0C: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_68:
    // 0x80399C10: lh          $t6, 0xDA($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XDA);
L_80399C14:
    // 0x80399C14: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80399C18: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80399C1C: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80399C20: lwc1        $f6, 0x0($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X0);
    // 0x80399C24: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80399C28: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80399C2C: lb          $a3, 0x7DD5($a3)
    ctx->r7 = MEM_B(ctx->r7, 0X7DD5);
    // 0x80399C30: add.s       $f18, $f6, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x80399C34: add.s       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f18.fl;
    // 0x80399C38: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x80399C3C: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x80399C40: nop

    // 0x80399C44: sh          $t8, 0xDA($sp)
    MEM_H(0XDA, ctx->r29) = ctx->r24;
L_80399C48:
    // 0x80399C48: addiu       $t9, $a3, 0x1
    ctx->r25 = ADD32(ctx->r7, 0X1);
    // 0x80399C4C: sh          $t9, 0xD2($sp)
    MEM_H(0XD2, ctx->r29) = ctx->r25;
    // 0x80399C50: lh          $t5, 0xD2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XD2);
    // 0x80399C54: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x80399C58: lh          $t6, 0xD2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XD2);
    // 0x80399C5C: beq         $t5, $at, L_80399C8C
    if (ctx->r13 == ctx->r1) {
        // 0x80399C60: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80399C8C;
    }
    // 0x80399C60: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80399C64: beq         $t5, $at, L_80399C8C
    if (ctx->r13 == ctx->r1) {
        // 0x80399C68: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_80399C8C;
    }
    // 0x80399C68: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x80399C6C: beq         $t5, $at, L_80399C8C
    if (ctx->r13 == ctx->r1) {
        // 0x80399C70: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_80399C8C;
    }
    // 0x80399C70: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80399C74: beq         $t5, $at, L_80399C8C
    if (ctx->r13 == ctx->r1) {
        // 0x80399C78: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_80399C8C;
    }
    // 0x80399C78: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x80399C7C: beq         $t5, $at, L_80399C8C
    if (ctx->r13 == ctx->r1) {
        // 0x80399C80: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_80399C8C;
    }
    // 0x80399C80: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x80399C84: bne         $t5, $at, L_8039A1A8
    if (ctx->r13 != ctx->r1) {
        // 0x80399C88: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_8039A1A8;
    }
    // 0x80399C88: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_80399C8C:
    // 0x80399C8C: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x80399C90: bne         $t6, $at, L_80399D6C
    if (ctx->r14 != ctx->r1) {
        // 0x80399C94: lui         $a3, 0x8024
        ctx->r7 = S32(0X8024 << 16);
            goto L_80399D6C;
    }
    // 0x80399C94: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x80399C98: lw          $a3, -0xD70($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD70);
    // 0x80399C9C: addiu       $a1, $sp, 0xCC
    ctx->r5 = ADD32(ctx->r29, 0XCC);
    // 0x80399CA0: addiu       $a2, $sp, 0xCE
    ctx->r6 = ADD32(ctx->r29, 0XCE);
    // 0x80399CA4: srl         $t7, $a3, 13
    ctx->r15 = S32(U32(ctx->r7) >> 13);
    // 0x80399CA8: andi        $t8, $t7, 0x1FF
    ctx->r24 = ctx->r15 & 0X1FF;
    // 0x80399CAC: beq         $t8, $zero, L_80399D6C
    if (ctx->r24 == 0) {
        // 0x80399CB0: sll         $a0, $t8, 16
        ctx->r4 = S32(ctx->r24 << 16);
            goto L_80399D6C;
    }
    // 0x80399CB0: sll         $a0, $t8, 16
    ctx->r4 = S32(ctx->r24 << 16);
    // 0x80399CB4: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80399CB8: jal         0x8039DB60
    // 0x80399CBC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    seconds_to_mins_secs(rdram, ctx);
        goto after_69;
    // 0x80399CBC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    after_69:
    // 0x80399CC0: lh          $a3, 0xCE($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XCE);
    // 0x80399CC4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399CC8: addiu       $a1, $a1, 0x3A8
    ctx->r5 = ADD32(ctx->r5, 0X3A8);
    // 0x80399CCC: slti        $at, $a3, 0xA
    ctx->r1 = SIGNED(ctx->r7) < 0XA ? 1 : 0;
    // 0x80399CD0: beq         $at, $zero, L_80399CF4
    if (ctx->r1 == 0) {
        // 0x80399CD4: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_80399CF4;
    }
    // 0x80399CD4: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399CD8: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399CDC: addiu       $a1, $a1, 0x3A0
    ctx->r5 = ADD32(ctx->r5, 0X3A0);
    // 0x80399CE0: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399CE4: jal         0x801395F4
    // 0x80399CE8: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_70;
    // 0x80399CE8: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_70:
    // 0x80399CEC: b           L_80399D00
    // 0x80399CF0: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
        goto L_80399D00;
    // 0x80399CF0: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_80399CF4:
    // 0x80399CF4: jal         0x801395F4
    // 0x80399CF8: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_71;
    // 0x80399CF8: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_71:
    // 0x80399CFC: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_80399D00:
    // 0x80399D00: jal         0x801308B4
    // 0x80399D04: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_72;
    // 0x80399D04: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_72:
    // 0x80399D08: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399D0C: lwc1        $f8, 0x74C4($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399D10: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399D14: lwc1        $f4, 0x74C0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399D18: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    // 0x80399D1C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399D20: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x80399D24: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399D28: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x80399D2C: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x80399D30: jal         0x8012DEF8
    // 0x80399D34: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    display_text(rdram, ctx);
        goto after_73;
    // 0x80399D34: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    after_73:
    // 0x80399D38: jal         0x80130A90
    // 0x80399D3C: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    get_message_address_by_id(rdram, ctx);
        goto after_74;
    // 0x80399D3C: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_74:
    // 0x80399D40: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399D44: lwc1        $f18, 0x74C4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399D48: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399D4C: lwc1        $f6, 0x74C0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399D50: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399D54: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399D58: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x80399D5C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399D60: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80399D64: jal         0x8012DEF8
    // 0x80399D68: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text(rdram, ctx);
        goto after_75;
    // 0x80399D68: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_75:
L_80399D6C:
    // 0x80399D6C: lh          $t5, 0xD2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XD2);
    // 0x80399D70: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80399D74: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x80399D78: bnel        $t5, $at, L_80399EAC
    if (ctx->r13 != ctx->r1) {
        // 0x80399D7C: lh          $t8, 0xD2($sp)
        ctx->r24 = MEM_H(ctx->r29, 0XD2);
            goto L_80399EAC;
    }
    goto skip_11;
    // 0x80399D7C: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
    skip_11:
    // 0x80399D80: lw          $a3, -0xD70($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD70);
    // 0x80399D84: addiu       $a1, $sp, 0xCC
    ctx->r5 = ADD32(ctx->r29, 0XCC);
    // 0x80399D88: addiu       $a2, $sp, 0xCE
    ctx->r6 = ADD32(ctx->r29, 0XCE);
    // 0x80399D8C: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x80399D90: beq         $t6, $zero, L_80399EA8
    if (ctx->r14 == 0) {
        // 0x80399D94: sll         $a0, $t6, 16
        ctx->r4 = S32(ctx->r14 << 16);
            goto L_80399EA8;
    }
    // 0x80399D94: sll         $a0, $t6, 16
    ctx->r4 = S32(ctx->r14 << 16);
    // 0x80399D98: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80399D9C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80399DA0: jal         0x8039DB60
    // 0x80399DA4: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    seconds_to_mins_secs(rdram, ctx);
        goto after_76;
    // 0x80399DA4: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    after_76:
    // 0x80399DA8: lh          $a3, 0xCE($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XCE);
    // 0x80399DAC: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399DB0: addiu       $a1, $a1, 0x3B8
    ctx->r5 = ADD32(ctx->r5, 0X3B8);
    // 0x80399DB4: slti        $at, $a3, 0xA
    ctx->r1 = SIGNED(ctx->r7) < 0XA ? 1 : 0;
    // 0x80399DB8: beq         $at, $zero, L_80399DDC
    if (ctx->r1 == 0) {
        // 0x80399DBC: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_80399DDC;
    }
    // 0x80399DBC: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399DC0: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399DC4: addiu       $a1, $a1, 0x3B0
    ctx->r5 = ADD32(ctx->r5, 0X3B0);
    // 0x80399DC8: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399DCC: jal         0x801395F4
    // 0x80399DD0: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_77;
    // 0x80399DD0: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_77:
    // 0x80399DD4: b           L_80399DE8
    // 0x80399DD8: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
        goto L_80399DE8;
    // 0x80399DD8: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_80399DDC:
    // 0x80399DDC: jal         0x801395F4
    // 0x80399DE0: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_78;
    // 0x80399DE0: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_78:
    // 0x80399DE4: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_80399DE8:
    // 0x80399DE8: jal         0x801308B4
    // 0x80399DEC: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_79;
    // 0x80399DEC: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_79:
    // 0x80399DF0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399DF4: lwc1        $f10, 0x74C4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399DF8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399DFC: lwc1        $f8, 0x74C0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399E00: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399E04: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x80399E08: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399E0C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399E10: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80399E14: jal         0x8012DEF8
    // 0x80399E18: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text(rdram, ctx);
        goto after_80;
    // 0x80399E18: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_80:
    // 0x80399E1C: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x80399E20: lb          $v0, -0xD52($v0)
    ctx->r2 = MEM_B(ctx->r2, -0XD52);
    // 0x80399E24: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80399E28: beq         $v0, $at, L_80399E38
    if (ctx->r2 == ctx->r1) {
        // 0x80399E2C: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80399E38;
    }
    // 0x80399E2C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80399E30: bne         $v0, $at, L_80399E74
    if (ctx->r2 != ctx->r1) {
        // 0x80399E34: nop
    
            goto L_80399E74;
    }
    // 0x80399E34: nop

L_80399E38:
    // 0x80399E38: jal         0x80130A90
    // 0x80399E3C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    get_message_address_by_id(rdram, ctx);
        goto after_81;
    // 0x80399E3C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    after_81:
    // 0x80399E40: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399E44: lwc1        $f4, 0x74C4($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399E48: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399E4C: lwc1        $f18, 0x74C0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399E50: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399E54: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399E58: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x80399E5C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399E60: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x80399E64: jal         0x8012DEF8
    // 0x80399E68: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_82;
    // 0x80399E68: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_82:
    // 0x80399E6C: b           L_80399EAC
    // 0x80399E70: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
        goto L_80399EAC;
    // 0x80399E70: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
L_80399E74:
    // 0x80399E74: jal         0x80130A90
    // 0x80399E78: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    get_message_address_by_id(rdram, ctx);
        goto after_83;
    // 0x80399E78: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    after_83:
    // 0x80399E7C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399E80: lwc1        $f6, 0x74C4($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399E84: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399E88: lwc1        $f10, 0x74C0($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399E8C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399E90: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399E94: addiu       $a2, $zero, 0x10E
    ctx->r6 = ADD32(0, 0X10E);
    // 0x80399E98: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399E9C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x80399EA0: jal         0x8012DEF8
    // 0x80399EA4: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    display_text(rdram, ctx);
        goto after_84;
    // 0x80399EA4: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    after_84:
L_80399EA8:
    // 0x80399EA8: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
L_80399EAC:
    // 0x80399EAC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x80399EB0: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x80399EB4: bnel        $t8, $at, L_80399F64
    if (ctx->r24 != ctx->r1) {
        // 0x80399EB8: lh          $t6, 0xD2($sp)
        ctx->r14 = MEM_H(ctx->r29, 0XD2);
            goto L_80399F64;
    }
    goto skip_12;
    // 0x80399EB8: lh          $t6, 0xD2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XD2);
    skip_12:
    // 0x80399EBC: lw          $a3, -0xD70($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD70);
    // 0x80399EC0: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399EC4: addiu       $a1, $a1, 0x3C0
    ctx->r5 = ADD32(ctx->r5, 0X3C0);
    // 0x80399EC8: srl         $t9, $a3, 24
    ctx->r25 = S32(U32(ctx->r7) >> 24);
    // 0x80399ECC: sll         $t5, $t9, 2
    ctx->r13 = S32(ctx->r25 << 2);
    // 0x80399ED0: subu        $t5, $t5, $t9
    ctx->r13 = SUB32(ctx->r13, ctx->r25);
    // 0x80399ED4: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x80399ED8: addu        $t5, $t5, $t9
    ctx->r13 = ADD32(ctx->r13, ctx->r25);
    // 0x80399EDC: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80399EE0: beq         $t5, $zero, L_80399F60
    if (ctx->r13 == 0) {
        // 0x80399EE4: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_80399F60;
    }
    // 0x80399EE4: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399EE8: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    // 0x80399EEC: jal         0x801395F4
    // 0x80399EF0: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    sprintf_recomp(rdram, ctx);
        goto after_85;
    // 0x80399EF0: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    after_85:
    // 0x80399EF4: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399EF8: jal         0x801308B4
    // 0x80399EFC: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_86;
    // 0x80399EFC: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_86:
    // 0x80399F00: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399F04: lwc1        $f8, 0x74C4($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399F08: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399F0C: lwc1        $f4, 0x74C0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399F10: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399F14: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x80399F18: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399F1C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399F20: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x80399F24: jal         0x8012DEF8
    // 0x80399F28: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text(rdram, ctx);
        goto after_87;
    // 0x80399F28: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_87:
    // 0x80399F2C: jal         0x80130A90
    // 0x80399F30: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    get_message_address_by_id(rdram, ctx);
        goto after_88;
    // 0x80399F30: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    after_88:
    // 0x80399F34: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399F38: lwc1        $f18, 0x74C4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399F3C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399F40: lwc1        $f6, 0x74C0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399F44: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399F48: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399F4C: addiu       $a2, $zero, 0x101
    ctx->r6 = ADD32(0, 0X101);
    // 0x80399F50: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399F54: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x80399F58: jal         0x8012DEF8
    // 0x80399F5C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text(rdram, ctx);
        goto after_89;
    // 0x80399F5C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_89:
L_80399F60:
    // 0x80399F60: lh          $t6, 0xD2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XD2);
L_80399F64:
    // 0x80399F64: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x80399F68: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x80399F6C: bnel        $t6, $at, L_8039A00C
    if (ctx->r14 != ctx->r1) {
        // 0x80399F70: lh          $t9, 0xD2($sp)
        ctx->r25 = MEM_H(ctx->r29, 0XD2);
            goto L_8039A00C;
    }
    goto skip_13;
    // 0x80399F70: lh          $t9, 0xD2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD2);
    skip_13:
    // 0x80399F74: lw          $a3, -0xD70($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD70);
    // 0x80399F78: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x80399F7C: addiu       $a1, $a1, 0x3C4
    ctx->r5 = ADD32(ctx->r5, 0X3C4);
    // 0x80399F80: srl         $t7, $a3, 8
    ctx->r15 = S32(U32(ctx->r7) >> 8);
    // 0x80399F84: andi        $t8, $t7, 0x1F
    ctx->r24 = ctx->r15 & 0X1F;
    // 0x80399F88: beq         $t8, $zero, L_8039A008
    if (ctx->r24 == 0) {
        // 0x80399F8C: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_8039A008;
    }
    // 0x80399F8C: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399F90: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80399F94: jal         0x801395F4
    // 0x80399F98: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    sprintf_recomp(rdram, ctx);
        goto after_90;
    // 0x80399F98: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    after_90:
    // 0x80399F9C: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x80399FA0: jal         0x801308B4
    // 0x80399FA4: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_91;
    // 0x80399FA4: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_91:
    // 0x80399FA8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399FAC: lwc1        $f10, 0x74C4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399FB0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399FB4: lwc1        $f8, 0x74C0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399FB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399FBC: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x80399FC0: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x80399FC4: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399FC8: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x80399FCC: jal         0x8012DEF8
    // 0x80399FD0: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text(rdram, ctx);
        goto after_92;
    // 0x80399FD0: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_92:
    // 0x80399FD4: jal         0x80130A90
    // 0x80399FD8: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    get_message_address_by_id(rdram, ctx);
        goto after_93;
    // 0x80399FD8: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    after_93:
    // 0x80399FDC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399FE0: lwc1        $f4, 0x74C4($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x80399FE4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x80399FE8: lwc1        $f18, 0x74C0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x80399FEC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80399FF0: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80399FF4: addiu       $a2, $zero, 0x11D
    ctx->r6 = ADD32(0, 0X11D);
    // 0x80399FF8: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x80399FFC: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8039A000: jal         0x8012DEF8
    // 0x8039A004: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_94;
    // 0x8039A004: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_94:
L_8039A008:
    // 0x8039A008: lh          $t9, 0xD2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD2);
L_8039A00C:
    // 0x8039A00C: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x8039A010: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A014: bnel        $t9, $at, L_8039A0F4
    if (ctx->r25 != ctx->r1) {
        // 0x8039A018: lh          $t8, 0xD2($sp)
        ctx->r24 = MEM_H(ctx->r29, 0XD2);
            goto L_8039A0F4;
    }
    goto skip_14;
    // 0x8039A018: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
    skip_14:
    // 0x8039A01C: lw          $a3, -0xD6C($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD6C);
    // 0x8039A020: addiu       $a1, $sp, 0xCC
    ctx->r5 = ADD32(ctx->r29, 0XCC);
    // 0x8039A024: addiu       $a2, $sp, 0xCE
    ctx->r6 = ADD32(ctx->r29, 0XCE);
    // 0x8039A028: srl         $t5, $a3, 8
    ctx->r13 = S32(U32(ctx->r7) >> 8);
    // 0x8039A02C: andi        $t6, $t5, 0x1FF
    ctx->r14 = ctx->r13 & 0X1FF;
    // 0x8039A030: beq         $t6, $zero, L_8039A0F0
    if (ctx->r14 == 0) {
        // 0x8039A034: sll         $a0, $t6, 16
        ctx->r4 = S32(ctx->r14 << 16);
            goto L_8039A0F0;
    }
    // 0x8039A034: sll         $a0, $t6, 16
    ctx->r4 = S32(ctx->r14 << 16);
    // 0x8039A038: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8039A03C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8039A040: jal         0x8039DB60
    // 0x8039A044: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    seconds_to_mins_secs(rdram, ctx);
        goto after_95;
    // 0x8039A044: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    after_95:
    // 0x8039A048: lh          $a3, 0xCE($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XCE);
    // 0x8039A04C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039A050: addiu       $a1, $a1, 0x3D0
    ctx->r5 = ADD32(ctx->r5, 0X3D0);
    // 0x8039A054: slti        $at, $a3, 0xA
    ctx->r1 = SIGNED(ctx->r7) < 0XA ? 1 : 0;
    // 0x8039A058: beq         $at, $zero, L_8039A07C
    if (ctx->r1 == 0) {
        // 0x8039A05C: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_8039A07C;
    }
    // 0x8039A05C: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x8039A060: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039A064: addiu       $a1, $a1, 0x3C8
    ctx->r5 = ADD32(ctx->r5, 0X3C8);
    // 0x8039A068: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x8039A06C: jal         0x801395F4
    // 0x8039A070: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_96;
    // 0x8039A070: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_96:
    // 0x8039A074: b           L_8039A088
    // 0x8039A078: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
        goto L_8039A088;
    // 0x8039A078: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_8039A07C:
    // 0x8039A07C: jal         0x801395F4
    // 0x8039A080: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    sprintf_recomp(rdram, ctx);
        goto after_97;
    // 0x8039A080: lh          $a2, 0xCC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XCC);
    after_97:
    // 0x8039A084: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
L_8039A088:
    // 0x8039A088: jal         0x801308B4
    // 0x8039A08C: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_98;
    // 0x8039A08C: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_98:
    // 0x8039A090: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A094: lwc1        $f6, 0x74C4($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x8039A098: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A09C: lwc1        $f10, 0x74C0($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039A0A0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A0A4: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x8039A0A8: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039A0AC: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x8039A0B0: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039A0B4: jal         0x8012DEF8
    // 0x8039A0B8: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    display_text(rdram, ctx);
        goto after_99;
    // 0x8039A0B8: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    after_99:
    // 0x8039A0BC: jal         0x80130A90
    // 0x8039A0C0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    get_message_address_by_id(rdram, ctx);
        goto after_100;
    // 0x8039A0C0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_100:
    // 0x8039A0C4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A0C8: lwc1        $f8, 0x74C4($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C4);
    // 0x8039A0CC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A0D0: lwc1        $f4, 0x74C0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039A0D4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A0D8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039A0DC: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x8039A0E0: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x8039A0E4: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x8039A0E8: jal         0x8012DEF8
    // 0x8039A0EC: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text(rdram, ctx);
        goto after_101;
    // 0x8039A0EC: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_101:
L_8039A0F0:
    // 0x8039A0F0: lh          $t8, 0xD2($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XD2);
L_8039A0F4:
    // 0x8039A0F4: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8039A0F8: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A0FC: bne         $t8, $at, L_8039A2BC
    if (ctx->r24 != ctx->r1) {
        // 0x8039A100: addiu       $a0, $sp, 0x118
        ctx->r4 = ADD32(ctx->r29, 0X118);
            goto L_8039A2BC;
    }
    // 0x8039A100: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x8039A104: lw          $a3, -0xD6C($a3)
    ctx->r7 = MEM_W(ctx->r7, -0XD6C);
    // 0x8039A108: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039A10C: addiu       $a1, $a1, 0x3D8
    ctx->r5 = ADD32(ctx->r5, 0X3D8);
    // 0x8039A110: srl         $t9, $a3, 21
    ctx->r25 = S32(U32(ctx->r7) >> 21);
    // 0x8039A114: andi        $t5, $t9, 0x7FF
    ctx->r13 = ctx->r25 & 0X7FF;
    // 0x8039A118: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8039A11C: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x8039A120: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8039A124: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x8039A128: sll         $a2, $t6, 2
    ctx->r6 = S32(ctx->r14 << 2);
    // 0x8039A12C: jal         0x801395F4
    // 0x8039A130: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    sprintf_recomp(rdram, ctx);
        goto after_102;
    // 0x8039A130: lhu         $s0, 0xDA($sp)
    ctx->r16 = MEM_HU(ctx->r29, 0XDA);
    after_102:
    // 0x8039A134: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x8039A138: jal         0x801308B4
    // 0x8039A13C: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_103;
    // 0x8039A13C: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_103:
    // 0x8039A140: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A144: lwc1        $f18, 0x74BC($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x8039A148: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A14C: lwc1        $f6, 0x74C0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039A150: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A154: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x8039A158: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039A15C: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x8039A160: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039A164: jal         0x8012DEF8
    // 0x8039A168: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text(rdram, ctx);
        goto after_104;
    // 0x8039A168: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_104:
    // 0x8039A16C: jal         0x80130A90
    // 0x8039A170: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    get_message_address_by_id(rdram, ctx);
        goto after_105;
    // 0x8039A170: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    after_105:
    // 0x8039A174: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A178: lwc1        $f10, 0x74BC($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x8039A17C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A180: lwc1        $f8, 0x74C0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039A184: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A188: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039A18C: addiu       $a2, $zero, 0xF0
    ctx->r6 = ADD32(0, 0XF0);
    // 0x8039A190: andi        $a3, $s0, 0xFFFF
    ctx->r7 = ctx->r16 & 0XFFFF;
    // 0x8039A194: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8039A198: jal         0x8012DEF8
    // 0x8039A19C: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text(rdram, ctx);
        goto after_106;
    // 0x8039A19C: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_106:
    // 0x8039A1A0: b           L_8039A2C0
    // 0x8039A1A4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
        goto L_8039A2C0;
    // 0x8039A1A4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_8039A1A8:
    // 0x8039A1A8: lui         $a2, 0x8024
    ctx->r6 = S32(0X8024 << 16);
    // 0x8039A1AC: addu        $a2, $a2, $a3
    ctx->r6 = ADD32(ctx->r6, ctx->r7);
    // 0x8039A1B0: lbu         $a2, -0xD9C($a2)
    ctx->r6 = MEM_BU(ctx->r6, -0XD9C);
    // 0x8039A1B4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039A1B8: addiu       $a1, $a1, 0x3DC
    ctx->r5 = ADD32(ctx->r5, 0X3DC);
    // 0x8039A1BC: srl         $t7, $a2, 4
    ctx->r15 = S32(U32(ctx->r6) >> 4);
    // 0x8039A1C0: jal         0x801395F4
    // 0x8039A1C4: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    sprintf_recomp(rdram, ctx);
        goto after_107;
    // 0x8039A1C4: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    after_107:
    // 0x8039A1C8: addiu       $a0, $sp, 0x118
    ctx->r4 = ADD32(ctx->r29, 0X118);
    // 0x8039A1CC: jal         0x801308B4
    // 0x8039A1D0: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    prepare_text(rdram, ctx);
        goto after_108;
    // 0x8039A1D0: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    after_108:
    // 0x8039A1D4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A1D8: lwc1        $f4, 0x74BC($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x8039A1DC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A1E0: lwc1        $f18, 0x74C0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039A1E4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A1E8: addiu       $a1, $sp, 0xE4
    ctx->r5 = ADD32(ctx->r29, 0XE4);
    // 0x8039A1EC: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039A1F0: lhu         $a3, 0xDA($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0XDA);
    // 0x8039A1F4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8039A1F8: jal         0x8012DEF8
    // 0x8039A1FC: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_109;
    // 0x8039A1FC: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_109:
    // 0x8039A200: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8039A204: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x8039A208: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8039A20C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039A210: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8039A214: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039A218: lw          $t5, 0x5C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X5C);
    // 0x8039A21C: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8039A220: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8039A224: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8039A228: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8039A22C: lui         $t5, 0xB900
    ctx->r13 = S32(0XB900 << 16);
    // 0x8039A230: ori         $t5, $t5, 0x2
    ctx->r13 = ctx->r13 | 0X2;
    // 0x8039A234: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039A238: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8039A23C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039A240: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039A244: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8039A248: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8039A24C: lui         $t8, 0xF900
    ctx->r24 = S32(0XF900 << 16);
    // 0x8039A250: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039A254: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8039A258: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039A25C: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8039A260: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8039A264: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x8039A268: addiu       $a1, $zero, 0x410
    ctx->r5 = ADD32(0, 0X410);
    // 0x8039A26C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039A270: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8039A274: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039A278: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039A27C: lh          $t5, 0xDA($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XDA);
    // 0x8039A280: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x8039A284: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8039A288: addiu       $t6, $t5, -0x2
    ctx->r14 = ADD32(ctx->r13, -0X2);
    // 0x8039A28C: sll         $t7, $t6, 18
    ctx->r15 = S32(ctx->r14 << 18);
    // 0x8039A290: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039A294: addiu       $t9, $t5, 0xE
    ctx->r25 = ADD32(ctx->r13, 0XE);
    // 0x8039A298: lui         $t7, 0x800E
    ctx->r15 = S32(0X800E << 16);
    // 0x8039A29C: addiu       $t7, $t7, -0x1C70
    ctx->r15 = ADD32(ctx->r15, -0X1C70);
    // 0x8039A2A0: sll         $t6, $t9, 2
    ctx->r14 = S32(ctx->r25 << 2);
    // 0x8039A2A4: addiu       $t5, $zero, 0x20
    ctx->r13 = ADD32(0, 0X20);
    // 0x8039A2A8: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x8039A2AC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039A2B0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8039A2B4: jal         0x803962EC
    // 0x8039A2B8: addiu       $a3, $zero, 0x450
    ctx->r7 = ADD32(0, 0X450);
    func_803962EC_7A799C(rdram, ctx);
        goto after_110;
    // 0x8039A2B8: addiu       $a3, $zero, 0x450
    ctx->r7 = ADD32(0, 0X450);
    after_110:
L_8039A2BC:
    // 0x8039A2BC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_8039A2C0:
    sssv_file_select_layout_hook(rdram, ctx, 3);
    // 0x8039A2C0: jal         0x8039D034
    // 0x8039A2C4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_8039D034_7AE6E4(rdram, ctx);
        goto after_111;
    // 0x8039A2C4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_111:
    // 0x8039A2C8: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8039A2CC: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x8039A2D0: lw          $s1, 0x38($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X38);
    // 0x8039A2D4: jr          $ra
    // 0x8039A2D8: addiu       $sp, $sp, 0x140
    ctx->r29 = ADD32(ctx->r29, 0X140);
    return;
    // 0x8039A2D8: addiu       $sp, $sp, 0x140
    ctx->r29 = ADD32(ctx->r29, 0X140);
;}
RECOMP_FUNC void func_8039A2DC_7AB98C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039A2DC: addiu       $sp, $sp, -0xD8
    ctx->r29 = ADD32(ctx->r29, -0XD8);
    // 0x8039A2E0: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8039A2E4: lui         $s0, 0x803F
    ctx->r16 = S32(0X803F << 16);
    // 0x8039A2E8: addiu       $s0, $s0, 0x7DA8
    ctx->r16 = ADD32(ctx->r16, 0X7DA8);
    // 0x8039A2EC: lb          $t6, 0x2F($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X2F);
    // 0x8039A2F0: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8039A2F4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039A2F8: bne         $t6, $zero, L_8039A304
    if (ctx->r14 != 0) {
        // 0x8039A2FC: addiu       $t7, $zero, 0x63
        ctx->r15 = ADD32(0, 0X63);
            goto L_8039A304;
    }
    // 0x8039A2FC: addiu       $t7, $zero, 0x63
    ctx->r15 = ADD32(0, 0X63);
    // 0x8039A300: sb          $t7, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r15;
L_8039A304:
    // 0x8039A304: jal         0x8039CE38
    // 0x8039A308: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    func_8039CE38_7AE4E8(rdram, ctx);
        goto after_0;
    // 0x8039A308: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_0:
    sssv_file_select_layout_hook(rdram, ctx, 0);
    // 0x8039A30C: jal         0x8039CAB8
    // 0x8039A310: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_8039CAB8_7AE168(rdram, ctx);
        goto after_1;
    // 0x8039A310: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    // 0x8039A314: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    sssv_file_select_layout_hook(rdram, ctx, 1);
    // 0x8039A318: jal         0x8039D30C
    // 0x8039A31C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    render_stars(rdram, ctx);
        goto after_2;
    // 0x8039A31C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_2:
    sssv_file_select_layout_hook(rdram, ctx, 2);
    // 0x8039A320: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039A324: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039A328: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039A32C: lui         $t9, 0xE700
    ctx->r25 = S32(0XE700 << 16);
    // 0x8039A330: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039A334: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8039A338: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039A33C: jal         0x8012C1F0
    // 0x8039A340: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    load_default_display_list(rdram, ctx);
        goto after_3;
    // 0x8039A340: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    after_3:
    // 0x8039A344: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039A348: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8039A34C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039A350: jal         0x8012C248
    // 0x8039A354: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_4;
    // 0x8039A354: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_4:
    // 0x8039A358: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039A35C: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039A360: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039A364: jal         0x8012C214
    // 0x8039A368: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_5;
    // 0x8039A368: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_5:
    // 0x8039A36C: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8039A370: lb          $t4, -0xD52($t4)
    ctx->r12 = MEM_B(ctx->r12, -0XD52);
    // 0x8039A374: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039A378: bnel        $t4, $at, L_8039A3E8
    if (ctx->r12 != ctx->r1) {
        // 0x8039A37C: lui         $at, 0x4140
        ctx->r1 = S32(0X4140 << 16);
            goto L_8039A3E8;
    }
    goto skip_0;
    // 0x8039A37C: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    skip_0:
    // 0x8039A380: jal         0x80130A90
    // 0x8039A384: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    get_message_address_by_id(rdram, ctx);
        goto after_6;
    // 0x8039A384: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_6:
    // 0x8039A388: lui         $at, 0x41B0
    ctx->r1 = S32(0X41B0 << 16);
    // 0x8039A38C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039A390: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039A394: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039A398: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039A39C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x8039A3A0: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x8039A3A4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039A3A8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039A3AC: addiu       $a2, $zero, 0x18
    ctx->r6 = ADD32(0, 0X18);
    // 0x8039A3B0: addiu       $a3, $zero, 0x1F
    ctx->r7 = ADD32(0, 0X1F);
    // 0x8039A3B4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    sssv_hd_menu_title_hook(rdram, ctx);
    // 0x8039A3B8: jal         0x8012D374
    // 0x8039A3BC: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_7;
    // 0x8039A3BC: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_7:
    // 0x8039A3C0: lui         $at, 0x4130
    ctx->r1 = S32(0X4130 << 16);
    // 0x8039A3C4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039A3C8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A3CC: swc1        $f8, 0x74AC($at)
    MEM_W(0X74AC, ctx->r1) = ctx->f8.u32l;
    // 0x8039A3D0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039A3D4: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039A3D8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A3DC: b           L_8039A444
    // 0x8039A3E0: swc1        $f10, 0x74B0($at)
    MEM_W(0X74B0, ctx->r1) = ctx->f10.u32l;
        goto L_8039A444;
    // 0x8039A3E0: swc1        $f10, 0x74B0($at)
    MEM_W(0X74B0, ctx->r1) = ctx->f10.u32l;
    // 0x8039A3E4: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
L_8039A3E8:
    // 0x8039A3E8: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039A3EC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A3F0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8039A3F4: swc1        $f16, 0x74AC($at)
    MEM_W(0X74AC, ctx->r1) = ctx->f16.u32l;
    // 0x8039A3F8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039A3FC: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8039A400: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039A404: jal         0x80130A90
    // 0x8039A408: swc1        $f18, 0x74B0($at)
    MEM_W(0X74B0, ctx->r1) = ctx->f18.u32l;
    get_message_address_by_id(rdram, ctx);
        goto after_8;
    // 0x8039A408: swc1        $f18, 0x74B0($at)
    MEM_W(0X74B0, ctx->r1) = ctx->f18.u32l;
    after_8:
    // 0x8039A40C: lui         $at, 0x41C0
    ctx->r1 = S32(0X41C0 << 16);
    // 0x8039A410: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039A414: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039A418: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039A41C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039A420: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8039A424: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8039A428: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039A42C: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039A430: addiu       $a2, $zero, 0x18
    ctx->r6 = ADD32(0, 0X18);
    // 0x8039A434: addiu       $a3, $zero, 0x1F
    ctx->r7 = ADD32(0, 0X1F);
    // 0x8039A438: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    sssv_hd_menu_title_hook(rdram, ctx);
    // 0x8039A43C: jal         0x8012D374
    // 0x8039A440: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    func_8012D374(rdram, ctx);
        goto after_9;
    // 0x8039A440: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_9:
L_8039A444:
    // 0x8039A444: lui         $t0, 0x801E
    ctx->r8 = S32(0X801E << 16);
    // 0x8039A448: addiu       $t0, $t0, -0x6184
    ctx->r8 = ADD32(ctx->r8, -0X6184);
    // 0x8039A44C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8039A450: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8039A454: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x8039A458: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039A45C: sw          $t7, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r15;
    // 0x8039A460: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039A464: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039A468: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8039A46C: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x8039A470: lui         $t1, 0x8016
    ctx->r9 = S32(0X8016 << 16);
    // 0x8039A474: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039A478: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x8039A47C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039A480: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039A484: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8039A488: addiu       $t1, $t1, -0x7B60
    ctx->r9 = ADD32(ctx->r9, -0X7B60);
    // 0x8039A48C: lui         $t6, 0x600
    ctx->r14 = S32(0X600 << 16);
    // 0x8039A490: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8039A494: sw          $t5, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r13;
    // 0x8039A498: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
    // 0x8039A49C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039A4A0: lb          $v1, 0x2E($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A4A4: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    // 0x8039A4A8: addiu       $a1, $zero, 0x58
    ctx->r5 = ADD32(0, 0X58);
    // 0x8039A4AC: sltiu       $t7, $v1, 0x1
    ctx->r15 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039A4B0: bne         $t7, $zero, L_8039A4C4
    if (ctx->r15 != 0) {
        // 0x8039A4B4: or          $v1, $t7, $zero
        ctx->r3 = ctx->r15 | 0;
            goto L_8039A4C4;
    }
    // 0x8039A4B4: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x8039A4B8: lb          $v1, 0x31($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X31);
    // 0x8039A4BC: sltiu       $t8, $v1, 0x1
    ctx->r24 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039A4C0: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_8039A4C4:
    // 0x8039A4C4: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A4C8: addiu       $a3, $a3, -0xD20
    ctx->r7 = ADD32(ctx->r7, -0XD20);
    // 0x8039A4CC: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    // 0x8039A4D0: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    // 0x8039A4D4: jal         0x8039C5F8
    // 0x8039A4D8: sw          $t1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r9;
    func_8039C5F8_7ADCA8(rdram, ctx);
        goto after_10;
    // 0x8039A4D8: sw          $t1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r9;
    after_10:
    // 0x8039A4DC: lb          $t9, 0x2E($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A4E0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8039A4E4: addiu       $a0, $zero, 0x84
    ctx->r4 = ADD32(0, 0X84);
    // 0x8039A4E8: xor         $v1, $v0, $t9
    ctx->r3 = ctx->r2 ^ ctx->r25;
    // 0x8039A4EC: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039A4F0: bne         $v1, $zero, L_8039A504
    if (ctx->r3 != 0) {
        // 0x8039A4F4: addiu       $a1, $zero, 0x58
        ctx->r5 = ADD32(0, 0X58);
            goto L_8039A504;
    }
    // 0x8039A4F4: addiu       $a1, $zero, 0x58
    ctx->r5 = ADD32(0, 0X58);
    // 0x8039A4F8: lb          $t4, 0x31($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X31);
    // 0x8039A4FC: xor         $v1, $v0, $t4
    ctx->r3 = ctx->r2 ^ ctx->r12;
    // 0x8039A500: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
L_8039A504:
    // 0x8039A504: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A508: addiu       $a3, $a3, -0xCE0
    ctx->r7 = ADD32(ctx->r7, -0XCE0);
    // 0x8039A50C: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    // 0x8039A510: jal         0x8039C5F8
    // 0x8039A514: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    func_8039C5F8_7ADCA8(rdram, ctx);
        goto after_11;
    // 0x8039A514: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    after_11:
    // 0x8039A518: lb          $t5, 0x2E($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A51C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
    // 0x8039A520: addiu       $a0, $zero, 0x38
    ctx->r4 = ADD32(0, 0X38);
    // 0x8039A524: xor         $v1, $v0, $t5
    ctx->r3 = ctx->r2 ^ ctx->r13;
    // 0x8039A528: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039A52C: bne         $v1, $zero, L_8039A540
    if (ctx->r3 != 0) {
        // 0x8039A530: addiu       $a1, $zero, 0xA4
        ctx->r5 = ADD32(0, 0XA4);
            goto L_8039A540;
    }
    // 0x8039A530: addiu       $a1, $zero, 0xA4
    ctx->r5 = ADD32(0, 0XA4);
    // 0x8039A534: lb          $t6, 0x31($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X31);
    // 0x8039A538: xor         $v1, $v0, $t6
    ctx->r3 = ctx->r2 ^ ctx->r14;
    // 0x8039A53C: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
L_8039A540:
    // 0x8039A540: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A544: addiu       $a3, $a3, -0xCA0
    ctx->r7 = ADD32(ctx->r7, -0XCA0);
    // 0x8039A548: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    // 0x8039A54C: jal         0x8039C5F8
    // 0x8039A550: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    func_8039C5F8_7ADCA8(rdram, ctx);
        goto after_12;
    // 0x8039A550: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    after_12:
    // 0x8039A554: lb          $t7, 0x2E($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A558: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
    // 0x8039A55C: addiu       $a0, $zero, 0x84
    ctx->r4 = ADD32(0, 0X84);
    // 0x8039A560: xor         $v1, $v0, $t7
    ctx->r3 = ctx->r2 ^ ctx->r15;
    // 0x8039A564: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039A568: bne         $v1, $zero, L_8039A57C
    if (ctx->r3 != 0) {
        // 0x8039A56C: addiu       $a1, $zero, 0xA4
        ctx->r5 = ADD32(0, 0XA4);
            goto L_8039A57C;
    }
    // 0x8039A56C: addiu       $a1, $zero, 0xA4
    ctx->r5 = ADD32(0, 0XA4);
    // 0x8039A570: lb          $t8, 0x31($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X31);
    // 0x8039A574: xor         $v1, $v0, $t8
    ctx->r3 = ctx->r2 ^ ctx->r24;
    // 0x8039A578: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
L_8039A57C:
    // 0x8039A57C: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039A580: addiu       $a3, $a3, -0xC60
    ctx->r7 = ADD32(ctx->r7, -0XC60);
    // 0x8039A584: lui         $a2, 0x3F80
    ctx->r6 = S32(0X3F80 << 16);
    // 0x8039A588: jal         0x8039C5F8
    // 0x8039A58C: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    func_8039C5F8_7ADCA8(rdram, ctx);
        goto after_13;
    // 0x8039A58C: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    after_13:
    // 0x8039A590: lb          $t9, 0x2F($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2F);
    // 0x8039A594: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039A598: bnel        $t9, $at, L_8039A5C8
    if (ctx->r25 != ctx->r1) {
        // 0x8039A59C: lb          $t7, 0x2E($s0)
        ctx->r15 = MEM_B(ctx->r16, 0X2E);
            goto L_8039A5C8;
    }
    goto skip_1;
    // 0x8039A59C: lb          $t7, 0x2E($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2E);
    skip_1:
    // 0x8039A5A0: lb          $t4, 0x31($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X31);
    // 0x8039A5A4: lui         $t6, 0x8024
    ctx->r14 = S32(0X8024 << 16);
    // 0x8039A5A8: addiu       $t6, $t6, -0xD20
    ctx->r14 = ADD32(ctx->r14, -0XD20);
    // 0x8039A5AC: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x8039A5B0: addu        $a0, $t5, $t6
    ctx->r4 = ADD32(ctx->r13, ctx->r14);
    // 0x8039A5B4: jal         0x8039CCBC
    // 0x8039A5B8: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    get_player_progress(rdram, ctx);
        goto after_14;
    // 0x8039A5B8: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    after_14:
    // 0x8039A5BC: b           L_8039A5E4
    // 0x8039A5C0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
        goto L_8039A5E4;
    // 0x8039A5C0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039A5C4: lb          $t7, 0x2E($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2E);
L_8039A5C8:
    // 0x8039A5C8: lui         $t9, 0x8024
    ctx->r25 = S32(0X8024 << 16);
    // 0x8039A5CC: addiu       $t9, $t9, -0xD20
    ctx->r25 = ADD32(ctx->r25, -0XD20);
    // 0x8039A5D0: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x8039A5D4: addu        $a0, $t8, $t9
    ctx->r4 = ADD32(ctx->r24, ctx->r25);
    // 0x8039A5D8: jal         0x8039CCBC
    // 0x8039A5DC: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    get_player_progress(rdram, ctx);
        goto after_15;
    // 0x8039A5DC: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    after_15:
    // 0x8039A5E0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
L_8039A5E4:
    // 0x8039A5E4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039A5E8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039A5EC: jal         0x8012C214
    // 0x8039A5F0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_16;
    // 0x8039A5F0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_16:
    // 0x8039A5F4: lui         $a3, 0x8029
    ctx->r7 = S32(0X8029 << 16);
    // 0x8039A5F8: lbu         $a3, 0x12E4($a3)
    ctx->r7 = MEM_BU(ctx->r7, 0X12E4);
    // 0x8039A5FC: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8039A600: lui         $a2, 0x8029
    ctx->r6 = S32(0X8029 << 16);
    // 0x8039A604: bne         $t3, $a3, L_8039A614
    if (ctx->r11 != ctx->r7) {
        // 0x8039A608: lui         $a0, 0x8029
        ctx->r4 = S32(0X8029 << 16);
            goto L_8039A614;
    }
    // 0x8039A608: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8039A60C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039A610: sb          $zero, 0x7DA3($at)
    MEM_B(0X7DA3, ctx->r1) = 0;
L_8039A614:
    // 0x8039A614: lbu         $a2, 0x12E3($a2)
    ctx->r6 = MEM_BU(ctx->r6, 0X12E3);
    // 0x8039A618: bne         $t3, $a2, L_8039A624
    if (ctx->r11 != ctx->r6) {
        // 0x8039A61C: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8039A624;
    }
    // 0x8039A61C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039A620: sb          $zero, 0x7DA2($at)
    MEM_B(0X7DA2, ctx->r1) = 0;
L_8039A624:
    // 0x8039A624: lw          $a0, 0x10D0($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X10D0);
    // 0x8039A628: sb          $zero, 0x84($sp)
    MEM_B(0X84, ctx->r29) = 0;
    // 0x8039A62C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8039A630: lb          $v0, 0x2($a0)
    ctx->r2 = MEM_B(ctx->r4, 0X2);
    // 0x8039A634: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
    // 0x8039A638: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x8039A63C: slti        $at, $v0, -0x1E
    ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
    // 0x8039A640: beq         $at, $zero, L_8039A678
    if (ctx->r1 == 0) {
        // 0x8039A644: or          $t2, $zero, $zero
        ctx->r10 = 0 | 0;
            goto L_8039A678;
    }
    // 0x8039A644: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x8039A648: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x8039A64C: addiu       $a1, $a1, -0x612C
    ctx->r5 = ADD32(ctx->r5, -0X612C);
    // 0x8039A650: lh          $t4, 0x0($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X0);
    // 0x8039A654: bnel        $t4, $zero, L_8039A670
    if (ctx->r12 != 0) {
        // 0x8039A658: sll         $v1, $t3, 24
        ctx->r3 = S32(ctx->r11 << 24);
            goto L_8039A670;
    }
    goto skip_2;
    // 0x8039A658: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
    skip_2:
    // 0x8039A65C: sll         $t0, $t3, 24
    ctx->r8 = S32(ctx->r11 << 24);
    // 0x8039A660: sra         $t5, $t0, 24
    ctx->r13 = S32(SIGNED(ctx->r8) >> 24);
    // 0x8039A664: b           L_8039A678
    // 0x8039A668: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
        goto L_8039A678;
    // 0x8039A668: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x8039A66C: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
L_8039A670:
    // 0x8039A670: sra         $t6, $v1, 24
    ctx->r14 = S32(SIGNED(ctx->r3) >> 24);
    // 0x8039A674: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_8039A678:
    // 0x8039A678: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x8039A67C: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x8039A680: bne         $at, $zero, L_8039A6B0
    if (ctx->r1 != 0) {
        // 0x8039A684: addiu       $a1, $a1, -0x612C
        ctx->r5 = ADD32(ctx->r5, -0X612C);
            goto L_8039A6B0;
    }
    // 0x8039A684: addiu       $a1, $a1, -0x612C
    ctx->r5 = ADD32(ctx->r5, -0X612C);
    // 0x8039A688: lh          $t7, 0x0($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X0);
    // 0x8039A68C: bnel        $t7, $zero, L_8039A6A8
    if (ctx->r15 != 0) {
        // 0x8039A690: sll         $v1, $t3, 24
        ctx->r3 = S32(ctx->r11 << 24);
            goto L_8039A6A8;
    }
    goto skip_3;
    // 0x8039A690: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
    skip_3:
    // 0x8039A694: sll         $t1, $t3, 24
    ctx->r9 = S32(ctx->r11 << 24);
    // 0x8039A698: sra         $t8, $t1, 24
    ctx->r24 = S32(SIGNED(ctx->r9) >> 24);
    // 0x8039A69C: b           L_8039A6B0
    // 0x8039A6A0: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
        goto L_8039A6B0;
    // 0x8039A6A0: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
    // 0x8039A6A4: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
L_8039A6A8:
    // 0x8039A6A8: sra         $t9, $v1, 24
    ctx->r25 = S32(SIGNED(ctx->r3) >> 24);
    // 0x8039A6AC: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
L_8039A6B0:
    // 0x8039A6B0: lb          $v0, 0x3($a0)
    ctx->r2 = MEM_B(ctx->r4, 0X3);
    // 0x8039A6B4: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x8039A6B8: bnel        $at, $zero, L_8039A6EC
    if (ctx->r1 != 0) {
        // 0x8039A6BC: slti        $at, $v0, -0x1E
        ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
            goto L_8039A6EC;
    }
    goto skip_4;
    // 0x8039A6BC: slti        $at, $v0, -0x1E
    ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
    skip_4:
    // 0x8039A6C0: lh          $t4, 0x0($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X0);
    // 0x8039A6C4: bnel        $t4, $zero, L_8039A6E0
    if (ctx->r12 != 0) {
        // 0x8039A6C8: sll         $v1, $t3, 24
        ctx->r3 = S32(ctx->r11 << 24);
            goto L_8039A6E0;
    }
    goto skip_5;
    // 0x8039A6C8: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
    skip_5:
    // 0x8039A6CC: sll         $t2, $t3, 24
    ctx->r10 = S32(ctx->r11 << 24);
    // 0x8039A6D0: sra         $t5, $t2, 24
    ctx->r13 = S32(SIGNED(ctx->r10) >> 24);
    // 0x8039A6D4: b           L_8039A6E8
    // 0x8039A6D8: or          $t2, $t5, $zero
    ctx->r10 = ctx->r13 | 0;
        goto L_8039A6E8;
    // 0x8039A6D8: or          $t2, $t5, $zero
    ctx->r10 = ctx->r13 | 0;
    // 0x8039A6DC: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
L_8039A6E0:
    // 0x8039A6E0: sra         $t6, $v1, 24
    ctx->r14 = S32(SIGNED(ctx->r3) >> 24);
    // 0x8039A6E4: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_8039A6E8:
    // 0x8039A6E8: slti        $at, $v0, -0x1E
    ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
L_8039A6EC:
    // 0x8039A6EC: beq         $at, $zero, L_8039A714
    if (ctx->r1 == 0) {
        // 0x8039A6F0: nop
    
            goto L_8039A714;
    }
    // 0x8039A6F0: nop

    // 0x8039A6F4: lh          $t7, 0x0($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X0);
    // 0x8039A6F8: bnel        $t7, $zero, L_8039A70C
    if (ctx->r15 != 0) {
        // 0x8039A6FC: sll         $v1, $t3, 24
        ctx->r3 = S32(ctx->r11 << 24);
            goto L_8039A70C;
    }
    goto skip_6;
    // 0x8039A6FC: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
    skip_6:
    // 0x8039A700: b           L_8039A714
    // 0x8039A704: sb          $t3, 0x84($sp)
    MEM_B(0X84, ctx->r29) = ctx->r11;
        goto L_8039A714;
    // 0x8039A704: sb          $t3, 0x84($sp)
    MEM_B(0X84, ctx->r29) = ctx->r11;
    // 0x8039A708: sll         $v1, $t3, 24
    ctx->r3 = S32(ctx->r11 << 24);
L_8039A70C:
    // 0x8039A70C: sra         $t8, $v1, 24
    ctx->r24 = S32(SIGNED(ctx->r3) >> 24);
    // 0x8039A710: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_8039A714:
    // 0x8039A714: bnel        $t2, $zero, L_8039A738
    if (ctx->r10 != 0) {
        // 0x8039A718: addiu       $t4, $zero, 0x11
        ctx->r12 = ADD32(0, 0X11);
            goto L_8039A738;
    }
    goto skip_7;
    // 0x8039A718: addiu       $t4, $zero, 0x11
    ctx->r12 = ADD32(0, 0X11);
    skip_7:
    // 0x8039A71C: lb          $t9, 0x84($sp)
    ctx->r25 = MEM_B(ctx->r29, 0X84);
    // 0x8039A720: bnel        $t9, $zero, L_8039A738
    if (ctx->r25 != 0) {
        // 0x8039A724: addiu       $t4, $zero, 0x11
        ctx->r12 = ADD32(0, 0X11);
            goto L_8039A738;
    }
    goto skip_8;
    // 0x8039A724: addiu       $t4, $zero, 0x11
    ctx->r12 = ADD32(0, 0X11);
    skip_8:
    // 0x8039A728: bnel        $t0, $zero, L_8039A738
    if (ctx->r8 != 0) {
        // 0x8039A72C: addiu       $t4, $zero, 0x11
        ctx->r12 = ADD32(0, 0X11);
            goto L_8039A738;
    }
    goto skip_9;
    // 0x8039A72C: addiu       $t4, $zero, 0x11
    ctx->r12 = ADD32(0, 0X11);
    skip_9:
    // 0x8039A730: beq         $t1, $zero, L_8039A73C
    if (ctx->r9 == 0) {
        // 0x8039A734: addiu       $t4, $zero, 0x11
        ctx->r12 = ADD32(0, 0X11);
            goto L_8039A73C;
    }
    // 0x8039A734: addiu       $t4, $zero, 0x11
    ctx->r12 = ADD32(0, 0X11);
L_8039A738:
    // 0x8039A738: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
L_8039A73C:
    // 0x8039A73C: bnel        $v1, $zero, L_8039A7D0
    if (ctx->r3 != 0) {
        // 0x8039A740: lb          $v1, 0x2F($s0)
        ctx->r3 = MEM_B(ctx->r16, 0X2F);
            goto L_8039A7D0;
    }
    goto skip_10;
    // 0x8039A740: lb          $v1, 0x2F($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X2F);
    skip_10:
    // 0x8039A744: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x8039A748: andi        $t5, $v0, 0x200
    ctx->r13 = ctx->r2 & 0X200;
    // 0x8039A74C: beq         $t5, $zero, L_8039A76C
    if (ctx->r13 == 0) {
        // 0x8039A750: andi        $t7, $v0, 0x100
        ctx->r15 = ctx->r2 & 0X100;
            goto L_8039A76C;
    }
    // 0x8039A750: andi        $t7, $v0, 0x100
    ctx->r15 = ctx->r2 & 0X100;
    // 0x8039A754: bne         $t3, $a2, L_8039A76C
    if (ctx->r11 != ctx->r6) {
        // 0x8039A758: nop
    
            goto L_8039A76C;
    }
    // 0x8039A758: nop

    // 0x8039A75C: sll         $t0, $t3, 24
    ctx->r8 = S32(ctx->r11 << 24);
    // 0x8039A760: sra         $t6, $t0, 24
    ctx->r14 = S32(SIGNED(ctx->r8) >> 24);
    // 0x8039A764: b           L_8039A7CC
    // 0x8039A768: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
        goto L_8039A7CC;
    // 0x8039A768: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
L_8039A76C:
    // 0x8039A76C: beq         $t7, $zero, L_8039A78C
    if (ctx->r15 == 0) {
        // 0x8039A770: andi        $t9, $v0, 0x800
        ctx->r25 = ctx->r2 & 0X800;
            goto L_8039A78C;
    }
    // 0x8039A770: andi        $t9, $v0, 0x800
    ctx->r25 = ctx->r2 & 0X800;
    // 0x8039A774: bne         $t3, $a3, L_8039A78C
    if (ctx->r11 != ctx->r7) {
        // 0x8039A778: nop
    
            goto L_8039A78C;
    }
    // 0x8039A778: nop

    // 0x8039A77C: sll         $t1, $t3, 24
    ctx->r9 = S32(ctx->r11 << 24);
    // 0x8039A780: sra         $t8, $t1, 24
    ctx->r24 = S32(SIGNED(ctx->r9) >> 24);
    // 0x8039A784: b           L_8039A7CC
    // 0x8039A788: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
        goto L_8039A7CC;
    // 0x8039A788: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
L_8039A78C:
    // 0x8039A78C: beq         $t9, $zero, L_8039A7B0
    if (ctx->r25 == 0) {
        // 0x8039A790: lui         $t4, 0x8029
        ctx->r12 = S32(0X8029 << 16);
            goto L_8039A7B0;
    }
    // 0x8039A790: lui         $t4, 0x8029
    ctx->r12 = S32(0X8029 << 16);
    // 0x8039A794: lbu         $t4, 0x12E1($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X12E1);
    // 0x8039A798: bnel        $t3, $t4, L_8039A7B4
    if (ctx->r11 != ctx->r12) {
        // 0x8039A79C: andi        $t6, $v0, 0x400
        ctx->r14 = ctx->r2 & 0X400;
            goto L_8039A7B4;
    }
    goto skip_11;
    // 0x8039A79C: andi        $t6, $v0, 0x400
    ctx->r14 = ctx->r2 & 0X400;
    skip_11:
    // 0x8039A7A0: sll         $t2, $t3, 24
    ctx->r10 = S32(ctx->r11 << 24);
    // 0x8039A7A4: sra         $t5, $t2, 24
    ctx->r13 = S32(SIGNED(ctx->r10) >> 24);
    // 0x8039A7A8: b           L_8039A7CC
    // 0x8039A7AC: or          $t2, $t5, $zero
    ctx->r10 = ctx->r13 | 0;
        goto L_8039A7CC;
    // 0x8039A7AC: or          $t2, $t5, $zero
    ctx->r10 = ctx->r13 | 0;
L_8039A7B0:
    // 0x8039A7B0: andi        $t6, $v0, 0x400
    ctx->r14 = ctx->r2 & 0X400;
L_8039A7B4:
    // 0x8039A7B4: beq         $t6, $zero, L_8039A7CC
    if (ctx->r14 == 0) {
        // 0x8039A7B8: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039A7CC;
    }
    // 0x8039A7B8: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x8039A7BC: lbu         $t7, 0x12E2($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12E2);
    // 0x8039A7C0: bnel        $t3, $t7, L_8039A7D0
    if (ctx->r11 != ctx->r15) {
        // 0x8039A7C4: lb          $v1, 0x2F($s0)
        ctx->r3 = MEM_B(ctx->r16, 0X2F);
            goto L_8039A7D0;
    }
    goto skip_12;
    // 0x8039A7C4: lb          $v1, 0x2F($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X2F);
    skip_12:
    // 0x8039A7C8: sb          $t3, 0x84($sp)
    MEM_B(0X84, ctx->r29) = ctx->r11;
L_8039A7CC:
    // 0x8039A7CC: lb          $v1, 0x2F($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X2F);
L_8039A7D0:
    // 0x8039A7D0: beq         $v1, $zero, L_8039A7F8
    if (ctx->r3 == 0) {
        // 0x8039A7D4: nop
    
            goto L_8039A7F8;
    }
    // 0x8039A7D4: nop

    // 0x8039A7D8: beq         $v1, $t3, L_8039A9F0
    if (ctx->r3 == ctx->r11) {
        // 0x8039A7DC: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8039A9F0;
    }
    // 0x8039A7DC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039A7E0: beq         $v1, $at, L_8039AEE4
    if (ctx->r3 == ctx->r1) {
        // 0x8039A7E4: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8039AEE4;
    }
    // 0x8039A7E4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039A7E8: beql        $v1, $at, L_8039B2C0
    if (ctx->r3 == ctx->r1) {
        // 0x8039A7EC: lhu         $v0, 0x0($a0)
        ctx->r2 = MEM_HU(ctx->r4, 0X0);
            goto L_8039B2C0;
    }
    goto skip_13;
    // 0x8039A7EC: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    skip_13:
    // 0x8039A7F0: b           L_8039B5F4
    // 0x8039A7F4: nop

        goto L_8039B5F4;
    // 0x8039A7F4: nop

L_8039A7F8:
    // 0x8039A7F8: beq         $t0, $zero, L_8039A848
    if (ctx->r8 == 0) {
        // 0x8039A7FC: nop
    
            goto L_8039A848;
    }
    // 0x8039A7FC: nop

    // 0x8039A800: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A804: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039A808: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039A80C: beq         $t3, $v0, L_8039A818
    if (ctx->r11 == ctx->r2) {
        // 0x8039A810: addiu       $t8, $v0, -0x1
        ctx->r24 = ADD32(ctx->r2, -0X1);
            goto L_8039A818;
    }
    // 0x8039A810: addiu       $t8, $v0, -0x1
    ctx->r24 = ADD32(ctx->r2, -0X1);
    // 0x8039A814: bne         $v0, $at, L_8039A848
    if (ctx->r2 != ctx->r1) {
        // 0x8039A818: addiu       $t9, $zero, 0x40
        ctx->r25 = ADD32(0, 0X40);
            goto L_8039A848;
    }
L_8039A818:
    // 0x8039A818: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8039A81C: sb          $t8, 0x2E($s0)
    MEM_B(0X2E, ctx->r16) = ctx->r24;
    // 0x8039A820: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039A824: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A828: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A82C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039A830: sb          $t1, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r9;
    // 0x8039A834: jal         0x8013307C
    // 0x8039A838: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_17;
    // 0x8039A838: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_17:
    // 0x8039A83C: lb          $t1, 0x82($sp)
    ctx->r9 = MEM_B(ctx->r29, 0X82);
    // 0x8039A840: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039A844: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039A848:
    // 0x8039A848: beq         $t1, $zero, L_8039A890
    if (ctx->r9 == 0) {
        // 0x8039A84C: nop
    
            goto L_8039A890;
    }
    // 0x8039A84C: nop

    // 0x8039A850: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A854: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039A858: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039A85C: beq         $v0, $zero, L_8039A868
    if (ctx->r2 == 0) {
        // 0x8039A860: addiu       $t4, $v0, 0x1
        ctx->r12 = ADD32(ctx->r2, 0X1);
            goto L_8039A868;
    }
    // 0x8039A860: addiu       $t4, $v0, 0x1
    ctx->r12 = ADD32(ctx->r2, 0X1);
    // 0x8039A864: bne         $v0, $at, L_8039A890
    if (ctx->r2 != ctx->r1) {
        // 0x8039A868: addiu       $t5, $zero, 0x40
        ctx->r13 = ADD32(0, 0X40);
            goto L_8039A890;
    }
L_8039A868:
    // 0x8039A868: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x8039A86C: sb          $t4, 0x2E($s0)
    MEM_B(0X2E, ctx->r16) = ctx->r12;
    // 0x8039A870: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x8039A874: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A878: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A87C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039A880: jal         0x8013307C
    // 0x8039A884: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_18;
    // 0x8039A884: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_18:
    // 0x8039A888: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039A88C: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039A890:
    // 0x8039A890: beql        $t2, $zero, L_8039A8D8
    if (ctx->r10 == 0) {
        // 0x8039A894: lb          $t8, 0x84($sp)
        ctx->r24 = MEM_B(ctx->r29, 0X84);
            goto L_8039A8D8;
    }
    goto skip_14;
    // 0x8039A894: lb          $t8, 0x84($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X84);
    skip_14:
    // 0x8039A898: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A89C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039A8A0: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039A8A4: beq         $v0, $at, L_8039A8B4
    if (ctx->r2 == ctx->r1) {
        // 0x8039A8A8: addiu       $t6, $v0, -0x2
        ctx->r14 = ADD32(ctx->r2, -0X2);
            goto L_8039A8B4;
    }
    // 0x8039A8A8: addiu       $t6, $v0, -0x2
    ctx->r14 = ADD32(ctx->r2, -0X2);
    // 0x8039A8AC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039A8B0: bne         $v0, $at, L_8039A8D4
    if (ctx->r2 != ctx->r1) {
        // 0x8039A8B4: addiu       $t7, $zero, 0x40
        ctx->r15 = ADD32(0, 0X40);
            goto L_8039A8D4;
    }
L_8039A8B4:
    // 0x8039A8B4: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x8039A8B8: sb          $t6, 0x2E($s0)
    MEM_B(0X2E, ctx->r16) = ctx->r14;
    // 0x8039A8BC: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039A8C0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A8C4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A8C8: jal         0x8013307C
    // 0x8039A8CC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_19;
    // 0x8039A8CC: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_19:
    // 0x8039A8D0: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039A8D4:
    // 0x8039A8D4: lb          $t8, 0x84($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X84);
L_8039A8D8:
    // 0x8039A8D8: beq         $t8, $zero, L_8039A914
    if (ctx->r24 == 0) {
        // 0x8039A8DC: nop
    
            goto L_8039A914;
    }
    // 0x8039A8DC: nop

    // 0x8039A8E0: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    // 0x8039A8E4: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039A8E8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A8EC: beq         $v0, $zero, L_8039A8F8
    if (ctx->r2 == 0) {
        // 0x8039A8F0: addiu       $t9, $v0, 0x2
        ctx->r25 = ADD32(ctx->r2, 0X2);
            goto L_8039A8F8;
    }
    // 0x8039A8F0: addiu       $t9, $v0, 0x2
    ctx->r25 = ADD32(ctx->r2, 0X2);
    // 0x8039A8F4: bne         $t3, $v0, L_8039A914
    if (ctx->r11 != ctx->r2) {
        // 0x8039A8F8: addiu       $t4, $zero, 0x40
        ctx->r12 = ADD32(0, 0X40);
            goto L_8039A914;
    }
L_8039A8F8:
    // 0x8039A8F8: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039A8FC: sb          $t9, 0x2E($s0)
    MEM_B(0X2E, ctx->r16) = ctx->r25;
    // 0x8039A900: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039A904: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A908: jal         0x8013307C
    // 0x8039A90C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_20;
    // 0x8039A90C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_20:
    // 0x8039A910: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039A914:
    // 0x8039A914: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x8039A918: lw          $t5, 0x10D0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X10D0);
    // 0x8039A91C: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x8039A920: lhu         $v0, 0x0($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X0);
    // 0x8039A924: andi        $t6, $v0, 0x4000
    ctx->r14 = ctx->r2 & 0X4000;
    // 0x8039A928: beql        $t6, $zero, L_8039A988
    if (ctx->r14 == 0) {
        // 0x8039A92C: andi        $t5, $v0, 0x1000
        ctx->r13 = ctx->r2 & 0X1000;
            goto L_8039A988;
    }
    goto skip_15;
    // 0x8039A92C: andi        $t5, $v0, 0x1000
    ctx->r13 = ctx->r2 & 0X1000;
    skip_15:
    // 0x8039A930: lbu         $t7, 0x12E0($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12E0);
    // 0x8039A934: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039A938: addiu       $v1, $v1, 0x6680
    ctx->r3 = ADD32(ctx->r3, 0X6680);
    // 0x8039A93C: bnel        $t3, $t7, L_8039A988
    if (ctx->r11 != ctx->r15) {
        // 0x8039A940: andi        $t5, $v0, 0x1000
        ctx->r13 = ctx->r2 & 0X1000;
            goto L_8039A988;
    }
    goto skip_16;
    // 0x8039A940: andi        $t5, $v0, 0x1000
    ctx->r13 = ctx->r2 & 0X1000;
    skip_16:
    // 0x8039A944: lh          $t8, 0x24($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X24);
    // 0x8039A948: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039A94C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A950: bne         $t8, $zero, L_8039A984
    if (ctx->r24 != 0) {
        // 0x8039A954: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039A984;
    }
    // 0x8039A954: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A958: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8039A95C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039A960: jal         0x8013307C
    // 0x8039A964: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_21;
    // 0x8039A964: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_21:
    // 0x8039A968: jal         0x80395074
    // 0x8039A96C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_22;
    // 0x8039A96C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_22:
    // 0x8039A970: jal         0x8038F708
    // 0x8039A974: nop

    func_8038F708_7A0DB8(rdram, ctx);
        goto after_23;
    // 0x8039A974: nop

    after_23:
    // 0x8039A978: lui         $t4, 0x8029
    ctx->r12 = S32(0X8029 << 16);
    // 0x8039A97C: lw          $t4, 0x10D0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X10D0);
    // 0x8039A980: lhu         $v0, 0x0($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X0);
L_8039A984:
    // 0x8039A984: andi        $t5, $v0, 0x1000
    ctx->r13 = ctx->r2 & 0X1000;
L_8039A988:
    // 0x8039A988: beq         $t5, $zero, L_8039A99C
    if (ctx->r13 == 0) {
        // 0x8039A98C: addiu       $t3, $zero, 0x1
        ctx->r11 = ADD32(0, 0X1);
            goto L_8039A99C;
    }
    // 0x8039A98C: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8039A990: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8039A994: lbu         $t6, 0x12DE($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12DE);
    // 0x8039A998: beq         $t3, $t6, L_8039A9B0
    if (ctx->r11 == ctx->r14) {
        // 0x8039A99C: andi        $t7, $v0, 0x8000
        ctx->r15 = ctx->r2 & 0X8000;
            goto L_8039A9B0;
    }
L_8039A99C:
    // 0x8039A99C: andi        $t7, $v0, 0x8000
    ctx->r15 = ctx->r2 & 0X8000;
    // 0x8039A9A0: beq         $t7, $zero, L_8039B5F4
    if (ctx->r15 == 0) {
        // 0x8039A9A4: lui         $t8, 0x8029
        ctx->r24 = S32(0X8029 << 16);
            goto L_8039B5F4;
    }
    // 0x8039A9A4: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x8039A9A8: lbu         $t8, 0x12DF($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X12DF);
    // 0x8039A9AC: bne         $t3, $t8, L_8039B5F4
    if (ctx->r11 != ctx->r24) {
        // 0x8039A9B0: addiu       $t9, $zero, 0x40
        ctx->r25 = ADD32(0, 0X40);
            goto L_8039B5F4;
    }
L_8039A9B0:
    // 0x8039A9B0: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8039A9B4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039A9B8: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x8039A9BC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039A9C0: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039A9C4: jal         0x8013307C
    // 0x8039A9C8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_24;
    // 0x8039A9C8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_24:
    // 0x8039A9CC: jal         0x80395074
    // 0x8039A9D0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_25;
    // 0x8039A9D0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_25:
    // 0x8039A9D4: lb          $t4, 0x2F($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X2F);
    // 0x8039A9D8: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8039A9DC: bne         $t4, $zero, L_8039B5F4
    if (ctx->r12 != 0) {
        // 0x8039A9E0: nop
    
            goto L_8039B5F4;
    }
    // 0x8039A9E0: nop

    // 0x8039A9E4: sb          $t5, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = ctx->r13;
    // 0x8039A9E8: b           L_8039B5F4
    // 0x8039A9EC: sb          $zero, 0x30($s0)
    MEM_B(0X30, ctx->r16) = 0;
        goto L_8039B5F4;
    // 0x8039A9EC: sb          $zero, 0x30($s0)
    MEM_B(0X30, ctx->r16) = 0;
L_8039A9F0:
    // 0x8039A9F0: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x8039A9F4: andi        $t6, $v0, 0x1000
    ctx->r14 = ctx->r2 & 0X1000;
    // 0x8039A9F8: beq         $t6, $zero, L_8039AA08
    if (ctx->r14 == 0) {
        // 0x8039A9FC: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039AA08;
    }
    // 0x8039A9FC: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x8039AA00: lbu         $t7, 0x12DE($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12DE);
    // 0x8039AA04: beq         $t3, $t7, L_8039AA20
    if (ctx->r11 == ctx->r15) {
        // 0x8039AA08: andi        $t8, $v0, 0x8000
        ctx->r24 = ctx->r2 & 0X8000;
            goto L_8039AA20;
    }
L_8039AA08:
    // 0x8039AA08: andi        $t8, $v0, 0x8000
    ctx->r24 = ctx->r2 & 0X8000;
    // 0x8039AA0C: beq         $t8, $zero, L_8039ABDC
    if (ctx->r24 == 0) {
        // 0x8039AA10: lui         $t9, 0x8029
        ctx->r25 = S32(0X8029 << 16);
            goto L_8039ABDC;
    }
    // 0x8039AA10: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x8039AA14: lbu         $t9, 0x12DF($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X12DF);
    // 0x8039AA18: bnel        $t3, $t9, L_8039ABE0
    if (ctx->r11 != ctx->r25) {
        // 0x8039AA1C: andi        $t6, $v0, 0x4000
        ctx->r14 = ctx->r2 & 0X4000;
            goto L_8039ABE0;
    }
    goto skip_17;
    // 0x8039AA1C: andi        $t6, $v0, 0x4000
    ctx->r14 = ctx->r2 & 0X4000;
    skip_17:
L_8039AA20:
    // 0x8039AA20: jal         0x80395074
    // 0x8039AA24: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_26;
    // 0x8039AA24: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_26:
    // 0x8039AA28: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039AA2C: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x8039AA30: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AA34: bne         $v0, $zero, L_8039AB34
    if (ctx->r2 != 0) {
        // 0x8039AA38: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039AB34;
    }
    // 0x8039AA38: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AA3C: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039AA40: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039AA44: jal         0x8013307C
    // 0x8039AA48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_27;
    // 0x8039AA48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_27:
    // 0x8039AA4C: lb          $t5, 0x2E($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X2E);
    // 0x8039AA50: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8039AA54: addiu       $t7, $t7, -0xD20
    ctx->r15 = ADD32(ctx->r15, -0XD20);
    // 0x8039AA58: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x8039AA5C: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x8039AA60: addu        $a0, $t6, $t7
    ctx->r4 = ADD32(ctx->r14, ctx->r15);
    // 0x8039AA64: addiu       $a1, $a1, -0xDA0
    ctx->r5 = ADD32(ctx->r5, -0XDA0);
    // 0x8039AA68: jal         0x80129158
    // 0x8039AA6C: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_28;
    // 0x8039AA6C: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_28:
    // 0x8039AA70: lb          $v1, 0x2E($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X2E);
    // 0x8039AA74: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039AA78: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039AA7C: lui         $at, 0x4260
    ctx->r1 = S32(0X4260 << 16);
    // 0x8039AA80: beq         $v1, $zero, L_8039AAAC
    if (ctx->r3 == 0) {
        // 0x8039AA84: swc1        $f8, 0x8($s0)
        MEM_W(0X8, ctx->r16) = ctx->f8.u32l;
            goto L_8039AAAC;
    }
    // 0x8039AA84: swc1        $f8, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->f8.u32l;
    // 0x8039AA88: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039AA8C: beq         $v1, $at, L_8039AAC4
    if (ctx->r3 == ctx->r1) {
        // 0x8039AA90: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8039AAC4;
    }
    // 0x8039AA90: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039AA94: beq         $v1, $at, L_8039AAE0
    if (ctx->r3 == ctx->r1) {
        // 0x8039AA98: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8039AAE0;
    }
    // 0x8039AA98: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039AA9C: beql        $v1, $at, L_8039AB00
    if (ctx->r3 == ctx->r1) {
        // 0x8039AAA0: lui         $at, 0x4304
        ctx->r1 = S32(0X4304 << 16);
            goto L_8039AB00;
    }
    goto skip_18;
    // 0x8039AAA0: lui         $at, 0x4304
    ctx->r1 = S32(0X4304 << 16);
    skip_18:
    // 0x8039AAA4: b           L_8039AB14
    // 0x8039AAA8: nop

        goto L_8039AB14;
    // 0x8039AAA8: nop

L_8039AAAC:
    // 0x8039AAAC: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039AAB0: lui         $at, 0x42B0
    ctx->r1 = S32(0X42B0 << 16);
    // 0x8039AAB4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039AAB8: swc1        $f10, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f10.u32l;
    // 0x8039AABC: b           L_8039AB14
    // 0x8039AAC0: swc1        $f16, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f16.u32l;
        goto L_8039AB14;
    // 0x8039AAC0: swc1        $f16, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f16.u32l;
L_8039AAC4:
    // 0x8039AAC4: lui         $at, 0x4304
    ctx->r1 = S32(0X4304 << 16);
    // 0x8039AAC8: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8039AACC: lui         $at, 0x42B0
    ctx->r1 = S32(0X42B0 << 16);
    // 0x8039AAD0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039AAD4: swc1        $f18, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f18.u32l;
    // 0x8039AAD8: b           L_8039AB14
    // 0x8039AADC: swc1        $f4, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f4.u32l;
        goto L_8039AB14;
    // 0x8039AADC: swc1        $f4, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f4.u32l;
L_8039AAE0:
    // 0x8039AAE0: lui         $at, 0x4260
    ctx->r1 = S32(0X4260 << 16);
    // 0x8039AAE4: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039AAE8: lui         $at, 0x4324
    ctx->r1 = S32(0X4324 << 16);
    // 0x8039AAEC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039AAF0: swc1        $f6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f6.u32l;
    // 0x8039AAF4: b           L_8039AB14
    // 0x8039AAF8: swc1        $f8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f8.u32l;
        goto L_8039AB14;
    // 0x8039AAF8: swc1        $f8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f8.u32l;
    // 0x8039AAFC: lui         $at, 0x4304
    ctx->r1 = S32(0X4304 << 16);
L_8039AB00:
    // 0x8039AB00: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039AB04: lui         $at, 0x4324
    ctx->r1 = S32(0X4324 << 16);
    // 0x8039AB08: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039AB0C: swc1        $f10, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->f10.u32l;
    // 0x8039AB10: swc1        $f16, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->f16.u32l;
L_8039AB14:
    // 0x8039AB14: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039AB18: addiu       $v1, $v1, 0x6680
    ctx->r3 = ADD32(ctx->r3, 0X6680);
    // 0x8039AB1C: lh          $t8, 0x18($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X18);
    // 0x8039AB20: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8039AB24: jal         0x8039884C
    // 0x8039AB28: sh          $t9, 0x18($v1)
    MEM_H(0X18, ctx->r3) = ctx->r25;
    func_8039884C_7A9EFC(rdram, ctx);
        goto after_29;
    // 0x8039AB28: sh          $t9, 0x18($v1)
    MEM_H(0X18, ctx->r3) = ctx->r25;
    after_29:
    // 0x8039AB2C: sb          $zero, 0x2D($s0)
    MEM_B(0X2D, ctx->r16) = 0;
    // 0x8039AB30: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
L_8039AB34:
    // 0x8039AB34: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039AB38: bne         $v0, $at, L_8039ABA0
    if (ctx->r2 != ctx->r1) {
        // 0x8039AB3C: addiu       $a0, $zero, 0x93
        ctx->r4 = ADD32(0, 0X93);
            goto L_8039ABA0;
    }
    // 0x8039AB3C: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x8039AB40: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039AB44: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039AB48: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AB4C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AB50: jal         0x8013307C
    // 0x8039AB54: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_30;
    // 0x8039AB54: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_30:
    // 0x8039AB58: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    // 0x8039AB5C: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x8039AB60: sb          $t5, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = ctx->r13;
    // 0x8039AB64: bne         $v0, $zero, L_8039AB74
    if (ctx->r2 != 0) {
        // 0x8039AB68: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_8039AB74;
    }
    // 0x8039AB68: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039AB6C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8039AB70: sb          $t6, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r14;
L_8039AB74:
    // 0x8039AB74: bne         $v0, $at, L_8039AB80
    if (ctx->r2 != ctx->r1) {
        // 0x8039AB78: addiu       $t7, $zero, 0x3
        ctx->r15 = ADD32(0, 0X3);
            goto L_8039AB80;
    }
    // 0x8039AB78: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x8039AB7C: sb          $t7, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r15;
L_8039AB80:
    // 0x8039AB80: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039AB84: bne         $v0, $at, L_8039AB90
    if (ctx->r2 != ctx->r1) {
        // 0x8039AB88: addiu       $t8, $zero, 0x2
        ctx->r24 = ADD32(0, 0X2);
            goto L_8039AB90;
    }
    // 0x8039AB88: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x8039AB8C: sb          $zero, 0x31($s0)
    MEM_B(0X31, ctx->r16) = 0;
L_8039AB90:
    // 0x8039AB90: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039AB94: bnel        $v0, $at, L_8039ABA4
    if (ctx->r2 != ctx->r1) {
        // 0x8039AB98: lb          $t9, 0x30($s0)
        ctx->r25 = MEM_B(ctx->r16, 0X30);
            goto L_8039ABA4;
    }
    goto skip_19;
    // 0x8039AB98: lb          $t9, 0x30($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X30);
    skip_19:
    // 0x8039AB9C: sb          $t8, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r24;
L_8039ABA0:
    // 0x8039ABA0: lb          $t9, 0x30($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X30);
L_8039ABA4:
    // 0x8039ABA4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039ABA8: addiu       $a0, $zero, 0x93
    ctx->r4 = ADD32(0, 0X93);
    // 0x8039ABAC: bne         $t9, $at, L_8039ABD4
    if (ctx->r25 != ctx->r1) {
        // 0x8039ABB0: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_8039ABD4;
    }
    // 0x8039ABB0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039ABB4: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039ABB8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039ABBC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039ABC0: jal         0x8013307C
    // 0x8039ABC4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_31;
    // 0x8039ABC4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_31:
    // 0x8039ABC8: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x8039ABCC: sb          $t5, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = ctx->r13;
    // 0x8039ABD0: sb          $zero, 0x30($s0)
    MEM_B(0X30, ctx->r16) = 0;
L_8039ABD4:
    // 0x8039ABD4: b           L_8039AC8C
    // 0x8039ABD8: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
        goto L_8039AC8C;
    // 0x8039ABD8: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
L_8039ABDC:
    // 0x8039ABDC: andi        $t6, $v0, 0x4000
    ctx->r14 = ctx->r2 & 0X4000;
L_8039ABE0:
    // 0x8039ABE0: beq         $t6, $zero, L_8039AC18
    if (ctx->r14 == 0) {
        // 0x8039ABE4: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039AC18;
    }
    // 0x8039ABE4: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x8039ABE8: lbu         $t7, 0x12E0($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12E0);
    // 0x8039ABEC: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039ABF0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039ABF4: bne         $t3, $t7, L_8039AC18
    if (ctx->r11 != ctx->r15) {
        // 0x8039ABF8: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039AC18;
    }
    // 0x8039ABF8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039ABFC: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x8039AC00: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039AC04: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039AC08: jal         0x8013307C
    // 0x8039AC0C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_32;
    // 0x8039AC0C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_32:
    // 0x8039AC10: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039AC14: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
L_8039AC18:
    // 0x8039AC18: beql        $t2, $zero, L_8039AC50
    if (ctx->r10 == 0) {
        // 0x8039AC1C: lb          $t5, 0x84($sp)
        ctx->r13 = MEM_B(ctx->r29, 0X84);
            goto L_8039AC50;
    }
    goto skip_20;
    // 0x8039AC1C: lb          $t5, 0x84($sp)
    ctx->r13 = MEM_B(ctx->r29, 0X84);
    skip_20:
    // 0x8039AC20: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039AC24: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039AC28: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AC2C: blez        $v0, L_8039AC4C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8039AC30: addiu       $t9, $v0, -0x1
        ctx->r25 = ADD32(ctx->r2, -0X1);
            goto L_8039AC4C;
    }
    // 0x8039AC30: addiu       $t9, $v0, -0x1
    ctx->r25 = ADD32(ctx->r2, -0X1);
    // 0x8039AC34: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039AC38: sb          $t9, 0x30($s0)
    MEM_B(0X30, ctx->r16) = ctx->r25;
    // 0x8039AC3C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039AC40: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AC44: jal         0x8013307C
    // 0x8039AC48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_33;
    // 0x8039AC48: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_33:
L_8039AC4C:
    // 0x8039AC4C: lb          $t5, 0x84($sp)
    ctx->r13 = MEM_B(ctx->r29, 0X84);
L_8039AC50:
    // 0x8039AC50: beql        $t5, $zero, L_8039AC8C
    if (ctx->r13 == 0) {
        // 0x8039AC54: lb          $v0, 0x2E($s0)
        ctx->r2 = MEM_B(ctx->r16, 0X2E);
            goto L_8039AC8C;
    }
    goto skip_21;
    // 0x8039AC54: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    skip_21:
    // 0x8039AC58: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039AC5C: addiu       $a0, $zero, 0x91
    ctx->r4 = ADD32(0, 0X91);
    // 0x8039AC60: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AC64: slti        $at, $v0, 0x2
    ctx->r1 = SIGNED(ctx->r2) < 0X2 ? 1 : 0;
    // 0x8039AC68: beq         $at, $zero, L_8039AC88
    if (ctx->r1 == 0) {
        // 0x8039AC6C: addiu       $t6, $v0, 0x1
        ctx->r14 = ADD32(ctx->r2, 0X1);
            goto L_8039AC88;
    }
    // 0x8039AC6C: addiu       $t6, $v0, 0x1
    ctx->r14 = ADD32(ctx->r2, 0X1);
    // 0x8039AC70: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x8039AC74: sb          $t6, 0x30($s0)
    MEM_B(0X30, ctx->r16) = ctx->r14;
    // 0x8039AC78: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039AC7C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AC80: jal         0x8013307C
    // 0x8039AC84: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_34;
    // 0x8039AC84: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_34:
L_8039AC88:
    // 0x8039AC88: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
L_8039AC8C:
    // 0x8039AC8C: addiu       $t9, $zero, 0xA8
    ctx->r25 = ADD32(0, 0XA8);
    // 0x8039AC90: xori        $v1, $v0, 0x1
    ctx->r3 = ctx->r2 ^ 0X1;
    // 0x8039AC94: xori        $a0, $v0, 0x2
    ctx->r4 = ctx->r2 ^ 0X2;
    // 0x8039AC98: xori        $a1, $v0, 0x3
    ctx->r5 = ctx->r2 ^ 0X3;
    // 0x8039AC9C: sltiu       $a1, $a1, 0x1
    ctx->r5 = ctx->r5 < 0X1 ? 1 : 0;
    // 0x8039ACA0: sltiu       $a0, $a0, 0x1
    ctx->r4 = ctx->r4 < 0X1 ? 1 : 0;
    // 0x8039ACA4: bne         $v0, $zero, L_8039ACBC
    if (ctx->r2 != 0) {
        // 0x8039ACA8: sltiu       $v1, $v1, 0x1
        ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
            goto L_8039ACBC;
    }
    // 0x8039ACA8: sltiu       $v1, $v1, 0x1
    ctx->r3 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8039ACAC: addiu       $t0, $zero, 0x3A
    ctx->r8 = ADD32(0, 0X3A);
    // 0x8039ACB0: addiu       $v0, $zero, 0x58
    ctx->r2 = ADD32(0, 0X58);
    // 0x8039ACB4: sh          $v0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r2;
    // 0x8039ACB8: sh          $t0, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r8;
L_8039ACBC:
    // 0x8039ACBC: lh          $v0, 0x7C($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X7C);
    // 0x8039ACC0: beq         $v1, $zero, L_8039ACD0
    if (ctx->r3 == 0) {
        // 0x8039ACC4: lh          $t0, 0x7E($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X7E);
            goto L_8039ACD0;
    }
    // 0x8039ACC4: lh          $t0, 0x7E($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7E);
    // 0x8039ACC8: addiu       $t0, $zero, 0x86
    ctx->r8 = ADD32(0, 0X86);
    // 0x8039ACCC: addiu       $v0, $zero, 0x58
    ctx->r2 = ADD32(0, 0X58);
L_8039ACD0:
    // 0x8039ACD0: beq         $a0, $zero, L_8039ACE0
    if (ctx->r4 == 0) {
        // 0x8039ACD4: nop
    
            goto L_8039ACE0;
    }
    // 0x8039ACD4: nop

    // 0x8039ACD8: addiu       $t0, $zero, 0x3A
    ctx->r8 = ADD32(0, 0X3A);
    // 0x8039ACDC: addiu       $v0, $zero, 0xA4
    ctx->r2 = ADD32(0, 0XA4);
L_8039ACE0:
    // 0x8039ACE0: beq         $a1, $zero, L_8039ACF0
    if (ctx->r5 == 0) {
        // 0x8039ACE4: lui         $a0, 0x801E
        ctx->r4 = S32(0X801E << 16);
            goto L_8039ACF0;
    }
    // 0x8039ACE4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039ACE8: addiu       $t0, $zero, 0x86
    ctx->r8 = ADD32(0, 0X86);
    // 0x8039ACEC: addiu       $v0, $zero, 0xA4
    ctx->r2 = ADD32(0, 0XA4);
L_8039ACF0:
    // 0x8039ACF0: addiu       $a1, $t0, -0x26
    ctx->r5 = ADD32(ctx->r8, -0X26);
    // 0x8039ACF4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x8039ACF8: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039ACFC: addiu       $a2, $v0, -0x18
    ctx->r6 = ADD32(ctx->r2, -0X18);
    // 0x8039AD00: addiu       $a3, $t0, 0x24
    ctx->r7 = ADD32(ctx->r8, 0X24);
    // 0x8039AD04: sll         $t6, $a3, 16
    ctx->r14 = S32(ctx->r7 << 16);
    // 0x8039AD08: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x8039AD0C: addiu       $t8, $v0, 0x14
    ctx->r24 = ADD32(ctx->r2, 0X14);
    // 0x8039AD10: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039AD14: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8039AD18: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039AD1C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039AD20: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8039AD24: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039AD28: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8039AD2C: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x8039AD30: sh          $v0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r2;
    // 0x8039AD34: jal         0x8012AD30
    // 0x8039AD38: sh          $t0, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r8;
    draw_rectangle(rdram, ctx);
        goto after_35;
    // 0x8039AD38: sh          $t0, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r8;
    after_35:
    // 0x8039AD3C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039AD40: jal         0x8012C1F0
    // 0x8039AD44: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_36;
    // 0x8039AD44: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_36:
    // 0x8039AD48: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039AD4C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8039AD50: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039AD54: jal         0x8012C248
    // 0x8039AD58: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_37;
    // 0x8039AD58: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_37:
    // 0x8039AD5C: lb          $t4, 0x30($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X30);
    // 0x8039AD60: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039AD64: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039AD68: bne         $t4, $zero, L_8039AD8C
    if (ctx->r12 != 0) {
        // 0x8039AD6C: addiu       $a2, $zero, 0x80
        ctx->r6 = ADD32(0, 0X80);
            goto L_8039AD8C;
    }
    // 0x8039AD6C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039AD70: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039AD74: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039AD78: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039AD7C: jal         0x8012C214
    // 0x8039AD80: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_38;
    // 0x8039AD80: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_38:
    // 0x8039AD84: b           L_8039AD94
    // 0x8039AD88: nop

        goto L_8039AD94;
    // 0x8039AD88: nop

L_8039AD8C:
    // 0x8039AD8C: jal         0x8012C214
    // 0x8039AD90: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_39;
    // 0x8039AD90: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_39:
L_8039AD94:
    // 0x8039AD94: jal         0x80130A90
    // 0x8039AD98: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    get_message_address_by_id(rdram, ctx);
        goto after_40;
    // 0x8039AD98: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    after_40:
    // 0x8039AD9C: lh          $a3, 0x7C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7C);
    // 0x8039ADA0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039ADA4: lwc1        $f18, 0x74B4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039ADA8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039ADAC: lwc1        $f4, 0x74B8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039ADB0: lhu         $a2, 0x7E($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X7E);
    // 0x8039ADB4: addiu       $a3, $a3, -0x12
    ctx->r7 = ADD32(ctx->r7, -0X12);
    // 0x8039ADB8: andi        $t5, $a3, 0xFFFF
    ctx->r13 = ctx->r7 & 0XFFFF;
    // 0x8039ADBC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039ADC0: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039ADC4: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x8039ADC8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039ADCC: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039ADD0: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x8039ADD4: jal         0x8012C978
    // 0x8039ADD8: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    display_text_centered(rdram, ctx);
        goto after_41;
    // 0x8039ADD8: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    after_41:
    // 0x8039ADDC: lb          $t6, 0x30($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X30);
    // 0x8039ADE0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039ADE4: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039ADE8: bne         $t6, $at, L_8039AE0C
    if (ctx->r14 != ctx->r1) {
        // 0x8039ADEC: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_8039AE0C;
    }
    // 0x8039ADEC: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039ADF0: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039ADF4: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039ADF8: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039ADFC: jal         0x8012C214
    // 0x8039AE00: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_42;
    // 0x8039AE00: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_42:
    // 0x8039AE04: b           L_8039AE18
    // 0x8039AE08: nop

        goto L_8039AE18;
    // 0x8039AE08: nop

L_8039AE0C:
    // 0x8039AE0C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039AE10: jal         0x8012C214
    // 0x8039AE14: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_43;
    // 0x8039AE14: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_43:
L_8039AE18:
    // 0x8039AE18: jal         0x80130A90
    // 0x8039AE1C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    get_message_address_by_id(rdram, ctx);
        goto after_44;
    // 0x8039AE1C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_44:
    // 0x8039AE20: lh          $a3, 0x7C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7C);
    // 0x8039AE24: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039AE28: lwc1        $f6, 0x74B4($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039AE2C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039AE30: lwc1        $f8, 0x74B8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039AE34: addiu       $a3, $a3, -0x6
    ctx->r7 = ADD32(ctx->r7, -0X6);
    // 0x8039AE38: andi        $t7, $a3, 0xFFFF
    ctx->r15 = ctx->r7 & 0XFFFF;
    // 0x8039AE3C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039AE40: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039AE44: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x8039AE48: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039AE4C: lhu         $a2, 0x4A($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X4A);
    // 0x8039AE50: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039AE54: jal         0x8012C978
    // 0x8039AE58: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text_centered(rdram, ctx);
        goto after_45;
    // 0x8039AE58: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_45:
    // 0x8039AE5C: lb          $t8, 0x30($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X30);
    // 0x8039AE60: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039AE64: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039AE68: bne         $t8, $at, L_8039AE8C
    if (ctx->r24 != ctx->r1) {
        // 0x8039AE6C: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_8039AE8C;
    }
    // 0x8039AE6C: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039AE70: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039AE74: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039AE78: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039AE7C: jal         0x8012C214
    // 0x8039AE80: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_46;
    // 0x8039AE80: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_46:
    // 0x8039AE84: b           L_8039AE98
    // 0x8039AE88: nop

        goto L_8039AE98;
    // 0x8039AE88: nop

L_8039AE8C:
    // 0x8039AE8C: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039AE90: jal         0x8012C214
    // 0x8039AE94: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_47;
    // 0x8039AE94: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_47:
L_8039AE98:
    // 0x8039AE98: jal         0x80130A90
    // 0x8039AE9C: addiu       $a0, $zero, 0xB
    ctx->r4 = ADD32(0, 0XB);
    get_message_address_by_id(rdram, ctx);
        goto after_48;
    // 0x8039AE9C: addiu       $a0, $zero, 0xB
    ctx->r4 = ADD32(0, 0XB);
    after_48:
    // 0x8039AEA0: lh          $a3, 0x7C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7C);
    // 0x8039AEA4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039AEA8: lwc1        $f10, 0x74B4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039AEAC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039AEB0: lwc1        $f16, 0x74B8($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039AEB4: addiu       $a3, $a3, 0x6
    ctx->r7 = ADD32(ctx->r7, 0X6);
    // 0x8039AEB8: andi        $t9, $a3, 0xFFFF
    ctx->r25 = ctx->r7 & 0XFFFF;
    // 0x8039AEBC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039AEC0: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039AEC4: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8039AEC8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039AECC: lhu         $a2, 0x4A($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X4A);
    // 0x8039AED0: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8039AED4: jal         0x8012C978
    // 0x8039AED8: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    display_text_centered(rdram, ctx);
        goto after_49;
    // 0x8039AED8: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    after_49:
    // 0x8039AEDC: b           L_8039B5F4
    // 0x8039AEE0: nop

        goto L_8039B5F4;
    // 0x8039AEE0: nop

L_8039AEE4:
    // 0x8039AEE4: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x8039AEE8: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x8039AEEC: andi        $t4, $v0, 0x1000
    ctx->r12 = ctx->r2 & 0X1000;
    // 0x8039AEF0: beq         $t4, $zero, L_8039AF04
    if (ctx->r12 == 0) {
        // 0x8039AEF4: andi        $t6, $v0, 0x8000
        ctx->r14 = ctx->r2 & 0X8000;
            goto L_8039AF04;
    }
    // 0x8039AEF4: andi        $t6, $v0, 0x8000
    ctx->r14 = ctx->r2 & 0X8000;
    // 0x8039AEF8: lbu         $t5, 0x12DE($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X12DE);
    // 0x8039AEFC: beq         $t3, $t5, L_8039AF18
    if (ctx->r11 == ctx->r13) {
        // 0x8039AF00: nop
    
            goto L_8039AF18;
    }
    // 0x8039AF00: nop

L_8039AF04:
    // 0x8039AF04: beq         $t6, $zero, L_8039AF9C
    if (ctx->r14 == 0) {
        // 0x8039AF08: lui         $t7, 0x8029
        ctx->r15 = S32(0X8029 << 16);
            goto L_8039AF9C;
    }
    // 0x8039AF08: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x8039AF0C: lbu         $t7, 0x12DF($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X12DF);
    // 0x8039AF10: bnel        $t3, $t7, L_8039AFA0
    if (ctx->r11 != ctx->r15) {
        // 0x8039AF14: andi        $t4, $v0, 0x4000
        ctx->r12 = ctx->r2 & 0X4000;
            goto L_8039AFA0;
    }
    goto skip_22;
    // 0x8039AF14: andi        $t4, $v0, 0x4000
    ctx->r12 = ctx->r2 & 0X4000;
    skip_22:
L_8039AF18:
    // 0x8039AF18: jal         0x80395074
    // 0x8039AF1C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_50;
    // 0x8039AF1C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_50:
    // 0x8039AF20: lb          $t8, 0x2E($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X2E);
    // 0x8039AF24: lb          $t4, 0x31($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X31);
    // 0x8039AF28: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8039AF2C: addiu       $v0, $v0, -0xD20
    ctx->r2 = ADD32(ctx->r2, -0XD20);
    // 0x8039AF30: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x8039AF34: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x8039AF38: addu        $a1, $v0, $t5
    ctx->r5 = ADD32(ctx->r2, ctx->r13);
    // 0x8039AF3C: addu        $a0, $v0, $t9
    ctx->r4 = ADD32(ctx->r2, ctx->r25);
    // 0x8039AF40: jal         0x80129158
    // 0x8039AF44: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_51;
    // 0x8039AF44: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_51:
    // 0x8039AF48: lb          $t6, 0x2E($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X2E);
    // 0x8039AF4C: lui         $t8, 0x8024
    ctx->r24 = S32(0X8024 << 16);
    // 0x8039AF50: addiu       $t8, $t8, -0xD20
    ctx->r24 = ADD32(ctx->r24, -0XD20);
    // 0x8039AF54: lui         $a1, 0x8024
    ctx->r5 = S32(0X8024 << 16);
    // 0x8039AF58: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x8039AF5C: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    // 0x8039AF60: addiu       $a1, $a1, -0xDA0
    ctx->r5 = ADD32(ctx->r5, -0XDA0);
    // 0x8039AF64: jal         0x80129158
    // 0x8039AF68: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_52;
    // 0x8039AF68: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_52:
    // 0x8039AF6C: jal         0x80130C30
    // 0x8039AF70: lb          $a0, 0x31($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X31);
    write_eeprom(rdram, ctx);
        goto after_53;
    // 0x8039AF70: lb          $a0, 0x31($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X31);
    after_53:
    // 0x8039AF74: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8039AF78: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
    // 0x8039AF7C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039AF80: addiu       $a0, $zero, 0x8F
    ctx->r4 = ADD32(0, 0X8F);
    // 0x8039AF84: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AF88: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AF8C: jal         0x8013307C
    // 0x8039AF90: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_54;
    // 0x8039AF90: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_54:
    // 0x8039AF94: b           L_8039B5F4
    // 0x8039AF98: nop

        goto L_8039B5F4;
    // 0x8039AF98: nop

L_8039AF9C:
    // 0x8039AF9C: andi        $t4, $v0, 0x4000
    ctx->r12 = ctx->r2 & 0X4000;
L_8039AFA0:
    // 0x8039AFA0: beq         $t4, $zero, L_8039AFEC
    if (ctx->r12 == 0) {
        // 0x8039AFA4: lui         $t5, 0x8029
        ctx->r13 = S32(0X8029 << 16);
            goto L_8039AFEC;
    }
    // 0x8039AFA4: lui         $t5, 0x8029
    ctx->r13 = S32(0X8029 << 16);
    // 0x8039AFA8: lbu         $t5, 0x12E0($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X12E0);
    // 0x8039AFAC: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039AFB0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039AFB4: bne         $t3, $t5, L_8039AFEC
    if (ctx->r11 != ctx->r13) {
        // 0x8039AFB8: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039AFEC;
    }
    // 0x8039AFB8: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039AFBC: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x8039AFC0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039AFC4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039AFC8: sb          $t0, 0x83($sp)
    MEM_B(0X83, ctx->r29) = ctx->r8;
    // 0x8039AFCC: sb          $t1, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r9;
    // 0x8039AFD0: jal         0x8013307C
    // 0x8039AFD4: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_55;
    // 0x8039AFD4: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_55:
    // 0x8039AFD8: lb          $t0, 0x83($sp)
    ctx->r8 = MEM_B(ctx->r29, 0X83);
    // 0x8039AFDC: lb          $t1, 0x82($sp)
    ctx->r9 = MEM_B(ctx->r29, 0X82);
    // 0x8039AFE0: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039AFE4: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
    // 0x8039AFE8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039AFEC:
    // 0x8039AFEC: beq         $t0, $zero, L_8039B04C
    if (ctx->r8 == 0) {
        // 0x8039AFF0: nop
    
            goto L_8039B04C;
    }
    // 0x8039AFF0: nop

    // 0x8039AFF4: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039AFF8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039AFFC: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x8039B000: beq         $t3, $v0, L_8039B00C
    if (ctx->r11 == ctx->r2) {
        // 0x8039B004: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_8039B00C;
    }
    // 0x8039B004: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    // 0x8039B008: bne         $v0, $at, L_8039B04C
    if (ctx->r2 != ctx->r1) {
        // 0x8039B00C: addiu       $t8, $zero, 0x40
        ctx->r24 = ADD32(0, 0X40);
            goto L_8039B04C;
    }
L_8039B00C:
    // 0x8039B00C: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x8039B010: sb          $t7, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r15;
    // 0x8039B014: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039B018: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B01C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B020: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039B024: sb          $t1, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r9;
    // 0x8039B028: jal         0x8013307C
    // 0x8039B02C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_56;
    // 0x8039B02C: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_56:
    // 0x8039B030: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B034: lb          $t9, 0x2E($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2E);
    // 0x8039B038: lb          $t1, 0x82($sp)
    ctx->r9 = MEM_B(ctx->r29, 0X82);
    // 0x8039B03C: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039B040: bne         $v0, $t9, L_8039B04C
    if (ctx->r2 != ctx->r25) {
        // 0x8039B044: addiu       $t4, $v0, 0x1
        ctx->r12 = ADD32(ctx->r2, 0X1);
            goto L_8039B04C;
    }
    // 0x8039B044: addiu       $t4, $v0, 0x1
    ctx->r12 = ADD32(ctx->r2, 0X1);
    // 0x8039B048: sb          $t4, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r12;
L_8039B04C:
    // 0x8039B04C: beq         $t1, $zero, L_8039B0A8
    if (ctx->r9 == 0) {
        // 0x8039B050: nop
    
            goto L_8039B0A8;
    }
    // 0x8039B050: nop

    // 0x8039B054: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B058: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039B05C: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x8039B060: beq         $v0, $zero, L_8039B06C
    if (ctx->r2 == 0) {
        // 0x8039B064: addiu       $t5, $v0, 0x1
        ctx->r13 = ADD32(ctx->r2, 0X1);
            goto L_8039B06C;
    }
    // 0x8039B064: addiu       $t5, $v0, 0x1
    ctx->r13 = ADD32(ctx->r2, 0X1);
    // 0x8039B068: bne         $v0, $at, L_8039B0A8
    if (ctx->r2 != ctx->r1) {
        // 0x8039B06C: addiu       $t6, $zero, 0x40
        ctx->r14 = ADD32(0, 0X40);
            goto L_8039B0A8;
    }
L_8039B06C:
    // 0x8039B06C: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x8039B070: sb          $t5, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r13;
    // 0x8039B074: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039B078: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B07C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B080: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039B084: jal         0x8013307C
    // 0x8039B088: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_57;
    // 0x8039B088: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_57:
    // 0x8039B08C: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B090: lb          $t7, 0x2E($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X2E);
    // 0x8039B094: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039B098: addiu       $t8, $v0, -0x1
    ctx->r24 = ADD32(ctx->r2, -0X1);
    // 0x8039B09C: bne         $v0, $t7, L_8039B0A8
    if (ctx->r2 != ctx->r15) {
        // 0x8039B0A0: nop
    
            goto L_8039B0A8;
    }
    // 0x8039B0A0: nop

    // 0x8039B0A4: sb          $t8, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r24;
L_8039B0A8:
    // 0x8039B0A8: beql        $t2, $zero, L_8039B104
    if (ctx->r10 == 0) {
        // 0x8039B0AC: lb          $t7, 0x84($sp)
        ctx->r15 = MEM_B(ctx->r29, 0X84);
            goto L_8039B104;
    }
    goto skip_23;
    // 0x8039B0AC: lb          $t7, 0x84($sp)
    ctx->r15 = MEM_B(ctx->r29, 0X84);
    skip_23:
    // 0x8039B0B0: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B0B4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039B0B8: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x8039B0BC: beq         $v0, $at, L_8039B0CC
    if (ctx->r2 == ctx->r1) {
        // 0x8039B0C0: addiu       $t9, $v0, -0x2
        ctx->r25 = ADD32(ctx->r2, -0X2);
            goto L_8039B0CC;
    }
    // 0x8039B0C0: addiu       $t9, $v0, -0x2
    ctx->r25 = ADD32(ctx->r2, -0X2);
    // 0x8039B0C4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039B0C8: bne         $v0, $at, L_8039B100
    if (ctx->r2 != ctx->r1) {
        // 0x8039B0CC: addiu       $t4, $zero, 0x40
        ctx->r12 = ADD32(0, 0X40);
            goto L_8039B100;
    }
L_8039B0CC:
    // 0x8039B0CC: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x8039B0D0: sb          $t9, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r25;
    // 0x8039B0D4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039B0D8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B0DC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B0E0: jal         0x8013307C
    // 0x8039B0E4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_58;
    // 0x8039B0E4: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_58:
    // 0x8039B0E8: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B0EC: lb          $t5, 0x2E($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X2E);
    // 0x8039B0F0: addiu       $t6, $v0, 0x2
    ctx->r14 = ADD32(ctx->r2, 0X2);
    // 0x8039B0F4: bnel        $v0, $t5, L_8039B104
    if (ctx->r2 != ctx->r13) {
        // 0x8039B0F8: lb          $t7, 0x84($sp)
        ctx->r15 = MEM_B(ctx->r29, 0X84);
            goto L_8039B104;
    }
    goto skip_24;
    // 0x8039B0F8: lb          $t7, 0x84($sp)
    ctx->r15 = MEM_B(ctx->r29, 0X84);
    skip_24:
    // 0x8039B0FC: sb          $t6, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r14;
L_8039B100:
    // 0x8039B100: lb          $t7, 0x84($sp)
    ctx->r15 = MEM_B(ctx->r29, 0X84);
L_8039B104:
    // 0x8039B104: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8039B108: beql        $t7, $zero, L_8039B15C
    if (ctx->r15 == 0) {
        // 0x8039B10C: lb          $v0, 0x2E($s0)
        ctx->r2 = MEM_B(ctx->r16, 0X2E);
            goto L_8039B15C;
    }
    goto skip_25;
    // 0x8039B10C: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    skip_25:
    // 0x8039B110: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B114: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x8039B118: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B11C: beq         $v0, $zero, L_8039B128
    if (ctx->r2 == 0) {
        // 0x8039B120: addiu       $t8, $v0, 0x2
        ctx->r24 = ADD32(ctx->r2, 0X2);
            goto L_8039B128;
    }
    // 0x8039B120: addiu       $t8, $v0, 0x2
    ctx->r24 = ADD32(ctx->r2, 0X2);
    // 0x8039B124: bne         $t3, $v0, L_8039B158
    if (ctx->r11 != ctx->r2) {
        // 0x8039B128: addiu       $t9, $zero, 0x40
        ctx->r25 = ADD32(0, 0X40);
            goto L_8039B158;
    }
L_8039B128:
    // 0x8039B128: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x8039B12C: sb          $t8, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r24;
    // 0x8039B130: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8039B134: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B138: jal         0x8013307C
    // 0x8039B13C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_59;
    // 0x8039B13C: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_59:
    // 0x8039B140: lb          $v0, 0x31($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X31);
    // 0x8039B144: lb          $t4, 0x2E($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X2E);
    // 0x8039B148: addiu       $t5, $v0, -0x2
    ctx->r13 = ADD32(ctx->r2, -0X2);
    // 0x8039B14C: bnel        $v0, $t4, L_8039B15C
    if (ctx->r2 != ctx->r12) {
        // 0x8039B150: lb          $v0, 0x2E($s0)
        ctx->r2 = MEM_B(ctx->r16, 0X2E);
            goto L_8039B15C;
    }
    goto skip_26;
    // 0x8039B150: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    skip_26:
    // 0x8039B154: sb          $t5, 0x31($s0)
    MEM_B(0X31, ctx->r16) = ctx->r13;
L_8039B158:
    // 0x8039B158: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
L_8039B15C:
    // 0x8039B15C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B160: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039B164: bne         $v0, $zero, L_8039B17C
    if (ctx->r2 != 0) {
        // 0x8039B168: addiu       $a0, $a0, -0x6184
        ctx->r4 = ADD32(ctx->r4, -0X6184);
            goto L_8039B17C;
    }
    // 0x8039B168: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B16C: addiu       $v1, $zero, 0x3A
    ctx->r3 = ADD32(0, 0X3A);
    // 0x8039B170: addiu       $t0, $zero, 0x58
    ctx->r8 = ADD32(0, 0X58);
    // 0x8039B174: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    // 0x8039B178: sh          $v1, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r3;
L_8039B17C:
    // 0x8039B17C: lh          $v1, 0x7E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X7E);
    // 0x8039B180: bne         $v0, $at, L_8039B190
    if (ctx->r2 != ctx->r1) {
        // 0x8039B184: lh          $t0, 0x7C($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X7C);
            goto L_8039B190;
    }
    // 0x8039B184: lh          $t0, 0x7C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7C);
    // 0x8039B188: addiu       $v1, $zero, 0x86
    ctx->r3 = ADD32(0, 0X86);
    // 0x8039B18C: addiu       $t0, $zero, 0x58
    ctx->r8 = ADD32(0, 0X58);
L_8039B190:
    // 0x8039B190: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039B194: bne         $v0, $at, L_8039B1A4
    if (ctx->r2 != ctx->r1) {
        // 0x8039B198: addiu       $t7, $zero, 0xA8
        ctx->r15 = ADD32(0, 0XA8);
            goto L_8039B1A4;
    }
    // 0x8039B198: addiu       $t7, $zero, 0xA8
    ctx->r15 = ADD32(0, 0XA8);
    // 0x8039B19C: addiu       $v1, $zero, 0x3A
    ctx->r3 = ADD32(0, 0X3A);
    // 0x8039B1A0: addiu       $t0, $zero, 0xA4
    ctx->r8 = ADD32(0, 0XA4);
L_8039B1A4:
    // 0x8039B1A4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039B1A8: bnel        $v0, $at, L_8039B1BC
    if (ctx->r2 != ctx->r1) {
        // 0x8039B1AC: addiu       $a1, $v1, -0x1E
        ctx->r5 = ADD32(ctx->r3, -0X1E);
            goto L_8039B1BC;
    }
    goto skip_27;
    // 0x8039B1AC: addiu       $a1, $v1, -0x1E
    ctx->r5 = ADD32(ctx->r3, -0X1E);
    skip_27:
    // 0x8039B1B0: addiu       $v1, $zero, 0x86
    ctx->r3 = ADD32(0, 0X86);
    // 0x8039B1B4: addiu       $t0, $zero, 0xA4
    ctx->r8 = ADD32(0, 0XA4);
    // 0x8039B1B8: addiu       $a1, $v1, -0x1E
    ctx->r5 = ADD32(ctx->r3, -0X1E);
L_8039B1BC:
    // 0x8039B1BC: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8039B1C0: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039B1C4: addiu       $a2, $t0, -0x18
    ctx->r6 = ADD32(ctx->r8, -0X18);
    // 0x8039B1C8: addiu       $a3, $v1, 0x1C
    ctx->r7 = ADD32(ctx->r3, 0X1C);
    // 0x8039B1CC: sll         $t4, $a3, 16
    ctx->r12 = S32(ctx->r7 << 16);
    // 0x8039B1D0: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8039B1D4: addiu       $t6, $t0, 0x14
    ctx->r14 = ADD32(ctx->r8, 0X14);
    // 0x8039B1D8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039B1DC: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039B1E0: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8039B1E4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8039B1E8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039B1EC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8039B1F0: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x8039B1F4: sh          $v1, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r3;
    // 0x8039B1F8: jal         0x8012AD30
    // 0x8039B1FC: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    draw_rectangle(rdram, ctx);
        goto after_60;
    // 0x8039B1FC: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    after_60:
    // 0x8039B200: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B204: jal         0x8012C1F0
    // 0x8039B208: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_61;
    // 0x8039B208: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_61:
    // 0x8039B20C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039B210: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8039B214: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039B218: jal         0x8012C248
    // 0x8039B21C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_62;
    // 0x8039B21C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_62:
    // 0x8039B220: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039B224: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039B228: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039B22C: jal         0x8012C214
    // 0x8039B230: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_63;
    // 0x8039B230: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_63:
    // 0x8039B234: jal         0x80130A90
    // 0x8039B238: addiu       $a0, $zero, 0xC
    ctx->r4 = ADD32(0, 0XC);
    get_message_address_by_id(rdram, ctx);
        goto after_64;
    // 0x8039B238: addiu       $a0, $zero, 0xC
    ctx->r4 = ADD32(0, 0XC);
    after_64:
    // 0x8039B23C: lh          $a3, 0x7C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7C);
    // 0x8039B240: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B244: lwc1        $f18, 0x74B4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039B248: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B24C: lwc1        $f4, 0x74B8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039B250: lhu         $a2, 0x7E($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X7E);
    // 0x8039B254: addiu       $a3, $a3, -0xC
    ctx->r7 = ADD32(ctx->r7, -0XC);
    // 0x8039B258: andi        $t8, $a3, 0xFFFF
    ctx->r24 = ctx->r7 & 0XFFFF;
    // 0x8039B25C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B260: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B264: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8039B268: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B26C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039B270: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x8039B274: jal         0x8012C978
    // 0x8039B278: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    display_text_centered(rdram, ctx);
        goto after_65;
    // 0x8039B278: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    after_65:
    // 0x8039B27C: jal         0x80130A90
    // 0x8039B280: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    get_message_address_by_id(rdram, ctx);
        goto after_66;
    // 0x8039B280: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    after_66:
    // 0x8039B284: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B288: lwc1        $f6, 0x74B4($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039B28C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B290: lwc1        $f8, 0x74B8($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039B294: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B298: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B29C: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B2A0: lhu         $a2, 0x4A($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X4A);
    // 0x8039B2A4: lhu         $a3, 0x7C($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X7C);
    // 0x8039B2A8: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039B2AC: jal         0x8012C978
    // 0x8039B2B0: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    display_text_centered(rdram, ctx);
        goto after_67;
    // 0x8039B2B0: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_67:
    // 0x8039B2B4: b           L_8039B5F4
    // 0x8039B2B8: nop

        goto L_8039B5F4;
    // 0x8039B2B8: nop

    // 0x8039B2BC: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
L_8039B2C0:
    // 0x8039B2C0: lui         $t4, 0x8029
    ctx->r12 = S32(0X8029 << 16);
    // 0x8039B2C4: andi        $t9, $v0, 0x1000
    ctx->r25 = ctx->r2 & 0X1000;
    // 0x8039B2C8: beq         $t9, $zero, L_8039B2DC
    if (ctx->r25 == 0) {
        // 0x8039B2CC: andi        $t5, $v0, 0x8000
        ctx->r13 = ctx->r2 & 0X8000;
            goto L_8039B2DC;
    }
    // 0x8039B2CC: andi        $t5, $v0, 0x8000
    ctx->r13 = ctx->r2 & 0X8000;
    // 0x8039B2D0: lbu         $t4, 0x12DE($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X12DE);
    // 0x8039B2D4: beql        $t3, $t4, L_8039B2F0
    if (ctx->r11 == ctx->r12) {
        // 0x8039B2D8: addiu       $t7, $zero, 0x40
        ctx->r15 = ADD32(0, 0X40);
            goto L_8039B2F0;
    }
    goto skip_28;
    // 0x8039B2D8: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    skip_28:
L_8039B2DC:
    // 0x8039B2DC: beq         $t5, $zero, L_8039B368
    if (ctx->r13 == 0) {
        // 0x8039B2E0: lui         $t6, 0x8029
        ctx->r14 = S32(0X8029 << 16);
            goto L_8039B368;
    }
    // 0x8039B2E0: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8039B2E4: lbu         $t6, 0x12DF($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12DF);
    // 0x8039B2E8: bne         $t3, $t6, L_8039B368
    if (ctx->r11 != ctx->r14) {
        // 0x8039B2EC: addiu       $t7, $zero, 0x40
        ctx->r15 = ADD32(0, 0X40);
            goto L_8039B368;
    }
    // 0x8039B2EC: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
L_8039B2F0:
    // 0x8039B2F0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039B2F4: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039B2F8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B2FC: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B300: jal         0x8013307C
    // 0x8039B304: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_68;
    // 0x8039B304: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_68:
    // 0x8039B308: jal         0x80395074
    // 0x8039B30C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80395074_7A6724(rdram, ctx);
        goto after_69;
    // 0x8039B30C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_69:
    // 0x8039B310: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039B314: lui         $a0, 0x8024
    ctx->r4 = S32(0X8024 << 16);
    // 0x8039B318: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039B31C: bne         $v0, $zero, L_8039B328
    if (ctx->r2 != 0) {
        // 0x8039B320: addiu       $a0, $a0, -0xDA0
        ctx->r4 = ADD32(ctx->r4, -0XDA0);
            goto L_8039B328;
    }
    // 0x8039B320: addiu       $a0, $a0, -0xDA0
    ctx->r4 = ADD32(ctx->r4, -0XDA0);
    // 0x8039B324: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
L_8039B328:
    // 0x8039B328: bne         $v0, $at, L_8039B5F4
    if (ctx->r2 != ctx->r1) {
        // 0x8039B32C: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_8039B5F4;
    }
    // 0x8039B32C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B330: jal         0x80129090
    // 0x8039B334: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memset_bytes(rdram, ctx);
        goto after_70;
    // 0x8039B334: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_70:
    // 0x8039B338: lb          $t8, 0x2E($s0)
    ctx->r24 = MEM_B(ctx->r16, 0X2E);
    // 0x8039B33C: lui         $t4, 0x8024
    ctx->r12 = S32(0X8024 << 16);
    // 0x8039B340: addiu       $t4, $t4, -0xD20
    ctx->r12 = ADD32(ctx->r12, -0XD20);
    // 0x8039B344: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x8039B348: addu        $a0, $t9, $t4
    ctx->r4 = ADD32(ctx->r25, ctx->r12);
    // 0x8039B34C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B350: jal         0x80129090
    // 0x8039B354: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memset_bytes(rdram, ctx);
        goto after_71;
    // 0x8039B354: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_71:
    // 0x8039B358: jal         0x80130C30
    // 0x8039B35C: lb          $a0, 0x2E($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X2E);
    write_eeprom(rdram, ctx);
        goto after_72;
    // 0x8039B35C: lb          $a0, 0x2E($s0)
    ctx->r4 = MEM_B(ctx->r16, 0X2E);
    after_72:
    // 0x8039B360: b           L_8039B5F4
    // 0x8039B364: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
        goto L_8039B5F4;
    // 0x8039B364: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
L_8039B368:
    // 0x8039B368: andi        $t5, $v0, 0x4000
    ctx->r13 = ctx->r2 & 0X4000;
    // 0x8039B36C: beq         $t5, $zero, L_8039B3A8
    if (ctx->r13 == 0) {
        // 0x8039B370: lui         $t6, 0x8029
        ctx->r14 = S32(0X8029 << 16);
            goto L_8039B3A8;
    }
    // 0x8039B370: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8039B374: lbu         $t6, 0x12E0($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X12E0);
    // 0x8039B378: addiu       $a0, $zero, 0xA4
    ctx->r4 = ADD32(0, 0XA4);
    // 0x8039B37C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B380: bne         $t3, $t6, L_8039B3A8
    if (ctx->r11 != ctx->r14) {
        // 0x8039B384: addiu       $a2, $zero, 0x5000
        ctx->r6 = ADD32(0, 0X5000);
            goto L_8039B3A8;
    }
    // 0x8039B384: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B388: addiu       $t7, $zero, 0x40
    ctx->r15 = ADD32(0, 0X40);
    // 0x8039B38C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039B390: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039B394: jal         0x8013307C
    // 0x8039B398: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    play_sound_effect(rdram, ctx);
        goto after_73;
    // 0x8039B398: sb          $t2, 0x85($sp)
    MEM_B(0X85, ctx->r29) = ctx->r10;
    after_73:
    // 0x8039B39C: lb          $t2, 0x85($sp)
    ctx->r10 = MEM_B(ctx->r29, 0X85);
    // 0x8039B3A0: sb          $zero, 0x2F($s0)
    MEM_B(0X2F, ctx->r16) = 0;
    // 0x8039B3A4: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039B3A8:
    // 0x8039B3A8: bnel        $t2, $zero, L_8039B3C0
    if (ctx->r10 != 0) {
        // 0x8039B3AC: lb          $t9, 0x30($s0)
        ctx->r25 = MEM_B(ctx->r16, 0X30);
            goto L_8039B3C0;
    }
    goto skip_29;
    // 0x8039B3AC: lb          $t9, 0x30($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X30);
    skip_29:
    // 0x8039B3B0: lb          $t8, 0x84($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X84);
    // 0x8039B3B4: beql        $t8, $zero, L_8039B418
    if (ctx->r24 == 0) {
        // 0x8039B3B8: lb          $v0, 0x2E($s0)
        ctx->r2 = MEM_B(ctx->r16, 0X2E);
            goto L_8039B418;
    }
    goto skip_30;
    // 0x8039B3B8: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
    skip_30:
    // 0x8039B3BC: lb          $t9, 0x30($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X30);
L_8039B3C0:
    // 0x8039B3C0: addiu       $a0, $zero, 0x90
    ctx->r4 = ADD32(0, 0X90);
    // 0x8039B3C4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B3C8: subu        $t4, $t3, $t9
    ctx->r12 = SUB32(ctx->r11, ctx->r25);
    // 0x8039B3CC: sb          $t4, 0x30($s0)
    MEM_B(0X30, ctx->r16) = ctx->r12;
    // 0x8039B3D0: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039B3D4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B3D8: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x8039B3DC: bne         $v0, $zero, L_8039B3F4
    if (ctx->r2 != 0) {
        // 0x8039B3E0: addiu       $t5, $zero, 0x40
        ctx->r13 = ADD32(0, 0X40);
            goto L_8039B3F4;
    }
    // 0x8039B3E0: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x8039B3E4: jal         0x8013307C
    // 0x8039B3E8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    play_sound_effect(rdram, ctx);
        goto after_74;
    // 0x8039B3E8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_74:
    // 0x8039B3EC: lb          $v0, 0x30($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X30);
    // 0x8039B3F0: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_8039B3F4:
    // 0x8039B3F4: bne         $t3, $v0, L_8039B414
    if (ctx->r11 != ctx->r2) {
        // 0x8039B3F8: addiu       $a0, $zero, 0x92
        ctx->r4 = ADD32(0, 0X92);
            goto L_8039B414;
    }
    // 0x8039B3F8: addiu       $a0, $zero, 0x92
    ctx->r4 = ADD32(0, 0X92);
    // 0x8039B3FC: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x8039B400: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8039B404: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039B408: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8039B40C: jal         0x8013307C
    // 0x8039B410: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    play_sound_effect(rdram, ctx);
        goto after_75;
    // 0x8039B410: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    after_75:
L_8039B414:
    // 0x8039B414: lb          $v0, 0x2E($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X2E);
L_8039B418:
    // 0x8039B418: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B41C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039B420: bne         $v0, $zero, L_8039B438
    if (ctx->r2 != 0) {
        // 0x8039B424: addiu       $a0, $a0, -0x6184
        ctx->r4 = ADD32(ctx->r4, -0X6184);
            goto L_8039B438;
    }
    // 0x8039B424: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B428: addiu       $v1, $zero, 0x3A
    ctx->r3 = ADD32(0, 0X3A);
    // 0x8039B42C: addiu       $t0, $zero, 0x58
    ctx->r8 = ADD32(0, 0X58);
    // 0x8039B430: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    // 0x8039B434: sh          $v1, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r3;
L_8039B438:
    // 0x8039B438: lh          $v1, 0x7E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X7E);
    // 0x8039B43C: bne         $v0, $at, L_8039B44C
    if (ctx->r2 != ctx->r1) {
        // 0x8039B440: lh          $t0, 0x7C($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X7C);
            goto L_8039B44C;
    }
    // 0x8039B440: lh          $t0, 0x7C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7C);
    // 0x8039B444: addiu       $v1, $zero, 0x86
    ctx->r3 = ADD32(0, 0X86);
    // 0x8039B448: addiu       $t0, $zero, 0x58
    ctx->r8 = ADD32(0, 0X58);
L_8039B44C:
    // 0x8039B44C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039B450: bne         $v0, $at, L_8039B460
    if (ctx->r2 != ctx->r1) {
        // 0x8039B454: addiu       $t8, $zero, 0xA8
        ctx->r24 = ADD32(0, 0XA8);
            goto L_8039B460;
    }
    // 0x8039B454: addiu       $t8, $zero, 0xA8
    ctx->r24 = ADD32(0, 0XA8);
    // 0x8039B458: addiu       $v1, $zero, 0x3A
    ctx->r3 = ADD32(0, 0X3A);
    // 0x8039B45C: addiu       $t0, $zero, 0xA4
    ctx->r8 = ADD32(0, 0XA4);
L_8039B460:
    // 0x8039B460: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039B464: bnel        $v0, $at, L_8039B478
    if (ctx->r2 != ctx->r1) {
        // 0x8039B468: addiu       $a1, $v1, -0x1E
        ctx->r5 = ADD32(ctx->r3, -0X1E);
            goto L_8039B478;
    }
    goto skip_31;
    // 0x8039B468: addiu       $a1, $v1, -0x1E
    ctx->r5 = ADD32(ctx->r3, -0X1E);
    skip_31:
    // 0x8039B46C: addiu       $v1, $zero, 0x86
    ctx->r3 = ADD32(0, 0X86);
    // 0x8039B470: addiu       $t0, $zero, 0xA4
    ctx->r8 = ADD32(0, 0XA4);
    // 0x8039B474: addiu       $a1, $v1, -0x1E
    ctx->r5 = ADD32(ctx->r3, -0X1E);
L_8039B478:
    // 0x8039B478: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x8039B47C: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039B480: addiu       $a2, $t0, -0x18
    ctx->r6 = ADD32(ctx->r8, -0X18);
    // 0x8039B484: addiu       $a3, $v1, 0x1C
    ctx->r7 = ADD32(ctx->r3, 0X1C);
    // 0x8039B488: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x8039B48C: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8039B490: addiu       $t7, $t0, 0x14
    ctx->r15 = ADD32(ctx->r8, 0X14);
    // 0x8039B494: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039B498: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039B49C: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8039B4A0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8039B4A4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039B4A8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8039B4AC: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8039B4B0: sh          $v1, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r3;
    // 0x8039B4B4: jal         0x8012AD30
    // 0x8039B4B8: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    draw_rectangle(rdram, ctx);
        goto after_76;
    // 0x8039B4B8: sh          $t0, 0x7C($sp)
    MEM_H(0X7C, ctx->r29) = ctx->r8;
    after_76:
    // 0x8039B4BC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B4C0: jal         0x8012C1F0
    // 0x8039B4C4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_77;
    // 0x8039B4C4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_77:
    // 0x8039B4C8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8039B4CC: lw          $v0, -0x6184($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6184);
    // 0x8039B4D0: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8039B4D4: lui         $t4, 0xB900
    ctx->r12 = S32(0XB900 << 16);
    // 0x8039B4D8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039B4DC: sw          $t9, -0x6184($at)
    MEM_W(-0X6184, ctx->r1) = ctx->r25;
    // 0x8039B4E0: ori         $t4, $t4, 0x2
    ctx->r12 = ctx->r12 | 0X2;
    // 0x8039B4E4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039B4E8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8039B4EC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039B4F0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8039B4F4: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039B4F8: jal         0x8012C248
    // 0x8039B4FC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    select_font(rdram, ctx);
        goto after_78;
    // 0x8039B4FC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    after_78:
    // 0x8039B500: lb          $t5, 0x30($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X30);
    // 0x8039B504: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039B508: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039B50C: bne         $t5, $zero, L_8039B530
    if (ctx->r13 != 0) {
        // 0x8039B510: addiu       $a2, $zero, 0x80
        ctx->r6 = ADD32(0, 0X80);
            goto L_8039B530;
    }
    // 0x8039B510: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039B514: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039B518: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039B51C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039B520: jal         0x8012C214
    // 0x8039B524: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_79;
    // 0x8039B524: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_79:
    // 0x8039B528: b           L_8039B538
    // 0x8039B52C: nop

        goto L_8039B538;
    // 0x8039B52C: nop

L_8039B530:
    // 0x8039B530: jal         0x8012C214
    // 0x8039B534: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_80;
    // 0x8039B534: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_80:
L_8039B538:
    // 0x8039B538: jal         0x80130A90
    // 0x8039B53C: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    get_message_address_by_id(rdram, ctx);
        goto after_81;
    // 0x8039B53C: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    after_81:
    // 0x8039B540: lh          $a3, 0x7C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7C);
    // 0x8039B544: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B548: lwc1        $f10, 0x74B4($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039B54C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B550: lwc1        $f16, 0x74B8($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039B554: lhu         $a2, 0x7E($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X7E);
    // 0x8039B558: addiu       $a3, $a3, -0xC
    ctx->r7 = ADD32(ctx->r7, -0XC);
    // 0x8039B55C: andi        $t6, $a3, 0xFFFF
    ctx->r14 = ctx->r7 & 0XFFFF;
    // 0x8039B560: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B564: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B568: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8039B56C: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B570: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8039B574: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    // 0x8039B578: jal         0x8012C978
    // 0x8039B57C: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    display_text_centered(rdram, ctx);
        goto after_82;
    // 0x8039B57C: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    after_82:
    // 0x8039B580: lb          $t7, 0x30($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X30);
    // 0x8039B584: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039B588: addiu       $a0, $zero, 0x80
    ctx->r4 = ADD32(0, 0X80);
    // 0x8039B58C: bne         $t7, $at, L_8039B5B0
    if (ctx->r15 != ctx->r1) {
        // 0x8039B590: addiu       $a1, $zero, 0x80
        ctx->r5 = ADD32(0, 0X80);
            goto L_8039B5B0;
    }
    // 0x8039B590: addiu       $a1, $zero, 0x80
    ctx->r5 = ADD32(0, 0X80);
    // 0x8039B594: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039B598: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039B59C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039B5A0: jal         0x8012C214
    // 0x8039B5A4: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_83;
    // 0x8039B5A4: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_83:
    // 0x8039B5A8: b           L_8039B5BC
    // 0x8039B5AC: nop

        goto L_8039B5BC;
    // 0x8039B5AC: nop

L_8039B5B0:
    // 0x8039B5B0: addiu       $a2, $zero, 0x80
    ctx->r6 = ADD32(0, 0X80);
    // 0x8039B5B4: jal         0x8012C214
    // 0x8039B5B8: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_84;
    // 0x8039B5B8: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_84:
L_8039B5BC:
    // 0x8039B5BC: jal         0x80130A90
    // 0x8039B5C0: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    get_message_address_by_id(rdram, ctx);
        goto after_85;
    // 0x8039B5C0: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    after_85:
    // 0x8039B5C4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B5C8: lwc1        $f18, 0x74B4($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B4);
    // 0x8039B5CC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B5D0: lwc1        $f4, 0x74B8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74B8);
    // 0x8039B5D4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B5D8: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B5DC: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B5E0: lhu         $a2, 0x4A($sp)
    ctx->r6 = MEM_HU(ctx->r29, 0X4A);
    // 0x8039B5E4: lhu         $a3, 0x7C($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X7C);
    // 0x8039B5E8: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039B5EC: jal         0x8012C978
    // 0x8039B5F0: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text_centered(rdram, ctx);
        goto after_86;
    // 0x8039B5F0: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_86:
L_8039B5F4:
    // 0x8039B5F4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B5F8: jal         0x8012C1F0
    // 0x8039B5FC: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_87;
    // 0x8039B5FC: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_87:
    // 0x8039B600: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8039B604: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8039B608: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x8039B60C: jal         0x8012C248
    // 0x8039B610: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_88;
    // 0x8039B610: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_88:
    // 0x8039B614: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8039B618: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8039B61C: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8039B620: jal         0x8012C214
    // 0x8039B624: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_89;
    // 0x8039B624: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_89:
    // 0x8039B628: lui         $v0, 0x8024
    ctx->r2 = S32(0X8024 << 16);
    // 0x8039B62C: lb          $v0, -0xD52($v0)
    ctx->r2 = MEM_B(ctx->r2, -0XD52);
    // 0x8039B630: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8039B634: beq         $v0, $at, L_8039B644
    if (ctx->r2 == ctx->r1) {
        // 0x8039B638: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_8039B644;
    }
    // 0x8039B638: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8039B63C: bnel        $v0, $at, L_8039B690
    if (ctx->r2 != ctx->r1) {
        // 0x8039B640: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_8039B690;
    }
    goto skip_32;
    // 0x8039B640: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    skip_32:
L_8039B644:
    // 0x8039B644: jal         0x80130A90
    // 0x8039B648: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    get_message_address_by_id(rdram, ctx);
        goto after_90;
    // 0x8039B648: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    after_90:
    // 0x8039B64C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8039B650: lwc1        $f6, 0x410($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X410);
    // 0x8039B654: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039B658: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039B65C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B660: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8039B664: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8039B668: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B66C: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B670: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x8039B674: addiu       $a3, $zero, 0xD0
    ctx->r7 = ADD32(0, 0XD0);
    // 0x8039B678: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039B67C: jal         0x8012D374
    // 0x8039B680: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    func_8012D374(rdram, ctx);
        goto after_91;
    // 0x8039B680: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    after_91:
    // 0x8039B684: b           L_8039B720
    // 0x8039B688: nop

        goto L_8039B720;
    // 0x8039B688: nop

    // 0x8039B68C: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
L_8039B690:
    // 0x8039B690: beq         $v0, $at, L_8039B6A0
    if (ctx->r2 == ctx->r1) {
        // 0x8039B694: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_8039B6A0;
    }
    // 0x8039B694: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8039B698: bne         $v0, $at, L_8039B6E8
    if (ctx->r2 != ctx->r1) {
        // 0x8039B69C: nop
    
            goto L_8039B6E8;
    }
    // 0x8039B69C: nop

L_8039B6A0:
    // 0x8039B6A0: jal         0x80130A90
    // 0x8039B6A4: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    get_message_address_by_id(rdram, ctx);
        goto after_92;
    // 0x8039B6A4: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    after_92:
    // 0x8039B6A8: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x8039B6AC: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039B6B0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039B6B4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039B6B8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B6BC: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8039B6C0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8039B6C4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B6C8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B6CC: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x8039B6D0: addiu       $a3, $zero, 0xD0
    ctx->r7 = ADD32(0, 0XD0);
    // 0x8039B6D4: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8039B6D8: jal         0x8012D374
    // 0x8039B6DC: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    func_8012D374(rdram, ctx);
        goto after_93;
    // 0x8039B6DC: swc1        $f16, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f16.u32l;
    after_93:
    // 0x8039B6E0: b           L_8039B720
    // 0x8039B6E4: nop

        goto L_8039B720;
    // 0x8039B6E4: nop

L_8039B6E8:
    // 0x8039B6E8: jal         0x80130A90
    // 0x8039B6EC: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    get_message_address_by_id(rdram, ctx);
        goto after_94;
    // 0x8039B6EC: addiu       $a0, $zero, 0xD6
    ctx->r4 = ADD32(0, 0XD6);
    after_94:
    // 0x8039B6F0: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8039B6F4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039B6F8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B6FC: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x8039B700: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8039B704: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B708: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B70C: addiu       $a2, $zero, 0x17
    ctx->r6 = ADD32(0, 0X17);
    // 0x8039B710: addiu       $a3, $zero, 0xD0
    ctx->r7 = ADD32(0, 0XD0);
    // 0x8039B714: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x8039B718: jal         0x8012D374
    // 0x8039B71C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    func_8012D374(rdram, ctx);
        goto after_95;
    // 0x8039B71C: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    after_95:
L_8039B720:
    // 0x8039B720: jal         0x80130A90
    // 0x8039B724: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    get_message_address_by_id(rdram, ctx);
        goto after_96;
    // 0x8039B724: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    after_96:
    // 0x8039B728: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B72C: lwc1        $f18, 0x74AC($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74AC);
    // 0x8039B730: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B734: lwc1        $f4, 0x74B0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B738: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B73C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B740: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B744: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x8039B748: addiu       $a3, $zero, 0x38
    ctx->r7 = ADD32(0, 0X38);
    // 0x8039B74C: swc1        $f18, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f18.u32l;
    // 0x8039B750: jal         0x8012DEF8
    // 0x8039B754: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    display_text(rdram, ctx);
        goto after_97;
    // 0x8039B754: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    after_97:
    // 0x8039B758: addiu       $t5, $zero, 0x38
    ctx->r13 = ADD32(0, 0X38);
    // 0x8039B75C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B760: lwc1        $f8, 0x74B0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B764: mtc1        $t5, $f6
    ctx->f6.u32l = ctx->r13;
    // 0x8039B768: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x8039B76C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039B770: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039B774: addiu       $a0, $zero, 0x11
    ctx->r4 = ADD32(0, 0X11);
    // 0x8039B778: add.s       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x8039B77C: swc1        $f0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->f0.u32l;
    // 0x8039B780: add.s       $f18, $f0, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f0.fl + ctx->f16.fl;
    // 0x8039B784: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x8039B788: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
    // 0x8039B78C: jal         0x80130A90
    // 0x8039B790: sh          $t8, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r24;
    get_message_address_by_id(rdram, ctx);
        goto after_98;
    // 0x8039B790: sh          $t8, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r24;
    after_98:
    // 0x8039B794: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B798: lwc1        $f6, 0x74AC($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74AC);
    // 0x8039B79C: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B7A0: lwc1        $f8, 0x74B0($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B7A4: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039B7A8: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B7AC: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B7B0: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B7B4: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x8039B7B8: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039B7BC: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    // 0x8039B7C0: jal         0x8012DEF8
    // 0x8039B7C4: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    display_text(rdram, ctx);
        goto after_99;
    // 0x8039B7C4: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    after_99:
    // 0x8039B7C8: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039B7CC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B7D0: lwc1        $f18, 0x74B0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B7D4: mtc1        $v1, $f10
    ctx->f10.u32l = ctx->r3;
    // 0x8039B7D8: addiu       $a0, $zero, 0x12
    ctx->r4 = ADD32(0, 0X12);
    // 0x8039B7DC: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039B7E0: add.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f16.fl + ctx->f18.fl;
    // 0x8039B7E4: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039B7E8: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x8039B7EC: jal         0x80130A90
    // 0x8039B7F0: sh          $t5, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r13;
    get_message_address_by_id(rdram, ctx);
        goto after_100;
    // 0x8039B7F0: sh          $t5, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r13;
    after_100:
    // 0x8039B7F4: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B7F8: lwc1        $f8, 0x74AC($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74AC);
    // 0x8039B7FC: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B800: lwc1        $f10, 0x74B0($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B804: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039B808: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B80C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B810: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8039B814: addiu       $a2, $zero, 0x108
    ctx->r6 = ADD32(0, 0X108);
    // 0x8039B818: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x8039B81C: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    // 0x8039B820: jal         0x8012DEF8
    // 0x8039B824: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    display_text(rdram, ctx);
        goto after_101;
    // 0x8039B824: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    after_101:
    // 0x8039B828: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039B82C: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x8039B830: addiu       $a2, $a2, 0x3E4
    ctx->r6 = ADD32(ctx->r6, 0X3E4);
    // 0x8039B834: addiu       $a1, $a1, 0x3E0
    ctx->r5 = ADD32(ctx->r5, 0X3E0);
    // 0x8039B838: jal         0x801395F4
    // 0x8039B83C: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    sprintf_recomp(rdram, ctx);
        goto after_102;
    // 0x8039B83C: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    after_102:
    // 0x8039B840: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x8039B844: jal         0x801308B4
    // 0x8039B848: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    prepare_text(rdram, ctx);
        goto after_103;
    // 0x8039B848: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    after_103:
    // 0x8039B84C: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x8039B850: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039B854: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B858: lwc1        $f18, 0x74B0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B85C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B860: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x8039B864: addiu       $s0, $sp, 0xBC
    ctx->r16 = ADD32(ctx->r29, 0XBC);
    // 0x8039B868: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8039B86C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B870: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039B874: addiu       $a2, $zero, 0x10C
    ctx->r6 = ADD32(0, 0X10C);
    // 0x8039B878: addiu       $a3, $zero, 0x38
    ctx->r7 = ADD32(0, 0X38);
    // 0x8039B87C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x8039B880: jal         0x8012D374
    // 0x8039B884: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    func_8012D374(rdram, ctx);
        goto after_104;
    // 0x8039B884: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_104:
    // 0x8039B888: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B88C: lwc1        $f0, 0x74B0($at)
    ctx->f0.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B890: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x8039B894: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039B898: lwc1        $f4, 0x48($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X48);
    // 0x8039B89C: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x8039B8A0: add.s       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f0.fl + ctx->f6.fl;
    // 0x8039B8A4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B8A8: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x8039B8AC: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8039B8B0: add.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x8039B8B4: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B8B8: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039B8BC: addiu       $a2, $zero, 0x10C
    ctx->r6 = ADD32(0, 0X10C);
    // 0x8039B8C0: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8039B8C4: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8039B8C8: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x8039B8CC: mfc1        $v1, $f16
    ctx->r3 = (int32_t)ctx->f16.u32l;
    // 0x8039B8D0: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8039B8D4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x8039B8D8: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039B8DC: mtc1        $v1, $f18
    ctx->f18.u32l = ctx->r3;
    // 0x8039B8E0: nop

    // 0x8039B8E4: cvt.s.w     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039B8E8: add.s       $f4, $f6, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = ctx->f6.fl + ctx->f0.fl;
    // 0x8039B8EC: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039B8F0: mfc1        $t6, $f8
    ctx->r14 = (int32_t)ctx->f8.u32l;
    // 0x8039B8F4: nop

    // 0x8039B8F8: andi        $a3, $t6, 0xFFFF
    ctx->r7 = ctx->r14 & 0XFFFF;
    // 0x8039B8FC: jal         0x8012D374
    // 0x8039B900: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    func_8012D374(rdram, ctx);
        goto after_105;
    // 0x8039B900: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    after_105:
    // 0x8039B904: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039B908: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B90C: lwc1        $f0, 0x74B0($at)
    ctx->f0.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B910: mtc1        $v1, $f16
    ctx->f16.u32l = ctx->r3;
    // 0x8039B914: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x8039B918: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039B91C: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039B920: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x8039B924: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039B928: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B92C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x8039B930: add.s       $f4, $f0, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f0.fl + ctx->f6.fl;
    // 0x8039B934: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x8039B938: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B93C: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039B940: add.s       $f8, $f18, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x8039B944: addiu       $a2, $zero, 0x10C
    ctx->r6 = ADD32(0, 0X10C);
    // 0x8039B948: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x8039B94C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x8039B950: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8039B954: mfc1        $t4, $f10
    ctx->r12 = (int32_t)ctx->f10.u32l;
    // 0x8039B958: jal         0x8012D374
    // 0x8039B95C: andi        $a3, $t4, 0xFFFF
    ctx->r7 = ctx->r12 & 0XFFFF;
    func_8012D374(rdram, ctx);
        goto after_106;
    // 0x8039B95C: andi        $a3, $t4, 0xFFFF
    ctx->r7 = ctx->r12 & 0XFFFF;
    after_106:
    // 0x8039B960: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039B964: addiu       $a1, $a1, 0x3E8
    ctx->r5 = ADD32(ctx->r5, 0X3E8);
    // 0x8039B968: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039B96C: jal         0x801395F4
    // 0x8039B970: lh          $a2, 0x74($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X74);
    sprintf_recomp(rdram, ctx);
        goto after_107;
    // 0x8039B970: lh          $a2, 0x74($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X74);
    after_107:
    // 0x8039B974: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039B978: jal         0x801308B4
    // 0x8039B97C: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    prepare_text(rdram, ctx);
        goto after_108;
    // 0x8039B97C: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    after_108:
    // 0x8039B980: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x8039B984: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8039B988: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B98C: lwc1        $f18, 0x74B0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B990: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039B994: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039B998: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039B99C: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039B9A0: addiu       $a3, $zero, 0x38
    ctx->r7 = ADD32(0, 0X38);
    // 0x8039B9A4: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x8039B9A8: jal         0x8012DEF8
    // 0x8039B9AC: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    display_text(rdram, ctx);
        goto after_109;
    // 0x8039B9AC: swc1        $f18, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f18.u32l;
    after_109:
    // 0x8039B9B0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039B9B4: lwc1        $f0, 0x74B0($at)
    ctx->f0.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039B9B8: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x8039B9BC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039B9C0: lwc1        $f4, 0x48($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X48);
    // 0x8039B9C4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039B9C8: add.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f0.fl + ctx->f8.fl;
    // 0x8039B9CC: addiu       $a1, $a1, 0x3EC
    ctx->r5 = ADD32(ctx->r5, 0X3EC);
    // 0x8039B9D0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039B9D4: lh          $a2, 0x76($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X76);
    // 0x8039B9D8: add.s       $f16, $f4, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f4.fl + ctx->f10.fl;
    // 0x8039B9DC: trunc.w.s   $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    ctx->f6.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8039B9E0: mfc1        $v1, $f6
    ctx->r3 = (int32_t)ctx->f6.u32l;
    // 0x8039B9E4: nop

    // 0x8039B9E8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x8039B9EC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039B9F0: mtc1        $v1, $f18
    ctx->f18.u32l = ctx->r3;
    // 0x8039B9F4: nop

    // 0x8039B9F8: cvt.s.w     $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    ctx->f8.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039B9FC: add.s       $f4, $f8, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = ctx->f8.fl + ctx->f0.fl;
    // 0x8039BA00: trunc.w.s   $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039BA04: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x8039BA08: jal         0x801395F4
    // 0x8039BA0C: sh          $t5, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r13;
    sprintf_recomp(rdram, ctx);
        goto after_110;
    // 0x8039BA0C: sh          $t5, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r13;
    after_110:
    // 0x8039BA10: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039BA14: jal         0x801308B4
    // 0x8039BA18: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    prepare_text(rdram, ctx);
        goto after_111;
    // 0x8039BA18: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    after_111:
    // 0x8039BA1C: lui         $at, 0x4140
    ctx->r1 = S32(0X4140 << 16);
    // 0x8039BA20: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x8039BA24: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039BA28: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039BA2C: lwc1        $f6, 0x74B0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039BA30: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039BA34: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039BA38: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039BA3C: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039BA40: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    // 0x8039BA44: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    // 0x8039BA48: jal         0x8012DEF8
    // 0x8039BA4C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    display_text(rdram, ctx);
        goto after_112;
    // 0x8039BA4C: swc1        $f6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f6.u32l;
    after_112:
    // 0x8039BA50: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039BA54: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039BA58: lwc1        $f18, 0x74B0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X74B0);
    // 0x8039BA5C: mtc1        $v1, $f10
    ctx->f10.u32l = ctx->r3;
    // 0x8039BA60: lui         $at, 0x40C0
    ctx->r1 = S32(0X40C0 << 16);
    // 0x8039BA64: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039BA68: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039BA6C: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x8039BA70: addiu       $a1, $a1, 0x3F0
    ctx->r5 = ADD32(ctx->r5, 0X3F0);
    // 0x8039BA74: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039BA78: lh          $a2, 0x78($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X78);
    // 0x8039BA7C: add.s       $f4, $f18, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f18.fl + ctx->f8.fl;
    // 0x8039BA80: add.s       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x8039BA84: trunc.w.s   $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8039BA88: mfc1        $t8, $f18
    ctx->r24 = (int32_t)ctx->f18.u32l;
    // 0x8039BA8C: jal         0x801395F4
    // 0x8039BA90: sh          $t8, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r24;
    sprintf_recomp(rdram, ctx);
        goto after_113;
    // 0x8039BA90: sh          $t8, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r24;
    after_113:
    // 0x8039BA94: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039BA98: jal         0x801308B4
    // 0x8039BA9C: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    prepare_text(rdram, ctx);
        goto after_114;
    // 0x8039BA9C: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    after_114:
    // 0x8039BAA0: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039BAA4: lwc1        $f8, 0x74BC($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X74BC);
    // 0x8039BAA8: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8039BAAC: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039BAB0: lwc1        $f10, 0x74C0($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X74C0);
    // 0x8039BAB4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039BAB8: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039BABC: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x8039BAC0: addiu       $a2, $zero, 0x12C
    ctx->r6 = ADD32(0, 0X12C);
    // 0x8039BAC4: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x8039BAC8: andi        $a3, $v1, 0xFFFF
    ctx->r7 = ctx->r3 & 0XFFFF;
    // 0x8039BACC: jal         0x8012DEF8
    // 0x8039BAD0: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    display_text(rdram, ctx);
        goto after_115;
    // 0x8039BAD0: swc1        $f10, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f10.u32l;
    after_115:
    // 0x8039BAD4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039BAD8: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039BADC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039BAE0: lh          $v1, 0x86($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X86);
    // 0x8039BAE4: lui         $t4, 0x600
    ctx->r12 = S32(0X600 << 16);
    // 0x8039BAE8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039BAEC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039BAF0: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039BAF4: lw          $t5, 0x44($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X44);
    // 0x8039BAF8: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8039BAFC: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8039BB00: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8039BB04: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039BB08: lui         $t4, 0xB900
    ctx->r12 = S32(0XB900 << 16);
    // 0x8039BB0C: ori         $t4, $t4, 0x2
    ctx->r12 = ctx->r12 | 0X2;
    // 0x8039BB10: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039BB14: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039BB18: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039BB1C: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039BB20: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039BB24: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8039BB28: lui         $t7, 0xF900
    ctx->r15 = S32(0XF900 << 16);
    // 0x8039BB2C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039BB30: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039BB34: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8039BB38: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039BB3C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039BB40: addiu       $t8, $zero, 0x80
    ctx->r24 = ADD32(0, 0X80);
    // 0x8039BB44: addiu       $t9, $v1, -0x2
    ctx->r25 = ADD32(ctx->r3, -0X2);
    // 0x8039BB48: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039BB4C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039BB50: sll         $t4, $t9, 18
    ctx->r12 = S32(ctx->r25 << 18);
    // 0x8039BB54: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039BB58: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039BB5C: lui         $t8, 0x800E
    ctx->r24 = S32(0X800E << 16);
    // 0x8039BB60: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8039BB64: addiu       $t6, $v1, 0xE
    ctx->r14 = ADD32(ctx->r3, 0XE);
    // 0x8039BB68: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8039BB6C: addiu       $t4, $zero, 0x20
    ctx->r12 = ADD32(0, 0X20);
    // 0x8039BB70: addiu       $t8, $t8, -0x1C70
    ctx->r24 = ADD32(ctx->r24, -0X1C70);
    // 0x8039BB74: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x8039BB78: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8039BB7C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8039BB80: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x8039BB84: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8039BB88: addiu       $a1, $zero, 0x3C8
    ctx->r5 = ADD32(0, 0X3C8);
    // 0x8039BB8C: jal         0x803962EC
    // 0x8039BB90: addiu       $a3, $zero, 0x408
    ctx->r7 = ADD32(0, 0X408);
    func_803962EC_7A799C(rdram, ctx);
        goto after_116;
    // 0x8039BB90: addiu       $a3, $zero, 0x408
    ctx->r7 = ADD32(0, 0X408);
    after_116:
    sssv_file_select_layout_hook(rdram, ctx, 3);
    // 0x8039BB94: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039BB98: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039BB9C: jal         0x8039D034
    // 0x8039BBA0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    func_8039D034_7AE6E4(rdram, ctx);
        goto after_117;
    // 0x8039BBA0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_117:
    // 0x8039BBA4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8039BBA8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8039BBAC: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
    // 0x8039BBB0: jr          $ra
    // 0x8039BBB4: nop

    return;
    // 0x8039BBB4: nop

;}
RECOMP_FUNC void func_8039BBB8_7AD268(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039BBB8: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8039BBBC: addiu       $t2, $t2, 0x2D50
    ctx->r10 = ADD32(ctx->r10, 0X2D50);
    // 0x8039BBC0: lh          $t6, 0xC6($t2)
    ctx->r14 = MEM_H(ctx->r10, 0XC6);
    // 0x8039BBC4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8039BBC8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8039BBCC: beq         $t6, $zero, L_8039BE30
    if (ctx->r14 == 0) {
        // 0x8039BBD0: lui         $a1, 0x803F
        ctx->r5 = S32(0X803F << 16);
            goto L_8039BE30;
    }
    // 0x8039BBD0: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8039BBD4: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x8039BBD8: lw          $v1, 0x4D28($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4D28);
    // 0x8039BBDC: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BBE0: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    // 0x8039BBE4: andi        $t7, $v1, 0x1
    ctx->r15 = ctx->r3 & 0X1;
    // 0x8039BBE8: beq         $t7, $zero, L_8039BC54
    if (ctx->r15 == 0) {
        // 0x8039BBEC: andi        $a0, $v1, 0x2
        ctx->r4 = ctx->r3 & 0X2;
            goto L_8039BC54;
    }
    // 0x8039BBEC: andi        $a0, $v1, 0x2
    ctx->r4 = ctx->r3 & 0X2;
    // 0x8039BBF0: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BBF4: lb          $v0, 0x2D($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X2D);
    // 0x8039BBF8: addiu       $t1, $zero, 0xA
    ctx->r9 = ADD32(0, 0XA);
    // 0x8039BBFC: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8039BC00: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039BC04: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8039BC08: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039BC0C: beq         $t9, $t1, L_8039BC54
    if (ctx->r25 == ctx->r9) {
        // 0x8039BC10: nop
    
            goto L_8039BC54;
    }
    // 0x8039BC10: nop

    // 0x8039BC14: beq         $t9, $at, L_8039BC54
    if (ctx->r25 == ctx->r1) {
        // 0x8039BC18: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_8039BC54;
    }
    // 0x8039BC18: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x8039BC1C: beq         $t9, $at, L_8039BC54
    if (ctx->r25 == ctx->r1) {
        // 0x8039BC20: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_8039BC54;
    }
    // 0x8039BC20: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x8039BC24: beq         $t9, $at, L_8039BC54
    if (ctx->r25 == ctx->r1) {
        // 0x8039BC28: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_8039BC54;
    }
    // 0x8039BC28: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x8039BC2C: beq         $t9, $at, L_8039BC54
    if (ctx->r25 == ctx->r1) {
        // 0x8039BC30: lui         $a1, 0x803F
        ctx->r5 = S32(0X803F << 16);
            goto L_8039BC54;
    }
    // 0x8039BC30: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8039BC34: addiu       $a1, $a1, 0x2D30
    ctx->r5 = ADD32(ctx->r5, 0X2D30);
    // 0x8039BC38: lh          $t3, 0x8($a1)
    ctx->r11 = MEM_H(ctx->r5, 0X8);
    // 0x8039BC3C: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039BC40: addiu       $a3, $a3, -0xDA0
    ctx->r7 = ADD32(ctx->r7, -0XDA0);
    // 0x8039BC44: addu        $v0, $a3, $t3
    ctx->r2 = ADD32(ctx->r7, ctx->r11);
    // 0x8039BC48: lbu         $t5, 0x3($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X3);
    // 0x8039BC4C: ori         $t6, $t5, 0x1
    ctx->r14 = ctx->r13 | 0X1;
    // 0x8039BC50: sb          $t6, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r14;
L_8039BC54:
    // 0x8039BC54: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BC58: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BC5C: lb          $v0, 0x2D($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X2D);
    // 0x8039BC60: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8039BC64: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039BC68: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039BC6C: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039BC70: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039BC74: addiu       $a3, $a3, -0xDA0
    ctx->r7 = ADD32(ctx->r7, -0XDA0);
    // 0x8039BC78: addiu       $a1, $a1, 0x2D30
    ctx->r5 = ADD32(ctx->r5, 0X2D30);
    // 0x8039BC7C: addiu       $t1, $zero, 0xA
    ctx->r9 = ADD32(0, 0XA);
    // 0x8039BC80: beq         $a0, $zero, L_8039BCE0
    if (ctx->r4 == 0) {
        // 0x8039BC84: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_8039BCE0;
    }
    // 0x8039BC84: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x8039BC88: bne         $t8, $t1, L_8039BC9C
    if (ctx->r24 != ctx->r9) {
        // 0x8039BC8C: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_8039BC9C;
    }
    // 0x8039BC8C: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8039BC90: lb          $t9, 0x3B($a3)
    ctx->r25 = MEM_B(ctx->r7, 0X3B);
    // 0x8039BC94: ori         $t3, $t9, 0x1
    ctx->r11 = ctx->r25 | 0X1;
    // 0x8039BC98: sb          $t3, 0x3B($a3)
    MEM_B(0X3B, ctx->r7) = ctx->r11;
L_8039BC9C:
    // 0x8039BC9C: bnel        $v0, $at, L_8039BCB4
    if (ctx->r2 != ctx->r1) {
        // 0x8039BCA0: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_8039BCB4;
    }
    goto skip_0;
    // 0x8039BCA0: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    skip_0:
    // 0x8039BCA4: lb          $t4, 0x3B($a3)
    ctx->r12 = MEM_B(ctx->r7, 0X3B);
    // 0x8039BCA8: ori         $t5, $t4, 0x2
    ctx->r13 = ctx->r12 | 0X2;
    // 0x8039BCAC: sb          $t5, 0x3B($a3)
    MEM_B(0X3B, ctx->r7) = ctx->r13;
    // 0x8039BCB0: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
L_8039BCB4:
    // 0x8039BCB4: bnel        $v0, $at, L_8039BCCC
    if (ctx->r2 != ctx->r1) {
        // 0x8039BCB8: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_8039BCCC;
    }
    goto skip_1;
    // 0x8039BCB8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    skip_1:
    // 0x8039BCBC: lb          $t6, 0x3B($a3)
    ctx->r14 = MEM_B(ctx->r7, 0X3B);
    // 0x8039BCC0: ori         $t7, $t6, 0x4
    ctx->r15 = ctx->r14 | 0X4;
    // 0x8039BCC4: sb          $t7, 0x3B($a3)
    MEM_B(0X3B, ctx->r7) = ctx->r15;
    // 0x8039BCC8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
L_8039BCCC:
    // 0x8039BCCC: bne         $v0, $at, L_8039BCE0
    if (ctx->r2 != ctx->r1) {
        // 0x8039BCD0: nop
    
            goto L_8039BCE0;
    }
    // 0x8039BCD0: nop

    // 0x8039BCD4: lb          $t8, 0x3B($a3)
    ctx->r24 = MEM_B(ctx->r7, 0X3B);
    // 0x8039BCD8: ori         $t9, $t8, 0x8
    ctx->r25 = ctx->r24 | 0X8;
    // 0x8039BCDC: sb          $t9, 0x3B($a3)
    MEM_B(0X3B, ctx->r7) = ctx->r25;
L_8039BCE0:
    // 0x8039BCE0: beq         $v0, $t1, L_8039BD00
    if (ctx->r2 == ctx->r9) {
        // 0x8039BCE4: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_8039BD00;
    }
    // 0x8039BCE4: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8039BCE8: beq         $v0, $at, L_8039BD00
    if (ctx->r2 == ctx->r1) {
        // 0x8039BCEC: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_8039BD00;
    }
    // 0x8039BCEC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x8039BCF0: beq         $v0, $at, L_8039BD00
    if (ctx->r2 == ctx->r1) {
        // 0x8039BCF4: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_8039BD00;
    }
    // 0x8039BCF4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x8039BCF8: bnel        $v0, $at, L_8039BD24
    if (ctx->r2 != ctx->r1) {
        // 0x8039BCFC: lh          $t7, 0x8($a1)
        ctx->r15 = MEM_H(ctx->r5, 0X8);
            goto L_8039BD24;
    }
    goto skip_2;
    // 0x8039BCFC: lh          $t7, 0x8($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X8);
    skip_2:
L_8039BD00:
    // 0x8039BD00: beql        $a0, $zero, L_8039BD5C
    if (ctx->r4 == 0) {
        // 0x8039BD04: lb          $t3, 0x2E($t0)
        ctx->r11 = MEM_B(ctx->r8, 0X2E);
            goto L_8039BD5C;
    }
    goto skip_3;
    // 0x8039BD04: lb          $t3, 0x2E($t0)
    ctx->r11 = MEM_B(ctx->r8, 0X2E);
    skip_3:
    // 0x8039BD08: lh          $t3, 0x8($a1)
    ctx->r11 = MEM_H(ctx->r5, 0X8);
    // 0x8039BD0C: addu        $v0, $a3, $t3
    ctx->r2 = ADD32(ctx->r7, ctx->r11);
    // 0x8039BD10: lbu         $t5, 0x3($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X3);
    // 0x8039BD14: ori         $t6, $t5, 0x2
    ctx->r14 = ctx->r13 | 0X2;
    // 0x8039BD18: b           L_8039BD58
    // 0x8039BD1C: sb          $t6, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r14;
        goto L_8039BD58;
    // 0x8039BD1C: sb          $t6, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r14;
    // 0x8039BD20: lh          $t7, 0x8($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X8);
L_8039BD24:
    // 0x8039BD24: lh          $a0, 0xC($a1)
    ctx->r4 = MEM_H(ctx->r5, 0XC);
    // 0x8039BD28: addu        $v0, $a3, $t7
    ctx->r2 = ADD32(ctx->r7, ctx->r15);
    // 0x8039BD2C: lbu         $t9, 0x3($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X3);
    // 0x8039BD30: sll         $t7, $a0, 4
    ctx->r15 = S32(ctx->r4 << 4);
    // 0x8039BD34: ori         $t3, $t9, 0x2
    ctx->r11 = ctx->r25 | 0X2;
    // 0x8039BD38: andi        $v1, $t3, 0xFF
    ctx->r3 = ctx->r11 & 0XFF;
    // 0x8039BD3C: srl         $t4, $v1, 4
    ctx->r12 = S32(U32(ctx->r3) >> 4);
    // 0x8039BD40: slt         $at, $t4, $a0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x8039BD44: beq         $at, $zero, L_8039BD58
    if (ctx->r1 == 0) {
        // 0x8039BD48: sb          $t3, 0x3($v0)
        MEM_B(0X3, ctx->r2) = ctx->r11;
            goto L_8039BD58;
    }
    // 0x8039BD48: sb          $t3, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r11;
    // 0x8039BD4C: andi        $t8, $v1, 0xFF0F
    ctx->r24 = ctx->r3 & 0XFF0F;
    // 0x8039BD50: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8039BD54: sb          $t9, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r25;
L_8039BD58:
    // 0x8039BD58: lb          $t3, 0x2E($t0)
    ctx->r11 = MEM_B(ctx->r8, 0X2E);
L_8039BD5C:
    // 0x8039BD5C: lui         $t5, 0x8024
    ctx->r13 = S32(0X8024 << 16);
    // 0x8039BD60: addiu       $t5, $t5, -0xD20
    ctx->r13 = ADD32(ctx->r13, -0XD20);
    // 0x8039BD64: sll         $t4, $t3, 6
    ctx->r12 = S32(ctx->r11 << 6);
    // 0x8039BD68: sh          $zero, 0xC6($t2)
    MEM_H(0XC6, ctx->r10) = 0;
    // 0x8039BD6C: addu        $a1, $t4, $t5
    ctx->r5 = ADD32(ctx->r12, ctx->r13);
    // 0x8039BD70: jal         0x80129158
    // 0x8039BD74: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    memcpy_sssv(rdram, ctx);
        goto after_0;
    // 0x8039BD74: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_0:
    // 0x8039BD78: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BD7C: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BD80: jal         0x80130C30
    // 0x8039BD84: lb          $a0, 0x2E($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2E);
    write_eeprom(rdram, ctx);
        goto after_1;
    // 0x8039BD84: lb          $a0, 0x2E($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2E);
    after_1:
    // 0x8039BD88: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BD8C: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BD90: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
    // 0x8039BD94: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039BD98: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x8039BD9C: addiu       $v1, $a0, 0x1
    ctx->r3 = ADD32(ctx->r4, 0X1);
    // 0x8039BDA0: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x8039BDA4: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8039BDA8: addiu       $a3, $a3, -0xDA0
    ctx->r7 = ADD32(ctx->r7, -0XDA0);
    // 0x8039BDAC: beq         $t6, $at, L_8039BDCC
    if (ctx->r14 == ctx->r1) {
        // 0x8039BDB0: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_8039BDCC;
    }
    // 0x8039BDB0: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x8039BDB4: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8039BDB8: beq         $t6, $at, L_8039BDCC
    if (ctx->r14 == ctx->r1) {
        // 0x8039BDBC: addiu       $at, $zero, 0x17
        ctx->r1 = ADD32(0, 0X17);
            goto L_8039BDCC;
    }
    // 0x8039BDBC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x8039BDC0: beq         $t6, $at, L_8039BDCC
    if (ctx->r14 == ctx->r1) {
        // 0x8039BDC4: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_8039BDCC;
    }
    // 0x8039BDC4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x8039BDC8: bne         $t6, $at, L_8039BE14
    if (ctx->r14 != ctx->r1) {
        // 0x8039BDCC: lui         $t7, 0x803E
        ctx->r15 = S32(0X803E << 16);
            goto L_8039BE14;
    }
L_8039BDCC:
    // 0x8039BDCC: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x8039BDD0: lw          $t7, 0x4D28($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X4D28);
    // 0x8039BDD4: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x8039BDD8: andi        $t8, $t7, 0x2
    ctx->r24 = ctx->r15 & 0X2;
    // 0x8039BDDC: beql        $t8, $zero, L_8039BE20
    if (ctx->r24 == 0) {
        // 0x8039BDE0: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_8039BE20;
    }
    goto skip_4;
    // 0x8039BDE0: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    skip_4:
    // 0x8039BDE4: bnel        $v0, $at, L_8039BE0C
    if (ctx->r2 != ctx->r1) {
        // 0x8039BDE8: sb          $v1, 0x2D($t0)
        MEM_B(0X2D, ctx->r8) = ctx->r3;
            goto L_8039BE0C;
    }
    goto skip_5;
    // 0x8039BDE8: sb          $v1, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r3;
    skip_5:
    // 0x8039BDEC: lb          $t9, 0x3B($a3)
    ctx->r25 = MEM_B(ctx->r7, 0X3B);
    // 0x8039BDF0: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    // 0x8039BDF4: bnel        $t9, $at, L_8039BE20
    if (ctx->r25 != ctx->r1) {
        // 0x8039BDF8: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_8039BE20;
    }
    goto skip_6;
    // 0x8039BDF8: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    skip_6:
    // 0x8039BDFC: sb          $v1, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r3;
    // 0x8039BE00: b           L_8039BE1C
    // 0x8039BE04: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
        goto L_8039BE1C;
    // 0x8039BE04: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
    // 0x8039BE08: sb          $v1, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r3;
L_8039BE0C:
    // 0x8039BE0C: b           L_8039BE1C
    // 0x8039BE10: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
        goto L_8039BE1C;
    // 0x8039BE10: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
L_8039BE14:
    // 0x8039BE14: sb          $v1, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r3;
    // 0x8039BE18: lb          $a0, 0x2D($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2D);
L_8039BE1C:
    // 0x8039BE1C: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
L_8039BE20:
    // 0x8039BE20: bne         $a0, $at, L_8039BE88
    if (ctx->r4 != ctx->r1) {
        // 0x8039BE24: addiu       $t3, $zero, 0x22
        ctx->r11 = ADD32(0, 0X22);
            goto L_8039BE88;
    }
    // 0x8039BE24: addiu       $t3, $zero, 0x22
    ctx->r11 = ADD32(0, 0X22);
    // 0x8039BE28: b           L_8039BE88
    // 0x8039BE2C: sb          $t3, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r11;
        goto L_8039BE88;
    // 0x8039BE2C: sb          $t3, 0x2D($t0)
    MEM_B(0X2D, ctx->r8) = ctx->r11;
L_8039BE30:
    // 0x8039BE30: lui         $a3, 0x8024
    ctx->r7 = S32(0X8024 << 16);
    // 0x8039BE34: addiu       $a3, $a3, -0xDA0
    ctx->r7 = ADD32(ctx->r7, -0XDA0);
    // 0x8039BE38: addiu       $a1, $a1, 0x2D30
    ctx->r5 = ADD32(ctx->r5, 0X2D30);
    // 0x8039BE3C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8039BE40: lw          $t4, 0x3C($a3)
    ctx->r12 = MEM_W(ctx->r7, 0X3C);
    // 0x8039BE44: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BE48: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BE4C: slt         $at, $t4, $v0
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8039BE50: beq         $at, $zero, L_8039BE5C
    if (ctx->r1 == 0) {
        // 0x8039BE54: or          $a0, $a3, $zero
        ctx->r4 = ctx->r7 | 0;
            goto L_8039BE5C;
    }
    // 0x8039BE54: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    // 0x8039BE58: sw          $v0, 0x3C($a3)
    MEM_W(0X3C, ctx->r7) = ctx->r2;
L_8039BE5C:
    // 0x8039BE5C: lb          $t5, 0x2E($t0)
    ctx->r13 = MEM_B(ctx->r8, 0X2E);
    // 0x8039BE60: lui         $t7, 0x8024
    ctx->r15 = S32(0X8024 << 16);
    // 0x8039BE64: addiu       $t7, $t7, -0xD20
    ctx->r15 = ADD32(ctx->r15, -0XD20);
    // 0x8039BE68: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x8039BE6C: addu        $a1, $t6, $t7
    ctx->r5 = ADD32(ctx->r14, ctx->r15);
    // 0x8039BE70: jal         0x80129158
    // 0x8039BE74: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    memcpy_sssv(rdram, ctx);
        goto after_2;
    // 0x8039BE74: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    after_2:
    // 0x8039BE78: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039BE7C: addiu       $t0, $t0, 0x7DA8
    ctx->r8 = ADD32(ctx->r8, 0X7DA8);
    // 0x8039BE80: jal         0x80130C30
    // 0x8039BE84: lb          $a0, 0x2E($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2E);
    write_eeprom(rdram, ctx);
        goto after_3;
    // 0x8039BE84: lb          $a0, 0x2E($t0)
    ctx->r4 = MEM_B(ctx->r8, 0X2E);
    after_3:
L_8039BE88:
    // 0x8039BE88: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8039BE8C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8039BE90: jr          $ra
    // 0x8039BE94: nop

    return;
    // 0x8039BE94: nop

;}
RECOMP_FUNC void draw_level_rings_segment(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039BE98: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8039BE9C: lw          $t6, 0x7D60($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X7D60);
    // 0x8039BEA0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039BEA4: addiu       $sp, $sp, -0xD8
    ctx->r29 = ADD32(ctx->r29, -0XD8);
    // 0x8039BEA8: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8039BEAC: sw          $t7, 0x7D60($at)
    MEM_W(0X7D60, ctx->r1) = ctx->r15;
    // 0x8039BEB0: addiu       $at, $zero, 0x64
    ctx->r1 = ADD32(0, 0X64);
    // 0x8039BEB4: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x8039BEB8: sw          $a3, 0xE4($sp)
    MEM_W(0XE4, ctx->r29) = ctx->r7;
    // 0x8039BEBC: lh          $a3, 0xEA($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XEA);
    // 0x8039BEC0: sw          $s3, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r19;
    // 0x8039BEC4: sw          $s2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r18;
    // 0x8039BEC8: sw          $s1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r17;
    // 0x8039BECC: addiu       $v0, $zero, 0x1E
    ctx->r2 = ADD32(0, 0X1E);
    // 0x8039BED0: mfhi        $t8
    ctx->r24 = hi;
    // 0x8039BED4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039BED8: andi        $s1, $a0, 0xFF
    ctx->r17 = ctx->r4 & 0XFF;
    // 0x8039BEDC: andi        $s2, $a1, 0xFF
    ctx->r18 = ctx->r5 & 0XFF;
    // 0x8039BEE0: andi        $s3, $a2, 0xFF
    ctx->r19 = ctx->r6 & 0XFF;
    // 0x8039BEE4: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x8039BEE8: sw          $s7, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r23;
    // 0x8039BEEC: sw          $s6, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r22;
    // 0x8039BEF0: sw          $s5, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r21;
    // 0x8039BEF4: sw          $s4, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r20;
    // 0x8039BEF8: sw          $s0, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r16;
    // 0x8039BEFC: sdc1        $f22, 0x30($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X30, ctx->r29);
    // 0x8039BF00: sdc1        $f20, 0x28($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X28, ctx->r29);
    // 0x8039BF04: sw          $a0, 0xD8($sp)
    MEM_W(0XD8, ctx->r29) = ctx->r4;
    // 0x8039BF08: sw          $a1, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->r5;
    // 0x8039BF0C: sw          $a2, 0xE0($sp)
    MEM_W(0XE0, ctx->r29) = ctx->r6;
    // 0x8039BF10: bne         $a3, $v0, L_8039C210
    if (ctx->r7 != ctx->r2) {
        // 0x8039BF14: sw          $t8, 0x7D60($at)
        MEM_W(0X7D60, ctx->r1) = ctx->r24;
            goto L_8039C210;
    }
    // 0x8039BF14: sw          $t8, 0x7D60($at)
    MEM_W(0X7D60, ctx->r1) = ctx->r24;
    // 0x8039BF18: lbu         $t3, 0x103($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X103);
    // 0x8039BF1C: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
    // 0x8039BF20: bne         $t3, $v0, L_8039C038
    if (ctx->r11 != ctx->r2) {
        // 0x8039BF24: nop
    
            goto L_8039C038;
    }
    // 0x8039BF24: nop

    // 0x8039BF28: lbu         $t9, 0x22($ra)
    ctx->r25 = MEM_BU(ctx->r31, 0X22);
    // 0x8039BF2C: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8039BF30: slti        $at, $t8, 0x32
    ctx->r1 = SIGNED(ctx->r24) < 0X32 ? 1 : 0;
    // 0x8039BF34: sll         $t6, $t9, 30
    ctx->r14 = S32(ctx->r25 << 30);
    // 0x8039BF38: srl         $t7, $t6, 31
    ctx->r15 = S32(U32(ctx->r14) >> 31);
    // 0x8039BF3C: bne         $s4, $t7, L_8039BFB8
    if (ctx->r20 != ctx->r15) {
        // 0x8039BF40: nop
    
            goto L_8039BFB8;
    }
    // 0x8039BF40: nop

    // 0x8039BF44: beq         $at, $zero, L_8039BF90
    if (ctx->r1 == 0) {
        // 0x8039BF48: lui         $t1, 0xFA00
        ctx->r9 = S32(0XFA00 << 16);
            goto L_8039BF90;
    }
    // 0x8039BF48: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039BF4C: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039BF50: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039BF54: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039BF58: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x8039BF5C: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x8039BF60: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039BF64: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039BF68: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8039BF6C: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8039BF70: andi        $t8, $s3, 0xFF
    ctx->r24 = ctx->r19 & 0XFF;
    // 0x8039BF74: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8039BF78: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8039BF7C: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039BF80: ori         $t8, $t9, 0xF0
    ctx->r24 = ctx->r25 | 0XF0;
    // 0x8039BF84: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039BF88: b           L_8039C1CC
    // 0x8039BF8C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039BF8C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039BF90:
    // 0x8039BF90: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039BF94: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039BF98: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039BF9C: lui         $s6, 0xFF80
    ctx->r22 = S32(0XFF80 << 16);
    // 0x8039BFA0: ori         $s6, $s6, 0xF0
    ctx->r22 = ctx->r22 | 0XF0;
    // 0x8039BFA4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039BFA8: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039BFAC: sw          $s6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r22;
    // 0x8039BFB0: b           L_8039C1CC
    // 0x8039BFB4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039BFB4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039BFB8:
    // 0x8039BFB8: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8039BFBC: lw          $t7, 0x7D60($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X7D60);
    // 0x8039BFC0: slti        $at, $t7, 0x32
    ctx->r1 = SIGNED(ctx->r15) < 0X32 ? 1 : 0;
    // 0x8039BFC4: beq         $at, $zero, L_8039C00C
    if (ctx->r1 == 0) {
        // 0x8039BFC8: lui         $s0, 0x801E
        ctx->r16 = S32(0X801E << 16);
            goto L_8039C00C;
    }
    // 0x8039BFC8: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039BFCC: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039BFD0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039BFD4: andi        $t7, $s2, 0xFF
    ctx->r15 = ctx->r18 & 0XFF;
    // 0x8039BFD8: sll         $t6, $s1, 24
    ctx->r14 = S32(ctx->r17 << 24);
    // 0x8039BFDC: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039BFE0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039BFE4: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8039BFE8: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8039BFEC: andi        $t7, $s3, 0xFF
    ctx->r15 = ctx->r19 & 0XFF;
    // 0x8039BFF0: sll         $t6, $t7, 8
    ctx->r14 = S32(ctx->r15 << 8);
    // 0x8039BFF4: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8039BFF8: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039BFFC: ori         $t7, $t9, 0xF0
    ctx->r15 = ctx->r25 | 0XF0;
    // 0x8039C000: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039C004: b           L_8039C1CC
    // 0x8039C008: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C008: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C00C:
    // 0x8039C00C: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C010: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C014: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C018: lui         $s6, 0xFF80
    ctx->r22 = S32(0XFF80 << 16);
    // 0x8039C01C: ori         $s6, $s6, 0xF0
    ctx->r22 = ctx->r22 | 0XF0;
    // 0x8039C020: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C024: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C028: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C02C: sw          $s6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r22;
    // 0x8039C030: b           L_8039C1CC
    // 0x8039C034: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C034: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C038:
    // 0x8039C038: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8039C03C: lb          $t6, 0x7DFE($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X7DFE);
    // 0x8039C040: bne         $t6, $zero, L_8039C090
    if (ctx->r14 != 0) {
        // 0x8039C044: addiu       $s7, $zero, 0xFF
        ctx->r23 = ADD32(0, 0XFF);
            goto L_8039C090;
    }
    // 0x8039C044: addiu       $s7, $zero, 0xFF
    ctx->r23 = ADD32(0, 0XFF);
    // 0x8039C048: beq         $s7, $t3, L_8039C090
    if (ctx->r23 == ctx->r11) {
        // 0x8039C04C: lui         $t1, 0xFA00
        ctx->r9 = S32(0XFA00 << 16);
            goto L_8039C090;
    }
    // 0x8039C04C: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C050: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C054: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C058: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C05C: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x8039C060: sll         $t8, $s1, 24
    ctx->r24 = S32(ctx->r17 << 24);
    // 0x8039C064: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039C068: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039C06C: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8039C070: or          $t7, $t8, $t9
    ctx->r15 = ctx->r24 | ctx->r25;
    // 0x8039C074: andi        $t6, $s3, 0xFF
    ctx->r14 = ctx->r19 & 0XFF;
    // 0x8039C078: sll         $t8, $t6, 8
    ctx->r24 = S32(ctx->r14 << 8);
    // 0x8039C07C: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8039C080: ori         $t6, $t9, 0x14
    ctx->r14 = ctx->r25 | 0X14;
    // 0x8039C084: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039C088: b           L_8039C1CC
    // 0x8039C08C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C08C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C090:
    // 0x8039C090: addiu       $s7, $zero, 0xFF
    ctx->r23 = ADD32(0, 0XFF);
    // 0x8039C094: bnel        $s7, $t3, L_8039C134
    if (ctx->r23 != ctx->r11) {
        // 0x8039C098: lw          $ra, 0xF0($sp)
        ctx->r31 = MEM_W(ctx->r29, 0XF0);
            goto L_8039C134;
    }
    goto skip_0;
    // 0x8039C098: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
    skip_0:
    // 0x8039C09C: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
    // 0x8039C0A0: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8039C0A4: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C0A8: lbu         $t7, 0x22($ra)
    ctx->r15 = MEM_BU(ctx->r31, 0X22);
    // 0x8039C0AC: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C0B0: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C0B4: sll         $t8, $t7, 30
    ctx->r24 = S32(ctx->r15 << 30);
    // 0x8039C0B8: srl         $t9, $t8, 31
    ctx->r25 = S32(U32(ctx->r24) >> 31);
    // 0x8039C0BC: bne         $s4, $t9, L_8039C0F8
    if (ctx->r20 != ctx->r25) {
        // 0x8039C0C0: addiu       $t8, $s1, -0xF
        ctx->r24 = ADD32(ctx->r17, -0XF);
            goto L_8039C0F8;
    }
    // 0x8039C0C0: addiu       $t8, $s1, -0xF
    ctx->r24 = ADD32(ctx->r17, -0XF);
    // 0x8039C0C4: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C0C8: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C0CC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C0D0: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x8039C0D4: lui         $at, 0x28
    ctx->r1 = S32(0X28 << 16);
    // 0x8039C0D8: or          $t7, $t9, $at
    ctx->r15 = ctx->r25 | ctx->r1;
    // 0x8039C0DC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039C0E0: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C0E4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039C0E8: ori         $t8, $t7, 0x28FF
    ctx->r24 = ctx->r15 | 0X28FF;
    // 0x8039C0EC: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039C0F0: b           L_8039C1CC
    // 0x8039C0F4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C0F4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C0F8:
    // 0x8039C0F8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C0FC: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x8039C100: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x8039C104: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039C108: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039C10C: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x8039C110: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x8039C114: andi        $t8, $s3, 0xFF
    ctx->r24 = ctx->r19 & 0XFF;
    // 0x8039C118: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x8039C11C: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8039C120: ori         $t8, $t9, 0xFF
    ctx->r24 = ctx->r25 | 0XFF;
    // 0x8039C124: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039C128: b           L_8039C1CC
    // 0x8039C12C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C12C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039C130: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
L_8039C134:
    // 0x8039C134: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8039C138: lbu         $t6, 0x22($ra)
    ctx->r14 = MEM_BU(ctx->r31, 0X22);
    // 0x8039C13C: sll         $t7, $t6, 30
    ctx->r15 = S32(ctx->r14 << 30);
    // 0x8039C140: srl         $t9, $t7, 31
    ctx->r25 = S32(U32(ctx->r15) >> 31);
    // 0x8039C144: bne         $s4, $t9, L_8039C18C
    if (ctx->r20 != ctx->r25) {
        // 0x8039C148: lui         $s0, 0x801E
        ctx->r16 = S32(0X801E << 16);
            goto L_8039C18C;
    }
    // 0x8039C148: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C14C: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C150: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C154: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x8039C158: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x8039C15C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C160: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C164: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x8039C168: or          $t6, $t7, $t8
    ctx->r14 = ctx->r15 | ctx->r24;
    // 0x8039C16C: andi        $t9, $s3, 0xFF
    ctx->r25 = ctx->r19 & 0XFF;
    // 0x8039C170: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x8039C174: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8039C178: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C17C: ori         $t9, $t8, 0xF0
    ctx->r25 = ctx->r24 | 0XF0;
    // 0x8039C180: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039C184: b           L_8039C1CC
    // 0x8039C188: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C1CC;
    // 0x8039C188: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C18C:
    // 0x8039C18C: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C190: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C194: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C198: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x8039C19C: sll         $t8, $s1, 24
    ctx->r24 = S32(ctx->r17 << 24);
    // 0x8039C1A0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039C1A4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039C1A8: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x8039C1AC: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8039C1B0: andi        $t9, $s3, 0xFF
    ctx->r25 = ctx->r19 & 0XFF;
    // 0x8039C1B4: sll         $t8, $t9, 8
    ctx->r24 = S32(ctx->r25 << 8);
    // 0x8039C1B8: or          $t6, $t7, $t8
    ctx->r14 = ctx->r15 | ctx->r24;
    // 0x8039C1BC: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C1C0: ori         $t9, $t6, 0x46
    ctx->r25 = ctx->r14 | 0X46;
    // 0x8039C1C4: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039C1C8: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C1CC:
    // 0x8039C1CC: lwc1        $f20, 0xFC($sp)
    ctx->f20.u32l = MEM_W(ctx->r29, 0XFC);
    // 0x8039C1D0: lh          $t7, 0xF6($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XF6);
    // 0x8039C1D4: lh          $t8, 0xFA($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XFA);
    // 0x8039C1D8: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039C1DC: addiu       $a1, $a1, -0x58A0
    ctx->r5 = ADD32(ctx->r5, -0X58A0);
    // 0x8039C1E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039C1E4: addiu       $a2, $zero, 0x2B
    ctx->r6 = ADD32(0, 0X2B);
    // 0x8039C1E8: addiu       $a3, $zero, 0x2B
    ctx->r7 = ADD32(0, 0X2B);
    // 0x8039C1EC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039C1F0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8039C1F4: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8039C1F8: swc1        $f20, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f20.u32l;
    // 0x8039C1FC: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x8039C200: jal         0x8039C834
    // 0x8039C204: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_0;
    // 0x8039C204: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    after_0:
    // 0x8039C208: b           L_8039C5C8
    // 0x8039C20C: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
        goto L_8039C5C8;
    // 0x8039C20C: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_8039C210:
    // 0x8039C210: lh          $t9, 0xEE($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XEE);
    // 0x8039C214: sll         $t2, $a3, 16
    ctx->r10 = S32(ctx->r7 << 16);
    // 0x8039C218: sra         $t6, $t2, 16
    ctx->r14 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8039C21C: slt         $at, $t9, $a3
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x8039C220: bne         $at, $zero, L_8039C5C4
    if (ctx->r1 != 0) {
        // 0x8039C224: or          $t2, $t6, $zero
        ctx->r10 = ctx->r14 | 0;
            goto L_8039C5C4;
    }
    // 0x8039C224: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
    // 0x8039C228: lh          $t7, 0xF6($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XF6);
    // 0x8039C22C: lh          $t8, 0xFA($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XFA);
    // 0x8039C230: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x8039C234: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x8039C238: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x8039C23C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039C240: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039C244: lwc1        $f20, 0xFC($sp)
    ctx->f20.u32l = MEM_W(ctx->r29, 0XFC);
    // 0x8039C248: lui         $s6, 0xFF80
    ctx->r22 = S32(0XFF80 << 16);
    // 0x8039C24C: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8039C250: addiu       $s0, $s0, -0x6184
    ctx->r16 = ADD32(ctx->r16, -0X6184);
    // 0x8039C254: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8039C258: ori         $s6, $s6, 0xF0
    ctx->r22 = ctx->r22 | 0XF0;
    // 0x8039C25C: swc1        $f8, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->f8.u32l;
    // 0x8039C260: lbu         $t3, 0x103($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X103);
    // 0x8039C264: addiu       $s7, $zero, 0xFF
    ctx->r23 = ADD32(0, 0XFF);
    // 0x8039C268: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x8039C26C: swc1        $f16, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f16.u32l;
    // 0x8039C270: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
    // 0x8039C274: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C278: div.s       $f22, $f20, $f4
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f22.fl = DIV_S(ctx->f20.fl, ctx->f4.fl);
L_8039C27C:
    // 0x8039C27C: andi        $v0, $t2, 0xFF
    ctx->r2 = ctx->r10 & 0XFF;
    // 0x8039C280: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x8039C284: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x8039C288: addiu       $t9, $t9, 0x71D0
    ctx->r25 = ADD32(ctx->r25, 0X71D0);
    // 0x8039C28C: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x8039C290: addu        $t0, $t6, $t9
    ctx->r8 = ADD32(ctx->r14, ctx->r25);
    // 0x8039C294: lbu         $s5, 0x4($t0)
    ctx->r21 = MEM_BU(ctx->r8, 0X4);
    // 0x8039C298: lb          $t6, 0x0($t0)
    ctx->r14 = MEM_B(ctx->r8, 0X0);
    // 0x8039C29C: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x8039C2A0: sll         $t7, $s5, 2
    ctx->r15 = S32(ctx->r21 << 2);
    // 0x8039C2A4: addu        $t7, $t7, $s5
    ctx->r15 = ADD32(ctx->r15, ctx->r21);
    // 0x8039C2A8: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8039C2AC: subu        $t7, $t7, $s5
    ctx->r15 = SUB32(ctx->r15, ctx->r21);
    // 0x8039C2B0: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8039C2B4: subu        $t7, $t7, $s5
    ctx->r15 = SUB32(ctx->r15, ctx->r21);
    // 0x8039C2B8: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8039C2BC: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
    // 0x8039C2C0: bgez        $t6, L_8039C2CC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8039C2C4: andi        $s5, $t7, 0xFFFF
        ctx->r21 = ctx->r15 & 0XFFFF;
            goto L_8039C2CC;
    }
    // 0x8039C2C4: andi        $s5, $t7, 0xFFFF
    ctx->r21 = ctx->r15 & 0XFFFF;
    // 0x8039C2C8: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
L_8039C2CC:
    // 0x8039C2CC: lb          $t9, 0x1($t0)
    ctx->r25 = MEM_B(ctx->r8, 0X1);
    // 0x8039C2D0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8039C2D4: addu        $t7, $ra, $v0
    ctx->r15 = ADD32(ctx->r31, ctx->r2);
    // 0x8039C2D8: slti        $at, $t9, -0x1
    ctx->r1 = SIGNED(ctx->r25) < -0X1 ? 1 : 0;
    // 0x8039C2DC: beq         $at, $zero, L_8039C2E8
    if (ctx->r1 == 0) {
        // 0x8039C2E0: addu        $t6, $t6, $v0
        ctx->r14 = ADD32(ctx->r14, ctx->r2);
            goto L_8039C2E8;
    }
    // 0x8039C2E0: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x8039C2E4: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
L_8039C2E8:
    // 0x8039C2E8: bne         $t2, $t3, L_8039C3CC
    if (ctx->r10 != ctx->r11) {
        // 0x8039C2EC: nop
    
            goto L_8039C3CC;
    }
    // 0x8039C2EC: nop

    // 0x8039C2F0: lbu         $t8, 0x4($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X4);
    // 0x8039C2F4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8039C2F8: sll         $t6, $t8, 30
    ctx->r14 = S32(ctx->r24 << 30);
    // 0x8039C2FC: srl         $t9, $t6, 31
    ctx->r25 = S32(U32(ctx->r14) >> 31);
    // 0x8039C300: bne         $s4, $t9, L_8039C368
    if (ctx->r20 != ctx->r25) {
        // 0x8039C304: nop
    
            goto L_8039C368;
    }
    // 0x8039C304: nop

    // 0x8039C308: lw          $t7, 0x7D60($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X7D60);
    // 0x8039C30C: slti        $at, $t7, 0x32
    ctx->r1 = SIGNED(ctx->r15) < 0X32 ? 1 : 0;
    // 0x8039C310: beql        $at, $zero, L_8039C354
    if (ctx->r1 == 0) {
        // 0x8039C314: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8039C354;
    }
    goto skip_1;
    // 0x8039C314: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_1:
    // 0x8039C318: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C31C: andi        $t7, $s2, 0xFF
    ctx->r15 = ctx->r18 & 0XFF;
    // 0x8039C320: sll         $t9, $s1, 24
    ctx->r25 = S32(ctx->r17 << 24);
    // 0x8039C324: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C328: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C32C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039C330: or          $t6, $t9, $t8
    ctx->r14 = ctx->r25 | ctx->r24;
    // 0x8039C334: andi        $t7, $s3, 0xFF
    ctx->r15 = ctx->r19 & 0XFF;
    // 0x8039C338: sll         $t9, $t7, 8
    ctx->r25 = S32(ctx->r15 << 8);
    // 0x8039C33C: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8039C340: ori         $t7, $t8, 0xF0
    ctx->r15 = ctx->r24 | 0XF0;
    // 0x8039C344: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039C348: b           L_8039C4F8
    // 0x8039C34C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C34C: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039C350: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_8039C354:
    // 0x8039C354: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039C358: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039C35C: sw          $s6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r22;
    // 0x8039C360: b           L_8039C4F8
    // 0x8039C364: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C364: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C368:
    // 0x8039C368: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8039C36C: lw          $t9, 0x7D60($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X7D60);
    // 0x8039C370: slti        $at, $t9, 0x32
    ctx->r1 = SIGNED(ctx->r25) < 0X32 ? 1 : 0;
    // 0x8039C374: beql        $at, $zero, L_8039C3B8
    if (ctx->r1 == 0) {
        // 0x8039C378: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8039C3B8;
    }
    goto skip_2;
    // 0x8039C378: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_2:
    // 0x8039C37C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C380: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x8039C384: sll         $t6, $s1, 24
    ctx->r14 = S32(ctx->r17 << 24);
    // 0x8039C388: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C38C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C390: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x8039C394: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x8039C398: andi        $t9, $s3, 0xFF
    ctx->r25 = ctx->r19 & 0XFF;
    // 0x8039C39C: sll         $t6, $t9, 8
    ctx->r14 = S32(ctx->r25 << 8);
    // 0x8039C3A0: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x8039C3A4: ori         $t9, $t8, 0xF0
    ctx->r25 = ctx->r24 | 0XF0;
    // 0x8039C3A8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039C3AC: b           L_8039C4F8
    // 0x8039C3B0: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C3B0: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039C3B4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_8039C3B8:
    // 0x8039C3B8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039C3BC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039C3C0: sw          $s6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r22;
    // 0x8039C3C4: b           L_8039C4F8
    // 0x8039C3C8: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C3C8: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C3CC:
    // 0x8039C3CC: lb          $t6, 0x7DE0($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X7DE0);
    // 0x8039C3D0: bne         $t6, $zero, L_8039C418
    if (ctx->r14 != 0) {
        // 0x8039C3D4: nop
    
            goto L_8039C418;
    }
    // 0x8039C3D4: nop

    // 0x8039C3D8: beq         $s7, $t3, L_8039C418
    if (ctx->r23 == ctx->r11) {
        // 0x8039C3DC: nop
    
            goto L_8039C418;
    }
    // 0x8039C3DC: nop

    // 0x8039C3E0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C3E4: andi        $t6, $s2, 0xFF
    ctx->r14 = ctx->r18 & 0XFF;
    // 0x8039C3E8: sll         $t7, $s1, 24
    ctx->r15 = S32(ctx->r17 << 24);
    // 0x8039C3EC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C3F0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C3F4: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x8039C3F8: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x8039C3FC: andi        $t6, $s3, 0xFF
    ctx->r14 = ctx->r19 & 0XFF;
    // 0x8039C400: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x8039C404: or          $t8, $t9, $t7
    ctx->r24 = ctx->r25 | ctx->r15;
    // 0x8039C408: ori         $t6, $t8, 0x14
    ctx->r14 = ctx->r24 | 0X14;
    // 0x8039C40C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039C410: b           L_8039C4F8
    // 0x8039C414: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C414: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C418:
    // 0x8039C418: bne         $s7, $t3, L_8039C494
    if (ctx->r23 != ctx->r11) {
        // 0x8039C41C: sll         $t6, $s1, 24
        ctx->r14 = S32(ctx->r17 << 24);
            goto L_8039C494;
    }
    // 0x8039C41C: sll         $t6, $s1, 24
    ctx->r14 = S32(ctx->r17 << 24);
    // 0x8039C420: addu        $t9, $ra, $v0
    ctx->r25 = ADD32(ctx->r31, ctx->r2);
    // 0x8039C424: lbu         $t7, 0x4($t9)
    ctx->r15 = MEM_BU(ctx->r25, 0X4);
    // 0x8039C428: sll         $t8, $t7, 30
    ctx->r24 = S32(ctx->r15 << 30);
    // 0x8039C42C: srl         $t6, $t8, 31
    ctx->r14 = S32(U32(ctx->r24) >> 31);
    // 0x8039C430: bnel        $s4, $t6, L_8039C460
    if (ctx->r20 != ctx->r14) {
        // 0x8039C434: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8039C460;
    }
    goto skip_3;
    // 0x8039C434: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_3:
    // 0x8039C438: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C43C: addiu       $t8, $s1, 0xF
    ctx->r24 = ADD32(ctx->r17, 0XF);
    // 0x8039C440: sll         $t6, $t8, 24
    ctx->r14 = S32(ctx->r24 << 24);
    // 0x8039C444: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039C448: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039C44C: ori         $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 | 0XFF;
    // 0x8039C450: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039C454: b           L_8039C4F8
    // 0x8039C458: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C458: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039C45C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_8039C460:
    // 0x8039C460: andi        $t9, $s2, 0xFF
    ctx->r25 = ctx->r18 & 0XFF;
    // 0x8039C464: sll         $t6, $s1, 24
    ctx->r14 = S32(ctx->r17 << 24);
    // 0x8039C468: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039C46C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039C470: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8039C474: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8039C478: andi        $t9, $s3, 0xFF
    ctx->r25 = ctx->r19 & 0XFF;
    // 0x8039C47C: sll         $t6, $t9, 8
    ctx->r14 = S32(ctx->r25 << 8);
    // 0x8039C480: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x8039C484: ori         $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 | 0XFF;
    // 0x8039C488: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039C48C: b           L_8039C4F8
    // 0x8039C490: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C490: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C494:
    // 0x8039C494: andi        $t7, $s2, 0xFF
    ctx->r15 = ctx->r18 & 0XFF;
    // 0x8039C498: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8039C49C: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x8039C4A0: andi        $t7, $s3, 0xFF
    ctx->r15 = ctx->r19 & 0XFF;
    // 0x8039C4A4: sll         $t6, $t7, 8
    ctx->r14 = S32(ctx->r15 << 8);
    // 0x8039C4A8: addu        $t9, $ra, $v0
    ctx->r25 = ADD32(ctx->r31, ctx->r2);
    // 0x8039C4AC: lbu         $t7, 0x4($t9)
    ctx->r15 = MEM_BU(ctx->r25, 0X4);
    // 0x8039C4B0: or          $a0, $t8, $t6
    ctx->r4 = ctx->r24 | ctx->r14;
    // 0x8039C4B4: sll         $t8, $t7, 30
    ctx->r24 = S32(ctx->r15 << 30);
    // 0x8039C4B8: srl         $t6, $t8, 31
    ctx->r14 = S32(U32(ctx->r24) >> 31);
    // 0x8039C4BC: bnel        $s4, $t6, L_8039C4E4
    if (ctx->r20 != ctx->r14) {
        // 0x8039C4C0: lw          $v0, 0x0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X0);
            goto L_8039C4E4;
    }
    goto skip_4;
    // 0x8039C4C0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    skip_4:
    // 0x8039C4C4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C4C8: ori         $t7, $a0, 0xF0
    ctx->r15 = ctx->r4 | 0XF0;
    // 0x8039C4CC: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039C4D0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039C4D4: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039C4D8: b           L_8039C4F8
    // 0x8039C4DC: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
        goto L_8039C4F8;
    // 0x8039C4DC: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039C4E0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_8039C4E4:
    // 0x8039C4E4: ori         $t6, $a0, 0x46
    ctx->r14 = ctx->r4 | 0X46;
    // 0x8039C4E8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039C4EC: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039C4F0: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039C4F4: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
L_8039C4F8:
    // 0x8039C4F8: lb          $t9, 0x1($t0)
    ctx->r25 = MEM_B(ctx->r8, 0X1);
    // 0x8039C4FC: lb          $t7, 0x0($t0)
    ctx->r15 = MEM_B(ctx->r8, 0X0);
    // 0x8039C500: lwc1        $f10, 0x64($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X64);
    // 0x8039C504: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x8039C508: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x8039C50C: lbu         $a3, 0x3($t0)
    ctx->r7 = MEM_BU(ctx->r8, 0X3);
    // 0x8039C510: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039C514: lui         $t6, 0x800C
    ctx->r14 = S32(0X800C << 16);
    // 0x8039C518: addiu       $t6, $t6, -0x58A0
    ctx->r14 = ADD32(ctx->r14, -0X58A0);
    // 0x8039C51C: addiu       $t8, $s5, 0xFA0
    ctx->r24 = ADD32(ctx->r21, 0XFA0);
    // 0x8039C520: addu        $a1, $t8, $t6
    ctx->r5 = ADD32(ctx->r24, ctx->r14);
    // 0x8039C524: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039C528: mul.s       $f0, $f4, $f20
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f0.fl = MUL_S(ctx->f4.fl, ctx->f20.fl);
    // 0x8039C52C: lwc1        $f4, 0x60($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X60);
    // 0x8039C530: sll         $t8, $a3, 1
    ctx->r24 = S32(ctx->r7 << 1);
    // 0x8039C534: andi        $a3, $t8, 0xFFFF
    ctx->r7 = ctx->r24 & 0XFFFF;
    // 0x8039C538: lbu         $a2, 0x2($t0)
    ctx->r6 = MEM_BU(ctx->r8, 0X2);
    // 0x8039C53C: mul.s       $f2, $f8, $f20
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f2.fl = MUL_S(ctx->f8.fl, ctx->f20.fl);
    // 0x8039C540: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8039C544: add.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f0.fl;
    // 0x8039C548: sll         $t9, $a2, 1
    ctx->r25 = S32(ctx->r6 << 1);
    // 0x8039C54C: andi        $a2, $t9, 0xFFFF
    ctx->r6 = ctx->r25 & 0XFFFF;
    // 0x8039C550: swc1        $f22, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f22.u32l;
    // 0x8039C554: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8039C558: swc1        $f22, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f22.u32l;
    // 0x8039C55C: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x8039C560: add.s       $f16, $f10, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = ctx->f10.fl + ctx->f2.fl;
    // 0x8039C564: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x8039C568: sh          $t2, 0xD0($sp)
    MEM_H(0XD0, ctx->r29) = ctx->r10;
    // 0x8039C56C: sw          $t3, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r11;
    // 0x8039C570: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x8039C574: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x8039C578: nop

    // 0x8039C57C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039C580: mfc1        $t7, $f8
    ctx->r15 = (int32_t)ctx->f8.u32l;
    // 0x8039C584: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039C588: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8039C58C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8039C590: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039C594: jal         0x8039C834
    // 0x8039C598: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_1;
    // 0x8039C598: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    after_1:
    // 0x8039C59C: lh          $t2, 0xD0($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XD0);
    // 0x8039C5A0: lh          $t8, 0xEE($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XEE);
    // 0x8039C5A4: lui         $t1, 0xFA00
    ctx->r9 = S32(0XFA00 << 16);
    // 0x8039C5A8: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x8039C5AC: sll         $t9, $t2, 16
    ctx->r25 = S32(ctx->r10 << 16);
    // 0x8039C5B0: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039C5B4: slt         $at, $t8, $t2
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x8039C5B8: lw          $t3, 0x78($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X78);
    // 0x8039C5BC: beq         $at, $zero, L_8039C27C
    if (ctx->r1 == 0) {
        // 0x8039C5C0: lw          $ra, 0xF0($sp)
        ctx->r31 = MEM_W(ctx->r29, 0XF0);
            goto L_8039C27C;
    }
    // 0x8039C5C0: lw          $ra, 0xF0($sp)
    ctx->r31 = MEM_W(ctx->r29, 0XF0);
L_8039C5C4:
    // 0x8039C5C4: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_8039C5C8:
    // 0x8039C5C8: ldc1        $f20, 0x28($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X28);
    // 0x8039C5CC: ldc1        $f22, 0x30($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X30);
    // 0x8039C5D0: lw          $s0, 0x3C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X3C);
    // 0x8039C5D4: lw          $s1, 0x40($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X40);
    // 0x8039C5D8: lw          $s2, 0x44($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X44);
    // 0x8039C5DC: lw          $s3, 0x48($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X48);
    // 0x8039C5E0: lw          $s4, 0x4C($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X4C);
    // 0x8039C5E4: lw          $s5, 0x50($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X50);
    // 0x8039C5E8: lw          $s6, 0x54($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X54);
    // 0x8039C5EC: lw          $s7, 0x58($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X58);
    // 0x8039C5F0: jr          $ra
    // 0x8039C5F4: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
    return;
    // 0x8039C5F4: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
;}
RECOMP_FUNC void func_8039C5F8_7ADCA8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039C5F8: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x8039C5FC: lh          $t8, 0x6A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X6A);
    // 0x8039C600: sw          $s4, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r20;
    // 0x8039C604: sw          $s3, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r19;
    // 0x8039C608: sll         $s3, $a0, 16
    ctx->r19 = S32(ctx->r4 << 16);
    // 0x8039C60C: sll         $s4, $a1, 16
    ctx->r20 = S32(ctx->r5 << 16);
    // 0x8039C610: sdc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X30, ctx->r29);
    // 0x8039C614: mtc1        $a2, $f20
    ctx->f20.u32l = ctx->r6;
    // 0x8039C618: sra         $t7, $s4, 16
    ctx->r15 = S32(SIGNED(ctx->r20) >> 16);
    // 0x8039C61C: sra         $t6, $s3, 16
    ctx->r14 = S32(SIGNED(ctx->r19) >> 16);
    // 0x8039C620: sw          $s5, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r21;
    // 0x8039C624: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039C628: or          $s5, $a3, $zero
    ctx->r21 = ctx->r7 | 0;
    // 0x8039C62C: or          $s3, $t6, $zero
    ctx->r19 = ctx->r14 | 0;
    // 0x8039C630: or          $s4, $t7, $zero
    ctx->r20 = ctx->r15 | 0;
    // 0x8039C634: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8039C638: sw          $s2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r18;
    // 0x8039C63C: sw          $s1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r17;
    // 0x8039C640: sw          $s0, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r16;
    // 0x8039C644: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x8039C648: bne         $t8, $at, L_8039C664
    if (ctx->r24 != ctx->r1) {
        // 0x8039C64C: sw          $a1, 0x5C($sp)
        MEM_W(0X5C, ctx->r29) = ctx->r5;
            goto L_8039C664;
    }
    // 0x8039C64C: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    // 0x8039C650: addiu       $s0, $zero, 0xC8
    ctx->r16 = ADD32(0, 0XC8);
    // 0x8039C654: addiu       $s1, $zero, 0xC8
    ctx->r17 = ADD32(0, 0XC8);
    // 0x8039C658: addiu       $s2, $zero, 0xFF
    ctx->r18 = ADD32(0, 0XFF);
    // 0x8039C65C: b           L_8039C674
    // 0x8039C660: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
        goto L_8039C674;
    // 0x8039C660: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
L_8039C664:
    // 0x8039C664: addiu       $s0, $zero, 0x3C
    ctx->r16 = ADD32(0, 0X3C);
    // 0x8039C668: addiu       $s1, $zero, 0x3C
    ctx->r17 = ADD32(0, 0X3C);
    // 0x8039C66C: addiu       $s2, $zero, 0x64
    ctx->r18 = ADD32(0, 0X64);
    // 0x8039C670: addiu       $t1, $zero, 0x80
    ctx->r9 = ADD32(0, 0X80);
L_8039C674:
    // 0x8039C674: lui         $at, 0x41AC
    ctx->r1 = S32(0X41AC << 16);
    // 0x8039C678: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039C67C: mtc1        $s3, $f6
    ctx->f6.u32l = ctx->r19;
    // 0x8039C680: mtc1        $s4, $f18
    ctx->f18.u32l = ctx->r20;
    // 0x8039C684: mul.s       $f0, $f4, $f20
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f0.fl = MUL_S(ctx->f4.fl, ctx->f20.fl);
    // 0x8039C688: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x8039C68C: addiu       $t2, $t2, -0x6184
    ctx->r10 = ADD32(ctx->r10, -0X6184);
    // 0x8039C690: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x8039C694: andi        $v0, $t1, 0xFF
    ctx->r2 = ctx->r9 & 0XFF;
    // 0x8039C698: sll         $t4, $v0, 24
    ctx->r12 = S32(ctx->r2 << 24);
    // 0x8039C69C: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8039C6A0: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x8039C6A4: addiu       $t9, $t0, 0x8
    ctx->r25 = ADD32(ctx->r8, 0X8);
    // 0x8039C6A8: sw          $t9, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r25;
    // 0x8039C6AC: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x8039C6B0: cvt.s.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8039C6B4: sll         $t7, $v0, 8
    ctx->r15 = S32(ctx->r2 << 8);
    // 0x8039C6B8: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8039C6BC: ori         $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 | 0XFF;
    // 0x8039C6C0: lui         $t3, 0xFA00
    ctx->r11 = S32(0XFA00 << 16);
    // 0x8039C6C4: sub.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f0.fl;
    // 0x8039C6C8: sw          $t3, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r11;
    // 0x8039C6CC: sw          $t9, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r25;
    // 0x8039C6D0: sub.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f0.fl;
    // 0x8039C6D4: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x8039C6D8: addiu       $t3, $zero, 0x1E
    ctx->r11 = ADD32(0, 0X1E);
    // 0x8039C6DC: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x8039C6E0: addiu       $t4, $zero, 0x1E
    ctx->r12 = ADD32(0, 0X1E);
    // 0x8039C6E4: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x8039C6E8: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x8039C6EC: mfc1        $t6, $f16
    ctx->r14 = (int32_t)ctx->f16.u32l;
    // 0x8039C6F0: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x8039C6F4: sw          $t9, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r25;
    // 0x8039C6F8: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x8039C6FC: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    // 0x8039C700: sw          $s5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r21;
    // 0x8039C704: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x8039C708: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x8039C70C: andi        $a2, $s2, 0xFF
    ctx->r6 = ctx->r18 & 0XFF;
    // 0x8039C710: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x8039C714: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8039C718: jal         0x8039BE98
    // 0x8039C71C: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    draw_level_rings_segment(rdram, ctx);
        goto after_0;
    // 0x8039C71C: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    after_0:
    // 0x8039C720: addiu       $t3, $zero, 0x9
    ctx->r11 = ADD32(0, 0X9);
    // 0x8039C724: addiu       $t4, $zero, 0xFF
    ctx->r12 = ADD32(0, 0XFF);
    // 0x8039C728: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    // 0x8039C72C: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x8039C730: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x8039C734: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x8039C738: andi        $a2, $s2, 0xFF
    ctx->r6 = ctx->r18 & 0XFF;
    // 0x8039C73C: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x8039C740: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8039C744: sw          $s5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r21;
    // 0x8039C748: sw          $s3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r19;
    // 0x8039C74C: sw          $s4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r20;
    // 0x8039C750: jal         0x8039BE98
    // 0x8039C754: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    draw_level_rings_segment(rdram, ctx);
        goto after_1;
    // 0x8039C754: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    after_1:
    // 0x8039C758: addiu       $t5, $zero, 0xA
    ctx->r13 = ADD32(0, 0XA);
    // 0x8039C75C: addiu       $t6, $zero, 0x10
    ctx->r14 = ADD32(0, 0X10);
    // 0x8039C760: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8039C764: sw          $t7, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r15;
    // 0x8039C768: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8039C76C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x8039C770: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x8039C774: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x8039C778: andi        $a2, $s2, 0xFF
    ctx->r6 = ctx->r18 & 0XFF;
    // 0x8039C77C: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x8039C780: sw          $s5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r21;
    // 0x8039C784: sw          $s3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r19;
    // 0x8039C788: sw          $s4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r20;
    // 0x8039C78C: jal         0x8039BE98
    // 0x8039C790: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    draw_level_rings_segment(rdram, ctx);
        goto after_2;
    // 0x8039C790: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    after_2:
    // 0x8039C794: addiu       $t8, $zero, 0x11
    ctx->r24 = ADD32(0, 0X11);
    // 0x8039C798: addiu       $t9, $zero, 0x16
    ctx->r25 = ADD32(0, 0X16);
    // 0x8039C79C: addiu       $t3, $zero, 0xFF
    ctx->r11 = ADD32(0, 0XFF);
    // 0x8039C7A0: sw          $t3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r11;
    // 0x8039C7A4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8039C7A8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039C7AC: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x8039C7B0: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x8039C7B4: andi        $a2, $s2, 0xFF
    ctx->r6 = ctx->r18 & 0XFF;
    // 0x8039C7B8: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x8039C7BC: sw          $s5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r21;
    // 0x8039C7C0: sw          $s3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r19;
    // 0x8039C7C4: sw          $s4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r20;
    // 0x8039C7C8: jal         0x8039BE98
    // 0x8039C7CC: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    draw_level_rings_segment(rdram, ctx);
        goto after_3;
    // 0x8039C7CC: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    after_3:
    // 0x8039C7D0: addiu       $t4, $zero, 0x17
    ctx->r12 = ADD32(0, 0X17);
    // 0x8039C7D4: addiu       $t5, $zero, 0x1D
    ctx->r13 = ADD32(0, 0X1D);
    // 0x8039C7D8: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x8039C7DC: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x8039C7E0: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x8039C7E4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8039C7E8: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x8039C7EC: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x8039C7F0: andi        $a2, $s2, 0xFF
    ctx->r6 = ctx->r18 & 0XFF;
    // 0x8039C7F4: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x8039C7F8: sw          $s5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r21;
    // 0x8039C7FC: sw          $s3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r19;
    // 0x8039C800: sw          $s4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r20;
    // 0x8039C804: jal         0x8039BE98
    // 0x8039C808: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    draw_level_rings_segment(rdram, ctx);
        goto after_4;
    // 0x8039C808: swc1        $f20, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f20.u32l;
    after_4:
    // 0x8039C80C: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x8039C810: ldc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X30);
    // 0x8039C814: lw          $s0, 0x3C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X3C);
    // 0x8039C818: lw          $s1, 0x40($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X40);
    // 0x8039C81C: lw          $s2, 0x44($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X44);
    // 0x8039C820: lw          $s3, 0x48($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X48);
    // 0x8039C824: lw          $s4, 0x4C($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X4C);
    // 0x8039C828: lw          $s5, 0x50($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X50);
    // 0x8039C82C: jr          $ra
    // 0x8039C830: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    return;
    // 0x8039C830: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
;}
RECOMP_FUNC void func_8039C834_7ADEE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039C834: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8039C838: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x8039C83C: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x8039C840: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x8039C844: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x8039C848: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x8039C84C: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x8039C850: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x8039C854: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x8039C858: lw          $t6, -0x76EC($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76EC);
    // 0x8039C85C: lhu         $t8, 0x46($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X46);
    // 0x8039C860: lhu         $a3, 0x42($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X42);
    // 0x8039C864: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8039C868: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8039C86C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8039C870: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8039C874: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8039C878: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x8039C87C: addiu       $t1, $zero, 0x2
    ctx->r9 = ADD32(0, 0X2);
    // 0x8039C880: addu        $a0, $v1, $t7
    ctx->r4 = ADD32(ctx->r3, ctx->r15);
    // 0x8039C884: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x8039C888: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8039C88C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8039C890: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x8039C894: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8039C898: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8039C89C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039C8A0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039C8A4: jal         0x8013E360
    // 0x8039C8A8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    guSprite2DInit(rdram, ctx);
        goto after_0;
    // 0x8039C8A8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    after_0:
    // 0x8039C8AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039C8B0: lui         $t3, 0x900
    ctx->r11 = S32(0X900 << 16);
    // 0x8039C8B4: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x8039C8B8: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x8039C8BC: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x8039C8C0: ori         $t3, $t3, 0x18
    ctx->r11 = ctx->r11 | 0X18;
    // 0x8039C8C4: addiu       $a3, $a3, 0x4278
    ctx->r7 = ADD32(ctx->r7, 0X4278);
    // 0x8039C8C8: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x8039C8CC: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8039C8D0: lui         $t0, 0x3
    ctx->r8 = S32(0X3 << 16);
    // 0x8039C8D4: ori         $t0, $t0, 0x8000
    ctx->r8 = ctx->r8 | 0X8000;
    // 0x8039C8D8: addu        $t4, $v1, $t0
    ctx->r12 = ADD32(ctx->r3, ctx->r8);
    // 0x8039C8DC: lw          $t5, 0x914($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X914);
    // 0x8039C8E0: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
    // 0x8039C8E4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039C8E8: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8039C8EC: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x8039C8F0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8039C8F4: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x8039C8F8: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x8039C8FC: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x8039C900: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x8039C904: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039C908: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x8039C90C: lui         $at, 0xBE00
    ctx->r1 = S32(0XBE00 << 16);
    // 0x8039C910: addiu       $t9, $a1, 0x8
    ctx->r25 = ADD32(ctx->r5, 0X8);
    // 0x8039C914: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039C918: lbu         $t2, 0x53($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X53);
    // 0x8039C91C: lbu         $t6, 0x57($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X57);
    // 0x8039C920: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039C924: sll         $t3, $t2, 8
    ctx->r11 = S32(ctx->r10 << 8);
    // 0x8039C928: or          $t4, $t3, $at
    ctx->r12 = ctx->r11 | ctx->r1;
    // 0x8039C92C: or          $t7, $t4, $t6
    ctx->r15 = ctx->r12 | ctx->r14;
    // 0x8039C930: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x8039C934: lwc1        $f4, 0x48($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X48);
    // 0x8039C938: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039C93C: div.s       $f6, $f0, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f0.fl, ctx->f4.fl);
    // 0x8039C940: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8039C944: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039C948: nop

    // 0x8039C94C: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8039C950: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039C954: nop

    // 0x8039C958: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039C95C: beql        $t9, $zero, L_8039C9AC
    if (ctx->r25 == 0) {
        // 0x8039C960: mfc1        $t9, $f8
        ctx->r25 = (int32_t)ctx->f8.u32l;
            goto L_8039C9AC;
    }
    goto skip_0;
    // 0x8039C960: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    skip_0:
    // 0x8039C964: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8039C968: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039C96C: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x8039C970: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8039C974: nop

    // 0x8039C978: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x8039C97C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8039C980: nop

    // 0x8039C984: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x8039C988: bne         $t9, $zero, L_8039C9A0
    if (ctx->r25 != 0) {
        // 0x8039C98C: nop
    
            goto L_8039C9A0;
    }
    // 0x8039C98C: nop

    // 0x8039C990: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x8039C994: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039C998: b           L_8039C9B8
    // 0x8039C99C: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_8039C9B8;
    // 0x8039C99C: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_8039C9A0:
    // 0x8039C9A0: b           L_8039C9B8
    // 0x8039C9A4: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_8039C9B8;
    // 0x8039C9A4: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x8039C9A8: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
L_8039C9AC:
    // 0x8039C9AC: nop

    // 0x8039C9B0: bltz        $t9, L_8039C9A0
    if (SIGNED(ctx->r25) < 0) {
        // 0x8039C9B4: nop
    
            goto L_8039C9A0;
    }
    // 0x8039C9B4: nop

L_8039C9B8:
    // 0x8039C9B8: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x8039C9BC: lwc1        $f10, 0x4C($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X4C);
    // 0x8039C9C0: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8039C9C4: sll         $t2, $t9, 16
    ctx->r10 = S32(ctx->r25 << 16);
    // 0x8039C9C8: div.s       $f16, $f0, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = DIV_S(ctx->f0.fl, ctx->f10.fl);
    // 0x8039C9CC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8039C9D0: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x8039C9D4: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8039C9D8: nop

    // 0x8039C9DC: cvt.w.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = CVT_W_S(ctx->f16.fl);
    // 0x8039C9E0: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8039C9E4: nop

    // 0x8039C9E8: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x8039C9EC: beql        $t5, $zero, L_8039CA3C
    if (ctx->r13 == 0) {
        // 0x8039C9F0: mfc1        $t5, $f18
        ctx->r13 = (int32_t)ctx->f18.u32l;
            goto L_8039CA3C;
    }
    goto skip_1;
    // 0x8039C9F0: mfc1        $t5, $f18
    ctx->r13 = (int32_t)ctx->f18.u32l;
    skip_1:
    // 0x8039C9F4: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x8039C9F8: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8039C9FC: sub.s       $f18, $f16, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f16.fl - ctx->f18.fl;
    // 0x8039CA00: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x8039CA04: nop

    // 0x8039CA08: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x8039CA0C: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x8039CA10: nop

    // 0x8039CA14: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x8039CA18: bne         $t5, $zero, L_8039CA30
    if (ctx->r13 != 0) {
        // 0x8039CA1C: nop
    
            goto L_8039CA30;
    }
    // 0x8039CA1C: nop

    // 0x8039CA20: mfc1        $t5, $f18
    ctx->r13 = (int32_t)ctx->f18.u32l;
    // 0x8039CA24: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039CA28: b           L_8039CA48
    // 0x8039CA2C: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
        goto L_8039CA48;
    // 0x8039CA2C: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
L_8039CA30:
    // 0x8039CA30: b           L_8039CA48
    // 0x8039CA34: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
        goto L_8039CA48;
    // 0x8039CA34: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x8039CA38: mfc1        $t5, $f18
    ctx->r13 = (int32_t)ctx->f18.u32l;
L_8039CA3C:
    // 0x8039CA3C: nop

    // 0x8039CA40: bltz        $t5, L_8039CA30
    if (SIGNED(ctx->r13) < 0) {
        // 0x8039CA44: nop
    
            goto L_8039CA30;
    }
    // 0x8039CA44: nop

L_8039CA48:
    // 0x8039CA48: andi        $t4, $t5, 0xFFFF
    ctx->r12 = ctx->r13 & 0XFFFF;
    // 0x8039CA4C: or          $t6, $t2, $t4
    ctx->r14 = ctx->r10 | ctx->r12;
    // 0x8039CA50: sw          $t6, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r14;
    // 0x8039CA54: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039CA58: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x8039CA5C: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x8039CA60: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039CA64: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039CA68: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039CA6C: lhu         $t2, 0x5E($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X5E);
    // 0x8039CA70: lhu         $t3, 0x5A($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X5A);
    // 0x8039CA74: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8039CA78: sll         $t4, $t2, 2
    ctx->r12 = S32(ctx->r10 << 2);
    // 0x8039CA7C: andi        $t6, $t4, 0xFFFF
    ctx->r14 = ctx->r12 & 0XFFFF;
    // 0x8039CA80: sll         $t5, $t3, 18
    ctx->r13 = S32(ctx->r11 << 18);
    // 0x8039CA84: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x8039CA88: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039CA8C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8039CA90: addu        $t8, $v1, $t0
    ctx->r24 = ADD32(ctx->r3, ctx->r8);
    // 0x8039CA94: lw          $t9, 0x914($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X914);
    // 0x8039CA98: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x8039CA9C: addiu       $t1, $t9, 0x1
    ctx->r9 = ADD32(ctx->r25, 0X1);
    // 0x8039CAA0: sw          $t1, -0x76EC($at)
    MEM_W(-0X76EC, ctx->r1) = ctx->r9;
    // 0x8039CAA4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x8039CAA8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8039CAAC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x8039CAB0: jr          $ra
    // 0x8039CAB4: nop

    return;
    // 0x8039CAB4: nop

;}
RECOMP_FUNC void func_8039CAB8_7AE168(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039CAB8: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8039CABC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039CAC0: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8039CAC4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039CAC8: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x8039CACC: bne         $t7, $at, L_8039CB08
    if (ctx->r15 != ctx->r1) {
        // 0x8039CAD0: sw          $a0, 0x30($sp)
        MEM_W(0X30, ctx->r29) = ctx->r4;
            goto L_8039CB08;
    }
    // 0x8039CAD0: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x8039CAD4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039CAD8: addiu       $t8, $zero, 0xF0
    ctx->r24 = ADD32(0, 0XF0);
    // 0x8039CADC: addiu       $t9, $zero, 0x28
    ctx->r25 = ADD32(0, 0X28);
    // 0x8039CAE0: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039CAE4: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x8039CAE8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8039CAEC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039CAF0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039CAF4: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x8039CAF8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8039CAFC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039CB00: jal         0x8012AD30
    // 0x8039CB04: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_0;
    // 0x8039CB04: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_0:
L_8039CB08:
    // 0x8039CB08: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039CB0C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039CB10: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CB14: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8039CB18: addiu       $t8, $t8, -0x7B60
    ctx->r24 = ADD32(ctx->r24, -0X7B60);
    // 0x8039CB1C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039CB20: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CB24: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8039CB28: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039CB2C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039CB30: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CB34: lui         $ra, 0xE700
    ctx->r31 = S32(0XE700 << 16);
    // 0x8039CB38: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8039CB3C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039CB40: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039CB44: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039CB48: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x8039CB4C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CB50: ori         $t7, $t7, 0x2
    ctx->r15 = ctx->r15 | 0X2;
    // 0x8039CB54: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8039CB58: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039CB5C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CB60: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039CB64: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039CB68: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CB6C: lui         $t6, 0xF900
    ctx->r14 = S32(0XF900 << 16);
    // 0x8039CB70: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x8039CB74: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039CB78: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039CB7C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039CB80: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039CB84: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CB88: lui         $t9, 0xF0A
    ctx->r25 = S32(0XF0A << 16);
    // 0x8039CB8C: ori         $t9, $t9, 0x7008
    ctx->r25 = ctx->r25 | 0X7008;
    // 0x8039CB90: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039CB94: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039CB98: ori         $t8, $t8, 0x31D
    ctx->r24 = ctx->r24 | 0X31D;
    // 0x8039CB9C: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039CBA0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039CBA4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CBA8: lui         $t8, 0xFF2F
    ctx->r24 = S32(0XFF2F << 16);
    // 0x8039CBAC: lui         $t7, 0xFC11
    ctx->r15 = S32(0XFC11 << 16);
    // 0x8039CBB0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039CBB4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CBB8: ori         $t7, $t7, 0x9623
    ctx->r15 = ctx->r15 | 0X9623;
    // 0x8039CBBC: ori         $t8, $t8, 0xFFFF
    ctx->r24 = ctx->r24 | 0XFFFF;
    // 0x8039CBC0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039CBC4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039CBC8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CBCC: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x8039CBD0: ori         $t6, $t6, 0x1402
    ctx->r14 = ctx->r14 | 0X1402;
    // 0x8039CBD4: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039CBD8: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039CBDC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039CBE0: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039CBE4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CBE8: addiu       $t6, $zero, -0xB0
    ctx->r14 = ADD32(0, -0XB0);
    // 0x8039CBEC: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039CBF0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039CBF4: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039CBF8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039CBFC: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x8039CC00: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CC04: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039CC08: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039CC0C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039CC10: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8039CC14: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039CC18: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039CC1C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CC20: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8039CC24: ori         $t8, $t8, 0x602
    ctx->r24 = ctx->r24 | 0X602;
    // 0x8039CC28: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039CC2C: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039CC30: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x8039CC34: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039CC38: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039CC3C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CC40: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x8039CC44: ori         $t7, $t7, 0x402
    ctx->r15 = ctx->r15 | 0X402;
    // 0x8039CC48: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039CC4C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CC50: addiu       $t8, $zero, 0x30
    ctx->r24 = ADD32(0, 0X30);
    // 0x8039CC54: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039CC58: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039CC5C: addiu       $t9, $zero, 0xC
    ctx->r25 = ADD32(0, 0XC);
    // 0x8039CC60: lui         $a1, 0x800C
    ctx->r5 = S32(0X800C << 16);
    // 0x8039CC64: addiu       $a1, $a1, -0x2380
    ctx->r5 = ADD32(ctx->r5, -0X2380);
    // 0x8039CC68: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8039CC6C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8039CC70: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8039CC74: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8039CC78: addiu       $a2, $zero, 0x140
    ctx->r6 = ADD32(0, 0X140);
    // 0x8039CC7C: addiu       $a3, $zero, 0x24
    ctx->r7 = ADD32(0, 0X24);
    // 0x8039CC80: swc1        $f0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f0.u32l;
    // 0x8039CC84: jal         0x8039C834
    // 0x8039CC88: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    func_8039C834_7ADEE4(rdram, ctx);
        goto after_1;
    // 0x8039CC88: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    after_1:
    // 0x8039CC8C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8039CC90: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8039CC94: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039CC98: lui         $ra, 0xE700
    ctx->r31 = S32(0XE700 << 16);
    // 0x8039CC9C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039CCA0: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CCA4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039CCA8: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x8039CCAC: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8039CCB0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    sssv_hd_header_hook(rdram, ctx);
    // 0x8039CCB4: jr          $ra
    // 0x8039CCB8: nop

    return;
    // 0x8039CCB8: nop

;}
RECOMP_FUNC void get_player_progress(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039CCBC: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8039CCC0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039CCC4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8039CCC8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039CCCC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8039CCD0: addiu       $t4, $zero, 0x1E
    ctx->r12 = ADD32(0, 0X1E);
    // 0x8039CCD4: addiu       $t3, $zero, 0x1D
    ctx->r11 = ADD32(0, 0X1D);
    // 0x8039CCD8: addiu       $t2, $zero, 0x16
    ctx->r10 = ADD32(0, 0X16);
    // 0x8039CCDC: addiu       $t1, $zero, 0x10
    ctx->r9 = ADD32(0, 0X10);
    // 0x8039CCE0: addiu       $t0, $zero, 0x9
    ctx->r8 = ADD32(0, 0X9);
    // 0x8039CCE4: addu        $t6, $a0, $a3
    ctx->r14 = ADD32(ctx->r4, ctx->r7);
L_8039CCE8:
    // 0x8039CCE8: lbu         $a1, 0x4($t6)
    ctx->r5 = MEM_BU(ctx->r14, 0X4);
    // 0x8039CCEC: sll         $t8, $a1, 30
    ctx->r24 = S32(ctx->r5 << 30);
    // 0x8039CCF0: bgez        $t8, L_8039CD04
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8039CCF4: nop
    
            goto L_8039CD04;
    }
    // 0x8039CCF4: nop

    // 0x8039CCF8: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
    // 0x8039CCFC: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8039CD00: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
L_8039CD04:
    // 0x8039CD04: beql        $a3, $t0, L_8039CD3C
    if (ctx->r7 == ctx->r8) {
        // 0x8039CD08: addiu       $a3, $a3, 0x1
        ctx->r7 = ADD32(ctx->r7, 0X1);
            goto L_8039CD3C;
    }
    goto skip_0;
    // 0x8039CD08: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    skip_0:
    // 0x8039CD0C: beql        $a3, $t1, L_8039CD3C
    if (ctx->r7 == ctx->r9) {
        // 0x8039CD10: addiu       $a3, $a3, 0x1
        ctx->r7 = ADD32(ctx->r7, 0X1);
            goto L_8039CD3C;
    }
    goto skip_1;
    // 0x8039CD10: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    skip_1:
    // 0x8039CD14: beql        $a3, $t2, L_8039CD3C
    if (ctx->r7 == ctx->r10) {
        // 0x8039CD18: addiu       $a3, $a3, 0x1
        ctx->r7 = ADD32(ctx->r7, 0X1);
            goto L_8039CD3C;
    }
    goto skip_2;
    // 0x8039CD18: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    skip_2:
    // 0x8039CD1C: beql        $a3, $t3, L_8039CD3C
    if (ctx->r7 == ctx->r11) {
        // 0x8039CD20: addiu       $a3, $a3, 0x1
        ctx->r7 = ADD32(ctx->r7, 0X1);
            goto L_8039CD3C;
    }
    goto skip_3;
    // 0x8039CD20: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    skip_3:
    // 0x8039CD24: beq         $a3, $t4, L_8039CD38
    if (ctx->r7 == ctx->r12) {
        // 0x8039CD28: srl         $t6, $a1, 4
        ctx->r14 = S32(U32(ctx->r5) >> 4);
            goto L_8039CD38;
    }
    // 0x8039CD28: srl         $t6, $a1, 4
    ctx->r14 = S32(U32(ctx->r5) >> 4);
    // 0x8039CD2C: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x8039CD30: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039CD34: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
L_8039CD38:
    // 0x8039CD38: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
L_8039CD3C:
    // 0x8039CD3C: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x8039CD40: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039CD44: slti        $at, $a3, 0x1F
    ctx->r1 = SIGNED(ctx->r7) < 0X1F ? 1 : 0;
    // 0x8039CD48: bnel        $at, $zero, L_8039CCE8
    if (ctx->r1 != 0) {
        // 0x8039CD4C: addu        $t6, $a0, $a3
        ctx->r14 = ADD32(ctx->r4, ctx->r7);
            goto L_8039CCE8;
    }
    goto skip_4;
    // 0x8039CD4C: addu        $t6, $a0, $a3
    ctx->r14 = ADD32(ctx->r4, ctx->r7);
    skip_4:
    // 0x8039CD50: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8039CD54: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
L_8039CD58:
    // 0x8039CD58: div         $zero, $a3, $a1
    lo = S32(S64(S32(ctx->r7)) / S64(S32(ctx->r5))); hi = S32(S64(S32(ctx->r7)) % S64(S32(ctx->r5)));
    // 0x8039CD5C: sra         $t6, $a3, 3
    ctx->r14 = S32(SIGNED(ctx->r7) >> 3);
    // 0x8039CD60: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8039CD64: sra         $t8, $t7, 24
    ctx->r24 = S32(SIGNED(ctx->r15) >> 24);
    // 0x8039CD68: addu        $t9, $a0, $t8
    ctx->r25 = ADD32(ctx->r4, ctx->r24);
    // 0x8039CD6C: lbu         $t5, 0x28($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X28);
    // 0x8039CD70: mfhi        $t6
    ctx->r14 = hi;
    // 0x8039CD74: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x8039CD78: sra         $t8, $t7, 24
    ctx->r24 = S32(SIGNED(ctx->r15) >> 24);
    // 0x8039CD7C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8039CD80: sllv        $t6, $t9, $t8
    ctx->r14 = S32(ctx->r25 << (ctx->r24 & 31));
    // 0x8039CD84: bne         $a1, $zero, L_8039CD90
    if (ctx->r5 != 0) {
        // 0x8039CD88: nop
    
            goto L_8039CD90;
    }
    // 0x8039CD88: nop

    // 0x8039CD8C: break       7
    do_break(2151271820);
L_8039CD90:
    // 0x8039CD90: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039CD94: bne         $a1, $at, L_8039CDA8
    if (ctx->r5 != ctx->r1) {
        // 0x8039CD98: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039CDA8;
    }
    // 0x8039CD98: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039CD9C: bne         $a3, $at, L_8039CDA8
    if (ctx->r7 != ctx->r1) {
        // 0x8039CDA0: nop
    
            goto L_8039CDA8;
    }
    // 0x8039CDA0: nop

    // 0x8039CDA4: break       6
    do_break(2151271844);
L_8039CDA8:
    // 0x8039CDA8: and         $t7, $t5, $t6
    ctx->r15 = ctx->r13 & ctx->r14;
    // 0x8039CDAC: beq         $t7, $zero, L_8039CDC0
    if (ctx->r15 == 0) {
        // 0x8039CDB0: addiu       $a3, $a3, 0x1
        ctx->r7 = ADD32(ctx->r7, 0X1);
            goto L_8039CDC0;
    }
    // 0x8039CDB0: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    // 0x8039CDB4: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x8039CDB8: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x8039CDBC: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
L_8039CDC0:
    // 0x8039CDC0: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x8039CDC4: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8039CDC8: slti        $at, $a3, 0x44
    ctx->r1 = SIGNED(ctx->r7) < 0X44 ? 1 : 0;
    // 0x8039CDCC: bne         $at, $zero, L_8039CD58
    if (ctx->r1 != 0) {
        // 0x8039CDD0: nop
    
            goto L_8039CD58;
    }
    // 0x8039CDD0: nop

    // 0x8039CDD4: lw          $t7, 0x4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X4);
    // 0x8039CDD8: sh          $a2, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r6;
    // 0x8039CDDC: sh          $v1, 0x2($t7)
    MEM_H(0X2, ctx->r15) = ctx->r3;
    // 0x8039CDE0: jr          $ra
    // 0x8039CDE4: sh          $v0, 0x4($t7)
    MEM_H(0X4, ctx->r15) = ctx->r2;
    return;
    // 0x8039CDE4: sh          $v0, 0x4($t7)
    MEM_H(0X4, ctx->r15) = ctx->r2;
;}
RECOMP_FUNC void func_8039CDE8_7AE498(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039CDE8: lui         $at, 0x3FD0
    ctx->r1 = S32(0X3FD0 << 16);
    // 0x8039CDEC: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x8039CDF0: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x8039CDF4: cvt.d.s     $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f0.d = CVT_D_S(ctx->f14.fl);
    // 0x8039CDF8: cvt.d.s     $f2, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f2.d = CVT_D_S(ctx->f12.fl);
    // 0x8039CDFC: sub.d       $f4, $f0, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f16.d); 
    ctx->f4.d = ctx->f0.d - ctx->f16.d;
    // 0x8039CE00: c.lt.d      $f4, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f4.d < ctx->f2.d;
    // 0x8039CE04: nop

    // 0x8039CE08: bc1fl       L_8039CE30
    if (!c1cs) {
        // 0x8039CE0C: mov.s       $f0, $f12
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
            goto L_8039CE30;
    }
    goto skip_0;
    // 0x8039CE0C: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
    skip_0:
    // 0x8039CE10: add.d       $f6, $f0, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f16.d); 
    ctx->f6.d = ctx->f0.d + ctx->f16.d;
    // 0x8039CE14: c.lt.d      $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    c1cs = ctx->f2.d < ctx->f6.d;
    // 0x8039CE18: nop

    // 0x8039CE1C: bc1fl       L_8039CE30
    if (!c1cs) {
        // 0x8039CE20: mov.s       $f0, $f12
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
            goto L_8039CE30;
    }
    goto skip_1;
    // 0x8039CE20: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
    skip_1:
    // 0x8039CE24: jr          $ra
    // 0x8039CE28: mov.s       $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    ctx->f0.fl = ctx->f14.fl;
    return;
    // 0x8039CE28: mov.s       $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    ctx->f0.fl = ctx->f14.fl;
    // 0x8039CE2C: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
L_8039CE30:
    // 0x8039CE30: jr          $ra
    // 0x8039CE34: nop

    return;
    // 0x8039CE34: nop

;}
RECOMP_FUNC void func_8039CE38_7AE4E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039CE38: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8039CE3C: addiu       $a3, $a3, 0x66F0
    ctx->r7 = ADD32(ctx->r7, 0X66F0);
    // 0x8039CE40: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8039CE44: addiu       $t0, $zero, 0x280
    ctx->r8 = ADD32(0, 0X280);
    // 0x8039CE48: addiu       $t1, $zero, 0x1E0
    ctx->r9 = ADD32(0, 0X1E0);
    // 0x8039CE4C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8039CE50: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8039CE54: sh          $t0, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r8;
    // 0x8039CE58: sh          $t1, 0x2($a3)
    MEM_H(0X2, ctx->r7) = ctx->r9;
    // 0x8039CE5C: sh          $t0, 0x8($a3)
    MEM_H(0X8, ctx->r7) = ctx->r8;
    // 0x8039CE60: sh          $t1, 0xA($a3)
    MEM_H(0XA, ctx->r7) = ctx->r9;
    // 0x8039CE64: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8039CE68: lui         $t2, 0xE700
    ctx->r10 = S32(0XE700 << 16);
    // 0x8039CE6C: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x8039CE70: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8039CE74: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CE78: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8039CE7C: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x8039CE80: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8039CE84: addiu       $t9, $t9, -0x38B0
    ctx->r25 = ADD32(ctx->r25, -0X38B0);
    // 0x8039CE88: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x8039CE8C: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8039CE90: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039CE94: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8039CE98: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8039CE9C: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8039CEA0: lui         $t4, 0xAF00
    ctx->r12 = S32(0XAF00 << 16);
    // 0x8039CEA4: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x8039CEA8: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x8039CEAC: sw          $t3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r11;
    // 0x8039CEB0: addiu       $t5, $t5, -0x1D00
    ctx->r13 = ADD32(ctx->r13, -0X1D00);
    // 0x8039CEB4: ori         $t4, $t4, 0x7FF
    ctx->r12 = ctx->r12 | 0X7FF;
    // 0x8039CEB8: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8039CEBC: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x8039CEC0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8039CEC4: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8039CEC8: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8039CECC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8039CED0: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039CED4: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8039CED8: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x8039CEDC: jal         0x80129300
    // 0x8039CEE0: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    load_segments(rdram, ctx);
        goto after_0;
    // 0x8039CEE0: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    after_0:
    // 0x8039CEE4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039CEE8: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8039CEEC: lui         $t8, 0x380
    ctx->r24 = S32(0X380 << 16);
    // 0x8039CEF0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8039CEF4: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039CEF8: addiu       $a3, $a3, 0x66F0
    ctx->r7 = ADD32(ctx->r7, 0X66F0);
    // 0x8039CEFC: ori         $t8, $t8, 0x10
    ctx->r24 = ctx->r24 | 0X10;
    // 0x8039CF00: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8039CF04: sw          $a3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r7;
    // 0x8039CF08: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039CF0C: lui         $t3, 0xFE00
    ctx->r11 = S32(0XFE00 << 16);
    // 0x8039CF10: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8039CF14: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8039CF18: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039CF1C: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x8039CF20: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8039CF24: jal         0x80138130
    // 0x8039CF28: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x8039CF28: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    after_1:
    // 0x8039CF2C: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x8039CF30: lui         $t5, 0xFF10
    ctx->r13 = S32(0XFF10 << 16);
    // 0x8039CF34: ori         $t5, $t5, 0x13F
    ctx->r13 = ctx->r13 | 0X13F;
    // 0x8039CF38: sw          $v0, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r2;
    // 0x8039CF3C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039CF40: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x8039CF44: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x8039CF48: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x8039CF4C: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8039CF50: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8039CF54: lw          $t6, 0x4274($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4274);
    // 0x8039CF58: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    // 0x8039CF5C: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x8039CF60: jal         0x80138130
    // 0x8039CF64: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_2;
    // 0x8039CF64: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    after_2:
    // 0x8039CF68: lw          $a3, 0x20($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X20);
    // 0x8039CF6C: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8039CF70: addiu       $t9, $t9, 0x4270
    ctx->r25 = ADD32(ctx->r25, 0X4270);
    // 0x8039CF74: sw          $v0, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r2;
    // 0x8039CF78: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039CF7C: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x8039CF80: lui         $t4, 0xED02
    ctx->r12 = S32(0XED02 << 16);
    // 0x8039CF84: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8039CF88: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039CF8C: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8039CF90: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8039CF94: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039CF98: ori         $t4, $t4, 0x20
    ctx->r12 = ctx->r12 | 0X20;
    // 0x8039CF9C: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8039CFA0: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x8039CFA4: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039CFA8: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8039CFAC: lh          $t5, 0x3FD0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD0);
    // 0x8039CFB0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x8039CFB4: lh          $t4, 0x3FD2($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD2);
    // 0x8039CFB8: addiu       $t6, $t5, -0x8
    ctx->r14 = ADD32(ctx->r13, -0X8);
    // 0x8039CFBC: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8039CFC0: addiu       $t5, $t4, -0x8
    ctx->r13 = ADD32(ctx->r12, -0X8);
    // 0x8039CFC4: mtc1        $t5, $f16
    ctx->f16.u32l = ctx->r13;
    // 0x8039CFC8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8039CFCC: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8039CFD0: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039CFD4: lui         $t5, 0xE700
    ctx->r13 = S32(0XE700 << 16);
    // 0x8039CFD8: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039CFDC: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x8039CFE0: nop

    // 0x8039CFE4: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039CFE8: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8039CFEC: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039CFF0: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x8039CFF4: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8039CFF8: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8039CFFC: sll         $t3, $t9, 12
    ctx->r11 = S32(ctx->r25 << 12);
    // 0x8039D000: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8039D004: or          $t9, $t3, $t8
    ctx->r25 = ctx->r11 | ctx->r24;
    // 0x8039D008: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8039D00C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8039D010: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x8039D014: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x8039D018: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8039D01C: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8039D020: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8039D024: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8039D028: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x8039D02C: jr          $ra
    // 0x8039D030: nop

    return;
    // 0x8039D030: nop

;}
RECOMP_FUNC void func_8039D034_7AE6E4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039D034: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8039D038: lh          $t6, 0x66A4($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X66A4);
    // 0x8039D03C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8039D040: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x8039D044: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8039D048: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8039D04C: bne         $t6, $zero, L_8039D2F8
    if (ctx->r14 != 0) {
        // 0x8039D050: sw          $a1, 0x2C($sp)
        MEM_W(0X2C, ctx->r29) = ctx->r5;
            goto L_8039D2F8;
    }
    // 0x8039D050: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x8039D054: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D058: addiu       $v1, $v1, 0x7D9E
    ctx->r3 = ADD32(ctx->r3, 0X7D9E);
    // 0x8039D05C: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x8039D060: bne         $v0, $zero, L_8039D098
    if (ctx->r2 != 0) {
        // 0x8039D064: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_8039D098;
    }
    // 0x8039D064: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x8039D068: jal         0x80140D20
    // 0x8039D06C: nop

    guRandom(rdram, ctx);
        goto after_0;
    // 0x8039D06C: nop

    after_0:
    // 0x8039D070: addiu       $at, $zero, 0x3E8
    ctx->r1 = ADD32(0, 0X3E8);
    // 0x8039D074: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8039D078: mfhi        $t7
    ctx->r15 = hi;
    // 0x8039D07C: slti        $at, $t7, 0xA
    ctx->r1 = SIGNED(ctx->r15) < 0XA ? 1 : 0;
    // 0x8039D080: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D084: beq         $at, $zero, L_8039D09C
    if (ctx->r1 == 0) {
        // 0x8039D088: addiu       $v1, $v1, 0x7D9E
        ctx->r3 = ADD32(ctx->r3, 0X7D9E);
            goto L_8039D09C;
    }
    // 0x8039D088: addiu       $v1, $v1, 0x7D9E
    ctx->r3 = ADD32(ctx->r3, 0X7D9E);
    // 0x8039D08C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8039D090: b           L_8039D09C
    // 0x8039D094: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
        goto L_8039D09C;
    // 0x8039D094: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
L_8039D098:
    // 0x8039D098: sh          $t9, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r25;
L_8039D09C:
    // 0x8039D09C: jal         0x80140D20
    // 0x8039D0A0: nop

    guRandom(rdram, ctx);
        goto after_1;
    // 0x8039D0A0: nop

    after_1:
    // 0x8039D0A4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D0A8: addiu       $v1, $v1, 0x7D9E
    ctx->r3 = ADD32(ctx->r3, 0X7D9E);
    // 0x8039D0AC: lh          $t1, 0x0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X0);
    // 0x8039D0B0: bgez        $v0, L_8039D0C4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8039D0B4: andi        $t2, $v0, 0x1
        ctx->r10 = ctx->r2 & 0X1;
            goto L_8039D0C4;
    }
    // 0x8039D0B4: andi        $t2, $v0, 0x1
    ctx->r10 = ctx->r2 & 0X1;
    // 0x8039D0B8: beq         $t2, $zero, L_8039D0C4
    if (ctx->r10 == 0) {
        // 0x8039D0BC: nop
    
            goto L_8039D0C4;
    }
    // 0x8039D0BC: nop

    // 0x8039D0C0: addiu       $t2, $t2, -0x2
    ctx->r10 = ADD32(ctx->r10, -0X2);
L_8039D0C4:
    // 0x8039D0C4: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x8039D0C8: slt         $at, $t3, $t1
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x8039D0CC: beq         $at, $zero, L_8039D0D8
    if (ctx->r1 == 0) {
        // 0x8039D0D0: nop
    
            goto L_8039D0D8;
    }
    // 0x8039D0D0: nop

    // 0x8039D0D4: sh          $zero, 0x0($v1)
    MEM_H(0X0, ctx->r3) = 0;
L_8039D0D8:
    // 0x8039D0D8: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D0DC: lh          $v1, 0x7D9C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7D9C);
    // 0x8039D0E0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039D0E4: bne         $v1, $zero, L_8039D13C
    if (ctx->r3 != 0) {
        // 0x8039D0E8: addiu       $t6, $v1, 0x1
        ctx->r14 = ADD32(ctx->r3, 0X1);
            goto L_8039D13C;
    }
    // 0x8039D0E8: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x8039D0EC: jal         0x80140D20
    // 0x8039D0F0: nop

    guRandom(rdram, ctx);
        goto after_2;
    // 0x8039D0F0: nop

    after_2:
    // 0x8039D0F4: addiu       $at, $zero, 0x7D0
    ctx->r1 = ADD32(0, 0X7D0);
    // 0x8039D0F8: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8039D0FC: mfhi        $t4
    ctx->r12 = hi;
    // 0x8039D100: slti        $at, $t4, 0xA
    ctx->r1 = SIGNED(ctx->r12) < 0XA ? 1 : 0;
    // 0x8039D104: beq         $at, $zero, L_8039D140
    if (ctx->r1 == 0) {
        // 0x8039D108: addiu       $t5, $zero, 0x1
        ctx->r13 = ADD32(0, 0X1);
            goto L_8039D140;
    }
    // 0x8039D108: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x8039D10C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039D110: sh          $t5, 0x7D9C($at)
    MEM_H(0X7D9C, ctx->r1) = ctx->r13;
    // 0x8039D114: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8039D118: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8039D11C: addiu       $a0, $zero, 0x283B
    ctx->r4 = ADD32(0, 0X283B);
    // 0x8039D120: addiu       $a1, $zero, 0x74
    ctx->r5 = ADD32(0, 0X74);
    // 0x8039D124: addiu       $a2, $zero, 0x4000
    ctx->r6 = ADD32(0, 0X4000);
    // 0x8039D128: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8039D12C: jal         0x8032CD20
    // 0x8039D130: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_3;
    // 0x8039D130: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_3:
    // 0x8039D134: b           L_8039D140
    // 0x8039D138: nop

        goto L_8039D140;
    // 0x8039D138: nop

L_8039D13C:
    // 0x8039D13C: sh          $t6, 0x7D9C($at)
    MEM_H(0X7D9C, ctx->r1) = ctx->r14;
L_8039D140:
    // 0x8039D140: jal         0x80140D20
    // 0x8039D144: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x8039D144: nop

    after_4:
    // 0x8039D148: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8039D14C: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8039D150: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D154: lh          $v1, 0x7D9C($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X7D9C);
    // 0x8039D158: mfhi        $t7
    ctx->r15 = hi;
    // 0x8039D15C: addiu       $t8, $t7, 0x9
    ctx->r24 = ADD32(ctx->r15, 0X9);
    // 0x8039D160: slt         $at, $t8, $v1
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8039D164: beq         $at, $zero, L_8039D178
    if (ctx->r1 == 0) {
        // 0x8039D168: lui         $a3, 0xE700
        ctx->r7 = S32(0XE700 << 16);
            goto L_8039D178;
    }
    // 0x8039D168: lui         $a3, 0xE700
    ctx->r7 = S32(0XE700 << 16);
    // 0x8039D16C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8039D170: sh          $zero, 0x7D9C($at)
    MEM_H(0X7D9C, ctx->r1) = 0;
    // 0x8039D174: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8039D178:
    // 0x8039D178: bne         $v1, $zero, L_8039D188
    if (ctx->r3 != 0) {
        // 0x8039D17C: lh          $t0, 0x2E($sp)
        ctx->r8 = MEM_H(ctx->r29, 0X2E);
            goto L_8039D188;
    }
    // 0x8039D17C: lh          $t0, 0x2E($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X2E);
    // 0x8039D180: beql        $t0, $zero, L_8039D2FC
    if (ctx->r8 == 0) {
        // 0x8039D184: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_8039D2FC;
    }
    goto skip_0;
    // 0x8039D184: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
L_8039D188:
    // 0x8039D188: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D18C: lh          $t0, 0x2E($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X2E);
    // 0x8039D190: lui         $t1, 0xBA00
    ctx->r9 = S32(0XBA00 << 16);
    // 0x8039D194: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039D198: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039D19C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D1A0: sw          $a3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r7;
    // 0x8039D1A4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D1A8: ori         $t1, $t1, 0x1402
    ctx->r9 = ctx->r9 | 0X1402;
    // 0x8039D1AC: lui         $t4, 0xF900
    ctx->r12 = S32(0XF900 << 16);
    // 0x8039D1B0: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x8039D1B4: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x8039D1B8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D1BC: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8039D1C0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D1C4: addiu       $t5, $zero, 0x80
    ctx->r13 = ADD32(0, 0X80);
    // 0x8039D1C8: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8039D1CC: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x8039D1D0: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039D1D4: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x8039D1D8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039D1DC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D1E0: lui         $t8, 0xC08
    ctx->r24 = S32(0XC08 << 16);
    // 0x8039D1E4: ori         $t8, $t8, 0x4203
    ctx->r24 = ctx->r24 | 0X4203;
    // 0x8039D1E8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039D1EC: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039D1F0: ori         $t7, $t7, 0x31D
    ctx->r15 = ctx->r15 | 0X31D;
    // 0x8039D1F4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8039D1F8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039D1FC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D200: lui         $t1, 0x2
    ctx->r9 = S32(0X2 << 16);
    // 0x8039D204: ori         $t1, $t1, 0x2200
    ctx->r9 = ctx->r9 | 0X2200;
    // 0x8039D208: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039D20C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8039D210: lui         $t2, 0xB600
    ctx->r10 = S32(0XB600 << 16);
    // 0x8039D214: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x8039D218: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
    // 0x8039D21C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D220: lui         $t4, 0xBA00
    ctx->r12 = S32(0XBA00 << 16);
    // 0x8039D224: ori         $t4, $t4, 0x1301
    ctx->r12 = ctx->r12 | 0X1301;
    // 0x8039D228: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x8039D22C: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039D230: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D234: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039D238: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D23C: lui         $t7, 0xFFFD
    ctx->r15 = S32(0XFFFD << 16);
    // 0x8039D240: lui         $t6, 0xFCFF
    ctx->r14 = S32(0XFCFF << 16);
    // 0x8039D244: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8039D248: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x8039D24C: ori         $t6, $t6, 0xFFFF
    ctx->r14 = ctx->r14 | 0XFFFF;
    // 0x8039D250: ori         $t7, $t7, 0xF6FB
    ctx->r15 = ctx->r15 | 0XF6FB;
    // 0x8039D254: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8039D258: beq         $t0, $zero, L_8039D28C
    if (ctx->r8 == 0) {
        // 0x8039D25C: sw          $t6, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->r14;
            goto L_8039D28C;
    }
    // 0x8039D25C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039D260: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D264: lui         $at, 0x7878
    ctx->r1 = S32(0X7878 << 16);
    // 0x8039D268: ori         $at, $at, 0x7800
    ctx->r1 = ctx->r1 | 0X7800;
    // 0x8039D26C: andi        $t2, $t0, 0xFF
    ctx->r10 = ctx->r8 & 0XFF;
    // 0x8039D270: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039D274: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8039D278: or          $t1, $t2, $at
    ctx->r9 = ctx->r10 | ctx->r1;
    // 0x8039D27C: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8039D280: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8039D284: b           L_8039D2AC
    // 0x8039D288: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
        goto L_8039D2AC;
    // 0x8039D288: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
L_8039D28C:
    // 0x8039D28C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D290: lui         $t5, 0x7878
    ctx->r13 = S32(0X7878 << 16);
    // 0x8039D294: ori         $t5, $t5, 0x7805
    ctx->r13 = ctx->r13 | 0X7805;
    // 0x8039D298: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x8039D29C: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x8039D2A0: lui         $t4, 0xFA00
    ctx->r12 = S32(0XFA00 << 16);
    // 0x8039D2A4: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8039D2A8: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
L_8039D2AC:
    // 0x8039D2AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D2B0: lui         $t8, 0xF650
    ctx->r24 = S32(0XF650 << 16);
    // 0x8039D2B4: lui         $t0, 0x801E
    ctx->r8 = S32(0X801E << 16);
    // 0x8039D2B8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039D2BC: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8039D2C0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D2C4: sw          $a3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r7;
    // 0x8039D2C8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8039D2CC: ori         $t8, $t8, 0x3BC
    ctx->r24 = ctx->r24 | 0X3BC;
    // 0x8039D2D0: addiu       $t0, $t0, -0x6184
    ctx->r8 = ADD32(ctx->r8, -0X6184);
    // 0x8039D2D4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D2D8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8039D2DC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D2E0: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039D2E4: lw          $a2, 0x0($t0)
    ctx->r6 = MEM_W(ctx->r8, 0X0);
    // 0x8039D2E8: addiu       $t9, $a2, 0x8
    ctx->r25 = ADD32(ctx->r6, 0X8);
    // 0x8039D2EC: sw          $t9, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r25;
    // 0x8039D2F0: sw          $zero, 0x4($a2)
    MEM_W(0X4, ctx->r6) = 0;
    // 0x8039D2F4: sw          $a3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r7;
L_8039D2F8:
    // 0x8039D2F8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8039D2FC:
    // 0x8039D2FC: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8039D300: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8039D304: jr          $ra
    // 0x8039D308: nop

    return;
    // 0x8039D308: nop

;}
RECOMP_FUNC void render_stars(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039D30C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8039D310: sw          $s4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r20;
    // 0x8039D314: sw          $s3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r19;
    // 0x8039D318: sw          $s2, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r18;
    // 0x8039D31C: sw          $s1, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r17;
    // 0x8039D320: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x8039D324: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D328: lui         $v1, 0xE700
    ctx->r3 = S32(0XE700 << 16);
    // 0x8039D32C: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8039D330: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039D334: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039D338: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D33C: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8039D340: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D344: ori         $t8, $t8, 0x1402
    ctx->r24 = ctx->r24 | 0X1402;
    // 0x8039D348: lui         $t6, 0xB900
    ctx->r14 = S32(0XB900 << 16);
    // 0x8039D34C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D350: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039D354: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D358: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039D35C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D360: ori         $t6, $t6, 0x2
    ctx->r14 = ctx->r14 | 0X2;
    // 0x8039D364: lui         $t8, 0xFCFF
    ctx->r24 = S32(0XFCFF << 16);
    // 0x8039D368: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039D36C: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039D370: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D374: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039D378: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D37C: lui         $t9, 0xFFFD
    ctx->r25 = S32(0XFFFD << 16);
    // 0x8039D380: ori         $t9, $t9, 0xF6FB
    ctx->r25 = ctx->r25 | 0XF6FB;
    // 0x8039D384: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D388: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039D38C: ori         $t8, $t8, 0xFFFF
    ctx->r24 = ctx->r24 | 0XFFFF;
    // 0x8039D390: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039D394: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039D398: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D39C: lui         $t8, 0xF0A
    ctx->r24 = S32(0XF0A << 16);
    // 0x8039D3A0: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x8039D3A4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8039D3A8: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8039D3AC: ori         $t7, $t7, 0x31D
    ctx->r15 = ctx->r15 | 0X31D;
    // 0x8039D3B0: ori         $t8, $t8, 0x4000
    ctx->r24 = ctx->r24 | 0X4000;
    // 0x8039D3B4: lui         $s0, 0x800E
    ctx->r16 = S32(0X800E << 16);
    // 0x8039D3B8: lui         $s1, 0x8020
    ctx->r17 = S32(0X8020 << 16);
    // 0x8039D3BC: addiu       $s1, $s1, 0x4290
    ctx->r17 = ADD32(ctx->r17, 0X4290);
    // 0x8039D3C0: addiu       $s0, $s0, -0xDE0
    ctx->r16 = ADD32(ctx->r16, -0XDE0);
    // 0x8039D3C4: lui         $s2, 0xE400
    ctx->r18 = S32(0XE400 << 16);
    // 0x8039D3C8: lui         $s3, 0xB400
    ctx->r19 = S32(0XB400 << 16);
    // 0x8039D3CC: lui         $s4, 0xB300
    ctx->r20 = S32(0XB300 << 16);
    // 0x8039D3D0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8039D3D4: lui         $t5, 0xFA00
    ctx->r13 = S32(0XFA00 << 16);
    // 0x8039D3D8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039D3DC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
L_8039D3E0:
    // 0x8039D3E0: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D3E4: sll         $t6, $a2, 3
    ctx->r14 = S32(ctx->r6 << 3);
    // 0x8039D3E8: addu        $t3, $s0, $t6
    ctx->r11 = ADD32(ctx->r16, ctx->r14);
    // 0x8039D3EC: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8039D3F0: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8039D3F4: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8039D3F8: lh          $a3, 0x4($t3)
    ctx->r7 = MEM_H(ctx->r11, 0X4);
    // 0x8039D3FC: andi        $t7, $a3, 0xFF
    ctx->r15 = ctx->r7 & 0XFF;
    // 0x8039D400: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x8039D404: sll         $t9, $t7, 24
    ctx->r25 = S32(ctx->r15 << 24);
    // 0x8039D408: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x8039D40C: sll         $t7, $t7, 16
    ctx->r15 = S32(ctx->r15 << 16);
    // 0x8039D410: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8039D414: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8039D418: lh          $t6, 0x0($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X0);
    // 0x8039D41C: lh          $t9, 0x6($t3)
    ctx->r25 = MEM_H(ctx->r11, 0X6);
    // 0x8039D420: lh          $t8, 0x0($t3)
    ctx->r24 = MEM_H(ctx->r11, 0X0);
    // 0x8039D424: multu       $t9, $t6
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039D428: mflo        $t7
    ctx->r15 = lo;
    // 0x8039D42C: subu        $t9, $t8, $t7
    ctx->r25 = SUB32(ctx->r24, ctx->r15);
    // 0x8039D430: sh          $t9, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r25;
    // 0x8039D434: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x8039D438: slti        $at, $t4, 0x28
    ctx->r1 = SIGNED(ctx->r12) < 0X28 ? 1 : 0;
    // 0x8039D43C: beq         $at, $zero, L_8039D44C
    if (ctx->r1 == 0) {
        // 0x8039D440: addiu       $t6, $t4, 0x500
        ctx->r14 = ADD32(ctx->r12, 0X500);
            goto L_8039D44C;
    }
    // 0x8039D440: addiu       $t6, $t4, 0x500
    ctx->r14 = ADD32(ctx->r12, 0X500);
    // 0x8039D444: sh          $t6, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r14;
    // 0x8039D448: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
L_8039D44C:
    // 0x8039D44C: lh          $a3, 0x2($t3)
    ctx->r7 = MEM_H(ctx->r11, 0X2);
    // 0x8039D450: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D454: addiu       $t7, $t4, 0x4
    ctx->r15 = ADD32(ctx->r12, 0X4);
    // 0x8039D458: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
    // 0x8039D45C: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8039D460: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x8039D464: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x8039D468: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039D46C: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8039D470: addiu       $t7, $a3, 0x4
    ctx->r15 = ADD32(ctx->r7, 0X4);
    // 0x8039D474: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x8039D478: or          $t8, $t6, $s2
    ctx->r24 = ctx->r14 | ctx->r18;
    // 0x8039D47C: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x8039D480: andi        $t7, $t4, 0xFFF
    ctx->r15 = ctx->r12 & 0XFFF;
    // 0x8039D484: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x8039D488: andi        $t9, $a3, 0xFFF
    ctx->r25 = ctx->r7 & 0XFFF;
    // 0x8039D48C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8039D490: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x8039D494: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8039D498: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D49C: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
    // 0x8039D4A0: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8039D4A4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D4A8: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039D4AC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D4B0: sw          $s3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r19;
    // 0x8039D4B4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D4B8: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039D4BC: slti        $at, $a2, 0xB4
    ctx->r1 = SIGNED(ctx->r6) < 0XB4 ? 1 : 0;
    // 0x8039D4C0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8039D4C4: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8039D4C8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D4CC: bne         $at, $zero, L_8039D3E0
    if (ctx->r1 != 0) {
        // 0x8039D4D0: sw          $s4, 0x0($v0)
        MEM_W(0X0, ctx->r2) = ctx->r20;
            goto L_8039D3E0;
    }
    // 0x8039D4D0: sw          $s4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r20;
    // 0x8039D4D4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D4D8: lui         $t8, 0xED02
    ctx->r24 = S32(0XED02 << 16);
    // 0x8039D4DC: ori         $t8, $t8, 0x20
    ctx->r24 = ctx->r24 | 0X20;
    // 0x8039D4E0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D4E4: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039D4E8: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x8039D4EC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8039D4F0: lh          $t9, 0x3FD0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FD0);
    // 0x8039D4F4: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8039D4F8: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8039D4FC: addiu       $t6, $t9, -0x8
    ctx->r14 = ADD32(ctx->r25, -0X8);
    // 0x8039D500: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8039D504: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x8039D508: lh          $t7, 0x3FD2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FD2);
    // 0x8039D50C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8039D510: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x8039D514: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8039D518: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x8039D51C: nop

    // 0x8039D520: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x8039D524: addiu       $t8, $t7, -0x8
    ctx->r24 = ADD32(ctx->r15, -0X8);
    // 0x8039D528: mtc1        $t8, $f16
    ctx->f16.u32l = ctx->r24;
    // 0x8039D52C: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x8039D530: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8039D534: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8039D538: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x8039D53C: mfc1        $t7, $f6
    ctx->r15 = (int32_t)ctx->f6.u32l;
    // 0x8039D540: nop

    // 0x8039D544: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8039D548: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x8039D54C: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8039D550: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8039D554: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8039D558: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x8039D55C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8039D560: sw          $v1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r3;
    // 0x8039D564: lw          $s4, 0x14($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X14);
    // 0x8039D568: lw          $s3, 0x10($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X10);
    // 0x8039D56C: lw          $s2, 0xC($sp)
    ctx->r18 = MEM_W(ctx->r29, 0XC);
    // 0x8039D570: lw          $s1, 0x8($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X8);
    // 0x8039D574: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x8039D578: jr          $ra
    // 0x8039D57C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x8039D57C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void generate_stars(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039D580: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x8039D584: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x8039D588: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x8039D58C: sw          $s4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r20;
    // 0x8039D590: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x8039D594: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8039D598: lui         $s2, 0x800E
    ctx->r18 = S32(0X800E << 16);
    // 0x8039D59C: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x8039D5A0: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8039D5A4: addiu       $s2, $s2, -0xDE0
    ctx->r18 = ADD32(ctx->r18, -0XDE0);
    // 0x8039D5A8: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x8039D5AC: addiu       $s3, $zero, 0x140
    ctx->r19 = ADD32(0, 0X140);
    // 0x8039D5B0: addiu       $s4, $zero, 0xF0
    ctx->r20 = ADD32(0, 0XF0);
    // 0x8039D5B4: addiu       $s5, $zero, 0xF
    ctx->r21 = ADD32(0, 0XF);
L_8039D5B8:
    // 0x8039D5B8: jal         0x80140D20
    // 0x8039D5BC: nop

    guRandom(rdram, ctx);
        goto after_0;
    // 0x8039D5BC: nop

    after_0:
    // 0x8039D5C0: div         $zero, $v0, $s3
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r19)));
    // 0x8039D5C4: mfhi        $t7
    ctx->r15 = hi;
    // 0x8039D5C8: sll         $t6, $s1, 3
    ctx->r14 = S32(ctx->r17 << 3);
    // 0x8039D5CC: addu        $s0, $s2, $t6
    ctx->r16 = ADD32(ctx->r18, ctx->r14);
    // 0x8039D5D0: bne         $s3, $zero, L_8039D5DC
    if (ctx->r19 != 0) {
        // 0x8039D5D4: nop
    
            goto L_8039D5DC;
    }
    // 0x8039D5D4: nop

    // 0x8039D5D8: break       7
    do_break(2151273944);
L_8039D5DC:
    // 0x8039D5DC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039D5E0: bne         $s3, $at, L_8039D5F4
    if (ctx->r19 != ctx->r1) {
        // 0x8039D5E4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039D5F4;
    }
    // 0x8039D5E4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039D5E8: bne         $v0, $at, L_8039D5F4
    if (ctx->r2 != ctx->r1) {
        // 0x8039D5EC: nop
    
            goto L_8039D5F4;
    }
    // 0x8039D5EC: nop

    // 0x8039D5F0: break       6
    do_break(2151273968);
L_8039D5F4:
    // 0x8039D5F4: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x8039D5F8: jal         0x80140D20
    // 0x8039D5FC: sh          $t8, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r24;
    guRandom(rdram, ctx);
        goto after_1;
    // 0x8039D5FC: sh          $t8, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r24;
    after_1:
    // 0x8039D600: div         $zero, $v0, $s4
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r20))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r20)));
    // 0x8039D604: mfhi        $t9
    ctx->r25 = hi;
    // 0x8039D608: sll         $t0, $t9, 2
    ctx->r8 = S32(ctx->r25 << 2);
    // 0x8039D60C: bne         $s4, $zero, L_8039D618
    if (ctx->r20 != 0) {
        // 0x8039D610: nop
    
            goto L_8039D618;
    }
    // 0x8039D610: nop

    // 0x8039D614: break       7
    do_break(2151274004);
L_8039D618:
    // 0x8039D618: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039D61C: bne         $s4, $at, L_8039D630
    if (ctx->r20 != ctx->r1) {
        // 0x8039D620: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039D630;
    }
    // 0x8039D620: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039D624: bne         $v0, $at, L_8039D630
    if (ctx->r2 != ctx->r1) {
        // 0x8039D628: nop
    
            goto L_8039D630;
    }
    // 0x8039D628: nop

    // 0x8039D62C: break       6
    do_break(2151274028);
L_8039D630:
    // 0x8039D630: sh          $t0, 0x2($s0)
    MEM_H(0X2, ctx->r16) = ctx->r8;
    // 0x8039D634: jal         0x80140D20
    // 0x8039D638: nop

    guRandom(rdram, ctx);
        goto after_2;
    // 0x8039D638: nop

    after_2:
    // 0x8039D63C: bgez        $v0, L_8039D650
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8039D640: andi        $t1, $v0, 0x3
        ctx->r9 = ctx->r2 & 0X3;
            goto L_8039D650;
    }
    // 0x8039D640: andi        $t1, $v0, 0x3
    ctx->r9 = ctx->r2 & 0X3;
    // 0x8039D644: beq         $t1, $zero, L_8039D650
    if (ctx->r9 == 0) {
        // 0x8039D648: nop
    
            goto L_8039D650;
    }
    // 0x8039D648: nop

    // 0x8039D64C: addiu       $t1, $t1, -0x4
    ctx->r9 = ADD32(ctx->r9, -0X4);
L_8039D650:
    // 0x8039D650: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x8039D654: sh          $t2, 0x6($s0)
    MEM_H(0X6, ctx->r16) = ctx->r10;
    // 0x8039D658: lh          $t3, 0x6($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X6);
    // 0x8039D65C: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x8039D660: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x8039D664: multu       $t3, $s5
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r21)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039D668: sra         $s1, $t6, 16
    ctx->r17 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039D66C: slti        $at, $s1, 0xB4
    ctx->r1 = SIGNED(ctx->r17) < 0XB4 ? 1 : 0;
    // 0x8039D670: mflo        $t4
    ctx->r12 = lo;
    // 0x8039D674: addiu       $t5, $t4, 0x46
    ctx->r13 = ADD32(ctx->r12, 0X46);
    // 0x8039D678: bne         $at, $zero, L_8039D5B8
    if (ctx->r1 != 0) {
        // 0x8039D67C: sh          $t5, 0x4($s0)
        MEM_H(0X4, ctx->r16) = ctx->r13;
            goto L_8039D5B8;
    }
    // 0x8039D67C: sh          $t5, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r13;
    // 0x8039D680: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8039D684: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x8039D688: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x8039D68C: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x8039D690: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x8039D694: lw          $s4, 0x24($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X24);
    // 0x8039D698: lw          $s5, 0x28($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X28);
    // 0x8039D69C: jr          $ra
    // 0x8039D6A0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x8039D6A0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void determine_available_levels(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039D6A4: lui         $t1, 0x8024
    ctx->r9 = S32(0X8024 << 16);
    // 0x8039D6A8: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8039D6AC: addiu       $v1, $v1, 0x7DE0
    ctx->r3 = ADD32(ctx->r3, 0X7DE0);
    // 0x8039D6B0: addiu       $t1, $t1, -0xDA0
    ctx->r9 = ADD32(ctx->r9, -0XDA0);
    // 0x8039D6B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039D6B8: addiu       $t0, $zero, 0xF
    ctx->r8 = ADD32(0, 0XF);
    // 0x8039D6BC: addiu       $a3, $zero, 0x1E
    ctx->r7 = ADD32(0, 0X1E);
    // 0x8039D6C0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_8039D6C4:
    // 0x8039D6C4: bne         $v0, $a3, L_8039D6F0
    if (ctx->r2 != ctx->r7) {
        // 0x8039D6C8: addu        $a2, $t1, $v0
        ctx->r6 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D6F0;
    }
    // 0x8039D6C8: addu        $a2, $t1, $v0
    ctx->r6 = ADD32(ctx->r9, ctx->r2);
    // 0x8039D6CC: lb          $t6, 0x3B($t1)
    ctx->r14 = MEM_B(ctx->r9, 0X3B);
    // 0x8039D6D0: addu        $t7, $v1, $v0
    ctx->r15 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D6D4: addu        $t8, $v1, $v0
    ctx->r24 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D6D8: bne         $t0, $t6, L_8039D6E8
    if (ctx->r8 != ctx->r14) {
        // 0x8039D6DC: nop
    
            goto L_8039D6E8;
    }
    // 0x8039D6DC: nop

    // 0x8039D6E0: b           L_8039D730
    // 0x8039D6E4: sb          $a0, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r4;
        goto L_8039D730;
    // 0x8039D6E4: sb          $a0, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r4;
L_8039D6E8:
    // 0x8039D6E8: b           L_8039D730
    // 0x8039D6EC: sb          $zero, 0x0($t8)
    MEM_B(0X0, ctx->r24) = 0;
        goto L_8039D730;
    // 0x8039D6EC: sb          $zero, 0x0($t8)
    MEM_B(0X0, ctx->r24) = 0;
L_8039D6F0:
    // 0x8039D6F0: lbu         $t9, 0x4($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X4);
    // 0x8039D6F4: addu        $a1, $v1, $v0
    ctx->r5 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D6F8: sll         $t6, $t9, 30
    ctx->r14 = S32(ctx->r25 << 30);
    // 0x8039D6FC: bgezl       $t6, L_8039D714
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8039D700: sb          $zero, 0x0($a1)
        MEM_B(0X0, ctx->r5) = 0;
            goto L_8039D714;
    }
    goto skip_0;
    // 0x8039D700: sb          $zero, 0x0($a1)
    MEM_B(0X0, ctx->r5) = 0;
    skip_0:
    // 0x8039D704: addu        $a1, $v1, $v0
    ctx->r5 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D708: b           L_8039D714
    // 0x8039D70C: sb          $a0, 0x0($a1)
    MEM_B(0X0, ctx->r5) = ctx->r4;
        goto L_8039D714;
    // 0x8039D70C: sb          $a0, 0x0($a1)
    MEM_B(0X0, ctx->r5) = ctx->r4;
    // 0x8039D710: sb          $zero, 0x0($a1)
    MEM_B(0X0, ctx->r5) = 0;
L_8039D714:
    // 0x8039D714: beql        $v0, $zero, L_8039D734
    if (ctx->r2 == 0) {
        // 0x8039D718: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039D734;
    }
    goto skip_1;
    // 0x8039D718: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_1:
    // 0x8039D71C: lbu         $t7, 0x3($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X3);
    // 0x8039D720: sll         $t9, $t7, 30
    ctx->r25 = S32(ctx->r15 << 30);
    // 0x8039D724: bgezl       $t9, L_8039D734
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8039D728: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039D734;
    }
    goto skip_2;
    // 0x8039D728: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_2:
    // 0x8039D72C: sb          $a0, 0x0($a1)
    MEM_B(0X0, ctx->r5) = ctx->r4;
L_8039D730:
    // 0x8039D730: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039D734:
    // 0x8039D734: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x8039D738: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8039D73C: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x8039D740: bne         $at, $zero, L_8039D6C4
    if (ctx->r1 != 0) {
        // 0x8039D744: nop
    
            goto L_8039D6C4;
    }
    // 0x8039D744: nop

    // 0x8039D748: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x8039D74C: addiu       $t2, $t2, 0x7E06
    ctx->r10 = ADD32(ctx->r10, 0X7E06);
    // 0x8039D750: sh          $zero, 0x0($t2)
    MEM_H(0X0, ctx->r10) = 0;
    // 0x8039D754: lh          $t7, 0x0($t2)
    ctx->r15 = MEM_H(ctx->r10, 0X0);
    // 0x8039D758: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8039D75C: addiu       $t3, $t3, 0x7E04
    ctx->r11 = ADD32(ctx->r11, 0X7E04);
    // 0x8039D760: sh          $t7, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r15;
    // 0x8039D764: lh          $a1, 0x0($t3)
    ctx->r5 = MEM_H(ctx->r11, 0X0);
    // 0x8039D768: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x8039D76C: addiu       $t4, $t4, 0x7E02
    ctx->r12 = ADD32(ctx->r12, 0X7E02);
    // 0x8039D770: sh          $a1, 0x0($t4)
    MEM_H(0X0, ctx->r12) = ctx->r5;
    // 0x8039D774: lh          $a2, 0x0($t4)
    ctx->r6 = MEM_H(ctx->r12, 0X0);
    // 0x8039D778: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039D77C: addiu       $t0, $t0, 0x7E00
    ctx->r8 = ADD32(ctx->r8, 0X7E00);
    // 0x8039D780: sb          $a0, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r4;
    // 0x8039D784: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039D788: sh          $a2, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r6;
    // 0x8039D78C: addu        $t8, $t1, $v0
    ctx->r24 = ADD32(ctx->r9, ctx->r2);
L_8039D790:
    // 0x8039D790: lbu         $t9, 0x4($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X4);
    // 0x8039D794: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D798: sll         $t6, $t9, 30
    ctx->r14 = S32(ctx->r25 << 30);
    // 0x8039D79C: bgez        $t6, L_8039D7B0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8039D7A0: sll         $t9, $v0, 16
        ctx->r25 = S32(ctx->r2 << 16);
            goto L_8039D7B0;
    }
    // 0x8039D7A0: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x8039D7A4: lh          $t7, 0x0($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X0);
    // 0x8039D7A8: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8039D7AC: sh          $t8, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r24;
L_8039D7B0:
    // 0x8039D7B0: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039D7B4: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x8039D7B8: bnel        $at, $zero, L_8039D790
    if (ctx->r1 != 0) {
        // 0x8039D7BC: addu        $t8, $t1, $v0
        ctx->r24 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D790;
    }
    goto skip_3;
    // 0x8039D7BC: addu        $t8, $t1, $v0
    ctx->r24 = ADD32(ctx->r9, ctx->r2);
    skip_3:
    // 0x8039D7C0: lh          $a3, 0x0($t0)
    ctx->r7 = MEM_H(ctx->r8, 0X0);
    // 0x8039D7C4: slti        $at, $a3, 0x3
    ctx->r1 = SIGNED(ctx->r7) < 0X3 ? 1 : 0;
    // 0x8039D7C8: bne         $at, $zero, L_8039D824
    if (ctx->r1 != 0) {
        // 0x8039D7CC: addiu       $t0, $a3, 0x9
        ctx->r8 = ADD32(ctx->r7, 0X9);
            goto L_8039D824;
    }
    // 0x8039D7CC: addiu       $t0, $a3, 0x9
    ctx->r8 = ADD32(ctx->r7, 0X9);
    // 0x8039D7D0: slti        $at, $t0, 0xB
    ctx->r1 = SIGNED(ctx->r8) < 0XB ? 1 : 0;
    // 0x8039D7D4: bne         $at, $zero, L_8039D824
    if (ctx->r1 != 0) {
        // 0x8039D7D8: addiu       $v0, $zero, 0xA
        ctx->r2 = ADD32(0, 0XA);
            goto L_8039D824;
    }
    // 0x8039D7D8: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
    // 0x8039D7DC: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
L_8039D7E0:
    // 0x8039D7E0: bne         $v0, $a3, L_8039D7F4
    if (ctx->r2 != ctx->r7) {
        // 0x8039D7E4: addu        $t7, $t1, $v0
        ctx->r15 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D7F4;
    }
    // 0x8039D7E4: addu        $t7, $t1, $v0
    ctx->r15 = ADD32(ctx->r9, ctx->r2);
    // 0x8039D7E8: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D7EC: b           L_8039D80C
    // 0x8039D7F0: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
        goto L_8039D80C;
    // 0x8039D7F0: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D7F4:
    // 0x8039D7F4: lbu         $t8, 0x3($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X3);
    // 0x8039D7F8: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D7FC: sll         $t5, $t8, 30
    ctx->r13 = S32(ctx->r24 << 30);
    // 0x8039D800: bgezl       $t5, L_8039D810
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8039D804: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039D810;
    }
    goto skip_4;
    // 0x8039D804: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_4:
    // 0x8039D808: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D80C:
    // 0x8039D80C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039D810:
    // 0x8039D810: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039D814: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039D818: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x8039D81C: bne         $at, $zero, L_8039D7E0
    if (ctx->r1 != 0) {
        // 0x8039D820: nop
    
            goto L_8039D7E0;
    }
    // 0x8039D820: nop

L_8039D824:
    // 0x8039D824: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
    // 0x8039D828: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
L_8039D82C:
    // 0x8039D82C: lbu         $t5, 0x4($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X4);
    // 0x8039D830: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D834: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x8039D838: sll         $t7, $t5, 30
    ctx->r15 = S32(ctx->r13 << 30);
    // 0x8039D83C: bgez        $t7, L_8039D850
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039D840: sra         $v0, $t9, 16
        ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8039D850;
    }
    // 0x8039D840: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039D844: addiu       $t8, $a2, 0x1
    ctx->r24 = ADD32(ctx->r6, 0X1);
    // 0x8039D848: sh          $t8, 0x0($t4)
    MEM_H(0X0, ctx->r12) = ctx->r24;
    // 0x8039D84C: lh          $a2, 0x0($t4)
    ctx->r6 = MEM_H(ctx->r12, 0X0);
L_8039D850:
    // 0x8039D850: slti        $at, $v0, 0x11
    ctx->r1 = SIGNED(ctx->r2) < 0X11 ? 1 : 0;
    // 0x8039D854: bnel        $at, $zero, L_8039D82C
    if (ctx->r1 != 0) {
        // 0x8039D858: addu        $t9, $t1, $v0
        ctx->r25 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D82C;
    }
    goto skip_5;
    // 0x8039D858: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
    skip_5:
    // 0x8039D85C: slti        $at, $a2, 0x3
    ctx->r1 = SIGNED(ctx->r6) < 0X3 ? 1 : 0;
    // 0x8039D860: bne         $at, $zero, L_8039D8BC
    if (ctx->r1 != 0) {
        // 0x8039D864: addiu       $a3, $a2, 0x10
        ctx->r7 = ADD32(ctx->r6, 0X10);
            goto L_8039D8BC;
    }
    // 0x8039D864: addiu       $a3, $a2, 0x10
    ctx->r7 = ADD32(ctx->r6, 0X10);
    // 0x8039D868: slti        $at, $a3, 0x12
    ctx->r1 = SIGNED(ctx->r7) < 0X12 ? 1 : 0;
    // 0x8039D86C: bne         $at, $zero, L_8039D8BC
    if (ctx->r1 != 0) {
        // 0x8039D870: addiu       $v0, $zero, 0x11
        ctx->r2 = ADD32(0, 0X11);
            goto L_8039D8BC;
    }
    // 0x8039D870: addiu       $v0, $zero, 0x11
    ctx->r2 = ADD32(0, 0X11);
    // 0x8039D874: addiu       $a2, $zero, 0x11
    ctx->r6 = ADD32(0, 0X11);
L_8039D878:
    // 0x8039D878: bne         $v0, $a2, L_8039D88C
    if (ctx->r2 != ctx->r6) {
        // 0x8039D87C: addu        $t7, $t1, $v0
        ctx->r15 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D88C;
    }
    // 0x8039D87C: addu        $t7, $t1, $v0
    ctx->r15 = ADD32(ctx->r9, ctx->r2);
    // 0x8039D880: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D884: b           L_8039D8A4
    // 0x8039D888: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
        goto L_8039D8A4;
    // 0x8039D888: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D88C:
    // 0x8039D88C: lbu         $t8, 0x3($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X3);
    // 0x8039D890: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D894: sll         $t5, $t8, 30
    ctx->r13 = S32(ctx->r24 << 30);
    // 0x8039D898: bgezl       $t5, L_8039D8A8
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8039D89C: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039D8A8;
    }
    goto skip_6;
    // 0x8039D89C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_6:
    // 0x8039D8A0: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D8A4:
    // 0x8039D8A4: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039D8A8:
    // 0x8039D8A8: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039D8AC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039D8B0: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x8039D8B4: bne         $at, $zero, L_8039D878
    if (ctx->r1 != 0) {
        // 0x8039D8B8: nop
    
            goto L_8039D878;
    }
    // 0x8039D8B8: nop

L_8039D8BC:
    // 0x8039D8BC: addiu       $v0, $zero, 0x11
    ctx->r2 = ADD32(0, 0X11);
    // 0x8039D8C0: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
L_8039D8C4:
    // 0x8039D8C4: lbu         $t5, 0x4($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X4);
    // 0x8039D8C8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D8CC: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x8039D8D0: sll         $t7, $t5, 30
    ctx->r15 = S32(ctx->r13 << 30);
    // 0x8039D8D4: bgez        $t7, L_8039D8E8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039D8D8: sra         $v0, $t9, 16
        ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
            goto L_8039D8E8;
    }
    // 0x8039D8D8: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039D8DC: addiu       $t8, $a1, 0x1
    ctx->r24 = ADD32(ctx->r5, 0X1);
    // 0x8039D8E0: sh          $t8, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r24;
    // 0x8039D8E4: lh          $a1, 0x0($t3)
    ctx->r5 = MEM_H(ctx->r11, 0X0);
L_8039D8E8:
    // 0x8039D8E8: slti        $at, $v0, 0x17
    ctx->r1 = SIGNED(ctx->r2) < 0X17 ? 1 : 0;
    // 0x8039D8EC: bnel        $at, $zero, L_8039D8C4
    if (ctx->r1 != 0) {
        // 0x8039D8F0: addu        $t9, $t1, $v0
        ctx->r25 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D8C4;
    }
    goto skip_7;
    // 0x8039D8F0: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
    skip_7:
    // 0x8039D8F4: slti        $at, $a1, 0x3
    ctx->r1 = SIGNED(ctx->r5) < 0X3 ? 1 : 0;
    // 0x8039D8F8: bne         $at, $zero, L_8039D954
    if (ctx->r1 != 0) {
        // 0x8039D8FC: addiu       $a2, $a1, 0x16
        ctx->r6 = ADD32(ctx->r5, 0X16);
            goto L_8039D954;
    }
    // 0x8039D8FC: addiu       $a2, $a1, 0x16
    ctx->r6 = ADD32(ctx->r5, 0X16);
    // 0x8039D900: slti        $at, $a2, 0x18
    ctx->r1 = SIGNED(ctx->r6) < 0X18 ? 1 : 0;
    // 0x8039D904: bne         $at, $zero, L_8039D954
    if (ctx->r1 != 0) {
        // 0x8039D908: addiu       $v0, $zero, 0x17
        ctx->r2 = ADD32(0, 0X17);
            goto L_8039D954;
    }
    // 0x8039D908: addiu       $v0, $zero, 0x17
    ctx->r2 = ADD32(0, 0X17);
    // 0x8039D90C: addiu       $a1, $zero, 0x17
    ctx->r5 = ADD32(0, 0X17);
L_8039D910:
    // 0x8039D910: bne         $v0, $a1, L_8039D924
    if (ctx->r2 != ctx->r5) {
        // 0x8039D914: addu        $t7, $t1, $v0
        ctx->r15 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D924;
    }
    // 0x8039D914: addu        $t7, $t1, $v0
    ctx->r15 = ADD32(ctx->r9, ctx->r2);
    // 0x8039D918: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D91C: b           L_8039D93C
    // 0x8039D920: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
        goto L_8039D93C;
    // 0x8039D920: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D924:
    // 0x8039D924: lbu         $t8, 0x3($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X3);
    // 0x8039D928: addu        $t6, $v1, $v0
    ctx->r14 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D92C: sll         $t5, $t8, 30
    ctx->r13 = S32(ctx->r24 << 30);
    // 0x8039D930: bgezl       $t5, L_8039D940
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8039D934: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039D940;
    }
    goto skip_8;
    // 0x8039D934: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_8:
    // 0x8039D938: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_8039D93C:
    // 0x8039D93C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039D940:
    // 0x8039D940: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039D944: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039D948: slt         $at, $v0, $a2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x8039D94C: bne         $at, $zero, L_8039D910
    if (ctx->r1 != 0) {
        // 0x8039D950: nop
    
            goto L_8039D910;
    }
    // 0x8039D950: nop

L_8039D954:
    // 0x8039D954: addiu       $v0, $zero, 0x17
    ctx->r2 = ADD32(0, 0X17);
    // 0x8039D958: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
L_8039D95C:
    // 0x8039D95C: lbu         $t5, 0x4($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X4);
    // 0x8039D960: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D964: sll         $t7, $t5, 30
    ctx->r15 = S32(ctx->r13 << 30);
    // 0x8039D968: bgez        $t7, L_8039D97C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8039D96C: sll         $t5, $v0, 16
        ctx->r13 = S32(ctx->r2 << 16);
            goto L_8039D97C;
    }
    // 0x8039D96C: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x8039D970: lh          $t8, 0x0($t2)
    ctx->r24 = MEM_H(ctx->r10, 0X0);
    // 0x8039D974: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8039D978: sh          $t9, 0x0($t2)
    MEM_H(0X0, ctx->r10) = ctx->r25;
L_8039D97C:
    // 0x8039D97C: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8039D980: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039D984: bnel        $at, $zero, L_8039D95C
    if (ctx->r1 != 0) {
        // 0x8039D988: addu        $t9, $t1, $v0
        ctx->r25 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D95C;
    }
    goto skip_9;
    // 0x8039D988: addu        $t9, $t1, $v0
    ctx->r25 = ADD32(ctx->r9, ctx->r2);
    skip_9:
    // 0x8039D98C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8039D990: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039D994: addu        $t7, $t1, $v0
    ctx->r15 = ADD32(ctx->r9, ctx->r2);
L_8039D998:
    // 0x8039D998: lbu         $t8, 0x4($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X4);
    // 0x8039D99C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D9A0: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039D9A4: andi        $t9, $t8, 0x1
    ctx->r25 = ctx->r24 & 0X1;
    // 0x8039D9A8: beq         $t9, $zero, L_8039D9BC
    if (ctx->r25 == 0) {
        // 0x8039D9AC: sra         $v0, $t7, 16
        ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
            goto L_8039D9BC;
    }
    // 0x8039D9AC: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039D9B0: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x8039D9B4: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x8039D9B8: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
L_8039D9BC:
    // 0x8039D9BC: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039D9C0: bnel        $at, $zero, L_8039D998
    if (ctx->r1 != 0) {
        // 0x8039D9C4: addu        $t7, $t1, $v0
        ctx->r15 = ADD32(ctx->r9, ctx->r2);
            goto L_8039D998;
    }
    goto skip_10;
    // 0x8039D9C4: addu        $t7, $t1, $v0
    ctx->r15 = ADD32(ctx->r9, ctx->r2);
    skip_10:
    // 0x8039D9C8: slti        $at, $a1, 0x1A
    ctx->r1 = SIGNED(ctx->r5) < 0X1A ? 1 : 0;
    // 0x8039D9CC: bne         $at, $zero, L_8039D9DC
    if (ctx->r1 != 0) {
        // 0x8039D9D0: lui         $a1, 0x803F
        ctx->r5 = S32(0X803F << 16);
            goto L_8039D9DC;
    }
    // 0x8039D9D0: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8039D9D4: b           L_8039D9E0
    // 0x8039D9D8: sb          $a0, 0x1F($v1)
    MEM_B(0X1F, ctx->r3) = ctx->r4;
        goto L_8039D9E0;
    // 0x8039D9D8: sb          $a0, 0x1F($v1)
    MEM_B(0X1F, ctx->r3) = ctx->r4;
L_8039D9DC:
    // 0x8039D9DC: sb          $zero, 0x1F($v1)
    MEM_B(0X1F, ctx->r3) = 0;
L_8039D9E0:
    // 0x8039D9E0: addiu       $a1, $a1, 0x6428
    ctx->r5 = ADD32(ctx->r5, 0X6428);
    // 0x8039D9E4: lh          $t9, 0xA($a1)
    ctx->r25 = MEM_H(ctx->r5, 0XA);
    // 0x8039D9E8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039D9EC: beq         $t9, $zero, L_8039DA0C
    if (ctx->r25 == 0) {
        // 0x8039D9F0: addu        $t5, $v1, $v0
        ctx->r13 = ADD32(ctx->r3, ctx->r2);
            goto L_8039DA0C;
    }
L_8039D9F0:
    // 0x8039D9F0: addu        $t5, $v1, $v0
    ctx->r13 = ADD32(ctx->r3, ctx->r2);
    // 0x8039D9F4: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039D9F8: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x8039D9FC: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039DA00: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x8039DA04: bne         $at, $zero, L_8039D9F0
    if (ctx->r1 != 0) {
        // 0x8039DA08: sb          $a0, 0x0($t5)
        MEM_B(0X0, ctx->r13) = ctx->r4;
            goto L_8039D9F0;
    }
    // 0x8039DA08: sb          $a0, 0x0($t5)
    MEM_B(0X0, ctx->r13) = ctx->r4;
L_8039DA0C:
    // 0x8039DA0C: lh          $t8, 0xC($a1)
    ctx->r24 = MEM_H(ctx->r5, 0XC);
    // 0x8039DA10: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
    // 0x8039DA14: beq         $t8, $zero, L_8039DA34
    if (ctx->r24 == 0) {
        // 0x8039DA18: addu        $t9, $v1, $v0
        ctx->r25 = ADD32(ctx->r3, ctx->r2);
            goto L_8039DA34;
    }
L_8039DA18:
    // 0x8039DA18: addu        $t9, $v1, $v0
    ctx->r25 = ADD32(ctx->r3, ctx->r2);
    // 0x8039DA1C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039DA20: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x8039DA24: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8039DA28: slti        $at, $v0, 0x11
    ctx->r1 = SIGNED(ctx->r2) < 0X11 ? 1 : 0;
    // 0x8039DA2C: bne         $at, $zero, L_8039DA18
    if (ctx->r1 != 0) {
        // 0x8039DA30: sb          $a0, 0x0($t9)
        MEM_B(0X0, ctx->r25) = ctx->r4;
            goto L_8039DA18;
    }
    // 0x8039DA30: sb          $a0, 0x0($t9)
    MEM_B(0X0, ctx->r25) = ctx->r4;
L_8039DA34:
    // 0x8039DA34: lh          $t7, 0xE($a1)
    ctx->r15 = MEM_H(ctx->r5, 0XE);
    // 0x8039DA38: addiu       $v0, $zero, 0x11
    ctx->r2 = ADD32(0, 0X11);
    // 0x8039DA3C: beq         $t7, $zero, L_8039DA5C
    if (ctx->r15 == 0) {
        // 0x8039DA40: addu        $t8, $v1, $v0
        ctx->r24 = ADD32(ctx->r3, ctx->r2);
            goto L_8039DA5C;
    }
L_8039DA40:
    // 0x8039DA40: addu        $t8, $v1, $v0
    ctx->r24 = ADD32(ctx->r3, ctx->r2);
    // 0x8039DA44: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039DA48: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x8039DA4C: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8039DA50: slti        $at, $v0, 0x17
    ctx->r1 = SIGNED(ctx->r2) < 0X17 ? 1 : 0;
    // 0x8039DA54: bne         $at, $zero, L_8039DA40
    if (ctx->r1 != 0) {
        // 0x8039DA58: sb          $a0, 0x0($t8)
        MEM_B(0X0, ctx->r24) = ctx->r4;
            goto L_8039DA40;
    }
    // 0x8039DA58: sb          $a0, 0x0($t8)
    MEM_B(0X0, ctx->r24) = ctx->r4;
L_8039DA5C:
    // 0x8039DA5C: lh          $t6, 0x10($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X10);
    // 0x8039DA60: addiu       $v0, $zero, 0x17
    ctx->r2 = ADD32(0, 0X17);
    // 0x8039DA64: beq         $t6, $zero, L_8039DA84
    if (ctx->r14 == 0) {
        // 0x8039DA68: addu        $t7, $v1, $v0
        ctx->r15 = ADD32(ctx->r3, ctx->r2);
            goto L_8039DA84;
    }
L_8039DA68:
    // 0x8039DA68: addu        $t7, $v1, $v0
    ctx->r15 = ADD32(ctx->r3, ctx->r2);
    // 0x8039DA6C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8039DA70: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8039DA74: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039DA78: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039DA7C: bne         $at, $zero, L_8039DA68
    if (ctx->r1 != 0) {
        // 0x8039DA80: sb          $a0, 0x0($t7)
        MEM_B(0X0, ctx->r15) = ctx->r4;
            goto L_8039DA68;
    }
    // 0x8039DA80: sb          $a0, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r4;
L_8039DA84:
    // 0x8039DA84: lh          $t5, 0x12($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X12);
    // 0x8039DA88: beql        $t5, $zero, L_8039DA98
    if (ctx->r13 == 0) {
        // 0x8039DA8C: lh          $t6, 0x14($a1)
        ctx->r14 = MEM_H(ctx->r5, 0X14);
            goto L_8039DA98;
    }
    goto skip_11;
    // 0x8039DA8C: lh          $t6, 0x14($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X14);
    skip_11:
    // 0x8039DA90: sb          $a0, 0x1E($v1)
    MEM_B(0X1E, ctx->r3) = ctx->r4;
    // 0x8039DA94: lh          $t6, 0x14($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X14);
L_8039DA98:
    // 0x8039DA98: beq         $t6, $zero, L_8039DAA4
    if (ctx->r14 == 0) {
        // 0x8039DA9C: nop
    
            goto L_8039DAA4;
    }
    // 0x8039DA9C: nop

    // 0x8039DAA0: sb          $a0, 0x1F($v1)
    MEM_B(0X1F, ctx->r3) = ctx->r4;
L_8039DAA4:
    // 0x8039DAA4: jr          $ra
    // 0x8039DAA8: nop

    return;
    // 0x8039DAA8: nop

;}
RECOMP_FUNC void get_next_available_level(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DAAC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8039DAB0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8039DAB4: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8039DAB8: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x8039DABC: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039DAC0: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039DAC4: addu        $a2, $a0, $a1
    ctx->r6 = ADD32(ctx->r4, ctx->r5);
    // 0x8039DAC8: sll         $v0, $a2, 16
    ctx->r2 = S32(ctx->r6 << 16);
    // 0x8039DACC: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x8039DAD0: sra         $t0, $v0, 16
    ctx->r8 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8039DAD4: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8039DAD8: addiu       $v1, $zero, 0x63
    ctx->r3 = ADD32(0, 0X63);
    // 0x8039DADC: beq         $a0, $t2, L_8039DB44
    if (ctx->r4 == ctx->r10) {
        // 0x8039DAE0: or          $v0, $t0, $zero
        ctx->r2 = ctx->r8 | 0;
            goto L_8039DB44;
    }
    // 0x8039DAE0: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x8039DAE4: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8039DAE8: addiu       $a2, $a2, 0x7DE0
    ctx->r6 = ADD32(ctx->r6, 0X7DE0);
    // 0x8039DAEC: addiu       $a3, $zero, 0x63
    ctx->r7 = ADD32(0, 0X63);
    // 0x8039DAF0: addu        $t3, $a2, $v0
    ctx->r11 = ADD32(ctx->r6, ctx->r2);
L_8039DAF4:
    // 0x8039DAF4: lb          $t4, 0x0($t3)
    ctx->r12 = MEM_B(ctx->r11, 0X0);
    // 0x8039DAF8: beql        $t4, $zero, L_8039DB18
    if (ctx->r12 == 0) {
        // 0x8039DAFC: addu        $v0, $v0, $a1
        ctx->r2 = ADD32(ctx->r2, ctx->r5);
            goto L_8039DB18;
    }
    goto skip_0;
    // 0x8039DAFC: addu        $v0, $v0, $a1
    ctx->r2 = ADD32(ctx->r2, ctx->r5);
    skip_0:
    // 0x8039DB00: bnel        $v1, $a3, L_8039DB18
    if (ctx->r3 != ctx->r7) {
        // 0x8039DB04: addu        $v0, $v0, $a1
        ctx->r2 = ADD32(ctx->r2, ctx->r5);
            goto L_8039DB18;
    }
    goto skip_1;
    // 0x8039DB04: addu        $v0, $v0, $a1
    ctx->r2 = ADD32(ctx->r2, ctx->r5);
    skip_1:
    // 0x8039DB08: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x8039DB0C: sra         $t5, $v1, 16
    ctx->r13 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8039DB10: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x8039DB14: addu        $v0, $v0, $a1
    ctx->r2 = ADD32(ctx->r2, ctx->r5);
L_8039DB18:
    // 0x8039DB18: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x8039DB1C: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039DB20: bgezl       $v0, L_8039DB30
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8039DB24: slti        $at, $v0, 0x20
        ctx->r1 = SIGNED(ctx->r2) < 0X20 ? 1 : 0;
            goto L_8039DB30;
    }
    goto skip_2;
    // 0x8039DB24: slti        $at, $v0, 0x20
    ctx->r1 = SIGNED(ctx->r2) < 0X20 ? 1 : 0;
    skip_2:
    // 0x8039DB28: addiu       $v0, $zero, 0x1F
    ctx->r2 = ADD32(0, 0X1F);
    // 0x8039DB2C: slti        $at, $v0, 0x20
    ctx->r1 = SIGNED(ctx->r2) < 0X20 ? 1 : 0;
L_8039DB30:
    // 0x8039DB30: bne         $at, $zero, L_8039DB3C
    if (ctx->r1 != 0) {
        // 0x8039DB34: nop
    
            goto L_8039DB3C;
    }
    // 0x8039DB34: nop

    // 0x8039DB38: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8039DB3C:
    // 0x8039DB3C: bnel        $v0, $a0, L_8039DAF4
    if (ctx->r2 != ctx->r4) {
        // 0x8039DB40: addu        $t3, $a2, $v0
        ctx->r11 = ADD32(ctx->r6, ctx->r2);
            goto L_8039DAF4;
    }
    goto skip_3;
    // 0x8039DB40: addu        $t3, $a2, $v0
    ctx->r11 = ADD32(ctx->r6, ctx->r2);
    skip_3:
L_8039DB44:
    // 0x8039DB44: addiu       $a3, $zero, 0x63
    ctx->r7 = ADD32(0, 0X63);
    // 0x8039DB48: beq         $v1, $a3, L_8039DB58
    if (ctx->r3 == ctx->r7) {
        // 0x8039DB4C: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_8039DB58;
    }
    // 0x8039DB4C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x8039DB50: jr          $ra
    // 0x8039DB54: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x8039DB54: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_8039DB58:
    // 0x8039DB58: jr          $ra
    // 0x8039DB5C: nop

    return;
    // 0x8039DB5C: nop

;}
RECOMP_FUNC void seconds_to_mins_secs(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DB60: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8039DB64: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039DB68: addiu       $v1, $zero, 0x3C
    ctx->r3 = ADD32(0, 0X3C);
    // 0x8039DB6C: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x8039DB70: mflo        $v0
    ctx->r2 = lo;
    // 0x8039DB74: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8039DB78: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039DB7C: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039DB80: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8039DB84: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8039DB88: bne         $v1, $zero, L_8039DB94
    if (ctx->r3 != 0) {
        // 0x8039DB8C: nop
    
            goto L_8039DB94;
    }
    // 0x8039DB8C: nop

    // 0x8039DB90: break       7
    do_break(2151275408);
L_8039DB94:
    // 0x8039DB94: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039DB98: bne         $v1, $at, L_8039DBAC
    if (ctx->r3 != ctx->r1) {
        // 0x8039DB9C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039DBAC;
    }
    // 0x8039DB9C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039DBA0: bne         $a0, $at, L_8039DBAC
    if (ctx->r4 != ctx->r1) {
        // 0x8039DBA4: nop
    
            goto L_8039DBAC;
    }
    // 0x8039DBA4: nop

    // 0x8039DBA8: break       6
    do_break(2151275432);
L_8039DBAC:
    // 0x8039DBAC: mflo        $t0
    ctx->r8 = lo;
    // 0x8039DBB0: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8039DBB4: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x8039DBB8: sh          $v0, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r2;
    // 0x8039DBBC: subu        $t3, $a0, $t2
    ctx->r11 = SUB32(ctx->r4, ctx->r10);
    // 0x8039DBC0: jr          $ra
    // 0x8039DBC4: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
    return;
    // 0x8039DBC4: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
;}
RECOMP_FUNC void get_biome_for_level(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DCC0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8039DCC4: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8039DCC8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8039DCCC: bltz        $t7, L_8039DCE8
    if (SIGNED(ctx->r15) < 0) {
        // 0x8039DCD0: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_8039DCE8;
    }
    // 0x8039DCD0: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x8039DCD4: slti        $at, $t7, 0xA
    ctx->r1 = SIGNED(ctx->r15) < 0XA ? 1 : 0;
    // 0x8039DCD8: beql        $at, $zero, L_8039DCEC
    if (ctx->r1 == 0) {
        // 0x8039DCDC: slti        $at, $a0, 0xA
        ctx->r1 = SIGNED(ctx->r4) < 0XA ? 1 : 0;
            goto L_8039DCEC;
    }
    goto skip_0;
    // 0x8039DCDC: slti        $at, $a0, 0xA
    ctx->r1 = SIGNED(ctx->r4) < 0XA ? 1 : 0;
    skip_0:
    // 0x8039DCE0: jr          $ra
    // 0x8039DCE4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x8039DCE4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8039DCE8:
    // 0x8039DCE8: slti        $at, $a0, 0xA
    ctx->r1 = SIGNED(ctx->r4) < 0XA ? 1 : 0;
L_8039DCEC:
    // 0x8039DCEC: bne         $at, $zero, L_8039DD04
    if (ctx->r1 != 0) {
        // 0x8039DCF0: slti        $at, $a0, 0x11
        ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
            goto L_8039DD04;
    }
    // 0x8039DCF0: slti        $at, $a0, 0x11
    ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
    // 0x8039DCF4: beql        $at, $zero, L_8039DD08
    if (ctx->r1 == 0) {
        // 0x8039DCF8: slti        $at, $a0, 0x11
        ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
            goto L_8039DD08;
    }
    goto skip_1;
    // 0x8039DCF8: slti        $at, $a0, 0x11
    ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
    skip_1:
    // 0x8039DCFC: jr          $ra
    // 0x8039DD00: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x8039DD00: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8039DD04:
    // 0x8039DD04: slti        $at, $a0, 0x11
    ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
L_8039DD08:
    // 0x8039DD08: bne         $at, $zero, L_8039DD20
    if (ctx->r1 != 0) {
        // 0x8039DD0C: slti        $at, $a0, 0x17
        ctx->r1 = SIGNED(ctx->r4) < 0X17 ? 1 : 0;
            goto L_8039DD20;
    }
    // 0x8039DD0C: slti        $at, $a0, 0x17
    ctx->r1 = SIGNED(ctx->r4) < 0X17 ? 1 : 0;
    // 0x8039DD10: beql        $at, $zero, L_8039DD24
    if (ctx->r1 == 0) {
        // 0x8039DD14: slti        $at, $a0, 0x17
        ctx->r1 = SIGNED(ctx->r4) < 0X17 ? 1 : 0;
            goto L_8039DD24;
    }
    goto skip_2;
    // 0x8039DD14: slti        $at, $a0, 0x17
    ctx->r1 = SIGNED(ctx->r4) < 0X17 ? 1 : 0;
    skip_2:
    // 0x8039DD18: jr          $ra
    // 0x8039DD1C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
    return;
    // 0x8039DD1C: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_8039DD20:
    // 0x8039DD20: slti        $at, $a0, 0x17
    ctx->r1 = SIGNED(ctx->r4) < 0X17 ? 1 : 0;
L_8039DD24:
    // 0x8039DD24: bne         $at, $zero, L_8039DD3C
    if (ctx->r1 != 0) {
        // 0x8039DD28: slti        $at, $a0, 0x1E
        ctx->r1 = SIGNED(ctx->r4) < 0X1E ? 1 : 0;
            goto L_8039DD3C;
    }
    // 0x8039DD28: slti        $at, $a0, 0x1E
    ctx->r1 = SIGNED(ctx->r4) < 0X1E ? 1 : 0;
    // 0x8039DD2C: beql        $at, $zero, L_8039DD40
    if (ctx->r1 == 0) {
        // 0x8039DD30: addiu       $at, $zero, 0x1E
        ctx->r1 = ADD32(0, 0X1E);
            goto L_8039DD40;
    }
    goto skip_3;
    // 0x8039DD30: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    skip_3:
    // 0x8039DD34: jr          $ra
    // 0x8039DD38: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
    return;
    // 0x8039DD38: addiu       $v0, $zero, 0x3
    ctx->r2 = ADD32(0, 0X3);
L_8039DD3C:
    // 0x8039DD3C: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
L_8039DD40:
    // 0x8039DD40: beq         $a0, $at, L_8039DD50
    if (ctx->r4 == ctx->r1) {
        // 0x8039DD44: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_8039DD50;
    }
    // 0x8039DD44: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x8039DD48: bne         $a0, $at, L_8039DD54
    if (ctx->r4 != ctx->r1) {
        // 0x8039DD4C: nop
    
            goto L_8039DD54;
    }
    // 0x8039DD4C: nop

L_8039DD50:
    // 0x8039DD50: addiu       $v0, $zero, 0x4
    ctx->r2 = ADD32(0, 0X4);
L_8039DD54:
    // 0x8039DD54: jr          $ra
    // 0x8039DD58: nop

    return;
    // 0x8039DD58: nop

;}
RECOMP_FUNC void reset_trails(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DD60: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8039DD64: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8039DD68: lui         $at, 0x8040
    ctx->r1 = S32(0X8040 << 16);
    // 0x8039DD6C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8039DD70: sh          $zero, -0x2160($at)
    MEM_H(-0X2160, ctx->r1) = 0;
    // 0x8039DD74: addiu       $a0, $a0, 0x7E10
    ctx->r4 = ADD32(ctx->r4, 0X7E10);
    // 0x8039DD78: jal         0x80128FB4
    // 0x8039DD7C: addiu       $a1, $zero, 0x6090
    ctx->r5 = ADD32(0, 0X6090);
    bzero_sssv(rdram, ctx);
        goto after_0;
    // 0x8039DD7C: addiu       $a1, $zero, 0x6090
    ctx->r5 = ADD32(0, 0X6090);
    after_0:
    // 0x8039DD80: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8039DD84: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8039DD88: jr          $ra
    // 0x8039DD8C: nop

    return;
    // 0x8039DD8C: nop

;}
RECOMP_FUNC void func_8039DD90_7AF440(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DD90: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x8039DD94: andi        $t7, $t6, 0xFFF0
    ctx->r15 = ctx->r14 & 0XFFF0;
    // 0x8039DD98: ori         $t8, $t7, 0x2
    ctx->r24 = ctx->r15 | 0X2;
    // 0x8039DD9C: jr          $ra
    // 0x8039DDA0: sb          $t8, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r24;
    return;
    // 0x8039DDA0: sb          $t8, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r24;
;}
RECOMP_FUNC void add_regular_trail(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DDA4: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x8039DDA8: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x8039DDAC: lw          $s0, 0x50($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X50);
    // 0x8039DDB0: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x8039DDB4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8039DDB8: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    // 0x8039DDBC: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8039DDC0: andi        $t7, $a2, 0xFF
    ctx->r15 = ctx->r6 & 0XFF;
    // 0x8039DDC4: andi        $t8, $a3, 0xFF
    ctx->r24 = ctx->r7 & 0XFF;
    // 0x8039DDC8: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8039DDCC: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8039DDD0: beq         $s0, $zero, L_8039DE54
    if (ctx->r16 == 0) {
        // 0x8039DDD4: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_8039DE54;
    }
    // 0x8039DDD4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8039DDD8: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039DDDC: addiu       $t0, $t0, 0x7E10
    ctx->r8 = ADD32(ctx->r8, 0X7E10);
    // 0x8039DDE0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039DDE4: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x8039DDE8: addiu       $t1, $zero, 0x338
    ctx->r9 = ADD32(0, 0X338);
L_8039DDEC:
    // 0x8039DDEC: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039DDF0: mflo        $t9
    ctx->r25 = lo;
    // 0x8039DDF4: addu        $v1, $t0, $t9
    ctx->r3 = ADD32(ctx->r8, ctx->r25);
    // 0x8039DDF8: lw          $t3, 0x4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X4);
    // 0x8039DDFC: bnel        $s0, $t3, L_8039DE40
    if (ctx->r16 != ctx->r11) {
        // 0x8039DE00: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039DE40;
    }
    goto skip_0;
    // 0x8039DE00: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_0:
    // 0x8039DE04: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x8039DE08: srl         $t5, $t4, 28
    ctx->r13 = S32(U32(ctx->r12) >> 28);
    // 0x8039DE0C: beql        $t5, $zero, L_8039DE40
    if (ctx->r13 == 0) {
        // 0x8039DE10: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039DE40;
    }
    goto skip_1;
    // 0x8039DE10: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_1:
    // 0x8039DE14: lbu         $t6, 0x0($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X0);
    // 0x8039DE18: andi        $t7, $t6, 0xF
    ctx->r15 = ctx->r14 & 0XF;
    // 0x8039DE1C: beql        $t2, $t7, L_8039DE40
    if (ctx->r10 == ctx->r15) {
        // 0x8039DE20: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039DE40;
    }
    goto skip_2;
    // 0x8039DE20: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_2:
    // 0x8039DE24: lbu         $t8, 0x1($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X1);
    // 0x8039DE28: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8039DE2C: andi        $t9, $t8, 0xFFF0
    ctx->r25 = ctx->r24 & 0XFFF0;
    // 0x8039DE30: ori         $t3, $t9, 0x1
    ctx->r11 = ctx->r25 | 0X1;
    // 0x8039DE34: b           L_8039DFC8
    // 0x8039DE38: sb          $t3, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r11;
        goto L_8039DFC8;
    // 0x8039DE38: sb          $t3, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r11;
    // 0x8039DE3C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039DE40:
    // 0x8039DE40: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x8039DE44: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8039DE48: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039DE4C: bne         $at, $zero, L_8039DDEC
    if (ctx->r1 != 0) {
        // 0x8039DE50: nop
    
            goto L_8039DDEC;
    }
    // 0x8039DE50: nop

L_8039DE54:
    // 0x8039DE54: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039DE58: addiu       $t0, $t0, 0x7E10
    ctx->r8 = ADD32(ctx->r8, 0X7E10);
    // 0x8039DE5C: addiu       $t1, $zero, 0x338
    ctx->r9 = ADD32(0, 0X338);
    // 0x8039DE60: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8039DE64:
    // 0x8039DE64: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039DE68: mflo        $t6
    ctx->r14 = lo;
    // 0x8039DE6C: addu        $v1, $t0, $t6
    ctx->r3 = ADD32(ctx->r8, ctx->r14);
    // 0x8039DE70: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x8039DE74: srl         $t8, $t7, 28
    ctx->r24 = S32(U32(ctx->r15) >> 28);
    // 0x8039DE78: bnel        $t8, $zero, L_8039DFB4
    if (ctx->r24 != 0) {
        // 0x8039DE7C: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039DFB4;
    }
    goto skip_3;
    // 0x8039DE7C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_3:
    // 0x8039DE80: lbu         $t9, 0x0($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X0);
    // 0x8039DE84: sw          $a0, 0x248($v1)
    MEM_W(0X248, ctx->r3) = ctx->r4;
    // 0x8039DE88: lbu         $a0, 0x4B($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X4B);
    // 0x8039DE8C: andi        $t3, $t9, 0xFF0F
    ctx->r11 = ctx->r25 & 0XFF0F;
    // 0x8039DE90: ori         $t5, $t3, 0x10
    ctx->r13 = ctx->r11 | 0X10;
    // 0x8039DE94: sb          $t5, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r13;
    // 0x8039DE98: andi        $t6, $t5, 0xF0
    ctx->r14 = ctx->r13 & 0XF0;
    // 0x8039DE9C: lbu         $t5, 0x1($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X1);
    // 0x8039DEA0: lbu         $t9, 0x4F($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X4F);
    // 0x8039DEA4: ori         $t7, $t6, 0x1
    ctx->r15 = ctx->r14 | 0X1;
    // 0x8039DEA8: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8039DEAC: sll         $t4, $t9, 4
    ctx->r12 = S32(ctx->r25 << 4);
    // 0x8039DEB0: multu       $a3, $a0
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039DEB4: sb          $t7, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r15;
    // 0x8039DEB8: or          $t8, $t4, $t6
    ctx->r24 = ctx->r12 | ctx->r14;
    // 0x8039DEBC: lbu         $t7, 0x8($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X8);
    // 0x8039DEC0: andi        $t9, $t8, 0xF0
    ctx->r25 = ctx->r24 & 0XF0;
    // 0x8039DEC4: sb          $t8, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r24;
    // 0x8039DEC8: or          $t5, $a1, $zero
    ctx->r13 = ctx->r5 | 0;
    // 0x8039DECC: ori         $t3, $t9, 0x1
    ctx->r11 = ctx->r25 | 0X1;
    // 0x8039DED0: sll         $t6, $t5, 4
    ctx->r14 = S32(ctx->r13 << 4);
    // 0x8039DED4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x8039DED8: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x8039DEDC: lbu         $t8, 0x2F($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X2F);
    // 0x8039DEE0: sb          $t9, 0x8($v1)
    MEM_B(0X8, ctx->r3) = ctx->r25;
    // 0x8039DEE4: lbu         $t9, 0x33($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X33);
    // 0x8039DEE8: sb          $t8, 0x10($v1)
    MEM_B(0X10, ctx->r3) = ctx->r24;
    // 0x8039DEEC: mflo        $t8
    ctx->r24 = lo;
    // 0x8039DEF0: sb          $t9, 0x11($v1)
    MEM_B(0X11, ctx->r3) = ctx->r25;
    // 0x8039DEF4: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x8039DEF8: div         $zero, $t9, $t8
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r24))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r24)));
    // 0x8039DEFC: lh          $t5, 0x1E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X1E);
    // 0x8039DF00: sb          $t3, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r11;
    // 0x8039DF04: lh          $t3, 0x1A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X1A);
    // 0x8039DF08: lh          $t4, 0x22($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X22);
    // 0x8039DF0C: sh          $t5, 0x242($v1)
    MEM_H(0X242, ctx->r3) = ctx->r13;
    // 0x8039DF10: lbu         $t5, 0x3B($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X3B);
    // 0x8039DF14: lbu         $t7, 0x27($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X27);
    // 0x8039DF18: lbu         $t6, 0x2B($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X2B);
    // 0x8039DF1C: lui         $a1, 0x8040
    ctx->r5 = S32(0X8040 << 16);
    // 0x8039DF20: sh          $t3, 0x240($v1)
    MEM_H(0X240, ctx->r3) = ctx->r11;
    // 0x8039DF24: sh          $t4, 0x244($v1)
    MEM_H(0X244, ctx->r3) = ctx->r12;
    // 0x8039DF28: lbu         $t3, 0x37($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X37);
    // 0x8039DF2C: lbu         $t4, 0x3F($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X3F);
    // 0x8039DF30: addiu       $a1, $a1, -0x2160
    ctx->r5 = ADD32(ctx->r5, -0X2160);
    // 0x8039DF34: sb          $t5, 0x13($v1)
    MEM_B(0X13, ctx->r3) = ctx->r13;
    // 0x8039DF38: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x8039DF3C: sb          $t7, 0xE($v1)
    MEM_B(0XE, ctx->r3) = ctx->r15;
    // 0x8039DF40: sb          $t6, 0xF($v1)
    MEM_B(0XF, ctx->r3) = ctx->r14;
    // 0x8039DF44: lbu         $t7, 0x43($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X43);
    // 0x8039DF48: lbu         $t6, 0x47($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X47);
    // 0x8039DF4C: sb          $t3, 0x12($v1)
    MEM_B(0X12, ctx->r3) = ctx->r11;
    // 0x8039DF50: sb          $t4, 0x14($v1)
    MEM_B(0X14, ctx->r3) = ctx->r12;
    // 0x8039DF54: mflo        $t3
    ctx->r11 = lo;
    // 0x8039DF58: addiu       $t4, $t5, 0x1
    ctx->r12 = ADD32(ctx->r13, 0X1);
    // 0x8039DF5C: sw          $s0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r16;
    // 0x8039DF60: sb          $zero, 0xB($v1)
    MEM_B(0XB, ctx->r3) = 0;
    // 0x8039DF64: sb          $zero, 0xC($v1)
    MEM_B(0XC, ctx->r3) = 0;
    // 0x8039DF68: sb          $a2, 0xD($v1)
    MEM_B(0XD, ctx->r3) = ctx->r6;
    // 0x8039DF6C: sb          $t3, 0x17($v1)
    MEM_B(0X17, ctx->r3) = ctx->r11;
    // 0x8039DF70: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
    // 0x8039DF74: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8039DF78: sb          $a0, 0x18($v1)
    MEM_B(0X18, ctx->r3) = ctx->r4;
    // 0x8039DF7C: sb          $t7, 0x15($v1)
    MEM_B(0X15, ctx->r3) = ctx->r15;
    // 0x8039DF80: sb          $t6, 0x16($v1)
    MEM_B(0X16, ctx->r3) = ctx->r14;
    // 0x8039DF84: bne         $t8, $zero, L_8039DF90
    if (ctx->r24 != 0) {
        // 0x8039DF88: nop
    
            goto L_8039DF90;
    }
    // 0x8039DF88: nop

    // 0x8039DF8C: break       7
    do_break(2151276428);
L_8039DF90:
    // 0x8039DF90: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039DF94: bne         $t8, $at, L_8039DFA8
    if (ctx->r24 != ctx->r1) {
        // 0x8039DF98: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039DFA8;
    }
    // 0x8039DF98: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039DF9C: bne         $t9, $at, L_8039DFA8
    if (ctx->r25 != ctx->r1) {
        // 0x8039DFA0: nop
    
            goto L_8039DFA8;
    }
    // 0x8039DFA0: nop

    // 0x8039DFA4: break       6
    do_break(2151276452);
L_8039DFA8:
    // 0x8039DFA8: b           L_8039DFCC
    // 0x8039DFAC: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
        goto L_8039DFCC;
    // 0x8039DFAC: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x8039DFB0: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039DFB4:
    // 0x8039DFB4: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x8039DFB8: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8039DFBC: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039DFC0: bne         $at, $zero, L_8039DE64
    if (ctx->r1 != 0) {
        // 0x8039DFC4: nop
    
            goto L_8039DE64;
    }
    // 0x8039DFC4: nop

L_8039DFC8:
    // 0x8039DFC8: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
L_8039DFCC:
    // 0x8039DFCC: jr          $ra
    // 0x8039DFD0: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    return;
    // 0x8039DFD0: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
;}
RECOMP_FUNC void add_walrus_wake(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039DFD4: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x8039DFD8: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x8039DFDC: lw          $s0, 0x44($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X44);
    // 0x8039DFE0: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x8039DFE4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8039DFE8: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    // 0x8039DFEC: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8039DFF0: andi        $t7, $a2, 0xFF
    ctx->r15 = ctx->r6 & 0XFF;
    // 0x8039DFF4: andi        $t8, $a3, 0xFF
    ctx->r24 = ctx->r7 & 0XFF;
    // 0x8039DFF8: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8039DFFC: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8039E000: beq         $s0, $zero, L_8039E0A0
    if (ctx->r16 == 0) {
        // 0x8039E004: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_8039E0A0;
    }
    // 0x8039E004: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8039E008: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039E00C: addiu       $t0, $t0, 0x7E10
    ctx->r8 = ADD32(ctx->r8, 0X7E10);
    // 0x8039E010: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039E014: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x8039E018: addiu       $t1, $zero, 0x338
    ctx->r9 = ADD32(0, 0X338);
L_8039E01C:
    // 0x8039E01C: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E020: mflo        $t9
    ctx->r25 = lo;
    // 0x8039E024: addu        $v1, $t0, $t9
    ctx->r3 = ADD32(ctx->r8, ctx->r25);
    // 0x8039E028: lw          $t3, 0x4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X4);
    // 0x8039E02C: bnel        $s0, $t3, L_8039E070
    if (ctx->r16 != ctx->r11) {
        // 0x8039E030: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039E070;
    }
    goto skip_0;
    // 0x8039E030: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_0:
    // 0x8039E034: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x8039E038: srl         $t5, $t4, 28
    ctx->r13 = S32(U32(ctx->r12) >> 28);
    // 0x8039E03C: beql        $t5, $zero, L_8039E070
    if (ctx->r13 == 0) {
        // 0x8039E040: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039E070;
    }
    goto skip_1;
    // 0x8039E040: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_1:
    // 0x8039E044: lbu         $t6, 0x0($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X0);
    // 0x8039E048: andi        $t7, $t6, 0xF
    ctx->r15 = ctx->r14 & 0XF;
    // 0x8039E04C: beql        $t2, $t7, L_8039E070
    if (ctx->r10 == ctx->r15) {
        // 0x8039E050: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039E070;
    }
    goto skip_2;
    // 0x8039E050: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_2:
    // 0x8039E054: lbu         $t8, 0x1($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X1);
    // 0x8039E058: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8039E05C: andi        $t9, $t8, 0xFFF0
    ctx->r25 = ctx->r24 & 0XFFF0;
    // 0x8039E060: ori         $t3, $t9, 0x1
    ctx->r11 = ctx->r25 | 0X1;
    // 0x8039E064: b           L_8039E200
    // 0x8039E068: sb          $t3, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r11;
        goto L_8039E200;
    // 0x8039E068: sb          $t3, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r11;
    // 0x8039E06C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039E070:
    // 0x8039E070: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x8039E074: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8039E078: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039E07C: bne         $at, $zero, L_8039E01C
    if (ctx->r1 != 0) {
        // 0x8039E080: nop
    
            goto L_8039E01C;
    }
    // 0x8039E080: nop

    // 0x8039E084: lh          $t6, 0x1C($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X1C);
    // 0x8039E088: lh          $t7, 0x20($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X20);
    // 0x8039E08C: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x8039E090: bne         $t8, $zero, L_8039E0A0
    if (ctx->r24 != 0) {
        // 0x8039E094: nop
    
            goto L_8039E0A0;
    }
    // 0x8039E094: nop

    // 0x8039E098: b           L_8039E200
    // 0x8039E09C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_8039E200;
    // 0x8039E09C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8039E0A0:
    // 0x8039E0A0: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039E0A4: addiu       $t0, $t0, 0x7E10
    ctx->r8 = ADD32(ctx->r8, 0X7E10);
    // 0x8039E0A8: addiu       $t1, $zero, 0x338
    ctx->r9 = ADD32(0, 0X338);
    // 0x8039E0AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8039E0B0:
    // 0x8039E0B0: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E0B4: mflo        $t9
    ctx->r25 = lo;
    // 0x8039E0B8: addu        $v1, $t0, $t9
    ctx->r3 = ADD32(ctx->r8, ctx->r25);
    // 0x8039E0BC: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x8039E0C0: srl         $t4, $t3, 28
    ctx->r12 = S32(U32(ctx->r11) >> 28);
    // 0x8039E0C4: bnel        $t4, $zero, L_8039E1EC
    if (ctx->r12 != 0) {
        // 0x8039E0C8: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039E1EC;
    }
    goto skip_3;
    // 0x8039E0C8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_3:
    // 0x8039E0CC: lbu         $t5, 0x0($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X0);
    // 0x8039E0D0: sw          $a0, 0x330($v1)
    MEM_W(0X330, ctx->r3) = ctx->r4;
    // 0x8039E0D4: lbu         $a0, 0x3F($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X3F);
    // 0x8039E0D8: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8039E0DC: ori         $t8, $t6, 0x30
    ctx->r24 = ctx->r14 | 0X30;
    // 0x8039E0E0: sb          $t8, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r24;
    // 0x8039E0E4: andi        $t9, $t8, 0xF0
    ctx->r25 = ctx->r24 & 0XF0;
    // 0x8039E0E8: lbu         $t8, 0x1($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X1);
    // 0x8039E0EC: lbu         $t5, 0x43($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X43);
    // 0x8039E0F0: ori         $t3, $t9, 0x1
    ctx->r11 = ctx->r25 | 0X1;
    // 0x8039E0F4: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x8039E0F8: sll         $t7, $t5, 4
    ctx->r15 = S32(ctx->r13 << 4);
    // 0x8039E0FC: or          $t4, $t7, $t9
    ctx->r12 = ctx->r15 | ctx->r25;
    // 0x8039E100: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
    // 0x8039E104: sb          $t3, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r11;
    // 0x8039E108: lbu         $t3, 0x8($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X8);
    // 0x8039E10C: sh          $t7, 0x32C($v1)
    MEM_H(0X32C, ctx->r3) = ctx->r15;
    // 0x8039E110: addiu       $t7, $a3, -0x2
    ctx->r15 = ADD32(ctx->r7, -0X2);
    // 0x8039E114: multu       $t7, $a0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E118: sb          $t4, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r12;
    // 0x8039E11C: andi        $t5, $t4, 0xF0
    ctx->r13 = ctx->r12 & 0XF0;
    // 0x8039E120: or          $t8, $a1, $zero
    ctx->r24 = ctx->r5 | 0;
    // 0x8039E124: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x8039E128: lbu         $t3, 0x27($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X27);
    // 0x8039E12C: ori         $t6, $t5, 0x1
    ctx->r14 = ctx->r13 | 0X1;
    // 0x8039E130: sll         $t9, $t8, 4
    ctx->r25 = S32(ctx->r24 << 4);
    // 0x8039E134: or          $t5, $t9, $t4
    ctx->r13 = ctx->r25 | ctx->r12;
    // 0x8039E138: lbu         $t9, 0x2B($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X2B);
    // 0x8039E13C: sb          $t3, 0xE($v1)
    MEM_B(0XE, ctx->r3) = ctx->r11;
    // 0x8039E140: mflo        $t3
    ctx->r11 = lo;
    // 0x8039E144: sb          $t9, 0xF($v1)
    MEM_B(0XF, ctx->r3) = ctx->r25;
    // 0x8039E148: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x8039E14C: div         $zero, $t9, $t3
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r11)));
    // 0x8039E150: sb          $t6, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r14;
    // 0x8039E154: lh          $t6, 0x1A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X1A);
    // 0x8039E158: sb          $t5, 0x8($v1)
    MEM_B(0X8, ctx->r3) = ctx->r13;
    // 0x8039E15C: lbu         $t5, 0x33($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X33);
    // 0x8039E160: lh          $t8, 0x1E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X1E);
    // 0x8039E164: lui         $a1, 0x8040
    ctx->r5 = S32(0X8040 << 16);
    // 0x8039E168: sh          $t6, 0x328($v1)
    MEM_H(0X328, ctx->r3) = ctx->r14;
    // 0x8039E16C: lbu         $t4, 0x2F($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X2F);
    // 0x8039E170: lbu         $t6, 0x37($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X37);
    // 0x8039E174: addiu       $a1, $a1, -0x2160
    ctx->r5 = ADD32(ctx->r5, -0X2160);
    // 0x8039E178: sb          $t5, 0x11($v1)
    MEM_B(0X11, ctx->r3) = ctx->r13;
    // 0x8039E17C: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x8039E180: sh          $t8, 0x32A($v1)
    MEM_H(0X32A, ctx->r3) = ctx->r24;
    // 0x8039E184: lbu         $t8, 0x3B($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X3B);
    // 0x8039E188: sb          $t4, 0x10($v1)
    MEM_B(0X10, ctx->r3) = ctx->r12;
    // 0x8039E18C: sb          $t6, 0x12($v1)
    MEM_B(0X12, ctx->r3) = ctx->r14;
    // 0x8039E190: mflo        $t4
    ctx->r12 = lo;
    // 0x8039E194: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x8039E198: sw          $s0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r16;
    // 0x8039E19C: sb          $zero, 0xB($v1)
    MEM_B(0XB, ctx->r3) = 0;
    // 0x8039E1A0: sb          $zero, 0xC($v1)
    MEM_B(0XC, ctx->r3) = 0;
    // 0x8039E1A4: sb          $a2, 0xD($v1)
    MEM_B(0XD, ctx->r3) = ctx->r6;
    // 0x8039E1A8: sb          $t4, 0x14($v1)
    MEM_B(0X14, ctx->r3) = ctx->r12;
    // 0x8039E1AC: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
    // 0x8039E1B0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8039E1B4: sb          $a0, 0x15($v1)
    MEM_B(0X15, ctx->r3) = ctx->r4;
    // 0x8039E1B8: sb          $t8, 0x13($v1)
    MEM_B(0X13, ctx->r3) = ctx->r24;
    // 0x8039E1BC: bne         $t3, $zero, L_8039E1C8
    if (ctx->r11 != 0) {
        // 0x8039E1C0: nop
    
            goto L_8039E1C8;
    }
    // 0x8039E1C0: nop

    // 0x8039E1C4: break       7
    do_break(2151276996);
L_8039E1C8:
    // 0x8039E1C8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8039E1CC: bne         $t3, $at, L_8039E1E0
    if (ctx->r11 != ctx->r1) {
        // 0x8039E1D0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8039E1E0;
    }
    // 0x8039E1D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8039E1D4: bne         $t9, $at, L_8039E1E0
    if (ctx->r25 != ctx->r1) {
        // 0x8039E1D8: nop
    
            goto L_8039E1E0;
    }
    // 0x8039E1D8: nop

    // 0x8039E1DC: break       6
    do_break(2151277020);
L_8039E1E0:
    // 0x8039E1E0: b           L_8039E204
    // 0x8039E1E4: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
        goto L_8039E204;
    // 0x8039E1E4: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x8039E1E8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039E1EC:
    // 0x8039E1EC: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8039E1F0: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8039E1F4: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039E1F8: bne         $at, $zero, L_8039E0B0
    if (ctx->r1 != 0) {
        // 0x8039E1FC: nop
    
            goto L_8039E0B0;
    }
    // 0x8039E1FC: nop

L_8039E200:
    // 0x8039E200: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
L_8039E204:
    // 0x8039E204: jr          $ra
    // 0x8039E208: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    return;
    // 0x8039E208: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
;}
RECOMP_FUNC void add_simple_trail(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039E20C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8039E210: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x8039E214: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x8039E218: andi        $t7, $a2, 0xFF
    ctx->r15 = ctx->r6 & 0XFF;
    // 0x8039E21C: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x8039E220: andi        $t8, $a3, 0xFF
    ctx->r24 = ctx->r7 & 0XFF;
    // 0x8039E224: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8039E228: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8039E22C: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8039E230: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x8039E234: addiu       $t0, $t0, 0x7E10
    ctx->r8 = ADD32(ctx->r8, 0X7E10);
    // 0x8039E238: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8039E23C: addiu       $t1, $zero, 0x338
    ctx->r9 = ADD32(0, 0X338);
L_8039E240:
    // 0x8039E240: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E244: mflo        $t9
    ctx->r25 = lo;
    // 0x8039E248: addu        $v1, $t0, $t9
    ctx->r3 = ADD32(ctx->r8, ctx->r25);
    // 0x8039E24C: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x8039E250: srl         $t3, $t2, 28
    ctx->r11 = S32(U32(ctx->r10) >> 28);
    // 0x8039E254: bnel        $t3, $zero, L_8039E320
    if (ctx->r11 != 0) {
        // 0x8039E258: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_8039E320;
    }
    goto skip_0;
    // 0x8039E258: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_0:
    // 0x8039E25C: lbu         $t4, 0x0($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X0);
    // 0x8039E260: lbu         $t3, 0x37($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X37);
    // 0x8039E264: lbu         $t6, 0x1($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X1);
    // 0x8039E268: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x8039E26C: ori         $t7, $t5, 0x40
    ctx->r15 = ctx->r13 | 0X40;
    // 0x8039E270: andi        $t8, $t7, 0xF0
    ctx->r24 = ctx->r15 & 0XF0;
    // 0x8039E274: sb          $t7, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r15;
    // 0x8039E278: ori         $t9, $t8, 0x1
    ctx->r25 = ctx->r24 | 0X1;
    // 0x8039E27C: sll         $t5, $t3, 4
    ctx->r13 = S32(ctx->r11 << 4);
    // 0x8039E280: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x8039E284: lbu         $t4, 0x8($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X8);
    // 0x8039E288: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x8039E28C: sb          $t8, 0x1($v1)
    MEM_B(0X1, ctx->r3) = ctx->r24;
    // 0x8039E290: lh          $t8, 0x16($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X16);
    // 0x8039E294: sll         $t3, $a1, 4
    ctx->r11 = S32(ctx->r5 << 4);
    // 0x8039E298: sw          $a0, 0x248($v1)
    MEM_W(0X248, ctx->r3) = ctx->r4;
    // 0x8039E29C: andi        $t6, $t4, 0xFF0F
    ctx->r14 = ctx->r12 & 0XFF0F;
    // 0x8039E2A0: lh          $t7, 0x12($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X12);
    // 0x8039E2A4: sb          $t9, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r25;
    // 0x8039E2A8: or          $t5, $t3, $t6
    ctx->r13 = ctx->r11 | ctx->r14;
    // 0x8039E2AC: lui         $a0, 0x8040
    ctx->r4 = S32(0X8040 << 16);
    // 0x8039E2B0: lh          $t9, 0x1A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X1A);
    // 0x8039E2B4: addiu       $a0, $a0, -0x2160
    ctx->r4 = ADD32(ctx->r4, -0X2160);
    // 0x8039E2B8: sh          $t8, 0x242($v1)
    MEM_H(0X242, ctx->r3) = ctx->r24;
    // 0x8039E2BC: lh          $t8, 0x0($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X0);
    // 0x8039E2C0: sb          $t5, 0x8($v1)
    MEM_B(0X8, ctx->r3) = ctx->r13;
    // 0x8039E2C4: sh          $t7, 0x240($v1)
    MEM_H(0X240, ctx->r3) = ctx->r15;
    // 0x8039E2C8: lbu         $t2, 0x1F($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X1F);
    // 0x8039E2CC: lbu         $t4, 0x23($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X23);
    // 0x8039E2D0: lbu         $t3, 0x27($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X27);
    // 0x8039E2D4: lbu         $t6, 0x2B($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X2B);
    // 0x8039E2D8: lbu         $t5, 0x2F($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X2F);
    // 0x8039E2DC: lbu         $t7, 0x33($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X33);
    // 0x8039E2E0: sh          $t9, 0x244($v1)
    MEM_H(0X244, ctx->r3) = ctx->r25;
    // 0x8039E2E4: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8039E2E8: sb          $zero, 0x9($v1)
    MEM_B(0X9, ctx->r3) = 0;
    // 0x8039E2EC: sb          $zero, 0xA($v1)
    MEM_B(0XA, ctx->r3) = 0;
    // 0x8039E2F0: sb          $a2, 0xB($v1)
    MEM_B(0XB, ctx->r3) = ctx->r6;
    // 0x8039E2F4: sb          $a3, 0x12($v1)
    MEM_B(0X12, ctx->r3) = ctx->r7;
    // 0x8039E2F8: sh          $t9, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r25;
    // 0x8039E2FC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8039E300: sb          $t2, 0xC($v1)
    MEM_B(0XC, ctx->r3) = ctx->r10;
    // 0x8039E304: sb          $t4, 0xD($v1)
    MEM_B(0XD, ctx->r3) = ctx->r12;
    // 0x8039E308: sb          $t3, 0xE($v1)
    MEM_B(0XE, ctx->r3) = ctx->r11;
    // 0x8039E30C: sb          $t6, 0xF($v1)
    MEM_B(0XF, ctx->r3) = ctx->r14;
    // 0x8039E310: sb          $t5, 0x10($v1)
    MEM_B(0X10, ctx->r3) = ctx->r13;
    // 0x8039E314: jr          $ra
    // 0x8039E318: sb          $t7, 0x11($v1)
    MEM_B(0X11, ctx->r3) = ctx->r15;
    return;
    // 0x8039E318: sb          $t7, 0x11($v1)
    MEM_B(0X11, ctx->r3) = ctx->r15;
    // 0x8039E31C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_8039E320:
    // 0x8039E320: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x8039E324: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8039E328: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x8039E32C: bne         $at, $zero, L_8039E240
    if (ctx->r1 != 0) {
        // 0x8039E330: nop
    
            goto L_8039E240;
    }
    // 0x8039E330: nop

    // 0x8039E334: jr          $ra
    // 0x8039E338: nop

    return;
    // 0x8039E338: nop

;}
RECOMP_FUNC void func_8039E33C_7AF9EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8039E33C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8039E340: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8039E344: lbu         $t6, 0x1($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X1);
    // 0x8039E348: lw          $a3, 0x328($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X328);
    // 0x8039E34C: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x8039E350: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x8039E354: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8039E358: addu        $t9, $a0, $t8
    ctx->r25 = ADD32(ctx->r4, ctx->r24);
    // 0x8039E35C: sh          $zero, 0xE($t9)
    MEM_H(0XE, ctx->r25) = 0;
    // 0x8039E360: lbu         $t2, 0x1($a0)
    ctx->r10 = MEM_BU(ctx->r4, 0X1);
    // 0x8039E364: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x8039E368: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x8039E36C: addu        $t5, $a0, $t4
    ctx->r13 = ADD32(ctx->r4, ctx->r12);
    // 0x8039E370: sh          $zero, 0x3E($t5)
    MEM_H(0X3E, ctx->r13) = 0;
    // 0x8039E374: lw          $t0, 0x1C($a3)
    ctx->r8 = MEM_W(ctx->r7, 0X1C);
    // 0x8039E378: lw          $t1, 0x20($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X20);
    // 0x8039E37C: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x8039E380: sra         $t6, $t0, 8
    ctx->r14 = S32(SIGNED(ctx->r8) >> 8);
    // 0x8039E384: sra         $t7, $t1, 8
    ctx->r15 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8039E388: sll         $a1, $t7, 16
    ctx->r5 = S32(ctx->r15 << 16);
    // 0x8039E38C: sll         $a0, $t6, 16
    ctx->r4 = S32(ctx->r14 << 16);
    // 0x8039E390: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8039E394: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8039E398: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x8039E39C: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x8039E3A0: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8039E3A4: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8039E3A8: jal         0x801284B8
    // 0x8039E3AC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    func_801284B8(rdram, ctx);
        goto after_0;
    // 0x8039E3AC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    after_0:
    // 0x8039E3B0: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x8039E3B4: lw          $t0, 0x1C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X1C);
    // 0x8039E3B8: lw          $t1, 0x18($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X18);
    // 0x8039E3BC: lbu         $t2, 0x1($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E3C0: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    // 0x8039E3C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8039E3C8: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x8039E3CC: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x8039E3D0: addu        $t5, $a2, $t4
    ctx->r13 = ADD32(ctx->r6, ctx->r12);
    // 0x8039E3D4: sh          $v0, 0xBE($t5)
    MEM_H(0XBE, ctx->r13) = ctx->r2;
    // 0x8039E3D8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8039E3DC: negu        $t0, $t0
    ctx->r8 = SUB32(0, ctx->r8);
    // 0x8039E3E0: negu        $t1, $t1
    ctx->r9 = SUB32(0, ctx->r9);
    // 0x8039E3E4: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x8039E3E8: bne         $t6, $at, L_8039E470
    if (ctx->r14 != ctx->r1) {
        // 0x8039E3EC: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_8039E470;
    }
    // 0x8039E3EC: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x8039E3F0: lbu         $t3, 0x4($a2)
    ctx->r11 = MEM_BU(ctx->r6, 0X4);
    // 0x8039E3F4: lbu         $t7, 0x1($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E3F8: addiu       $t4, $t3, 0x40
    ctx->r12 = ADD32(ctx->r11, 0X40);
    // 0x8039E3FC: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x8039E400: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8039E404: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x8039E408: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8039E40C: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8039E410: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8039E414: lh          $t7, 0x2C78($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C78);
    // 0x8039E418: addu        $v0, $a2, $t9
    ctx->r2 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E41C: lh          $t2, 0xBE($v0)
    ctx->r10 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E420: sra         $t8, $t7, 12
    ctx->r24 = S32(SIGNED(ctx->r15) >> 12);
    // 0x8039E424: addu        $t9, $t2, $t8
    ctx->r25 = ADD32(ctx->r10, ctx->r24);
    // 0x8039E428: sh          $t9, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r25;
    // 0x8039E42C: lbu         $t3, 0x1($a2)
    ctx->r11 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E430: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x8039E434: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x8039E438: addu        $v0, $a2, $t5
    ctx->r2 = ADD32(ctx->r6, ctx->r13);
    // 0x8039E43C: lh          $t6, 0xBE($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E440: addiu       $t7, $t6, 0x28
    ctx->r15 = ADD32(ctx->r14, 0X28);
    // 0x8039E444: sh          $t7, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r15;
    // 0x8039E448: lbu         $t2, 0x1($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E44C: sra         $t8, $t2, 1
    ctx->r24 = S32(SIGNED(ctx->r10) >> 1);
    // 0x8039E450: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8039E454: addu        $v0, $a2, $t9
    ctx->r2 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E458: lh          $v1, 0xBE($v0)
    ctx->r3 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E45C: slti        $at, $v1, 0x168
    ctx->r1 = SIGNED(ctx->r3) < 0X168 ? 1 : 0;
    // 0x8039E460: bne         $at, $zero, L_8039E4F4
    if (ctx->r1 != 0) {
        // 0x8039E464: addiu       $t3, $v1, -0x168
        ctx->r11 = ADD32(ctx->r3, -0X168);
            goto L_8039E4F4;
    }
    // 0x8039E464: addiu       $t3, $v1, -0x168
    ctx->r11 = ADD32(ctx->r3, -0X168);
    // 0x8039E468: b           L_8039E4F4
    // 0x8039E46C: sh          $t3, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r11;
        goto L_8039E4F4;
    // 0x8039E46C: sh          $t3, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r11;
L_8039E470:
    // 0x8039E470: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8039E474: bnel        $v1, $at, L_8039E4F8
    if (ctx->r3 != ctx->r1) {
        // 0x8039E478: lbu         $t9, 0x1($a2)
        ctx->r25 = MEM_BU(ctx->r6, 0X1);
            goto L_8039E4F8;
    }
    goto skip_0;
    // 0x8039E478: lbu         $t9, 0x1($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X1);
    skip_0:
    // 0x8039E47C: lbu         $t2, 0x4($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X4);
    // 0x8039E480: lbu         $t4, 0x1($a2)
    ctx->r12 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E484: addiu       $t8, $t2, 0x40
    ctx->r24 = ADD32(ctx->r10, 0X40);
    // 0x8039E488: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8039E48C: sra         $t5, $t4, 1
    ctx->r13 = S32(SIGNED(ctx->r12) >> 1);
    // 0x8039E490: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x8039E494: sll         $t3, $t9, 1
    ctx->r11 = S32(ctx->r25 << 1);
    // 0x8039E498: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x8039E49C: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8039E4A0: lh          $t4, 0x2C78($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C78);
    // 0x8039E4A4: addu        $v0, $a2, $t6
    ctx->r2 = ADD32(ctx->r6, ctx->r14);
    // 0x8039E4A8: lh          $t7, 0xBE($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E4AC: sra         $t5, $t4, 12
    ctx->r13 = S32(SIGNED(ctx->r12) >> 12);
    // 0x8039E4B0: subu        $t6, $t7, $t5
    ctx->r14 = SUB32(ctx->r15, ctx->r13);
    // 0x8039E4B4: sh          $t6, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r14;
    // 0x8039E4B8: lbu         $t2, 0x1($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E4BC: sra         $t8, $t2, 1
    ctx->r24 = S32(SIGNED(ctx->r10) >> 1);
    // 0x8039E4C0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8039E4C4: addu        $v0, $a2, $t9
    ctx->r2 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E4C8: lh          $t3, 0xBE($v0)
    ctx->r11 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E4CC: addiu       $t4, $t3, -0x28
    ctx->r12 = ADD32(ctx->r11, -0X28);
    // 0x8039E4D0: sh          $t4, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r12;
    // 0x8039E4D4: lbu         $t7, 0x1($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E4D8: sra         $t5, $t7, 1
    ctx->r13 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8039E4DC: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8039E4E0: addu        $v0, $a2, $t6
    ctx->r2 = ADD32(ctx->r6, ctx->r14);
    // 0x8039E4E4: lh          $v1, 0xBE($v0)
    ctx->r3 = MEM_H(ctx->r2, 0XBE);
    // 0x8039E4E8: bgez        $v1, L_8039E4F4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8039E4EC: addiu       $t2, $v1, 0x168
        ctx->r10 = ADD32(ctx->r3, 0X168);
            goto L_8039E4F4;
    }
    // 0x8039E4EC: addiu       $t2, $v1, 0x168
    ctx->r10 = ADD32(ctx->r3, 0X168);
    // 0x8039E4F0: sh          $t2, 0xBE($v0)
    MEM_H(0XBE, ctx->r2) = ctx->r10;
L_8039E4F4:
    // 0x8039E4F4: lbu         $t9, 0x1($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X1);
L_8039E4F8:
    // 0x8039E4F8: addiu       $v1, $zero, 0x6
    ctx->r3 = ADD32(0, 0X6);
    // 0x8039E4FC: lh          $t8, 0x4($a3)
    ctx->r24 = MEM_H(ctx->r7, 0X4);
    // 0x8039E500: sra         $t3, $t9, 1
    ctx->r11 = S32(SIGNED(ctx->r25) >> 1);
    // 0x8039E504: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E508: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x8039E50C: addiu       $a0, $a0, 0x2350
    ctx->r4 = ADD32(ctx->r4, 0X2350);
    // 0x8039E510: mflo        $t4
    ctx->r12 = lo;
    // 0x8039E514: addu        $t7, $a2, $t4
    ctx->r15 = ADD32(ctx->r6, ctx->r12);
    // 0x8039E518: sh          $t8, 0x5E($t7)
    MEM_H(0X5E, ctx->r15) = ctx->r24;
    // 0x8039E51C: lbu         $t6, 0x1($a2)
    ctx->r14 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E520: lh          $t5, 0x8($a3)
    ctx->r13 = MEM_H(ctx->r7, 0X8);
    // 0x8039E524: sra         $t2, $t6, 1
    ctx->r10 = S32(SIGNED(ctx->r14) >> 1);
    // 0x8039E528: multu       $t2, $v1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E52C: mflo        $t9
    ctx->r25 = lo;
    // 0x8039E530: addu        $t3, $a2, $t9
    ctx->r11 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E534: sh          $t5, 0x60($t3)
    MEM_H(0X60, ctx->r11) = ctx->r13;
    // 0x8039E538: lbu         $t8, 0x1($a2)
    ctx->r24 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E53C: lh          $t4, 0xC($a3)
    ctx->r12 = MEM_H(ctx->r7, 0XC);
    // 0x8039E540: sra         $t7, $t8, 1
    ctx->r15 = S32(SIGNED(ctx->r24) >> 1);
    // 0x8039E544: multu       $t7, $v1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E548: mflo        $t6
    ctx->r14 = lo;
    // 0x8039E54C: addu        $t2, $a2, $t6
    ctx->r10 = ADD32(ctx->r6, ctx->r14);
    // 0x8039E550: sh          $t4, 0x62($t2)
    MEM_H(0X62, ctx->r10) = ctx->r12;
    // 0x8039E554: lbu         $v0, 0x1($a2)
    ctx->r2 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E558: multu       $t0, $t0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E55C: sra         $t9, $v0, 1
    ctx->r25 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8039E560: sll         $t5, $t9, 1
    ctx->r13 = S32(ctx->r25 << 1);
    // 0x8039E564: addu        $t3, $a2, $t5
    ctx->r11 = ADD32(ctx->r6, ctx->r13);
    // 0x8039E568: lh          $t8, 0xBE($t3)
    ctx->r24 = MEM_H(ctx->r11, 0XBE);
    // 0x8039E56C: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8039E570: addu        $t5, $a2, $t9
    ctx->r13 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E574: sll         $t7, $t8, 1
    ctx->r15 = S32(ctx->r24 << 1);
    // 0x8039E578: addu        $t6, $a0, $t7
    ctx->r14 = ADD32(ctx->r4, ctx->r15);
    // 0x8039E57C: lh          $t4, 0x2D0($t6)
    ctx->r12 = MEM_H(ctx->r14, 0X2D0);
    // 0x8039E580: negu        $t2, $t4
    ctx->r10 = SUB32(0, ctx->r12);
    // 0x8039E584: sh          $t2, 0xDE($t5)
    MEM_H(0XDE, ctx->r13) = ctx->r10;
    // 0x8039E588: lbu         $v0, 0x1($a2)
    ctx->r2 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E58C: sra         $t3, $v0, 1
    ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8039E590: sll         $t8, $t3, 1
    ctx->r24 = S32(ctx->r11 << 1);
    // 0x8039E594: addu        $t7, $a2, $t8
    ctx->r15 = ADD32(ctx->r6, ctx->r24);
    // 0x8039E598: lh          $t6, 0xBE($t7)
    ctx->r14 = MEM_H(ctx->r15, 0XBE);
    // 0x8039E59C: mflo        $t7
    ctx->r15 = lo;
    // 0x8039E5A0: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x8039E5A4: sll         $t4, $t6, 1
    ctx->r12 = S32(ctx->r14 << 1);
    // 0x8039E5A8: multu       $t1, $t1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8039E5AC: addu        $t9, $a0, $t4
    ctx->r25 = ADD32(ctx->r4, ctx->r12);
    // 0x8039E5B0: lh          $t2, 0x384($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X384);
    // 0x8039E5B4: addu        $t8, $a2, $t3
    ctx->r24 = ADD32(ctx->r6, ctx->r11);
    // 0x8039E5B8: negu        $t5, $t2
    ctx->r13 = SUB32(0, ctx->r10);
    // 0x8039E5BC: sh          $t5, 0xE0($t8)
    MEM_H(0XE0, ctx->r24) = ctx->r13;
    // 0x8039E5C0: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x8039E5C4: mflo        $t6
    ctx->r14 = lo;
    // 0x8039E5C8: addu        $t4, $t7, $t6
    ctx->r12 = ADD32(ctx->r15, ctx->r14);
    // 0x8039E5CC: addiu       $t9, $t4, 0x1
    ctx->r25 = ADD32(ctx->r12, 0X1);
    // 0x8039E5D0: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8039E5D4: jal         0x80137E10
    // 0x8039E5D8: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    sqrtf_recomp(rdram, ctx);
        goto after_1;
    // 0x8039E5D8: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    after_1:
    // 0x8039E5DC: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8039E5E0: addiu       $at, $zero, 0x3C00
    ctx->r1 = ADD32(0, 0X3C00);
    // 0x8039E5E4: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x8039E5E8: addiu       $v1, $zero, 0x7FF
    ctx->r3 = ADD32(0, 0X7FF);
    // 0x8039E5EC: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x8039E5F0: nop

    // 0x8039E5F4: sll         $t3, $v0, 7
    ctx->r11 = S32(ctx->r2 << 7);
    // 0x8039E5F8: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x8039E5FC: mflo        $v0
    ctx->r2 = lo;
    // 0x8039E600: slti        $at, $v0, 0x81
    ctx->r1 = SIGNED(ctx->r2) < 0X81 ? 1 : 0;
    // 0x8039E604: bnel        $at, $zero, L_8039E628
    if (ctx->r1 != 0) {
        // 0x8039E608: lbu         $t9, 0x1($a2)
        ctx->r25 = MEM_BU(ctx->r6, 0X1);
            goto L_8039E628;
    }
    goto skip_1;
    // 0x8039E608: lbu         $t9, 0x1($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X1);
    skip_1:
    // 0x8039E60C: lbu         $t7, 0x1($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E610: addiu       $t8, $zero, 0x80
    ctx->r24 = ADD32(0, 0X80);
    // 0x8039E614: sra         $t6, $t7, 1
    ctx->r14 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8039E618: addu        $t4, $a2, $t6
    ctx->r12 = ADD32(ctx->r6, ctx->r14);
    // 0x8039E61C: b           L_8039E634
    // 0x8039E620: sb          $t8, 0x2E($t4)
    MEM_B(0X2E, ctx->r12) = ctx->r24;
        goto L_8039E634;
    // 0x8039E620: sb          $t8, 0x2E($t4)
    MEM_B(0X2E, ctx->r12) = ctx->r24;
    // 0x8039E624: lbu         $t9, 0x1($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X1);
L_8039E628:
    // 0x8039E628: sra         $t2, $t9, 1
    ctx->r10 = S32(SIGNED(ctx->r25) >> 1);
    // 0x8039E62C: addu        $t3, $a2, $t2
    ctx->r11 = ADD32(ctx->r6, ctx->r10);
    // 0x8039E630: sb          $v0, 0x2E($t3)
    MEM_B(0X2E, ctx->r11) = ctx->r2;
L_8039E634:
    // 0x8039E634: lbu         $v0, 0x1($a2)
    ctx->r2 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E638: sra         $t5, $v0, 1
    ctx->r13 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8039E63C: andi        $t7, $t5, 0x1
    ctx->r15 = ctx->r13 & 0X1;
    // 0x8039E640: beq         $t7, $zero, L_8039E688
    if (ctx->r15 == 0) {
        // 0x8039E644: sll         $t9, $v0, 4
        ctx->r25 = S32(ctx->r2 << 4);
            goto L_8039E688;
    }
    // 0x8039E644: sll         $t9, $v0, 4
    ctx->r25 = S32(ctx->r2 << 4);
    // 0x8039E648: sll         $t6, $v0, 4
    ctx->r14 = S32(ctx->r2 << 4);
    // 0x8039E64C: addu        $t8, $a2, $t6
    ctx->r24 = ADD32(ctx->r6, ctx->r14);
    // 0x8039E650: sh          $v1, 0x128($t8)
    MEM_H(0X128, ctx->r24) = ctx->r3;
    // 0x8039E654: lbu         $t4, 0x1($a2)
    ctx->r12 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E658: sll         $t9, $t4, 4
    ctx->r25 = S32(ctx->r12 << 4);
    // 0x8039E65C: addu        $t2, $a2, $t9
    ctx->r10 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E660: sh          $zero, 0x12A($t2)
    MEM_H(0X12A, ctx->r10) = 0;
    // 0x8039E664: lbu         $t3, 0x1($a2)
    ctx->r11 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E668: sll         $t5, $t3, 4
    ctx->r13 = S32(ctx->r11 << 4);
    // 0x8039E66C: addu        $t7, $a2, $t5
    ctx->r15 = ADD32(ctx->r6, ctx->r13);
    // 0x8039E670: sh          $v1, 0x138($t7)
    MEM_H(0X138, ctx->r15) = ctx->r3;
    // 0x8039E674: lbu         $t6, 0x1($a2)
    ctx->r14 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E678: sll         $t8, $t6, 4
    ctx->r24 = S32(ctx->r14 << 4);
    // 0x8039E67C: addu        $t4, $a2, $t8
    ctx->r12 = ADD32(ctx->r6, ctx->r24);
    // 0x8039E680: b           L_8039E6C4
    // 0x8039E684: sh          $v1, 0x13A($t4)
    MEM_H(0X13A, ctx->r12) = ctx->r3;
        goto L_8039E6C4;
    // 0x8039E684: sh          $v1, 0x13A($t4)
    MEM_H(0X13A, ctx->r12) = ctx->r3;
L_8039E688:
    // 0x8039E688: addu        $t2, $a2, $t9
    ctx->r10 = ADD32(ctx->r6, ctx->r25);
    // 0x8039E68C: sh          $zero, 0x128($t2)
    MEM_H(0X128, ctx->r10) = 0;
    // 0x8039E690: lbu         $t3, 0x1($a2)
    ctx->r11 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E694: addiu       $v1, $zero, 0x7FF
    ctx->r3 = ADD32(0, 0X7FF);
    // 0x8039E698: sll         $t5, $t3, 4
    ctx->r13 = S32(ctx->r11 << 4);
    // 0x8039E69C: addu        $t7, $a2, $t5
    ctx->r15 = ADD32(ctx->r6, ctx->r13);
    // 0x8039E6A0: sh          $zero, 0x12A($t7)
    MEM_H(0X12A, ctx->r15) = 0;
    // 0x8039E6A4: lbu         $t6, 0x1($a2)
    ctx->r14 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E6A8: sll         $t8, $t6, 4
    ctx->r24 = S32(ctx->r14 << 4);
    // 0x8039E6AC: addu        $t4, $a2, $t8
    ctx->r12 = ADD32(ctx->r6, ctx->r24);
    // 0x8039E6B0: sh          $zero, 0x138($t4)
    MEM_H(0X138, ctx->r12) = 0;
    // 0x8039E6B4: lbu         $t9, 0x1($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X1);
    // 0x8039E6B8: sll         $t2, $t9, 4
    ctx->r10 = S32(ctx->r25 << 4);
    // 0x8039E6BC: addu        $t3, $a2, $t2
    ctx->r11 = ADD32(ctx->r6, ctx->r10);
    // 0x8039E6C0: sh          $v1, 0x13A($t3)
    MEM_H(0X13A, ctx->r11) = ctx->r3;
L_8039E6C4:
    // 0x8039E6C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8039E6C8: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8039E6CC: jr          $ra
    // 0x8039E6D0: nop

    return;
    // 0x8039E6D0: nop

;}
