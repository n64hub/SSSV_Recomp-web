#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_802F5C60_707310(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F5C60: addiu       $sp, $sp, -0x78
    ctx->r29 = ADD32(ctx->r29, -0X78);
    // 0x802F5C64: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802F5C68: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x802F5C6C: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x802F5C70: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x802F5C74: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x802F5C78: lw          $t6, 0x16C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X16C);
    // 0x802F5C7C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802F5C80: or          $s3, $a0, $zero
    ctx->r19 = ctx->r4 | 0;
    // 0x802F5C84: lbu         $v0, 0x15($t6)
    ctx->r2 = MEM_BU(ctx->r14, 0X15);
    // 0x802F5C88: beq         $v1, $v0, L_802F5CB4
    if (ctx->r3 == ctx->r2) {
        // 0x802F5C8C: nop
    
            goto L_802F5CB4;
    }
    // 0x802F5C8C: nop

    // 0x802F5C90: lw          $t7, 0x74($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X74);
    // 0x802F5C94: lw          $t8, 0x78($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X78);
    // 0x802F5C98: lw          $t9, 0x7C($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X7C);
    // 0x802F5C9C: lw          $t0, 0x80($a0)
    ctx->r8 = MEM_W(ctx->r4, 0X80);
    // 0x802F5CA0: sw          $t7, 0xC4($a0)
    MEM_W(0XC4, ctx->r4) = ctx->r15;
    // 0x802F5CA4: sw          $t8, 0xC8($a0)
    MEM_W(0XC8, ctx->r4) = ctx->r24;
    // 0x802F5CA8: sw          $t9, 0xCC($a0)
    MEM_W(0XCC, ctx->r4) = ctx->r25;
    // 0x802F5CAC: b           L_802F5F28
    // 0x802F5CB0: sw          $t0, 0xD0($a0)
    MEM_W(0XD0, ctx->r4) = ctx->r8;
        goto L_802F5F28;
    // 0x802F5CB0: sw          $t0, 0xD0($a0)
    MEM_W(0XD0, ctx->r4) = ctx->r8;
L_802F5CB4:
    // 0x802F5CB4: bnel        $v1, $v0, L_802F5F2C
    if (ctx->r3 != ctx->r2) {
        // 0x802F5CB8: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802F5F2C;
    }
    goto skip_0;
    // 0x802F5CB8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x802F5CBC: lh          $t1, 0x2E($s3)
    ctx->r9 = MEM_H(ctx->r19, 0X2E);
    // 0x802F5CC0: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x802F5CC4: addiu       $a1, $a1, 0x2350
    ctx->r5 = ADD32(ctx->r5, 0X2350);
    // 0x802F5CC8: sll         $t2, $t1, 1
    ctx->r10 = S32(ctx->r9 << 1);
    // 0x802F5CCC: addu        $v0, $a1, $t2
    ctx->r2 = ADD32(ctx->r5, ctx->r10);
    // 0x802F5CD0: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
    // 0x802F5CD4: lh          $t6, 0x384($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X384);
    // 0x802F5CD8: addiu       $s1, $s3, 0x74
    ctx->r17 = ADD32(ctx->r19, 0X74);
    // 0x802F5CDC: sra         $t4, $t3, 31
    ctx->r12 = S32(SIGNED(ctx->r11) >> 31);
    // 0x802F5CE0: sra         $t8, $t6, 31
    ctx->r24 = S32(SIGNED(ctx->r14) >> 31);
    // 0x802F5CE4: sw          $t4, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r12;
    // 0x802F5CE8: sw          $t8, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r24;
    // 0x802F5CEC: sw          $t3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r11;
    // 0x802F5CF0: sw          $t6, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r14;
    // 0x802F5CF4: lh          $t7, 0x2C($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X2C);
    // 0x802F5CF8: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x802F5CFC: sll         $t0, $t7, 1
    ctx->r8 = S32(ctx->r15 << 1);
    // 0x802F5D00: addu        $v1, $a1, $t0
    ctx->r3 = ADD32(ctx->r5, ctx->r8);
    // 0x802F5D04: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    // 0x802F5D08: lh          $t4, 0x384($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X384);
    // 0x802F5D0C: sra         $t2, $t1, 31
    ctx->r10 = S32(SIGNED(ctx->r9) >> 31);
    // 0x802F5D10: sra         $t6, $t4, 31
    ctx->r14 = S32(SIGNED(ctx->r12) >> 31);
    // 0x802F5D14: sw          $t2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r10;
    // 0x802F5D18: sw          $t6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r14;
    // 0x802F5D1C: sw          $t1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r9;
    // 0x802F5D20: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    // 0x802F5D24: lw          $t5, 0xC($s1)
    ctx->r13 = MEM_W(ctx->r17, 0XC);
    // 0x802F5D28: beql        $t5, $zero, L_802F5F04
    if (ctx->r13 == 0) {
        // 0x802F5D2C: slti        $at, $s2, 0x5
        ctx->r1 = SIGNED(ctx->r18) < 0X5 ? 1 : 0;
            goto L_802F5F04;
    }
    goto skip_1;
    // 0x802F5D2C: slti        $at, $s2, 0x5
    ctx->r1 = SIGNED(ctx->r18) < 0X5 ? 1 : 0;
    skip_1:
    // 0x802F5D30: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
L_802F5D34:
    // 0x802F5D34: lw          $a2, 0x48($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X48);
    // 0x802F5D38: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    // 0x802F5D3C: sra         $t0, $t8, 31
    ctx->r8 = S32(SIGNED(ctx->r24) >> 31);
    // 0x802F5D40: sw          $t0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r8;
    // 0x802F5D44: sw          $t8, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r24;
    // 0x802F5D48: lw          $a1, 0x4($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X4);
    // 0x802F5D4C: jal         0x80137CB8
    // 0x802F5D50: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_0;
    // 0x802F5D50: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_0:
    // 0x802F5D54: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x802F5D58: sw          $v1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r3;
    // 0x802F5D5C: lw          $a1, 0x8($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X8);
    // 0x802F5D60: lw          $a2, 0x58($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X58);
    // 0x802F5D64: lw          $a3, 0x5C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X5C);
    // 0x802F5D68: jal         0x80137CB8
    // 0x802F5D6C: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_1;
    // 0x802F5D6C: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_1:
    // 0x802F5D70: lw          $t4, 0x28($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X28);
    // 0x802F5D74: lw          $t5, 0x2C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X2C);
    // 0x802F5D78: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F5D7C: subu        $a0, $t4, $v0
    ctx->r4 = SUB32(ctx->r12, ctx->r2);
    // 0x802F5D80: sltu        $at, $t5, $v1
    ctx->r1 = ctx->r13 < ctx->r3 ? 1 : 0;
    // 0x802F5D84: subu        $a0, $a0, $at
    ctx->r4 = SUB32(ctx->r4, ctx->r1);
    // 0x802F5D88: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F5D8C: jal         0x80137DE4
    // 0x802F5D90: subu        $a1, $t5, $v1
    ctx->r5 = SUB32(ctx->r13, ctx->r3);
    __ll_rshift_recomp(rdram, ctx);
        goto after_2;
    // 0x802F5D90: subu        $a1, $t5, $v1
    ctx->r5 = SUB32(ctx->r13, ctx->r3);
    after_2:
    // 0x802F5D94: sw          $v0, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r2;
    // 0x802F5D98: sw          $v1, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r3;
    // 0x802F5D9C: lw          $a1, 0x4($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X4);
    // 0x802F5DA0: lw          $a2, 0x58($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X58);
    // 0x802F5DA4: lw          $a3, 0x5C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X5C);
    // 0x802F5DA8: jal         0x80137CB8
    // 0x802F5DAC: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_3;
    // 0x802F5DAC: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_3:
    // 0x802F5DB0: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x802F5DB4: sw          $v1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r3;
    // 0x802F5DB8: lw          $a1, 0x8($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X8);
    // 0x802F5DBC: lw          $a2, 0x48($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X48);
    // 0x802F5DC0: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    // 0x802F5DC4: jal         0x80137CB8
    // 0x802F5DC8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_4;
    // 0x802F5DC8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_4:
    // 0x802F5DCC: lw          $t9, 0x2C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X2C);
    // 0x802F5DD0: lw          $t8, 0x28($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X28);
    // 0x802F5DD4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F5DD8: addu        $a1, $v1, $t9
    ctx->r5 = ADD32(ctx->r3, ctx->r25);
    // 0x802F5DDC: sltu        $at, $a1, $t9
    ctx->r1 = ctx->r5 < ctx->r25 ? 1 : 0;
    // 0x802F5DE0: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F5DE4: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F5DE8: jal         0x80137DE4
    // 0x802F5DEC: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    __ll_rshift_recomp(rdram, ctx);
        goto after_5;
    // 0x802F5DEC: addu        $a0, $a0, $t8
    ctx->r4 = ADD32(ctx->r4, ctx->r24);
    after_5:
    // 0x802F5DF0: sw          $v0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r2;
    // 0x802F5DF4: sw          $v1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r3;
    // 0x802F5DF8: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x802F5DFC: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x802F5E00: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x802F5E04: jal         0x80137CB8
    // 0x802F5E08: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    __ll_mul_recomp(rdram, ctx);
        goto after_6;
    // 0x802F5E08: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    after_6:
    // 0x802F5E0C: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x802F5E10: sw          $v1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r3;
    // 0x802F5E14: lw          $a0, 0x68($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X68);
    // 0x802F5E18: lw          $a1, 0x6C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X6C);
    // 0x802F5E1C: lw          $a2, 0x50($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X50);
    // 0x802F5E20: jal         0x80137CB8
    // 0x802F5E24: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    __ll_mul_recomp(rdram, ctx);
        goto after_7;
    // 0x802F5E24: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    after_7:
    // 0x802F5E28: lw          $t1, 0x2C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X2C);
    // 0x802F5E2C: lw          $t0, 0x28($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X28);
    // 0x802F5E30: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F5E34: addu        $a1, $v1, $t1
    ctx->r5 = ADD32(ctx->r3, ctx->r9);
    // 0x802F5E38: sltu        $at, $a1, $t1
    ctx->r1 = ctx->r5 < ctx->r9 ? 1 : 0;
    // 0x802F5E3C: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F5E40: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F5E44: jal         0x80137DE4
    // 0x802F5E48: addu        $a0, $a0, $t0
    ctx->r4 = ADD32(ctx->r4, ctx->r8);
    __ll_rshift_recomp(rdram, ctx);
        goto after_8;
    // 0x802F5E48: addu        $a0, $a0, $t0
    ctx->r4 = ADD32(ctx->r4, ctx->r8);
    after_8:
    // 0x802F5E4C: sll         $t7, $s2, 4
    ctx->r15 = S32(ctx->r18 << 4);
    // 0x802F5E50: addu        $s0, $s3, $t7
    ctx->r16 = ADD32(ctx->r19, ctx->r15);
    // 0x802F5E54: sw          $v1, 0xC4($s0)
    MEM_W(0XC4, ctx->r16) = ctx->r3;
    // 0x802F5E58: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x802F5E5C: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x802F5E60: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    // 0x802F5E64: sltiu       $at, $a1, 0x1
    ctx->r1 = ctx->r5 < 0X1 ? 1 : 0;
    // 0x802F5E68: nor         $a0, $a0, $zero
    ctx->r4 = ~(ctx->r4 | 0);
    // 0x802F5E6C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x802F5E70: lw          $a2, 0x50($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X50);
    // 0x802F5E74: jal         0x80137CB8
    // 0x802F5E78: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    __ll_mul_recomp(rdram, ctx);
        goto after_9;
    // 0x802F5E78: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    after_9:
    // 0x802F5E7C: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x802F5E80: sw          $v1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r3;
    // 0x802F5E84: lw          $a0, 0x68($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X68);
    // 0x802F5E88: lw          $a1, 0x6C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X6C);
    // 0x802F5E8C: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x802F5E90: jal         0x80137CB8
    // 0x802F5E94: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    __ll_mul_recomp(rdram, ctx);
        goto after_10;
    // 0x802F5E94: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    after_10:
    // 0x802F5E98: lw          $t5, 0x2C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X2C);
    // 0x802F5E9C: lw          $t4, 0x28($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X28);
    // 0x802F5EA0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F5EA4: addu        $a1, $v1, $t5
    ctx->r5 = ADD32(ctx->r3, ctx->r13);
    // 0x802F5EA8: sltu        $at, $a1, $t5
    ctx->r1 = ctx->r5 < ctx->r13 ? 1 : 0;
    // 0x802F5EAC: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F5EB0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F5EB4: jal         0x80137DE4
    // 0x802F5EB8: addu        $a0, $a0, $t4
    ctx->r4 = ADD32(ctx->r4, ctx->r12);
    __ll_rshift_recomp(rdram, ctx);
        goto after_11;
    // 0x802F5EB8: addu        $a0, $a0, $t4
    ctx->r4 = ADD32(ctx->r4, ctx->r12);
    after_11:
    // 0x802F5EBC: sw          $v1, 0xC8($s0)
    MEM_W(0XC8, ctx->r16) = ctx->r3;
    // 0x802F5EC0: lhu         $t6, 0x42($s3)
    ctx->r14 = MEM_HU(ctx->r19, 0X42);
    // 0x802F5EC4: lw          $t3, 0x64($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X64);
    // 0x802F5EC8: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x802F5ECC: sll         $t8, $t6, 15
    ctx->r24 = S32(ctx->r14 << 15);
    // 0x802F5ED0: addu        $t5, $t8, $t3
    ctx->r13 = ADD32(ctx->r24, ctx->r11);
    // 0x802F5ED4: sw          $t5, 0xCC($s0)
    MEM_W(0XCC, ctx->r16) = ctx->r13;
    // 0x802F5ED8: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x802F5EDC: lw          $t7, 0xC($s1)
    ctx->r15 = MEM_W(ctx->r17, 0XC);
    // 0x802F5EE0: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F5EE4: slti        $at, $s2, 0x5
    ctx->r1 = SIGNED(ctx->r18) < 0X5 ? 1 : 0;
    // 0x802F5EE8: addiu       $s1, $s1, 0x10
    ctx->r17 = ADD32(ctx->r17, 0X10);
    // 0x802F5EEC: beq         $at, $zero, L_802F5F00
    if (ctx->r1 == 0) {
        // 0x802F5EF0: sw          $t7, 0xD0($s0)
        MEM_W(0XD0, ctx->r16) = ctx->r15;
            goto L_802F5F00;
    }
    // 0x802F5EF0: sw          $t7, 0xD0($s0)
    MEM_W(0XD0, ctx->r16) = ctx->r15;
    // 0x802F5EF4: lw          $t0, 0xC($s1)
    ctx->r8 = MEM_W(ctx->r17, 0XC);
    // 0x802F5EF8: bnel        $t0, $zero, L_802F5D34
    if (ctx->r8 != 0) {
        // 0x802F5EFC: lw          $t8, 0x0($s1)
        ctx->r24 = MEM_W(ctx->r17, 0X0);
            goto L_802F5D34;
    }
    goto skip_2;
    // 0x802F5EFC: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    skip_2:
L_802F5F00:
    // 0x802F5F00: slti        $at, $s2, 0x5
    ctx->r1 = SIGNED(ctx->r18) < 0X5 ? 1 : 0;
L_802F5F04:
    // 0x802F5F04: beq         $at, $zero, L_802F5F28
    if (ctx->r1 == 0) {
        // 0x802F5F08: sll         $t1, $s2, 4
        ctx->r9 = S32(ctx->r18 << 4);
            goto L_802F5F28;
    }
L_802F5F08:
    // 0x802F5F08: sll         $t1, $s2, 4
    ctx->r9 = S32(ctx->r18 << 4);
    // 0x802F5F0C: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x802F5F10: sll         $t3, $s2, 16
    ctx->r11 = S32(ctx->r18 << 16);
    // 0x802F5F14: sra         $s2, $t3, 16
    ctx->r18 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F5F18: slti        $at, $s2, 0x5
    ctx->r1 = SIGNED(ctx->r18) < 0X5 ? 1 : 0;
    // 0x802F5F1C: addu        $t2, $s3, $t1
    ctx->r10 = ADD32(ctx->r19, ctx->r9);
    // 0x802F5F20: bne         $at, $zero, L_802F5F08
    if (ctx->r1 != 0) {
        // 0x802F5F24: sw          $zero, 0xD0($t2)
        MEM_W(0XD0, ctx->r10) = 0;
            goto L_802F5F08;
    }
    // 0x802F5F24: sw          $zero, 0xD0($t2)
    MEM_W(0XD0, ctx->r10) = 0;
L_802F5F28:
    // 0x802F5F28: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802F5F2C:
    // 0x802F5F2C: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x802F5F30: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x802F5F34: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x802F5F38: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x802F5F3C: jr          $ra
    // 0x802F5F40: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
    return;
    // 0x802F5F40: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
;}
RECOMP_FUNC void func_802F5F44_7075F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F5F44: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802F5F48: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802F5F4C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802F5F50: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802F5F54: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F5F58: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F5F5C: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802F5F60: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802F5F64: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802F5F68: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F5F6C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F5F70: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x802F5F74: addiu       $t5, $t5, 0x2350
    ctx->r13 = ADD32(ctx->r13, 0X2350);
    // 0x802F5F78: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x802F5F7C: addu        $v1, $t5, $t6
    ctx->r3 = ADD32(ctx->r13, ctx->r14);
    // 0x802F5F80: lh          $t0, 0x384($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X384);
    // 0x802F5F84: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x802F5F88: lh          $t7, 0x12($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X12);
    // 0x802F5F8C: multu       $a1, $t0
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F5F90: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802F5F94: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802F5F98: addu        $t2, $t5, $t8
    ctx->r10 = ADD32(ctx->r13, ctx->r24);
    // 0x802F5F9C: lh          $t3, 0x384($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X384);
    // 0x802F5FA0: lh          $t1, 0x2D0($t2)
    ctx->r9 = MEM_H(ctx->r10, 0X2D0);
    // 0x802F5FA4: mflo        $t9
    ctx->r25 = lo;
    // 0x802F5FA8: nop

    // 0x802F5FAC: nop

    // 0x802F5FB0: multu       $a2, $v0
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F5FB4: mflo        $t6
    ctx->r14 = lo;
    // 0x802F5FB8: subu        $t4, $t9, $t6
    ctx->r12 = SUB32(ctx->r25, ctx->r14);
    // 0x802F5FBC: sra         $t7, $t4, 8
    ctx->r15 = S32(SIGNED(ctx->r12) >> 8);
    // 0x802F5FC0: multu       $a0, $t3
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F5FC4: or          $t4, $t7, $zero
    ctx->r12 = ctx->r15 | 0;
    // 0x802F5FC8: mflo        $t8
    ctx->r24 = lo;
    // 0x802F5FCC: nop

    // 0x802F5FD0: nop

    // 0x802F5FD4: multu       $t7, $t1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F5FD8: mflo        $t9
    ctx->r25 = lo;
    // 0x802F5FDC: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x802F5FE0: negu        $t9, $a0
    ctx->r25 = SUB32(0, ctx->r4);
    // 0x802F5FE4: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F5FE8: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x802F5FEC: lw          $t8, 0x14($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X14);
    // 0x802F5FF0: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    // 0x802F5FF4: mflo        $t6
    ctx->r14 = lo;
    // 0x802F5FF8: nop

    // 0x802F5FFC: nop

    // 0x802F6000: multu       $t4, $t3
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6004: mflo        $t7
    ctx->r15 = lo;
    // 0x802F6008: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802F600C: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x802F6010: multu       $a1, $v0
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6014: sh          $t6, 0x2($t8)
    MEM_H(0X2, ctx->r24) = ctx->r14;
    // 0x802F6018: mflo        $t7
    ctx->r15 = lo;
    // 0x802F601C: nop

    // 0x802F6020: nop

    // 0x802F6024: multu       $a2, $t0
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6028: mflo        $t9
    ctx->r25 = lo;
    // 0x802F602C: addu        $t6, $t7, $t9
    ctx->r14 = ADD32(ctx->r15, ctx->r25);
    // 0x802F6030: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x802F6034: jr          $ra
    // 0x802F6038: sh          $t7, 0x4($t8)
    MEM_H(0X4, ctx->r24) = ctx->r15;
    return;
    // 0x802F6038: sh          $t7, 0x4($t8)
    MEM_H(0X4, ctx->r24) = ctx->r15;
;}
RECOMP_FUNC void func_802F603C_7076EC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F603C: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x802F6040: sw          $a3, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r7;
    // 0x802F6044: lh          $t6, 0x8E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X8E);
    // 0x802F6048: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x802F604C: addiu       $t0, $t0, 0x2350
    ctx->r8 = ADD32(ctx->r8, 0X2350);
    // 0x802F6050: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802F6054: lh          $t1, 0x92($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X92);
    // 0x802F6058: addu        $v0, $t0, $t7
    ctx->r2 = ADD32(ctx->r8, ctx->r15);
    // 0x802F605C: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
    // 0x802F6060: sll         $t6, $t1, 1
    ctx->r14 = S32(ctx->r9 << 1);
    // 0x802F6064: lh          $t9, 0x384($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X384);
    // 0x802F6068: addu        $v1, $t0, $t6
    ctx->r3 = ADD32(ctx->r8, ctx->r14);
    // 0x802F606C: sra         $t2, $t3, 31
    ctx->r10 = S32(SIGNED(ctx->r11) >> 31);
    // 0x802F6070: sw          $t2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r10;
    // 0x802F6074: lh          $t7, 0x2D0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X2D0);
    // 0x802F6078: lh          $t2, 0x384($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X384);
    // 0x802F607C: sw          $a0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r4;
    // 0x802F6080: sw          $a1, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r5;
    // 0x802F6084: sra         $t4, $t9, 31
    ctx->r12 = S32(SIGNED(ctx->r25) >> 31);
    // 0x802F6088: lh          $a1, 0x82($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X82);
    // 0x802F608C: lhu         $a3, 0x96($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X96);
    // 0x802F6090: sw          $a2, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r6;
    // 0x802F6094: sw          $t4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r12;
    // 0x802F6098: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F609C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F60A0: sra         $t8, $t7, 31
    ctx->r24 = S32(SIGNED(ctx->r15) >> 31);
    // 0x802F60A4: sra         $t4, $t2, 31
    ctx->r12 = S32(SIGNED(ctx->r10) >> 31);
    // 0x802F60A8: sw          $t8, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r24;
    // 0x802F60AC: sw          $t4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r12;
    // 0x802F60B0: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    // 0x802F60B4: sw          $t3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r11;
    // 0x802F60B8: sw          $t9, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r25;
    // 0x802F60BC: sw          $t7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r15;
    // 0x802F60C0: sw          $t2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r10;
    // 0x802F60C4: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x802F60C8: jal         0x80137CB8
    // 0x802F60CC: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    __ll_mul_recomp(rdram, ctx);
        goto after_0;
    // 0x802F60CC: sw          $a3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r7;
    after_0:
    // 0x802F60D0: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802F60D4: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802F60D8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F60DC: jal         0x80137DE4
    // 0x802F60E0: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    __ll_rshift_recomp(rdram, ctx);
        goto after_1;
    // 0x802F60E0: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    after_1:
    // 0x802F60E4: lh          $a1, 0x86($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X86);
    // 0x802F60E8: sw          $v0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r2;
    // 0x802F60EC: sw          $v1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r3;
    // 0x802F60F0: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x802F60F4: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x802F60F8: jal         0x80137CB8
    // 0x802F60FC: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_2;
    // 0x802F60FC: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_2:
    // 0x802F6100: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802F6104: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802F6108: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F610C: jal         0x80137DE4
    // 0x802F6110: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    __ll_rshift_recomp(rdram, ctx);
        goto after_3;
    // 0x802F6110: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    after_3:
    // 0x802F6114: lh          $a1, 0x8A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X8A);
    // 0x802F6118: sw          $v0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r2;
    // 0x802F611C: sw          $v1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r3;
    // 0x802F6120: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x802F6124: lw          $a3, 0x1C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X1C);
    // 0x802F6128: jal         0x80137CB8
    // 0x802F612C: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_4;
    // 0x802F612C: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_4:
    // 0x802F6130: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802F6134: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802F6138: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F613C: jal         0x80137DE4
    // 0x802F6140: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    __ll_rshift_recomp(rdram, ctx);
        goto after_5;
    // 0x802F6140: addiu       $a3, $zero, 0xB
    ctx->r7 = ADD32(0, 0XB);
    after_5:
    // 0x802F6144: sw          $v0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r2;
    // 0x802F6148: sw          $v1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r3;
    // 0x802F614C: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x802F6150: lw          $a1, 0x5C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X5C);
    // 0x802F6154: lw          $a2, 0x48($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X48);
    // 0x802F6158: jal         0x80137CB8
    // 0x802F615C: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    __ll_mul_recomp(rdram, ctx);
        goto after_6;
    // 0x802F615C: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    after_6:
    // 0x802F6160: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802F6164: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802F6168: lw          $a0, 0x50($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X50);
    // 0x802F616C: lw          $a1, 0x54($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X54);
    // 0x802F6170: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x802F6174: jal         0x80137CB8
    // 0x802F6178: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    __ll_mul_recomp(rdram, ctx);
        goto after_7;
    // 0x802F6178: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    after_7:
    // 0x802F617C: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
    // 0x802F6180: lw          $t3, 0x24($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X24);
    // 0x802F6184: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F6188: subu        $a0, $t2, $v0
    ctx->r4 = SUB32(ctx->r10, ctx->r2);
    // 0x802F618C: sltu        $at, $t3, $v1
    ctx->r1 = ctx->r11 < ctx->r3 ? 1 : 0;
    // 0x802F6190: subu        $a0, $a0, $at
    ctx->r4 = SUB32(ctx->r4, ctx->r1);
    // 0x802F6194: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F6198: jal         0x80137DE4
    // 0x802F619C: subu        $a1, $t3, $v1
    ctx->r5 = SUB32(ctx->r11, ctx->r3);
    __ll_rshift_recomp(rdram, ctx);
        goto after_8;
    // 0x802F619C: subu        $a1, $t3, $v1
    ctx->r5 = SUB32(ctx->r11, ctx->r3);
    after_8:
    // 0x802F61A0: sw          $v0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r2;
    // 0x802F61A4: sw          $v1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r3;
    // 0x802F61A8: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x802F61AC: lw          $a1, 0x5C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X5C);
    // 0x802F61B0: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x802F61B4: jal         0x80137CB8
    // 0x802F61B8: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    __ll_mul_recomp(rdram, ctx);
        goto after_9;
    // 0x802F61B8: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    after_9:
    // 0x802F61BC: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802F61C0: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802F61C4: lw          $a0, 0x50($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X50);
    // 0x802F61C8: lw          $a1, 0x54($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X54);
    // 0x802F61CC: lw          $a2, 0x48($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X48);
    // 0x802F61D0: jal         0x80137CB8
    // 0x802F61D4: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    __ll_mul_recomp(rdram, ctx);
        goto after_10;
    // 0x802F61D4: lw          $a3, 0x4C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X4C);
    after_10:
    // 0x802F61D8: lw          $t5, 0x24($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X24);
    // 0x802F61DC: lw          $t4, 0x20($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X20);
    // 0x802F61E0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F61E4: addu        $a1, $v1, $t5
    ctx->r5 = ADD32(ctx->r3, ctx->r13);
    // 0x802F61E8: sltu        $at, $a1, $t5
    ctx->r1 = ctx->r5 < ctx->r13 ? 1 : 0;
    // 0x802F61EC: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F61F0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F61F4: jal         0x80137DE4
    // 0x802F61F8: addu        $a0, $a0, $t4
    ctx->r4 = ADD32(ctx->r4, ctx->r12);
    __ll_rshift_recomp(rdram, ctx);
        goto after_11;
    // 0x802F61F8: addu        $a0, $a0, $t4
    ctx->r4 = ADD32(ctx->r4, ctx->r12);
    after_11:
    // 0x802F61FC: sw          $v0, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r2;
    // 0x802F6200: sw          $v1, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r3;
    // 0x802F6204: lw          $a0, 0x60($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X60);
    // 0x802F6208: lw          $a1, 0x64($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X64);
    // 0x802F620C: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x802F6210: jal         0x80137CB8
    // 0x802F6214: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    __ll_mul_recomp(rdram, ctx);
        goto after_12;
    // 0x802F6214: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    after_12:
    // 0x802F6218: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802F621C: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802F6220: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x802F6224: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x802F6228: lw          $a2, 0x30($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X30);
    // 0x802F622C: jal         0x80137CB8
    // 0x802F6230: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    __ll_mul_recomp(rdram, ctx);
        goto after_13;
    // 0x802F6230: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    after_13:
    // 0x802F6234: lw          $t7, 0x24($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X24);
    // 0x802F6238: lw          $t6, 0x20($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X20);
    // 0x802F623C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F6240: addu        $a1, $v1, $t7
    ctx->r5 = ADD32(ctx->r3, ctx->r15);
    // 0x802F6244: sltu        $at, $a1, $t7
    ctx->r1 = ctx->r5 < ctx->r15 ? 1 : 0;
    // 0x802F6248: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F624C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F6250: jal         0x80137DE4
    // 0x802F6254: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    __ll_rshift_recomp(rdram, ctx);
        goto after_14;
    // 0x802F6254: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    after_14:
    // 0x802F6258: lw          $t8, 0x98($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X98);
    // 0x802F625C: sh          $v1, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r3;
    // 0x802F6260: lw          $a1, 0x64($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X64);
    // 0x802F6264: lw          $a0, 0x60($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X60);
    // 0x802F6268: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    // 0x802F626C: sltiu       $at, $a1, 0x1
    ctx->r1 = ctx->r5 < 0X1 ? 1 : 0;
    // 0x802F6270: nor         $a0, $a0, $zero
    ctx->r4 = ~(ctx->r4 | 0);
    // 0x802F6274: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x802F6278: lw          $a2, 0x30($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X30);
    // 0x802F627C: jal         0x80137CB8
    // 0x802F6280: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    __ll_mul_recomp(rdram, ctx);
        goto after_15;
    // 0x802F6280: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    after_15:
    // 0x802F6284: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802F6288: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802F628C: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x802F6290: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x802F6294: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x802F6298: jal         0x80137CB8
    // 0x802F629C: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    __ll_mul_recomp(rdram, ctx);
        goto after_16;
    // 0x802F629C: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    after_16:
    // 0x802F62A0: lw          $t3, 0x24($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X24);
    // 0x802F62A4: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
    // 0x802F62A8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x802F62AC: addu        $a1, $v1, $t3
    ctx->r5 = ADD32(ctx->r3, ctx->r11);
    // 0x802F62B0: sltu        $at, $a1, $t3
    ctx->r1 = ctx->r5 < ctx->r11 ? 1 : 0;
    // 0x802F62B4: addu        $a0, $at, $v0
    ctx->r4 = ADD32(ctx->r1, ctx->r2);
    // 0x802F62B8: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802F62BC: jal         0x80137DE4
    // 0x802F62C0: addu        $a0, $a0, $t2
    ctx->r4 = ADD32(ctx->r4, ctx->r10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_17;
    // 0x802F62C0: addu        $a0, $a0, $t2
    ctx->r4 = ADD32(ctx->r4, ctx->r10);
    after_17:
    // 0x802F62C4: lw          $a0, 0x98($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X98);
    // 0x802F62C8: sh          $v1, 0x2($a0)
    MEM_H(0X2, ctx->r4) = ctx->r3;
    // 0x802F62CC: lw          $t5, 0x6C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X6C);
    // 0x802F62D0: sh          $t5, 0x4($a0)
    MEM_H(0X4, ctx->r4) = ctx->r13;
    // 0x802F62D4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802F62D8: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    // 0x802F62DC: jr          $ra
    // 0x802F62E0: nop

    return;
    // 0x802F62E0: nop

;}
RECOMP_FUNC void func_802F62E4_707994(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F62E4: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802F62E8: lh          $t6, 0x6A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X6A);
    // 0x802F62EC: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802F62F0: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x802F62F4: sw          $a1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r5;
    // 0x802F62F8: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x802F62FC: sw          $a3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r7;
    // 0x802F6300: addiu       $t7, $sp, 0x3C
    ctx->r15 = ADD32(ctx->r29, 0X3C);
    // 0x802F6304: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802F6308: lh          $a3, 0x66($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X66);
    // 0x802F630C: lh          $a2, 0x62($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X62);
    // 0x802F6310: lh          $a1, 0x5E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5E);
    // 0x802F6314: lh          $a0, 0x5A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5A);
    // 0x802F6318: jal         0x802F5F44
    // 0x802F631C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_0;
    // 0x802F631C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_0:
    // 0x802F6320: lh          $t8, 0x6E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X6E);
    // 0x802F6324: lh          $t1, 0x6A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X6A);
    // 0x802F6328: addiu       $t2, $sp, 0x34
    ctx->r10 = ADD32(ctx->r29, 0X34);
    // 0x802F632C: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x802F6330: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F6334: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x802F6338: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802F633C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F6340: lh          $a3, 0x66($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X66);
    // 0x802F6344: jal         0x802F5F44
    // 0x802F6348: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_1;
    // 0x802F6348: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    after_1:
    // 0x802F634C: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    // 0x802F6350: lh          $t4, 0x3C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X3C);
    // 0x802F6354: lh          $t7, 0x4E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X4E);
    // 0x802F6358: lh          $t8, 0x3E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X3E);
    // 0x802F635C: lh          $t1, 0x52($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X52);
    // 0x802F6360: lh          $t2, 0x40($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X40);
    // 0x802F6364: addu        $a1, $t3, $t4
    ctx->r5 = ADD32(ctx->r11, ctx->r12);
    // 0x802F6368: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x802F636C: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802F6370: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x802F6374: addu        $a3, $t1, $t2
    ctx->r7 = ADD32(ctx->r9, ctx->r10);
    // 0x802F6378: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F637C: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F6380: lh          $t9, 0x38($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X38);
    // 0x802F6384: lh          $t5, 0x34($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X34);
    // 0x802F6388: lh          $t7, 0x36($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X36);
    // 0x802F638C: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x802F6390: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F6394: lw          $t3, 0x70($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X70);
    // 0x802F6398: lh          $t2, 0x6A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X6A);
    // 0x802F639C: lh          $t1, 0x66($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X66);
    // 0x802F63A0: sll         $t0, $t9, 8
    ctx->r8 = S32(ctx->r25 << 8);
    // 0x802F63A4: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x802F63A8: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802F63AC: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x802F63B0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802F63B4: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x802F63B8: lbu         $a0, 0x57($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X57);
    // 0x802F63BC: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x802F63C0: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x802F63C4: jal         0x802C9564
    // 0x802F63C8: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    static_2_802C9564(rdram, ctx);
        goto after_2;
    // 0x802F63C8: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    after_2:
    // 0x802F63CC: bne         $v0, $zero, L_802F63DC
    if (ctx->r2 != 0) {
        // 0x802F63D0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802F63DC;
    }
    // 0x802F63D0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802F63D4: b           L_802F63E8
    // 0x802F63D8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802F63E8;
    // 0x802F63D8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802F63DC:
    // 0x802F63DC: lh          $t4, 0x66($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X66);
    // 0x802F63E0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802F63E4: sh          $t4, 0x2E($v1)
    MEM_H(0X2E, ctx->r3) = ctx->r12;
L_802F63E8:
    // 0x802F63E8: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802F63EC: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x802F63F0: jr          $ra
    // 0x802F63F4: nop

    return;
    // 0x802F63F4: nop

;}
RECOMP_FUNC void func_802F63F8_707AA8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F63F8: subu        $v0, $a1, $a0
    ctx->r2 = SUB32(ctx->r5, ctx->r4);
    // 0x802F63FC: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F6400: sll         $a3, $v0, 16
    ctx->r7 = S32(ctx->r2 << 16);
    // 0x802F6404: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802F6408: sll         $t0, $a2, 16
    ctx->r8 = S32(ctx->r6 << 16);
    // 0x802F640C: sra         $t2, $v1, 16
    ctx->r10 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F6410: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802F6414: sra         $a2, $t0, 16
    ctx->r6 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F6418: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802F641C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802F6420: bgez        $t3, L_802F6434
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802F6424: or          $v1, $t2, $zero
        ctx->r3 = ctx->r10 | 0;
            goto L_802F6434;
    }
    // 0x802F6424: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
    // 0x802F6428: addiu       $v1, $t3, 0x168
    ctx->r3 = ADD32(ctx->r11, 0X168);
    // 0x802F642C: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x802F6430: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
L_802F6434:
    // 0x802F6434: bne         $v1, $zero, L_802F6444
    if (ctx->r3 != 0) {
        // 0x802F6438: slti        $at, $v1, 0xB4
        ctx->r1 = SIGNED(ctx->r3) < 0XB4 ? 1 : 0;
            goto L_802F6444;
    }
    // 0x802F6438: slti        $at, $v1, 0xB4
    ctx->r1 = SIGNED(ctx->r3) < 0XB4 ? 1 : 0;
    // 0x802F643C: jr          $ra
    // 0x802F6440: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x802F6440: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802F6444:
    // 0x802F6444: bne         $at, $zero, L_802F6474
    if (ctx->r1 != 0) {
        // 0x802F6448: subu        $t0, $v1, $a2
        ctx->r8 = SUB32(ctx->r3, ctx->r6);
            goto L_802F6474;
    }
    // 0x802F6448: subu        $t0, $v1, $a2
    ctx->r8 = SUB32(ctx->r3, ctx->r6);
    // 0x802F644C: addu        $t6, $v1, $a2
    ctx->r14 = ADD32(ctx->r3, ctx->r6);
    // 0x802F6450: slti        $at, $t6, 0x168
    ctx->r1 = SIGNED(ctx->r14) < 0X168 ? 1 : 0;
    // 0x802F6454: bne         $at, $zero, L_802F646C
    if (ctx->r1 != 0) {
        // 0x802F6458: addiu       $t7, $zero, 0x168
        ctx->r15 = ADD32(0, 0X168);
            goto L_802F646C;
    }
    // 0x802F6458: addiu       $t7, $zero, 0x168
    ctx->r15 = ADD32(0, 0X168);
    // 0x802F645C: subu        $v0, $t7, $v1
    ctx->r2 = SUB32(ctx->r15, ctx->r3);
    // 0x802F6460: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802F6464: jr          $ra
    // 0x802F6468: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    return;
    // 0x802F6468: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
L_802F646C:
    // 0x802F646C: jr          $ra
    // 0x802F6470: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    return;
    // 0x802F6470: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802F6474:
    // 0x802F6474: bgez        $t0, L_802F648C
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F6478: negu        $v0, $a2
        ctx->r2 = SUB32(0, ctx->r6);
            goto L_802F648C;
    }
    // 0x802F6478: negu        $v0, $a2
    ctx->r2 = SUB32(0, ctx->r6);
    // 0x802F647C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
    // 0x802F6480: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x802F6484: jr          $ra
    // 0x802F6488: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    return;
    // 0x802F6488: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
L_802F648C:
    // 0x802F648C: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802F6490: sra         $v0, $t3, 16
    ctx->r2 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F6494: jr          $ra
    // 0x802F6498: nop

    return;
    // 0x802F6498: nop

;}
RECOMP_FUNC void func_802F649C_707B4C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F649C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802F64A0: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802F64A4: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F64A8: subu        $v1, $a1, $a0
    ctx->r3 = SUB32(ctx->r5, ctx->r4);
    // 0x802F64AC: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802F64B0: sll         $a3, $v1, 16
    ctx->r7 = S32(ctx->r3 << 16);
    // 0x802F64B4: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802F64B8: sll         $t0, $a2, 16
    ctx->r8 = S32(ctx->r6 << 16);
    // 0x802F64BC: sra         $t2, $v0, 16
    ctx->r10 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802F64C0: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802F64C4: sra         $a2, $t0, 16
    ctx->r6 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F64C8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802F64CC: bgez        $t3, L_802F64E0
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802F64D0: or          $v0, $t2, $zero
        ctx->r2 = ctx->r10 | 0;
            goto L_802F64E0;
    }
    // 0x802F64D0: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    // 0x802F64D4: addiu       $v0, $t3, 0x168
    ctx->r2 = ADD32(ctx->r11, 0X168);
    // 0x802F64D8: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x802F64DC: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
L_802F64E0:
    // 0x802F64E0: beq         $v0, $zero, L_802F6574
    if (ctx->r2 == 0) {
        // 0x802F64E4: slti        $at, $v0, 0xB4
        ctx->r1 = SIGNED(ctx->r2) < 0XB4 ? 1 : 0;
            goto L_802F6574;
    }
    // 0x802F64E4: slti        $at, $v0, 0xB4
    ctx->r1 = SIGNED(ctx->r2) < 0XB4 ? 1 : 0;
    // 0x802F64E8: bne         $at, $zero, L_802F653C
    if (ctx->r1 != 0) {
        // 0x802F64EC: subu        $t3, $v0, $a2
        ctx->r11 = SUB32(ctx->r2, ctx->r6);
            goto L_802F653C;
    }
    // 0x802F64EC: subu        $t3, $v0, $a2
    ctx->r11 = SUB32(ctx->r2, ctx->r6);
    // 0x802F64F0: addu        $t6, $v0, $a2
    ctx->r14 = ADD32(ctx->r2, ctx->r6);
    // 0x802F64F4: slti        $at, $t6, 0x168
    ctx->r1 = SIGNED(ctx->r14) < 0X168 ? 1 : 0;
    // 0x802F64F8: bnel        $at, $zero, L_802F6518
    if (ctx->r1 != 0) {
        // 0x802F64FC: addu        $a1, $a1, $a2
        ctx->r5 = ADD32(ctx->r5, ctx->r6);
            goto L_802F6518;
    }
    goto skip_0;
    // 0x802F64FC: addu        $a1, $a1, $a2
    ctx->r5 = ADD32(ctx->r5, ctx->r6);
    skip_0:
    // 0x802F6500: subu        $a1, $a1, $v0
    ctx->r5 = SUB32(ctx->r5, ctx->r2);
    // 0x802F6504: addiu       $a1, $a1, 0x168
    ctx->r5 = ADD32(ctx->r5, 0X168);
    // 0x802F6508: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802F650C: b           L_802F6520
    // 0x802F6510: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802F6520;
    // 0x802F6510: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F6514: addu        $a1, $a1, $a2
    ctx->r5 = ADD32(ctx->r5, ctx->r6);
L_802F6518:
    // 0x802F6518: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x802F651C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
L_802F6520:
    // 0x802F6520: slti        $at, $a1, 0x168
    ctx->r1 = SIGNED(ctx->r5) < 0X168 ? 1 : 0;
    // 0x802F6524: bne         $at, $zero, L_802F6574
    if (ctx->r1 != 0) {
        // 0x802F6528: nop
    
            goto L_802F6574;
    }
    // 0x802F6528: nop

    // 0x802F652C: addiu       $a1, $a1, -0x168
    ctx->r5 = ADD32(ctx->r5, -0X168);
    // 0x802F6530: sll         $t1, $a1, 16
    ctx->r9 = S32(ctx->r5 << 16);
    // 0x802F6534: jr          $ra
    // 0x802F6538: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    return;
    // 0x802F6538: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
L_802F653C:
    // 0x802F653C: bgezl       $t3, L_802F6558
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802F6540: subu        $a1, $a1, $a2
        ctx->r5 = SUB32(ctx->r5, ctx->r6);
            goto L_802F6558;
    }
    goto skip_1;
    // 0x802F6540: subu        $a1, $a1, $a2
    ctx->r5 = SUB32(ctx->r5, ctx->r6);
    skip_1:
    // 0x802F6544: subu        $a1, $a1, $v0
    ctx->r5 = SUB32(ctx->r5, ctx->r2);
    // 0x802F6548: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x802F654C: b           L_802F6560
    // 0x802F6550: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
        goto L_802F6560;
    // 0x802F6550: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802F6554: subu        $a1, $a1, $a2
    ctx->r5 = SUB32(ctx->r5, ctx->r6);
L_802F6558:
    // 0x802F6558: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802F655C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
L_802F6560:
    // 0x802F6560: bgez        $a1, L_802F6574
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802F6564: nop
    
            goto L_802F6574;
    }
    // 0x802F6564: nop

    // 0x802F6568: addiu       $a1, $a1, 0x168
    ctx->r5 = ADD32(ctx->r5, 0X168);
    // 0x802F656C: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802F6570: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
L_802F6574:
    // 0x802F6574: jr          $ra
    // 0x802F6578: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    return;
    // 0x802F6578: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
;}
RECOMP_FUNC void func_802F657C_707C2C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F657C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802F6580: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802F6584: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802F6588: sh          $a1, 0x178($a0)
    MEM_H(0X178, ctx->r4) = ctx->r5;
    // 0x802F658C: sh          $a2, 0x17A($a0)
    MEM_H(0X17A, ctx->r4) = ctx->r6;
    // 0x802F6590: sh          $a3, 0x17C($a0)
    MEM_H(0X17C, ctx->r4) = ctx->r7;
    // 0x802F6594: lh          $t2, 0x12($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X12);
    // 0x802F6598: lh          $t3, 0x4($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X4);
    // 0x802F659C: lh          $t4, 0x8($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X8);
    // 0x802F65A0: lh          $t5, 0xC($a0)
    ctx->r13 = MEM_H(ctx->r4, 0XC);
    // 0x802F65A4: sh          $zero, 0x184($a0)
    MEM_H(0X184, ctx->r4) = 0;
    // 0x802F65A8: sh          $t2, 0x172($a0)
    MEM_H(0X172, ctx->r4) = ctx->r10;
    // 0x802F65AC: sh          $t3, 0x17E($a0)
    MEM_H(0X17E, ctx->r4) = ctx->r11;
    // 0x802F65B0: sh          $t4, 0x180($a0)
    MEM_H(0X180, ctx->r4) = ctx->r12;
    // 0x802F65B4: jr          $ra
    // 0x802F65B8: sh          $t5, 0x182($a0)
    MEM_H(0X182, ctx->r4) = ctx->r13;
    return;
    // 0x802F65B8: sh          $t5, 0x182($a0)
    MEM_H(0X182, ctx->r4) = ctx->r13;
;}
RECOMP_FUNC void func_802F65BC_707C6C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F65BC: lh          $v0, 0x184($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X184);
    // 0x802F65C0: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802F65C4: bnel        $at, $zero, L_802F65F0
    if (ctx->r1 != 0) {
        // 0x802F65C8: lhu         $t9, 0x0($a0)
        ctx->r25 = MEM_HU(ctx->r4, 0X0);
            goto L_802F65F0;
    }
    goto skip_0;
    // 0x802F65C8: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
    skip_0:
    // 0x802F65CC: lw          $t6, 0x4C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X4C);
    // 0x802F65D0: sb          $zero, 0x170($a0)
    MEM_B(0X170, ctx->r4) = 0;
    // 0x802F65D4: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F65D8: sll         $t8, $t6, 29
    ctx->r24 = S32(ctx->r14 << 29);
    // 0x802F65DC: bltz        $t8, L_802F6748
    if (SIGNED(ctx->r24) < 0) {
        // 0x802F65E0: sw          $zero, 0x20($a0)
        MEM_W(0X20, ctx->r4) = 0;
            goto L_802F6748;
    }
    // 0x802F65E0: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F65E4: jr          $ra
    // 0x802F65E8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F65E8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    // 0x802F65EC: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
L_802F65F0:
    // 0x802F65F0: bnel        $t9, $zero, L_802F661C
    if (ctx->r25 != 0) {
        // 0x802F65F4: lh          $t8, 0x172($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X172);
            goto L_802F661C;
    }
    goto skip_1;
    // 0x802F65F4: lh          $t8, 0x172($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X172);
    skip_1:
    // 0x802F65F8: lw          $t5, 0x4C($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X4C);
    // 0x802F65FC: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F6600: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F6604: sll         $t7, $t5, 29
    ctx->r15 = S32(ctx->r13 << 29);
    // 0x802F6608: bltz        $t7, L_802F6748
    if (SIGNED(ctx->r15) < 0) {
        // 0x802F660C: nop
    
            goto L_802F6748;
    }
    // 0x802F660C: nop

    // 0x802F6610: jr          $ra
    // 0x802F6614: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F6614: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    // 0x802F6618: lh          $t8, 0x172($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X172);
L_802F661C:
    // 0x802F661C: lh          $a1, 0x17E($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X17E);
    // 0x802F6620: lh          $t5, 0x178($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X178);
    // 0x802F6624: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802F6628: sh          $t9, 0x184($a0)
    MEM_H(0X184, ctx->r4) = ctx->r25;
    // 0x802F662C: lh          $a3, 0x180($a0)
    ctx->r7 = MEM_H(ctx->r4, 0X180);
    // 0x802F6630: lh          $t7, 0x17A($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X17A);
    // 0x802F6634: lh          $t9, 0x17C($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X17C);
    // 0x802F6638: lh          $t1, 0x182($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X182);
    // 0x802F663C: lh          $v0, 0x184($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X184);
    // 0x802F6640: subu        $v1, $t5, $a1
    ctx->r3 = SUB32(ctx->r13, ctx->r5);
    // 0x802F6644: subu        $a2, $t7, $a3
    ctx->r6 = SUB32(ctx->r15, ctx->r7);
    // 0x802F6648: subu        $t0, $t9, $t1
    ctx->r8 = SUB32(ctx->r25, ctx->r9);
    // 0x802F664C: sra         $t6, $v1, 1
    ctx->r14 = S32(SIGNED(ctx->r3) >> 1);
    // 0x802F6650: sra         $t8, $a2, 1
    ctx->r24 = S32(SIGNED(ctx->r6) >> 1);
    // 0x802F6654: sra         $t5, $t0, 1
    ctx->r13 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802F6658: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802F665C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802F6660: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x802F6664: bne         $at, $zero, L_802F6674
    if (ctx->r1 != 0) {
        // 0x802F6668: or          $t0, $t5, $zero
        ctx->r8 = ctx->r13 | 0;
            goto L_802F6674;
    }
    // 0x802F6668: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x802F666C: b           L_802F669C
    // 0x802F6670: addiu       $t2, $zero, -0x8000
    ctx->r10 = ADD32(0, -0X8000);
        goto L_802F669C;
    // 0x802F6670: addiu       $t2, $zero, -0x8000
    ctx->r10 = ADD32(0, -0X8000);
L_802F6674:
    // 0x802F6674: bne         $v0, $zero, L_802F6684
    if (ctx->r2 != 0) {
        // 0x802F6678: sra         $t8, $v0, 1
        ctx->r24 = S32(SIGNED(ctx->r2) >> 1);
            goto L_802F6684;
    }
    // 0x802F6678: sra         $t8, $v0, 1
    ctx->r24 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802F667C: b           L_802F669C
    // 0x802F6680: ori         $t2, $zero, 0x8000
    ctx->r10 = 0 | 0X8000;
        goto L_802F669C;
    // 0x802F6680: ori         $t2, $zero, 0x8000
    ctx->r10 = 0 | 0X8000;
L_802F6684:
    // 0x802F6684: addiu       $t9, $t8, 0x40
    ctx->r25 = ADD32(ctx->r24, 0X40);
    // 0x802F6688: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x802F668C: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802F6690: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802F6694: addu        $t2, $t2, $t6
    ctx->r10 = ADD32(ctx->r10, ctx->r14);
    // 0x802F6698: lh          $t2, 0x2C78($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2C78);
L_802F669C:
    // 0x802F669C: andi        $t7, $v0, 0x1
    ctx->r15 = ctx->r2 & 0X1;
    // 0x802F66A0: beq         $t7, $zero, L_802F66CC
    if (ctx->r15 == 0) {
        // 0x802F66A4: sra         $t6, $v0, 1
        ctx->r14 = S32(SIGNED(ctx->r2) >> 1);
            goto L_802F66CC;
    }
    // 0x802F66A4: sra         $t6, $v0, 1
    ctx->r14 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802F66A8: addiu       $t7, $t6, 0x41
    ctx->r15 = ADD32(ctx->r14, 0X41);
    // 0x802F66AC: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802F66B0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802F66B4: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x802F66B8: addu        $t5, $t5, $t9
    ctx->r13 = ADD32(ctx->r13, ctx->r25);
    // 0x802F66BC: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x802F66C0: addu        $t2, $t5, $t2
    ctx->r10 = ADD32(ctx->r13, ctx->r10);
    // 0x802F66C4: sra         $t6, $t2, 1
    ctx->r14 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802F66C8: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
L_802F66CC:
    // 0x802F66CC: sll         $t9, $v1, 1
    ctx->r25 = S32(ctx->r3 << 1);
    // 0x802F66D0: multu       $t9, $t2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F66D4: sll         $t9, $a2, 1
    ctx->r25 = S32(ctx->r6 << 1);
    // 0x802F66D8: addu        $t7, $a1, $v1
    ctx->r15 = ADD32(ctx->r5, ctx->r3);
    // 0x802F66DC: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802F66E0: addu        $t6, $a3, $a2
    ctx->r14 = ADD32(ctx->r7, ctx->r6);
    // 0x802F66E4: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802F66E8: mflo        $t5
    ctx->r13 = lo;
    // 0x802F66EC: subu        $v0, $t8, $t5
    ctx->r2 = SUB32(ctx->r24, ctx->r13);
    // 0x802F66F0: addu        $t5, $t1, $t0
    ctx->r13 = ADD32(ctx->r9, ctx->r8);
    // 0x802F66F4: multu       $t9, $t2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F66F8: sll         $t9, $t0, 1
    ctx->r25 = S32(ctx->r8 << 1);
    // 0x802F66FC: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802F6700: mflo        $t8
    ctx->r24 = lo;
    // 0x802F6704: subu        $t3, $t7, $t8
    ctx->r11 = SUB32(ctx->r15, ctx->r24);
    // 0x802F6708: lw          $t8, 0x4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X4);
    // 0x802F670C: multu       $t9, $t2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6710: lw          $t9, 0x8($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X8);
    // 0x802F6714: subu        $t5, $v0, $t8
    ctx->r13 = SUB32(ctx->r2, ctx->r24);
    // 0x802F6718: sw          $t5, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r13;
    // 0x802F671C: mflo        $t7
    ctx->r15 = lo;
    // 0x802F6720: subu        $t4, $t6, $t7
    ctx->r12 = SUB32(ctx->r14, ctx->r15);
    // 0x802F6724: lw          $t7, 0x4C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X4C);
    // 0x802F6728: subu        $t6, $t3, $t9
    ctx->r14 = SUB32(ctx->r11, ctx->r25);
    // 0x802F672C: sw          $t6, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r14;
    // 0x802F6730: sll         $t5, $t7, 29
    ctx->r13 = S32(ctx->r15 << 29);
    // 0x802F6734: bltz        $t5, L_802F6748
    if (SIGNED(ctx->r13) < 0) {
        // 0x802F6738: nop
    
            goto L_802F6748;
    }
    // 0x802F6738: nop

    // 0x802F673C: lw          $t9, 0xC($a0)
    ctx->r25 = MEM_W(ctx->r4, 0XC);
    // 0x802F6740: subu        $t6, $t4, $t9
    ctx->r14 = SUB32(ctx->r12, ctx->r25);
    // 0x802F6744: sw          $t6, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r14;
L_802F6748:
    // 0x802F6748: jr          $ra
    // 0x802F674C: nop

    return;
    // 0x802F674C: nop

;}
RECOMP_FUNC void func_802F6750_707E00(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F6750: lh          $v0, 0x184($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X184);
    // 0x802F6754: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802F6758: bnel        $at, $zero, L_802F6784
    if (ctx->r1 != 0) {
        // 0x802F675C: lhu         $t9, 0x0($a0)
        ctx->r25 = MEM_HU(ctx->r4, 0X0);
            goto L_802F6784;
    }
    goto skip_0;
    // 0x802F675C: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
    skip_0:
    // 0x802F6760: lw          $t6, 0x4C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X4C);
    // 0x802F6764: sb          $zero, 0x170($a0)
    MEM_B(0X170, ctx->r4) = 0;
    // 0x802F6768: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F676C: sll         $t8, $t6, 29
    ctx->r24 = S32(ctx->r14 << 29);
    // 0x802F6770: bltz        $t8, L_802F6898
    if (SIGNED(ctx->r24) < 0) {
        // 0x802F6774: sw          $zero, 0x20($a0)
        MEM_W(0X20, ctx->r4) = 0;
            goto L_802F6898;
    }
    // 0x802F6774: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F6778: jr          $ra
    // 0x802F677C: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F677C: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    // 0x802F6780: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
L_802F6784:
    // 0x802F6784: bnel        $t9, $zero, L_802F67B0
    if (ctx->r25 != 0) {
        // 0x802F6788: lh          $t8, 0x172($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X172);
            goto L_802F67B0;
    }
    goto skip_1;
    // 0x802F6788: lh          $t8, 0x172($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X172);
    skip_1:
    // 0x802F678C: lw          $t5, 0x4C($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X4C);
    // 0x802F6790: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F6794: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F6798: sll         $t7, $t5, 29
    ctx->r15 = S32(ctx->r13 << 29);
    // 0x802F679C: bltz        $t7, L_802F6898
    if (SIGNED(ctx->r15) < 0) {
        // 0x802F67A0: nop
    
            goto L_802F6898;
    }
    // 0x802F67A0: nop

    // 0x802F67A4: jr          $ra
    // 0x802F67A8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F67A8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    // 0x802F67AC: lh          $t8, 0x172($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X172);
L_802F67B0:
    // 0x802F67B0: addiu       $t6, $zero, 0x100
    ctx->r14 = ADD32(0, 0X100);
    // 0x802F67B4: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802F67B8: sh          $t9, 0x184($a0)
    MEM_H(0X184, ctx->r4) = ctx->r25;
    // 0x802F67BC: lh          $t5, 0x184($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X184);
    // 0x802F67C0: slti        $at, $t5, 0x101
    ctx->r1 = SIGNED(ctx->r13) < 0X101 ? 1 : 0;
    // 0x802F67C4: bnel        $at, $zero, L_802F67D4
    if (ctx->r1 != 0) {
        // 0x802F67C8: lh          $v1, 0x178($a0)
        ctx->r3 = MEM_H(ctx->r4, 0X178);
            goto L_802F67D4;
    }
    goto skip_2;
    // 0x802F67C8: lh          $v1, 0x178($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X178);
    skip_2:
    // 0x802F67CC: sh          $t6, 0x184($a0)
    MEM_H(0X184, ctx->r4) = ctx->r14;
    // 0x802F67D0: lh          $v1, 0x178($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X178);
L_802F67D4:
    // 0x802F67D4: lh          $a1, 0x17E($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X17E);
    // 0x802F67D8: lh          $a3, 0x17A($a0)
    ctx->r7 = MEM_H(ctx->r4, 0X17A);
    // 0x802F67DC: lh          $t0, 0x180($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X180);
    // 0x802F67E0: lh          $t2, 0x17C($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X17C);
    // 0x802F67E4: lh          $t3, 0x182($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X182);
    // 0x802F67E8: subu        $v0, $v1, $a1
    ctx->r2 = SUB32(ctx->r3, ctx->r5);
    // 0x802F67EC: subu        $a2, $a3, $t0
    ctx->r6 = SUB32(ctx->r7, ctx->r8);
    // 0x802F67F0: bne         $v0, $zero, L_802F6800
    if (ctx->r2 != 0) {
        // 0x802F67F4: subu        $t1, $t2, $t3
        ctx->r9 = SUB32(ctx->r10, ctx->r11);
            goto L_802F6800;
    }
    // 0x802F67F4: subu        $t1, $t2, $t3
    ctx->r9 = SUB32(ctx->r10, ctx->r11);
    // 0x802F67F8: b           L_802F6818
    // 0x802F67FC: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
        goto L_802F6818;
    // 0x802F67FC: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
L_802F6800:
    // 0x802F6800: lh          $t8, 0x184($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X184);
    // 0x802F6804: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802F6808: multu       $v0, $t8
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F680C: mflo        $t9
    ctx->r25 = lo;
    // 0x802F6810: sll         $t5, $t9, 8
    ctx->r13 = S32(ctx->r25 << 8);
    // 0x802F6814: addu        $t4, $t7, $t5
    ctx->r12 = ADD32(ctx->r15, ctx->r13);
L_802F6818:
    // 0x802F6818: bnel        $a2, $zero, L_802F682C
    if (ctx->r6 != 0) {
        // 0x802F681C: lh          $t8, 0x184($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X184);
            goto L_802F682C;
    }
    goto skip_3;
    // 0x802F681C: lh          $t8, 0x184($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X184);
    skip_3:
    // 0x802F6820: b           L_802F6840
    // 0x802F6824: sll         $v0, $a3, 16
    ctx->r2 = S32(ctx->r7 << 16);
        goto L_802F6840;
    // 0x802F6824: sll         $v0, $a3, 16
    ctx->r2 = S32(ctx->r7 << 16);
    // 0x802F6828: lh          $t8, 0x184($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X184);
L_802F682C:
    // 0x802F682C: sll         $t6, $t0, 16
    ctx->r14 = S32(ctx->r8 << 16);
    // 0x802F6830: multu       $a2, $t8
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6834: mflo        $t9
    ctx->r25 = lo;
    // 0x802F6838: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x802F683C: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
L_802F6840:
    // 0x802F6840: bnel        $t1, $zero, L_802F6854
    if (ctx->r9 != 0) {
        // 0x802F6844: lh          $t8, 0x184($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X184);
            goto L_802F6854;
    }
    goto skip_4;
    // 0x802F6844: lh          $t8, 0x184($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X184);
    skip_4:
    // 0x802F6848: b           L_802F6868
    // 0x802F684C: sll         $v1, $t2, 16
    ctx->r3 = S32(ctx->r10 << 16);
        goto L_802F6868;
    // 0x802F684C: sll         $v1, $t2, 16
    ctx->r3 = S32(ctx->r10 << 16);
    // 0x802F6850: lh          $t8, 0x184($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X184);
L_802F6854:
    // 0x802F6854: sll         $t5, $t3, 16
    ctx->r13 = S32(ctx->r11 << 16);
    // 0x802F6858: multu       $t1, $t8
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F685C: mflo        $t9
    ctx->r25 = lo;
    // 0x802F6860: sll         $t6, $t9, 8
    ctx->r14 = S32(ctx->r25 << 8);
    // 0x802F6864: addu        $v1, $t5, $t6
    ctx->r3 = ADD32(ctx->r13, ctx->r14);
L_802F6868:
    // 0x802F6868: lw          $t7, 0x4($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X4);
    // 0x802F686C: lw          $t9, 0x8($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X8);
    // 0x802F6870: lw          $t6, 0x4C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X4C);
    // 0x802F6874: subu        $t8, $t4, $t7
    ctx->r24 = SUB32(ctx->r12, ctx->r15);
    // 0x802F6878: sw          $t8, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r24;
    // 0x802F687C: subu        $t5, $v0, $t9
    ctx->r13 = SUB32(ctx->r2, ctx->r25);
    // 0x802F6880: sll         $t8, $t6, 29
    ctx->r24 = S32(ctx->r14 << 29);
    // 0x802F6884: bltz        $t8, L_802F6898
    if (SIGNED(ctx->r24) < 0) {
        // 0x802F6888: sw          $t5, 0x20($a0)
        MEM_W(0X20, ctx->r4) = ctx->r13;
            goto L_802F6898;
    }
    // 0x802F6888: sw          $t5, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r13;
    // 0x802F688C: lw          $t9, 0xC($a0)
    ctx->r25 = MEM_W(ctx->r4, 0XC);
    // 0x802F6890: subu        $t5, $v1, $t9
    ctx->r13 = SUB32(ctx->r3, ctx->r25);
    // 0x802F6894: sw          $t5, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r13;
L_802F6898:
    // 0x802F6898: jr          $ra
    // 0x802F689C: nop

    return;
    // 0x802F689C: nop

;}
RECOMP_FUNC void head_towards_waypoint(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F68A0: lh          $v0, 0x178($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X178);
    // 0x802F68A4: lh          $v1, 0x4($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X4);
    // 0x802F68A8: bnel        $v0, $v1, L_802F6900
    if (ctx->r2 != ctx->r3) {
        // 0x802F68AC: lw          $a3, 0x4C($a0)
        ctx->r7 = MEM_W(ctx->r4, 0X4C);
            goto L_802F6900;
    }
    goto skip_0;
    // 0x802F68AC: lw          $a3, 0x4C($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X4C);
    skip_0:
    // 0x802F68B0: lh          $t6, 0x17A($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X17A);
    // 0x802F68B4: lh          $t7, 0x8($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X8);
    // 0x802F68B8: bnel        $t6, $t7, L_802F6900
    if (ctx->r14 != ctx->r15) {
        // 0x802F68BC: lw          $a3, 0x4C($a0)
        ctx->r7 = MEM_W(ctx->r4, 0X4C);
            goto L_802F6900;
    }
    goto skip_1;
    // 0x802F68BC: lw          $a3, 0x4C($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X4C);
    skip_1:
    // 0x802F68C0: lw          $a3, 0x4C($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X4C);
    // 0x802F68C4: sll         $t8, $a3, 29
    ctx->r24 = S32(ctx->r7 << 29);
    // 0x802F68C8: srl         $a3, $t8, 31
    ctx->r7 = S32(U32(ctx->r24) >> 31);
    // 0x802F68CC: bnel        $a3, $zero, L_802F68E8
    if (ctx->r7 != 0) {
        // 0x802F68D0: sb          $zero, 0x170($a0)
        MEM_B(0X170, ctx->r4) = 0;
            goto L_802F68E8;
    }
    goto skip_2;
    // 0x802F68D0: sb          $zero, 0x170($a0)
    MEM_B(0X170, ctx->r4) = 0;
    skip_2:
    // 0x802F68D4: lh          $t3, 0x17C($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X17C);
    // 0x802F68D8: lh          $t4, 0xC($a0)
    ctx->r12 = MEM_H(ctx->r4, 0XC);
    // 0x802F68DC: bnel        $t3, $t4, L_802F6900
    if (ctx->r11 != ctx->r12) {
        // 0x802F68E0: lw          $a3, 0x4C($a0)
        ctx->r7 = MEM_W(ctx->r4, 0X4C);
            goto L_802F6900;
    }
    goto skip_3;
    // 0x802F68E0: lw          $a3, 0x4C($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X4C);
    skip_3:
    // 0x802F68E4: sb          $zero, 0x170($a0)
    MEM_B(0X170, ctx->r4) = 0;
L_802F68E8:
    // 0x802F68E8: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F68EC: bne         $a3, $zero, L_802F6A54
    if (ctx->r7 != 0) {
        // 0x802F68F0: sw          $zero, 0x20($a0)
        MEM_W(0X20, ctx->r4) = 0;
            goto L_802F6A54;
    }
    // 0x802F68F0: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F68F4: jr          $ra
    // 0x802F68F8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F68F8: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    // 0x802F68FC: lw          $a3, 0x4C($a0)
    ctx->r7 = MEM_W(ctx->r4, 0X4C);
L_802F6900:
    // 0x802F6900: lhu         $t7, 0x0($a0)
    ctx->r15 = MEM_HU(ctx->r4, 0X0);
    // 0x802F6904: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F6908: sll         $t5, $a3, 29
    ctx->r13 = S32(ctx->r7 << 29);
    // 0x802F690C: srl         $t6, $t5, 31
    ctx->r14 = S32(U32(ctx->r13) >> 31);
    // 0x802F6910: bne         $t7, $zero, L_802F692C
    if (ctx->r15 != 0) {
        // 0x802F6914: or          $a3, $t6, $zero
        ctx->r7 = ctx->r14 | 0;
            goto L_802F692C;
    }
    // 0x802F6914: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802F6918: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x802F691C: bne         $t6, $zero, L_802F6A54
    if (ctx->r14 != 0) {
        // 0x802F6920: sw          $zero, 0x20($a0)
        MEM_W(0X20, ctx->r4) = 0;
            goto L_802F6A54;
    }
    // 0x802F6920: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x802F6924: jr          $ra
    // 0x802F6928: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
    return;
    // 0x802F6928: sw          $zero, 0x24($a0)
    MEM_W(0X24, ctx->r4) = 0;
L_802F692C:
    // 0x802F692C: lh          $a1, 0x17A($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X17A);
    // 0x802F6930: lh          $a2, 0x8($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X8);
    // 0x802F6934: lh          $t0, 0x17C($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X17C);
    // 0x802F6938: beq         $at, $zero, L_802F695C
    if (ctx->r1 == 0) {
        // 0x802F693C: lh          $t1, 0xC($a0)
        ctx->r9 = MEM_H(ctx->r4, 0XC);
            goto L_802F695C;
    }
    // 0x802F693C: lh          $t1, 0xC($a0)
    ctx->r9 = MEM_H(ctx->r4, 0XC);
    // 0x802F6940: lh          $t8, 0x172($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X172);
    // 0x802F6944: addu        $t2, $v1, $t8
    ctx->r10 = ADD32(ctx->r3, ctx->r24);
    // 0x802F6948: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802F694C: beql        $at, $zero, L_802F6988
    if (ctx->r1 == 0) {
        // 0x802F6950: slt         $at, $a2, $a1
        ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_802F6988;
    }
    goto skip_4;
    // 0x802F6950: slt         $at, $a2, $a1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
    skip_4:
    // 0x802F6954: b           L_802F6984
    // 0x802F6958: or          $t2, $v0, $zero
    ctx->r10 = ctx->r2 | 0;
        goto L_802F6984;
    // 0x802F6958: or          $t2, $v0, $zero
    ctx->r10 = ctx->r2 | 0;
L_802F695C:
    // 0x802F695C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F6960: beq         $at, $zero, L_802F6984
    if (ctx->r1 == 0) {
        // 0x802F6964: or          $t2, $v1, $zero
        ctx->r10 = ctx->r3 | 0;
            goto L_802F6984;
    }
    // 0x802F6964: or          $t2, $v1, $zero
    ctx->r10 = ctx->r3 | 0;
    // 0x802F6968: lh          $t9, 0x172($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X172);
    // 0x802F696C: subu        $t2, $v1, $t9
    ctx->r10 = SUB32(ctx->r3, ctx->r25);
    // 0x802F6970: slt         $at, $t2, $v0
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F6974: beql        $at, $zero, L_802F6988
    if (ctx->r1 == 0) {
        // 0x802F6978: slt         $at, $a2, $a1
        ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_802F6988;
    }
    goto skip_5;
    // 0x802F6978: slt         $at, $a2, $a1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
    skip_5:
    // 0x802F697C: b           L_802F6984
    // 0x802F6980: or          $t2, $v0, $zero
    ctx->r10 = ctx->r2 | 0;
        goto L_802F6984;
    // 0x802F6980: or          $t2, $v0, $zero
    ctx->r10 = ctx->r2 | 0;
L_802F6984:
    // 0x802F6984: slt         $at, $a2, $a1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
L_802F6988:
    // 0x802F6988: beq         $at, $zero, L_802F69AC
    if (ctx->r1 == 0) {
        // 0x802F698C: sll         $t7, $t2, 16
        ctx->r15 = S32(ctx->r10 << 16);
            goto L_802F69AC;
    }
    // 0x802F698C: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x802F6990: lh          $t3, 0x172($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X172);
    // 0x802F6994: addu        $v0, $a2, $t3
    ctx->r2 = ADD32(ctx->r6, ctx->r11);
    // 0x802F6998: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F699C: beql        $at, $zero, L_802F69D8
    if (ctx->r1 == 0) {
        // 0x802F69A0: slt         $at, $t1, $t0
        ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802F69D8;
    }
    goto skip_6;
    // 0x802F69A0: slt         $at, $t1, $t0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
    skip_6:
    // 0x802F69A4: b           L_802F69D4
    // 0x802F69A8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802F69D4;
    // 0x802F69A8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802F69AC:
    // 0x802F69AC: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802F69B0: beq         $at, $zero, L_802F69D4
    if (ctx->r1 == 0) {
        // 0x802F69B4: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802F69D4;
    }
    // 0x802F69B4: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802F69B8: lh          $t4, 0x172($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X172);
    // 0x802F69BC: subu        $v0, $a2, $t4
    ctx->r2 = SUB32(ctx->r6, ctx->r12);
    // 0x802F69C0: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802F69C4: beql        $at, $zero, L_802F69D8
    if (ctx->r1 == 0) {
        // 0x802F69C8: slt         $at, $t1, $t0
        ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802F69D8;
    }
    goto skip_7;
    // 0x802F69C8: slt         $at, $t1, $t0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
    skip_7:
    // 0x802F69CC: b           L_802F69D4
    // 0x802F69D0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
        goto L_802F69D4;
    // 0x802F69D0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_802F69D4:
    // 0x802F69D4: slt         $at, $t1, $t0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
L_802F69D8:
    // 0x802F69D8: beql        $at, $zero, L_802F6A00
    if (ctx->r1 == 0) {
        // 0x802F69DC: slt         $at, $t0, $t1
        ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r9) ? 1 : 0;
            goto L_802F6A00;
    }
    goto skip_8;
    // 0x802F69DC: slt         $at, $t0, $t1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r9) ? 1 : 0;
    skip_8:
    // 0x802F69E0: lh          $t5, 0x172($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X172);
    // 0x802F69E4: addu        $v1, $t1, $t5
    ctx->r3 = ADD32(ctx->r9, ctx->r13);
    // 0x802F69E8: slt         $at, $t0, $v1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F69EC: beql        $at, $zero, L_802F6A28
    if (ctx->r1 == 0) {
        // 0x802F69F0: lw          $t8, 0x4($a0)
        ctx->r24 = MEM_W(ctx->r4, 0X4);
            goto L_802F6A28;
    }
    goto skip_9;
    // 0x802F69F0: lw          $t8, 0x4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X4);
    skip_9:
    // 0x802F69F4: b           L_802F6A24
    // 0x802F69F8: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
        goto L_802F6A24;
    // 0x802F69F8: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
    // 0x802F69FC: slt         $at, $t0, $t1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r9) ? 1 : 0;
L_802F6A00:
    // 0x802F6A00: beq         $at, $zero, L_802F6A24
    if (ctx->r1 == 0) {
        // 0x802F6A04: or          $v1, $t1, $zero
        ctx->r3 = ctx->r9 | 0;
            goto L_802F6A24;
    }
    // 0x802F6A04: or          $v1, $t1, $zero
    ctx->r3 = ctx->r9 | 0;
    // 0x802F6A08: lh          $t6, 0x172($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X172);
    // 0x802F6A0C: subu        $v1, $t1, $t6
    ctx->r3 = SUB32(ctx->r9, ctx->r14);
    // 0x802F6A10: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802F6A14: beql        $at, $zero, L_802F6A28
    if (ctx->r1 == 0) {
        // 0x802F6A18: lw          $t8, 0x4($a0)
        ctx->r24 = MEM_W(ctx->r4, 0X4);
            goto L_802F6A28;
    }
    goto skip_10;
    // 0x802F6A18: lw          $t8, 0x4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X4);
    skip_10:
    // 0x802F6A1C: b           L_802F6A24
    // 0x802F6A20: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
        goto L_802F6A24;
    // 0x802F6A20: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
L_802F6A24:
    // 0x802F6A24: lw          $t8, 0x4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X4);
L_802F6A28:
    // 0x802F6A28: lw          $t4, 0x8($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X8);
    // 0x802F6A2C: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802F6A30: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x802F6A34: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x802F6A38: sw          $t9, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r25;
    // 0x802F6A3C: bne         $a3, $zero, L_802F6A54
    if (ctx->r7 != 0) {
        // 0x802F6A40: sw          $t5, 0x20($a0)
        MEM_W(0X20, ctx->r4) = ctx->r13;
            goto L_802F6A54;
    }
    // 0x802F6A40: sw          $t5, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r13;
    // 0x802F6A44: lw          $t7, 0xC($a0)
    ctx->r15 = MEM_W(ctx->r4, 0XC);
    // 0x802F6A48: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802F6A4C: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802F6A50: sw          $t8, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r24;
L_802F6A54:
    // 0x802F6A54: jr          $ra
    // 0x802F6A58: nop

    return;
    // 0x802F6A58: nop

;}
RECOMP_FUNC void func_802F6A5C_70810C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F6A5C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802F6A60: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F6A64: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x802F6A68: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802F6A6C: beq         $v0, $at, L_802F6DDC
    if (ctx->r2 == ctx->r1) {
        // 0x802F6A70: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802F6DDC;
    }
    // 0x802F6A70: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802F6A74: beql        $v0, $at, L_802F6DE0
    if (ctx->r2 == ctx->r1) {
        // 0x802F6A78: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802F6DE0;
    }
    goto skip_0;
    // 0x802F6A78: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802F6A7C: lbu         $t6, 0x161($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X161);
    // 0x802F6A80: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F6A84: bnel        $t6, $at, L_802F6ADC
    if (ctx->r14 != ctx->r1) {
        // 0x802F6A88: lh          $t4, 0x30($a0)
        ctx->r12 = MEM_H(ctx->r4, 0X30);
            goto L_802F6ADC;
    }
    goto skip_1;
    // 0x802F6A88: lh          $t4, 0x30($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X30);
    skip_1:
    // 0x802F6A8C: lw          $v0, 0x6C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X6C);
    // 0x802F6A90: beql        $v0, $zero, L_802F6ADC
    if (ctx->r2 == 0) {
        // 0x802F6A94: lh          $t4, 0x30($a0)
        ctx->r12 = MEM_H(ctx->r4, 0X30);
            goto L_802F6ADC;
    }
    goto skip_2;
    // 0x802F6A94: lh          $t4, 0x30($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X30);
    skip_2:
    // 0x802F6A98: lh          $t7, 0x30($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X30);
    // 0x802F6A9C: lw          $t8, 0x1C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X1C);
    // 0x802F6AA0: lw          $t9, 0x1C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X1C);
    // 0x802F6AA4: lw          $t1, 0x20($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X20);
    // 0x802F6AA8: lw          $t2, 0x20($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X20);
    // 0x802F6AAC: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802F6AB0: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x802F6AB4: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x802F6AB8: mtc1        $t0, $f6
    ctx->f6.u32l = ctx->r8;
    // 0x802F6ABC: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x802F6AC0: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F6AC4: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F6AC8: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F6ACC: div.s       $f14, $f8, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802F6AD0: b           L_802F6B04
    // 0x802F6AD4: div.s       $f2, $f4, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f4.fl, ctx->f0.fl);
        goto L_802F6B04;
    // 0x802F6AD4: div.s       $f2, $f4, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802F6AD8: lh          $t4, 0x30($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X30);
L_802F6ADC:
    // 0x802F6ADC: lw          $t5, 0x1C($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X1C);
    // 0x802F6AE0: lw          $t6, 0x20($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X20);
    // 0x802F6AE4: mtc1        $t4, $f6
    ctx->f6.u32l = ctx->r12;
    // 0x802F6AE8: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x802F6AEC: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802F6AF0: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F6AF4: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F6AF8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F6AFC: div.s       $f14, $f10, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802F6B00: div.s       $f2, $f6, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
L_802F6B04:
    // 0x802F6B04: mul.s       $f8, $f14, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x802F6B08: mtc1        $zero, $f5
    ctx->f_odd[(5 - 1) * 2] = 0;
    // 0x802F6B0C: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802F6B10: mul.s       $f10, $f2, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x802F6B14: add.s       $f0, $f8, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f0.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x802F6B18: sqrt.s      $f18, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = sqrtf(ctx->f0.fl);
    // 0x802F6B1C: cvt.d.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.d = CVT_D_S(ctx->f18.fl);
    // 0x802F6B20: c.eq.d      $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    c1cs = ctx->f4.d == ctx->f6.d;
    // 0x802F6B24: nop

    // 0x802F6B28: bc1fl       L_802F6B40
    if (!c1cs) {
        // 0x802F6B2C: neg.s       $f12, $f2
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = -ctx->f2.fl;
            goto L_802F6B40;
    }
    goto skip_3;
    // 0x802F6B2C: neg.s       $f12, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = -ctx->f2.fl;
    skip_3:
    // 0x802F6B30: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x802F6B34: b           L_802F6B8C
    // 0x802F6B38: nop

        goto L_802F6B8C;
    // 0x802F6B38: nop

    // 0x802F6B3C: neg.s       $f12, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = -ctx->f2.fl;
L_802F6B40:
    // 0x802F6B40: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802F6B44: jal         0x801286B8
    // 0x802F6B48: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    func_801286B8(rdram, ctx);
        goto after_0;
    // 0x802F6B48: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    after_0:
    // 0x802F6B4C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F6B50: ldc1        $f14, -0x3130($at)
    CHECK_FR(ctx, 14);
    ctx->f14.u64 = LD(ctx->r1, -0X3130);
    // 0x802F6B54: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F6B58: ldc1        $f10, -0x3128($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X3128);
    // 0x802F6B5C: cvt.d.s     $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f8.d = CVT_D_S(ctx->f0.fl);
    // 0x802F6B60: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x802F6B64: add.d       $f4, $f8, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f4.d = ctx->f8.d + ctx->f10.d;
    // 0x802F6B68: lwc1        $f18, 0x18($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X18);
    // 0x802F6B6C: cvt.s.d     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f16.fl = CVT_S_D(ctx->f4.d);
    // 0x802F6B70: cvt.d.s     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f12.d = CVT_D_S(ctx->f16.fl);
    // 0x802F6B74: c.lt.d      $f14, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f14.d < ctx->f12.d;
    // 0x802F6B78: nop

    // 0x802F6B7C: bc1f        L_802F6B8C
    if (!c1cs) {
        // 0x802F6B80: nop
    
            goto L_802F6B8C;
    }
    // 0x802F6B80: nop

    // 0x802F6B84: sub.d       $f6, $f12, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.d); NAN_CHECK(ctx->f14.d); 
    ctx->f6.d = ctx->f12.d - ctx->f14.d;
    // 0x802F6B88: cvt.s.d     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f16.fl = CVT_S_D(ctx->f6.d);
L_802F6B8C:
    // 0x802F6B8C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F6B90: ldc1        $f14, -0x3120($at)
    CHECK_FR(ctx, 14);
    ctx->f14.u64 = LD(ctx->r1, -0X3120);
    // 0x802F6B94: cvt.d.s     $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f2.d = CVT_D_S(ctx->f18.fl);
    // 0x802F6B98: trunc.w.s   $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    ctx->f6.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802F6B9C: c.lt.d      $f14, $f2
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f14.d < ctx->f2.d;
    // 0x802F6BA0: nop

    // 0x802F6BA4: bc1fl       L_802F6CA4
    if (!c1cs) {
        // 0x802F6BA8: lh          $t6, 0x2C($a0)
        ctx->r14 = MEM_H(ctx->r4, 0X2C);
            goto L_802F6CA4;
    }
    goto skip_4;
    // 0x802F6BA8: lh          $t6, 0x2C($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2C);
    skip_4:
    // 0x802F6BAC: trunc.w.s   $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802F6BB0: lh          $v1, 0x2C($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X2C);
    // 0x802F6BB4: div.d       $f0, $f2, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f14.d); 
    ctx->f0.d = DIV_D(ctx->f2.d, ctx->f14.d);
    // 0x802F6BB8: mfc1        $t0, $f8
    ctx->r8 = (int32_t)ctx->f8.u32l;
    // 0x802F6BBC: nop

    // 0x802F6BC0: subu        $v0, $t0, $v1
    ctx->r2 = SUB32(ctx->r8, ctx->r3);
    // 0x802F6BC4: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x802F6BC8: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F6BCC: slti        $at, $v0, -0x5A
    ctx->r1 = SIGNED(ctx->r2) < -0X5A ? 1 : 0;
    // 0x802F6BD0: beql        $at, $zero, L_802F6BF4
    if (ctx->r1 == 0) {
        // 0x802F6BD4: slti        $at, $v0, 0x5B
        ctx->r1 = SIGNED(ctx->r2) < 0X5B ? 1 : 0;
            goto L_802F6BF4;
    }
    goto skip_5;
    // 0x802F6BD4: slti        $at, $v0, 0x5B
    ctx->r1 = SIGNED(ctx->r2) < 0X5B ? 1 : 0;
    skip_5:
    // 0x802F6BD8: addiu       $v0, $v0, 0xB4
    ctx->r2 = ADD32(ctx->r2, 0XB4);
L_802F6BDC:
    // 0x802F6BDC: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802F6BE0: sra         $v0, $t3, 16
    ctx->r2 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F6BE4: slti        $at, $v0, -0x5A
    ctx->r1 = SIGNED(ctx->r2) < -0X5A ? 1 : 0;
    // 0x802F6BE8: bnel        $at, $zero, L_802F6BDC
    if (ctx->r1 != 0) {
        // 0x802F6BEC: addiu       $v0, $v0, 0xB4
        ctx->r2 = ADD32(ctx->r2, 0XB4);
            goto L_802F6BDC;
    }
    goto skip_6;
    // 0x802F6BEC: addiu       $v0, $v0, 0xB4
    ctx->r2 = ADD32(ctx->r2, 0XB4);
    skip_6:
    // 0x802F6BF0: slti        $at, $v0, 0x5B
    ctx->r1 = SIGNED(ctx->r2) < 0X5B ? 1 : 0;
L_802F6BF4:
    // 0x802F6BF4: bnel        $at, $zero, L_802F6C18
    if (ctx->r1 != 0) {
        // 0x802F6BF8: lui         $at, 0x4024
        ctx->r1 = S32(0X4024 << 16);
            goto L_802F6C18;
    }
    goto skip_7;
    // 0x802F6BF8: lui         $at, 0x4024
    ctx->r1 = S32(0X4024 << 16);
    skip_7:
    // 0x802F6BFC: addiu       $v0, $v0, -0xB4
    ctx->r2 = ADD32(ctx->r2, -0XB4);
L_802F6C00:
    // 0x802F6C00: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x802F6C04: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F6C08: slti        $at, $v0, 0x5B
    ctx->r1 = SIGNED(ctx->r2) < 0X5B ? 1 : 0;
    // 0x802F6C0C: beql        $at, $zero, L_802F6C00
    if (ctx->r1 == 0) {
        // 0x802F6C10: addiu       $v0, $v0, -0xB4
        ctx->r2 = ADD32(ctx->r2, -0XB4);
            goto L_802F6C00;
    }
    goto skip_8;
    // 0x802F6C10: addiu       $v0, $v0, -0xB4
    ctx->r2 = ADD32(ctx->r2, -0XB4);
    skip_8:
    // 0x802F6C14: lui         $at, 0x4024
    ctx->r1 = S32(0X4024 << 16);
L_802F6C18:
    // 0x802F6C18: mtc1        $at, $f13
    ctx->f_odd[(13 - 1) * 2] = ctx->r1;
    // 0x802F6C1C: mtc1        $zero, $f12
    ctx->f12.u32l = 0;
    // 0x802F6C20: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802F6C24: addu        $t3, $v1, $v0
    ctx->r11 = ADD32(ctx->r3, ctx->r2);
    // 0x802F6C28: c.lt.d      $f12, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f12.d < ctx->f0.d;
    // 0x802F6C2C: nop

    // 0x802F6C30: bc1fl       L_802F6C54
    if (!c1cs) {
        // 0x802F6C34: trunc.w.d   $f4, $f0
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_D(ctx->f0.d);
            goto L_802F6C54;
    }
    goto skip_9;
    // 0x802F6C34: trunc.w.d   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_D(ctx->f0.d);
    skip_9:
    // 0x802F6C38: trunc.w.d   $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    ctx->f10.u32l = TRUNC_W_D(ctx->f12.d);
    // 0x802F6C3C: mfc1        $a2, $f10
    ctx->r6 = (int32_t)ctx->f10.u32l;
    // 0x802F6C40: nop

    // 0x802F6C44: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802F6C48: b           L_802F6C64
    // 0x802F6C4C: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802F6C64;
    // 0x802F6C4C: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F6C50: trunc.w.d   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_D(ctx->f0.d);
L_802F6C54:
    // 0x802F6C54: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x802F6C58: nop

    // 0x802F6C5C: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x802F6C60: sra         $a2, $t1, 16
    ctx->r6 = S32(SIGNED(ctx->r9) >> 16);
L_802F6C64:
    // 0x802F6C64: bgez        $v0, L_802F6C74
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F6C68: nop
    
            goto L_802F6C74;
    }
    // 0x802F6C68: nop

    // 0x802F6C6C: b           L_802F6C74
    // 0x802F6C70: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802F6C74;
    // 0x802F6C70: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802F6C74:
    // 0x802F6C74: slt         $at, $a2, $a1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802F6C78: bne         $at, $zero, L_802F6C88
    if (ctx->r1 != 0) {
        // 0x802F6C7C: nop
    
            goto L_802F6C88;
    }
    // 0x802F6C7C: nop

    // 0x802F6C80: b           L_802F6CA0
    // 0x802F6C84: sh          $t3, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r11;
        goto L_802F6CA0;
    // 0x802F6C84: sh          $t3, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r11;
L_802F6C88:
    // 0x802F6C88: bgez        $v0, L_802F6C9C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F6C8C: addu        $t5, $v1, $a2
        ctx->r13 = ADD32(ctx->r3, ctx->r6);
            goto L_802F6C9C;
    }
    // 0x802F6C8C: addu        $t5, $v1, $a2
    ctx->r13 = ADD32(ctx->r3, ctx->r6);
    // 0x802F6C90: subu        $t4, $v1, $a2
    ctx->r12 = SUB32(ctx->r3, ctx->r6);
    // 0x802F6C94: b           L_802F6CA0
    // 0x802F6C98: sh          $t4, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r12;
        goto L_802F6CA0;
    // 0x802F6C98: sh          $t4, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r12;
L_802F6C9C:
    // 0x802F6C9C: sh          $t5, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r13;
L_802F6CA0:
    // 0x802F6CA0: lh          $t6, 0x2C($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2C);
L_802F6CA4:
    // 0x802F6CA4: mfc1        $t0, $f6
    ctx->r8 = (int32_t)ctx->f6.u32l;
    // 0x802F6CA8: nop

    // 0x802F6CAC: subu        $v0, $t6, $t0
    ctx->r2 = SUB32(ctx->r14, ctx->r8);
    // 0x802F6CB0: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x802F6CB4: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F6CB8: slti        $at, $v0, -0xB4
    ctx->r1 = SIGNED(ctx->r2) < -0XB4 ? 1 : 0;
    // 0x802F6CBC: beql        $at, $zero, L_802F6CE0
    if (ctx->r1 == 0) {
        // 0x802F6CC0: slti        $at, $v0, 0xB5
        ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
            goto L_802F6CE0;
    }
    goto skip_10;
    // 0x802F6CC0: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    skip_10:
    // 0x802F6CC4: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
L_802F6CC8:
    // 0x802F6CC8: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802F6CCC: sra         $v0, $t3, 16
    ctx->r2 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F6CD0: slti        $at, $v0, -0xB4
    ctx->r1 = SIGNED(ctx->r2) < -0XB4 ? 1 : 0;
    // 0x802F6CD4: bnel        $at, $zero, L_802F6CC8
    if (ctx->r1 != 0) {
        // 0x802F6CD8: addiu       $v0, $v0, 0x168
        ctx->r2 = ADD32(ctx->r2, 0X168);
            goto L_802F6CC8;
    }
    goto skip_11;
    // 0x802F6CD8: addiu       $v0, $v0, 0x168
    ctx->r2 = ADD32(ctx->r2, 0X168);
    skip_11:
    // 0x802F6CDC: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
L_802F6CE0:
    // 0x802F6CE0: bne         $at, $zero, L_802F6D00
    if (ctx->r1 != 0) {
        // 0x802F6CE4: nop
    
            goto L_802F6D00;
    }
    // 0x802F6CE4: nop

    // 0x802F6CE8: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
L_802F6CEC:
    // 0x802F6CEC: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x802F6CF0: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F6CF4: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    // 0x802F6CF8: beql        $at, $zero, L_802F6CEC
    if (ctx->r1 == 0) {
        // 0x802F6CFC: addiu       $v0, $v0, -0x168
        ctx->r2 = ADD32(ctx->r2, -0X168);
            goto L_802F6CEC;
    }
    goto skip_12;
    // 0x802F6CFC: addiu       $v0, $v0, -0x168
    ctx->r2 = ADD32(ctx->r2, -0X168);
    skip_12:
L_802F6D00:
    // 0x802F6D00: bgez        $v0, L_802F6D10
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F6D04: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802F6D10;
    }
    // 0x802F6D04: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802F6D08: b           L_802F6D10
    // 0x802F6D0C: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802F6D10;
    // 0x802F6D0C: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802F6D10:
    // 0x802F6D10: slti        $at, $a1, 0x5A
    ctx->r1 = SIGNED(ctx->r5) < 0X5A ? 1 : 0;
    // 0x802F6D14: beq         $at, $zero, L_802F6D40
    if (ctx->r1 == 0) {
        // 0x802F6D18: lui         $at, 0x803C
        ctx->r1 = S32(0X803C << 16);
            goto L_802F6D40;
    }
    // 0x802F6D18: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F6D1C: ldc1        $f8, -0x3118($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, -0X3118);
    // 0x802F6D20: lh          $t8, 0x2E($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X2E);
    // 0x802F6D24: mul.d       $f10, $f2, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = MUL_D(ctx->f2.d, ctx->f8.d);
    // 0x802F6D28: trunc.w.d   $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = TRUNC_W_D(ctx->f10.d);
    // 0x802F6D2C: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x802F6D30: nop

    // 0x802F6D34: subu        $t2, $t8, $t1
    ctx->r10 = SUB32(ctx->r24, ctx->r9);
    // 0x802F6D38: b           L_802F6D64
    // 0x802F6D3C: sh          $t2, 0x2E($a0)
    MEM_H(0X2E, ctx->r4) = ctx->r10;
        goto L_802F6D64;
    // 0x802F6D3C: sh          $t2, 0x2E($a0)
    MEM_H(0X2E, ctx->r4) = ctx->r10;
L_802F6D40:
    // 0x802F6D40: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F6D44: ldc1        $f6, -0x3110($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X3110);
    // 0x802F6D48: lh          $t3, 0x2E($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X2E);
    // 0x802F6D4C: mul.d       $f8, $f2, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f2.d, ctx->f6.d);
    // 0x802F6D50: trunc.w.d   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_D(ctx->f8.d);
    // 0x802F6D54: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x802F6D58: nop

    // 0x802F6D5C: addu        $t6, $t3, $t9
    ctx->r14 = ADD32(ctx->r11, ctx->r25);
    // 0x802F6D60: sh          $t6, 0x2E($a0)
    MEM_H(0X2E, ctx->r4) = ctx->r14;
L_802F6D64:
    // 0x802F6D64: lh          $v0, 0x2E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X2E);
    // 0x802F6D68: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x802F6D6C: bne         $at, $zero, L_802F6D88
    if (ctx->r1 != 0) {
        // 0x802F6D70: addiu       $t0, $v0, -0x168
        ctx->r8 = ADD32(ctx->r2, -0X168);
            goto L_802F6D88;
    }
    // 0x802F6D70: addiu       $t0, $v0, -0x168
    ctx->r8 = ADD32(ctx->r2, -0X168);
L_802F6D74:
    // 0x802F6D74: sh          $t0, 0x2E($a0)
    MEM_H(0X2E, ctx->r4) = ctx->r8;
    // 0x802F6D78: lh          $v0, 0x2E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X2E);
    // 0x802F6D7C: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x802F6D80: beql        $at, $zero, L_802F6D74
    if (ctx->r1 == 0) {
        // 0x802F6D84: addiu       $t0, $v0, -0x168
        ctx->r8 = ADD32(ctx->r2, -0X168);
            goto L_802F6D74;
    }
    goto skip_13;
    // 0x802F6D84: addiu       $t0, $v0, -0x168
    ctx->r8 = ADD32(ctx->r2, -0X168);
    skip_13:
L_802F6D88:
    // 0x802F6D88: bgez        $v0, L_802F6DA0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F6D8C: addiu       $t8, $v0, 0x168
        ctx->r24 = ADD32(ctx->r2, 0X168);
            goto L_802F6DA0;
    }
    // 0x802F6D8C: addiu       $t8, $v0, 0x168
    ctx->r24 = ADD32(ctx->r2, 0X168);
L_802F6D90:
    // 0x802F6D90: sh          $t8, 0x2E($a0)
    MEM_H(0X2E, ctx->r4) = ctx->r24;
    // 0x802F6D94: lh          $v0, 0x2E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X2E);
    // 0x802F6D98: bltzl       $v0, L_802F6D90
    if (SIGNED(ctx->r2) < 0) {
        // 0x802F6D9C: addiu       $t8, $v0, 0x168
        ctx->r24 = ADD32(ctx->r2, 0X168);
            goto L_802F6D90;
    }
    goto skip_14;
    // 0x802F6D9C: addiu       $t8, $v0, 0x168
    ctx->r24 = ADD32(ctx->r2, 0X168);
    skip_14:
L_802F6DA0:
    // 0x802F6DA0: lh          $v1, 0x2C($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X2C);
    // 0x802F6DA4: slti        $at, $v1, 0x168
    ctx->r1 = SIGNED(ctx->r3) < 0X168 ? 1 : 0;
    // 0x802F6DA8: bne         $at, $zero, L_802F6DC4
    if (ctx->r1 != 0) {
        // 0x802F6DAC: addiu       $t1, $v1, -0x168
        ctx->r9 = ADD32(ctx->r3, -0X168);
            goto L_802F6DC4;
    }
    // 0x802F6DAC: addiu       $t1, $v1, -0x168
    ctx->r9 = ADD32(ctx->r3, -0X168);
L_802F6DB0:
    // 0x802F6DB0: sh          $t1, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r9;
    // 0x802F6DB4: lh          $v1, 0x2C($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X2C);
    // 0x802F6DB8: slti        $at, $v1, 0x168
    ctx->r1 = SIGNED(ctx->r3) < 0X168 ? 1 : 0;
    // 0x802F6DBC: beql        $at, $zero, L_802F6DB0
    if (ctx->r1 == 0) {
        // 0x802F6DC0: addiu       $t1, $v1, -0x168
        ctx->r9 = ADD32(ctx->r3, -0X168);
            goto L_802F6DB0;
    }
    goto skip_15;
    // 0x802F6DC0: addiu       $t1, $v1, -0x168
    ctx->r9 = ADD32(ctx->r3, -0X168);
    skip_15:
L_802F6DC4:
    // 0x802F6DC4: bgez        $v1, L_802F6DDC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F6DC8: addiu       $t2, $v1, 0x168
        ctx->r10 = ADD32(ctx->r3, 0X168);
            goto L_802F6DDC;
    }
    // 0x802F6DC8: addiu       $t2, $v1, 0x168
    ctx->r10 = ADD32(ctx->r3, 0X168);
L_802F6DCC:
    // 0x802F6DCC: sh          $t2, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r10;
    // 0x802F6DD0: lh          $v1, 0x2C($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X2C);
    // 0x802F6DD4: bltzl       $v1, L_802F6DCC
    if (SIGNED(ctx->r3) < 0) {
        // 0x802F6DD8: addiu       $t2, $v1, 0x168
        ctx->r10 = ADD32(ctx->r3, 0X168);
            goto L_802F6DCC;
    }
    goto skip_16;
    // 0x802F6DD8: addiu       $t2, $v1, 0x168
    ctx->r10 = ADD32(ctx->r3, 0X168);
    skip_16:
L_802F6DDC:
    // 0x802F6DDC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802F6DE0:
    // 0x802F6DE0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802F6DE4: jr          $ra
    // 0x802F6DE8: nop

    return;
    // 0x802F6DE8: nop

;}
RECOMP_FUNC void func_802F6DEC_70849C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F6DEC: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x802F6DF0: sw          $a1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r5;
    // 0x802F6DF4: lh          $t6, 0x76($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X76);
    // 0x802F6DF8: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x802F6DFC: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F6E00: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802F6E04: lh          $t9, 0x2C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2C);
    // 0x802F6E08: lh          $a3, 0x2E($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2E);
    // 0x802F6E0C: addiu       $t0, $sp, 0x68
    ctx->r8 = ADD32(ctx->r29, 0X68);
    // 0x802F6E10: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x802F6E14: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F6E18: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802F6E1C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802F6E20: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F6E24: jal         0x802F5F44
    // 0x802F6E28: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_0;
    // 0x802F6E28: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_0:
    // 0x802F6E2C: lh          $t1, 0x68($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X68);
    // 0x802F6E30: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x802F6E34: lh          $t5, 0x6A($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X6A);
    // 0x802F6E38: sll         $t2, $t1, 8
    ctx->r10 = S32(ctx->r9 << 8);
    // 0x802F6E3C: subu        $t4, $t2, $t3
    ctx->r12 = SUB32(ctx->r10, ctx->r11);
    // 0x802F6E40: sw          $t4, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r12;
    // 0x802F6E44: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802F6E48: lh          $t8, 0x6C($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X6C);
    // 0x802F6E4C: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x802F6E50: lw          $t0, 0x24($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X24);
    // 0x802F6E54: subu        $v0, $t6, $t7
    ctx->r2 = SUB32(ctx->r14, ctx->r15);
    // 0x802F6E58: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x802F6E5C: sra         $a2, $v0, 31
    ctx->r6 = S32(SIGNED(ctx->r2) >> 31);
    // 0x802F6E60: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x802F6E64: sw          $t1, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r9;
    // 0x802F6E68: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802F6E6C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    // 0x802F6E70: sw          $v0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r2;
    // 0x802F6E74: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802F6E78: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    // 0x802F6E7C: jal         0x80137CB8
    // 0x802F6E80: sw          $v0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r2;
    __ll_mul_recomp(rdram, ctx);
        goto after_1;
    // 0x802F6E80: sw          $v0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r2;
    after_1:
    // 0x802F6E84: lw          $a3, 0x58($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X58);
    // 0x802F6E88: sw          $v0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r2;
    // 0x802F6E8C: sw          $v1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r3;
    // 0x802F6E90: sra         $a2, $a3, 31
    ctx->r6 = S32(SIGNED(ctx->r7) >> 31);
    // 0x802F6E94: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802F6E98: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    // 0x802F6E9C: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802F6EA0: jal         0x80137CB8
    // 0x802F6EA4: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_2;
    // 0x802F6EA4: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    after_2:
    // 0x802F6EA8: lw          $a3, 0x60($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X60);
    // 0x802F6EAC: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x802F6EB0: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x802F6EB4: sra         $a2, $a3, 31
    ctx->r6 = S32(SIGNED(ctx->r7) >> 31);
    // 0x802F6EB8: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802F6EBC: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    // 0x802F6EC0: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802F6EC4: jal         0x80137CB8
    // 0x802F6EC8: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_3;
    // 0x802F6EC8: or          $a1, $a3, $zero
    ctx->r5 = ctx->r7 | 0;
    after_3:
    // 0x802F6ECC: lw          $t3, 0x44($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X44);
    // 0x802F6ED0: lw          $t7, 0x3C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X3C);
    // 0x802F6ED4: lw          $t2, 0x40($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X40);
    // 0x802F6ED8: addu        $t5, $v1, $t3
    ctx->r13 = ADD32(ctx->r3, ctx->r11);
    // 0x802F6EDC: sltu        $at, $t5, $t3
    ctx->r1 = ctx->r13 < ctx->r11 ? 1 : 0;
    // 0x802F6EE0: addu        $t4, $at, $v0
    ctx->r12 = ADD32(ctx->r1, ctx->r2);
    // 0x802F6EE4: addu        $a1, $t5, $t7
    ctx->r5 = ADD32(ctx->r13, ctx->r15);
    // 0x802F6EE8: lw          $t6, 0x38($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X38);
    // 0x802F6EEC: sltu        $at, $a1, $t7
    ctx->r1 = ctx->r5 < ctx->r15 ? 1 : 0;
    // 0x802F6EF0: addu        $t4, $t4, $t2
    ctx->r12 = ADD32(ctx->r12, ctx->r10);
    // 0x802F6EF4: addu        $a0, $at, $t4
    ctx->r4 = ADD32(ctx->r1, ctx->r12);
    // 0x802F6EF8: jal         0x8013F25C
    // 0x802F6EFC: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    __ll_to_f_recomp(rdram, ctx);
        goto after_4;
    // 0x802F6EFC: addu        $a0, $a0, $t6
    ctx->r4 = ADD32(ctx->r4, ctx->r14);
    after_4:
    // 0x802F6F00: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F6F04: lui         $v1, 0x5
    ctx->r3 = S32(0X5 << 16);
    // 0x802F6F08: lw          $t2, 0x58($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X58);
    // 0x802F6F0C: lw          $t1, 0x58($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X58);
    // 0x802F6F10: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802F6F14: mfc1        $v0, $f4
    ctx->r2 = (int32_t)ctx->f4.u32l;
    // 0x802F6F18: nop

    // 0x802F6F1C: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802F6F20: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F6F24: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F6F28: beq         $at, $zero, L_802F6F60
    if (ctx->r1 == 0) {
        // 0x802F6F2C: nop
    
            goto L_802F6F60;
    }
    // 0x802F6F2C: nop

    // 0x802F6F30: lw          $t1, 0x1C($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X1C);
    // 0x802F6F34: lw          $t4, 0x20($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X20);
    // 0x802F6F38: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x802F6F3C: addu        $t3, $t1, $t2
    ctx->r11 = ADD32(ctx->r9, ctx->r10);
    // 0x802F6F40: sw          $t3, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r11;
    // 0x802F6F44: lw          $t5, 0x5C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X5C);
    // 0x802F6F48: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802F6F4C: sw          $t6, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r14;
    // 0x802F6F50: lw          $t8, 0x60($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X60);
    // 0x802F6F54: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x802F6F58: b           L_802F7040
    // 0x802F6F5C: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
        goto L_802F7040;
    // 0x802F6F5C: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
L_802F6F60:
    // 0x802F6F60: multu       $t1, $v1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6F64: lw          $t0, 0x1C($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X1C);
    // 0x802F6F68: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x802F6F6C: lw          $t1, 0x24($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X24);
    // 0x802F6F70: mflo        $t2
    ctx->r10 = lo;
    // 0x802F6F74: nop

    // 0x802F6F78: nop

    // 0x802F6F7C: div         $zero, $t2, $v0
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r2)));
    // 0x802F6F80: mflo        $t3
    ctx->r11 = lo;
    // 0x802F6F84: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x802F6F88: sw          $t4, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r12;
    // 0x802F6F8C: lw          $t6, 0x5C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X5C);
    // 0x802F6F90: bne         $v0, $zero, L_802F6F9C
    if (ctx->r2 != 0) {
        // 0x802F6F94: nop
    
            goto L_802F6F9C;
    }
    // 0x802F6F94: nop

    // 0x802F6F98: break       7
    do_break(2150592408);
L_802F6F9C:
    // 0x802F6F9C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F6FA0: bne         $v0, $at, L_802F6FB4
    if (ctx->r2 != ctx->r1) {
        // 0x802F6FA4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F6FB4;
    }
    // 0x802F6FA4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F6FA8: bne         $t2, $at, L_802F6FB4
    if (ctx->r10 != ctx->r1) {
        // 0x802F6FAC: nop
    
            goto L_802F6FB4;
    }
    // 0x802F6FAC: nop

    // 0x802F6FB0: break       6
    do_break(2150592432);
L_802F6FB4:
    // 0x802F6FB4: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F6FB8: mflo        $t7
    ctx->r15 = lo;
    // 0x802F6FBC: nop

    // 0x802F6FC0: nop

    // 0x802F6FC4: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x802F6FC8: mflo        $t8
    ctx->r24 = lo;
    // 0x802F6FCC: addu        $t9, $t5, $t8
    ctx->r25 = ADD32(ctx->r13, ctx->r24);
    // 0x802F6FD0: sw          $t9, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r25;
    // 0x802F6FD4: lw          $t2, 0x60($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X60);
    // 0x802F6FD8: bne         $v0, $zero, L_802F6FE4
    if (ctx->r2 != 0) {
        // 0x802F6FDC: nop
    
            goto L_802F6FE4;
    }
    // 0x802F6FDC: nop

    // 0x802F6FE0: break       7
    do_break(2150592480);
L_802F6FE4:
    // 0x802F6FE4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F6FE8: bne         $v0, $at, L_802F6FFC
    if (ctx->r2 != ctx->r1) {
        // 0x802F6FEC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F6FFC;
    }
    // 0x802F6FEC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F6FF0: bne         $t7, $at, L_802F6FFC
    if (ctx->r15 != ctx->r1) {
        // 0x802F6FF4: nop
    
            goto L_802F6FFC;
    }
    // 0x802F6FF4: nop

    // 0x802F6FF8: break       6
    do_break(2150592504);
L_802F6FFC:
    // 0x802F6FFC: multu       $t2, $v1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7000: mflo        $t0
    ctx->r8 = lo;
    // 0x802F7004: nop

    // 0x802F7008: nop

    // 0x802F700C: div         $zero, $t0, $v0
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r2)));
    // 0x802F7010: mflo        $t3
    ctx->r11 = lo;
    // 0x802F7014: addu        $t4, $t1, $t3
    ctx->r12 = ADD32(ctx->r9, ctx->r11);
    // 0x802F7018: sw          $t4, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r12;
    // 0x802F701C: bne         $v0, $zero, L_802F7028
    if (ctx->r2 != 0) {
        // 0x802F7020: nop
    
            goto L_802F7028;
    }
    // 0x802F7020: nop

    // 0x802F7024: break       7
    do_break(2150592548);
L_802F7028:
    // 0x802F7028: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F702C: bne         $v0, $at, L_802F7040
    if (ctx->r2 != ctx->r1) {
        // 0x802F7030: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F7040;
    }
    // 0x802F7030: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F7034: bne         $t0, $at, L_802F7040
    if (ctx->r8 != ctx->r1) {
        // 0x802F7038: nop
    
            goto L_802F7040;
    }
    // 0x802F7038: nop

    // 0x802F703C: break       6
    do_break(2150592572);
L_802F7040:
    // 0x802F7040: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x802F7044: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x802F7048: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    // 0x802F704C: jr          $ra
    // 0x802F7050: nop

    return;
    // 0x802F7050: nop

;}
RECOMP_FUNC void func_802F7054_708704(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F7054: jr          $ra
    // 0x802F7058: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    return;
    // 0x802F7058: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
;}
RECOMP_FUNC void func_802F705C_70870C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F705C: addiu       $sp, $sp, -0x140
    ctx->r29 = ADD32(ctx->r29, -0X140);
    // 0x802F7060: sw          $s0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r16;
    // 0x802F7064: lh          $s0, 0x152($sp)
    ctx->r16 = MEM_H(ctx->r29, 0X152);
    // 0x802F7068: sw          $s5, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r21;
    // 0x802F706C: sw          $s3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r19;
    // 0x802F7070: sw          $s1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r17;
    // 0x802F7074: sll         $s1, $a1, 16
    ctx->r17 = S32(ctx->r5 << 16);
    // 0x802F7078: sll         $s3, $a2, 16
    ctx->r19 = S32(ctx->r6 << 16);
    // 0x802F707C: sll         $s5, $a3, 16
    ctx->r21 = S32(ctx->r7 << 16);
    // 0x802F7080: sra         $t8, $s5, 16
    ctx->r24 = S32(SIGNED(ctx->r21) >> 16);
    // 0x802F7084: sra         $t7, $s3, 16
    ctx->r15 = S32(SIGNED(ctx->r19) >> 16);
    // 0x802F7088: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x802F708C: sw          $s2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r18;
    // 0x802F7090: or          $s2, $a0, $zero
    ctx->r18 = ctx->r4 | 0;
    // 0x802F7094: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
    // 0x802F7098: or          $s3, $t7, $zero
    ctx->r19 = ctx->r15 | 0;
    // 0x802F709C: or          $s5, $t8, $zero
    ctx->r21 = ctx->r24 | 0;
    // 0x802F70A0: sw          $ra, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r31;
    // 0x802F70A4: sw          $fp, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r30;
    // 0x802F70A8: sw          $s7, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r23;
    // 0x802F70AC: sw          $s6, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r22;
    // 0x802F70B0: sw          $s4, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r20;
    // 0x802F70B4: sdc1        $f30, 0x58($sp)
    CHECK_FR(ctx, 30);
    SD(ctx->f30.u64, 0X58, ctx->r29);
    // 0x802F70B8: sdc1        $f28, 0x50($sp)
    CHECK_FR(ctx, 28);
    SD(ctx->f28.u64, 0X50, ctx->r29);
    // 0x802F70BC: sdc1        $f26, 0x48($sp)
    CHECK_FR(ctx, 26);
    SD(ctx->f26.u64, 0X48, ctx->r29);
    // 0x802F70C0: sdc1        $f24, 0x40($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X40, ctx->r29);
    // 0x802F70C4: sdc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X38, ctx->r29);
    // 0x802F70C8: sdc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X30, ctx->r29);
    // 0x802F70CC: sw          $a1, 0x144($sp)
    MEM_W(0X144, ctx->r29) = ctx->r5;
    // 0x802F70D0: sw          $a2, 0x148($sp)
    MEM_W(0X148, ctx->r29) = ctx->r6;
    // 0x802F70D4: beq         $s0, $zero, L_802F78F8
    if (ctx->r16 == 0) {
        // 0x802F70D8: sw          $a3, 0x14C($sp)
        MEM_W(0X14C, ctx->r29) = ctx->r7;
            goto L_802F78F8;
    }
    // 0x802F70D8: sw          $a3, 0x14C($sp)
    MEM_W(0X14C, ctx->r29) = ctx->r7;
    // 0x802F70DC: lhu         $s4, 0x15E($sp)
    ctx->r20 = MEM_HU(ctx->r29, 0X15E);
    // 0x802F70E0: andi        $v0, $s4, 0x200
    ctx->r2 = ctx->r20 & 0X200;
    // 0x802F70E4: beq         $v0, $zero, L_802F710C
    if (ctx->r2 == 0) {
        // 0x802F70E8: andi        $t9, $s4, 0x100
        ctx->r25 = ctx->r20 & 0X100;
            goto L_802F710C;
    }
    // 0x802F70E8: andi        $t9, $s4, 0x100
    ctx->r25 = ctx->r20 & 0X100;
    // 0x802F70EC: mtc1        $s0, $f4
    ctx->f4.u32l = ctx->r16;
    // 0x802F70F0: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802F70F4: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802F70F8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F70FC: mtc1        $zero, $f26
    ctx->f26.u32l = 0;
    // 0x802F7100: div.s       $f18, $f6, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802F7104: b           L_802F7140
    // 0x802F7108: neg.s       $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = -ctx->f18.fl;
        goto L_802F7140;
    // 0x802F7108: neg.s       $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = -ctx->f18.fl;
L_802F710C:
    // 0x802F710C: beql        $t9, $zero, L_802F7134
    if (ctx->r25 == 0) {
        // 0x802F7110: mtc1        $zero, $f26
        ctx->f26.u32l = 0;
            goto L_802F7134;
    }
    goto skip_0;
    // 0x802F7110: mtc1        $zero, $f26
    ctx->f26.u32l = 0;
    skip_0:
    // 0x802F7114: mtc1        $s0, $f8
    ctx->f8.u32l = ctx->r16;
    // 0x802F7118: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802F711C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802F7120: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F7124: mtc1        $zero, $f26
    ctx->f26.u32l = 0;
    // 0x802F7128: b           L_802F7140
    // 0x802F712C: div.s       $f18, $f10, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
        goto L_802F7140;
    // 0x802F712C: div.s       $f18, $f10, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802F7130: mtc1        $zero, $f26
    ctx->f26.u32l = 0;
L_802F7134:
    // 0x802F7134: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802F7138: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802F713C: mov.s       $f18, $f26
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 26);
    ctx->f18.fl = ctx->f26.fl;
L_802F7140:
    // 0x802F7140: beq         $v0, $zero, L_802F7160
    if (ctx->r2 == 0) {
        // 0x802F7144: andi        $t5, $s4, 0x100
        ctx->r13 = ctx->r20 & 0X100;
            goto L_802F7160;
    }
    // 0x802F7144: andi        $t5, $s4, 0x100
    ctx->r13 = ctx->r20 & 0X100;
    // 0x802F7148: mtc1        $s0, $f4
    ctx->f4.u32l = ctx->r16;
    // 0x802F714C: nop

    // 0x802F7150: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F7154: div.s       $f30, $f6, $f0
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f30.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802F7158: b           L_802F7180
    // 0x802F715C: neg.s       $f30, $f30
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 30);
    NAN_CHECK(ctx->f30.fl); 
    ctx->f30.fl = -ctx->f30.fl;
        goto L_802F7180;
    // 0x802F715C: neg.s       $f30, $f30
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 30);
    NAN_CHECK(ctx->f30.fl); 
    ctx->f30.fl = -ctx->f30.fl;
L_802F7160:
    // 0x802F7160: beql        $t5, $zero, L_802F7180
    if (ctx->r13 == 0) {
        // 0x802F7164: mov.s       $f30, $f26
        CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 26);
    ctx->f30.fl = ctx->f26.fl;
            goto L_802F7180;
    }
    goto skip_1;
    // 0x802F7164: mov.s       $f30, $f26
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 26);
    ctx->f30.fl = ctx->f26.fl;
    skip_1:
    // 0x802F7168: mtc1        $s0, $f8
    ctx->f8.u32l = ctx->r16;
    // 0x802F716C: nop

    // 0x802F7170: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F7174: b           L_802F7180
    // 0x802F7178: div.s       $f30, $f10, $f0
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f30.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
        goto L_802F7180;
    // 0x802F7178: div.s       $f30, $f10, $f0
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f30.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802F717C: mov.s       $f30, $f26
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 26);
    ctx->f30.fl = ctx->f26.fl;
L_802F7180:
    // 0x802F7180: lh          $v0, 0x15A($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X15A);
    // 0x802F7184: bnel        $v0, $zero, L_802F71B0
    if (ctx->r2 != 0) {
        // 0x802F7188: mtc1        $v0, $f4
        ctx->f4.u32l = ctx->r2;
            goto L_802F71B0;
    }
    goto skip_2;
    // 0x802F7188: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    skip_2:
    // 0x802F718C: mtc1        $s0, $f4
    ctx->f4.u32l = ctx->r16;
    // 0x802F7190: lui         $at, 0x4280
    ctx->r1 = S32(0X4280 << 16);
    // 0x802F7194: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802F7198: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F719C: div.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802F71A0: mul.s       $f28, $f8, $f10
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f28.fl = MUL_S(ctx->f8.fl, ctx->f10.fl);
    // 0x802F71A4: b           L_802F71BC
    // 0x802F71A8: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
        goto L_802F71BC;
    // 0x802F71A8: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
    // 0x802F71AC: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
L_802F71B0:
    // 0x802F71B0: nop

    // 0x802F71B4: cvt.s.w     $f28, $f4
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 4);
    ctx->f28.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F71B8: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
L_802F71BC:
    // 0x802F71BC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802F71C0: lh          $a2, 0x4($s2)
    ctx->r6 = MEM_H(ctx->r18, 0X4);
    // 0x802F71C4: lh          $a3, 0x8($s2)
    ctx->r7 = MEM_H(ctx->r18, 0X8);
    // 0x802F71C8: div.s       $f0, $f28, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f28.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = DIV_S(ctx->f28.fl, ctx->f6.fl);
    // 0x802F71CC: sra         $t6, $a2, 10
    ctx->r14 = S32(SIGNED(ctx->r6) >> 10);
    // 0x802F71D0: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802F71D4: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F71D8: sra         $t9, $a3, 10
    ctx->r25 = S32(SIGNED(ctx->r7) >> 10);
    // 0x802F71DC: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x802F71E0: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F71E4: addiu       $fp, $sp, 0xC8
    ctx->r30 = ADD32(ctx->r29, 0XC8);
    // 0x802F71E8: neg.s       $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = -ctx->f0.fl;
    // 0x802F71EC: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802F71F0: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802F71F4: mfc1        $v1, $f4
    ctx->r3 = (int32_t)ctx->f4.u32l;
    // 0x802F71F8: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x802F71FC: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x802F7200: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x802F7204: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x802F7208: sra         $t8, $t2, 16
    ctx->r24 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802F720C: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
    // 0x802F7210: addiu       $t8, $a2, 0x1
    ctx->r24 = ADD32(ctx->r6, 0X1);
    // 0x802F7214: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802F7218: sra         $t9, $t0, 16
    ctx->r25 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F721C: sra         $t7, $t1, 16
    ctx->r15 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F7220: sra         $t6, $t3, 16
    ctx->r14 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F7224: slti        $at, $t8, 0x5
    ctx->r1 = SIGNED(ctx->r24) < 0X5 ? 1 : 0;
    // 0x802F7228: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
    // 0x802F722C: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
    // 0x802F7230: bne         $at, $zero, L_802F7244
    if (ctx->r1 != 0) {
        // 0x802F7234: or          $t1, $t7, $zero
        ctx->r9 = ctx->r15 | 0;
            goto L_802F7244;
    }
    // 0x802F7234: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
    // 0x802F7238: addiu       $t1, $v1, -0x1
    ctx->r9 = ADD32(ctx->r3, -0X1);
    // 0x802F723C: sll         $t5, $t1, 16
    ctx->r13 = S32(ctx->r9 << 16);
    // 0x802F7240: sra         $t1, $t5, 16
    ctx->r9 = S32(SIGNED(ctx->r13) >> 16);
L_802F7244:
    // 0x802F7244: bgtz        $a2, L_802F7258
    if (SIGNED(ctx->r6) > 0) {
        // 0x802F7248: addiu       $t5, $a3, 0x1
        ctx->r13 = ADD32(ctx->r7, 0X1);
            goto L_802F7258;
    }
    // 0x802F7248: addiu       $t5, $a3, 0x1
    ctx->r13 = ADD32(ctx->r7, 0X1);
    // 0x802F724C: addiu       $t0, $v0, 0x1
    ctx->r8 = ADD32(ctx->r2, 0X1);
    // 0x802F7250: sll         $t8, $t0, 16
    ctx->r24 = S32(ctx->r8 << 16);
    // 0x802F7254: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802F7258:
    // 0x802F7258: slti        $at, $t5, 0x8
    ctx->r1 = SIGNED(ctx->r13) < 0X8 ? 1 : 0;
    // 0x802F725C: bne         $at, $zero, L_802F7270
    if (ctx->r1 != 0) {
        // 0x802F7260: nop
    
            goto L_802F7270;
    }
    // 0x802F7260: nop

    // 0x802F7264: addiu       $t3, $v1, -0x1
    ctx->r11 = ADD32(ctx->r3, -0X1);
    // 0x802F7268: sll         $t7, $t3, 16
    ctx->r15 = S32(ctx->r11 << 16);
    // 0x802F726C: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
L_802F7270:
    // 0x802F7270: bgtz        $a3, L_802F7284
    if (SIGNED(ctx->r7) > 0) {
        // 0x802F7274: lui         $v1, 0x8015
        ctx->r3 = S32(0X8015 << 16);
            goto L_802F7284;
    }
    // 0x802F7274: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802F7278: addiu       $t2, $v0, 0x1
    ctx->r10 = ADD32(ctx->r2, 0X1);
    // 0x802F727C: sll         $t5, $t2, 16
    ctx->r13 = S32(ctx->r10 << 16);
    // 0x802F7280: sra         $t2, $t5, 16
    ctx->r10 = S32(SIGNED(ctx->r13) >> 16);
L_802F7284:
    // 0x802F7284: addiu       $v1, $v1, 0x2350
    ctx->r3 = ADD32(ctx->r3, 0X2350);
    // 0x802F7288: sll         $t7, $s1, 1
    ctx->r15 = S32(ctx->r17 << 1);
    // 0x802F728C: addu        $v0, $v1, $t7
    ctx->r2 = ADD32(ctx->r3, ctx->r15);
    // 0x802F7290: lh          $t8, 0x384($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X384);
    // 0x802F7294: lh          $t9, 0x2D0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2D0);
    // 0x802F7298: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802F729C: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x802F72A0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802F72A4: sll         $t5, $s3, 1
    ctx->r13 = S32(ctx->r19 << 1);
    // 0x802F72A8: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F72AC: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x802F72B0: addu        $a0, $v1, $t5
    ctx->r4 = ADD32(ctx->r3, ctx->r13);
    // 0x802F72B4: lh          $t6, 0x2D0($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X2D0);
    // 0x802F72B8: lh          $t7, 0x384($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X384);
    // 0x802F72BC: addu        $a1, $a2, $t0
    ctx->r5 = ADD32(ctx->r6, ctx->r8);
    // 0x802F72C0: div.s       $f4, $f8, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = DIV_S(ctx->f8.fl, ctx->f10.fl);
    // 0x802F72C4: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802F72C8: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802F72CC: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F72D0: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F72D4: addu        $t4, $a2, $t1
    ctx->r12 = ADD32(ctx->r6, ctx->r9);
    // 0x802F72D8: sh          $a1, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = ctx->r5;
    // 0x802F72DC: addu        $t5, $a3, $t2
    ctx->r13 = ADD32(ctx->r7, ctx->r10);
    // 0x802F72E0: div.s       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = DIV_S(ctx->f8.fl, ctx->f10.fl);
    // 0x802F72E4: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x802F72E8: swc1        $f4, 0xD8($sp)
    MEM_W(0XD8, ctx->r29) = ctx->f4.u32l;
    // 0x802F72EC: addu        $t6, $a3, $t3
    ctx->r14 = ADD32(ctx->r7, ctx->r11);
    // 0x802F72F0: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F72F4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802F72F8: swc1        $f6, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->f6.u32l;
    // 0x802F72FC: mul.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f4.fl);
    // 0x802F7300: div.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802F7304: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802F7308: nop

    // 0x802F730C: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F7310: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802F7314: slt         $at, $t4, $t9
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802F7318: swc1        $f10, 0xD4($sp)
    MEM_W(0XD4, ctx->r29) = ctx->f10.u32l;
    // 0x802F731C: mul.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802F7320: div.s       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f10.fl, ctx->f6.fl);
    // 0x802F7324: bne         $at, $zero, L_802F78F8
    if (ctx->r1 != 0) {
        // 0x802F7328: swc1        $f8, 0xD8($sp)
        MEM_W(0XD8, ctx->r29) = ctx->f8.u32l;
            goto L_802F78F8;
    }
    // 0x802F7328: swc1        $f8, 0xD8($sp)
    MEM_W(0XD8, ctx->r29) = ctx->f8.u32l;
    // 0x802F732C: sw          $t5, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r13;
    // 0x802F7330: lh          $t7, 0xA2($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XA2);
    // 0x802F7334: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x802F7338: mtc1        $at, $f24
    ctx->f24.u32l = ctx->r1;
    // 0x802F733C: sw          $t6, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r14;
    // 0x802F7340: sw          $t4, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r12;
    // 0x802F7344: lh          $s6, 0x156($sp)
    ctx->r22 = MEM_H(ctx->r29, 0X156);
    // 0x802F7348: sw          $t7, 0x98($sp)
    MEM_W(0X98, ctx->r29) = ctx->r15;
L_802F734C:
    // 0x802F734C: lw          $t9, 0x9C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X9C);
    // 0x802F7350: lw          $t5, 0x98($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X98);
    // 0x802F7354: lw          $t8, 0xA0($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XA0);
    // 0x802F7358: slt         $at, $t9, $t5
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802F735C: bne         $at, $zero, L_802F78D8
    if (ctx->r1 != 0) {
        // 0x802F7360: sh          $t8, 0x138($sp)
        MEM_H(0X138, ctx->r29) = ctx->r24;
            goto L_802F78D8;
    }
    // 0x802F7360: sh          $t8, 0x138($sp)
    MEM_H(0X138, ctx->r29) = ctx->r24;
L_802F7364:
    // 0x802F7364: lh          $t7, 0x138($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X138);
    // 0x802F7368: lh          $t6, 0x13A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X13A);
    // 0x802F736C: lui         $s3, 0x803E
    ctx->r19 = S32(0X803E << 16);
    // 0x802F7370: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x802F7374: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802F7378: addu        $s7, $t6, $t8
    ctx->r23 = ADD32(ctx->r14, ctx->r24);
    // 0x802F737C: sll         $t9, $s7, 16
    ctx->r25 = S32(ctx->r23 << 16);
    // 0x802F7380: sra         $s7, $t9, 16
    ctx->r23 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F7384: sll         $t7, $s7, 2
    ctx->r15 = S32(ctx->r23 << 2);
    // 0x802F7388: subu        $t7, $t7, $s7
    ctx->r15 = SUB32(ctx->r15, ctx->r23);
    // 0x802F738C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802F7390: addu        $s3, $s3, $t7
    ctx->r19 = ADD32(ctx->r19, ctx->r15);
    // 0x802F7394: lw          $s3, -0x5EF0($s3)
    ctx->r19 = MEM_W(ctx->r19, -0X5EF0);
    // 0x802F7398: beql        $s3, $zero, L_802F78BC
    if (ctx->r19 == 0) {
        // 0x802F739C: lh          $t8, 0x138($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X138);
            goto L_802F78BC;
    }
    goto skip_3;
    // 0x802F739C: lh          $t8, 0x138($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X138);
    skip_3:
    // 0x802F73A0: lw          $s0, 0x8($s3)
    ctx->r16 = MEM_W(ctx->r19, 0X8);
L_802F73A4:
    // 0x802F73A4: beql        $s0, $s2, L_802F78B0
    if (ctx->r16 == ctx->r18) {
        // 0x802F73A8: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_4;
    // 0x802F73A8: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_4:
    // 0x802F73AC: lw          $v0, 0x4C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4C);
    // 0x802F73B0: sll         $t8, $v0, 27
    ctx->r24 = S32(ctx->r2 << 27);
    // 0x802F73B4: bgez        $t8, L_802F78AC
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802F73B8: sll         $t5, $v0, 28
        ctx->r13 = S32(ctx->r2 << 28);
            goto L_802F78AC;
    }
    // 0x802F73B8: sll         $t5, $v0, 28
    ctx->r13 = S32(ctx->r2 << 28);
    // 0x802F73BC: bgezl       $t5, L_802F78B0
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802F73C0: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_5;
    // 0x802F73C0: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_5:
    // 0x802F73C4: lh          $t7, 0x114($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X114);
    // 0x802F73C8: bnel        $s7, $t7, L_802F78B0
    if (ctx->r23 != ctx->r15) {
        // 0x802F73CC: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_6;
    // 0x802F73CC: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_6:
    // 0x802F73D0: lh          $t6, 0x4($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X4);
    // 0x802F73D4: lh          $t8, 0x4($s2)
    ctx->r24 = MEM_H(ctx->r18, 0X4);
    // 0x802F73D8: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x802F73DC: lh          $t7, 0x8($s2)
    ctx->r15 = MEM_H(ctx->r18, 0X8);
    // 0x802F73E0: subu        $t9, $t6, $t8
    ctx->r25 = SUB32(ctx->r14, ctx->r24);
    // 0x802F73E4: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x802F73E8: lh          $t9, 0xC($s2)
    ctx->r25 = MEM_H(ctx->r18, 0XC);
    // 0x802F73EC: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x802F73F0: subu        $t6, $t5, $t7
    ctx->r14 = SUB32(ctx->r13, ctx->r15);
    // 0x802F73F4: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F73F8: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x802F73FC: subu        $t5, $t8, $t9
    ctx->r13 = SUB32(ctx->r24, ctx->r25);
    // 0x802F7400: subu        $t7, $t5, $s5
    ctx->r15 = SUB32(ctx->r13, ctx->r21);
    // 0x802F7404: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802F7408: cvt.s.w     $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    ctx->f14.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F740C: mul.s       $f8, $f12, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x802F7410: nop

    // 0x802F7414: mul.s       $f4, $f14, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x802F7418: cvt.s.w     $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    ctx->f16.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F741C: add.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f4.fl;
    // 0x802F7420: mul.s       $f6, $f16, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x802F7424: add.s       $f0, $f10, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802F7428: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F742C: c.lt.s      $f28, $f0
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f28.fl < ctx->f0.fl;
    // 0x802F7430: nop

    // 0x802F7434: bc1t        L_802F78AC
    if (c1cs) {
        // 0x802F7438: nop
    
            goto L_802F78AC;
    }
    // 0x802F7438: nop

    // 0x802F743C: c.eq.s      $f0, $f26
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f0.fl == ctx->f26.fl;
    // 0x802F7440: nop

    // 0x802F7444: bc1tl       L_802F78B0
    if (c1cs) {
        // 0x802F7448: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_7;
    // 0x802F7448: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_7:
    // 0x802F744C: div.s       $f8, $f12, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = DIV_S(ctx->f12.fl, ctx->f0.fl);
    // 0x802F7450: sra         $t8, $s6, 1
    ctx->r24 = S32(SIGNED(ctx->r22) >> 1);
    // 0x802F7454: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802F7458: andi        $t6, $s4, 0x8
    ctx->r14 = ctx->r20 & 0X8;
    // 0x802F745C: sra         $t5, $t9, 16
    ctx->r13 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F7460: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x802F7464: div.s       $f10, $f16, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = DIV_S(ctx->f16.fl, ctx->f0.fl);
    // 0x802F7468: swc1        $f8, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->f8.u32l;
    // 0x802F746C: lwc1        $f8, 0xD8($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XD8);
    // 0x802F7470: div.s       $f4, $f14, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = DIV_S(ctx->f14.fl, ctx->f0.fl);
    // 0x802F7474: swc1        $f10, 0xD0($sp)
    MEM_W(0XD0, ctx->r29) = ctx->f10.u32l;
    // 0x802F7478: lwc1        $f10, 0xD4($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XD4);
    // 0x802F747C: bne         $t6, $zero, L_802F74B0
    if (ctx->r14 != 0) {
        // 0x802F7480: swc1        $f4, 0xCC($sp)
        MEM_W(0XCC, ctx->r29) = ctx->f4.u32l;
            goto L_802F74B0;
    }
    // 0x802F7480: swc1        $f4, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->f4.u32l;
    // 0x802F7484: addu        $t6, $v1, $t7
    ctx->r14 = ADD32(ctx->r3, ctx->r15);
    // 0x802F7488: lh          $t8, 0x384($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X384);
    // 0x802F748C: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802F7490: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F7494: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x802F7498: mov.s       $f22, $f0
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 0);
    ctx->f22.fl = ctx->f0.fl;
    // 0x802F749C: or          $s1, $fp, $zero
    ctx->r17 = ctx->r30 | 0;
    // 0x802F74A0: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F74A4: andi        $v0, $s4, 0x300
    ctx->r2 = ctx->r20 & 0X300;
    // 0x802F74A8: b           L_802F75B0
    // 0x802F74AC: div.s       $f2, $f8, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f2.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
        goto L_802F75B0;
    // 0x802F74AC: div.s       $f2, $f8, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f2.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
L_802F74B0:
    // 0x802F74B0: mul.s       $f6, $f12, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = MUL_S(ctx->f12.fl, ctx->f10.fl);
    // 0x802F74B4: nop

    // 0x802F74B8: mul.s       $f4, $f14, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f8.fl);
    // 0x802F74BC: lwc1        $f8, 0xDC($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x802F74C0: add.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x802F74C4: mul.s       $f6, $f16, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f16.fl, ctx->f8.fl);
    // 0x802F74C8: add.s       $f2, $f10, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f2.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802F74CC: c.lt.s      $f28, $f2
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f28.fl < ctx->f2.fl;
    // 0x802F74D0: nop

    // 0x802F74D4: bc1t        L_802F78AC
    if (c1cs) {
        // 0x802F74D8: nop
    
            goto L_802F78AC;
    }
    // 0x802F74D8: nop

    // 0x802F74DC: c.le.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl <= ctx->f26.fl;
    // 0x802F74E0: lwc1        $f10, 0xD4($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XD4);
    // 0x802F74E4: bc1tl       L_802F78B0
    if (c1cs) {
        // 0x802F74E8: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_8;
    // 0x802F74E8: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_8:
    // 0x802F74EC: lh          $t9, 0x4($s2)
    ctx->r25 = MEM_H(ctx->r18, 0X4);
    // 0x802F74F0: mul.s       $f6, $f2, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = MUL_S(ctx->f2.fl, ctx->f10.fl);
    // 0x802F74F4: lh          $t5, 0x4($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X4);
    // 0x802F74F8: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x802F74FC: lh          $t7, 0x8($s2)
    ctx->r15 = MEM_H(ctx->r18, 0X8);
    // 0x802F7500: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x802F7504: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x802F7508: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F750C: lh          $t8, 0xC($s2)
    ctx->r24 = MEM_H(ctx->r18, 0XC);
    // 0x802F7510: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802F7514: mov.s       $f22, $f2
    CHECK_FR(ctx, 22);
    CHECK_FR(ctx, 2);
    ctx->f22.fl = ctx->f2.fl;
    // 0x802F7518: addiu       $s1, $sp, 0xD4
    ctx->r17 = ADD32(ctx->r29, 0XD4);
    // 0x802F751C: andi        $v0, $s4, 0x300
    ctx->r2 = ctx->r20 & 0X300;
    // 0x802F7520: add.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f8.fl + ctx->f6.fl;
    // 0x802F7524: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802F7528: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F752C: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F7530: sub.s       $f12, $f4, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x802F7534: lwc1        $f4, 0xD8($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0XD8);
    // 0x802F7538: mul.s       $f8, $f2, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f2.fl, ctx->f4.fl);
    // 0x802F753C: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802F7540: add.s       $f6, $f10, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802F7544: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802F7548: cvt.s.w     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F754C: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F7550: sub.s       $f14, $f6, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f14.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x802F7554: lwc1        $f6, 0xDC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x802F7558: mul.s       $f10, $f2, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f6.fl);
    // 0x802F755C: mtc1        $s5, $f6
    ctx->f6.u32l = ctx->r21;
    // 0x802F7560: add.s       $f8, $f4, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f10.fl;
    // 0x802F7564: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F7568: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x802F756C: add.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f4.fl;
    // 0x802F7570: mul.s       $f4, $f12, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x802F7574: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F7578: mul.s       $f6, $f14, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x802F757C: sub.s       $f16, $f10, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f10.fl - ctx->f8.fl;
    // 0x802F7580: add.s       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x802F7584: mul.s       $f8, $f16, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x802F7588: mtc1        $s6, $f4
    ctx->f4.u32l = ctx->r22;
    // 0x802F758C: nop

    // 0x802F7590: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F7594: add.s       $f0, $f10, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802F7598: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F759C: c.lt.s      $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f6.fl < ctx->f0.fl;
    // 0x802F75A0: nop

    // 0x802F75A4: bc1tl       L_802F78B0
    if (c1cs) {
        // 0x802F75A8: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_9;
    // 0x802F75A8: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_9:
    // 0x802F75AC: mov.s       $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    ctx->f2.fl = ctx->f26.fl;
L_802F75B0:
    // 0x802F75B0: beq         $v0, $zero, L_802F75FC
    if (ctx->r2 == 0) {
        // 0x802F75B4: lwc1        $f10, 0xC8($sp)
        ctx->f10.u32l = MEM_W(ctx->r29, 0XC8);
            goto L_802F75FC;
    }
    // 0x802F75B4: lwc1        $f10, 0xC8($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XC8);
    // 0x802F75B8: lwc1        $f8, 0xD4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XD4);
    // 0x802F75BC: lwc1        $f6, 0xCC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XCC);
    // 0x802F75C0: mul.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f8.fl);
    // 0x802F75C4: lwc1        $f10, 0xD8($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XD8);
    // 0x802F75C8: mul.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x802F75CC: lwc1        $f10, 0xD0($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XD0);
    // 0x802F75D0: add.s       $f6, $f4, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x802F75D4: lwc1        $f4, 0xDC($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x802F75D8: mul.s       $f8, $f10, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f4.fl);
    // 0x802F75DC: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x802F75E0: c.le.s      $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f2.fl <= ctx->f10.fl;
    // 0x802F75E4: nop

    // 0x802F75E8: bc1fl       L_802F7600
    if (!c1cs) {
        // 0x802F75EC: andi        $t5, $s4, 0x3
        ctx->r13 = ctx->r20 & 0X3;
            goto L_802F7600;
    }
    goto skip_10;
    // 0x802F75EC: andi        $t5, $s4, 0x3
    ctx->r13 = ctx->r20 & 0X3;
    skip_10:
    // 0x802F75F0: c.eq.s      $f18, $f26
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f18.fl == ctx->f26.fl;
    // 0x802F75F4: mov.s       $f20, $f18
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 18);
    ctx->f20.fl = ctx->f18.fl;
    // 0x802F75F8: bc1f        L_802F7650
    if (!c1cs) {
        // 0x802F75FC: andi        $t5, $s4, 0x3
        ctx->r13 = ctx->r20 & 0X3;
            goto L_802F7650;
    }
L_802F75FC:
    // 0x802F75FC: andi        $t5, $s4, 0x3
    ctx->r13 = ctx->r20 & 0X3;
L_802F7600:
    // 0x802F7600: beq         $t5, $zero, L_802F78AC
    if (ctx->r13 == 0) {
        // 0x802F7604: lwc1        $f6, 0xC8($sp)
        ctx->f6.u32l = MEM_W(ctx->r29, 0XC8);
            goto L_802F78AC;
    }
    // 0x802F7604: lwc1        $f6, 0xC8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XC8);
    // 0x802F7608: lwc1        $f8, 0xD4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XD4);
    // 0x802F760C: neg.s       $f4, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = -ctx->f2.fl;
    // 0x802F7610: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802F7614: lwc1        $f8, 0xD8($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XD8);
    // 0x802F7618: lwc1        $f6, 0xCC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XCC);
    // 0x802F761C: mul.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802F7620: add.s       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802F7624: lwc1        $f6, 0xDC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x802F7628: lwc1        $f10, 0xD0($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0XD0);
    // 0x802F762C: mul.s       $f10, $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f10.fl, ctx->f6.fl);
    // 0x802F7630: add.s       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x802F7634: c.le.s      $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f6.fl <= ctx->f4.fl;
    // 0x802F7638: nop

    // 0x802F763C: bc1fl       L_802F78B0
    if (!c1cs) {
        // 0x802F7640: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_11;
    // 0x802F7640: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_11:
    // 0x802F7644: c.eq.s      $f30, $f26
    CHECK_FR(ctx, 30);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f30.fl == ctx->f26.fl;
    // 0x802F7648: mov.s       $f20, $f30
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 30);
    ctx->f20.fl = ctx->f30.fl;
    // 0x802F764C: bc1t        L_802F78AC
    if (c1cs) {
        // 0x802F7650: andi        $t7, $s4, 0x4
        ctx->r15 = ctx->r20 & 0X4;
            goto L_802F78AC;
    }
L_802F7650:
    // 0x802F7650: andi        $t7, $s4, 0x4
    ctx->r15 = ctx->r20 & 0X4;
    // 0x802F7654: beql        $t7, $zero, L_802F76B0
    if (ctx->r15 == 0) {
        // 0x802F7658: lui         $at, 0x4080
        ctx->r1 = S32(0X4080 << 16);
            goto L_802F76B0;
    }
    goto skip_12;
    // 0x802F7658: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    skip_12:
    // 0x802F765C: lh          $t6, 0x4($s2)
    ctx->r14 = MEM_H(ctx->r18, 0X4);
    // 0x802F7660: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802F7664: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F7668: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802F766C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802F7670: lh          $t8, 0x8($s2)
    ctx->r24 = MEM_H(ctx->r18, 0X8);
    // 0x802F7674: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802F7678: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x802F767C: lh          $t9, 0xC($s2)
    ctx->r25 = MEM_H(ctx->r18, 0XC);
    // 0x802F7680: swc1        $f18, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->f18.u32l;
    // 0x802F7684: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802F7688: addu        $t5, $t9, $s5
    ctx->r13 = ADD32(ctx->r25, ctx->r21);
    // 0x802F768C: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802F7690: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802F7694: jal         0x8033C9CC
    // 0x802F7698: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    func_8033C9CC_74E07C(rdram, ctx);
        goto after_0;
    // 0x802F7698: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_0:
    // 0x802F769C: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802F76A0: addiu       $v1, $v1, 0x2350
    ctx->r3 = ADD32(ctx->r3, 0X2350);
    // 0x802F76A4: bne         $v0, $zero, L_802F78AC
    if (ctx->r2 != 0) {
        // 0x802F76A8: lwc1        $f18, 0xC0($sp)
        ctx->f18.u32l = MEM_W(ctx->r29, 0XC0);
            goto L_802F78AC;
    }
    // 0x802F76A8: lwc1        $f18, 0xC0($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XC0);
    // 0x802F76AC: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
L_802F76B0:
    // 0x802F76B0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802F76B4: sub.s       $f4, $f28, $f22
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 28);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f28.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f4.fl = ctx->f28.fl - ctx->f22.fl;
    // 0x802F76B8: lhu         $v0, 0x44($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X44);
    // 0x802F76BC: lui         $at, 0x42C8
    ctx->r1 = S32(0X42C8 << 16);
    // 0x802F76C0: div.s       $f10, $f20, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f20.fl, ctx->f8.fl);
    // 0x802F76C4: mul.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f4.fl);
    // 0x802F76C8: div.s       $f0, $f6, $f28
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 28);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f28.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f28.fl);
    // 0x802F76CC: beq         $v0, $zero, L_802F76FC
    if (ctx->r2 == 0) {
        // 0x802F76D0: mov.s       $f12, $f0
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    ctx->f12.fl = ctx->f0.fl;
            goto L_802F76FC;
    }
    // 0x802F76D0: mov.s       $f12, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    ctx->f12.fl = ctx->f0.fl;
    // 0x802F76D4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802F76D8: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x802F76DC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802F76E0: mul.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x802F76E4: bgez        $v0, L_802F76F8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F76E8: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802F76F8;
    }
    // 0x802F76E8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F76EC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802F76F0: nop

    // 0x802F76F4: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802F76F8:
    // 0x802F76F8: div.s       $f12, $f10, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = DIV_S(ctx->f10.fl, ctx->f6.fl);
L_802F76FC:
    // 0x802F76FC: lwc1        $f2, 0x0($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X0);
    // 0x802F7700: c.lt.s      $f26, $f2
    CHECK_FR(ctx, 26);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f26.fl < ctx->f2.fl;
    // 0x802F7704: nop

    // 0x802F7708: bc1fl       L_802F7738
    if (!c1cs) {
        // 0x802F770C: c.lt.s      $f2, $f26
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
            goto L_802F7738;
    }
    goto skip_13;
    // 0x802F770C: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
    skip_13:
    // 0x802F7710: lw          $t7, 0x1C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X1C);
    // 0x802F7714: mul.s       $f8, $f20, $f24
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f8.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F7718: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802F771C: nop

    // 0x802F7720: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F7724: c.lt.s      $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f0.fl < ctx->f8.fl;
    // 0x802F7728: nop

    // 0x802F772C: bc1t        L_802F776C
    if (c1cs) {
        // 0x802F7730: nop
    
            goto L_802F776C;
    }
    // 0x802F7730: nop

    // 0x802F7734: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
L_802F7738:
    // 0x802F7738: nop

    // 0x802F773C: bc1fl       L_802F7790
    if (!c1cs) {
        // 0x802F7740: lwc1        $f2, 0x4($s1)
        ctx->f2.u32l = MEM_W(ctx->r17, 0X4);
            goto L_802F7790;
    }
    goto skip_14;
    // 0x802F7740: lwc1        $f2, 0x4($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X4);
    skip_14:
    // 0x802F7744: lw          $t6, 0x1C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X1C);
    // 0x802F7748: mul.s       $f6, $f20, $f24
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f6.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F774C: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x802F7750: nop

    // 0x802F7754: cvt.s.w     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F7758: neg.s       $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = -ctx->f6.fl;
    // 0x802F775C: c.lt.s      $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f4.fl < ctx->f0.fl;
    // 0x802F7760: nop

    // 0x802F7764: bc1fl       L_802F7790
    if (!c1cs) {
        // 0x802F7768: lwc1        $f2, 0x4($s1)
        ctx->f2.u32l = MEM_W(ctx->r17, 0X4);
            goto L_802F7790;
    }
    goto skip_15;
    // 0x802F7768: lwc1        $f2, 0x4($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X4);
    skip_15:
L_802F776C:
    // 0x802F776C: mul.s       $f8, $f12, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = MUL_S(ctx->f12.fl, ctx->f2.fl);
    // 0x802F7770: nop

    // 0x802F7774: mul.s       $f10, $f8, $f24
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f24.fl);
    // 0x802F7778: add.s       $f6, $f0, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f0.fl + ctx->f10.fl;
    // 0x802F777C: trunc.w.s   $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802F7780: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x802F7784: nop

    // 0x802F7788: sw          $t9, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r25;
    // 0x802F778C: lwc1        $f2, 0x4($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X4);
L_802F7790:
    // 0x802F7790: c.lt.s      $f26, $f2
    CHECK_FR(ctx, 26);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f26.fl < ctx->f2.fl;
    // 0x802F7794: nop

    // 0x802F7798: bc1fl       L_802F77C8
    if (!c1cs) {
        // 0x802F779C: c.lt.s      $f2, $f26
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
            goto L_802F77C8;
    }
    goto skip_16;
    // 0x802F779C: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
    skip_16:
    // 0x802F77A0: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x802F77A4: mul.s       $f10, $f20, $f24
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f10.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F77A8: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x802F77AC: nop

    // 0x802F77B0: cvt.s.w     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    ctx->f0.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F77B4: c.lt.s      $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f0.fl < ctx->f10.fl;
    // 0x802F77B8: nop

    // 0x802F77BC: bc1t        L_802F77FC
    if (c1cs) {
        // 0x802F77C0: nop
    
            goto L_802F77FC;
    }
    // 0x802F77C0: nop

    // 0x802F77C4: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
L_802F77C8:
    // 0x802F77C8: nop

    // 0x802F77CC: bc1fl       L_802F7820
    if (!c1cs) {
        // 0x802F77D0: lwc1        $f2, 0x8($s1)
        ctx->f2.u32l = MEM_W(ctx->r17, 0X8);
            goto L_802F7820;
    }
    goto skip_17;
    // 0x802F77D0: lwc1        $f2, 0x8($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X8);
    skip_17:
    // 0x802F77D4: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802F77D8: mul.s       $f4, $f20, $f24
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f4.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F77DC: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802F77E0: nop

    // 0x802F77E4: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F77E8: neg.s       $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = -ctx->f4.fl;
    // 0x802F77EC: c.lt.s      $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f8.fl < ctx->f0.fl;
    // 0x802F77F0: nop

    // 0x802F77F4: bc1fl       L_802F7820
    if (!c1cs) {
        // 0x802F77F8: lwc1        $f2, 0x8($s1)
        ctx->f2.u32l = MEM_W(ctx->r17, 0X8);
            goto L_802F7820;
    }
    goto skip_18;
    // 0x802F77F8: lwc1        $f2, 0x8($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X8);
    skip_18:
L_802F77FC:
    // 0x802F77FC: mul.s       $f10, $f12, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = MUL_S(ctx->f12.fl, ctx->f2.fl);
    // 0x802F7800: nop

    // 0x802F7804: mul.s       $f6, $f10, $f24
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f24.fl);
    // 0x802F7808: add.s       $f4, $f0, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f0.fl + ctx->f6.fl;
    // 0x802F780C: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802F7810: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x802F7814: nop

    // 0x802F7818: sw          $t8, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r24;
    // 0x802F781C: lwc1        $f2, 0x8($s1)
    ctx->f2.u32l = MEM_W(ctx->r17, 0X8);
L_802F7820:
    // 0x802F7820: c.lt.s      $f26, $f2
    CHECK_FR(ctx, 26);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f26.fl < ctx->f2.fl;
    // 0x802F7824: nop

    // 0x802F7828: bc1fl       L_802F7858
    if (!c1cs) {
        // 0x802F782C: c.lt.s      $f2, $f26
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
            goto L_802F7858;
    }
    goto skip_19;
    // 0x802F782C: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
    skip_19:
    // 0x802F7830: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802F7834: mul.s       $f6, $f20, $f24
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f6.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F7838: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x802F783C: nop

    // 0x802F7840: cvt.s.w     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F7844: c.lt.s      $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    c1cs = ctx->f0.fl < ctx->f6.fl;
    // 0x802F7848: nop

    // 0x802F784C: bc1t        L_802F788C
    if (c1cs) {
        // 0x802F7850: nop
    
            goto L_802F788C;
    }
    // 0x802F7850: nop

    // 0x802F7854: c.lt.s      $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    c1cs = ctx->f2.fl < ctx->f26.fl;
L_802F7858:
    // 0x802F7858: nop

    // 0x802F785C: bc1fl       L_802F78B0
    if (!c1cs) {
        // 0x802F7860: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_20;
    // 0x802F7860: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_20:
    // 0x802F7864: lw          $t5, 0x24($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X24);
    // 0x802F7868: mul.s       $f8, $f20, $f24
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f20.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f8.fl = MUL_S(ctx->f20.fl, ctx->f24.fl);
    // 0x802F786C: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802F7870: nop

    // 0x802F7874: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F7878: neg.s       $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = -ctx->f8.fl;
    // 0x802F787C: c.lt.s      $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f10.fl < ctx->f0.fl;
    // 0x802F7880: nop

    // 0x802F7884: bc1fl       L_802F78B0
    if (!c1cs) {
        // 0x802F7888: lw          $s3, 0x0($s3)
        ctx->r19 = MEM_W(ctx->r19, 0X0);
            goto L_802F78B0;
    }
    goto skip_21;
    // 0x802F7888: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
    skip_21:
L_802F788C:
    // 0x802F788C: mul.s       $f6, $f12, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = MUL_S(ctx->f12.fl, ctx->f2.fl);
    // 0x802F7890: nop

    // 0x802F7894: mul.s       $f4, $f6, $f24
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 24);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f24.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f24.fl);
    // 0x802F7898: add.s       $f8, $f0, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f0.fl + ctx->f4.fl;
    // 0x802F789C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802F78A0: mfc1        $t6, $f10
    ctx->r14 = (int32_t)ctx->f10.u32l;
    // 0x802F78A4: nop

    // 0x802F78A8: sw          $t6, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r14;
L_802F78AC:
    // 0x802F78AC: lw          $s3, 0x0($s3)
    ctx->r19 = MEM_W(ctx->r19, 0X0);
L_802F78B0:
    // 0x802F78B0: bnel        $s3, $zero, L_802F73A4
    if (ctx->r19 != 0) {
        // 0x802F78B4: lw          $s0, 0x8($s3)
        ctx->r16 = MEM_W(ctx->r19, 0X8);
            goto L_802F73A4;
    }
    goto skip_22;
    // 0x802F78B4: lw          $s0, 0x8($s3)
    ctx->r16 = MEM_W(ctx->r19, 0X8);
    skip_22:
    // 0x802F78B8: lh          $t8, 0x138($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X138);
L_802F78BC:
    // 0x802F78BC: lw          $t5, 0x9C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X9C);
    // 0x802F78C0: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x802F78C4: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x802F78C8: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F78CC: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802F78D0: beq         $at, $zero, L_802F7364
    if (ctx->r1 == 0) {
        // 0x802F78D4: sh          $t9, 0x138($sp)
        MEM_H(0X138, ctx->r29) = ctx->r25;
            goto L_802F7364;
    }
    // 0x802F78D4: sh          $t9, 0x138($sp)
    MEM_H(0X138, ctx->r29) = ctx->r25;
L_802F78D8:
    // 0x802F78D8: lh          $t8, 0x13A($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X13A);
    // 0x802F78DC: lw          $t7, 0xA4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XA4);
    // 0x802F78E0: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x802F78E4: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x802F78E8: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F78EC: slt         $at, $t7, $t6
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802F78F0: beq         $at, $zero, L_802F734C
    if (ctx->r1 == 0) {
        // 0x802F78F4: sh          $t9, 0x13A($sp)
        MEM_H(0X13A, ctx->r29) = ctx->r25;
            goto L_802F734C;
    }
    // 0x802F78F4: sh          $t9, 0x13A($sp)
    MEM_H(0X13A, ctx->r29) = ctx->r25;
L_802F78F8:
    // 0x802F78F8: lw          $ra, 0x84($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X84);
    // 0x802F78FC: ldc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X30);
    // 0x802F7900: ldc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X38);
    // 0x802F7904: ldc1        $f24, 0x40($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X40);
    // 0x802F7908: ldc1        $f26, 0x48($sp)
    CHECK_FR(ctx, 26);
    ctx->f26.u64 = LD(ctx->r29, 0X48);
    // 0x802F790C: ldc1        $f28, 0x50($sp)
    CHECK_FR(ctx, 28);
    ctx->f28.u64 = LD(ctx->r29, 0X50);
    // 0x802F7910: ldc1        $f30, 0x58($sp)
    CHECK_FR(ctx, 30);
    ctx->f30.u64 = LD(ctx->r29, 0X58);
    // 0x802F7914: lw          $s0, 0x60($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X60);
    // 0x802F7918: lw          $s1, 0x64($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X64);
    // 0x802F791C: lw          $s2, 0x68($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X68);
    // 0x802F7920: lw          $s3, 0x6C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X6C);
    // 0x802F7924: lw          $s4, 0x70($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X70);
    // 0x802F7928: lw          $s5, 0x74($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X74);
    // 0x802F792C: lw          $s6, 0x78($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X78);
    // 0x802F7930: lw          $s7, 0x7C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X7C);
    // 0x802F7934: lw          $fp, 0x80($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X80);
    // 0x802F7938: jr          $ra
    // 0x802F793C: addiu       $sp, $sp, 0x140
    ctx->r29 = ADD32(ctx->r29, 0X140);
    return;
    // 0x802F793C: addiu       $sp, $sp, 0x140
    ctx->r29 = ADD32(ctx->r29, 0X140);
;}
RECOMP_FUNC void func_802F7940_708FF0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F7940: addiu       $sp, $sp, -0xD8
    ctx->r29 = ADD32(ctx->r29, -0XD8);
    // 0x802F7944: sw          $a1, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->r5;
    // 0x802F7948: lh          $v0, 0xDE($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XDE);
    // 0x802F794C: sw          $a2, 0xE0($sp)
    MEM_W(0XE0, ctx->r29) = ctx->r6;
    // 0x802F7950: lh          $v1, 0xE2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XE2);
    // 0x802F7954: lh          $t9, 0xEA($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XEA);
    // 0x802F7958: sra         $t6, $v0, 10
    ctx->r14 = S32(SIGNED(ctx->r2) >> 10);
    // 0x802F795C: sll         $t1, $t6, 16
    ctx->r9 = S32(ctx->r14 << 16);
    // 0x802F7960: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x802F7964: sra         $t7, $t1, 16
    ctx->r15 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F7968: sra         $t8, $v1, 10
    ctx->r24 = S32(SIGNED(ctx->r3) >> 10);
    // 0x802F796C: or          $s6, $a0, $zero
    ctx->r22 = ctx->r4 | 0;
    // 0x802F7970: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802F7974: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x802F7978: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x802F797C: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x802F7980: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x802F7984: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x802F7988: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x802F798C: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x802F7990: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802F7994: sw          $a3, 0xE4($sp)
    MEM_W(0XE4, ctx->r29) = ctx->r7;
    // 0x802F7998: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
    // 0x802F799C: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802F79A0: beq         $t9, $zero, L_802F801C
    if (ctx->r25 == 0) {
        // 0x802F79A4: sh          $t8, 0xD4($sp)
        MEM_H(0XD4, ctx->r29) = ctx->r24;
            goto L_802F801C;
    }
    // 0x802F79A4: sh          $t8, 0xD4($sp)
    MEM_H(0XD4, ctx->r29) = ctx->r24;
    // 0x802F79A8: sll         $a1, $t6, 16
    ctx->r5 = S32(ctx->r14 << 16);
    // 0x802F79AC: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F79B0: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x802F79B4: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802F79B8: slti        $at, $t5, 0x5
    ctx->r1 = SIGNED(ctx->r13) < 0X5 ? 1 : 0;
    // 0x802F79BC: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
    // 0x802F79C0: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    // 0x802F79C4: sh          $t3, 0xC8($sp)
    MEM_H(0XC8, ctx->r29) = ctx->r11;
    // 0x802F79C8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x802F79CC: bne         $at, $zero, L_802F79D8
    if (ctx->r1 != 0) {
        // 0x802F79D0: or          $a1, $t4, $zero
        ctx->r5 = ctx->r12 | 0;
            goto L_802F79D8;
    }
    // 0x802F79D0: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x802F79D4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_802F79D8:
    // 0x802F79D8: bgtz        $a1, L_802F79E4
    if (SIGNED(ctx->r5) > 0) {
        // 0x802F79DC: sll         $a0, $v1, 16
        ctx->r4 = S32(ctx->r3 << 16);
            goto L_802F79E4;
    }
    // 0x802F79DC: sll         $a0, $v1, 16
    ctx->r4 = S32(ctx->r3 << 16);
    // 0x802F79E0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
L_802F79E4:
    // 0x802F79E4: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F79E8: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802F79EC: slti        $at, $t7, 0x8
    ctx->r1 = SIGNED(ctx->r15) < 0X8 ? 1 : 0;
    // 0x802F79F0: bne         $at, $zero, L_802F79FC
    if (ctx->r1 != 0) {
        // 0x802F79F4: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_802F79FC;
    }
    // 0x802F79F4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802F79F8: sh          $zero, 0xC8($sp)
    MEM_H(0XC8, ctx->r29) = 0;
L_802F79FC:
    // 0x802F79FC: bgtz        $a0, L_802F7A08
    if (SIGNED(ctx->r4) > 0) {
        // 0x802F7A00: addiu       $fp, $zero, 0x64
        ctx->r30 = ADD32(0, 0X64);
            goto L_802F7A08;
    }
    // 0x802F7A00: addiu       $fp, $zero, 0x64
    ctx->r30 = ADD32(0, 0X64);
    // 0x802F7A04: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_802F7A08:
    // 0x802F7A08: lw          $v0, 0x168($s6)
    ctx->r2 = MEM_W(ctx->r22, 0X168);
    // 0x802F7A0C: sltu        $t8, $zero, $v0
    ctx->r24 = 0 < ctx->r2 ? 1 : 0;
    // 0x802F7A10: beq         $t8, $zero, L_802F7A60
    if (ctx->r24 == 0) {
        // 0x802F7A14: sw          $t8, 0x88($sp)
        MEM_W(0X88, ctx->r29) = ctx->r24;
            goto L_802F7A60;
    }
    // 0x802F7A14: sw          $t8, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r24;
    // 0x802F7A18: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802F7A1C: sltu        $t3, $zero, $v1
    ctx->r11 = 0 < ctx->r3 ? 1 : 0;
    // 0x802F7A20: beq         $t3, $zero, L_802F7A60
    if (ctx->r11 == 0) {
        // 0x802F7A24: sw          $t3, 0x88($sp)
        MEM_W(0X88, ctx->r29) = ctx->r11;
            goto L_802F7A60;
    }
    // 0x802F7A24: sw          $t3, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r11;
    // 0x802F7A28: lhu         $t5, 0x0($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X0);
    // 0x802F7A2C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802F7A30: slti        $t6, $t5, 0x100
    ctx->r14 = SIGNED(ctx->r13) < 0X100 ? 1 : 0;
    // 0x802F7A34: xori        $t6, $t6, 0x1
    ctx->r14 = ctx->r14 ^ 0X1;
    // 0x802F7A38: beq         $t6, $zero, L_802F7A60
    if (ctx->r14 == 0) {
        // 0x802F7A3C: sw          $t6, 0x88($sp)
        MEM_W(0X88, ctx->r29) = ctx->r14;
            goto L_802F7A60;
    }
    // 0x802F7A3C: sw          $t6, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r14;
    // 0x802F7A40: lh          $t8, 0x5534($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5534);
    // 0x802F7A44: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x802F7A48: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802F7A4C: addu        $t3, $t3, $t9
    ctx->r11 = ADD32(ctx->r11, ctx->r25);
    // 0x802F7A50: lw          $t3, -0x2274($t3)
    ctx->r11 = MEM_W(ctx->r11, -0X2274);
    // 0x802F7A54: xor         $t4, $v0, $t3
    ctx->r12 = ctx->r2 ^ ctx->r11;
    // 0x802F7A58: sltiu       $t4, $t4, 0x1
    ctx->r12 = ctx->r12 < 0X1 ? 1 : 0;
    // 0x802F7A5C: sw          $t4, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r12;
L_802F7A60:
    // 0x802F7A60: addu        $v0, $a1, $a3
    ctx->r2 = ADD32(ctx->r5, ctx->r7);
    // 0x802F7A64: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x802F7A68: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F7A6C: addu        $t5, $a1, $a2
    ctx->r13 = ADD32(ctx->r5, ctx->r6);
    // 0x802F7A70: slt         $at, $t5, $t7
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802F7A74: bne         $at, $zero, L_802F801C
    if (ctx->r1 != 0) {
        // 0x802F7A78: sh          $v0, 0xD2($sp)
        MEM_H(0XD2, ctx->r29) = ctx->r2;
            goto L_802F801C;
    }
    // 0x802F7A78: sh          $v0, 0xD2($sp)
    MEM_H(0XD2, ctx->r29) = ctx->r2;
    // 0x802F7A7C: addu        $t9, $a0, $t0
    ctx->r25 = ADD32(ctx->r4, ctx->r8);
    // 0x802F7A80: lh          $t3, 0xC8($sp)
    ctx->r11 = MEM_H(ctx->r29, 0XC8);
    // 0x802F7A84: sw          $t9, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r25;
    // 0x802F7A88: lh          $t6, 0x66($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X66);
    // 0x802F7A8C: addu        $t8, $t1, $a2
    ctx->r24 = ADD32(ctx->r9, ctx->r6);
    // 0x802F7A90: addu        $t4, $a0, $t3
    ctx->r12 = ADD32(ctx->r4, ctx->r11);
    // 0x802F7A94: sw          $t4, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r12;
    // 0x802F7A98: sw          $t8, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r24;
    // 0x802F7A9C: sw          $t6, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r14;
L_802F7AA0:
    // 0x802F7AA0: lw          $t7, 0x60($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X60);
    // 0x802F7AA4: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    // 0x802F7AA8: lw          $t5, 0x64($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X64);
    // 0x802F7AAC: lh          $t9, 0xD4($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD4);
    // 0x802F7AB0: slt         $at, $t7, $t8
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802F7AB4: bne         $at, $zero, L_802F7FFC
    if (ctx->r1 != 0) {
        // 0x802F7AB8: sh          $t5, 0xD0($sp)
        MEM_H(0XD0, ctx->r29) = ctx->r13;
            goto L_802F7FFC;
    }
    // 0x802F7AB8: sh          $t5, 0xD0($sp)
    MEM_H(0XD0, ctx->r29) = ctx->r13;
    // 0x802F7ABC: lh          $t3, 0xC8($sp)
    ctx->r11 = MEM_H(ctx->r29, 0XC8);
    // 0x802F7AC0: addu        $t4, $t9, $t3
    ctx->r12 = ADD32(ctx->r25, ctx->r11);
    // 0x802F7AC4: sw          $t4, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r12;
L_802F7AC8:
    // 0x802F7AC8: lh          $t5, 0xD0($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XD0);
    // 0x802F7ACC: lh          $t6, 0xD2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XD2);
    // 0x802F7AD0: lui         $s7, 0x803E
    ctx->r23 = S32(0X803E << 16);
    // 0x802F7AD4: sll         $t7, $t5, 2
    ctx->r15 = S32(ctx->r13 << 2);
    // 0x802F7AD8: addu        $t7, $t7, $t5
    ctx->r15 = ADD32(ctx->r15, ctx->r13);
    // 0x802F7ADC: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x802F7AE0: andi        $t8, $v0, 0xFFFF
    ctx->r24 = ctx->r2 & 0XFFFF;
    // 0x802F7AE4: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x802F7AE8: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x802F7AEC: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802F7AF0: addu        $s7, $s7, $t9
    ctx->r23 = ADD32(ctx->r23, ctx->r25);
    // 0x802F7AF4: lw          $s7, -0x5EF0($s7)
    ctx->r23 = MEM_W(ctx->r23, -0X5EF0);
    // 0x802F7AF8: beql        $s7, $zero, L_802F7FE0
    if (ctx->r23 == 0) {
        // 0x802F7AFC: lh          $t9, 0xD0($sp)
        ctx->r25 = MEM_H(ctx->r29, 0XD0);
            goto L_802F7FE0;
    }
    goto skip_0;
    // 0x802F7AFC: lh          $t9, 0xD0($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD0);
    skip_0:
    // 0x802F7B00: sw          $t8, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r24;
    // 0x802F7B04: lw          $s0, 0x8($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X8);
L_802F7B08:
    // 0x802F7B08: lw          $t3, 0x68($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X68);
    // 0x802F7B0C: lh          $t4, 0x114($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X114);
    // 0x802F7B10: bnel        $t3, $t4, L_802F7FD4
    if (ctx->r11 != ctx->r12) {
        // 0x802F7B14: lw          $s7, 0x0($s7)
        ctx->r23 = MEM_W(ctx->r23, 0X0);
            goto L_802F7FD4;
    }
    goto skip_1;
    // 0x802F7B14: lw          $s7, 0x0($s7)
    ctx->r23 = MEM_W(ctx->r23, 0X0);
    skip_1:
    // 0x802F7B18: lw          $t5, 0x16C($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X16C);
    // 0x802F7B1C: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x802F7B20: lhu         $t6, 0x0($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0X0);
    // 0x802F7B24: beql        $t6, $at, L_802F7FD4
    if (ctx->r14 == ctx->r1) {
        // 0x802F7B28: lw          $s7, 0x0($s7)
        ctx->r23 = MEM_W(ctx->r23, 0X0);
            goto L_802F7FD4;
    }
    goto skip_2;
    // 0x802F7B28: lw          $s7, 0x0($s7)
    ctx->r23 = MEM_W(ctx->r23, 0X0);
    skip_2:
    // 0x802F7B2C: beql        $s0, $s6, L_802F7FD4
    if (ctx->r16 == ctx->r22) {
        // 0x802F7B30: lw          $s7, 0x0($s7)
        ctx->r23 = MEM_W(ctx->r23, 0X0);
            goto L_802F7FD4;
    }
    goto skip_3;
    // 0x802F7B30: lw          $s7, 0x0($s7)
    ctx->r23 = MEM_W(ctx->r23, 0X0);
    skip_3:
    // 0x802F7B34: lw          $t7, 0x168($s6)
    ctx->r15 = MEM_W(ctx->r22, 0X168);
    // 0x802F7B38: lh          $t8, 0xDE($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XDE);
    // 0x802F7B3C: lh          $t9, 0xE2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XE2);
    // 0x802F7B40: beq         $s0, $t7, L_802F7FD0
    if (ctx->r16 == ctx->r15) {
        // 0x802F7B44: lh          $t5, 0xE6($sp)
        ctx->r13 = MEM_H(ctx->r29, 0XE6);
            goto L_802F7FD0;
    }
    // 0x802F7B44: lh          $t5, 0xE6($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XE6);
    // 0x802F7B48: lhu         $a0, 0x42($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X42);
    // 0x802F7B4C: lh          $t0, 0x4($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X4);
    // 0x802F7B50: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802F7B54: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x802F7B58: sra         $t3, $a0, 1
    ctx->r11 = S32(SIGNED(ctx->r4) >> 1);
    // 0x802F7B5C: subu        $s2, $t0, $t8
    ctx->r18 = SUB32(ctx->r8, ctx->r24);
    // 0x802F7B60: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x802F7B64: subu        $v1, $t4, $t5
    ctx->r3 = SUB32(ctx->r12, ctx->r13);
    // 0x802F7B68: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x802F7B6C: blez        $s2, L_802F7B94
    if (SIGNED(ctx->r18) <= 0) {
        // 0x802F7B70: subu        $s4, $t1, $t9
        ctx->r20 = SUB32(ctx->r9, ctx->r25);
            goto L_802F7B94;
    }
    // 0x802F7B70: subu        $s4, $t1, $t9
    ctx->r20 = SUB32(ctx->r9, ctx->r25);
    // 0x802F7B74: lh          $t6, 0x30($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X30);
    // 0x802F7B78: subu        $v0, $s2, $t6
    ctx->r2 = SUB32(ctx->r18, ctx->r14);
    // 0x802F7B7C: bgez        $v0, L_802F7B8C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F7B80: nop
    
            goto L_802F7B8C;
    }
    // 0x802F7B80: nop

    // 0x802F7B84: b           L_802F7BAC
    // 0x802F7B88: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_802F7BAC;
    // 0x802F7B88: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_802F7B8C:
    // 0x802F7B8C: b           L_802F7BAC
    // 0x802F7B90: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
        goto L_802F7BAC;
    // 0x802F7B90: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
L_802F7B94:
    // 0x802F7B94: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802F7B98: addu        $v0, $t7, $s2
    ctx->r2 = ADD32(ctx->r15, ctx->r18);
    // 0x802F7B9C: blez        $v0, L_802F7BAC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F7BA0: or          $s2, $v0, $zero
        ctx->r18 = ctx->r2 | 0;
            goto L_802F7BAC;
    }
    // 0x802F7BA0: or          $s2, $v0, $zero
    ctx->r18 = ctx->r2 | 0;
    // 0x802F7BA4: b           L_802F7BAC
    // 0x802F7BA8: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_802F7BAC;
    // 0x802F7BA8: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_802F7BAC:
    // 0x802F7BAC: blezl       $s4, L_802F7BD8
    if (SIGNED(ctx->r20) <= 0) {
        // 0x802F7BB0: lh          $t9, 0x32($s0)
        ctx->r25 = MEM_H(ctx->r16, 0X32);
            goto L_802F7BD8;
    }
    goto skip_4;
    // 0x802F7BB0: lh          $t9, 0x32($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X32);
    skip_4:
    // 0x802F7BB4: lh          $t8, 0x32($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X32);
    // 0x802F7BB8: subu        $v0, $s4, $t8
    ctx->r2 = SUB32(ctx->r20, ctx->r24);
    // 0x802F7BBC: bgez        $v0, L_802F7BCC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F7BC0: nop
    
            goto L_802F7BCC;
    }
    // 0x802F7BC0: nop

    // 0x802F7BC4: b           L_802F7BEC
    // 0x802F7BC8: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
        goto L_802F7BEC;
    // 0x802F7BC8: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
L_802F7BCC:
    // 0x802F7BCC: b           L_802F7BEC
    // 0x802F7BD0: or          $s4, $v0, $zero
    ctx->r20 = ctx->r2 | 0;
        goto L_802F7BEC;
    // 0x802F7BD0: or          $s4, $v0, $zero
    ctx->r20 = ctx->r2 | 0;
    // 0x802F7BD4: lh          $t9, 0x32($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X32);
L_802F7BD8:
    // 0x802F7BD8: addu        $v0, $t9, $s4
    ctx->r2 = ADD32(ctx->r25, ctx->r20);
    // 0x802F7BDC: blez        $v0, L_802F7BEC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F7BE0: or          $s4, $v0, $zero
        ctx->r20 = ctx->r2 | 0;
            goto L_802F7BEC;
    }
    // 0x802F7BE0: or          $s4, $v0, $zero
    ctx->r20 = ctx->r2 | 0;
    // 0x802F7BE4: b           L_802F7BEC
    // 0x802F7BE8: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
        goto L_802F7BEC;
    // 0x802F7BE8: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
L_802F7BEC:
    // 0x802F7BEC: blez        $v1, L_802F7C10
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802F7BF0: addu        $v0, $a0, $v1
        ctx->r2 = ADD32(ctx->r4, ctx->r3);
            goto L_802F7C10;
    }
    // 0x802F7BF0: addu        $v0, $a0, $v1
    ctx->r2 = ADD32(ctx->r4, ctx->r3);
    // 0x802F7BF4: subu        $v0, $v1, $a0
    ctx->r2 = SUB32(ctx->r3, ctx->r4);
    // 0x802F7BF8: bgez        $v0, L_802F7C08
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F7BFC: nop
    
            goto L_802F7C08;
    }
    // 0x802F7BFC: nop

    // 0x802F7C00: b           L_802F7C20
    // 0x802F7C04: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802F7C20;
    // 0x802F7C04: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802F7C08:
    // 0x802F7C08: b           L_802F7C20
    // 0x802F7C0C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802F7C20;
    // 0x802F7C0C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802F7C10:
    // 0x802F7C10: blez        $v0, L_802F7C20
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F7C14: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802F7C20;
    }
    // 0x802F7C14: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802F7C18: b           L_802F7C20
    // 0x802F7C1C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_802F7C20;
    // 0x802F7C1C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_802F7C20:
    // 0x802F7C20: multu       $s2, $s2
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7C24: lh          $t8, 0xEE($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XEE);
    // 0x802F7C28: mflo        $t3
    ctx->r11 = lo;
    // 0x802F7C2C: nop

    // 0x802F7C30: nop

    // 0x802F7C34: multu       $s4, $s4
    result = U64(U32(ctx->r20)) * U64(U32(ctx->r20)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7C38: mflo        $t4
    ctx->r12 = lo;
    // 0x802F7C3C: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x802F7C40: nop

    // 0x802F7C44: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7C48: mflo        $t6
    ctx->r14 = lo;
    // 0x802F7C4C: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802F7C50: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802F7C54: lh          $t7, 0xF2($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XF2);
    // 0x802F7C58: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F7C5C: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F7C60: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802F7C64: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x802F7C68: nop

    // 0x802F7C6C: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802F7C70: sra         $s3, $t9, 16
    ctx->r19 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F7C74: bgtz        $s3, L_802F7C80
    if (SIGNED(ctx->r19) > 0) {
        // 0x802F7C78: nop
    
            goto L_802F7C80;
    }
    // 0x802F7C78: nop

    // 0x802F7C7C: addiu       $s3, $zero, 0x1
    ctx->r19 = ADD32(0, 0X1);
L_802F7C80:
    // 0x802F7C80: bgez        $s3, L_802F7C98
    if (SIGNED(ctx->r19) >= 0) {
        // 0x802F7C84: sll         $s1, $s3, 16
        ctx->r17 = S32(ctx->r19 << 16);
            goto L_802F7C98;
    }
    // 0x802F7C84: sll         $s1, $s3, 16
    ctx->r17 = S32(ctx->r19 << 16);
    // 0x802F7C88: negu        $s1, $s3
    ctx->r17 = SUB32(0, ctx->r19);
    // 0x802F7C8C: sll         $t4, $s1, 16
    ctx->r12 = S32(ctx->r17 << 16);
    // 0x802F7C90: b           L_802F7CA0
    // 0x802F7C94: sra         $s1, $t4, 16
    ctx->r17 = S32(SIGNED(ctx->r12) >> 16);
        goto L_802F7CA0;
    // 0x802F7C94: sra         $s1, $t4, 16
    ctx->r17 = S32(SIGNED(ctx->r12) >> 16);
L_802F7C98:
    // 0x802F7C98: sra         $t6, $s1, 16
    ctx->r14 = S32(SIGNED(ctx->r17) >> 16);
    // 0x802F7C9C: or          $s1, $t6, $zero
    ctx->r17 = ctx->r14 | 0;
L_802F7CA0:
    // 0x802F7CA0: slt         $at, $s1, $t7
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802F7CA4: beq         $at, $zero, L_802F7FD0
    if (ctx->r1 == 0) {
        // 0x802F7CA8: slt         $at, $t8, $s1
        ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r17) ? 1 : 0;
            goto L_802F7FD0;
    }
    // 0x802F7CA8: slt         $at, $t8, $s1
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x802F7CAC: beq         $at, $zero, L_802F7FD0
    if (ctx->r1 == 0) {
        // 0x802F7CB0: lh          $a0, 0xDE($sp)
        ctx->r4 = MEM_H(ctx->r29, 0XDE);
            goto L_802F7FD0;
    }
    // 0x802F7CB0: lh          $a0, 0xDE($sp)
    ctx->r4 = MEM_H(ctx->r29, 0XDE);
    // 0x802F7CB4: lbu         $a3, 0x160($s6)
    ctx->r7 = MEM_BU(ctx->r22, 0X160);
    // 0x802F7CB8: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x802F7CBC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    // 0x802F7CC0: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x802F7CC4: lbu         $t9, 0x160($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X160);
    // 0x802F7CC8: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802F7CCC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802F7CD0: lh          $a1, 0xE2($sp)
    ctx->r5 = MEM_H(ctx->r29, 0XE2);
    // 0x802F7CD4: lh          $a2, 0xE6($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XE6);
    // 0x802F7CD8: jal         0x8033C9CC
    // 0x802F7CDC: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    func_8033C9CC_74E07C(rdram, ctx);
        goto after_0;
    // 0x802F7CDC: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    after_0:
    // 0x802F7CE0: bne         $v0, $zero, L_802F7FD0
    if (ctx->r2 != 0) {
        // 0x802F7CE4: lh          $a0, 0xDE($sp)
        ctx->r4 = MEM_H(ctx->r29, 0XDE);
            goto L_802F7FD0;
    }
    // 0x802F7CE4: lh          $a0, 0xDE($sp)
    ctx->r4 = MEM_H(ctx->r29, 0XDE);
    // 0x802F7CE8: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x802F7CEC: lhu         $t4, 0x42($s6)
    ctx->r12 = MEM_HU(ctx->r22, 0X42);
    // 0x802F7CF0: lbu         $a3, 0x160($s6)
    ctx->r7 = MEM_BU(ctx->r22, 0X160);
    // 0x802F7CF4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802F7CF8: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802F7CFC: lh          $t3, 0xE6($sp)
    ctx->r11 = MEM_H(ctx->r29, 0XE6);
    // 0x802F7D00: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x802F7D04: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802F7D08: addu        $a2, $t3, $t5
    ctx->r6 = ADD32(ctx->r11, ctx->r13);
    // 0x802F7D0C: lhu         $t3, 0x42($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X42);
    // 0x802F7D10: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802F7D14: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802F7D18: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F7D1C: addu        $t5, $t4, $t3
    ctx->r13 = ADD32(ctx->r12, ctx->r11);
    // 0x802F7D20: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802F7D24: lbu         $t6, 0x160($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X160);
    // 0x802F7D28: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802F7D2C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802F7D30: lh          $a1, 0xE2($sp)
    ctx->r5 = MEM_H(ctx->r29, 0XE2);
    // 0x802F7D34: jal         0x8033C9CC
    // 0x802F7D38: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_8033C9CC_74E07C(rdram, ctx);
        goto after_1;
    // 0x802F7D38: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_1:
    // 0x802F7D3C: bnel        $v0, $zero, L_802F7FD4
    if (ctx->r2 != 0) {
        // 0x802F7D40: lw          $s7, 0x0($s7)
        ctx->r23 = MEM_W(ctx->r23, 0X0);
            goto L_802F7FD4;
    }
    goto skip_5;
    // 0x802F7D40: lw          $s7, 0x0($s7)
    ctx->r23 = MEM_W(ctx->r23, 0X0);
    skip_5:
    // 0x802F7D44: lw          $t7, 0x16C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X16C);
    // 0x802F7D48: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x802F7D4C: lhu         $v0, 0x0($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X0);
    // 0x802F7D50: beq         $v0, $at, L_802F7D68
    if (ctx->r2 == ctx->r1) {
        // 0x802F7D54: addiu       $at, $zero, 0x4D
        ctx->r1 = ADD32(0, 0X4D);
            goto L_802F7D68;
    }
    // 0x802F7D54: addiu       $at, $zero, 0x4D
    ctx->r1 = ADD32(0, 0X4D);
    // 0x802F7D58: beq         $v0, $at, L_802F7D68
    if (ctx->r2 == ctx->r1) {
        // 0x802F7D5C: addiu       $at, $zero, 0x4E
        ctx->r1 = ADD32(0, 0X4E);
            goto L_802F7D68;
    }
    // 0x802F7D5C: addiu       $at, $zero, 0x4E
    ctx->r1 = ADD32(0, 0X4E);
    // 0x802F7D60: bne         $v0, $at, L_802F7D9C
    if (ctx->r2 != ctx->r1) {
        // 0x802F7D64: sll         $t5, $s2, 16
        ctx->r13 = S32(ctx->r18 << 16);
            goto L_802F7D9C;
    }
    // 0x802F7D64: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
L_802F7D68:
    // 0x802F7D68: lbu         $t4, 0x154($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X154);
    // 0x802F7D6C: sra         $v0, $s1, 4
    ctx->r2 = S32(SIGNED(ctx->r17) >> 4);
    // 0x802F7D70: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802F7D74: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F7D78: slt         $at, $t9, $t4
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802F7D7C: beq         $at, $zero, L_802F7FD0
    if (ctx->r1 == 0) {
        // 0x802F7D80: slti        $at, $t9, 0x2
        ctx->r1 = SIGNED(ctx->r25) < 0X2 ? 1 : 0;
            goto L_802F7FD0;
    }
    // 0x802F7D80: slti        $at, $t9, 0x2
    ctx->r1 = SIGNED(ctx->r25) < 0X2 ? 1 : 0;
    // 0x802F7D84: bne         $at, $zero, L_802F7D94
    if (ctx->r1 != 0) {
        // 0x802F7D88: addiu       $t3, $zero, 0x2
        ctx->r11 = ADD32(0, 0X2);
            goto L_802F7D94;
    }
    // 0x802F7D88: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x802F7D8C: b           L_802F7FD0
    // 0x802F7D90: sb          $t9, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r25;
        goto L_802F7FD0;
    // 0x802F7D90: sb          $t9, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r25;
L_802F7D94:
    // 0x802F7D94: b           L_802F7FD0
    // 0x802F7D98: sb          $t3, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r11;
        goto L_802F7FD0;
    // 0x802F7D98: sb          $t3, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r11;
L_802F7D9C:
    // 0x802F7D9C: div         $zero, $t5, $s3
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r19)));
    // 0x802F7DA0: lh          $t6, 0xEA($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XEA);
    // 0x802F7DA4: mflo        $s5
    ctx->r21 = lo;
    // 0x802F7DA8: or          $v0, $s5, $zero
    ctx->r2 = ctx->r21 | 0;
    // 0x802F7DAC: bne         $s3, $zero, L_802F7DB8
    if (ctx->r19 != 0) {
        // 0x802F7DB0: nop
    
            goto L_802F7DB8;
    }
    // 0x802F7DB0: nop

    // 0x802F7DB4: break       7
    do_break(2150596020);
L_802F7DB8:
    // 0x802F7DB8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F7DBC: bne         $s3, $at, L_802F7DD0
    if (ctx->r19 != ctx->r1) {
        // 0x802F7DC0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F7DD0;
    }
    // 0x802F7DC0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F7DC4: bne         $t5, $at, L_802F7DD0
    if (ctx->r13 != ctx->r1) {
        // 0x802F7DC8: nop
    
            goto L_802F7DD0;
    }
    // 0x802F7DC8: nop

    // 0x802F7DCC: break       6
    do_break(2150596044);
L_802F7DD0:
    // 0x802F7DD0: lbu         $s1, 0x8B($sp)
    ctx->r17 = MEM_BU(ctx->r29, 0X8B);
    // 0x802F7DD4: beq         $t6, $zero, L_802F7DEC
    if (ctx->r14 == 0) {
        // 0x802F7DD8: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_802F7DEC;
    }
    // 0x802F7DD8: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802F7DDC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802F7DE0: lh          $a2, 0xF6($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XF6);
    // 0x802F7DE4: jal         0x802B356C
    // 0x802F7DE8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    func_802B356C_6C4C1C(rdram, ctx);
        goto after_2;
    // 0x802F7DE8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    after_2:
L_802F7DEC:
    // 0x802F7DEC: beql        $s1, $zero, L_802F7E18
    if (ctx->r17 == 0) {
        // 0x802F7DF0: lw          $v0, 0x4C($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X4C);
            goto L_802F7E18;
    }
    goto skip_6;
    // 0x802F7DF0: lw          $v0, 0x4C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4C);
    skip_6:
    // 0x802F7DF4: lw          $t7, 0x16C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X16C);
    // 0x802F7DF8: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x802F7DFC: slti        $at, $t8, 0x100
    ctx->r1 = SIGNED(ctx->r24) < 0X100 ? 1 : 0;
    // 0x802F7E00: bnel        $at, $zero, L_802F7E18
    if (ctx->r1 != 0) {
        // 0x802F7E04: lw          $v0, 0x4C($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X4C);
            goto L_802F7E18;
    }
    goto skip_7;
    // 0x802F7E04: lw          $v0, 0x4C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4C);
    skip_7:
    // 0x802F7E08: lb          $t9, 0x2EB($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X2EB);
    // 0x802F7E0C: addiu       $t4, $t9, 0x1
    ctx->r12 = ADD32(ctx->r25, 0X1);
    // 0x802F7E10: sb          $t4, 0x2EB($s0)
    MEM_B(0X2EB, ctx->r16) = ctx->r12;
    // 0x802F7E14: lw          $v0, 0x4C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4C);
L_802F7E18:
    // 0x802F7E18: sll         $t3, $v0, 27
    ctx->r11 = S32(ctx->r2 << 27);
    // 0x802F7E1C: srl         $t5, $t3, 31
    ctx->r13 = S32(U32(ctx->r11) >> 31);
    // 0x802F7E20: beq         $t5, $zero, L_802F7FA0
    if (ctx->r13 == 0) {
        // 0x802F7E24: sll         $t6, $v0, 28
        ctx->r14 = S32(ctx->r2 << 28);
            goto L_802F7FA0;
    }
    // 0x802F7E24: sll         $t6, $v0, 28
    ctx->r14 = S32(ctx->r2 << 28);
    // 0x802F7E28: srl         $t7, $t6, 31
    ctx->r15 = S32(U32(ctx->r14) >> 31);
    // 0x802F7E2C: beql        $t7, $zero, L_802F7FA4
    if (ctx->r15 == 0) {
        // 0x802F7E30: lbu         $t9, 0x4F($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X4F);
            goto L_802F7FA4;
    }
    goto skip_8;
    // 0x802F7E30: lbu         $t9, 0x4F($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X4F);
    skip_8:
    // 0x802F7E34: lhu         $a1, 0x44($s0)
    ctx->r5 = MEM_HU(ctx->r16, 0X44);
    // 0x802F7E38: blez        $a1, L_802F7FA0
    if (SIGNED(ctx->r5) <= 0) {
        // 0x802F7E3C: slti        $at, $a1, 0x65
        ctx->r1 = SIGNED(ctx->r5) < 0X65 ? 1 : 0;
            goto L_802F7FA0;
    }
    // 0x802F7E3C: slti        $at, $a1, 0x65
    ctx->r1 = SIGNED(ctx->r5) < 0X65 ? 1 : 0;
    // 0x802F7E40: beq         $at, $zero, L_802F7FA0
    if (ctx->r1 == 0) {
        // 0x802F7E44: subu        $v1, $fp, $a1
        ctx->r3 = SUB32(ctx->r30, ctx->r5);
            goto L_802F7FA0;
    }
    // 0x802F7E44: subu        $v1, $fp, $a1
    ctx->r3 = SUB32(ctx->r30, ctx->r5);
    // 0x802F7E48: sll         $t8, $s5, 2
    ctx->r24 = S32(ctx->r21 << 2);
    // 0x802F7E4C: multu       $t8, $v1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7E50: sll         $t4, $s4, 16
    ctx->r12 = S32(ctx->r20 << 16);
    // 0x802F7E54: mflo        $t9
    ctx->r25 = lo;
    // 0x802F7E58: nop

    // 0x802F7E5C: nop

    // 0x802F7E60: div         $zero, $t9, $fp
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r30))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r30)));
    // 0x802F7E64: mflo        $v0
    ctx->r2 = lo;
    // 0x802F7E68: bne         $fp, $zero, L_802F7E74
    if (ctx->r30 != 0) {
        // 0x802F7E6C: nop
    
            goto L_802F7E74;
    }
    // 0x802F7E6C: nop

    // 0x802F7E70: break       7
    do_break(2150596208);
L_802F7E74:
    // 0x802F7E74: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F7E78: bne         $fp, $at, L_802F7E8C
    if (ctx->r30 != ctx->r1) {
        // 0x802F7E7C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F7E8C;
    }
    // 0x802F7E7C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F7E80: bne         $t9, $at, L_802F7E8C
    if (ctx->r25 != ctx->r1) {
        // 0x802F7E84: nop
    
            goto L_802F7E8C;
    }
    // 0x802F7E84: nop

    // 0x802F7E88: break       6
    do_break(2150596232);
L_802F7E8C:
    // 0x802F7E8C: div         $zero, $t4, $s3
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r19)));
    // 0x802F7E90: mflo        $t3
    ctx->r11 = lo;
    // 0x802F7E94: sll         $t5, $t3, 2
    ctx->r13 = S32(ctx->r11 << 2);
    // 0x802F7E98: bne         $s3, $zero, L_802F7EA4
    if (ctx->r19 != 0) {
        // 0x802F7E9C: nop
    
            goto L_802F7EA4;
    }
    // 0x802F7E9C: nop

    // 0x802F7EA0: break       7
    do_break(2150596256);
L_802F7EA4:
    // 0x802F7EA4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F7EA8: bne         $s3, $at, L_802F7EBC
    if (ctx->r19 != ctx->r1) {
        // 0x802F7EAC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F7EBC;
    }
    // 0x802F7EAC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F7EB0: bne         $t4, $at, L_802F7EBC
    if (ctx->r12 != ctx->r1) {
        // 0x802F7EB4: nop
    
            goto L_802F7EBC;
    }
    // 0x802F7EB4: nop

    // 0x802F7EB8: break       6
    do_break(2150596280);
L_802F7EBC:
    // 0x802F7EBC: multu       $t5, $v1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F7EC0: mflo        $t6
    ctx->r14 = lo;
    // 0x802F7EC4: nop

    // 0x802F7EC8: nop

    // 0x802F7ECC: div         $zero, $t6, $fp
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r30))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r30)));
    // 0x802F7ED0: mflo        $a0
    ctx->r4 = lo;
    // 0x802F7ED4: bne         $fp, $zero, L_802F7EE0
    if (ctx->r30 != 0) {
        // 0x802F7ED8: nop
    
            goto L_802F7EE0;
    }
    // 0x802F7ED8: nop

    // 0x802F7EDC: break       7
    do_break(2150596316);
L_802F7EE0:
    // 0x802F7EE0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F7EE4: bne         $fp, $at, L_802F7EF8
    if (ctx->r30 != ctx->r1) {
        // 0x802F7EE8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F7EF8;
    }
    // 0x802F7EE8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F7EEC: bne         $t6, $at, L_802F7EF8
    if (ctx->r14 != ctx->r1) {
        // 0x802F7EF0: nop
    
            goto L_802F7EF8;
    }
    // 0x802F7EF0: nop

    // 0x802F7EF4: break       6
    do_break(2150596340);
L_802F7EF8:
    // 0x802F7EF8: bgez        $v0, L_802F7F24
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F7EFC: nop
    
            goto L_802F7F24;
    }
    // 0x802F7EFC: nop

    // 0x802F7F00: lw          $v1, 0x1C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X1C);
    // 0x802F7F04: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F7F08: beq         $at, $zero, L_802F7F24
    if (ctx->r1 == 0) {
        // 0x802F7F0C: addu        $t7, $v1, $v0
        ctx->r15 = ADD32(ctx->r3, ctx->r2);
            goto L_802F7F24;
    }
    // 0x802F7F0C: addu        $t7, $v1, $v0
    ctx->r15 = ADD32(ctx->r3, ctx->r2);
    // 0x802F7F10: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F7F14: beq         $at, $zero, L_802F7F4C
    if (ctx->r1 == 0) {
        // 0x802F7F18: sw          $t7, 0x1C($s0)
        MEM_W(0X1C, ctx->r16) = ctx->r15;
            goto L_802F7F4C;
    }
    // 0x802F7F18: sw          $t7, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r15;
    // 0x802F7F1C: b           L_802F7F4C
    // 0x802F7F20: sw          $v0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r2;
        goto L_802F7F4C;
    // 0x802F7F20: sw          $v0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r2;
L_802F7F24:
    // 0x802F7F24: blez        $v0, L_802F7F4C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F7F28: nop
    
            goto L_802F7F4C;
    }
    // 0x802F7F28: nop

    // 0x802F7F2C: lw          $v1, 0x1C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X1C);
    // 0x802F7F30: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F7F34: beq         $at, $zero, L_802F7F4C
    if (ctx->r1 == 0) {
        // 0x802F7F38: addu        $t9, $v1, $v0
        ctx->r25 = ADD32(ctx->r3, ctx->r2);
            goto L_802F7F4C;
    }
    // 0x802F7F38: addu        $t9, $v1, $v0
    ctx->r25 = ADD32(ctx->r3, ctx->r2);
    // 0x802F7F3C: slt         $at, $v0, $t9
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802F7F40: beq         $at, $zero, L_802F7F4C
    if (ctx->r1 == 0) {
        // 0x802F7F44: sw          $t9, 0x1C($s0)
        MEM_W(0X1C, ctx->r16) = ctx->r25;
            goto L_802F7F4C;
    }
    // 0x802F7F44: sw          $t9, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r25;
    // 0x802F7F48: sw          $v0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r2;
L_802F7F4C:
    // 0x802F7F4C: bgez        $a0, L_802F7F78
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802F7F50: nop
    
            goto L_802F7F78;
    }
    // 0x802F7F50: nop

    // 0x802F7F54: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802F7F58: slt         $at, $a0, $v0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F7F5C: beq         $at, $zero, L_802F7F78
    if (ctx->r1 == 0) {
        // 0x802F7F60: addu        $t3, $v0, $a0
        ctx->r11 = ADD32(ctx->r2, ctx->r4);
            goto L_802F7F78;
    }
    // 0x802F7F60: addu        $t3, $v0, $a0
    ctx->r11 = ADD32(ctx->r2, ctx->r4);
    // 0x802F7F64: slt         $at, $t3, $a0
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F7F68: beq         $at, $zero, L_802F7FA0
    if (ctx->r1 == 0) {
        // 0x802F7F6C: sw          $t3, 0x20($s0)
        MEM_W(0X20, ctx->r16) = ctx->r11;
            goto L_802F7FA0;
    }
    // 0x802F7F6C: sw          $t3, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r11;
    // 0x802F7F70: b           L_802F7FA0
    // 0x802F7F74: sw          $a0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r4;
        goto L_802F7FA0;
    // 0x802F7F74: sw          $a0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r4;
L_802F7F78:
    // 0x802F7F78: blezl       $a0, L_802F7FA4
    if (SIGNED(ctx->r4) <= 0) {
        // 0x802F7F7C: lbu         $t9, 0x4F($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X4F);
            goto L_802F7FA4;
    }
    goto skip_9;
    // 0x802F7F7C: lbu         $t9, 0x4F($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X4F);
    skip_9:
    // 0x802F7F80: lw          $v0, 0x20($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X20);
    // 0x802F7F84: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F7F88: beq         $at, $zero, L_802F7FA0
    if (ctx->r1 == 0) {
        // 0x802F7F8C: addu        $t6, $v0, $a0
        ctx->r14 = ADD32(ctx->r2, ctx->r4);
            goto L_802F7FA0;
    }
    // 0x802F7F8C: addu        $t6, $v0, $a0
    ctx->r14 = ADD32(ctx->r2, ctx->r4);
    // 0x802F7F90: slt         $at, $a0, $t6
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802F7F94: beq         $at, $zero, L_802F7FA0
    if (ctx->r1 == 0) {
        // 0x802F7F98: sw          $t6, 0x20($s0)
        MEM_W(0X20, ctx->r16) = ctx->r14;
            goto L_802F7FA0;
    }
    // 0x802F7F98: sw          $t6, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r14;
    // 0x802F7F9C: sw          $a0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r4;
L_802F7FA0:
    // 0x802F7FA0: lbu         $t9, 0x4F($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X4F);
L_802F7FA4:
    // 0x802F7FA4: lbu         $t3, 0x54($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X54);
    // 0x802F7FA8: sw          $zero, 0x58($s0)
    MEM_W(0X58, ctx->r16) = 0;
    // 0x802F7FAC: ori         $t4, $t9, 0x40
    ctx->r12 = ctx->r25 | 0X40;
    // 0x802F7FB0: ori         $t5, $t3, 0x9
    ctx->r13 = ctx->r11 | 0X9;
    // 0x802F7FB4: sb          $t4, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r12;
    // 0x802F7FB8: sb          $t5, 0x54($s0)
    MEM_B(0X54, ctx->r16) = ctx->r13;
    // 0x802F7FBC: lw          $t6, 0x16C($s6)
    ctx->r14 = MEM_W(ctx->r22, 0X16C);
    // 0x802F7FC0: addiu       $t8, $zero, 0xA
    ctx->r24 = ADD32(0, 0XA);
    // 0x802F7FC4: lhu         $t7, 0x0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X0);
    // 0x802F7FC8: sb          $t8, 0x56($s0)
    MEM_B(0X56, ctx->r16) = ctx->r24;
    // 0x802F7FCC: sb          $t7, 0x55($s0)
    MEM_B(0X55, ctx->r16) = ctx->r15;
L_802F7FD0:
    // 0x802F7FD0: lw          $s7, 0x0($s7)
    ctx->r23 = MEM_W(ctx->r23, 0X0);
L_802F7FD4:
    // 0x802F7FD4: bnel        $s7, $zero, L_802F7B08
    if (ctx->r23 != 0) {
        // 0x802F7FD8: lw          $s0, 0x8($s7)
        ctx->r16 = MEM_W(ctx->r23, 0X8);
            goto L_802F7B08;
    }
    goto skip_10;
    // 0x802F7FD8: lw          $s0, 0x8($s7)
    ctx->r16 = MEM_W(ctx->r23, 0X8);
    skip_10:
    // 0x802F7FDC: lh          $t9, 0xD0($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD0);
L_802F7FE0:
    // 0x802F7FE0: lw          $t3, 0x80($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X80);
    // 0x802F7FE4: addiu       $t4, $t9, 0x1
    ctx->r12 = ADD32(ctx->r25, 0X1);
    // 0x802F7FE8: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x802F7FEC: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F7FF0: slt         $at, $t3, $t6
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802F7FF4: beq         $at, $zero, L_802F7AC8
    if (ctx->r1 == 0) {
        // 0x802F7FF8: sh          $t4, 0xD0($sp)
        MEM_H(0XD0, ctx->r29) = ctx->r12;
            goto L_802F7AC8;
    }
    // 0x802F7FF8: sh          $t4, 0xD0($sp)
    MEM_H(0XD0, ctx->r29) = ctx->r12;
L_802F7FFC:
    // 0x802F7FFC: lh          $t7, 0xD2($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XD2);
    // 0x802F8000: lw          $t9, 0x84($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X84);
    // 0x802F8004: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x802F8008: sll         $t4, $t8, 16
    ctx->r12 = S32(ctx->r24 << 16);
    // 0x802F800C: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802F8010: slt         $at, $t9, $t5
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802F8014: beq         $at, $zero, L_802F7AA0
    if (ctx->r1 == 0) {
        // 0x802F8018: sh          $t8, 0xD2($sp)
        MEM_H(0XD2, ctx->r29) = ctx->r24;
            goto L_802F7AA0;
    }
    // 0x802F8018: sh          $t8, 0xD2($sp)
    MEM_H(0XD2, ctx->r29) = ctx->r24;
L_802F801C:
    // 0x802F801C: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x802F8020: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802F8024: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x802F8028: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x802F802C: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x802F8030: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x802F8034: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x802F8038: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x802F803C: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x802F8040: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x802F8044: jr          $ra
    // 0x802F8048: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
    return;
    // 0x802F8048: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
;}
RECOMP_FUNC void func_802F804C_7096FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F804C: mtc1        $a1, $f12
    ctx->f12.u32l = ctx->r5;
    // 0x802F8050: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802F8054: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802F8058: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802F805C: c.eq.s      $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f12.fl == ctx->f4.fl;
    // 0x802F8060: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x802F8064: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802F8068: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F806C: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x802F8070: bc1f        L_802F8080
    if (!c1cs) {
        // 0x802F8074: sw          $a3, 0x24($sp)
        MEM_W(0X24, ctx->r29) = ctx->r7;
            goto L_802F8080;
    }
    // 0x802F8074: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x802F8078: b           L_802F8150
    // 0x802F807C: addiu       $v0, $zero, 0x5A
    ctx->r2 = ADD32(0, 0X5A);
        goto L_802F8150;
    // 0x802F807C: addiu       $v0, $zero, 0x5A
    ctx->r2 = ADD32(0, 0X5A);
L_802F8080:
    // 0x802F8080: lwc1        $f6, 0x20($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X20);
    // 0x802F8084: lwc1        $f14, 0x28($sp)
    ctx->f14.u32l = MEM_W(ctx->r29, 0X28);
    // 0x802F8088: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x802F808C: mul.s       $f2, $f6, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f2.fl = MUL_S(ctx->f6.fl, ctx->f6.fl);
    // 0x802F8090: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x802F8094: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x802F8098: mul.s       $f8, $f12, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x802F809C: lui         $at, 0x4280
    ctx->r1 = S32(0X4280 << 16);
    // 0x802F80A0: add.s       $f4, $f2, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = ctx->f2.fl + ctx->f2.fl;
    // 0x802F80A4: mul.s       $f10, $f14, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f14.fl, ctx->f8.fl);
    // 0x802F80A8: lwc1        $f8, 0x24($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X24);
    // 0x802F80AC: div.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f10.fl, ctx->f4.fl);
    // 0x802F80B0: add.s       $f4, $f14, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = ctx->f14.fl + ctx->f14.fl;
    // 0x802F80B4: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x802F80B8: div.s       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = DIV_S(ctx->f4.fl, ctx->f2.fl);
    // 0x802F80BC: mul.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x802F80C0: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802F80C4: cvt.d.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f4.d = CVT_D_S(ctx->f8.fl);
    // 0x802F80C8: sub.d       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f16.d - ctx->f4.d;
    // 0x802F80CC: cvt.s.d     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f18.fl = CVT_S_D(ctx->f6.d);
    // 0x802F80D0: c.lt.s      $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f18.fl < ctx->f10.fl;
    // 0x802F80D4: nop

    // 0x802F80D8: bc1f        L_802F80E8
    if (!c1cs) {
        // 0x802F80DC: nop
    
            goto L_802F80E8;
    }
    // 0x802F80DC: nop

    // 0x802F80E0: b           L_802F8150
    // 0x802F80E4: addiu       $v0, $zero, 0x270F
    ctx->r2 = ADD32(0, 0X270F);
        goto L_802F8150;
    // 0x802F80E4: addiu       $v0, $zero, 0x270F
    ctx->r2 = ADD32(0, 0X270F);
L_802F80E8:
    // 0x802F80E8: beq         $a0, $zero, L_802F8110
    if (ctx->r4 == 0) {
        // 0x802F80EC: sqrt.s      $f0, $f18
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f0.fl = sqrtf(ctx->f18.fl);
            goto L_802F8110;
    }
    // 0x802F80EC: sqrt.s      $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f0.fl = sqrtf(ctx->f18.fl);
    // 0x802F80F0: mul.s       $f8, $f14, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = MUL_S(ctx->f14.fl, ctx->f12.fl);
    // 0x802F80F4: cvt.d.s     $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f10.d = CVT_D_S(ctx->f0.fl);
    // 0x802F80F8: div.s       $f4, $f2, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = DIV_S(ctx->f2.fl, ctx->f8.fl);
    // 0x802F80FC: add.d       $f8, $f16, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f10.d); 
    ctx->f8.d = ctx->f16.d + ctx->f10.d;
    // 0x802F8100: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x802F8104: mul.d       $f4, $f6, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f4.d = MUL_D(ctx->f6.d, ctx->f8.d);
    // 0x802F8108: b           L_802F812C
    // 0x802F810C: cvt.s.d     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f18.fl = CVT_S_D(ctx->f4.d);
        goto L_802F812C;
    // 0x802F810C: cvt.s.d     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f18.fl = CVT_S_D(ctx->f4.d);
L_802F8110:
    // 0x802F8110: mul.s       $f10, $f14, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = MUL_S(ctx->f14.fl, ctx->f12.fl);
    // 0x802F8114: cvt.d.s     $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f4.d = CVT_D_S(ctx->f0.fl);
    // 0x802F8118: div.s       $f6, $f2, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = DIV_S(ctx->f2.fl, ctx->f10.fl);
    // 0x802F811C: sub.d       $f10, $f16, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f4.d); 
    ctx->f10.d = ctx->f16.d - ctx->f4.d;
    // 0x802F8120: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x802F8124: mul.d       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f6.d = MUL_D(ctx->f8.d, ctx->f10.d);
    // 0x802F8128: cvt.s.d     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f18.fl = CVT_S_D(ctx->f6.d);
L_802F812C:
    // 0x802F812C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F8130: nop

    // 0x802F8134: mul.s       $f8, $f18, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f18.fl, ctx->f4.fl);
    // 0x802F8138: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802F813C: mfc1        $a0, $f10
    ctx->r4 = (int32_t)ctx->f10.u32l;
    // 0x802F8140: nop

    // 0x802F8144: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x802F8148: jal         0x8012844C
    // 0x802F814C: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    func_8012844C(rdram, ctx);
        goto after_0;
    // 0x802F814C: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    after_0:
L_802F8150:
    // 0x802F8150: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802F8154: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802F8158: jr          $ra
    // 0x802F815C: nop

    return;
    // 0x802F815C: nop

;}
RECOMP_FUNC void func_802F8160_709810(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8160: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802F8164: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x802F8168: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802F816C: sw          $a3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r7;
    // 0x802F8170: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802F8174: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F8178: lh          $t6, 0x4($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X4);
    // 0x802F817C: lh          $t5, 0x4($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X4);
    // 0x802F8180: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802F8184: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x802F8188: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802F818C: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F8190: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F8194: lh          $t8, 0x8($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X8);
    // 0x802F8198: lh          $t7, 0x8($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X8);
    // 0x802F819C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F81A0: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802F81A4: nop

    // 0x802F81A8: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F81AC: sub.s       $f2, $f6, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f2.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x802F81B0: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x802F81B4: nop

    // 0x802F81B8: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F81BC: mul.s       $f4, $f2, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x802F81C0: sub.s       $f12, $f8, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x802F81C4: mtc1        $a2, $f8
    ctx->f8.u32l = ctx->r6;
    // 0x802F81C8: mul.s       $f6, $f12, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x802F81CC: cvt.s.w     $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    ctx->f14.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F81D0: add.s       $f0, $f4, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x802F81D4: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F81D8: c.lt.s      $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f0.fl < ctx->f14.fl;
    // 0x802F81DC: sub.s       $f16, $f0, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f16.fl = ctx->f0.fl - ctx->f14.fl;
    // 0x802F81E0: bc1f        L_802F81F0
    if (!c1cs) {
        // 0x802F81E4: mov.s       $f18, $f16
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = ctx->f16.fl;
            goto L_802F81F0;
    }
    // 0x802F81E4: mov.s       $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = ctx->f16.fl;
    // 0x802F81E8: b           L_802F8648
    // 0x802F81EC: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
        goto L_802F8648;
    // 0x802F81EC: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802F81F0:
    // 0x802F81F0: lh          $t9, 0xC($a1)
    ctx->r25 = MEM_H(ctx->r5, 0XC);
    // 0x802F81F4: lh          $t5, 0xC($a0)
    ctx->r13 = MEM_H(ctx->r4, 0XC);
    // 0x802F81F8: lbu         $v0, 0x7F($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X7F);
    // 0x802F81FC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802F8200: subu        $t6, $t9, $t5
    ctx->r14 = SUB32(ctx->r25, ctx->r13);
    // 0x802F8204: subu        $t7, $t6, $a3
    ctx->r15 = SUB32(ctx->r14, ctx->r7);
    // 0x802F8208: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x802F820C: or          $t4, $v0, $zero
    ctx->r12 = ctx->r2 | 0;
    // 0x802F8210: bne         $v0, $at, L_802F8298
    if (ctx->r2 != ctx->r1) {
        // 0x802F8214: cvt.s.w     $f0, $f10
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802F8298;
    }
    // 0x802F8214: cvt.s.w     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F8218: lui         $at, 0x4200
    ctx->r1 = S32(0X4200 << 16);
    // 0x802F821C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F8220: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802F8224: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F8228: c.lt.s      $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f4.fl < ctx->f0.fl;
    // 0x802F822C: nop

    // 0x802F8230: bc1f        L_802F823C
    if (!c1cs) {
        // 0x802F8234: nop
    
            goto L_802F823C;
    }
    // 0x802F8234: nop

    // 0x802F8238: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F823C:
    // 0x802F823C: bne         $v0, $zero, L_802F8290
    if (ctx->r2 != 0) {
        // 0x802F8240: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802F8290;
    }
    // 0x802F8240: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802F8244: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802F8248: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F824C: c.lt.s      $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f6.fl < ctx->f16.fl;
    // 0x802F8250: nop

    // 0x802F8254: bc1f        L_802F8260
    if (!c1cs) {
        // 0x802F8258: nop
    
            goto L_802F8260;
    }
    // 0x802F8258: nop

    // 0x802F825C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F8260:
    // 0x802F8260: beq         $v0, $zero, L_802F8290
    if (ctx->r2 == 0) {
        // 0x802F8264: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802F8290;
    }
    // 0x802F8264: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802F8268: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x802F826C: swc1        $f0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->f0.u32l;
    // 0x802F8270: jal         0x80128200
    // 0x802F8274: swc1        $f18, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f18.u32l;
    func_80128200(rdram, ctx);
        goto after_0;
    // 0x802F8274: swc1        $f18, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f18.u32l;
    after_0:
    // 0x802F8278: andi        $a0, $v0, 0x3
    ctx->r4 = ctx->r2 & 0X3;
    // 0x802F827C: xori        $t8, $a0, 0x1
    ctx->r24 = ctx->r4 ^ 0X1;
    // 0x802F8280: sltiu       $a0, $t8, 0x1
    ctx->r4 = ctx->r24 < 0X1 ? 1 : 0;
    // 0x802F8284: lw          $t4, 0x24($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X24);
    // 0x802F8288: lwc1        $f0, 0x50($sp)
    ctx->f0.u32l = MEM_W(ctx->r29, 0X50);
    // 0x802F828C: lwc1        $f18, 0x54($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X54);
L_802F8290:
    // 0x802F8290: b           L_802F82B0
    // 0x802F8294: sb          $a0, 0x45($sp)
    MEM_B(0X45, ctx->r29) = ctx->r4;
        goto L_802F82B0;
    // 0x802F8294: sb          $a0, 0x45($sp)
    MEM_B(0X45, ctx->r29) = ctx->r4;
L_802F8298:
    // 0x802F8298: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802F829C: bnel        $t4, $at, L_802F82B0
    if (ctx->r12 != ctx->r1) {
        // 0x802F82A0: sb          $v0, 0x45($sp)
        MEM_B(0X45, ctx->r29) = ctx->r2;
            goto L_802F82B0;
    }
    goto skip_0;
    // 0x802F82A0: sb          $v0, 0x45($sp)
    MEM_B(0X45, ctx->r29) = ctx->r2;
    skip_0:
    // 0x802F82A4: b           L_802F82B0
    // 0x802F82A8: sb          $zero, 0x45($sp)
    MEM_B(0X45, ctx->r29) = 0;
        goto L_802F82B0;
    // 0x802F82A8: sb          $zero, 0x45($sp)
    MEM_B(0X45, ctx->r29) = 0;
    // 0x802F82AC: sb          $v0, 0x45($sp)
    MEM_B(0X45, ctx->r29) = ctx->r2;
L_802F82B0:
    // 0x802F82B0: lh          $t9, 0x72($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X72);
    // 0x802F82B4: lwc1        $f10, 0x80($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X80);
    // 0x802F82B8: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x802F82BC: mtc1        $t9, $f8
    ctx->f8.u32l = ctx->r25;
    // 0x802F82C0: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x802F82C4: lbu         $a0, 0x45($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X45);
    // 0x802F82C8: cvt.s.w     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    ctx->f2.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F82CC: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x802F82D0: swc1        $f0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->f0.u32l;
    // 0x802F82D4: swc1        $f18, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f18.u32l;
    // 0x802F82D8: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x802F82DC: mfc1        $a2, $f2
    ctx->r6 = (int32_t)ctx->f2.u32l;
    // 0x802F82E0: jal         0x802F804C
    // 0x802F82E4: swc1        $f2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->f2.u32l;
    func_802F804C_7096FC(rdram, ctx);
        goto after_1;
    // 0x802F82E4: swc1        $f2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->f2.u32l;
    after_1:
    // 0x802F82E8: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x802F82EC: sra         $t5, $t1, 16
    ctx->r13 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F82F0: addiu       $at, $zero, 0x270F
    ctx->r1 = ADD32(0, 0X270F);
    // 0x802F82F4: or          $t1, $t5, $zero
    ctx->r9 = ctx->r13 | 0;
    // 0x802F82F8: lw          $t4, 0x24($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X24);
    // 0x802F82FC: lwc1        $f0, 0x50($sp)
    ctx->f0.u32l = MEM_W(ctx->r29, 0X50);
    // 0x802F8300: lwc1        $f2, 0x28($sp)
    ctx->f2.u32l = MEM_W(ctx->r29, 0X28);
    // 0x802F8304: bne         $v0, $at, L_802F8314
    if (ctx->r2 != ctx->r1) {
        // 0x802F8308: lwc1        $f18, 0x54($sp)
        ctx->f18.u32l = MEM_W(ctx->r29, 0X54);
            goto L_802F8314;
    }
    // 0x802F8308: lwc1        $f18, 0x54($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X54);
    // 0x802F830C: b           L_802F8648
    // 0x802F8310: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
        goto L_802F8648;
    // 0x802F8310: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802F8314:
    // 0x802F8314: lh          $t3, 0x76($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X76);
    // 0x802F8318: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F831C: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8320: slt         $at, $t3, $t6
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802F8324: beq         $at, $zero, L_802F8360
    if (ctx->r1 == 0) {
        // 0x802F8328: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_802F8360;
    }
    // 0x802F8328: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802F832C: subu        $v0, $t6, $t3
    ctx->r2 = SUB32(ctx->r14, ctx->r11);
    // 0x802F8330: bgez        $v0, L_802F8348
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F8334: sll         $t1, $t3, 16
        ctx->r9 = S32(ctx->r11 << 16);
            goto L_802F8348;
    }
    // 0x802F8334: sll         $t1, $t3, 16
    ctx->r9 = S32(ctx->r11 << 16);
    // 0x802F8338: negu        $t2, $v0
    ctx->r10 = SUB32(0, ctx->r2);
    // 0x802F833C: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x802F8340: b           L_802F8354
    // 0x802F8344: sra         $t2, $t7, 16
    ctx->r10 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802F8354;
    // 0x802F8344: sra         $t2, $t7, 16
    ctx->r10 = S32(SIGNED(ctx->r15) >> 16);
L_802F8348:
    // 0x802F8348: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x802F834C: sra         $t9, $t2, 16
    ctx->r25 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802F8350: or          $t2, $t9, $zero
    ctx->r10 = ctx->r25 | 0;
L_802F8354:
    // 0x802F8354: sra         $t5, $t1, 16
    ctx->r13 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F8358: b           L_802F8430
    // 0x802F835C: or          $t1, $t5, $zero
    ctx->r9 = ctx->r13 | 0;
        goto L_802F8430;
    // 0x802F835C: or          $t1, $t5, $zero
    ctx->r9 = ctx->r13 | 0;
L_802F8360:
    // 0x802F8360: lh          $t0, 0x7A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7A);
    // 0x802F8364: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802F8368: beq         $at, $zero, L_802F8414
    if (ctx->r1 == 0) {
        // 0x802F836C: nop
    
            goto L_802F8414;
    }
    // 0x802F836C: nop

    // 0x802F8370: bgez        $v1, L_802F8380
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F8374: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802F8380;
    }
    // 0x802F8374: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802F8378: b           L_802F8380
    // 0x802F837C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802F8380;
    // 0x802F837C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802F8380:
    // 0x802F8380: bgez        $t0, L_802F8390
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F8384: or          $a0, $t0, $zero
        ctx->r4 = ctx->r8 | 0;
            goto L_802F8390;
    }
    // 0x802F8384: or          $a0, $t0, $zero
    ctx->r4 = ctx->r8 | 0;
    // 0x802F8388: b           L_802F8390
    // 0x802F838C: negu        $a0, $t0
    ctx->r4 = SUB32(0, ctx->r8);
        goto L_802F8390;
    // 0x802F838C: negu        $a0, $t0
    ctx->r4 = SUB32(0, ctx->r8);
L_802F8390:
    // 0x802F8390: subu        $t6, $v0, $a0
    ctx->r14 = SUB32(ctx->r2, ctx->r4);
    // 0x802F8394: bgez        $t6, L_802F83DC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802F8398: sll         $t1, $t0, 16
        ctx->r9 = S32(ctx->r8 << 16);
            goto L_802F83DC;
    }
    // 0x802F8398: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802F839C: bgez        $v1, L_802F83AC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F83A0: sll         $t1, $t0, 16
        ctx->r9 = S32(ctx->r8 << 16);
            goto L_802F83AC;
    }
    // 0x802F83A0: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802F83A4: b           L_802F83B0
    // 0x802F83A8: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_802F83B0;
    // 0x802F83A8: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_802F83AC:
    // 0x802F83AC: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_802F83B0:
    // 0x802F83B0: bgez        $t0, L_802F83C0
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F83B4: sra         $t6, $t1, 16
        ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
            goto L_802F83C0;
    }
    // 0x802F83B4: sra         $t6, $t1, 16
    ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F83B8: b           L_802F83C4
    // 0x802F83BC: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
        goto L_802F83C4;
    // 0x802F83BC: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
L_802F83C0:
    // 0x802F83C0: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
L_802F83C4:
    // 0x802F83C4: subu        $t2, $a0, $v0
    ctx->r10 = SUB32(ctx->r4, ctx->r2);
    // 0x802F83C8: negu        $t2, $t2
    ctx->r10 = SUB32(0, ctx->r10);
    // 0x802F83CC: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x802F83D0: sra         $t2, $t7, 16
    ctx->r10 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F83D4: b           L_802F8430
    // 0x802F83D8: or          $t1, $t6, $zero
    ctx->r9 = ctx->r14 | 0;
        goto L_802F8430;
    // 0x802F83D8: or          $t1, $t6, $zero
    ctx->r9 = ctx->r14 | 0;
L_802F83DC:
    // 0x802F83DC: bgez        $v1, L_802F83EC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F83E0: sra         $t6, $t1, 16
        ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
            goto L_802F83EC;
    }
    // 0x802F83E0: sra         $t6, $t1, 16
    ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F83E4: b           L_802F83F0
    // 0x802F83E8: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_802F83F0;
    // 0x802F83E8: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_802F83EC:
    // 0x802F83EC: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_802F83F0:
    // 0x802F83F0: bgez        $t0, L_802F8400
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F83F4: or          $v0, $t0, $zero
        ctx->r2 = ctx->r8 | 0;
            goto L_802F8400;
    }
    // 0x802F83F4: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x802F83F8: b           L_802F8400
    // 0x802F83FC: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
        goto L_802F8400;
    // 0x802F83FC: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
L_802F8400:
    // 0x802F8400: subu        $t2, $a0, $v0
    ctx->r10 = SUB32(ctx->r4, ctx->r2);
    // 0x802F8404: sll         $t9, $t2, 16
    ctx->r25 = S32(ctx->r10 << 16);
    // 0x802F8408: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F840C: b           L_802F8430
    // 0x802F8410: or          $t1, $t6, $zero
    ctx->r9 = ctx->r14 | 0;
        goto L_802F8430;
    // 0x802F8410: or          $t1, $t6, $zero
    ctx->r9 = ctx->r14 | 0;
L_802F8414:
    // 0x802F8414: bgez        $v1, L_802F8428
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F8418: nop
    
            goto L_802F8428;
    }
    // 0x802F8418: nop

    // 0x802F841C: addiu       $t1, $v1, 0x168
    ctx->r9 = ADD32(ctx->r3, 0X168);
    // 0x802F8420: sll         $t7, $t1, 16
    ctx->r15 = S32(ctx->r9 << 16);
    // 0x802F8424: sra         $t1, $t7, 16
    ctx->r9 = S32(SIGNED(ctx->r15) >> 16);
L_802F8428:
    // 0x802F8428: b           L_802F8648
    // 0x802F842C: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
        goto L_802F8648;
    // 0x802F842C: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
L_802F8430:
    // 0x802F8430: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802F8434: bne         $t4, $at, L_802F8474
    if (ctx->r12 != ctx->r1) {
        // 0x802F8438: lbu         $a0, 0x45($sp)
        ctx->r4 = MEM_BU(ctx->r29, 0X45);
            goto L_802F8474;
    }
    // 0x802F8438: lbu         $a0, 0x45($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X45);
    // 0x802F843C: lui         $at, 0x428C
    ctx->r1 = S32(0X428C << 16);
    // 0x802F8440: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F8444: nop

    // 0x802F8448: c.lt.s      $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f18.fl < ctx->f4.fl;
    // 0x802F844C: nop

    // 0x802F8450: bc1fl       L_802F8478
    if (!c1cs) {
        // 0x802F8454: lwc1        $f6, 0x80($sp)
        ctx->f6.u32l = MEM_W(ctx->r29, 0X80);
            goto L_802F8478;
    }
    goto skip_1;
    // 0x802F8454: lwc1        $f6, 0x80($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X80);
    skip_1:
    // 0x802F8458: bgez        $t1, L_802F846C
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802F845C: nop
    
            goto L_802F846C;
    }
    // 0x802F845C: nop

    // 0x802F8460: addiu       $t1, $t1, 0x168
    ctx->r9 = ADD32(ctx->r9, 0X168);
    // 0x802F8464: sll         $t9, $t1, 16
    ctx->r25 = S32(ctx->r9 << 16);
    // 0x802F8468: sra         $t1, $t9, 16
    ctx->r9 = S32(SIGNED(ctx->r25) >> 16);
L_802F846C:
    // 0x802F846C: b           L_802F8648
    // 0x802F8470: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
        goto L_802F8648;
    // 0x802F8470: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
L_802F8474:
    // 0x802F8474: lwc1        $f6, 0x80($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X80);
L_802F8478:
    // 0x802F8478: sltiu       $t6, $a0, 0x1
    ctx->r14 = ctx->r4 < 0X1 ? 1 : 0;
    // 0x802F847C: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x802F8480: mfc1        $a2, $f2
    ctx->r6 = (int32_t)ctx->f2.u32l;
    // 0x802F8484: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x802F8488: andi        $a0, $t6, 0xFF
    ctx->r4 = ctx->r14 & 0XFF;
    // 0x802F848C: sh          $t1, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r9;
    // 0x802F8490: sh          $t2, 0x4A($sp)
    MEM_H(0X4A, ctx->r29) = ctx->r10;
    // 0x802F8494: jal         0x802F804C
    // 0x802F8498: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    func_802F804C_7096FC(rdram, ctx);
        goto after_2;
    // 0x802F8498: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    after_2:
    // 0x802F849C: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x802F84A0: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F84A4: addiu       $at, $zero, 0x270F
    ctx->r1 = ADD32(0, 0X270F);
    // 0x802F84A8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x802F84AC: lh          $t0, 0x7A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7A);
    // 0x802F84B0: lh          $t1, 0x4E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X4E);
    // 0x802F84B4: lh          $t2, 0x4A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X4A);
    // 0x802F84B8: bne         $v0, $at, L_802F84C8
    if (ctx->r2 != ctx->r1) {
        // 0x802F84BC: lh          $t3, 0x76($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X76);
            goto L_802F84C8;
    }
    // 0x802F84BC: lh          $t3, 0x76($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X76);
    // 0x802F84C0: b           L_802F8648
    // 0x802F84C4: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
        goto L_802F8648;
    // 0x802F84C4: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802F84C8:
    // 0x802F84C8: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F84CC: sra         $t9, $v1, 16
    ctx->r25 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F84D0: slt         $at, $t3, $t9
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802F84D4: beq         $at, $zero, L_802F851C
    if (ctx->r1 == 0) {
        // 0x802F84D8: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_802F851C;
    }
    // 0x802F84D8: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x802F84DC: subu        $v0, $t9, $t3
    ctx->r2 = SUB32(ctx->r25, ctx->r11);
    // 0x802F84E0: bgez        $v0, L_802F8504
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F84E4: sll         $v1, $v0, 16
        ctx->r3 = S32(ctx->r2 << 16);
            goto L_802F8504;
    }
    // 0x802F84E4: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F84E8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x802F84EC: sll         $a0, $t3, 16
    ctx->r4 = S32(ctx->r11 << 16);
    // 0x802F84F0: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802F84F4: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F84F8: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F84FC: b           L_802F85EC
    // 0x802F8500: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
        goto L_802F85EC;
    // 0x802F8500: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
L_802F8504:
    // 0x802F8504: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8508: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x802F850C: sll         $a0, $t3, 16
    ctx->r4 = S32(ctx->r11 << 16);
    // 0x802F8510: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8514: b           L_802F85EC
    // 0x802F8518: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
        goto L_802F85EC;
    // 0x802F8518: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
L_802F851C:
    // 0x802F851C: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802F8520: beq         $at, $zero, L_802F85D0
    if (ctx->r1 == 0) {
        // 0x802F8524: nop
    
            goto L_802F85D0;
    }
    // 0x802F8524: nop

    // 0x802F8528: bgez        $v1, L_802F8538
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F852C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802F8538;
    }
    // 0x802F852C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802F8530: b           L_802F8538
    // 0x802F8534: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
        goto L_802F8538;
    // 0x802F8534: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
L_802F8538:
    // 0x802F8538: bgez        $t0, L_802F8548
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F853C: or          $a0, $t0, $zero
        ctx->r4 = ctx->r8 | 0;
            goto L_802F8548;
    }
    // 0x802F853C: or          $a0, $t0, $zero
    ctx->r4 = ctx->r8 | 0;
    // 0x802F8540: b           L_802F8548
    // 0x802F8544: negu        $a0, $t0
    ctx->r4 = SUB32(0, ctx->r8);
        goto L_802F8548;
    // 0x802F8544: negu        $a0, $t0
    ctx->r4 = SUB32(0, ctx->r8);
L_802F8548:
    // 0x802F8548: subu        $t9, $v0, $a0
    ctx->r25 = SUB32(ctx->r2, ctx->r4);
    // 0x802F854C: bgez        $t9, L_802F8594
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802F8550: nop
    
            goto L_802F8594;
    }
    // 0x802F8550: nop

    // 0x802F8554: bgez        $v1, L_802F8564
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F8558: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802F8564;
    }
    // 0x802F8558: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802F855C: b           L_802F8564
    // 0x802F8560: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_802F8564;
    // 0x802F8560: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_802F8564:
    // 0x802F8564: bgez        $t0, L_802F8574
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F8568: or          $v0, $t0, $zero
        ctx->r2 = ctx->r8 | 0;
            goto L_802F8574;
    }
    // 0x802F8568: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x802F856C: b           L_802F8574
    // 0x802F8570: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
        goto L_802F8574;
    // 0x802F8570: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
L_802F8574:
    // 0x802F8574: subu        $v1, $a0, $v0
    ctx->r3 = SUB32(ctx->r4, ctx->r2);
    // 0x802F8578: negu        $v1, $v1
    ctx->r3 = SUB32(0, ctx->r3);
    // 0x802F857C: sll         $a0, $t0, 16
    ctx->r4 = S32(ctx->r8 << 16);
    // 0x802F8580: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802F8584: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8588: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F858C: b           L_802F85EC
    // 0x802F8590: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
        goto L_802F85EC;
    // 0x802F8590: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_802F8594:
    // 0x802F8594: bgez        $v1, L_802F85A4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F8598: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802F85A4;
    }
    // 0x802F8598: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802F859C: b           L_802F85A4
    // 0x802F85A0: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_802F85A4;
    // 0x802F85A0: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_802F85A4:
    // 0x802F85A4: bgez        $t0, L_802F85B4
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F85A8: or          $v0, $t0, $zero
        ctx->r2 = ctx->r8 | 0;
            goto L_802F85B4;
    }
    // 0x802F85A8: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x802F85AC: b           L_802F85B4
    // 0x802F85B0: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
        goto L_802F85B4;
    // 0x802F85B0: negu        $v0, $t0
    ctx->r2 = SUB32(0, ctx->r8);
L_802F85B4:
    // 0x802F85B4: subu        $v1, $a0, $v0
    ctx->r3 = SUB32(ctx->r4, ctx->r2);
    // 0x802F85B8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802F85BC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F85C0: sll         $a0, $t0, 16
    ctx->r4 = S32(ctx->r8 << 16);
    // 0x802F85C4: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F85C8: b           L_802F85EC
    // 0x802F85CC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
        goto L_802F85EC;
    // 0x802F85CC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_802F85D0:
    // 0x802F85D0: bgez        $v1, L_802F85E4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F85D4: nop
    
            goto L_802F85E4;
    }
    // 0x802F85D4: nop

    // 0x802F85D8: addiu       $a0, $v1, 0x168
    ctx->r4 = ADD32(ctx->r3, 0X168);
    // 0x802F85DC: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x802F85E0: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
L_802F85E4:
    // 0x802F85E4: b           L_802F8648
    // 0x802F85E8: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
        goto L_802F8648;
    // 0x802F85E8: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_802F85EC:
    // 0x802F85EC: slt         $at, $t2, $v1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F85F0: beq         $at, $zero, L_802F8610
    if (ctx->r1 == 0) {
        // 0x802F85F4: slti        $at, $t2, 0x5
        ctx->r1 = SIGNED(ctx->r10) < 0X5 ? 1 : 0;
            goto L_802F8610;
    }
    // 0x802F85F4: slti        $at, $t2, 0x5
    ctx->r1 = SIGNED(ctx->r10) < 0X5 ? 1 : 0;
    // 0x802F85F8: beql        $at, $zero, L_802F8614
    if (ctx->r1 == 0) {
        // 0x802F85FC: slti        $at, $v1, 0x5
        ctx->r1 = SIGNED(ctx->r3) < 0X5 ? 1 : 0;
            goto L_802F8614;
    }
    goto skip_2;
    // 0x802F85FC: slti        $at, $v1, 0x5
    ctx->r1 = SIGNED(ctx->r3) < 0X5 ? 1 : 0;
    skip_2:
    // 0x802F8600: sll         $v1, $t1, 16
    ctx->r3 = S32(ctx->r9 << 16);
    // 0x802F8604: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8608: b           L_802F8630
    // 0x802F860C: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
        goto L_802F8630;
    // 0x802F860C: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_802F8610:
    // 0x802F8610: slti        $at, $v1, 0x5
    ctx->r1 = SIGNED(ctx->r3) < 0X5 ? 1 : 0;
L_802F8614:
    // 0x802F8614: beq         $at, $zero, L_802F8628
    if (ctx->r1 == 0) {
        // 0x802F8618: sll         $v1, $a0, 16
        ctx->r3 = S32(ctx->r4 << 16);
            goto L_802F8628;
    }
    // 0x802F8618: sll         $v1, $a0, 16
    ctx->r3 = S32(ctx->r4 << 16);
    // 0x802F861C: sra         $t8, $v1, 16
    ctx->r24 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8620: b           L_802F8630
    // 0x802F8624: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
        goto L_802F8630;
    // 0x802F8624: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_802F8628:
    // 0x802F8628: b           L_802F8648
    // 0x802F862C: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
        goto L_802F8648;
    // 0x802F862C: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802F8630:
    // 0x802F8630: bgezl       $v1, L_802F8648
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802F8634: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802F8648;
    }
    goto skip_3;
    // 0x802F8634: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    skip_3:
    // 0x802F8638: addiu       $v1, $v1, 0x168
    ctx->r3 = ADD32(ctx->r3, 0X168);
    // 0x802F863C: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x802F8640: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F8644: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802F8648:
    // 0x802F8648: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802F864C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802F8650: jr          $ra
    // 0x802F8654: nop

    return;
    // 0x802F8654: nop

;}
RECOMP_FUNC void func_802F8658_709D08(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8658: addiu       $sp, $sp, -0x68
    ctx->r29 = ADD32(ctx->r29, -0X68);
    // 0x802F865C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802F8660: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802F8664: lh          $t7, 0x4($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X4);
    // 0x802F8668: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x802F866C: mtc1        $a3, $f12
    ctx->f12.u32l = ctx->r7;
    // 0x802F8670: mtc1        $a2, $f14
    ctx->f14.u32l = ctx->r6;
    // 0x802F8674: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802F8678: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x802F867C: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x802F8680: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F8684: swc1        $f6, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->f6.u32l;
    // 0x802F8688: lh          $t0, 0x8($a1)
    ctx->r8 = MEM_H(ctx->r5, 0X8);
    // 0x802F868C: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x802F8690: mul.s       $f4, $f6, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f6.fl);
    // 0x802F8694: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x802F8698: mtc1        $t1, $f8
    ctx->f8.u32l = ctx->r9;
    // 0x802F869C: nop

    // 0x802F86A0: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F86A4: swc1        $f10, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->f10.u32l;
    // 0x802F86A8: lhu         $t3, 0x42($a0)
    ctx->r11 = MEM_HU(ctx->r4, 0X42);
    // 0x802F86AC: lh          $t2, 0xC($a0)
    ctx->r10 = MEM_H(ctx->r4, 0XC);
    // 0x802F86B0: lh          $t5, 0xC($a1)
    ctx->r13 = MEM_H(ctx->r5, 0XC);
    // 0x802F86B4: lhu         $t7, 0x42($a1)
    ctx->r15 = MEM_HU(ctx->r5, 0X42);
    // 0x802F86B8: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x802F86BC: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x802F86C0: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802F86C4: mtc1        $t8, $f16
    ctx->f16.u32l = ctx->r24;
    // 0x802F86C8: mul.s       $f8, $f10, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f10.fl);
    // 0x802F86CC: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x802F86D0: add.s       $f16, $f4, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x802F86D4: mul.s       $f6, $f18, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f18.fl);
    // 0x802F86D8: swc1        $f18, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->f18.u32l;
    // 0x802F86DC: add.s       $f0, $f16, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = ctx->f16.fl + ctx->f6.fl;
    // 0x802F86E0: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F86E4: c.lt.s      $f12, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f12.fl < ctx->f0.fl;
    // 0x802F86E8: swc1        $f0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->f0.u32l;
    // 0x802F86EC: bc1fl       L_802F8700
    if (!c1cs) {
        // 0x802F86F0: lh          $t9, 0x1C($s0)
        ctx->r25 = MEM_H(ctx->r16, 0X1C);
            goto L_802F8700;
    }
    goto skip_0;
    // 0x802F86F0: lh          $t9, 0x1C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1C);
    skip_0:
    // 0x802F86F4: b           L_802F8904
    // 0x802F86F8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802F8904;
    // 0x802F86F8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F86FC: lh          $t9, 0x1C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X1C);
L_802F8700:
    // 0x802F8700: addiu       $a0, $sp, 0x44
    ctx->r4 = ADD32(ctx->r29, 0X44);
    // 0x802F8704: addiu       $a1, $sp, 0x38
    ctx->r5 = ADD32(ctx->r29, 0X38);
    // 0x802F8708: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x802F870C: nop

    // 0x802F8710: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F8714: swc1        $f4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->f4.u32l;
    // 0x802F8718: lh          $t0, 0x20($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X20);
    // 0x802F871C: lwc1        $f10, 0x38($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X38);
    // 0x802F8720: mtc1        $t0, $f8
    ctx->f8.u32l = ctx->r8;
    // 0x802F8724: mul.s       $f4, $f10, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f10.fl);
    // 0x802F8728: cvt.s.w     $f18, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    ctx->f18.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F872C: swc1        $f18, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->f18.u32l;
    // 0x802F8730: lh          $t1, 0x24($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X24);
    // 0x802F8734: lwc1        $f8, 0x3C($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X3C);
    // 0x802F8738: mtc1        $t1, $f16
    ctx->f16.u32l = ctx->r9;
    // 0x802F873C: mul.s       $f18, $f8, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f18.fl = MUL_S(ctx->f8.fl, ctx->f8.fl);
    // 0x802F8740: cvt.s.w     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    ctx->f6.fl = CVT_S_W(ctx->f16.u32l);
    // 0x802F8744: add.s       $f16, $f4, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f4.fl + ctx->f18.fl;
    // 0x802F8748: swc1        $f6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->f6.u32l;
    // 0x802F874C: lwc1        $f6, 0x40($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X40);
    // 0x802F8750: mul.s       $f10, $f6, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f6.fl);
    // 0x802F8754: add.s       $f0, $f16, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f0.fl = ctx->f16.fl + ctx->f10.fl;
    // 0x802F8758: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F875C: div.s       $f8, $f0, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = DIV_S(ctx->f0.fl, ctx->f14.fl);
    // 0x802F8760: jal         0x8032D5A4
    // 0x802F8764: swc1        $f8, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f8.u32l;
    get_angle_between_vectors(rdram, ctx);
        goto after_0;
    // 0x802F8764: swc1        $f8, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->f8.u32l;
    after_0:
    // 0x802F8768: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x802F876C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F8770: ldc1        $f16, -0x3108($at)
    CHECK_FR(ctx, 16);
    ctx->f16.u64 = LD(ctx->r1, -0X3108);
    // 0x802F8774: cvt.s.w     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    ctx->f18.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F8778: sh          $v0, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r2;
    // 0x802F877C: cvt.d.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.d = CVT_D_S(ctx->f18.fl);
    // 0x802F8780: mul.d       $f10, $f6, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f16.d); 
    ctx->f10.d = MUL_D(ctx->f6.d, ctx->f16.d);
    // 0x802F8784: jal         0x8013FEE0
    // 0x802F8788: cvt.s.d     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f12.fl = CVT_S_D(ctx->f10.d);
    __sinf_recomp(rdram, ctx);
        goto after_1;
    // 0x802F8788: cvt.s.d     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f12.fl = CVT_S_D(ctx->f10.d);
    after_1:
    // 0x802F878C: lwc1        $f8, 0x60($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X60);
    // 0x802F8790: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802F8794: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x802F8798: mul.s       $f4, $f0, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x802F879C: nop

    // 0x802F87A0: mul.s       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f18.fl);
    // 0x802F87A4: trunc.w.s   $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    ctx->f16.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802F87A8: mfc1        $a0, $f16
    ctx->r4 = (int32_t)ctx->f16.u32l;
    // 0x802F87AC: nop

    // 0x802F87B0: sll         $t3, $a0, 16
    ctx->r11 = S32(ctx->r4 << 16);
    // 0x802F87B4: jal         0x8012835C
    // 0x802F87B8: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    func_8012835C(rdram, ctx);
        goto after_2;
    // 0x802F87B8: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    after_2:
    // 0x802F87BC: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x802F87C0: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802F87C4: lh          $t9, 0x2A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2A);
    // 0x802F87C8: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F87CC: c.lt.s      $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f14.fl < ctx->f10.fl;
    // 0x802F87D0: sra         $t5, $v1, 16
    ctx->r13 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F87D4: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x802F87D8: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x802F87DC: bc1f        L_802F87F0
    if (!c1cs) {
        // 0x802F87E0: nop
    
            goto L_802F87F0;
    }
    // 0x802F87E0: nop

    // 0x802F87E4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x802F87E8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802F87EC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
L_802F87F0:
    // 0x802F87F0: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x802F87F4: addiu       $v0, $v0, 0x2350
    ctx->r2 = ADD32(ctx->r2, 0X2350);
    // 0x802F87F8: addu        $t1, $v0, $t0
    ctx->r9 = ADD32(ctx->r2, ctx->r8);
    // 0x802F87FC: lh          $t2, 0x384($t1)
    ctx->r10 = MEM_H(ctx->r9, 0X384);
    // 0x802F8800: lwc1        $f18, 0x60($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X60);
    // 0x802F8804: sll         $t7, $v1, 1
    ctx->r15 = S32(ctx->r3 << 1);
    // 0x802F8808: mtc1        $t2, $f8
    ctx->f8.u32l = ctx->r10;
    // 0x802F880C: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x802F8810: lh          $t9, 0x384($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X384);
    // 0x802F8814: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802F8818: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802F881C: mul.s       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f18.fl);
    // 0x802F8820: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F8824: lwc1        $f18, 0x50($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X50);
    // 0x802F8828: trunc.w.s   $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    ctx->f16.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802F882C: mfc1        $t4, $f16
    ctx->r12 = (int32_t)ctx->f16.u32l;
    // 0x802F8830: nop

    // 0x802F8834: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x802F8838: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F883C: addu        $t0, $t6, $t9
    ctx->r8 = ADD32(ctx->r14, ctx->r25);
    // 0x802F8840: mtc1        $t0, $f10
    ctx->f10.u32l = ctx->r8;
    // 0x802F8844: nop

    // 0x802F8848: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F884C: div.s       $f0, $f8, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802F8850: c.eq.s      $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f0.fl == ctx->f14.fl;
    // 0x802F8854: nop

    // 0x802F8858: bc1fl       L_802F886C
    if (!c1cs) {
        // 0x802F885C: div.s       $f6, $f18, $f0
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f0.fl);
            goto L_802F886C;
    }
    goto skip_1;
    // 0x802F885C: div.s       $f6, $f18, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f0.fl);
    skip_1:
    // 0x802F8860: b           L_802F8904
    // 0x802F8864: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802F8904;
    // 0x802F8864: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F8868: div.s       $f6, $f18, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f0.fl);
L_802F886C:
    // 0x802F886C: addiu       $a0, $sp, 0x38
    ctx->r4 = ADD32(ctx->r29, 0X38);
    // 0x802F8870: jal         0x8032D440
    // 0x802F8874: swc1        $f6, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->f6.u32l;
    get_magnitude(rdram, ctx);
        goto after_3;
    // 0x802F8874: swc1        $f6, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->f6.u32l;
    after_3:
    // 0x802F8878: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x802F887C: lwc1        $f16, 0x38($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X38);
    // 0x802F8880: lwc1        $f10, 0x3C($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X3C);
    // 0x802F8884: c.eq.s      $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f0.fl == ctx->f14.fl;
    // 0x802F8888: lwc1        $f8, 0x60($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X60);
    // 0x802F888C: lwc1        $f4, 0x5C($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X5C);
    // 0x802F8890: bc1fl       L_802F88A8
    if (!c1cs) {
        // 0x802F8894: div.s       $f12, $f16, $f0
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f0.fl);
            goto L_802F88A8;
    }
    goto skip_2;
    // 0x802F8894: div.s       $f12, $f16, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f0.fl);
    skip_2:
    // 0x802F8898: mov.s       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.fl = ctx->f14.fl;
    // 0x802F889C: b           L_802F88AC
    // 0x802F88A0: mov.s       $f12, $f14
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    ctx->f12.fl = ctx->f14.fl;
        goto L_802F88AC;
    // 0x802F88A0: mov.s       $f12, $f14
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    ctx->f12.fl = ctx->f14.fl;
    // 0x802F88A4: div.s       $f12, $f16, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f0.fl);
L_802F88A8:
    // 0x802F88A8: div.s       $f2, $f10, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = DIV_S(ctx->f10.fl, ctx->f0.fl);
L_802F88AC:
    // 0x802F88AC: mul.s       $f0, $f8, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = MUL_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802F88B0: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802F88B4: lw          $v1, 0x78($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X78);
    // 0x802F88B8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802F88BC: mul.s       $f18, $f0, $f12
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f18.fl = MUL_S(ctx->f0.fl, ctx->f12.fl);
    // 0x802F88C0: trunc.w.s   $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x802F88C4: mul.s       $f16, $f0, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = MUL_S(ctx->f0.fl, ctx->f2.fl);
    // 0x802F88C8: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x802F88CC: nop

    // 0x802F88D0: addu        $t7, $t1, $t5
    ctx->r15 = ADD32(ctx->r9, ctx->r13);
    // 0x802F88D4: trunc.w.s   $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    ctx->f10.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802F88D8: sh          $t7, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r15;
    // 0x802F88DC: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802F88E0: mfc1        $t2, $f10
    ctx->r10 = (int32_t)ctx->f10.u32l;
    // 0x802F88E4: nop

    // 0x802F88E8: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x802F88EC: sh          $t3, 0x2($v1)
    MEM_H(0X2, ctx->r3) = ctx->r11;
    // 0x802F88F0: lhu         $t1, 0x42($s0)
    ctx->r9 = MEM_HU(ctx->r16, 0X42);
    // 0x802F88F4: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802F88F8: sra         $t5, $t1, 1
    ctx->r13 = S32(SIGNED(ctx->r9) >> 1);
    // 0x802F88FC: addu        $t7, $t4, $t5
    ctx->r15 = ADD32(ctx->r12, ctx->r13);
    // 0x802F8900: sh          $t7, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r15;
L_802F8904:
    // 0x802F8904: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802F8908: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802F890C: addiu       $sp, $sp, 0x68
    ctx->r29 = ADD32(ctx->r29, 0X68);
    // 0x802F8910: jr          $ra
    // 0x802F8914: nop

    return;
    // 0x802F8914: nop

;}
RECOMP_FUNC void func_802F8918_709FC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8918: lbu         $v0, 0x18C($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X18C);
    // 0x802F891C: or          $a2, $a1, $zero
    ctx->r6 = ctx->r5 | 0;
    // 0x802F8920: bne         $v0, $zero, L_802F8930
    if (ctx->r2 != 0) {
        // 0x802F8924: nop
    
            goto L_802F8930;
    }
    // 0x802F8924: nop

    // 0x802F8928: jr          $ra
    // 0x802F892C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802F892C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F8930:
    // 0x802F8930: blez        $v0, L_802F8988
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F8934: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_802F8988;
    }
    // 0x802F8934: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x802F8938: lbu         $a3, 0x192($a2)
    ctx->r7 = MEM_BU(ctx->r6, 0X192);
L_802F893C:
    // 0x802F893C: blez        $a3, L_802F8974
    if (SIGNED(ctx->r7) <= 0) {
        // 0x802F8940: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_802F8974;
    }
    // 0x802F8940: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802F8944: addu        $t6, $a0, $v1
    ctx->r14 = ADD32(ctx->r4, ctx->r3);
    // 0x802F8948: lbu         $t0, 0x18D($t6)
    ctx->r8 = MEM_BU(ctx->r14, 0X18D);
L_802F894C:
    // 0x802F894C: addu        $t7, $a2, $a1
    ctx->r15 = ADD32(ctx->r6, ctx->r5);
    // 0x802F8950: lbu         $t8, 0x193($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X193);
    // 0x802F8954: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x802F8958: andi        $t9, $a1, 0xFF
    ctx->r25 = ctx->r5 & 0XFF;
    // 0x802F895C: bne         $t0, $t8, L_802F896C
    if (ctx->r8 != ctx->r24) {
        // 0x802F8960: slt         $at, $t9, $a3
        ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r7) ? 1 : 0;
            goto L_802F896C;
    }
    // 0x802F8960: slt         $at, $t9, $a3
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802F8964: jr          $ra
    // 0x802F8968: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802F8968: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F896C:
    // 0x802F896C: bne         $at, $zero, L_802F894C
    if (ctx->r1 != 0) {
        // 0x802F8970: or          $a1, $t9, $zero
        ctx->r5 = ctx->r25 | 0;
            goto L_802F894C;
    }
    // 0x802F8970: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802F8974:
    // 0x802F8974: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x802F8978: andi        $t1, $v1, 0xFF
    ctx->r9 = ctx->r3 & 0XFF;
    // 0x802F897C: slt         $at, $t1, $v0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802F8980: bne         $at, $zero, L_802F893C
    if (ctx->r1 != 0) {
        // 0x802F8984: or          $v1, $t1, $zero
        ctx->r3 = ctx->r9 | 0;
            goto L_802F893C;
    }
    // 0x802F8984: or          $v1, $t1, $zero
    ctx->r3 = ctx->r9 | 0;
L_802F8988:
    // 0x802F8988: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F898C: jr          $ra
    // 0x802F8990: nop

    return;
    // 0x802F8990: nop

;}
RECOMP_FUNC void find_closest_animal(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8994: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802F8998: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x802F899C: lui         $s6, 0x803D
    ctx->r22 = S32(0X803D << 16);
    // 0x802F89A0: addiu       $s6, $s6, 0x553E
    ctx->r22 = ADD32(ctx->r22, 0X553E);
    // 0x802F89A4: lh          $t6, 0x0($s6)
    ctx->r14 = MEM_H(ctx->r22, 0X0);
    // 0x802F89A8: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x802F89AC: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x802F89B0: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x802F89B4: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x802F89B8: or          $s3, $a0, $zero
    ctx->r19 = ctx->r4 | 0;
    // 0x802F89BC: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802F89C0: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x802F89C4: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x802F89C8: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x802F89CC: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802F89D0: addiu       $s4, $zero, 0x7FFF
    ctx->r20 = ADD32(0, 0X7FFF);
    // 0x802F89D4: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x802F89D8: blez        $t6, L_802F8B18
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802F89DC: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_802F8B18;
    }
    // 0x802F89DC: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x802F89E0: lui         $s7, 0x801E
    ctx->r23 = S32(0X801E << 16);
    // 0x802F89E4: addiu       $s7, $s7, -0x6128
    ctx->r23 = ADD32(ctx->r23, -0X6128);
    // 0x802F89E8: addiu       $fp, $zero, 0x6
    ctx->r30 = ADD32(0, 0X6);
    // 0x802F89EC: sll         $t7, $s2, 3
    ctx->r15 = S32(ctx->r18 << 3);
L_802F89F0:
    // 0x802F89F0: addu        $v1, $s7, $t7
    ctx->r3 = ADD32(ctx->r23, ctx->r15);
    // 0x802F89F4: lw          $a0, 0x3EB4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X3EB4);
    // 0x802F89F8: beql        $a0, $zero, L_802F8B00
    if (ctx->r4 == 0) {
        // 0x802F89FC: lh          $t4, 0x0($s6)
        ctx->r12 = MEM_H(ctx->r22, 0X0);
            goto L_802F8B00;
    }
    goto skip_0;
    // 0x802F89FC: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    skip_0:
    // 0x802F8A00: lbu         $v0, 0x366($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X366);
    // 0x802F8A04: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802F8A08: beql        $fp, $v0, L_802F8B00
    if (ctx->r30 == ctx->r2) {
        // 0x802F8A0C: lh          $t4, 0x0($s6)
        ctx->r12 = MEM_H(ctx->r22, 0X0);
            goto L_802F8B00;
    }
    goto skip_1;
    // 0x802F8A0C: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    skip_1:
    // 0x802F8A10: beq         $v0, $at, L_802F8AFC
    if (ctx->r2 == ctx->r1) {
        // 0x802F8A14: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_802F8AFC;
    }
    // 0x802F8A14: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802F8A18: beql        $v0, $at, L_802F8B00
    if (ctx->r2 == ctx->r1) {
        // 0x802F8A1C: lh          $t4, 0x0($s6)
        ctx->r12 = MEM_H(ctx->r22, 0X0);
            goto L_802F8B00;
    }
    goto skip_2;
    // 0x802F8A1C: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    skip_2:
    // 0x802F8A20: lw          $t8, 0x3EB0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X3EB0);
    // 0x802F8A24: addiu       $at, $zero, 0x3E
    ctx->r1 = ADD32(0, 0X3E);
    // 0x802F8A28: lhu         $v0, 0x9C($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X9C);
    // 0x802F8A2C: beq         $v0, $at, L_802F8AFC
    if (ctx->r2 == ctx->r1) {
        // 0x802F8A30: addiu       $at, $zero, 0x3F
        ctx->r1 = ADD32(0, 0X3F);
            goto L_802F8AFC;
    }
    // 0x802F8A30: addiu       $at, $zero, 0x3F
    ctx->r1 = ADD32(0, 0X3F);
    // 0x802F8A34: beql        $v0, $at, L_802F8B00
    if (ctx->r2 == ctx->r1) {
        // 0x802F8A38: lh          $t4, 0x0($s6)
        ctx->r12 = MEM_H(ctx->r22, 0X0);
            goto L_802F8B00;
    }
    goto skip_3;
    // 0x802F8A38: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    skip_3:
    // 0x802F8A3C: lh          $t9, 0x4($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X4);
    // 0x802F8A40: lh          $t0, 0x4($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X4);
    // 0x802F8A44: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x802F8A48: lh          $v1, 0x8($s3)
    ctx->r3 = MEM_H(ctx->r19, 0X8);
    // 0x802F8A4C: subu        $v0, $t9, $t0
    ctx->r2 = SUB32(ctx->r25, ctx->r8);
    // 0x802F8A50: bgez        $v0, L_802F8A68
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F8A54: sll         $a0, $v0, 16
        ctx->r4 = S32(ctx->r2 << 16);
            goto L_802F8A68;
    }
    // 0x802F8A54: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x802F8A58: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
    // 0x802F8A5C: sll         $t1, $a0, 16
    ctx->r9 = S32(ctx->r4 << 16);
    // 0x802F8A60: b           L_802F8A70
    // 0x802F8A64: sra         $a0, $t1, 16
    ctx->r4 = S32(SIGNED(ctx->r9) >> 16);
        goto L_802F8A70;
    // 0x802F8A64: sra         $a0, $t1, 16
    ctx->r4 = S32(SIGNED(ctx->r9) >> 16);
L_802F8A68:
    // 0x802F8A68: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8A6C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
L_802F8A70:
    // 0x802F8A70: lh          $t4, 0x8($s1)
    ctx->r12 = MEM_H(ctx->r17, 0X8);
    // 0x802F8A74: subu        $v0, $v1, $t4
    ctx->r2 = SUB32(ctx->r3, ctx->r12);
    // 0x802F8A78: bgez        $v0, L_802F8A90
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F8A7C: sll         $v1, $v0, 16
        ctx->r3 = S32(ctx->r2 << 16);
            goto L_802F8A90;
    }
    // 0x802F8A7C: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F8A80: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x802F8A84: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802F8A88: b           L_802F8A98
    // 0x802F8A8C: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
        goto L_802F8A98;
    // 0x802F8A8C: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
L_802F8A90:
    // 0x802F8A90: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8A94: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_802F8A98:
    // 0x802F8A98: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F8A9C: beq         $at, $zero, L_802F8AAC
    if (ctx->r1 == 0) {
        // 0x802F8AA0: or          $a1, $v1, $zero
        ctx->r5 = ctx->r3 | 0;
            goto L_802F8AAC;
    }
    // 0x802F8AA0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802F8AA4: b           L_802F8AAC
    // 0x802F8AA8: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_802F8AAC;
    // 0x802F8AA8: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_802F8AAC:
    // 0x802F8AAC: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F8AB0: beq         $at, $zero, L_802F8AC0
    if (ctx->r1 == 0) {
        // 0x802F8AB4: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802F8AC0;
    }
    // 0x802F8AB4: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802F8AB8: b           L_802F8AC0
    // 0x802F8ABC: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
        goto L_802F8AC0;
    // 0x802F8ABC: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_802F8AC0:
    // 0x802F8AC0: sra         $t8, $v0, 1
    ctx->r24 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802F8AC4: addu        $s0, $t8, $a1
    ctx->r16 = ADD32(ctx->r24, ctx->r5);
    // 0x802F8AC8: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x802F8ACC: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F8AD0: slt         $at, $s0, $s4
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x802F8AD4: beq         $at, $zero, L_802F8AFC
    if (ctx->r1 == 0) {
        // 0x802F8AD8: or          $a0, $s3, $zero
        ctx->r4 = ctx->r19 | 0;
            goto L_802F8AFC;
    }
    // 0x802F8AD8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x802F8ADC: jal         0x802F8918
    // 0x802F8AE0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    func_802F8918_709FC8(rdram, ctx);
        goto after_0;
    // 0x802F8AE0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_0:
    // 0x802F8AE4: beql        $v0, $zero, L_802F8B00
    if (ctx->r2 == 0) {
        // 0x802F8AE8: lh          $t4, 0x0($s6)
        ctx->r12 = MEM_H(ctx->r22, 0X0);
            goto L_802F8B00;
    }
    goto skip_4;
    // 0x802F8AE8: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    skip_4:
    // 0x802F8AEC: sll         $s4, $s0, 16
    ctx->r20 = S32(ctx->r16 << 16);
    // 0x802F8AF0: sra         $t1, $s4, 16
    ctx->r9 = S32(SIGNED(ctx->r20) >> 16);
    // 0x802F8AF4: or          $s4, $t1, $zero
    ctx->r20 = ctx->r9 | 0;
    // 0x802F8AF8: or          $s5, $s1, $zero
    ctx->r21 = ctx->r17 | 0;
L_802F8AFC:
    // 0x802F8AFC: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
L_802F8B00:
    // 0x802F8B00: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x802F8B04: sll         $t2, $s2, 16
    ctx->r10 = S32(ctx->r18 << 16);
    // 0x802F8B08: sra         $s2, $t2, 16
    ctx->r18 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802F8B0C: slt         $at, $s2, $t4
    ctx->r1 = SIGNED(ctx->r18) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802F8B10: bnel        $at, $zero, L_802F89F0
    if (ctx->r1 != 0) {
        // 0x802F8B14: sll         $t7, $s2, 3
        ctx->r15 = S32(ctx->r18 << 3);
            goto L_802F89F0;
    }
    goto skip_5;
    // 0x802F8B14: sll         $t7, $s2, 3
    ctx->r15 = S32(ctx->r18 << 3);
    skip_5:
L_802F8B18:
    // 0x802F8B18: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x802F8B1C: or          $v0, $s5, $zero
    ctx->r2 = ctx->r21 | 0;
    // 0x802F8B20: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x802F8B24: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802F8B28: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x802F8B2C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x802F8B30: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x802F8B34: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x802F8B38: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x802F8B3C: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x802F8B40: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x802F8B44: jr          $ra
    // 0x802F8B48: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x802F8B48: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_802F8B4C_70A1FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8B4C: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x802F8B50: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802F8B54: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802F8B58: lh          $v0, 0x150($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X150);
    // 0x802F8B5C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F8B60: blez        $v0, L_802F8B6C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F8B64: addiu       $t6, $v0, -0x2
        ctx->r14 = ADD32(ctx->r2, -0X2);
            goto L_802F8B6C;
    }
    // 0x802F8B64: addiu       $t6, $v0, -0x2
    ctx->r14 = ADD32(ctx->r2, -0X2);
    // 0x802F8B68: sh          $t6, 0x150($a0)
    MEM_H(0X150, ctx->r4) = ctx->r14;
L_802F8B6C:
    // 0x802F8B6C: lhu         $t7, 0x0($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X0);
    // 0x802F8B70: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F8B74: bnel        $t7, $at, L_802F8DBC
    if (ctx->r15 != ctx->r1) {
        // 0x802F8B78: lw          $ra, 0x3C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X3C);
            goto L_802F8DBC;
    }
    goto skip_0;
    // 0x802F8B78: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    skip_0:
    // 0x802F8B7C: jal         0x802F8994
    // 0x802F8B80: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    find_closest_animal(rdram, ctx);
        goto after_0;
    // 0x802F8B80: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802F8B84: beq         $v0, $zero, L_802F8DB8
    if (ctx->r2 == 0) {
        // 0x802F8B88: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802F8DB8;
    }
    // 0x802F8B88: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802F8B8C: addiu       $t8, $sp, 0x48
    ctx->r24 = ADD32(ctx->r29, 0X48);
    // 0x802F8B90: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802F8B94: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802F8B98: lui         $a2, 0x4180
    ctx->r6 = S32(0X4180 << 16);
    // 0x802F8B9C: lui         $a3, 0x4400
    ctx->r7 = S32(0X4400 << 16);
    // 0x802F8BA0: jal         0x802F8658
    // 0x802F8BA4: sw          $v0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r2;
    func_802F8658_709D08(rdram, ctx);
        goto after_1;
    // 0x802F8BA4: sw          $v0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r2;
    after_1:
    // 0x802F8BA8: beq         $v0, $zero, L_802F8DB8
    if (ctx->r2 == 0) {
        // 0x802F8BAC: lh          $t9, 0x48($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X48);
            goto L_802F8DB8;
    }
    // 0x802F8BAC: lh          $t9, 0x48($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X48);
    // 0x802F8BB0: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802F8BB4: lh          $t2, 0x4A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X4A);
    // 0x802F8BB8: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x802F8BBC: subu        $v0, $t9, $t1
    ctx->r2 = SUB32(ctx->r25, ctx->r9);
    // 0x802F8BC0: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x802F8BC4: subu        $v1, $t2, $t3
    ctx->r3 = SUB32(ctx->r10, ctx->r11);
    // 0x802F8BC8: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802F8BCC: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F8BD0: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F8BD4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8BD8: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F8BDC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802F8BE0: jal         0x801284B8
    // 0x802F8BE4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_801284B8(rdram, ctx);
        goto after_2;
    // 0x802F8BE4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_2:
    // 0x802F8BE8: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x802F8BEC: lw          $t4, 0x5B0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5B0);
    // 0x802F8BF0: lui         $at, 0x4120
    ctx->r1 = S32(0X4120 << 16);
    // 0x802F8BF4: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x802F8BF8: mtc1        $t4, $f6
    ctx->f6.u32l = ctx->r12;
    // 0x802F8BFC: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x802F8C00: addiu       $t9, $zero, 0x10
    ctx->r25 = ADD32(0, 0X10);
    // 0x802F8C04: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802F8C08: addiu       $t1, $zero, 0x59
    ctx->r9 = ADD32(0, 0X59);
    // 0x802F8C0C: addiu       $t2, $zero, -0x4
    ctx->r10 = ADD32(0, -0X4);
    // 0x802F8C10: addiu       $t3, $zero, 0x4
    ctx->r11 = ADD32(0, 0X4);
    // 0x802F8C14: sh          $v0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r2;
    // 0x802F8C18: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x802F8C1C: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x802F8C20: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x802F8C24: div.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x802F8C28: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    // 0x802F8C2C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802F8C30: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802F8C34: lw          $a1, 0x58($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X58);
    // 0x802F8C38: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F8C3C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802F8C40: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x802F8C44: jal         0x802F8160
    // 0x802F8C48: swc1        $f4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f4.u32l;
    func_802F8160_709810(rdram, ctx);
        goto after_3;
    // 0x802F8C48: swc1        $f4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f4.u32l;
    after_3:
    // 0x802F8C4C: lh          $t6, 0x5E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X5E);
    // 0x802F8C50: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802F8C54: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802F8C58: addiu       $t7, $t6, 0xB4
    ctx->r15 = ADD32(ctx->r14, 0XB4);
    // 0x802F8C5C: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x802F8C60: sra         $t5, $t0, 16
    ctx->r13 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F8C64: mfhi        $t8
    ctx->r24 = hi;
    // 0x802F8C68: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F8C6C: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x802F8C70: beq         $v0, $at, L_802F8CA0
    if (ctx->r2 == ctx->r1) {
        // 0x802F8C74: sh          $t8, 0x2C($s0)
        MEM_H(0X2C, ctx->r16) = ctx->r24;
            goto L_802F8CA0;
    }
    // 0x802F8C74: sh          $t8, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r24;
    // 0x802F8C78: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F8C7C: sra         $t9, $v1, 16
    ctx->r25 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F8C80: slti        $at, $t9, 0x5B
    ctx->r1 = SIGNED(ctx->r25) < 0X5B ? 1 : 0;
    // 0x802F8C84: beq         $at, $zero, L_802F8C9C
    if (ctx->r1 == 0) {
        // 0x802F8C88: addiu       $t3, $zero, 0x5A
        ctx->r11 = ADD32(0, 0X5A);
            goto L_802F8C9C;
    }
    // 0x802F8C88: addiu       $t3, $zero, 0x5A
    ctx->r11 = ADD32(0, 0X5A);
    // 0x802F8C8C: addiu       $t1, $zero, 0x5A
    ctx->r9 = ADD32(0, 0X5A);
    // 0x802F8C90: subu        $t2, $t1, $t9
    ctx->r10 = SUB32(ctx->r9, ctx->r25);
    // 0x802F8C94: b           L_802F8CA0
    // 0x802F8C98: sh          $t2, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r10;
        goto L_802F8CA0;
    // 0x802F8C98: sh          $t2, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r10;
L_802F8C9C:
    // 0x802F8C9C: sh          $t3, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r11;
L_802F8CA0:
    // 0x802F8CA0: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
    // 0x802F8CA4: bgtz        $v0, L_802F8DB4
    if (SIGNED(ctx->r2) > 0) {
        // 0x802F8CA8: addiu       $t9, $v0, -0x1
        ctx->r25 = ADD32(ctx->r2, -0X1);
            goto L_802F8DB4;
    }
    // 0x802F8CA8: addiu       $t9, $v0, -0x1
    ctx->r25 = ADD32(ctx->r2, -0X1);
    // 0x802F8CAC: lh          $v0, 0x152($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X152);
    // 0x802F8CB0: blez        $v0, L_802F8D8C
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F8CB4: addiu       $t4, $v0, -0x1
        ctx->r12 = ADD32(ctx->r2, -0X1);
            goto L_802F8D8C;
    }
    // 0x802F8CB4: addiu       $t4, $v0, -0x1
    ctx->r12 = ADD32(ctx->r2, -0X1);
    // 0x802F8CB8: sh          $t4, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r12;
    // 0x802F8CBC: lh          $t6, 0x152($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X152);
    // 0x802F8CC0: addiu       $t5, $zero, 0x100
    ctx->r13 = ADD32(0, 0X100);
    // 0x802F8CC4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F8CC8: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x802F8CCC: bne         $t7, $at, L_802F8DB8
    if (ctx->r15 != ctx->r1) {
        // 0x802F8CD0: sh          $t5, 0x150($s0)
        MEM_H(0X150, ctx->r16) = ctx->r13;
            goto L_802F8DB8;
    }
    // 0x802F8CD0: sh          $t5, 0x150($s0)
    MEM_H(0X150, ctx->r16) = ctx->r13;
    // 0x802F8CD4: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802F8CD8: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F8CDC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802F8CE0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802F8CE4: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802F8CE8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802F8CEC: sh          $t0, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r8;
    // 0x802F8CF0: addiu       $a0, $zero, 0x4A
    ctx->r4 = ADD32(0, 0X4A);
    // 0x802F8CF4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802F8CF8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F8CFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802F8D00: jal         0x8032C360
    // 0x802F8D04: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_4;
    // 0x802F8D04: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_4:
    // 0x802F8D08: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802F8D0C: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802F8D10: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802F8D14: sll         $t2, $v0, 2
    ctx->r10 = S32(ctx->r2 << 2);
    // 0x802F8D18: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F8D1C: subu        $t2, $t2, $v0
    ctx->r10 = SUB32(ctx->r10, ctx->r2);
    // 0x802F8D20: sll         $t2, $t2, 1
    ctx->r10 = S32(ctx->r10 << 1);
    // 0x802F8D24: sra         $t3, $t2, 11
    ctx->r11 = S32(SIGNED(ctx->r10) >> 11);
    // 0x802F8D28: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802F8D2C: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x802F8D30: addu        $a2, $t1, $t3
    ctx->r6 = ADD32(ctx->r9, ctx->r11);
    // 0x802F8D34: lh          $t0, 0x5C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X5C);
    // 0x802F8D38: lh          $t8, 0x5E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X5E);
    // 0x802F8D3C: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802F8D40: sll         $t2, $v0, 11
    ctx->r10 = S32(ctx->r2 << 11);
    // 0x802F8D44: sra         $t1, $t2, 11
    ctx->r9 = S32(SIGNED(ctx->r10) >> 11);
    // 0x802F8D48: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802F8D4C: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x802F8D50: addiu       $t9, $zero, 0x10
    ctx->r25 = ADD32(0, 0X10);
    // 0x802F8D54: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x802F8D58: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802F8D5C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802F8D60: sw          $t1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r9;
    // 0x802F8D64: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802F8D68: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802F8D6C: addiu       $a3, $zero, 0x26
    ctx->r7 = ADD32(0, 0X26);
    // 0x802F8D70: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x802F8D74: jal         0x802F62E4
    // 0x802F8D78: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    func_802F62E4_707994(rdram, ctx);
        goto after_5;
    // 0x802F8D78: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    after_5:
    // 0x802F8D7C: beq         $v0, $zero, L_802F8DB8
    if (ctx->r2 == 0) {
        // 0x802F8D80: addiu       $t3, $zero, 0xC8
        ctx->r11 = ADD32(0, 0XC8);
            goto L_802F8DB8;
    }
    // 0x802F8D80: addiu       $t3, $zero, 0xC8
    ctx->r11 = ADD32(0, 0XC8);
    // 0x802F8D84: b           L_802F8DB8
    // 0x802F8D88: sb          $t3, 0x154($v0)
    MEM_B(0X154, ctx->r2) = ctx->r11;
        goto L_802F8DB8;
    // 0x802F8D88: sb          $t3, 0x154($v0)
    MEM_B(0X154, ctx->r2) = ctx->r11;
L_802F8D8C:
    // 0x802F8D8C: jal         0x80128200
    // 0x802F8D90: nop

    func_80128200(rdram, ctx);
        goto after_6;
    // 0x802F8D90: nop

    after_6:
    // 0x802F8D94: lw          $t5, 0x158($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X158);
    // 0x802F8D98: andi        $t4, $v0, 0x1F
    ctx->r12 = ctx->r2 & 0X1F;
    // 0x802F8D9C: addiu       $t8, $zero, 0x6
    ctx->r24 = ADD32(0, 0X6);
    // 0x802F8DA0: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802F8DA4: addiu       $t7, $t6, 0x18
    ctx->r15 = ADD32(ctx->r14, 0X18);
    // 0x802F8DA8: sh          $t7, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r15;
    // 0x802F8DAC: b           L_802F8DB8
    // 0x802F8DB0: sh          $t8, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r24;
        goto L_802F8DB8;
    // 0x802F8DB0: sh          $t8, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r24;
L_802F8DB4:
    // 0x802F8DB4: sh          $t9, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r25;
L_802F8DB8:
    // 0x802F8DB8: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_802F8DBC:
    // 0x802F8DBC: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802F8DC0: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    // 0x802F8DC4: jr          $ra
    // 0x802F8DC8: nop

    return;
    // 0x802F8DC8: nop

;}
RECOMP_FUNC void func_802F8DCC_70A47C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F8DCC: addiu       $sp, $sp, -0x68
    ctx->r29 = ADD32(ctx->r29, -0X68);
    // 0x802F8DD0: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802F8DD4: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x802F8DD8: lh          $v0, 0x150($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X150);
    // 0x802F8DDC: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F8DE0: blez        $v0, L_802F8DEC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F8DE4: addiu       $t6, $v0, -0x2
        ctx->r14 = ADD32(ctx->r2, -0X2);
            goto L_802F8DEC;
    }
    // 0x802F8DE4: addiu       $t6, $v0, -0x2
    ctx->r14 = ADD32(ctx->r2, -0X2);
    // 0x802F8DE8: sh          $t6, 0x150($a0)
    MEM_H(0X150, ctx->r4) = ctx->r14;
L_802F8DEC:
    // 0x802F8DEC: lhu         $t7, 0x0($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X0);
    // 0x802F8DF0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F8DF4: bnel        $t7, $at, L_802F9074
    if (ctx->r15 != ctx->r1) {
        // 0x802F8DF8: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_802F9074;
    }
    goto skip_0;
    // 0x802F8DF8: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_0:
    // 0x802F8DFC: jal         0x802F8994
    // 0x802F8E00: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    find_closest_animal(rdram, ctx);
        goto after_0;
    // 0x802F8E00: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802F8E04: beq         $v0, $zero, L_802F9070
    if (ctx->r2 == 0) {
        // 0x802F8E08: sw          $v0, 0x4C($sp)
        MEM_W(0X4C, ctx->r29) = ctx->r2;
            goto L_802F9070;
    }
    // 0x802F8E08: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    // 0x802F8E0C: lh          $v1, 0x14E($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X14E);
    // 0x802F8E10: blez        $v1, L_802F8E1C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802F8E14: addiu       $t8, $v1, -0x1
        ctx->r24 = ADD32(ctx->r3, -0X1);
            goto L_802F8E1C;
    }
    // 0x802F8E14: addiu       $t8, $v1, -0x1
    ctx->r24 = ADD32(ctx->r3, -0X1);
    // 0x802F8E18: sh          $t8, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r24;
L_802F8E1C:
    // 0x802F8E1C: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    // 0x802F8E20: lh          $t2, 0x4($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X4);
    // 0x802F8E24: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802F8E28: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802F8E2C: subu        $a2, $t9, $t2
    ctx->r6 = SUB32(ctx->r25, ctx->r10);
    // 0x802F8E30: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F8E34: subu        $a3, $t3, $t4
    ctx->r7 = SUB32(ctx->r11, ctx->r12);
    // 0x802F8E38: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x802F8E3C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802F8E40: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x802F8E44: lhu         $t2, 0x42($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X42);
    // 0x802F8E48: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x802F8E4C: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x802F8E50: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802F8E54: addu        $t0, $t9, $t3
    ctx->r8 = ADD32(ctx->r25, ctx->r11);
    // 0x802F8E58: mflo        $t4
    ctx->r12 = lo;
    // 0x802F8E5C: sll         $a1, $a3, 16
    ctx->r5 = S32(ctx->r7 << 16);
    // 0x802F8E60: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
    // 0x802F8E64: multu       $a3, $a3
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F8E68: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8E6C: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F8E70: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x802F8E74: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x802F8E78: mflo        $t5
    ctx->r13 = lo;
    // 0x802F8E7C: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802F8E80: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802F8E84: nop

    // 0x802F8E88: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F8E8C: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F8E90: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802F8E94: mfc1        $v1, $f6
    ctx->r3 = (int32_t)ctx->f6.u32l;
    // 0x802F8E98: nop

    // 0x802F8E9C: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802F8EA0: sra         $t2, $t8, 16
    ctx->r10 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F8EA4: slti        $at, $t2, 0x280
    ctx->r1 = SIGNED(ctx->r10) < 0X280 ? 1 : 0;
    // 0x802F8EA8: beql        $at, $zero, L_802F9074
    if (ctx->r1 == 0) {
        // 0x802F8EAC: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_802F9074;
    }
    goto skip_1;
    // 0x802F8EAC: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_1:
    // 0x802F8EB0: sw          $t0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r8;
    // 0x802F8EB4: jal         0x801284B8
    // 0x802F8EB8: sw          $t2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r10;
    func_801284B8(rdram, ctx);
        goto after_1;
    // 0x802F8EB8: sw          $t2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r10;
    after_1:
    // 0x802F8EBC: lw          $t0, 0x5C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X5C);
    // 0x802F8EC0: lw          $t1, 0x58($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X58);
    // 0x802F8EC4: sh          $v0, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r2;
    // 0x802F8EC8: sll         $a0, $t0, 16
    ctx->r4 = S32(ctx->r8 << 16);
    // 0x802F8ECC: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x802F8ED0: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F8ED4: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F8ED8: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x802F8EDC: jal         0x801284B8
    // 0x802F8EE0: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    func_801284B8(rdram, ctx);
        goto after_2;
    // 0x802F8EE0: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    after_2:
    // 0x802F8EE4: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802F8EE8: sra         $t6, $t0, 16
    ctx->r14 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F8EEC: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    // 0x802F8EF0: bne         $at, $zero, L_802F8F00
    if (ctx->r1 != 0) {
        // 0x802F8EF4: or          $t0, $t6, $zero
        ctx->r8 = ctx->r14 | 0;
            goto L_802F8F00;
    }
    // 0x802F8EF4: or          $t0, $t6, $zero
    ctx->r8 = ctx->r14 | 0;
    // 0x802F8EF8: b           L_802F8F18
    // 0x802F8EFC: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
        goto L_802F8F18;
    // 0x802F8EFC: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_802F8F00:
    // 0x802F8F00: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802F8F04: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802F8F08: slti        $at, $t8, 0x5B
    ctx->r1 = SIGNED(ctx->r24) < 0X5B ? 1 : 0;
    // 0x802F8F0C: bnel        $at, $zero, L_802F8F1C
    if (ctx->r1 != 0) {
        // 0x802F8F10: lh          $a0, 0x56($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X56);
            goto L_802F8F1C;
    }
    goto skip_2;
    // 0x802F8F10: lh          $a0, 0x56($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X56);
    skip_2:
    // 0x802F8F14: addiu       $t0, $zero, 0x5A
    ctx->r8 = ADD32(0, 0X5A);
L_802F8F18:
    // 0x802F8F18: lh          $a0, 0x56($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X56);
L_802F8F1C:
    // 0x802F8F1C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802F8F20: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    // 0x802F8F24: addiu       $a0, $a0, 0xB4
    ctx->r4 = ADD32(ctx->r4, 0XB4);
    // 0x802F8F28: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x802F8F2C: mfhi        $t2
    ctx->r10 = hi;
    // 0x802F8F30: sll         $t9, $t2, 16
    ctx->r25 = S32(ctx->r10 << 16);
    // 0x802F8F34: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F8F38: sh          $t0, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r8;
    // 0x802F8F3C: jal         0x802F649C
    // 0x802F8F40: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    func_802F649C_707B4C(rdram, ctx);
        goto after_3;
    // 0x802F8F40: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    after_3:
    // 0x802F8F44: lh          $t0, 0x54($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X54);
    // 0x802F8F48: addiu       $t4, $zero, 0x5A
    ctx->r12 = ADD32(0, 0X5A);
    // 0x802F8F4C: sh          $v0, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r2;
    // 0x802F8F50: subu        $a0, $t4, $t0
    ctx->r4 = SUB32(ctx->r12, ctx->r8);
    // 0x802F8F54: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x802F8F58: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802F8F5C: lh          $a1, 0x2E($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2E);
    // 0x802F8F60: jal         0x802F649C
    // 0x802F8F64: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    func_802F649C_707B4C(rdram, ctx);
        goto after_4;
    // 0x802F8F64: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    after_4:
    // 0x802F8F68: lh          $t7, 0x14E($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X14E);
    // 0x802F8F6C: lh          $t0, 0x54($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X54);
    // 0x802F8F70: sh          $v0, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r2;
    // 0x802F8F74: bgtz        $t7, L_802F9070
    if (SIGNED(ctx->r15) > 0) {
        // 0x802F8F78: addiu       $t9, $zero, 0x100
        ctx->r25 = ADD32(0, 0X100);
            goto L_802F9070;
    }
    // 0x802F8F78: addiu       $t9, $zero, 0x100
    ctx->r25 = ADD32(0, 0X100);
    // 0x802F8F7C: lw          $t8, 0x158($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X158);
    // 0x802F8F80: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x802F8F84: sh          $t9, 0x150($s0)
    MEM_H(0X150, ctx->r16) = ctx->r25;
    // 0x802F8F88: addiu       $t2, $t8, 0xFA
    ctx->r10 = ADD32(ctx->r24, 0XFA);
    // 0x802F8F8C: sh          $t2, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r10;
    // 0x802F8F90: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F8F94: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802F8F98: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802F8F9C: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802F8FA0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802F8FA4: sh          $t0, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r8;
    // 0x802F8FA8: addiu       $a0, $zero, 0x4A
    ctx->r4 = ADD32(0, 0X4A);
    // 0x802F8FAC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802F8FB0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F8FB4: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x802F8FB8: jal         0x8032C360
    // 0x802F8FBC: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_5;
    // 0x802F8FBC: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    after_5:
    // 0x802F8FC0: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802F8FC4: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802F8FC8: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802F8FCC: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802F8FD0: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802F8FD4: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x802F8FD8: sll         $t2, $v0, 2
    ctx->r10 = S32(ctx->r2 << 2);
    // 0x802F8FDC: sll         $t6, $t6, 1
    ctx->r14 = S32(ctx->r14 << 1);
    // 0x802F8FE0: addu        $t2, $t2, $v0
    ctx->r10 = ADD32(ctx->r10, ctx->r2);
    // 0x802F8FE4: lh          $t0, 0x54($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X54);
    // 0x802F8FE8: lh          $t3, 0x56($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X56);
    // 0x802F8FEC: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x802F8FF0: sll         $t2, $t2, 3
    ctx->r10 = S32(ctx->r10 << 3);
    // 0x802F8FF4: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802F8FF8: sra         $t9, $t2, 11
    ctx->r25 = S32(SIGNED(ctx->r10) >> 11);
    // 0x802F8FFC: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802F9000: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802F9004: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x802F9008: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802F900C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802F9010: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802F9014: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802F9018: lw          $a1, 0x4C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4C);
    // 0x802F901C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802F9020: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802F9024: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x802F9028: bgez        $v0, L_802F9040
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F902C: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802F9040;
    }
    // 0x802F902C: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802F9030: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802F9034: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x802F9038: nop

    // 0x802F903C: add.s       $f16, $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f18.fl;
L_802F9040:
    // 0x802F9040: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802F9044: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F9048: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F904C: ldc1        $f10, -0x3100($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X3100);
    // 0x802F9050: div.s       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f16.fl, ctx->f4.fl);
    // 0x802F9054: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x802F9058: sw          $t4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r12;
    // 0x802F905C: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x802F9060: mul.d       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = MUL_D(ctx->f8.d, ctx->f10.d);
    // 0x802F9064: cvt.s.d     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f16.fl = CVT_S_D(ctx->f18.d);
    // 0x802F9068: jal         0x802FED68
    // 0x802F906C: swc1        $f16, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->f16.u32l;
    func_802FED68_710418(rdram, ctx);
        goto after_6;
    // 0x802F906C: swc1        $f16, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->f16.u32l;
    after_6:
L_802F9070:
    // 0x802F9070: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
L_802F9074:
    // 0x802F9074: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x802F9078: addiu       $sp, $sp, 0x68
    ctx->r29 = ADD32(ctx->r29, 0X68);
    // 0x802F907C: jr          $ra
    // 0x802F9080: nop

    return;
    // 0x802F9080: nop

;}
RECOMP_FUNC void func_802F9084_70A734(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9084: jr          $ra
    // 0x802F9088: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    return;
    // 0x802F9088: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
;}
RECOMP_FUNC void func_802F908C_70A73C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F908C: lbu         $t6, 0x154($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X154);
    // 0x802F9090: addiu       $t7, $zero, 0x64
    ctx->r15 = ADD32(0, 0X64);
    // 0x802F9094: bne         $t6, $zero, L_802F90A0
    if (ctx->r14 != 0) {
        // 0x802F9098: nop
    
            goto L_802F90A0;
    }
    // 0x802F9098: nop

    // 0x802F909C: sb          $t7, 0x154($a0)
    MEM_B(0X154, ctx->r4) = ctx->r15;
L_802F90A0:
    // 0x802F90A0: jr          $ra
    // 0x802F90A4: nop

    return;
    // 0x802F90A4: nop

;}
RECOMP_FUNC void func_802F90A8_70A758(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F90A8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802F90AC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F90B0: lw          $t6, 0x4($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X4);
    // 0x802F90B4: lw          $t7, 0x1C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X1C);
    // 0x802F90B8: lw          $t9, 0x8($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X8);
    // 0x802F90BC: lw          $t0, 0x20($a0)
    ctx->r8 = MEM_W(ctx->r4, 0X20);
    // 0x802F90C0: lw          $t2, 0x4C($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X4C);
    // 0x802F90C4: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802F90C8: addu        $t1, $t9, $t0
    ctx->r9 = ADD32(ctx->r25, ctx->r8);
    // 0x802F90CC: sll         $t4, $t2, 29
    ctx->r12 = S32(ctx->r10 << 29);
    // 0x802F90D0: sw          $t8, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r24;
    // 0x802F90D4: bltz        $t4, L_802F90EC
    if (SIGNED(ctx->r12) < 0) {
        // 0x802F90D8: sw          $t1, 0x8($a0)
        MEM_W(0X8, ctx->r4) = ctx->r9;
            goto L_802F90EC;
    }
    // 0x802F90D8: sw          $t1, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r9;
    // 0x802F90DC: lw          $t5, 0xC($a0)
    ctx->r13 = MEM_W(ctx->r4, 0XC);
    // 0x802F90E0: lw          $t6, 0x24($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X24);
    // 0x802F90E4: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802F90E8: sw          $t7, 0xC($a0)
    MEM_W(0XC, ctx->r4) = ctx->r15;
L_802F90EC:
    // 0x802F90EC: jal         0x803136B0
    // 0x802F90F0: nop

    func_803136B0_724D60(rdram, ctx);
        goto after_0;
    // 0x802F90F0: nop

    after_0:
    // 0x802F90F4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802F90F8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802F90FC: jr          $ra
    // 0x802F9100: nop

    return;
    // 0x802F9100: nop

;}
RECOMP_FUNC void func_802F9104_70A7B4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9104: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802F9108: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F910C: lh          $t6, 0x150($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X150);
    // 0x802F9110: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x802F9114: addiu       $t7, $t6, 0x4
    ctx->r15 = ADD32(ctx->r14, 0X4);
    // 0x802F9118: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802F911C: sh          $t8, 0x150($a0)
    MEM_H(0X150, ctx->r4) = ctx->r24;
    // 0x802F9120: lh          $t9, 0x150($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X150);
    // 0x802F9124: addiu       $t0, $t9, 0x40
    ctx->r8 = ADD32(ctx->r25, 0X40);
    // 0x802F9128: andi        $t1, $t0, 0xFF
    ctx->r9 = ctx->r8 & 0XFF;
    // 0x802F912C: sll         $t2, $t1, 1
    ctx->r10 = S32(ctx->r9 << 1);
    // 0x802F9130: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x802F9134: lh          $t3, 0x2C78($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X2C78);
    // 0x802F9138: sra         $t4, $t3, 7
    ctx->r12 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802F913C: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x802F9140: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802F9144: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802F9148: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802F914C: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802F9150: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802F9154: sll         $t5, $t5, 1
    ctx->r13 = S32(ctx->r13 << 1);
    // 0x802F9158: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x802F915C: addiu       $t7, $t6, 0x533
    ctx->r15 = ADD32(ctx->r14, 0X533);
    // 0x802F9160: jal         0x802C9BA4
    // 0x802F9164: sh          $t7, 0x40($a0)
    MEM_H(0X40, ctx->r4) = ctx->r15;
    func_802C9BA4_6DB254(rdram, ctx);
        goto after_0;
    // 0x802F9164: sh          $t7, 0x40($a0)
    MEM_H(0X40, ctx->r4) = ctx->r15;
    after_0:
    // 0x802F9168: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802F916C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802F9170: jr          $ra
    // 0x802F9174: nop

    return;
    // 0x802F9174: nop

;}
RECOMP_FUNC void func_802F9178_70A828(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9178: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802F917C: lh          $v1, 0x553E($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X553E);
    // 0x802F9180: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x802F9184: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F9188: blez        $v1, L_802F92A4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x802F918C: addiu       $t5, $zero, 0x5
        ctx->r13 = ADD32(0, 0X5);
            goto L_802F92A4;
    }
    // 0x802F918C: addiu       $t5, $zero, 0x5
    ctx->r13 = ADD32(0, 0X5);
    // 0x802F9190: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x802F9194: addiu       $t1, $t1, -0x6128
    ctx->r9 = ADD32(ctx->r9, -0X6128);
    // 0x802F9198: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x802F919C: addiu       $t3, $zero, 0x6
    ctx->r11 = ADD32(0, 0X6);
    // 0x802F91A0: addiu       $t2, $zero, 0x14
    ctx->r10 = ADD32(0, 0X14);
    // 0x802F91A4: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
L_802F91A8:
    // 0x802F91A8: addu        $a0, $t1, $t6
    ctx->r4 = ADD32(ctx->r9, ctx->r14);
    // 0x802F91AC: lw          $a1, 0x3EB4($a0)
    ctx->r5 = MEM_W(ctx->r4, 0X3EB4);
    // 0x802F91B0: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802F91B4: beql        $a1, $zero, L_802F9294
    if (ctx->r5 == 0) {
        // 0x802F91B8: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_0;
    // 0x802F91B8: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_0:
    // 0x802F91BC: lw          $t7, 0x3EB0($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X3EB0);
    // 0x802F91C0: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x802F91C4: bnel        $t2, $t8, L_802F9294
    if (ctx->r10 != ctx->r24) {
        // 0x802F91C8: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_1;
    // 0x802F91C8: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_1:
    // 0x802F91CC: lbu         $a0, 0x366($a1)
    ctx->r4 = MEM_BU(ctx->r5, 0X366);
    // 0x802F91D0: beql        $t3, $a0, L_802F9294
    if (ctx->r11 == ctx->r4) {
        // 0x802F91D4: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_2;
    // 0x802F91D4: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_2:
    // 0x802F91D8: beql        $t4, $a0, L_802F9294
    if (ctx->r12 == ctx->r4) {
        // 0x802F91DC: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_3;
    // 0x802F91DC: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_3:
    // 0x802F91E0: beql        $t5, $a0, L_802F9294
    if (ctx->r13 == ctx->r4) {
        // 0x802F91E4: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_4;
    // 0x802F91E4: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_4:
    // 0x802F91E8: lh          $t9, 0x4($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X4);
    // 0x802F91EC: lh          $t6, 0x4($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X4);
    // 0x802F91F0: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    // 0x802F91F4: lh          $t0, 0x8($a2)
    ctx->r8 = MEM_H(ctx->r6, 0X8);
    // 0x802F91F8: subu        $a3, $t9, $t6
    ctx->r7 = SUB32(ctx->r25, ctx->r14);
    // 0x802F91FC: bgez        $a3, L_802F9214
    if (SIGNED(ctx->r7) >= 0) {
        // 0x802F9200: sll         $a1, $a3, 16
        ctx->r5 = S32(ctx->r7 << 16);
            goto L_802F9214;
    }
    // 0x802F9200: sll         $a1, $a3, 16
    ctx->r5 = S32(ctx->r7 << 16);
    // 0x802F9204: negu        $a1, $a3
    ctx->r5 = SUB32(0, ctx->r7);
    // 0x802F9208: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802F920C: b           L_802F921C
    // 0x802F9210: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802F921C;
    // 0x802F9210: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
L_802F9214:
    // 0x802F9214: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F9218: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
L_802F921C:
    // 0x802F921C: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x802F9220: subu        $a3, $t0, $t6
    ctx->r7 = SUB32(ctx->r8, ctx->r14);
    // 0x802F9224: bgez        $a3, L_802F923C
    if (SIGNED(ctx->r7) >= 0) {
        // 0x802F9228: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802F923C;
    }
    // 0x802F9228: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802F922C: negu        $a0, $a3
    ctx->r4 = SUB32(0, ctx->r7);
    // 0x802F9230: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x802F9234: b           L_802F9244
    // 0x802F9238: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802F9244;
    // 0x802F9238: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
L_802F923C:
    // 0x802F923C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F9240: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_802F9244:
    // 0x802F9244: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802F9248: beq         $at, $zero, L_802F9258
    if (ctx->r1 == 0) {
        // 0x802F924C: or          $a3, $a0, $zero
        ctx->r7 = ctx->r4 | 0;
            goto L_802F9258;
    }
    // 0x802F924C: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x802F9250: b           L_802F9258
    // 0x802F9254: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
        goto L_802F9258;
    // 0x802F9254: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
L_802F9258:
    // 0x802F9258: slt         $at, $a1, $a0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F925C: beq         $at, $zero, L_802F926C
    if (ctx->r1 == 0) {
        // 0x802F9260: or          $t0, $a0, $zero
        ctx->r8 = ctx->r4 | 0;
            goto L_802F926C;
    }
    // 0x802F9260: or          $t0, $a0, $zero
    ctx->r8 = ctx->r4 | 0;
    // 0x802F9264: b           L_802F926C
    // 0x802F9268: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
        goto L_802F926C;
    // 0x802F9268: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
L_802F926C:
    // 0x802F926C: sra         $t6, $t0, 1
    ctx->r14 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802F9270: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x802F9274: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802F9278: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F927C: slti        $at, $t9, 0x280
    ctx->r1 = SIGNED(ctx->r25) < 0X280 ? 1 : 0;
    // 0x802F9280: beql        $at, $zero, L_802F9294
    if (ctx->r1 == 0) {
        // 0x802F9284: sll         $t6, $v0, 16
        ctx->r14 = S32(ctx->r2 << 16);
            goto L_802F9294;
    }
    goto skip_5;
    // 0x802F9284: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    skip_5:
    // 0x802F9288: jr          $ra
    // 0x802F928C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802F928C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802F9290: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
L_802F9294:
    // 0x802F9294: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F9298: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802F929C: bnel        $at, $zero, L_802F91A8
    if (ctx->r1 != 0) {
        // 0x802F92A0: sll         $t6, $v0, 3
        ctx->r14 = S32(ctx->r2 << 3);
            goto L_802F91A8;
    }
    goto skip_6;
    // 0x802F92A0: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
    skip_6:
L_802F92A4:
    // 0x802F92A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F92A8: jr          $ra
    // 0x802F92AC: nop

    return;
    // 0x802F92AC: nop

;}
RECOMP_FUNC void func_802F92B0_70A960(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F92B0: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x802F92B4: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802F92B8: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802F92BC: jal         0x802F9178
    // 0x802F92C0: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    func_802F9178_70A828(rdram, ctx);
        goto after_0;
    // 0x802F92C0: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    after_0:
    // 0x802F92C4: sb          $v0, 0x47($sp)
    MEM_B(0X47, ctx->r29) = ctx->r2;
    // 0x802F92C8: lw          $a3, 0x188($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X188);
    // 0x802F92CC: beql        $a3, $zero, L_802F940C
    if (ctx->r7 == 0) {
        // 0x802F92D0: lh          $v0, 0x152($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X152);
            goto L_802F940C;
    }
    goto skip_0;
    // 0x802F92D0: lh          $v0, 0x152($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X152);
    skip_0:
    // 0x802F92D4: lh          $t6, 0x4($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X4);
    // 0x802F92D8: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x802F92DC: lh          $t8, 0x8($a3)
    ctx->r24 = MEM_H(ctx->r7, 0X8);
    // 0x802F92E0: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802F92E4: subu        $v1, $t6, $t7
    ctx->r3 = SUB32(ctx->r14, ctx->r15);
    // 0x802F92E8: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F92EC: subu        $a2, $t8, $t9
    ctx->r6 = SUB32(ctx->r24, ctx->r25);
    // 0x802F92F0: lh          $t0, 0xC($a3)
    ctx->r8 = MEM_H(ctx->r7, 0XC);
    // 0x802F92F4: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802F92F8: lhu         $t3, 0x42($a3)
    ctx->r11 = MEM_HU(ctx->r7, 0X42);
    // 0x802F92FC: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
    // 0x802F9300: subu        $t2, $t0, $t1
    ctx->r10 = SUB32(ctx->r8, ctx->r9);
    // 0x802F9304: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x802F9308: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x802F930C: sll         $a0, $v1, 16
    ctx->r4 = S32(ctx->r3 << 16);
    // 0x802F9310: mflo        $t6
    ctx->r14 = lo;
    // 0x802F9314: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F9318: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F931C: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F9320: sw          $t5, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r13;
    // 0x802F9324: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x802F9328: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x802F932C: mflo        $t7
    ctx->r15 = lo;
    // 0x802F9330: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802F9334: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x802F9338: nop

    // 0x802F933C: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802F9340: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802F9344: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802F9348: mfc1        $t0, $f6
    ctx->r8 = (int32_t)ctx->f6.u32l;
    // 0x802F934C: nop

    // 0x802F9350: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802F9354: sra         $t3, $t1, 16
    ctx->r11 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802F9358: jal         0x801284B8
    // 0x802F935C: sw          $t3, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_1;
    // 0x802F935C: sw          $t3, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r11;
    after_1:
    // 0x802F9360: sh          $v0, 0x4E($sp)
    MEM_H(0X4E, ctx->r29) = ctx->r2;
    // 0x802F9364: lh          $a0, 0x56($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X56);
    // 0x802F9368: jal         0x801284B8
    // 0x802F936C: lh          $a1, 0x52($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X52);
    func_801284B8(rdram, ctx);
        goto after_2;
    // 0x802F936C: lh          $a1, 0x52($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X52);
    after_2:
    // 0x802F9370: lh          $v1, 0x150($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X150);
    // 0x802F9374: sll         $a3, $v0, 16
    ctx->r7 = S32(ctx->r2 << 16);
    // 0x802F9378: sra         $t5, $a3, 16
    ctx->r13 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802F937C: beq         $v1, $zero, L_802F9394
    if (ctx->r3 == 0) {
        // 0x802F9380: or          $a3, $t5, $zero
        ctx->r7 = ctx->r13 | 0;
            goto L_802F9394;
    }
    // 0x802F9380: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x802F9384: sll         $a2, $v1, 16
    ctx->r6 = S32(ctx->r3 << 16);
    // 0x802F9388: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802F938C: b           L_802F9398
    // 0x802F9390: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
        goto L_802F9398;
    // 0x802F9390: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
L_802F9394:
    // 0x802F9394: addiu       $a2, $zero, 0x7
    ctx->r6 = ADD32(0, 0X7);
L_802F9398:
    // 0x802F9398: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    // 0x802F939C: sh          $a3, 0x4C($sp)
    MEM_H(0X4C, ctx->r29) = ctx->r7;
    // 0x802F93A0: sh          $a2, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r6;
    // 0x802F93A4: jal         0x802F649C
    // 0x802F93A8: lh          $a0, 0x4E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X4E);
    func_802F649C_707B4C(rdram, ctx);
        goto after_3;
    // 0x802F93A8: lh          $a0, 0x4E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X4E);
    after_3:
    // 0x802F93AC: lh          $a2, 0x48($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X48);
    // 0x802F93B0: lh          $a3, 0x4C($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X4C);
    // 0x802F93B4: sh          $v0, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r2;
    // 0x802F93B8: sll         $a0, $a2, 2
    ctx->r4 = S32(ctx->r6 << 2);
    // 0x802F93BC: subu        $a0, $a0, $a2
    ctx->r4 = SUB32(ctx->r4, ctx->r6);
    // 0x802F93C0: bgez        $a0, L_802F93D0
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802F93C4: sra         $t7, $a0, 2
        ctx->r15 = S32(SIGNED(ctx->r4) >> 2);
            goto L_802F93D0;
    }
    // 0x802F93C4: sra         $t7, $a0, 2
    ctx->r15 = S32(SIGNED(ctx->r4) >> 2);
    // 0x802F93C8: addiu       $at, $a0, 0x3
    ctx->r1 = ADD32(ctx->r4, 0X3);
    // 0x802F93CC: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_802F93D0:
    // 0x802F93D0: slti        $at, $t7, 0x2
    ctx->r1 = SIGNED(ctx->r15) < 0X2 ? 1 : 0;
    // 0x802F93D4: bne         $at, $zero, L_802F93E4
    if (ctx->r1 != 0) {
        // 0x802F93D8: sll         $a0, $a3, 16
        ctx->r4 = S32(ctx->r7 << 16);
            goto L_802F93E4;
    }
    // 0x802F93D8: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x802F93DC: b           L_802F93E8
    // 0x802F93E0: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
        goto L_802F93E8;
    // 0x802F93E0: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_802F93E4:
    // 0x802F93E4: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_802F93E8:
    // 0x802F93E8: sll         $a2, $v1, 16
    ctx->r6 = S32(ctx->r3 << 16);
    // 0x802F93EC: sra         $t9, $a2, 16
    ctx->r25 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802F93F0: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802F93F4: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x802F93F8: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802F93FC: jal         0x802F649C
    // 0x802F9400: lh          $a1, 0x2E($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2E);
    func_802F649C_707B4C(rdram, ctx);
        goto after_4;
    // 0x802F9400: lh          $a1, 0x2E($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2E);
    after_4:
    // 0x802F9404: sh          $v0, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r2;
    // 0x802F9408: lh          $v0, 0x152($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X152);
L_802F940C:
    // 0x802F940C: addiu       $a1, $zero, 0x12
    ctx->r5 = ADD32(0, 0X12);
    // 0x802F9410: lbu         $t1, 0x47($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X47);
    // 0x802F9414: beq         $v0, $zero, L_802F942C
    if (ctx->r2 == 0) {
        // 0x802F9418: nop
    
            goto L_802F942C;
    }
    // 0x802F9418: nop

    // 0x802F941C: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x802F9420: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802F9424: b           L_802F942C
    // 0x802F9428: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
        goto L_802F942C;
    // 0x802F9428: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
L_802F942C:
    // 0x802F942C: beql        $t1, $zero, L_802F9474
    if (ctx->r9 == 0) {
        // 0x802F9430: lh          $v0, 0x2C($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X2C);
            goto L_802F9474;
    }
    goto skip_1;
    // 0x802F9430: lh          $v0, 0x2C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2C);
    skip_1:
    // 0x802F9434: lh          $t2, 0x14E($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X14E);
    // 0x802F9438: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802F943C: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x802F9440: sll         $t4, $t2, 4
    ctx->r12 = S32(ctx->r10 << 4);
    // 0x802F9444: div         $zero, $t4, $at
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r1)));
    // 0x802F9448: mfhi        $t5
    ctx->r13 = hi;
    // 0x802F944C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802F9450: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F9454: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802F9458: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802F945C: lh          $t9, 0x2620($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2620);
    // 0x802F9460: lh          $t3, 0x2C($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X2C);
    // 0x802F9464: sra         $t0, $t9, 5
    ctx->r8 = S32(SIGNED(ctx->r25) >> 5);
    // 0x802F9468: addu        $t1, $t3, $t0
    ctx->r9 = ADD32(ctx->r11, ctx->r8);
    // 0x802F946C: sh          $t1, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r9;
    // 0x802F9470: lh          $v0, 0x2C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2C);
L_802F9474:
    // 0x802F9474: slti        $at, $v0, 0x168
    ctx->r1 = SIGNED(ctx->r2) < 0X168 ? 1 : 0;
    // 0x802F9478: bne         $at, $zero, L_802F9488
    if (ctx->r1 != 0) {
        // 0x802F947C: addiu       $t2, $v0, -0x168
        ctx->r10 = ADD32(ctx->r2, -0X168);
            goto L_802F9488;
    }
    // 0x802F947C: addiu       $t2, $v0, -0x168
    ctx->r10 = ADD32(ctx->r2, -0X168);
    // 0x802F9480: b           L_802F9494
    // 0x802F9484: sh          $t2, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r10;
        goto L_802F9494;
    // 0x802F9484: sh          $t2, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r10;
L_802F9488:
    // 0x802F9488: bgez        $v0, L_802F9494
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F948C: addiu       $t4, $v0, 0x168
        ctx->r12 = ADD32(ctx->r2, 0X168);
            goto L_802F9494;
    }
    // 0x802F948C: addiu       $t4, $v0, 0x168
    ctx->r12 = ADD32(ctx->r2, 0X168);
    // 0x802F9490: sh          $t4, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r12;
L_802F9494:
    // 0x802F9494: jal         0x802F6DEC
    // 0x802F9498: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F6DEC_70849C(rdram, ctx);
        goto after_5;
    // 0x802F9498: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_5:
    // 0x802F949C: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
    // 0x802F94A0: lbu         $t6, 0x154($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X154);
    // 0x802F94A4: addiu       $t7, $zero, 0xA0
    ctx->r15 = ADD32(0, 0XA0);
    // 0x802F94A8: addiu       $t5, $v0, 0x1
    ctx->r13 = ADD32(ctx->r2, 0X1);
    // 0x802F94AC: bne         $t6, $zero, L_802F94B8
    if (ctx->r14 != 0) {
        // 0x802F94B0: sh          $t5, 0x14E($s0)
        MEM_H(0X14E, ctx->r16) = ctx->r13;
            goto L_802F94B8;
    }
    // 0x802F94B0: sh          $t5, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r13;
    // 0x802F94B4: sb          $t7, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r15;
L_802F94B8:
    // 0x802F94B8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802F94BC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802F94C0: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x802F94C4: lui         $a3, 0x3ECC
    ctx->r7 = S32(0X3ECC << 16);
    // 0x802F94C8: ori         $a3, $a3, 0xCCCD
    ctx->r7 = ctx->r7 | 0XCCCD;
    // 0x802F94CC: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x802F94D0: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802F94D4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802F94D8: addiu       $a1, $zero, 0x67
    ctx->r5 = ADD32(0, 0X67);
    // 0x802F94DC: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802F94E0: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x802F94E4: addiu       $a2, $zero, 0x4000
    ctx->r6 = ADD32(0, 0X4000);
    // 0x802F94E8: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    // 0x802F94EC: lw          $t0, 0x1C($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X1C);
    // 0x802F94F0: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x802F94F4: lw          $t1, 0x20($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X20);
    // 0x802F94F8: sw          $t1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r9;
    // 0x802F94FC: lw          $t2, 0x24($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X24);
    // 0x802F9500: jal         0x8032CED0
    // 0x802F9504: sw          $t2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r10;
    func_8032CED0_73E580(rdram, ctx);
        goto after_6;
    // 0x802F9504: sw          $t2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r10;
    after_6:
    // 0x802F9508: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x802F950C: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802F9510: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    // 0x802F9514: jr          $ra
    // 0x802F9518: nop

    return;
    // 0x802F9518: nop

;}
RECOMP_FUNC void func_802F951C_70ABCC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F951C: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802F9520: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802F9524: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802F9528: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F952C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F9530: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F9534: bnel        $t6, $at, L_802F9614
    if (ctx->r14 != ctx->r1) {
        // 0x802F9538: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_802F9614;
    }
    goto skip_0;
    // 0x802F9538: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_0:
    // 0x802F953C: lbu         $t1, 0x203($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X203);
    // 0x802F9540: lbu         $v1, 0x207($a0)
    ctx->r3 = MEM_BU(ctx->r4, 0X207);
    // 0x802F9544: lbu         $t0, 0x20B($a0)
    ctx->r8 = MEM_BU(ctx->r4, 0X20B);
    // 0x802F9548: bne         $t1, $zero, L_802F9560
    if (ctx->r9 != 0) {
        // 0x802F954C: or          $v0, $t1, $zero
        ctx->r2 = ctx->r9 | 0;
            goto L_802F9560;
    }
    // 0x802F954C: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
    // 0x802F9550: bnel        $v1, $zero, L_802F9564
    if (ctx->r3 != 0) {
        // 0x802F9554: lh          $a0, 0x4($s0)
        ctx->r4 = MEM_H(ctx->r16, 0X4);
            goto L_802F9564;
    }
    goto skip_1;
    // 0x802F9554: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    skip_1:
    // 0x802F9558: beql        $t0, $zero, L_802F9614
    if (ctx->r8 == 0) {
        // 0x802F955C: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_802F9614;
    }
    goto skip_2;
    // 0x802F955C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_2:
L_802F9560:
    // 0x802F9560: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
L_802F9564:
    // 0x802F9564: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9568: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802F956C: sb          $t1, 0x3F($sp)
    MEM_B(0X3F, ctx->r29) = ctx->r9;
    // 0x802F9570: sb          $t0, 0x3D($sp)
    MEM_B(0X3D, ctx->r29) = ctx->r8;
    // 0x802F9574: sb          $v1, 0x3E($sp)
    MEM_B(0X3E, ctx->r29) = ctx->r3;
    // 0x802F9578: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x802F957C: sw          $v1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r3;
    // 0x802F9580: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802F9584: jal         0x802F2B54
    // 0x802F9588: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    add_light_at_location(rdram, ctx);
        goto after_0;
    // 0x802F9588: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_0:
    // 0x802F958C: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802F9590: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802F9594: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9598: sll         $t3, $v0, 3
    ctx->r11 = S32(ctx->r2 << 3);
    // 0x802F959C: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802F95A0: addu        $t3, $t3, $v0
    ctx->r11 = ADD32(ctx->r11, ctx->r2);
    // 0x802F95A4: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x802F95A8: subu        $t3, $t3, $v0
    ctx->r11 = SUB32(ctx->r11, ctx->r2);
    // 0x802F95AC: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802F95B0: lbu         $v1, 0x3E($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X3E);
    // 0x802F95B4: lbu         $t0, 0x3D($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X3D);
    // 0x802F95B8: lbu         $t1, 0x3F($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X3F);
    // 0x802F95BC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802F95C0: addu        $t3, $t3, $v0
    ctx->r11 = ADD32(ctx->r11, ctx->r2);
    // 0x802F95C4: sll         $a3, $v0, 1
    ctx->r7 = S32(ctx->r2 << 1);
    // 0x802F95C8: andi        $t4, $a3, 0xFFFF
    ctx->r12 = ctx->r7 & 0XFFFF;
    // 0x802F95CC: sll         $t3, $t3, 1
    ctx->r11 = S32(ctx->r11 << 1);
    // 0x802F95D0: addiu       $t6, $t6, 0x2E08
    ctx->r14 = ADD32(ctx->r14, 0X2E08);
    // 0x802F95D4: addiu       $t5, $zero, 0x22
    ctx->r13 = ADD32(0, 0X22);
    // 0x802F95D8: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x802F95DC: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802F95E0: sll         $t2, $t9, 16
    ctx->r10 = S32(ctx->r25 << 16);
    // 0x802F95E4: addu        $a2, $t2, $t3
    ctx->r6 = ADD32(ctx->r10, ctx->r11);
    // 0x802F95E8: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802F95EC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802F95F0: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802F95F4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802F95F8: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x802F95FC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802F9600: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    // 0x802F9604: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x802F9608: jal         0x8029CEF0
    // 0x802F960C: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    enqueue_dynamic_texture_billboard_6AE5A0(rdram, ctx);
        goto after_1;
    // 0x802F960C: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    after_1:
    // 0x802F9610: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802F9614:
    // 0x802F9614: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802F9618: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x802F961C: jr          $ra
    // 0x802F9620: nop

    return;
    // 0x802F9620: nop

;}
RECOMP_FUNC void func_802F9624_70ACD4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9624: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802F9628: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802F962C: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802F9630: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F9634: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F9638: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F963C: bnel        $t6, $at, L_802F96D0
    if (ctx->r14 != ctx->r1) {
        // 0x802F9640: lw          $ra, 0x3C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X3C);
            goto L_802F96D0;
    }
    goto skip_0;
    // 0x802F9640: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    skip_0:
    // 0x802F9644: lh          $t7, 0x14E($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9648: addiu       $a3, $zero, 0x3F
    ctx->r7 = ADD32(0, 0X3F);
    // 0x802F964C: lui         $t5, 0x4
    ctx->r13 = S32(0X4 << 16);
    // 0x802F9650: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x802F9654: sh          $t8, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r24;
    // 0x802F9658: lh          $t9, 0x14E($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X14E);
    // 0x802F965C: andi        $t0, $t9, 0x3
    ctx->r8 = ctx->r25 & 0X3;
    // 0x802F9660: sh          $t0, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r8;
    // 0x802F9664: lh          $t1, 0x14E($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9668: bnel        $t1, $zero, L_802F96D0
    if (ctx->r9 != 0) {
        // 0x802F966C: lw          $ra, 0x3C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X3C);
            goto L_802F96D0;
    }
    goto skip_1;
    // 0x802F966C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    skip_1:
    // 0x802F9670: lhu         $v0, 0x42($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X42);
    // 0x802F9674: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802F9678: lh          $a0, 0x4($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X4);
    // 0x802F967C: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9680: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802F9684: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802F9688: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802F968C: lhu         $t6, 0x40($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X40);
    // 0x802F9690: addu        $t3, $t2, $v0
    ctx->r11 = ADD32(ctx->r10, ctx->r2);
    // 0x802F9694: bgez        $v0, L_802F96A4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F9698: sra         $t4, $v0, 1
        ctx->r12 = S32(SIGNED(ctx->r2) >> 1);
            goto L_802F96A4;
    }
    // 0x802F9698: sra         $t4, $v0, 1
    ctx->r12 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802F969C: addiu       $at, $v0, 0x1
    ctx->r1 = ADD32(ctx->r2, 0X1);
    // 0x802F96A0: sra         $t4, $at, 1
    ctx->r12 = S32(SIGNED(ctx->r1) >> 1);
L_802F96A4:
    // 0x802F96A4: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802F96A8: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x802F96AC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802F96B0: sra         $t8, $t7, 11
    ctx->r24 = S32(SIGNED(ctx->r15) >> 11);
    // 0x802F96B4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x802F96B8: addu        $a2, $t3, $t4
    ctx->r6 = ADD32(ctx->r11, ctx->r12);
    // 0x802F96BC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802F96C0: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802F96C4: jal         0x802D5F4C
    // 0x802F96C8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    create_particle_effect(rdram, ctx);
        goto after_0;
    // 0x802F96C8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    after_0:
    // 0x802F96CC: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_802F96D0:
    // 0x802F96D0: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802F96D4: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x802F96D8: jr          $ra
    // 0x802F96DC: nop

    return;
    // 0x802F96DC: nop

;}
RECOMP_FUNC void func_802F96E0_70AD90(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F96E0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802F96E4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802F96E8: lh          $t6, 0x150($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X150);
    // 0x802F96EC: bnel        $t6, $zero, L_802F9714
    if (ctx->r14 != 0) {
        // 0x802F96F0: lhu         $t9, 0x0($a0)
        ctx->r25 = MEM_HU(ctx->r4, 0X0);
            goto L_802F9714;
    }
    goto skip_0;
    // 0x802F96F0: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
    skip_0:
    // 0x802F96F4: lhu         $t7, 0x40($a0)
    ctx->r15 = MEM_HU(ctx->r4, 0X40);
    // 0x802F96F8: sh          $t7, 0x150($a0)
    MEM_H(0X150, ctx->r4) = ctx->r15;
    // 0x802F96FC: jal         0x80128200
    // 0x802F9700: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    func_80128200(rdram, ctx);
        goto after_0;
    // 0x802F9700: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x802F9704: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x802F9708: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x802F970C: sh          $t8, 0x152($a0)
    MEM_H(0X152, ctx->r4) = ctx->r24;
    // 0x802F9710: lhu         $t9, 0x0($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X0);
L_802F9714:
    // 0x802F9714: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F9718: bnel        $t9, $at, L_802F9758
    if (ctx->r25 != ctx->r1) {
        // 0x802F971C: lh          $v0, 0x14E($a0)
        ctx->r2 = MEM_H(ctx->r4, 0X14E);
            goto L_802F9758;
    }
    goto skip_1;
    // 0x802F971C: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    skip_1:
    // 0x802F9720: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9724: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802F9728: beq         $at, $zero, L_802F9778
    if (ctx->r1 == 0) {
        // 0x802F972C: addiu       $t0, $v0, 0x8
        ctx->r8 = ADD32(ctx->r2, 0X8);
            goto L_802F9778;
    }
    // 0x802F972C: addiu       $t0, $v0, 0x8
    ctx->r8 = ADD32(ctx->r2, 0X8);
    // 0x802F9730: sh          $t0, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r8;
    // 0x802F9734: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9738: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
    // 0x802F973C: slti        $at, $v0, 0x101
    ctx->r1 = SIGNED(ctx->r2) < 0X101 ? 1 : 0;
    // 0x802F9740: bne         $at, $zero, L_802F9778
    if (ctx->r1 != 0) {
        // 0x802F9744: nop
    
            goto L_802F9778;
    }
    // 0x802F9744: nop

    // 0x802F9748: sh          $t1, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r9;
    // 0x802F974C: b           L_802F9778
    // 0x802F9750: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
        goto L_802F9778;
    // 0x802F9750: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9754: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9758:
    // 0x802F9758: blez        $v0, L_802F9778
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F975C: addiu       $t2, $v0, -0x8
        ctx->r10 = ADD32(ctx->r2, -0X8);
            goto L_802F9778;
    }
    // 0x802F975C: addiu       $t2, $v0, -0x8
    ctx->r10 = ADD32(ctx->r2, -0X8);
    // 0x802F9760: sh          $t2, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r10;
    // 0x802F9764: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9768: bgez        $v0, L_802F9778
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F976C: nop
    
            goto L_802F9778;
    }
    // 0x802F976C: nop

    // 0x802F9770: sh          $zero, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = 0;
    // 0x802F9774: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9778:
    // 0x802F9778: blezl       $v0, L_802F9874
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F977C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802F9874;
    }
    goto skip_2;
    // 0x802F977C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802F9780: lh          $t3, 0x152($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X152);
    // 0x802F9784: lui         $at, 0x3FF8
    ctx->r1 = S32(0X3FF8 << 16);
    // 0x802F9788: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x802F978C: addiu       $t4, $t3, 0x4
    ctx->r12 = ADD32(ctx->r11, 0X4);
    // 0x802F9790: sh          $t4, 0x152($a0)
    MEM_H(0X152, ctx->r4) = ctx->r12;
    // 0x802F9794: lh          $t5, 0x152($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X152);
    // 0x802F9798: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x802F979C: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802F97A0: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802F97A4: sh          $t6, 0x152($a0)
    MEM_H(0X152, ctx->r4) = ctx->r14;
    // 0x802F97A8: lh          $t0, 0x152($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X152);
    // 0x802F97AC: lh          $t6, 0x150($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X150);
    // 0x802F97B0: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802F97B4: addiu       $t1, $t0, 0x40
    ctx->r9 = ADD32(ctx->r8, 0X40);
    // 0x802F97B8: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x802F97BC: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x802F97C0: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x802F97C4: lh          $t4, 0x2C78($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C78);
    // 0x802F97C8: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x802F97CC: lui         $at, 0x41E0
    ctx->r1 = S32(0X41E0 << 16);
    // 0x802F97D0: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x802F97D4: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802F97D8: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x802F97DC: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802F97E0: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x802F97E4: add.d       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f10.d + ctx->f18.d;
    // 0x802F97E8: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x802F97EC: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802F97F0: nop

    // 0x802F97F4: cvt.w.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_D(ctx->f4.d);
    // 0x802F97F8: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802F97FC: nop

    // 0x802F9800: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802F9804: beql        $t8, $zero, L_802F9858
    if (ctx->r24 == 0) {
        // 0x802F9808: mfc1        $t8, $f6
        ctx->r24 = (int32_t)ctx->f6.u32l;
            goto L_802F9858;
    }
    goto skip_3;
    // 0x802F9808: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    skip_3:
    // 0x802F980C: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802F9810: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802F9814: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802F9818: sub.d       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f6.d = ctx->f4.d - ctx->f6.d;
    // 0x802F981C: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802F9820: nop

    // 0x802F9824: cvt.w.d     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_D(ctx->f6.d);
    // 0x802F9828: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802F982C: nop

    // 0x802F9830: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802F9834: bne         $t8, $zero, L_802F984C
    if (ctx->r24 != 0) {
        // 0x802F9838: nop
    
            goto L_802F984C;
    }
    // 0x802F9838: nop

    // 0x802F983C: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x802F9840: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F9844: b           L_802F9864
    // 0x802F9848: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_802F9864;
    // 0x802F9848: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_802F984C:
    // 0x802F984C: b           L_802F9864
    // 0x802F9850: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_802F9864;
    // 0x802F9850: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x802F9854: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
L_802F9858:
    // 0x802F9858: nop

    // 0x802F985C: bltz        $t8, L_802F984C
    if (SIGNED(ctx->r24) < 0) {
        // 0x802F9860: nop
    
            goto L_802F984C;
    }
    // 0x802F9860: nop

L_802F9864:
    // 0x802F9864: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x802F9868: jal         0x802C9BA4
    // 0x802F986C: sh          $t8, 0x40($a0)
    MEM_H(0X40, ctx->r4) = ctx->r24;
    func_802C9BA4_6DB254(rdram, ctx);
        goto after_1;
    // 0x802F986C: sh          $t8, 0x40($a0)
    MEM_H(0X40, ctx->r4) = ctx->r24;
    after_1:
    // 0x802F9870: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802F9874:
    // 0x802F9874: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802F9878: jr          $ra
    // 0x802F987C: nop

    return;
    // 0x802F987C: nop

;}
RECOMP_FUNC void func_802F9880_70AF30(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9880: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802F9884: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802F9888: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802F988C: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F9890: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802F9894: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F9898: bnel        $v1, $t6, L_802F9920
    if (ctx->r3 != ctx->r14) {
        // 0x802F989C: lh          $t4, 0x150($s0)
        ctx->r12 = MEM_H(ctx->r16, 0X150);
            goto L_802F9920;
    }
    goto skip_0;
    // 0x802F989C: lh          $t4, 0x150($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X150);
    skip_0:
    // 0x802F98A0: lh          $t7, 0x150($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X150);
    // 0x802F98A4: bnel        $t7, $zero, L_802F98F0
    if (ctx->r15 != 0) {
        // 0x802F98A8: lh          $v0, 0x14E($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X14E);
            goto L_802F98F0;
    }
    goto skip_1;
    // 0x802F98A8: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
    skip_1:
    // 0x802F98AC: lh          $t8, 0x152($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X152);
    // 0x802F98B0: sh          $v1, 0x150($a0)
    MEM_H(0X150, ctx->r4) = ctx->r3;
    // 0x802F98B4: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F98B8: beq         $t8, $zero, L_802F98EC
    if (ctx->r24 == 0) {
        // 0x802F98BC: addiu       $a1, $zero, 0x7FFF
        ctx->r5 = ADD32(0, 0X7FFF);
            goto L_802F98EC;
    }
    // 0x802F98BC: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F98C0: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802F98C4: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F98C8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802F98CC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802F98D0: lh          $t0, 0xC($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XC);
    // 0x802F98D4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F98D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F98DC: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802F98E0: jal         0x8032C360
    // 0x802F98E4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x802F98E4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_0:
    // 0x802F98E8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_802F98EC:
    // 0x802F98EC: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
L_802F98F0:
    // 0x802F98F0: slti        $at, $v0, 0x80
    ctx->r1 = SIGNED(ctx->r2) < 0X80 ? 1 : 0;
    // 0x802F98F4: beq         $at, $zero, L_802F9988
    if (ctx->r1 == 0) {
        // 0x802F98F8: addiu       $t1, $v0, 0x8
        ctx->r9 = ADD32(ctx->r2, 0X8);
            goto L_802F9988;
    }
    // 0x802F98F8: addiu       $t1, $v0, 0x8
    ctx->r9 = ADD32(ctx->r2, 0X8);
    // 0x802F98FC: sh          $t1, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r9;
    // 0x802F9900: lh          $t2, 0x14E($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X14E);
    // 0x802F9904: addiu       $t3, $zero, 0x80
    ctx->r11 = ADD32(0, 0X80);
    // 0x802F9908: slti        $at, $t2, 0x80
    ctx->r1 = SIGNED(ctx->r10) < 0X80 ? 1 : 0;
    // 0x802F990C: bnel        $at, $zero, L_802F998C
    if (ctx->r1 != 0) {
        // 0x802F9910: lh          $t0, 0x152($s0)
        ctx->r8 = MEM_H(ctx->r16, 0X152);
            goto L_802F998C;
    }
    goto skip_2;
    // 0x802F9910: lh          $t0, 0x152($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X152);
    skip_2:
    // 0x802F9914: b           L_802F9988
    // 0x802F9918: sh          $t3, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r11;
        goto L_802F9988;
    // 0x802F9918: sh          $t3, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r11;
    // 0x802F991C: lh          $t4, 0x150($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X150);
L_802F9920:
    // 0x802F9920: bnel        $v1, $t4, L_802F996C
    if (ctx->r3 != ctx->r12) {
        // 0x802F9924: lh          $v0, 0x14E($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X14E);
            goto L_802F996C;
    }
    goto skip_3;
    // 0x802F9924: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
    skip_3:
    // 0x802F9928: lh          $t5, 0x152($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X152);
    // 0x802F992C: sh          $zero, 0x150($s0)
    MEM_H(0X150, ctx->r16) = 0;
    // 0x802F9930: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F9934: beq         $t5, $zero, L_802F9968
    if (ctx->r13 == 0) {
        // 0x802F9938: addiu       $a1, $zero, 0x7FFF
        ctx->r5 = ADD32(0, 0X7FFF);
            goto L_802F9968;
    }
    // 0x802F9938: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F993C: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x802F9940: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F9944: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F9948: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802F994C: lh          $t7, 0xC($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XC);
    // 0x802F9950: lwc1        $f6, -0x30F8($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0X30F8);
    // 0x802F9954: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F9958: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802F995C: jal         0x8032C360
    // 0x802F9960: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802F9960: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_1:
    // 0x802F9964: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_802F9968:
    // 0x802F9968: lh          $v0, 0x14E($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14E);
L_802F996C:
    // 0x802F996C: blez        $v0, L_802F9988
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F9970: addiu       $t8, $v0, -0x8
        ctx->r24 = ADD32(ctx->r2, -0X8);
            goto L_802F9988;
    }
    // 0x802F9970: addiu       $t8, $v0, -0x8
    ctx->r24 = ADD32(ctx->r2, -0X8);
    // 0x802F9974: sh          $t8, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r24;
    // 0x802F9978: lh          $t9, 0x14E($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X14E);
    // 0x802F997C: bgezl       $t9, L_802F998C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802F9980: lh          $t0, 0x152($s0)
        ctx->r8 = MEM_H(ctx->r16, 0X152);
            goto L_802F998C;
    }
    goto skip_4;
    // 0x802F9980: lh          $t0, 0x152($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X152);
    skip_4:
    // 0x802F9984: sh          $zero, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = 0;
L_802F9988:
    // 0x802F9988: lh          $t0, 0x152($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X152);
L_802F998C:
    // 0x802F998C: bnel        $t0, $zero, L_802F999C
    if (ctx->r8 != 0) {
        // 0x802F9990: lh          $t1, 0x14E($s0)
        ctx->r9 = MEM_H(ctx->r16, 0X14E);
            goto L_802F999C;
    }
    goto skip_5;
    // 0x802F9990: lh          $t1, 0x14E($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X14E);
    skip_5:
    // 0x802F9994: sh          $v1, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r3;
    // 0x802F9998: lh          $t1, 0x14E($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X14E);
L_802F999C:
    // 0x802F999C: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x802F99A0: lh          $t9, 0x2E($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2E);
    // 0x802F99A4: addiu       $t2, $t1, 0x40
    ctx->r10 = ADD32(ctx->r9, 0X40);
    // 0x802F99A8: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x802F99AC: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x802F99B0: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802F99B4: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x802F99B8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802F99BC: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x802F99C0: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802F99C4: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802F99C8: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802F99CC: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802F99D0: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802F99D4: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x802F99D8: sra         $t8, $t7, 8
    ctx->r24 = S32(SIGNED(ctx->r15) >> 8);
    // 0x802F99DC: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x802F99E0: sh          $t0, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r8;
    // 0x802F99E4: lh          $t1, 0x152($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X152);
    // 0x802F99E8: div         $zero, $t1, $at
    lo = S32(S64(S32(ctx->r9)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r9)) % S64(S32(ctx->r1)));
    // 0x802F99EC: mfhi        $t2
    ctx->r10 = hi;
    // 0x802F99F0: sh          $t2, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r10;
    // 0x802F99F4: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802F99F8: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802F99FC: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802F9A00: jr          $ra
    // 0x802F9A04: nop

    return;
    // 0x802F9A04: nop

;}
RECOMP_FUNC void func_802F9A08_70B0B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9A08: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F9A0C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802F9A10: bnel        $t6, $at, L_802F9A90
    if (ctx->r14 != ctx->r1) {
        // 0x802F9A14: lh          $v0, 0x14E($a0)
        ctx->r2 = MEM_H(ctx->r4, 0X14E);
            goto L_802F9A90;
    }
    goto skip_0;
    // 0x802F9A14: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    skip_0:
    // 0x802F9A18: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9A1C: addiu       $v1, $zero, 0x80
    ctx->r3 = ADD32(0, 0X80);
    // 0x802F9A20: addiu       $t8, $zero, 0x60
    ctx->r24 = ADD32(0, 0X60);
    // 0x802F9A24: bne         $v0, $zero, L_802F9A58
    if (ctx->r2 != 0) {
        // 0x802F9A28: addiu       $t9, $zero, 0x5
        ctx->r25 = ADD32(0, 0X5);
            goto L_802F9A58;
    }
    // 0x802F9A28: addiu       $t9, $zero, 0x5
    ctx->r25 = ADD32(0, 0X5);
    // 0x802F9A2C: addiu       $t7, $zero, 0xD
    ctx->r15 = ADD32(0, 0XD);
    // 0x802F9A30: addiu       $t0, $zero, 0x40
    ctx->r8 = ADD32(0, 0X40);
    // 0x802F9A34: sb          $t7, 0x23C($a0)
    MEM_B(0X23C, ctx->r4) = ctx->r15;
    // 0x802F9A38: sb          $v1, 0x23D($a0)
    MEM_B(0X23D, ctx->r4) = ctx->r3;
    // 0x802F9A3C: sb          $v1, 0x23E($a0)
    MEM_B(0X23E, ctx->r4) = ctx->r3;
    // 0x802F9A40: sb          $t8, 0x23F($a0)
    MEM_B(0X23F, ctx->r4) = ctx->r24;
    // 0x802F9A44: sb          $v1, 0x240($a0)
    MEM_B(0X240, ctx->r4) = ctx->r3;
    // 0x802F9A48: sb          $t9, 0x241($a0)
    MEM_B(0X241, ctx->r4) = ctx->r25;
    // 0x802F9A4C: sh          $t0, 0x242($a0)
    MEM_H(0X242, ctx->r4) = ctx->r8;
    // 0x802F9A50: sh          $zero, 0x244($a0)
    MEM_H(0X244, ctx->r4) = 0;
    // 0x802F9A54: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9A58:
    // 0x802F9A58: slti        $at, $v0, 0xFF
    ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
    // 0x802F9A5C: beql        $at, $zero, L_802F9AFC
    if (ctx->r1 == 0) {
        // 0x802F9A60: addiu       $v1, $zero, 0x168
        ctx->r3 = ADD32(0, 0X168);
            goto L_802F9AFC;
    }
    goto skip_1;
    // 0x802F9A60: addiu       $v1, $zero, 0x168
    ctx->r3 = ADD32(0, 0X168);
    skip_1:
    // 0x802F9A64: addiu       $t1, $v0, 0x4
    ctx->r9 = ADD32(ctx->r2, 0X4);
    // 0x802F9A68: sh          $t1, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r9;
    // 0x802F9A6C: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9A70: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802F9A74: bnel        $at, $zero, L_802F9AFC
    if (ctx->r1 != 0) {
        // 0x802F9A78: addiu       $v1, $zero, 0x168
        ctx->r3 = ADD32(0, 0X168);
            goto L_802F9AFC;
    }
    goto skip_2;
    // 0x802F9A78: addiu       $v1, $zero, 0x168
    ctx->r3 = ADD32(0, 0X168);
    skip_2:
    // 0x802F9A7C: addiu       $t2, $zero, 0xFF
    ctx->r10 = ADD32(0, 0XFF);
    // 0x802F9A80: sh          $t2, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r10;
    // 0x802F9A84: b           L_802F9AF8
    // 0x802F9A88: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
        goto L_802F9AF8;
    // 0x802F9A88: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9A8C: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9A90:
    // 0x802F9A90: addiu       $v1, $zero, 0x80
    ctx->r3 = ADD32(0, 0X80);
    // 0x802F9A94: slti        $at, $v0, 0xFF
    ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
    // 0x802F9A98: bne         $at, $zero, L_802F9AD4
    if (ctx->r1 != 0) {
        // 0x802F9A9C: nop
    
            goto L_802F9AD4;
    }
    // 0x802F9A9C: nop

    // 0x802F9AA0: addiu       $t3, $zero, 0xD
    ctx->r11 = ADD32(0, 0XD);
    // 0x802F9AA4: addiu       $t4, $zero, 0x60
    ctx->r12 = ADD32(0, 0X60);
    // 0x802F9AA8: addiu       $t5, $zero, 0x5
    ctx->r13 = ADD32(0, 0X5);
    // 0x802F9AAC: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x802F9AB0: sb          $t3, 0x23C($a0)
    MEM_B(0X23C, ctx->r4) = ctx->r11;
    // 0x802F9AB4: sb          $v1, 0x23D($a0)
    MEM_B(0X23D, ctx->r4) = ctx->r3;
    // 0x802F9AB8: sb          $v1, 0x23E($a0)
    MEM_B(0X23E, ctx->r4) = ctx->r3;
    // 0x802F9ABC: sb          $v1, 0x23F($a0)
    MEM_B(0X23F, ctx->r4) = ctx->r3;
    // 0x802F9AC0: sb          $t4, 0x240($a0)
    MEM_B(0X240, ctx->r4) = ctx->r12;
    // 0x802F9AC4: sb          $t5, 0x241($a0)
    MEM_B(0X241, ctx->r4) = ctx->r13;
    // 0x802F9AC8: sh          $t6, 0x242($a0)
    MEM_H(0X242, ctx->r4) = ctx->r14;
    // 0x802F9ACC: sh          $zero, 0x244($a0)
    MEM_H(0X244, ctx->r4) = 0;
    // 0x802F9AD0: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9AD4:
    // 0x802F9AD4: blezl       $v0, L_802F9AFC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802F9AD8: addiu       $v1, $zero, 0x168
        ctx->r3 = ADD32(0, 0X168);
            goto L_802F9AFC;
    }
    goto skip_3;
    // 0x802F9AD8: addiu       $v1, $zero, 0x168
    ctx->r3 = ADD32(0, 0X168);
    skip_3:
    // 0x802F9ADC: addiu       $t7, $v0, -0x4
    ctx->r15 = ADD32(ctx->r2, -0X4);
    // 0x802F9AE0: sh          $t7, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r15;
    // 0x802F9AE4: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9AE8: bgezl       $v0, L_802F9AFC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F9AEC: addiu       $v1, $zero, 0x168
        ctx->r3 = ADD32(0, 0X168);
            goto L_802F9AFC;
    }
    goto skip_4;
    // 0x802F9AEC: addiu       $v1, $zero, 0x168
    ctx->r3 = ADD32(0, 0X168);
    skip_4:
    // 0x802F9AF0: sh          $zero, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = 0;
    // 0x802F9AF4: lh          $v0, 0x14E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X14E);
L_802F9AF8:
    // 0x802F9AF8: addiu       $v1, $zero, 0x168
    ctx->r3 = ADD32(0, 0X168);
L_802F9AFC:
    // 0x802F9AFC: multu       $v0, $v1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F9B00: mflo        $t8
    ctx->r24 = lo;
    // 0x802F9B04: bgez        $t8, L_802F9B14
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802F9B08: sra         $t9, $t8, 7
        ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
            goto L_802F9B14;
    }
    // 0x802F9B08: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802F9B0C: addiu       $at, $t8, 0x7F
    ctx->r1 = ADD32(ctx->r24, 0X7F);
    // 0x802F9B10: sra         $t9, $at, 7
    ctx->r25 = S32(SIGNED(ctx->r1) >> 7);
L_802F9B14:
    // 0x802F9B14: div         $zero, $t9, $v1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r3)));
    // 0x802F9B18: mfhi        $t0
    ctx->r8 = hi;
    // 0x802F9B1C: sh          $t0, 0x2C($a0)
    MEM_H(0X2C, ctx->r4) = ctx->r8;
    // 0x802F9B20: bne         $v1, $zero, L_802F9B2C
    if (ctx->r3 != 0) {
        // 0x802F9B24: nop
    
            goto L_802F9B2C;
    }
    // 0x802F9B24: nop

    // 0x802F9B28: break       7
    do_break(2150603560);
L_802F9B2C:
    // 0x802F9B2C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802F9B30: bne         $v1, $at, L_802F9B44
    if (ctx->r3 != ctx->r1) {
        // 0x802F9B34: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802F9B44;
    }
    // 0x802F9B34: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802F9B38: bne         $t9, $at, L_802F9B44
    if (ctx->r25 != ctx->r1) {
        // 0x802F9B3C: nop
    
            goto L_802F9B44;
    }
    // 0x802F9B3C: nop

    // 0x802F9B40: break       6
    do_break(2150603584);
L_802F9B44:
    // 0x802F9B44: jr          $ra
    // 0x802F9B48: nop

    return;
    // 0x802F9B48: nop

;}
RECOMP_FUNC void func_802F9B4C_70B1FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9B4C: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802F9B50: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802F9B54: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802F9B58: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F9B5C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802F9B60: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F9B64: bne         $v0, $t6, L_802F9BE0
    if (ctx->r2 != ctx->r14) {
        // 0x802F9B68: addiu       $a3, $zero, 0xFF
        ctx->r7 = ADD32(0, 0XFF);
            goto L_802F9BE0;
    }
    // 0x802F9B68: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    // 0x802F9B6C: lh          $a0, 0x4($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X4);
    // 0x802F9B70: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9B74: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802F9B78: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x802F9B7C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802F9B80: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802F9B84: jal         0x802F2B54
    // 0x802F9B88: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    add_light_at_location(rdram, ctx);
        goto after_0;
    // 0x802F9B88: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802F9B8C: lh          $t8, 0x14E($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14E);
    // 0x802F9B90: bne         $t8, $zero, L_802F9BD8
    if (ctx->r24 != 0) {
        // 0x802F9B94: nop
    
            goto L_802F9BD8;
    }
    // 0x802F9B94: nop

    // 0x802F9B98: lh          $t0, 0x152($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X152);
    // 0x802F9B9C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802F9BA0: sh          $t9, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = ctx->r25;
    // 0x802F9BA4: beq         $t0, $zero, L_802F9BD8
    if (ctx->r8 == 0) {
        // 0x802F9BA8: addiu       $a0, $zero, 0x52
        ctx->r4 = ADD32(0, 0X52);
            goto L_802F9BD8;
    }
    // 0x802F9BA8: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F9BAC: lh          $t1, 0x8($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X8);
    // 0x802F9BB0: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F9BB4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802F9BB8: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x802F9BBC: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802F9BC0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F9BC4: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F9BC8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F9BCC: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x802F9BD0: jal         0x8032C360
    // 0x802F9BD4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802F9BD4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_1:
L_802F9BD8:
    // 0x802F9BD8: b           L_802F9C2C
    // 0x802F9BDC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802F9C2C;
    // 0x802F9BDC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F9BE0:
    // 0x802F9BE0: lh          $t3, 0x14E($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X14E);
    // 0x802F9BE4: bnel        $v0, $t3, L_802F9C30
    if (ctx->r2 != ctx->r11) {
        // 0x802F9BE8: lh          $t7, 0x152($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X152);
            goto L_802F9C30;
    }
    goto skip_0;
    // 0x802F9BE8: lh          $t7, 0x152($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X152);
    skip_0:
    // 0x802F9BEC: lh          $t4, 0x152($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X152);
    // 0x802F9BF0: sh          $zero, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = 0;
    // 0x802F9BF4: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F9BF8: beq         $t4, $zero, L_802F9C2C
    if (ctx->r12 == 0) {
        // 0x802F9BFC: addiu       $a1, $zero, 0x7FFF
        ctx->r5 = ADD32(0, 0X7FFF);
            goto L_802F9C2C;
    }
    // 0x802F9BFC: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F9C00: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x802F9C04: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F9C08: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F9C0C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802F9C10: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802F9C14: lwc1        $f6, -0x30F4($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0X30F4);
    // 0x802F9C18: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F9C1C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802F9C20: jal         0x8032C360
    // 0x802F9C24: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_2;
    // 0x802F9C24: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_2:
    // 0x802F9C28: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802F9C2C:
    // 0x802F9C2C: lh          $t7, 0x152($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X152);
L_802F9C30:
    // 0x802F9C30: bnel        $t7, $zero, L_802F9C40
    if (ctx->r15 != 0) {
        // 0x802F9C34: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802F9C40;
    }
    goto skip_1;
    // 0x802F9C34: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_1:
    // 0x802F9C38: sh          $v0, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r2;
    // 0x802F9C3C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802F9C40:
    // 0x802F9C40: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802F9C44: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802F9C48: jr          $ra
    // 0x802F9C4C: nop

    return;
    // 0x802F9C4C: nop

;}
RECOMP_FUNC void func_802F9C50_70B300(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9C50: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802F9C54: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802F9C58: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x802F9C5C: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802F9C60: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802F9C64: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802F9C68: bnel        $v1, $t6, L_802F9CDC
    if (ctx->r3 != ctx->r14) {
        // 0x802F9C6C: lh          $t3, 0x14E($s0)
        ctx->r11 = MEM_H(ctx->r16, 0X14E);
            goto L_802F9CDC;
    }
    goto skip_0;
    // 0x802F9C6C: lh          $t3, 0x14E($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X14E);
    skip_0:
    // 0x802F9C70: lh          $t7, 0x14E($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X14E);
    // 0x802F9C74: addiu       $v0, $zero, 0xFF
    ctx->r2 = ADD32(0, 0XFF);
    // 0x802F9C78: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
    // 0x802F9C7C: bnel        $t7, $zero, L_802F9D40
    if (ctx->r15 != 0) {
        // 0x802F9C80: lh          $t7, 0x152($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X152);
            goto L_802F9D40;
    }
    goto skip_1;
    // 0x802F9C80: lh          $t7, 0x152($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X152);
    skip_1:
    // 0x802F9C84: lh          $t8, 0x152($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X152);
    // 0x802F9C88: sh          $v1, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r3;
    // 0x802F9C8C: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F9C90: beq         $t8, $zero, L_802F9D3C
    if (ctx->r24 == 0) {
        // 0x802F9C94: addiu       $a1, $zero, 0x7FFF
        ctx->r5 = ADD32(0, 0X7FFF);
            goto L_802F9D3C;
    }
    // 0x802F9C94: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F9C98: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x802F9C9C: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F9CA0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802F9CA4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802F9CA8: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802F9CAC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802F9CB0: sb          $zero, 0x55($sp)
    MEM_B(0X55, ctx->r29) = 0;
    // 0x802F9CB4: sb          $v0, 0x57($sp)
    MEM_B(0X57, ctx->r29) = ctx->r2;
    // 0x802F9CB8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F9CBC: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x802F9CC0: jal         0x8032C360
    // 0x802F9CC4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x802F9CC4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_0:
    // 0x802F9CC8: lbu         $v0, 0x57($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X57);
    // 0x802F9CCC: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802F9CD0: b           L_802F9D3C
    // 0x802F9CD4: lbu         $t1, 0x55($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X55);
        goto L_802F9D3C;
    // 0x802F9CD4: lbu         $t1, 0x55($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X55);
    // 0x802F9CD8: lh          $t3, 0x14E($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X14E);
L_802F9CDC:
    // 0x802F9CDC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802F9CE0: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x802F9CE4: bnel        $v1, $t3, L_802F9D40
    if (ctx->r3 != ctx->r11) {
        // 0x802F9CE8: lh          $t7, 0x152($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X152);
            goto L_802F9D40;
    }
    goto skip_2;
    // 0x802F9CE8: lh          $t7, 0x152($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X152);
    skip_2:
    // 0x802F9CEC: lh          $t4, 0x152($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X152);
    // 0x802F9CF0: sh          $zero, 0x14E($s0)
    MEM_H(0X14E, ctx->r16) = 0;
    // 0x802F9CF4: addiu       $a0, $zero, 0x52
    ctx->r4 = ADD32(0, 0X52);
    // 0x802F9CF8: beq         $t4, $zero, L_802F9D3C
    if (ctx->r12 == 0) {
        // 0x802F9CFC: addiu       $a1, $zero, 0x7FFF
        ctx->r5 = ADD32(0, 0X7FFF);
            goto L_802F9D3C;
    }
    // 0x802F9CFC: addiu       $a1, $zero, 0x7FFF
    ctx->r5 = ADD32(0, 0X7FFF);
    // 0x802F9D00: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x802F9D04: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802F9D08: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802F9D0C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802F9D10: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802F9D14: lwc1        $f6, -0x30F0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0X30F0);
    // 0x802F9D18: sb          $t1, 0x55($sp)
    MEM_B(0X55, ctx->r29) = ctx->r9;
    // 0x802F9D1C: sb          $zero, 0x57($sp)
    MEM_B(0X57, ctx->r29) = 0;
    // 0x802F9D20: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802F9D24: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802F9D28: jal         0x8032C360
    // 0x802F9D2C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x802F9D2C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_1:
    // 0x802F9D30: lbu         $v0, 0x57($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X57);
    // 0x802F9D34: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802F9D38: lbu         $t1, 0x55($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X55);
L_802F9D3C:
    // 0x802F9D3C: lh          $t7, 0x152($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X152);
L_802F9D40:
    // 0x802F9D40: sll         $t0, $t1, 16
    ctx->r8 = S32(ctx->r9 << 16);
    // 0x802F9D44: sra         $t9, $t0, 16
    ctx->r25 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802F9D48: bne         $t7, $zero, L_802F9D54
    if (ctx->r15 != 0) {
        // 0x802F9D4C: addiu       $a3, $zero, 0xFF
        ctx->r7 = ADD32(0, 0XFF);
            goto L_802F9D54;
    }
    // 0x802F9D4C: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    // 0x802F9D50: sh          $v1, 0x152($s0)
    MEM_H(0X152, ctx->r16) = ctx->r3;
L_802F9D54:
    // 0x802F9D54: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802F9D58: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9D5C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802F9D60: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802F9D64: sra         $t8, $v1, 16
    ctx->r24 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802F9D68: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802F9D6C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802F9D70: sw          $t8, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r24;
    // 0x802F9D74: sw          $t9, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r25;
    // 0x802F9D78: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x802F9D7C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802F9D80: jal         0x802F2B54
    // 0x802F9D84: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
    add_light_at_location(rdram, ctx);
        goto after_2;
    // 0x802F9D84: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
    after_2:
    // 0x802F9D88: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802F9D8C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802F9D90: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x802F9D94: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802F9D98: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802F9D9C: sll         $t2, $v0, 6
    ctx->r10 = S32(ctx->r2 << 6);
    // 0x802F9DA0: sra         $t3, $t2, 11
    ctx->r11 = S32(SIGNED(ctx->r10) >> 11);
    // 0x802F9DA4: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x802F9DA8: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802F9DAC: lw          $v1, 0x4C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X4C);
    // 0x802F9DB0: lw          $t0, 0x48($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X48);
    // 0x802F9DB4: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802F9DB8: lui         $t3, 0x103
    ctx->r11 = S32(0X103 << 16);
    // 0x802F9DBC: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    // 0x802F9DC0: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802F9DC4: addiu       $t3, $t3, 0x3190
    ctx->r11 = ADD32(ctx->r11, 0X3190);
    // 0x802F9DC8: addiu       $t4, $zero, 0x20
    ctx->r12 = ADD32(0, 0X20);
    // 0x802F9DCC: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x802F9DD0: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802F9DD4: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802F9DD8: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x802F9DDC: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802F9DE0: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x802F9DE4: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x802F9DE8: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802F9DEC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802F9DF0: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    // 0x802F9DF4: jal         0x8034C8F8
    // 0x802F9DF8: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    func_8034C8F8_75DFA8(rdram, ctx);
        goto after_3;
    // 0x802F9DF8: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    after_3:
    // 0x802F9DFC: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x802F9E00: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x802F9E04: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802F9E08: jr          $ra
    // 0x802F9E0C: nop

    return;
    // 0x802F9E0C: nop

;}
RECOMP_FUNC void func_802F9E10_70B4C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9E10: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802F9E14: andi        $t7, $a2, 0xFF
    ctx->r15 = ctx->r6 & 0XFF;
    // 0x802F9E18: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802F9E1C: sll         $t8, $a3, 24
    ctx->r24 = S32(ctx->r7 << 24);
    // 0x802F9E20: sra         $a3, $t8, 24
    ctx->r7 = S32(SIGNED(ctx->r24) >> 24);
    // 0x802F9E24: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x802F9E28: multu       $a2, $a3
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802F9E2C: andi        $t6, $a1, 0xFF
    ctx->r14 = ctx->r5 & 0XFF;
    // 0x802F9E30: sll         $t0, $t6, 2
    ctx->r8 = S32(ctx->r14 << 2);
    // 0x802F9E34: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802F9E38: addu        $v0, $v0, $t0
    ctx->r2 = ADD32(ctx->r2, ctx->r8);
    // 0x802F9E3C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802F9E40: lw          $v0, -0x71A0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X71A0);
    // 0x802F9E44: sb          $t6, 0x175($a0)
    MEM_B(0X175, ctx->r4) = ctx->r14;
    // 0x802F9E48: lb          $t6, 0x174($a0)
    ctx->r14 = MEM_B(ctx->r4, 0X174);
    // 0x802F9E4C: sll         $t5, $a3, 4
    ctx->r13 = S32(ctx->r7 << 4);
    // 0x802F9E50: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x802F9E54: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x802F9E58: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x802F9E5C: sb          $t8, 0x174($a0)
    MEM_B(0X174, ctx->r4) = ctx->r24;
    // 0x802F9E60: mflo        $t9
    ctx->r25 = lo;
    // 0x802F9E64: sb          $t1, 0x170($a0)
    MEM_B(0X170, ctx->r4) = ctx->r9;
    // 0x802F9E68: sh          $t9, 0x172($a0)
    MEM_H(0X172, ctx->r4) = ctx->r25;
    // 0x802F9E6C: lbu         $t2, 0x13($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X13);
    // 0x802F9E70: lb          $t4, 0x174($a0)
    ctx->r12 = MEM_B(ctx->r4, 0X174);
    // 0x802F9E74: andi        $t3, $t2, 0xF
    ctx->r11 = ctx->r10 & 0XF;
    // 0x802F9E78: andi        $t6, $t4, 0xFFF0
    ctx->r14 = ctx->r12 & 0XFFF0;
    // 0x802F9E7C: or          $t5, $t3, $t6
    ctx->r13 = ctx->r11 | ctx->r14;
    // 0x802F9E80: sb          $t5, 0x174($a0)
    MEM_B(0X174, ctx->r4) = ctx->r13;
    // 0x802F9E84: lbu         $t7, 0x17($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X17);
    // 0x802F9E88: bne         $t7, $zero, L_802F9EB0
    if (ctx->r15 != 0) {
        // 0x802F9E8C: nop
    
            goto L_802F9EB0;
    }
    // 0x802F9E8C: nop

    // 0x802F9E90: blezl       $a3, L_802F9EA4
    if (SIGNED(ctx->r7) <= 0) {
        // 0x802F9E94: lbu         $t8, 0x0($v0)
        ctx->r24 = MEM_BU(ctx->r2, 0X0);
            goto L_802F9EA4;
    }
    goto skip_0;
    // 0x802F9E94: lbu         $t8, 0x0($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X0);
    skip_0:
    // 0x802F9E98: jr          $ra
    // 0x802F9E9C: sh          $zero, 0x176($a0)
    MEM_H(0X176, ctx->r4) = 0;
    return;
    // 0x802F9E9C: sh          $zero, 0x176($a0)
    MEM_H(0X176, ctx->r4) = 0;
    // 0x802F9EA0: lbu         $t8, 0x0($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X0);
L_802F9EA4:
    // 0x802F9EA4: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x802F9EA8: addiu       $t0, $t9, 0x80
    ctx->r8 = ADD32(ctx->r25, 0X80);
    // 0x802F9EAC: sh          $t0, 0x176($a0)
    MEM_H(0X176, ctx->r4) = ctx->r8;
L_802F9EB0:
    // 0x802F9EB0: jr          $ra
    // 0x802F9EB4: nop

    return;
    // 0x802F9EB4: nop

;}
RECOMP_FUNC void func_802F9EB8_70B568(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802F9EB8: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802F9EBC: lbu         $t2, 0x77($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X77);
    // 0x802F9EC0: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x802F9EC4: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x802F9EC8: beql        $t2, $zero, L_802F9FB8
    if (ctx->r10 == 0) {
        // 0x802F9ECC: lh          $v0, 0x72($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X72);
            goto L_802F9FB8;
    }
    goto skip_0;
    // 0x802F9ECC: lh          $v0, 0x72($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X72);
    skip_0:
    // 0x802F9ED0: lh          $v0, 0x72($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X72);
    // 0x802F9ED4: bgez        $v0, L_802F9EE4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F9ED8: sra         $v1, $v0, 7
        ctx->r3 = S32(SIGNED(ctx->r2) >> 7);
            goto L_802F9EE4;
    }
    // 0x802F9ED8: sra         $v1, $v0, 7
    ctx->r3 = S32(SIGNED(ctx->r2) >> 7);
    // 0x802F9EDC: addiu       $at, $v0, 0x7F
    ctx->r1 = ADD32(ctx->r2, 0X7F);
    // 0x802F9EE0: sra         $v1, $at, 7
    ctx->r3 = S32(SIGNED(ctx->r1) >> 7);
L_802F9EE4:
    // 0x802F9EE4: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x802F9EE8: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802F9EEC: addiu       $t0, $v1, -0x1
    ctx->r8 = ADD32(ctx->r3, -0X1);
    // 0x802F9EF0: sll         $t3, $t0, 16
    ctx->r11 = S32(ctx->r8 << 16);
    // 0x802F9EF4: sra         $t8, $t3, 16
    ctx->r24 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802F9EF8: addiu       $a0, $t8, -0x1
    ctx->r4 = ADD32(ctx->r24, -0X1);
    // 0x802F9EFC: bgez        $a0, L_802F9F18
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802F9F00: or          $t0, $t8, $zero
        ctx->r8 = ctx->r24 | 0;
            goto L_802F9F18;
    }
    // 0x802F9F00: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
    // 0x802F9F04: lbu         $t5, 0x0($a3)
    ctx->r13 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9F08: addu        $t9, $t5, $t8
    ctx->r25 = ADD32(ctx->r13, ctx->r24);
    // 0x802F9F0C: addiu       $t7, $t9, -0x1
    ctx->r15 = ADD32(ctx->r25, -0X1);
    // 0x802F9F10: b           L_802F9F1C
    // 0x802F9F14: sh          $t7, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r15;
        goto L_802F9F1C;
    // 0x802F9F14: sh          $t7, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r15;
L_802F9F18:
    // 0x802F9F18: sh          $a0, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r4;
L_802F9F1C:
    // 0x802F9F1C: bgez        $t0, L_802F9F34
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802F9F20: addiu       $t1, $t0, 0x1
        ctx->r9 = ADD32(ctx->r8, 0X1);
            goto L_802F9F34;
    }
    // 0x802F9F20: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x802F9F24: lbu         $t2, 0x0($a3)
    ctx->r10 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9F28: addu        $t4, $t2, $t0
    ctx->r12 = ADD32(ctx->r10, ctx->r8);
    // 0x802F9F2C: b           L_802F9F50
    // 0x802F9F30: sh          $t4, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r12;
        goto L_802F9F50;
    // 0x802F9F30: sh          $t4, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r12;
L_802F9F34:
    // 0x802F9F34: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9F38: slt         $at, $t0, $a0
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F9F3C: bne         $at, $zero, L_802F9F4C
    if (ctx->r1 != 0) {
        // 0x802F9F40: subu        $t6, $t0, $a0
        ctx->r14 = SUB32(ctx->r8, ctx->r4);
            goto L_802F9F4C;
    }
    // 0x802F9F40: subu        $t6, $t0, $a0
    ctx->r14 = SUB32(ctx->r8, ctx->r4);
    // 0x802F9F44: b           L_802F9F50
    // 0x802F9F48: sh          $t6, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r14;
        goto L_802F9F50;
    // 0x802F9F48: sh          $t6, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r14;
L_802F9F4C:
    // 0x802F9F4C: sh          $t0, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r8;
L_802F9F50:
    // 0x802F9F50: bgezl       $t1, L_802F9F70
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802F9F54: lbu         $a0, 0x0($a3)
        ctx->r4 = MEM_BU(ctx->r7, 0X0);
            goto L_802F9F70;
    }
    goto skip_1;
    // 0x802F9F54: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    skip_1:
    // 0x802F9F58: lbu         $t3, 0x0($a3)
    ctx->r11 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9F5C: addu        $t8, $t3, $t0
    ctx->r24 = ADD32(ctx->r11, ctx->r8);
    // 0x802F9F60: addiu       $t5, $t8, 0x1
    ctx->r13 = ADD32(ctx->r24, 0X1);
    // 0x802F9F64: b           L_802F9F8C
    // 0x802F9F68: sh          $t5, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r13;
        goto L_802F9F8C;
    // 0x802F9F68: sh          $t5, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r13;
    // 0x802F9F6C: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
L_802F9F70:
    // 0x802F9F70: slt         $at, $t1, $a0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F9F74: bne         $at, $zero, L_802F9F88
    if (ctx->r1 != 0) {
        // 0x802F9F78: subu        $t9, $t0, $a0
        ctx->r25 = SUB32(ctx->r8, ctx->r4);
            goto L_802F9F88;
    }
    // 0x802F9F78: subu        $t9, $t0, $a0
    ctx->r25 = SUB32(ctx->r8, ctx->r4);
    // 0x802F9F7C: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x802F9F80: b           L_802F9F8C
    // 0x802F9F84: sh          $t7, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r15;
        goto L_802F9F8C;
    // 0x802F9F84: sh          $t7, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r15;
L_802F9F88:
    // 0x802F9F88: sh          $t1, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r9;
L_802F9F8C:
    // 0x802F9F8C: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9F90: addiu       $a1, $t0, 0x2
    ctx->r5 = ADD32(ctx->r8, 0X2);
    // 0x802F9F94: slt         $at, $a1, $a0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802F9F98: bne         $at, $zero, L_802F9FAC
    if (ctx->r1 != 0) {
        // 0x802F9F9C: subu        $t2, $t0, $a0
        ctx->r10 = SUB32(ctx->r8, ctx->r4);
            goto L_802F9FAC;
    }
    // 0x802F9F9C: subu        $t2, $t0, $a0
    ctx->r10 = SUB32(ctx->r8, ctx->r4);
    // 0x802F9FA0: addiu       $t4, $t2, 0x2
    ctx->r12 = ADD32(ctx->r10, 0X2);
    // 0x802F9FA4: b           L_802FA0A0
    // 0x802F9FA8: sh          $t4, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r12;
        goto L_802FA0A0;
    // 0x802F9FA8: sh          $t4, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r12;
L_802F9FAC:
    // 0x802F9FAC: b           L_802FA0A0
    // 0x802F9FB0: sh          $a1, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r5;
        goto L_802FA0A0;
    // 0x802F9FB0: sh          $a1, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r5;
    // 0x802F9FB4: lh          $v0, 0x72($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X72);
L_802F9FB8:
    // 0x802F9FB8: bgez        $v0, L_802F9FC8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802F9FBC: sra         $v1, $v0, 7
        ctx->r3 = S32(SIGNED(ctx->r2) >> 7);
            goto L_802F9FC8;
    }
    // 0x802F9FBC: sra         $v1, $v0, 7
    ctx->r3 = S32(SIGNED(ctx->r2) >> 7);
    // 0x802F9FC0: addiu       $at, $v0, 0x7F
    ctx->r1 = ADD32(ctx->r2, 0X7F);
    // 0x802F9FC4: sra         $v1, $at, 7
    ctx->r3 = S32(SIGNED(ctx->r1) >> 7);
L_802F9FC8:
    // 0x802F9FC8: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802F9FCC: sra         $v1, $t6, 16
    ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802F9FD0: addiu       $t0, $v1, -0x1
    ctx->r8 = ADD32(ctx->r3, -0X1);
    // 0x802F9FD4: sll         $t8, $t0, 16
    ctx->r24 = S32(ctx->r8 << 16);
    // 0x802F9FD8: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802F9FDC: addiu       $a0, $t0, -0x1
    ctx->r4 = ADD32(ctx->r8, -0X1);
    // 0x802F9FE0: bgez        $a0, L_802F9FF0
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802F9FE4: or          $a1, $t0, $zero
        ctx->r5 = ctx->r8 | 0;
            goto L_802F9FF0;
    }
    // 0x802F9FE4: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x802F9FE8: b           L_802F9FF4
    // 0x802F9FEC: sh          $zero, 0x58($sp)
    MEM_H(0X58, ctx->r29) = 0;
        goto L_802F9FF4;
    // 0x802F9FEC: sh          $zero, 0x58($sp)
    MEM_H(0X58, ctx->r29) = 0;
L_802F9FF0:
    // 0x802F9FF0: sh          $a0, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r4;
L_802F9FF4:
    // 0x802F9FF4: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    // 0x802F9FF8: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x802F9FFC: slt         $at, $a0, $t0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FA000: beq         $at, $zero, L_802FA010
    if (ctx->r1 == 0) {
        // 0x802FA004: nop
    
            goto L_802FA010;
    }
    // 0x802FA004: nop

    // 0x802FA008: b           L_802FA010
    // 0x802FA00C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_802FA010;
    // 0x802FA00C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_802FA010:
    // 0x802FA010: bgez        $a1, L_802FA020
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802FA014: slt         $at, $a0, $t0
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r8) ? 1 : 0;
            goto L_802FA020;
    }
    // 0x802FA014: slt         $at, $a0, $t0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FA018: b           L_802FA034
    // 0x802FA01C: sh          $zero, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = 0;
        goto L_802FA034;
    // 0x802FA01C: sh          $zero, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = 0;
L_802FA020:
    // 0x802FA020: beq         $at, $zero, L_802FA030
    if (ctx->r1 == 0) {
        // 0x802FA024: or          $a1, $t0, $zero
        ctx->r5 = ctx->r8 | 0;
            goto L_802FA030;
    }
    // 0x802FA024: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x802FA028: b           L_802FA030
    // 0x802FA02C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_802FA030;
    // 0x802FA02C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_802FA030:
    // 0x802FA030: sh          $a1, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r5;
L_802FA034:
    // 0x802FA034: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    // 0x802FA038: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x802FA03C: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x802FA040: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x802FA044: slt         $at, $a0, $t1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802FA048: beq         $at, $zero, L_802FA058
    if (ctx->r1 == 0) {
        // 0x802FA04C: nop
    
            goto L_802FA058;
    }
    // 0x802FA04C: nop

    // 0x802FA050: b           L_802FA058
    // 0x802FA054: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_802FA058;
    // 0x802FA054: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_802FA058:
    // 0x802FA058: bgez        $a1, L_802FA068
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802FA05C: slt         $at, $a0, $t1
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r9) ? 1 : 0;
            goto L_802FA068;
    }
    // 0x802FA05C: slt         $at, $a0, $t1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802FA060: b           L_802FA07C
    // 0x802FA064: sh          $zero, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = 0;
        goto L_802FA07C;
    // 0x802FA064: sh          $zero, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = 0;
L_802FA068:
    // 0x802FA068: beq         $at, $zero, L_802FA078
    if (ctx->r1 == 0) {
        // 0x802FA06C: or          $a1, $t1, $zero
        ctx->r5 = ctx->r9 | 0;
            goto L_802FA078;
    }
    // 0x802FA06C: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x802FA070: b           L_802FA078
    // 0x802FA074: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
        goto L_802FA078;
    // 0x802FA074: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
L_802FA078:
    // 0x802FA078: sh          $a1, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r5;
L_802FA07C:
    // 0x802FA07C: lbu         $a0, 0x0($a3)
    ctx->r4 = MEM_BU(ctx->r7, 0X0);
    // 0x802FA080: addiu       $a1, $t0, 0x2
    ctx->r5 = ADD32(ctx->r8, 0X2);
    // 0x802FA084: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x802FA088: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FA08C: beql        $at, $zero, L_802FA0A0
    if (ctx->r1 == 0) {
        // 0x802FA090: sh          $a1, 0x5E($sp)
        MEM_H(0X5E, ctx->r29) = ctx->r5;
            goto L_802FA0A0;
    }
    goto skip_2;
    // 0x802FA090: sh          $a1, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r5;
    skip_2:
    // 0x802FA094: b           L_802FA0A0
    // 0x802FA098: sh          $a0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r4;
        goto L_802FA0A0;
    // 0x802FA098: sh          $a0, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r4;
    // 0x802FA09C: sh          $a1, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r5;
L_802FA0A0:
    // 0x802FA0A0: sll         $t9, $v1, 7
    ctx->r25 = S32(ctx->r3 << 7);
    // 0x802FA0A4: subu        $t7, $v0, $t9
    ctx->r15 = SUB32(ctx->r2, ctx->r25);
    // 0x802FA0A8: sll         $t2, $t7, 16
    ctx->r10 = S32(ctx->r15 << 16);
    // 0x802FA0AC: sra         $t4, $t2, 16
    ctx->r12 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802FA0B0: mtc1        $t4, $f10
    ctx->f10.u32l = ctx->r12;
    // 0x802FA0B4: lui         $at, 0x4018
    ctx->r1 = S32(0X4018 << 16);
    // 0x802FA0B8: mtc1        $at, $f3
    ctx->f_odd[(3 - 1) * 2] = ctx->r1;
    // 0x802FA0BC: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FA0C0: lui         $at, 0x4300
    ctx->r1 = S32(0X4300 << 16);
    // 0x802FA0C4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FA0C8: mtc1        $zero, $f2
    ctx->f2.u32l = 0;
    // 0x802FA0CC: lui         $at, 0x4008
    ctx->r1 = S32(0X4008 << 16);
    // 0x802FA0D0: mtc1        $at, $f11
    ctx->f_odd[(11 - 1) * 2] = ctx->r1;
    // 0x802FA0D4: div.s       $f18, $f8, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f18.fl = DIV_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802FA0D8: lh          $t6, 0x58($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X58);
    // 0x802FA0DC: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x802FA0E0: lui         $a1, 0x20
    ctx->r5 = S32(0X20 << 16);
    // 0x802FA0E4: multu       $t6, $a0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA0E8: lh          $t9, 0x5A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X5A);
    // 0x802FA0EC: mflo        $t3
    ctx->r11 = lo;
    // 0x802FA0F0: addu        $t8, $a3, $t3
    ctx->r24 = ADD32(ctx->r7, ctx->r11);
    // 0x802FA0F4: mul.s       $f6, $f18, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f18.fl);
    // 0x802FA0F8: swc1        $f6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f6.u32l;
    // 0x802FA0FC: lwc1        $f10, 0x24($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X24);
    // 0x802FA100: mul.s       $f8, $f18, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = MUL_S(ctx->f18.fl, ctx->f10.fl);
    // 0x802FA104: cvt.d.s     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f12.d = CVT_D_S(ctx->f10.fl);
    // 0x802FA108: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802FA10C: swc1        $f8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f8.u32l;
    // 0x802FA110: lwc1        $f4, 0x20($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X20);
    // 0x802FA114: cvt.d.s     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f0.d = CVT_D_S(ctx->f4.fl);
    // 0x802FA118: div.d       $f6, $f0, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = DIV_D(ctx->f0.d, ctx->f2.d);
    // 0x802FA11C: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x802FA120: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802FA124: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802FA128: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x802FA12C: swc1        $f8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f8.u32l;
    // 0x802FA130: mul.d       $f14, $f6, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f12.d); 
    ctx->f14.d = MUL_D(ctx->f6.d, ctx->f12.d);
    // 0x802FA134: cvt.d.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.d = CVT_D_S(ctx->f18.fl);
    // 0x802FA138: mul.d       $f16, $f10, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f6.d);
    // 0x802FA13C: neg.s       $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = -ctx->f4.fl;
    // 0x802FA140: cvt.d.s     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f6.d = CVT_D_S(ctx->f10.fl);
    // 0x802FA144: add.d       $f4, $f6, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f14.d); 
    ctx->f4.d = ctx->f6.d + ctx->f14.d;
    // 0x802FA148: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802FA14C: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802FA150: lui         $at, 0x4008
    ctx->r1 = S32(0X4008 << 16);
    // 0x802FA154: sub.d       $f10, $f4, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f16.d); 
    ctx->f10.d = ctx->f4.d - ctx->f16.d;
    // 0x802FA158: add.d       $f4, $f10, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = ctx->f10.d + ctx->f6.d;
    // 0x802FA15C: div.d       $f10, $f4, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f2.d); 
    ctx->f10.d = DIV_D(ctx->f4.d, ctx->f2.d);
    // 0x802FA160: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802FA164: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x802FA168: lui         $at, 0x4010
    ctx->r1 = S32(0X4010 << 16);
    // 0x802FA16C: cvt.s.d     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f6.fl = CVT_S_D(ctx->f10.d);
    // 0x802FA170: mul.d       $f10, $f0, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f4.d); 
    ctx->f10.d = MUL_D(ctx->f0.d, ctx->f4.d);
    // 0x802FA174: swc1        $f6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->f6.u32l;
    // 0x802FA178: mul.d       $f6, $f2, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f2.d); NAN_CHECK(ctx->f12.d); 
    ctx->f6.d = MUL_D(ctx->f2.d, ctx->f12.d);
    // 0x802FA17C: sub.d       $f4, $f10, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = ctx->f10.d - ctx->f6.d;
    // 0x802FA180: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802FA184: mtc1        $at, $f11
    ctx->f_odd[(11 - 1) * 2] = ctx->r1;
    // 0x802FA188: lui         $at, 0xC008
    ctx->r1 = S32(0XC008 << 16);
    // 0x802FA18C: add.d       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f10.d); 
    ctx->f6.d = ctx->f4.d + ctx->f10.d;
    // 0x802FA190: div.d       $f4, $f6, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f2.d); 
    ctx->f4.d = DIV_D(ctx->f6.d, ctx->f2.d);
    // 0x802FA194: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802FA198: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802FA19C: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x802FA1A0: cvt.s.d     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f10.fl = CVT_S_D(ctx->f4.d);
    // 0x802FA1A4: mul.d       $f4, $f0, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f6.d);
    // 0x802FA1A8: swc1        $f10, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f10.u32l;
    // 0x802FA1AC: add.d       $f6, $f4, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f14.d); 
    ctx->f6.d = ctx->f4.d + ctx->f14.d;
    // 0x802FA1B0: add.d       $f4, $f6, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f16.d); 
    ctx->f4.d = ctx->f6.d + ctx->f16.d;
    // 0x802FA1B4: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802FA1B8: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802FA1BC: nop

    // 0x802FA1C0: add.d       $f4, $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = ctx->f4.d + ctx->f6.d;
    // 0x802FA1C4: div.d       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f2.d); 
    ctx->f6.d = DIV_D(ctx->f4.d, ctx->f2.d);
    // 0x802FA1C8: cvt.s.d     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f4.fl = CVT_S_D(ctx->f6.d);
    // 0x802FA1CC: lwc1        $f6, 0x28($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X28);
    // 0x802FA1D0: swc1        $f4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f4.u32l;
    // 0x802FA1D4: lbu         $t5, 0x1($t8)
    ctx->r13 = MEM_BU(ctx->r24, 0X1);
    // 0x802FA1D8: swc1        $f8, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f8.u32l;
    // 0x802FA1DC: swc1        $f10, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f10.u32l;
    // 0x802FA1E0: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x802FA1E4: bgez        $t5, L_802FA1FC
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FA1E8: cvt.s.w     $f8, $f8
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FA1FC;
    }
    // 0x802FA1E8: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FA1EC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA1F0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FA1F4: nop

    // 0x802FA1F8: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_802FA1FC:
    // 0x802FA1FC: multu       $t9, $a0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA200: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FA204: lwc1        $f8, 0x4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4);
    // 0x802FA208: lh          $t3, 0x5C($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X5C);
    // 0x802FA20C: mflo        $t7
    ctx->r15 = lo;
    // 0x802FA210: addu        $t2, $a3, $t7
    ctx->r10 = ADD32(ctx->r7, ctx->r15);
    // 0x802FA214: lbu         $t4, 0x1($t2)
    ctx->r12 = MEM_BU(ctx->r10, 0X1);
    // 0x802FA218: swc1        $f4, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f4.u32l;
    // 0x802FA21C: swc1        $f6, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->f6.u32l;
    // 0x802FA220: mtc1        $t4, $f4
    ctx->f4.u32l = ctx->r12;
    // 0x802FA224: bgez        $t4, L_802FA23C
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FA228: cvt.s.w     $f4, $f4
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FA23C;
    }
    // 0x802FA228: cvt.s.w     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FA22C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA230: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FA234: nop

    // 0x802FA238: add.s       $f4, $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f6.fl;
L_802FA23C:
    // 0x802FA23C: multu       $t3, $a0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA240: mul.s       $f6, $f8, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802FA244: lh          $t2, 0x5E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X5E);
    // 0x802FA248: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA24C: add.s       $f4, $f10, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802FA250: lwc1        $f10, 0x4($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X4);
    // 0x802FA254: mflo        $t8
    ctx->r24 = lo;
    // 0x802FA258: addu        $t5, $a3, $t8
    ctx->r13 = ADD32(ctx->r7, ctx->r24);
    // 0x802FA25C: lbu         $t7, 0x1($t5)
    ctx->r15 = MEM_BU(ctx->r13, 0X1);
    // 0x802FA260: swc1        $f8, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f8.u32l;
    // 0x802FA264: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802FA268: bgez        $t7, L_802FA27C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FA26C: cvt.s.w     $f6, $f6
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FA27C;
    }
    // 0x802FA26C: cvt.s.w     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FA270: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FA274: nop

    // 0x802FA278: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802FA27C:
    // 0x802FA27C: multu       $t2, $a0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA280: mul.s       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f6.fl);
    // 0x802FA284: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA288: add.s       $f6, $f4, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x802FA28C: mflo        $t4
    ctx->r12 = lo;
    // 0x802FA290: addu        $t8, $t4, $a3
    ctx->r24 = ADD32(ctx->r12, ctx->r7);
    // 0x802FA294: lbu         $t5, 0x1($t8)
    ctx->r13 = MEM_BU(ctx->r24, 0X1);
    // 0x802FA298: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802FA29C: bgez        $t5, L_802FA2B0
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FA2A0: cvt.s.w     $f8, $f4
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FA2B0;
    }
    // 0x802FA2A0: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FA2A4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FA2A8: nop

    // 0x802FA2AC: add.s       $f8, $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f4.fl;
L_802FA2B0:
    // 0x802FA2B0: lwc1        $f4, 0x0($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X0);
    // 0x802FA2B4: lui         $at, 0x4A80
    ctx->r1 = S32(0X4A80 << 16);
    // 0x802FA2B8: multu       $t6, $a0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA2BC: mul.s       $f8, $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802FA2C0: lw          $t5, 0x60($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X60);
    // 0x802FA2C4: add.s       $f8, $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f6.fl;
    // 0x802FA2C8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FA2CC: mflo        $t7
    ctx->r15 = lo;
    // 0x802FA2D0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA2D4: mul.s       $f8, $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x802FA2D8: trunc.w.s   $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802FA2DC: mfc1        $t4, $f6
    ctx->r12 = (int32_t)ctx->f6.u32l;
    // 0x802FA2E0: nop

    // 0x802FA2E4: addu        $t8, $t4, $a1
    ctx->r24 = ADD32(ctx->r12, ctx->r5);
    // 0x802FA2E8: addu        $t4, $a3, $t7
    ctx->r12 = ADD32(ctx->r7, ctx->r15);
    // 0x802FA2EC: sw          $t8, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r24;
    // 0x802FA2F0: lbu         $t8, 0x2($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X2);
    // 0x802FA2F4: lwc1        $f8, 0x8($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X8);
    // 0x802FA2F8: swc1        $f10, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->f10.u32l;
    // 0x802FA2FC: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x802FA300: bgez        $t8, L_802FA314
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FA304: cvt.s.w     $f6, $f6
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FA314;
    }
    // 0x802FA304: cvt.s.w     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FA308: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FA30C: nop

    // 0x802FA310: add.s       $f6, $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f10.fl;
L_802FA314:
    // 0x802FA314: multu       $t9, $a0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA318: mul.s       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x802FA31C: lwc1        $f6, 0x4($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X4);
    // 0x802FA320: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA324: mflo        $t5
    ctx->r13 = lo;
    // 0x802FA328: addu        $t7, $a3, $t5
    ctx->r15 = ADD32(ctx->r7, ctx->r13);
    // 0x802FA32C: lbu         $t4, 0x2($t7)
    ctx->r12 = MEM_BU(ctx->r15, 0X2);
    // 0x802FA330: swc1        $f4, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f4.u32l;
    // 0x802FA334: swc1        $f8, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f8.u32l;
    // 0x802FA338: mtc1        $t4, $f4
    ctx->f4.u32l = ctx->r12;
    // 0x802FA33C: bgez        $t4, L_802FA350
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FA340: cvt.s.w     $f4, $f4
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FA350;
    }
    // 0x802FA340: cvt.s.w     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FA344: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FA348: nop

    // 0x802FA34C: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_802FA350:
    // 0x802FA350: multu       $t3, $a0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA354: mul.s       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FA358: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA35C: add.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802FA360: lwc1        $f10, 0x8($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X8);
    // 0x802FA364: mflo        $t8
    ctx->r24 = lo;
    // 0x802FA368: addu        $t5, $a3, $t8
    ctx->r13 = ADD32(ctx->r7, ctx->r24);
    // 0x802FA36C: lbu         $t7, 0x2($t5)
    ctx->r15 = MEM_BU(ctx->r13, 0X2);
    // 0x802FA370: swc1        $f6, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->f6.u32l;
    // 0x802FA374: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x802FA378: bgez        $t7, L_802FA38C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FA37C: cvt.s.w     $f8, $f8
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FA38C;
    }
    // 0x802FA37C: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FA380: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FA384: nop

    // 0x802FA388: add.s       $f8, $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f6.fl;
L_802FA38C:
    // 0x802FA38C: multu       $t2, $a0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA390: mul.s       $f6, $f10, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f8.fl);
    // 0x802FA394: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA398: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x802FA39C: mflo        $t4
    ctx->r12 = lo;
    // 0x802FA3A0: addu        $t8, $t4, $a3
    ctx->r24 = ADD32(ctx->r12, ctx->r7);
    // 0x802FA3A4: lbu         $t5, 0x2($t8)
    ctx->r13 = MEM_BU(ctx->r24, 0X2);
    // 0x802FA3A8: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802FA3AC: bgez        $t5, L_802FA3C0
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FA3B0: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FA3C0;
    }
    // 0x802FA3B0: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FA3B4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FA3B8: nop

    // 0x802FA3BC: add.s       $f6, $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f4.fl;
L_802FA3C0:
    // 0x802FA3C0: lwc1        $f4, 0x4($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X4);
    // 0x802FA3C4: lui         $at, 0x4A80
    ctx->r1 = S32(0X4A80 << 16);
    // 0x802FA3C8: multu       $t6, $a0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA3CC: mul.s       $f6, $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FA3D0: lw          $t5, 0x64($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X64);
    // 0x802FA3D4: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x802FA3D8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FA3DC: mflo        $t7
    ctx->r15 = lo;
    // 0x802FA3E0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA3E4: mul.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FA3E8: trunc.w.s   $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802FA3EC: mfc1        $t4, $f8
    ctx->r12 = (int32_t)ctx->f8.u32l;
    // 0x802FA3F0: nop

    // 0x802FA3F4: addu        $t8, $t4, $a1
    ctx->r24 = ADD32(ctx->r12, ctx->r5);
    // 0x802FA3F8: addu        $t4, $a3, $t7
    ctx->r12 = ADD32(ctx->r7, ctx->r15);
    // 0x802FA3FC: sw          $t8, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r24;
    // 0x802FA400: lbu         $t8, 0x3($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X3);
    // 0x802FA404: swc1        $f10, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->f10.u32l;
    // 0x802FA408: lwc1        $f6, 0x0($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X0);
    // 0x802FA40C: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802FA410: bgez        $t8, L_802FA424
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FA414: cvt.s.w     $f8, $f8
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FA424;
    }
    // 0x802FA414: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FA418: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FA41C: nop

    // 0x802FA420: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_802FA424:
    // 0x802FA424: multu       $t9, $a0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA428: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FA42C: lwc1        $f6, 0x8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X8);
    // 0x802FA430: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA434: mflo        $t5
    ctx->r13 = lo;
    // 0x802FA438: addu        $t6, $a3, $t5
    ctx->r14 = ADD32(ctx->r7, ctx->r13);
    // 0x802FA43C: lbu         $t7, 0x3($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X3);
    // 0x802FA440: swc1        $f4, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->f4.u32l;
    // 0x802FA444: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x802FA448: bgez        $t7, L_802FA45C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FA44C: cvt.s.w     $f8, $f8
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FA45C;
    }
    // 0x802FA44C: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FA450: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FA454: nop

    // 0x802FA458: add.s       $f8, $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f4.fl;
L_802FA45C:
    // 0x802FA45C: multu       $t3, $a0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA460: mul.s       $f4, $f6, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FA464: lwc1        $f8, 0x4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X4);
    // 0x802FA468: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA46C: add.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f10.fl + ctx->f4.fl;
    // 0x802FA470: mflo        $t4
    ctx->r12 = lo;
    // 0x802FA474: addu        $t8, $a3, $t4
    ctx->r24 = ADD32(ctx->r7, ctx->r12);
    // 0x802FA478: lbu         $t9, 0x3($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X3);
    // 0x802FA47C: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x802FA480: bgez        $t9, L_802FA494
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FA484: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FA494;
    }
    // 0x802FA484: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FA488: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FA48C: nop

    // 0x802FA490: add.s       $f4, $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f10.fl;
L_802FA494:
    // 0x802FA494: multu       $t2, $a0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FA498: mul.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f4.fl);
    // 0x802FA49C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FA4A0: add.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x802FA4A4: mflo        $t5
    ctx->r13 = lo;
    // 0x802FA4A8: addu        $t6, $t5, $a3
    ctx->r14 = ADD32(ctx->r13, ctx->r7);
    // 0x802FA4AC: lbu         $t7, 0x3($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X3);
    // 0x802FA4B0: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802FA4B4: nop

    // 0x802FA4B8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FA4BC: bgez        $t7, L_802FA4D0
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FA4C0: lwc1        $f4, 0x8($sp)
        ctx->f4.u32l = MEM_W(ctx->r29, 0X8);
            goto L_802FA4D0;
    }
    // 0x802FA4C0: lwc1        $f4, 0x8($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X8);
    // 0x802FA4C4: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FA4C8: nop

    // 0x802FA4CC: add.s       $f6, $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f10.fl;
L_802FA4D0:
    // 0x802FA4D0: mul.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FA4D4: lui         $at, 0x4A80
    ctx->r1 = S32(0X4A80 << 16);
    // 0x802FA4D8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FA4DC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FA4E0: add.s       $f6, $f10, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802FA4E4: mul.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FA4E8: trunc.w.s   $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x802FA4EC: mfc1        $t4, $f8
    ctx->r12 = (int32_t)ctx->f8.u32l;
    // 0x802FA4F0: jr          $ra
    // 0x802FA4F4: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    return;
    // 0x802FA4F4: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
;}
RECOMP_FUNC void func_802FA4F8_70BBA8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FA4F8: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802FA4FC: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802FA500: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x802FA504: lbu         $t6, 0x175($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X175);
    // 0x802FA508: lw          $v0, 0x174($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X174);
    // 0x802FA50C: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x802FA510: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FA514: sll         $t8, $v0, 4
    ctx->r24 = S32(ctx->r2 << 4);
    // 0x802FA518: addu        $a3, $a3, $t7
    ctx->r7 = ADD32(ctx->r7, ctx->r15);
    // 0x802FA51C: sra         $t9, $t8, 28
    ctx->r25 = S32(SIGNED(ctx->r24) >> 28);
    // 0x802FA520: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FA524: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FA528: bne         $t9, $at, L_802FA608
    if (ctx->r25 != ctx->r1) {
        // 0x802FA52C: lw          $a3, -0x71A0($a3)
        ctx->r7 = MEM_W(ctx->r7, -0X71A0);
            goto L_802FA608;
    }
    // 0x802FA52C: lw          $a3, -0x71A0($a3)
    ctx->r7 = MEM_W(ctx->r7, -0X71A0);
    // 0x802FA530: sra         $t0, $v0, 28
    ctx->r8 = S32(SIGNED(ctx->r2) >> 28);
    // 0x802FA534: blez        $t0, L_802FA560
    if (SIGNED(ctx->r8) <= 0) {
        // 0x802FA538: addiu       $a1, $sp, 0x40
        ctx->r5 = ADD32(ctx->r29, 0X40);
            goto L_802FA560;
    }
    // 0x802FA538: addiu       $a1, $sp, 0x40
    ctx->r5 = ADD32(ctx->r29, 0X40);
    // 0x802FA53C: lbu         $t1, 0x0($a3)
    ctx->r9 = MEM_BU(ctx->r7, 0X0);
    // 0x802FA540: lh          $v0, 0x176($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X176);
    // 0x802FA544: sll         $t2, $t1, 7
    ctx->r10 = S32(ctx->r9 << 7);
    // 0x802FA548: addiu       $t3, $t2, 0x80
    ctx->r11 = ADD32(ctx->r10, 0X80);
    // 0x802FA54C: slt         $v1, $v0, $t3
    ctx->r3 = SIGNED(ctx->r2) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802FA550: xori        $v1, $v1, 0x1
    ctx->r3 = ctx->r3 ^ 0X1;
    // 0x802FA554: andi        $t4, $v1, 0xFF
    ctx->r12 = ctx->r3 & 0XFF;
    // 0x802FA558: b           L_802FA570
    // 0x802FA55C: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
        goto L_802FA570;
    // 0x802FA55C: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
L_802FA560:
    // 0x802FA560: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    // 0x802FA564: slti        $v1, $v0, 0x1
    ctx->r3 = SIGNED(ctx->r2) < 0X1 ? 1 : 0;
    // 0x802FA568: andi        $t5, $v1, 0xFF
    ctx->r13 = ctx->r3 & 0XFF;
    // 0x802FA56C: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
L_802FA570:
    // 0x802FA570: beq         $v1, $zero, L_802FA598
    if (ctx->r3 == 0) {
        // 0x802FA574: addiu       $a0, $sp, 0x44
        ctx->r4 = ADD32(ctx->r29, 0X44);
            goto L_802FA598;
    }
    // 0x802FA574: addiu       $a0, $sp, 0x44
    ctx->r4 = ADD32(ctx->r29, 0X44);
    // 0x802FA578: lw          $t6, 0x4C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4C);
    // 0x802FA57C: sb          $zero, 0x170($s0)
    MEM_B(0X170, ctx->r16) = 0;
    // 0x802FA580: sw          $zero, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = 0;
    // 0x802FA584: sll         $t8, $t6, 29
    ctx->r24 = S32(ctx->r14 << 29);
    // 0x802FA588: bltz        $t8, L_802FA6C4
    if (SIGNED(ctx->r24) < 0) {
        // 0x802FA58C: sw          $zero, 0x20($s0)
        MEM_W(0X20, ctx->r16) = 0;
            goto L_802FA6C4;
    }
    // 0x802FA58C: sw          $zero, 0x20($s0)
    MEM_W(0X20, ctx->r16) = 0;
    // 0x802FA590: b           L_802FA6C4
    // 0x802FA594: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
        goto L_802FA6C4;
    // 0x802FA594: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
L_802FA598:
    // 0x802FA598: lh          $t9, 0x172($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X172);
    // 0x802FA59C: addiu       $a2, $sp, 0x3C
    ctx->r6 = ADD32(ctx->r29, 0X3C);
    // 0x802FA5A0: addu        $t0, $v0, $t9
    ctx->r8 = ADD32(ctx->r2, ctx->r25);
    // 0x802FA5A4: sh          $t0, 0x176($s0)
    MEM_H(0X176, ctx->r16) = ctx->r8;
    // 0x802FA5A8: lw          $t1, 0x174($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X174);
    // 0x802FA5AC: sra         $t2, $t1, 28
    ctx->r10 = S32(SIGNED(ctx->r9) >> 28);
    // 0x802FA5B0: blezl       $t2, L_802FA5E4
    if (SIGNED(ctx->r10) <= 0) {
        // 0x802FA5B4: lh          $v0, 0x176($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X176);
            goto L_802FA5E4;
    }
    goto skip_0;
    // 0x802FA5B4: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    skip_0:
    // 0x802FA5B8: lbu         $v1, 0x0($a3)
    ctx->r3 = MEM_BU(ctx->r7, 0X0);
    // 0x802FA5BC: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    // 0x802FA5C0: sll         $t3, $v1, 7
    ctx->r11 = S32(ctx->r3 << 7);
    // 0x802FA5C4: addiu       $v1, $t3, 0x80
    ctx->r3 = ADD32(ctx->r11, 0X80);
    // 0x802FA5C8: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802FA5CC: bnel        $at, $zero, L_802FA5F8
    if (ctx->r1 != 0) {
        // 0x802FA5D0: sw          $v0, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->r2;
            goto L_802FA5F8;
    }
    goto skip_1;
    // 0x802FA5D0: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    skip_1:
    // 0x802FA5D4: sh          $v1, 0x176($s0)
    MEM_H(0X176, ctx->r16) = ctx->r3;
    // 0x802FA5D8: b           L_802FA5F4
    // 0x802FA5DC: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
        goto L_802FA5F4;
    // 0x802FA5DC: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    // 0x802FA5E0: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
L_802FA5E4:
    // 0x802FA5E4: bgtzl       $v0, L_802FA5F8
    if (SIGNED(ctx->r2) > 0) {
        // 0x802FA5E8: sw          $v0, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->r2;
            goto L_802FA5F8;
    }
    goto skip_2;
    // 0x802FA5E8: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    skip_2:
    // 0x802FA5EC: sh          $zero, 0x176($s0)
    MEM_H(0X176, ctx->r16) = 0;
    // 0x802FA5F0: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
L_802FA5F4:
    // 0x802FA5F4: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
L_802FA5F8:
    // 0x802FA5F8: jal         0x802F9EB8
    // 0x802FA5FC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802F9EB8_70B568(rdram, ctx);
        goto after_0;
    // 0x802FA5FC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FA600: b           L_802FA678
    // 0x802FA604: lw          $t3, 0x16C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X16C);
        goto L_802FA678;
    // 0x802FA604: lw          $t3, 0x16C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X16C);
L_802FA608:
    // 0x802FA608: lh          $t4, 0x176($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X176);
    // 0x802FA60C: lh          $t5, 0x172($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X172);
    // 0x802FA610: addiu       $a0, $sp, 0x44
    ctx->r4 = ADD32(ctx->r29, 0X44);
    // 0x802FA614: addiu       $a1, $sp, 0x40
    ctx->r5 = ADD32(ctx->r29, 0X40);
    // 0x802FA618: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802FA61C: sh          $t6, 0x176($s0)
    MEM_H(0X176, ctx->r16) = ctx->r14;
    // 0x802FA620: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    // 0x802FA624: addiu       $a2, $sp, 0x3C
    ctx->r6 = ADD32(ctx->r29, 0X3C);
    // 0x802FA628: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FA62C: bgezl       $v0, L_802FA650
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FA630: lbu         $v1, 0x0($a3)
        ctx->r3 = MEM_BU(ctx->r7, 0X0);
            goto L_802FA650;
    }
    goto skip_3;
    // 0x802FA630: lbu         $v1, 0x0($a3)
    ctx->r3 = MEM_BU(ctx->r7, 0X0);
    skip_3:
    // 0x802FA634: lbu         $t7, 0x0($a3)
    ctx->r15 = MEM_BU(ctx->r7, 0X0);
    // 0x802FA638: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802FA63C: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x802FA640: sh          $t9, 0x176($s0)
    MEM_H(0X176, ctx->r16) = ctx->r25;
    // 0x802FA644: b           L_802FA668
    // 0x802FA648: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
        goto L_802FA668;
    // 0x802FA648: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
    // 0x802FA64C: lbu         $v1, 0x0($a3)
    ctx->r3 = MEM_BU(ctx->r7, 0X0);
L_802FA650:
    // 0x802FA650: sll         $t0, $v1, 7
    ctx->r8 = S32(ctx->r3 << 7);
    // 0x802FA654: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FA658: bne         $at, $zero, L_802FA668
    if (ctx->r1 != 0) {
        // 0x802FA65C: subu        $t1, $v0, $t0
        ctx->r9 = SUB32(ctx->r2, ctx->r8);
            goto L_802FA668;
    }
    // 0x802FA65C: subu        $t1, $v0, $t0
    ctx->r9 = SUB32(ctx->r2, ctx->r8);
    // 0x802FA660: sh          $t1, 0x176($s0)
    MEM_H(0X176, ctx->r16) = ctx->r9;
    // 0x802FA664: lh          $v0, 0x176($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X176);
L_802FA668:
    // 0x802FA668: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FA66C: jal         0x802F9EB8
    // 0x802FA670: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    func_802F9EB8_70B568(rdram, ctx);
        goto after_1;
    // 0x802FA670: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_1:
    // 0x802FA674: lw          $t3, 0x16C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X16C);
L_802FA678:
    // 0x802FA678: lh          $t5, 0x82($t3)
    ctx->r13 = MEM_H(ctx->r11, 0X82);
    // 0x802FA67C: bgezl       $t5, L_802FA68C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FA680: lw          $t6, 0x44($sp)
        ctx->r14 = MEM_W(ctx->r29, 0X44);
            goto L_802FA68C;
    }
    goto skip_4;
    // 0x802FA680: lw          $t6, 0x44($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X44);
    skip_4:
    // 0x802FA684: sw          $zero, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = 0;
    // 0x802FA688: lw          $t6, 0x44($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X44);
L_802FA68C:
    // 0x802FA68C: lw          $t7, 0x4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X4);
    // 0x802FA690: lw          $t0, 0x8($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X8);
    // 0x802FA694: lw          $t2, 0x4C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4C);
    // 0x802FA698: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802FA69C: sw          $t8, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r24;
    // 0x802FA6A0: lw          $t9, 0x40($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X40);
    // 0x802FA6A4: sll         $t4, $t2, 29
    ctx->r12 = S32(ctx->r10 << 29);
    // 0x802FA6A8: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x802FA6AC: bltz        $t4, L_802FA6C4
    if (SIGNED(ctx->r12) < 0) {
        // 0x802FA6B0: sw          $t1, 0x20($s0)
        MEM_W(0X20, ctx->r16) = ctx->r9;
            goto L_802FA6C4;
    }
    // 0x802FA6B0: sw          $t1, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r9;
    // 0x802FA6B4: lw          $t5, 0x3C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X3C);
    // 0x802FA6B8: lw          $t6, 0xC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0XC);
    // 0x802FA6BC: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x802FA6C0: sw          $t7, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r15;
L_802FA6C4:
    // 0x802FA6C4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x802FA6C8: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x802FA6CC: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x802FA6D0: jr          $ra
    // 0x802FA6D4: nop

    return;
    // 0x802FA6D4: nop

;}
RECOMP_FUNC void func_802FA6D8_70BD88(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FA6D8: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x802FA6DC: lw          $t6, 0x4278($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4278);
    // 0x802FA6E0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802FA6E4: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802FA6E8: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x802FA6EC: sh          $zero, -0x4CF8($at)
    MEM_H(-0X4CF8, ctx->r1) = 0;
    // 0x802FA6F0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802FA6F4: addiu       $v0, $v0, 0x5760
    ctx->r2 = ADD32(ctx->r2, 0X5760);
    // 0x802FA6F8: sh          $zero, -0x6840($at)
    MEM_H(-0X6840, ctx->r1) = 0;
    // 0x802FA6FC: lhu         $t7, 0x0($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X0);
    // 0x802FA700: lui         $v1, 0x803A
    ctx->r3 = S32(0X803A << 16);
    // 0x802FA704: addiu       $v1, $v1, 0x52D0
    ctx->r3 = ADD32(ctx->r3, 0X52D0);
    // 0x802FA708: lbu         $t1, 0x0($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X0);
    // 0x802FA70C: addiu       $t9, $t7, 0x4
    ctx->r25 = ADD32(ctx->r15, 0X4);
    // 0x802FA710: sh          $t9, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r25;
    // 0x802FA714: andi        $t0, $t9, 0xFF
    ctx->r8 = ctx->r25 & 0XFF;
    // 0x802FA718: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x802FA71C: sh          $t0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r8;
    // 0x802FA720: sb          $t2, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r10;
    // 0x802FA724: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FA728: jr          $ra
    // 0x802FA72C: sw          $zero, 0x1BE0($at)
    MEM_W(0X1BE0, ctx->r1) = 0;
    return;
    // 0x802FA72C: sw          $zero, 0x1BE0($at)
    MEM_W(0X1BE0, ctx->r1) = 0;
;}
RECOMP_FUNC void func_802FA730_70BDE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FA730: addiu       $sp, $sp, -0xC0
    ctx->r29 = ADD32(ctx->r29, -0XC0);
    // 0x802FA734: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802FA738: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x802FA73C: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x802FA740: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x802FA744: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x802FA748: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x802FA74C: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x802FA750: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802FA754: lhu         $t6, 0x21E($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X21E);
    // 0x802FA758: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FA75C: andi        $t7, $t6, 0x10
    ctx->r15 = ctx->r14 & 0X10;
    // 0x802FA760: beql        $t7, $zero, L_802FA788
    if (ctx->r15 == 0) {
        // 0x802FA764: lhu         $a0, 0x21E($s0)
        ctx->r4 = MEM_HU(ctx->r16, 0X21E);
            goto L_802FA788;
    }
    goto skip_0;
    // 0x802FA764: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
    skip_0:
    // 0x802FA768: lhu         $t8, 0x224($a0)
    ctx->r24 = MEM_HU(ctx->r4, 0X224);
    // 0x802FA76C: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x802FA770: andi        $t3, $t9, 0xFFFF
    ctx->r11 = ctx->r25 & 0XFFFF;
    // 0x802FA774: bne         $t3, $zero, L_802FA784
    if (ctx->r11 != 0) {
        // 0x802FA778: sh          $t9, 0x224($a0)
        MEM_H(0X224, ctx->r4) = ctx->r25;
            goto L_802FA784;
    }
    // 0x802FA778: sh          $t9, 0x224($a0)
    MEM_H(0X224, ctx->r4) = ctx->r25;
    // 0x802FA77C: b           L_802FAD94
    // 0x802FA780: sh          $zero, 0x21E($a0)
    MEM_H(0X21E, ctx->r4) = 0;
        goto L_802FAD94;
    // 0x802FA780: sh          $zero, 0x21E($a0)
    MEM_H(0X21E, ctx->r4) = 0;
L_802FA784:
    // 0x802FA784: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
L_802FA788:
    // 0x802FA788: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
    // 0x802FA78C: addiu       $s6, $zero, 0x168
    ctx->r22 = ADD32(0, 0X168);
    // 0x802FA790: andi        $t4, $a0, 0x8
    ctx->r12 = ctx->r4 & 0X8;
    // 0x802FA794: beq         $t4, $zero, L_802FA848
    if (ctx->r12 == 0) {
        // 0x802FA798: lui         $s4, 0x8015
        ctx->r20 = S32(0X8015 << 16);
            goto L_802FA848;
    }
    // 0x802FA798: lui         $s4, 0x8015
    ctx->r20 = S32(0X8015 << 16);
    // 0x802FA79C: lb          $v0, 0x22A($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X22A);
    // 0x802FA7A0: andi        $t8, $a0, 0x4
    ctx->r24 = ctx->r4 & 0X4;
    // 0x802FA7A4: blez        $v0, L_802FA7B8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802FA7A8: nop
    
            goto L_802FA7B8;
    }
    // 0x802FA7A8: nop

    // 0x802FA7AC: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x802FA7B0: b           L_802FAD94
    // 0x802FA7B4: sb          $t5, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r13;
        goto L_802FAD94;
    // 0x802FA7B4: sb          $t5, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r13;
L_802FA7B8:
    // 0x802FA7B8: bne         $v0, $zero, L_802FA7C8
    if (ctx->r2 != 0) {
        // 0x802FA7BC: addiu       $s5, $zero, 0x1
        ctx->r21 = ADD32(0, 0X1);
            goto L_802FA7C8;
    }
    // 0x802FA7BC: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
    // 0x802FA7C0: b           L_802FA7DC
    // 0x802FA7C4: sh          $s5, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r21;
        goto L_802FA7DC;
    // 0x802FA7C4: sh          $s5, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r21;
L_802FA7C8:
    // 0x802FA7C8: bgez        $v0, L_802FA7DC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FA7CC: negu        $s5, $v0
        ctx->r21 = SUB32(0, ctx->r2);
            goto L_802FA7DC;
    }
    // 0x802FA7CC: negu        $s5, $v0
    ctx->r21 = SUB32(0, ctx->r2);
    // 0x802FA7D0: sll         $t6, $s5, 16
    ctx->r14 = S32(ctx->r21 << 16);
    // 0x802FA7D4: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FA7D8: sh          $t7, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r15;
L_802FA7DC:
    // 0x802FA7DC: beq         $t8, $zero, L_802FA83C
    if (ctx->r24 == 0) {
        // 0x802FA7E0: lh          $s5, 0x66($sp)
        ctx->r21 = MEM_H(ctx->r29, 0X66);
            goto L_802FA83C;
    }
    // 0x802FA7E0: lh          $s5, 0x66($sp)
    ctx->r21 = MEM_H(ctx->r29, 0X66);
    // 0x802FA7E4: lw          $v0, 0x158($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X158);
    // 0x802FA7E8: bnel        $v0, $zero, L_802FA800
    if (ctx->r2 != 0) {
        // 0x802FA7EC: lb          $t3, 0x221($s0)
        ctx->r11 = MEM_B(ctx->r16, 0X221);
            goto L_802FA800;
    }
    goto skip_1;
    // 0x802FA7EC: lb          $t3, 0x221($s0)
    ctx->r11 = MEM_B(ctx->r16, 0X221);
    skip_1:
    // 0x802FA7F0: lb          $t9, 0x221($s0)
    ctx->r25 = MEM_B(ctx->r16, 0X221);
    // 0x802FA7F4: b           L_802FAD94
    // 0x802FA7F8: sb          $t9, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r25;
        goto L_802FAD94;
    // 0x802FA7F8: sb          $t9, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r25;
    // 0x802FA7FC: lb          $t3, 0x221($s0)
    ctx->r11 = MEM_B(ctx->r16, 0X221);
L_802FA800:
    // 0x802FA800: sll         $t4, $t3, 11
    ctx->r12 = S32(ctx->r11 << 11);
    // 0x802FA804: div         $zero, $t4, $v0
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r2)));
    // 0x802FA808: mflo        $t5
    ctx->r13 = lo;
    // 0x802FA80C: sb          $t5, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r13;
    // 0x802FA810: bne         $v0, $zero, L_802FA81C
    if (ctx->r2 != 0) {
        // 0x802FA814: nop
    
            goto L_802FA81C;
    }
    // 0x802FA814: nop

    // 0x802FA818: break       7
    do_break(2150606872);
L_802FA81C:
    // 0x802FA81C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FA820: bne         $v0, $at, L_802FA834
    if (ctx->r2 != ctx->r1) {
        // 0x802FA824: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FA834;
    }
    // 0x802FA824: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FA828: bne         $t4, $at, L_802FA834
    if (ctx->r12 != ctx->r1) {
        // 0x802FA82C: nop
    
            goto L_802FA834;
    }
    // 0x802FA82C: nop

    // 0x802FA830: break       6
    do_break(2150606896);
L_802FA834:
    // 0x802FA834: b           L_802FA84C
    // 0x802FA838: slt         $v1, $zero, $s5
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r21) ? 1 : 0;
        goto L_802FA84C;
    // 0x802FA838: slt         $v1, $zero, $s5
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r21) ? 1 : 0;
L_802FA83C:
    // 0x802FA83C: lb          $t6, 0x221($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X221);
    // 0x802FA840: b           L_802FA848
    // 0x802FA844: sb          $t6, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r14;
        goto L_802FA848;
    // 0x802FA844: sb          $t6, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r14;
L_802FA848:
    // 0x802FA848: slt         $v1, $zero, $s5
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r21) ? 1 : 0;
L_802FA84C:
    // 0x802FA84C: addiu       $s5, $s5, -0x1
    ctx->r21 = ADD32(ctx->r21, -0X1);
    // 0x802FA850: sll         $t7, $s5, 16
    ctx->r15 = S32(ctx->r21 << 16);
    // 0x802FA854: beq         $v1, $zero, L_802FAD94
    if (ctx->r3 == 0) {
        // 0x802FA858: sra         $s5, $t7, 16
        ctx->r21 = S32(SIGNED(ctx->r15) >> 16);
            goto L_802FAD94;
    }
    // 0x802FA858: sra         $s5, $t7, 16
    ctx->r21 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FA85C: addiu       $s4, $s4, 0x2C78
    ctx->r20 = ADD32(ctx->r20, 0X2C78);
L_802FA860:
    // 0x802FA860: lb          $v0, 0x22A($s0)
    ctx->r2 = MEM_B(ctx->r16, 0X22A);
    // 0x802FA864: bgez        $v0, L_802FA870
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FA868: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_802FA870;
    }
    // 0x802FA868: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x802FA86C: sb          $t9, 0x22A($s0)
    MEM_B(0X22A, ctx->r16) = ctx->r25;
L_802FA870:
    // 0x802FA870: lb          $t3, 0x212($s0)
    ctx->r11 = MEM_B(ctx->r16, 0X212);
    // 0x802FA874: sh          $t3, 0xB8($sp)
    MEM_H(0XB8, ctx->r29) = ctx->r11;
    // 0x802FA878: lb          $t4, 0x213($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X213);
    // 0x802FA87C: sh          $t4, 0xBA($sp)
    MEM_H(0XBA, ctx->r29) = ctx->r12;
    // 0x802FA880: lb          $t5, 0x214($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X214);
    // 0x802FA884: sh          $t5, 0xBC($sp)
    MEM_H(0XBC, ctx->r29) = ctx->r13;
    // 0x802FA888: lbu         $t6, 0x215($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X215);
    // 0x802FA88C: beql        $t6, $zero, L_802FA8F8
    if (ctx->r14 == 0) {
        // 0x802FA890: lbu         $t3, 0x216($s0)
        ctx->r11 = MEM_BU(ctx->r16, 0X216);
            goto L_802FA8F8;
    }
    goto skip_2;
    // 0x802FA890: lbu         $t3, 0x216($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X216);
    skip_2:
    // 0x802FA894: jal         0x80128200
    // 0x802FA898: nop

    func_80128200(rdram, ctx);
        goto after_0;
    // 0x802FA898: nop

    after_0:
    // 0x802FA89C: lbu         $v1, 0x215($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X215);
    // 0x802FA8A0: sra         $t7, $v0, 4
    ctx->r15 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FA8A4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802FA8A8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FA8AC: sll         $t3, $t9, 1
    ctx->r11 = S32(ctx->r25 << 1);
    // 0x802FA8B0: div         $zero, $t7, $t3
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r11)));
    // 0x802FA8B4: lh          $t8, 0xB8($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XB8);
    // 0x802FA8B8: mfhi        $t4
    ctx->r12 = hi;
    // 0x802FA8BC: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x802FA8C0: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FA8C4: bne         $t3, $zero, L_802FA8D0
    if (ctx->r11 != 0) {
        // 0x802FA8C8: nop
    
            goto L_802FA8D0;
    }
    // 0x802FA8C8: nop

    // 0x802FA8CC: break       7
    do_break(2150607052);
L_802FA8D0:
    // 0x802FA8D0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FA8D4: bne         $t3, $at, L_802FA8E8
    if (ctx->r11 != ctx->r1) {
        // 0x802FA8D8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FA8E8;
    }
    // 0x802FA8D8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FA8DC: bne         $t7, $at, L_802FA8E8
    if (ctx->r15 != ctx->r1) {
        // 0x802FA8E0: nop
    
            goto L_802FA8E8;
    }
    // 0x802FA8E0: nop

    // 0x802FA8E4: break       6
    do_break(2150607076);
L_802FA8E8:
    // 0x802FA8E8: addu        $t9, $t8, $t6
    ctx->r25 = ADD32(ctx->r24, ctx->r14);
    // 0x802FA8EC: subu        $t7, $t9, $v1
    ctx->r15 = SUB32(ctx->r25, ctx->r3);
    // 0x802FA8F0: sh          $t7, 0xB8($sp)
    MEM_H(0XB8, ctx->r29) = ctx->r15;
    // 0x802FA8F4: lbu         $t3, 0x216($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X216);
L_802FA8F8:
    // 0x802FA8F8: beql        $t3, $zero, L_802FA964
    if (ctx->r11 == 0) {
        // 0x802FA8FC: lbu         $t6, 0x217($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X217);
            goto L_802FA964;
    }
    goto skip_3;
    // 0x802FA8FC: lbu         $t6, 0x217($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X217);
    skip_3:
    // 0x802FA900: jal         0x80128200
    // 0x802FA904: nop

    func_80128200(rdram, ctx);
        goto after_1;
    // 0x802FA904: nop

    after_1:
    // 0x802FA908: lbu         $v1, 0x216($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X216);
    // 0x802FA90C: sra         $t4, $v0, 4
    ctx->r12 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FA910: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802FA914: sra         $t8, $t5, 16
    ctx->r24 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FA918: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802FA91C: div         $zero, $t4, $t6
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r14))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r14)));
    // 0x802FA920: lh          $t5, 0xBA($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XBA);
    // 0x802FA924: mfhi        $t9
    ctx->r25 = hi;
    // 0x802FA928: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x802FA92C: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FA930: bne         $t6, $zero, L_802FA93C
    if (ctx->r14 != 0) {
        // 0x802FA934: nop
    
            goto L_802FA93C;
    }
    // 0x802FA934: nop

    // 0x802FA938: break       7
    do_break(2150607160);
L_802FA93C:
    // 0x802FA93C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FA940: bne         $t6, $at, L_802FA954
    if (ctx->r14 != ctx->r1) {
        // 0x802FA944: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FA954;
    }
    // 0x802FA944: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FA948: bne         $t4, $at, L_802FA954
    if (ctx->r12 != ctx->r1) {
        // 0x802FA94C: nop
    
            goto L_802FA954;
    }
    // 0x802FA94C: nop

    // 0x802FA950: break       6
    do_break(2150607184);
L_802FA954:
    // 0x802FA954: addu        $t8, $t5, $t3
    ctx->r24 = ADD32(ctx->r13, ctx->r11);
    // 0x802FA958: subu        $t4, $t8, $v1
    ctx->r12 = SUB32(ctx->r24, ctx->r3);
    // 0x802FA95C: sh          $t4, 0xBA($sp)
    MEM_H(0XBA, ctx->r29) = ctx->r12;
    // 0x802FA960: lbu         $t6, 0x217($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X217);
L_802FA964:
    // 0x802FA964: beql        $t6, $zero, L_802FA9D0
    if (ctx->r14 == 0) {
        // 0x802FA968: lhu         $a0, 0x21E($s0)
        ctx->r4 = MEM_HU(ctx->r16, 0X21E);
            goto L_802FA9D0;
    }
    goto skip_4;
    // 0x802FA968: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
    skip_4:
    // 0x802FA96C: jal         0x80128200
    // 0x802FA970: nop

    func_80128200(rdram, ctx);
        goto after_2;
    // 0x802FA970: nop

    after_2:
    // 0x802FA974: lbu         $v1, 0x217($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X217);
    // 0x802FA978: sra         $t9, $v0, 4
    ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FA97C: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802FA980: sra         $t5, $t7, 16
    ctx->r13 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FA984: sll         $t3, $t5, 1
    ctx->r11 = S32(ctx->r13 << 1);
    // 0x802FA988: div         $zero, $t9, $t3
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r11)));
    // 0x802FA98C: lh          $t7, 0xBC($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XBC);
    // 0x802FA990: mfhi        $t8
    ctx->r24 = hi;
    // 0x802FA994: sll         $t4, $t8, 16
    ctx->r12 = S32(ctx->r24 << 16);
    // 0x802FA998: sra         $t6, $t4, 16
    ctx->r14 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FA99C: bne         $t3, $zero, L_802FA9A8
    if (ctx->r11 != 0) {
        // 0x802FA9A0: nop
    
            goto L_802FA9A8;
    }
    // 0x802FA9A0: nop

    // 0x802FA9A4: break       7
    do_break(2150607268);
L_802FA9A8:
    // 0x802FA9A8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FA9AC: bne         $t3, $at, L_802FA9C0
    if (ctx->r11 != ctx->r1) {
        // 0x802FA9B0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FA9C0;
    }
    // 0x802FA9B0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FA9B4: bne         $t9, $at, L_802FA9C0
    if (ctx->r25 != ctx->r1) {
        // 0x802FA9B8: nop
    
            goto L_802FA9C0;
    }
    // 0x802FA9B8: nop

    // 0x802FA9BC: break       6
    do_break(2150607292);
L_802FA9C0:
    // 0x802FA9C0: addu        $t5, $t7, $t6
    ctx->r13 = ADD32(ctx->r15, ctx->r14);
    // 0x802FA9C4: subu        $t9, $t5, $v1
    ctx->r25 = SUB32(ctx->r13, ctx->r3);
    // 0x802FA9C8: sh          $t9, 0xBC($sp)
    MEM_H(0XBC, ctx->r29) = ctx->r25;
    // 0x802FA9CC: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
L_802FA9D0:
    // 0x802FA9D0: lh          $t8, 0xB8($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XB8);
    // 0x802FA9D4: lh          $t4, 0xBA($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XBA);
    // 0x802FA9D8: andi        $t3, $a0, 0x40
    ctx->r11 = ctx->r4 & 0X40;
    // 0x802FA9DC: beq         $t3, $zero, L_802FAA18
    if (ctx->r11 == 0) {
        // 0x802FA9E0: lh          $t6, 0xBC($sp)
        ctx->r14 = MEM_H(ctx->r29, 0XBC);
            goto L_802FAA18;
    }
    // 0x802FA9E0: lh          $t6, 0xBC($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XBC);
    // 0x802FA9E4: or          $t7, $t8, $t4
    ctx->r15 = ctx->r24 | ctx->r12;
    // 0x802FA9E8: or          $t5, $t7, $t6
    ctx->r13 = ctx->r15 | ctx->r14;
    // 0x802FA9EC: beq         $t5, $zero, L_802FAA18
    if (ctx->r13 == 0) {
        // 0x802FA9F0: addiu       $t3, $sp, 0xB8
        ctx->r11 = ADD32(ctx->r29, 0XB8);
            goto L_802FAA18;
    }
    // 0x802FA9F0: addiu       $t3, $sp, 0xB8
    ctx->r11 = ADD32(ctx->r29, 0XB8);
    // 0x802FA9F4: lh          $t9, 0x2C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2C);
    // 0x802FA9F8: lh          $a3, 0x2E($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2E);
    // 0x802FA9FC: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x802FAA00: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x802FAA04: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x802FAA08: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x802FAA0C: jal         0x802F5F44
    // 0x802FAA10: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_3;
    // 0x802FAA10: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_3:
    // 0x802FAA14: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
L_802FAA18:
    // 0x802FAA18: andi        $t7, $a0, 0x80
    ctx->r15 = ctx->r4 & 0X80;
    // 0x802FAA1C: beq         $t7, $zero, L_802FAA68
    if (ctx->r15 == 0) {
        // 0x802FAA20: lh          $t5, 0xB8($sp)
        ctx->r13 = MEM_H(ctx->r29, 0XB8);
            goto L_802FAA68;
    }
    // 0x802FAA20: lh          $t5, 0xB8($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XB8);
    // 0x802FAA24: lhu         $t8, 0x40($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X40);
    // 0x802FAA28: lh          $t9, 0xBA($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XBA);
    // 0x802FAA2C: multu       $t5, $t8
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAA30: lh          $t8, 0xBC($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XBC);
    // 0x802FAA34: mflo        $t4
    ctx->r12 = lo;
    // 0x802FAA38: sra         $t6, $t4, 11
    ctx->r14 = S32(SIGNED(ctx->r12) >> 11);
    // 0x802FAA3C: sh          $t6, 0xB8($sp)
    MEM_H(0XB8, ctx->r29) = ctx->r14;
    // 0x802FAA40: lhu         $t3, 0x40($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X40);
    // 0x802FAA44: multu       $t9, $t3
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAA48: mflo        $t7
    ctx->r15 = lo;
    // 0x802FAA4C: sra         $t5, $t7, 11
    ctx->r13 = S32(SIGNED(ctx->r15) >> 11);
    // 0x802FAA50: sh          $t5, 0xBA($sp)
    MEM_H(0XBA, ctx->r29) = ctx->r13;
    // 0x802FAA54: lhu         $t4, 0x40($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X40);
    // 0x802FAA58: multu       $t8, $t4
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAA5C: mflo        $t6
    ctx->r14 = lo;
    // 0x802FAA60: sra         $t9, $t6, 11
    ctx->r25 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FAA64: sh          $t9, 0xBC($sp)
    MEM_H(0XBC, ctx->r29) = ctx->r25;
L_802FAA68:
    // 0x802FAA68: lh          $t3, 0xB8($sp)
    ctx->r11 = MEM_H(ctx->r29, 0XB8);
    // 0x802FAA6C: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x802FAA70: lh          $t8, 0xBA($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XBA);
    // 0x802FAA74: lh          $t9, 0xBC($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XBC);
    // 0x802FAA78: addu        $t5, $t3, $t7
    ctx->r13 = ADD32(ctx->r11, ctx->r15);
    // 0x802FAA7C: sh          $t5, 0xB8($sp)
    MEM_H(0XB8, ctx->r29) = ctx->r13;
    // 0x802FAA80: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802FAA84: addu        $t6, $t8, $t4
    ctx->r14 = ADD32(ctx->r24, ctx->r12);
    // 0x802FAA88: sh          $t6, 0xBA($sp)
    MEM_H(0XBA, ctx->r29) = ctx->r14;
    // 0x802FAA8C: lhu         $t5, 0x42($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X42);
    // 0x802FAA90: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x802FAA94: sra         $t8, $t5, 1
    ctx->r24 = S32(SIGNED(ctx->r13) >> 1);
    // 0x802FAA98: addu        $t7, $t9, $t3
    ctx->r15 = ADD32(ctx->r25, ctx->r11);
    // 0x802FAA9C: addu        $t4, $t7, $t8
    ctx->r12 = ADD32(ctx->r15, ctx->r24);
    // 0x802FAAA0: sh          $t4, 0xBC($sp)
    MEM_H(0XBC, ctx->r29) = ctx->r12;
    // 0x802FAAA4: lbu         $t6, 0x21D($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X21D);
    // 0x802FAAA8: lbu         $s1, 0x21A($s0)
    ctx->r17 = MEM_BU(ctx->r16, 0X21A);
    // 0x802FAAAC: lbu         $s2, 0x218($s0)
    ctx->r18 = MEM_BU(ctx->r16, 0X218);
    // 0x802FAAB0: beq         $t6, $zero, L_802FAB00
    if (ctx->r14 == 0) {
        // 0x802FAAB4: lbu         $s3, 0x219($s0)
        ctx->r19 = MEM_BU(ctx->r16, 0X219);
            goto L_802FAB00;
    }
    // 0x802FAAB4: lbu         $s3, 0x219($s0)
    ctx->r19 = MEM_BU(ctx->r16, 0X219);
    // 0x802FAAB8: jal         0x80128200
    // 0x802FAABC: nop

    func_80128200(rdram, ctx);
        goto after_4;
    // 0x802FAABC: nop

    after_4:
    // 0x802FAAC0: lbu         $v1, 0x21D($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X21D);
    // 0x802FAAC4: sra         $t9, $v0, 4
    ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FAAC8: sll         $t3, $v1, 1
    ctx->r11 = S32(ctx->r3 << 1);
    // 0x802FAACC: div         $zero, $t9, $t3
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r11)));
    // 0x802FAAD0: mfhi        $t5
    ctx->r13 = hi;
    // 0x802FAAD4: addu        $t7, $s1, $t5
    ctx->r15 = ADD32(ctx->r17, ctx->r13);
    // 0x802FAAD8: bne         $t3, $zero, L_802FAAE4
    if (ctx->r11 != 0) {
        // 0x802FAADC: nop
    
            goto L_802FAAE4;
    }
    // 0x802FAADC: nop

    // 0x802FAAE0: break       7
    do_break(2150607584);
L_802FAAE4:
    // 0x802FAAE4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAAE8: bne         $t3, $at, L_802FAAFC
    if (ctx->r11 != ctx->r1) {
        // 0x802FAAEC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAAFC;
    }
    // 0x802FAAEC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAAF0: bne         $t9, $at, L_802FAAFC
    if (ctx->r25 != ctx->r1) {
        // 0x802FAAF4: nop
    
            goto L_802FAAFC;
    }
    // 0x802FAAF4: nop

    // 0x802FAAF8: break       6
    do_break(2150607608);
L_802FAAFC:
    // 0x802FAAFC: subu        $s1, $t7, $v1
    ctx->r17 = SUB32(ctx->r15, ctx->r3);
L_802FAB00:
    // 0x802FAB00: lbu         $t8, 0x21B($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X21B);
    // 0x802FAB04: beql        $t8, $zero, L_802FAB68
    if (ctx->r24 == 0) {
        // 0x802FAB08: lbu         $t6, 0x21C($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X21C);
            goto L_802FAB68;
    }
    goto skip_5;
    // 0x802FAB08: lbu         $t6, 0x21C($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X21C);
    skip_5:
    // 0x802FAB0C: jal         0x80128200
    // 0x802FAB10: nop

    func_80128200(rdram, ctx);
        goto after_5;
    // 0x802FAB10: nop

    after_5:
    // 0x802FAB14: lbu         $v1, 0x21B($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X21B);
    // 0x802FAB18: sra         $t4, $v0, 4
    ctx->r12 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FAB1C: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802FAB20: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FAB24: sll         $t3, $t9, 1
    ctx->r11 = S32(ctx->r25 << 1);
    // 0x802FAB28: div         $zero, $t4, $t3
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r11))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r11)));
    // 0x802FAB2C: mfhi        $t5
    ctx->r13 = hi;
    // 0x802FAB30: addu        $t7, $t5, $s2
    ctx->r15 = ADD32(ctx->r13, ctx->r18);
    // 0x802FAB34: subu        $s2, $t7, $v1
    ctx->r18 = SUB32(ctx->r15, ctx->r3);
    // 0x802FAB38: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x802FAB3C: or          $s2, $t8, $zero
    ctx->r18 = ctx->r24 | 0;
    // 0x802FAB40: bne         $t3, $zero, L_802FAB4C
    if (ctx->r11 != 0) {
        // 0x802FAB44: nop
    
            goto L_802FAB4C;
    }
    // 0x802FAB44: nop

    // 0x802FAB48: break       7
    do_break(2150607688);
L_802FAB4C:
    // 0x802FAB4C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAB50: bne         $t3, $at, L_802FAB64
    if (ctx->r11 != ctx->r1) {
        // 0x802FAB54: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAB64;
    }
    // 0x802FAB54: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAB58: bne         $t4, $at, L_802FAB64
    if (ctx->r12 != ctx->r1) {
        // 0x802FAB5C: nop
    
            goto L_802FAB64;
    }
    // 0x802FAB5C: nop

    // 0x802FAB60: break       6
    do_break(2150607712);
L_802FAB64:
    // 0x802FAB64: lbu         $t6, 0x21C($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X21C);
L_802FAB68:
    // 0x802FAB68: beql        $t6, $zero, L_802FABCC
    if (ctx->r14 == 0) {
        // 0x802FAB6C: lhu         $a0, 0x21E($s0)
        ctx->r4 = MEM_HU(ctx->r16, 0X21E);
            goto L_802FABCC;
    }
    goto skip_6;
    // 0x802FAB6C: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
    skip_6:
    // 0x802FAB70: jal         0x80128200
    // 0x802FAB74: nop

    func_80128200(rdram, ctx);
        goto after_6;
    // 0x802FAB74: nop

    after_6:
    // 0x802FAB78: lbu         $v1, 0x21C($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X21C);
    // 0x802FAB7C: sra         $t9, $v0, 4
    ctx->r25 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FAB80: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x802FAB84: sra         $t3, $t4, 16
    ctx->r11 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FAB88: sll         $t5, $t3, 1
    ctx->r13 = S32(ctx->r11 << 1);
    // 0x802FAB8C: div         $zero, $t9, $t5
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r13))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r13)));
    // 0x802FAB90: mfhi        $t7
    ctx->r15 = hi;
    // 0x802FAB94: addu        $t8, $t7, $s3
    ctx->r24 = ADD32(ctx->r15, ctx->r19);
    // 0x802FAB98: subu        $s3, $t8, $v1
    ctx->r19 = SUB32(ctx->r24, ctx->r3);
    // 0x802FAB9C: andi        $t6, $s3, 0xFF
    ctx->r14 = ctx->r19 & 0XFF;
    // 0x802FABA0: or          $s3, $t6, $zero
    ctx->r19 = ctx->r14 | 0;
    // 0x802FABA4: bne         $t5, $zero, L_802FABB0
    if (ctx->r13 != 0) {
        // 0x802FABA8: nop
    
            goto L_802FABB0;
    }
    // 0x802FABA8: nop

    // 0x802FABAC: break       7
    do_break(2150607788);
L_802FABB0:
    // 0x802FABB0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FABB4: bne         $t5, $at, L_802FABC8
    if (ctx->r13 != ctx->r1) {
        // 0x802FABB8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FABC8;
    }
    // 0x802FABB8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FABBC: bne         $t9, $at, L_802FABC8
    if (ctx->r25 != ctx->r1) {
        // 0x802FABC0: nop
    
            goto L_802FABC8;
    }
    // 0x802FABC0: nop

    // 0x802FABC4: break       6
    do_break(2150607812);
L_802FABC8:
    // 0x802FABC8: lhu         $a0, 0x21E($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X21E);
L_802FABCC:
    // 0x802FABCC: andi        $t4, $a0, 0x20
    ctx->r12 = ctx->r4 & 0X20;
    // 0x802FABD0: beql        $t4, $zero, L_802FAC5C
    if (ctx->r12 == 0) {
        // 0x802FABD4: andi        $t9, $a0, 0x2
        ctx->r25 = ctx->r4 & 0X2;
            goto L_802FAC5C;
    }
    goto skip_7;
    // 0x802FABD4: andi        $t9, $a0, 0x2
    ctx->r25 = ctx->r4 & 0X2;
    skip_7:
    // 0x802FABD8: lh          $t3, 0x2E($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X2E);
    // 0x802FABDC: lh          $t7, 0x2C($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2C);
    // 0x802FABE0: sll         $t9, $t3, 8
    ctx->r25 = S32(ctx->r11 << 8);
    // 0x802FABE4: div         $zero, $t9, $s6
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r22))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r22)));
    // 0x802FABE8: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802FABEC: mflo        $t5
    ctx->r13 = lo;
    // 0x802FABF0: addu        $s2, $s2, $t5
    ctx->r18 = ADD32(ctx->r18, ctx->r13);
    // 0x802FABF4: bne         $s6, $zero, L_802FAC00
    if (ctx->r22 != 0) {
        // 0x802FABF8: nop
    
            goto L_802FAC00;
    }
    // 0x802FABF8: nop

    // 0x802FABFC: break       7
    do_break(2150607868);
L_802FAC00:
    // 0x802FAC00: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAC04: bne         $s6, $at, L_802FAC18
    if (ctx->r22 != ctx->r1) {
        // 0x802FAC08: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAC18;
    }
    // 0x802FAC08: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAC0C: bne         $t9, $at, L_802FAC18
    if (ctx->r25 != ctx->r1) {
        // 0x802FAC10: nop
    
            goto L_802FAC18;
    }
    // 0x802FAC10: nop

    // 0x802FAC14: break       6
    do_break(2150607892);
L_802FAC18:
    // 0x802FAC18: div         $zero, $t8, $s6
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r22))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r22)));
    // 0x802FAC1C: mflo        $t6
    ctx->r14 = lo;
    // 0x802FAC20: addu        $s3, $s3, $t6
    ctx->r19 = ADD32(ctx->r19, ctx->r14);
    // 0x802FAC24: andi        $t4, $s2, 0xFF
    ctx->r12 = ctx->r18 & 0XFF;
    // 0x802FAC28: andi        $t3, $s3, 0xFF
    ctx->r11 = ctx->r19 & 0XFF;
    // 0x802FAC2C: bne         $s6, $zero, L_802FAC38
    if (ctx->r22 != 0) {
        // 0x802FAC30: nop
    
            goto L_802FAC38;
    }
    // 0x802FAC30: nop

    // 0x802FAC34: break       7
    do_break(2150607924);
L_802FAC38:
    // 0x802FAC38: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAC3C: bne         $s6, $at, L_802FAC50
    if (ctx->r22 != ctx->r1) {
        // 0x802FAC40: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAC50;
    }
    // 0x802FAC40: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAC44: bne         $t8, $at, L_802FAC50
    if (ctx->r24 != ctx->r1) {
        // 0x802FAC48: nop
    
            goto L_802FAC50;
    }
    // 0x802FAC48: nop

    // 0x802FAC4C: break       6
    do_break(2150607948);
L_802FAC50:
    // 0x802FAC50: or          $s2, $t4, $zero
    ctx->r18 = ctx->r12 | 0;
    // 0x802FAC54: or          $s3, $t3, $zero
    ctx->r19 = ctx->r11 | 0;
    // 0x802FAC58: andi        $t9, $a0, 0x2
    ctx->r25 = ctx->r4 & 0X2;
L_802FAC5C:
    // 0x802FAC5C: beq         $t9, $zero, L_802FAC84
    if (ctx->r25 == 0) {
        // 0x802FAC60: addiu       $t6, $s2, 0x40
        ctx->r14 = ADD32(ctx->r18, 0X40);
            goto L_802FAC84;
    }
    // 0x802FAC60: addiu       $t6, $s2, 0x40
    ctx->r14 = ADD32(ctx->r18, 0X40);
    // 0x802FAC64: lw          $v0, 0x158($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X158);
    // 0x802FAC68: beql        $v0, $zero, L_802FAD98
    if (ctx->r2 == 0) {
        // 0x802FAC6C: lw          $ra, 0x54($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X54);
            goto L_802FAD98;
    }
    goto skip_8;
    // 0x802FAC6C: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    skip_8:
    // 0x802FAC70: multu       $s1, $v0
    result = U64(U32(ctx->r17)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAC74: mflo        $s1
    ctx->r17 = lo;
    // 0x802FAC78: sra         $t5, $s1, 2
    ctx->r13 = S32(SIGNED(ctx->r17) >> 2);
    // 0x802FAC7C: b           L_802FAC8C
    // 0x802FAC80: or          $s1, $t5, $zero
    ctx->r17 = ctx->r13 | 0;
        goto L_802FAC8C;
    // 0x802FAC80: or          $s1, $t5, $zero
    ctx->r17 = ctx->r13 | 0;
L_802FAC84:
    // 0x802FAC84: sll         $t7, $s1, 8
    ctx->r15 = S32(ctx->r17 << 8);
    // 0x802FAC88: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
L_802FAC8C:
    // 0x802FAC8C: andi        $t4, $t6, 0xFF
    ctx->r12 = ctx->r14 & 0XFF;
    // 0x802FAC90: sll         $t3, $t4, 1
    ctx->r11 = S32(ctx->r12 << 1);
    // 0x802FAC94: addu        $t9, $s4, $t3
    ctx->r25 = ADD32(ctx->r20, ctx->r11);
    // 0x802FAC98: lh          $t5, 0x0($t9)
    ctx->r13 = MEM_H(ctx->r25, 0X0);
    // 0x802FAC9C: andi        $t8, $s2, 0xFF
    ctx->r24 = ctx->r18 & 0XFF;
    // 0x802FACA0: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802FACA4: multu       $t5, $s1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FACA8: addu        $t4, $s4, $t6
    ctx->r12 = ADD32(ctx->r20, ctx->r14);
    // 0x802FACAC: lh          $t3, 0x0($t4)
    ctx->r11 = MEM_H(ctx->r12, 0X0);
    // 0x802FACB0: mflo        $t0
    ctx->r8 = lo;
    // 0x802FACB4: sra         $t7, $t0, 15
    ctx->r15 = S32(SIGNED(ctx->r8) >> 15);
    // 0x802FACB8: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x802FACBC: multu       $t3, $s1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FACC0: andi        $t7, $s3, 0xFF
    ctx->r15 = ctx->r19 & 0XFF;
    // 0x802FACC4: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802FACC8: addu        $t6, $s4, $t8
    ctx->r14 = ADD32(ctx->r20, ctx->r24);
    // 0x802FACCC: lh          $t4, 0x0($t6)
    ctx->r12 = MEM_H(ctx->r14, 0X0);
    // 0x802FACD0: mflo        $t1
    ctx->r9 = lo;
    // 0x802FACD4: sra         $t9, $t1, 15
    ctx->r25 = S32(SIGNED(ctx->r9) >> 15);
    // 0x802FACD8: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x802FACDC: multu       $t4, $t0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FACE0: addiu       $t9, $s3, 0x40
    ctx->r25 = ADD32(ctx->r19, 0X40);
    // 0x802FACE4: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x802FACE8: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x802FACEC: addu        $t8, $s4, $t7
    ctx->r24 = ADD32(ctx->r20, ctx->r15);
    // 0x802FACF0: lh          $t6, 0x0($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X0);
    // 0x802FACF4: mflo        $t2
    ctx->r10 = lo;
    // 0x802FACF8: sra         $t3, $t2, 15
    ctx->r11 = S32(SIGNED(ctx->r10) >> 15);
    // 0x802FACFC: or          $t2, $t3, $zero
    ctx->r10 = ctx->r11 | 0;
    // 0x802FAD00: multu       $t6, $t0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAD04: andi        $t3, $a0, 0x80
    ctx->r11 = ctx->r4 & 0X80;
    // 0x802FAD08: sll         $t8, $t2, 8
    ctx->r24 = S32(ctx->r10 << 8);
    // 0x802FAD0C: mflo        $t0
    ctx->r8 = lo;
    // 0x802FAD10: sra         $t4, $t0, 15
    ctx->r12 = S32(SIGNED(ctx->r8) >> 15);
    // 0x802FAD14: beq         $t3, $zero, L_802FAD38
    if (ctx->r11 == 0) {
        // 0x802FAD18: or          $t0, $t4, $zero
        ctx->r8 = ctx->r12 | 0;
            goto L_802FAD38;
    }
    // 0x802FAD18: or          $t0, $t4, $zero
    ctx->r8 = ctx->r12 | 0;
    // 0x802FAD1C: lbu         $t9, 0x222($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X222);
    // 0x802FAD20: lhu         $t5, 0x40($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X40);
    // 0x802FAD24: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAD28: mflo        $v0
    ctx->r2 = lo;
    // 0x802FAD2C: sra         $t7, $v0, 11
    ctx->r15 = S32(SIGNED(ctx->r2) >> 11);
    // 0x802FAD30: b           L_802FAD3C
    // 0x802FAD34: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
        goto L_802FAD3C;
    // 0x802FAD34: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
L_802FAD38:
    // 0x802FAD38: lbu         $v0, 0x222($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X222);
L_802FAD3C:
    // 0x802FAD3C: lbu         $a3, 0x220($s0)
    ctx->r7 = MEM_BU(ctx->r16, 0X220);
    // 0x802FAD40: sll         $t6, $t0, 8
    ctx->r14 = S32(ctx->r8 << 8);
    // 0x802FAD44: sll         $t4, $t1, 8
    ctx->r12 = S32(ctx->r9 << 8);
    // 0x802FAD48: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x802FAD4C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802FAD50: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    // 0x802FAD54: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FAD58: lhu         $t3, 0x226($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X226);
    // 0x802FAD5C: lh          $a0, 0xB8($sp)
    ctx->r4 = MEM_H(ctx->r29, 0XB8);
    // 0x802FAD60: lh          $a1, 0xBA($sp)
    ctx->r5 = MEM_H(ctx->r29, 0XBA);
    // 0x802FAD64: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    // 0x802FAD68: lhu         $t9, 0x228($s0)
    ctx->r25 = MEM_HU(ctx->r16, 0X228);
    // 0x802FAD6C: lh          $a2, 0xBC($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XBC);
    // 0x802FAD70: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x802FAD74: lbu         $t5, 0x223($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X223);
    // 0x802FAD78: jal         0x802D5F4C
    // 0x802FAD7C: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    create_particle_effect(rdram, ctx);
        goto after_7;
    // 0x802FAD7C: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    after_7:
    // 0x802FAD80: slt         $v1, $zero, $s5
    ctx->r3 = SIGNED(0) < SIGNED(ctx->r21) ? 1 : 0;
    // 0x802FAD84: addiu       $s5, $s5, -0x1
    ctx->r21 = ADD32(ctx->r21, -0X1);
    // 0x802FAD88: sll         $t7, $s5, 16
    ctx->r15 = S32(ctx->r21 << 16);
    // 0x802FAD8C: bne         $v1, $zero, L_802FA860
    if (ctx->r3 != 0) {
        // 0x802FAD90: sra         $s5, $t7, 16
        ctx->r21 = S32(SIGNED(ctx->r15) >> 16);
            goto L_802FA860;
    }
    // 0x802FAD90: sra         $s5, $t7, 16
    ctx->r21 = S32(SIGNED(ctx->r15) >> 16);
L_802FAD94:
    // 0x802FAD94: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_802FAD98:
    // 0x802FAD98: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802FAD9C: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x802FADA0: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x802FADA4: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x802FADA8: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x802FADAC: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x802FADB0: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x802FADB4: jr          $ra
    // 0x802FADB8: addiu       $sp, $sp, 0xC0
    ctx->r29 = ADD32(ctx->r29, 0XC0);
    return;
    // 0x802FADB8: addiu       $sp, $sp, 0xC0
    ctx->r29 = ADD32(ctx->r29, 0XC0);
;}
RECOMP_FUNC void func_802FADBC_70C46C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FADBC: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x802FADC0: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802FADC4: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802FADC8: lbu         $a2, 0x241($a0)
    ctx->r6 = MEM_BU(ctx->r4, 0X241);
    // 0x802FADCC: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FADD0: andi        $t6, $a2, 0x4
    ctx->r14 = ctx->r6 & 0X4;
    // 0x802FADD4: beql        $t6, $zero, L_802FAF80
    if (ctx->r14 == 0) {
        // 0x802FADD8: lh          $v0, 0x20C($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X20C);
            goto L_802FAF80;
    }
    goto skip_0;
    // 0x802FADD8: lh          $v0, 0x20C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X20C);
    skip_0:
    // 0x802FADDC: lh          $v0, 0x242($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X242);
    // 0x802FADE0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802FADE4: blezl       $v0, L_802FAEB0
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802FADE8: lbu         $t3, 0x23F($s0)
        ctx->r11 = MEM_BU(ctx->r16, 0X23F);
            goto L_802FAEB0;
    }
    goto skip_1;
    // 0x802FADE8: lbu         $t3, 0x23F($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X23F);
    skip_1:
    // 0x802FADEC: lbu         $v1, 0x23D($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X23D);
    // 0x802FADF0: lbu         $t7, 0x23E($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X23E);
    // 0x802FADF4: lhu         $a0, 0x244($s0)
    ctx->r4 = MEM_HU(ctx->r16, 0X244);
    // 0x802FADF8: lbu         $a1, 0x23F($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X23F);
    // 0x802FADFC: subu        $t8, $t7, $v1
    ctx->r24 = SUB32(ctx->r15, ctx->r3);
    // 0x802FAE00: multu       $t8, $a0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAE04: lbu         $t4, 0x240($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X240);
    // 0x802FAE08: subu        $t5, $t4, $a1
    ctx->r13 = SUB32(ctx->r12, ctx->r5);
    // 0x802FAE0C: mflo        $t9
    ctx->r25 = lo;
    // 0x802FAE10: nop

    // 0x802FAE14: nop

    // 0x802FAE18: div         $zero, $t9, $v0
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r2)));
    // 0x802FAE1C: mflo        $t2
    ctx->r10 = lo;
    // 0x802FAE20: addu        $t0, $t2, $v1
    ctx->r8 = ADD32(ctx->r10, ctx->r3);
    // 0x802FAE24: bne         $v0, $zero, L_802FAE30
    if (ctx->r2 != 0) {
        // 0x802FAE28: nop
    
            goto L_802FAE30;
    }
    // 0x802FAE28: nop

    // 0x802FAE2C: break       7
    do_break(2150608428);
L_802FAE30:
    // 0x802FAE30: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAE34: bne         $v0, $at, L_802FAE48
    if (ctx->r2 != ctx->r1) {
        // 0x802FAE38: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAE48;
    }
    // 0x802FAE38: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAE3C: bne         $t9, $at, L_802FAE48
    if (ctx->r25 != ctx->r1) {
        // 0x802FAE40: nop
    
            goto L_802FAE48;
    }
    // 0x802FAE40: nop

    // 0x802FAE44: break       6
    do_break(2150608452);
L_802FAE48:
    // 0x802FAE48: multu       $t5, $a0
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FAE4C: sll         $t3, $t0, 7
    ctx->r11 = S32(ctx->r8 << 7);
    // 0x802FAE50: or          $t0, $t3, $zero
    ctx->r8 = ctx->r11 | 0;
    // 0x802FAE54: mflo        $t6
    ctx->r14 = lo;
    // 0x802FAE58: nop

    // 0x802FAE5C: nop

    // 0x802FAE60: div         $zero, $t6, $v0
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r2)));
    // 0x802FAE64: mflo        $t7
    ctx->r15 = lo;
    // 0x802FAE68: addu        $t8, $t7, $a1
    ctx->r24 = ADD32(ctx->r15, ctx->r5);
    // 0x802FAE6C: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x802FAE70: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x802FAE74: bne         $v0, $zero, L_802FAE80
    if (ctx->r2 != 0) {
        // 0x802FAE78: nop
    
            goto L_802FAE80;
    }
    // 0x802FAE78: nop

    // 0x802FAE7C: break       7
    do_break(2150608508);
L_802FAE80:
    // 0x802FAE80: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FAE84: bne         $v0, $at, L_802FAE98
    if (ctx->r2 != ctx->r1) {
        // 0x802FAE88: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FAE98;
    }
    // 0x802FAE88: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FAE8C: bne         $t6, $at, L_802FAE98
    if (ctx->r14 != ctx->r1) {
        // 0x802FAE90: nop
    
            goto L_802FAE98;
    }
    // 0x802FAE90: nop

    // 0x802FAE94: break       6
    do_break(2150608532);
L_802FAE98:
    // 0x802FAE98: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FAE9C: lui         $at, 0x4300
    ctx->r1 = S32(0X4300 << 16);
    // 0x802FAEA0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FAEA4: b           L_802FAED4
    // 0x802FAEA8: div.s       $f0, $f6, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
        goto L_802FAED4;
    // 0x802FAEA8: div.s       $f0, $f6, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FAEAC: lbu         $t3, 0x23F($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X23F);
L_802FAEB0:
    // 0x802FAEB0: lbu         $t0, 0x23D($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X23D);
    // 0x802FAEB4: lui         $at, 0x4300
    ctx->r1 = S32(0X4300 << 16);
    // 0x802FAEB8: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x802FAEBC: mtc1        $t4, $f10
    ctx->f10.u32l = ctx->r12;
    // 0x802FAEC0: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x802FAEC4: sll         $t2, $t0, 7
    ctx->r10 = S32(ctx->r8 << 7);
    // 0x802FAEC8: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FAECC: or          $t0, $t2, $zero
    ctx->r8 = ctx->r10 | 0;
    // 0x802FAED0: div.s       $f0, $f16, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f0.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
L_802FAED4:
    // 0x802FAED4: andi        $t5, $a2, 0x1
    ctx->r13 = ctx->r6 & 0X1;
    // 0x802FAED8: beq         $t5, $zero, L_802FAF3C
    if (ctx->r13 == 0) {
        // 0x802FAEDC: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802FAF3C;
    }
    // 0x802FAEDC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FAEE0: lbu         $a1, 0x23C($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X23C);
    // 0x802FAEE4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FAEE8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FAEEC: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x802FAEF0: sll         $a2, $t0, 16
    ctx->r6 = S32(ctx->r8 << 16);
    // 0x802FAEF4: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802FAEF8: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x802FAEFC: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802FAF00: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x802FAF04: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x802FAF08: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x802FAF0C: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802FAF10: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FAF14: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x802FAF18: lw          $t2, 0x1C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X1C);
    // 0x802FAF1C: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    // 0x802FAF20: lw          $t3, 0x20($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X20);
    // 0x802FAF24: sw          $t3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r11;
    // 0x802FAF28: lw          $t4, 0x24($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X24);
    // 0x802FAF2C: jal         0x8032CED0
    // 0x802FAF30: sw          $t4, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r12;
    func_8032CED0_73E580(rdram, ctx);
        goto after_0;
    // 0x802FAF30: sw          $t4, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r12;
    after_0:
    // 0x802FAF34: b           L_802FAF58
    // 0x802FAF38: lh          $v0, 0x242($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X242);
        goto L_802FAF58;
    // 0x802FAF38: lh          $v0, 0x242($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X242);
L_802FAF3C:
    // 0x802FAF3C: sll         $a2, $t0, 16
    ctx->r6 = S32(ctx->r8 << 16);
    // 0x802FAF40: sra         $t5, $a2, 16
    ctx->r13 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802FAF44: lbu         $a1, 0x23C($s0)
    ctx->r5 = MEM_BU(ctx->r16, 0X23C);
    // 0x802FAF48: swc1        $f0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f0.u32l;
    // 0x802FAF4C: jal         0x8032CD20
    // 0x802FAF50: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    func_8032CD20_73E3D0(rdram, ctx);
        goto after_1;
    // 0x802FAF50: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
    after_1:
    // 0x802FAF54: lh          $v0, 0x242($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X242);
L_802FAF58:
    // 0x802FAF58: bltzl       $v0, L_802FAF80
    if (SIGNED(ctx->r2) < 0) {
        // 0x802FAF5C: lh          $v0, 0x20C($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X20C);
            goto L_802FAF80;
    }
    goto skip_2;
    // 0x802FAF5C: lh          $v0, 0x20C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X20C);
    skip_2:
    // 0x802FAF60: lhu         $v1, 0x244($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X244);
    // 0x802FAF64: slt         $a0, $v1, $v0
    ctx->r4 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802FAF68: xori        $a0, $a0, 0x1
    ctx->r4 = ctx->r4 ^ 0X1;
    // 0x802FAF6C: addiu       $t6, $v1, 0x1
    ctx->r14 = ADD32(ctx->r3, 0X1);
    // 0x802FAF70: beq         $a0, $zero, L_802FAF7C
    if (ctx->r4 == 0) {
        // 0x802FAF74: sh          $t6, 0x244($s0)
        MEM_H(0X244, ctx->r16) = ctx->r14;
            goto L_802FAF7C;
    }
    // 0x802FAF74: sh          $t6, 0x244($s0)
    MEM_H(0X244, ctx->r16) = ctx->r14;
    // 0x802FAF78: sb          $zero, 0x241($s0)
    MEM_B(0X241, ctx->r16) = 0;
L_802FAF7C:
    // 0x802FAF7C: lh          $v0, 0x20C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X20C);
L_802FAF80:
    // 0x802FAF80: beql        $v0, $zero, L_802FAFDC
    if (ctx->r2 == 0) {
        // 0x802FAF84: lbu         $v0, 0x170($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X170);
            goto L_802FAFDC;
    }
    goto skip_3;
    // 0x802FAF84: lbu         $v0, 0x170($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X170);
    skip_3:
    // 0x802FAF88: lw          $t7, 0x16C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X16C);
    // 0x802FAF8C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802FAF90: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x802FAF94: beql        $t8, $at, L_802FAFDC
    if (ctx->r24 == ctx->r1) {
        // 0x802FAF98: lbu         $v0, 0x170($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X170);
            goto L_802FAFDC;
    }
    goto skip_4;
    // 0x802FAF98: lbu         $v0, 0x170($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X170);
    skip_4:
    // 0x802FAF9C: lw          $t4, 0x158($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X158);
    // 0x802FAFA0: lhu         $a3, 0x42($s0)
    ctx->r7 = MEM_HU(ctx->r16, 0X42);
    // 0x802FAFA4: lh          $a1, 0x2E($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2E);
    // 0x802FAFA8: lh          $a2, 0x2C($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X2C);
    // 0x802FAFAC: sw          $v0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r2;
    // 0x802FAFB0: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802FAFB4: lh          $t5, 0x210($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X210);
    // 0x802FAFB8: sra         $t9, $a3, 1
    ctx->r25 = S32(SIGNED(ctx->r7) >> 1);
    // 0x802FAFBC: sll         $t2, $t9, 16
    ctx->r10 = S32(ctx->r25 << 16);
    // 0x802FAFC0: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802FAFC4: lhu         $t6, 0x20E($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X20E);
    // 0x802FAFC8: sra         $a3, $t2, 16
    ctx->r7 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802FAFCC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FAFD0: jal         0x802F705C
    // 0x802FAFD4: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_802F705C_70870C(rdram, ctx);
        goto after_2;
    // 0x802FAFD4: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_2:
    // 0x802FAFD8: lbu         $v0, 0x170($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X170);
L_802FAFDC:
    // 0x802FAFDC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802FAFE0: bnel        $v0, $at, L_802FAFFC
    if (ctx->r2 != ctx->r1) {
        // 0x802FAFE4: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802FAFFC;
    }
    goto skip_5;
    // 0x802FAFE4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    skip_5:
    // 0x802FAFE8: jal         0x802FA4F8
    // 0x802FAFEC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FA4F8_70BBA8(rdram, ctx);
        goto after_3;
    // 0x802FAFEC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_3:
    // 0x802FAFF0: b           L_802FB064
    // 0x802FAFF4: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
        goto L_802FB064;
    // 0x802FAFF4: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
    // 0x802FAFF8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
L_802FAFFC:
    // 0x802FAFFC: bnel        $v0, $at, L_802FB018
    if (ctx->r2 != ctx->r1) {
        // 0x802FB000: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_802FB018;
    }
    goto skip_6;
    // 0x802FB000: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    skip_6:
    // 0x802FB004: jal         0x802F65BC
    // 0x802FB008: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F65BC_707C6C(rdram, ctx);
        goto after_4;
    // 0x802FB008: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_4:
    // 0x802FB00C: b           L_802FB064
    // 0x802FB010: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
        goto L_802FB064;
    // 0x802FB010: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
    // 0x802FB014: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
L_802FB018:
    // 0x802FB018: bnel        $v0, $at, L_802FB034
    if (ctx->r2 != ctx->r1) {
        // 0x802FB01C: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_802FB034;
    }
    goto skip_7;
    // 0x802FB01C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    skip_7:
    // 0x802FB020: jal         0x802F6750
    // 0x802FB024: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F6750_707E00(rdram, ctx);
        goto after_5;
    // 0x802FB024: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_5:
    // 0x802FB028: b           L_802FB064
    // 0x802FB02C: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
        goto L_802FB064;
    // 0x802FB02C: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
    // 0x802FB030: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
L_802FB034:
    // 0x802FB034: bnel        $v0, $at, L_802FB050
    if (ctx->r2 != ctx->r1) {
        // 0x802FB038: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802FB050;
    }
    goto skip_8;
    // 0x802FB038: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    skip_8:
    // 0x802FB03C: jal         0x802F68A0
    // 0x802FB040: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    head_towards_waypoint(rdram, ctx);
        goto after_6;
    // 0x802FB040: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_6:
    // 0x802FB044: b           L_802FB064
    // 0x802FB048: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
        goto L_802FB064;
    // 0x802FB048: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
    // 0x802FB04C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
L_802FB050:
    // 0x802FB050: bnel        $v0, $at, L_802FB064
    if (ctx->r2 != ctx->r1) {
        // 0x802FB054: lhu         $t7, 0x21E($s0)
        ctx->r15 = MEM_HU(ctx->r16, 0X21E);
            goto L_802FB064;
    }
    goto skip_9;
    // 0x802FB054: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
    skip_9:
    // 0x802FB058: jal         0x802F68A0
    // 0x802FB05C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    head_towards_waypoint(rdram, ctx);
        goto after_7;
    // 0x802FB05C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_7:
    // 0x802FB060: lhu         $t7, 0x21E($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X21E);
L_802FB064:
    // 0x802FB064: andi        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 & 0X1;
    // 0x802FB068: beql        $t8, $zero, L_802FB07C
    if (ctx->r24 == 0) {
        // 0x802FB06C: lbu         $v0, 0x22C($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X22C);
            goto L_802FB07C;
    }
    goto skip_10;
    // 0x802FB06C: lbu         $v0, 0x22C($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X22C);
    skip_10:
    // 0x802FB070: jal         0x802FA730
    // 0x802FB074: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FA730_70BDE0(rdram, ctx);
        goto after_8;
    // 0x802FB074: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_8:
    // 0x802FB078: lbu         $v0, 0x22C($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X22C);
L_802FB07C:
    // 0x802FB07C: beq         $v0, $zero, L_802FB25C
    if (ctx->r2 == 0) {
        // 0x802FB080: andi        $t9, $v0, 0x10
        ctx->r25 = ctx->r2 & 0X10;
            goto L_802FB25C;
    }
    // 0x802FB080: andi        $t9, $v0, 0x10
    ctx->r25 = ctx->r2 & 0X10;
    // 0x802FB084: beq         $t9, $zero, L_802FB0C0
    if (ctx->r25 == 0) {
        // 0x802FB088: andi        $t2, $v0, 0x4
        ctx->r10 = ctx->r2 & 0X4;
            goto L_802FB0C0;
    }
    // 0x802FB088: andi        $t2, $v0, 0x4
    ctx->r10 = ctx->r2 & 0X4;
    // 0x802FB08C: lh          $t2, 0x2E($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2E);
    // 0x802FB090: lh          $t3, 0x22E($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X22E);
    // 0x802FB094: lh          $t6, 0x2C($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2C);
    // 0x802FB098: lh          $t7, 0x232($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X232);
    // 0x802FB09C: addu        $a1, $t2, $t3
    ctx->r5 = ADD32(ctx->r10, ctx->r11);
    // 0x802FB0A0: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x802FB0A4: addu        $a2, $t6, $t7
    ctx->r6 = ADD32(ctx->r14, ctx->r15);
    // 0x802FB0A8: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802FB0AC: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FB0B0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FB0B4: sh          $t9, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r25;
    // 0x802FB0B8: b           L_802FB1B8
    // 0x802FB0BC: sh          $t5, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r13;
        goto L_802FB1B8;
    // 0x802FB0BC: sh          $t5, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r13;
L_802FB0C0:
    // 0x802FB0C0: beql        $t2, $zero, L_802FB10C
    if (ctx->r10 == 0) {
        // 0x802FB0C4: lh          $v0, 0x230($s0)
        ctx->r2 = MEM_H(ctx->r16, 0X230);
            goto L_802FB10C;
    }
    goto skip_11;
    // 0x802FB0C4: lh          $v0, 0x230($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X230);
    skip_11:
    // 0x802FB0C8: lh          $a2, 0x22E($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X22E);
    // 0x802FB0CC: lh          $v0, 0x230($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X230);
    // 0x802FB0D0: lh          $t0, 0x236($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X236);
    // 0x802FB0D4: multu       $a2, $v0
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB0D8: mflo        $t3
    ctx->r11 = lo;
    // 0x802FB0DC: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x802FB0E0: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x802FB0E4: sh          $t5, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r13;
    // 0x802FB0E8: lh          $a3, 0x232($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X232);
    // 0x802FB0EC: lh          $t1, 0x23A($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X23A);
    // 0x802FB0F0: multu       $a3, $v0
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB0F4: mflo        $t6
    ctx->r14 = lo;
    // 0x802FB0F8: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x802FB0FC: addu        $t8, $t1, $t7
    ctx->r24 = ADD32(ctx->r9, ctx->r15);
    // 0x802FB100: b           L_802FB170
    // 0x802FB104: sh          $t8, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r24;
        goto L_802FB170;
    // 0x802FB104: sh          $t8, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r24;
    // 0x802FB108: lh          $v0, 0x230($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X230);
L_802FB10C:
    // 0x802FB10C: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x802FB110: lh          $a2, 0x22E($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X22E);
    // 0x802FB114: sra         $t3, $v0, 1
    ctx->r11 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802FB118: addiu       $t4, $t3, 0x40
    ctx->r12 = ADD32(ctx->r11, 0X40);
    // 0x802FB11C: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x802FB120: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802FB124: addu        $v1, $v1, $t6
    ctx->r3 = ADD32(ctx->r3, ctx->r14);
    // 0x802FB128: lh          $v1, 0x2C78($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2C78);
    // 0x802FB12C: sra         $a0, $a2, 1
    ctx->r4 = S32(SIGNED(ctx->r6) >> 1);
    // 0x802FB130: lh          $t0, 0x236($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X236);
    // 0x802FB134: multu       $a0, $v1
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB138: addu        $t7, $t0, $a0
    ctx->r15 = ADD32(ctx->r8, ctx->r4);
    // 0x802FB13C: mflo        $t8
    ctx->r24 = lo;
    // 0x802FB140: sra         $t9, $t8, 15
    ctx->r25 = S32(SIGNED(ctx->r24) >> 15);
    // 0x802FB144: subu        $t2, $t7, $t9
    ctx->r10 = SUB32(ctx->r15, ctx->r25);
    // 0x802FB148: sh          $t2, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r10;
    // 0x802FB14C: lh          $a3, 0x232($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X232);
    // 0x802FB150: lh          $t1, 0x23A($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X23A);
    // 0x802FB154: sra         $a1, $a3, 1
    ctx->r5 = S32(SIGNED(ctx->r7) >> 1);
    // 0x802FB158: multu       $a1, $v1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB15C: addu        $t3, $t1, $a1
    ctx->r11 = ADD32(ctx->r9, ctx->r5);
    // 0x802FB160: mflo        $t4
    ctx->r12 = lo;
    // 0x802FB164: sra         $t5, $t4, 15
    ctx->r13 = S32(SIGNED(ctx->r12) >> 15);
    // 0x802FB168: subu        $t6, $t3, $t5
    ctx->r14 = SUB32(ctx->r11, ctx->r13);
    // 0x802FB16C: sh          $t6, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r14;
L_802FB170:
    // 0x802FB170: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x802FB174: bnel        $at, $zero, L_802FB198
    if (ctx->r1 != 0) {
        // 0x802FB178: lbu         $t9, 0x22D($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X22D);
            goto L_802FB198;
    }
    goto skip_12;
    // 0x802FB178: lbu         $t9, 0x22D($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X22D);
    skip_12:
    // 0x802FB17C: sb          $zero, 0x22C($s0)
    MEM_B(0X22C, ctx->r16) = 0;
    // 0x802FB180: addu        $t8, $t0, $a2
    ctx->r24 = ADD32(ctx->r8, ctx->r6);
    // 0x802FB184: addu        $t7, $t1, $a3
    ctx->r15 = ADD32(ctx->r9, ctx->r7);
    // 0x802FB188: sh          $t8, 0x44($sp)
    MEM_H(0X44, ctx->r29) = ctx->r24;
    // 0x802FB18C: b           L_802FB1B8
    // 0x802FB190: sh          $t7, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r15;
        goto L_802FB1B8;
    // 0x802FB190: sh          $t7, 0x42($sp)
    MEM_H(0X42, ctx->r29) = ctx->r15;
    // 0x802FB194: lbu         $t9, 0x22D($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X22D);
L_802FB198:
    // 0x802FB198: addu        $t2, $v0, $t9
    ctx->r10 = ADD32(ctx->r2, ctx->r25);
    // 0x802FB19C: sh          $t2, 0x230($s0)
    MEM_H(0X230, ctx->r16) = ctx->r10;
    // 0x802FB1A0: lh          $t4, 0x230($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X230);
    // 0x802FB1A4: slti        $at, $t4, 0x101
    ctx->r1 = SIGNED(ctx->r12) < 0X101 ? 1 : 0;
    // 0x802FB1A8: bnel        $at, $zero, L_802FB1BC
    if (ctx->r1 != 0) {
        // 0x802FB1AC: addiu       $v0, $zero, 0x168
        ctx->r2 = ADD32(0, 0X168);
            goto L_802FB1BC;
    }
    goto skip_13;
    // 0x802FB1AC: addiu       $v0, $zero, 0x168
    ctx->r2 = ADD32(0, 0X168);
    skip_13:
    // 0x802FB1B0: addiu       $t3, $zero, 0x100
    ctx->r11 = ADD32(0, 0X100);
    // 0x802FB1B4: sh          $t3, 0x230($s0)
    MEM_H(0X230, ctx->r16) = ctx->r11;
L_802FB1B8:
    // 0x802FB1B8: addiu       $v0, $zero, 0x168
    ctx->r2 = ADD32(0, 0X168);
L_802FB1BC:
    // 0x802FB1BC: lh          $a1, 0x44($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X44);
    // 0x802FB1C0: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FB1C4: lw          $t9, 0x16C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X16C);
    // 0x802FB1C8: div         $zero, $a1, $v0
    lo = S32(S64(S32(ctx->r5)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r5)) % S64(S32(ctx->r2)));
    // 0x802FB1CC: bne         $v0, $zero, L_802FB1D8
    if (ctx->r2 != 0) {
        // 0x802FB1D0: nop
    
            goto L_802FB1D8;
    }
    // 0x802FB1D0: nop

    // 0x802FB1D4: break       7
    do_break(2150609364);
L_802FB1D8:
    // 0x802FB1D8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FB1DC: bne         $v0, $at, L_802FB1F0
    if (ctx->r2 != ctx->r1) {
        // 0x802FB1E0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FB1F0;
    }
    // 0x802FB1E0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FB1E4: bne         $a1, $at, L_802FB1F0
    if (ctx->r5 != ctx->r1) {
        // 0x802FB1E8: nop
    
            goto L_802FB1F0;
    }
    // 0x802FB1E8: nop

    // 0x802FB1EC: break       6
    do_break(2150609388);
L_802FB1F0:
    // 0x802FB1F0: mfhi        $a1
    ctx->r5 = hi;
    // 0x802FB1F4: lbu         $t2, 0x15($t9)
    ctx->r10 = MEM_BU(ctx->r25, 0X15);
    // 0x802FB1F8: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x802FB1FC: div         $zero, $a2, $v0
    lo = S32(S64(S32(ctx->r6)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r6)) % S64(S32(ctx->r2)));
    // 0x802FB200: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FB204: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802FB208: bne         $v0, $zero, L_802FB214
    if (ctx->r2 != 0) {
        // 0x802FB20C: nop
    
            goto L_802FB214;
    }
    // 0x802FB20C: nop

    // 0x802FB210: break       7
    do_break(2150609424);
L_802FB214:
    // 0x802FB214: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FB218: bne         $v0, $at, L_802FB22C
    if (ctx->r2 != ctx->r1) {
        // 0x802FB21C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FB22C;
    }
    // 0x802FB21C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FB220: bne         $a2, $at, L_802FB22C
    if (ctx->r6 != ctx->r1) {
        // 0x802FB224: nop
    
            goto L_802FB22C;
    }
    // 0x802FB224: nop

    // 0x802FB228: break       6
    do_break(2150609448);
L_802FB22C:
    // 0x802FB22C: mfhi        $a2
    ctx->r6 = hi;
    // 0x802FB230: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802FB234: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FB238: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802FB23C: bne         $t2, $at, L_802FB254
    if (ctx->r10 != ctx->r1) {
        // 0x802FB240: or          $a2, $t7, $zero
        ctx->r6 = ctx->r15 | 0;
            goto L_802FB254;
    }
    // 0x802FB240: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x802FB244: jal         0x802C9918
    // 0x802FB248: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802C9918_6DAFC8(rdram, ctx);
        goto after_9;
    // 0x802FB248: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_9:
    // 0x802FB24C: b           L_802FB260
    // 0x802FB250: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
        goto L_802FB260;
    // 0x802FB250: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_802FB254:
    // 0x802FB254: sh          $a1, 0x2E($s0)
    MEM_H(0X2E, ctx->r16) = ctx->r5;
    // 0x802FB258: sh          $a2, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r6;
L_802FB25C:
    // 0x802FB25C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_802FB260:
    // 0x802FB260: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802FB264: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    // 0x802FB268: jr          $ra
    // 0x802FB26C: nop

    return;
    // 0x802FB26C: nop

;}
RECOMP_FUNC void func_802FB270_70C920(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FB270: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802FB274: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802FB278: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802FB27C: lw          $v0, 0x4C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X4C);
    // 0x802FB280: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FB284: sll         $v1, $v0, 28
    ctx->r3 = S32(ctx->r2 << 28);
    // 0x802FB288: srl         $t6, $v1, 31
    ctx->r14 = S32(U32(ctx->r3) >> 31);
    // 0x802FB28C: bne         $t6, $zero, L_802FB2A0
    if (ctx->r14 != 0) {
        // 0x802FB290: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_802FB2A0;
    }
    // 0x802FB290: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x802FB294: sll         $t8, $v0, 29
    ctx->r24 = S32(ctx->r2 << 29);
    // 0x802FB298: bgez        $t8, L_802FB2B8
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FB29C: nop
    
            goto L_802FB2B8;
    }
    // 0x802FB29C: nop

L_802FB2A0:
    // 0x802FB2A0: jal         0x802C9F60
    // 0x802FB2A4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    update_entity_physics(rdram, ctx);
        goto after_0;
    // 0x802FB2A4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802FB2A8: lw          $v0, 0x4C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4C);
    // 0x802FB2AC: sll         $v1, $v0, 28
    ctx->r3 = S32(ctx->r2 << 28);
    // 0x802FB2B0: srl         $t9, $v1, 31
    ctx->r25 = S32(U32(ctx->r3) >> 31);
    // 0x802FB2B4: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
L_802FB2B8:
    // 0x802FB2B8: beq         $v1, $zero, L_802FB2C8
    if (ctx->r3 == 0) {
        // 0x802FB2BC: sll         $t1, $v0, 29
        ctx->r9 = S32(ctx->r2 << 29);
            goto L_802FB2C8;
    }
    // 0x802FB2BC: sll         $t1, $v0, 29
    ctx->r9 = S32(ctx->r2 << 29);
    // 0x802FB2C0: bltzl       $t1, L_802FB2D4
    if (SIGNED(ctx->r9) < 0) {
        // 0x802FB2C4: lw          $t2, 0x1A8($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X1A8);
            goto L_802FB2D4;
    }
    goto skip_0;
    // 0x802FB2C4: lw          $t2, 0x1A8($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X1A8);
    skip_0:
L_802FB2C8:
    // 0x802FB2C8: jal         0x802F90A8
    // 0x802FB2CC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F90A8_70A758(rdram, ctx);
        goto after_1;
    // 0x802FB2CC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x802FB2D0: lw          $t2, 0x1A8($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X1A8);
L_802FB2D4:
    // 0x802FB2D4: beq         $t2, $zero, L_802FB2E4
    if (ctx->r10 == 0) {
        // 0x802FB2D8: nop
    
            goto L_802FB2E4;
    }
    // 0x802FB2D8: nop

    // 0x802FB2DC: jal         0x803191B0
    // 0x802FB2E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_803191B0_72A860(rdram, ctx);
        goto after_2;
    // 0x802FB2E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
L_802FB2E4:
    // 0x802FB2E4: jal         0x802FADBC
    // 0x802FB2E8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FADBC_70C46C(rdram, ctx);
        goto after_3;
    // 0x802FB2E8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_3:
    // 0x802FB2EC: lw          $t3, 0x4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X4);
    // 0x802FB2F0: lw          $t4, 0x1C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X1C);
    // 0x802FB2F4: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x802FB2F8: lw          $t7, 0x20($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X20);
    // 0x802FB2FC: lw          $t9, 0xC($s0)
    ctx->r25 = MEM_W(ctx->r16, 0XC);
    // 0x802FB300: lw          $t0, 0x24($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X24);
    // 0x802FB304: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x802FB308: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802FB30C: addu        $t1, $t9, $t0
    ctx->r9 = ADD32(ctx->r25, ctx->r8);
    // 0x802FB310: sw          $t5, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r13;
    // 0x802FB314: sw          $t8, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r24;
    // 0x802FB318: sw          $t1, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r9;
    // 0x802FB31C: jal         0x802F5C60
    // 0x802FB320: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802F5C60_707310(rdram, ctx);
        goto after_4;
    // 0x802FB320: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_4:
    // 0x802FB324: lw          $t2, 0x4C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4C);
    // 0x802FB328: sll         $t4, $t2, 26
    ctx->r12 = S32(ctx->r10 << 26);
    // 0x802FB32C: bltzl       $t4, L_802FB43C
    if (SIGNED(ctx->r12) < 0) {
        // 0x802FB330: lw          $t2, 0x4C($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X4C);
            goto L_802FB43C;
    }
    goto skip_1;
    // 0x802FB330: lw          $t2, 0x4C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4C);
    skip_1:
    // 0x802FB334: lw          $v0, 0x16C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X16C);
    // 0x802FB338: lbu         $t5, 0x88($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X88);
    // 0x802FB33C: sltiu       $at, $t5, 0x6
    ctx->r1 = ctx->r13 < 0X6 ? 1 : 0;
    // 0x802FB340: beq         $at, $zero, L_802FB42C
    if (ctx->r1 == 0) {
        // 0x802FB344: sll         $t5, $t5, 2
        ctx->r13 = S32(ctx->r13 << 2);
            goto L_802FB42C;
    }
    // 0x802FB344: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802FB348: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802FB34C: addu        $at, $at, $t5
    gpr jr_addend_802FB354 = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x802FB350: lw          $t5, -0x30EC($at)
    ctx->r13 = ADD32(ctx->r1, -0X30EC);
    // 0x802FB354: jr          $t5
    // 0x802FB358: nop

    switch (jr_addend_802FB354 >> 2) {
        case 0: goto L_802FB35C; break;
        case 1: goto L_802FB378; break;
        case 2: goto L_802FB42C; break;
        case 3: goto L_802FB3BC; break;
        case 4: goto L_802FB3DC; break;
        case 5: goto L_802FB3FC; break;
        default: switch_error(__func__, 0x802FB354, 0x803BCF14);
    }
    // 0x802FB358: nop

L_802FB35C:
    // 0x802FB35C: lh          $t6, 0x14C($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X14C);
    // 0x802FB360: bgtzl       $t6, L_802FB430
    if (SIGNED(ctx->r14) > 0) {
        // 0x802FB364: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_2;
    // 0x802FB364: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_2:
    // 0x802FB368: jal         0x802FC990
    // 0x802FB36C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_5;
    // 0x802FB36C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_5:
    // 0x802FB370: b           L_802FB430
    // 0x802FB374: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
        goto L_802FB430;
    // 0x802FB374: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
L_802FB378:
    // 0x802FB378: lbu         $t7, 0x5C($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X5C);
    // 0x802FB37C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802FB380: andi        $t8, $t7, 0x4
    ctx->r24 = ctx->r15 & 0X4;
    // 0x802FB384: beql        $t8, $zero, L_802FB430
    if (ctx->r24 == 0) {
        // 0x802FB388: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_3;
    // 0x802FB388: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_3:
    // 0x802FB38C: lh          $t0, 0x5534($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X5534);
    // 0x802FB390: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x802FB394: lw          $t9, 0x60($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X60);
    // 0x802FB398: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x802FB39C: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x802FB3A0: lw          $t2, -0x2274($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X2274);
    // 0x802FB3A4: bnel        $t9, $t2, L_802FB430
    if (ctx->r25 != ctx->r10) {
        // 0x802FB3A8: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_4;
    // 0x802FB3A8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_4:
    // 0x802FB3AC: jal         0x802FC990
    // 0x802FB3B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_6;
    // 0x802FB3B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_6:
    // 0x802FB3B4: b           L_802FB430
    // 0x802FB3B8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
        goto L_802FB430;
    // 0x802FB3B8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
L_802FB3BC:
    // 0x802FB3BC: lbu         $t3, 0x5C($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X5C);
    // 0x802FB3C0: andi        $t4, $t3, 0x8
    ctx->r12 = ctx->r11 & 0X8;
    // 0x802FB3C4: beql        $t4, $zero, L_802FB430
    if (ctx->r12 == 0) {
        // 0x802FB3C8: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_5;
    // 0x802FB3C8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_5:
    // 0x802FB3CC: jal         0x802FC990
    // 0x802FB3D0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_7;
    // 0x802FB3D0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_7:
    // 0x802FB3D4: b           L_802FB430
    // 0x802FB3D8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
        goto L_802FB430;
    // 0x802FB3D8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
L_802FB3DC:
    // 0x802FB3DC: lbu         $t5, 0x5C($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X5C);
    // 0x802FB3E0: andi        $t6, $t5, 0x5
    ctx->r14 = ctx->r13 & 0X5;
    // 0x802FB3E4: beql        $t6, $zero, L_802FB430
    if (ctx->r14 == 0) {
        // 0x802FB3E8: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_6;
    // 0x802FB3E8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_6:
    // 0x802FB3EC: jal         0x802FC990
    // 0x802FB3F0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_8;
    // 0x802FB3F0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_8:
    // 0x802FB3F4: b           L_802FB430
    // 0x802FB3F8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
        goto L_802FB430;
    // 0x802FB3F8: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
L_802FB3FC:
    // 0x802FB3FC: lbu         $v1, 0x5C($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X5C);
    // 0x802FB400: andi        $t7, $v1, 0x1
    ctx->r15 = ctx->r3 & 0X1;
    // 0x802FB404: beq         $t7, $zero, L_802FB41C
    if (ctx->r15 == 0) {
        // 0x802FB408: andi        $t1, $v1, 0x6
        ctx->r9 = ctx->r3 & 0X6;
            goto L_802FB41C;
    }
    // 0x802FB408: andi        $t1, $v1, 0x6
    ctx->r9 = ctx->r3 & 0X6;
    // 0x802FB40C: lhu         $t8, 0x0($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X0);
    // 0x802FB410: lbu         $t0, 0x5D($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X5D);
    // 0x802FB414: bne         $t8, $t0, L_802FB424
    if (ctx->r24 != ctx->r8) {
        // 0x802FB418: nop
    
            goto L_802FB424;
    }
    // 0x802FB418: nop

L_802FB41C:
    // 0x802FB41C: beql        $t1, $zero, L_802FB430
    if (ctx->r9 == 0) {
        // 0x802FB420: lbu         $t9, 0x26C($s0)
        ctx->r25 = MEM_BU(ctx->r16, 0X26C);
            goto L_802FB430;
    }
    goto skip_7;
    // 0x802FB420: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
    skip_7:
L_802FB424:
    // 0x802FB424: jal         0x802FC990
    // 0x802FB428: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_9;
    // 0x802FB428: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_9:
L_802FB42C:
    // 0x802FB42C: lbu         $t9, 0x26C($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X26C);
L_802FB430:
    // 0x802FB430: bnel        $t9, $zero, L_802FB48C
    if (ctx->r25 != 0) {
        // 0x802FB434: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_802FB48C;
    }
    goto skip_8;
    // 0x802FB434: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_8:
    // 0x802FB438: lw          $t2, 0x4C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X4C);
L_802FB43C:
    // 0x802FB43C: sll         $t4, $t2, 26
    ctx->r12 = S32(ctx->r10 << 26);
    // 0x802FB440: bltz        $t4, L_802FB46C
    if (SIGNED(ctx->r12) < 0) {
        // 0x802FB444: nop
    
            goto L_802FB46C;
    }
    // 0x802FB444: nop

    // 0x802FB448: lbu         $v0, 0x154($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X154);
    // 0x802FB44C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FB450: beq         $v0, $zero, L_802FB46C
    if (ctx->r2 == 0) {
        // 0x802FB454: addiu       $t5, $v0, -0x1
        ctx->r13 = ADD32(ctx->r2, -0X1);
            goto L_802FB46C;
    }
    // 0x802FB454: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x802FB458: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802FB45C: bne         $t6, $at, L_802FB46C
    if (ctx->r14 != ctx->r1) {
        // 0x802FB460: sb          $t5, 0x154($s0)
        MEM_B(0X154, ctx->r16) = ctx->r13;
            goto L_802FB46C;
    }
    // 0x802FB460: sb          $t5, 0x154($s0)
    MEM_B(0X154, ctx->r16) = ctx->r13;
    // 0x802FB464: jal         0x802FC990
    // 0x802FB468: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    run_commands(rdram, ctx);
        goto after_10;
    // 0x802FB468: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_10:
L_802FB46C:
    // 0x802FB46C: jal         0x802FB49C
    // 0x802FB470: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FB49C_70CB4C(rdram, ctx);
        goto after_11;
    // 0x802FB470: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_11:
    // 0x802FB474: lbu         $v0, 0x15C($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X15C);
    // 0x802FB478: sb          $zero, 0x65($s0)
    MEM_B(0X65, ctx->r16) = 0;
    // 0x802FB47C: blez        $v0, L_802FB488
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802FB480: addiu       $t7, $v0, -0x1
        ctx->r15 = ADD32(ctx->r2, -0X1);
            goto L_802FB488;
    }
    // 0x802FB480: addiu       $t7, $v0, -0x1
    ctx->r15 = ADD32(ctx->r2, -0X1);
    // 0x802FB484: sb          $t7, 0x15C($s0)
    MEM_B(0X15C, ctx->r16) = ctx->r15;
L_802FB488:
    // 0x802FB488: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_802FB48C:
    // 0x802FB48C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802FB490: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802FB494: jr          $ra
    // 0x802FB498: nop

    return;
    // 0x802FB498: nop

;}
RECOMP_FUNC void func_802FB49C_70CB4C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FB49C: lw          $at, 0x54($a0)
    ctx->r1 = MEM_W(ctx->r4, 0X54);
    // 0x802FB4A0: lw          $t8, 0x58($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X58);
    // 0x802FB4A4: sb          $zero, 0x54($a0)
    MEM_B(0X54, ctx->r4) = 0;
    // 0x802FB4A8: sb          $zero, 0x55($a0)
    MEM_B(0X55, ctx->r4) = 0;
    // 0x802FB4AC: sb          $zero, 0x56($a0)
    MEM_B(0X56, ctx->r4) = 0;
    // 0x802FB4B0: sb          $zero, 0x57($a0)
    MEM_B(0X57, ctx->r4) = 0;
    // 0x802FB4B4: sw          $at, 0x5C($a0)
    MEM_W(0X5C, ctx->r4) = ctx->r1;
    // 0x802FB4B8: jr          $ra
    // 0x802FB4BC: sw          $t8, 0x60($a0)
    MEM_W(0X60, ctx->r4) = ctx->r24;
    return;
    // 0x802FB4BC: sw          $t8, 0x60($a0)
    MEM_W(0X60, ctx->r4) = ctx->r24;
;}
RECOMP_FUNC void func_802FB4C0_70CB70(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FB4C0: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FB4C4: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FB4C8: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FB4CC: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FB4D0: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FB4D4: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FB4D8: bne         $v0, $zero, L_802FB4F8
    if (ctx->r2 != 0) {
        // 0x802FB4DC: addiu       $t9, $zero, 0x32
        ctx->r25 = ADD32(0, 0X32);
            goto L_802FB4F8;
    }
    // 0x802FB4DC: addiu       $t9, $zero, 0x32
    ctx->r25 = ADD32(0, 0X32);
    // 0x802FB4E0: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FB4E4: sll         $t6, $t0, 4
    ctx->r14 = S32(ctx->r8 << 4);
    // 0x802FB4E8: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FB4EC: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FB4F0: b           L_802FB504
    // 0x802FB4F4: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FB504;
    // 0x802FB4F4: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FB4F8:
    // 0x802FB4F8: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FB4FC: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FB500: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FB504:
    // 0x802FB504: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FB508: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FB50C: beql        $v0, $zero, L_802FB534
    if (ctx->r2 == 0) {
        // 0x802FB510: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FB534;
    }
    goto skip_0;
    // 0x802FB510: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FB514: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FB518: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FB51C: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FB520: bgezl       $t4, L_802FB534
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FB524: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FB534;
    }
    goto skip_1;
    // 0x802FB524: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FB528: b           L_802FB534
    // 0x802FB52C: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FB534;
    // 0x802FB52C: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FB530: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FB534:
    // 0x802FB534: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FB538: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FB53C: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FB540: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FB544: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FB548: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FB54C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FB550: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FB554: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FB558: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FB55C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FB560: jal         0x802FF184
    // 0x802FB564: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FB564: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FB568: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FB56C: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FB570: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FB574: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FB578: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802FB57C: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802FB580: sra         $t7, $t2, 6
    ctx->r15 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FB584: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FB588: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FB58C: lui         $t1, 0x803C
    ctx->r9 = S32(0X803C << 16);
    // 0x802FB590: addiu       $t1, $t1, 0x740
    ctx->r9 = ADD32(ctx->r9, 0X740);
    // 0x802FB594: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FB598: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802FB59C: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FB5A0: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FB5A4: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FB5A8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FB5AC: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB5B0: beq         $at, $zero, L_802FB5C0
    if (ctx->r1 == 0) {
        // 0x802FB5B4: nop
    
            goto L_802FB5C0;
    }
    // 0x802FB5B4: nop

    // 0x802FB5B8: b           L_802FB5C0
    // 0x802FB5BC: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FB5C0;
    // 0x802FB5BC: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FB5C0:
    // 0x802FB5C0: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FB5C4: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FB5C8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB5CC: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB5D0: beq         $at, $zero, L_802FB5E0
    if (ctx->r1 == 0) {
        // 0x802FB5D4: nop
    
            goto L_802FB5E0;
    }
    // 0x802FB5D4: nop

    // 0x802FB5D8: b           L_802FB5E0
    // 0x802FB5DC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB5E0;
    // 0x802FB5DC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB5E0:
    // 0x802FB5E0: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FB5E4: beq         $at, $zero, L_802FB604
    if (ctx->r1 == 0) {
        // 0x802FB5E8: slt         $at, $v1, $a0
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
            goto L_802FB604;
    }
    // 0x802FB5E8: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB5EC: beq         $at, $zero, L_802FB5FC
    if (ctx->r1 == 0) {
        // 0x802FB5F0: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FB5FC;
    }
    // 0x802FB5F0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FB5F4: b           L_802FB61C
    // 0x802FB5F8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FB61C;
    // 0x802FB5F8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FB5FC:
    // 0x802FB5FC: b           L_802FB61C
    // 0x802FB600: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FB61C;
    // 0x802FB600: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB604:
    // 0x802FB604: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB608: beq         $at, $zero, L_802FB618
    if (ctx->r1 == 0) {
        // 0x802FB60C: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FB618;
    }
    // 0x802FB60C: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB610: b           L_802FB618
    // 0x802FB614: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB618;
    // 0x802FB614: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB618:
    // 0x802FB618: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB61C:
    // 0x802FB61C: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FB620: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x802FB624: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FB628: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FB62C: beq         $at, $zero, L_802FB63C
    if (ctx->r1 == 0) {
        // 0x802FB630: nop
    
            goto L_802FB63C;
    }
    // 0x802FB630: nop

    // 0x802FB634: b           L_802FB63C
    // 0x802FB638: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FB63C;
    // 0x802FB638: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FB63C:
    // 0x802FB63C: lhu         $t3, 0x42($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X42);
    // 0x802FB640: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FB644: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FB648: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x802FB64C: addu        $t5, $v0, $t4
    ctx->r13 = ADD32(ctx->r2, ctx->r12);
    // 0x802FB650: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802FB654: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802FB658: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FB65C: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FB660: sra         $t6, $t7, 2
    ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
    // 0x802FB664: jal         0x802D7BE0
    // 0x802FB668: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FB668: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_1:
    // 0x802FB66C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FB670: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FB674: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FB678: jr          $ra
    // 0x802FB67C: nop

    return;
    // 0x802FB67C: nop

;}
RECOMP_FUNC void func_802FB680_70CD30(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FB680: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FB684: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FB688: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FB68C: lh          $v1, 0x15E($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X15E);
    // 0x802FB690: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FB694: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FB698: bne         $v1, $zero, L_802FB6D4
    if (ctx->r3 != 0) {
        // 0x802FB69C: sll         $v0, $v1, 16
        ctx->r2 = S32(ctx->r3 << 16);
            goto L_802FB6D4;
    }
    // 0x802FB69C: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802FB6A0: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FB6A4: lw          $v1, 0x158($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X158);
    // 0x802FB6A8: sll         $t6, $v0, 5
    ctx->r14 = S32(ctx->r2 << 5);
    // 0x802FB6AC: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FB6B0: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FB6B4: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FB6B8: beq         $v1, $zero, L_802FB6DC
    if (ctx->r3 == 0) {
        // 0x802FB6BC: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_802FB6DC;
    }
    // 0x802FB6BC: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x802FB6C0: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB6C4: mflo        $v0
    ctx->r2 = lo;
    // 0x802FB6C8: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FB6CC: b           L_802FB6DC
    // 0x802FB6D0: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
        goto L_802FB6DC;
    // 0x802FB6D0: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
L_802FB6D4:
    // 0x802FB6D4: sra         $t2, $v0, 16
    ctx->r10 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802FB6D8: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
L_802FB6DC:
    // 0x802FB6DC: lw          $v1, 0x168($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X168);
    // 0x802FB6E0: addiu       $t0, $zero, 0x64
    ctx->r8 = ADD32(0, 0X64);
    // 0x802FB6E4: beql        $v1, $zero, L_802FB70C
    if (ctx->r3 == 0) {
        // 0x802FB6E8: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FB70C;
    }
    goto skip_0;
    // 0x802FB6E8: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_0:
    // 0x802FB6EC: lw          $a0, 0x16C($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X16C);
    // 0x802FB6F0: lw          $t3, 0x80($a0)
    ctx->r11 = MEM_W(ctx->r4, 0X80);
    // 0x802FB6F4: sll         $t5, $t3, 18
    ctx->r13 = S32(ctx->r11 << 18);
    // 0x802FB6F8: bgezl       $t5, L_802FB70C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FB6FC: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FB70C;
    }
    goto skip_1;
    // 0x802FB6FC: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_1:
    // 0x802FB700: b           L_802FB70C
    // 0x802FB704: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
        goto L_802FB70C;
    // 0x802FB704: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
    // 0x802FB708: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
L_802FB70C:
    // 0x802FB70C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802FB710: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x802FB714: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FB718: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FB71C: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802FB720: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FB724: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802FB728: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802FB72C: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802FB730: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x802FB734: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FB738: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FB73C: jal         0x802FF184
    // 0x802FB740: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FB740: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802FB744: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FB748: lui         $t0, 0x803C
    ctx->r8 = S32(0X803C << 16);
    // 0x802FB74C: addiu       $t0, $t0, 0x740
    ctx->r8 = ADD32(ctx->r8, 0X740);
    // 0x802FB750: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FB754: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FB758: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FB75C: sll         $t5, $t4, 7
    ctx->r13 = S32(ctx->r12 << 7);
    // 0x802FB760: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802FB764: sra         $t6, $t2, 6
    ctx->r14 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FB768: sll         $t8, $t6, 3
    ctx->r24 = S32(ctx->r14 << 3);
    // 0x802FB76C: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802FB770: addu        $t9, $t5, $t8
    ctx->r25 = ADD32(ctx->r13, ctx->r24);
    // 0x802FB774: addu        $v0, $t9, $t0
    ctx->r2 = ADD32(ctx->r25, ctx->r8);
    // 0x802FB778: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FB77C: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FB780: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FB784: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FB788: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB78C: beq         $at, $zero, L_802FB79C
    if (ctx->r1 == 0) {
        // 0x802FB790: nop
    
            goto L_802FB79C;
    }
    // 0x802FB790: nop

    // 0x802FB794: b           L_802FB79C
    // 0x802FB798: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FB79C;
    // 0x802FB798: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FB79C:
    // 0x802FB79C: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FB7A0: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FB7A4: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB7A8: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB7AC: beq         $at, $zero, L_802FB7BC
    if (ctx->r1 == 0) {
        // 0x802FB7B0: nop
    
            goto L_802FB7BC;
    }
    // 0x802FB7B0: nop

    // 0x802FB7B4: b           L_802FB7BC
    // 0x802FB7B8: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB7BC;
    // 0x802FB7B8: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB7BC:
    // 0x802FB7BC: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FB7C0: beq         $at, $zero, L_802FB7E0
    if (ctx->r1 == 0) {
        // 0x802FB7C4: slt         $at, $v1, $a0
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
            goto L_802FB7E0;
    }
    // 0x802FB7C4: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB7C8: beq         $at, $zero, L_802FB7D8
    if (ctx->r1 == 0) {
        // 0x802FB7CC: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FB7D8;
    }
    // 0x802FB7CC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FB7D0: b           L_802FB7F8
    // 0x802FB7D4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FB7F8;
    // 0x802FB7D4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FB7D8:
    // 0x802FB7D8: b           L_802FB7F8
    // 0x802FB7DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FB7F8;
    // 0x802FB7DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB7E0:
    // 0x802FB7E0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB7E4: beq         $at, $zero, L_802FB7F4
    if (ctx->r1 == 0) {
        // 0x802FB7E8: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FB7F4;
    }
    // 0x802FB7E8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB7EC: b           L_802FB7F4
    // 0x802FB7F0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB7F4;
    // 0x802FB7F0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB7F4:
    // 0x802FB7F4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB7F8:
    // 0x802FB7F8: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FB7FC: sll         $t1, $v1, 2
    ctx->r9 = S32(ctx->r3 << 2);
    // 0x802FB800: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x802FB804: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802FB808: beq         $at, $zero, L_802FB818
    if (ctx->r1 == 0) {
        // 0x802FB80C: nop
    
            goto L_802FB818;
    }
    // 0x802FB80C: nop

    // 0x802FB810: b           L_802FB818
    // 0x802FB814: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FB818;
    // 0x802FB814: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FB818:
    // 0x802FB818: lhu         $t2, 0x42($s0)
    ctx->r10 = MEM_HU(ctx->r16, 0X42);
    // 0x802FB81C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FB820: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FB824: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802FB828: addu        $t4, $v0, $t3
    ctx->r12 = ADD32(ctx->r2, ctx->r11);
    // 0x802FB82C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802FB830: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802FB834: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FB838: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FB83C: sra         $t6, $t7, 2
    ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
    // 0x802FB840: jal         0x802D7BE0
    // 0x802FB844: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FB844: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_1:
    // 0x802FB848: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FB84C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FB850: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FB854: jr          $ra
    // 0x802FB858: nop

    return;
    // 0x802FB858: nop

;}
RECOMP_FUNC void func_802FB85C_70CF0C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FB85C: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FB860: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FB864: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FB868: lh          $v1, 0x15E($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X15E);
    // 0x802FB86C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FB870: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FB874: bne         $v1, $zero, L_802FB8B0
    if (ctx->r3 != 0) {
        // 0x802FB878: sll         $v0, $v1, 16
        ctx->r2 = S32(ctx->r3 << 16);
            goto L_802FB8B0;
    }
    // 0x802FB878: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802FB87C: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FB880: lw          $v1, 0x158($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X158);
    // 0x802FB884: sll         $t6, $v0, 5
    ctx->r14 = S32(ctx->r2 << 5);
    // 0x802FB888: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FB88C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FB890: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FB894: beq         $v1, $zero, L_802FB8B8
    if (ctx->r3 == 0) {
        // 0x802FB898: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_802FB8B8;
    }
    // 0x802FB898: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x802FB89C: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FB8A0: mflo        $v0
    ctx->r2 = lo;
    // 0x802FB8A4: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FB8A8: b           L_802FB8B8
    // 0x802FB8AC: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
        goto L_802FB8B8;
    // 0x802FB8AC: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
L_802FB8B0:
    // 0x802FB8B0: sra         $t2, $v0, 16
    ctx->r10 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802FB8B4: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
L_802FB8B8:
    // 0x802FB8B8: lw          $v1, 0x168($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X168);
    // 0x802FB8BC: addiu       $t0, $zero, 0x64
    ctx->r8 = ADD32(0, 0X64);
    // 0x802FB8C0: beql        $v1, $zero, L_802FB8E8
    if (ctx->r3 == 0) {
        // 0x802FB8C4: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FB8E8;
    }
    goto skip_0;
    // 0x802FB8C4: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_0:
    // 0x802FB8C8: lw          $a0, 0x16C($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X16C);
    // 0x802FB8CC: lw          $t3, 0x80($a0)
    ctx->r11 = MEM_W(ctx->r4, 0X80);
    // 0x802FB8D0: sll         $t5, $t3, 18
    ctx->r13 = S32(ctx->r11 << 18);
    // 0x802FB8D4: bgezl       $t5, L_802FB8E8
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FB8D8: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FB8E8;
    }
    goto skip_1;
    // 0x802FB8D8: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_1:
    // 0x802FB8DC: b           L_802FB8E8
    // 0x802FB8E0: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
        goto L_802FB8E8;
    // 0x802FB8E0: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
    // 0x802FB8E4: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
L_802FB8E8:
    // 0x802FB8E8: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802FB8EC: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x802FB8F0: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FB8F4: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FB8F8: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802FB8FC: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FB900: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802FB904: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802FB908: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802FB90C: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x802FB910: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FB914: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FB918: jal         0x802FF184
    // 0x802FB91C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FB91C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802FB920: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FB924: lui         $t0, 0x803C
    ctx->r8 = S32(0X803C << 16);
    // 0x802FB928: addiu       $t0, $t0, 0x740
    ctx->r8 = ADD32(ctx->r8, 0X740);
    // 0x802FB92C: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FB930: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FB934: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FB938: sll         $t5, $t4, 7
    ctx->r13 = S32(ctx->r12 << 7);
    // 0x802FB93C: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802FB940: sra         $t6, $t2, 6
    ctx->r14 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FB944: sll         $t8, $t6, 3
    ctx->r24 = S32(ctx->r14 << 3);
    // 0x802FB948: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802FB94C: addu        $t9, $t5, $t8
    ctx->r25 = ADD32(ctx->r13, ctx->r24);
    // 0x802FB950: addu        $v0, $t9, $t0
    ctx->r2 = ADD32(ctx->r25, ctx->r8);
    // 0x802FB954: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FB958: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FB95C: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FB960: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FB964: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB968: beq         $at, $zero, L_802FB978
    if (ctx->r1 == 0) {
        // 0x802FB96C: nop
    
            goto L_802FB978;
    }
    // 0x802FB96C: nop

    // 0x802FB970: b           L_802FB978
    // 0x802FB974: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FB978;
    // 0x802FB974: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FB978:
    // 0x802FB978: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FB97C: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FB980: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB984: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB988: beq         $at, $zero, L_802FB998
    if (ctx->r1 == 0) {
        // 0x802FB98C: nop
    
            goto L_802FB998;
    }
    // 0x802FB98C: nop

    // 0x802FB990: b           L_802FB998
    // 0x802FB994: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB998;
    // 0x802FB994: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB998:
    // 0x802FB998: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FB99C: beq         $at, $zero, L_802FB9C0
    if (ctx->r1 == 0) {
        // 0x802FB9A0: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FB9C0;
    }
    // 0x802FB9A0: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FB9A4: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FB9A8: beq         $at, $zero, L_802FB9B8
    if (ctx->r1 == 0) {
        // 0x802FB9AC: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FB9B8;
    }
    // 0x802FB9AC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FB9B0: b           L_802FB9D8
    // 0x802FB9B4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FB9D8;
    // 0x802FB9B4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FB9B8:
    // 0x802FB9B8: b           L_802FB9D8
    // 0x802FB9BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FB9D8;
    // 0x802FB9BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB9C0:
    // 0x802FB9C0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FB9C4: beq         $at, $zero, L_802FB9D4
    if (ctx->r1 == 0) {
        // 0x802FB9C8: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FB9D4;
    }
    // 0x802FB9C8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FB9CC: b           L_802FB9D4
    // 0x802FB9D0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FB9D4;
    // 0x802FB9D0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FB9D4:
    // 0x802FB9D4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FB9D8:
    // 0x802FB9D8: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FB9DC: sll         $t1, $v1, 2
    ctx->r9 = S32(ctx->r3 << 2);
    // 0x802FB9E0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FB9E4: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802FB9E8: beq         $at, $zero, L_802FB9F8
    if (ctx->r1 == 0) {
        // 0x802FB9EC: lh          $a2, 0x42($sp)
        ctx->r6 = MEM_H(ctx->r29, 0X42);
            goto L_802FB9F8;
    }
    // 0x802FB9EC: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FB9F0: b           L_802FB9FC
    // 0x802FB9F4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FB9FC;
    // 0x802FB9F4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FB9F8:
    // 0x802FB9F8: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
L_802FB9FC:
    // 0x802FB9FC: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x802FBA00: ori         $t2, $a1, 0x40
    ctx->r10 = ctx->r5 | 0X40;
    // 0x802FBA04: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x802FBA08: sra         $t6, $t7, 1
    ctx->r14 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802FBA0C: addu        $t5, $v0, $t6
    ctx->r13 = ADD32(ctx->r2, ctx->r14);
    // 0x802FBA10: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802FBA14: lh          $t8, 0x30($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X30);
    // 0x802FBA18: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802FBA1C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBA20: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x802FBA24: jal         0x802D7BE0
    // 0x802FBA28: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FBA28: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_1:
    // 0x802FBA2C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FBA30: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FBA34: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FBA38: jr          $ra
    // 0x802FBA3C: nop

    return;
    // 0x802FBA3C: nop

;}
RECOMP_FUNC void func_802FBA40_70D0F0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FBA40: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FBA44: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FBA48: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FBA4C: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FBA50: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FBA54: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBA58: bne         $v0, $zero, L_802FBA78
    if (ctx->r2 != 0) {
        // 0x802FBA5C: sll         $t0, $v0, 16
        ctx->r8 = S32(ctx->r2 << 16);
            goto L_802FBA78;
    }
    // 0x802FBA5C: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FBA60: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FBA64: sll         $t6, $t0, 5
    ctx->r14 = S32(ctx->r8 << 5);
    // 0x802FBA68: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FBA6C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FBA70: b           L_802FBA80
    // 0x802FBA74: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FBA80;
    // 0x802FBA74: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FBA78:
    // 0x802FBA78: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FBA7C: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FBA80:
    // 0x802FBA80: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FBA84: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FBA88: addiu       $t1, $zero, 0x5A
    ctx->r9 = ADD32(0, 0X5A);
    // 0x802FBA8C: beql        $v0, $zero, L_802FBAB4
    if (ctx->r2 == 0) {
        // 0x802FBA90: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBAB4;
    }
    goto skip_0;
    // 0x802FBA90: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FBA94: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FBA98: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FBA9C: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FBAA0: bgezl       $t4, L_802FBAB4
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FBAA4: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBAB4;
    }
    goto skip_1;
    // 0x802FBAA4: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FBAA8: b           L_802FBAB4
    // 0x802FBAAC: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FBAB4;
    // 0x802FBAAC: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FBAB0: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FBAB4:
    // 0x802FBAB4: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FBAB8: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FBABC: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FBAC0: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FBAC4: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FBAC8: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FBACC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FBAD0: lh          $t9, 0x2C($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2C);
    // 0x802FBAD4: addiu       $t2, $zero, 0x64
    ctx->r10 = ADD32(0, 0X64);
    // 0x802FBAD8: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x802FBADC: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FBAE0: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FBAE4: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x802FBAE8: jal         0x802FF184
    // 0x802FBAEC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FBAEC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_0:
    // 0x802FBAF0: lh          $t3, 0x4($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X4);
    // 0x802FBAF4: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x802FBAF8: lh          $t4, 0x8($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X8);
    // 0x802FBAFC: sra         $t5, $t3, 6
    ctx->r13 = S32(SIGNED(ctx->r11) >> 6);
    // 0x802FBB00: sll         $t7, $t5, 7
    ctx->r15 = S32(ctx->r13 << 7);
    // 0x802FBB04: addu        $t7, $t7, $t5
    ctx->r15 = ADD32(ctx->r15, ctx->r13);
    // 0x802FBB08: sra         $t9, $t4, 6
    ctx->r25 = S32(SIGNED(ctx->r12) >> 6);
    // 0x802FBB0C: sll         $t1, $t9, 3
    ctx->r9 = S32(ctx->r25 << 3);
    // 0x802FBB10: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802FBB14: lui         $t3, 0x803C
    ctx->r11 = S32(0X803C << 16);
    // 0x802FBB18: addiu       $t3, $t3, 0x740
    ctx->r11 = ADD32(ctx->r11, 0X740);
    // 0x802FBB1C: addu        $t2, $t7, $t1
    ctx->r10 = ADD32(ctx->r15, ctx->r9);
    // 0x802FBB20: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x802FBB24: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FBB28: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FBB2C: sw          $t4, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r12;
    // 0x802FBB30: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FBB34: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBB38: beq         $at, $zero, L_802FBB48
    if (ctx->r1 == 0) {
        // 0x802FBB3C: nop
    
            goto L_802FBB48;
    }
    // 0x802FBB3C: nop

    // 0x802FBB40: b           L_802FBB48
    // 0x802FBB44: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FBB48;
    // 0x802FBB44: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FBB48:
    // 0x802FBB48: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FBB4C: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FBB50: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBB54: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBB58: beq         $at, $zero, L_802FBB68
    if (ctx->r1 == 0) {
        // 0x802FBB5C: nop
    
            goto L_802FBB68;
    }
    // 0x802FBB5C: nop

    // 0x802FBB60: b           L_802FBB68
    // 0x802FBB64: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBB68;
    // 0x802FBB64: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBB68:
    // 0x802FBB68: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FBB6C: beq         $at, $zero, L_802FBB90
    if (ctx->r1 == 0) {
        // 0x802FBB70: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FBB90;
    }
    // 0x802FBB70: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FBB74: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBB78: beq         $at, $zero, L_802FBB88
    if (ctx->r1 == 0) {
        // 0x802FBB7C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FBB88;
    }
    // 0x802FBB7C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FBB80: b           L_802FBBA8
    // 0x802FBB84: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FBBA8;
    // 0x802FBB84: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FBB88:
    // 0x802FBB88: b           L_802FBBA8
    // 0x802FBB8C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FBBA8;
    // 0x802FBB8C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBB90:
    // 0x802FBB90: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBB94: beq         $at, $zero, L_802FBBA4
    if (ctx->r1 == 0) {
        // 0x802FBB98: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FBBA4;
    }
    // 0x802FBB98: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBB9C: b           L_802FBBA4
    // 0x802FBBA0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBBA4;
    // 0x802FBBA0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBBA4:
    // 0x802FBBA4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBBA8:
    // 0x802FBBA8: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FBBAC: sll         $t4, $v1, 2
    ctx->r12 = S32(ctx->r3 << 2);
    // 0x802FBBB0: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBBB4: slt         $at, $v0, $t4
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802FBBB8: beq         $at, $zero, L_802FBBC8
    if (ctx->r1 == 0) {
        // 0x802FBBBC: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FBBC8;
    }
    // 0x802FBBBC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FBBC0: b           L_802FBBC8
    // 0x802FBBC4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FBBC8;
    // 0x802FBBC4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FBBC8:
    // 0x802FBBC8: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FBBCC: lh          $t6, 0x30($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X30);
    // 0x802FBBD0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBBD4: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FBBD8: sra         $t5, $t6, 4
    ctx->r13 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802FBBDC: jal         0x802D7BE0
    // 0x802FBBE0: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FBBE0: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_1:
    // 0x802FBBE4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FBBE8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FBBEC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FBBF0: jr          $ra
    // 0x802FBBF4: nop

    return;
    // 0x802FBBF4: nop

;}
RECOMP_FUNC void func_802FBBF8_70D2A8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FBBF8: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FBBFC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FBC00: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FBC04: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FBC08: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FBC0C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBC10: bne         $v0, $zero, L_802FBC30
    if (ctx->r2 != 0) {
        // 0x802FBC14: addiu       $t9, $zero, 0x64
        ctx->r25 = ADD32(0, 0X64);
            goto L_802FBC30;
    }
    // 0x802FBC14: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FBC18: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FBC1C: sll         $t6, $t0, 5
    ctx->r14 = S32(ctx->r8 << 5);
    // 0x802FBC20: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FBC24: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FBC28: b           L_802FBC3C
    // 0x802FBC2C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FBC3C;
    // 0x802FBC2C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FBC30:
    // 0x802FBC30: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FBC34: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FBC38: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FBC3C:
    // 0x802FBC3C: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FBC40: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FBC44: beql        $v0, $zero, L_802FBC6C
    if (ctx->r2 == 0) {
        // 0x802FBC48: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBC6C;
    }
    goto skip_0;
    // 0x802FBC48: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FBC4C: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FBC50: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FBC54: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FBC58: bgezl       $t4, L_802FBC6C
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FBC5C: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBC6C;
    }
    goto skip_1;
    // 0x802FBC5C: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FBC60: b           L_802FBC6C
    // 0x802FBC64: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FBC6C;
    // 0x802FBC64: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FBC68: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FBC6C:
    // 0x802FBC6C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FBC70: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FBC74: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FBC78: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FBC7C: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FBC80: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FBC84: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FBC88: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FBC8C: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FBC90: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FBC94: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBC98: jal         0x802FF184
    // 0x802FBC9C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FBC9C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FBCA0: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FBCA4: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FBCA8: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FBCAC: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FBCB0: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802FBCB4: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802FBCB8: sra         $t7, $t2, 6
    ctx->r15 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FBCBC: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FBCC0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FBCC4: lui         $t1, 0x803C
    ctx->r9 = S32(0X803C << 16);
    // 0x802FBCC8: addiu       $t1, $t1, 0x740
    ctx->r9 = ADD32(ctx->r9, 0X740);
    // 0x802FBCCC: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FBCD0: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802FBCD4: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FBCD8: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FBCDC: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FBCE0: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FBCE4: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBCE8: beq         $at, $zero, L_802FBCF8
    if (ctx->r1 == 0) {
        // 0x802FBCEC: nop
    
            goto L_802FBCF8;
    }
    // 0x802FBCEC: nop

    // 0x802FBCF0: b           L_802FBCF8
    // 0x802FBCF4: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FBCF8;
    // 0x802FBCF4: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FBCF8:
    // 0x802FBCF8: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FBCFC: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FBD00: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBD04: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBD08: beq         $at, $zero, L_802FBD18
    if (ctx->r1 == 0) {
        // 0x802FBD0C: nop
    
            goto L_802FBD18;
    }
    // 0x802FBD0C: nop

    // 0x802FBD10: b           L_802FBD18
    // 0x802FBD14: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBD18;
    // 0x802FBD14: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBD18:
    // 0x802FBD18: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FBD1C: beq         $at, $zero, L_802FBD40
    if (ctx->r1 == 0) {
        // 0x802FBD20: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FBD40;
    }
    // 0x802FBD20: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FBD24: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBD28: beq         $at, $zero, L_802FBD38
    if (ctx->r1 == 0) {
        // 0x802FBD2C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FBD38;
    }
    // 0x802FBD2C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FBD30: b           L_802FBD58
    // 0x802FBD34: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FBD58;
    // 0x802FBD34: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FBD38:
    // 0x802FBD38: b           L_802FBD58
    // 0x802FBD3C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FBD58;
    // 0x802FBD3C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBD40:
    // 0x802FBD40: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBD44: beq         $at, $zero, L_802FBD54
    if (ctx->r1 == 0) {
        // 0x802FBD48: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FBD54;
    }
    // 0x802FBD48: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBD4C: b           L_802FBD54
    // 0x802FBD50: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBD54;
    // 0x802FBD50: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBD54:
    // 0x802FBD54: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBD58:
    // 0x802FBD58: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FBD5C: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x802FBD60: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBD64: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FBD68: beq         $at, $zero, L_802FBD78
    if (ctx->r1 == 0) {
        // 0x802FBD6C: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FBD78;
    }
    // 0x802FBD6C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FBD70: b           L_802FBD78
    // 0x802FBD74: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FBD78;
    // 0x802FBD74: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FBD78:
    // 0x802FBD78: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FBD7C: lh          $t3, 0x30($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X30);
    // 0x802FBD80: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBD84: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FBD88: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802FBD8C: jal         0x802D7BE0
    // 0x802FBD90: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FBD90: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_1:
    // 0x802FBD94: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FBD98: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FBD9C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FBDA0: jr          $ra
    // 0x802FBDA4: nop

    return;
    // 0x802FBDA4: nop

;}
RECOMP_FUNC void func_802FBDA8_70D458(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FBDA8: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FBDAC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FBDB0: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FBDB4: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FBDB8: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FBDBC: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBDC0: bne         $v0, $zero, L_802FBDE0
    if (ctx->r2 != 0) {
        // 0x802FBDC4: addiu       $t9, $zero, 0x64
        ctx->r25 = ADD32(0, 0X64);
            goto L_802FBDE0;
    }
    // 0x802FBDC4: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FBDC8: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FBDCC: sll         $t6, $t0, 4
    ctx->r14 = S32(ctx->r8 << 4);
    // 0x802FBDD0: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FBDD4: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FBDD8: b           L_802FBDEC
    // 0x802FBDDC: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FBDEC;
    // 0x802FBDDC: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FBDE0:
    // 0x802FBDE0: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FBDE4: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FBDE8: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FBDEC:
    // 0x802FBDEC: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FBDF0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FBDF4: beql        $v0, $zero, L_802FBE1C
    if (ctx->r2 == 0) {
        // 0x802FBDF8: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBE1C;
    }
    goto skip_0;
    // 0x802FBDF8: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FBDFC: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FBE00: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FBE04: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FBE08: bgezl       $t4, L_802FBE1C
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FBE0C: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBE1C;
    }
    goto skip_1;
    // 0x802FBE0C: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FBE10: b           L_802FBE1C
    // 0x802FBE14: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FBE1C;
    // 0x802FBE14: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FBE18: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FBE1C:
    // 0x802FBE1C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FBE20: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FBE24: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FBE28: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FBE2C: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FBE30: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FBE34: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FBE38: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FBE3C: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FBE40: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FBE44: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBE48: jal         0x802FF184
    // 0x802FBE4C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FBE4C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FBE50: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FBE54: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FBE58: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FBE5C: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FBE60: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802FBE64: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802FBE68: sra         $t7, $t2, 6
    ctx->r15 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FBE6C: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FBE70: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FBE74: lui         $t1, 0x803C
    ctx->r9 = S32(0X803C << 16);
    // 0x802FBE78: addiu       $t1, $t1, 0x740
    ctx->r9 = ADD32(ctx->r9, 0X740);
    // 0x802FBE7C: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FBE80: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802FBE84: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FBE88: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FBE8C: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FBE90: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FBE94: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBE98: beq         $at, $zero, L_802FBEA8
    if (ctx->r1 == 0) {
        // 0x802FBE9C: nop
    
            goto L_802FBEA8;
    }
    // 0x802FBE9C: nop

    // 0x802FBEA0: b           L_802FBEA8
    // 0x802FBEA4: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FBEA8;
    // 0x802FBEA4: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FBEA8:
    // 0x802FBEA8: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FBEAC: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FBEB0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBEB4: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBEB8: beq         $at, $zero, L_802FBEC8
    if (ctx->r1 == 0) {
        // 0x802FBEBC: nop
    
            goto L_802FBEC8;
    }
    // 0x802FBEBC: nop

    // 0x802FBEC0: b           L_802FBEC8
    // 0x802FBEC4: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBEC8;
    // 0x802FBEC4: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBEC8:
    // 0x802FBEC8: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FBECC: beq         $at, $zero, L_802FBEF0
    if (ctx->r1 == 0) {
        // 0x802FBED0: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FBEF0;
    }
    // 0x802FBED0: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FBED4: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FBED8: beq         $at, $zero, L_802FBEE8
    if (ctx->r1 == 0) {
        // 0x802FBEDC: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FBEE8;
    }
    // 0x802FBEDC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FBEE0: b           L_802FBF08
    // 0x802FBEE4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FBF08;
    // 0x802FBEE4: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FBEE8:
    // 0x802FBEE8: b           L_802FBF08
    // 0x802FBEEC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FBF08;
    // 0x802FBEEC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBEF0:
    // 0x802FBEF0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FBEF4: beq         $at, $zero, L_802FBF04
    if (ctx->r1 == 0) {
        // 0x802FBEF8: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FBF04;
    }
    // 0x802FBEF8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FBEFC: b           L_802FBF04
    // 0x802FBF00: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FBF04;
    // 0x802FBF00: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FBF04:
    // 0x802FBF04: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FBF08:
    // 0x802FBF08: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FBF0C: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x802FBF10: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802FBF14: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FBF18: beq         $at, $zero, L_802FBF28
    if (ctx->r1 == 0) {
        // 0x802FBF1C: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FBF28;
    }
    // 0x802FBF1C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FBF20: b           L_802FBF28
    // 0x802FBF24: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FBF28;
    // 0x802FBF24: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FBF28:
    // 0x802FBF28: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FBF2C: lh          $t3, 0x30($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X30);
    // 0x802FBF30: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBF34: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FBF38: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802FBF3C: jal         0x802D7BE0
    // 0x802FBF40: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FBF40: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_1:
    // 0x802FBF44: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FBF48: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FBF4C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FBF50: jr          $ra
    // 0x802FBF54: nop

    return;
    // 0x802FBF54: nop

;}
RECOMP_FUNC void func_802FBF58_70D608(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FBF58: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FBF5C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FBF60: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FBF64: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FBF68: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FBF6C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FBF70: bne         $v0, $zero, L_802FBF90
    if (ctx->r2 != 0) {
        // 0x802FBF74: addiu       $t9, $zero, 0x64
        ctx->r25 = ADD32(0, 0X64);
            goto L_802FBF90;
    }
    // 0x802FBF74: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FBF78: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FBF7C: sll         $t6, $t0, 5
    ctx->r14 = S32(ctx->r8 << 5);
    // 0x802FBF80: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FBF84: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FBF88: b           L_802FBF9C
    // 0x802FBF8C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FBF9C;
    // 0x802FBF8C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FBF90:
    // 0x802FBF90: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FBF94: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FBF98: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FBF9C:
    // 0x802FBF9C: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FBFA0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FBFA4: beql        $v0, $zero, L_802FBFCC
    if (ctx->r2 == 0) {
        // 0x802FBFA8: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBFCC;
    }
    goto skip_0;
    // 0x802FBFA8: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FBFAC: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FBFB0: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FBFB4: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FBFB8: bgezl       $t4, L_802FBFCC
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FBFBC: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FBFCC;
    }
    goto skip_1;
    // 0x802FBFBC: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FBFC0: b           L_802FBFCC
    // 0x802FBFC4: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FBFCC;
    // 0x802FBFC4: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FBFC8: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FBFCC:
    // 0x802FBFCC: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FBFD0: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FBFD4: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FBFD8: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FBFDC: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FBFE0: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FBFE4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FBFE8: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FBFEC: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FBFF0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FBFF4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FBFF8: jal         0x802FF184
    // 0x802FBFFC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FBFFC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FC000: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FC004: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FC008: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FC00C: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FC010: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802FC014: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802FC018: sra         $t7, $t2, 6
    ctx->r15 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FC01C: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FC020: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FC024: lui         $t1, 0x803C
    ctx->r9 = S32(0X803C << 16);
    // 0x802FC028: addiu       $t1, $t1, 0x740
    ctx->r9 = ADD32(ctx->r9, 0X740);
    // 0x802FC02C: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FC030: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802FC034: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FC038: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FC03C: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FC040: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FC044: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FC048: beq         $at, $zero, L_802FC058
    if (ctx->r1 == 0) {
        // 0x802FC04C: nop
    
            goto L_802FC058;
    }
    // 0x802FC04C: nop

    // 0x802FC050: b           L_802FC058
    // 0x802FC054: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FC058;
    // 0x802FC054: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FC058:
    // 0x802FC058: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FC05C: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FC060: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FC064: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC068: beq         $at, $zero, L_802FC078
    if (ctx->r1 == 0) {
        // 0x802FC06C: nop
    
            goto L_802FC078;
    }
    // 0x802FC06C: nop

    // 0x802FC070: b           L_802FC078
    // 0x802FC074: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC078;
    // 0x802FC074: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC078:
    // 0x802FC078: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FC07C: beq         $at, $zero, L_802FC0A0
    if (ctx->r1 == 0) {
        // 0x802FC080: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FC0A0;
    }
    // 0x802FC080: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FC084: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FC088: beq         $at, $zero, L_802FC098
    if (ctx->r1 == 0) {
        // 0x802FC08C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FC098;
    }
    // 0x802FC08C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FC090: b           L_802FC0B8
    // 0x802FC094: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FC0B8;
    // 0x802FC094: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FC098:
    // 0x802FC098: b           L_802FC0B8
    // 0x802FC09C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FC0B8;
    // 0x802FC09C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC0A0:
    // 0x802FC0A0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC0A4: beq         $at, $zero, L_802FC0B4
    if (ctx->r1 == 0) {
        // 0x802FC0A8: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FC0B4;
    }
    // 0x802FC0A8: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FC0AC: b           L_802FC0B4
    // 0x802FC0B0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC0B4;
    // 0x802FC0B0: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC0B4:
    // 0x802FC0B4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC0B8:
    // 0x802FC0B8: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FC0BC: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x802FC0C0: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    // 0x802FC0C4: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FC0C8: beq         $at, $zero, L_802FC0D8
    if (ctx->r1 == 0) {
        // 0x802FC0CC: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FC0D8;
    }
    // 0x802FC0CC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FC0D0: b           L_802FC0D8
    // 0x802FC0D4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FC0D8;
    // 0x802FC0D4: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FC0D8:
    // 0x802FC0D8: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FC0DC: lh          $t3, 0x30($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X30);
    // 0x802FC0E0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FC0E4: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FC0E8: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802FC0EC: jal         0x802D7BE0
    // 0x802FC0F0: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FC0F0: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_1:
    // 0x802FC0F4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FC0F8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FC0FC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FC100: jr          $ra
    // 0x802FC104: nop

    return;
    // 0x802FC104: nop

;}
