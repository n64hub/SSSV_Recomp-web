#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_802B33D0_6C4A80(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B33D0: lb          $t6, 0x4A($a0)
    ctx->r14 = MEM_B(ctx->r4, 0X4A);
    // 0x802B33D4: lw          $t8, 0x16C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X16C);
    // 0x802B33D8: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802B33DC: sb          $t7, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = ctx->r15;
    // 0x802B33E0: lw          $t9, 0x80($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X80);
    // 0x802B33E4: sll         $t1, $t9, 18
    ctx->r9 = S32(ctx->r25 << 18);
    // 0x802B33E8: bgez        $t1, L_802B33F8
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802B33EC: nop
    
            goto L_802B33F8;
    }
    // 0x802B33EC: nop

    // 0x802B33F0: lh          $t2, 0x302($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X302);
    // 0x802B33F4: sh          $t2, 0x304($a0)
    MEM_H(0X304, ctx->r4) = ctx->r10;
L_802B33F8:
    // 0x802B33F8: jr          $ra
    // 0x802B33FC: nop

    return;
    // 0x802B33FC: nop

;}
RECOMP_FUNC void func_802B3400_6C4AB0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3400: lw          $t7, 0x16C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X16C);
    // 0x802B3404: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B3408: sb          $t6, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = ctx->r14;
    // 0x802B340C: lw          $t8, 0x80($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X80);
    // 0x802B3410: sll         $t0, $t8, 18
    ctx->r8 = S32(ctx->r24 << 18);
    // 0x802B3414: bgez        $t0, L_802B3424
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802B3418: nop
    
            goto L_802B3424;
    }
    // 0x802B3418: nop

    // 0x802B341C: lh          $t1, 0x302($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X302);
    // 0x802B3420: sh          $t1, 0x304($a0)
    MEM_H(0X304, ctx->r4) = ctx->r9;
L_802B3424:
    // 0x802B3424: jr          $ra
    // 0x802B3428: nop

    return;
    // 0x802B3428: nop

;}
RECOMP_FUNC void func_802B342C_6C4ADC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B342C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B3430: addiu       $a0, $a0, 0x5534
    ctx->r4 = ADD32(ctx->r4, 0X5534);
    // 0x802B3434: lh          $t6, 0x0($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X0);
    // 0x802B3438: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x802B343C: addiu       $v1, $v1, -0x6128
    ctx->r3 = ADD32(ctx->r3, -0X6128);
    // 0x802B3440: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802B3444: addu        $t8, $v1, $t7
    ctx->r24 = ADD32(ctx->r3, ctx->r15);
    // 0x802B3448: lw          $v0, 0x3EB4($t8)
    ctx->r2 = MEM_W(ctx->r24, 0X3EB4);
    // 0x802B344C: lb          $t9, 0x4A($v0)
    ctx->r25 = MEM_B(ctx->r2, 0X4A);
    // 0x802B3450: addiu       $t0, $t9, 0x1
    ctx->r8 = ADD32(ctx->r25, 0X1);
    // 0x802B3454: sb          $t0, 0x4A($v0)
    MEM_B(0X4A, ctx->r2) = ctx->r8;
    // 0x802B3458: lh          $t1, 0x0($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X0);
    // 0x802B345C: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x802B3460: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x802B3464: lw          $v0, 0x3EB4($t3)
    ctx->r2 = MEM_W(ctx->r11, 0X3EB4);
    // 0x802B3468: lh          $t4, 0x302($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X302);
    // 0x802B346C: jr          $ra
    // 0x802B3470: sh          $t4, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r12;
    return;
    // 0x802B3470: sh          $t4, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r12;
;}
RECOMP_FUNC void func_802B3474_6C4B24(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3474: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B3478: addiu       $a0, $a0, 0x5534
    ctx->r4 = ADD32(ctx->r4, 0X5534);
    // 0x802B347C: lh          $t7, 0x0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X0);
    // 0x802B3480: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x802B3484: addiu       $v1, $v1, -0x6128
    ctx->r3 = ADD32(ctx->r3, -0X6128);
    // 0x802B3488: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802B348C: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x802B3490: lw          $t0, 0x3EB4($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X3EB4);
    // 0x802B3494: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B3498: sb          $t6, 0x4A($t0)
    MEM_B(0X4A, ctx->r8) = ctx->r14;
    // 0x802B349C: lh          $t1, 0x0($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X0);
    // 0x802B34A0: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x802B34A4: addu        $t3, $v1, $t2
    ctx->r11 = ADD32(ctx->r3, ctx->r10);
    // 0x802B34A8: lw          $v0, 0x3EB4($t3)
    ctx->r2 = MEM_W(ctx->r11, 0X3EB4);
    // 0x802B34AC: lh          $t4, 0x302($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X302);
    // 0x802B34B0: jr          $ra
    // 0x802B34B4: sh          $t4, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r12;
    return;
    // 0x802B34B4: sh          $t4, 0x304($v0)
    MEM_H(0X304, ctx->r2) = ctx->r12;
;}
RECOMP_FUNC void func_802B34B8_6C4B68(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B34B8: lb          $v0, 0x4A($a0)
    ctx->r2 = MEM_B(ctx->r4, 0X4A);
    // 0x802B34BC: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x802B34C0: bgezl       $v0, L_802B34D4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B34C4: sb          $v0, 0x4A($a0)
        MEM_B(0X4A, ctx->r4) = ctx->r2;
            goto L_802B34D4;
    }
    goto skip_0;
    // 0x802B34C4: sb          $v0, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = ctx->r2;
    skip_0:
    // 0x802B34C8: jr          $ra
    // 0x802B34CC: sb          $zero, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = 0;
    return;
    // 0x802B34CC: sb          $zero, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = 0;
    // 0x802B34D0: sb          $v0, 0x4A($a0)
    MEM_B(0X4A, ctx->r4) = ctx->r2;
L_802B34D4:
    // 0x802B34D4: jr          $ra
    // 0x802B34D8: nop

    return;
    // 0x802B34D8: nop

;}
RECOMP_FUNC void func_802B34DC_6C4B8C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B34DC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B34E0: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x802B34E4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B34E8: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802B34EC: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802B34F0: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x802B34F4: lb          $v1, 0x4A($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X4A);
    // 0x802B34F8: addiu       $v1, $v1, -0x1
    ctx->r3 = ADD32(ctx->r3, -0X1);
    // 0x802B34FC: bgezl       $v1, L_802B3510
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B3500: sb          $v1, 0x4A($v0)
        MEM_B(0X4A, ctx->r2) = ctx->r3;
            goto L_802B3510;
    }
    goto skip_0;
    // 0x802B3500: sb          $v1, 0x4A($v0)
    MEM_B(0X4A, ctx->r2) = ctx->r3;
    skip_0:
    // 0x802B3504: jr          $ra
    // 0x802B3508: sb          $zero, 0x4A($v0)
    MEM_B(0X4A, ctx->r2) = 0;
    return;
    // 0x802B3508: sb          $zero, 0x4A($v0)
    MEM_B(0X4A, ctx->r2) = 0;
    // 0x802B350C: sb          $v1, 0x4A($v0)
    MEM_B(0X4A, ctx->r2) = ctx->r3;
L_802B3510:
    // 0x802B3510: jr          $ra
    // 0x802B3514: nop

    return;
    // 0x802B3514: nop

;}
RECOMP_FUNC void func_802B3518_6C4BC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3518: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B351C: addiu       $v0, $v0, 0x554A
    ctx->r2 = ADD32(ctx->r2, 0X554A);
    // 0x802B3520: lb          $t6, 0x0($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X0);
    // 0x802B3524: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802B3528: jr          $ra
    // 0x802B352C: sb          $t7, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r15;
    return;
    // 0x802B352C: sb          $t7, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r15;
;}
RECOMP_FUNC void func_802B3530_6C4BE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3530: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B3534: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B3538: jr          $ra
    // 0x802B353C: sb          $t6, 0x554A($at)
    MEM_B(0X554A, ctx->r1) = ctx->r14;
    return;
    // 0x802B353C: sb          $t6, 0x554A($at)
    MEM_B(0X554A, ctx->r1) = ctx->r14;
;}
RECOMP_FUNC void func_802B3540_6C4BF0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3540: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B3544: addiu       $v1, $v1, 0x554A
    ctx->r3 = ADD32(ctx->r3, 0X554A);
    // 0x802B3548: lb          $v0, 0x0($v1)
    ctx->r2 = MEM_B(ctx->r3, 0X0);
    // 0x802B354C: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x802B3550: bgezl       $v0, L_802B3564
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B3554: sb          $v0, 0x0($v1)
        MEM_B(0X0, ctx->r3) = ctx->r2;
            goto L_802B3564;
    }
    goto skip_0;
    // 0x802B3554: sb          $v0, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r2;
    skip_0:
    // 0x802B3558: jr          $ra
    // 0x802B355C: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
    return;
    // 0x802B355C: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
    // 0x802B3560: sb          $v0, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r2;
L_802B3564:
    // 0x802B3564: jr          $ra
    // 0x802B3568: nop

    return;
    // 0x802B3568: nop

;}
RECOMP_FUNC void func_802B356C_6C4C1C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B356C: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802B3570: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    // 0x802B3574: lh          $t9, 0x46($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X46);
    // 0x802B3578: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802B357C: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x802B3580: sll         $t0, $t9, 4
    ctx->r8 = S32(ctx->r25 << 4);
    // 0x802B3584: sw          $a2, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r6;
    // 0x802B3588: sw          $a3, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r7;
    // 0x802B358C: sh          $t0, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r8;
    // 0x802B3590: lw          $t1, 0x4C($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X4C);
    // 0x802B3594: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802B3598: andi        $t8, $a3, 0xFF
    ctx->r24 = ctx->r7 & 0XFF;
    // 0x802B359C: sll         $t3, $t1, 26
    ctx->r11 = S32(ctx->r9 << 26);
    // 0x802B35A0: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x802B35A4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B35A8: bltz        $t3, L_802B35D0
    if (SIGNED(ctx->r11) < 0) {
        // 0x802B35AC: or          $s0, $a0, $zero
        ctx->r16 = ctx->r4 | 0;
            goto L_802B35D0;
    }
    // 0x802B35AC: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802B35B0: lb          $t4, 0x4A($a0)
    ctx->r12 = MEM_B(ctx->r4, 0X4A);
    // 0x802B35B4: bnel        $t4, $zero, L_802B35D4
    if (ctx->r12 != 0) {
        // 0x802B35B8: sh          $zero, 0x46($sp)
        MEM_H(0X46, ctx->r29) = 0;
            goto L_802B35D4;
    }
    goto skip_0;
    // 0x802B35B8: sh          $zero, 0x46($sp)
    MEM_H(0X46, ctx->r29) = 0;
    skip_0:
    // 0x802B35BC: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
    // 0x802B35C0: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x802B35C4: lbu         $t5, 0x8B($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X8B);
    // 0x802B35C8: bnel        $t5, $at, L_802B35DC
    if (ctx->r13 != ctx->r1) {
        // 0x802B35CC: lw          $a0, 0x80($v0)
        ctx->r4 = MEM_W(ctx->r2, 0X80);
            goto L_802B35DC;
    }
    goto skip_1;
    // 0x802B35CC: lw          $a0, 0x80($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X80);
    skip_1:
L_802B35D0:
    // 0x802B35D0: sh          $zero, 0x46($sp)
    MEM_H(0X46, ctx->r29) = 0;
L_802B35D4:
    // 0x802B35D4: lw          $v0, 0x16C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X16C);
    // 0x802B35D8: lw          $a0, 0x80($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X80);
L_802B35DC:
    // 0x802B35DC: lh          $t9, 0x46($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X46);
    // 0x802B35E0: sll         $t6, $a0, 18
    ctx->r14 = S32(ctx->r4 << 18);
    // 0x802B35E4: srl         $a0, $t6, 31
    ctx->r4 = S32(U32(ctx->r14) >> 31);
    // 0x802B35E8: bnel        $a0, $zero, L_802B3634
    if (ctx->r4 != 0) {
        // 0x802B35EC: lb          $a1, 0xE6($v0)
        ctx->r5 = MEM_B(ctx->r2, 0XE6);
            goto L_802B3634;
    }
    goto skip_2;
    // 0x802B35EC: lb          $a1, 0xE6($v0)
    ctx->r5 = MEM_B(ctx->r2, 0XE6);
    skip_2:
    // 0x802B35F0: lh          $t8, 0x14C($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14C);
    // 0x802B35F4: sra         $t0, $t9, 4
    ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B35F8: subu        $v1, $t8, $t0
    ctx->r3 = SUB32(ctx->r24, ctx->r8);
    // 0x802B35FC: bgezl       $v1, L_802B3620
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B3600: lw          $v0, 0x16C($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X16C);
            goto L_802B3620;
    }
    goto skip_3;
    // 0x802B3600: lw          $v0, 0x16C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X16C);
    skip_3:
    // 0x802B3604: lw          $v0, 0x16C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X16C);
    // 0x802B3608: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    // 0x802B360C: lw          $a0, 0x80($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X80);
    // 0x802B3610: sll         $t1, $a0, 18
    ctx->r9 = S32(ctx->r4 << 18);
    // 0x802B3614: b           L_802B3630
    // 0x802B3618: srl         $a0, $t1, 31
    ctx->r4 = S32(U32(ctx->r9) >> 31);
        goto L_802B3630;
    // 0x802B3618: srl         $a0, $t1, 31
    ctx->r4 = S32(U32(ctx->r9) >> 31);
    // 0x802B361C: lw          $v0, 0x16C($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X16C);
L_802B3620:
    // 0x802B3620: sh          $v1, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r3;
    // 0x802B3624: lw          $a0, 0x80($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X80);
    // 0x802B3628: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    // 0x802B362C: srl         $a0, $t3, 31
    ctx->r4 = S32(U32(ctx->r11) >> 31);
L_802B3630:
    // 0x802B3630: lb          $a1, 0xE6($v0)
    ctx->r5 = MEM_B(ctx->r2, 0XE6);
L_802B3634:
    // 0x802B3634: lh          $t7, 0x46($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X46);
    // 0x802B3638: sltiu       $at, $a1, 0x5
    ctx->r1 = ctx->r5 < 0X5 ? 1 : 0;
    // 0x802B363C: beq         $at, $zero, L_802B36E0
    if (ctx->r1 == 0) {
        // 0x802B3640: sll         $t9, $t7, 16
        ctx->r25 = S32(ctx->r15 << 16);
            goto L_802B36E0;
    }
    // 0x802B3640: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x802B3644: sll         $t5, $a1, 2
    ctx->r13 = S32(ctx->r5 << 2);
    // 0x802B3648: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B364C: addu        $at, $at, $t5
    gpr jr_addend_802B3654 = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x802B3650: lw          $t5, -0x4190($at)
    ctx->r13 = ADD32(ctx->r1, -0X4190);
    // 0x802B3654: jr          $t5
    // 0x802B3658: nop

    switch (jr_addend_802B3654 >> 2) {
        case 0: goto L_802B365C; break;
        case 1: goto L_802B367C; break;
        case 2: goto L_802B369C; break;
        case 3: goto L_802B36AC; break;
        case 4: goto L_802B36C4; break;
        default: switch_error(__func__, 0x802B3654, 0x803BBE70);
    }
    // 0x802B3658: nop

L_802B365C:
    // 0x802B365C: lh          $v0, 0x46($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X46);
    // 0x802B3660: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
    // 0x802B3664: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x802B3668: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802B366C: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802B3670: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x802B3674: b           L_802B36E4
    // 0x802B3678: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
        goto L_802B36E4;
    // 0x802B3678: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
L_802B367C:
    // 0x802B367C: lh          $v0, 0x46($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X46);
    // 0x802B3680: sll         $t0, $v0, 2
    ctx->r8 = S32(ctx->r2 << 2);
    // 0x802B3684: subu        $t0, $t0, $v0
    ctx->r8 = SUB32(ctx->r8, ctx->r2);
    // 0x802B3688: sll         $t0, $t0, 3
    ctx->r8 = S32(ctx->r8 << 3);
    // 0x802B368C: sra         $t1, $t0, 4
    ctx->r9 = S32(SIGNED(ctx->r8) >> 4);
    // 0x802B3690: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x802B3694: b           L_802B36E4
    // 0x802B3698: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
        goto L_802B36E4;
    // 0x802B3698: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
L_802B369C:
    // 0x802B369C: lh          $t5, 0x46($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X46);
    // 0x802B36A0: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802B36A4: b           L_802B36E4
    // 0x802B36A8: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
        goto L_802B36E4;
    // 0x802B36A8: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
L_802B36AC:
    // 0x802B36AC: lh          $v0, 0x46($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X46);
    // 0x802B36B0: sll         $t9, $v0, 3
    ctx->r25 = S32(ctx->r2 << 3);
    // 0x802B36B4: sra         $t8, $t9, 4
    ctx->r24 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B36B8: sll         $t0, $t8, 16
    ctx->r8 = S32(ctx->r24 << 16);
    // 0x802B36BC: b           L_802B36E4
    // 0x802B36C0: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
        goto L_802B36E4;
    // 0x802B36C0: sra         $v0, $t0, 16
    ctx->r2 = S32(SIGNED(ctx->r8) >> 16);
L_802B36C4:
    // 0x802B36C4: lh          $v0, 0x46($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X46);
    // 0x802B36C8: sll         $t2, $v0, 2
    ctx->r10 = S32(ctx->r2 << 2);
    // 0x802B36CC: addu        $t2, $t2, $v0
    ctx->r10 = ADD32(ctx->r10, ctx->r2);
    // 0x802B36D0: sra         $t3, $t2, 4
    ctx->r11 = S32(SIGNED(ctx->r10) >> 4);
    // 0x802B36D4: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x802B36D8: b           L_802B36E4
    // 0x802B36DC: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
        goto L_802B36E4;
    // 0x802B36DC: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
L_802B36E0:
    // 0x802B36E0: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
L_802B36E4:
    // 0x802B36E4: bltz        $a2, L_802B3788
    if (SIGNED(ctx->r6) < 0) {
        // 0x802B36E8: nop
    
            goto L_802B3788;
    }
    // 0x802B36E8: nop

    // 0x802B36EC: beq         $a0, $zero, L_802B3788
    if (ctx->r4 == 0) {
        // 0x802B36F0: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_802B3788;
    }
    // 0x802B36F0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B36F4: lh          $t0, 0x5534($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X5534);
    // 0x802B36F8: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x802B36FC: subu        $v1, $a1, $a2
    ctx->r3 = SUB32(ctx->r5, ctx->r6);
    // 0x802B3700: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x802B3704: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x802B3708: lw          $t2, -0x2274($t2)
    ctx->r10 = MEM_W(ctx->r10, -0X2274);
    // 0x802B370C: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x802B3710: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802B3714: beq         $s0, $t2, L_802B3788
    if (ctx->r16 == ctx->r10) {
        // 0x802B3718: addiu       $t5, $t4, -0x2
        ctx->r13 = ADD32(ctx->r12, -0X2);
            goto L_802B3788;
    }
    // 0x802B3718: addiu       $t5, $t4, -0x2
    ctx->r13 = ADD32(ctx->r12, -0X2);
    // 0x802B371C: sltiu       $at, $t5, 0x6
    ctx->r1 = ctx->r13 < 0X6 ? 1 : 0;
    // 0x802B3720: beq         $at, $zero, L_802B3788
    if (ctx->r1 == 0) {
        // 0x802B3724: sll         $t5, $t5, 2
        ctx->r13 = S32(ctx->r13 << 2);
            goto L_802B3788;
    }
    // 0x802B3724: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x802B3728: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B372C: addu        $at, $at, $t5
    gpr jr_addend_802B3734 = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x802B3730: lw          $t5, -0x417C($at)
    ctx->r13 = ADD32(ctx->r1, -0X417C);
    // 0x802B3734: jr          $t5
    // 0x802B3738: nop

    switch (jr_addend_802B3734 >> 2) {
        case 0: goto L_802B373C; break;
        case 1: goto L_802B3754; break;
        case 2: goto L_802B3764; break;
        case 3: goto L_802B3774; break;
        case 4: goto L_802B3784; break;
        case 5: goto L_802B3784; break;
        default: switch_error(__func__, 0x802B3734, 0x803BBE84);
    }
    // 0x802B3738: nop

L_802B373C:
    // 0x802B373C: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802B3740: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x802B3744: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x802B3748: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x802B374C: b           L_802B3788
    // 0x802B3750: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
        goto L_802B3788;
    // 0x802B3750: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
L_802B3754:
    // 0x802B3754: sra         $t0, $v0, 1
    ctx->r8 = S32(SIGNED(ctx->r2) >> 1);
    // 0x802B3758: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802B375C: b           L_802B3788
    // 0x802B3760: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
        goto L_802B3788;
    // 0x802B3760: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
L_802B3764:
    // 0x802B3764: sra         $t3, $v0, 2
    ctx->r11 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802B3768: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x802B376C: b           L_802B3788
    // 0x802B3770: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
        goto L_802B3788;
    // 0x802B3770: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
L_802B3774:
    // 0x802B3774: sra         $t6, $v0, 3
    ctx->r14 = S32(SIGNED(ctx->r2) >> 3);
    // 0x802B3778: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802B377C: b           L_802B3788
    // 0x802B3780: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
        goto L_802B3788;
    // 0x802B3780: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
L_802B3784:
    // 0x802B3784: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802B3788:
    // 0x802B3788: beql        $a0, $zero, L_802B385C
    if (ctx->r4 == 0) {
        // 0x802B378C: slti        $at, $v0, 0x230
        ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
            goto L_802B385C;
    }
    goto skip_4;
    // 0x802B378C: slti        $at, $v0, 0x230
    ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
    skip_4:
    // 0x802B3790: beql        $a3, $zero, L_802B385C
    if (ctx->r7 == 0) {
        // 0x802B3794: slti        $at, $v0, 0x230
        ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
            goto L_802B385C;
    }
    goto skip_5;
    // 0x802B3794: slti        $at, $v0, 0x230
    ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
    skip_5:
    // 0x802B3798: lh          $t8, 0x14C($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14C);
    // 0x802B379C: slti        $at, $v0, 0x1E1
    ctx->r1 = SIGNED(ctx->r2) < 0X1E1 ? 1 : 0;
    // 0x802B37A0: subu        $t0, $t8, $v0
    ctx->r8 = SUB32(ctx->r24, ctx->r2);
    // 0x802B37A4: blezl       $t0, L_802B385C
    if (SIGNED(ctx->r8) <= 0) {
        // 0x802B37A8: slti        $at, $v0, 0x230
        ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
            goto L_802B385C;
    }
    goto skip_6;
    // 0x802B37A8: slti        $at, $v0, 0x230
    ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
    skip_6:
    // 0x802B37AC: bne         $at, $zero, L_802B37E4
    if (ctx->r1 != 0) {
        // 0x802B37B0: addiu       $a0, $zero, 0xE
        ctx->r4 = ADD32(0, 0XE);
            goto L_802B37E4;
    }
    // 0x802B37B0: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x802B37B4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B37B8: jal         0x802DBA58
    // 0x802B37BC: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_0;
    // 0x802B37BC: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    after_0:
    // 0x802B37C0: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802B37C4: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B37C8: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802B37CC: ori         $t1, $zero, 0xE701
    ctx->r9 = 0 | 0XE701;
    // 0x802B37D0: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x802B37D4: jal         0x802D9C64
    // 0x802B37D8: addiu       $a3, $zero, 0x21
    ctx->r7 = ADD32(0, 0X21);
    create_sparks(rdram, ctx);
        goto after_1;
    // 0x802B37D8: addiu       $a3, $zero, 0x21
    ctx->r7 = ADD32(0, 0X21);
    after_1:
    // 0x802B37DC: b           L_802B3858
    // 0x802B37E0: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
        goto L_802B3858;
    // 0x802B37E0: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
L_802B37E4:
    // 0x802B37E4: slti        $at, $v0, 0xC1
    ctx->r1 = SIGNED(ctx->r2) < 0XC1 ? 1 : 0;
    // 0x802B37E8: bne         $at, $zero, L_802B3820
    if (ctx->r1 != 0) {
        // 0x802B37EC: addiu       $a0, $zero, 0xE
        ctx->r4 = ADD32(0, 0XE);
            goto L_802B3820;
    }
    // 0x802B37EC: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x802B37F0: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B37F4: jal         0x802DBA58
    // 0x802B37F8: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_2;
    // 0x802B37F8: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    after_2:
    // 0x802B37FC: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802B3800: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B3804: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802B3808: ori         $t2, $zero, 0xE701
    ctx->r10 = 0 | 0XE701;
    // 0x802B380C: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x802B3810: jal         0x802D9C64
    // 0x802B3814: addiu       $a3, $zero, 0x11
    ctx->r7 = ADD32(0, 0X11);
    create_sparks(rdram, ctx);
        goto after_3;
    // 0x802B3814: addiu       $a3, $zero, 0x11
    ctx->r7 = ADD32(0, 0X11);
    after_3:
    // 0x802B3818: b           L_802B3858
    // 0x802B381C: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
        goto L_802B3858;
    // 0x802B381C: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
L_802B3820:
    // 0x802B3820: slti        $at, $v0, 0x40
    ctx->r1 = SIGNED(ctx->r2) < 0X40 ? 1 : 0;
    // 0x802B3824: bne         $at, $zero, L_802B3858
    if (ctx->r1 != 0) {
        // 0x802B3828: addiu       $a0, $zero, 0xD
        ctx->r4 = ADD32(0, 0XD);
            goto L_802B3858;
    }
    // 0x802B3828: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    // 0x802B382C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B3830: jal         0x802DBA58
    // 0x802B3834: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_4;
    // 0x802B3834: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    after_4:
    // 0x802B3838: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802B383C: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B3840: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802B3844: ori         $t3, $zero, 0xE701
    ctx->r11 = 0 | 0XE701;
    // 0x802B3848: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802B384C: jal         0x802D9C64
    // 0x802B3850: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    create_sparks(rdram, ctx);
        goto after_5;
    // 0x802B3850: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    after_5:
    // 0x802B3854: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
L_802B3858:
    // 0x802B3858: slti        $at, $v0, 0x230
    ctx->r1 = SIGNED(ctx->r2) < 0X230 ? 1 : 0;
L_802B385C:
    // 0x802B385C: bne         $at, $zero, L_802B3868
    if (ctx->r1 != 0) {
        // 0x802B3860: lh          $t4, 0x46($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X46);
            goto L_802B3868;
    }
    // 0x802B3860: lh          $t4, 0x46($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X46);
    // 0x802B3864: addiu       $v0, $zero, 0x230
    ctx->r2 = ADD32(0, 0X230);
L_802B3868:
    // 0x802B3868: beq         $t4, $zero, L_802B387C
    if (ctx->r12 == 0) {
        // 0x802B386C: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802B387C;
    }
    // 0x802B386C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B3870: bgtzl       $v0, L_802B3880
    if (SIGNED(ctx->r2) > 0) {
        // 0x802B3874: sra         $v1, $v0, 4
        ctx->r3 = S32(SIGNED(ctx->r2) >> 4);
            goto L_802B3880;
    }
    goto skip_7;
    // 0x802B3874: sra         $v1, $v0, 4
    ctx->r3 = S32(SIGNED(ctx->r2) >> 4);
    skip_7:
    // 0x802B3878: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B387C:
    // 0x802B387C: sra         $v1, $v0, 4
    ctx->r3 = S32(SIGNED(ctx->r2) >> 4);
L_802B3880:
    // 0x802B3880: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x802B3884: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B3888: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x802B388C: sw          $v1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r3;
    // 0x802B3890: jal         0x80349280
    // 0x802B3894: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    func_80349280_75A930(rdram, ctx);
        goto after_6;
    // 0x802B3894: sh          $v0, 0x3E($sp)
    MEM_H(0X3E, ctx->r29) = ctx->r2;
    after_6:
    // 0x802B3898: lh          $v0, 0x3E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X3E);
    // 0x802B389C: lw          $v1, 0x28($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X28);
    // 0x802B38A0: blezl       $v0, L_802B38EC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x802B38A4: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B38EC;
    }
    goto skip_8;
    // 0x802B38A4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_8:
    // 0x802B38A8: bgtz        $v1, L_802B38B8
    if (SIGNED(ctx->r3) > 0) {
        // 0x802B38AC: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802B38B8;
    }
    // 0x802B38AC: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802B38B0: b           L_802B38B8
    // 0x802B38B4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
        goto L_802B38B8;
    // 0x802B38B4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_802B38B8:
    // 0x802B38B8: lh          $v0, 0x14C($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X14C);
    // 0x802B38BC: subu        $t6, $v0, $a0
    ctx->r14 = SUB32(ctx->r2, ctx->r4);
    // 0x802B38C0: bgez        $t6, L_802B38D0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802B38C4: nop
    
            goto L_802B38D0;
    }
    // 0x802B38C4: nop

    // 0x802B38C8: b           L_802B38E8
    // 0x802B38CC: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802B38E8;
    // 0x802B38CC: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
L_802B38D0:
    // 0x802B38D0: bgtz        $v1, L_802B38E0
    if (SIGNED(ctx->r3) > 0) {
        // 0x802B38D4: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802B38E0;
    }
    // 0x802B38D4: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802B38D8: b           L_802B38E0
    // 0x802B38DC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
        goto L_802B38E0;
    // 0x802B38DC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_802B38E0:
    // 0x802B38E0: subu        $t7, $v0, $a0
    ctx->r15 = SUB32(ctx->r2, ctx->r4);
    // 0x802B38E4: sh          $t7, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r15;
L_802B38E8:
    // 0x802B38E8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802B38EC:
    // 0x802B38EC: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x802B38F0: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x802B38F4: jr          $ra
    // 0x802B38F8: nop

    return;
    // 0x802B38F8: nop

;}
RECOMP_FUNC void func_802B38FC_6C4FAC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B38FC: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802B3900: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B3904: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B3908: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x802B390C: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x802B3910: sw          $a3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r7;
    // 0x802B3914: lw          $t7, 0x4C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X4C);
    // 0x802B3918: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x802B391C: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802B3920: sll         $t9, $t7, 26
    ctx->r25 = S32(ctx->r15 << 26);
    // 0x802B3924: bltz        $t9, L_802B3938
    if (SIGNED(ctx->r25) < 0) {
        // 0x802B3928: or          $s0, $a0, $zero
        ctx->r16 = ctx->r4 | 0;
            goto L_802B3938;
    }
    // 0x802B3928: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802B392C: lb          $t0, 0x4A($a0)
    ctx->r8 = MEM_B(ctx->r4, 0X4A);
    // 0x802B3930: beql        $t0, $zero, L_802B3940
    if (ctx->r8 == 0) {
        // 0x802B3934: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B3940;
    }
    goto skip_0;
    // 0x802B3934: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_0:
L_802B3938:
    // 0x802B3938: sh          $zero, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = 0;
    // 0x802B393C: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
L_802B3940:
    // 0x802B3940: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x802B3944: lbu         $t1, 0x8B($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X8B);
    // 0x802B3948: bnel        $t1, $at, L_802B3958
    if (ctx->r9 != ctx->r1) {
        // 0x802B394C: lh          $t2, 0x32($sp)
        ctx->r10 = MEM_H(ctx->r29, 0X32);
            goto L_802B3958;
    }
    goto skip_1;
    // 0x802B394C: lh          $t2, 0x32($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X32);
    skip_1:
    // 0x802B3950: sh          $zero, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = 0;
    // 0x802B3954: lh          $t2, 0x32($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X32);
L_802B3958:
    // 0x802B3958: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B395C: bltzl       $t2, L_802B3A3C
    if (SIGNED(ctx->r10) < 0) {
        // 0x802B3960: lw          $t2, 0x80($v1)
        ctx->r10 = MEM_W(ctx->r3, 0X80);
            goto L_802B3A3C;
    }
    goto skip_2;
    // 0x802B3960: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    skip_2:
    // 0x802B3964: lw          $t3, 0x80($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X80);
    // 0x802B3968: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B396C: sll         $t5, $t3, 18
    ctx->r13 = S32(ctx->r11 << 18);
    // 0x802B3970: bgezl       $t5, L_802B3A3C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802B3974: lw          $t2, 0x80($v1)
        ctx->r10 = MEM_W(ctx->r3, 0X80);
            goto L_802B3A3C;
    }
    goto skip_3;
    // 0x802B3974: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    skip_3:
    // 0x802B3978: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x802B397C: lui         $t8, 0x801E
    ctx->r24 = S32(0X801E << 16);
    // 0x802B3980: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802B3984: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802B3988: lw          $t8, -0x2274($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X2274);
    // 0x802B398C: beql        $s0, $t8, L_802B3A3C
    if (ctx->r16 == ctx->r24) {
        // 0x802B3990: lw          $t2, 0x80($v1)
        ctx->r10 = MEM_W(ctx->r3, 0X80);
            goto L_802B3A3C;
    }
    goto skip_4;
    // 0x802B3990: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    skip_4:
    // 0x802B3994: lb          $t9, 0xE6($v1)
    ctx->r25 = MEM_B(ctx->r3, 0XE6);
    // 0x802B3998: subu        $v0, $t9, $t2
    ctx->r2 = SUB32(ctx->r25, ctx->r10);
    // 0x802B399C: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802B39A0: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B39A4: addiu       $t3, $t1, -0x2
    ctx->r11 = ADD32(ctx->r9, -0X2);
    // 0x802B39A8: sltiu       $at, $t3, 0x6
    ctx->r1 = ctx->r11 < 0X6 ? 1 : 0;
    // 0x802B39AC: beq         $at, $zero, L_802B3A38
    if (ctx->r1 == 0) {
        // 0x802B39B0: sll         $t3, $t3, 2
        ctx->r11 = S32(ctx->r11 << 2);
            goto L_802B3A38;
    }
    // 0x802B39B0: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x802B39B4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B39B8: addu        $at, $at, $t3
    gpr jr_addend_802B39C0 = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802B39BC: lw          $t3, -0x4164($at)
    ctx->r11 = ADD32(ctx->r1, -0X4164);
    // 0x802B39C0: jr          $t3
    // 0x802B39C4: nop

    switch (jr_addend_802B39C0 >> 2) {
        case 0: goto L_802B39C8; break;
        case 1: goto L_802B39E8; break;
        case 2: goto L_802B3A04; break;
        case 3: goto L_802B3A24; break;
        case 4: goto L_802B3A24; break;
        case 5: goto L_802B3A24; break;
        default: switch_error(__func__, 0x802B39C0, 0x803BBE9C);
    }
    // 0x802B39C4: nop

L_802B39C8:
    // 0x802B39C8: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B39CC: sll         $t4, $a2, 2
    ctx->r12 = S32(ctx->r6 << 2);
    // 0x802B39D0: subu        $t4, $t4, $a2
    ctx->r12 = SUB32(ctx->r12, ctx->r6);
    // 0x802B39D4: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x802B39D8: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802B39DC: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802B39E0: b           L_802B3A38
    // 0x802B39E4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
        goto L_802B3A38;
    // 0x802B39E4: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
L_802B39E8:
    // 0x802B39E8: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B39EC: sll         $t8, $a2, 3
    ctx->r24 = S32(ctx->r6 << 3);
    // 0x802B39F0: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x802B39F4: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802B39F8: sll         $t2, $t9, 16
    ctx->r10 = S32(ctx->r25 << 16);
    // 0x802B39FC: b           L_802B3A38
    // 0x802B3A00: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
        goto L_802B3A38;
    // 0x802B3A00: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
L_802B3A04:
    // 0x802B3A04: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B3A08: sll         $t1, $a2, 2
    ctx->r9 = S32(ctx->r6 << 2);
    // 0x802B3A0C: subu        $t1, $t1, $a2
    ctx->r9 = SUB32(ctx->r9, ctx->r6);
    // 0x802B3A10: sll         $t1, $t1, 1
    ctx->r9 = S32(ctx->r9 << 1);
    // 0x802B3A14: sra         $t3, $t1, 4
    ctx->r11 = S32(SIGNED(ctx->r9) >> 4);
    // 0x802B3A18: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x802B3A1C: b           L_802B3A38
    // 0x802B3A20: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
        goto L_802B3A38;
    // 0x802B3A20: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
L_802B3A24:
    // 0x802B3A24: lh          $a2, 0x2E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X2E);
    // 0x802B3A28: sll         $t6, $a2, 2
    ctx->r14 = S32(ctx->r6 << 2);
    // 0x802B3A2C: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802B3A30: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802B3A34: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
L_802B3A38:
    // 0x802B3A38: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
L_802B3A3C:
    // 0x802B3A3C: sll         $t1, $t2, 18
    ctx->r9 = S32(ctx->r10 << 18);
    // 0x802B3A40: bgezl       $t1, L_802B3AD8
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802B3A44: lh          $t5, 0x2E($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X2E);
            goto L_802B3AD8;
    }
    goto skip_5;
    // 0x802B3A44: lh          $t5, 0x2E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2E);
    skip_5:
    // 0x802B3A48: beql        $a3, $zero, L_802B3AD8
    if (ctx->r7 == 0) {
        // 0x802B3A4C: lh          $t5, 0x2E($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X2E);
            goto L_802B3AD8;
    }
    goto skip_6;
    // 0x802B3A4C: lh          $t5, 0x2E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2E);
    skip_6:
    // 0x802B3A50: lh          $t3, 0x14C($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X14C);
    // 0x802B3A54: slti        $at, $a2, 0x1E1
    ctx->r1 = SIGNED(ctx->r6) < 0X1E1 ? 1 : 0;
    // 0x802B3A58: subu        $t4, $t3, $a2
    ctx->r12 = SUB32(ctx->r11, ctx->r6);
    // 0x802B3A5C: blezl       $t4, L_802B3AD8
    if (SIGNED(ctx->r12) <= 0) {
        // 0x802B3A60: lh          $t5, 0x2E($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X2E);
            goto L_802B3AD8;
    }
    goto skip_7;
    // 0x802B3A60: lh          $t5, 0x2E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2E);
    skip_7:
    // 0x802B3A64: bne         $at, $zero, L_802B3A88
    if (ctx->r1 != 0) {
        // 0x802B3A68: addiu       $a0, $zero, 0xE
        ctx->r4 = ADD32(0, 0XE);
            goto L_802B3A88;
    }
    // 0x802B3A68: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x802B3A6C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B3A70: jal         0x802DBA58
    // 0x802B3A74: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_0;
    // 0x802B3A74: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    after_0:
    // 0x802B3A78: jal         0x8034A684
    // 0x802B3A7C: nop

    spawn_dizzy_stars_big(rdram, ctx);
        goto after_1;
    // 0x802B3A7C: nop

    after_1:
    // 0x802B3A80: b           L_802B3AD4
    // 0x802B3A84: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
        goto L_802B3AD4;
    // 0x802B3A84: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
L_802B3A88:
    // 0x802B3A88: slti        $at, $a2, 0xC1
    ctx->r1 = SIGNED(ctx->r6) < 0XC1 ? 1 : 0;
    // 0x802B3A8C: bne         $at, $zero, L_802B3AB0
    if (ctx->r1 != 0) {
        // 0x802B3A90: addiu       $a0, $zero, 0xE
        ctx->r4 = ADD32(0, 0XE);
            goto L_802B3AB0;
    }
    // 0x802B3A90: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x802B3A94: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B3A98: jal         0x802DBA58
    // 0x802B3A9C: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_2;
    // 0x802B3A9C: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    after_2:
    // 0x802B3AA0: jal         0x8034A914
    // 0x802B3AA4: nop

    spawn_dizzy_stars_medium(rdram, ctx);
        goto after_3;
    // 0x802B3AA4: nop

    after_3:
    // 0x802B3AA8: b           L_802B3AD4
    // 0x802B3AAC: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
        goto L_802B3AD4;
    // 0x802B3AAC: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
L_802B3AB0:
    // 0x802B3AB0: slti        $at, $a2, 0x40
    ctx->r1 = SIGNED(ctx->r6) < 0X40 ? 1 : 0;
    // 0x802B3AB4: bne         $at, $zero, L_802B3AD4
    if (ctx->r1 != 0) {
        // 0x802B3AB8: addiu       $a0, $zero, 0xD
        ctx->r4 = ADD32(0, 0XD);
            goto L_802B3AD4;
    }
    // 0x802B3AB8: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    // 0x802B3ABC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B3AC0: jal         0x802DBA58
    // 0x802B3AC4: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    func_802DBA58_6ED108(rdram, ctx);
        goto after_4;
    // 0x802B3AC4: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    after_4:
    // 0x802B3AC8: jal         0x8034ABA4
    // 0x802B3ACC: nop

    spawn_dizzy_starts_small(rdram, ctx);
        goto after_5;
    // 0x802B3ACC: nop

    after_5:
    // 0x802B3AD0: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
L_802B3AD4:
    // 0x802B3AD4: lh          $t5, 0x2E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X2E);
L_802B3AD8:
    // 0x802B3AD8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B3ADC: beql        $t5, $zero, L_802B3AF4
    if (ctx->r13 == 0) {
        // 0x802B3AE0: slti        $at, $a2, 0x23
        ctx->r1 = SIGNED(ctx->r6) < 0X23 ? 1 : 0;
            goto L_802B3AF4;
    }
    goto skip_8;
    // 0x802B3AE0: slti        $at, $a2, 0x23
    ctx->r1 = SIGNED(ctx->r6) < 0X23 ? 1 : 0;
    skip_8:
    // 0x802B3AE4: bgtzl       $a2, L_802B3AF4
    if (SIGNED(ctx->r6) > 0) {
        // 0x802B3AE8: slti        $at, $a2, 0x23
        ctx->r1 = SIGNED(ctx->r6) < 0X23 ? 1 : 0;
            goto L_802B3AF4;
    }
    goto skip_9;
    // 0x802B3AE8: slti        $at, $a2, 0x23
    ctx->r1 = SIGNED(ctx->r6) < 0X23 ? 1 : 0;
    skip_9:
    // 0x802B3AEC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x802B3AF0: slti        $at, $a2, 0x23
    ctx->r1 = SIGNED(ctx->r6) < 0X23 ? 1 : 0;
L_802B3AF4:
    // 0x802B3AF4: bnel        $at, $zero, L_802B3B04
    if (ctx->r1 != 0) {
        // 0x802B3AF8: sll         $a1, $a2, 16
        ctx->r5 = S32(ctx->r6 << 16);
            goto L_802B3B04;
    }
    goto skip_10;
    // 0x802B3AF8: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
    skip_10:
    // 0x802B3AFC: addiu       $a2, $zero, 0x23
    ctx->r6 = ADD32(0, 0X23);
    // 0x802B3B00: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
L_802B3B04:
    // 0x802B3B04: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B3B08: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802B3B0C: jal         0x80349280
    // 0x802B3B10: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    func_80349280_75A930(rdram, ctx);
        goto after_6;
    // 0x802B3B10: sh          $a2, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r6;
    after_6:
    // 0x802B3B14: lh          $a2, 0x26($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X26);
    // 0x802B3B18: lh          $t7, 0x14C($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X14C);
    // 0x802B3B1C: subu        $v0, $t7, $a2
    ctx->r2 = SUB32(ctx->r15, ctx->r6);
    // 0x802B3B20: bgezl       $v0, L_802B3B34
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B3B24: sh          $v0, 0x14C($s0)
        MEM_H(0X14C, ctx->r16) = ctx->r2;
            goto L_802B3B34;
    }
    goto skip_11;
    // 0x802B3B24: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
    skip_11:
    // 0x802B3B28: b           L_802B3B34
    // 0x802B3B2C: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
        goto L_802B3B34;
    // 0x802B3B2C: sh          $zero, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = 0;
    // 0x802B3B30: sh          $v0, 0x14C($s0)
    MEM_H(0X14C, ctx->r16) = ctx->r2;
L_802B3B34:
    // 0x802B3B34: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B3B38: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B3B3C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802B3B40: jr          $ra
    // 0x802B3B44: nop

    return;
    // 0x802B3B44: nop

;}
RECOMP_FUNC void func_802B3B48_6C51F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3B48: lw          $t7, 0x16C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X16C);
    // 0x802B3B4C: lh          $v1, 0x0($a2)
    ctx->r3 = MEM_H(ctx->r6, 0X0);
    // 0x802B3B50: lbu         $t8, 0xE6($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0XE6);
    // 0x802B3B54: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802B3B58: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B3B5C: sltiu       $at, $t8, 0x5
    ctx->r1 = ctx->r24 < 0X5 ? 1 : 0;
    // 0x802B3B60: beq         $at, $zero, L_802B3BD8
    if (ctx->r1 == 0) {
        // 0x802B3B64: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_802B3BD8;
    }
    // 0x802B3B64: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802B3B68: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802B3B6C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B3B70: addu        $at, $at, $t8
    gpr jr_addend_802B3B78 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802B3B74: lw          $t8, -0x414C($at)
    ctx->r24 = ADD32(ctx->r1, -0X414C);
    // 0x802B3B78: jr          $t8
    // 0x802B3B7C: nop

    switch (jr_addend_802B3B78 >> 2) {
        case 0: goto L_802B3B80; break;
        case 1: goto L_802B3B98; break;
        case 2: goto L_802B3BB0; break;
        case 3: goto L_802B3BB8; break;
        case 4: goto L_802B3BC8; break;
        default: switch_error(__func__, 0x802B3B78, 0x803BBEB4);
    }
    // 0x802B3B7C: nop

L_802B3B80:
    // 0x802B3B80: sll         $t9, $v1, 3
    ctx->r25 = S32(ctx->r3 << 3);
    // 0x802B3B84: addu        $t9, $t9, $v1
    ctx->r25 = ADD32(ctx->r25, ctx->r3);
    // 0x802B3B88: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802B3B8C: sra         $t0, $t9, 4
    ctx->r8 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802B3B90: b           L_802B3BD8
    // 0x802B3B94: sh          $t0, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r8;
        goto L_802B3BD8;
    // 0x802B3B94: sh          $t0, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r8;
L_802B3B98:
    // 0x802B3B98: sll         $t1, $v1, 2
    ctx->r9 = S32(ctx->r3 << 2);
    // 0x802B3B9C: subu        $t1, $t1, $v1
    ctx->r9 = SUB32(ctx->r9, ctx->r3);
    // 0x802B3BA0: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x802B3BA4: sra         $t2, $t1, 4
    ctx->r10 = S32(SIGNED(ctx->r9) >> 4);
    // 0x802B3BA8: b           L_802B3BD8
    // 0x802B3BAC: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
        goto L_802B3BD8;
    // 0x802B3BAC: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
L_802B3BB0:
    // 0x802B3BB0: b           L_802B3BD8
    // 0x802B3BB4: sh          $v1, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r3;
        goto L_802B3BD8;
    // 0x802B3BB4: sh          $v1, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r3;
L_802B3BB8:
    // 0x802B3BB8: sll         $t5, $v1, 3
    ctx->r13 = S32(ctx->r3 << 3);
    // 0x802B3BBC: sra         $t6, $t5, 4
    ctx->r14 = S32(SIGNED(ctx->r13) >> 4);
    // 0x802B3BC0: b           L_802B3BD8
    // 0x802B3BC4: sh          $t6, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r14;
        goto L_802B3BD8;
    // 0x802B3BC4: sh          $t6, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r14;
L_802B3BC8:
    // 0x802B3BC8: sll         $t7, $v1, 2
    ctx->r15 = S32(ctx->r3 << 2);
    // 0x802B3BCC: addu        $t7, $t7, $v1
    ctx->r15 = ADD32(ctx->r15, ctx->r3);
    // 0x802B3BD0: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802B3BD4: sh          $t8, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r24;
L_802B3BD8:
    // 0x802B3BD8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B3BDC: lh          $t9, 0x5534($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5534);
    // 0x802B3BE0: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x802B3BE4: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x802B3BE8: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x802B3BEC: lw          $t1, -0x2274($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X2274);
    // 0x802B3BF0: beq         $a0, $t1, L_802B3C6C
    if (ctx->r4 == ctx->r9) {
        // 0x802B3BF4: nop
    
            goto L_802B3C6C;
    }
    // 0x802B3BF4: nop

    // 0x802B3BF8: lw          $t2, 0x16C($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X16C);
    // 0x802B3BFC: lw          $t4, 0x16C($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X16C);
    // 0x802B3C00: lb          $t3, 0xE6($t2)
    ctx->r11 = MEM_B(ctx->r10, 0XE6);
    // 0x802B3C04: lb          $t5, 0xE6($t4)
    ctx->r13 = MEM_B(ctx->r12, 0XE6);
    // 0x802B3C08: subu        $v1, $t3, $t5
    ctx->r3 = SUB32(ctx->r11, ctx->r13);
    // 0x802B3C0C: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802B3C10: sra         $v1, $t6, 16
    ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B3C14: addiu       $t8, $v1, -0x2
    ctx->r24 = ADD32(ctx->r3, -0X2);
    // 0x802B3C18: sltiu       $at, $t8, 0x6
    ctx->r1 = ctx->r24 < 0X6 ? 1 : 0;
    // 0x802B3C1C: beq         $at, $zero, L_802B3C6C
    if (ctx->r1 == 0) {
        // 0x802B3C20: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_802B3C6C;
    }
    // 0x802B3C20: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802B3C24: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B3C28: addu        $at, $at, $t8
    gpr jr_addend_802B3C30 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x802B3C2C: lw          $t8, -0x4138($at)
    ctx->r24 = ADD32(ctx->r1, -0X4138);
    // 0x802B3C30: jr          $t8
    // 0x802B3C34: nop

    switch (jr_addend_802B3C30 >> 2) {
        case 0: goto L_802B3C38; break;
        case 1: goto L_802B3C48; break;
        case 2: goto L_802B3C58; break;
        case 3: goto L_802B3C68; break;
        case 4: goto L_802B3C68; break;
        case 5: goto L_802B3C68; break;
        default: switch_error(__func__, 0x802B3C30, 0x803BBEC8);
    }
    // 0x802B3C34: nop

L_802B3C38:
    // 0x802B3C38: lh          $t9, 0x0($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X0);
    // 0x802B3C3C: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B3C40: b           L_802B3C6C
    // 0x802B3C44: sh          $t0, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r8;
        goto L_802B3C6C;
    // 0x802B3C44: sh          $t0, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r8;
L_802B3C48:
    // 0x802B3C48: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x802B3C4C: sra         $t2, $t1, 2
    ctx->r10 = S32(SIGNED(ctx->r9) >> 2);
    // 0x802B3C50: b           L_802B3C6C
    // 0x802B3C54: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
        goto L_802B3C6C;
    // 0x802B3C54: sh          $t2, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r10;
L_802B3C58:
    // 0x802B3C58: lh          $t4, 0x0($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X0);
    // 0x802B3C5C: sra         $t3, $t4, 3
    ctx->r11 = S32(SIGNED(ctx->r12) >> 3);
    // 0x802B3C60: b           L_802B3C6C
    // 0x802B3C64: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
        goto L_802B3C6C;
    // 0x802B3C64: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
L_802B3C68:
    // 0x802B3C68: sh          $zero, 0x0($a2)
    MEM_H(0X0, ctx->r6) = 0;
L_802B3C6C:
    // 0x802B3C6C: beq         $v0, $zero, L_802B3C94
    if (ctx->r2 == 0) {
        // 0x802B3C70: nop
    
            goto L_802B3C94;
    }
    // 0x802B3C70: nop

    // 0x802B3C74: lh          $v1, 0x0($a2)
    ctx->r3 = MEM_H(ctx->r6, 0X0);
    // 0x802B3C78: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802B3C7C: slti        $at, $v1, 0x2
    ctx->r1 = SIGNED(ctx->r3) < 0X2 ? 1 : 0;
    // 0x802B3C80: bnel        $at, $zero, L_802B3C94
    if (ctx->r1 != 0) {
        // 0x802B3C84: sh          $t5, 0x0($a2)
        MEM_H(0X0, ctx->r6) = ctx->r13;
            goto L_802B3C94;
    }
    goto skip_0;
    // 0x802B3C84: sh          $t5, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r13;
    skip_0:
    // 0x802B3C88: jr          $ra
    // 0x802B3C8C: sh          $v1, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r3;
    return;
    // 0x802B3C8C: sh          $v1, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r3;
    // 0x802B3C90: sh          $t5, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r13;
L_802B3C94:
    // 0x802B3C94: jr          $ra
    // 0x802B3C98: nop

    return;
    // 0x802B3C98: nop

;}
RECOMP_FUNC void func_802B3C9C_6C534C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3C9C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802B3CA0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802B3CA4: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B3CA8: bnel        $a0, $zero, L_802B3CBC
    if (ctx->r4 != 0) {
        // 0x802B3CAC: lw          $t8, 0x16C($a1)
        ctx->r24 = MEM_W(ctx->r5, 0X16C);
            goto L_802B3CBC;
    }
    goto skip_0;
    // 0x802B3CAC: lw          $t8, 0x16C($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X16C);
    skip_0:
    // 0x802B3CB0: jr          $ra
    // 0x802B3CB4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x802B3CB4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802B3CB8: lw          $t8, 0x16C($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X16C);
L_802B3CBC:
    // 0x802B3CBC: lbu         $t9, 0xE6($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0XE6);
    // 0x802B3CC0: sltiu       $at, $t9, 0x5
    ctx->r1 = ctx->r25 < 0X5 ? 1 : 0;
    // 0x802B3CC4: beq         $at, $zero, L_802B3D44
    if (ctx->r1 == 0) {
        // 0x802B3CC8: sll         $t9, $t9, 2
        ctx->r25 = S32(ctx->r25 << 2);
            goto L_802B3D44;
    }
    // 0x802B3CC8: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x802B3CCC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B3CD0: addu        $at, $at, $t9
    gpr jr_addend_802B3CD8 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x802B3CD4: lw          $t9, -0x4120($at)
    ctx->r25 = ADD32(ctx->r1, -0X4120);
    // 0x802B3CD8: jr          $t9
    // 0x802B3CDC: nop

    switch (jr_addend_802B3CD8 >> 2) {
        case 0: goto L_802B3CE0; break;
        case 1: goto L_802B3CF4; break;
        case 2: goto L_802B3D44; break;
        case 3: goto L_802B3D10; break;
        case 4: goto L_802B3D2C; break;
        default: switch_error(__func__, 0x802B3CD8, 0x803BBEE0);
    }
    // 0x802B3CDC: nop

L_802B3CE0:
    // 0x802B3CE0: sll         $t0, $a0, 5
    ctx->r8 = S32(ctx->r4 << 5);
    // 0x802B3CE4: sra         $t1, $t0, 4
    ctx->r9 = S32(SIGNED(ctx->r8) >> 4);
    // 0x802B3CE8: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x802B3CEC: b           L_802B3D44
    // 0x802B3CF0: sra         $a0, $t2, 16
    ctx->r4 = S32(SIGNED(ctx->r10) >> 16);
        goto L_802B3D44;
    // 0x802B3CF0: sra         $a0, $t2, 16
    ctx->r4 = S32(SIGNED(ctx->r10) >> 16);
L_802B3CF4:
    // 0x802B3CF4: sll         $t4, $a0, 2
    ctx->r12 = S32(ctx->r4 << 2);
    // 0x802B3CF8: subu        $t4, $t4, $a0
    ctx->r12 = SUB32(ctx->r12, ctx->r4);
    // 0x802B3CFC: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x802B3D00: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x802B3D04: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802B3D08: b           L_802B3D44
    // 0x802B3D0C: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
        goto L_802B3D44;
    // 0x802B3D0C: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
L_802B3D10:
    // 0x802B3D10: sll         $t8, $a0, 2
    ctx->r24 = S32(ctx->r4 << 2);
    // 0x802B3D14: addu        $t8, $t8, $a0
    ctx->r24 = ADD32(ctx->r24, ctx->r4);
    // 0x802B3D18: sll         $t8, $t8, 1
    ctx->r24 = S32(ctx->r24 << 1);
    // 0x802B3D1C: sra         $t9, $t8, 4
    ctx->r25 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802B3D20: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x802B3D24: b           L_802B3D44
    // 0x802B3D28: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
        goto L_802B3D44;
    // 0x802B3D28: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
L_802B3D2C:
    // 0x802B3D2C: sll         $t2, $a0, 2
    ctx->r10 = S32(ctx->r4 << 2);
    // 0x802B3D30: subu        $t2, $t2, $a0
    ctx->r10 = SUB32(ctx->r10, ctx->r4);
    // 0x802B3D34: sll         $t2, $t2, 1
    ctx->r10 = S32(ctx->r10 << 1);
    // 0x802B3D38: sra         $t3, $t2, 4
    ctx->r11 = S32(SIGNED(ctx->r10) >> 4);
    // 0x802B3D3C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x802B3D40: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
L_802B3D44:
    // 0x802B3D44: bgtz        $a0, L_802B3D54
    if (SIGNED(ctx->r4) > 0) {
        // 0x802B3D48: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_802B3D54;
    }
    // 0x802B3D48: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x802B3D4C: b           L_802B3D54
    // 0x802B3D50: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_802B3D54;
    // 0x802B3D50: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_802B3D54:
    // 0x802B3D54: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802B3D58: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B3D5C: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802B3D60: jr          $ra
    // 0x802B3D64: nop

    return;
    // 0x802B3D64: nop

;}
RECOMP_FUNC void func_802B3D68_6C5418(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3D68: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B3D6C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x802B3D70: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802B3D74: lwc1        $f2, 0x2C44($at)
    ctx->f2.u32l = MEM_W(ctx->r1, 0X2C44);
    // 0x802B3D78: lh          $t6, 0x4($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X4);
    // 0x802B3D7C: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802B3D80: nop

    // 0x802B3D84: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802B3D88: c.lt.s      $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f0.fl < ctx->f2.fl;
    // 0x802B3D8C: nop

    // 0x802B3D90: bc1fl       L_802B3DA8
    if (!c1cs) {
        // 0x802B3D94: sub.s       $f12, $f0, $f2
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
            goto L_802B3DA8;
    }
    goto skip_0;
    // 0x802B3D94: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    skip_0:
    // 0x802B3D98: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    // 0x802B3D9C: b           L_802B3DA8
    // 0x802B3DA0: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
        goto L_802B3DA8;
    // 0x802B3DA0: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
    // 0x802B3DA4: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
L_802B3DA8:
    // 0x802B3DA8: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x802B3DAC: trunc.w.s   $f6, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    ctx->f6.u32l = TRUNC_W_S(ctx->f12.fl);
    // 0x802B3DB0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802B3DB4: mtc1        $t3, $f8
    ctx->f8.u32l = ctx->r11;
    // 0x802B3DB8: lwc1        $f2, 0x2C48($at)
    ctx->f2.u32l = MEM_W(ctx->r1, 0X2C48);
    // 0x802B3DBC: mfc1        $v1, $f6
    ctx->r3 = (int32_t)ctx->f6.u32l;
    // 0x802B3DC0: cvt.s.w     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    ctx->f0.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802B3DC4: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802B3DC8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B3DCC: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B3DD0: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802B3DD4: c.lt.s      $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f0.fl < ctx->f2.fl;
    // 0x802B3DD8: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802B3DDC: bc1fl       L_802B3DF4
    if (!c1cs) {
        // 0x802B3DE0: sub.s       $f12, $f0, $f2
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
            goto L_802B3DF4;
    }
    goto skip_1;
    // 0x802B3DE0: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    skip_1:
    // 0x802B3DE4: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    // 0x802B3DE8: b           L_802B3DF4
    // 0x802B3DEC: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
        goto L_802B3DF4;
    // 0x802B3DEC: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
    // 0x802B3DF0: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
L_802B3DF4:
    // 0x802B3DF4: lh          $t0, 0xC($v0)
    ctx->r8 = MEM_H(ctx->r2, 0XC);
    // 0x802B3DF8: trunc.w.s   $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    ctx->f10.u32l = TRUNC_W_S(ctx->f12.fl);
    // 0x802B3DFC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802B3E00: mtc1        $t0, $f16
    ctx->f16.u32l = ctx->r8;
    // 0x802B3E04: lwc1        $f2, 0x2C4C($at)
    ctx->f2.u32l = MEM_W(ctx->r1, 0X2C4C);
    // 0x802B3E08: mfc1        $a0, $f10
    ctx->r4 = (int32_t)ctx->f10.u32l;
    // 0x802B3E0C: cvt.s.w     $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    ctx->f0.fl = CVT_S_W(ctx->f16.u32l);
    // 0x802B3E10: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x802B3E14: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B3E18: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802B3E1C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802B3E20: c.lt.s      $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f0.fl < ctx->f2.fl;
    // 0x802B3E24: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B3E28: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B3E2C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802B3E30: bc1fl       L_802B3E48
    if (!c1cs) {
        // 0x802B3E34: sub.s       $f12, $f0, $f2
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
            goto L_802B3E48;
    }
    goto skip_2;
    // 0x802B3E34: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    skip_2:
    // 0x802B3E38: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
    // 0x802B3E3C: b           L_802B3E48
    // 0x802B3E40: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
        goto L_802B3E48;
    // 0x802B3E40: neg.s       $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = -ctx->f12.fl;
    // 0x802B3E44: sub.s       $f12, $f0, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = ctx->f0.fl - ctx->f2.fl;
L_802B3E48:
    // 0x802B3E48: beq         $at, $zero, L_802B3E58
    if (ctx->r1 == 0) {
        // 0x802B3E4C: trunc.w.s   $f18, $f12
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    ctx->f18.u32l = TRUNC_W_S(ctx->f12.fl);
            goto L_802B3E58;
    }
    // 0x802B3E4C: trunc.w.s   $f18, $f12
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    ctx->f18.u32l = TRUNC_W_S(ctx->f12.fl);
    // 0x802B3E50: b           L_802B3E58
    // 0x802B3E54: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
        goto L_802B3E58;
    // 0x802B3E54: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_802B3E58:
    // 0x802B3E58: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
    // 0x802B3E5C: nop

    // 0x802B3E60: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x802B3E64: sra         $t3, $t2, 16
    ctx->r11 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802B3E68: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x802B3E6C: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x802B3E70: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B3E74: slt         $at, $a2, $v0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B3E78: beq         $at, $zero, L_802B3E9C
    if (ctx->r1 == 0) {
        // 0x802B3E7C: or          $a1, $a2, $zero
        ctx->r5 = ctx->r6 | 0;
            goto L_802B3E9C;
    }
    // 0x802B3E7C: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
    // 0x802B3E80: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B3E84: beq         $at, $zero, L_802B3E94
    if (ctx->r1 == 0) {
        // 0x802B3E88: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802B3E94;
    }
    // 0x802B3E88: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802B3E8C: b           L_802B3E9C
    // 0x802B3E90: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
        goto L_802B3E9C;
    // 0x802B3E90: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
L_802B3E94:
    // 0x802B3E94: b           L_802B3E9C
    // 0x802B3E98: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
        goto L_802B3E9C;
    // 0x802B3E98: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
L_802B3E9C:
    // 0x802B3E9C: addu        $t7, $a1, $v1
    ctx->r15 = ADD32(ctx->r5, ctx->r3);
    // 0x802B3EA0: addu        $t8, $t7, $a0
    ctx->r24 = ADD32(ctx->r15, ctx->r4);
    // 0x802B3EA4: addu        $v0, $t8, $a2
    ctx->r2 = ADD32(ctx->r24, ctx->r6);
    // 0x802B3EA8: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B3EAC: jr          $ra
    // 0x802B3EB0: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    return;
    // 0x802B3EB0: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
;}
RECOMP_FUNC void func_802B3EC0_6C5570(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3EC0: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x802B3EC4: addiu       $v0, $v0, 0x5C0
    ctx->r2 = ADD32(ctx->r2, 0X5C0);
    // 0x802B3EC8: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802B3ECC: lh          $t6, 0x0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X0);
    // 0x802B3ED0: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x802B3ED4: lh          $t8, 0x36($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X36);
    // 0x802B3ED8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802B3EDC: subu        $t7, $v1, $t6
    ctx->r15 = SUB32(ctx->r3, ctx->r14);
    // 0x802B3EE0: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802B3EE4: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802B3EE8: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x802B3EEC: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x802B3EF0: beq         $t8, $v1, L_802B3F9C
    if (ctx->r24 == ctx->r3) {
        // 0x802B3EF4: sh          $t7, 0x0($v0)
        MEM_H(0X0, ctx->r2) = ctx->r15;
            goto L_802B3F9C;
    }
    // 0x802B3EF4: sh          $t7, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r15;
    // 0x802B3EF8: lh          $t9, 0x36($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X36);
    // 0x802B3EFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B3F00: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802B3F04: bne         $t9, $zero, L_802B3F34
    if (ctx->r25 != 0) {
        // 0x802B3F08: addiu       $a3, $zero, 0x140
        ctx->r7 = ADD32(0, 0X140);
            goto L_802B3F34;
    }
    // 0x802B3F08: addiu       $a3, $zero, 0x140
    ctx->r7 = ADD32(0, 0X140);
    // 0x802B3F0C: addiu       $t0, $zero, 0xF0
    ctx->r8 = ADD32(0, 0XF0);
    // 0x802B3F10: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x802B3F14: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x802B3F18: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x802B3F1C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802B3F20: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802B3F24: jal         0x8012AD30
    // 0x802B3F28: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    draw_rectangle(rdram, ctx);
        goto after_0;
    // 0x802B3F28: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    after_0:
    // 0x802B3F2C: jal         0x802B4148
    // 0x802B3F30: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    func_802B4148_6C57F8(rdram, ctx);
        goto after_1;
    // 0x802B3F30: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    after_1:
L_802B3F34:
    // 0x802B3F34: lh          $t2, 0x36($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X36);
    // 0x802B3F38: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B3F3C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802B3F40: bne         $t2, $at, L_802B3F9C
    if (ctx->r10 != ctx->r1) {
        // 0x802B3F44: addiu       $v0, $v0, 0x1CF8
        ctx->r2 = ADD32(ctx->r2, 0X1CF8);
            goto L_802B3F9C;
    }
    // 0x802B3F44: addiu       $v0, $v0, 0x1CF8
    ctx->r2 = ADD32(ctx->r2, 0X1CF8);
    // 0x802B3F48: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x802B3F4C: lh          $a3, 0x3FD0($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X3FD0);
    // 0x802B3F50: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x802B3F54: lh          $t5, 0x3FD2($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X3FD2);
    // 0x802B3F58: lbu         $t7, 0x4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X4);
    // 0x802B3F5C: lbu         $t8, 0x5($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X5);
    // 0x802B3F60: lbu         $t9, 0x6($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X6);
    // 0x802B3F64: addiu       $a3, $a3, -0x8
    ctx->r7 = ADD32(ctx->r7, -0X8);
    // 0x802B3F68: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x802B3F6C: addiu       $t0, $zero, 0xFF
    ctx->r8 = ADD32(0, 0XFF);
    // 0x802B3F70: addiu       $t6, $t5, -0x8
    ctx->r14 = ADD32(ctx->r13, -0X8);
    // 0x802B3F74: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802B3F78: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802B3F7C: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802B3F80: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    // 0x802B3F84: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x802B3F88: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    // 0x802B3F8C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802B3F90: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x802B3F94: jal         0x8012AD30
    // 0x802B3F98: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    draw_rectangle(rdram, ctx);
        goto after_2;
    // 0x802B3F98: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    after_2:
L_802B3F9C:
    // 0x802B3F9C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802B3FA0: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802B3FA4: jr          $ra
    // 0x802B3FA8: nop

    return;
    // 0x802B3FA8: nop

;}
RECOMP_FUNC void func_802B3FAC_6C565C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B3FAC: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802B3FB0: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x802B3FB4: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x802B3FB8: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x802B3FBC: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x802B3FC0: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x802B3FC4: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x802B3FC8: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x802B3FCC: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x802B3FD0: lui         $s3, 0x803D
    ctx->r19 = S32(0X803D << 16);
    // 0x802B3FD4: lui         $s4, 0x803D
    ctx->r20 = S32(0X803D << 16);
    // 0x802B3FD8: lui         $s5, 0x803D
    ctx->r21 = S32(0X803D << 16);
    // 0x802B3FDC: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x802B3FE0: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802B3FE4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B3FE8: addiu       $s7, $s7, 0x5E00
    ctx->r23 = ADD32(ctx->r23, 0X5E00);
    // 0x802B3FEC: addiu       $s5, $s5, 0x5B30
    ctx->r21 = ADD32(ctx->r21, 0X5B30);
    // 0x802B3FF0: addiu       $s4, $s4, 0x5860
    ctx->r20 = ADD32(ctx->r20, 0X5860);
    // 0x802B3FF4: addiu       $s3, $s3, 0x5590
    ctx->r19 = ADD32(ctx->r19, 0X5590);
    // 0x802B3FF8: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x802B3FFC: ori         $s2, $zero, 0xFFFA
    ctx->r18 = 0 | 0XFFFA;
    // 0x802B4000: addiu       $s6, $zero, 0x1B58
    ctx->r22 = ADD32(0, 0X1B58);
    // 0x802B4004: addiu       $fp, $zero, 0x64
    ctx->r30 = ADD32(0, 0X64);
L_802B4008:
    // 0x802B4008: jal         0x80140D20
    // 0x802B400C: nop

    guRandom(rdram, ctx);
        goto after_0;
    // 0x802B400C: nop

    after_0:
    // 0x802B4010: div         $zero, $v0, $s2
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r18)));
    // 0x802B4014: mfhi        $t6
    ctx->r14 = hi;
    // 0x802B4018: sll         $s0, $s1, 1
    ctx->r16 = S32(ctx->r17 << 1);
    // 0x802B401C: addu        $t8, $s3, $s0
    ctx->r24 = ADD32(ctx->r19, ctx->r16);
    // 0x802B4020: bne         $s2, $zero, L_802B402C
    if (ctx->r18 != 0) {
        // 0x802B4024: nop
    
            goto L_802B402C;
    }
    // 0x802B4024: nop

    // 0x802B4028: break       7
    do_break(2150318120);
L_802B402C:
    // 0x802B402C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B4030: bne         $s2, $at, L_802B4044
    if (ctx->r18 != ctx->r1) {
        // 0x802B4034: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B4044;
    }
    // 0x802B4034: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B4038: bne         $v0, $at, L_802B4044
    if (ctx->r2 != ctx->r1) {
        // 0x802B403C: nop
    
            goto L_802B4044;
    }
    // 0x802B403C: nop

    // 0x802B4040: break       6
    do_break(2150318144);
L_802B4044:
    // 0x802B4044: addiu       $t7, $t6, -0x7FF8
    ctx->r15 = ADD32(ctx->r14, -0X7FF8);
    // 0x802B4048: jal         0x80140D20
    // 0x802B404C: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    guRandom(rdram, ctx);
        goto after_1;
    // 0x802B404C: sh          $t7, 0x0($t8)
    MEM_H(0X0, ctx->r24) = ctx->r15;
    after_1:
    // 0x802B4050: div         $zero, $v0, $s2
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r18)));
    // 0x802B4054: mfhi        $t9
    ctx->r25 = hi;
    // 0x802B4058: addiu       $t0, $t9, 0x7FF8
    ctx->r8 = ADD32(ctx->r25, 0X7FF8);
    // 0x802B405C: bne         $s2, $zero, L_802B4068
    if (ctx->r18 != 0) {
        // 0x802B4060: nop
    
            goto L_802B4068;
    }
    // 0x802B4060: nop

    // 0x802B4064: break       7
    do_break(2150318180);
L_802B4068:
    // 0x802B4068: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B406C: bne         $s2, $at, L_802B4080
    if (ctx->r18 != ctx->r1) {
        // 0x802B4070: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B4080;
    }
    // 0x802B4070: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B4074: bne         $v0, $at, L_802B4080
    if (ctx->r2 != ctx->r1) {
        // 0x802B4078: nop
    
            goto L_802B4080;
    }
    // 0x802B4078: nop

    // 0x802B407C: break       6
    do_break(2150318204);
L_802B4080:
    // 0x802B4080: addu        $t1, $s4, $s0
    ctx->r9 = ADD32(ctx->r20, ctx->r16);
    // 0x802B4084: jal         0x80140D20
    // 0x802B4088: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    guRandom(rdram, ctx);
        goto after_2;
    // 0x802B4088: sh          $t0, 0x0($t1)
    MEM_H(0X0, ctx->r9) = ctx->r8;
    after_2:
    // 0x802B408C: div         $zero, $v0, $s6
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r22))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r22)));
    // 0x802B4090: mfhi        $t2
    ctx->r10 = hi;
    // 0x802B4094: addiu       $t3, $t2, -0xBB8
    ctx->r11 = ADD32(ctx->r10, -0XBB8);
    // 0x802B4098: bne         $s6, $zero, L_802B40A4
    if (ctx->r22 != 0) {
        // 0x802B409C: nop
    
            goto L_802B40A4;
    }
    // 0x802B409C: nop

    // 0x802B40A0: break       7
    do_break(2150318240);
L_802B40A4:
    // 0x802B40A4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B40A8: bne         $s6, $at, L_802B40BC
    if (ctx->r22 != ctx->r1) {
        // 0x802B40AC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B40BC;
    }
    // 0x802B40AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B40B0: bne         $v0, $at, L_802B40BC
    if (ctx->r2 != ctx->r1) {
        // 0x802B40B4: nop
    
            goto L_802B40BC;
    }
    // 0x802B40B4: nop

    // 0x802B40B8: break       6
    do_break(2150318264);
L_802B40BC:
    // 0x802B40BC: addu        $t4, $s5, $s0
    ctx->r12 = ADD32(ctx->r21, ctx->r16);
    // 0x802B40C0: jal         0x80140D20
    // 0x802B40C4: sh          $t3, 0x0($t4)
    MEM_H(0X0, ctx->r12) = ctx->r11;
    guRandom(rdram, ctx);
        goto after_3;
    // 0x802B40C4: sh          $t3, 0x0($t4)
    MEM_H(0X0, ctx->r12) = ctx->r11;
    after_3:
    // 0x802B40C8: div         $zero, $v0, $fp
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r30))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r30)));
    // 0x802B40CC: bne         $fp, $zero, L_802B40D8
    if (ctx->r30 != 0) {
        // 0x802B40D0: nop
    
            goto L_802B40D8;
    }
    // 0x802B40D0: nop

    // 0x802B40D4: break       7
    do_break(2150318292);
L_802B40D8:
    // 0x802B40D8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B40DC: bne         $fp, $at, L_802B40F0
    if (ctx->r30 != ctx->r1) {
        // 0x802B40E0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B40F0;
    }
    // 0x802B40E0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B40E4: bne         $v0, $at, L_802B40F0
    if (ctx->r2 != ctx->r1) {
        // 0x802B40E8: nop
    
            goto L_802B40F0;
    }
    // 0x802B40E8: nop

    // 0x802B40EC: break       6
    do_break(2150318316);
L_802B40F0:
    // 0x802B40F0: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x802B40F4: sll         $t8, $s1, 16
    ctx->r24 = S32(ctx->r17 << 16);
    // 0x802B40F8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B40FC: mfhi        $t5
    ctx->r13 = hi;
    // 0x802B4100: slti        $at, $t9, 0x168
    ctx->r1 = SIGNED(ctx->r25) < 0X168 ? 1 : 0;
    // 0x802B4104: addiu       $t6, $t5, 0x96
    ctx->r14 = ADD32(ctx->r13, 0X96);
    // 0x802B4108: addu        $t7, $s7, $s0
    ctx->r15 = ADD32(ctx->r23, ctx->r16);
    // 0x802B410C: or          $s1, $t9, $zero
    ctx->r17 = ctx->r25 | 0;
    // 0x802B4110: bne         $at, $zero, L_802B4008
    if (ctx->r1 != 0) {
        // 0x802B4114: sh          $t6, 0x0($t7)
        MEM_H(0X0, ctx->r15) = ctx->r14;
            goto L_802B4008;
    }
    // 0x802B4114: sh          $t6, 0x0($t7)
    MEM_H(0X0, ctx->r15) = ctx->r14;
    // 0x802B4118: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x802B411C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B4120: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x802B4124: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x802B4128: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x802B412C: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x802B4130: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x802B4134: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x802B4138: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x802B413C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x802B4140: jr          $ra
    // 0x802B4144: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x802B4144: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_802B4148_6C57F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B4148: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802B414C: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x802B4150: sw          $fp, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r30;
    // 0x802B4154: sw          $s7, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r23;
    // 0x802B4158: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x802B415C: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x802B4160: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x802B4164: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x802B4168: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x802B416C: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x802B4170: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802B4174: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B4178: lui         $t7, 0xEE00
    ctx->r15 = S32(0XEE00 << 16);
    // 0x802B417C: lui         $t0, 0xE700
    ctx->r8 = S32(0XE700 << 16);
    // 0x802B4180: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x802B4184: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x802B4188: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B418C: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x802B4190: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B4194: lui         $t4, 0x1E
    ctx->r12 = S32(0X1E << 16);
    // 0x802B4198: ori         $t4, $t4, 0x3204
    ctx->r12 = ctx->r12 | 0X3204;
    // 0x802B419C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x802B41A0: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x802B41A4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B41A8: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x802B41AC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B41B0: lui         $t3, 0xB600
    ctx->r11 = S32(0XB600 << 16);
    // 0x802B41B4: lui         $t6, 0xFC30
    ctx->r14 = S32(0XFC30 << 16);
    // 0x802B41B8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x802B41BC: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x802B41C0: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x802B41C4: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x802B41C8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B41CC: ori         $t6, $t6, 0xFE61
    ctx->r14 = ctx->r14 | 0XFE61;
    // 0x802B41D0: addiu       $t7, $zero, -0xC07
    ctx->r15 = ADD32(0, -0XC07);
    // 0x802B41D4: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x802B41D8: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x802B41DC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x802B41E0: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x802B41E4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B41E8: lui         $t3, 0xF0A
    ctx->r11 = S32(0XF0A << 16);
    // 0x802B41EC: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x802B41F0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x802B41F4: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x802B41F8: ori         $t9, $t9, 0x31D
    ctx->r25 = ctx->r25 | 0X31D;
    // 0x802B41FC: ori         $t3, $t3, 0x4000
    ctx->r11 = ctx->r11 | 0X4000;
    // 0x802B4200: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x802B4204: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x802B4208: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x802B420C: or          $s4, $a0, $zero
    ctx->r20 = ctx->r4 | 0;
    // 0x802B4210: lui         $t5, 0xBA00
    ctx->r13 = S32(0XBA00 << 16);
    // 0x802B4214: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x802B4218: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x802B421C: ori         $t5, $t5, 0x1402
    ctx->r13 = ctx->r13 | 0X1402;
    // 0x802B4220: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x802B4224: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B4228: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B422C: lui         $t7, 0xB900
    ctx->r15 = S32(0XB900 << 16);
    // 0x802B4230: ori         $t7, $t7, 0x2
    ctx->r15 = ctx->r15 | 0X2;
    // 0x802B4234: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x802B4238: sw          $t6, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r14;
    // 0x802B423C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802B4240: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x802B4244: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x802B4248: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B424C: lui         $t4, 0x8000
    ctx->r12 = S32(0X8000 << 16);
    // 0x802B4250: lui         $t3, 0xBB00
    ctx->r11 = S32(0XBB00 << 16);
    // 0x802B4254: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x802B4258: sw          $t9, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r25;
    // 0x802B425C: ori         $t3, $t3, 0x1
    ctx->r11 = ctx->r11 | 0X1;
    // 0x802B4260: ori         $t4, $t4, 0x8000
    ctx->r12 = ctx->r12 | 0X8000;
    // 0x802B4264: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x802B4268: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x802B426C: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B4270: lui         $t6, 0xF900
    ctx->r14 = S32(0XF900 << 16);
    // 0x802B4274: lui         $t8, 0xB900
    ctx->r24 = S32(0XB900 << 16);
    // 0x802B4278: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x802B427C: sw          $t5, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r13;
    // 0x802B4280: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B4284: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x802B4288: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B428C: ori         $t8, $t8, 0x201
    ctx->r24 = ctx->r24 | 0X201;
    // 0x802B4290: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x802B4294: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x802B4298: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x802B429C: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x802B42A0: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x802B42A4: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B42A8: lui         $t4, 0xBA00
    ctx->r12 = S32(0XBA00 << 16);
    // 0x802B42AC: ori         $t4, $t4, 0x1301
    ctx->r12 = ctx->r12 | 0X1301;
    // 0x802B42B0: addiu       $t3, $v0, 0x8
    ctx->r11 = ADD32(ctx->r2, 0X8);
    // 0x802B42B4: sw          $t3, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r11;
    // 0x802B42B8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B42BC: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x802B42C0: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B42C4: lui         $t7, 0xB4B4
    ctx->r15 = S32(0XB4B4 << 16);
    // 0x802B42C8: ori         $t7, $t7, 0xDCFF
    ctx->r15 = ctx->r15 | 0XDCFF;
    // 0x802B42CC: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x802B42D0: sw          $t5, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r13;
    // 0x802B42D4: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x802B42D8: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x802B42DC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x802B42E0: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B42E4: lui         $t3, 0x8103
    ctx->r11 = S32(0X8103 << 16);
    // 0x802B42E8: addiu       $t3, $t3, -0x5DF0
    ctx->r11 = ADD32(ctx->r11, -0X5DF0);
    // 0x802B42EC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x802B42F0: sw          $t8, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r24;
    // 0x802B42F4: lui         $t9, 0xFD90
    ctx->r25 = S32(0XFD90 << 16);
    // 0x802B42F8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x802B42FC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x802B4300: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B4304: lui         $t6, 0x701
    ctx->r14 = S32(0X701 << 16);
    // 0x802B4308: ori         $t6, $t6, 0x4050
    ctx->r14 = ctx->r14 | 0X4050;
    // 0x802B430C: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x802B4310: sw          $t4, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r12;
    // 0x802B4314: lui         $t5, 0xF590
    ctx->r13 = S32(0XF590 << 16);
    // 0x802B4318: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x802B431C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x802B4320: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B4324: lui         $t8, 0xE600
    ctx->r24 = S32(0XE600 << 16);
    // 0x802B4328: lui         $t4, 0x71F
    ctx->r12 = S32(0X71F << 16);
    // 0x802B432C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x802B4330: sw          $t7, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r15;
    // 0x802B4334: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B4338: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x802B433C: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B4340: ori         $t4, $t4, 0xF200
    ctx->r12 = ctx->r12 | 0XF200;
    // 0x802B4344: lui         $t3, 0xF300
    ctx->r11 = S32(0XF300 << 16);
    // 0x802B4348: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x802B434C: sw          $t9, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r25;
    // 0x802B4350: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x802B4354: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x802B4358: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B435C: lui         $s6, 0x803A
    ctx->r22 = S32(0X803A << 16);
    // 0x802B4360: lh          $s6, 0x5C8($s6)
    ctx->r22 = MEM_H(ctx->r22, 0X5C8);
    // 0x802B4364: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x802B4368: sw          $t5, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r13;
    // 0x802B436C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802B4370: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x802B4374: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B4378: lui         $t8, 0x1
    ctx->r24 = S32(0X1 << 16);
    // 0x802B437C: lui         $t7, 0xF588
    ctx->r15 = S32(0XF588 << 16);
    // 0x802B4380: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x802B4384: sw          $t6, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r14;
    // 0x802B4388: ori         $t7, $t7, 0x800
    ctx->r15 = ctx->r15 | 0X800;
    // 0x802B438C: ori         $t8, $t8, 0x4050
    ctx->r24 = ctx->r24 | 0X4050;
    // 0x802B4390: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x802B4394: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x802B4398: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x802B439C: lui         $t4, 0x7
    ctx->r12 = S32(0X7 << 16);
    // 0x802B43A0: ori         $t4, $t4, 0xC07C
    ctx->r12 = ctx->r12 | 0XC07C;
    // 0x802B43A4: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x802B43A8: sw          $t9, 0x0($s4)
    MEM_W(0X0, ctx->r20) = ctx->r25;
    // 0x802B43AC: lui         $t3, 0xF200
    ctx->r11 = S32(0XF200 << 16);
    // 0x802B43B0: lui         $t5, 0x803E
    ctx->r13 = S32(0X803E << 16);
    // 0x802B43B4: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x802B43B8: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x802B43BC: lw          $t5, 0x4D30($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X4D30);
    // 0x802B43C0: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x802B43C4: lui         $fp, 0x803D
    ctx->r30 = S32(0X803D << 16);
    // 0x802B43C8: subu        $s6, $s6, $t5
    ctx->r22 = SUB32(ctx->r22, ctx->r13);
    // 0x802B43CC: sll         $t6, $s6, 16
    ctx->r14 = S32(ctx->r22 << 16);
    // 0x802B43D0: sra         $s6, $t6, 16
    ctx->r22 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B43D4: addiu       $fp, $fp, 0x5860
    ctx->r30 = ADD32(ctx->r30, 0X5860);
    // 0x802B43D8: addiu       $s7, $s7, 0x5590
    ctx->r23 = ADD32(ctx->r23, 0X5590);
    // 0x802B43DC: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x802B43E0: sll         $v0, $s5, 1
    ctx->r2 = S32(ctx->r21 << 1);
L_802B43E4:
    // 0x802B43E4: addu        $s0, $s7, $v0
    ctx->r16 = ADD32(ctx->r23, ctx->r2);
    // 0x802B43E8: lh          $a1, 0x0($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X0);
    // 0x802B43EC: addu        $s1, $fp, $v0
    ctx->r17 = ADD32(ctx->r30, ctx->r2);
    // 0x802B43F0: lh          $t9, 0x0($s1)
    ctx->r25 = MEM_H(ctx->r17, 0X0);
    // 0x802B43F4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802B43F8: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802B43FC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B4400: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B4404: addiu       $t4, $t4, 0x5B30
    ctx->r12 = ADD32(ctx->r12, 0X5B30);
    // 0x802B4408: addiu       $t8, $t8, 0x5E00
    ctx->r24 = ADD32(ctx->r24, 0X5E00);
    // 0x802B440C: addu        $s3, $v0, $t8
    ctx->r19 = ADD32(ctx->r2, ctx->r24);
    // 0x802B4410: addu        $s2, $v0, $t4
    ctx->r18 = ADD32(ctx->r2, ctx->r12);
    // 0x802B4414: addu        $a2, $t9, $s6
    ctx->r6 = ADD32(ctx->r25, ctx->r22);
    // 0x802B4418: lh          $t9, 0x0($s3)
    ctx->r25 = MEM_H(ctx->r19, 0X0);
    // 0x802B441C: lh          $a3, 0x0($s2)
    ctx->r7 = MEM_H(ctx->r18, 0X0);
    // 0x802B4420: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802B4424: or          $a2, $t3, $zero
    ctx->r6 = ctx->r11 | 0;
    // 0x802B4428: addiu       $t6, $zero, 0x1F
    ctx->r14 = ADD32(0, 0X1F);
    // 0x802B442C: addiu       $t7, $zero, 0x1F
    ctx->r15 = ADD32(0, 0X1F);
    // 0x802B4430: sll         $t3, $t9, 8
    ctx->r11 = S32(ctx->r25 << 8);
    // 0x802B4434: sll         $t5, $a3, 17
    ctx->r13 = S32(ctx->r7 << 17);
    // 0x802B4438: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x802B443C: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x802B4440: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802B4444: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802B4448: jal         0x802B4794
    // 0x802B444C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    draw_star_billboard_texrect(rdram, ctx);
        goto after_0;
    // 0x802B444C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_0:
    // 0x802B4450: lui         $t4, 0x803E
    ctx->r12 = S32(0X803E << 16);
    // 0x802B4454: lw          $t4, 0x4D28($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X4D28);
    // 0x802B4458: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x802B445C: addiu       $t3, $zero, 0x1F
    ctx->r11 = ADD32(0, 0X1F);
    // 0x802B4460: andi        $t5, $t4, 0x4
    ctx->r13 = ctx->r12 & 0X4;
    // 0x802B4464: beq         $t5, $zero, L_802B4554
    if (ctx->r13 == 0) {
        // 0x802B4468: addiu       $t4, $zero, 0x1F
        ctx->r12 = ADD32(0, 0X1F);
            goto L_802B4554;
    }
    // 0x802B4468: addiu       $t4, $zero, 0x1F
    ctx->r12 = ADD32(0, 0X1F);
    // 0x802B446C: lh          $a1, 0x0($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X0);
    // 0x802B4470: lh          $t7, 0x0($s1)
    ctx->r15 = MEM_H(ctx->r17, 0X0);
    // 0x802B4474: lh          $a3, 0x0($s2)
    ctx->r7 = MEM_H(ctx->r18, 0X0);
    // 0x802B4478: lh          $t5, 0x0($s3)
    ctx->r13 = MEM_H(ctx->r19, 0X0);
    // 0x802B447C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802B4480: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802B4484: addu        $a2, $t7, $s6
    ctx->r6 = ADD32(ctx->r15, ctx->r22);
    // 0x802B4488: addiu       $a3, $a3, -0x2EE0
    ctx->r7 = ADD32(ctx->r7, -0X2EE0);
    // 0x802B448C: sll         $t9, $a3, 17
    ctx->r25 = S32(ctx->r7 << 17);
    // 0x802B4490: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802B4494: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x802B4498: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x802B449C: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x802B44A0: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x802B44A4: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802B44A8: jal         0x802B4794
    // 0x802B44AC: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    draw_star_billboard_texrect(rdram, ctx);
        goto after_1;
    // 0x802B44AC: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_1:
    // 0x802B44B0: lh          $a1, 0x0($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X0);
    // 0x802B44B4: lh          $t8, 0x0($s1)
    ctx->r24 = MEM_H(ctx->r17, 0X0);
    // 0x802B44B8: lh          $a3, 0x0($s2)
    ctx->r7 = MEM_H(ctx->r18, 0X0);
    // 0x802B44BC: lh          $t6, 0x0($s3)
    ctx->r14 = MEM_H(ctx->r19, 0X0);
    // 0x802B44C0: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802B44C4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802B44C8: addu        $a2, $t8, $s6
    ctx->r6 = ADD32(ctx->r24, ctx->r22);
    // 0x802B44CC: addiu       $a3, $a3, 0x2EE0
    ctx->r7 = ADD32(ctx->r7, 0X2EE0);
    // 0x802B44D0: sll         $t3, $a3, 17
    ctx->r11 = S32(ctx->r7 << 17);
    // 0x802B44D4: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802B44D8: addiu       $t4, $zero, 0x1F
    ctx->r12 = ADD32(0, 0X1F);
    // 0x802B44DC: addiu       $t5, $zero, 0x1F
    ctx->r13 = ADD32(0, 0X1F);
    // 0x802B44E0: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x802B44E4: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x802B44E8: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x802B44EC: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802B44F0: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802B44F4: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
    // 0x802B44F8: jal         0x802B4794
    // 0x802B44FC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    draw_star_billboard_texrect(rdram, ctx);
        goto after_2;
    // 0x802B44FC: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_2:
    // 0x802B4500: lh          $a1, 0x0($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X0);
    // 0x802B4504: lh          $t9, 0x0($s1)
    ctx->r25 = MEM_H(ctx->r17, 0X0);
    // 0x802B4508: lh          $a3, 0x0($s2)
    ctx->r7 = MEM_H(ctx->r18, 0X0);
    // 0x802B450C: lh          $t7, 0x0($s3)
    ctx->r15 = MEM_H(ctx->r19, 0X0);
    // 0x802B4510: addiu       $a1, $a1, 0x2710
    ctx->r5 = ADD32(ctx->r5, 0X2710);
    // 0x802B4514: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802B4518: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802B451C: addu        $a2, $t9, $s6
    ctx->r6 = ADD32(ctx->r25, ctx->r22);
    // 0x802B4520: addiu       $a3, $a3, 0x1770
    ctx->r7 = ADD32(ctx->r7, 0X1770);
    // 0x802B4524: sll         $t4, $a3, 17
    ctx->r12 = S32(ctx->r7 << 17);
    // 0x802B4528: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802B452C: addiu       $t5, $zero, 0x1F
    ctx->r13 = ADD32(0, 0X1F);
    // 0x802B4530: addiu       $t6, $zero, 0x1F
    ctx->r14 = ADD32(0, 0X1F);
    // 0x802B4534: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B4538: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x802B453C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802B4540: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802B4544: or          $a2, $t3, $zero
    ctx->r6 = ctx->r11 | 0;
    // 0x802B4548: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x802B454C: jal         0x802B4794
    // 0x802B4550: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    draw_star_billboard_texrect(rdram, ctx);
        goto after_3;
    // 0x802B4550: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_3:
L_802B4554:
    // 0x802B4554: addiu       $s5, $s5, 0x1
    ctx->r21 = ADD32(ctx->r21, 0X1);
    // 0x802B4558: sll         $t9, $s5, 16
    ctx->r25 = S32(ctx->r21 << 16);
    // 0x802B455C: sra         $s5, $t9, 16
    ctx->r21 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B4560: slti        $at, $s5, 0x168
    ctx->r1 = SIGNED(ctx->r21) < 0X168 ? 1 : 0;
    // 0x802B4564: bnel        $at, $zero, L_802B43E4
    if (ctx->r1 != 0) {
        // 0x802B4568: sll         $v0, $s5, 1
        ctx->r2 = S32(ctx->r21 << 1);
            goto L_802B43E4;
    }
    goto skip_0;
    // 0x802B4568: sll         $v0, $s5, 1
    ctx->r2 = S32(ctx->r21 << 1);
    skip_0:
    // 0x802B456C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x802B4570: lh          $t4, 0x6680($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X6680);
    // 0x802B4574: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x802B4578: sh          $s6, 0x5C8($at)
    MEM_H(0X5C8, ctx->r1) = ctx->r22;
    // 0x802B457C: bnel        $t4, $zero, L_802B4768
    if (ctx->r12 != 0) {
        // 0x802B4580: lw          $ra, 0x5C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X5C);
            goto L_802B4768;
    }
    goto skip_1;
    // 0x802B4580: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
    skip_1:
    // 0x802B4584: jal         0x80140D20
    // 0x802B4588: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x802B4588: nop

    after_4:
    // 0x802B458C: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x802B4590: ori         $at, $at, 0x86A0
    ctx->r1 = ctx->r1 | 0X86A0;
    // 0x802B4594: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x802B4598: mfhi        $t5
    ctx->r13 = hi;
    // 0x802B459C: slti        $at, $t5, 0x5
    ctx->r1 = SIGNED(ctx->r13) < 0X5 ? 1 : 0;
    // 0x802B45A0: beql        $at, $zero, L_802B4768
    if (ctx->r1 == 0) {
        // 0x802B45A4: lw          $ra, 0x5C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X5C);
            goto L_802B4768;
    }
    goto skip_2;
    // 0x802B45A4: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
    skip_2:
    // 0x802B45A8: jal         0x80140D20
    // 0x802B45AC: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x802B45AC: nop

    after_5:
    // 0x802B45B0: addiu       $s4, $zero, 0x168
    ctx->r20 = ADD32(0, 0X168);
    // 0x802B45B4: div         $zero, $v0, $s4
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r20))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r20)));
    // 0x802B45B8: mfhi        $s1
    ctx->r17 = hi;
    // 0x802B45BC: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x802B45C0: bne         $s4, $zero, L_802B45CC
    if (ctx->r20 != 0) {
        // 0x802B45C4: nop
    
            goto L_802B45CC;
    }
    // 0x802B45C4: nop

    // 0x802B45C8: break       7
    do_break(2150319560);
L_802B45CC:
    // 0x802B45CC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B45D0: bne         $s4, $at, L_802B45E4
    if (ctx->r20 != ctx->r1) {
        // 0x802B45D4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B45E4;
    }
    // 0x802B45D4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B45D8: bne         $v0, $at, L_802B45E4
    if (ctx->r2 != ctx->r1) {
        // 0x802B45DC: nop
    
            goto L_802B45E4;
    }
    // 0x802B45DC: nop

    // 0x802B45E0: break       6
    do_break(2150319584);
L_802B45E4:
    // 0x802B45E4: sra         $s1, $t6, 16
    ctx->r17 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B45E8: jal         0x80140D20
    // 0x802B45EC: nop

    guRandom(rdram, ctx);
        goto after_6;
    // 0x802B45EC: nop

    after_6:
    // 0x802B45F0: addiu       $at, $zero, 0x1770
    ctx->r1 = ADD32(0, 0X1770);
    // 0x802B45F4: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x802B45F8: mfhi        $s0
    ctx->r16 = hi;
    // 0x802B45FC: addiu       $s0, $s0, 0x7D0
    ctx->r16 = ADD32(ctx->r16, 0X7D0);
    // 0x802B4600: jal         0x80140D20
    // 0x802B4604: nop

    guRandom(rdram, ctx);
        goto after_7;
    // 0x802B4604: nop

    after_7:
    // 0x802B4608: div         $zero, $v0, $s4
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r20))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r20)));
    // 0x802B460C: mfhi        $s2
    ctx->r18 = hi;
    // 0x802B4610: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x802B4614: bne         $s4, $zero, L_802B4620
    if (ctx->r20 != 0) {
        // 0x802B4618: nop
    
            goto L_802B4620;
    }
    // 0x802B4618: nop

    // 0x802B461C: break       7
    do_break(2150319644);
L_802B4620:
    // 0x802B4620: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B4624: bne         $s4, $at, L_802B4638
    if (ctx->r20 != ctx->r1) {
        // 0x802B4628: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B4638;
    }
    // 0x802B4628: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B462C: bne         $v0, $at, L_802B4638
    if (ctx->r2 != ctx->r1) {
        // 0x802B4630: nop
    
            goto L_802B4638;
    }
    // 0x802B4630: nop

    // 0x802B4634: break       6
    do_break(2150319668);
L_802B4638:
    // 0x802B4638: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B463C: jal         0x80140D20
    // 0x802B4640: nop

    guRandom(rdram, ctx);
        goto after_8;
    // 0x802B4640: nop

    after_8:
    // 0x802B4644: jal         0x80140D20
    // 0x802B4648: or          $s3, $v0, $zero
    ctx->r19 = ctx->r2 | 0;
    guRandom(rdram, ctx);
        goto after_9;
    // 0x802B4648: or          $s3, $v0, $zero
    ctx->r19 = ctx->r2 | 0;
    after_9:
    // 0x802B464C: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x802B4650: addiu       $t1, $t1, 0x2350
    ctx->r9 = ADD32(ctx->r9, 0X2350);
    // 0x802B4654: sll         $t3, $s2, 1
    ctx->r11 = S32(ctx->r18 << 1);
    // 0x802B4658: addu        $v1, $t1, $t3
    ctx->r3 = ADD32(ctx->r9, ctx->r11);
    // 0x802B465C: lh          $t4, 0x2D0($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X2D0);
    // 0x802B4660: lh          $t6, 0x384($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X384);
    // 0x802B4664: sll         $t8, $s1, 1
    ctx->r24 = S32(ctx->r17 << 1);
    // 0x802B4668: multu       $t4, $s0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B466C: addu        $t0, $t1, $t8
    ctx->r8 = ADD32(ctx->r9, ctx->r24);
    // 0x802B4670: lh          $t9, 0x2D0($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X2D0);
    // 0x802B4674: addiu       $t2, $zero, 0xFA0
    ctx->r10 = ADD32(0, 0XFA0);
    // 0x802B4678: lh          $t4, 0x384($t0)
    ctx->r12 = MEM_H(ctx->r8, 0X384);
    // 0x802B467C: addiu       $a3, $zero, 0x56
    ctx->r7 = ADD32(0, 0X56);
    // 0x802B4680: mflo        $a0
    ctx->r4 = lo;
    // 0x802B4684: bgez        $a0, L_802B4694
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802B4688: sra         $t5, $a0, 7
        ctx->r13 = S32(SIGNED(ctx->r4) >> 7);
            goto L_802B4694;
    }
    // 0x802B4688: sra         $t5, $a0, 7
    ctx->r13 = S32(SIGNED(ctx->r4) >> 7);
    // 0x802B468C: addiu       $at, $a0, 0x7F
    ctx->r1 = ADD32(ctx->r4, 0X7F);
    // 0x802B4690: sra         $t5, $at, 7
    ctx->r13 = S32(SIGNED(ctx->r1) >> 7);
L_802B4694:
    // 0x802B4694: multu       $t6, $s0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4698: addiu       $a0, $t5, 0x900
    ctx->r4 = ADD32(ctx->r13, 0X900);
    // 0x802B469C: mflo        $a1
    ctx->r5 = lo;
    // 0x802B46A0: bgez        $a1, L_802B46B0
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B46A4: sra         $t7, $a1, 7
        ctx->r15 = S32(SIGNED(ctx->r5) >> 7);
            goto L_802B46B0;
    }
    // 0x802B46A4: sra         $t7, $a1, 7
    ctx->r15 = S32(SIGNED(ctx->r5) >> 7);
    // 0x802B46A8: addiu       $at, $a1, 0x7F
    ctx->r1 = ADD32(ctx->r5, 0X7F);
    // 0x802B46AC: sra         $t7, $at, 7
    ctx->r15 = S32(SIGNED(ctx->r1) >> 7);
L_802B46B0:
    // 0x802B46B0: addiu       $at, $zero, 0x7D0
    ctx->r1 = ADD32(0, 0X7D0);
    // 0x802B46B4: div         $zero, $s3, $at
    lo = S32(S64(S32(ctx->r19)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r19)) % S64(S32(ctx->r1)));
    // 0x802B46B8: mfhi        $a2
    ctx->r6 = hi;
    // 0x802B46BC: addiu       $a1, $t7, 0xE00
    ctx->r5 = ADD32(ctx->r15, 0XE00);
    // 0x802B46C0: addiu       $a2, $a2, 0x3E8
    ctx->r6 = ADD32(ctx->r6, 0X3E8);
    // 0x802B46C4: multu       $t9, $t2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B46C8: mflo        $t3
    ctx->r11 = lo;
    // 0x802B46CC: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802B46D0: nop

    // 0x802B46D4: multu       $t4, $t2
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B46D8: mflo        $t5
    ctx->r13 = lo;
    // 0x802B46DC: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x802B46E0: nop

    // 0x802B46E4: div         $zero, $v0, $s4
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r20))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r20)));
    // 0x802B46E8: mfhi        $t6
    ctx->r14 = hi;
    // 0x802B46EC: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802B46F0: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B46F4: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B46F8: addu        $t3, $t1, $t9
    ctx->r11 = ADD32(ctx->r9, ctx->r25);
    // 0x802B46FC: lh          $t4, 0x2D0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X2D0);
    // 0x802B4700: addiu       $t8, $zero, 0x3E
    ctx->r24 = ADD32(0, 0X3E);
    // 0x802B4704: ori         $t7, $zero, 0xCE7E
    ctx->r15 = 0 | 0XCE7E;
    // 0x802B4708: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x802B470C: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802B4710: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802B4714: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x802B4718: sll         $t5, $t5, 4
    ctx->r13 = S32(ctx->r13 << 4);
    // 0x802B471C: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x802B4720: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802B4724: addiu       $t6, $zero, 0x64
    ctx->r14 = ADD32(0, 0X64);
    // 0x802B4728: bne         $s4, $zero, L_802B4734
    if (ctx->r20 != 0) {
        // 0x802B472C: nop
    
            goto L_802B4734;
    }
    // 0x802B472C: nop

    // 0x802B4730: break       7
    do_break(2150319920);
L_802B4734:
    // 0x802B4734: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B4738: bne         $s4, $at, L_802B474C
    if (ctx->r20 != ctx->r1) {
        // 0x802B473C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B474C;
    }
    // 0x802B473C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B4740: bne         $v0, $at, L_802B474C
    if (ctx->r2 != ctx->r1) {
        // 0x802B4744: nop
    
            goto L_802B474C;
    }
    // 0x802B4744: nop

    // 0x802B4748: break       6
    do_break(2150319944);
L_802B474C:
    // 0x802B474C: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x802B4750: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802B4754: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x802B4758: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x802B475C: jal         0x802D5F4C
    // 0x802B4760: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    create_particle_effect(rdram, ctx);
        goto after_10;
    // 0x802B4760: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    after_10:
    // 0x802B4764: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_802B4768:
    // 0x802B4768: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802B476C: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x802B4770: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x802B4774: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x802B4778: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x802B477C: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x802B4780: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x802B4784: lw          $s7, 0x54($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X54);
    // 0x802B4788: lw          $fp, 0x58($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X58);
    // 0x802B478C: jr          $ra
    // 0x802B4790: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x802B4790: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void draw_star_billboard_texrect(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B4794: mtc1        $a1, $f4
    ctx->f4.u32l = ctx->r5;
    // 0x802B4798: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B479C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x802B47A0: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B47A4: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B47A8: mtc1        $a2, $f4
    ctx->f4.u32l = ctx->r6;
    // 0x802B47AC: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x802B47B0: lw          $v0, 0x4278($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X4278);
    // 0x802B47B4: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x802B47B8: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B47BC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x802B47C0: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x802B47C4: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B47C8: mtc1        $a3, $f4
    ctx->f4.u32l = ctx->r7;
    // 0x802B47CC: sw          $a0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r4;
    // 0x802B47D0: cvt.s.d     $f12, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f12.fl = CVT_S_D(ctx->f10.d);
    // 0x802B47D4: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x802B47D8: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B47DC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x802B47E0: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x802B47E4: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B47E8: ori         $at, $at, 0x8000
    ctx->r1 = ctx->r1 | 0X8000;
    // 0x802B47EC: addu        $v0, $v0, $at
    ctx->r2 = ADD32(ctx->r2, ctx->r1);
    // 0x802B47F0: lui         $at, 0xC008
    ctx->r1 = S32(0XC008 << 16);
    // 0x802B47F4: cvt.s.d     $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f14.fl = CVT_S_D(ctx->f10.d);
    // 0x802B47F8: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x802B47FC: cvt.s.d     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f16.fl = CVT_S_D(ctx->f10.d);
    // 0x802B4800: swc1        $f16, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f16.u32l;
    // 0x802B4804: lwc1        $f6, 0xA30($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0XA30);
    // 0x802B4808: lwc1        $f10, 0xA34($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XA34);
    // 0x802B480C: lwc1        $f4, 0xA3C($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0XA3C);
    // 0x802B4810: mul.s       $f8, $f6, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f12.fl);
    // 0x802B4814: nop

    // 0x802B4818: mul.s       $f6, $f10, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f14.fl);
    // 0x802B481C: add.s       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f6.fl;
    // 0x802B4820: lwc1        $f8, 0xA38($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA38);
    // 0x802B4824: mtc1        $at, $f11
    ctx->f_odd[(11 - 1) * 2] = ctx->r1;
    // 0x802B4828: mul.s       $f6, $f8, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f16.fl);
    // 0x802B482C: add.s       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802B4830: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802B4834: add.s       $f0, $f8, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = ctx->f8.fl + ctx->f4.fl;
    // 0x802B4838: cvt.d.s     $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f6.d = CVT_D_S(ctx->f0.fl);
    // 0x802B483C: c.le.d      $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f6.d <= ctx->f10.d;
    // 0x802B4840: nop

    // 0x802B4844: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4848: nop
    
            goto L_802B4D14;
    }
    // 0x802B4848: nop

    // 0x802B484C: lwc1        $f8, 0xA48($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA48);
    // 0x802B4850: lwc1        $f10, 0xA4C($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XA4C);
    // 0x802B4854: neg.s       $f18, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = -ctx->f0.fl;
    // 0x802B4858: mul.s       $f4, $f8, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802B485C: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B4860: mtc1        $zero, $f9
    ctx->f_odd[(9 - 1) * 2] = 0;
    // 0x802B4864: add.s       $f6, $f4, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f10.fl;
    // 0x802B4868: div.s       $f2, $f6, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f18.fl);
    // 0x802B486C: cvt.d.s     $f4, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f4.d = CVT_D_S(ctx->f2.fl);
    // 0x802B4870: c.lt.d      $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f8.d < ctx->f4.d;
    // 0x802B4874: nop

    // 0x802B4878: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B487C: nop
    
            goto L_802B4D14;
    }
    // 0x802B487C: nop

    // 0x802B4880: lwc1        $f10, 0xA10($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0XA10);
    // 0x802B4884: lwc1        $f8, 0xA14($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA14);
    // 0x802B4888: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x802B488C: mul.s       $f6, $f10, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f12.fl);
    // 0x802B4890: lh          $v1, 0x3FD0($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X3FD0);
    // 0x802B4894: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x802B4898: mul.s       $f4, $f8, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = MUL_S(ctx->f8.fl, ctx->f14.fl);
    // 0x802B489C: lwc1        $f8, 0xA18($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA18);
    // 0x802B48A0: sll         $t6, $v1, 1
    ctx->r14 = S32(ctx->r3 << 1);
    // 0x802B48A4: lh          $t7, 0x3FD2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FD2);
    // 0x802B48A8: lw          $a0, 0x98($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X98);
    // 0x802B48AC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802B48B0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802B48B4: add.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x802B48B8: mul.s       $f6, $f8, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f16.fl);
    // 0x802B48BC: lwc1        $f8, 0xA1C($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA1C);
    // 0x802B48C0: sll         $t9, $a0, 5
    ctx->r25 = S32(ctx->r4 << 5);
    // 0x802B48C4: addu        $t9, $t9, $a0
    ctx->r25 = ADD32(ctx->r25, ctx->r4);
    // 0x802B48C8: add.s       $f4, $f10, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f6.fl;
    // 0x802B48CC: add.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x802B48D0: swc1        $f10, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->f10.u32l;
    // 0x802B48D4: lwc1        $f6, 0xA20($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0XA20);
    // 0x802B48D8: lwc1        $f8, 0xA24($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA24);
    // 0x802B48DC: mul.s       $f4, $f6, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f12.fl);
    // 0x802B48E0: nop

    // 0x802B48E4: mul.s       $f6, $f8, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f14.fl);
    // 0x802B48E8: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x802B48EC: lwc1        $f4, 0xA28($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0XA28);
    // 0x802B48F0: mul.s       $f6, $f4, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f16.fl);
    // 0x802B48F4: add.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f8.fl + ctx->f6.fl;
    // 0x802B48F8: lwc1        $f8, 0xA2C($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA2C);
    // 0x802B48FC: add.s       $f6, $f4, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f4.fl + ctx->f8.fl;
    // 0x802B4900: swc1        $f6, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->f6.u32l;
    // 0x802B4904: lwc1        $f4, 0xA40($v0)
    ctx->f4.u32l = MEM_W(ctx->r2, 0XA40);
    // 0x802B4908: mul.s       $f8, $f4, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f10.fl);
    // 0x802B490C: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x802B4910: div.s       $f4, $f8, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = DIV_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802B4914: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802B4918: add.s       $f10, $f8, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f4.fl;
    // 0x802B491C: swc1        $f10, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->f10.u32l;
    // 0x802B4920: lwc1        $f8, 0xA44($v0)
    ctx->f8.u32l = MEM_W(ctx->r2, 0XA44);
    // 0x802B4924: lh          $v0, 0x92($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X92);
    // 0x802B4928: mul.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x802B492C: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802B4930: nop

    // 0x802B4934: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802B4938: mtc1        $t9, $f8
    ctx->f8.u32l = ctx->r25;
    // 0x802B493C: div.s       $f10, $f4, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = DIV_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802B4940: add.s       $f4, $f6, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x802B4944: lwc1        $f10, 0x2E30($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X2E30);
    // 0x802B4948: lui         $at, 0x4170
    ctx->r1 = S32(0X4170 << 16);
    // 0x802B494C: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802B4950: swc1        $f4, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->f4.u32l;
    // 0x802B4954: div.s       $f4, $f6, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = DIV_S(ctx->f6.fl, ctx->f10.fl);
    // 0x802B4958: trunc.w.s   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802B495C: mfc1        $a0, $f8
    ctx->r4 = (int32_t)ctx->f8.u32l;
    // 0x802B4960: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802B4964: lui         $at, 0x4170
    ctx->r1 = S32(0X4170 << 16);
    // 0x802B4968: sll         $t6, $a0, 5
    ctx->r14 = S32(ctx->r4 << 5);
    // 0x802B496C: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x802B4970: nop

    // 0x802B4974: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802B4978: div.s       $f2, $f10, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f2.fl = DIV_S(ctx->f10.fl, ctx->f18.fl);
    // 0x802B497C: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802B4980: c.lt.s      $f8, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f8.fl < ctx->f2.fl;
    // 0x802B4984: swc1        $f2, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f2.u32l;
    // 0x802B4988: bc1f        L_802B4998
    if (!c1cs) {
        // 0x802B498C: nop
    
            goto L_802B4998;
    }
    // 0x802B498C: nop

    // 0x802B4990: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    // 0x802B4994: nop

L_802B4998:
    // 0x802B4998: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x802B499C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802B49A0: nop

    // 0x802B49A4: c.lt.s      $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f2.fl < ctx->f0.fl;
    // 0x802B49A8: nop

    // 0x802B49AC: bc1fl       L_802B49BC
    if (!c1cs) {
        // 0x802B49B0: c.lt.s      $f18, $f2
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f18.fl < ctx->f2.fl;
            goto L_802B49BC;
    }
    goto skip_0;
    // 0x802B49B0: c.lt.s      $f18, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f18.fl < ctx->f2.fl;
    skip_0:
    // 0x802B49B4: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
    // 0x802B49B8: c.lt.s      $f18, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f18.fl < ctx->f2.fl;
L_802B49BC:
    // 0x802B49BC: lwc1        $f16, 0x70($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X70);
    // 0x802B49C0: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B49C4: nop
    
            goto L_802B4D14;
    }
    // 0x802B49C4: nop

    // 0x802B49C8: mtc1        $v0, $f6
    ctx->f6.u32l = ctx->r2;
    // 0x802B49CC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802B49D0: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x802B49D4: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802B49D8: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x802B49DC: lh          $a2, 0x96($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X96);
    // 0x802B49E0: mul.s       $f8, $f10, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f2.fl);
    // 0x802B49E4: cvt.d.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f4.d = CVT_D_S(ctx->f8.fl);
    // 0x802B49E8: mul.d       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = MUL_D(ctx->f4.d, ctx->f6.d);
    // 0x802B49EC: cvt.s.d     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f0.fl = CVT_S_D(ctx->f10.d);
    // 0x802B49F0: sub.s       $f12, $f16, $f0
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f12.fl = ctx->f16.fl - ctx->f0.fl;
    // 0x802B49F4: add.s       $f14, $f16, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = ctx->f16.fl + ctx->f0.fl;
    // 0x802B49F8: c.lt.s      $f12, $f14
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f12.fl < ctx->f14.fl;
    // 0x802B49FC: nop

    // 0x802B4A00: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4A04: nop
    
            goto L_802B4D14;
    }
    // 0x802B4A04: nop

    // 0x802B4A08: mtc1        $a2, $f8
    ctx->f8.u32l = ctx->r6;
    // 0x802B4A0C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802B4A10: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x802B4A14: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802B4A18: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B4A1C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x802B4A20: sll         $t7, $a2, 12
    ctx->r15 = S32(ctx->r6 << 12);
    // 0x802B4A24: mul.s       $f6, $f4, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f2.fl);
    // 0x802B4A28: cvt.d.s     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f10.d = CVT_D_S(ctx->f6.fl);
    // 0x802B4A2C: mul.d       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f8.d); 
    ctx->f4.d = MUL_D(ctx->f10.d, ctx->f8.d);
    // 0x802B4A30: lwc1        $f10, 0x6C($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X6C);
    // 0x802B4A34: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802B4A38: nop

    // 0x802B4A3C: add.s       $f16, $f10, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802B4A40: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x802B4A44: sub.s       $f0, $f10, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = ctx->f10.fl - ctx->f6.fl;
    // 0x802B4A48: c.lt.s      $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.fl < ctx->f16.fl;
    // 0x802B4A4C: nop

    // 0x802B4A50: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4A54: nop
    
            goto L_802B4D14;
    }
    // 0x802B4A54: nop

    // 0x802B4A58: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802B4A5C: sub.s       $f10, $f14, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = ctx->f14.fl - ctx->f12.fl;
    // 0x802B4A60: sll         $t5, $v0, 12
    ctx->r13 = S32(ctx->r2 << 12);
    // 0x802B4A64: sll         $t8, $v1, 2
    ctx->r24 = S32(ctx->r3 << 2);
    // 0x802B4A68: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802B4A6C: lui         $at, 0x4470
    ctx->r1 = S32(0X4470 << 16);
    // 0x802B4A70: div.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = DIV_S(ctx->f6.fl, ctx->f10.fl);
    // 0x802B4A74: mtc1        $t5, $f6
    ctx->f6.u32l = ctx->r13;
    // 0x802B4A78: nop

    // 0x802B4A7C: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802B4A80: trunc.w.s   $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802B4A84: sub.s       $f8, $f16, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = ctx->f16.fl - ctx->f0.fl;
    // 0x802B4A88: mfc1        $t4, $f4
    ctx->r12 = (int32_t)ctx->f4.u32l;
    // 0x802B4A8C: div.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = DIV_S(ctx->f10.fl, ctx->f8.fl);
    // 0x802B4A90: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x802B4A94: sll         $a0, $t4, 16
    ctx->r4 = S32(ctx->r12 << 16);
    // 0x802B4A98: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x802B4A9C: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802B4AA0: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x802B4AA4: c.lt.s      $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f12.fl < ctx->f8.fl;
    // 0x802B4AA8: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802B4AAC: mfc1        $a3, $f6
    ctx->r7 = (int32_t)ctx->f6.u32l;
    // 0x802B4AB0: nop

    // 0x802B4AB4: sll         $a1, $a3, 16
    ctx->r5 = S32(ctx->r7 << 16);
    // 0x802B4AB8: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B4ABC: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4AC0: or          $a1, $t7, $zero
        ctx->r5 = ctx->r15 | 0;
            goto L_802B4D14;
    }
    // 0x802B4AC0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x802B4AC4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802B4AC8: nop

    // 0x802B4ACC: c.lt.s      $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f0.fl < ctx->f4.fl;
    // 0x802B4AD0: nop

    // 0x802B4AD4: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4AD8: nop
    
            goto L_802B4D14;
    }
    // 0x802B4AD8: nop

    // 0x802B4ADC: c.lt.s      $f18, $f14
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f18.fl < ctx->f14.fl;
    // 0x802B4AE0: nop

    // 0x802B4AE4: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4AE8: nop
    
            goto L_802B4D14;
    }
    // 0x802B4AE8: nop

    // 0x802B4AEC: c.lt.s      $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f18.fl < ctx->f16.fl;
    // 0x802B4AF0: lw          $t9, 0x80($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X80);
    // 0x802B4AF4: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x802B4AF8: bc1f        L_802B4D14
    if (!c1cs) {
        // 0x802B4AFC: nop
    
            goto L_802B4D14;
    }
    // 0x802B4AFC: nop

    // 0x802B4B00: trunc.w.s   $f6, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    ctx->f6.u32l = TRUNC_W_S(ctx->f14.fl);
    // 0x802B4B04: lw          $t0, 0x0($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X0);
    // 0x802B4B08: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x802B4B0C: trunc.w.s   $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    ctx->f10.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802B4B10: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x802B4B14: addiu       $t5, $t0, 0x8
    ctx->r13 = ADD32(ctx->r8, 0X8);
    // 0x802B4B18: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802B4B1C: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802B4B20: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x802B4B24: sw          $t5, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r13;
    // 0x802B4B28: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B4B2C: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B4B30: mfc1        $v0, $f4
    ctx->r2 = (int32_t)ctx->f4.u32l;
    // 0x802B4B34: blez        $t8, L_802B4B44
    if (SIGNED(ctx->r24) <= 0) {
        // 0x802B4B38: or          $t3, $zero, $zero
        ctx->r11 = 0 | 0;
            goto L_802B4B44;
    }
    // 0x802B4B38: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
    // 0x802B4B3C: b           L_802B4B44
    // 0x802B4B40: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
        goto L_802B4B44;
    // 0x802B4B40: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
L_802B4B44:
    // 0x802B4B44: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B4B48: blez        $t6, L_802B4B58
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802B4B4C: andi        $t5, $t2, 0xFFF
        ctx->r13 = ctx->r10 & 0XFFF;
            goto L_802B4B58;
    }
    // 0x802B4B4C: andi        $t5, $t2, 0xFFF
    ctx->r13 = ctx->r10 & 0XFFF;
    // 0x802B4B50: b           L_802B4B58
    // 0x802B4B54: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
        goto L_802B4B58;
    // 0x802B4B54: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
L_802B4B58:
    // 0x802B4B58: trunc.w.s   $f8, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    ctx->f8.u32l = TRUNC_W_S(ctx->f12.fl);
    // 0x802B4B5C: andi        $t7, $t3, 0xFFF
    ctx->r15 = ctx->r11 & 0XFFF;
    // 0x802B4B60: sll         $t9, $t5, 12
    ctx->r25 = S32(ctx->r13 << 12);
    // 0x802B4B64: or          $t8, $t7, $at
    ctx->r24 = ctx->r15 | ctx->r1;
    // 0x802B4B68: mfc1        $v1, $f8
    ctx->r3 = (int32_t)ctx->f8.u32l;
    // 0x802B4B6C: or          $t6, $t8, $t9
    ctx->r14 = ctx->r24 | ctx->r25;
    // 0x802B4B70: sw          $t6, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r14;
    // 0x802B4B74: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x802B4B78: sra         $t8, $t5, 16
    ctx->r24 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B4B7C: blez        $t8, L_802B4B8C
    if (SIGNED(ctx->r24) <= 0) {
        // 0x802B4B80: or          $v1, $t8, $zero
        ctx->r3 = ctx->r24 | 0;
            goto L_802B4B8C;
    }
    // 0x802B4B80: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802B4B84: b           L_802B4B90
    // 0x802B4B88: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
        goto L_802B4B90;
    // 0x802B4B88: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
L_802B4B8C:
    // 0x802B4B8C: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
L_802B4B90:
    // 0x802B4B90: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x802B4B94: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B4B98: blez        $t7, L_802B4BA8
    if (SIGNED(ctx->r15) <= 0) {
        // 0x802B4B9C: or          $v0, $t7, $zero
        ctx->r2 = ctx->r15 | 0;
            goto L_802B4BA8;
    }
    // 0x802B4B9C: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x802B4BA0: b           L_802B4BAC
    // 0x802B4BA4: or          $t3, $t7, $zero
    ctx->r11 = ctx->r15 | 0;
        goto L_802B4BAC;
    // 0x802B4BA4: or          $t3, $t7, $zero
    ctx->r11 = ctx->r15 | 0;
L_802B4BA8:
    // 0x802B4BA8: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
L_802B4BAC:
    // 0x802B4BAC: andi        $t8, $t2, 0xFFF
    ctx->r24 = ctx->r10 & 0XFFF;
    // 0x802B4BB0: sll         $t9, $t8, 12
    ctx->r25 = S32(ctx->r24 << 12);
    // 0x802B4BB4: andi        $t5, $t3, 0xFFF
    ctx->r13 = ctx->r11 & 0XFFF;
    // 0x802B4BB8: or          $t6, $t5, $t9
    ctx->r14 = ctx->r13 | ctx->r25;
    // 0x802B4BBC: sw          $t6, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r14;
    // 0x802B4BC0: lw          $t7, 0x80($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X80);
    // 0x802B4BC4: sll         $t9, $t4, 16
    ctx->r25 = S32(ctx->r12 << 16);
    // 0x802B4BC8: lui         $t5, 0xB400
    ctx->r13 = S32(0XB400 << 16);
    // 0x802B4BCC: lw          $a2, 0x0($t7)
    ctx->r6 = MEM_W(ctx->r15, 0X0);
    // 0x802B4BD0: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B4BD4: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x802B4BD8: addiu       $t8, $a2, 0x8
    ctx->r24 = ADD32(ctx->r6, 0X8);
    // 0x802B4BDC: sw          $t8, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r24;
    // 0x802B4BE0: bgez        $v1, L_802B4C44
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B4BE4: sw          $t5, 0x0($a2)
        MEM_W(0X0, ctx->r6) = ctx->r13;
            goto L_802B4C44;
    }
    // 0x802B4BE4: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x802B4BE8: bgez        $t6, L_802B4C18
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802B4BEC: nop
    
            goto L_802B4C18;
    }
    // 0x802B4BEC: nop

    // 0x802B4BF0: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4BF4: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x802B4BF8: mflo        $t1
    ctx->r9 = lo;
    // 0x802B4BFC: sra         $t8, $t1, 7
    ctx->r24 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802B4C00: blez        $t8, L_802B4C10
    if (SIGNED(ctx->r24) <= 0) {
        // 0x802B4C04: nop
    
            goto L_802B4C10;
    }
    // 0x802B4C04: nop

    // 0x802B4C08: b           L_802B4C44
    // 0x802B4C0C: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
        goto L_802B4C44;
    // 0x802B4C0C: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
L_802B4C10:
    // 0x802B4C10: b           L_802B4C44
    // 0x802B4C14: nop

        goto L_802B4C44;
    // 0x802B4C14: nop

L_802B4C18:
    // 0x802B4C18: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4C1C: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x802B4C20: mflo        $t1
    ctx->r9 = lo;
    // 0x802B4C24: sra         $t7, $t1, 7
    ctx->r15 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802B4C28: bgez        $t7, L_802B4C38
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802B4C2C: nop
    
            goto L_802B4C38;
    }
    // 0x802B4C2C: nop

    // 0x802B4C30: b           L_802B4C38
    // 0x802B4C34: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
        goto L_802B4C38;
    // 0x802B4C34: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
L_802B4C38:
    // 0x802B4C38: or          $t1, $t0, $zero
    ctx->r9 = ctx->r8 | 0;
    // 0x802B4C3C: b           L_802B4C44
    // 0x802B4C40: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
        goto L_802B4C44;
    // 0x802B4C40: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802B4C44:
    // 0x802B4C44: bgez        $v0, L_802B4CB0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B4C48: andi        $t7, $v0, 0x3
        ctx->r15 = ctx->r2 & 0X3;
            goto L_802B4CB0;
    }
    // 0x802B4C48: andi        $t7, $v0, 0x3
    ctx->r15 = ctx->r2 & 0X3;
    // 0x802B4C4C: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x802B4C50: sra         $t9, $t5, 16
    ctx->r25 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B4C54: bgez        $t9, L_802B4C84
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802B4C58: nop
    
            goto L_802B4C84;
    }
    // 0x802B4C58: nop

    // 0x802B4C5C: multu       $v0, $a1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4C60: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802B4C64: mflo        $t1
    ctx->r9 = lo;
    // 0x802B4C68: sra         $t6, $t1, 7
    ctx->r14 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802B4C6C: blez        $t6, L_802B4C7C
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802B4C70: nop
    
            goto L_802B4C7C;
    }
    // 0x802B4C70: nop

    // 0x802B4C74: b           L_802B4CB4
    // 0x802B4C78: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
        goto L_802B4CB4;
    // 0x802B4C78: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
L_802B4C7C:
    // 0x802B4C7C: b           L_802B4CB4
    // 0x802B4C80: or          $t3, $a3, $zero
    ctx->r11 = ctx->r7 | 0;
        goto L_802B4CB4;
    // 0x802B4C80: or          $t3, $a3, $zero
    ctx->r11 = ctx->r7 | 0;
L_802B4C84:
    // 0x802B4C84: multu       $v0, $a1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4C88: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802B4C8C: mflo        $t1
    ctx->r9 = lo;
    // 0x802B4C90: sra         $t8, $t1, 7
    ctx->r24 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802B4C94: bgez        $t8, L_802B4CA4
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802B4C98: nop
    
            goto L_802B4CA4;
    }
    // 0x802B4C98: nop

    // 0x802B4C9C: b           L_802B4CA4
    // 0x802B4CA0: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
        goto L_802B4CA4;
    // 0x802B4CA0: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
L_802B4CA4:
    // 0x802B4CA4: or          $t2, $a3, $zero
    ctx->r10 = ctx->r7 | 0;
    // 0x802B4CA8: b           L_802B4CB4
    // 0x802B4CAC: or          $t3, $t2, $zero
    ctx->r11 = ctx->r10 | 0;
        goto L_802B4CB4;
    // 0x802B4CAC: or          $t3, $t2, $zero
    ctx->r11 = ctx->r10 | 0;
L_802B4CB0:
    // 0x802B4CB0: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
L_802B4CB4:
    // 0x802B4CB4: multu       $a1, $t7
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4CB8: mflo        $t5
    ctx->r13 = lo;
    // 0x802B4CBC: negu        $t9, $t5
    ctx->r25 = SUB32(0, ctx->r13);
    // 0x802B4CC0: andi        $t5, $v1, 0x3
    ctx->r13 = ctx->r3 & 0X3;
    // 0x802B4CC4: multu       $a0, $t5
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B4CC8: sra         $t6, $t9, 7
    ctx->r14 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802B4CCC: subu        $t8, $t6, $t3
    ctx->r24 = SUB32(ctx->r14, ctx->r11);
    // 0x802B4CD0: andi        $t7, $t8, 0xFFFF
    ctx->r15 = ctx->r24 & 0XFFFF;
    // 0x802B4CD4: mflo        $t9
    ctx->r25 = lo;
    // 0x802B4CD8: sra         $t6, $t9, 9
    ctx->r14 = S32(SIGNED(ctx->r25) >> 9);
    // 0x802B4CDC: subu        $t5, $t6, $t0
    ctx->r13 = SUB32(ctx->r14, ctx->r8);
    // 0x802B4CE0: sll         $t9, $t5, 16
    ctx->r25 = S32(ctx->r13 << 16);
    // 0x802B4CE4: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x802B4CE8: sw          $t6, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r14;
    // 0x802B4CEC: lw          $t8, 0x80($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X80);
    // 0x802B4CF0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x802B4CF4: lui         $t7, 0xB300
    ctx->r15 = S32(0XB300 << 16);
    // 0x802B4CF8: lw          $t1, 0x0($t8)
    ctx->r9 = MEM_W(ctx->r24, 0X0);
    // 0x802B4CFC: addiu       $t5, $t1, 0x8
    ctx->r13 = ADD32(ctx->r9, 0X8);
    // 0x802B4D00: sw          $t5, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r13;
    // 0x802B4D04: andi        $t5, $a1, 0xFFFF
    ctx->r13 = ctx->r5 & 0XFFFF;
    // 0x802B4D08: or          $t8, $t6, $t5
    ctx->r24 = ctx->r14 | ctx->r13;
    // 0x802B4D0C: sw          $t8, 0x4($t1)
    MEM_W(0X4, ctx->r9) = ctx->r24;
    // 0x802B4D10: sw          $t7, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r15;
L_802B4D14:
    // 0x802B4D14: jr          $ra
    // 0x802B4D18: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    return;
    // 0x802B4D18: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
;}
RECOMP_FUNC void func_802B4D20_6C63D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B4D20: addiu       $sp, $sp, -0x138
    ctx->r29 = ADD32(ctx->r29, -0X138);
    // 0x802B4D24: sdc1        $f30, 0x58($sp)
    CHECK_FR(ctx, 30);
    SD(ctx->f30.u64, 0X58, ctx->r29);
    // 0x802B4D28: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B4D2C: ldc1        $f30, -0x40C8($at)
    CHECK_FR(ctx, 30);
    ctx->f30.u64 = LD(ctx->r1, -0X40C8);
    // 0x802B4D30: sdc1        $f28, 0x50($sp)
    CHECK_FR(ctx, 28);
    SD(ctx->f28.u64, 0X50, ctx->r29);
    // 0x802B4D34: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B4D38: ldc1        $f28, -0x40C0($at)
    CHECK_FR(ctx, 28);
    ctx->f28.u64 = LD(ctx->r1, -0X40C0);
    // 0x802B4D3C: sdc1        $f26, 0x48($sp)
    CHECK_FR(ctx, 26);
    SD(ctx->f26.u64, 0X48, ctx->r29);
    // 0x802B4D40: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802B4D44: mtc1        $at, $f26
    ctx->f26.u32l = ctx->r1;
    // 0x802B4D48: sdc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    SD(ctx->f22.u64, 0X38, ctx->r29);
    // 0x802B4D4C: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x802B4D50: sdc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X30, ctx->r29);
    // 0x802B4D54: mtc1        $at, $f22
    ctx->f22.u32l = ctx->r1;
    // 0x802B4D58: sw          $s7, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r23;
    // 0x802B4D5C: sw          $s6, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r22;
    // 0x802B4D60: sdc1        $f24, 0x40($sp)
    CHECK_FR(ctx, 24);
    SD(ctx->f24.u64, 0X40, ctx->r29);
    // 0x802B4D64: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B4D68: sw          $fp, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r30;
    // 0x802B4D6C: lui         $s6, 0x803D
    ctx->r22 = S32(0X803D << 16);
    // 0x802B4D70: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x802B4D74: mtc1        $at, $f21
    ctx->f_odd[(21 - 1) * 2] = ctx->r1;
    // 0x802B4D78: mtc1        $zero, $f24
    ctx->f24.u32l = 0;
    // 0x802B4D7C: mtc1        $zero, $f20
    ctx->f20.u32l = 0;
    // 0x802B4D80: sw          $ra, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r31;
    // 0x802B4D84: sw          $s5, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r21;
    // 0x802B4D88: sw          $s4, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r20;
    // 0x802B4D8C: sw          $s3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r19;
    // 0x802B4D90: sw          $s2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r18;
    // 0x802B4D94: sw          $s1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r17;
    // 0x802B4D98: sw          $s0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r16;
    // 0x802B4D9C: addiu       $s7, $s7, 0x60DC
    ctx->r23 = ADD32(ctx->r23, 0X60DC);
    // 0x802B4DA0: addiu       $s6, $s6, 0x60D8
    ctx->r22 = ADD32(ctx->r22, 0X60D8);
    // 0x802B4DA4: addiu       $fp, $zero, 0x1
    ctx->r30 = ADD32(0, 0X1);
    // 0x802B4DA8: sh          $zero, 0x136($sp)
    MEM_H(0X136, ctx->r29) = 0;
L_802B4DAC:
    // 0x802B4DAC: lh          $t6, 0x136($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X136);
    // 0x802B4DB0: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x802B4DB4: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802B4DB8: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802B4DBC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802B4DC0: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802B4DC4: lw          $t8, -0x5EF0($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X5EF0);
    // 0x802B4DC8: beq         $t8, $zero, L_802B5DE4
    if (ctx->r24 == 0) {
        // 0x802B4DCC: sw          $t8, 0x130($sp)
        MEM_W(0X130, ctx->r29) = ctx->r24;
            goto L_802B5DE4;
    }
    // 0x802B4DCC: sw          $t8, 0x130($sp)
    MEM_W(0X130, ctx->r29) = ctx->r24;
L_802B4DD0:
    // 0x802B4DD0: lw          $t9, 0x130($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X130);
    // 0x802B4DD4: lw          $v0, 0x0($t9)
    ctx->r2 = MEM_W(ctx->r25, 0X0);
    // 0x802B4DD8: beq         $v0, $zero, L_802B5DDC
    if (ctx->r2 == 0) {
        // 0x802B4DDC: sw          $v0, 0x12C($sp)
        MEM_W(0X12C, ctx->r29) = ctx->r2;
            goto L_802B5DDC;
    }
    // 0x802B4DDC: sw          $v0, 0x12C($sp)
    MEM_W(0X12C, ctx->r29) = ctx->r2;
L_802B4DE0:
    // 0x802B4DE0: lw          $t0, 0x130($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X130);
    // 0x802B4DE4: lh          $t1, 0x136($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X136);
    // 0x802B4DE8: lw          $t2, 0x12C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X12C);
    // 0x802B4DEC: lw          $a2, 0x8($t0)
    ctx->r6 = MEM_W(ctx->r8, 0X8);
    // 0x802B4DF0: lw          $t4, 0x12C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X12C);
    // 0x802B4DF4: lh          $t5, 0x136($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X136);
    // 0x802B4DF8: lh          $a0, 0x114($a2)
    ctx->r4 = MEM_H(ctx->r6, 0X114);
    // 0x802B4DFC: bnel        $t1, $a0, L_802B4E18
    if (ctx->r9 != ctx->r4) {
        // 0x802B4E00: lw          $v1, 0x8($t4)
        ctx->r3 = MEM_W(ctx->r12, 0X8);
            goto L_802B4E18;
    }
    goto skip_0;
    // 0x802B4E00: lw          $v1, 0x8($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X8);
    skip_0:
    // 0x802B4E04: lw          $v1, 0x8($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X8);
    // 0x802B4E08: lh          $t3, 0x114($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X114);
    // 0x802B4E0C: beql        $t1, $t3, L_802B4E44
    if (ctx->r9 == ctx->r11) {
        // 0x802B4E10: lw          $t7, 0x16C($a2)
        ctx->r15 = MEM_W(ctx->r6, 0X16C);
            goto L_802B4E44;
    }
    goto skip_1;
    // 0x802B4E10: lw          $t7, 0x16C($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X16C);
    skip_1:
    // 0x802B4E14: lw          $v1, 0x8($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X8);
L_802B4E18:
    // 0x802B4E18: lh          $t6, 0x136($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X136);
    // 0x802B4E1C: bne         $t5, $a0, L_802B4E30
    if (ctx->r13 != ctx->r4) {
        // 0x802B4E20: lh          $v0, 0x114($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X114);
            goto L_802B4E30;
    }
    // 0x802B4E20: lh          $v0, 0x114($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X114);
    // 0x802B4E24: slt         $at, $v0, $t5
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B4E28: bnel        $at, $zero, L_802B4E44
    if (ctx->r1 != 0) {
        // 0x802B4E2C: lw          $t7, 0x16C($a2)
        ctx->r15 = MEM_W(ctx->r6, 0X16C);
            goto L_802B4E44;
    }
    goto skip_2;
    // 0x802B4E2C: lw          $t7, 0x16C($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X16C);
    skip_2:
L_802B4E30:
    // 0x802B4E30: bne         $t6, $v0, L_802B5DC4
    if (ctx->r14 != ctx->r2) {
        // 0x802B4E34: slt         $at, $a0, $t6
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r14) ? 1 : 0;
            goto L_802B5DC4;
    }
    // 0x802B4E34: slt         $at, $a0, $t6
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802B4E38: beql        $at, $zero, L_802B5DC8
    if (ctx->r1 == 0) {
        // 0x802B4E3C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_3;
    // 0x802B4E3C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_3:
    // 0x802B4E40: lw          $t7, 0x16C($a2)
    ctx->r15 = MEM_W(ctx->r6, 0X16C);
L_802B4E44:
    // 0x802B4E44: lw          $t2, 0x16C($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X16C);
    // 0x802B4E48: lui         $t0, 0x803B
    ctx->r8 = S32(0X803B << 16);
    // 0x802B4E4C: lbu         $t8, 0x2($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X2);
    // 0x802B4E50: lbu         $t1, 0x2($t2)
    ctx->r9 = MEM_BU(ctx->r10, 0X2);
    // 0x802B4E54: addiu       $t3, $zero, 0xF
    ctx->r11 = ADD32(0, 0XF);
    // 0x802B4E58: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B4E5C: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x802B4E60: lhu         $t0, 0x1BAC($t0)
    ctx->r8 = MEM_HU(ctx->r8, 0X1BAC);
    // 0x802B4E64: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802B4E68: subu        $t4, $t3, $t1
    ctx->r12 = SUB32(ctx->r11, ctx->r9);
    // 0x802B4E6C: sllv        $t6, $t5, $t4
    ctx->r14 = S32(ctx->r13 << (ctx->r12 & 31));
    // 0x802B4E70: and         $t7, $t0, $t6
    ctx->r15 = ctx->r8 & ctx->r14;
    // 0x802B4E74: beql        $t7, $zero, L_802B5DC8
    if (ctx->r15 == 0) {
        // 0x802B4E78: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_4;
    // 0x802B4E78: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_4:
    // 0x802B4E7C: lh          $t8, 0x10($a2)
    ctx->r24 = MEM_H(ctx->r6, 0X10);
    // 0x802B4E80: lh          $t9, 0x10($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X10);
    // 0x802B4E84: lh          $a3, 0x34($a2)
    ctx->r7 = MEM_H(ctx->r6, 0X34);
    // 0x802B4E88: subu        $a0, $t8, $t9
    ctx->r4 = SUB32(ctx->r24, ctx->r25);
    // 0x802B4E8C: bgez        $a0, L_802B4E9C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802B4E90: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802B4E9C;
    }
    // 0x802B4E90: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802B4E94: b           L_802B4E9C
    // 0x802B4E98: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
        goto L_802B4E9C;
    // 0x802B4E98: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
L_802B4E9C:
    // 0x802B4E9C: lh          $t2, 0x34($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X34);
    // 0x802B4EA0: addu        $a1, $a3, $t2
    ctx->r5 = ADD32(ctx->r7, ctx->r10);
    // 0x802B4EA4: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802B4EA8: beql        $at, $zero, L_802B5DC8
    if (ctx->r1 == 0) {
        // 0x802B4EAC: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_5;
    // 0x802B4EAC: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_5:
    // 0x802B4EB0: lh          $t3, 0x14($a2)
    ctx->r11 = MEM_H(ctx->r6, 0X14);
    // 0x802B4EB4: lh          $t1, 0x14($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X14);
    // 0x802B4EB8: subu        $a0, $t3, $t1
    ctx->r4 = SUB32(ctx->r11, ctx->r9);
    // 0x802B4EBC: bgez        $a0, L_802B4ECC
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802B4EC0: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802B4ECC;
    }
    // 0x802B4EC0: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802B4EC4: b           L_802B4ECC
    // 0x802B4EC8: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
        goto L_802B4ECC;
    // 0x802B4EC8: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
L_802B4ECC:
    // 0x802B4ECC: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802B4ED0: beql        $at, $zero, L_802B5DC8
    if (ctx->r1 == 0) {
        // 0x802B4ED4: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_6;
    // 0x802B4ED4: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_6:
    // 0x802B4ED8: lhu         $t4, 0x42($a2)
    ctx->r12 = MEM_HU(ctx->r6, 0X42);
    // 0x802B4EDC: lh          $t5, 0x18($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X18);
    // 0x802B4EE0: lh          $t7, 0x18($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X18);
    // 0x802B4EE4: lhu         $t9, 0x42($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X42);
    // 0x802B4EE8: sra         $t0, $t4, 1
    ctx->r8 = S32(SIGNED(ctx->r12) >> 1);
    // 0x802B4EEC: addu        $t6, $t5, $t0
    ctx->r14 = ADD32(ctx->r13, ctx->r8);
    // 0x802B4EF0: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x802B4EF4: sra         $t2, $t9, 1
    ctx->r10 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B4EF8: subu        $a0, $t8, $t2
    ctx->r4 = SUB32(ctx->r24, ctx->r10);
    // 0x802B4EFC: bgez        $a0, L_802B4F0C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x802B4F00: lh          $a1, 0x36($a2)
        ctx->r5 = MEM_H(ctx->r6, 0X36);
            goto L_802B4F0C;
    }
    // 0x802B4F00: lh          $a1, 0x36($a2)
    ctx->r5 = MEM_H(ctx->r6, 0X36);
    // 0x802B4F04: b           L_802B4F10
    // 0x802B4F08: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
        goto L_802B4F10;
    // 0x802B4F08: negu        $v0, $a0
    ctx->r2 = SUB32(0, ctx->r4);
L_802B4F0C:
    // 0x802B4F0C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_802B4F10:
    // 0x802B4F10: lh          $t3, 0x36($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X36);
    // 0x802B4F14: addu        $t1, $a1, $t3
    ctx->r9 = ADD32(ctx->r5, ctx->r11);
    // 0x802B4F18: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B4F1C: beql        $at, $zero, L_802B5DC8
    if (ctx->r1 == 0) {
        // 0x802B4F20: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_7;
    // 0x802B4F20: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_7:
    // 0x802B4F24: lw          $t4, 0x68($a2)
    ctx->r12 = MEM_W(ctx->r6, 0X68);
    // 0x802B4F28: or          $s1, $a2, $zero
    ctx->r17 = ctx->r6 | 0;
    // 0x802B4F2C: or          $s0, $v1, $zero
    ctx->r16 = ctx->r3 | 0;
    // 0x802B4F30: bne         $v1, $t4, L_802B4F70
    if (ctx->r3 != ctx->r12) {
        // 0x802B4F34: lui         $t7, 0x803A
        ctx->r15 = S32(0X803A << 16);
            goto L_802B4F70;
    }
    // 0x802B4F34: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x802B4F38: lw          $t5, 0x16C($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X16C);
    // 0x802B4F3C: lw          $t9, 0x16C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X16C);
    // 0x802B4F40: addiu       $t2, $zero, 0xF
    ctx->r10 = ADD32(0, 0XF);
    // 0x802B4F44: lbu         $t0, 0x2($t5)
    ctx->r8 = MEM_BU(ctx->r13, 0X2);
    // 0x802B4F48: lbu         $t8, 0x2($t9)
    ctx->r24 = MEM_BU(ctx->r25, 0X2);
    // 0x802B4F4C: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802B4F50: sll         $t6, $t0, 1
    ctx->r14 = S32(ctx->r8 << 1);
    // 0x802B4F54: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x802B4F58: lhu         $t7, 0x510($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X510);
    // 0x802B4F5C: subu        $t3, $t2, $t8
    ctx->r11 = SUB32(ctx->r10, ctx->r24);
    // 0x802B4F60: sllv        $t4, $t1, $t3
    ctx->r12 = S32(ctx->r9 << (ctx->r11 & 31));
    // 0x802B4F64: and         $t5, $t7, $t4
    ctx->r13 = ctx->r15 & ctx->r12;
    // 0x802B4F68: bnel        $t5, $zero, L_802B5DC8
    if (ctx->r13 != 0) {
        // 0x802B4F6C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_8;
    // 0x802B4F6C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_8:
L_802B4F70:
    // 0x802B4F70: lw          $t0, 0x68($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X68);
    // 0x802B4F74: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x802B4F78: bnel        $s1, $t0, L_802B4FBC
    if (ctx->r17 != ctx->r8) {
        // 0x802B4F7C: lw          $t9, 0x70($s1)
        ctx->r25 = MEM_W(ctx->r17, 0X70);
            goto L_802B4FBC;
    }
    goto skip_9;
    // 0x802B4F7C: lw          $t9, 0x70($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X70);
    skip_9:
    // 0x802B4F80: lw          $t6, 0x16C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X16C);
    // 0x802B4F84: lw          $t1, 0x16C($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X16C);
    // 0x802B4F88: addiu       $t7, $zero, 0xF
    ctx->r15 = ADD32(0, 0XF);
    // 0x802B4F8C: lbu         $t9, 0x2($t6)
    ctx->r25 = MEM_BU(ctx->r14, 0X2);
    // 0x802B4F90: lbu         $t3, 0x2($t1)
    ctx->r11 = MEM_BU(ctx->r9, 0X2);
    // 0x802B4F94: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802B4F98: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x802B4F9C: addu        $t8, $t8, $t2
    ctx->r24 = ADD32(ctx->r24, ctx->r10);
    // 0x802B4FA0: lhu         $t8, 0x510($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X510);
    // 0x802B4FA4: subu        $t4, $t7, $t3
    ctx->r12 = SUB32(ctx->r15, ctx->r11);
    // 0x802B4FA8: sllv        $t0, $t5, $t4
    ctx->r8 = S32(ctx->r13 << (ctx->r12 & 31));
    // 0x802B4FAC: and         $t6, $t8, $t0
    ctx->r14 = ctx->r24 & ctx->r8;
    // 0x802B4FB0: bnel        $t6, $zero, L_802B5DC8
    if (ctx->r14 != 0) {
        // 0x802B4FB4: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_10;
    // 0x802B4FB4: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_10:
    // 0x802B4FB8: lw          $t9, 0x70($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X70);
L_802B4FBC:
    // 0x802B4FBC: bnel        $s0, $t9, L_802B4FF0
    if (ctx->r16 != ctx->r25) {
        // 0x802B4FC0: lw          $t5, 0x70($s0)
        ctx->r13 = MEM_W(ctx->r16, 0X70);
            goto L_802B4FF0;
    }
    goto skip_11;
    // 0x802B4FC0: lw          $t5, 0x70($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X70);
    skip_11:
    // 0x802B4FC4: lw          $t2, 0x16C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X16C);
    // 0x802B4FC8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B4FCC: lbu         $t1, 0x15($t2)
    ctx->r9 = MEM_BU(ctx->r10, 0X15);
    // 0x802B4FD0: bnel        $t1, $at, L_802B4FF0
    if (ctx->r9 != ctx->r1) {
        // 0x802B4FD4: lw          $t5, 0x70($s0)
        ctx->r13 = MEM_W(ctx->r16, 0X70);
            goto L_802B4FF0;
    }
    goto skip_12;
    // 0x802B4FD4: lw          $t5, 0x70($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X70);
    skip_12:
    // 0x802B4FD8: lw          $t7, 0x16C($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X16C);
    // 0x802B4FDC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802B4FE0: lbu         $t3, 0x2($t7)
    ctx->r11 = MEM_BU(ctx->r15, 0X2);
    // 0x802B4FE4: beql        $t3, $at, L_802B5DC8
    if (ctx->r11 == ctx->r1) {
        // 0x802B4FE8: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_13;
    // 0x802B4FE8: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_13:
    // 0x802B4FEC: lw          $t5, 0x70($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X70);
L_802B4FF0:
    // 0x802B4FF0: bnel        $s1, $t5, L_802B5024
    if (ctx->r17 != ctx->r13) {
        // 0x802B4FF4: lhu         $v0, 0x0($s1)
        ctx->r2 = MEM_HU(ctx->r17, 0X0);
            goto L_802B5024;
    }
    goto skip_14;
    // 0x802B4FF4: lhu         $v0, 0x0($s1)
    ctx->r2 = MEM_HU(ctx->r17, 0X0);
    skip_14:
    // 0x802B4FF8: lw          $t4, 0x16C($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X16C);
    // 0x802B4FFC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B5000: lbu         $t8, 0x15($t4)
    ctx->r24 = MEM_BU(ctx->r12, 0X15);
    // 0x802B5004: bnel        $t8, $at, L_802B5024
    if (ctx->r24 != ctx->r1) {
        // 0x802B5008: lhu         $v0, 0x0($s1)
        ctx->r2 = MEM_HU(ctx->r17, 0X0);
            goto L_802B5024;
    }
    goto skip_15;
    // 0x802B5008: lhu         $v0, 0x0($s1)
    ctx->r2 = MEM_HU(ctx->r17, 0X0);
    skip_15:
    // 0x802B500C: lw          $t0, 0x16C($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5010: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802B5014: lbu         $t6, 0x2($t0)
    ctx->r14 = MEM_BU(ctx->r8, 0X2);
    // 0x802B5018: beql        $t6, $at, L_802B5DC8
    if (ctx->r14 == ctx->r1) {
        // 0x802B501C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_16;
    // 0x802B501C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_16:
    // 0x802B5020: lhu         $v0, 0x0($s1)
    ctx->r2 = MEM_HU(ctx->r17, 0X0);
L_802B5024:
    // 0x802B5024: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802B5028: beql        $v0, $at, L_802B5DC8
    if (ctx->r2 == ctx->r1) {
        // 0x802B502C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_17;
    // 0x802B502C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_17:
    // 0x802B5030: lhu         $v1, 0x0($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X0);
    // 0x802B5034: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802B5038: beq         $v1, $at, L_802B5DC4
    if (ctx->r3 == ctx->r1) {
        // 0x802B503C: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B5DC4;
    }
    // 0x802B503C: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B5040: beq         $v0, $at, L_802B5DC4
    if (ctx->r2 == ctx->r1) {
        // 0x802B5044: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B5DC4;
    }
    // 0x802B5044: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B5048: beql        $v1, $at, L_802B5DC8
    if (ctx->r3 == ctx->r1) {
        // 0x802B504C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_18;
    // 0x802B504C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_18:
    // 0x802B5050: lbu         $t9, 0x15C($s1)
    ctx->r25 = MEM_BU(ctx->r17, 0X15C);
    // 0x802B5054: beql        $t9, $zero, L_802B506C
    if (ctx->r25 == 0) {
        // 0x802B5058: lbu         $t1, 0x15C($s0)
        ctx->r9 = MEM_BU(ctx->r16, 0X15C);
            goto L_802B506C;
    }
    goto skip_19;
    // 0x802B5058: lbu         $t1, 0x15C($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X15C);
    skip_19:
    // 0x802B505C: lw          $t2, 0x168($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X168);
    // 0x802B5060: beql        $s0, $t2, L_802B5DC8
    if (ctx->r16 == ctx->r10) {
        // 0x802B5064: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_20;
    // 0x802B5064: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_20:
    // 0x802B5068: lbu         $t1, 0x15C($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X15C);
L_802B506C:
    // 0x802B506C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5070: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B5074: beq         $t1, $zero, L_802B5084
    if (ctx->r9 == 0) {
        // 0x802B5078: lui         $a2, 0x803D
        ctx->r6 = S32(0X803D << 16);
            goto L_802B5084;
    }
    // 0x802B5078: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B507C: lw          $t7, 0x168($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X168);
    // 0x802B5080: beq         $s1, $t7, L_802B5DC4
    if (ctx->r17 == ctx->r15) {
        // 0x802B5084: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802B5DC4;
    }
L_802B5084:
    // 0x802B5084: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B5088: addiu       $a3, $a3, 0x60D4
    ctx->r7 = ADD32(ctx->r7, 0X60D4);
    // 0x802B508C: jal         0x802B5E48
    // 0x802B5090: addiu       $a2, $a2, 0x60D0
    ctx->r6 = ADD32(ctx->r6, 0X60D0);
    func_802B5E48_6C74F8(rdram, ctx);
        goto after_0;
    // 0x802B5090: addiu       $a2, $a2, 0x60D0
    ctx->r6 = ADD32(ctx->r6, 0X60D0);
    after_0:
    // 0x802B5094: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5098: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
    // 0x802B509C: sll         $s2, $v0, 16
    ctx->r18 = S32(ctx->r2 << 16);
    // 0x802B50A0: sra         $t3, $s2, 16
    ctx->r11 = S32(SIGNED(ctx->r18) >> 16);
    // 0x802B50A4: beq         $v1, $zero, L_802B5104
    if (ctx->r3 == 0) {
        // 0x802B50A8: or          $s2, $t3, $zero
        ctx->r18 = ctx->r11 | 0;
            goto L_802B5104;
    }
    // 0x802B50A8: or          $s2, $t3, $zero
    ctx->r18 = ctx->r11 | 0;
    // 0x802B50AC: lw          $at, 0x10($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X10);
    // 0x802B50B0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B50B4: lw          $t9, 0x60D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X60D0);
    // 0x802B50B8: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B50BC: lw          $at, 0x14($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X14);
    // 0x802B50C0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B50C4: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B50C8: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B50CC: lw          $at, 0x18($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X18);
    // 0x802B50D0: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x802B50D4: or          $a3, $s7, $zero
    ctx->r7 = ctx->r23 | 0;
    // 0x802B50D8: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B50DC: lw          $at, 0x10($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X10);
    // 0x802B50E0: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B50E4: lw          $at, 0x14($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X14);
    // 0x802B50E8: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B50EC: lw          $at, 0x18($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X18);
    // 0x802B50F0: jalr        $t9
    // 0x802B50F4: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_1;
    // 0x802B50F4: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_1:
    // 0x802B50F8: bne         $v0, $zero, L_802B5160
    if (ctx->r2 != 0) {
        // 0x802B50FC: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B5160;
    }
    // 0x802B50FC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5100: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
L_802B5104:
    // 0x802B5104: bnel        $v1, $zero, L_802B5DC8
    if (ctx->r3 != 0) {
        // 0x802B5108: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_21;
    // 0x802B5108: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_21:
    // 0x802B510C: lw          $at, 0x10($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X10);
    // 0x802B5110: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B5114: lw          $t9, 0x60D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X60D0);
    // 0x802B5118: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B511C: lw          $at, 0x14($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X14);
    // 0x802B5120: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5124: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B5128: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B512C: lw          $at, 0x18($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X18);
    // 0x802B5130: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x802B5134: or          $a3, $s7, $zero
    ctx->r7 = ctx->r23 | 0;
    // 0x802B5138: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B513C: lw          $at, 0x10($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X10);
    // 0x802B5140: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B5144: lw          $at, 0x14($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X14);
    // 0x802B5148: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B514C: lw          $at, 0x18($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X18);
    // 0x802B5150: jalr        $t9
    // 0x802B5154: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_2;
    // 0x802B5154: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_2:
    // 0x802B5158: beql        $v0, $zero, L_802B5DC8
    if (ctx->r2 == 0) {
        // 0x802B515C: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_22;
    // 0x802B515C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_22:
L_802B5160:
    // 0x802B5160: lbu         $t2, 0x4F($s1)
    ctx->r10 = MEM_BU(ctx->r17, 0X4F);
    // 0x802B5164: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x802B5168: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B516C: ori         $t1, $t2, 0x40
    ctx->r9 = ctx->r10 | 0X40;
    // 0x802B5170: sb          $t1, 0x4F($s1)
    MEM_B(0X4F, ctx->r17) = ctx->r9;
    // 0x802B5174: lbu         $t3, 0x4F($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X4F);
    // 0x802B5178: ori         $t5, $t3, 0x40
    ctx->r13 = ctx->r11 | 0X40;
    // 0x802B517C: sb          $t5, 0x4F($s0)
    MEM_B(0X4F, ctx->r16) = ctx->r13;
    // 0x802B5180: lh          $t4, 0x5534($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X5534);
    // 0x802B5184: sll         $t8, $t4, 3
    ctx->r24 = S32(ctx->r12 << 3);
    // 0x802B5188: addu        $v0, $v0, $t8
    ctx->r2 = ADD32(ctx->r2, ctx->r24);
    // 0x802B518C: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x802B5190: bne         $s1, $v0, L_802B51CC
    if (ctx->r17 != ctx->r2) {
        // 0x802B5194: nop
    
            goto L_802B51CC;
    }
    // 0x802B5194: nop

    // 0x802B5198: lw          $t0, 0x16C($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X16C);
    // 0x802B519C: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B51A0: lhu         $t9, 0x0($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0X0);
    // 0x802B51A4: bne         $t9, $at, L_802B51CC
    if (ctx->r25 != ctx->r1) {
        // 0x802B51A8: nop
    
            goto L_802B51CC;
    }
    // 0x802B51A8: nop

    // 0x802B51AC: jal         0x8038F5F8
    // 0x802B51B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_3;
    // 0x802B51B0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_3:
    // 0x802B51B4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B51B8: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x802B51BC: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B51C0: sll         $t2, $t6, 3
    ctx->r10 = S32(ctx->r14 << 3);
    // 0x802B51C4: addu        $v0, $v0, $t2
    ctx->r2 = ADD32(ctx->r2, ctx->r10);
    // 0x802B51C8: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
L_802B51CC:
    // 0x802B51CC: bnel        $s0, $v0, L_802B51F4
    if (ctx->r16 != ctx->r2) {
        // 0x802B51D0: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802B51F4;
    }
    goto skip_23;
    // 0x802B51D0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    skip_23:
    // 0x802B51D4: lw          $t1, 0x16C($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X16C);
    // 0x802B51D8: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B51DC: lhu         $t7, 0x0($t1)
    ctx->r15 = MEM_HU(ctx->r9, 0X0);
    // 0x802B51E0: bnel        $t7, $at, L_802B51F4
    if (ctx->r15 != ctx->r1) {
        // 0x802B51E4: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802B51F4;
    }
    goto skip_24;
    // 0x802B51E4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    skip_24:
    // 0x802B51E8: jal         0x8038F5F8
    // 0x802B51EC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_4;
    // 0x802B51EC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_4:
    // 0x802B51F0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
L_802B51F4:
    // 0x802B51F4: jal         0x802FD674
    // 0x802B51F8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    func_802FD674_70ED24(rdram, ctx);
        goto after_5;
    // 0x802B51F8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_5:
    // 0x802B51FC: lw          $t3, 0x1C($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X1C);
    // 0x802B5200: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x802B5204: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5208: sw          $t3, 0x11C($sp)
    MEM_W(0X11C, ctx->r29) = ctx->r11;
    // 0x802B520C: lw          $t5, 0x20($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X20);
    // 0x802B5210: lh          $a2, 0x11C($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X11C);
    // 0x802B5214: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B5218: sw          $t5, 0x114($sp)
    MEM_W(0X114, ctx->r29) = ctx->r13;
    // 0x802B521C: lw          $t4, 0x24($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X24);
    // 0x802B5220: lh          $a3, 0x114($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X114);
    // 0x802B5224: sw          $t4, 0x10C($sp)
    MEM_W(0X10C, ctx->r29) = ctx->r12;
    // 0x802B5228: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x802B522C: lh          $t1, 0x10C($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X10C);
    // 0x802B5230: sw          $t8, 0x118($sp)
    MEM_W(0X118, ctx->r29) = ctx->r24;
    // 0x802B5234: lw          $t0, 0x20($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X20);
    // 0x802B5238: sw          $t0, 0x110($sp)
    MEM_W(0X110, ctx->r29) = ctx->r8;
    // 0x802B523C: lw          $t9, 0x24($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X24);
    // 0x802B5240: sw          $t9, 0x108($sp)
    MEM_W(0X108, ctx->r29) = ctx->r25;
    // 0x802B5244: lw          $t6, 0x16C($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X16C);
    // 0x802B5248: lbu         $v1, 0x2($t6)
    ctx->r3 = MEM_BU(ctx->r14, 0X2);
    // 0x802B524C: beql        $v1, $at, L_802B527C
    if (ctx->r3 == ctx->r1) {
        // 0x802B5250: lh          $t7, 0x118($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X118);
            goto L_802B527C;
    }
    goto skip_25;
    // 0x802B5250: lh          $t7, 0x118($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X118);
    skip_25:
    // 0x802B5254: lw          $t2, 0x16C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5258: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x802B525C: lbu         $v0, 0x2($t2)
    ctx->r2 = MEM_BU(ctx->r10, 0X2);
    // 0x802B5260: beq         $v0, $at, L_802B5278
    if (ctx->r2 == ctx->r1) {
        // 0x802B5264: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_802B5278;
    }
    // 0x802B5264: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802B5268: beq         $v1, $at, L_802B5278
    if (ctx->r3 == ctx->r1) {
        // 0x802B526C: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_802B5278;
    }
    // 0x802B526C: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x802B5270: bnel        $v0, $at, L_802B52A4
    if (ctx->r2 != ctx->r1) {
        // 0x802B5274: lw          $t4, 0x4($s1)
        ctx->r12 = MEM_W(ctx->r17, 0X4);
            goto L_802B52A4;
    }
    goto skip_26;
    // 0x802B5274: lw          $t4, 0x4($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X4);
    skip_26:
L_802B5278:
    // 0x802B5278: lh          $t7, 0x118($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X118);
L_802B527C:
    // 0x802B527C: lh          $t3, 0x110($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X110);
    // 0x802B5280: lh          $t5, 0x108($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X108);
    // 0x802B5284: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x802B5288: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802B528C: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x802B5290: jal         0x802CAB20
    // 0x802B5294: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    func_802CAB20_6DC1D0(rdram, ctx);
        goto after_6;
    // 0x802B5294: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    after_6:
    // 0x802B5298: b           L_802B5DC8
    // 0x802B529C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
        goto L_802B5DC8;
    // 0x802B529C: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    // 0x802B52A0: lw          $t4, 0x4($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X4);
L_802B52A4:
    // 0x802B52A4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802B52A8: mov.s       $f2, $f26
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 26);
    ctx->f2.fl = ctx->f26.fl;
    // 0x802B52AC: mtc1        $t4, $f4
    ctx->f4.u32l = ctx->r12;
    // 0x802B52B0: nop

    // 0x802B52B4: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B52B8: div.d       $f8, $f6, $f20
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f20.d); 
    ctx->f8.d = DIV_D(ctx->f6.d, ctx->f20.d);
    // 0x802B52BC: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x802B52C0: swc1        $f10, 0xF8($sp)
    MEM_W(0XF8, ctx->r29) = ctx->f10.u32l;
    // 0x802B52C4: lw          $t8, 0x8($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X8);
    // 0x802B52C8: mtc1        $t8, $f16
    ctx->f16.u32l = ctx->r24;
    // 0x802B52CC: nop

    // 0x802B52D0: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x802B52D4: div.d       $f4, $f18, $f20
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f20.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f20.d);
    // 0x802B52D8: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x802B52DC: swc1        $f6, 0xFC($sp)
    MEM_W(0XFC, ctx->r29) = ctx->f6.u32l;
    // 0x802B52E0: lw          $t0, 0xC($s1)
    ctx->r8 = MEM_W(ctx->r17, 0XC);
    // 0x802B52E4: lhu         $t9, 0x42($s1)
    ctx->r25 = MEM_HU(ctx->r17, 0X42);
    // 0x802B52E8: mtc1        $t0, $f8
    ctx->f8.u32l = ctx->r8;
    // 0x802B52EC: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B52F0: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x802B52F4: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802B52F8: cvt.d.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.d = CVT_D_W(ctx->f18.u32l);
    // 0x802B52FC: div.d       $f16, $f10, $f20
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f20.d); 
    ctx->f16.d = DIV_D(ctx->f10.d, ctx->f20.d);
    // 0x802B5300: add.d       $f6, $f16, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f16.d + ctx->f4.d;
    // 0x802B5304: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x802B5308: swc1        $f8, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f8.u32l;
    // 0x802B530C: lw          $t2, 0x1C($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X1C);
    // 0x802B5310: mtc1        $t2, $f10
    ctx->f10.u32l = ctx->r10;
    // 0x802B5314: nop

    // 0x802B5318: cvt.d.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.d = CVT_D_W(ctx->f10.u32l);
    // 0x802B531C: div.d       $f16, $f18, $f20
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f20.d); 
    ctx->f16.d = DIV_D(ctx->f18.d, ctx->f20.d);
    // 0x802B5320: cvt.s.d     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f4.fl = CVT_S_D(ctx->f16.d);
    // 0x802B5324: swc1        $f4, 0xEC($sp)
    MEM_W(0XEC, ctx->r29) = ctx->f4.u32l;
    // 0x802B5328: lw          $t1, 0x20($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X20);
    // 0x802B532C: mtc1        $t1, $f6
    ctx->f6.u32l = ctx->r9;
    // 0x802B5330: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B5334: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x802B5338: div.d       $f10, $f8, $f20
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f20.d); 
    ctx->f10.d = DIV_D(ctx->f8.d, ctx->f20.d);
    // 0x802B533C: cvt.s.d     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f18.fl = CVT_S_D(ctx->f10.d);
    // 0x802B5340: swc1        $f18, 0xF0($sp)
    MEM_W(0XF0, ctx->r29) = ctx->f18.u32l;
    // 0x802B5344: lw          $t7, 0x24($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X24);
    // 0x802B5348: mtc1        $t7, $f16
    ctx->f16.u32l = ctx->r15;
    // 0x802B534C: nop

    // 0x802B5350: cvt.d.w     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.d = CVT_D_W(ctx->f16.u32l);
    // 0x802B5354: div.d       $f6, $f4, $f20
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f20.d); 
    ctx->f6.d = DIV_D(ctx->f4.d, ctx->f20.d);
    // 0x802B5358: cvt.s.d     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f8.fl = CVT_S_D(ctx->f6.d);
    // 0x802B535C: swc1        $f8, 0xF4($sp)
    MEM_W(0XF4, ctx->r29) = ctx->f8.u32l;
    // 0x802B5360: lw          $t3, 0x4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X4);
    // 0x802B5364: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x802B5368: nop

    // 0x802B536C: cvt.d.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.d = CVT_D_W(ctx->f10.u32l);
    // 0x802B5370: div.d       $f16, $f18, $f20
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f20.d); 
    ctx->f16.d = DIV_D(ctx->f18.d, ctx->f20.d);
    // 0x802B5374: cvt.s.d     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f4.fl = CVT_S_D(ctx->f16.d);
    // 0x802B5378: swc1        $f4, 0xE0($sp)
    MEM_W(0XE0, ctx->r29) = ctx->f4.u32l;
    // 0x802B537C: lw          $t5, 0x8($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X8);
    // 0x802B5380: mtc1        $t5, $f6
    ctx->f6.u32l = ctx->r13;
    // 0x802B5384: nop

    // 0x802B5388: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x802B538C: div.d       $f10, $f8, $f20
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f20.d); 
    ctx->f10.d = DIV_D(ctx->f8.d, ctx->f20.d);
    // 0x802B5390: cvt.s.d     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f18.fl = CVT_S_D(ctx->f10.d);
    // 0x802B5394: swc1        $f18, 0xE4($sp)
    MEM_W(0XE4, ctx->r29) = ctx->f18.u32l;
    // 0x802B5398: lw          $t4, 0xC($s0)
    ctx->r12 = MEM_W(ctx->r16, 0XC);
    // 0x802B539C: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x802B53A0: mtc1        $t4, $f16
    ctx->f16.u32l = ctx->r12;
    // 0x802B53A4: sra         $t0, $t8, 1
    ctx->r8 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802B53A8: mtc1        $t0, $f8
    ctx->f8.u32l = ctx->r8;
    // 0x802B53AC: cvt.d.w     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.d = CVT_D_W(ctx->f16.u32l);
    // 0x802B53B0: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802B53B4: div.d       $f6, $f4, $f20
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f20.d); 
    ctx->f6.d = DIV_D(ctx->f4.d, ctx->f20.d);
    // 0x802B53B8: add.d       $f18, $f6, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = ctx->f6.d + ctx->f10.d;
    // 0x802B53BC: cvt.s.d     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f16.fl = CVT_S_D(ctx->f18.d);
    // 0x802B53C0: swc1        $f16, 0xE8($sp)
    MEM_W(0XE8, ctx->r29) = ctx->f16.u32l;
    // 0x802B53C4: lw          $t9, 0x1C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X1C);
    // 0x802B53C8: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x802B53CC: nop

    // 0x802B53D0: cvt.d.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B53D4: div.d       $f6, $f8, $f20
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f20.d); 
    ctx->f6.d = DIV_D(ctx->f8.d, ctx->f20.d);
    // 0x802B53D8: cvt.s.d     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f10.fl = CVT_S_D(ctx->f6.d);
    // 0x802B53DC: swc1        $f10, 0xD4($sp)
    MEM_W(0XD4, ctx->r29) = ctx->f10.u32l;
    // 0x802B53E0: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x802B53E4: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x802B53E8: nop

    // 0x802B53EC: cvt.d.w     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    ctx->f16.d = CVT_D_W(ctx->f18.u32l);
    // 0x802B53F0: div.d       $f4, $f16, $f20
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f20.d); 
    ctx->f4.d = DIV_D(ctx->f16.d, ctx->f20.d);
    // 0x802B53F4: cvt.s.d     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f8.fl = CVT_S_D(ctx->f4.d);
    // 0x802B53F8: swc1        $f8, 0xD8($sp)
    MEM_W(0XD8, ctx->r29) = ctx->f8.u32l;
    // 0x802B53FC: lw          $t2, 0x24($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X24);
    // 0x802B5400: mtc1        $t2, $f6
    ctx->f6.u32l = ctx->r10;
    // 0x802B5404: nop

    // 0x802B5408: cvt.d.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.d = CVT_D_W(ctx->f6.u32l);
    // 0x802B540C: div.d       $f18, $f10, $f20
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f20.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f20.d);
    // 0x802B5410: cvt.s.d     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f16.fl = CVT_S_D(ctx->f18.d);
    // 0x802B5414: beq         $s2, $at, L_802B5428
    if (ctx->r18 == ctx->r1) {
        // 0x802B5418: swc1        $f16, 0xDC($sp)
        MEM_W(0XDC, ctx->r29) = ctx->f16.u32l;
            goto L_802B5428;
    }
    // 0x802B5418: swc1        $f16, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->f16.u32l;
    // 0x802B541C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B5420: bnel        $s2, $at, L_802B5464
    if (ctx->r18 != ctx->r1) {
        // 0x802B5424: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5464;
    }
    goto skip_27;
    // 0x802B5424: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_27:
L_802B5428:
    // 0x802B5428: lbu         $t1, 0x60E0($t1)
    ctx->r9 = MEM_BU(ctx->r9, 0X60E0);
    // 0x802B542C: bnel        $fp, $t1, L_802B5464
    if (ctx->r30 != ctx->r9) {
        // 0x802B5430: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5464;
    }
    goto skip_28;
    // 0x802B5430: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_28:
    // 0x802B5434: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    // 0x802B5438: lw          $a2, 0x80($a1)
    ctx->r6 = MEM_W(ctx->r5, 0X80);
    // 0x802B543C: sll         $a3, $a2, 18
    ctx->r7 = S32(ctx->r6 << 18);
    // 0x802B5440: srl         $t7, $a3, 31
    ctx->r15 = S32(U32(ctx->r7) >> 31);
    // 0x802B5444: bne         $t7, $zero, L_802B5518
    if (ctx->r15 != 0) {
        // 0x802B5448: or          $a3, $t7, $zero
        ctx->r7 = ctx->r15 | 0;
            goto L_802B5518;
    }
    // 0x802B5448: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x802B544C: lw          $t3, 0x16C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5450: lw          $t5, 0x80($t3)
    ctx->r13 = MEM_W(ctx->r11, 0X80);
    // 0x802B5454: sll         $t8, $t5, 18
    ctx->r24 = S32(ctx->r13 << 18);
    // 0x802B5458: bltzl       $t8, L_802B551C
    if (SIGNED(ctx->r24) < 0) {
        // 0x802B545C: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B551C;
    }
    goto skip_29;
    // 0x802B545C: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_29:
    // 0x802B5460: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
L_802B5464:
    // 0x802B5464: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B5468: lw          $a2, 0x80($a1)
    ctx->r6 = MEM_W(ctx->r5, 0X80);
    // 0x802B546C: sll         $a3, $a2, 18
    ctx->r7 = S32(ctx->r6 << 18);
    // 0x802B5470: srl         $t0, $a3, 31
    ctx->r8 = S32(U32(ctx->r7) >> 31);
    // 0x802B5474: beq         $s2, $fp, L_802B5484
    if (ctx->r18 == ctx->r30) {
        // 0x802B5478: or          $a3, $t0, $zero
        ctx->r7 = ctx->r8 | 0;
            goto L_802B5484;
    }
    // 0x802B5478: or          $a3, $t0, $zero
    ctx->r7 = ctx->r8 | 0;
    // 0x802B547C: bnel        $s2, $at, L_802B5534
    if (ctx->r18 != ctx->r1) {
        // 0x802B5480: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B5534;
    }
    goto skip_30;
    // 0x802B5480: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_30:
L_802B5484:
    // 0x802B5484: lw          $t9, 0x0($s7)
    ctx->r25 = MEM_W(ctx->r23, 0X0);
    // 0x802B5488: lw          $t6, 0x8($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X8);
    // 0x802B548C: bnel        $t6, $zero, L_802B5534
    if (ctx->r14 != 0) {
        // 0x802B5490: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B5534;
    }
    goto skip_31;
    // 0x802B5490: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_31:
    // 0x802B5494: beql        $a3, $zero, L_802B54D4
    if (ctx->r7 == 0) {
        // 0x802B5498: lw          $t4, 0x16C($s0)
        ctx->r12 = MEM_W(ctx->r16, 0X16C);
            goto L_802B54D4;
    }
    goto skip_32;
    // 0x802B5498: lw          $t4, 0x16C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X16C);
    skip_32:
    // 0x802B549C: lhu         $t1, 0x42($s1)
    ctx->r9 = MEM_HU(ctx->r17, 0X42);
    // 0x802B54A0: lh          $t2, 0xC($s1)
    ctx->r10 = MEM_H(ctx->r17, 0XC);
    // 0x802B54A4: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802B54A8: sra         $t7, $t1, 1
    ctx->r15 = S32(SIGNED(ctx->r9) >> 1);
    // 0x802B54AC: addu        $v1, $t2, $t7
    ctx->r3 = ADD32(ctx->r10, ctx->r15);
    // 0x802B54B0: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B54B4: beql        $at, $zero, L_802B54D4
    if (ctx->r1 == 0) {
        // 0x802B54B8: lw          $t4, 0x16C($s0)
        ctx->r12 = MEM_W(ctx->r16, 0X16C);
            goto L_802B54D4;
    }
    goto skip_33;
    // 0x802B54B8: lw          $t4, 0x16C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X16C);
    skip_33:
    // 0x802B54BC: lhu         $t3, 0x42($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X42);
    // 0x802B54C0: addu        $t5, $v0, $t3
    ctx->r13 = ADD32(ctx->r2, ctx->r11);
    // 0x802B54C4: slt         $at, $v1, $t5
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B54C8: bnel        $at, $zero, L_802B551C
    if (ctx->r1 != 0) {
        // 0x802B54CC: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B551C;
    }
    goto skip_34;
    // 0x802B54CC: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_34:
    // 0x802B54D0: lw          $t4, 0x16C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X16C);
L_802B54D4:
    // 0x802B54D4: lw          $t8, 0x80($t4)
    ctx->r24 = MEM_W(ctx->r12, 0X80);
    // 0x802B54D8: sll         $t9, $t8, 18
    ctx->r25 = S32(ctx->r24 << 18);
    // 0x802B54DC: bgezl       $t9, L_802B5534
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802B54E0: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B5534;
    }
    goto skip_35;
    // 0x802B54E0: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_35:
    // 0x802B54E4: lhu         $t1, 0x42($s0)
    ctx->r9 = MEM_HU(ctx->r16, 0X42);
    // 0x802B54E8: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802B54EC: lh          $v0, 0xC($s1)
    ctx->r2 = MEM_H(ctx->r17, 0XC);
    // 0x802B54F0: sra         $t2, $t1, 1
    ctx->r10 = S32(SIGNED(ctx->r9) >> 1);
    // 0x802B54F4: addu        $v1, $t6, $t2
    ctx->r3 = ADD32(ctx->r14, ctx->r10);
    // 0x802B54F8: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B54FC: beql        $at, $zero, L_802B5534
    if (ctx->r1 == 0) {
        // 0x802B5500: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B5534;
    }
    goto skip_36;
    // 0x802B5500: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_36:
    // 0x802B5504: lhu         $t7, 0x42($s1)
    ctx->r15 = MEM_HU(ctx->r17, 0X42);
    // 0x802B5508: addu        $t3, $v0, $t7
    ctx->r11 = ADD32(ctx->r2, ctx->r15);
    // 0x802B550C: slt         $at, $v1, $t3
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B5510: beql        $at, $zero, L_802B5534
    if (ctx->r1 == 0) {
        // 0x802B5514: lw          $v1, 0x16C($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X16C);
            goto L_802B5534;
    }
    goto skip_37;
    // 0x802B5514: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    skip_37:
L_802B5518:
    // 0x802B5518: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
L_802B551C:
    // 0x802B551C: lui         $at, 0x3E00
    ctx->r1 = S32(0X3E00 << 16);
    // 0x802B5520: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    // 0x802B5524: addiu       $s5, $zero, 0x1
    ctx->r21 = ADD32(0, 0X1);
    // 0x802B5528: b           L_802B553C
    // 0x802B552C: lw          $a0, 0x80($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X80);
        goto L_802B553C;
    // 0x802B552C: lw          $a0, 0x80($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X80);
    // 0x802B5530: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
L_802B5534:
    // 0x802B5534: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x802B5538: lw          $a0, 0x80($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X80);
L_802B553C:
    // 0x802B553C: beq         $a3, $zero, L_802B55A8
    if (ctx->r7 == 0) {
        // 0x802B5540: sll         $t7, $a0, 18
        ctx->r15 = S32(ctx->r4 << 18);
            goto L_802B55A8;
    }
    // 0x802B5540: sll         $t7, $a0, 18
    ctx->r15 = S32(ctx->r4 << 18);
    // 0x802B5544: lw          $t4, 0x0($s6)
    ctx->r12 = MEM_W(ctx->r22, 0X0);
    // 0x802B5548: addiu       $t5, $s1, 0xC4
    ctx->r13 = ADD32(ctx->r17, 0XC4);
    // 0x802B554C: bne         $t5, $t4, L_802B55A8
    if (ctx->r13 != ctx->r12) {
        // 0x802B5550: nop
    
            goto L_802B55A8;
    }
    // 0x802B5550: nop

    // 0x802B5554: lbu         $v0, 0x162($s1)
    ctx->r2 = MEM_BU(ctx->r17, 0X162);
    // 0x802B5558: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B555C: beql        $fp, $v0, L_802B5570
    if (ctx->r30 == ctx->r2) {
        // 0x802B5560: lbu         $v0, 0x162($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X162);
            goto L_802B5570;
    }
    goto skip_38;
    // 0x802B5560: lbu         $v0, 0x162($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X162);
    skip_38:
    // 0x802B5564: bne         $v0, $at, L_802B55A8
    if (ctx->r2 != ctx->r1) {
        // 0x802B5568: nop
    
            goto L_802B55A8;
    }
    // 0x802B5568: nop

    // 0x802B556C: lbu         $v0, 0x162($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X162);
L_802B5570:
    // 0x802B5570: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B5574: beql        $fp, $v0, L_802B5588
    if (ctx->r30 == ctx->r2) {
        // 0x802B5578: lw          $t8, 0x4C($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X4C);
            goto L_802B5588;
    }
    goto skip_39;
    // 0x802B5578: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
    skip_39:
    // 0x802B557C: bne         $v0, $at, L_802B55A8
    if (ctx->r2 != ctx->r1) {
        // 0x802B5580: nop
    
            goto L_802B55A8;
    }
    // 0x802B5580: nop

    // 0x802B5584: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
L_802B5588:
    // 0x802B5588: sll         $t1, $a0, 17
    ctx->r9 = S32(ctx->r4 << 17);
    // 0x802B558C: sll         $t0, $t8, 27
    ctx->r8 = S32(ctx->r24 << 27);
    // 0x802B5590: srl         $t9, $t0, 31
    ctx->r25 = S32(U32(ctx->r8) >> 31);
    // 0x802B5594: beq         $t9, $zero, L_802B55A8
    if (ctx->r25 == 0) {
        // 0x802B5598: nop
    
            goto L_802B55A8;
    }
    // 0x802B5598: nop

    // 0x802B559C: srl         $t6, $t1, 31
    ctx->r14 = S32(U32(ctx->r9) >> 31);
    // 0x802B55A0: beql        $t6, $zero, L_802B5618
    if (ctx->r14 == 0) {
        // 0x802B55A4: lhu         $v0, 0x0($a1)
        ctx->r2 = MEM_HU(ctx->r5, 0X0);
            goto L_802B5618;
    }
    goto skip_40;
    // 0x802B55A4: lhu         $v0, 0x0($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X0);
    skip_40:
L_802B55A8:
    // 0x802B55A8: bgez        $t7, L_802B5910
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802B55AC: nop
    
            goto L_802B5910;
    }
    // 0x802B55AC: nop

    // 0x802B55B0: lw          $t5, 0x0($s6)
    ctx->r13 = MEM_W(ctx->r22, 0X0);
    // 0x802B55B4: addiu       $t3, $s0, 0xC4
    ctx->r11 = ADD32(ctx->r16, 0XC4);
    // 0x802B55B8: bne         $t3, $t5, L_802B5910
    if (ctx->r11 != ctx->r13) {
        // 0x802B55BC: nop
    
            goto L_802B5910;
    }
    // 0x802B55BC: nop

    // 0x802B55C0: lbu         $v0, 0x162($s1)
    ctx->r2 = MEM_BU(ctx->r17, 0X162);
    // 0x802B55C4: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B55C8: beql        $fp, $v0, L_802B55DC
    if (ctx->r30 == ctx->r2) {
        // 0x802B55CC: lbu         $v0, 0x162($s0)
        ctx->r2 = MEM_BU(ctx->r16, 0X162);
            goto L_802B55DC;
    }
    goto skip_41;
    // 0x802B55CC: lbu         $v0, 0x162($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X162);
    skip_41:
    // 0x802B55D0: bne         $v0, $at, L_802B5910
    if (ctx->r2 != ctx->r1) {
        // 0x802B55D4: nop
    
            goto L_802B5910;
    }
    // 0x802B55D4: nop

    // 0x802B55D8: lbu         $v0, 0x162($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X162);
L_802B55DC:
    // 0x802B55DC: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B55E0: beql        $fp, $v0, L_802B55F4
    if (ctx->r30 == ctx->r2) {
        // 0x802B55E4: lw          $t4, 0x4C($s1)
        ctx->r12 = MEM_W(ctx->r17, 0X4C);
            goto L_802B55F4;
    }
    goto skip_42;
    // 0x802B55E4: lw          $t4, 0x4C($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X4C);
    skip_42:
    // 0x802B55E8: bne         $v0, $at, L_802B5910
    if (ctx->r2 != ctx->r1) {
        // 0x802B55EC: nop
    
            goto L_802B5910;
    }
    // 0x802B55EC: nop

    // 0x802B55F0: lw          $t4, 0x4C($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X4C);
L_802B55F4:
    // 0x802B55F4: sll         $t9, $a2, 17
    ctx->r25 = S32(ctx->r6 << 17);
    // 0x802B55F8: srl         $t1, $t9, 31
    ctx->r9 = S32(U32(ctx->r25) >> 31);
    // 0x802B55FC: sll         $t8, $t4, 27
    ctx->r24 = S32(ctx->r12 << 27);
    // 0x802B5600: srl         $t0, $t8, 31
    ctx->r8 = S32(U32(ctx->r24) >> 31);
    // 0x802B5604: beq         $t0, $zero, L_802B5910
    if (ctx->r8 == 0) {
        // 0x802B5608: nop
    
            goto L_802B5910;
    }
    // 0x802B5608: nop

    // 0x802B560C: bne         $t1, $zero, L_802B5910
    if (ctx->r9 != 0) {
        // 0x802B5610: nop
    
            goto L_802B5910;
    }
    // 0x802B5610: nop

    // 0x802B5614: lhu         $v0, 0x0($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X0);
L_802B5618:
    // 0x802B5618: addiu       $at, $zero, 0x13D
    ctx->r1 = ADD32(0, 0X13D);
    // 0x802B561C: lhu         $s3, 0x44($s1)
    ctx->r19 = MEM_HU(ctx->r17, 0X44);
    // 0x802B5620: bne         $v0, $at, L_802B5630
    if (ctx->r2 != ctx->r1) {
        // 0x802B5624: lhu         $s4, 0x44($s0)
        ctx->r20 = MEM_HU(ctx->r16, 0X44);
            goto L_802B5630;
    }
    // 0x802B5624: lhu         $s4, 0x44($s0)
    ctx->r20 = MEM_HU(ctx->r16, 0X44);
    // 0x802B5628: b           L_802B5644
    // 0x802B562C: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
        goto L_802B5644;
    // 0x802B562C: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
L_802B5630:
    // 0x802B5630: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    // 0x802B5634: addiu       $at, $zero, 0x13D
    ctx->r1 = ADD32(0, 0X13D);
    // 0x802B5638: bne         $t6, $at, L_802B5644
    if (ctx->r14 != ctx->r1) {
        // 0x802B563C: nop
    
            goto L_802B5644;
    }
    // 0x802B563C: nop

    // 0x802B5640: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
L_802B5644:
    // 0x802B5644: beq         $a3, $zero, L_802B56F0
    if (ctx->r7 == 0) {
        // 0x802B5648: sll         $t7, $a0, 18
        ctx->r15 = S32(ctx->r4 << 18);
            goto L_802B56F0;
    }
    // 0x802B5648: sll         $t7, $a0, 18
    ctx->r15 = S32(ctx->r4 << 18);
    // 0x802B564C: bgez        $t7, L_802B56F0
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802B5650: addiu       $at, $zero, 0x111
        ctx->r1 = ADD32(0, 0X111);
            goto L_802B56F0;
    }
    // 0x802B5650: addiu       $at, $zero, 0x111
    ctx->r1 = ADD32(0, 0X111);
    // 0x802B5654: beq         $v0, $at, L_802B5668
    if (ctx->r2 == ctx->r1) {
        // 0x802B5658: sll         $t3, $s3, 2
        ctx->r11 = S32(ctx->r19 << 2);
            goto L_802B5668;
    }
    // 0x802B5658: sll         $t3, $s3, 2
    ctx->r11 = S32(ctx->r19 << 2);
    // 0x802B565C: addiu       $at, $zero, 0x141
    ctx->r1 = ADD32(0, 0X141);
    // 0x802B5660: bnel        $v0, $at, L_802B56A0
    if (ctx->r2 != ctx->r1) {
        // 0x802B5664: lhu         $v0, 0x0($v1)
        ctx->r2 = MEM_HU(ctx->r3, 0X0);
            goto L_802B56A0;
    }
    goto skip_43;
    // 0x802B5664: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    skip_43:
L_802B5668:
    // 0x802B5668: lh          $t5, 0x8($s1)
    ctx->r13 = MEM_H(ctx->r17, 0X8);
    // 0x802B566C: lh          $a3, 0x4($s1)
    ctx->r7 = MEM_H(ctx->r17, 0X4);
    // 0x802B5670: subu        $t3, $t3, $s3
    ctx->r11 = SUB32(ctx->r11, ctx->r19);
    // 0x802B5674: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802B5678: lh          $t4, 0xC($s1)
    ctx->r12 = MEM_H(ctx->r17, 0XC);
    // 0x802B567C: or          $s3, $t3, $zero
    ctx->r19 = ctx->r11 | 0;
    // 0x802B5680: swc1        $f26, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f26.u32l;
    // 0x802B5684: addiu       $a0, $zero, 0x4F
    ctx->r4 = ADD32(0, 0X4F);
    // 0x802B5688: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802B568C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802B5690: jal         0x8032C360
    // 0x802B5694: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    play_sound_effect_at_location(rdram, ctx);
        goto after_7;
    // 0x802B5694: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_7:
    // 0x802B5698: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    // 0x802B569C: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
L_802B56A0:
    // 0x802B56A0: addiu       $at, $zero, 0x111
    ctx->r1 = ADD32(0, 0X111);
    // 0x802B56A4: addiu       $a0, $zero, 0x4F
    ctx->r4 = ADD32(0, 0X4F);
    // 0x802B56A8: beq         $v0, $at, L_802B56B8
    if (ctx->r2 == ctx->r1) {
        // 0x802B56AC: addiu       $at, $zero, 0x141
        ctx->r1 = ADD32(0, 0X141);
            goto L_802B56B8;
    }
    // 0x802B56AC: addiu       $at, $zero, 0x141
    ctx->r1 = ADD32(0, 0X141);
    // 0x802B56B0: bnel        $v0, $at, L_802B5728
    if (ctx->r2 != ctx->r1) {
        // 0x802B56B4: addu        $s2, $s3, $s4
        ctx->r18 = ADD32(ctx->r19, ctx->r20);
            goto L_802B5728;
    }
    goto skip_44;
    // 0x802B56B4: addu        $s2, $s3, $s4
    ctx->r18 = ADD32(ctx->r19, ctx->r20);
    skip_44:
L_802B56B8:
    // 0x802B56B8: lh          $t0, 0x8($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X8);
    // 0x802B56BC: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802B56C0: sll         $t8, $s4, 2
    ctx->r24 = S32(ctx->r20 << 2);
    // 0x802B56C4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x802B56C8: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802B56CC: subu        $t8, $t8, $s4
    ctx->r24 = SUB32(ctx->r24, ctx->r20);
    // 0x802B56D0: or          $s4, $t8, $zero
    ctx->r20 = ctx->r24 | 0;
    // 0x802B56D4: swc1        $f26, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f26.u32l;
    // 0x802B56D8: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x802B56DC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802B56E0: jal         0x8032C360
    // 0x802B56E4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_8;
    // 0x802B56E4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_8:
    // 0x802B56E8: b           L_802B5728
    // 0x802B56EC: addu        $s2, $s3, $s4
    ctx->r18 = ADD32(ctx->r19, ctx->r20);
        goto L_802B5728;
    // 0x802B56EC: addu        $s2, $s3, $s4
    ctx->r18 = ADD32(ctx->r19, ctx->r20);
L_802B56F0:
    // 0x802B56F0: sll         $t1, $s4, 2
    ctx->r9 = S32(ctx->r20 << 2);
    // 0x802B56F4: subu        $t1, $t1, $s4
    ctx->r9 = SUB32(ctx->r9, ctx->r20);
    // 0x802B56F8: slt         $at, $t1, $s3
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x802B56FC: beql        $at, $zero, L_802B5710
    if (ctx->r1 == 0) {
        // 0x802B5700: sll         $t6, $s3, 2
        ctx->r14 = S32(ctx->r19 << 2);
            goto L_802B5710;
    }
    goto skip_45;
    // 0x802B5700: sll         $t6, $s3, 2
    ctx->r14 = S32(ctx->r19 << 2);
    skip_45:
    // 0x802B5704: b           L_802B5724
    // 0x802B5708: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
        goto L_802B5724;
    // 0x802B5708: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x802B570C: sll         $t6, $s3, 2
    ctx->r14 = S32(ctx->r19 << 2);
L_802B5710:
    // 0x802B5710: subu        $t6, $t6, $s3
    ctx->r14 = SUB32(ctx->r14, ctx->r19);
    // 0x802B5714: slt         $at, $t6, $s4
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x802B5718: beql        $at, $zero, L_802B5728
    if (ctx->r1 == 0) {
        // 0x802B571C: addu        $s2, $s3, $s4
        ctx->r18 = ADD32(ctx->r19, ctx->r20);
            goto L_802B5728;
    }
    goto skip_46;
    // 0x802B571C: addu        $s2, $s3, $s4
    ctx->r18 = ADD32(ctx->r19, ctx->r20);
    skip_46:
    // 0x802B5720: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
L_802B5724:
    // 0x802B5724: addu        $s2, $s3, $s4
    ctx->r18 = ADD32(ctx->r19, ctx->r20);
L_802B5728:
    // 0x802B5728: bne         $s2, $zero, L_802B5748
    if (ctx->r18 != 0) {
        // 0x802B572C: lui         $a0, 0x803C
        ctx->r4 = S32(0X803C << 16);
            goto L_802B5748;
    }
    // 0x802B572C: lui         $a0, 0x803C
    ctx->r4 = S32(0X803C << 16);
    // 0x802B5730: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x802B5734: addiu       $a1, $a1, -0x40DC
    ctx->r5 = ADD32(ctx->r5, -0X40DC);
    // 0x802B5738: addiu       $a0, $a0, -0x4100
    ctx->r4 = ADD32(ctx->r4, -0X4100);
    // 0x802B573C: jal         0x8013966C
    // 0x802B5740: addiu       $a2, $zero, 0x146
    ctx->r6 = ADD32(0, 0X146);
    osSyncPrintf(rdram, ctx);
        goto after_9;
    // 0x802B5740: addiu       $a2, $zero, 0x146
    ctx->r6 = ADD32(0, 0X146);
    after_9:
    // 0x802B5744: sw          $zero, 0x0($zero)
    MEM_W(0X0, 0) = 0;
L_802B5748:
    // 0x802B5748: lw          $v1, 0x1C($s1)
    ctx->r3 = MEM_W(ctx->r17, 0X1C);
    // 0x802B574C: lw          $a0, 0x1C($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X1C);
    // 0x802B5750: multu       $s3, $v1
    result = U64(U32(ctx->r19)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B5754: mflo        $t2
    ctx->r10 = lo;
    // 0x802B5758: nop

    // 0x802B575C: nop

    // 0x802B5760: multu       $s4, $a0
    result = U64(U32(ctx->r20)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B5764: mflo        $t7
    ctx->r15 = lo;
    // 0x802B5768: addu        $t3, $t2, $t7
    ctx->r11 = ADD32(ctx->r10, ctx->r15);
    // 0x802B576C: nop

    // 0x802B5770: div         $zero, $t3, $s2
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r18)));
    // 0x802B5774: mflo        $v0
    ctx->r2 = lo;
    // 0x802B5778: sw          $v0, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r2;
    // 0x802B577C: lw          $v1, 0x20($s1)
    ctx->r3 = MEM_W(ctx->r17, 0X20);
    // 0x802B5780: sw          $v0, 0x1C($s1)
    MEM_W(0X1C, ctx->r17) = ctx->r2;
    // 0x802B5784: lw          $a0, 0x20($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X20);
    // 0x802B5788: multu       $s3, $v1
    result = U64(U32(ctx->r19)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B578C: bne         $s2, $zero, L_802B5798
    if (ctx->r18 != 0) {
        // 0x802B5790: nop
    
            goto L_802B5798;
    }
    // 0x802B5790: nop

    // 0x802B5794: break       7
    do_break(2150324116);
L_802B5798:
    // 0x802B5798: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B579C: bne         $s2, $at, L_802B57B0
    if (ctx->r18 != ctx->r1) {
        // 0x802B57A0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B57B0;
    }
    // 0x802B57A0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B57A4: bne         $t3, $at, L_802B57B0
    if (ctx->r11 != ctx->r1) {
        // 0x802B57A8: nop
    
            goto L_802B57B0;
    }
    // 0x802B57A8: nop

    // 0x802B57AC: break       6
    do_break(2150324140);
L_802B57B0:
    // 0x802B57B0: mflo        $t5
    ctx->r13 = lo;
    // 0x802B57B4: nop

    // 0x802B57B8: nop

    // 0x802B57BC: multu       $s4, $a0
    result = U64(U32(ctx->r20)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B57C0: mflo        $t4
    ctx->r12 = lo;
    // 0x802B57C4: addu        $t8, $t5, $t4
    ctx->r24 = ADD32(ctx->r13, ctx->r12);
    // 0x802B57C8: nop

    // 0x802B57CC: div         $zero, $t8, $s2
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r18)));
    // 0x802B57D0: mflo        $v0
    ctx->r2 = lo;
    // 0x802B57D4: sw          $v0, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r2;
    // 0x802B57D8: bne         $s2, $zero, L_802B57E4
    if (ctx->r18 != 0) {
        // 0x802B57DC: nop
    
            goto L_802B57E4;
    }
    // 0x802B57DC: nop

    // 0x802B57E0: break       7
    do_break(2150324192);
L_802B57E4:
    // 0x802B57E4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B57E8: bne         $s2, $at, L_802B57FC
    if (ctx->r18 != ctx->r1) {
        // 0x802B57EC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B57FC;
    }
    // 0x802B57EC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B57F0: bne         $t8, $at, L_802B57FC
    if (ctx->r24 != ctx->r1) {
        // 0x802B57F4: nop
    
            goto L_802B57FC;
    }
    // 0x802B57F4: nop

    // 0x802B57F8: break       6
    do_break(2150324216);
L_802B57FC:
    // 0x802B57FC: sw          $v0, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r2;
    // 0x802B5800: bnel        $s5, $zero, L_802B5A80
    if (ctx->r21 != 0) {
        // 0x802B5804: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_47;
    // 0x802B5804: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_47:
    // 0x802B5808: lw          $t0, 0x4C($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X4C);
    // 0x802B580C: lw          $v1, 0x24($s1)
    ctx->r3 = MEM_W(ctx->r17, 0X24);
    // 0x802B5810: lw          $a0, 0x24($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X24);
    // 0x802B5814: sll         $t9, $t0, 27
    ctx->r25 = S32(ctx->r8 << 27);
    // 0x802B5818: srl         $t1, $t9, 31
    ctx->r9 = S32(U32(ctx->r25) >> 31);
    // 0x802B581C: beql        $t1, $zero, L_802B5890
    if (ctx->r9 == 0) {
        // 0x802B5820: lw          $t9, 0x4C($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X4C);
            goto L_802B5890;
    }
    goto skip_48;
    // 0x802B5820: lw          $t9, 0x4C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4C);
    skip_48:
    // 0x802B5824: lw          $t6, 0x16C($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X16C);
    // 0x802B5828: lw          $t2, 0x80($t6)
    ctx->r10 = MEM_W(ctx->r14, 0X80);
    // 0x802B582C: sll         $t7, $t2, 17
    ctx->r15 = S32(ctx->r10 << 17);
    // 0x802B5830: srl         $t3, $t7, 31
    ctx->r11 = S32(U32(ctx->r15) >> 31);
    // 0x802B5834: bnel        $t3, $zero, L_802B5890
    if (ctx->r11 != 0) {
        // 0x802B5838: lw          $t9, 0x4C($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X4C);
            goto L_802B5890;
    }
    goto skip_49;
    // 0x802B5838: lw          $t9, 0x4C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4C);
    skip_49:
    // 0x802B583C: multu       $s3, $v1
    result = U64(U32(ctx->r19)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B5840: mflo        $t5
    ctx->r13 = lo;
    // 0x802B5844: nop

    // 0x802B5848: nop

    // 0x802B584C: multu       $s4, $a0
    result = U64(U32(ctx->r20)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B5850: mflo        $t4
    ctx->r12 = lo;
    // 0x802B5854: addu        $t8, $t5, $t4
    ctx->r24 = ADD32(ctx->r13, ctx->r12);
    // 0x802B5858: nop

    // 0x802B585C: div         $zero, $t8, $s2
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r18)));
    // 0x802B5860: mflo        $t0
    ctx->r8 = lo;
    // 0x802B5864: sw          $t0, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r8;
    // 0x802B5868: bne         $s2, $zero, L_802B5874
    if (ctx->r18 != 0) {
        // 0x802B586C: nop
    
            goto L_802B5874;
    }
    // 0x802B586C: nop

    // 0x802B5870: break       7
    do_break(2150324336);
L_802B5874:
    // 0x802B5874: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B5878: bne         $s2, $at, L_802B588C
    if (ctx->r18 != ctx->r1) {
        // 0x802B587C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B588C;
    }
    // 0x802B587C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B5880: bne         $t8, $at, L_802B588C
    if (ctx->r24 != ctx->r1) {
        // 0x802B5884: nop
    
            goto L_802B588C;
    }
    // 0x802B5884: nop

    // 0x802B5888: break       6
    do_break(2150324360);
L_802B588C:
    // 0x802B588C: lw          $t9, 0x4C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4C);
L_802B5890:
    // 0x802B5890: sll         $t1, $t9, 27
    ctx->r9 = S32(ctx->r25 << 27);
    // 0x802B5894: srl         $t6, $t1, 31
    ctx->r14 = S32(U32(ctx->r9) >> 31);
    // 0x802B5898: beql        $t6, $zero, L_802B5A80
    if (ctx->r14 == 0) {
        // 0x802B589C: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_50;
    // 0x802B589C: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_50:
    // 0x802B58A0: lw          $t2, 0x16C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X16C);
    // 0x802B58A4: lw          $t7, 0x80($t2)
    ctx->r15 = MEM_W(ctx->r10, 0X80);
    // 0x802B58A8: sll         $t3, $t7, 17
    ctx->r11 = S32(ctx->r15 << 17);
    // 0x802B58AC: srl         $t5, $t3, 31
    ctx->r13 = S32(U32(ctx->r11) >> 31);
    // 0x802B58B0: bnel        $t5, $zero, L_802B5A80
    if (ctx->r13 != 0) {
        // 0x802B58B4: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_51;
    // 0x802B58B4: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_51:
    // 0x802B58B8: multu       $s3, $v1
    result = U64(U32(ctx->r19)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B58BC: mflo        $t4
    ctx->r12 = lo;
    // 0x802B58C0: nop

    // 0x802B58C4: nop

    // 0x802B58C8: multu       $s4, $a0
    result = U64(U32(ctx->r20)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B58CC: mflo        $t8
    ctx->r24 = lo;
    // 0x802B58D0: addu        $t0, $t4, $t8
    ctx->r8 = ADD32(ctx->r12, ctx->r24);
    // 0x802B58D4: nop

    // 0x802B58D8: div         $zero, $t0, $s2
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r18)));
    // 0x802B58DC: mflo        $t9
    ctx->r25 = lo;
    // 0x802B58E0: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
    // 0x802B58E4: bne         $s2, $zero, L_802B58F0
    if (ctx->r18 != 0) {
        // 0x802B58E8: nop
    
            goto L_802B58F0;
    }
    // 0x802B58E8: nop

    // 0x802B58EC: break       7
    do_break(2150324460);
L_802B58F0:
    // 0x802B58F0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B58F4: bne         $s2, $at, L_802B5908
    if (ctx->r18 != ctx->r1) {
        // 0x802B58F8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B5908;
    }
    // 0x802B58F8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B58FC: bne         $t0, $at, L_802B5908
    if (ctx->r8 != ctx->r1) {
        // 0x802B5900: nop
    
            goto L_802B5908;
    }
    // 0x802B5900: nop

    // 0x802B5904: break       6
    do_break(2150324484);
L_802B5908:
    // 0x802B5908: b           L_802B5A80
    // 0x802B590C: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
        goto L_802B5A80;
    // 0x802B590C: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
L_802B5910:
    // 0x802B5910: beq         $s5, $zero, L_802B5928
    if (ctx->r21 == 0) {
        // 0x802B5914: cvt.d.s     $f0, $f2
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f0.d = CVT_D_S(ctx->f2.fl);
            goto L_802B5928;
    }
    // 0x802B5914: cvt.d.s     $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f0.d = CVT_D_S(ctx->f2.fl);
    // 0x802B5918: swc1        $f24, 0xF4($sp)
    MEM_W(0XF4, ctx->r29) = ctx->f24.u32l;
    // 0x802B591C: swc1        $f24, 0xDC($sp)
    MEM_W(0XDC, ctx->r29) = ctx->f24.u32l;
    // 0x802B5920: swc1        $f24, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f24.u32l;
    // 0x802B5924: swc1        $f24, 0xE8($sp)
    MEM_W(0XE8, ctx->r29) = ctx->f24.u32l;
L_802B5928:
    // 0x802B5928: mul.d       $f4, $f0, $f28
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 28);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f28.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f28.d);
    // 0x802B592C: addiu       $t1, $sp, 0xE0
    ctx->r9 = ADD32(ctx->r29, 0XE0);
    // 0x802B5930: addiu       $t6, $sp, 0xD4
    ctx->r14 = ADD32(ctx->r29, 0XD4);
    // 0x802B5934: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802B5938: mul.d       $f6, $f0, $f30
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 30);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f30.d); 
    ctx->f6.d = MUL_D(ctx->f0.d, ctx->f30.d);
    // 0x802B593C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x802B5940: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5944: addiu       $a1, $sp, 0xF8
    ctx->r5 = ADD32(ctx->r29, 0XF8);
    // 0x802B5948: addiu       $a2, $sp, 0xEC
    ctx->r6 = ADD32(ctx->r29, 0XEC);
    // 0x802B594C: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x802B5950: cvt.s.d     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f8.fl = CVT_S_D(ctx->f4.d);
    // 0x802B5954: cvt.s.d     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f10.fl = CVT_S_D(ctx->f6.d);
    // 0x802B5958: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x802B595C: jal         0x80319280
    // 0x802B5960: swc1        $f10, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f10.u32l;
    func_80319280_72A930(rdram, ctx);
        goto after_10;
    // 0x802B5960: swc1        $f10, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f10.u32l;
    after_10:
    // 0x802B5964: lw          $t2, 0x4C($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X4C);
    // 0x802B5968: sll         $t3, $t2, 27
    ctx->r11 = S32(ctx->r10 << 27);
    // 0x802B596C: bgezl       $t3, L_802B59F4
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802B5970: lw          $t8, 0x4C($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X4C);
            goto L_802B59F4;
    }
    goto skip_52;
    // 0x802B5970: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
    skip_52:
    // 0x802B5974: lw          $t5, 0x16C($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X16C);
    // 0x802B5978: lwc1        $f18, 0xEC($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XEC);
    // 0x802B597C: lw          $t4, 0x80($t5)
    ctx->r12 = MEM_W(ctx->r13, 0X80);
    // 0x802B5980: sll         $t0, $t4, 17
    ctx->r8 = S32(ctx->r12 << 17);
    // 0x802B5984: bltzl       $t0, L_802B59F4
    if (SIGNED(ctx->r8) < 0) {
        // 0x802B5988: lw          $t8, 0x4C($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X4C);
            goto L_802B59F4;
    }
    goto skip_53;
    // 0x802B5988: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
    skip_53:
    // 0x802B598C: mul.s       $f16, $f18, $f22
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f16.fl = MUL_S(ctx->f18.fl, ctx->f22.fl);
    // 0x802B5990: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5994: trunc.w.s   $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802B5998: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x802B599C: nop

    // 0x802B59A0: sw          $t1, 0x1C($s1)
    MEM_W(0X1C, ctx->r17) = ctx->r9;
    // 0x802B59A4: lwc1        $f8, 0xF0($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XF0);
    // 0x802B59A8: mul.s       $f6, $f8, $f22
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f22.fl);
    // 0x802B59AC: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802B59B0: mfc1        $t2, $f10
    ctx->r10 = (int32_t)ctx->f10.u32l;
    // 0x802B59B4: bne         $s5, $zero, L_802B59D4
    if (ctx->r21 != 0) {
        // 0x802B59B8: sw          $t2, 0x20($s1)
        MEM_W(0X20, ctx->r17) = ctx->r10;
            goto L_802B59D4;
    }
    // 0x802B59B8: sw          $t2, 0x20($s1)
    MEM_W(0X20, ctx->r17) = ctx->r10;
    // 0x802B59BC: lwc1        $f18, 0xF4($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XF4);
    // 0x802B59C0: mul.s       $f16, $f18, $f22
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f16.fl = MUL_S(ctx->f18.fl, ctx->f22.fl);
    // 0x802B59C4: trunc.w.s   $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802B59C8: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    // 0x802B59CC: nop

    // 0x802B59D0: sw          $t3, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r11;
L_802B59D4:
    // 0x802B59D4: lw          $t5, 0x16C($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X16C);
    // 0x802B59D8: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802B59DC: lbu         $t4, 0x2($t5)
    ctx->r12 = MEM_BU(ctx->r13, 0X2);
    // 0x802B59E0: bnel        $t4, $at, L_802B59F4
    if (ctx->r12 != ctx->r1) {
        // 0x802B59E4: lw          $t8, 0x4C($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X4C);
            goto L_802B59F4;
    }
    goto skip_54;
    // 0x802B59E4: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
    skip_54:
    // 0x802B59E8: jal         0x802B8304
    // 0x802B59EC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    func_802B8304_6C99B4(rdram, ctx);
        goto after_11;
    // 0x802B59EC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_11:
    // 0x802B59F0: lw          $t8, 0x4C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4C);
L_802B59F4:
    // 0x802B59F4: sll         $t9, $t8, 27
    ctx->r25 = S32(ctx->r24 << 27);
    // 0x802B59F8: bgezl       $t9, L_802B5A80
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802B59FC: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_55;
    // 0x802B59FC: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_55:
    // 0x802B5A00: lw          $t1, 0x16C($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5A04: lwc1        $f8, 0xD4($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XD4);
    // 0x802B5A08: lw          $t6, 0x80($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X80);
    // 0x802B5A0C: sll         $t7, $t6, 17
    ctx->r15 = S32(ctx->r14 << 17);
    // 0x802B5A10: bltzl       $t7, L_802B5A80
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B5A14: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_56;
    // 0x802B5A14: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_56:
    // 0x802B5A18: mul.s       $f6, $f8, $f22
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f22.fl);
    // 0x802B5A1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B5A20: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802B5A24: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x802B5A28: nop

    // 0x802B5A2C: sw          $t5, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r13;
    // 0x802B5A30: lwc1        $f18, 0xD8($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XD8);
    // 0x802B5A34: mul.s       $f16, $f18, $f22
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f16.fl = MUL_S(ctx->f18.fl, ctx->f22.fl);
    // 0x802B5A38: trunc.w.s   $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802B5A3C: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
    // 0x802B5A40: bne         $s5, $zero, L_802B5A60
    if (ctx->r21 != 0) {
        // 0x802B5A44: sw          $t8, 0x20($s0)
        MEM_W(0X20, ctx->r16) = ctx->r24;
            goto L_802B5A60;
    }
    // 0x802B5A44: sw          $t8, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r24;
    // 0x802B5A48: lwc1        $f8, 0xDC($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0XDC);
    // 0x802B5A4C: mul.s       $f6, $f8, $f22
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 22);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f22.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f22.fl);
    // 0x802B5A50: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802B5A54: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x802B5A58: nop

    // 0x802B5A5C: sw          $t9, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r25;
L_802B5A60:
    // 0x802B5A60: lw          $t1, 0x16C($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5A64: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x802B5A68: lbu         $t6, 0x2($t1)
    ctx->r14 = MEM_BU(ctx->r9, 0X2);
    // 0x802B5A6C: bnel        $t6, $at, L_802B5A80
    if (ctx->r14 != ctx->r1) {
        // 0x802B5A70: lw          $a1, 0x16C($s1)
        ctx->r5 = MEM_W(ctx->r17, 0X16C);
            goto L_802B5A80;
    }
    goto skip_57;
    // 0x802B5A70: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
    skip_57:
    // 0x802B5A74: jal         0x802B8304
    // 0x802B5A78: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    func_802B8304_6C99B4(rdram, ctx);
        goto after_12;
    // 0x802B5A78: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_12:
    // 0x802B5A7C: lw          $a1, 0x16C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X16C);
L_802B5A80:
    // 0x802B5A80: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5A84: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B5A88: lw          $t2, 0x80($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X80);
    // 0x802B5A8C: lw          $a0, 0x80($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X80);
    // 0x802B5A90: sll         $t3, $t2, 18
    ctx->r11 = S32(ctx->r10 << 18);
    // 0x802B5A94: bgezl       $t3, L_802B5B24
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802B5A98: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_58;
    // 0x802B5A98: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_58:
    // 0x802B5A9C: lw          $t4, 0x0($s6)
    ctx->r12 = MEM_W(ctx->r22, 0X0);
    // 0x802B5AA0: addiu       $t5, $s1, 0xC4
    ctx->r13 = ADD32(ctx->r17, 0XC4);
    // 0x802B5AA4: sll         $t0, $a0, 17
    ctx->r8 = S32(ctx->r4 << 17);
    // 0x802B5AA8: bnel        $t5, $t4, L_802B5B24
    if (ctx->r13 != ctx->r12) {
        // 0x802B5AAC: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_59;
    // 0x802B5AAC: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_59:
    // 0x802B5AB0: bltzl       $t0, L_802B5AD8
    if (SIGNED(ctx->r8) < 0) {
        // 0x802B5AB4: lhu         $v0, 0x9C($a1)
        ctx->r2 = MEM_HU(ctx->r5, 0X9C);
            goto L_802B5AD8;
    }
    goto skip_60;
    // 0x802B5AB4: lhu         $v0, 0x9C($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X9C);
    skip_60:
    // 0x802B5AB8: lw          $t9, 0x18($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X18);
    // 0x802B5ABC: beql        $t9, $zero, L_802B5B24
    if (ctx->r25 == 0) {
        // 0x802B5AC0: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_61;
    // 0x802B5AC0: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_61:
    // 0x802B5AC4: lhu         $t1, 0x40($s0)
    ctx->r9 = MEM_HU(ctx->r16, 0X40);
    // 0x802B5AC8: slti        $at, $t1, 0x1001
    ctx->r1 = SIGNED(ctx->r9) < 0X1001 ? 1 : 0;
    // 0x802B5ACC: bnel        $at, $zero, L_802B5B24
    if (ctx->r1 != 0) {
        // 0x802B5AD0: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_62;
    // 0x802B5AD0: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_62:
    // 0x802B5AD4: lhu         $v0, 0x9C($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X9C);
L_802B5AD8:
    // 0x802B5AD8: addiu       $at, $zero, 0x39
    ctx->r1 = ADD32(0, 0X39);
    // 0x802B5ADC: beq         $v0, $at, L_802B5AFC
    if (ctx->r2 == ctx->r1) {
        // 0x802B5AE0: addiu       $at, $zero, 0x3A
        ctx->r1 = ADD32(0, 0X3A);
            goto L_802B5AFC;
    }
    // 0x802B5AE0: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x802B5AE4: beq         $v0, $at, L_802B5AFC
    if (ctx->r2 == ctx->r1) {
        // 0x802B5AE8: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B5AFC;
    }
    // 0x802B5AE8: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B5AEC: beq         $v0, $at, L_802B5AFC
    if (ctx->r2 == ctx->r1) {
        // 0x802B5AF0: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B5AFC;
    }
    // 0x802B5AF0: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B5AF4: bnel        $v0, $at, L_802B5B24
    if (ctx->r2 != ctx->r1) {
        // 0x802B5AF8: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_63;
    // 0x802B5AF8: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_63:
L_802B5AFC:
    // 0x802B5AFC: lhu         $t6, 0x3C0($s1)
    ctx->r14 = MEM_HU(ctx->r17, 0X3C0);
    // 0x802B5B00: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x802B5B04: addiu       $t2, $zero, 0x10
    ctx->r10 = ADD32(0, 0X10);
    // 0x802B5B08: beql        $t6, $at, L_802B5B24
    if (ctx->r14 == ctx->r1) {
        // 0x802B5B0C: sll         $t3, $a0, 18
        ctx->r11 = S32(ctx->r4 << 18);
            goto L_802B5B24;
    }
    goto skip_64;
    // 0x802B5B0C: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
    skip_64:
    // 0x802B5B10: sh          $t2, 0x3C0($s1)
    MEM_H(0X3C0, ctx->r17) = ctx->r10;
    // 0x802B5B14: sh          $zero, 0x3C2($s1)
    MEM_H(0X3C2, ctx->r17) = 0;
    // 0x802B5B18: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    // 0x802B5B1C: lw          $a0, 0x80($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X80);
    // 0x802B5B20: sll         $t3, $a0, 18
    ctx->r11 = S32(ctx->r4 << 18);
L_802B5B24:
    // 0x802B5B24: bgez        $t3, L_802B5B94
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802B5B28: or          $a1, $s0, $zero
        ctx->r5 = ctx->r16 | 0;
            goto L_802B5B94;
    }
    // 0x802B5B28: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B5B2C: lw          $t4, 0x0($s7)
    ctx->r12 = MEM_W(ctx->r23, 0X0);
    // 0x802B5B30: addiu       $t5, $s0, 0xC4
    ctx->r13 = ADD32(ctx->r16, 0XC4);
    // 0x802B5B34: bne         $t5, $t4, L_802B5B94
    if (ctx->r13 != ctx->r12) {
        // 0x802B5B38: nop
    
            goto L_802B5B94;
    }
    // 0x802B5B38: nop

    // 0x802B5B3C: lw          $t8, 0x16C($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X16C);
    // 0x802B5B40: lw          $t0, 0x80($t8)
    ctx->r8 = MEM_W(ctx->r24, 0X80);
    // 0x802B5B44: sll         $t1, $t0, 17
    ctx->r9 = S32(ctx->r8 << 17);
    // 0x802B5B48: bgez        $t1, L_802B5B94
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802B5B4C: nop
    
            goto L_802B5B94;
    }
    // 0x802B5B4C: nop

    // 0x802B5B50: lhu         $v0, 0x9C($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X9C);
    // 0x802B5B54: addiu       $at, $zero, 0x39
    ctx->r1 = ADD32(0, 0X39);
    // 0x802B5B58: beq         $v0, $at, L_802B5B78
    if (ctx->r2 == ctx->r1) {
        // 0x802B5B5C: addiu       $at, $zero, 0x3A
        ctx->r1 = ADD32(0, 0X3A);
            goto L_802B5B78;
    }
    // 0x802B5B5C: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x802B5B60: beq         $v0, $at, L_802B5B78
    if (ctx->r2 == ctx->r1) {
        // 0x802B5B64: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B5B78;
    }
    // 0x802B5B64: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B5B68: beq         $v0, $at, L_802B5B78
    if (ctx->r2 == ctx->r1) {
        // 0x802B5B6C: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B5B78;
    }
    // 0x802B5B6C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B5B70: bne         $v0, $at, L_802B5B94
    if (ctx->r2 != ctx->r1) {
        // 0x802B5B74: nop
    
            goto L_802B5B94;
    }
    // 0x802B5B74: nop

L_802B5B78:
    // 0x802B5B78: lhu         $t6, 0x3C0($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X3C0);
    // 0x802B5B7C: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x802B5B80: addiu       $t2, $zero, 0x10
    ctx->r10 = ADD32(0, 0X10);
    // 0x802B5B84: beq         $t6, $at, L_802B5B94
    if (ctx->r14 == ctx->r1) {
        // 0x802B5B88: nop
    
            goto L_802B5B94;
    }
    // 0x802B5B88: nop

    // 0x802B5B8C: sh          $t2, 0x3C0($s0)
    MEM_H(0X3C0, ctx->r16) = ctx->r10;
    // 0x802B5B90: sh          $zero, 0x3C2($s0)
    MEM_H(0X3C2, ctx->r16) = 0;
L_802B5B94:
    // 0x802B5B94: lhu         $t3, 0x5544($t7)
    ctx->r11 = MEM_HU(ctx->r15, 0X5544);
    // 0x802B5B98: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B5B9C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B5BA0: sh          $t3, 0x48($s0)
    MEM_H(0X48, ctx->r16) = ctx->r11;
    // 0x802B5BA4: sh          $t3, 0x48($s1)
    MEM_H(0X48, ctx->r17) = ctx->r11;
    // 0x802B5BA8: lh          $t5, 0x5534($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5534);
    // 0x802B5BAC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5BB0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B5BB4: sll         $t4, $t5, 3
    ctx->r12 = S32(ctx->r13 << 3);
    // 0x802B5BB8: addu        $v0, $v0, $t4
    ctx->r2 = ADD32(ctx->r2, ctx->r12);
    // 0x802B5BBC: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x802B5BC0: bne         $s1, $v0, L_802B5C14
    if (ctx->r17 != ctx->r2) {
        // 0x802B5BC4: nop
    
            goto L_802B5C14;
    }
    // 0x802B5BC4: nop

    // 0x802B5BC8: lhu         $v1, 0x5544($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X5544);
    // 0x802B5BCC: lhu         $t8, 0x60E2($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X60E2);
    // 0x802B5BD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B5BD4: subu        $t0, $v1, $t8
    ctx->r8 = SUB32(ctx->r3, ctx->r24);
    // 0x802B5BD8: slti        $at, $t0, 0x5
    ctx->r1 = SIGNED(ctx->r8) < 0X5 ? 1 : 0;
    // 0x802B5BDC: bnel        $at, $zero, L_802B5C6C
    if (ctx->r1 != 0) {
        // 0x802B5BE0: lh          $t7, 0x10C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X10C);
            goto L_802B5C6C;
    }
    goto skip_65;
    // 0x802B5BE0: lh          $t7, 0x10C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X10C);
    skip_65:
    // 0x802B5BE4: lh          $v0, 0x5546($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5546);
    // 0x802B5BE8: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x802B5BEC: slti        $at, $v0, 0x2
    ctx->r1 = SIGNED(ctx->r2) < 0X2 ? 1 : 0;
    // 0x802B5BF0: beq         $at, $zero, L_802B5C00
    if (ctx->r1 == 0) {
        // 0x802B5BF4: lui         $at, 0x803D
        ctx->r1 = S32(0X803D << 16);
            goto L_802B5C00;
    }
    // 0x802B5BF4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B5BF8: b           L_802B5C08
    // 0x802B5BFC: sh          $t9, 0x5546($at)
    MEM_H(0X5546, ctx->r1) = ctx->r25;
        goto L_802B5C08;
    // 0x802B5BFC: sh          $t9, 0x5546($at)
    MEM_H(0X5546, ctx->r1) = ctx->r25;
L_802B5C00:
    // 0x802B5C00: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B5C04: sh          $v0, 0x5546($at)
    MEM_H(0X5546, ctx->r1) = ctx->r2;
L_802B5C08:
    // 0x802B5C08: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B5C0C: b           L_802B5C68
    // 0x802B5C10: sh          $v1, 0x60E2($at)
    MEM_H(0X60E2, ctx->r1) = ctx->r3;
        goto L_802B5C68;
    // 0x802B5C10: sh          $v1, 0x60E2($at)
    MEM_H(0X60E2, ctx->r1) = ctx->r3;
L_802B5C14:
    // 0x802B5C14: bne         $s0, $v0, L_802B5C68
    if (ctx->r16 != ctx->r2) {
        // 0x802B5C18: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B5C68;
    }
    // 0x802B5C18: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5C1C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x802B5C20: lhu         $t1, 0x60E2($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X60E2);
    // 0x802B5C24: lhu         $v1, 0x5544($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X5544);
    // 0x802B5C28: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x802B5C2C: addiu       $a0, $a0, 0x5546
    ctx->r4 = ADD32(ctx->r4, 0X5546);
    // 0x802B5C30: subu        $t6, $v1, $t1
    ctx->r14 = SUB32(ctx->r3, ctx->r9);
    // 0x802B5C34: slti        $at, $t6, 0x5
    ctx->r1 = SIGNED(ctx->r14) < 0X5 ? 1 : 0;
    // 0x802B5C38: bnel        $at, $zero, L_802B5C6C
    if (ctx->r1 != 0) {
        // 0x802B5C3C: lh          $t7, 0x10C($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X10C);
            goto L_802B5C6C;
    }
    goto skip_66;
    // 0x802B5C3C: lh          $t7, 0x10C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X10C);
    skip_66:
    // 0x802B5C40: lh          $v0, 0x0($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X0);
    // 0x802B5C44: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x802B5C48: slti        $at, $v0, 0x2
    ctx->r1 = SIGNED(ctx->r2) < 0X2 ? 1 : 0;
    // 0x802B5C4C: beql        $at, $zero, L_802B5C60
    if (ctx->r1 == 0) {
        // 0x802B5C50: sh          $v0, 0x0($a0)
        MEM_H(0X0, ctx->r4) = ctx->r2;
            goto L_802B5C60;
    }
    goto skip_67;
    // 0x802B5C50: sh          $v0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r2;
    skip_67:
    // 0x802B5C54: b           L_802B5C60
    // 0x802B5C58: sh          $t2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r10;
        goto L_802B5C60;
    // 0x802B5C58: sh          $t2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r10;
    // 0x802B5C5C: sh          $v0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r2;
L_802B5C60:
    // 0x802B5C60: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B5C64: sh          $v1, 0x60E2($at)
    MEM_H(0X60E2, ctx->r1) = ctx->r3;
L_802B5C68:
    // 0x802B5C68: lh          $t7, 0x10C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X10C);
L_802B5C6C:
    // 0x802B5C6C: lh          $t3, 0x118($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X118);
    // 0x802B5C70: lh          $t5, 0x110($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X110);
    // 0x802B5C74: lh          $t4, 0x108($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X108);
    // 0x802B5C78: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5C7C: lh          $a2, 0x11C($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X11C);
    // 0x802B5C80: lh          $a3, 0x114($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X114);
    // 0x802B5C84: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802B5C88: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x802B5C8C: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802B5C90: jal         0x802CAB20
    // 0x802B5C94: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    func_802CAB20_6DC1D0(rdram, ctx);
        goto after_13;
    // 0x802B5C94: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    after_13:
    // 0x802B5C98: lw          $t8, 0x4($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X4);
    // 0x802B5C9C: lw          $t0, 0x1C($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X1C);
    // 0x802B5CA0: lw          $t1, 0x8($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X8);
    // 0x802B5CA4: lw          $t6, 0x20($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X20);
    // 0x802B5CA8: lw          $t7, 0xC($s1)
    ctx->r15 = MEM_W(ctx->r17, 0XC);
    // 0x802B5CAC: lw          $t3, 0x24($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X24);
    // 0x802B5CB0: addu        $t9, $t8, $t0
    ctx->r25 = ADD32(ctx->r24, ctx->r8);
    // 0x802B5CB4: addu        $t2, $t1, $t6
    ctx->r10 = ADD32(ctx->r9, ctx->r14);
    // 0x802B5CB8: addu        $t5, $t7, $t3
    ctx->r13 = ADD32(ctx->r15, ctx->r11);
    // 0x802B5CBC: sw          $t9, 0x10($s1)
    MEM_W(0X10, ctx->r17) = ctx->r25;
    // 0x802B5CC0: sw          $t2, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r10;
    // 0x802B5CC4: sw          $t5, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r13;
    // 0x802B5CC8: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x802B5CCC: lw          $t4, 0x4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4);
    // 0x802B5CD0: lw          $t1, 0x20($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X20);
    // 0x802B5CD4: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x802B5CD8: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x802B5CDC: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802B5CE0: addu        $t0, $t4, $t8
    ctx->r8 = ADD32(ctx->r12, ctx->r24);
    // 0x802B5CE4: addu        $t6, $t9, $t1
    ctx->r14 = ADD32(ctx->r25, ctx->r9);
    // 0x802B5CE8: addu        $t3, $t2, $t7
    ctx->r11 = ADD32(ctx->r10, ctx->r15);
    // 0x802B5CEC: sw          $t0, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r8;
    // 0x802B5CF0: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x802B5CF4: sw          $t3, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r11;
    // 0x802B5CF8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5CFC: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
    // 0x802B5D00: beq         $v1, $zero, L_802B5D60
    if (ctx->r3 == 0) {
        // 0x802B5D04: nop
    
            goto L_802B5D60;
    }
    // 0x802B5D04: nop

    // 0x802B5D08: lw          $at, 0x4($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X4);
    // 0x802B5D0C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B5D10: lw          $t9, 0x60D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X60D0);
    // 0x802B5D14: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B5D18: lw          $at, 0x8($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X8);
    // 0x802B5D1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B5D20: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B5D24: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B5D28: lw          $at, 0xC($s0)
    ctx->r1 = MEM_W(ctx->r16, 0XC);
    // 0x802B5D2C: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x802B5D30: or          $a3, $s7, $zero
    ctx->r7 = ctx->r23 | 0;
    // 0x802B5D34: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B5D38: lw          $at, 0x4($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X4);
    // 0x802B5D3C: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B5D40: lw          $at, 0x8($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X8);
    // 0x802B5D44: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B5D48: lw          $at, 0xC($s1)
    ctx->r1 = MEM_W(ctx->r17, 0XC);
    // 0x802B5D4C: jalr        $t9
    // 0x802B5D50: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_14;
    // 0x802B5D50: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_14:
    // 0x802B5D54: bne         $v0, $zero, L_802B5DB8
    if (ctx->r2 != 0) {
        // 0x802B5D58: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B5DB8;
    }
    // 0x802B5D58: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B5D5C: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
L_802B5D60:
    // 0x802B5D60: bnel        $v1, $zero, L_802B5DC8
    if (ctx->r3 != 0) {
        // 0x802B5D64: lw          $t1, 0x12C($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X12C);
            goto L_802B5DC8;
    }
    goto skip_68;
    // 0x802B5D64: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
    skip_68:
    // 0x802B5D68: lw          $at, 0x4($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X4);
    // 0x802B5D6C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B5D70: lw          $t9, 0x60D0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X60D0);
    // 0x802B5D74: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B5D78: lw          $at, 0x8($s1)
    ctx->r1 = MEM_W(ctx->r17, 0X8);
    // 0x802B5D7C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5D80: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B5D84: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B5D88: lw          $at, 0xC($s1)
    ctx->r1 = MEM_W(ctx->r17, 0XC);
    // 0x802B5D8C: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x802B5D90: or          $a3, $s7, $zero
    ctx->r7 = ctx->r23 | 0;
    // 0x802B5D94: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B5D98: lw          $at, 0x4($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X4);
    // 0x802B5D9C: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B5DA0: lw          $at, 0x8($s0)
    ctx->r1 = MEM_W(ctx->r16, 0X8);
    // 0x802B5DA4: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B5DA8: lw          $at, 0xC($s0)
    ctx->r1 = MEM_W(ctx->r16, 0XC);
    // 0x802B5DAC: jalr        $t9
    // 0x802B5DB0: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_15;
    // 0x802B5DB0: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_15:
    // 0x802B5DB4: beq         $v0, $zero, L_802B5DC4
    if (ctx->r2 == 0) {
        // 0x802B5DB8: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B5DC4;
    }
L_802B5DB8:
    // 0x802B5DB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B5DBC: jal         0x802B7BC8
    // 0x802B5DC0: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    func_802B7BC8_6C9278(rdram, ctx);
        goto after_16;
    // 0x802B5DC0: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_16:
L_802B5DC4:
    // 0x802B5DC4: lw          $t1, 0x12C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X12C);
L_802B5DC8:
    // 0x802B5DC8: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x802B5DCC: bne         $t6, $zero, L_802B4DE0
    if (ctx->r14 != 0) {
        // 0x802B5DD0: sw          $t6, 0x12C($sp)
        MEM_W(0X12C, ctx->r29) = ctx->r14;
            goto L_802B4DE0;
    }
    // 0x802B5DD0: sw          $t6, 0x12C($sp)
    MEM_W(0X12C, ctx->r29) = ctx->r14;
    // 0x802B5DD4: lw          $t2, 0x130($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X130);
    // 0x802B5DD8: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
L_802B5DDC:
    // 0x802B5DDC: bne         $v0, $zero, L_802B4DD0
    if (ctx->r2 != 0) {
        // 0x802B5DE0: sw          $v0, 0x130($sp)
        MEM_W(0X130, ctx->r29) = ctx->r2;
            goto L_802B4DD0;
    }
    // 0x802B5DE0: sw          $v0, 0x130($sp)
    MEM_W(0X130, ctx->r29) = ctx->r2;
L_802B5DE4:
    // 0x802B5DE4: lh          $t3, 0x136($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X136);
    // 0x802B5DE8: addiu       $t5, $t3, 0x1
    ctx->r13 = ADD32(ctx->r11, 0X1);
    // 0x802B5DEC: sll         $t4, $t5, 16
    ctx->r12 = S32(ctx->r13 << 16);
    // 0x802B5DF0: sra         $t8, $t4, 16
    ctx->r24 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802B5DF4: slti        $at, $t8, 0x28
    ctx->r1 = SIGNED(ctx->r24) < 0X28 ? 1 : 0;
    // 0x802B5DF8: bne         $at, $zero, L_802B4DAC
    if (ctx->r1 != 0) {
        // 0x802B5DFC: sh          $t5, 0x136($sp)
        MEM_H(0X136, ctx->r29) = ctx->r13;
            goto L_802B4DAC;
    }
    // 0x802B5DFC: sh          $t5, 0x136($sp)
    MEM_H(0X136, ctx->r29) = ctx->r13;
    // 0x802B5E00: lw          $ra, 0x84($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X84);
    // 0x802B5E04: ldc1        $f20, 0x30($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X30);
    // 0x802B5E08: ldc1        $f22, 0x38($sp)
    CHECK_FR(ctx, 22);
    ctx->f22.u64 = LD(ctx->r29, 0X38);
    // 0x802B5E0C: ldc1        $f24, 0x40($sp)
    CHECK_FR(ctx, 24);
    ctx->f24.u64 = LD(ctx->r29, 0X40);
    // 0x802B5E10: ldc1        $f26, 0x48($sp)
    CHECK_FR(ctx, 26);
    ctx->f26.u64 = LD(ctx->r29, 0X48);
    // 0x802B5E14: ldc1        $f28, 0x50($sp)
    CHECK_FR(ctx, 28);
    ctx->f28.u64 = LD(ctx->r29, 0X50);
    // 0x802B5E18: ldc1        $f30, 0x58($sp)
    CHECK_FR(ctx, 30);
    ctx->f30.u64 = LD(ctx->r29, 0X58);
    // 0x802B5E1C: lw          $s0, 0x60($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X60);
    // 0x802B5E20: lw          $s1, 0x64($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X64);
    // 0x802B5E24: lw          $s2, 0x68($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X68);
    // 0x802B5E28: lw          $s3, 0x6C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X6C);
    // 0x802B5E2C: lw          $s4, 0x70($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X70);
    // 0x802B5E30: lw          $s5, 0x74($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X74);
    // 0x802B5E34: lw          $s6, 0x78($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X78);
    // 0x802B5E38: lw          $s7, 0x7C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X7C);
    // 0x802B5E3C: lw          $fp, 0x80($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X80);
    // 0x802B5E40: jr          $ra
    // 0x802B5E44: addiu       $sp, $sp, 0x138
    ctx->r29 = ADD32(ctx->r29, 0X138);
    return;
    // 0x802B5E44: addiu       $sp, $sp, 0x138
    ctx->r29 = ADD32(ctx->r29, 0X138);
;}
RECOMP_FUNC void func_802B5E48_6C74F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B5E48: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
    // 0x802B5E4C: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
    // 0x802B5E50: addiu       $t0, $zero, 0x4
    ctx->r8 = ADD32(0, 0X4);
    // 0x802B5E54: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x802B5E58: lbu         $t6, 0x15($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X15);
    // 0x802B5E5C: bnel        $t0, $t6, L_802B5EF8
    if (ctx->r8 != ctx->r14) {
        // 0x802B5E60: lw          $t7, 0x18($v0)
        ctx->r15 = MEM_W(ctx->r2, 0X18);
            goto L_802B5EF8;
    }
    goto skip_0;
    // 0x802B5E60: lw          $t7, 0x18($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X18);
    skip_0:
    // 0x802B5E64: lw          $v0, 0x16C($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X16C);
    // 0x802B5E68: lui         $t8, 0x802B
    ctx->r24 = S32(0X802B << 16);
    // 0x802B5E6C: addiu       $t8, $t8, 0x750C
    ctx->r24 = ADD32(ctx->r24, 0X750C);
    // 0x802B5E70: lbu         $t7, 0x15($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X15);
    // 0x802B5E74: bnel        $t0, $t7, L_802B5E90
    if (ctx->r8 != ctx->r15) {
        // 0x802B5E78: lw          $t9, 0x18($v0)
        ctx->r25 = MEM_W(ctx->r2, 0X18);
            goto L_802B5E90;
    }
    goto skip_1;
    // 0x802B5E78: lw          $t9, 0x18($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X18);
    skip_1:
    // 0x802B5E7C: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x802B5E80: addiu       $v1, $zero, 0x6
    ctx->r3 = ADD32(0, 0X6);
    // 0x802B5E84: b           L_802B606C
    // 0x802B5E88: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5E88: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
    // 0x802B5E8C: lw          $t9, 0x18($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X18);
L_802B5E90:
    // 0x802B5E90: beql        $t9, $zero, L_802B5ED4
    if (ctx->r25 == 0) {
        // 0x802B5E94: lw          $t4, 0xD0($a1)
        ctx->r12 = MEM_W(ctx->r5, 0XD0);
            goto L_802B5ED4;
    }
    goto skip_2;
    // 0x802B5E94: lw          $t4, 0xD0($a1)
    ctx->r12 = MEM_W(ctx->r5, 0XD0);
    skip_2:
    // 0x802B5E98: lw          $t1, 0xD0($a1)
    ctx->r9 = MEM_W(ctx->r5, 0XD0);
    // 0x802B5E9C: lui         $t3, 0x802B
    ctx->r11 = S32(0X802B << 16);
    // 0x802B5EA0: addiu       $v1, $zero, 0x7
    ctx->r3 = ADD32(0, 0X7);
    // 0x802B5EA4: beq         $t1, $zero, L_802B5EC4
    if (ctx->r9 == 0) {
        // 0x802B5EA8: addiu       $t3, $t3, 0x6F6C
        ctx->r11 = ADD32(ctx->r11, 0X6F6C);
            goto L_802B5EC4;
    }
    // 0x802B5EA8: addiu       $t3, $t3, 0x6F6C
    ctx->r11 = ADD32(ctx->r11, 0X6F6C);
    // 0x802B5EAC: lui         $t2, 0x802B
    ctx->r10 = S32(0X802B << 16);
    // 0x802B5EB0: addiu       $t2, $t2, 0x6F6C
    ctx->r10 = ADD32(ctx->r10, 0X6F6C);
    // 0x802B5EB4: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x802B5EB8: addiu       $v1, $zero, 0x7
    ctx->r3 = ADD32(0, 0X7);
    // 0x802B5EBC: b           L_802B606C
    // 0x802B5EC0: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5EC0: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
L_802B5EC4:
    // 0x802B5EC4: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x802B5EC8: b           L_802B606C
    // 0x802B5ECC: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5ECC: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
    // 0x802B5ED0: lw          $t4, 0xD0($a1)
    ctx->r12 = MEM_W(ctx->r5, 0XD0);
L_802B5ED4:
    // 0x802B5ED4: lui         $t5, 0x802B
    ctx->r13 = S32(0X802B << 16);
    // 0x802B5ED8: addiu       $t5, $t5, 0x6B5C
    ctx->r13 = ADD32(ctx->r13, 0X6B5C);
    // 0x802B5EDC: beq         $t4, $zero, L_802B606C
    if (ctx->r12 == 0) {
        // 0x802B5EE0: addiu       $t6, $zero, 0x1
        ctx->r14 = ADD32(0, 0X1);
            goto L_802B606C;
    }
    // 0x802B5EE0: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B5EE4: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x802B5EE8: addiu       $v1, $zero, 0x5
    ctx->r3 = ADD32(0, 0X5);
    // 0x802B5EEC: b           L_802B606C
    // 0x802B5EF0: sb          $t6, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r14;
        goto L_802B606C;
    // 0x802B5EF0: sb          $t6, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r14;
    // 0x802B5EF4: lw          $t7, 0x18($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X18);
L_802B5EF8:
    // 0x802B5EF8: beql        $t7, $zero, L_802B5FF8
    if (ctx->r15 == 0) {
        // 0x802B5EFC: lw          $t5, 0xD0($a0)
        ctx->r13 = MEM_W(ctx->r4, 0XD0);
            goto L_802B5FF8;
    }
    goto skip_3;
    // 0x802B5EFC: lw          $t5, 0xD0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0XD0);
    skip_3:
    // 0x802B5F00: lw          $v0, 0x16C($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X16C);
    // 0x802B5F04: lbu         $t8, 0x15($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X15);
    // 0x802B5F08: bnel        $t0, $t8, L_802B5F54
    if (ctx->r8 != ctx->r24) {
        // 0x802B5F0C: lw          $t5, 0x18($v0)
        ctx->r13 = MEM_W(ctx->r2, 0X18);
            goto L_802B5F54;
    }
    goto skip_4;
    // 0x802B5F0C: lw          $t5, 0x18($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X18);
    skip_4:
    // 0x802B5F10: lw          $t9, 0xD0($a1)
    ctx->r25 = MEM_W(ctx->r5, 0XD0);
    // 0x802B5F14: lui         $t3, 0x802B
    ctx->r11 = S32(0X802B << 16);
    // 0x802B5F18: addiu       $v1, $zero, 0x8
    ctx->r3 = ADD32(0, 0X8);
    // 0x802B5F1C: beq         $t9, $zero, L_802B5F40
    if (ctx->r25 == 0) {
        // 0x802B5F20: addiu       $t3, $t3, 0x6F6C
        ctx->r11 = ADD32(ctx->r11, 0X6F6C);
            goto L_802B5F40;
    }
    // 0x802B5F20: addiu       $t3, $t3, 0x6F6C
    ctx->r11 = ADD32(ctx->r11, 0X6F6C);
    // 0x802B5F24: lui         $t1, 0x802B
    ctx->r9 = S32(0X802B << 16);
    // 0x802B5F28: addiu       $t1, $t1, 0x6F6C
    ctx->r9 = ADD32(ctx->r9, 0X6F6C);
    // 0x802B5F2C: sw          $t1, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r9;
    // 0x802B5F30: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802B5F34: addiu       $v1, $zero, 0x7
    ctx->r3 = ADD32(0, 0X7);
    // 0x802B5F38: b           L_802B606C
    // 0x802B5F3C: sb          $t2, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r10;
        goto L_802B606C;
    // 0x802B5F3C: sb          $t2, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r10;
L_802B5F40:
    // 0x802B5F40: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x802B5F44: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B5F48: b           L_802B606C
    // 0x802B5F4C: sb          $t4, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r12;
        goto L_802B606C;
    // 0x802B5F4C: sb          $t4, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r12;
    // 0x802B5F50: lw          $t5, 0x18($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X18);
L_802B5F54:
    // 0x802B5F54: beql        $t5, $zero, L_802B5FD4
    if (ctx->r13 == 0) {
        // 0x802B5F58: lw          $t2, 0xD0($a1)
        ctx->r10 = MEM_W(ctx->r5, 0XD0);
            goto L_802B5FD4;
    }
    goto skip_5;
    // 0x802B5F58: lw          $t2, 0xD0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0XD0);
    skip_5:
    // 0x802B5F5C: lw          $v0, 0xD0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0XD0);
    // 0x802B5F60: beq         $v0, $zero, L_802B5F9C
    if (ctx->r2 == 0) {
        // 0x802B5F64: nop
    
            goto L_802B5F9C;
    }
    // 0x802B5F64: nop

    // 0x802B5F68: lw          $t6, 0xD0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0XD0);
    // 0x802B5F6C: lui         $t7, 0x802B
    ctx->r15 = S32(0X802B << 16);
    // 0x802B5F70: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802B5F74: beq         $t6, $zero, L_802B5F9C
    if (ctx->r14 == 0) {
        // 0x802B5F78: addiu       $t7, $t7, 0x6088
        ctx->r15 = ADD32(ctx->r15, 0X6088);
            goto L_802B5F9C;
    }
    // 0x802B5F78: addiu       $t7, $t7, 0x6088
    ctx->r15 = ADD32(ctx->r15, 0X6088);
    // 0x802B5F7C: sltu        $at, $a0, $a1
    ctx->r1 = ctx->r4 < ctx->r5 ? 1 : 0;
    // 0x802B5F80: beq         $at, $zero, L_802B5F90
    if (ctx->r1 == 0) {
        // 0x802B5F84: sw          $t7, 0x0($a2)
        MEM_W(0X0, ctx->r6) = ctx->r15;
            goto L_802B5F90;
    }
    // 0x802B5F84: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x802B5F88: b           L_802B606C
    // 0x802B5F8C: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5F8C: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
L_802B5F90:
    // 0x802B5F90: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802B5F94: b           L_802B606C
    // 0x802B5F98: sb          $t8, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r24;
        goto L_802B606C;
    // 0x802B5F98: sb          $t8, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r24;
L_802B5F9C:
    // 0x802B5F9C: beq         $v0, $zero, L_802B5FBC
    if (ctx->r2 == 0) {
        // 0x802B5FA0: addiu       $v1, $zero, 0x9
        ctx->r3 = ADD32(0, 0X9);
            goto L_802B5FBC;
    }
    // 0x802B5FA0: addiu       $v1, $zero, 0x9
    ctx->r3 = ADD32(0, 0X9);
    // 0x802B5FA4: lui         $t9, 0x802B
    ctx->r25 = S32(0X802B << 16);
    // 0x802B5FA8: addiu       $t9, $t9, 0x6088
    ctx->r25 = ADD32(ctx->r25, 0X6088);
    // 0x802B5FAC: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x802B5FB0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802B5FB4: b           L_802B606C
    // 0x802B5FB8: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5FB8: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
L_802B5FBC:
    // 0x802B5FBC: lui         $t1, 0x802B
    ctx->r9 = S32(0X802B << 16);
    // 0x802B5FC0: addiu       $t1, $t1, 0x75B4
    ctx->r9 = ADD32(ctx->r9, 0X75B4);
    // 0x802B5FC4: sw          $t1, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r9;
    // 0x802B5FC8: b           L_802B606C
    // 0x802B5FCC: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B5FCC: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
    // 0x802B5FD0: lw          $t2, 0xD0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0XD0);
L_802B5FD4:
    // 0x802B5FD4: lui         $t3, 0x802B
    ctx->r11 = S32(0X802B << 16);
    // 0x802B5FD8: addiu       $t3, $t3, 0x6088
    ctx->r11 = ADD32(ctx->r11, 0X6088);
    // 0x802B5FDC: beq         $t2, $zero, L_802B606C
    if (ctx->r10 == 0) {
        // 0x802B5FE0: addiu       $t4, $zero, 0x1
        ctx->r12 = ADD32(0, 0X1);
            goto L_802B606C;
    }
    // 0x802B5FE0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B5FE4: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x802B5FE8: addiu       $v1, $zero, 0x2
    ctx->r3 = ADD32(0, 0X2);
    // 0x802B5FEC: b           L_802B606C
    // 0x802B5FF0: sb          $t4, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r12;
        goto L_802B606C;
    // 0x802B5FF0: sb          $t4, 0x0($a3)
    MEM_B(0X0, ctx->r7) = ctx->r12;
    // 0x802B5FF4: lw          $t5, 0xD0($a0)
    ctx->r13 = MEM_W(ctx->r4, 0XD0);
L_802B5FF8:
    // 0x802B5FF8: beq         $t5, $zero, L_802B606C
    if (ctx->r13 == 0) {
        // 0x802B5FFC: nop
    
            goto L_802B606C;
    }
    // 0x802B5FFC: nop

    // 0x802B6000: lw          $v0, 0x16C($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X16C);
    // 0x802B6004: lui         $t7, 0x802B
    ctx->r15 = S32(0X802B << 16);
    // 0x802B6008: addiu       $t7, $t7, 0x6B5C
    ctx->r15 = ADD32(ctx->r15, 0X6B5C);
    // 0x802B600C: lbu         $t6, 0x15($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X15);
    // 0x802B6010: bnel        $t0, $t6, L_802B602C
    if (ctx->r8 != ctx->r14) {
        // 0x802B6014: lw          $t8, 0x18($v0)
        ctx->r24 = MEM_W(ctx->r2, 0X18);
            goto L_802B602C;
    }
    goto skip_6;
    // 0x802B6014: lw          $t8, 0x18($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X18);
    skip_6:
    // 0x802B6018: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x802B601C: addiu       $v1, $zero, 0x4
    ctx->r3 = ADD32(0, 0X4);
    // 0x802B6020: b           L_802B606C
    // 0x802B6024: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B6024: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
    // 0x802B6028: lw          $t8, 0x18($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X18);
L_802B602C:
    // 0x802B602C: lui         $t9, 0x802B
    ctx->r25 = S32(0X802B << 16);
    // 0x802B6030: addiu       $t9, $t9, 0x6088
    ctx->r25 = ADD32(ctx->r25, 0X6088);
    // 0x802B6034: beql        $t8, $zero, L_802B6050
    if (ctx->r24 == 0) {
        // 0x802B6038: lw          $t1, 0xD0($a1)
        ctx->r9 = MEM_W(ctx->r5, 0XD0);
            goto L_802B6050;
    }
    goto skip_7;
    // 0x802B6038: lw          $t1, 0xD0($a1)
    ctx->r9 = MEM_W(ctx->r5, 0XD0);
    skip_7:
    // 0x802B603C: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x802B6040: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x802B6044: b           L_802B606C
    // 0x802B6048: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
        goto L_802B606C;
    // 0x802B6048: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
    // 0x802B604C: lw          $t1, 0xD0($a1)
    ctx->r9 = MEM_W(ctx->r5, 0XD0);
L_802B6050:
    // 0x802B6050: lui         $t2, 0x802B
    ctx->r10 = S32(0X802B << 16);
    // 0x802B6054: addiu       $t2, $t2, 0x6948
    ctx->r10 = ADD32(ctx->r10, 0X6948);
    // 0x802B6058: beq         $t1, $zero, L_802B606C
    if (ctx->r9 == 0) {
        // 0x802B605C: nop
    
            goto L_802B606C;
    }
    // 0x802B605C: nop

    // 0x802B6060: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x802B6064: addiu       $v1, $zero, 0x3
    ctx->r3 = ADD32(0, 0X3);
    // 0x802B6068: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
L_802B606C:
    // 0x802B606C: bne         $v1, $zero, L_802B6080
    if (ctx->r3 != 0) {
        // 0x802B6070: lui         $t3, 0x802B
        ctx->r11 = S32(0X802B << 16);
            goto L_802B6080;
    }
    // 0x802B6070: lui         $t3, 0x802B
    ctx->r11 = S32(0X802B << 16);
    // 0x802B6074: addiu       $t3, $t3, 0x6948
    ctx->r11 = ADD32(ctx->r11, 0X6948);
    // 0x802B6078: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x802B607C: sb          $zero, 0x0($a3)
    MEM_B(0X0, ctx->r7) = 0;
L_802B6080:
    // 0x802B6080: jr          $ra
    // 0x802B6084: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x802B6084: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_802B6088_6C7738(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B6088: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x802B608C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802B6090: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x802B6094: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x802B6098: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B609C: sw          $a3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r7;
    // 0x802B60A0: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x802B60A4: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
    // 0x802B60A8: lw          $t7, 0x16C($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X16C);
    // 0x802B60AC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B60B0: or          $s0, $a2, $zero
    ctx->r16 = ctx->r6 | 0;
    // 0x802B60B4: lw          $t2, 0x18($t7)
    ctx->r10 = MEM_W(ctx->r15, 0X18);
    // 0x802B60B8: sw          $zero, 0x60E8($at)
    MEM_W(0X60E8, ctx->r1) = 0;
    // 0x802B60BC: sw          $zero, 0x60EC($at)
    MEM_W(0X60EC, ctx->r1) = 0;
    // 0x802B60C0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B60C4: sw          $zero, 0x60F0($at)
    MEM_W(0X60F0, ctx->r1) = 0;
    // 0x802B60C8: lw          $t8, 0xD0($a0)
    ctx->r24 = MEM_W(ctx->r4, 0XD0);
    // 0x802B60CC: or          $s1, $a1, $zero
    ctx->r17 = ctx->r5 | 0;
    // 0x802B60D0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x802B60D4: beq         $t8, $zero, L_802B681C
    if (ctx->r24 == 0) {
        // 0x802B60D8: or          $t4, $zero, $zero
        ctx->r12 = 0 | 0;
            goto L_802B681C;
    }
    // 0x802B60D8: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x802B60DC: sll         $s2, $zero, 4
    ctx->r18 = S32(0 << 4);
    // 0x802B60E0: addu        $t0, $a0, $s2
    ctx->r8 = ADD32(ctx->r4, ctx->r18);
    // 0x802B60E4: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B60E8: addiu       $ra, $zero, 0x20
    ctx->r31 = ADD32(0, 0X20);
    // 0x802B60EC: lhu         $a0, 0x40($s1)
    ctx->r4 = MEM_HU(ctx->r17, 0X40);
L_802B60F0:
    // 0x802B60F0: lw          $t7, 0xCC($t0)
    ctx->r15 = MEM_W(ctx->r8, 0XCC);
    // 0x802B60F4: lw          $t8, 0x68($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X68);
    // 0x802B60F8: sll         $t9, $a0, 6
    ctx->r25 = S32(ctx->r4 << 6);
    // 0x802B60FC: sra         $a0, $t9, 11
    ctx->r4 = S32(SIGNED(ctx->r25) >> 11);
    // 0x802B6100: lw          $t6, 0x74($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X74);
    // 0x802B6104: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x802B6108: lhu         $t8, 0x42($s1)
    ctx->r24 = MEM_HU(ctx->r17, 0X42);
    // 0x802B610C: subu        $t7, $t9, $t6
    ctx->r15 = SUB32(ctx->r25, ctx->r14);
    // 0x802B6110: lw          $t6, 0xC4($t0)
    ctx->r14 = MEM_W(ctx->r8, 0XC4);
    // 0x802B6114: sll         $t9, $t8, 15
    ctx->r25 = S32(ctx->r24 << 15);
    // 0x802B6118: lw          $t8, 0x60($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X60);
    // 0x802B611C: subu        $t5, $t7, $t9
    ctx->r13 = SUB32(ctx->r15, ctx->r25);
    // 0x802B6120: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    // 0x802B6124: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x802B6128: lh          $a3, 0x28($s1)
    ctx->r7 = MEM_H(ctx->r17, 0X28);
    // 0x802B612C: subu        $t6, $t7, $t9
    ctx->r14 = SUB32(ctx->r15, ctx->r25);
    // 0x802B6130: sra         $t8, $t6, 11
    ctx->r24 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802B6134: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x802B6138: bne         $a0, $zero, L_802B6144
    if (ctx->r4 != 0) {
        // 0x802B613C: nop
    
            goto L_802B6144;
    }
    // 0x802B613C: nop

    // 0x802B6140: break       7
    do_break(2150326592);
L_802B6144:
    // 0x802B6144: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B6148: bne         $a0, $at, L_802B615C
    if (ctx->r4 != ctx->r1) {
        // 0x802B614C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B615C;
    }
    // 0x802B614C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B6150: bne         $t8, $at, L_802B615C
    if (ctx->r24 != ctx->r1) {
        // 0x802B6154: nop
    
            goto L_802B615C;
    }
    // 0x802B6154: nop

    // 0x802B6158: break       6
    do_break(2150326616);
L_802B615C:
    // 0x802B615C: mflo        $a2
    ctx->r6 = lo;
    // 0x802B6160: lw          $t8, 0x64($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X64);
    // 0x802B6164: lw          $t6, 0xC8($t0)
    ctx->r14 = MEM_W(ctx->r8, 0XC8);
    // 0x802B6168: addiu       $a2, $a2, 0x10
    ctx->r6 = ADD32(ctx->r6, 0X10);
    // 0x802B616C: lw          $t9, 0x70($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X70);
    // 0x802B6170: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x802B6174: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B6178: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x802B617C: subu        $t6, $t7, $t9
    ctx->r14 = SUB32(ctx->r15, ctx->r25);
    // 0x802B6180: sra         $t8, $t6, 11
    ctx->r24 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802B6184: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x802B6188: sll         $t6, $v0, 5
    ctx->r14 = S32(ctx->r2 << 5);
    // 0x802B618C: mflo        $a1
    ctx->r5 = lo;
    // 0x802B6190: addiu       $a1, $a1, 0x10
    ctx->r5 = ADD32(ctx->r5, 0X10);
    // 0x802B6194: bne         $a0, $zero, L_802B61A0
    if (ctx->r4 != 0) {
        // 0x802B6198: nop
    
            goto L_802B61A0;
    }
    // 0x802B6198: nop

    // 0x802B619C: break       7
    do_break(2150326684);
L_802B61A0:
    // 0x802B61A0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B61A4: bne         $a0, $at, L_802B61B8
    if (ctx->r4 != ctx->r1) {
        // 0x802B61A8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B61B8;
    }
    // 0x802B61A8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B61AC: bne         $t8, $at, L_802B61B8
    if (ctx->r24 != ctx->r1) {
        // 0x802B61B0: nop
    
            goto L_802B61B8;
    }
    // 0x802B61B0: nop

    // 0x802B61B4: break       6
    do_break(2150326708);
L_802B61B8:
    // 0x802B61B8: div         $zero, $t6, $a0
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r4)));
    // 0x802B61BC: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x802B61C0: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B61C4: mflo        $v1
    ctx->r3 = lo;
    // 0x802B61C8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x802B61CC: bne         $a0, $zero, L_802B61D8
    if (ctx->r4 != 0) {
        // 0x802B61D0: nop
    
            goto L_802B61D8;
    }
    // 0x802B61D0: nop

    // 0x802B61D4: break       7
    do_break(2150326740);
L_802B61D8:
    // 0x802B61D8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B61DC: bne         $a0, $at, L_802B61F0
    if (ctx->r4 != ctx->r1) {
        // 0x802B61E0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B61F0;
    }
    // 0x802B61E0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B61E4: bne         $t6, $at, L_802B61F0
    if (ctx->r14 != ctx->r1) {
        // 0x802B61E8: nop
    
            goto L_802B61F0;
    }
    // 0x802B61E8: nop

    // 0x802B61EC: break       6
    do_break(2150326764);
L_802B61F0:
    // 0x802B61F0: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x802B61F4: bgtz        $v1, L_802B6204
    if (SIGNED(ctx->r3) > 0) {
        // 0x802B61F8: addiu       $s2, $s2, 0x10
        ctx->r18 = ADD32(ctx->r18, 0X10);
            goto L_802B6204;
    }
    // 0x802B61F8: addiu       $s2, $s2, 0x10
    ctx->r18 = ADD32(ctx->r18, 0X10);
    // 0x802B61FC: b           L_802B620C
    // 0x802B6200: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
        goto L_802B620C;
    // 0x802B6200: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
L_802B6204:
    // 0x802B6204: sra         $t8, $t1, 16
    ctx->r24 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802B6208: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
L_802B620C:
    // 0x802B620C: sll         $v0, $t1, 2
    ctx->r2 = S32(ctx->r9 << 2);
    // 0x802B6210: subu        $v0, $v0, $t1
    ctx->r2 = SUB32(ctx->r2, ctx->r9);
    // 0x802B6214: sra         $t7, $v0, 2
    ctx->r15 = S32(SIGNED(ctx->r2) >> 2);
    // 0x802B6218: bgtz        $t7, L_802B6228
    if (SIGNED(ctx->r15) > 0) {
        // 0x802B621C: or          $v0, $t7, $zero
        ctx->r2 = ctx->r15 | 0;
            goto L_802B6228;
    }
    // 0x802B621C: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x802B6220: b           L_802B6234
    // 0x802B6224: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
        goto L_802B6234;
    // 0x802B6224: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
L_802B6228:
    // 0x802B6228: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x802B622C: sra         $t9, $t3, 16
    ctx->r25 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802B6230: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
L_802B6234:
    // 0x802B6234: bne         $a3, $zero, L_802B62F0
    if (ctx->r7 != 0) {
        // 0x802B6238: nop
    
            goto L_802B62F0;
    }
    // 0x802B6238: nop

    // 0x802B623C: lh          $t6, 0x2A($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X2A);
    // 0x802B6240: bne         $t6, $zero, L_802B62F0
    if (ctx->r14 != 0) {
        // 0x802B6244: nop
    
            goto L_802B62F0;
    }
    // 0x802B6244: nop

    // 0x802B6248: lh          $v0, 0x2C($s1)
    ctx->r2 = MEM_H(ctx->r17, 0X2C);
    // 0x802B624C: addiu       $at, $zero, 0x5A
    ctx->r1 = ADD32(0, 0X5A);
    // 0x802B6250: beql        $v0, $at, L_802B627C
    if (ctx->r2 == ctx->r1) {
        // 0x802B6254: sll         $v0, $a2, 16
        ctx->r2 = S32(ctx->r6 << 16);
            goto L_802B627C;
    }
    goto skip_0;
    // 0x802B6254: sll         $v0, $a2, 16
    ctx->r2 = S32(ctx->r6 << 16);
    skip_0:
    // 0x802B6258: addiu       $at, $zero, 0xB4
    ctx->r1 = ADD32(0, 0XB4);
    // 0x802B625C: beql        $v0, $at, L_802B62A8
    if (ctx->r2 == ctx->r1) {
        // 0x802B6260: subu        $a2, $ra, $a2
        ctx->r6 = SUB32(ctx->r31, ctx->r6);
            goto L_802B62A8;
    }
    goto skip_1;
    // 0x802B6260: subu        $a2, $ra, $a2
    ctx->r6 = SUB32(ctx->r31, ctx->r6);
    skip_1:
    // 0x802B6264: addiu       $at, $zero, 0x10E
    ctx->r1 = ADD32(0, 0X10E);
    // 0x802B6268: beql        $v0, $at, L_802B62CC
    if (ctx->r2 == ctx->r1) {
        // 0x802B626C: sll         $v0, $a2, 16
        ctx->r2 = S32(ctx->r6 << 16);
            goto L_802B62CC;
    }
    goto skip_2;
    // 0x802B626C: sll         $v0, $a2, 16
    ctx->r2 = S32(ctx->r6 << 16);
    skip_2:
    // 0x802B6270: b           L_802B62F0
    // 0x802B6274: nop

        goto L_802B62F0;
    // 0x802B6274: nop

    // 0x802B6278: sll         $v0, $a2, 16
    ctx->r2 = S32(ctx->r6 << 16);
L_802B627C:
    // 0x802B627C: subu        $a2, $ra, $a1
    ctx->r6 = SUB32(ctx->r31, ctx->r5);
    // 0x802B6280: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B6284: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x802B6288: sll         $a1, $t8, 16
    ctx->r5 = S32(ctx->r24 << 16);
    // 0x802B628C: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B6290: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B6294: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x802B6298: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802B629C: b           L_802B62F0
    // 0x802B62A0: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
        goto L_802B62F0;
    // 0x802B62A0: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802B62A4: subu        $a2, $ra, $a2
    ctx->r6 = SUB32(ctx->r31, ctx->r6);
L_802B62A8:
    // 0x802B62A8: subu        $a1, $ra, $a1
    ctx->r5 = SUB32(ctx->r31, ctx->r5);
    // 0x802B62AC: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802B62B0: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x802B62B4: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B62B8: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B62BC: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x802B62C0: b           L_802B62F0
    // 0x802B62C4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
        goto L_802B62F0;
    // 0x802B62C4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802B62C8: sll         $v0, $a2, 16
    ctx->r2 = S32(ctx->r6 << 16);
L_802B62CC:
    // 0x802B62CC: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802B62D0: sll         $a2, $a1, 16
    ctx->r6 = S32(ctx->r5 << 16);
    // 0x802B62D4: subu        $a1, $ra, $t8
    ctx->r5 = SUB32(ctx->r31, ctx->r24);
    // 0x802B62D8: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x802B62DC: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802B62E0: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B62E4: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x802B62E8: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x802B62EC: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
L_802B62F0:
    // 0x802B62F0: bltzl       $a2, L_802B6424
    if (SIGNED(ctx->r6) < 0) {
        // 0x802B62F4: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B6424;
    }
    goto skip_3;
    // 0x802B62F4: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_3:
    // 0x802B62F8: slti        $at, $a2, 0x20
    ctx->r1 = SIGNED(ctx->r6) < 0X20 ? 1 : 0;
    // 0x802B62FC: beql        $at, $zero, L_802B6424
    if (ctx->r1 == 0) {
        // 0x802B6300: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B6424;
    }
    goto skip_4;
    // 0x802B6300: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_4:
    // 0x802B6304: bltzl       $a1, L_802B6424
    if (SIGNED(ctx->r5) < 0) {
        // 0x802B6308: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B6424;
    }
    goto skip_5;
    // 0x802B6308: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_5:
    // 0x802B630C: slti        $at, $a1, 0x20
    ctx->r1 = SIGNED(ctx->r5) < 0X20 ? 1 : 0;
    // 0x802B6310: beql        $at, $zero, L_802B6424
    if (ctx->r1 == 0) {
        // 0x802B6314: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B6424;
    }
    goto skip_6;
    // 0x802B6314: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_6:
    // 0x802B6318: sra         $t8, $t5, 11
    ctx->r24 = S32(SIGNED(ctx->r13) >> 11);
    // 0x802B631C: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x802B6320: mflo        $a3
    ctx->r7 = lo;
    // 0x802B6324: addiu       $a3, $a3, 0x10
    ctx->r7 = ADD32(ctx->r7, 0X10);
    // 0x802B6328: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x802B632C: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B6330: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802B6334: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x802B6338: bne         $a0, $zero, L_802B6344
    if (ctx->r4 != 0) {
        // 0x802B633C: nop
    
            goto L_802B6344;
    }
    // 0x802B633C: nop

    // 0x802B6340: break       7
    do_break(2150327104);
L_802B6344:
    // 0x802B6344: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B6348: bne         $a0, $at, L_802B635C
    if (ctx->r4 != ctx->r1) {
        // 0x802B634C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B635C;
    }
    // 0x802B634C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B6350: bne         $t8, $at, L_802B635C
    if (ctx->r24 != ctx->r1) {
        // 0x802B6354: nop
    
            goto L_802B635C;
    }
    // 0x802B6354: nop

    // 0x802B6358: break       6
    do_break(2150327128);
L_802B635C:
    // 0x802B635C: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B6360: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x802B6364: bltz        $t8, L_802B63B8
    if (SIGNED(ctx->r24) < 0) {
        // 0x802B6368: or          $a3, $t9, $zero
        ctx->r7 = ctx->r25 | 0;
            goto L_802B63B8;
    }
    // 0x802B6368: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x802B636C: slti        $at, $v0, 0x20
    ctx->r1 = SIGNED(ctx->r2) < 0X20 ? 1 : 0;
    // 0x802B6370: beq         $at, $zero, L_802B63B8
    if (ctx->r1 == 0) {
        // 0x802B6374: sll         $t7, $a2, 2
        ctx->r15 = S32(ctx->r6 << 2);
            goto L_802B63B8;
    }
    // 0x802B6374: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x802B6378: addu        $t9, $t2, $t7
    ctx->r25 = ADD32(ctx->r10, ctx->r15);
    // 0x802B637C: sll         $t8, $a1, 7
    ctx->r24 = S32(ctx->r5 << 7);
    // 0x802B6380: addu        $t7, $t9, $t8
    ctx->r15 = ADD32(ctx->r25, ctx->r24);
    // 0x802B6384: lw          $t6, 0x8($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X8);
    // 0x802B6388: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802B638C: sllv        $t8, $t9, $v0
    ctx->r24 = S32(ctx->r25 << (ctx->r2 & 31));
    // 0x802B6390: and         $t7, $t6, $t8
    ctx->r15 = ctx->r14 & ctx->r24;
    // 0x802B6394: beq         $t7, $zero, L_802B63B8
    if (ctx->r15 == 0) {
        // 0x802B6398: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_802B63B8;
    }
    // 0x802B6398: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B639C: lh          $t9, 0x60F0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60F0);
    // 0x802B63A0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B63A4: addiu       $t8, $t0, 0xC4
    ctx->r24 = ADD32(ctx->r8, 0XC4);
    // 0x802B63A8: addiu       $t6, $t9, 0x2
    ctx->r14 = ADD32(ctx->r25, 0X2);
    // 0x802B63AC: sh          $t6, 0x60F0($at)
    MEM_H(0X60F0, ctx->r1) = ctx->r14;
    // 0x802B63B0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B63B4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
L_802B63B8:
    // 0x802B63B8: subu        $v0, $a3, $t1
    ctx->r2 = SUB32(ctx->r7, ctx->r9);
    // 0x802B63BC: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802B63C0: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B63C4: bltz        $t9, L_802B6420
    if (SIGNED(ctx->r25) < 0) {
        // 0x802B63C8: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_802B6420;
    }
    // 0x802B63C8: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x802B63CC: slti        $at, $v0, 0x20
    ctx->r1 = SIGNED(ctx->r2) < 0X20 ? 1 : 0;
    // 0x802B63D0: beq         $at, $zero, L_802B6420
    if (ctx->r1 == 0) {
        // 0x802B63D4: sll         $t6, $a2, 2
        ctx->r14 = S32(ctx->r6 << 2);
            goto L_802B6420;
    }
    // 0x802B63D4: sll         $t6, $a2, 2
    ctx->r14 = S32(ctx->r6 << 2);
    // 0x802B63D8: or          $t7, $a1, $zero
    ctx->r15 = ctx->r5 | 0;
    // 0x802B63DC: sll         $t9, $t7, 7
    ctx->r25 = S32(ctx->r15 << 7);
    // 0x802B63E0: addu        $t8, $t2, $t6
    ctx->r24 = ADD32(ctx->r10, ctx->r14);
    // 0x802B63E4: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x802B63E8: lw          $t7, 0x8($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X8);
    // 0x802B63EC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802B63F0: sllv        $t9, $t8, $v0
    ctx->r25 = S32(ctx->r24 << (ctx->r2 & 31));
    // 0x802B63F4: and         $t6, $t7, $t9
    ctx->r14 = ctx->r15 & ctx->r25;
    // 0x802B63F8: beql        $t6, $zero, L_802B6424
    if (ctx->r14 == 0) {
        // 0x802B63FC: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B6424;
    }
    goto skip_7;
    // 0x802B63FC: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_7:
    // 0x802B6400: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B6404: lh          $t8, 0x60F0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60F0);
    // 0x802B6408: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B640C: addiu       $t9, $t0, 0xC4
    ctx->r25 = ADD32(ctx->r8, 0XC4);
    // 0x802B6410: addiu       $t7, $t8, -0x2
    ctx->r15 = ADD32(ctx->r24, -0X2);
    // 0x802B6414: sh          $t7, 0x60F0($at)
    MEM_H(0X60F0, ctx->r1) = ctx->r15;
    // 0x802B6418: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B641C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
L_802B6420:
    // 0x802B6420: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
L_802B6424:
    // 0x802B6424: div         $zero, $t6, $a0
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r4)));
    // 0x802B6428: mflo        $a3
    ctx->r7 = lo;
    // 0x802B642C: addiu       $a3, $a3, 0x10
    ctx->r7 = ADD32(ctx->r7, 0X10);
    // 0x802B6430: bne         $a0, $zero, L_802B643C
    if (ctx->r4 != 0) {
        // 0x802B6434: nop
    
            goto L_802B643C;
    }
    // 0x802B6434: nop

    // 0x802B6438: break       7
    do_break(2150327352);
L_802B643C:
    // 0x802B643C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B6440: bne         $a0, $at, L_802B6454
    if (ctx->r4 != ctx->r1) {
        // 0x802B6444: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B6454;
    }
    // 0x802B6444: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B6448: bne         $t6, $at, L_802B6454
    if (ctx->r14 != ctx->r1) {
        // 0x802B644C: nop
    
            goto L_802B6454;
    }
    // 0x802B644C: nop

    // 0x802B6450: break       6
    do_break(2150327376);
L_802B6454:
    // 0x802B6454: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x802B6458: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B645C: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x802B6460: bltz        $t7, L_802B67FC
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B6464: slti        $at, $t7, 0x20
        ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
            goto L_802B67FC;
    }
    // 0x802B6464: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B6468: beq         $at, $zero, L_802B67FC
    if (ctx->r1 == 0) {
        // 0x802B646C: nop
    
            goto L_802B67FC;
    }
    // 0x802B646C: nop

    // 0x802B6470: bltz        $a2, L_802B653C
    if (SIGNED(ctx->r6) < 0) {
        // 0x802B6474: slti        $at, $a2, 0x20
        ctx->r1 = SIGNED(ctx->r6) < 0X20 ? 1 : 0;
            goto L_802B653C;
    }
    // 0x802B6474: slti        $at, $a2, 0x20
    ctx->r1 = SIGNED(ctx->r6) < 0X20 ? 1 : 0;
    // 0x802B6478: beq         $at, $zero, L_802B653C
    if (ctx->r1 == 0) {
        // 0x802B647C: addu        $v0, $a1, $t1
        ctx->r2 = ADD32(ctx->r5, ctx->r9);
            goto L_802B653C;
    }
    // 0x802B647C: addu        $v0, $a1, $t1
    ctx->r2 = ADD32(ctx->r5, ctx->r9);
    // 0x802B6480: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B6484: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B6488: bltz        $t6, L_802B64E0
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B648C: subu        $v0, $a1, $t1
        ctx->r2 = SUB32(ctx->r5, ctx->r9);
            goto L_802B64E0;
    }
    // 0x802B648C: subu        $v0, $a1, $t1
    ctx->r2 = SUB32(ctx->r5, ctx->r9);
    // 0x802B6490: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B6494: beq         $at, $zero, L_802B64E0
    if (ctx->r1 == 0) {
        // 0x802B6498: sll         $t8, $a2, 2
        ctx->r24 = S32(ctx->r6 << 2);
            goto L_802B64E0;
    }
    // 0x802B6498: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x802B649C: or          $t9, $t6, $zero
    ctx->r25 = ctx->r14 | 0;
    // 0x802B64A0: sll         $t6, $t9, 7
    ctx->r14 = S32(ctx->r25 << 7);
    // 0x802B64A4: addu        $t7, $t2, $t8
    ctx->r15 = ADD32(ctx->r10, ctx->r24);
    // 0x802B64A8: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B64AC: lw          $t9, 0x8($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X8);
    // 0x802B64B0: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B64B4: sllv        $t6, $t7, $a3
    ctx->r14 = S32(ctx->r15 << (ctx->r7 & 31));
    // 0x802B64B8: and         $t8, $t9, $t6
    ctx->r24 = ctx->r25 & ctx->r14;
    // 0x802B64BC: beq         $t8, $zero, L_802B64E0
    if (ctx->r24 == 0) {
        // 0x802B64C0: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802B64E0;
    }
    // 0x802B64C0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B64C4: lh          $t7, 0x60EC($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60EC);
    // 0x802B64C8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B64CC: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B64D0: addiu       $t9, $t7, 0x2
    ctx->r25 = ADD32(ctx->r15, 0X2);
    // 0x802B64D4: sh          $t9, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r25;
    // 0x802B64D8: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B64DC: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
L_802B64E0:
    // 0x802B64E0: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B64E4: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B64E8: bltz        $t7, L_802B653C
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B64EC: slti        $at, $t7, 0x20
        ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
            goto L_802B653C;
    }
    // 0x802B64EC: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B64F0: beq         $at, $zero, L_802B653C
    if (ctx->r1 == 0) {
        // 0x802B64F4: sll         $t9, $a2, 2
        ctx->r25 = S32(ctx->r6 << 2);
            goto L_802B653C;
    }
    // 0x802B64F4: sll         $t9, $a2, 2
    ctx->r25 = S32(ctx->r6 << 2);
    // 0x802B64F8: or          $t8, $t7, $zero
    ctx->r24 = ctx->r15 | 0;
    // 0x802B64FC: sll         $t7, $t8, 7
    ctx->r15 = S32(ctx->r24 << 7);
    // 0x802B6500: addu        $t6, $t2, $t9
    ctx->r14 = ADD32(ctx->r10, ctx->r25);
    // 0x802B6504: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B6508: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B650C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B6510: sllv        $t7, $t6, $a3
    ctx->r15 = S32(ctx->r14 << (ctx->r7 & 31));
    // 0x802B6514: and         $t9, $t8, $t7
    ctx->r25 = ctx->r24 & ctx->r15;
    // 0x802B6518: beq         $t9, $zero, L_802B653C
    if (ctx->r25 == 0) {
        // 0x802B651C: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B653C;
    }
    // 0x802B651C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B6520: lh          $t6, 0x60EC($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60EC);
    // 0x802B6524: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6528: addiu       $t7, $t0, 0xC4
    ctx->r15 = ADD32(ctx->r8, 0XC4);
    // 0x802B652C: addiu       $t8, $t6, -0x2
    ctx->r24 = ADD32(ctx->r14, -0X2);
    // 0x802B6530: sh          $t8, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r24;
    // 0x802B6534: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B6538: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
L_802B653C:
    // 0x802B653C: bltz        $a1, L_802B6600
    if (SIGNED(ctx->r5) < 0) {
        // 0x802B6540: slti        $at, $a1, 0x20
        ctx->r1 = SIGNED(ctx->r5) < 0X20 ? 1 : 0;
            goto L_802B6600;
    }
    // 0x802B6540: slti        $at, $a1, 0x20
    ctx->r1 = SIGNED(ctx->r5) < 0X20 ? 1 : 0;
    // 0x802B6544: beq         $at, $zero, L_802B6600
    if (ctx->r1 == 0) {
        // 0x802B6548: addu        $v0, $a2, $t1
        ctx->r2 = ADD32(ctx->r6, ctx->r9);
            goto L_802B6600;
    }
    // 0x802B6548: addu        $v0, $a2, $t1
    ctx->r2 = ADD32(ctx->r6, ctx->r9);
    // 0x802B654C: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B6550: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B6554: bltz        $t6, L_802B65A8
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B6558: subu        $v0, $a2, $t1
        ctx->r2 = SUB32(ctx->r6, ctx->r9);
            goto L_802B65A8;
    }
    // 0x802B6558: subu        $v0, $a2, $t1
    ctx->r2 = SUB32(ctx->r6, ctx->r9);
    // 0x802B655C: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B6560: beq         $at, $zero, L_802B65A8
    if (ctx->r1 == 0) {
        // 0x802B6564: sll         $t8, $t6, 2
        ctx->r24 = S32(ctx->r14 << 2);
            goto L_802B65A8;
    }
    // 0x802B6564: sll         $t8, $t6, 2
    ctx->r24 = S32(ctx->r14 << 2);
    // 0x802B6568: addu        $t7, $t2, $t8
    ctx->r15 = ADD32(ctx->r10, ctx->r24);
    // 0x802B656C: sll         $t6, $a1, 7
    ctx->r14 = S32(ctx->r5 << 7);
    // 0x802B6570: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B6574: lw          $t9, 0x8($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X8);
    // 0x802B6578: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B657C: sllv        $t6, $t7, $a3
    ctx->r14 = S32(ctx->r15 << (ctx->r7 & 31));
    // 0x802B6580: and         $t8, $t9, $t6
    ctx->r24 = ctx->r25 & ctx->r14;
    // 0x802B6584: beq         $t8, $zero, L_802B65A8
    if (ctx->r24 == 0) {
        // 0x802B6588: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802B65A8;
    }
    // 0x802B6588: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B658C: lh          $t7, 0x60E8($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60E8);
    // 0x802B6590: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6594: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B6598: addiu       $t9, $t7, 0x2
    ctx->r25 = ADD32(ctx->r15, 0X2);
    // 0x802B659C: sh          $t9, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r25;
    // 0x802B65A0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B65A4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
L_802B65A8:
    // 0x802B65A8: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B65AC: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B65B0: bltz        $t7, L_802B6600
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B65B4: slti        $at, $t7, 0x20
        ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
            goto L_802B6600;
    }
    // 0x802B65B4: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B65B8: beq         $at, $zero, L_802B6600
    if (ctx->r1 == 0) {
        // 0x802B65BC: sll         $t9, $t7, 2
        ctx->r25 = S32(ctx->r15 << 2);
            goto L_802B6600;
    }
    // 0x802B65BC: sll         $t9, $t7, 2
    ctx->r25 = S32(ctx->r15 << 2);
    // 0x802B65C0: addu        $t6, $t2, $t9
    ctx->r14 = ADD32(ctx->r10, ctx->r25);
    // 0x802B65C4: sll         $t7, $a1, 7
    ctx->r15 = S32(ctx->r5 << 7);
    // 0x802B65C8: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B65CC: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B65D0: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B65D4: sllv        $t7, $t6, $a3
    ctx->r15 = S32(ctx->r14 << (ctx->r7 & 31));
    // 0x802B65D8: and         $t9, $t8, $t7
    ctx->r25 = ctx->r24 & ctx->r15;
    // 0x802B65DC: beq         $t9, $zero, L_802B6600
    if (ctx->r25 == 0) {
        // 0x802B65E0: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B6600;
    }
    // 0x802B65E0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B65E4: lh          $t6, 0x60E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60E8);
    // 0x802B65E8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B65EC: addiu       $t7, $t0, 0xC4
    ctx->r15 = ADD32(ctx->r8, 0XC4);
    // 0x802B65F0: addiu       $t8, $t6, -0x2
    ctx->r24 = ADD32(ctx->r14, -0X2);
    // 0x802B65F4: sh          $t8, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r24;
    // 0x802B65F8: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B65FC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
L_802B6600:
    // 0x802B6600: bne         $t4, $zero, L_802B67FC
    if (ctx->r12 != 0) {
        // 0x802B6604: addu        $a0, $a2, $t3
        ctx->r4 = ADD32(ctx->r6, ctx->r11);
            goto L_802B67FC;
    }
    // 0x802B6604: addu        $a0, $a2, $t3
    ctx->r4 = ADD32(ctx->r6, ctx->r11);
    // 0x802B6608: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x802B660C: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B6610: bltz        $t6, L_802B6704
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B6614: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_802B6704;
    }
    // 0x802B6614: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x802B6618: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B661C: beq         $at, $zero, L_802B6704
    if (ctx->r1 == 0) {
        // 0x802B6620: addu        $v0, $a1, $t3
        ctx->r2 = ADD32(ctx->r5, ctx->r11);
            goto L_802B6704;
    }
    // 0x802B6620: addu        $v0, $a1, $t3
    ctx->r2 = ADD32(ctx->r5, ctx->r11);
    // 0x802B6624: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B6628: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B662C: bltz        $t7, L_802B6694
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B6630: subu        $v1, $a1, $t3
        ctx->r3 = SUB32(ctx->r5, ctx->r11);
            goto L_802B6694;
    }
    // 0x802B6630: subu        $v1, $a1, $t3
    ctx->r3 = SUB32(ctx->r5, ctx->r11);
    // 0x802B6634: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B6638: beq         $at, $zero, L_802B6694
    if (ctx->r1 == 0) {
        // 0x802B663C: sll         $t9, $t6, 2
        ctx->r25 = S32(ctx->r14 << 2);
            goto L_802B6694;
    }
    // 0x802B663C: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x802B6640: or          $t8, $t7, $zero
    ctx->r24 = ctx->r15 | 0;
    // 0x802B6644: sll         $t7, $t8, 7
    ctx->r15 = S32(ctx->r24 << 7);
    // 0x802B6648: addu        $t6, $t2, $t9
    ctx->r14 = ADD32(ctx->r10, ctx->r25);
    // 0x802B664C: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B6650: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B6654: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B6658: sllv        $t7, $t6, $a3
    ctx->r15 = S32(ctx->r14 << (ctx->r7 & 31));
    // 0x802B665C: and         $t9, $t8, $t7
    ctx->r25 = ctx->r24 & ctx->r15;
    // 0x802B6660: beq         $t9, $zero, L_802B6694
    if (ctx->r25 == 0) {
        // 0x802B6664: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B6694;
    }
    // 0x802B6664: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B6668: lh          $t6, 0x60E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60E8);
    // 0x802B666C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6670: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B6674: addiu       $t8, $t6, 0x2
    ctx->r24 = ADD32(ctx->r14, 0X2);
    // 0x802B6678: sh          $t8, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r24;
    // 0x802B667C: lh          $t7, 0x60EC($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60EC);
    // 0x802B6680: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B6684: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B6688: addiu       $t9, $t7, 0x2
    ctx->r25 = ADD32(ctx->r15, 0X2);
    // 0x802B668C: sh          $t9, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r25;
    // 0x802B6690: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
L_802B6694:
    // 0x802B6694: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802B6698: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B669C: bltz        $t7, L_802B6704
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B66A0: or          $v1, $t7, $zero
        ctx->r3 = ctx->r15 | 0;
            goto L_802B6704;
    }
    // 0x802B66A0: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x802B66A4: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B66A8: beq         $at, $zero, L_802B6704
    if (ctx->r1 == 0) {
        // 0x802B66AC: sll         $t9, $a0, 2
        ctx->r25 = S32(ctx->r4 << 2);
            goto L_802B6704;
    }
    // 0x802B66AC: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x802B66B0: or          $t8, $t7, $zero
    ctx->r24 = ctx->r15 | 0;
    // 0x802B66B4: sll         $t7, $t8, 7
    ctx->r15 = S32(ctx->r24 << 7);
    // 0x802B66B8: addu        $t6, $t2, $t9
    ctx->r14 = ADD32(ctx->r10, ctx->r25);
    // 0x802B66BC: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B66C0: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B66C4: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B66C8: sllv        $t7, $t6, $a3
    ctx->r15 = S32(ctx->r14 << (ctx->r7 & 31));
    // 0x802B66CC: and         $t9, $t8, $t7
    ctx->r25 = ctx->r24 & ctx->r15;
    // 0x802B66D0: beq         $t9, $zero, L_802B6704
    if (ctx->r25 == 0) {
        // 0x802B66D4: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B6704;
    }
    // 0x802B66D4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B66D8: lh          $t6, 0x60E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60E8);
    // 0x802B66DC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B66E0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B66E4: addiu       $t8, $t6, 0x2
    ctx->r24 = ADD32(ctx->r14, 0X2);
    // 0x802B66E8: sh          $t8, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r24;
    // 0x802B66EC: lh          $t7, 0x60EC($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60EC);
    // 0x802B66F0: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B66F4: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B66F8: addiu       $t9, $t7, -0x2
    ctx->r25 = ADD32(ctx->r15, -0X2);
    // 0x802B66FC: sh          $t9, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r25;
    // 0x802B6700: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
L_802B6704:
    // 0x802B6704: subu        $a0, $a2, $t3
    ctx->r4 = SUB32(ctx->r6, ctx->r11);
    // 0x802B6708: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x802B670C: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B6710: bltz        $t7, L_802B67FC
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B6714: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_802B67FC;
    }
    // 0x802B6714: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x802B6718: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B671C: beq         $at, $zero, L_802B67FC
    if (ctx->r1 == 0) {
        // 0x802B6720: addu        $v0, $a1, $t3
        ctx->r2 = ADD32(ctx->r5, ctx->r11);
            goto L_802B67FC;
    }
    // 0x802B6720: addu        $v0, $a1, $t3
    ctx->r2 = ADD32(ctx->r5, ctx->r11);
    // 0x802B6724: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B6728: subu        $v1, $a1, $t3
    ctx->r3 = SUB32(ctx->r5, ctx->r11);
    // 0x802B672C: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802B6730: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B6734: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802B6738: bltz        $t6, L_802B679C
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B673C: sra         $v1, $t8, 16
        ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
            goto L_802B679C;
    }
    // 0x802B673C: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B6740: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B6744: beq         $at, $zero, L_802B679C
    if (ctx->r1 == 0) {
        // 0x802B6748: sll         $t9, $a0, 2
        ctx->r25 = S32(ctx->r4 << 2);
            goto L_802B679C;
    }
    // 0x802B6748: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x802B674C: addu        $t6, $t2, $t9
    ctx->r14 = ADD32(ctx->r10, ctx->r25);
    // 0x802B6750: sll         $t7, $v0, 7
    ctx->r15 = S32(ctx->r2 << 7);
    // 0x802B6754: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x802B6758: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B675C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B6760: sllv        $t7, $t6, $a3
    ctx->r15 = S32(ctx->r14 << (ctx->r7 & 31));
    // 0x802B6764: and         $t9, $t8, $t7
    ctx->r25 = ctx->r24 & ctx->r15;
    // 0x802B6768: beq         $t9, $zero, L_802B679C
    if (ctx->r25 == 0) {
        // 0x802B676C: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B679C;
    }
    // 0x802B676C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B6770: lh          $t6, 0x60E8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60E8);
    // 0x802B6774: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6778: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B677C: addiu       $t8, $t6, -0x2
    ctx->r24 = ADD32(ctx->r14, -0X2);
    // 0x802B6780: sh          $t8, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r24;
    // 0x802B6784: lh          $t7, 0x60EC($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60EC);
    // 0x802B6788: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B678C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B6790: addiu       $t9, $t7, 0x2
    ctx->r25 = ADD32(ctx->r15, 0X2);
    // 0x802B6794: sh          $t9, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r25;
    // 0x802B6798: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
L_802B679C:
    // 0x802B679C: bltz        $v1, L_802B67FC
    if (SIGNED(ctx->r3) < 0) {
        // 0x802B67A0: slti        $at, $v1, 0x20
        ctx->r1 = SIGNED(ctx->r3) < 0X20 ? 1 : 0;
            goto L_802B67FC;
    }
    // 0x802B67A0: slti        $at, $v1, 0x20
    ctx->r1 = SIGNED(ctx->r3) < 0X20 ? 1 : 0;
    // 0x802B67A4: beq         $at, $zero, L_802B67FC
    if (ctx->r1 == 0) {
        // 0x802B67A8: sll         $t8, $a0, 2
        ctx->r24 = S32(ctx->r4 << 2);
            goto L_802B67FC;
    }
    // 0x802B67A8: sll         $t8, $a0, 2
    ctx->r24 = S32(ctx->r4 << 2);
    // 0x802B67AC: addu        $t7, $t2, $t8
    ctx->r15 = ADD32(ctx->r10, ctx->r24);
    // 0x802B67B0: sll         $t6, $v1, 7
    ctx->r14 = S32(ctx->r3 << 7);
    // 0x802B67B4: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B67B8: lw          $t9, 0x8($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X8);
    // 0x802B67BC: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B67C0: sllv        $t6, $t7, $a3
    ctx->r14 = S32(ctx->r15 << (ctx->r7 & 31));
    // 0x802B67C4: and         $t8, $t9, $t6
    ctx->r24 = ctx->r25 & ctx->r14;
    // 0x802B67C8: beq         $t8, $zero, L_802B67FC
    if (ctx->r24 == 0) {
        // 0x802B67CC: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802B67FC;
    }
    // 0x802B67CC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B67D0: lh          $t7, 0x60E8($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60E8);
    // 0x802B67D4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B67D8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B67DC: addiu       $t9, $t7, -0x2
    ctx->r25 = ADD32(ctx->r15, -0X2);
    // 0x802B67E0: sh          $t9, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r25;
    // 0x802B67E4: lh          $t6, 0x60EC($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60EC);
    // 0x802B67E8: addiu       $t7, $t0, 0xC4
    ctx->r15 = ADD32(ctx->r8, 0XC4);
    // 0x802B67EC: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B67F0: addiu       $t8, $t6, -0x2
    ctx->r24 = ADD32(ctx->r14, -0X2);
    // 0x802B67F4: sh          $t8, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r24;
    // 0x802B67F8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
L_802B67FC:
    // 0x802B67FC: bne         $t4, $zero, L_802B681C
    if (ctx->r12 != 0) {
        // 0x802B6800: addiu       $t0, $t0, 0x10
        ctx->r8 = ADD32(ctx->r8, 0X10);
            goto L_802B681C;
    }
    // 0x802B6800: addiu       $t0, $t0, 0x10
    ctx->r8 = ADD32(ctx->r8, 0X10);
    // 0x802B6804: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6808: addiu       $at, $zero, 0x50
    ctx->r1 = ADD32(0, 0X50);
    // 0x802B680C: beq         $v0, $zero, L_802B681C
    if (ctx->r2 == 0) {
        // 0x802B6810: nop
    
            goto L_802B681C;
    }
    // 0x802B6810: nop

    // 0x802B6814: bnel        $s2, $at, L_802B60F0
    if (ctx->r18 != ctx->r1) {
        // 0x802B6818: lhu         $a0, 0x40($s1)
        ctx->r4 = MEM_HU(ctx->r17, 0X40);
            goto L_802B60F0;
    }
    goto skip_8;
    // 0x802B6818: lhu         $a0, 0x40($s1)
    ctx->r4 = MEM_HU(ctx->r17, 0X40);
    skip_8:
L_802B681C:
    // 0x802B681C: beql        $t4, $zero, L_802B6930
    if (ctx->r12 == 0) {
        // 0x802B6820: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802B6930;
    }
    goto skip_9;
    // 0x802B6820: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_9:
    // 0x802B6824: lh          $v0, 0x2C($s1)
    ctx->r2 = MEM_H(ctx->r17, 0X2C);
    // 0x802B6828: addiu       $at, $zero, 0x5A
    ctx->r1 = ADD32(0, 0X5A);
    // 0x802B682C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B6830: beq         $v0, $at, L_802B6854
    if (ctx->r2 == ctx->r1) {
        // 0x802B6834: addiu       $at, $zero, 0xB4
        ctx->r1 = ADD32(0, 0XB4);
            goto L_802B6854;
    }
    // 0x802B6834: addiu       $at, $zero, 0xB4
    ctx->r1 = ADD32(0, 0XB4);
    // 0x802B6838: beq         $v0, $at, L_802B6874
    if (ctx->r2 == ctx->r1) {
        // 0x802B683C: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_802B6874;
    }
    // 0x802B683C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B6840: addiu       $at, $zero, 0x10E
    ctx->r1 = ADD32(0, 0X10E);
    // 0x802B6844: beq         $v0, $at, L_802B6898
    if (ctx->r2 == ctx->r1) {
        // 0x802B6848: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_802B6898;
    }
    // 0x802B6848: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B684C: b           L_802B68B4
    // 0x802B6850: nop

        goto L_802B68B4;
    // 0x802B6850: nop

L_802B6854:
    // 0x802B6854: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B6858: lh          $v0, 0x60E8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X60E8);
    // 0x802B685C: lh          $t9, 0x60EC($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60EC);
    // 0x802B6860: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6864: negu        $t6, $v0
    ctx->r14 = SUB32(0, ctx->r2);
    // 0x802B6868: sh          $t6, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r14;
    // 0x802B686C: b           L_802B68B4
    // 0x802B6870: sh          $t9, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r25;
        goto L_802B68B4;
    // 0x802B6870: sh          $t9, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r25;
L_802B6874:
    // 0x802B6874: lh          $t8, 0x60E8($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60E8);
    // 0x802B6878: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B687C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B6880: negu        $t7, $t8
    ctx->r15 = SUB32(0, ctx->r24);
    // 0x802B6884: sh          $t7, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r15;
    // 0x802B6888: lh          $t9, 0x60EC($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60EC);
    // 0x802B688C: negu        $t6, $t9
    ctx->r14 = SUB32(0, ctx->r25);
    // 0x802B6890: b           L_802B68B4
    // 0x802B6894: sh          $t6, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r14;
        goto L_802B68B4;
    // 0x802B6894: sh          $t6, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r14;
L_802B6898:
    // 0x802B6898: lh          $t8, 0x60EC($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60EC);
    // 0x802B689C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B68A0: lh          $v0, 0x60E8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X60E8);
    // 0x802B68A4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B68A8: negu        $t7, $t8
    ctx->r15 = SUB32(0, ctx->r24);
    // 0x802B68AC: sh          $t7, 0x60E8($at)
    MEM_H(0X60E8, ctx->r1) = ctx->r15;
    // 0x802B68B0: sh          $v0, 0x60EC($at)
    MEM_H(0X60EC, ctx->r1) = ctx->r2;
L_802B68B4:
    // 0x802B68B4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B68B8: lh          $t9, 0x60E8($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60E8);
    // 0x802B68BC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B68C0: bnel        $t9, $zero, L_802B6920
    if (ctx->r25 != 0) {
        // 0x802B68C4: lw          $t8, 0x5C($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X5C);
            goto L_802B6920;
    }
    goto skip_10;
    // 0x802B68C4: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    skip_10:
    // 0x802B68C8: lh          $t6, 0x60EC($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60EC);
    // 0x802B68CC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B68D0: bnel        $t6, $zero, L_802B6920
    if (ctx->r14 != 0) {
        // 0x802B68D4: lw          $t8, 0x5C($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X5C);
            goto L_802B6920;
    }
    goto skip_11;
    // 0x802B68D4: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    skip_11:
    // 0x802B68D8: lh          $t8, 0x60F0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60F0);
    // 0x802B68DC: bnel        $t8, $zero, L_802B6920
    if (ctx->r24 != 0) {
        // 0x802B68E0: lw          $t8, 0x5C($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X5C);
            goto L_802B6920;
    }
    goto skip_12;
    // 0x802B68E0: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
    skip_12:
    // 0x802B68E4: jal         0x8012826C
    // 0x802B68E8: sb          $t4, 0x2B($sp)
    MEM_B(0X2B, ctx->r29) = ctx->r12;
    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x802B68E8: sb          $t4, 0x2B($sp)
    MEM_B(0X2B, ctx->r29) = ctx->r12;
    after_0:
    // 0x802B68EC: andi        $t7, $v0, 0xFF
    ctx->r15 = ctx->r2 & 0XFF;
    // 0x802B68F0: addiu       $t9, $t7, -0x80
    ctx->r25 = ADD32(ctx->r15, -0X80);
    // 0x802B68F4: sll         $t6, $t9, 10
    ctx->r14 = S32(ctx->r25 << 10);
    // 0x802B68F8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B68FC: jal         0x8012826C
    // 0x802B6900: sw          $t6, 0x60E8($at)
    MEM_W(0X60E8, ctx->r1) = ctx->r14;
    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x802B6900: sw          $t6, 0x60E8($at)
    MEM_W(0X60E8, ctx->r1) = ctx->r14;
    after_1:
    // 0x802B6904: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x802B6908: addiu       $t7, $t8, -0x80
    ctx->r15 = ADD32(ctx->r24, -0X80);
    // 0x802B690C: sll         $t9, $t7, 10
    ctx->r25 = S32(ctx->r15 << 10);
    // 0x802B6910: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6914: sw          $t9, 0x60EC($at)
    MEM_W(0X60EC, ctx->r1) = ctx->r25;
    // 0x802B6918: lbu         $t4, 0x2B($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X2B);
    // 0x802B691C: lw          $t8, 0x5C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X5C);
L_802B6920:
    // 0x802B6920: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B6924: addiu       $t6, $t6, 0x60E8
    ctx->r14 = ADD32(ctx->r14, 0X60E8);
    // 0x802B6928: sw          $t6, 0x0($t8)
    MEM_W(0X0, ctx->r24) = ctx->r14;
    // 0x802B692C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802B6930:
    // 0x802B6930: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B6934: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x802B6938: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x802B693C: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    // 0x802B6940: jr          $ra
    // 0x802B6944: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
    return;
    // 0x802B6944: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
;}
RECOMP_FUNC void func_802B6948_6C7FF8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B6948: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802B694C: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802B6950: sw          $fp, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r30;
    // 0x802B6954: sw          $s7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r23;
    // 0x802B6958: sw          $s6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r22;
    // 0x802B695C: sw          $s5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r21;
    // 0x802B6960: sw          $s4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r20;
    // 0x802B6964: sw          $s3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r19;
    // 0x802B6968: sw          $s2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r18;
    // 0x802B696C: sw          $s1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r17;
    // 0x802B6970: sw          $s0, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r16;
    // 0x802B6974: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802B6978: lw          $t7, 0xD0($a0)
    ctx->r15 = MEM_W(ctx->r4, 0XD0);
    // 0x802B697C: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x802B6980: or          $s7, $a2, $zero
    ctx->r23 = ctx->r6 | 0;
    // 0x802B6984: or          $fp, $a3, $zero
    ctx->r30 = ctx->r7 | 0;
    // 0x802B6988: or          $ra, $zero, $zero
    ctx->r31 = 0 | 0;
    // 0x802B698C: beq         $t7, $zero, L_802B6B28
    if (ctx->r15 == 0) {
        // 0x802B6990: or          $s6, $zero, $zero
        ctx->r22 = 0 | 0;
            goto L_802B6B28;
    }
    // 0x802B6990: or          $s6, $zero, $zero
    ctx->r22 = 0 | 0;
    // 0x802B6994: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802B6998: lw          $s5, 0x48($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X48);
    // 0x802B699C: lw          $s4, 0x54($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X54);
    // 0x802B69A0: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x802B69A4: lw          $s2, 0x50($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X50);
    // 0x802B69A8: lw          $s1, 0x40($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X40);
    // 0x802B69AC: lw          $t5, 0x4C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X4C);
L_802B69B0:
    // 0x802B69B0: bne         $v0, $zero, L_802B6AEC
    if (ctx->r2 != 0) {
        // 0x802B69B4: or          $t3, $zero, $zero
        ctx->r11 = 0 | 0;
            goto L_802B6AEC;
    }
    // 0x802B69B4: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
    // 0x802B69B8: lw          $t8, 0xD0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XD0);
    // 0x802B69BC: lw          $t9, 0x30($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X30);
    // 0x802B69C0: sll         $t6, $ra, 4
    ctx->r14 = S32(ctx->r31 << 4);
    // 0x802B69C4: beq         $t8, $zero, L_802B6AEC
    if (ctx->r24 == 0) {
        // 0x802B69C8: addu        $a1, $t9, $t6
        ctx->r5 = ADD32(ctx->r25, ctx->r14);
            goto L_802B6AEC;
    }
    // 0x802B69C8: addu        $a1, $t9, $t6
    ctx->r5 = ADD32(ctx->r25, ctx->r14);
    // 0x802B69CC: sll         $t7, $zero, 4
    ctx->r15 = S32(0 << 4);
    // 0x802B69D0: addu        $a0, $s0, $t7
    ctx->r4 = ADD32(ctx->r16, ctx->r15);
    // 0x802B69D4: lw          $a2, 0xD0($a0)
    ctx->r6 = MEM_W(ctx->r4, 0XD0);
    // 0x802B69D8: lw          $t8, 0xC4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0XC4);
L_802B69DC:
    // 0x802B69DC: lw          $t6, 0xC4($a1)
    ctx->r14 = MEM_W(ctx->r5, 0XC4);
    // 0x802B69E0: lw          $t4, 0xD0($a1)
    ctx->r12 = MEM_W(ctx->r5, 0XD0);
    // 0x802B69E4: addu        $t9, $t8, $t5
    ctx->r25 = ADD32(ctx->r24, ctx->r13);
    // 0x802B69E8: subu        $t7, $t9, $t6
    ctx->r15 = SUB32(ctx->r25, ctx->r14);
    // 0x802B69EC: subu        $a3, $t7, $s1
    ctx->r7 = SUB32(ctx->r15, ctx->r17);
    // 0x802B69F0: addu        $v0, $a2, $t4
    ctx->r2 = ADD32(ctx->r6, ctx->r12);
    // 0x802B69F4: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B69F8: lw          $t7, 0xC8($a0)
    ctx->r15 = MEM_W(ctx->r4, 0XC8);
    // 0x802B69FC: bgez        $a3, L_802B6A10
    if (SIGNED(ctx->r7) >= 0) {
        // 0x802B6A00: sra         $t8, $a3, 16
        ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
            goto L_802B6A10;
    }
    // 0x802B6A00: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802B6A04: ori         $at, $zero, 0xFFFF
    ctx->r1 = 0 | 0XFFFF;
    // 0x802B6A08: addu        $at, $at, $a3
    ctx->r1 = ADD32(ctx->r1, ctx->r7);
    // 0x802B6A0C: sra         $t8, $at, 16
    ctx->r24 = S32(SIGNED(ctx->r1) >> 16);
L_802B6A10:
    // 0x802B6A10: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802B6A14: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B6A18: lw          $t9, 0xC8($a1)
    ctx->r25 = MEM_W(ctx->r5, 0XC8);
    // 0x802B6A1C: addu        $t8, $t7, $s2
    ctx->r24 = ADD32(ctx->r15, ctx->r18);
    // 0x802B6A20: mflo        $v0
    ctx->r2 = lo;
    // 0x802B6A24: subu        $t6, $t8, $t9
    ctx->r14 = SUB32(ctx->r24, ctx->r25);
    // 0x802B6A28: subu        $t0, $t6, $s3
    ctx->r8 = SUB32(ctx->r14, ctx->r19);
    // 0x802B6A2C: multu       $a3, $a3
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6A30: lw          $t6, 0xCC($a0)
    ctx->r14 = MEM_W(ctx->r4, 0XCC);
    // 0x802B6A34: bgez        $t0, L_802B6A48
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802B6A38: sra         $t7, $t0, 16
        ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
            goto L_802B6A48;
    }
    // 0x802B6A38: sra         $t7, $t0, 16
    ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B6A3C: ori         $at, $zero, 0xFFFF
    ctx->r1 = 0 | 0XFFFF;
    // 0x802B6A40: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x802B6A44: sra         $t7, $at, 16
    ctx->r15 = S32(SIGNED(ctx->r1) >> 16);
L_802B6A48:
    // 0x802B6A48: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802B6A4C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B6A50: lw          $t8, 0xCC($a1)
    ctx->r24 = MEM_W(ctx->r5, 0XCC);
    // 0x802B6A54: addu        $t7, $t6, $s4
    ctx->r15 = ADD32(ctx->r14, ctx->r20);
    // 0x802B6A58: addiu       $t3, $t3, 0x1
    ctx->r11 = ADD32(ctx->r11, 0X1);
    // 0x802B6A5C: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x802B6A60: subu        $t1, $t9, $s5
    ctx->r9 = SUB32(ctx->r25, ctx->r21);
    // 0x802B6A64: mflo        $t9
    ctx->r25 = lo;
    // 0x802B6A68: bgez        $t1, L_802B6A7C
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802B6A6C: sra         $t6, $t1, 16
        ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
            goto L_802B6A7C;
    }
    // 0x802B6A6C: sra         $t6, $t1, 16
    ctx->r14 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802B6A70: ori         $at, $zero, 0xFFFF
    ctx->r1 = 0 | 0XFFFF;
    // 0x802B6A74: addu        $at, $at, $t1
    ctx->r1 = ADD32(ctx->r1, ctx->r9);
    // 0x802B6A78: sra         $t6, $at, 16
    ctx->r14 = S32(SIGNED(ctx->r1) >> 16);
L_802B6A7C:
    // 0x802B6A7C: multu       $t0, $t0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6A80: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802B6A84: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B6A88: mflo        $t6
    ctx->r14 = lo;
    // 0x802B6A8C: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x802B6A90: addiu       $t6, $a1, 0xC4
    ctx->r14 = ADD32(ctx->r5, 0XC4);
    // 0x802B6A94: multu       $t8, $t8
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6A98: mflo        $t8
    ctx->r24 = lo;
    // 0x802B6A9C: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x802B6AA0: sltu        $v1, $t9, $v0
    ctx->r3 = ctx->r25 < ctx->r2 ? 1 : 0;
    // 0x802B6AA4: andi        $t2, $v1, 0xFF
    ctx->r10 = ctx->r3 & 0XFF;
    // 0x802B6AA8: beq         $t2, $zero, L_802B6ABC
    if (ctx->r10 == 0) {
        // 0x802B6AAC: andi        $s6, $v1, 0xFF
        ctx->r22 = ctx->r3 & 0XFF;
            goto L_802B6ABC;
    }
    // 0x802B6AAC: andi        $s6, $v1, 0xFF
    ctx->r22 = ctx->r3 & 0XFF;
    // 0x802B6AB0: sw          $t6, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r14;
    // 0x802B6AB4: addiu       $t7, $a0, 0xC4
    ctx->r15 = ADD32(ctx->r4, 0XC4);
    // 0x802B6AB8: sw          $t7, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r15;
L_802B6ABC:
    // 0x802B6ABC: sll         $t8, $t3, 16
    ctx->r24 = S32(ctx->r11 << 16);
    // 0x802B6AC0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B6AC4: bne         $t2, $zero, L_802B6AEC
    if (ctx->r10 != 0) {
        // 0x802B6AC8: or          $t3, $t9, $zero
        ctx->r11 = ctx->r25 | 0;
            goto L_802B6AEC;
    }
    // 0x802B6AC8: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
    // 0x802B6ACC: sll         $t6, $t9, 4
    ctx->r14 = S32(ctx->r25 << 4);
    // 0x802B6AD0: addu        $a0, $s0, $t6
    ctx->r4 = ADD32(ctx->r16, ctx->r14);
    // 0x802B6AD4: lw          $a2, 0xD0($a0)
    ctx->r6 = MEM_W(ctx->r4, 0XD0);
    // 0x802B6AD8: slti        $at, $t9, 0x5
    ctx->r1 = SIGNED(ctx->r25) < 0X5 ? 1 : 0;
    // 0x802B6ADC: beql        $a2, $zero, L_802B6AF0
    if (ctx->r6 == 0) {
        // 0x802B6AE0: addiu       $ra, $ra, 0x1
        ctx->r31 = ADD32(ctx->r31, 0X1);
            goto L_802B6AF0;
    }
    goto skip_0;
    // 0x802B6AE0: addiu       $ra, $ra, 0x1
    ctx->r31 = ADD32(ctx->r31, 0X1);
    skip_0:
    // 0x802B6AE4: bnel        $at, $zero, L_802B69DC
    if (ctx->r1 != 0) {
        // 0x802B6AE8: lw          $t8, 0xC4($a0)
        ctx->r24 = MEM_W(ctx->r4, 0XC4);
            goto L_802B69DC;
    }
    goto skip_1;
    // 0x802B6AE8: lw          $t8, 0xC4($a0)
    ctx->r24 = MEM_W(ctx->r4, 0XC4);
    skip_1:
L_802B6AEC:
    // 0x802B6AEC: addiu       $ra, $ra, 0x1
    ctx->r31 = ADD32(ctx->r31, 0X1);
L_802B6AF0:
    // 0x802B6AF0: sll         $t7, $ra, 16
    ctx->r15 = S32(ctx->r31 << 16);
    // 0x802B6AF4: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B6AF8: or          $ra, $t8, $zero
    ctx->r31 = ctx->r24 | 0;
    // 0x802B6AFC: bne         $s6, $zero, L_802B6B28
    if (ctx->r22 != 0) {
        // 0x802B6B00: or          $v0, $s6, $zero
        ctx->r2 = ctx->r22 | 0;
            goto L_802B6B28;
    }
    // 0x802B6B00: or          $v0, $s6, $zero
    ctx->r2 = ctx->r22 | 0;
    // 0x802B6B04: lw          $t9, 0x30($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X30);
    // 0x802B6B08: sll         $t6, $t8, 4
    ctx->r14 = S32(ctx->r24 << 4);
    // 0x802B6B0C: slti        $at, $ra, 0x5
    ctx->r1 = SIGNED(ctx->r31) < 0X5 ? 1 : 0;
    // 0x802B6B10: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x802B6B14: lw          $t8, 0xD0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0XD0);
    // 0x802B6B18: beql        $t8, $zero, L_802B6B2C
    if (ctx->r24 == 0) {
        // 0x802B6B1C: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802B6B2C;
    }
    goto skip_2;
    // 0x802B6B1C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_2:
    // 0x802B6B20: bne         $at, $zero, L_802B69B0
    if (ctx->r1 != 0) {
        // 0x802B6B24: nop
    
            goto L_802B69B0;
    }
    // 0x802B6B24: nop

L_802B6B28:
    // 0x802B6B28: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802B6B2C:
    // 0x802B6B2C: or          $v0, $s6, $zero
    ctx->r2 = ctx->r22 | 0;
    // 0x802B6B30: lw          $s6, 0x20($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X20);
    // 0x802B6B34: lw          $s0, 0x8($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X8);
    // 0x802B6B38: lw          $s1, 0xC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XC);
    // 0x802B6B3C: lw          $s2, 0x10($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X10);
    // 0x802B6B40: lw          $s3, 0x14($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X14);
    // 0x802B6B44: lw          $s4, 0x18($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X18);
    // 0x802B6B48: lw          $s5, 0x1C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X1C);
    // 0x802B6B4C: lw          $s7, 0x24($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X24);
    // 0x802B6B50: lw          $fp, 0x28($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X28);
    // 0x802B6B54: jr          $ra
    // 0x802B6B58: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x802B6B58: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void func_802B6B5C_6C820C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B6B5C: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802B6B60: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802B6B64: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802B6B68: sw          $fp, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r30;
    // 0x802B6B6C: sw          $s7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r23;
    // 0x802B6B70: sw          $s6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r22;
    // 0x802B6B74: sw          $s5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r21;
    // 0x802B6B78: sw          $s4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r20;
    // 0x802B6B7C: sw          $s3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r19;
    // 0x802B6B80: sw          $s2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r18;
    // 0x802B6B84: sw          $s1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r17;
    // 0x802B6B88: sw          $s0, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r16;
    // 0x802B6B8C: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x802B6B90: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x802B6B94: addiu       $ra, $ra, 0x60E0
    ctx->r31 = ADD32(ctx->r31, 0X60E0);
    // 0x802B6B98: sw          $zero, 0x0($a2)
    MEM_W(0X0, ctx->r6) = 0;
    // 0x802B6B9C: sb          $zero, 0x0($ra)
    MEM_B(0X0, ctx->r31) = 0;
    // 0x802B6BA0: lw          $t7, 0xD0($a0)
    ctx->r15 = MEM_W(ctx->r4, 0XD0);
    // 0x802B6BA4: or          $s5, $a1, $zero
    ctx->r21 = ctx->r5 | 0;
    // 0x802B6BA8: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x802B6BAC: beq         $t7, $zero, L_802B6F38
    if (ctx->r15 == 0) {
        // 0x802B6BB0: sll         $s6, $zero, 4
        ctx->r22 = S32(0 << 4);
            goto L_802B6F38;
    }
    // 0x802B6BB0: sll         $s6, $zero, 4
    ctx->r22 = S32(0 << 4);
    // 0x802B6BB4: addu        $t0, $a0, $s6
    ctx->r8 = ADD32(ctx->r4, ctx->r22);
    // 0x802B6BB8: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6BBC: lh          $fp, 0x48($sp)
    ctx->r30 = MEM_H(ctx->r29, 0X48);
    // 0x802B6BC0: lh          $s7, 0x54($sp)
    ctx->r23 = MEM_H(ctx->r29, 0X54);
    // 0x802B6BC4: lh          $s4, 0x44($sp)
    ctx->r20 = MEM_H(ctx->r29, 0X44);
    // 0x802B6BC8: lh          $s3, 0x40($sp)
    ctx->r19 = MEM_H(ctx->r29, 0X40);
    // 0x802B6BCC: lh          $s2, 0x50($sp)
    ctx->r18 = MEM_H(ctx->r29, 0X50);
    // 0x802B6BD0: lh          $s1, 0x4C($sp)
    ctx->r17 = MEM_H(ctx->r29, 0X4C);
    // 0x802B6BD4: lh          $t8, 0x30($s5)
    ctx->r24 = MEM_H(ctx->r21, 0X30);
L_802B6BD8:
    // 0x802B6BD8: lh          $t6, 0xC4($t0)
    ctx->r14 = MEM_H(ctx->r8, 0XC4);
    // 0x802B6BDC: lh          $t9, 0x32($s5)
    ctx->r25 = MEM_H(ctx->r21, 0X32);
    // 0x802B6BE0: addu        $a0, $v0, $t8
    ctx->r4 = ADD32(ctx->r2, ctx->r24);
    // 0x802B6BE4: subu        $t7, $s1, $a0
    ctx->r15 = SUB32(ctx->r17, ctx->r4);
    // 0x802B6BE8: addu        $t2, $t6, $s3
    ctx->r10 = ADD32(ctx->r14, ctx->r19);
    // 0x802B6BEC: slt         $v1, $t7, $t2
    ctx->r3 = SIGNED(ctx->r15) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802B6BF0: beq         $v1, $zero, L_802B6C58
    if (ctx->r3 == 0) {
        // 0x802B6BF4: addu        $a1, $v0, $t9
        ctx->r5 = ADD32(ctx->r2, ctx->r25);
            goto L_802B6C58;
    }
    // 0x802B6BF4: addu        $a1, $v0, $t9
    ctx->r5 = ADD32(ctx->r2, ctx->r25);
    // 0x802B6BF8: addu        $t8, $s1, $a0
    ctx->r24 = ADD32(ctx->r17, ctx->r4);
    // 0x802B6BFC: slt         $v1, $t2, $t8
    ctx->r3 = SIGNED(ctx->r10) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B6C00: beql        $v1, $zero, L_802B6C5C
    if (ctx->r3 == 0) {
        // 0x802B6C04: andi        $t9, $v1, 0xFF
        ctx->r25 = ctx->r3 & 0XFF;
            goto L_802B6C5C;
    }
    goto skip_0;
    // 0x802B6C04: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    skip_0:
    // 0x802B6C08: lh          $t9, 0xC8($t0)
    ctx->r25 = MEM_H(ctx->r8, 0XC8);
    // 0x802B6C0C: subu        $t6, $s2, $a1
    ctx->r14 = SUB32(ctx->r18, ctx->r5);
    // 0x802B6C10: addu        $t7, $s2, $a1
    ctx->r15 = ADD32(ctx->r18, ctx->r5);
    // 0x802B6C14: addu        $t3, $t9, $s4
    ctx->r11 = ADD32(ctx->r25, ctx->r20);
    // 0x802B6C18: slt         $v1, $t6, $t3
    ctx->r3 = SIGNED(ctx->r14) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B6C1C: beql        $v1, $zero, L_802B6C5C
    if (ctx->r3 == 0) {
        // 0x802B6C20: andi        $t9, $v1, 0xFF
        ctx->r25 = ctx->r3 & 0XFF;
            goto L_802B6C5C;
    }
    goto skip_1;
    // 0x802B6C20: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    skip_1:
    // 0x802B6C24: slt         $v1, $t3, $t7
    ctx->r3 = SIGNED(ctx->r11) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802B6C28: beql        $v1, $zero, L_802B6C5C
    if (ctx->r3 == 0) {
        // 0x802B6C2C: andi        $t9, $v1, 0xFF
        ctx->r25 = ctx->r3 & 0XFF;
            goto L_802B6C5C;
    }
    goto skip_2;
    // 0x802B6C2C: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    skip_2:
    // 0x802B6C30: lh          $t8, 0xCC($t0)
    ctx->r24 = MEM_H(ctx->r8, 0XCC);
    // 0x802B6C34: subu        $t9, $s7, $v0
    ctx->r25 = SUB32(ctx->r23, ctx->r2);
    // 0x802B6C38: addu        $a0, $fp, $t8
    ctx->r4 = ADD32(ctx->r30, ctx->r24);
    // 0x802B6C3C: slt         $v1, $t9, $a0
    ctx->r3 = SIGNED(ctx->r25) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802B6C40: beql        $v1, $zero, L_802B6C5C
    if (ctx->r3 == 0) {
        // 0x802B6C44: andi        $t9, $v1, 0xFF
        ctx->r25 = ctx->r3 & 0XFF;
            goto L_802B6C5C;
    }
    goto skip_3;
    // 0x802B6C44: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    skip_3:
    // 0x802B6C48: lhu         $t7, 0x42($s5)
    ctx->r15 = MEM_HU(ctx->r21, 0X42);
    // 0x802B6C4C: addu        $t6, $v0, $s7
    ctx->r14 = ADD32(ctx->r2, ctx->r23);
    // 0x802B6C50: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B6C54: slt         $v1, $a0, $t8
    ctx->r3 = SIGNED(ctx->r4) < SIGNED(ctx->r24) ? 1 : 0;
L_802B6C58:
    // 0x802B6C58: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
L_802B6C5C:
    // 0x802B6C5C: beq         $t9, $zero, L_802B6F14
    if (ctx->r25 == 0) {
        // 0x802B6C60: andi        $s0, $v1, 0xFF
        ctx->r16 = ctx->r3 & 0XFF;
            goto L_802B6F14;
    }
    // 0x802B6C60: andi        $s0, $v1, 0xFF
    ctx->r16 = ctx->r3 & 0XFF;
    // 0x802B6C64: lw          $t7, 0x38($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X38);
    // 0x802B6C68: addiu       $t6, $t0, 0xC4
    ctx->r14 = ADD32(ctx->r8, 0XC4);
    // 0x802B6C6C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802B6C70: sw          $t6, 0x0($t7)
    MEM_W(0X0, ctx->r15) = ctx->r14;
    // 0x802B6C74: lh          $t5, 0x30($s5)
    ctx->r13 = MEM_H(ctx->r21, 0X30);
    // 0x802B6C78: lh          $a2, 0xC4($t0)
    ctx->r6 = MEM_H(ctx->r8, 0XC4);
    // 0x802B6C7C: subu        $t1, $s1, $t5
    ctx->r9 = SUB32(ctx->r17, ctx->r13);
    // 0x802B6C80: addu        $t2, $a2, $s3
    ctx->r10 = ADD32(ctx->r6, ctx->r19);
    // 0x802B6C84: slt         $at, $t2, $t1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B6C88: beq         $at, $zero, L_802B6C98
    if (ctx->r1 == 0) {
        // 0x802B6C8C: addu        $t8, $s1, $t5
        ctx->r24 = ADD32(ctx->r17, ctx->r13);
            goto L_802B6C98;
    }
    // 0x802B6C8C: addu        $t8, $s1, $t5
    ctx->r24 = ADD32(ctx->r17, ctx->r13);
    // 0x802B6C90: b           L_802B6CA8
    // 0x802B6C94: addiu       $v0, $zero, 0xC
    ctx->r2 = ADD32(0, 0XC);
        goto L_802B6CA8;
    // 0x802B6C94: addiu       $v0, $zero, 0xC
    ctx->r2 = ADD32(0, 0XC);
L_802B6C98:
    // 0x802B6C98: slt         $at, $t8, $t2
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802B6C9C: beql        $at, $zero, L_802B6CAC
    if (ctx->r1 == 0) {
        // 0x802B6CA0: lh          $a1, 0xC8($t0)
        ctx->r5 = MEM_H(ctx->r8, 0XC8);
            goto L_802B6CAC;
    }
    goto skip_4;
    // 0x802B6CA0: lh          $a1, 0xC8($t0)
    ctx->r5 = MEM_H(ctx->r8, 0XC8);
    skip_4:
    // 0x802B6CA4: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
L_802B6CA8:
    // 0x802B6CA8: lh          $a1, 0xC8($t0)
    ctx->r5 = MEM_H(ctx->r8, 0XC8);
L_802B6CAC:
    // 0x802B6CAC: lh          $t4, 0x32($s5)
    ctx->r12 = MEM_H(ctx->r21, 0X32);
    // 0x802B6CB0: ori         $t9, $v0, 0x3
    ctx->r25 = ctx->r2 | 0X3;
    // 0x802B6CB4: addu        $t3, $a1, $s4
    ctx->r11 = ADD32(ctx->r5, ctx->r20);
    // 0x802B6CB8: subu        $a3, $s2, $t4
    ctx->r7 = SUB32(ctx->r18, ctx->r12);
    // 0x802B6CBC: slt         $at, $t3, $a3
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B6CC0: beq         $at, $zero, L_802B6CD0
    if (ctx->r1 == 0) {
        // 0x802B6CC4: addu        $t7, $s2, $t4
        ctx->r15 = ADD32(ctx->r18, ctx->r12);
            goto L_802B6CD0;
    }
    // 0x802B6CC4: addu        $t7, $s2, $t4
    ctx->r15 = ADD32(ctx->r18, ctx->r12);
    // 0x802B6CC8: b           L_802B6CE0
    // 0x802B6CCC: andi        $v0, $t9, 0xFF
    ctx->r2 = ctx->r25 & 0XFF;
        goto L_802B6CE0;
    // 0x802B6CCC: andi        $v0, $t9, 0xFF
    ctx->r2 = ctx->r25 & 0XFF;
L_802B6CD0:
    // 0x802B6CD0: slt         $at, $t7, $t3
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B6CD4: beq         $at, $zero, L_802B6CE0
    if (ctx->r1 == 0) {
        // 0x802B6CD8: ori         $t8, $v0, 0x2
        ctx->r24 = ctx->r2 | 0X2;
            goto L_802B6CE0;
    }
    // 0x802B6CD8: ori         $t8, $v0, 0x2
    ctx->r24 = ctx->r2 | 0X2;
    // 0x802B6CDC: andi        $v0, $t8, 0xFF
    ctx->r2 = ctx->r24 & 0XFF;
L_802B6CE0:
    // 0x802B6CE0: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x802B6CE4: beq         $v0, $at, L_802B6E08
    if (ctx->r2 == ctx->r1) {
        // 0x802B6CE8: addiu       $at, $zero, 0xB
        ctx->r1 = ADD32(0, 0XB);
            goto L_802B6E08;
    }
    // 0x802B6CE8: addiu       $at, $zero, 0xB
    ctx->r1 = ADD32(0, 0XB);
    // 0x802B6CEC: beq         $v0, $at, L_802B6DB0
    if (ctx->r2 == ctx->r1) {
        // 0x802B6CF0: addiu       $at, $zero, 0xE
        ctx->r1 = ADD32(0, 0XE);
            goto L_802B6DB0;
    }
    // 0x802B6CF0: addiu       $at, $zero, 0xE
    ctx->r1 = ADD32(0, 0XE);
    // 0x802B6CF4: beq         $v0, $at, L_802B6D58
    if (ctx->r2 == ctx->r1) {
        // 0x802B6CF8: addiu       $at, $zero, 0xF
        ctx->r1 = ADD32(0, 0XF);
            goto L_802B6D58;
    }
    // 0x802B6CF8: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    // 0x802B6CFC: bne         $v0, $at, L_802B6E60
    if (ctx->r2 != ctx->r1) {
        // 0x802B6D00: nop
    
            goto L_802B6E60;
    }
    // 0x802B6D00: nop

    // 0x802B6D04: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6D08: subu        $t6, $t1, $s3
    ctx->r14 = SUB32(ctx->r9, ctx->r19);
    // 0x802B6D0C: addu        $v1, $t6, $a2
    ctx->r3 = ADD32(ctx->r14, ctx->r6);
    // 0x802B6D10: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D14: subu        $t7, $a3, $s4
    ctx->r15 = SUB32(ctx->r7, ctx->r20);
    // 0x802B6D18: addu        $a0, $t7, $a1
    ctx->r4 = ADD32(ctx->r15, ctx->r5);
    // 0x802B6D1C: mflo        $t8
    ctx->r24 = lo;
    // 0x802B6D20: nop

    // 0x802B6D24: nop

    // 0x802B6D28: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D2C: mflo        $t9
    ctx->r25 = lo;
    // 0x802B6D30: nop

    // 0x802B6D34: nop

    // 0x802B6D38: multu       $a0, $a0
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D3C: mflo        $t6
    ctx->r14 = lo;
    // 0x802B6D40: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x802B6D44: slt         $at, $t8, $t7
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802B6D48: beq         $at, $zero, L_802B6E60
    if (ctx->r1 == 0) {
        // 0x802B6D4C: nop
    
            goto L_802B6E60;
    }
    // 0x802B6D4C: nop

    // 0x802B6D50: b           L_802B6E60
    // 0x802B6D54: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
        goto L_802B6E60;
    // 0x802B6D54: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_802B6D58:
    // 0x802B6D58: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6D5C: subu        $t9, $t1, $s3
    ctx->r25 = SUB32(ctx->r9, ctx->r19);
    // 0x802B6D60: addu        $v1, $t9, $a2
    ctx->r3 = ADD32(ctx->r25, ctx->r6);
    // 0x802B6D64: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D68: addu        $t6, $s2, $t4
    ctx->r14 = ADD32(ctx->r18, ctx->r12);
    // 0x802B6D6C: subu        $t8, $t6, $s4
    ctx->r24 = SUB32(ctx->r14, ctx->r20);
    // 0x802B6D70: addu        $a0, $t8, $a1
    ctx->r4 = ADD32(ctx->r24, ctx->r5);
    // 0x802B6D74: mflo        $t7
    ctx->r15 = lo;
    // 0x802B6D78: nop

    // 0x802B6D7C: nop

    // 0x802B6D80: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D84: mflo        $t9
    ctx->r25 = lo;
    // 0x802B6D88: nop

    // 0x802B6D8C: nop

    // 0x802B6D90: multu       $a0, $a0
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6D94: mflo        $t6
    ctx->r14 = lo;
    // 0x802B6D98: addu        $t8, $t9, $t6
    ctx->r24 = ADD32(ctx->r25, ctx->r14);
    // 0x802B6D9C: slt         $at, $t7, $t8
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B6DA0: beq         $at, $zero, L_802B6E60
    if (ctx->r1 == 0) {
        // 0x802B6DA4: nop
    
            goto L_802B6E60;
    }
    // 0x802B6DA4: nop

    // 0x802B6DA8: b           L_802B6E60
    // 0x802B6DAC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
        goto L_802B6E60;
    // 0x802B6DAC: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_802B6DB0:
    // 0x802B6DB0: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6DB4: addu        $t9, $s1, $t5
    ctx->r25 = ADD32(ctx->r17, ctx->r13);
    // 0x802B6DB8: subu        $t6, $t9, $s3
    ctx->r14 = SUB32(ctx->r25, ctx->r19);
    // 0x802B6DBC: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6DC0: addu        $v1, $t6, $a2
    ctx->r3 = ADD32(ctx->r14, ctx->r6);
    // 0x802B6DC4: subu        $t7, $a3, $s4
    ctx->r15 = SUB32(ctx->r7, ctx->r20);
    // 0x802B6DC8: addu        $a0, $t7, $a1
    ctx->r4 = ADD32(ctx->r15, ctx->r5);
    // 0x802B6DCC: mflo        $t8
    ctx->r24 = lo;
    // 0x802B6DD0: nop

    // 0x802B6DD4: nop

    // 0x802B6DD8: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6DDC: mflo        $t9
    ctx->r25 = lo;
    // 0x802B6DE0: nop

    // 0x802B6DE4: nop

    // 0x802B6DE8: multu       $a0, $a0
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6DEC: mflo        $t6
    ctx->r14 = lo;
    // 0x802B6DF0: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x802B6DF4: slt         $at, $t8, $t7
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802B6DF8: beq         $at, $zero, L_802B6E60
    if (ctx->r1 == 0) {
        // 0x802B6DFC: nop
    
            goto L_802B6E60;
    }
    // 0x802B6DFC: nop

    // 0x802B6E00: b           L_802B6E60
    // 0x802B6E04: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
        goto L_802B6E60;
    // 0x802B6E04: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_802B6E08:
    // 0x802B6E08: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6E0C: addu        $t9, $s1, $t5
    ctx->r25 = ADD32(ctx->r17, ctx->r13);
    // 0x802B6E10: subu        $t6, $t9, $s3
    ctx->r14 = SUB32(ctx->r25, ctx->r19);
    // 0x802B6E14: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6E18: addu        $v1, $t6, $a2
    ctx->r3 = ADD32(ctx->r14, ctx->r6);
    // 0x802B6E1C: addu        $t8, $s2, $t4
    ctx->r24 = ADD32(ctx->r18, ctx->r12);
    // 0x802B6E20: subu        $t7, $t8, $s4
    ctx->r15 = SUB32(ctx->r24, ctx->r20);
    // 0x802B6E24: addu        $a0, $t7, $a1
    ctx->r4 = ADD32(ctx->r15, ctx->r5);
    // 0x802B6E28: mflo        $t9
    ctx->r25 = lo;
    // 0x802B6E2C: nop

    // 0x802B6E30: nop

    // 0x802B6E34: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6E38: mflo        $t6
    ctx->r14 = lo;
    // 0x802B6E3C: nop

    // 0x802B6E40: nop

    // 0x802B6E44: multu       $a0, $a0
    result = U64(U32(ctx->r4)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B6E48: mflo        $t8
    ctx->r24 = lo;
    // 0x802B6E4C: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x802B6E50: slt         $at, $t9, $t7
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x802B6E54: beq         $at, $zero, L_802B6E60
    if (ctx->r1 == 0) {
        // 0x802B6E58: nop
    
            goto L_802B6E60;
    }
    // 0x802B6E58: nop

    // 0x802B6E5C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_802B6E60:
    // 0x802B6E60: beq         $s0, $zero, L_802B6F14
    if (ctx->r16 == 0) {
        // 0x802B6E64: subu        $v1, $t2, $s1
        ctx->r3 = SUB32(ctx->r10, ctx->r17);
            goto L_802B6F14;
    }
    // 0x802B6E64: subu        $v1, $t2, $s1
    ctx->r3 = SUB32(ctx->r10, ctx->r17);
    // 0x802B6E68: lh          $t8, 0xCC($t0)
    ctx->r24 = MEM_H(ctx->r8, 0XCC);
    // 0x802B6E6C: lhu         $a2, 0x42($s5)
    ctx->r6 = MEM_HU(ctx->r21, 0X42);
    // 0x802B6E70: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x802B6E74: addu        $t9, $t8, $fp
    ctx->r25 = ADD32(ctx->r24, ctx->r30);
    // 0x802B6E78: subu        $t7, $t9, $s7
    ctx->r15 = SUB32(ctx->r25, ctx->r23);
    // 0x802B6E7C: sra         $t6, $a2, 1
    ctx->r14 = S32(SIGNED(ctx->r6) >> 1);
    // 0x802B6E80: subu        $v0, $t7, $t6
    ctx->r2 = SUB32(ctx->r15, ctx->r14);
    // 0x802B6E84: bgez        $v0, L_802B6E94
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B6E88: or          $a2, $t6, $zero
        ctx->r6 = ctx->r14 | 0;
            goto L_802B6E94;
    }
    // 0x802B6E88: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x802B6E8C: b           L_802B6E98
    // 0x802B6E90: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
        goto L_802B6E98;
    // 0x802B6E90: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
L_802B6E94:
    // 0x802B6E94: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
L_802B6E98:
    // 0x802B6E98: bgez        $v1, L_802B6EA8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B6E9C: subu        $v0, $t3, $s2
        ctx->r2 = SUB32(ctx->r11, ctx->r18);
            goto L_802B6EA8;
    }
    // 0x802B6E9C: subu        $v0, $t3, $s2
    ctx->r2 = SUB32(ctx->r11, ctx->r18);
    // 0x802B6EA0: b           L_802B6EA8
    // 0x802B6EA4: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
        goto L_802B6EA8;
    // 0x802B6EA4: negu        $a1, $v1
    ctx->r5 = SUB32(0, ctx->r3);
L_802B6EA8:
    // 0x802B6EA8: bgez        $v0, L_802B6EB8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B6EAC: subu        $t8, $a1, $t5
        ctx->r24 = SUB32(ctx->r5, ctx->r13);
            goto L_802B6EB8;
    }
    // 0x802B6EAC: subu        $t8, $a1, $t5
    ctx->r24 = SUB32(ctx->r5, ctx->r13);
    // 0x802B6EB0: b           L_802B6EBC
    // 0x802B6EB4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802B6EBC;
    // 0x802B6EB4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802B6EB8:
    // 0x802B6EB8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_802B6EBC:
    // 0x802B6EBC: subu        $t6, $a0, $t4
    ctx->r14 = SUB32(ctx->r4, ctx->r12);
    // 0x802B6EC0: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B6EC4: beq         $at, $zero, L_802B6EE8
    if (ctx->r1 == 0) {
        // 0x802B6EC8: subu        $t9, $a3, $a2
        ctx->r25 = SUB32(ctx->r7, ctx->r6);
            goto L_802B6EE8;
    }
    // 0x802B6EC8: subu        $t9, $a3, $a2
    ctx->r25 = SUB32(ctx->r7, ctx->r6);
    // 0x802B6ECC: bgez        $v1, L_802B6EE0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802B6ED0: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802B6EE0;
    }
    // 0x802B6ED0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802B6ED4: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
    // 0x802B6ED8: b           L_802B6EFC
    // 0x802B6EDC: subu        $v1, $v0, $t5
    ctx->r3 = SUB32(ctx->r2, ctx->r13);
        goto L_802B6EFC;
    // 0x802B6EDC: subu        $v1, $v0, $t5
    ctx->r3 = SUB32(ctx->r2, ctx->r13);
L_802B6EE0:
    // 0x802B6EE0: b           L_802B6EFC
    // 0x802B6EE4: subu        $v1, $v0, $t5
    ctx->r3 = SUB32(ctx->r2, ctx->r13);
        goto L_802B6EFC;
    // 0x802B6EE4: subu        $v1, $v0, $t5
    ctx->r3 = SUB32(ctx->r2, ctx->r13);
L_802B6EE8:
    // 0x802B6EE8: bgez        $v0, L_802B6EF8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802B6EEC: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_802B6EF8;
    }
    // 0x802B6EEC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x802B6EF0: b           L_802B6EF8
    // 0x802B6EF4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_802B6EF8;
    // 0x802B6EF4: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_802B6EF8:
    // 0x802B6EF8: subu        $v1, $a0, $t4
    ctx->r3 = SUB32(ctx->r4, ctx->r12);
L_802B6EFC:
    // 0x802B6EFC: slt         $at, $t9, $v1
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B6F00: beq         $at, $zero, L_802B6F10
    if (ctx->r1 == 0) {
        // 0x802B6F04: addiu       $t7, $zero, 0x1
        ctx->r15 = ADD32(0, 0X1);
            goto L_802B6F10;
    }
    // 0x802B6F04: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B6F08: b           L_802B6F14
    // 0x802B6F0C: sb          $t7, 0x0($ra)
    MEM_B(0X0, ctx->r31) = ctx->r15;
        goto L_802B6F14;
    // 0x802B6F0C: sb          $t7, 0x0($ra)
    MEM_B(0X0, ctx->r31) = ctx->r15;
L_802B6F10:
    // 0x802B6F10: sb          $zero, 0x0($ra)
    MEM_B(0X0, ctx->r31) = 0;
L_802B6F14:
    // 0x802B6F14: addiu       $s6, $s6, 0x10
    ctx->r22 = ADD32(ctx->r22, 0X10);
    // 0x802B6F18: bne         $s0, $zero, L_802B6F38
    if (ctx->r16 != 0) {
        // 0x802B6F1C: addiu       $t0, $t0, 0x10
        ctx->r8 = ADD32(ctx->r8, 0X10);
            goto L_802B6F38;
    }
    // 0x802B6F1C: addiu       $t0, $t0, 0x10
    ctx->r8 = ADD32(ctx->r8, 0X10);
    // 0x802B6F20: slti        $at, $s6, 0x50
    ctx->r1 = SIGNED(ctx->r22) < 0X50 ? 1 : 0;
    // 0x802B6F24: beql        $at, $zero, L_802B6F3C
    if (ctx->r1 == 0) {
        // 0x802B6F28: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802B6F3C;
    }
    goto skip_5;
    // 0x802B6F28: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_5:
    // 0x802B6F2C: lw          $v0, 0xD0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0XD0);
    // 0x802B6F30: bnel        $v0, $zero, L_802B6BD8
    if (ctx->r2 != 0) {
        // 0x802B6F34: lh          $t8, 0x30($s5)
        ctx->r24 = MEM_H(ctx->r21, 0X30);
            goto L_802B6BD8;
    }
    goto skip_6;
    // 0x802B6F34: lh          $t8, 0x30($s5)
    ctx->r24 = MEM_H(ctx->r21, 0X30);
    skip_6:
L_802B6F38:
    // 0x802B6F38: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802B6F3C:
    // 0x802B6F3C: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x802B6F40: lw          $s0, 0x8($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X8);
    // 0x802B6F44: lw          $s1, 0xC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XC);
    // 0x802B6F48: lw          $s2, 0x10($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X10);
    // 0x802B6F4C: lw          $s3, 0x14($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X14);
    // 0x802B6F50: lw          $s4, 0x18($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X18);
    // 0x802B6F54: lw          $s5, 0x1C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X1C);
    // 0x802B6F58: lw          $s6, 0x20($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X20);
    // 0x802B6F5C: lw          $s7, 0x24($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X24);
    // 0x802B6F60: lw          $fp, 0x28($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X28);
    // 0x802B6F64: jr          $ra
    // 0x802B6F68: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x802B6F68: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void func_802B6F6C_6C861C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B6F6C: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802B6F70: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x802B6F74: lw          $t6, 0x16C($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X16C);
    // 0x802B6F78: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6F7C: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
    // 0x802B6F80: lw          $t4, 0x18($t6)
    ctx->r12 = MEM_W(ctx->r14, 0X18);
    // 0x802B6F84: sw          $zero, 0x60F8($at)
    MEM_W(0X60F8, ctx->r1) = 0;
    // 0x802B6F88: sw          $zero, 0x60FC($at)
    MEM_W(0X60FC, ctx->r1) = 0;
    // 0x802B6F8C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B6F90: sw          $zero, 0x6100($at)
    MEM_W(0X6100, ctx->r1) = 0;
    // 0x802B6F94: lhu         $t2, 0x40($a1)
    ctx->r10 = MEM_HU(ctx->r5, 0X40);
    // 0x802B6F98: lhu         $t9, 0x42($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X42);
    // 0x802B6F9C: sll         $t7, $t2, 6
    ctx->r15 = S32(ctx->r10 << 6);
    // 0x802B6FA0: sra         $t2, $t7, 11
    ctx->r10 = S32(SIGNED(ctx->r15) >> 11);
    // 0x802B6FA4: lw          $t7, 0x50($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X50);
    // 0x802B6FA8: sll         $t6, $t9, 15
    ctx->r14 = S32(ctx->r25 << 15);
    // 0x802B6FAC: lw          $t9, 0x5C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X5C);
    // 0x802B6FB0: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B6FB4: lhu         $t7, 0x42($a1)
    ctx->r15 = MEM_HU(ctx->r5, 0X42);
    // 0x802B6FB8: subu        $t6, $t8, $t9
    ctx->r14 = SUB32(ctx->r24, ctx->r25);
    // 0x802B6FBC: lw          $t9, 0x48($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X48);
    // 0x802B6FC0: sll         $t8, $t7, 15
    ctx->r24 = S32(ctx->r15 << 15);
    // 0x802B6FC4: lw          $t7, 0x54($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X54);
    // 0x802B6FC8: subu        $t5, $t6, $t8
    ctx->r13 = SUB32(ctx->r14, ctx->r24);
    // 0x802B6FCC: subu        $t6, $t9, $t7
    ctx->r14 = SUB32(ctx->r25, ctx->r15);
    // 0x802B6FD0: sra         $t8, $t6, 11
    ctx->r24 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802B6FD4: div         $zero, $t8, $t2
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r10)));
    // 0x802B6FD8: mflo        $v0
    ctx->r2 = lo;
    // 0x802B6FDC: lw          $t6, 0x58($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X58);
    // 0x802B6FE0: lw          $t7, 0x4C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X4C);
    // 0x802B6FE4: addiu       $v0, $v0, 0x10
    ctx->r2 = ADD32(ctx->r2, 0X10);
    // 0x802B6FE8: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802B6FEC: bne         $t2, $zero, L_802B6FF8
    if (ctx->r10 != 0) {
        // 0x802B6FF0: nop
    
            goto L_802B6FF8;
    }
    // 0x802B6FF0: nop

    // 0x802B6FF4: break       7
    do_break(2150330356);
L_802B6FF8:
    // 0x802B6FF8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B6FFC: bne         $t2, $at, L_802B7010
    if (ctx->r10 != ctx->r1) {
        // 0x802B7000: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B7010;
    }
    // 0x802B7000: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B7004: bne         $t8, $at, L_802B7010
    if (ctx->r24 != ctx->r1) {
        // 0x802B7008: nop
    
            goto L_802B7010;
    }
    // 0x802B7008: nop

    // 0x802B700C: break       6
    do_break(2150330380);
L_802B7010:
    // 0x802B7010: sra         $t9, $t0, 16
    ctx->r25 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B7014: or          $t0, $t9, $zero
    ctx->r8 = ctx->r25 | 0;
    // 0x802B7018: subu        $t8, $t7, $t6
    ctx->r24 = SUB32(ctx->r15, ctx->r14);
    // 0x802B701C: sra         $t9, $t8, 11
    ctx->r25 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802B7020: div         $zero, $t9, $t2
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r10)));
    // 0x802B7024: mflo        $v1
    ctx->r3 = lo;
    // 0x802B7028: lh          $t8, 0x32($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X32);
    // 0x802B702C: lh          $t6, 0x30($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X30);
    // 0x802B7030: addiu       $v1, $v1, 0x10
    ctx->r3 = ADD32(ctx->r3, 0X10);
    // 0x802B7034: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x802B7038: bne         $t2, $zero, L_802B7044
    if (ctx->r10 != 0) {
        // 0x802B703C: nop
    
            goto L_802B7044;
    }
    // 0x802B703C: nop

    // 0x802B7040: break       7
    do_break(2150330432);
L_802B7044:
    // 0x802B7044: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B7048: bne         $t2, $at, L_802B705C
    if (ctx->r10 != ctx->r1) {
        // 0x802B704C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B705C;
    }
    // 0x802B704C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B7050: bne         $t9, $at, L_802B705C
    if (ctx->r25 != ctx->r1) {
        // 0x802B7054: nop
    
            goto L_802B705C;
    }
    // 0x802B7054: nop

    // 0x802B7058: break       6
    do_break(2150330456);
L_802B705C:
    // 0x802B705C: sra         $t7, $t1, 16
    ctx->r15 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802B7060: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
    // 0x802B7064: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802B7068: sll         $t7, $t9, 4
    ctx->r15 = S32(ctx->r25 << 4);
    // 0x802B706C: div         $zero, $t7, $t2
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r10)));
    // 0x802B7070: mflo        $t6
    ctx->r14 = lo;
    // 0x802B7074: sw          $t6, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r14;
    // 0x802B7078: bne         $t2, $zero, L_802B7084
    if (ctx->r10 != 0) {
        // 0x802B707C: nop
    
            goto L_802B7084;
    }
    // 0x802B707C: nop

    // 0x802B7080: break       7
    do_break(2150330496);
L_802B7084:
    // 0x802B7084: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B7088: bne         $t2, $at, L_802B709C
    if (ctx->r10 != ctx->r1) {
        // 0x802B708C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B709C;
    }
    // 0x802B708C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B7090: bne         $t7, $at, L_802B709C
    if (ctx->r15 != ctx->r1) {
        // 0x802B7094: nop
    
            goto L_802B709C;
    }
    // 0x802B7094: nop

    // 0x802B7098: break       6
    do_break(2150330520);
L_802B709C:
    // 0x802B709C: lh          $a0, 0x6($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X6);
    // 0x802B70A0: bgtz        $t6, L_802B70B0
    if (SIGNED(ctx->r14) > 0) {
        // 0x802B70A4: nop
    
            goto L_802B70B0;
    }
    // 0x802B70A4: nop

    // 0x802B70A8: b           L_802B70B0
    // 0x802B70AC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
        goto L_802B70B0;
    // 0x802B70AC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_802B70B0:
    // 0x802B70B0: lh          $t8, 0x2C($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X2C);
    // 0x802B70B4: addiu       $a2, $zero, 0x5A
    ctx->r6 = ADD32(0, 0X5A);
    // 0x802B70B8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802B70BC: beq         $t8, $a2, L_802B70E4
    if (ctx->r24 == ctx->r6) {
        // 0x802B70C0: or          $t9, $t8, $zero
        ctx->r25 = ctx->r24 | 0;
            goto L_802B70E4;
    }
    // 0x802B70C0: or          $t9, $t8, $zero
    ctx->r25 = ctx->r24 | 0;
    // 0x802B70C4: addiu       $at, $zero, 0xB4
    ctx->r1 = ADD32(0, 0XB4);
    // 0x802B70C8: beql        $t8, $at, L_802B7110
    if (ctx->r24 == ctx->r1) {
        // 0x802B70CC: or          $t6, $v0, $zero
        ctx->r14 = ctx->r2 | 0;
            goto L_802B7110;
    }
    goto skip_0;
    // 0x802B70CC: or          $t6, $v0, $zero
    ctx->r14 = ctx->r2 | 0;
    skip_0:
    // 0x802B70D0: addiu       $at, $zero, 0x10E
    ctx->r1 = ADD32(0, 0X10E);
    // 0x802B70D4: beql        $t8, $at, L_802B7144
    if (ctx->r24 == ctx->r1) {
        // 0x802B70D8: sh          $v0, 0x16($sp)
        MEM_H(0X16, ctx->r29) = ctx->r2;
            goto L_802B7144;
    }
    goto skip_1;
    // 0x802B70D8: sh          $v0, 0x16($sp)
    MEM_H(0X16, ctx->r29) = ctx->r2;
    skip_1:
    // 0x802B70DC: b           L_802B7168
    // 0x802B70E0: nop

        goto L_802B7168;
    // 0x802B70E0: nop

L_802B70E4:
    // 0x802B70E4: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x802B70E8: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B70EC: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x802B70F0: subu        $t0, $t8, $t6
    ctx->r8 = SUB32(ctx->r24, ctx->r14);
    // 0x802B70F4: sll         $t9, $t0, 16
    ctx->r25 = S32(ctx->r8 << 16);
    // 0x802B70F8: sh          $v0, 0x16($sp)
    MEM_H(0X16, ctx->r29) = ctx->r2;
    // 0x802B70FC: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B7100: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x802B7104: b           L_802B7168
    // 0x802B7108: lh          $t1, 0x16($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X16);
        goto L_802B7168;
    // 0x802B7108: lh          $t1, 0x16($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X16);
    // 0x802B710C: or          $t6, $v0, $zero
    ctx->r14 = ctx->r2 | 0;
L_802B7110:
    // 0x802B7110: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x802B7114: subu        $t0, $t9, $t6
    ctx->r8 = SUB32(ctx->r25, ctx->r14);
    // 0x802B7118: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x802B711C: sra         $t0, $t7, 16
    ctx->r8 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B7120: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x802B7124: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B7128: addiu       $t7, $zero, 0x20
    ctx->r15 = ADD32(0, 0X20);
    // 0x802B712C: subu        $t1, $t7, $t6
    ctx->r9 = SUB32(ctx->r15, ctx->r14);
    // 0x802B7130: sll         $t8, $t1, 16
    ctx->r24 = S32(ctx->r9 << 16);
    // 0x802B7134: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B7138: b           L_802B7168
    // 0x802B713C: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
        goto L_802B7168;
    // 0x802B713C: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x802B7140: sh          $v0, 0x16($sp)
    MEM_H(0X16, ctx->r29) = ctx->r2;
L_802B7144:
    // 0x802B7144: lh          $t6, 0x16($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X16);
    // 0x802B7148: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x802B714C: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x802B7150: sra         $t7, $t0, 16
    ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B7154: subu        $t1, $t8, $t6
    ctx->r9 = SUB32(ctx->r24, ctx->r14);
    // 0x802B7158: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x802B715C: sll         $t9, $t1, 16
    ctx->r25 = S32(ctx->r9 << 16);
    // 0x802B7160: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B7164: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
L_802B7168:
    // 0x802B7168: bltzl       $t0, L_802B7298
    if (SIGNED(ctx->r8) < 0) {
        // 0x802B716C: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_2;
    // 0x802B716C: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_2:
    // 0x802B7170: slti        $at, $t0, 0x20
    ctx->r1 = SIGNED(ctx->r8) < 0X20 ? 1 : 0;
    // 0x802B7174: beql        $at, $zero, L_802B7298
    if (ctx->r1 == 0) {
        // 0x802B7178: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_3;
    // 0x802B7178: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_3:
    // 0x802B717C: bltzl       $t1, L_802B7298
    if (SIGNED(ctx->r9) < 0) {
        // 0x802B7180: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_4;
    // 0x802B7180: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_4:
    // 0x802B7184: slti        $at, $t1, 0x20
    ctx->r1 = SIGNED(ctx->r9) < 0X20 ? 1 : 0;
    // 0x802B7188: beql        $at, $zero, L_802B7298
    if (ctx->r1 == 0) {
        // 0x802B718C: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_5;
    // 0x802B718C: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_5:
    // 0x802B7190: sra         $t8, $t5, 11
    ctx->r24 = S32(SIGNED(ctx->r13) >> 11);
    // 0x802B7194: div         $zero, $t8, $t2
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r10)));
    // 0x802B7198: mflo        $v1
    ctx->r3 = lo;
    // 0x802B719C: addiu       $v1, $v1, 0x10
    ctx->r3 = ADD32(ctx->r3, 0X10);
    // 0x802B71A0: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x802B71A4: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B71A8: addu        $v0, $t9, $a0
    ctx->r2 = ADD32(ctx->r25, ctx->r4);
    // 0x802B71AC: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802B71B0: bne         $t2, $zero, L_802B71BC
    if (ctx->r10 != 0) {
        // 0x802B71B4: nop
    
            goto L_802B71BC;
    }
    // 0x802B71B4: nop

    // 0x802B71B8: break       7
    do_break(2150330808);
L_802B71BC:
    // 0x802B71BC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B71C0: bne         $t2, $at, L_802B71D4
    if (ctx->r10 != ctx->r1) {
        // 0x802B71C4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B71D4;
    }
    // 0x802B71C4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B71C8: bne         $t8, $at, L_802B71D4
    if (ctx->r24 != ctx->r1) {
        // 0x802B71CC: nop
    
            goto L_802B71D4;
    }
    // 0x802B71CC: nop

    // 0x802B71D0: break       6
    do_break(2150330832);
L_802B71D4:
    // 0x802B71D4: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B71D8: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x802B71DC: bltz        $t8, L_802B7230
    if (SIGNED(ctx->r24) < 0) {
        // 0x802B71E0: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_802B7230;
    }
    // 0x802B71E0: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x802B71E4: slti        $at, $t8, 0x20
    ctx->r1 = SIGNED(ctx->r24) < 0X20 ? 1 : 0;
    // 0x802B71E8: beq         $at, $zero, L_802B7230
    if (ctx->r1 == 0) {
        // 0x802B71EC: sll         $t6, $t0, 2
        ctx->r14 = S32(ctx->r8 << 2);
            goto L_802B7230;
    }
    // 0x802B71EC: sll         $t6, $t0, 2
    ctx->r14 = S32(ctx->r8 << 2);
    // 0x802B71F0: or          $t7, $t1, $zero
    ctx->r15 = ctx->r9 | 0;
    // 0x802B71F4: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802B71F8: addu        $t9, $t4, $t6
    ctx->r25 = ADD32(ctx->r12, ctx->r14);
    // 0x802B71FC: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x802B7200: lw          $t7, 0x8($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X8);
    // 0x802B7204: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802B7208: sllv        $t8, $t9, $v0
    ctx->r24 = S32(ctx->r25 << (ctx->r2 & 31));
    // 0x802B720C: and         $t6, $t7, $t8
    ctx->r14 = ctx->r15 & ctx->r24;
    // 0x802B7210: beql        $t6, $zero, L_802B7234
    if (ctx->r14 == 0) {
        // 0x802B7214: subu        $v0, $v1, $a0
        ctx->r2 = SUB32(ctx->r3, ctx->r4);
            goto L_802B7234;
    }
    goto skip_6;
    // 0x802B7214: subu        $v0, $v1, $a0
    ctx->r2 = SUB32(ctx->r3, ctx->r4);
    skip_6:
    // 0x802B7218: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B721C: lh          $t9, 0x6100($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6100);
    // 0x802B7220: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7224: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B7228: addiu       $t7, $t9, 0x2
    ctx->r15 = ADD32(ctx->r25, 0X2);
    // 0x802B722C: sh          $t7, 0x6100($at)
    MEM_H(0X6100, ctx->r1) = ctx->r15;
L_802B7230:
    // 0x802B7230: subu        $v0, $v1, $a0
    ctx->r2 = SUB32(ctx->r3, ctx->r4);
L_802B7234:
    // 0x802B7234: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B7238: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B723C: bltz        $t6, L_802B7294
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B7240: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_802B7294;
    }
    // 0x802B7240: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x802B7244: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B7248: beql        $at, $zero, L_802B7298
    if (ctx->r1 == 0) {
        // 0x802B724C: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_7;
    // 0x802B724C: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_7:
    // 0x802B7250: sll         $t9, $t0, 2
    ctx->r25 = S32(ctx->r8 << 2);
    // 0x802B7254: or          $t8, $t1, $zero
    ctx->r24 = ctx->r9 | 0;
    // 0x802B7258: sll         $t6, $t8, 7
    ctx->r14 = S32(ctx->r24 << 7);
    // 0x802B725C: addu        $t7, $t4, $t9
    ctx->r15 = ADD32(ctx->r12, ctx->r25);
    // 0x802B7260: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x802B7264: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B7268: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B726C: sllv        $t6, $t7, $v0
    ctx->r14 = S32(ctx->r15 << (ctx->r2 & 31));
    // 0x802B7270: and         $t9, $t8, $t6
    ctx->r25 = ctx->r24 & ctx->r14;
    // 0x802B7274: beql        $t9, $zero, L_802B7298
    if (ctx->r25 == 0) {
        // 0x802B7278: sra         $t6, $t5, 11
        ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
            goto L_802B7298;
    }
    goto skip_8;
    // 0x802B7278: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    skip_8:
    // 0x802B727C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B7280: lh          $t7, 0x6100($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6100);
    // 0x802B7284: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7288: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B728C: addiu       $t8, $t7, -0x2
    ctx->r24 = ADD32(ctx->r15, -0X2);
    // 0x802B7290: sh          $t8, 0x6100($at)
    MEM_H(0X6100, ctx->r1) = ctx->r24;
L_802B7294:
    // 0x802B7294: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
L_802B7298:
    // 0x802B7298: div         $zero, $t6, $t2
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r10)));
    // 0x802B729C: mflo        $v1
    ctx->r3 = lo;
    // 0x802B72A0: addiu       $v1, $v1, 0x10
    ctx->r3 = ADD32(ctx->r3, 0X10);
    // 0x802B72A4: bne         $t2, $zero, L_802B72B0
    if (ctx->r10 != 0) {
        // 0x802B72A8: nop
    
            goto L_802B72B0;
    }
    // 0x802B72A8: nop

    // 0x802B72AC: break       7
    do_break(2150331052);
L_802B72B0:
    // 0x802B72B0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B72B4: bne         $t2, $at, L_802B72C8
    if (ctx->r10 != ctx->r1) {
        // 0x802B72B8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B72C8;
    }
    // 0x802B72B8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B72BC: bne         $t6, $at, L_802B72C8
    if (ctx->r14 != ctx->r1) {
        // 0x802B72C0: nop
    
            goto L_802B72C8;
    }
    // 0x802B72C0: nop

    // 0x802B72C4: break       6
    do_break(2150331076);
L_802B72C8:
    // 0x802B72C8: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x802B72CC: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B72D0: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x802B72D4: bltz        $t7, L_802B7454
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B72D8: slti        $at, $t7, 0x20
        ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
            goto L_802B7454;
    }
    // 0x802B72D8: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B72DC: beq         $at, $zero, L_802B7454
    if (ctx->r1 == 0) {
        // 0x802B72E0: nop
    
            goto L_802B7454;
    }
    // 0x802B72E0: nop

    // 0x802B72E4: bltz        $t0, L_802B73A0
    if (SIGNED(ctx->r8) < 0) {
        // 0x802B72E8: slti        $at, $t0, 0x20
        ctx->r1 = SIGNED(ctx->r8) < 0X20 ? 1 : 0;
            goto L_802B73A0;
    }
    // 0x802B72E8: slti        $at, $t0, 0x20
    ctx->r1 = SIGNED(ctx->r8) < 0X20 ? 1 : 0;
    // 0x802B72EC: beq         $at, $zero, L_802B73A0
    if (ctx->r1 == 0) {
        // 0x802B72F0: addu        $v0, $t1, $a0
        ctx->r2 = ADD32(ctx->r9, ctx->r4);
            goto L_802B73A0;
    }
    // 0x802B72F0: addu        $v0, $t1, $a0
    ctx->r2 = ADD32(ctx->r9, ctx->r4);
    // 0x802B72F4: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B72F8: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B72FC: bltz        $t6, L_802B734C
    if (SIGNED(ctx->r14) < 0) {
        // 0x802B7300: subu        $v0, $t1, $a0
        ctx->r2 = SUB32(ctx->r9, ctx->r4);
            goto L_802B734C;
    }
    // 0x802B7300: subu        $v0, $t1, $a0
    ctx->r2 = SUB32(ctx->r9, ctx->r4);
    // 0x802B7304: slti        $at, $t6, 0x20
    ctx->r1 = SIGNED(ctx->r14) < 0X20 ? 1 : 0;
    // 0x802B7308: beq         $at, $zero, L_802B734C
    if (ctx->r1 == 0) {
        // 0x802B730C: sll         $t9, $t0, 2
        ctx->r25 = S32(ctx->r8 << 2);
            goto L_802B734C;
    }
    // 0x802B730C: sll         $t9, $t0, 2
    ctx->r25 = S32(ctx->r8 << 2);
    // 0x802B7310: or          $t8, $t6, $zero
    ctx->r24 = ctx->r14 | 0;
    // 0x802B7314: sll         $t6, $t8, 7
    ctx->r14 = S32(ctx->r24 << 7);
    // 0x802B7318: addu        $t7, $t4, $t9
    ctx->r15 = ADD32(ctx->r12, ctx->r25);
    // 0x802B731C: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x802B7320: lw          $t8, 0x8($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X8);
    // 0x802B7324: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802B7328: sllv        $t6, $t7, $v1
    ctx->r14 = S32(ctx->r15 << (ctx->r3 & 31));
    // 0x802B732C: and         $t9, $t8, $t6
    ctx->r25 = ctx->r24 & ctx->r14;
    // 0x802B7330: beq         $t9, $zero, L_802B734C
    if (ctx->r25 == 0) {
        // 0x802B7334: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_802B734C;
    }
    // 0x802B7334: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B7338: lh          $t7, 0x60FC($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X60FC);
    // 0x802B733C: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7340: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B7344: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x802B7348: sh          $t8, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r24;
L_802B734C:
    // 0x802B734C: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x802B7350: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802B7354: bltz        $t9, L_802B73A0
    if (SIGNED(ctx->r25) < 0) {
        // 0x802B7358: slti        $at, $t9, 0x20
        ctx->r1 = SIGNED(ctx->r25) < 0X20 ? 1 : 0;
            goto L_802B73A0;
    }
    // 0x802B7358: slti        $at, $t9, 0x20
    ctx->r1 = SIGNED(ctx->r25) < 0X20 ? 1 : 0;
    // 0x802B735C: beq         $at, $zero, L_802B73A0
    if (ctx->r1 == 0) {
        // 0x802B7360: sll         $t7, $t0, 2
        ctx->r15 = S32(ctx->r8 << 2);
            goto L_802B73A0;
    }
    // 0x802B7360: sll         $t7, $t0, 2
    ctx->r15 = S32(ctx->r8 << 2);
    // 0x802B7364: or          $t6, $t9, $zero
    ctx->r14 = ctx->r25 | 0;
    // 0x802B7368: sll         $t9, $t6, 7
    ctx->r25 = S32(ctx->r14 << 7);
    // 0x802B736C: addu        $t8, $t4, $t7
    ctx->r24 = ADD32(ctx->r12, ctx->r15);
    // 0x802B7370: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x802B7374: lw          $t6, 0x8($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X8);
    // 0x802B7378: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802B737C: sllv        $t9, $t8, $v1
    ctx->r25 = S32(ctx->r24 << (ctx->r3 & 31));
    // 0x802B7380: and         $t7, $t6, $t9
    ctx->r15 = ctx->r14 & ctx->r25;
    // 0x802B7384: beq         $t7, $zero, L_802B73A0
    if (ctx->r15 == 0) {
        // 0x802B7388: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_802B73A0;
    }
    // 0x802B7388: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B738C: lh          $t8, 0x60FC($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60FC);
    // 0x802B7390: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7394: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B7398: addiu       $t6, $t8, -0x2
    ctx->r14 = ADD32(ctx->r24, -0X2);
    // 0x802B739C: sh          $t6, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r14;
L_802B73A0:
    // 0x802B73A0: bltz        $t1, L_802B7454
    if (SIGNED(ctx->r9) < 0) {
        // 0x802B73A4: slti        $at, $t1, 0x20
        ctx->r1 = SIGNED(ctx->r9) < 0X20 ? 1 : 0;
            goto L_802B7454;
    }
    // 0x802B73A4: slti        $at, $t1, 0x20
    ctx->r1 = SIGNED(ctx->r9) < 0X20 ? 1 : 0;
    // 0x802B73A8: beq         $at, $zero, L_802B7454
    if (ctx->r1 == 0) {
        // 0x802B73AC: addu        $v0, $t0, $a0
        ctx->r2 = ADD32(ctx->r8, ctx->r4);
            goto L_802B7454;
    }
    // 0x802B73AC: addu        $v0, $t0, $a0
    ctx->r2 = ADD32(ctx->r8, ctx->r4);
    // 0x802B73B0: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x802B73B4: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802B73B8: bltz        $t7, L_802B7404
    if (SIGNED(ctx->r15) < 0) {
        // 0x802B73BC: subu        $v0, $t0, $a0
        ctx->r2 = SUB32(ctx->r8, ctx->r4);
            goto L_802B7404;
    }
    // 0x802B73BC: subu        $v0, $t0, $a0
    ctx->r2 = SUB32(ctx->r8, ctx->r4);
    // 0x802B73C0: slti        $at, $t7, 0x20
    ctx->r1 = SIGNED(ctx->r15) < 0X20 ? 1 : 0;
    // 0x802B73C4: beq         $at, $zero, L_802B7404
    if (ctx->r1 == 0) {
        // 0x802B73C8: sll         $t8, $t7, 2
        ctx->r24 = S32(ctx->r15 << 2);
            goto L_802B7404;
    }
    // 0x802B73C8: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x802B73CC: addu        $t6, $t4, $t8
    ctx->r14 = ADD32(ctx->r12, ctx->r24);
    // 0x802B73D0: sll         $t7, $t1, 7
    ctx->r15 = S32(ctx->r9 << 7);
    // 0x802B73D4: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B73D8: lw          $t9, 0x8($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X8);
    // 0x802B73DC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B73E0: sllv        $t7, $t6, $v1
    ctx->r15 = S32(ctx->r14 << (ctx->r3 & 31));
    // 0x802B73E4: and         $t8, $t9, $t7
    ctx->r24 = ctx->r25 & ctx->r15;
    // 0x802B73E8: beq         $t8, $zero, L_802B7404
    if (ctx->r24 == 0) {
        // 0x802B73EC: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B7404;
    }
    // 0x802B73EC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B73F0: lh          $t6, 0x60F8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X60F8);
    // 0x802B73F4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B73F8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B73FC: addiu       $t9, $t6, 0x2
    ctx->r25 = ADD32(ctx->r14, 0X2);
    // 0x802B7400: sh          $t9, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r25;
L_802B7404:
    // 0x802B7404: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802B7408: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B740C: bltz        $t8, L_802B7454
    if (SIGNED(ctx->r24) < 0) {
        // 0x802B7410: slti        $at, $t8, 0x20
        ctx->r1 = SIGNED(ctx->r24) < 0X20 ? 1 : 0;
            goto L_802B7454;
    }
    // 0x802B7410: slti        $at, $t8, 0x20
    ctx->r1 = SIGNED(ctx->r24) < 0X20 ? 1 : 0;
    // 0x802B7414: beq         $at, $zero, L_802B7454
    if (ctx->r1 == 0) {
        // 0x802B7418: sll         $t6, $t8, 2
        ctx->r14 = S32(ctx->r24 << 2);
            goto L_802B7454;
    }
    // 0x802B7418: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x802B741C: addu        $t9, $t4, $t6
    ctx->r25 = ADD32(ctx->r12, ctx->r14);
    // 0x802B7420: sll         $t8, $t1, 7
    ctx->r24 = S32(ctx->r9 << 7);
    // 0x802B7424: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x802B7428: lw          $t7, 0x8($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X8);
    // 0x802B742C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802B7430: sllv        $t8, $t9, $v1
    ctx->r24 = S32(ctx->r25 << (ctx->r3 & 31));
    // 0x802B7434: and         $t6, $t7, $t8
    ctx->r14 = ctx->r15 & ctx->r24;
    // 0x802B7438: beq         $t6, $zero, L_802B7454
    if (ctx->r14 == 0) {
        // 0x802B743C: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_802B7454;
    }
    // 0x802B743C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B7440: lh          $t9, 0x60F8($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60F8);
    // 0x802B7444: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7448: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802B744C: addiu       $t7, $t9, -0x2
    ctx->r15 = ADD32(ctx->r25, -0X2);
    // 0x802B7450: sh          $t7, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r15;
L_802B7454:
    // 0x802B7454: beql        $t3, $zero, L_802B7504
    if (ctx->r11 == 0) {
        // 0x802B7458: or          $v0, $t3, $zero
        ctx->r2 = ctx->r11 | 0;
            goto L_802B7504;
    }
    goto skip_9;
    // 0x802B7458: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    skip_9:
    // 0x802B745C: lh          $t8, 0x2C($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X2C);
    // 0x802B7460: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B7464: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B7468: beq         $t8, $a2, L_802B748C
    if (ctx->r24 == ctx->r6) {
        // 0x802B746C: sw          $t8, 0x10($sp)
        MEM_W(0X10, ctx->r29) = ctx->r24;
            goto L_802B748C;
    }
    // 0x802B746C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802B7470: addiu       $at, $zero, 0xB4
    ctx->r1 = ADD32(0, 0XB4);
    // 0x802B7474: beq         $t8, $at, L_802B74A8
    if (ctx->r24 == ctx->r1) {
        // 0x802B7478: addiu       $at, $zero, 0x10E
        ctx->r1 = ADD32(0, 0X10E);
            goto L_802B74A8;
    }
    // 0x802B7478: addiu       $at, $zero, 0x10E
    ctx->r1 = ADD32(0, 0X10E);
    // 0x802B747C: beq         $t8, $at, L_802B74D0
    if (ctx->r24 == ctx->r1) {
        // 0x802B7480: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802B74D0;
    }
    // 0x802B7480: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B7484: b           L_802B74F0
    // 0x802B7488: lw          $t9, 0x40($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X40);
        goto L_802B74F0;
    // 0x802B7488: lw          $t9, 0x40($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X40);
L_802B748C:
    // 0x802B748C: lh          $v0, 0x60F8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X60F8);
    // 0x802B7490: lh          $t9, 0x60FC($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60FC);
    // 0x802B7494: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B7498: negu        $t7, $v0
    ctx->r15 = SUB32(0, ctx->r2);
    // 0x802B749C: sh          $t7, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r15;
    // 0x802B74A0: b           L_802B74EC
    // 0x802B74A4: sh          $t9, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r25;
        goto L_802B74EC;
    // 0x802B74A4: sh          $t9, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r25;
L_802B74A8:
    // 0x802B74A8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B74AC: lh          $t8, 0x60F8($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60F8);
    // 0x802B74B0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B74B4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B74B8: negu        $t6, $t8
    ctx->r14 = SUB32(0, ctx->r24);
    // 0x802B74BC: sh          $t6, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r14;
    // 0x802B74C0: lh          $t9, 0x60FC($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X60FC);
    // 0x802B74C4: negu        $t7, $t9
    ctx->r15 = SUB32(0, ctx->r25);
    // 0x802B74C8: b           L_802B74EC
    // 0x802B74CC: sh          $t7, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r15;
        goto L_802B74EC;
    // 0x802B74CC: sh          $t7, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r15;
L_802B74D0:
    // 0x802B74D0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B74D4: lh          $t8, 0x60FC($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X60FC);
    // 0x802B74D8: lh          $v0, 0x60F8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X60F8);
    // 0x802B74DC: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x802B74E0: negu        $t6, $t8
    ctx->r14 = SUB32(0, ctx->r24);
    // 0x802B74E4: sh          $t6, 0x60F8($at)
    MEM_H(0X60F8, ctx->r1) = ctx->r14;
    // 0x802B74E8: sh          $v0, 0x60FC($at)
    MEM_H(0X60FC, ctx->r1) = ctx->r2;
L_802B74EC:
    // 0x802B74EC: lw          $t9, 0x40($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X40);
L_802B74F0:
    // 0x802B74F0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B74F4: addiu       $v0, $v0, 0x60F8
    ctx->r2 = ADD32(ctx->r2, 0X60F8);
    // 0x802B74F8: sw          $v0, 0x0($t9)
    MEM_W(0X0, ctx->r25) = ctx->r2;
    // 0x802B74FC: sw          $v0, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r2;
    // 0x802B7500: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
L_802B7504:
    // 0x802B7504: jr          $ra
    // 0x802B7508: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x802B7508: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void func_802B750C_6C8BBC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B750C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802B7510: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802B7514: lh          $t7, 0x30($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X30);
    // 0x802B7518: lh          $t6, 0x30($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X30);
    // 0x802B751C: lh          $a3, 0x10($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X10);
    // 0x802B7520: lh          $t2, 0x1C($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X1C);
    // 0x802B7524: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x802B7528: lh          $t9, 0x32($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X32);
    // 0x802B752C: lh          $t8, 0x32($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X32);
    // 0x802B7530: subu        $t1, $a3, $v0
    ctx->r9 = SUB32(ctx->r7, ctx->r2);
    // 0x802B7534: slt         $a2, $t1, $t2
    ctx->r6 = SIGNED(ctx->r9) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802B7538: beq         $a2, $zero, L_802B756C
    if (ctx->r6 == 0) {
        // 0x802B753C: addu        $v1, $t8, $t9
        ctx->r3 = ADD32(ctx->r24, ctx->r25);
            goto L_802B756C;
    }
    // 0x802B753C: addu        $v1, $t8, $t9
    ctx->r3 = ADD32(ctx->r24, ctx->r25);
    // 0x802B7540: addu        $t3, $a3, $v0
    ctx->r11 = ADD32(ctx->r7, ctx->r2);
    // 0x802B7544: slt         $a2, $t2, $t3
    ctx->r6 = SIGNED(ctx->r10) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x802B7548: beq         $a2, $zero, L_802B756C
    if (ctx->r6 == 0) {
        // 0x802B754C: lh          $v0, 0x14($sp)
        ctx->r2 = MEM_H(ctx->r29, 0X14);
            goto L_802B756C;
    }
    // 0x802B754C: lh          $v0, 0x14($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X14);
    // 0x802B7550: lh          $a3, 0x20($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X20);
    // 0x802B7554: subu        $t4, $v0, $v1
    ctx->r12 = SUB32(ctx->r2, ctx->r3);
    // 0x802B7558: addu        $t5, $v0, $v1
    ctx->r13 = ADD32(ctx->r2, ctx->r3);
    // 0x802B755C: slt         $a2, $t4, $a3
    ctx->r6 = SIGNED(ctx->r12) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B7560: beql        $a2, $zero, L_802B7570
    if (ctx->r6 == 0) {
        // 0x802B7564: lh          $v1, 0x24($sp)
        ctx->r3 = MEM_H(ctx->r29, 0X24);
            goto L_802B7570;
    }
    goto skip_0;
    // 0x802B7564: lh          $v1, 0x24($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X24);
    skip_0:
    // 0x802B7568: slt         $a2, $a3, $t5
    ctx->r6 = SIGNED(ctx->r7) < SIGNED(ctx->r13) ? 1 : 0;
L_802B756C:
    // 0x802B756C: lh          $v1, 0x24($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X24);
L_802B7570:
    // 0x802B7570: lhu         $t6, 0x42($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X42);
    // 0x802B7574: lh          $a3, 0x18($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X18);
    // 0x802B7578: andi        $v0, $a2, 0xFF
    ctx->r2 = ctx->r6 & 0XFF;
    // 0x802B757C: subu        $t7, $v1, $t6
    ctx->r15 = SUB32(ctx->r3, ctx->r14);
    // 0x802B7580: slt         $a2, $t7, $a3
    ctx->r6 = SIGNED(ctx->r15) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802B7584: beql        $a2, $zero, L_802B759C
    if (ctx->r6 == 0) {
        // 0x802B7588: andi        $v1, $a2, 0xFF
        ctx->r3 = ctx->r6 & 0XFF;
            goto L_802B759C;
    }
    goto skip_1;
    // 0x802B7588: andi        $v1, $a2, 0xFF
    ctx->r3 = ctx->r6 & 0XFF;
    skip_1:
    // 0x802B758C: lhu         $t8, 0x42($a1)
    ctx->r24 = MEM_HU(ctx->r5, 0X42);
    // 0x802B7590: subu        $t9, $a3, $t8
    ctx->r25 = SUB32(ctx->r7, ctx->r24);
    // 0x802B7594: slt         $a2, $t9, $v1
    ctx->r6 = SIGNED(ctx->r25) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B7598: andi        $v1, $a2, 0xFF
    ctx->r3 = ctx->r6 & 0XFF;
L_802B759C:
    // 0x802B759C: sltu        $a2, $zero, $v0
    ctx->r6 = 0 < ctx->r2 ? 1 : 0;
    // 0x802B75A0: beq         $a2, $zero, L_802B75AC
    if (ctx->r6 == 0) {
        // 0x802B75A4: nop
    
            goto L_802B75AC;
    }
    // 0x802B75A4: nop

    // 0x802B75A8: sltu        $a2, $zero, $v1
    ctx->r6 = 0 < ctx->r3 ? 1 : 0;
L_802B75AC:
    // 0x802B75AC: jr          $ra
    // 0x802B75B0: andi        $v0, $a2, 0xFF
    ctx->r2 = ctx->r6 & 0XFF;
    return;
    // 0x802B75B0: andi        $v0, $a2, 0xFF
    ctx->r2 = ctx->r6 & 0XFF;
;}
RECOMP_FUNC void func_802B75B4_6C8C64(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B75B4: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802B75B8: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802B75BC: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802B75C0: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802B75C4: jr          $ra
    // 0x802B75C8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x802B75C8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
;}
RECOMP_FUNC void check_collision_against_animals_6C8C7C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    sssv_patch_trophy_collision_guard(rdram, ctx);
    // 0x802B75CC: addiu       $sp, $sp, -0x90
    ctx->r29 = ADD32(ctx->r29, -0X90);
    // 0x802B75D0: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802B75D4: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x802B75D8: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x802B75DC: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x802B75E0: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x802B75E4: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x802B75E8: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x802B75EC: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x802B75F0: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x802B75F4: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802B75F8: sw          $a1, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r5;
    // 0x802B75FC: sw          $a2, 0x98($sp)
    MEM_W(0X98, ctx->r29) = ctx->r6;
    // 0x802B7600: sw          $a3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r7;
    // 0x802B7604: lh          $v0, 0x114($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X114);
    // 0x802B7608: lui         $s5, 0x803E
    ctx->r21 = S32(0X803E << 16);
    // 0x802B760C: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x802B7610: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802B7614: subu        $t6, $t6, $v0
    ctx->r14 = SUB32(ctx->r14, ctx->r2);
    // 0x802B7618: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x802B761C: addu        $s5, $s5, $t6
    ctx->r21 = ADD32(ctx->r21, ctx->r14);
    // 0x802B7620: lw          $s5, -0x5EF0($s5)
    ctx->r21 = MEM_W(ctx->r21, -0X5EF0);
    // 0x802B7624: lui         $s6, 0x803D
    ctx->r22 = S32(0X803D << 16);
    // 0x802B7628: addiu       $s7, $sp, 0x7C
    ctx->r23 = ADD32(ctx->r29, 0X7C);
    // 0x802B762C: beq         $s5, $zero, L_802B7B94
    if (ctx->r21 == 0) {
        // 0x802B7630: addiu       $fp, $sp, 0x78
        ctx->r30 = ADD32(ctx->r29, 0X78);
            goto L_802B7B94;
    }
    // 0x802B7630: addiu       $fp, $sp, 0x78
    ctx->r30 = ADD32(ctx->r29, 0X78);
    // 0x802B7634: addiu       $s6, $s6, 0x60D0
    ctx->r22 = ADD32(ctx->r22, 0X60D0);
    // 0x802B7638: addiu       $a2, $zero, 0x4
    ctx->r6 = ADD32(0, 0X4);
    // 0x802B763C: lw          $v1, 0x8($s5)
    ctx->r3 = MEM_W(ctx->r21, 0X8);
L_802B7640:
    // 0x802B7640: lw          $t7, 0x94($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X94);
    // 0x802B7644: beql        $s1, $v1, L_802B7B88
    if (ctx->r17 == ctx->r3) {
        // 0x802B7648: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_0;
    // 0x802B7648: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_0:
    // 0x802B764C: beq         $s1, $t7, L_802B7B84
    if (ctx->r17 == ctx->r15) {
        // 0x802B7650: lui         $t1, 0x803B
        ctx->r9 = S32(0X803B << 16);
            goto L_802B7B84;
    }
    // 0x802B7650: lui         $t1, 0x803B
    ctx->r9 = S32(0X803B << 16);
    // 0x802B7654: lw          $t8, 0x16C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X16C);
    // 0x802B7658: lw          $t2, 0x16C($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X16C);
    // 0x802B765C: addiu       $t4, $zero, 0xF
    ctx->r12 = ADD32(0, 0XF);
    // 0x802B7660: lbu         $t9, 0x2($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X2);
    // 0x802B7664: lbu         $t3, 0x2($t2)
    ctx->r11 = MEM_BU(ctx->r10, 0X2);
    // 0x802B7668: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802B766C: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x802B7670: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x802B7674: lhu         $t1, 0x1BAC($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X1BAC);
    // 0x802B7678: subu        $t5, $t4, $t3
    ctx->r13 = SUB32(ctx->r12, ctx->r11);
    // 0x802B767C: sllv        $t7, $t6, $t5
    ctx->r15 = S32(ctx->r14 << (ctx->r13 & 31));
    // 0x802B7680: and         $t8, $t1, $t7
    ctx->r24 = ctx->r9 & ctx->r15;
    // 0x802B7684: beq         $t8, $zero, L_802B7B84
    if (ctx->r24 == 0) {
        // 0x802B7688: lw          $t9, 0x98($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X98);
            goto L_802B7B84;
    }
    // 0x802B7688: lw          $t9, 0x98($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X98);
    // 0x802B768C: sw          $t9, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r25;
    // 0x802B7690: lw          $v1, 0x8($s5)
    ctx->r3 = MEM_W(ctx->r21, 0X8);
    // 0x802B7694: lh          $t0, 0x7C($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7C);
    // 0x802B7698: lh          $t4, 0x7C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X7C);
    // 0x802B769C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x802B76A0: lw          $t1, 0x9C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X9C);
    // 0x802B76A4: subu        $t2, $a0, $t0
    ctx->r10 = SUB32(ctx->r4, ctx->r8);
    // 0x802B76A8: bgez        $t2, L_802B76BC
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802B76AC: subu        $v0, $a0, $t4
        ctx->r2 = SUB32(ctx->r4, ctx->r12);
            goto L_802B76BC;
    }
    // 0x802B76AC: subu        $v0, $a0, $t4
    ctx->r2 = SUB32(ctx->r4, ctx->r12);
    // 0x802B76B0: subu        $v0, $a0, $t0
    ctx->r2 = SUB32(ctx->r4, ctx->r8);
    // 0x802B76B4: b           L_802B76BC
    // 0x802B76B8: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
        goto L_802B76BC;
    // 0x802B76B8: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
L_802B76BC:
    // 0x802B76BC: lh          $t3, 0x34($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X34);
    // 0x802B76C0: lh          $t6, 0x34($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X34);
    // 0x802B76C4: addu        $t5, $t3, $t6
    ctx->r13 = ADD32(ctx->r11, ctx->r14);
    // 0x802B76C8: slt         $at, $v0, $t5
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B76CC: beql        $at, $zero, L_802B7B88
    if (ctx->r1 == 0) {
        // 0x802B76D0: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_1;
    // 0x802B76D0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_1:
    // 0x802B76D4: sw          $t1, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r9;
    // 0x802B76D8: lw          $v1, 0x8($s5)
    ctx->r3 = MEM_W(ctx->r21, 0X8);
    // 0x802B76DC: lh          $t7, 0x78($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X78);
    // 0x802B76E0: lh          $t9, 0x78($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X78);
    // 0x802B76E4: lh          $a0, 0x8($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X8);
    // 0x802B76E8: lw          $t3, 0xA0($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XA0);
    // 0x802B76EC: subu        $t8, $a0, $t7
    ctx->r24 = SUB32(ctx->r4, ctx->r15);
    // 0x802B76F0: bgez        $t8, L_802B7704
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802B76F4: subu        $v0, $a0, $t9
        ctx->r2 = SUB32(ctx->r4, ctx->r25);
            goto L_802B7704;
    }
    // 0x802B76F4: subu        $v0, $a0, $t9
    ctx->r2 = SUB32(ctx->r4, ctx->r25);
    // 0x802B76F8: subu        $v0, $a0, $t7
    ctx->r2 = SUB32(ctx->r4, ctx->r15);
    // 0x802B76FC: b           L_802B7704
    // 0x802B7700: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
        goto L_802B7704;
    // 0x802B7700: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
L_802B7704:
    // 0x802B7704: lh          $t2, 0x34($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X34);
    // 0x802B7708: lh          $t0, 0x34($s1)
    ctx->r8 = MEM_H(ctx->r17, 0X34);
    // 0x802B770C: addu        $t4, $t2, $t0
    ctx->r12 = ADD32(ctx->r10, ctx->r8);
    // 0x802B7710: slt         $at, $v0, $t4
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x802B7714: beql        $at, $zero, L_802B7B88
    if (ctx->r1 == 0) {
        // 0x802B7718: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_2;
    // 0x802B7718: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_2:
    // 0x802B771C: sw          $t3, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r11;
    // 0x802B7720: lw          $v1, 0x8($s5)
    ctx->r3 = MEM_W(ctx->r21, 0X8);
    // 0x802B7724: lh          $t7, 0x74($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X74);
    // 0x802B7728: lhu         $a1, 0x42($s1)
    ctx->r5 = MEM_HU(ctx->r17, 0X42);
    // 0x802B772C: lhu         $t5, 0x42($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X42);
    // 0x802B7730: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x802B7734: sra         $t8, $a1, 1
    ctx->r24 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B7738: sra         $t1, $t5, 1
    ctx->r9 = S32(SIGNED(ctx->r13) >> 1);
    // 0x802B773C: addu        $a0, $t6, $t1
    ctx->r4 = ADD32(ctx->r14, ctx->r9);
    // 0x802B7740: subu        $t9, $a0, $t7
    ctx->r25 = SUB32(ctx->r4, ctx->r15);
    // 0x802B7744: subu        $t2, $t9, $t8
    ctx->r10 = SUB32(ctx->r25, ctx->r24);
    // 0x802B7748: bgez        $t2, L_802B7760
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802B774C: or          $a1, $t8, $zero
        ctx->r5 = ctx->r24 | 0;
            goto L_802B7760;
    }
    // 0x802B774C: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802B7750: subu        $t0, $a0, $t7
    ctx->r8 = SUB32(ctx->r4, ctx->r15);
    // 0x802B7754: subu        $v0, $t0, $t8
    ctx->r2 = SUB32(ctx->r8, ctx->r24);
    // 0x802B7758: b           L_802B776C
    // 0x802B775C: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
        goto L_802B776C;
    // 0x802B775C: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
L_802B7760:
    // 0x802B7760: lh          $t4, 0x74($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X74);
    // 0x802B7764: subu        $t3, $a0, $t4
    ctx->r11 = SUB32(ctx->r4, ctx->r12);
    // 0x802B7768: subu        $v0, $t3, $a1
    ctx->r2 = SUB32(ctx->r11, ctx->r5);
L_802B776C:
    // 0x802B776C: lh          $t5, 0x36($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X36);
    // 0x802B7770: lh          $t6, 0x36($s1)
    ctx->r14 = MEM_H(ctx->r17, 0X36);
    // 0x802B7774: addu        $t1, $t5, $t6
    ctx->r9 = ADD32(ctx->r13, ctx->r14);
    // 0x802B7778: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x802B777C: beql        $at, $zero, L_802B7B88
    if (ctx->r1 == 0) {
        // 0x802B7780: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_3;
    // 0x802B7780: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_3:
    // 0x802B7784: lw          $t8, 0x68($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X68);
    // 0x802B7788: beql        $s1, $t8, L_802B7B88
    if (ctx->r17 == ctx->r24) {
        // 0x802B778C: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_4;
    // 0x802B778C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_4:
    // 0x802B7790: lw          $t9, 0x68($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X68);
    // 0x802B7794: beql        $v1, $t9, L_802B7B88
    if (ctx->r3 == ctx->r25) {
        // 0x802B7798: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_5;
    // 0x802B7798: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_5:
    // 0x802B779C: lw          $t2, 0x70($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X70);
    // 0x802B77A0: bnel        $s1, $t2, L_802B77BC
    if (ctx->r17 != ctx->r10) {
        // 0x802B77A4: lw          $t4, 0x70($s1)
        ctx->r12 = MEM_W(ctx->r17, 0X70);
            goto L_802B77BC;
    }
    goto skip_6;
    // 0x802B77A4: lw          $t4, 0x70($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X70);
    skip_6:
    // 0x802B77A8: lw          $t7, 0x16C($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X16C);
    // 0x802B77AC: lbu         $t0, 0x15($t7)
    ctx->r8 = MEM_BU(ctx->r15, 0X15);
    // 0x802B77B0: beql        $a2, $t0, L_802B7B88
    if (ctx->r6 == ctx->r8) {
        // 0x802B77B4: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_7;
    // 0x802B77B4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_7:
    // 0x802B77B8: lw          $t4, 0x70($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X70);
L_802B77BC:
    // 0x802B77BC: bnel        $v1, $t4, L_802B77D8
    if (ctx->r3 != ctx->r12) {
        // 0x802B77C0: lhu         $v0, 0x0($v1)
        ctx->r2 = MEM_HU(ctx->r3, 0X0);
            goto L_802B77D8;
    }
    goto skip_8;
    // 0x802B77C0: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    skip_8:
    // 0x802B77C4: lw          $t3, 0x16C($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X16C);
    // 0x802B77C8: lbu         $t5, 0x15($t3)
    ctx->r13 = MEM_BU(ctx->r11, 0X15);
    // 0x802B77CC: beql        $a2, $t5, L_802B7B88
    if (ctx->r6 == ctx->r13) {
        // 0x802B77D0: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_9;
    // 0x802B77D0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_9:
    // 0x802B77D4: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
L_802B77D8:
    // 0x802B77D8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802B77DC: beql        $v0, $at, L_802B7B88
    if (ctx->r2 == ctx->r1) {
        // 0x802B77E0: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_10;
    // 0x802B77E0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_10:
    // 0x802B77E4: lhu         $a0, 0x0($s1)
    ctx->r4 = MEM_HU(ctx->r17, 0X0);
    // 0x802B77E8: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x802B77EC: beq         $a0, $at, L_802B7B84
    if (ctx->r4 == ctx->r1) {
        // 0x802B77F0: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B7B84;
    }
    // 0x802B77F0: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B77F4: beq         $v0, $at, L_802B7B84
    if (ctx->r2 == ctx->r1) {
        // 0x802B77F8: addiu       $at, $zero, 0x1F
        ctx->r1 = ADD32(0, 0X1F);
            goto L_802B7B84;
    }
    // 0x802B77F8: addiu       $at, $zero, 0x1F
    ctx->r1 = ADD32(0, 0X1F);
    // 0x802B77FC: beql        $a0, $at, L_802B7B88
    if (ctx->r4 == ctx->r1) {
        // 0x802B7800: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_11;
    // 0x802B7800: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_11:
    // 0x802B7804: lbu         $t6, 0x15C($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X15C);
    // 0x802B7808: beql        $t6, $zero, L_802B7820
    if (ctx->r14 == 0) {
        // 0x802B780C: lbu         $t8, 0x15C($s1)
        ctx->r24 = MEM_BU(ctx->r17, 0X15C);
            goto L_802B7820;
    }
    goto skip_12;
    // 0x802B780C: lbu         $t8, 0x15C($s1)
    ctx->r24 = MEM_BU(ctx->r17, 0X15C);
    skip_12:
    // 0x802B7810: lw          $t1, 0x168($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X168);
    // 0x802B7814: beql        $s1, $t1, L_802B7B88
    if (ctx->r17 == ctx->r9) {
        // 0x802B7818: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_13;
    // 0x802B7818: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_13:
    // 0x802B781C: lbu         $t8, 0x15C($s1)
    ctx->r24 = MEM_BU(ctx->r17, 0X15C);
L_802B7820:
    // 0x802B7820: lhu         $t2, 0xAA($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0XAA);
    // 0x802B7824: beq         $t8, $zero, L_802B7838
    if (ctx->r24 == 0) {
        // 0x802B7828: nop
    
            goto L_802B7838;
    }
    // 0x802B7828: nop

    // 0x802B782C: lw          $t9, 0x168($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X168);
    // 0x802B7830: beql        $v1, $t9, L_802B7B88
    if (ctx->r3 == ctx->r25) {
        // 0x802B7834: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_14;
    // 0x802B7834: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_14:
L_802B7838:
    // 0x802B7838: beq         $t2, $zero, L_802B7850
    if (ctx->r10 == 0) {
        // 0x802B783C: or          $s0, $v1, $zero
        ctx->r16 = ctx->r3 | 0;
            goto L_802B7850;
    }
    // 0x802B783C: or          $s0, $v1, $zero
    ctx->r16 = ctx->r3 | 0;
    // 0x802B7840: lw          $t7, 0x16C($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X16C);
    // 0x802B7844: lhu         $t0, 0x0($t7)
    ctx->r8 = MEM_HU(ctx->r15, 0X0);
    // 0x802B7848: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x802B784C: beq         $at, $zero, L_802B7B84
    if (ctx->r1 == 0) {
        // 0x802B7850: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802B7B84;
    }
L_802B7850:
    // 0x802B7850: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B7854: addiu       $a3, $a3, 0x60D4
    ctx->r7 = ADD32(ctx->r7, 0X60D4);
    // 0x802B7858: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802B785C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B7860: jal         0x802B5E48
    // 0x802B7864: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    func_802B5E48_6C74F8(rdram, ctx);
        goto after_0;
    // 0x802B7864: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    after_0:
    // 0x802B7868: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B786C: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
    // 0x802B7870: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B7874: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B7878: beq         $v1, $zero, L_802B78DC
    if (ctx->r3 == 0) {
        // 0x802B787C: lui         $a2, 0x803D
        ctx->r6 = S32(0X803D << 16);
            goto L_802B78DC;
    }
    // 0x802B787C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B7880: lw          $at, 0x0($s7)
    ctx->r1 = MEM_W(ctx->r23, 0X0);
    // 0x802B7884: lw          $t1, 0x74($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X74);
    // 0x802B7888: addiu       $s2, $s0, 0x4
    ctx->r18 = ADD32(ctx->r16, 0X4);
    // 0x802B788C: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B7890: lw          $at, 0x0($fp)
    ctx->r1 = MEM_W(ctx->r30, 0X0);
    // 0x802B7894: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x802B7898: addiu       $s3, $s0, 0x8
    ctx->r19 = ADD32(ctx->r16, 0X8);
    // 0x802B789C: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B78A0: lw          $at, 0x0($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X0);
    // 0x802B78A4: lw          $t9, 0x0($s6)
    ctx->r25 = MEM_W(ctx->r22, 0X0);
    // 0x802B78A8: addiu       $s4, $s0, 0xC
    ctx->r20 = ADD32(ctx->r16, 0XC);
    // 0x802B78AC: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B78B0: lw          $at, 0x0($s3)
    ctx->r1 = MEM_W(ctx->r19, 0X0);
    // 0x802B78B4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B78B8: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B78BC: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B78C0: lw          $at, 0x0($s4)
    ctx->r1 = MEM_W(ctx->r20, 0X0);
    // 0x802B78C4: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B78C8: jalr        $t9
    // 0x802B78CC: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_1;
    // 0x802B78CC: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_1:
    // 0x802B78D0: bne         $v0, $zero, L_802B7944
    if (ctx->r2 != 0) {
        // 0x802B78D4: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B7944;
    }
    // 0x802B78D4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B78D8: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
L_802B78DC:
    // 0x802B78DC: bne         $v1, $zero, L_802B7B84
    if (ctx->r3 != 0) {
        // 0x802B78E0: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802B7B84;
    }
    // 0x802B78E0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B78E4: addiu       $s2, $s0, 0x4
    ctx->r18 = ADD32(ctx->r16, 0X4);
    // 0x802B78E8: lw          $at, 0x0($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X0);
    // 0x802B78EC: addiu       $s3, $s0, 0x8
    ctx->r19 = ADD32(ctx->r16, 0X8);
    // 0x802B78F0: addiu       $s4, $s0, 0xC
    ctx->r20 = ADD32(ctx->r16, 0XC);
    // 0x802B78F4: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B78F8: lw          $at, 0x0($s3)
    ctx->r1 = MEM_W(ctx->r19, 0X0);
    // 0x802B78FC: lw          $t9, 0x0($s6)
    ctx->r25 = MEM_W(ctx->r22, 0X0);
    // 0x802B7900: lw          $t3, 0x74($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X74);
    // 0x802B7904: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B7908: lw          $at, 0x0($s4)
    ctx->r1 = MEM_W(ctx->r20, 0X0);
    // 0x802B790C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B7910: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B7914: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B7918: lw          $at, 0x0($s7)
    ctx->r1 = MEM_W(ctx->r23, 0X0);
    // 0x802B791C: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B7920: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B7924: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B7928: lw          $at, 0x0($fp)
    ctx->r1 = MEM_W(ctx->r30, 0X0);
    // 0x802B792C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B7930: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x802B7934: jalr        $t9
    // 0x802B7938: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_2;
    // 0x802B7938: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    after_2:
    // 0x802B793C: beql        $v0, $zero, L_802B7B88
    if (ctx->r2 == 0) {
        // 0x802B7940: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_802B7B88;
    }
    goto skip_15;
    // 0x802B7940: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_15:
L_802B7944:
    // 0x802B7944: lw          $t5, 0x16C($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X16C);
    // 0x802B7948: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x802B794C: lbu         $v0, 0x2($t5)
    ctx->r2 = MEM_BU(ctx->r13, 0X2);
    // 0x802B7950: beq         $a0, $v0, L_802B7978
    if (ctx->r4 == ctx->r2) {
        // 0x802B7954: nop
    
            goto L_802B7978;
    }
    // 0x802B7954: nop

    // 0x802B7958: lw          $t6, 0x16C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X16C);
    // 0x802B795C: lbu         $v1, 0x2($t6)
    ctx->r3 = MEM_BU(ctx->r14, 0X2);
    // 0x802B7960: beq         $a0, $v1, L_802B7978
    if (ctx->r4 == ctx->r3) {
        // 0x802B7964: addiu       $a0, $zero, 0x8
        ctx->r4 = ADD32(0, 0X8);
            goto L_802B7978;
    }
    // 0x802B7964: addiu       $a0, $zero, 0x8
    ctx->r4 = ADD32(0, 0X8);
    // 0x802B7968: beq         $a0, $v0, L_802B7978
    if (ctx->r4 == ctx->r2) {
        // 0x802B796C: nop
    
            goto L_802B7978;
    }
    // 0x802B796C: nop

    // 0x802B7970: bne         $a0, $v1, L_802B7980
    if (ctx->r4 != ctx->r3) {
        // 0x802B7974: lw          $t1, 0x74($sp)
        ctx->r9 = MEM_W(ctx->r29, 0X74);
            goto L_802B7980;
    }
    // 0x802B7974: lw          $t1, 0x74($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X74);
L_802B7978:
    // 0x802B7978: b           L_802B7B98
    // 0x802B797C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_802B7B98;
    // 0x802B797C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802B7980:
    // 0x802B7980: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x802B7984: lw          $t8, 0x5B4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5B4);
    // 0x802B7988: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B798C: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
    // 0x802B7990: addu        $t2, $t1, $t8
    ctx->r10 = ADD32(ctx->r9, ctx->r24);
    // 0x802B7994: sw          $t2, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r10;
    // 0x802B7998: beq         $v1, $zero, L_802B79F8
    if (ctx->r3 == 0) {
        // 0x802B799C: nop
    
            goto L_802B79F8;
    }
    // 0x802B799C: nop

    // 0x802B79A0: lw          $at, 0x0($s7)
    ctx->r1 = MEM_W(ctx->r23, 0X0);
    // 0x802B79A4: lw          $t9, 0x0($s6)
    ctx->r25 = MEM_W(ctx->r22, 0X0);
    // 0x802B79A8: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B79AC: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B79B0: lw          $at, 0x0($fp)
    ctx->r1 = MEM_W(ctx->r30, 0X0);
    // 0x802B79B4: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x802B79B8: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B79BC: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B79C0: lw          $at, 0x0($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X0);
    // 0x802B79C4: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B79C8: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B79CC: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B79D0: lw          $at, 0x0($s3)
    ctx->r1 = MEM_W(ctx->r19, 0X0);
    // 0x802B79D4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B79D8: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B79DC: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B79E0: lw          $at, 0x0($s4)
    ctx->r1 = MEM_W(ctx->r20, 0X0);
    // 0x802B79E4: jalr        $t9
    // 0x802B79E8: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_3;
    // 0x802B79E8: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_3:
    // 0x802B79EC: bne         $v0, $zero, L_802B7A58
    if (ctx->r2 != 0) {
        // 0x802B79F0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B7A58;
    }
    // 0x802B79F0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B79F4: lbu         $v1, 0x60D4($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X60D4);
L_802B79F8:
    // 0x802B79F8: bnel        $v1, $zero, L_802B7AF4
    if (ctx->r3 != 0) {
        // 0x802B79FC: lw          $t4, 0xA4($sp)
        ctx->r12 = MEM_W(ctx->r29, 0XA4);
            goto L_802B7AF4;
    }
    goto skip_16;
    // 0x802B79FC: lw          $t4, 0xA4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XA4);
    skip_16:
    // 0x802B7A00: lw          $at, 0x0($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X0);
    // 0x802B7A04: lw          $t9, 0x0($s6)
    ctx->r25 = MEM_W(ctx->r22, 0X0);
    // 0x802B7A08: lw          $t0, 0x74($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X74);
    // 0x802B7A0C: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B7A10: lw          $at, 0x0($s3)
    ctx->r1 = MEM_W(ctx->r19, 0X0);
    // 0x802B7A14: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B7A18: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B7A1C: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B7A20: lw          $at, 0x0($s4)
    ctx->r1 = MEM_W(ctx->r20, 0X0);
    // 0x802B7A24: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B7A28: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B7A2C: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B7A30: lw          $at, 0x0($s7)
    ctx->r1 = MEM_W(ctx->r23, 0X0);
    // 0x802B7A34: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B7A38: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B7A3C: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B7A40: lw          $at, 0x0($fp)
    ctx->r1 = MEM_W(ctx->r30, 0X0);
    // 0x802B7A44: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x802B7A48: jalr        $t9
    // 0x802B7A4C: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_4;
    // 0x802B7A4C: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    after_4:
    // 0x802B7A50: beql        $v0, $zero, L_802B7AF4
    if (ctx->r2 == 0) {
        // 0x802B7A54: lw          $t4, 0xA4($sp)
        ctx->r12 = MEM_W(ctx->r29, 0XA4);
            goto L_802B7AF4;
    }
    goto skip_17;
    // 0x802B7A54: lw          $t4, 0xA4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XA4);
    skip_17:
L_802B7A58:
    // 0x802B7A58: lw          $t3, 0xA4($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XA4);
    // 0x802B7A5C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802B7A60: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B7A64: sb          $t4, 0x0($t3)
    MEM_B(0X0, ctx->r11) = ctx->r12;
    // 0x802B7A68: lh          $t5, 0x5534($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5534);
    // 0x802B7A6C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B7A70: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x802B7A74: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x802B7A78: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x802B7A7C: bne         $s1, $v0, L_802B7AB8
    if (ctx->r17 != ctx->r2) {
        // 0x802B7A80: nop
    
            goto L_802B7AB8;
    }
    // 0x802B7A80: nop

    // 0x802B7A84: lw          $t1, 0x16C($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X16C);
    // 0x802B7A88: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B7A8C: lhu         $t8, 0x0($t1)
    ctx->r24 = MEM_HU(ctx->r9, 0X0);
    // 0x802B7A90: bne         $t8, $at, L_802B7AB8
    if (ctx->r24 != ctx->r1) {
        // 0x802B7A94: nop
    
            goto L_802B7AB8;
    }
    // 0x802B7A94: nop

    // 0x802B7A98: jal         0x8038F5F8
    // 0x802B7A9C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_5;
    // 0x802B7A9C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_5:
    // 0x802B7AA0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B7AA4: lh          $t2, 0x5534($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X5534);
    // 0x802B7AA8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B7AAC: sll         $t7, $t2, 3
    ctx->r15 = S32(ctx->r10 << 3);
    // 0x802B7AB0: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802B7AB4: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
L_802B7AB8:
    // 0x802B7AB8: bnel        $s0, $v0, L_802B7AE0
    if (ctx->r16 != ctx->r2) {
        // 0x802B7ABC: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B7AE0;
    }
    goto skip_18;
    // 0x802B7ABC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_18:
    // 0x802B7AC0: lw          $t0, 0x16C($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X16C);
    // 0x802B7AC4: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B7AC8: lhu         $t9, 0x0($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0X0);
    // 0x802B7ACC: bnel        $t9, $at, L_802B7AE0
    if (ctx->r25 != ctx->r1) {
        // 0x802B7AD0: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B7AE0;
    }
    goto skip_19;
    // 0x802B7AD0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_19:
    // 0x802B7AD4: jal         0x8038F5F8
    // 0x802B7AD8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_6;
    // 0x802B7AD8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_6:
    // 0x802B7ADC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_802B7AE0:
    // 0x802B7AE0: jal         0x802FD674
    // 0x802B7AE4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    func_802FD674_70ED24(rdram, ctx);
        goto after_7;
    // 0x802B7AE4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_7:
    // 0x802B7AE8: b           L_802B7B98
    // 0x802B7AEC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B7B98;
    // 0x802B7AEC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802B7AF0: lw          $t4, 0xA4($sp)
    ctx->r12 = MEM_W(ctx->r29, 0XA4);
L_802B7AF4:
    // 0x802B7AF4: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x802B7AF8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B7AFC: sb          $zero, 0x0($t4)
    MEM_B(0X0, ctx->r12) = 0;
    // 0x802B7B00: lh          $t3, 0x5534($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X5534);
    // 0x802B7B04: sll         $t5, $t3, 3
    ctx->r13 = S32(ctx->r11 << 3);
    // 0x802B7B08: addu        $v0, $v0, $t5
    ctx->r2 = ADD32(ctx->r2, ctx->r13);
    // 0x802B7B0C: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x802B7B10: bne         $s1, $v0, L_802B7B4C
    if (ctx->r17 != ctx->r2) {
        // 0x802B7B14: nop
    
            goto L_802B7B4C;
    }
    // 0x802B7B14: nop

    // 0x802B7B18: lw          $t6, 0x16C($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X16C);
    // 0x802B7B1C: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B7B20: lhu         $t1, 0x0($t6)
    ctx->r9 = MEM_HU(ctx->r14, 0X0);
    // 0x802B7B24: bne         $t1, $at, L_802B7B4C
    if (ctx->r9 != ctx->r1) {
        // 0x802B7B28: nop
    
            goto L_802B7B4C;
    }
    // 0x802B7B28: nop

    // 0x802B7B2C: jal         0x8038F5F8
    // 0x802B7B30: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_8;
    // 0x802B7B30: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_8:
    // 0x802B7B34: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B7B38: lh          $t8, 0x5534($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5534);
    // 0x802B7B3C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x802B7B40: sll         $t2, $t8, 3
    ctx->r10 = S32(ctx->r24 << 3);
    // 0x802B7B44: addu        $v0, $v0, $t2
    ctx->r2 = ADD32(ctx->r2, ctx->r10);
    // 0x802B7B48: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
L_802B7B4C:
    // 0x802B7B4C: bnel        $s0, $v0, L_802B7B74
    if (ctx->r16 != ctx->r2) {
        // 0x802B7B50: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B7B74;
    }
    goto skip_20;
    // 0x802B7B50: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_20:
    // 0x802B7B54: lw          $t7, 0x16C($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X16C);
    // 0x802B7B58: addiu       $at, $zero, 0xF2
    ctx->r1 = ADD32(0, 0XF2);
    // 0x802B7B5C: lhu         $t0, 0x0($t7)
    ctx->r8 = MEM_HU(ctx->r15, 0X0);
    // 0x802B7B60: bnel        $t0, $at, L_802B7B74
    if (ctx->r8 != ctx->r1) {
        // 0x802B7B64: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B7B74;
    }
    goto skip_21;
    // 0x802B7B64: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_21:
    // 0x802B7B68: jal         0x8038F5F8
    // 0x802B7B6C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_8038F5F8_7A0CA8(rdram, ctx);
        goto after_9;
    // 0x802B7B6C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_9:
    // 0x802B7B70: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_802B7B74:
    // 0x802B7B74: jal         0x802FD674
    // 0x802B7B78: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    func_802FD674_70ED24(rdram, ctx);
        goto after_10;
    // 0x802B7B78: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_10:
    // 0x802B7B7C: b           L_802B7B98
    // 0x802B7B80: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_802B7B98;
    // 0x802B7B80: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802B7B84:
    // 0x802B7B84: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_802B7B88:
    // 0x802B7B88: addiu       $a2, $zero, 0x4
    ctx->r6 = ADD32(0, 0X4);
    // 0x802B7B8C: bnel        $s5, $zero, L_802B7640
    if (ctx->r21 != 0) {
        // 0x802B7B90: lw          $v1, 0x8($s5)
        ctx->r3 = MEM_W(ctx->r21, 0X8);
            goto L_802B7640;
    }
    goto skip_22;
    // 0x802B7B90: lw          $v1, 0x8($s5)
    ctx->r3 = MEM_W(ctx->r21, 0X8);
    skip_22:
L_802B7B94:
    // 0x802B7B94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802B7B98:
    // 0x802B7B98: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x802B7B9C: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802B7BA0: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x802B7BA4: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x802B7BA8: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x802B7BAC: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x802B7BB0: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x802B7BB4: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x802B7BB8: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x802B7BBC: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x802B7BC0: jr          $ra
    // 0x802B7BC4: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
    return;
    // 0x802B7BC4: addiu       $sp, $sp, 0x90
    ctx->r29 = ADD32(ctx->r29, 0X90);
;}
RECOMP_FUNC void func_802B7BC8_6C9278(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B7BC8: addiu       $sp, $sp, -0xD0
    ctx->r29 = ADD32(ctx->r29, -0XD0);
    // 0x802B7BCC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B7BD0: lw          $t7, 0x60D0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X60D0);
    // 0x802B7BD4: lui         $t6, 0x802B
    ctx->r14 = S32(0X802B << 16);
    // 0x802B7BD8: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x802B7BDC: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802B7BE0: addiu       $t6, $t6, 0x6088
    ctx->r14 = ADD32(ctx->r14, 0X6088);
    // 0x802B7BE4: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802B7BE8: or          $s1, $a1, $zero
    ctx->r17 = ctx->r5 | 0;
    // 0x802B7BEC: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802B7BF0: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x802B7BF4: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x802B7BF8: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x802B7BFC: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x802B7C00: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x802B7C04: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x802B7C08: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x802B7C0C: bne         $t7, $t6, L_802B7C74
    if (ctx->r15 != ctx->r14) {
        // 0x802B7C10: sw          $t6, 0x74($sp)
        MEM_W(0X74, ctx->r29) = ctx->r14;
            goto L_802B7C74;
    }
    // 0x802B7C10: sw          $t6, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r14;
    // 0x802B7C14: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B7C18: lbu         $t8, 0x60D4($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X60D4);
    // 0x802B7C1C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B7C20: beq         $t8, $zero, L_802B7C50
    if (ctx->r24 == 0) {
        // 0x802B7C24: nop
    
            goto L_802B7C50;
    }
    // 0x802B7C24: nop

    // 0x802B7C28: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B7C2C: lw          $v1, 0x60DC($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X60DC);
    // 0x802B7C30: lw          $s6, 0x8($v1)
    ctx->r22 = MEM_W(ctx->r3, 0X8);
    // 0x802B7C34: lw          $s4, 0x0($v1)
    ctx->r20 = MEM_W(ctx->r3, 0X0);
    // 0x802B7C38: lw          $s5, 0x4($v1)
    ctx->r21 = MEM_W(ctx->r3, 0X4);
    // 0x802B7C3C: negu        $t9, $s6
    ctx->r25 = SUB32(0, ctx->r22);
    // 0x802B7C40: sw          $t9, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r25;
    // 0x802B7C44: negu        $s7, $s4
    ctx->r23 = SUB32(0, ctx->r20);
    // 0x802B7C48: b           L_802B7E0C
    // 0x802B7C4C: negu        $fp, $s5
    ctx->r30 = SUB32(0, ctx->r21);
        goto L_802B7E0C;
    // 0x802B7C4C: negu        $fp, $s5
    ctx->r30 = SUB32(0, ctx->r21);
L_802B7C50:
    // 0x802B7C50: lw          $v1, 0x60DC($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X60DC);
    // 0x802B7C54: lw          $a2, 0x8($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X8);
    // 0x802B7C58: lw          $s7, 0x0($v1)
    ctx->r23 = MEM_W(ctx->r3, 0X0);
    // 0x802B7C5C: lw          $fp, 0x4($v1)
    ctx->r30 = MEM_W(ctx->r3, 0X4);
    // 0x802B7C60: negu        $s6, $a2
    ctx->r22 = SUB32(0, ctx->r6);
    // 0x802B7C64: sw          $a2, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r6;
    // 0x802B7C68: negu        $s4, $s7
    ctx->r20 = SUB32(0, ctx->r23);
    // 0x802B7C6C: b           L_802B7E0C
    // 0x802B7C70: negu        $s5, $fp
    ctx->r21 = SUB32(0, ctx->r30);
        goto L_802B7E0C;
    // 0x802B7C70: negu        $s5, $fp
    ctx->r21 = SUB32(0, ctx->r30);
L_802B7C74:
    // 0x802B7C74: lw          $t0, 0x4($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X4);
    // 0x802B7C78: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B7C7C: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x802B7C80: mtc1        $t0, $f4
    ctx->f4.u32l = ctx->r8;
    // 0x802B7C84: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x802B7C88: addiu       $s2, $sp, 0x9C
    ctx->r18 = ADD32(ctx->r29, 0X9C);
    // 0x802B7C8C: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B7C90: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    // 0x802B7C94: addiu       $a0, $sp, 0xA8
    ctx->r4 = ADD32(ctx->r29, 0XA8);
    // 0x802B7C98: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    // 0x802B7C9C: div.d       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f0.d); 
    ctx->f8.d = DIV_D(ctx->f6.d, ctx->f0.d);
    // 0x802B7CA0: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x802B7CA4: swc1        $f10, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->f10.u32l;
    // 0x802B7CA8: lw          $t1, 0x8($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X8);
    // 0x802B7CAC: mtc1        $t1, $f16
    ctx->f16.u32l = ctx->r9;
    // 0x802B7CB0: nop

    // 0x802B7CB4: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x802B7CB8: div.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f0.d);
    // 0x802B7CBC: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x802B7CC0: swc1        $f6, 0xB8($sp)
    MEM_W(0XB8, ctx->r29) = ctx->f6.u32l;
    // 0x802B7CC4: lhu         $t3, 0x42($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X42);
    // 0x802B7CC8: lw          $t2, 0xC($s0)
    ctx->r10 = MEM_W(ctx->r16, 0XC);
    // 0x802B7CCC: sll         $t4, $t3, 15
    ctx->r12 = S32(ctx->r11 << 15);
    // 0x802B7CD0: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x802B7CD4: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x802B7CD8: nop

    // 0x802B7CDC: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802B7CE0: div.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = DIV_D(ctx->f10.d, ctx->f0.d);
    // 0x802B7CE4: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x802B7CE8: swc1        $f18, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->f18.u32l;
    // 0x802B7CEC: lw          $t7, 0x4($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X4);
    // 0x802B7CF0: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802B7CF4: nop

    // 0x802B7CF8: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B7CFC: div.d       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f0.d); 
    ctx->f8.d = DIV_D(ctx->f6.d, ctx->f0.d);
    // 0x802B7D00: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x802B7D04: swc1        $f10, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->f10.u32l;
    // 0x802B7D08: lw          $t6, 0x8($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X8);
    // 0x802B7D0C: mtc1        $t6, $f16
    ctx->f16.u32l = ctx->r14;
    // 0x802B7D10: nop

    // 0x802B7D14: cvt.d.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.d = CVT_D_W(ctx->f16.u32l);
    // 0x802B7D18: div.d       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = DIV_D(ctx->f18.d, ctx->f0.d);
    // 0x802B7D1C: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x802B7D20: swc1        $f6, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->f6.u32l;
    // 0x802B7D24: lhu         $t9, 0x42($s1)
    ctx->r25 = MEM_HU(ctx->r17, 0X42);
    // 0x802B7D28: lw          $t8, 0xC($s1)
    ctx->r24 = MEM_W(ctx->r17, 0XC);
    // 0x802B7D2C: sll         $t0, $t9, 15
    ctx->r8 = S32(ctx->r25 << 15);
    // 0x802B7D30: addu        $t1, $t8, $t0
    ctx->r9 = ADD32(ctx->r24, ctx->r8);
    // 0x802B7D34: mtc1        $t1, $f8
    ctx->f8.u32l = ctx->r9;
    // 0x802B7D38: nop

    // 0x802B7D3C: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802B7D40: div.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = DIV_D(ctx->f10.d, ctx->f0.d);
    // 0x802B7D44: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x802B7D48: jal         0x8032D3B4
    // 0x802B7D4C: swc1        $f18, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->f18.u32l;
    vector_subtract(rdram, ctx);
        goto after_0;
    // 0x802B7D4C: swc1        $f18, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->f18.u32l;
    after_0:
    // 0x802B7D50: addiu       $s3, $sp, 0xC4
    ctx->r19 = ADD32(ctx->r29, 0XC4);
    // 0x802B7D54: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    // 0x802B7D58: jal         0x8032D494
    // 0x802B7D5C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    normalize_vector(rdram, ctx);
        goto after_1;
    // 0x802B7D5C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_1:
    // 0x802B7D60: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x802B7D64: lui         $a1, 0x4000
    ctx->r5 = S32(0X4000 << 16);
    // 0x802B7D68: jal         0x8032D3E8
    // 0x802B7D6C: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    vector_multiply_by(rdram, ctx);
        goto after_2;
    // 0x802B7D6C: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    after_2:
    // 0x802B7D70: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B7D74: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x802B7D78: lw          $at, 0x0($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X0);
    // 0x802B7D7C: lw          $t4, 0x4($s2)
    ctx->r12 = MEM_W(ctx->r18, 0X4);
    // 0x802B7D80: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x802B7D84: sw          $at, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->r1;
    // 0x802B7D88: lw          $at, 0x8($s2)
    ctx->r1 = MEM_W(ctx->r18, 0X8);
    // 0x802B7D8C: sw          $t4, 0x4($s3)
    MEM_W(0X4, ctx->r19) = ctx->r12;
    // 0x802B7D90: sw          $at, 0x8($s3)
    MEM_W(0X8, ctx->r19) = ctx->r1;
    // 0x802B7D94: lwc1        $f4, 0xC4($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0XC4);
    // 0x802B7D98: lwc1        $f18, 0xC8($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0XC8);
    // 0x802B7D9C: neg.s       $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = -ctx->f4.fl;
    // 0x802B7DA0: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x802B7DA4: neg.s       $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = -ctx->f18.fl;
    // 0x802B7DA8: mul.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = MUL_D(ctx->f8.d, ctx->f0.d);
    // 0x802B7DAC: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x802B7DB0: lwc1        $f6, 0xCC($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0XCC);
    // 0x802B7DB4: trunc.w.d   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_D(ctx->f10.d);
    // 0x802B7DB8: mul.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = MUL_D(ctx->f8.d, ctx->f0.d);
    // 0x802B7DBC: neg.s       $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = -ctx->f6.fl;
    // 0x802B7DC0: mfc1        $s4, $f16
    ctx->r20 = (int32_t)ctx->f16.u32l;
    // 0x802B7DC4: trunc.w.d   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_D(ctx->f10.d);
    // 0x802B7DC8: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x802B7DCC: mfc1        $s5, $f16
    ctx->r21 = (int32_t)ctx->f16.u32l;
    // 0x802B7DD0: mul.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f0.d);
    // 0x802B7DD4: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
    // 0x802B7DD8: cvt.d.s     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f4.d = CVT_D_S(ctx->f18.fl);
    // 0x802B7DDC: trunc.w.d   $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.u32l = TRUNC_W_D(ctx->f16.d);
    // 0x802B7DE0: mul.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = MUL_D(ctx->f10.d, ctx->f0.d);
    // 0x802B7DE4: mfc1        $s6, $f8
    ctx->r22 = (int32_t)ctx->f8.u32l;
    // 0x802B7DE8: mul.d       $f10, $f4, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = MUL_D(ctx->f4.d, ctx->f0.d);
    // 0x802B7DEC: trunc.w.d   $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.u32l = TRUNC_W_D(ctx->f16.d);
    // 0x802B7DF0: trunc.w.d   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_D(ctx->f10.d);
    // 0x802B7DF4: mfc1        $s7, $f8
    ctx->r23 = (int32_t)ctx->f8.u32l;
    // 0x802B7DF8: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x802B7DFC: mfc1        $fp, $f16
    ctx->r30 = (int32_t)ctx->f16.u32l;
    // 0x802B7E00: mul.d       $f18, $f8, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f18.d = MUL_D(ctx->f8.d, ctx->f0.d);
    // 0x802B7E04: trunc.w.d   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x802B7E08: swc1        $f4, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->f4.u32l;
L_802B7E0C:
    // 0x802B7E0C: lw          $v1, 0x16C($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X16C);
    // 0x802B7E10: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x802B7E14: lw          $t1, 0x80($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X80);
    // 0x802B7E18: sll         $t3, $t1, 17
    ctx->r11 = S32(ctx->r9 << 17);
    // 0x802B7E1C: bltz        $t3, L_802B7E58
    if (SIGNED(ctx->r11) < 0) {
        // 0x802B7E20: nop
    
            goto L_802B7E58;
    }
    // 0x802B7E20: nop

    // 0x802B7E24: lw          $t4, 0x4C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X4C);
    // 0x802B7E28: sll         $t7, $t4, 27
    ctx->r15 = S32(ctx->r12 << 27);
    // 0x802B7E2C: bgez        $t7, L_802B7E58
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802B7E30: nop
    
            goto L_802B7E58;
    }
    // 0x802B7E30: nop

    // 0x802B7E34: lb          $t6, 0x4A($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X4A);
    // 0x802B7E38: bne         $t6, $zero, L_802B7E58
    if (ctx->r14 != 0) {
        // 0x802B7E3C: nop
    
            goto L_802B7E58;
    }
    // 0x802B7E3C: nop

    // 0x802B7E40: bne         $s4, $zero, L_802B7E60
    if (ctx->r20 != 0) {
        // 0x802B7E44: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_802B7E60;
    }
    // 0x802B7E44: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802B7E48: bnel        $s5, $zero, L_802B7E64
    if (ctx->r21 != 0) {
        // 0x802B7E4C: sb          $t9, 0x82($sp)
        MEM_B(0X82, ctx->r29) = ctx->r25;
            goto L_802B7E64;
    }
    goto skip_0;
    // 0x802B7E4C: sb          $t9, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r25;
    skip_0:
    // 0x802B7E50: bnel        $s6, $zero, L_802B7E64
    if (ctx->r22 != 0) {
        // 0x802B7E54: sb          $t9, 0x82($sp)
        MEM_B(0X82, ctx->r29) = ctx->r25;
            goto L_802B7E64;
    }
    goto skip_1;
    // 0x802B7E54: sb          $t9, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r25;
    skip_1:
L_802B7E58:
    // 0x802B7E58: b           L_802B7E68
    // 0x802B7E5C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
        goto L_802B7E68;
    // 0x802B7E5C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_802B7E60:
    // 0x802B7E60: sb          $t9, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r25;
L_802B7E64:
    // 0x802B7E64: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
L_802B7E68:
    // 0x802B7E68: lw          $v0, 0x16C($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X16C);
    // 0x802B7E6C: lw          $t8, 0x80($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X80);
    // 0x802B7E70: sll         $t1, $t8, 17
    ctx->r9 = S32(ctx->r24 << 17);
    // 0x802B7E74: bltz        $t1, L_802B7EB0
    if (SIGNED(ctx->r9) < 0) {
        // 0x802B7E78: nop
    
            goto L_802B7EB0;
    }
    // 0x802B7E78: nop

    // 0x802B7E7C: lw          $t2, 0x4C($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X4C);
    // 0x802B7E80: sll         $t4, $t2, 27
    ctx->r12 = S32(ctx->r10 << 27);
    // 0x802B7E84: bgez        $t4, L_802B7EB0
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802B7E88: nop
    
            goto L_802B7EB0;
    }
    // 0x802B7E88: nop

    // 0x802B7E8C: lb          $t5, 0x4A($s1)
    ctx->r13 = MEM_B(ctx->r17, 0X4A);
    // 0x802B7E90: bne         $t5, $zero, L_802B7EB0
    if (ctx->r13 != 0) {
        // 0x802B7E94: nop
    
            goto L_802B7EB0;
    }
    // 0x802B7E94: nop

    // 0x802B7E98: bne         $s7, $zero, L_802B7EB8
    if (ctx->r23 != 0) {
        // 0x802B7E9C: addiu       $s3, $zero, 0x1
        ctx->r19 = ADD32(0, 0X1);
            goto L_802B7EB8;
    }
    // 0x802B7E9C: addiu       $s3, $zero, 0x1
    ctx->r19 = ADD32(0, 0X1);
    // 0x802B7EA0: bne         $fp, $zero, L_802B7EB8
    if (ctx->r30 != 0) {
        // 0x802B7EA4: lw          $t7, 0x84($sp)
        ctx->r15 = MEM_W(ctx->r29, 0X84);
            goto L_802B7EB8;
    }
    // 0x802B7EA4: lw          $t7, 0x84($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X84);
    // 0x802B7EA8: bne         $t7, $zero, L_802B7EB8
    if (ctx->r15 != 0) {
        // 0x802B7EAC: nop
    
            goto L_802B7EB8;
    }
    // 0x802B7EAC: nop

L_802B7EB0:
    // 0x802B7EB0: b           L_802B7EB8
    // 0x802B7EB4: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
        goto L_802B7EB8;
    // 0x802B7EB4: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
L_802B7EB8:
    // 0x802B7EB8: lhu         $t6, 0x0($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X0);
    // 0x802B7EBC: addiu       $a0, $zero, 0x13D
    ctx->r4 = ADD32(0, 0X13D);
    // 0x802B7EC0: bnel        $a0, $t6, L_802B7ED0
    if (ctx->r4 != ctx->r14) {
        // 0x802B7EC4: lhu         $t9, 0x0($v0)
        ctx->r25 = MEM_HU(ctx->r2, 0X0);
            goto L_802B7ED0;
    }
    goto skip_2;
    // 0x802B7EC4: lhu         $t9, 0x0($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X0);
    skip_2:
    // 0x802B7EC8: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    // 0x802B7ECC: lhu         $t9, 0x0($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X0);
L_802B7ED0:
    // 0x802B7ED0: bnel        $a0, $t9, L_802B7EE0
    if (ctx->r4 != ctx->r25) {
        // 0x802B7ED4: lhu         $v0, 0x44($s0)
        ctx->r2 = MEM_HU(ctx->r16, 0X44);
            goto L_802B7EE0;
    }
    goto skip_3;
    // 0x802B7ED4: lhu         $v0, 0x44($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X44);
    skip_3:
    // 0x802B7ED8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802B7EDC: lhu         $v0, 0x44($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X44);
L_802B7EE0:
    // 0x802B7EE0: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x802B7EE4: lhu         $v1, 0x44($s1)
    ctx->r3 = MEM_HU(ctx->r17, 0X44);
    // 0x802B7EE8: multu       $v0, $a0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B7EEC: mflo        $t8
    ctx->r24 = lo;
    // 0x802B7EF0: slt         $at, $t8, $v1
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B7EF4: beq         $at, $zero, L_802B7F0C
    if (ctx->r1 == 0) {
        // 0x802B7EF8: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802B7F0C;
    }
    // 0x802B7EF8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B7EFC: bne         $a1, $at, L_802B7F80
    if (ctx->r5 != ctx->r1) {
        // 0x802B7F00: nop
    
            goto L_802B7F80;
    }
    // 0x802B7F00: nop

    // 0x802B7F04: b           L_802B7F80
    // 0x802B7F08: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
        goto L_802B7F80;
    // 0x802B7F08: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
L_802B7F0C:
    // 0x802B7F0C: multu       $v1, $a0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B7F10: sll         $t1, $v0, 1
    ctx->r9 = S32(ctx->r2 << 1);
    // 0x802B7F14: mflo        $t0
    ctx->r8 = lo;
    // 0x802B7F18: slt         $at, $t0, $v0
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B7F1C: beq         $at, $zero, L_802B7F34
    if (ctx->r1 == 0) {
        // 0x802B7F20: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802B7F34;
    }
    // 0x802B7F20: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B7F24: bne         $s3, $at, L_802B7F80
    if (ctx->r19 != ctx->r1) {
        // 0x802B7F28: nop
    
            goto L_802B7F80;
    }
    // 0x802B7F28: nop

    // 0x802B7F2C: b           L_802B7F80
    // 0x802B7F30: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
        goto L_802B7F80;
    // 0x802B7F30: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_802B7F34:
    // 0x802B7F34: slt         $at, $t1, $v1
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B7F38: beq         $at, $zero, L_802B7F60
    if (ctx->r1 == 0) {
        // 0x802B7F3C: sll         $t7, $v1, 1
        ctx->r15 = S32(ctx->r3 << 1);
            goto L_802B7F60;
    }
    // 0x802B7F3C: sll         $t7, $v1, 1
    ctx->r15 = S32(ctx->r3 << 1);
    // 0x802B7F40: lw          $t4, 0x84($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X84);
    // 0x802B7F44: sra         $t2, $s7, 1
    ctx->r10 = S32(SIGNED(ctx->r23) >> 1);
    // 0x802B7F48: sra         $t3, $fp, 1
    ctx->r11 = S32(SIGNED(ctx->r30) >> 1);
    // 0x802B7F4C: sra         $t5, $t4, 1
    ctx->r13 = S32(SIGNED(ctx->r12) >> 1);
    // 0x802B7F50: or          $s7, $t2, $zero
    ctx->r23 = ctx->r10 | 0;
    // 0x802B7F54: or          $fp, $t3, $zero
    ctx->r30 = ctx->r11 | 0;
    // 0x802B7F58: b           L_802B7F80
    // 0x802B7F5C: sw          $t5, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r13;
        goto L_802B7F80;
    // 0x802B7F5C: sw          $t5, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r13;
L_802B7F60:
    // 0x802B7F60: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B7F64: beq         $at, $zero, L_802B7F80
    if (ctx->r1 == 0) {
        // 0x802B7F68: sra         $t6, $s4, 1
        ctx->r14 = S32(SIGNED(ctx->r20) >> 1);
            goto L_802B7F80;
    }
    // 0x802B7F68: sra         $t6, $s4, 1
    ctx->r14 = S32(SIGNED(ctx->r20) >> 1);
    // 0x802B7F6C: sra         $t9, $s5, 1
    ctx->r25 = S32(SIGNED(ctx->r21) >> 1);
    // 0x802B7F70: sra         $t8, $s6, 1
    ctx->r24 = S32(SIGNED(ctx->r22) >> 1);
    // 0x802B7F74: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
    // 0x802B7F78: or          $s5, $t9, $zero
    ctx->r21 = ctx->r25 | 0;
    // 0x802B7F7C: or          $s6, $t8, $zero
    ctx->r22 = ctx->r24 | 0;
L_802B7F80:
    // 0x802B7F80: bne         $a1, $zero, L_802B7F8C
    if (ctx->r5 != 0) {
        // 0x802B7F84: addiu       $a3, $zero, 0x1
        ctx->r7 = ADD32(0, 0X1);
            goto L_802B7F8C;
    }
    // 0x802B7F84: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x802B7F88: beq         $s3, $zero, L_802B8268
    if (ctx->r19 == 0) {
        // 0x802B7F8C: addiu       $t0, $s1, 0x4
        ctx->r8 = ADD32(ctx->r17, 0X4);
            goto L_802B8268;
    }
L_802B7F8C:
    // 0x802B7F8C: addiu       $t0, $s1, 0x4
    ctx->r8 = ADD32(ctx->r17, 0X4);
    // 0x802B7F90: addiu       $t1, $s1, 0x8
    ctx->r9 = ADD32(ctx->r17, 0X8);
    // 0x802B7F94: addiu       $t2, $s1, 0xC
    ctx->r10 = ADD32(ctx->r17, 0XC);
    // 0x802B7F98: addiu       $t3, $s0, 0x4
    ctx->r11 = ADD32(ctx->r16, 0X4);
    // 0x802B7F9C: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x802B7FA0: addiu       $t5, $s0, 0xC
    ctx->r13 = ADD32(ctx->r16, 0XC);
    // 0x802B7FA4: sw          $t5, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r13;
    // 0x802B7FA8: sw          $t4, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r12;
    // 0x802B7FAC: sw          $t3, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r11;
    // 0x802B7FB0: sw          $t2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r10;
    // 0x802B7FB4: sw          $t1, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r9;
    // 0x802B7FB8: sw          $t0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r8;
    // 0x802B7FBC: sb          $a1, 0x82($sp)
    MEM_B(0X82, ctx->r29) = ctx->r5;
    // 0x802B7FC0: lbu         $t7, 0x82($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X82);
L_802B7FC4:
    // 0x802B7FC4: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B7FC8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B7FCC: beq         $t7, $zero, L_802B8050
    if (ctx->r15 == 0) {
        // 0x802B7FD0: or          $a2, $s4, $zero
        ctx->r6 = ctx->r20 | 0;
            goto L_802B8050;
    }
    // 0x802B7FD0: or          $a2, $s4, $zero
    ctx->r6 = ctx->r20 | 0;
    // 0x802B7FD4: addiu       $t6, $sp, 0x80
    ctx->r14 = ADD32(ctx->r29, 0X80);
    // 0x802B7FD8: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802B7FDC: or          $a3, $s5, $zero
    ctx->r7 = ctx->r21 | 0;
    // 0x802B7FE0: sw          $s6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r22;
    // 0x802B7FE4: jal         0x802B75CC
    // 0x802B7FE8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    check_collision_against_animals_6C8C7C(rdram, ctx);
        goto after_3;
    // 0x802B7FE8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_3:
    // 0x802B7FEC: bne         $v0, $zero, L_802B804C
    if (ctx->r2 != 0) {
        // 0x802B7FF0: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_802B804C;
    }
    // 0x802B7FF0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B7FF4: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x802B7FF8: or          $a2, $s5, $zero
    ctx->r6 = ctx->r21 | 0;
    // 0x802B7FFC: jal         0x80313448
    // 0x802B8000: or          $a3, $s6, $zero
    ctx->r7 = ctx->r22 | 0;
    func_80313448_724AF8(rdram, ctx);
        goto after_4;
    // 0x802B8000: or          $a3, $s6, $zero
    ctx->r7 = ctx->r22 | 0;
    after_4:
    // 0x802B8004: beql        $v0, $zero, L_802B8050
    if (ctx->r2 == 0) {
        // 0x802B8008: sb          $zero, 0x82($sp)
        MEM_B(0X82, ctx->r29) = 0;
            goto L_802B8050;
    }
    goto skip_4;
    // 0x802B8008: sb          $zero, 0x82($sp)
    MEM_B(0X82, ctx->r29) = 0;
    skip_4:
    // 0x802B800C: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802B8010: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B8014: jal         0x80310EE4
    // 0x802B8018: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_5;
    // 0x802B8018: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    after_5:
    // 0x802B801C: lw          $v1, 0xC($s0)
    ctx->r3 = MEM_W(ctx->r16, 0XC);
    // 0x802B8020: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8024: beql        $at, $zero, L_802B8038
    if (ctx->r1 == 0) {
        // 0x802B8028: lh          $a0, 0x4($s0)
        ctx->r4 = MEM_H(ctx->r16, 0X4);
            goto L_802B8038;
    }
    goto skip_5;
    // 0x802B8028: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    skip_5:
    // 0x802B802C: b           L_802B8050
    // 0x802B8030: sw          $v1, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r3;
        goto L_802B8050;
    // 0x802B8030: sw          $v1, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r3;
    // 0x802B8034: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
L_802B8038:
    // 0x802B8038: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802B803C: jal         0x80310EE4
    // 0x802B8040: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_6;
    // 0x802B8040: lbu         $a2, 0x160($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X160);
    after_6:
    // 0x802B8044: b           L_802B8050
    // 0x802B8048: sw          $v0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r2;
        goto L_802B8050;
    // 0x802B8048: sw          $v0, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r2;
L_802B804C:
    // 0x802B804C: sb          $zero, 0x82($sp)
    MEM_B(0X82, ctx->r29) = 0;
L_802B8050:
    // 0x802B8050: beq         $s3, $zero, L_802B80E0
    if (ctx->r19 == 0) {
        // 0x802B8054: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B80E0;
    }
    // 0x802B8054: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B8058: lw          $t9, 0x84($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X84);
    // 0x802B805C: addiu       $t8, $sp, 0x80
    ctx->r24 = ADD32(ctx->r29, 0X80);
    // 0x802B8060: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x802B8064: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B8068: or          $a2, $s7, $zero
    ctx->r6 = ctx->r23 | 0;
    // 0x802B806C: or          $a3, $fp, $zero
    ctx->r7 = ctx->r30 | 0;
    // 0x802B8070: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802B8074: jal         0x802B75CC
    // 0x802B8078: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    check_collision_against_animals_6C8C7C(rdram, ctx);
        goto after_7;
    // 0x802B8078: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_7:
    // 0x802B807C: bne         $v0, $zero, L_802B80DC
    if (ctx->r2 != 0) {
        // 0x802B8080: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_802B80DC;
    }
    // 0x802B8080: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B8084: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    // 0x802B8088: or          $a2, $fp, $zero
    ctx->r6 = ctx->r30 | 0;
    // 0x802B808C: jal         0x80313448
    // 0x802B8090: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    func_80313448_724AF8(rdram, ctx);
        goto after_8;
    // 0x802B8090: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    after_8:
    // 0x802B8094: beql        $v0, $zero, L_802B80E0
    if (ctx->r2 == 0) {
        // 0x802B8098: or          $s3, $zero, $zero
        ctx->r19 = 0 | 0;
            goto L_802B80E0;
    }
    goto skip_6;
    // 0x802B8098: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    skip_6:
    // 0x802B809C: lh          $a0, 0x4($s1)
    ctx->r4 = MEM_H(ctx->r17, 0X4);
    // 0x802B80A0: lh          $a1, 0x8($s1)
    ctx->r5 = MEM_H(ctx->r17, 0X8);
    // 0x802B80A4: jal         0x80310EE4
    // 0x802B80A8: lbu         $a2, 0x160($s1)
    ctx->r6 = MEM_BU(ctx->r17, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_9;
    // 0x802B80A8: lbu         $a2, 0x160($s1)
    ctx->r6 = MEM_BU(ctx->r17, 0X160);
    after_9:
    // 0x802B80AC: lw          $v1, 0xC($s1)
    ctx->r3 = MEM_W(ctx->r17, 0XC);
    // 0x802B80B0: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B80B4: beql        $at, $zero, L_802B80C8
    if (ctx->r1 == 0) {
        // 0x802B80B8: lh          $a0, 0x4($s1)
        ctx->r4 = MEM_H(ctx->r17, 0X4);
            goto L_802B80C8;
    }
    goto skip_7;
    // 0x802B80B8: lh          $a0, 0x4($s1)
    ctx->r4 = MEM_H(ctx->r17, 0X4);
    skip_7:
    // 0x802B80BC: b           L_802B80E0
    // 0x802B80C0: sw          $v1, 0xC($s1)
    MEM_W(0XC, ctx->r17) = ctx->r3;
        goto L_802B80E0;
    // 0x802B80C0: sw          $v1, 0xC($s1)
    MEM_W(0XC, ctx->r17) = ctx->r3;
    // 0x802B80C4: lh          $a0, 0x4($s1)
    ctx->r4 = MEM_H(ctx->r17, 0X4);
L_802B80C8:
    // 0x802B80C8: lh          $a1, 0x8($s1)
    ctx->r5 = MEM_H(ctx->r17, 0X8);
    // 0x802B80CC: jal         0x80310EE4
    // 0x802B80D0: lbu         $a2, 0x160($s1)
    ctx->r6 = MEM_BU(ctx->r17, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_10;
    // 0x802B80D0: lbu         $a2, 0x160($s1)
    ctx->r6 = MEM_BU(ctx->r17, 0X160);
    after_10:
    // 0x802B80D4: b           L_802B80E0
    // 0x802B80D8: sw          $v0, 0xC($s1)
    MEM_W(0XC, ctx->r17) = ctx->r2;
        goto L_802B80E0;
    // 0x802B80D8: sw          $v0, 0xC($s1)
    MEM_W(0XC, ctx->r17) = ctx->r2;
L_802B80DC:
    // 0x802B80DC: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
L_802B80E0:
    // 0x802B80E0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B80E4: lbu         $t0, 0x60D4($t0)
    ctx->r8 = MEM_BU(ctx->r8, 0X60D4);
    // 0x802B80E8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B80EC: lw          $v0, 0x60D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X60D0);
    // 0x802B80F0: beq         $t0, $zero, L_802B8164
    if (ctx->r8 == 0) {
        // 0x802B80F4: lw          $t8, 0x64($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X64);
            goto L_802B8164;
    }
    // 0x802B80F4: lw          $t8, 0x64($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X64);
    // 0x802B80F8: lw          $t1, 0x70($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X70);
    // 0x802B80FC: lw          $t4, 0x6C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X6C);
    // 0x802B8100: lw          $t6, 0x68($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X68);
    // 0x802B8104: lw          $at, 0x0($t1)
    ctx->r1 = MEM_W(ctx->r9, 0X0);
    // 0x802B8108: lw          $t0, 0x64($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X64);
    // 0x802B810C: lw          $t3, 0x60($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X60);
    // 0x802B8110: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B8114: lw          $at, 0x0($t4)
    ctx->r1 = MEM_W(ctx->r12, 0X0);
    // 0x802B8118: lw          $t7, 0x5C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X5C);
    // 0x802B811C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B8120: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B8124: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x802B8128: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B812C: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B8130: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B8134: lw          $at, 0x0($t0)
    ctx->r1 = MEM_W(ctx->r8, 0X0);
    // 0x802B8138: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B813C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x802B8140: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B8144: lw          $at, 0x0($t3)
    ctx->r1 = MEM_W(ctx->r11, 0X0);
    // 0x802B8148: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x802B814C: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B8150: lw          $at, 0x0($t7)
    ctx->r1 = MEM_W(ctx->r15, 0X0);
    // 0x802B8154: jalr        $v0
    // 0x802B8158: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r2)(rdram, ctx);
        goto after_11;
    // 0x802B8158: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_11:
    // 0x802B815C: b           L_802B81C8
    // 0x802B8160: andi        $a3, $v0, 0xFF
    ctx->r7 = ctx->r2 & 0XFF;
        goto L_802B81C8;
    // 0x802B8160: andi        $a3, $v0, 0xFF
    ctx->r7 = ctx->r2 & 0XFF;
L_802B8164:
    // 0x802B8164: lw          $at, 0x0($t8)
    ctx->r1 = MEM_W(ctx->r24, 0X0);
    // 0x802B8168: lw          $t1, 0x60($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X60);
    // 0x802B816C: lw          $t4, 0x5C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X5C);
    // 0x802B8170: sw          $at, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r1;
    // 0x802B8174: lw          $at, 0x0($t1)
    ctx->r1 = MEM_W(ctx->r9, 0X0);
    // 0x802B8178: lw          $t6, 0x70($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X70);
    // 0x802B817C: lw          $t0, 0x6C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X6C);
    // 0x802B8180: sw          $at, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r1;
    // 0x802B8184: lw          $at, 0x0($t4)
    ctx->r1 = MEM_W(ctx->r12, 0X0);
    // 0x802B8188: lw          $t3, 0x68($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X68);
    // 0x802B818C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x802B8190: sw          $at, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r1;
    // 0x802B8194: lw          $at, 0x0($t6)
    ctx->r1 = MEM_W(ctx->r14, 0X0);
    // 0x802B8198: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B819C: addiu       $a3, $a3, 0x60DC
    ctx->r7 = ADD32(ctx->r7, 0X60DC);
    // 0x802B81A0: sw          $at, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r1;
    // 0x802B81A4: lw          $at, 0x0($t0)
    ctx->r1 = MEM_W(ctx->r8, 0X0);
    // 0x802B81A8: addiu       $a2, $a2, 0x60D8
    ctx->r6 = ADD32(ctx->r6, 0X60D8);
    // 0x802B81AC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802B81B0: sw          $at, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r1;
    // 0x802B81B4: lw          $at, 0x0($t3)
    ctx->r1 = MEM_W(ctx->r11, 0X0);
    // 0x802B81B8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x802B81BC: jalr        $v0
    // 0x802B81C0: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    LOOKUP_FUNC(ctx->r2)(rdram, ctx);
        goto after_12;
    // 0x802B81C0: sw          $at, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r1;
    after_12:
    // 0x802B81C4: andi        $a3, $v0, 0xFF
    ctx->r7 = ctx->r2 & 0XFF;
L_802B81C8:
    // 0x802B81C8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B81CC: lw          $t7, 0x60D0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X60D0);
    // 0x802B81D0: lw          $t2, 0x74($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X74);
    // 0x802B81D4: bnel        $t7, $t2, L_802B8240
    if (ctx->r15 != ctx->r10) {
        // 0x802B81D8: lbu         $t1, 0x82($sp)
        ctx->r9 = MEM_BU(ctx->r29, 0X82);
            goto L_802B8240;
    }
    goto skip_8;
    // 0x802B81D8: lbu         $t1, 0x82($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X82);
    skip_8:
    // 0x802B81DC: beq         $v0, $zero, L_802B823C
    if (ctx->r2 == 0) {
        // 0x802B81E0: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_802B823C;
    }
    // 0x802B81E0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B81E4: lbu         $t6, 0x60D4($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X60D4);
    // 0x802B81E8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B81EC: beq         $t6, $zero, L_802B821C
    if (ctx->r14 == 0) {
        // 0x802B81F0: nop
    
            goto L_802B821C;
    }
    // 0x802B81F0: nop

    // 0x802B81F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B81F8: lw          $v1, 0x60DC($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X60DC);
    // 0x802B81FC: lw          $s6, 0x8($v1)
    ctx->r22 = MEM_W(ctx->r3, 0X8);
    // 0x802B8200: lw          $s4, 0x0($v1)
    ctx->r20 = MEM_W(ctx->r3, 0X0);
    // 0x802B8204: lw          $s5, 0x4($v1)
    ctx->r21 = MEM_W(ctx->r3, 0X4);
    // 0x802B8208: negu        $t8, $s6
    ctx->r24 = SUB32(0, ctx->r22);
    // 0x802B820C: sw          $t8, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r24;
    // 0x802B8210: negu        $s7, $s4
    ctx->r23 = SUB32(0, ctx->r20);
    // 0x802B8214: b           L_802B823C
    // 0x802B8218: negu        $fp, $s5
    ctx->r30 = SUB32(0, ctx->r21);
        goto L_802B823C;
    // 0x802B8218: negu        $fp, $s5
    ctx->r30 = SUB32(0, ctx->r21);
L_802B821C:
    // 0x802B821C: lw          $v1, 0x60DC($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X60DC);
    // 0x802B8220: lw          $a2, 0x8($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X8);
    // 0x802B8224: lw          $s7, 0x0($v1)
    ctx->r23 = MEM_W(ctx->r3, 0X0);
    // 0x802B8228: lw          $fp, 0x4($v1)
    ctx->r30 = MEM_W(ctx->r3, 0X4);
    // 0x802B822C: negu        $s6, $a2
    ctx->r22 = SUB32(0, ctx->r6);
    // 0x802B8230: sw          $a2, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r6;
    // 0x802B8234: negu        $s4, $s7
    ctx->r20 = SUB32(0, ctx->r23);
    // 0x802B8238: negu        $s5, $fp
    ctx->r21 = SUB32(0, ctx->r30);
L_802B823C:
    // 0x802B823C: lbu         $t1, 0x82($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X82);
L_802B8240:
    // 0x802B8240: addiu       $s2, $s2, 0x1
    ctx->r18 = ADD32(ctx->r18, 0X1);
    // 0x802B8244: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x802B8248: bne         $t1, $zero, L_802B8258
    if (ctx->r9 != 0) {
        // 0x802B824C: sra         $s2, $t5, 16
        ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
            goto L_802B8258;
    }
    // 0x802B824C: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802B8250: beql        $s3, $zero, L_802B826C
    if (ctx->r19 == 0) {
        // 0x802B8254: lw          $t9, 0x4($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X4);
            goto L_802B826C;
    }
    goto skip_9;
    // 0x802B8254: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
    skip_9:
L_802B8258:
    // 0x802B8258: beq         $v0, $zero, L_802B8268
    if (ctx->r2 == 0) {
        // 0x802B825C: slti        $at, $s2, 0x10
        ctx->r1 = SIGNED(ctx->r18) < 0X10 ? 1 : 0;
            goto L_802B8268;
    }
    // 0x802B825C: slti        $at, $s2, 0x10
    ctx->r1 = SIGNED(ctx->r18) < 0X10 ? 1 : 0;
    // 0x802B8260: bnel        $at, $zero, L_802B7FC4
    if (ctx->r1 != 0) {
        // 0x802B8264: lbu         $t7, 0x82($sp)
        ctx->r15 = MEM_BU(ctx->r29, 0X82);
            goto L_802B7FC4;
    }
    goto skip_10;
    // 0x802B8264: lbu         $t7, 0x82($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X82);
    skip_10:
L_802B8268:
    // 0x802B8268: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
L_802B826C:
    // 0x802B826C: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x802B8270: lw          $t7, 0x8($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X8);
    // 0x802B8274: lw          $t2, 0x20($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X20);
    // 0x802B8278: lw          $t8, 0xC($s0)
    ctx->r24 = MEM_W(ctx->r16, 0XC);
    // 0x802B827C: lw          $t5, 0x24($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X24);
    // 0x802B8280: addu        $t4, $t9, $t3
    ctx->r12 = ADD32(ctx->r25, ctx->r11);
    // 0x802B8284: addu        $t6, $t7, $t2
    ctx->r14 = ADD32(ctx->r15, ctx->r10);
    // 0x802B8288: addu        $t0, $t8, $t5
    ctx->r8 = ADD32(ctx->r24, ctx->r13);
    // 0x802B828C: sw          $t4, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r12;
    // 0x802B8290: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x802B8294: sw          $t0, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r8;
    // 0x802B8298: lw          $t9, 0x1C($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X1C);
    // 0x802B829C: lw          $t1, 0x4($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X4);
    // 0x802B82A0: lw          $t7, 0x20($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X20);
    // 0x802B82A4: lw          $t4, 0x8($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X8);
    // 0x802B82A8: lw          $t8, 0x24($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X24);
    // 0x802B82AC: lw          $t6, 0xC($s1)
    ctx->r14 = MEM_W(ctx->r17, 0XC);
    // 0x802B82B0: addu        $t3, $t1, $t9
    ctx->r11 = ADD32(ctx->r9, ctx->r25);
    // 0x802B82B4: addu        $t2, $t4, $t7
    ctx->r10 = ADD32(ctx->r12, ctx->r15);
    // 0x802B82B8: addu        $t5, $t6, $t8
    ctx->r13 = ADD32(ctx->r14, ctx->r24);
    // 0x802B82BC: sw          $t3, 0x10($s1)
    MEM_W(0X10, ctx->r17) = ctx->r11;
    // 0x802B82C0: sw          $t2, 0x14($s1)
    MEM_W(0X14, ctx->r17) = ctx->r10;
    // 0x802B82C4: sw          $t5, 0x18($s1)
    MEM_W(0X18, ctx->r17) = ctx->r13;
    // 0x802B82C8: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x802B82CC: sltiu       $v0, $a3, 0x1
    ctx->r2 = ctx->r7 < 0X1 ? 1 : 0;
    // 0x802B82D0: andi        $t0, $v0, 0xFF
    ctx->r8 = ctx->r2 & 0XFF;
    // 0x802B82D4: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x802B82D8: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x802B82DC: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x802B82E0: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x802B82E4: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x802B82E8: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x802B82EC: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x802B82F0: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x802B82F4: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802B82F8: addiu       $sp, $sp, 0xD0
    ctx->r29 = ADD32(ctx->r29, 0XD0);
    // 0x802B82FC: jr          $ra
    // 0x802B8300: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    return;
    // 0x802B8300: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
;}
RECOMP_FUNC void func_802B8304_6C99B4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8304: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802B8308: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B830C: lw          $v0, 0x16C($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X16C);
    // 0x802B8310: lw          $t6, 0x18($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X18);
    // 0x802B8314: beql        $t6, $zero, L_802B83E4
    if (ctx->r14 == 0) {
        // 0x802B8318: lw          $t5, 0x4($a0)
        ctx->r13 = MEM_W(ctx->r4, 0X4);
            goto L_802B83E4;
    }
    goto skip_0;
    // 0x802B8318: lw          $t5, 0x4($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X4);
    skip_0:
    // 0x802B831C: lhu         $v0, 0x40($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X40);
    // 0x802B8320: slti        $at, $v0, 0x800
    ctx->r1 = SIGNED(ctx->r2) < 0X800 ? 1 : 0;
    // 0x802B8324: beq         $at, $zero, L_802B8334
    if (ctx->r1 == 0) {
        // 0x802B8328: sll         $v1, $v0, 16
        ctx->r3 = S32(ctx->r2 << 16);
            goto L_802B8334;
    }
    // 0x802B8328: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x802B832C: b           L_802B833C
    // 0x802B8330: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
        goto L_802B833C;
    // 0x802B8330: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
L_802B8334:
    // 0x802B8334: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x802B8338: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_802B833C:
    // 0x802B833C: lhu         $t9, 0x42($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X42);
    // 0x802B8340: lhu         $t3, 0x42($a1)
    ctx->r11 = MEM_HU(ctx->r5, 0X42);
    // 0x802B8344: lh          $t8, 0xC($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XC);
    // 0x802B8348: lh          $t2, 0xC($a1)
    ctx->r10 = MEM_H(ctx->r5, 0XC);
    // 0x802B834C: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B8350: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x802B8354: addu        $t1, $t8, $t0
    ctx->r9 = ADD32(ctx->r24, ctx->r8);
    // 0x802B8358: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x802B835C: slt         $at, $t1, $t5
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802B8360: beq         $at, $zero, L_802B8378
    if (ctx->r1 == 0) {
        // 0x802B8364: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_802B8378;
    }
    // 0x802B8364: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8368: slti        $at, $v1, 0x800
    ctx->r1 = SIGNED(ctx->r3) < 0X800 ? 1 : 0;
    // 0x802B836C: bne         $at, $zero, L_802B8378
    if (ctx->r1 != 0) {
        // 0x802B8370: nop
    
            goto L_802B8378;
    }
    // 0x802B8370: nop

    // 0x802B8374: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
L_802B8378:
    // 0x802B8378: addiu       $v0, $v0, 0x60DC
    ctx->r2 = ADD32(ctx->r2, 0X60DC);
    // 0x802B837C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8380: lw          $t6, 0x1C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X1C);
    // 0x802B8384: lw          $t2, 0x20($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X20);
    // 0x802B8388: lw          $t9, 0x0($t7)
    ctx->r25 = MEM_W(ctx->r15, 0X0);
    // 0x802B838C: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B8390: mflo        $t8
    ctx->r24 = lo;
    // 0x802B8394: sra         $t0, $t8, 11
    ctx->r8 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802B8398: subu        $t3, $t6, $t0
    ctx->r11 = SUB32(ctx->r14, ctx->r8);
    // 0x802B839C: sw          $t3, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r11;
    // 0x802B83A0: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B83A4: lw          $t8, 0x24($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X24);
    // 0x802B83A8: lw          $t1, 0x4($t4)
    ctx->r9 = MEM_W(ctx->r12, 0X4);
    // 0x802B83AC: multu       $t1, $v1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B83B0: mflo        $t5
    ctx->r13 = lo;
    // 0x802B83B4: sra         $t7, $t5, 11
    ctx->r15 = S32(SIGNED(ctx->r13) >> 11);
    // 0x802B83B8: subu        $t9, $t2, $t7
    ctx->r25 = SUB32(ctx->r10, ctx->r15);
    // 0x802B83BC: sw          $t9, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r25;
    // 0x802B83C0: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B83C4: lw          $t0, 0x8($t6)
    ctx->r8 = MEM_W(ctx->r14, 0X8);
    // 0x802B83C8: multu       $t0, $v1
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B83CC: mflo        $t3
    ctx->r11 = lo;
    // 0x802B83D0: sra         $t4, $t3, 11
    ctx->r12 = S32(SIGNED(ctx->r11) >> 11);
    // 0x802B83D4: subu        $t1, $t8, $t4
    ctx->r9 = SUB32(ctx->r24, ctx->r12);
    // 0x802B83D8: b           L_802B870C
    // 0x802B83DC: sw          $t1, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r9;
        goto L_802B870C;
    // 0x802B83DC: sw          $t1, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r9;
    // 0x802B83E0: lw          $t5, 0x4($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X4);
L_802B83E4:
    // 0x802B83E4: lw          $t2, 0x4($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X4);
    // 0x802B83E8: lw          $t9, 0x8($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X8);
    // 0x802B83EC: lw          $t6, 0x8($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X8);
    // 0x802B83F0: subu        $t7, $t5, $t2
    ctx->r15 = SUB32(ctx->r13, ctx->r10);
    // 0x802B83F4: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802B83F8: subu        $t0, $t9, $t6
    ctx->r8 = SUB32(ctx->r25, ctx->r14);
    // 0x802B83FC: mtc1        $t0, $f10
    ctx->f10.u32l = ctx->r8;
    // 0x802B8400: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B8404: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B8408: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802B840C: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802B8410: cvt.d.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.d = CVT_D_W(ctx->f10.u32l);
    // 0x802B8414: lbu         $t3, 0x15($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X15);
    // 0x802B8418: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B841C: div.d       $f8, $f6, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f8.d = DIV_D(ctx->f6.d, ctx->f18.d);
    // 0x802B8420: div.d       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f18.d); 
    ctx->f6.d = DIV_D(ctx->f4.d, ctx->f18.d);
    // 0x802B8424: cvt.s.d     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f2.fl = CVT_S_D(ctx->f8.d);
    // 0x802B8428: bne         $t3, $at, L_802B8528
    if (ctx->r11 != ctx->r1) {
        // 0x802B842C: cvt.s.d     $f14, $f6
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f14.fl = CVT_S_D(ctx->f6.d);
            goto L_802B8528;
    }
    // 0x802B842C: cvt.s.d     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f14.fl = CVT_S_D(ctx->f6.d);
    // 0x802B8430: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x802B8434: nop

    // 0x802B8438: c.lt.s      $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f2.fl < ctx->f16.fl;
    // 0x802B843C: nop

    // 0x802B8440: bc1fl       L_802B8484
    if (!c1cs) {
        // 0x802B8444: lh          $t1, 0x30($a1)
        ctx->r9 = MEM_H(ctx->r5, 0X30);
            goto L_802B8484;
    }
    goto skip_1;
    // 0x802B8444: lh          $t1, 0x30($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X30);
    skip_1:
    // 0x802B8448: lh          $t8, 0x30($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X30);
    // 0x802B844C: addiu       $t4, $t8, -0x2
    ctx->r12 = ADD32(ctx->r24, -0X2);
    // 0x802B8450: mtc1        $t4, $f8
    ctx->f8.u32l = ctx->r12;
    // 0x802B8454: nop

    // 0x802B8458: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802B845C: add.s       $f0, $f10, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f0.fl = ctx->f10.fl + ctx->f2.fl;
    // 0x802B8460: c.lt.s      $f16, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f16.fl < ctx->f0.fl;
    // 0x802B8464: nop

    // 0x802B8468: bc1f        L_802B8478
    if (!c1cs) {
        // 0x802B846C: nop
    
            goto L_802B8478;
    }
    // 0x802B846C: nop

    // 0x802B8470: b           L_802B84B0
    // 0x802B8474: mov.s       $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    ctx->f2.fl = ctx->f16.fl;
        goto L_802B84B0;
    // 0x802B8474: mov.s       $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    ctx->f2.fl = ctx->f16.fl;
L_802B8478:
    // 0x802B8478: b           L_802B84B0
    // 0x802B847C: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
        goto L_802B84B0;
    // 0x802B847C: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
    // 0x802B8480: lh          $t1, 0x30($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X30);
L_802B8484:
    // 0x802B8484: addiu       $t5, $t1, -0x2
    ctx->r13 = ADD32(ctx->r9, -0X2);
    // 0x802B8488: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802B848C: nop

    // 0x802B8490: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802B8494: c.lt.s      $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f2.fl < ctx->f0.fl;
    // 0x802B8498: nop

    // 0x802B849C: bc1fl       L_802B84B0
    if (!c1cs) {
        // 0x802B84A0: sub.s       $f2, $f2, $f0
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = ctx->f2.fl - ctx->f0.fl;
            goto L_802B84B0;
    }
    goto skip_2;
    // 0x802B84A0: sub.s       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = ctx->f2.fl - ctx->f0.fl;
    skip_2:
    // 0x802B84A4: b           L_802B84B0
    // 0x802B84A8: mov.s       $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    ctx->f2.fl = ctx->f16.fl;
        goto L_802B84B0;
    // 0x802B84A8: mov.s       $f2, $f16
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 16);
    ctx->f2.fl = ctx->f16.fl;
    // 0x802B84AC: sub.s       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = ctx->f2.fl - ctx->f0.fl;
L_802B84B0:
    // 0x802B84B0: c.lt.s      $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f14.fl < ctx->f16.fl;
    // 0x802B84B4: nop

    // 0x802B84B8: bc1fl       L_802B84FC
    if (!c1cs) {
        // 0x802B84BC: lh          $t9, 0x32($a1)
        ctx->r25 = MEM_H(ctx->r5, 0X32);
            goto L_802B84FC;
    }
    goto skip_3;
    // 0x802B84BC: lh          $t9, 0x32($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X32);
    skip_3:
    // 0x802B84C0: lh          $t2, 0x32($a1)
    ctx->r10 = MEM_H(ctx->r5, 0X32);
    // 0x802B84C4: addiu       $t7, $t2, -0x2
    ctx->r15 = ADD32(ctx->r10, -0X2);
    // 0x802B84C8: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802B84CC: nop

    // 0x802B84D0: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802B84D4: add.s       $f0, $f8, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f0.fl = ctx->f8.fl + ctx->f14.fl;
    // 0x802B84D8: c.lt.s      $f16, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f16.fl < ctx->f0.fl;
    // 0x802B84DC: nop

    // 0x802B84E0: bc1f        L_802B84F0
    if (!c1cs) {
        // 0x802B84E4: nop
    
            goto L_802B84F0;
    }
    // 0x802B84E4: nop

    // 0x802B84E8: b           L_802B8528
    // 0x802B84EC: mov.s       $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    ctx->f14.fl = ctx->f16.fl;
        goto L_802B8528;
    // 0x802B84EC: mov.s       $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    ctx->f14.fl = ctx->f16.fl;
L_802B84F0:
    // 0x802B84F0: b           L_802B8528
    // 0x802B84F4: mov.s       $f14, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    ctx->f14.fl = ctx->f0.fl;
        goto L_802B8528;
    // 0x802B84F4: mov.s       $f14, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    ctx->f14.fl = ctx->f0.fl;
    // 0x802B84F8: lh          $t9, 0x32($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X32);
L_802B84FC:
    // 0x802B84FC: addiu       $t6, $t9, -0x2
    ctx->r14 = ADD32(ctx->r25, -0X2);
    // 0x802B8500: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x802B8504: nop

    // 0x802B8508: cvt.s.w     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802B850C: c.lt.s      $f14, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f14.fl < ctx->f0.fl;
    // 0x802B8510: nop

    // 0x802B8514: bc1fl       L_802B8528
    if (!c1cs) {
        // 0x802B8518: sub.s       $f14, $f14, $f0
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = ctx->f14.fl - ctx->f0.fl;
            goto L_802B8528;
    }
    goto skip_4;
    // 0x802B8518: sub.s       $f14, $f14, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = ctx->f14.fl - ctx->f0.fl;
    skip_4:
    // 0x802B851C: b           L_802B8528
    // 0x802B8520: mov.s       $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    ctx->f14.fl = ctx->f16.fl;
        goto L_802B8528;
    // 0x802B8520: mov.s       $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    ctx->f14.fl = ctx->f16.fl;
    // 0x802B8524: sub.s       $f14, $f14, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = ctx->f14.fl - ctx->f0.fl;
L_802B8528:
    // 0x802B8528: mul.s       $f4, $f2, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x802B852C: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802B8530: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x802B8534: mul.s       $f6, $f14, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x802B8538: swc1        $f2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->f2.u32l;
    // 0x802B853C: swc1        $f14, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->f14.u32l;
    // 0x802B8540: jal         0x80137E10
    // 0x802B8544: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x802B8544: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    after_0:
    // 0x802B8548: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    // 0x802B854C: lw          $a1, 0x34($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X34);
    // 0x802B8550: swc1        $f0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f0.u32l;
    // 0x802B8554: lw          $t0, 0x1C($a0)
    ctx->r8 = MEM_W(ctx->r4, 0X1C);
    // 0x802B8558: lw          $t3, 0x1C($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X1C);
    // 0x802B855C: lw          $t4, 0x20($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X20);
    // 0x802B8560: lw          $t1, 0x20($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X20);
    // 0x802B8564: subu        $t8, $t0, $t3
    ctx->r24 = SUB32(ctx->r8, ctx->r11);
    // 0x802B8568: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802B856C: subu        $t5, $t4, $t1
    ctx->r13 = SUB32(ctx->r12, ctx->r9);
    // 0x802B8570: mtc1        $t5, $f6
    ctx->f6.u32l = ctx->r13;
    // 0x802B8574: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x802B8578: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B857C: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802B8580: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802B8584: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x802B8588: div.d       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = DIV_D(ctx->f10.d, ctx->f18.d);
    // 0x802B858C: div.d       $f10, $f8, $f18
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f18.d); 
    ctx->f10.d = DIV_D(ctx->f8.d, ctx->f18.d);
    // 0x802B8590: cvt.s.d     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f16.fl = CVT_S_D(ctx->f4.d);
    // 0x802B8594: swc1        $f16, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f16.u32l;
    // 0x802B8598: cvt.s.d     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f4.fl = CVT_S_D(ctx->f10.d);
    // 0x802B859C: mul.s       $f6, $f4, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f4.fl);
    // 0x802B85A0: swc1        $f4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f4.u32l;
    // 0x802B85A4: mul.s       $f8, $f16, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x802B85A8: jal         0x80137E10
    // 0x802B85AC: add.s       $f12, $f8, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f6.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_1;
    // 0x802B85AC: add.s       $f12, $f8, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f6.fl;
    after_1:
    // 0x802B85B0: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x802B85B4: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x802B85B8: lui         $at, 0x4010
    ctx->r1 = S32(0X4010 << 16);
    // 0x802B85BC: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x802B85C0: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802B85C4: cvt.d.s     $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f10.d = CVT_D_S(ctx->f0.fl);
    // 0x802B85C8: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x802B85CC: c.lt.d      $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    c1cs = ctx->f10.d < ctx->f4.d;
    // 0x802B85D0: lw          $a0, 0x30($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X30);
    // 0x802B85D4: lw          $a1, 0x34($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X34);
    // 0x802B85D8: lwc1        $f2, 0x2C($sp)
    ctx->f2.u32l = MEM_W(ctx->r29, 0X2C);
    // 0x802B85DC: lwc1        $f12, 0x24($sp)
    ctx->f12.u32l = MEM_W(ctx->r29, 0X24);
    // 0x802B85E0: bc1f        L_802B870C
    if (!c1cs) {
        // 0x802B85E4: lwc1        $f14, 0x28($sp)
        ctx->f14.u32l = MEM_W(ctx->r29, 0X28);
            goto L_802B870C;
    }
    // 0x802B85E4: lwc1        $f14, 0x28($sp)
    ctx->f14.u32l = MEM_W(ctx->r29, 0X28);
    // 0x802B85E8: mtc1        $zero, $f9
    ctx->f_odd[(9 - 1) * 2] = 0;
    // 0x802B85EC: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802B85F0: cvt.d.s     $f6, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f6.d = CVT_D_S(ctx->f12.fl);
    // 0x802B85F4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B85F8: c.eq.d      $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    c1cs = ctx->f8.d == ctx->f6.d;
    // 0x802B85FC: nop

    // 0x802B8600: bc1t        L_802B86C8
    if (c1cs) {
        // 0x802B8604: nop
    
            goto L_802B86C8;
    }
    // 0x802B8604: nop

    // 0x802B8608: lhu         $v0, 0x40($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X40);
    // 0x802B860C: slti        $at, $v0, 0x800
    ctx->r1 = SIGNED(ctx->r2) < 0X800 ? 1 : 0;
    // 0x802B8610: beq         $at, $zero, L_802B8620
    if (ctx->r1 == 0) {
        // 0x802B8614: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802B8620;
    }
    // 0x802B8614: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802B8618: b           L_802B8620
    // 0x802B861C: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
        goto L_802B8620;
    // 0x802B861C: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
L_802B8620:
    // 0x802B8620: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802B8624: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802B8628: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B862C: ldc1        $f6, -0x40B8($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X40B8);
    // 0x802B8630: mul.s       $f4, $f12, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = MUL_S(ctx->f12.fl, ctx->f10.fl);
    // 0x802B8634: cvt.d.s     $f8, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f8.d = CVT_D_S(ctx->f2.fl);
    // 0x802B8638: slti        $at, $v0, 0x800
    ctx->r1 = SIGNED(ctx->r2) < 0X800 ? 1 : 0;
    // 0x802B863C: mul.d       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = MUL_D(ctx->f8.d, ctx->f6.d);
    // 0x802B8640: cvt.d.s     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f0.d = CVT_D_S(ctx->f4.fl);
    // 0x802B8644: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x802B8648: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802B864C: cvt.d.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B8650: mul.d       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f6.d = MUL_D(ctx->f8.d, ctx->f10.d);
    // 0x802B8654: div.d       $f4, $f6, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = DIV_D(ctx->f6.d, ctx->f0.d);
    // 0x802B8658: beq         $at, $zero, L_802B8668
    if (ctx->r1 == 0) {
        // 0x802B865C: cvt.s.d     $f16, $f4
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f16.fl = CVT_S_D(ctx->f4.d);
            goto L_802B8668;
    }
    // 0x802B865C: cvt.s.d     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f16.fl = CVT_S_D(ctx->f4.d);
    // 0x802B8660: b           L_802B8668
    // 0x802B8664: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
        goto L_802B8668;
    // 0x802B8664: addiu       $v1, $zero, 0x800
    ctx->r3 = ADD32(0, 0X800);
L_802B8668:
    // 0x802B8668: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B866C: ldc1        $f10, -0x40B0($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X40B0);
    // 0x802B8670: cvt.d.s     $f8, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f8.d = CVT_D_S(ctx->f14.fl);
    // 0x802B8674: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x802B8678: mul.d       $f6, $f8, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f6.d = MUL_D(ctx->f8.d, ctx->f10.d);
    // 0x802B867C: cvt.d.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.d = CVT_D_W(ctx->f4.u32l);
    // 0x802B8680: mul.d       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = MUL_D(ctx->f8.d, ctx->f6.d);
    // 0x802B8684: lwc1        $f8, 0x20($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X20);
    // 0x802B8688: mul.s       $f6, $f8, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f16.fl);
    // 0x802B868C: div.d       $f4, $f10, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f4.d = DIV_D(ctx->f10.d, ctx->f0.d);
    // 0x802B8690: lwc1        $f10, 0x1C($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X1C);
    // 0x802B8694: cvt.s.d     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f12.fl = CVT_S_D(ctx->f4.d);
    // 0x802B8698: mul.s       $f4, $f10, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f12.fl);
    // 0x802B869C: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802B86A0: add.s       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x802B86A4: c.lt.s      $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f8.fl < ctx->f10.fl;
    // 0x802B86A8: nop

    // 0x802B86AC: bc1fl       L_802B86D8
    if (!c1cs) {
        // 0x802B86B0: cvt.d.s     $f6, $f16
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
            goto L_802B86D8;
    }
    goto skip_5;
    // 0x802B86B0: cvt.d.s     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
    skip_5:
    // 0x802B86B4: lw          $t2, 0x1C($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X1C);
    // 0x802B86B8: sw          $t2, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r10;
    // 0x802B86BC: lw          $t7, 0x20($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X20);
    // 0x802B86C0: b           L_802B86D4
    // 0x802B86C4: sw          $t7, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r15;
        goto L_802B86D4;
    // 0x802B86C4: sw          $t7, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r15;
L_802B86C8:
    // 0x802B86C8: lwc1        $f16, -0x40A8($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0X40A8);
    // 0x802B86CC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802B86D0: lwc1        $f12, -0x40A4($at)
    ctx->f12.u32l = MEM_W(ctx->r1, -0X40A4);
L_802B86D4:
    // 0x802B86D4: cvt.d.s     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
L_802B86D8:
    // 0x802B86D8: cvt.d.s     $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.d = CVT_D_S(ctx->f12.fl);
    // 0x802B86DC: mul.d       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f6.d, ctx->f18.d);
    // 0x802B86E0: lw          $t9, 0x1C($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X1C);
    // 0x802B86E4: lw          $t8, 0x20($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X20);
    // 0x802B86E8: mul.d       $f6, $f10, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f6.d = MUL_D(ctx->f10.d, ctx->f18.d);
    // 0x802B86EC: trunc.w.d   $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = TRUNC_W_D(ctx->f4.d);
    // 0x802B86F0: trunc.w.d   $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.u32l = TRUNC_W_D(ctx->f6.d);
    // 0x802B86F4: mfc1        $t0, $f8
    ctx->r8 = (int32_t)ctx->f8.u32l;
    // 0x802B86F8: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x802B86FC: addu        $t3, $t9, $t0
    ctx->r11 = ADD32(ctx->r25, ctx->r8);
    // 0x802B8700: sw          $t3, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r11;
    // 0x802B8704: addu        $t5, $t8, $t1
    ctx->r13 = ADD32(ctx->r24, ctx->r9);
    // 0x802B8708: sw          $t5, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r13;
L_802B870C:
    // 0x802B870C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8710: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802B8714: jr          $ra
    // 0x802B8718: nop

    return;
    // 0x802B8718: nop

;}
RECOMP_FUNC void func_802B8720_6C9DD0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8720: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8724: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8728: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B872C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B8730: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B8734: sh          $zero, 0x380($t6)
    MEM_H(0X380, ctx->r14) = 0;
    // 0x802B8738: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B873C: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x802B8740: sh          $zero, 0x394($t7)
    MEM_H(0X394, ctx->r15) = 0;
    // 0x802B8744: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8748: sh          $zero, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = 0;
    // 0x802B874C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B8750: sh          $zero, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = 0;
    // 0x802B8754: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8758: sh          $zero, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = 0;
    // 0x802B875C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B8760: sh          $zero, 0x382($t1)
    MEM_H(0X382, ctx->r9) = 0;
    // 0x802B8764: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B8768: sh          $zero, 0x396($t2)
    MEM_H(0X396, ctx->r10) = 0;
    // 0x802B876C: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B8770: sh          $zero, 0x3AA($t3)
    MEM_H(0X3AA, ctx->r11) = 0;
    // 0x802B8774: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B8778: jal         0x802C7BB4
    // 0x802B877C: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_0;
    // 0x802B877C: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    after_0:
    // 0x802B8780: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8784: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8788: jr          $ra
    // 0x802B878C: nop

    return;
    // 0x802B878C: nop

;}
RECOMP_FUNC void func_802B8790_6C9E40(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8790: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8794: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8798: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B879C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B87A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B87A4: sh          $zero, 0x380($t6)
    MEM_H(0X380, ctx->r14) = 0;
    // 0x802B87A8: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B87AC: sh          $zero, 0x394($t7)
    MEM_H(0X394, ctx->r15) = 0;
    // 0x802B87B0: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B87B4: sh          $zero, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = 0;
    // 0x802B87B8: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B87BC: sh          $zero, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = 0;
    // 0x802B87C0: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B87C4: sh          $zero, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = 0;
    // 0x802B87C8: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B87CC: sh          $zero, 0x382($t1)
    MEM_H(0X382, ctx->r9) = 0;
    // 0x802B87D0: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B87D4: sh          $zero, 0x396($t2)
    MEM_H(0X396, ctx->r10) = 0;
    // 0x802B87D8: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B87DC: sh          $zero, 0x3AA($t3)
    MEM_H(0X3AA, ctx->r11) = 0;
    // 0x802B87E0: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B87E4: jal         0x802B8B74
    // 0x802B87E8: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_0;
    // 0x802B87E8: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    after_0:
    // 0x802B87EC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B87F0: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802B87F4: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    // 0x802B87F8: jal         0x802C7BB4
    // 0x802B87FC: sh          $v0, 0x2FA($t5)
    MEM_H(0X2FA, ctx->r13) = ctx->r2;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_1;
    // 0x802B87FC: sh          $v0, 0x2FA($t5)
    MEM_H(0X2FA, ctx->r13) = ctx->r2;
    after_1:
    // 0x802B8800: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8804: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8808: jr          $ra
    // 0x802B880C: nop

    return;
    // 0x802B880C: nop

;}
RECOMP_FUNC void func_802B8810_6C9EC0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8810: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8814: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8818: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B881C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B8820: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B8824: sh          $zero, 0x380($t6)
    MEM_H(0X380, ctx->r14) = 0;
    // 0x802B8828: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B882C: sh          $zero, 0x394($t7)
    MEM_H(0X394, ctx->r15) = 0;
    // 0x802B8830: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8834: sh          $zero, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = 0;
    // 0x802B8838: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B883C: sh          $zero, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = 0;
    // 0x802B8840: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8844: sh          $zero, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = 0;
    // 0x802B8848: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B884C: sh          $zero, 0x382($t1)
    MEM_H(0X382, ctx->r9) = 0;
    // 0x802B8850: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B8854: sh          $zero, 0x396($t2)
    MEM_H(0X396, ctx->r10) = 0;
    // 0x802B8858: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B885C: sh          $zero, 0x3AA($t3)
    MEM_H(0X3AA, ctx->r11) = 0;
    // 0x802B8860: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B8864: jal         0x802B8B74
    // 0x802B8868: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    func_802B8B74_6CA224(rdram, ctx);
        goto after_0;
    // 0x802B8868: sh          $zero, 0x3BE($t4)
    MEM_H(0X3BE, ctx->r12) = 0;
    after_0:
    // 0x802B886C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B8870: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x802B8874: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802B8878: jal         0x802C7BB4
    // 0x802B887C: sh          $v0, 0x2FA($t5)
    MEM_H(0X2FA, ctx->r13) = ctx->r2;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_1;
    // 0x802B887C: sh          $v0, 0x2FA($t5)
    MEM_H(0X2FA, ctx->r13) = ctx->r2;
    after_1:
    // 0x802B8880: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8884: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8888: jr          $ra
    // 0x802B888C: nop

    return;
    // 0x802B888C: nop

;}
RECOMP_FUNC void func_802B8890_6C9F40(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8890: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8894: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8898: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B889C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B88A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B88A4: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    // 0x802B88A8: sh          $a1, 0x380($t6)
    MEM_H(0X380, ctx->r14) = ctx->r5;
    // 0x802B88AC: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B88B0: addiu       $a2, $zero, 0x4
    ctx->r6 = ADD32(0, 0X4);
    // 0x802B88B4: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x802B88B8: sh          $a1, 0x394($t7)
    MEM_H(0X394, ctx->r15) = ctx->r5;
    // 0x802B88BC: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B88C0: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    // 0x802B88C4: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802B88C8: sh          $a2, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = ctx->r6;
    // 0x802B88CC: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B88D0: sh          $a2, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = ctx->r6;
    // 0x802B88D4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B88D8: sh          $a3, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = ctx->r7;
    // 0x802B88DC: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B88E0: sh          $a3, 0x3C4($t1)
    MEM_H(0X3C4, ctx->r9) = ctx->r7;
    // 0x802B88E4: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B88E8: sh          $v1, 0x382($t2)
    MEM_H(0X382, ctx->r10) = ctx->r3;
    // 0x802B88EC: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B88F0: sh          $v1, 0x396($t3)
    MEM_H(0X396, ctx->r11) = ctx->r3;
    // 0x802B88F4: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B88F8: sh          $v1, 0x3AA($t4)
    MEM_H(0X3AA, ctx->r12) = ctx->r3;
    // 0x802B88FC: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802B8900: jal         0x802C7BB4
    // 0x802B8904: sh          $v1, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = ctx->r3;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_0;
    // 0x802B8904: sh          $v1, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = ctx->r3;
    after_0:
    // 0x802B8908: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B890C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8910: jr          $ra
    // 0x802B8914: nop

    return;
    // 0x802B8914: nop

;}
RECOMP_FUNC void func_802B8918_6C9FC8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8918: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B891C: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8920: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B8924: addiu       $v1, $zero, 0x7
    ctx->r3 = ADD32(0, 0X7);
    // 0x802B8928: sh          $v1, 0x380($t6)
    MEM_H(0X380, ctx->r14) = ctx->r3;
    // 0x802B892C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8930: sh          $v1, 0x394($t7)
    MEM_H(0X394, ctx->r15) = ctx->r3;
    // 0x802B8934: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8938: sh          $v1, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = ctx->r3;
    // 0x802B893C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B8940: sh          $v1, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = ctx->r3;
    // 0x802B8944: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8948: sh          $v1, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = ctx->r3;
    // 0x802B894C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B8950: sh          $v1, 0x3C4($t1)
    MEM_H(0X3C4, ctx->r9) = ctx->r3;
    // 0x802B8954: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B8958: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
    // 0x802B895C: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B8960: sh          $zero, 0x396($t3)
    MEM_H(0X396, ctx->r11) = 0;
    // 0x802B8964: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B8968: sh          $zero, 0x3AA($t4)
    MEM_H(0X3AA, ctx->r12) = 0;
    // 0x802B896C: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802B8970: jr          $ra
    // 0x802B8974: sh          $zero, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = 0;
    return;
    // 0x802B8974: sh          $zero, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = 0;
;}
RECOMP_FUNC void func_802B8978_6CA028(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8978: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B897C: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8980: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B8984: addiu       $v1, $zero, 0x8
    ctx->r3 = ADD32(0, 0X8);
    // 0x802B8988: sh          $v1, 0x380($t6)
    MEM_H(0X380, ctx->r14) = ctx->r3;
    // 0x802B898C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8990: sh          $v1, 0x394($t7)
    MEM_H(0X394, ctx->r15) = ctx->r3;
    // 0x802B8994: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8998: sh          $v1, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = ctx->r3;
    // 0x802B899C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B89A0: sh          $v1, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = ctx->r3;
    // 0x802B89A4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B89A8: sh          $v1, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = ctx->r3;
    // 0x802B89AC: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B89B0: sh          $v1, 0x3C4($t1)
    MEM_H(0X3C4, ctx->r9) = ctx->r3;
    // 0x802B89B4: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B89B8: sh          $zero, 0x382($t2)
    MEM_H(0X382, ctx->r10) = 0;
    // 0x802B89BC: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B89C0: sh          $zero, 0x396($t3)
    MEM_H(0X396, ctx->r11) = 0;
    // 0x802B89C4: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B89C8: sh          $zero, 0x3AA($t4)
    MEM_H(0X3AA, ctx->r12) = 0;
    // 0x802B89CC: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802B89D0: jr          $ra
    // 0x802B89D4: sh          $zero, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = 0;
    return;
    // 0x802B89D4: sh          $zero, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = 0;
;}
RECOMP_FUNC void func_802B89D8_6CA088(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B89D8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B89DC: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B89E0: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B89E4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B89E8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B89EC: addiu       $a1, $zero, 0x9
    ctx->r5 = ADD32(0, 0X9);
    // 0x802B89F0: sh          $a1, 0x3C0($t6)
    MEM_H(0X3C0, ctx->r14) = ctx->r5;
    // 0x802B89F4: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B89F8: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    // 0x802B89FC: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802B8A00: sh          $a1, 0x3C4($t7)
    MEM_H(0X3C4, ctx->r15) = ctx->r5;
    // 0x802B8A04: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A08: sh          $v1, 0x382($t8)
    MEM_H(0X382, ctx->r24) = ctx->r3;
    // 0x802B8A0C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A10: sh          $v1, 0x396($t9)
    MEM_H(0X396, ctx->r25) = ctx->r3;
    // 0x802B8A14: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A18: sh          $v1, 0x3AA($t0)
    MEM_H(0X3AA, ctx->r8) = ctx->r3;
    // 0x802B8A1C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A20: sh          $v1, 0x3BE($t1)
    MEM_H(0X3BE, ctx->r9) = ctx->r3;
    // 0x802B8A24: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A28: sh          $v1, 0x3C2($t2)
    MEM_H(0X3C2, ctx->r10) = ctx->r3;
    // 0x802B8A2C: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A30: jal         0x802C7BB4
    // 0x802B8A34: sh          $v1, 0x3C6($t3)
    MEM_H(0X3C6, ctx->r11) = ctx->r3;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_0;
    // 0x802B8A34: sh          $v1, 0x3C6($t3)
    MEM_H(0X3C6, ctx->r11) = ctx->r3;
    after_0:
    // 0x802B8A38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8A3C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8A40: jr          $ra
    // 0x802B8A44: nop

    return;
    // 0x802B8A44: nop

;}
RECOMP_FUNC void func_802B8A48_6CA0F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8A48: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8A4C: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8A50: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A54: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B8A58: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B8A5C: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
    // 0x802B8A60: sh          $v1, 0x380($t6)
    MEM_H(0X380, ctx->r14) = ctx->r3;
    // 0x802B8A64: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A68: addiu       $a1, $zero, -0x1
    ctx->r5 = ADD32(0, -0X1);
    // 0x802B8A6C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x802B8A70: sh          $v1, 0x394($t7)
    MEM_H(0X394, ctx->r15) = ctx->r3;
    // 0x802B8A74: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A78: sh          $v1, 0x3A8($t8)
    MEM_H(0X3A8, ctx->r24) = ctx->r3;
    // 0x802B8A7C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A80: sh          $v1, 0x3BC($t9)
    MEM_H(0X3BC, ctx->r25) = ctx->r3;
    // 0x802B8A84: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A88: sh          $v1, 0x3C0($t0)
    MEM_H(0X3C0, ctx->r8) = ctx->r3;
    // 0x802B8A8C: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A90: sh          $v1, 0x3C4($t1)
    MEM_H(0X3C4, ctx->r9) = ctx->r3;
    // 0x802B8A94: lw          $t2, 0x0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X0);
    // 0x802B8A98: sh          $a1, 0x382($t2)
    MEM_H(0X382, ctx->r10) = ctx->r5;
    // 0x802B8A9C: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AA0: sh          $a1, 0x396($t3)
    MEM_H(0X396, ctx->r11) = ctx->r5;
    // 0x802B8AA4: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AA8: sh          $a1, 0x3AA($t4)
    MEM_H(0X3AA, ctx->r12) = ctx->r5;
    // 0x802B8AAC: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AB0: sh          $a1, 0x3BE($t5)
    MEM_H(0X3BE, ctx->r13) = ctx->r5;
    // 0x802B8AB4: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AB8: sh          $a1, 0x3C2($t6)
    MEM_H(0X3C2, ctx->r14) = ctx->r5;
    // 0x802B8ABC: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AC0: jal         0x802C7BB4
    // 0x802B8AC4: sh          $a1, 0x3C6($t7)
    MEM_H(0X3C6, ctx->r15) = ctx->r5;
    func_802C7BB4_6D9264(rdram, ctx);
        goto after_0;
    // 0x802B8AC4: sh          $a1, 0x3C6($t7)
    MEM_H(0X3C6, ctx->r15) = ctx->r5;
    after_0:
    // 0x802B8AC8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B8ACC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B8AD0: jr          $ra
    // 0x802B8AD4: nop

    return;
    // 0x802B8AD4: nop

;}
RECOMP_FUNC void func_802B8AD8_6CA188(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8AD8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802B8ADC: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x802B8AE0: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AE4: addiu       $v1, $zero, 0x9
    ctx->r3 = ADD32(0, 0X9);
    // 0x802B8AE8: addiu       $a0, $zero, -0x1
    ctx->r4 = ADD32(0, -0X1);
    // 0x802B8AEC: sh          $v1, 0x3C0($t6)
    MEM_H(0X3C0, ctx->r14) = ctx->r3;
    // 0x802B8AF0: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AF4: sh          $v1, 0x3C4($t7)
    MEM_H(0X3C4, ctx->r15) = ctx->r3;
    // 0x802B8AF8: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x802B8AFC: sh          $v1, 0x3CE($t8)
    MEM_H(0X3CE, ctx->r24) = ctx->r3;
    // 0x802B8B00: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802B8B04: sh          $a0, 0x3C2($t9)
    MEM_H(0X3C2, ctx->r25) = ctx->r4;
    // 0x802B8B08: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x802B8B0C: sh          $a0, 0x3C6($t0)
    MEM_H(0X3C6, ctx->r8) = ctx->r4;
    // 0x802B8B10: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802B8B14: jr          $ra
    // 0x802B8B18: sh          $a0, 0x3D0($t1)
    MEM_H(0X3D0, ctx->r9) = ctx->r4;
    return;
    // 0x802B8B18: sh          $a0, 0x3D0($t1)
    MEM_H(0X3D0, ctx->r9) = ctx->r4;
;}
RECOMP_FUNC void func_802B8B1C_6CA1CC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8B1C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B8B20: addiu       $v1, $v1, 0x5528
    ctx->r3 = ADD32(ctx->r3, 0X5528);
    // 0x802B8B24: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B28: addiu       $a0, $zero, 0xC
    ctx->r4 = ADD32(0, 0XC);
    // 0x802B8B2C: addiu       $a1, $zero, -0x1
    ctx->r5 = ADD32(0, -0X1);
    // 0x802B8B30: sh          $a0, 0x3C0($t6)
    MEM_H(0X3C0, ctx->r14) = ctx->r4;
    // 0x802B8B34: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B38: addiu       $at, $zero, 0xC
    ctx->r1 = ADD32(0, 0XC);
    // 0x802B8B3C: sh          $a0, 0x3CE($t7)
    MEM_H(0X3CE, ctx->r15) = ctx->r4;
    // 0x802B8B40: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B44: sh          $a1, 0x3C2($t8)
    MEM_H(0X3C2, ctx->r24) = ctx->r5;
    // 0x802B8B48: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B4C: sh          $a1, 0x3D0($t9)
    MEM_H(0X3D0, ctx->r25) = ctx->r5;
    // 0x802B8B50: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B54: lhu         $t0, 0x3C4($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X3C4);
    // 0x802B8B58: beq         $t0, $at, L_802B8B6C
    if (ctx->r8 == ctx->r1) {
        // 0x802B8B5C: nop
    
            goto L_802B8B6C;
    }
    // 0x802B8B5C: nop

    // 0x802B8B60: sh          $a0, 0x3C4($v0)
    MEM_H(0X3C4, ctx->r2) = ctx->r4;
    // 0x802B8B64: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x802B8B68: sh          $a1, 0x3C6($t1)
    MEM_H(0X3C6, ctx->r9) = ctx->r5;
L_802B8B6C:
    // 0x802B8B6C: jr          $ra
    // 0x802B8B70: nop

    return;
    // 0x802B8B70: nop

;}
RECOMP_FUNC void func_802B8B74_6CA224(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8B74: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B8B78: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B8B7C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B8B80: addiu       $v0, $zero, 0xBB8
    ctx->r2 = ADD32(0, 0XBB8);
    // 0x802B8B84: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
    // 0x802B8B88: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B8B8C: beq         $v1, $at, L_802B8BAC
    if (ctx->r3 == ctx->r1) {
        // 0x802B8B90: addiu       $at, $zero, 0xB6
        ctx->r1 = ADD32(0, 0XB6);
            goto L_802B8BAC;
    }
    // 0x802B8B90: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B8B94: beq         $v1, $at, L_802B8BAC
    if (ctx->r3 == ctx->r1) {
        // 0x802B8B98: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802B8BAC;
    }
    // 0x802B8B98: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B8B9C: beq         $v1, $at, L_802B8BAC
    if (ctx->r3 == ctx->r1) {
        // 0x802B8BA0: addiu       $at, $zero, 0xB9
        ctx->r1 = ADD32(0, 0XB9);
            goto L_802B8BAC;
    }
    // 0x802B8BA0: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B8BA4: bnel        $v1, $at, L_802B8BBC
    if (ctx->r3 != ctx->r1) {
        // 0x802B8BA8: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B8BBC;
    }
    goto skip_0;
    // 0x802B8BA8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_0:
L_802B8BAC:
    // 0x802B8BAC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B8BB0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x802B8BB4: lhu         $v0, 0xC2($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0XC2);
    // 0x802B8BB8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802B8BBC:
    // 0x802B8BBC: beq         $v1, $at, L_802B8BD0
    if (ctx->r3 == ctx->r1) {
        // 0x802B8BC0: nop
    
            goto L_802B8BD0;
    }
    // 0x802B8BC0: nop

    // 0x802B8BC4: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B8BC8: bne         $v1, $at, L_802B8BDC
    if (ctx->r3 != ctx->r1) {
        // 0x802B8BCC: nop
    
            goto L_802B8BDC;
    }
    // 0x802B8BCC: nop

L_802B8BD0:
    // 0x802B8BD0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x802B8BD4: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x802B8BD8: lhu         $v0, 0xC4($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0XC4);
L_802B8BDC:
    // 0x802B8BDC: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x802B8BE0: lh          $v1, 0x31A($t9)
    ctx->r3 = MEM_H(ctx->r25, 0X31A);
    // 0x802B8BE4: sll         $t0, $v1, 5
    ctx->r8 = S32(ctx->r3 << 5);
    // 0x802B8BE8: sra         $t1, $t0, 6
    ctx->r9 = S32(SIGNED(ctx->r8) >> 6);
    // 0x802B8BEC: bgtz        $t1, L_802B8BFC
    if (SIGNED(ctx->r9) > 0) {
        // 0x802B8BF0: or          $v1, $t1, $zero
        ctx->r3 = ctx->r9 | 0;
            goto L_802B8BFC;
    }
    // 0x802B8BF0: or          $v1, $t1, $zero
    ctx->r3 = ctx->r9 | 0;
    // 0x802B8BF4: b           L_802B8C00
    // 0x802B8BF8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
        goto L_802B8C00;
    // 0x802B8BF8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_802B8BFC:
    // 0x802B8BFC: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_802B8C00:
    // 0x802B8C00: div         $zero, $v0, $a0
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r4)));
    // 0x802B8C04: mflo        $a1
    ctx->r5 = lo;
    // 0x802B8C08: andi        $v1, $a1, 0xFFFF
    ctx->r3 = ctx->r5 & 0XFFFF;
    // 0x802B8C0C: bne         $a0, $zero, L_802B8C18
    if (ctx->r4 != 0) {
        // 0x802B8C10: nop
    
            goto L_802B8C18;
    }
    // 0x802B8C10: nop

    // 0x802B8C14: break       7
    do_break(2150337556);
L_802B8C18:
    // 0x802B8C18: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B8C1C: bne         $a0, $at, L_802B8C30
    if (ctx->r4 != ctx->r1) {
        // 0x802B8C20: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B8C30;
    }
    // 0x802B8C20: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B8C24: bne         $v0, $at, L_802B8C30
    if (ctx->r2 != ctx->r1) {
        // 0x802B8C28: nop
    
            goto L_802B8C30;
    }
    // 0x802B8C28: nop

    // 0x802B8C2C: break       6
    do_break(2150337580);
L_802B8C30:
    // 0x802B8C30: andi        $t2, $a1, 0xFFFF
    ctx->r10 = ctx->r5 & 0XFFFF;
    // 0x802B8C34: bgtz        $t2, L_802B8C48
    if (SIGNED(ctx->r10) > 0) {
        // 0x802B8C38: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_802B8C48;
    }
    // 0x802B8C38: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x802B8C3C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x802B8C40: jr          $ra
    // 0x802B8C44: andi        $v0, $a0, 0xFFFF
    ctx->r2 = ctx->r4 & 0XFFFF;
    return;
    // 0x802B8C44: andi        $v0, $a0, 0xFFFF
    ctx->r2 = ctx->r4 & 0XFFFF;
L_802B8C48:
    // 0x802B8C48: jr          $ra
    // 0x802B8C4C: andi        $v0, $a0, 0xFFFF
    ctx->r2 = ctx->r4 & 0XFFFF;
    return;
    // 0x802B8C4C: andi        $v0, $a0, 0xFFFF
    ctx->r2 = ctx->r4 & 0XFFFF;
;}
RECOMP_FUNC void func_802B8C50_6CA300(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B8C50: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x802B8C54: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802B8C58: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802B8C5C: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802B8C60: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x802B8C64: lh          $t8, 0x66($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X66);
    // 0x802B8C68: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802B8C6C: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x802B8C70: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802B8C74: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x802B8C78: bgez        $a3, L_802B8C88
    if (SIGNED(ctx->r7) >= 0) {
        // 0x802B8C7C: sra         $t7, $a3, 5
        ctx->r15 = S32(SIGNED(ctx->r7) >> 5);
            goto L_802B8C88;
    }
    // 0x802B8C7C: sra         $t7, $a3, 5
    ctx->r15 = S32(SIGNED(ctx->r7) >> 5);
    // 0x802B8C80: addiu       $at, $a3, 0x1F
    ctx->r1 = ADD32(ctx->r7, 0X1F);
    // 0x802B8C84: sra         $t7, $at, 5
    ctx->r15 = S32(SIGNED(ctx->r1) >> 5);
L_802B8C88:
    // 0x802B8C88: sh          $t7, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r15;
    // 0x802B8C8C: bgez        $t8, L_802B8C9C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802B8C90: sra         $t9, $t8, 5
        ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
            goto L_802B8C9C;
    }
    // 0x802B8C90: sra         $t9, $t8, 5
    ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
    // 0x802B8C94: addiu       $at, $t8, 0x1F
    ctx->r1 = ADD32(ctx->r24, 0X1F);
    // 0x802B8C98: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_802B8C9C:
    // 0x802B8C9C: sh          $t9, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r25;
    // 0x802B8CA0: addiu       $a1, $sp, 0x5E
    ctx->r5 = ADD32(ctx->r29, 0X5E);
    // 0x802B8CA4: addiu       $a2, $sp, 0x5C
    ctx->r6 = ADD32(ctx->r29, 0X5C);
    // 0x802B8CA8: jal         0x802B901C
    // 0x802B8CAC: lbu         $a0, 0x303($t0)
    ctx->r4 = MEM_BU(ctx->r8, 0X303);
    func_802B901C_6CA6CC(rdram, ctx);
        goto after_0;
    // 0x802B8CAC: lbu         $a0, 0x303($t0)
    ctx->r4 = MEM_BU(ctx->r8, 0X303);
    after_0:
    // 0x802B8CB0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8CB4: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8CB8: lh          $t1, 0x5E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8CBC: lh          $t4, 0x5C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X5C);
    // 0x802B8CC0: lhu         $t2, 0x4($a3)
    ctx->r10 = MEM_HU(ctx->r7, 0X4);
    // 0x802B8CC4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B8CC8: addu        $t3, $t1, $t2
    ctx->r11 = ADD32(ctx->r9, ctx->r10);
    // 0x802B8CCC: sh          $t3, 0x5E($sp)
    MEM_H(0X5E, ctx->r29) = ctx->r11;
    // 0x802B8CD0: lhu         $t5, 0x8($a3)
    ctx->r13 = MEM_HU(ctx->r7, 0X8);
    // 0x802B8CD4: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8CD8: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802B8CDC: sh          $t6, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r14;
    // 0x802B8CE0: lbu         $v1, 0x160($a3)
    ctx->r3 = MEM_BU(ctx->r7, 0X160);
    // 0x802B8CE4: beq         $v1, $zero, L_802B8D0C
    if (ctx->r3 == 0) {
        // 0x802B8CE8: nop
    
            goto L_802B8D0C;
    }
    // 0x802B8CE8: nop

    // 0x802B8CEC: beq         $v1, $at, L_802B8E28
    if (ctx->r3 == ctx->r1) {
        // 0x802B8CF0: lh          $a0, 0x5E($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X5E);
            goto L_802B8E28;
    }
    // 0x802B8CF0: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8CF4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802B8CF8: beq         $v1, $at, L_802B8EE0
    if (ctx->r3 == ctx->r1) {
        // 0x802B8CFC: lh          $a0, 0x5E($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X5E);
            goto L_802B8EE0;
    }
    // 0x802B8CFC: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8D00: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8D04: b           L_802B9008
    // 0x802B8D08: lw          $v1, 0x58($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X58);
        goto L_802B9008;
    // 0x802B8D08: lw          $v1, 0x58($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X58);
L_802B8D0C:
    // 0x802B8D0C: jal         0x80310F58
    // 0x802B8D10: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    func_80310F58_722608(rdram, ctx);
        goto after_1;
    // 0x802B8D10: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_1:
    // 0x802B8D14: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8D18: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8D1C: lui         $at, 0xA
    ctx->r1 = S32(0XA << 16);
    // 0x802B8D20: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8D24: lb          $t7, 0x4E($a3)
    ctx->r15 = MEM_B(ctx->r7, 0X4E);
    // 0x802B8D28: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8D2C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802B8D30: subu        $v1, $v0, $t8
    ctx->r3 = SUB32(ctx->r2, ctx->r24);
    // 0x802B8D34: addu        $t9, $a2, $at
    ctx->r25 = ADD32(ctx->r6, ctx->r1);
    // 0x802B8D38: slt         $at, $t9, $v1
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8D3C: beql        $at, $zero, L_802B8D68
    if (ctx->r1 == 0) {
        // 0x802B8D40: lw          $t2, 0x68($a3)
        ctx->r10 = MEM_W(ctx->r7, 0X68);
            goto L_802B8D68;
    }
    goto skip_0;
    // 0x802B8D40: lw          $t2, 0x68($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X68);
    skip_0:
    // 0x802B8D44: jal         0x8031124C
    // 0x802B8D48: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_2;
    // 0x802B8D48: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_2:
    // 0x802B8D4C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8D50: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8D54: lb          $t0, 0x4E($a3)
    ctx->r8 = MEM_B(ctx->r7, 0X4E);
    // 0x802B8D58: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8D5C: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802B8D60: subu        $v1, $v0, $t1
    ctx->r3 = SUB32(ctx->r2, ctx->r9);
    // 0x802B8D64: lw          $t2, 0x68($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X68);
L_802B8D68:
    // 0x802B8D68: addiu       $t3, $sp, 0x4C
    ctx->r11 = ADD32(ctx->r29, 0X4C);
    // 0x802B8D6C: addiu       $t4, $sp, 0x54
    ctx->r12 = ADD32(ctx->r29, 0X54);
    // 0x802B8D70: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x802B8D74: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x802B8D78: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x802B8D7C: lw          $t5, 0x70($a3)
    ctx->r13 = MEM_W(ctx->r7, 0X70);
    // 0x802B8D80: addiu       $t6, $sp, 0x48
    ctx->r14 = ADD32(ctx->r29, 0X48);
    // 0x802B8D84: addiu       $t7, $sp, 0x50
    ctx->r15 = ADD32(ctx->r29, 0X50);
    // 0x802B8D88: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x802B8D8C: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x802B8D90: sw          $v1, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r3;
    // 0x802B8D94: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8D98: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    // 0x802B8D9C: jal         0x8029B000
    // 0x802B8DA0: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    func_8029B000_6AC6B0(rdram, ctx);
        goto after_3;
    // 0x802B8DA0: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    after_3:
    // 0x802B8DA4: beq         $v0, $zero, L_802B8DF4
    if (ctx->r2 == 0) {
        // 0x802B8DA8: lw          $v1, 0x58($sp)
        ctx->r3 = MEM_W(ctx->r29, 0X58);
            goto L_802B8DF4;
    }
    // 0x802B8DA8: lw          $v1, 0x58($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X58);
    // 0x802B8DAC: lw          $t8, 0x54($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X54);
    // 0x802B8DB0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8DB4: slt         $at, $v1, $t8
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B8DB8: beq         $at, $zero, L_802B8DF4
    if (ctx->r1 == 0) {
        // 0x802B8DBC: nop
    
            goto L_802B8DF4;
    }
    // 0x802B8DBC: nop

    // 0x802B8DC0: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8DC4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B8DC8: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802B8DCC: lbu         $t9, 0x161($a3)
    ctx->r25 = MEM_BU(ctx->r7, 0X161);
    // 0x802B8DD0: bne         $t9, $at, L_802B8DF4
    if (ctx->r25 != ctx->r1) {
        // 0x802B8DD4: nop
    
            goto L_802B8DF4;
    }
    // 0x802B8DD4: nop

    // 0x802B8DD8: lw          $v0, 0xC($a3)
    ctx->r2 = MEM_W(ctx->r7, 0XC);
    // 0x802B8DDC: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    // 0x802B8DE0: addu        $v0, $v0, $at
    ctx->r2 = ADD32(ctx->r2, ctx->r1);
    // 0x802B8DE4: slt         $at, $v0, $t8
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x802B8DE8: bne         $at, $zero, L_802B8DF4
    if (ctx->r1 != 0) {
        // 0x802B8DEC: nop
    
            goto L_802B8DF4;
    }
    // 0x802B8DEC: nop

    // 0x802B8DF0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8DF4:
    // 0x802B8DF4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8DF8: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8DFC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B8E00: lbu         $t0, 0x161($a3)
    ctx->r8 = MEM_BU(ctx->r7, 0X161);
    // 0x802B8E04: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8E08: bne         $t0, $at, L_802B9008
    if (ctx->r8 != ctx->r1) {
        // 0x802B8E0C: lui         $at, 0xFFF6
        ctx->r1 = S32(0XFFF6 << 16);
            goto L_802B9008;
    }
    // 0x802B8E0C: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    // 0x802B8E10: addu        $v0, $a2, $at
    ctx->r2 = ADD32(ctx->r6, ctx->r1);
    // 0x802B8E14: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8E18: bnel        $at, $zero, L_802B900C
    if (ctx->r1 != 0) {
        // 0x802B8E1C: lw          $ra, 0x2C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X2C);
            goto L_802B900C;
    }
    goto skip_1;
    // 0x802B8E1C: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    skip_1:
    // 0x802B8E20: b           L_802B9008
    // 0x802B8E24: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802B9008;
    // 0x802B8E24: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8E28:
    // 0x802B8E28: jal         0x8031124C
    // 0x802B8E2C: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_4;
    // 0x802B8E2C: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_4:
    // 0x802B8E30: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8E34: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8E38: addiu       $t4, $sp, 0x4C
    ctx->r12 = ADD32(ctx->r29, 0X4C);
    // 0x802B8E3C: addiu       $t5, $sp, 0x54
    ctx->r13 = ADD32(ctx->r29, 0X54);
    // 0x802B8E40: lb          $t1, 0x4E($a3)
    ctx->r9 = MEM_B(ctx->r7, 0X4E);
    // 0x802B8E44: lw          $t3, 0x68($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X68);
    // 0x802B8E48: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8E4C: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802B8E50: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x802B8E54: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802B8E58: lw          $t6, 0x70($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X70);
    // 0x802B8E5C: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x802B8E60: subu        $v1, $v0, $t2
    ctx->r3 = SUB32(ctx->r2, ctx->r10);
    // 0x802B8E64: addiu       $t7, $sp, 0x48
    ctx->r15 = ADD32(ctx->r29, 0X48);
    // 0x802B8E68: addiu       $t9, $sp, 0x50
    ctx->r25 = ADD32(ctx->r29, 0X50);
    // 0x802B8E6C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x802B8E70: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x802B8E74: sw          $v1, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r3;
    // 0x802B8E78: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8E7C: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    // 0x802B8E80: jal         0x8029B000
    // 0x802B8E84: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_8029B000_6AC6B0(rdram, ctx);
        goto after_5;
    // 0x802B8E84: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_5:
    // 0x802B8E88: beq         $v0, $zero, L_802B8EA4
    if (ctx->r2 == 0) {
        // 0x802B8E8C: lw          $v1, 0x58($sp)
        ctx->r3 = MEM_W(ctx->r29, 0X58);
            goto L_802B8EA4;
    }
    // 0x802B8E8C: lw          $v1, 0x58($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X58);
    // 0x802B8E90: lw          $v0, 0x54($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X54);
    // 0x802B8E94: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B8E98: beq         $at, $zero, L_802B8EA4
    if (ctx->r1 == 0) {
        // 0x802B8E9C: nop
    
            goto L_802B8EA4;
    }
    // 0x802B8E9C: nop

    // 0x802B8EA0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8EA4:
    // 0x802B8EA4: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8EA8: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8EAC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B8EB0: lbu         $t8, 0x161($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X161);
    // 0x802B8EB4: bne         $t8, $at, L_802B8ED8
    if (ctx->r24 != ctx->r1) {
        // 0x802B8EB8: nop
    
            goto L_802B8ED8;
    }
    // 0x802B8EB8: nop

    // 0x802B8EBC: lw          $v0, 0xC($a3)
    ctx->r2 = MEM_W(ctx->r7, 0XC);
    // 0x802B8EC0: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    // 0x802B8EC4: addu        $v0, $v0, $at
    ctx->r2 = ADD32(ctx->r2, ctx->r1);
    // 0x802B8EC8: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8ECC: bne         $at, $zero, L_802B8ED8
    if (ctx->r1 != 0) {
        // 0x802B8ED0: nop
    
            goto L_802B8ED8;
    }
    // 0x802B8ED0: nop

    // 0x802B8ED4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8ED8:
    // 0x802B8ED8: b           L_802B9008
    // 0x802B8EDC: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
        goto L_802B9008;
    // 0x802B8EDC: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
L_802B8EE0:
    // 0x802B8EE0: jal         0x80310F58
    // 0x802B8EE4: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    func_80310F58_722608(rdram, ctx);
        goto after_6;
    // 0x802B8EE4: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_6:
    // 0x802B8EE8: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x802B8EEC: bne         $v0, $at, L_802B8F5C
    if (ctx->r2 != ctx->r1) {
        // 0x802B8EF0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802B8F5C;
    }
    // 0x802B8EF0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802B8EF4: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8EF8: jal         0x8031124C
    // 0x802B8EFC: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_7;
    // 0x802B8EFC: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_7:
    // 0x802B8F00: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8F04: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8F08: lh          $a0, 0x4($a3)
    ctx->r4 = MEM_H(ctx->r7, 0X4);
    // 0x802B8F0C: lh          $a1, 0x8($a3)
    ctx->r5 = MEM_H(ctx->r7, 0X8);
    // 0x802B8F10: jal         0x80310F58
    // 0x802B8F14: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    func_80310F58_722608(rdram, ctx);
        goto after_8;
    // 0x802B8F14: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    after_8:
    // 0x802B8F18: lw          $v1, 0x40($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X40);
    // 0x802B8F1C: lui         $at, 0xFFFB
    ctx->r1 = S32(0XFFFB << 16);
    // 0x802B8F20: addu        $t0, $v0, $at
    ctx->r8 = ADD32(ctx->r2, ctx->r1);
    // 0x802B8F24: slt         $at, $t0, $v1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8F28: beq         $at, $zero, L_802B8F44
    if (ctx->r1 == 0) {
        // 0x802B8F2C: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802B8F44;
    }
    // 0x802B8F2C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8F30: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8F34: jal         0x8031124C
    // 0x802B8F38: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    sample_ground_height_at_xz(rdram, ctx);
        goto after_9;
    // 0x802B8F38: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    after_9:
    // 0x802B8F3C: b           L_802B8F5C
    // 0x802B8F40: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802B8F5C;
    // 0x802B8F40: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8F44:
    // 0x802B8F44: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8F48: lh          $a0, 0x4($a3)
    ctx->r4 = MEM_H(ctx->r7, 0X4);
    // 0x802B8F4C: jal         0x80310F58
    // 0x802B8F50: lh          $a1, 0x8($a3)
    ctx->r5 = MEM_H(ctx->r7, 0X8);
    func_80310F58_722608(rdram, ctx);
        goto after_10;
    // 0x802B8F50: lh          $a1, 0x8($a3)
    ctx->r5 = MEM_H(ctx->r7, 0X8);
    after_10:
    // 0x802B8F54: lui         $at, 0xFFFB
    ctx->r1 = S32(0XFFFB << 16);
    // 0x802B8F58: addu        $v1, $v0, $at
    ctx->r3 = ADD32(ctx->r2, ctx->r1);
L_802B8F5C:
    // 0x802B8F5C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8F60: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8F64: addiu       $t4, $sp, 0x4C
    ctx->r12 = ADD32(ctx->r29, 0X4C);
    // 0x802B8F68: addiu       $t5, $sp, 0x54
    ctx->r13 = ADD32(ctx->r29, 0X54);
    // 0x802B8F6C: lb          $t1, 0x4E($a3)
    ctx->r9 = MEM_B(ctx->r7, 0X4E);
    // 0x802B8F70: lw          $t3, 0x68($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X68);
    // 0x802B8F74: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    // 0x802B8F78: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x802B8F7C: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x802B8F80: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802B8F84: lw          $t6, 0x70($a3)
    ctx->r14 = MEM_W(ctx->r7, 0X70);
    // 0x802B8F88: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x802B8F8C: subu        $v1, $v1, $t2
    ctx->r3 = SUB32(ctx->r3, ctx->r10);
    // 0x802B8F90: addiu       $t7, $sp, 0x48
    ctx->r15 = ADD32(ctx->r29, 0X48);
    // 0x802B8F94: addiu       $t9, $sp, 0x50
    ctx->r25 = ADD32(ctx->r29, 0X50);
    // 0x802B8F98: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x802B8F9C: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x802B8FA0: sw          $v1, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r3;
    // 0x802B8FA4: lh          $a0, 0x5E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X5E);
    // 0x802B8FA8: lh          $a1, 0x5C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X5C);
    // 0x802B8FAC: jal         0x8029B000
    // 0x802B8FB0: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_8029B000_6AC6B0(rdram, ctx);
        goto after_11;
    // 0x802B8FB0: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_11:
    // 0x802B8FB4: beq         $v0, $zero, L_802B8FD0
    if (ctx->r2 == 0) {
        // 0x802B8FB8: lw          $v1, 0x58($sp)
        ctx->r3 = MEM_W(ctx->r29, 0X58);
            goto L_802B8FD0;
    }
    // 0x802B8FB8: lw          $v1, 0x58($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X58);
    // 0x802B8FBC: lw          $v0, 0x54($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X54);
    // 0x802B8FC0: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B8FC4: beq         $at, $zero, L_802B8FD0
    if (ctx->r1 == 0) {
        // 0x802B8FC8: nop
    
            goto L_802B8FD0;
    }
    // 0x802B8FC8: nop

    // 0x802B8FCC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802B8FD0:
    // 0x802B8FD0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802B8FD4: lw          $a3, 0x5530($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X5530);
    // 0x802B8FD8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802B8FDC: lbu         $t8, 0x161($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X161);
    // 0x802B8FE0: bnel        $t8, $at, L_802B9008
    if (ctx->r24 != ctx->r1) {
        // 0x802B8FE4: lw          $a2, 0xC($a3)
        ctx->r6 = MEM_W(ctx->r7, 0XC);
            goto L_802B9008;
    }
    goto skip_2;
    // 0x802B8FE4: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    skip_2:
    // 0x802B8FE8: lw          $v0, 0xC($a3)
    ctx->r2 = MEM_W(ctx->r7, 0XC);
    // 0x802B8FEC: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    // 0x802B8FF0: addu        $v0, $v0, $at
    ctx->r2 = ADD32(ctx->r2, ctx->r1);
    // 0x802B8FF4: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B8FF8: bnel        $at, $zero, L_802B9008
    if (ctx->r1 != 0) {
        // 0x802B8FFC: lw          $a2, 0xC($a3)
        ctx->r6 = MEM_W(ctx->r7, 0XC);
            goto L_802B9008;
    }
    goto skip_3;
    // 0x802B8FFC: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
    skip_3:
    // 0x802B9000: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802B9004: lw          $a2, 0xC($a3)
    ctx->r6 = MEM_W(ctx->r7, 0XC);
L_802B9008:
    // 0x802B9008: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
L_802B900C:
    // 0x802B900C: subu        $v0, $v1, $a2
    ctx->r2 = SUB32(ctx->r3, ctx->r6);
    // 0x802B9010: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802B9014: jr          $ra
    // 0x802B9018: nop

    return;
    // 0x802B9018: nop

;}
RECOMP_FUNC void func_802B901C_6CA6CC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B901C: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x802B9020: andi        $t8, $a0, 0xFF
    ctx->r24 = ctx->r4 & 0XFF;
    // 0x802B9024: addiu       $t3, $t3, 0x2C78
    ctx->r11 = ADD32(ctx->r11, 0X2C78);
    // 0x802B9028: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B902C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802B9030: addu        $t4, $t3, $t9
    ctx->r12 = ADD32(ctx->r11, ctx->r25);
    // 0x802B9034: lh          $v0, 0x0($t4)
    ctx->r2 = MEM_H(ctx->r12, 0X0);
    // 0x802B9038: lh          $t1, 0x0($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X0);
    // 0x802B903C: addiu       $t5, $a0, 0x40
    ctx->r13 = ADD32(ctx->r4, 0X40);
    // 0x802B9040: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802B9044: multu       $t1, $v0
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9048: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802B904C: addu        $t8, $t3, $t7
    ctx->r24 = ADD32(ctx->r11, ctx->r15);
    // 0x802B9050: lh          $a3, 0x0($t8)
    ctx->r7 = MEM_H(ctx->r24, 0X0);
    // 0x802B9054: lh          $t2, 0x0($a1)
    ctx->r10 = MEM_H(ctx->r5, 0X0);
    // 0x802B9058: mflo        $t9
    ctx->r25 = lo;
    // 0x802B905C: nop

    // 0x802B9060: nop

    // 0x802B9064: multu       $a3, $t2
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9068: mflo        $t4
    ctx->r12 = lo;
    // 0x802B906C: addu        $t0, $t9, $t4
    ctx->r8 = ADD32(ctx->r25, ctx->r12);
    // 0x802B9070: sra         $t7, $t0, 15
    ctx->r15 = S32(SIGNED(ctx->r8) >> 15);
    // 0x802B9074: multu       $a3, $t1
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9078: mflo        $t8
    ctx->r24 = lo;
    // 0x802B907C: nop

    // 0x802B9080: nop

    // 0x802B9084: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9088: mflo        $t9
    ctx->r25 = lo;
    // 0x802B908C: subu        $t4, $t8, $t9
    ctx->r12 = SUB32(ctx->r24, ctx->r25);
    // 0x802B9090: sra         $t5, $t4, 15
    ctx->r13 = S32(SIGNED(ctx->r12) >> 15);
    // 0x802B9094: sh          $t5, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r13;
    // 0x802B9098: jr          $ra
    // 0x802B909C: sh          $t7, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r15;
    return;
    // 0x802B909C: sh          $t7, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r15;
;}
RECOMP_FUNC void func_802B90A0_6CA750(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B90A0: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x802B90A4: andi        $t8, $a0, 0xFF
    ctx->r24 = ctx->r4 & 0XFF;
    // 0x802B90A8: addiu       $t3, $t3, 0x2C78
    ctx->r11 = ADD32(ctx->r11, 0X2C78);
    // 0x802B90AC: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B90B0: addu        $t4, $t3, $t9
    ctx->r12 = ADD32(ctx->r11, ctx->r25);
    // 0x802B90B4: lh          $v0, 0x0($t4)
    ctx->r2 = MEM_H(ctx->r12, 0X0);
    // 0x802B90B8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802B90BC: lw          $t1, 0x0($a2)
    ctx->r9 = MEM_W(ctx->r6, 0X0);
    // 0x802B90C0: sra         $t5, $v0, 7
    ctx->r13 = S32(SIGNED(ctx->r2) >> 7);
    // 0x802B90C4: addiu       $t6, $a0, 0x40
    ctx->r14 = ADD32(ctx->r4, 0X40);
    // 0x802B90C8: multu       $t1, $t5
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B90CC: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802B90D0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802B90D4: addu        $t9, $t3, $t8
    ctx->r25 = ADD32(ctx->r11, ctx->r24);
    // 0x802B90D8: lh          $a3, 0x0($t9)
    ctx->r7 = MEM_H(ctx->r25, 0X0);
    // 0x802B90DC: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x802B90E0: lw          $t2, 0x0($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X0);
    // 0x802B90E4: sra         $t4, $a3, 7
    ctx->r12 = S32(SIGNED(ctx->r7) >> 7);
    // 0x802B90E8: mflo        $t5
    ctx->r13 = lo;
    // 0x802B90EC: nop

    // 0x802B90F0: nop

    // 0x802B90F4: multu       $t4, $t2
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B90F8: mflo        $t6
    ctx->r14 = lo;
    // 0x802B90FC: addu        $t0, $t5, $t6
    ctx->r8 = ADD32(ctx->r13, ctx->r14);
    // 0x802B9100: sra         $t7, $t0, 8
    ctx->r15 = S32(SIGNED(ctx->r8) >> 8);
    // 0x802B9104: multu       $t4, $t1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9108: mflo        $t8
    ctx->r24 = lo;
    // 0x802B910C: nop

    // 0x802B9110: nop

    // 0x802B9114: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9118: mflo        $t9
    ctx->r25 = lo;
    // 0x802B911C: subu        $t4, $t8, $t9
    ctx->r12 = SUB32(ctx->r24, ctx->r25);
    // 0x802B9120: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x802B9124: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x802B9128: jr          $ra
    // 0x802B912C: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    return;
    // 0x802B912C: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
;}
RECOMP_FUNC void func_802B9130_6CA7E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B9130: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802B9134: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B9138: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B913C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802B9140: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802B9144: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x802B9148: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x802B914C: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x802B9150: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x802B9154: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x802B9158: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B915C: lui         $s0, 0x8020
    ctx->r16 = S32(0X8020 << 16);
    // 0x802B9160: beq         $v0, $at, L_802B91A4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9164: addiu       $s0, $s0, 0x3FE0
        ctx->r16 = ADD32(ctx->r16, 0X3FE0);
            goto L_802B91A4;
    }
    // 0x802B9164: addiu       $s0, $s0, 0x3FE0
    ctx->r16 = ADD32(ctx->r16, 0X3FE0);
    // 0x802B9168: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B916C: beq         $v0, $at, L_802B91A4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9170: nop
    
            goto L_802B91A4;
    }
    // 0x802B9170: nop

    // 0x802B9174: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B9178: beq         $v0, $at, L_802B91A4
    if (ctx->r2 == ctx->r1) {
        // 0x802B917C: nop
    
            goto L_802B91A4;
    }
    // 0x802B917C: nop

    // 0x802B9180: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B9184: beq         $v0, $at, L_802B91A4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9188: nop
    
            goto L_802B91A4;
    }
    // 0x802B9188: nop

    // 0x802B918C: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B9190: beq         $v0, $at, L_802B91A4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9194: nop
    
            goto L_802B91A4;
    }
    // 0x802B9194: nop

    // 0x802B9198: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B919C: bne         $v0, $at, L_802B9204
    if (ctx->r2 != ctx->r1) {
        // 0x802B91A0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_802B9204;
    }
    // 0x802B91A0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
L_802B91A4:
    // 0x802B91A4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x802B91A8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B91AC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B91B0: lhu         $t7, 0x2F2($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B91B4: lhu         $t9, 0x2FA($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B91B8: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B91BC: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802B91C0: mflo        $t0
    ctx->r8 = lo;
    // 0x802B91C4: sh          $t0, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r8;
    // 0x802B91C8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B91CC: bne         $t9, $zero, L_802B91D8
    if (ctx->r25 != 0) {
        // 0x802B91D0: nop
    
            goto L_802B91D8;
    }
    // 0x802B91D0: nop

    // 0x802B91D4: break       7
    do_break(2150339028);
L_802B91D8:
    // 0x802B91D8: lhu         $t1, 0x2F4($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B91DC: lhu         $t3, 0x2FA($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B91E0: sll         $t2, $t1, 8
    ctx->r10 = S32(ctx->r9 << 8);
    // 0x802B91E4: divu        $zero, $t2, $t3
    lo = S32(U32(ctx->r10) / U32(ctx->r11)); hi = S32(U32(ctx->r10) % U32(ctx->r11));
    // 0x802B91E8: mflo        $t4
    ctx->r12 = lo;
    // 0x802B91EC: sh          $t4, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r12;
    // 0x802B91F0: bne         $t3, $zero, L_802B91FC
    if (ctx->r11 != 0) {
        // 0x802B91F4: nop
    
            goto L_802B91FC;
    }
    // 0x802B91F4: nop

    // 0x802B91F8: break       7
    do_break(2150339064);
L_802B91FC:
    // 0x802B91FC: b           L_802B9224
    // 0x802B9200: lh          $v0, 0x42($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X42);
        goto L_802B9224;
    // 0x802B9200: lh          $v0, 0x42($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X42);
L_802B9204:
    // 0x802B9204: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x802B9208: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B920C: lhu         $t5, 0x2F2($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9210: sh          $t5, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r13;
    // 0x802B9214: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802B9218: lhu         $t6, 0x2F4($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B921C: sh          $t6, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r14;
    // 0x802B9220: lh          $v0, 0x42($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X42);
L_802B9224:
    // 0x802B9224: lh          $v1, 0x3E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X3E);
    // 0x802B9228: lh          $t7, 0x3E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X3E);
    // 0x802B922C: lh          $t8, 0x42($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X42);
    // 0x802B9230: lh          $t9, 0x3E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X3E);
    // 0x802B9234: lh          $t0, 0x42($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X42);
    // 0x802B9238: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x802B923C: negu        $v1, $v1
    ctx->r3 = SUB32(0, ctx->r3);
    // 0x802B9240: sh          $v0, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r2;
    // 0x802B9244: sh          $zero, 0x1C($s0)
    MEM_H(0X1C, ctx->r16) = 0;
    // 0x802B9248: sh          $zero, 0x24($s0)
    MEM_H(0X24, ctx->r16) = 0;
    // 0x802B924C: sh          $v1, 0x2A($s0)
    MEM_H(0X2A, ctx->r16) = ctx->r3;
    // 0x802B9250: sh          $v0, 0x28($s0)
    MEM_H(0X28, ctx->r16) = ctx->r2;
    // 0x802B9254: sh          $zero, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = 0;
    // 0x802B9258: sh          $v1, 0x32($s0)
    MEM_H(0X32, ctx->r16) = ctx->r3;
    // 0x802B925C: sh          $zero, 0x34($s0)
    MEM_H(0X34, ctx->r16) = 0;
    // 0x802B9260: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802B9264: sw          $v0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r2;
    // 0x802B9268: lhu         $a0, 0x3E($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X3E);
    // 0x802B926C: lhu         $a1, 0x42($sp)
    ctx->r5 = MEM_HU(ctx->r29, 0X42);
    // 0x802B9270: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x802B9274: sh          $t7, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r15;
    // 0x802B9278: sh          $t8, 0x20($s0)
    MEM_H(0X20, ctx->r16) = ctx->r24;
    // 0x802B927C: sh          $t9, 0x22($s0)
    MEM_H(0X22, ctx->r16) = ctx->r25;
    // 0x802B9280: jal         0x802BCF38
    // 0x802B9284: sh          $t0, 0x30($s0)
    MEM_H(0X30, ctx->r16) = ctx->r8;
    func_802BCF38_6CE5E8(rdram, ctx);
        goto after_0;
    // 0x802B9284: sh          $t0, 0x30($s0)
    MEM_H(0X30, ctx->r16) = ctx->r8;
    after_0:
    // 0x802B9288: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x802B928C: lh          $v0, 0x0($a2)
    ctx->r2 = MEM_H(ctx->r6, 0X0);
    // 0x802B9290: lh          $t1, 0x2($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X2);
    // 0x802B9294: addu        $t2, $t1, $v0
    ctx->r10 = ADD32(ctx->r9, ctx->r2);
    // 0x802B9298: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802B929C: sh          $t3, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r11;
    // 0x802B92A0: sll         $t8, $t3, 16
    ctx->r24 = S32(ctx->r11 << 16);
    // 0x802B92A4: lh          $t5, 0x4($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X4);
    // 0x802B92A8: lh          $t4, 0x6($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X6);
    // 0x802B92AC: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B92B0: lh          $t2, 0x42($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X42);
    // 0x802B92B4: subu        $v1, $v0, $t9
    ctx->r3 = SUB32(ctx->r2, ctx->r25);
    // 0x802B92B8: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x802B92BC: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802B92C0: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802B92C4: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802B92C8: slt         $at, $t1, $t2
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802B92CC: sh          $t7, 0x34($sp)
    MEM_H(0X34, ctx->r29) = ctx->r15;
    // 0x802B92D0: bne         $at, $zero, L_802B92E0
    if (ctx->r1 != 0) {
        // 0x802B92D4: or          $v1, $t1, $zero
        ctx->r3 = ctx->r9 | 0;
            goto L_802B92E0;
    }
    // 0x802B92D4: or          $v1, $t1, $zero
    ctx->r3 = ctx->r9 | 0;
    // 0x802B92D8: b           L_802B9348
    // 0x802B92DC: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
        goto L_802B9348;
    // 0x802B92DC: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
L_802B92E0:
    // 0x802B92E0: lw          $t4, 0x28($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X28);
    // 0x802B92E4: lh          $t6, 0x42($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X42);
    // 0x802B92E8: slt         $at, $t4, $v1
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B92EC: bnel        $at, $zero, L_802B9300
    if (ctx->r1 != 0) {
        // 0x802B92F0: sll         $t5, $v1, 8
        ctx->r13 = S32(ctx->r3 << 8);
            goto L_802B9300;
    }
    goto skip_0;
    // 0x802B92F0: sll         $t5, $v1, 8
    ctx->r13 = S32(ctx->r3 << 8);
    skip_0:
    // 0x802B92F4: b           L_802B9348
    // 0x802B92F8: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
        goto L_802B9348;
    // 0x802B92F8: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
    // 0x802B92FC: sll         $t5, $v1, 8
    ctx->r13 = S32(ctx->r3 << 8);
L_802B9300:
    // 0x802B9300: div         $zero, $t5, $t6
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r14))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r14)));
    // 0x802B9304: mflo        $a0
    ctx->r4 = lo;
    // 0x802B9308: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x802B930C: bne         $t6, $zero, L_802B9318
    if (ctx->r14 != 0) {
        // 0x802B9310: nop
    
            goto L_802B9318;
    }
    // 0x802B9310: nop

    // 0x802B9314: break       7
    do_break(2150339348);
L_802B9318:
    // 0x802B9318: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B931C: bne         $t6, $at, L_802B9330
    if (ctx->r14 != ctx->r1) {
        // 0x802B9320: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B9330;
    }
    // 0x802B9320: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B9324: bne         $t5, $at, L_802B9330
    if (ctx->r13 != ctx->r1) {
        // 0x802B9328: nop
    
            goto L_802B9330;
    }
    // 0x802B9328: nop

    // 0x802B932C: break       6
    do_break(2150339372);
L_802B9330:
    // 0x802B9330: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B9334: jal         0x8012835C
    // 0x802B9338: nop

    func_8012835C(rdram, ctx);
        goto after_1;
    // 0x802B9338: nop

    after_1:
    // 0x802B933C: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x802B9340: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B9344: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
L_802B9348:
    // 0x802B9348: slti        $at, $a1, -0x1E
    ctx->r1 = SIGNED(ctx->r5) < -0X1E ? 1 : 0;
    // 0x802B934C: beq         $at, $zero, L_802B9370
    if (ctx->r1 == 0) {
        // 0x802B9350: lui         $a0, 0x8020
        ctx->r4 = S32(0X8020 << 16);
            goto L_802B9370;
    }
    // 0x802B9350: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B9354: bgez        $a1, L_802B9364
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9358: sra         $t9, $a1, 1
        ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B9364;
    }
    // 0x802B9358: sra         $t9, $a1, 1
    ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B935C: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9360: sra         $t9, $at, 1
    ctx->r25 = S32(SIGNED(ctx->r1) >> 1);
L_802B9364:
    // 0x802B9364: addiu       $a1, $t9, -0xF
    ctx->r5 = ADD32(ctx->r25, -0XF);
    // 0x802B9368: sll         $t0, $a1, 16
    ctx->r8 = S32(ctx->r5 << 16);
    // 0x802B936C: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
L_802B9370:
    // 0x802B9370: slti        $at, $a1, 0x1F
    ctx->r1 = SIGNED(ctx->r5) < 0X1F ? 1 : 0;
    // 0x802B9374: bne         $at, $zero, L_802B9398
    if (ctx->r1 != 0) {
        // 0x802B9378: addiu       $a0, $a0, 0x3FF8
        ctx->r4 = ADD32(ctx->r4, 0X3FF8);
            goto L_802B9398;
    }
    // 0x802B9378: addiu       $a0, $a0, 0x3FF8
    ctx->r4 = ADD32(ctx->r4, 0X3FF8);
    // 0x802B937C: bgez        $a1, L_802B938C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9380: sra         $t2, $a1, 1
        ctx->r10 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B938C;
    }
    // 0x802B9380: sra         $t2, $a1, 1
    ctx->r10 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B9384: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9388: sra         $t2, $at, 1
    ctx->r10 = S32(SIGNED(ctx->r1) >> 1);
L_802B938C:
    // 0x802B938C: addiu       $a1, $t2, 0xF
    ctx->r5 = ADD32(ctx->r10, 0XF);
    // 0x802B9390: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x802B9394: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
L_802B9398:
    // 0x802B9398: jal         0x802C7A7C
    // 0x802B939C: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    func_802C7A7C_6D912C(rdram, ctx);
        goto after_2;
    // 0x802B939C: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    after_2:
    // 0x802B93A0: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B93A4: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    // 0x802B93A8: jal         0x802C7A7C
    // 0x802B93AC: addiu       $a0, $a0, 0x4000
    ctx->r4 = ADD32(ctx->r4, 0X4000);
    func_802C7A7C_6D912C(rdram, ctx);
        goto after_3;
    // 0x802B93AC: addiu       $a0, $a0, 0x4000
    ctx->r4 = ADD32(ctx->r4, 0X4000);
    after_3:
    // 0x802B93B0: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x802B93B4: lh          $t7, 0x34($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X34);
    // 0x802B93B8: lh          $t9, 0x42($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X42);
    // 0x802B93BC: lh          $t6, 0x4($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X4);
    // 0x802B93C0: subu        $v1, $t6, $t7
    ctx->r3 = SUB32(ctx->r14, ctx->r15);
    // 0x802B93C4: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x802B93C8: sra         $t8, $t3, 16
    ctx->r24 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802B93CC: slt         $at, $t8, $t9
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x802B93D0: bne         $at, $zero, L_802B93E0
    if (ctx->r1 != 0) {
        // 0x802B93D4: or          $v1, $t8, $zero
        ctx->r3 = ctx->r24 | 0;
            goto L_802B93E0;
    }
    // 0x802B93D4: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x802B93D8: b           L_802B9448
    // 0x802B93DC: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
        goto L_802B9448;
    // 0x802B93DC: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
L_802B93E0:
    // 0x802B93E0: lw          $t0, 0x28($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X28);
    // 0x802B93E4: lh          $t2, 0x42($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X42);
    // 0x802B93E8: slt         $at, $t0, $v1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B93EC: bnel        $at, $zero, L_802B9400
    if (ctx->r1 != 0) {
        // 0x802B93F0: sll         $t1, $v1, 8
        ctx->r9 = S32(ctx->r3 << 8);
            goto L_802B9400;
    }
    goto skip_1;
    // 0x802B93F0: sll         $t1, $v1, 8
    ctx->r9 = S32(ctx->r3 << 8);
    skip_1:
    // 0x802B93F4: b           L_802B9448
    // 0x802B93F8: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
        goto L_802B9448;
    // 0x802B93F8: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
    // 0x802B93FC: sll         $t1, $v1, 8
    ctx->r9 = S32(ctx->r3 << 8);
L_802B9400:
    // 0x802B9400: div         $zero, $t1, $t2
    lo = S32(S64(S32(ctx->r9)) / S64(S32(ctx->r10))); hi = S32(S64(S32(ctx->r9)) % S64(S32(ctx->r10)));
    // 0x802B9404: mflo        $a0
    ctx->r4 = lo;
    // 0x802B9408: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x802B940C: bne         $t2, $zero, L_802B9418
    if (ctx->r10 != 0) {
        // 0x802B9410: nop
    
            goto L_802B9418;
    }
    // 0x802B9410: nop

    // 0x802B9414: break       7
    do_break(2150339604);
L_802B9418:
    // 0x802B9418: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B941C: bne         $t2, $at, L_802B9430
    if (ctx->r10 != ctx->r1) {
        // 0x802B9420: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B9430;
    }
    // 0x802B9420: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B9424: bne         $t1, $at, L_802B9430
    if (ctx->r9 != ctx->r1) {
        // 0x802B9428: nop
    
            goto L_802B9430;
    }
    // 0x802B9428: nop

    // 0x802B942C: break       6
    do_break(2150339628);
L_802B9430:
    // 0x802B9430: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802B9434: jal         0x8012835C
    // 0x802B9438: nop

    func_8012835C(rdram, ctx);
        goto after_4;
    // 0x802B9438: nop

    after_4:
    // 0x802B943C: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x802B9440: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x802B9444: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
L_802B9448:
    // 0x802B9448: slti        $at, $a1, -0x1E
    ctx->r1 = SIGNED(ctx->r5) < -0X1E ? 1 : 0;
    // 0x802B944C: beq         $at, $zero, L_802B9470
    if (ctx->r1 == 0) {
        // 0x802B9450: lui         $a0, 0x8020
        ctx->r4 = S32(0X8020 << 16);
            goto L_802B9470;
    }
    // 0x802B9450: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B9454: bgez        $a1, L_802B9464
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9458: sra         $t7, $a1, 1
        ctx->r15 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B9464;
    }
    // 0x802B9458: sra         $t7, $a1, 1
    ctx->r15 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B945C: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9460: sra         $t7, $at, 1
    ctx->r15 = S32(SIGNED(ctx->r1) >> 1);
L_802B9464:
    // 0x802B9464: addiu       $a1, $t7, -0xF
    ctx->r5 = ADD32(ctx->r15, -0XF);
    // 0x802B9468: sll         $t3, $a1, 16
    ctx->r11 = S32(ctx->r5 << 16);
    // 0x802B946C: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
L_802B9470:
    // 0x802B9470: slti        $at, $a1, 0x1F
    ctx->r1 = SIGNED(ctx->r5) < 0X1F ? 1 : 0;
    // 0x802B9474: bne         $at, $zero, L_802B9498
    if (ctx->r1 != 0) {
        // 0x802B9478: addiu       $a0, $a0, 0x4008
        ctx->r4 = ADD32(ctx->r4, 0X4008);
            goto L_802B9498;
    }
    // 0x802B9478: addiu       $a0, $a0, 0x4008
    ctx->r4 = ADD32(ctx->r4, 0X4008);
    // 0x802B947C: bgez        $a1, L_802B948C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9480: sra         $t9, $a1, 1
        ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B948C;
    }
    // 0x802B9480: sra         $t9, $a1, 1
    ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B9484: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9488: sra         $t9, $at, 1
    ctx->r25 = S32(SIGNED(ctx->r1) >> 1);
L_802B948C:
    // 0x802B948C: addiu       $a1, $t9, 0xF
    ctx->r5 = ADD32(ctx->r25, 0XF);
    // 0x802B9490: sll         $t0, $a1, 16
    ctx->r8 = S32(ctx->r5 << 16);
    // 0x802B9494: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
L_802B9498:
    // 0x802B9498: jal         0x802C7A7C
    // 0x802B949C: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    func_802C7A7C_6D912C(rdram, ctx);
        goto after_5;
    // 0x802B949C: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    after_5:
    // 0x802B94A0: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B94A4: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    // 0x802B94A8: jal         0x802C7A7C
    // 0x802B94AC: addiu       $a0, $a0, 0x4010
    ctx->r4 = ADD32(ctx->r4, 0X4010);
    func_802C7A7C_6D912C(rdram, ctx);
        goto after_6;
    // 0x802B94AC: addiu       $a0, $a0, 0x4010
    ctx->r4 = ADD32(ctx->r4, 0X4010);
    after_6:
    // 0x802B94B0: lh          $t2, 0x36($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X36);
    // 0x802B94B4: lh          $t4, 0x34($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X34);
    // 0x802B94B8: lh          $v1, 0x3E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X3E);
    // 0x802B94BC: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x802B94C0: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x802B94C4: sra         $t6, $t5, 1
    ctx->r14 = S32(SIGNED(ctx->r13) >> 1);
    // 0x802B94C8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802B94CC: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B94D0: subu        $v0, $t2, $t3
    ctx->r2 = SUB32(ctx->r10, ctx->r11);
    // 0x802B94D4: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802B94D8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802B94DC: slt         $at, $t9, $v1
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802B94E0: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x802B94E4: bne         $at, $zero, L_802B94F4
    if (ctx->r1 != 0) {
        // 0x802B94E8: sw          $t3, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r11;
            goto L_802B94F4;
    }
    // 0x802B94E8: sw          $t3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r11;
    // 0x802B94EC: b           L_802B9550
    // 0x802B94F0: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
        goto L_802B9550;
    // 0x802B94F0: addiu       $a1, $zero, -0x5A
    ctx->r5 = ADD32(0, -0X5A);
L_802B94F4:
    // 0x802B94F4: slt         $at, $t0, $v0
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802B94F8: bne         $at, $zero, L_802B9508
    if (ctx->r1 != 0) {
        // 0x802B94FC: sll         $t1, $v0, 8
        ctx->r9 = S32(ctx->r2 << 8);
            goto L_802B9508;
    }
    // 0x802B94FC: sll         $t1, $v0, 8
    ctx->r9 = S32(ctx->r2 << 8);
    // 0x802B9500: b           L_802B9550
    // 0x802B9504: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
        goto L_802B9550;
    // 0x802B9504: addiu       $a1, $zero, 0x5A
    ctx->r5 = ADD32(0, 0X5A);
L_802B9508:
    // 0x802B9508: div         $zero, $t1, $v1
    lo = S32(S64(S32(ctx->r9)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r9)) % S64(S32(ctx->r3)));
    // 0x802B950C: mflo        $a0
    ctx->r4 = lo;
    // 0x802B9510: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x802B9514: bne         $v1, $zero, L_802B9520
    if (ctx->r3 != 0) {
        // 0x802B9518: nop
    
            goto L_802B9520;
    }
    // 0x802B9518: nop

    // 0x802B951C: break       7
    do_break(2150339868);
L_802B9520:
    // 0x802B9520: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802B9524: bne         $v1, $at, L_802B9538
    if (ctx->r3 != ctx->r1) {
        // 0x802B9528: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802B9538;
    }
    // 0x802B9528: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802B952C: bne         $t1, $at, L_802B9538
    if (ctx->r9 != ctx->r1) {
        // 0x802B9530: nop
    
            goto L_802B9538;
    }
    // 0x802B9530: nop

    // 0x802B9534: break       6
    do_break(2150339892);
L_802B9538:
    // 0x802B9538: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802B953C: jal         0x8012835C
    // 0x802B9540: nop

    func_8012835C(rdram, ctx);
        goto after_7;
    // 0x802B9540: nop

    after_7:
    // 0x802B9544: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
    // 0x802B9548: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802B954C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
L_802B9550:
    // 0x802B9550: slti        $at, $a1, -0x28
    ctx->r1 = SIGNED(ctx->r5) < -0X28 ? 1 : 0;
    // 0x802B9554: beq         $at, $zero, L_802B9578
    if (ctx->r1 == 0) {
        // 0x802B9558: lui         $a0, 0x8020
        ctx->r4 = S32(0X8020 << 16);
            goto L_802B9578;
    }
    // 0x802B9558: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B955C: bgez        $a1, L_802B956C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9560: sra         $t2, $a1, 1
        ctx->r10 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B956C;
    }
    // 0x802B9560: sra         $t2, $a1, 1
    ctx->r10 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B9564: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9568: sra         $t2, $at, 1
    ctx->r10 = S32(SIGNED(ctx->r1) >> 1);
L_802B956C:
    // 0x802B956C: addiu       $a1, $t2, -0x14
    ctx->r5 = ADD32(ctx->r10, -0X14);
    // 0x802B9570: sll         $t3, $a1, 16
    ctx->r11 = S32(ctx->r5 << 16);
    // 0x802B9574: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
L_802B9578:
    // 0x802B9578: slti        $at, $a1, 0x29
    ctx->r1 = SIGNED(ctx->r5) < 0X29 ? 1 : 0;
    // 0x802B957C: bne         $at, $zero, L_802B95A0
    if (ctx->r1 != 0) {
        // 0x802B9580: addiu       $a0, $a0, 0x3FF8
        ctx->r4 = ADD32(ctx->r4, 0X3FF8);
            goto L_802B95A0;
    }
    // 0x802B9580: addiu       $a0, $a0, 0x3FF8
    ctx->r4 = ADD32(ctx->r4, 0X3FF8);
    // 0x802B9584: bgez        $a1, L_802B9594
    if (SIGNED(ctx->r5) >= 0) {
        // 0x802B9588: sra         $t9, $a1, 1
        ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
            goto L_802B9594;
    }
    // 0x802B9588: sra         $t9, $a1, 1
    ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
    // 0x802B958C: addiu       $at, $a1, 0x1
    ctx->r1 = ADD32(ctx->r5, 0X1);
    // 0x802B9590: sra         $t9, $at, 1
    ctx->r25 = S32(SIGNED(ctx->r1) >> 1);
L_802B9594:
    // 0x802B9594: addiu       $a1, $t9, 0x14
    ctx->r5 = ADD32(ctx->r25, 0X14);
    // 0x802B9598: sll         $t0, $a1, 16
    ctx->r8 = S32(ctx->r5 << 16);
    // 0x802B959C: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
L_802B95A0:
    // 0x802B95A0: jal         0x802C79E0
    // 0x802B95A4: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    func_802C79E0_6D9090(rdram, ctx);
        goto after_8;
    // 0x802B95A4: sh          $a1, 0x2E($sp)
    MEM_H(0X2E, ctx->r29) = ctx->r5;
    after_8:
    // 0x802B95A8: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B95AC: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    // 0x802B95B0: jal         0x802C79E0
    // 0x802B95B4: addiu       $a0, $a0, 0x4000
    ctx->r4 = ADD32(ctx->r4, 0X4000);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_9;
    // 0x802B95B4: addiu       $a0, $a0, 0x4000
    ctx->r4 = ADD32(ctx->r4, 0X4000);
    after_9:
    // 0x802B95B8: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B95BC: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    // 0x802B95C0: jal         0x802C79E0
    // 0x802B95C4: addiu       $a0, $a0, 0x4008
    ctx->r4 = ADD32(ctx->r4, 0X4008);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_10;
    // 0x802B95C4: addiu       $a0, $a0, 0x4008
    ctx->r4 = ADD32(ctx->r4, 0X4008);
    after_10:
    // 0x802B95C8: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x802B95CC: lh          $a1, 0x2E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X2E);
    // 0x802B95D0: jal         0x802C79E0
    // 0x802B95D4: addiu       $a0, $a0, 0x4010
    ctx->r4 = ADD32(ctx->r4, 0X4010);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_11;
    // 0x802B95D4: addiu       $a0, $a0, 0x4010
    ctx->r4 = ADD32(ctx->r4, 0X4010);
    after_11:
    // 0x802B95D8: lw          $t4, 0x28($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X28);
    // 0x802B95DC: lh          $t5, 0x46($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X46);
    // 0x802B95E0: lh          $t7, 0x4A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X4A);
    // 0x802B95E4: lh          $t2, 0x1C($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X1C);
    // 0x802B95E8: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802B95EC: subu        $v0, $t6, $t7
    ctx->r2 = SUB32(ctx->r14, ctx->r15);
    // 0x802B95F0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x802B95F4: addu        $t3, $t2, $v0
    ctx->r11 = ADD32(ctx->r10, ctx->r2);
    // 0x802B95F8: sh          $t3, 0x3FFC($at)
    MEM_H(0X3FFC, ctx->r1) = ctx->r11;
    // 0x802B95FC: lh          $t8, 0x24($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X24);
    // 0x802B9600: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x802B9604: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802B9608: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x802B960C: sh          $t9, 0x4004($at)
    MEM_H(0X4004, ctx->r1) = ctx->r25;
    // 0x802B9610: lh          $t0, 0x2C($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2C);
    // 0x802B9614: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x802B9618: addu        $t1, $t0, $v0
    ctx->r9 = ADD32(ctx->r8, ctx->r2);
    // 0x802B961C: sh          $t1, 0x400C($at)
    MEM_H(0X400C, ctx->r1) = ctx->r9;
    // 0x802B9620: lh          $t4, 0x34($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X34);
    // 0x802B9624: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x802B9628: addu        $t5, $t4, $v0
    ctx->r13 = ADD32(ctx->r12, ctx->r2);
    // 0x802B962C: sh          $t5, 0x4014($at)
    MEM_H(0X4014, ctx->r1) = ctx->r13;
    // 0x802B9630: sh          $zero, 0x0($s0)
    MEM_H(0X0, ctx->r16) = 0;
    // 0x802B9634: sh          $zero, 0x2($s0)
    MEM_H(0X2, ctx->r16) = 0;
    // 0x802B9638: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x802B963C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802B9640: sh          $v0, 0x3FE4($at)
    MEM_H(0X3FE4, ctx->r1) = ctx->r2;
    // 0x802B9644: jr          $ra
    // 0x802B9648: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x802B9648: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void func_802B964C_6CACFC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B964C: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x802B9650: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x802B9654: lh          $t6, 0x20($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X20);
    // 0x802B9658: lh          $t7, 0x18($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X18);
    // 0x802B965C: lh          $t0, 0x22($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X22);
    // 0x802B9660: lh          $t1, 0x1A($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X1A);
    // 0x802B9664: lh          $t4, 0x24($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X24);
    // 0x802B9668: lh          $t5, 0x1C($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X1C);
    // 0x802B966C: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B9670: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802B9674: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x802B9678: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x802B967C: sh          $t9, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r25;
    // 0x802B9680: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x802B9684: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802B9688: lh          $t9, 0x28($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X28);
    // 0x802B968C: lh          $t8, 0x30($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X30);
    // 0x802B9690: sh          $t3, 0xA($v0)
    MEM_H(0XA, ctx->r2) = ctx->r11;
    // 0x802B9694: sh          $t7, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r15;
    // 0x802B9698: lh          $t3, 0x2A($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2A);
    // 0x802B969C: lh          $t2, 0x32($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X32);
    // 0x802B96A0: lh          $t7, 0x2C($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2C);
    // 0x802B96A4: lh          $t6, 0x34($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X34);
    // 0x802B96A8: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x802B96AC: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x802B96B0: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802B96B4: sra         $t1, $t0, 1
    ctx->r9 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802B96B8: sra         $t5, $t4, 1
    ctx->r13 = S32(SIGNED(ctx->r12) >> 1);
    // 0x802B96BC: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802B96C0: sh          $t1, 0x10($v0)
    MEM_H(0X10, ctx->r2) = ctx->r9;
    // 0x802B96C4: sh          $t5, 0x12($v0)
    MEM_H(0X12, ctx->r2) = ctx->r13;
    // 0x802B96C8: jr          $ra
    // 0x802B96CC: sh          $t9, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r25;
    return;
    // 0x802B96CC: sh          $t9, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r25;
;}
RECOMP_FUNC void func_802B96D0_6CAD80(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B96D0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B96D4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B96D8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802B96DC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B96E0: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x802B96E4: jal         0x802BD358
    // 0x802B96E8: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    func_802BD358_6CEA08(rdram, ctx);
        goto after_0;
    // 0x802B96E8: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B96EC: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x802B96F0: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x802B96F4: sh          $zero, 0x12($v0)
    MEM_H(0X12, ctx->r2) = 0;
    // 0x802B96F8: lh          $t6, 0x12($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X12);
    // 0x802B96FC: lw          $t7, 0x18($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X18);
    // 0x802B9700: lh          $t9, 0x22($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X22);
    // 0x802B9704: sh          $t6, 0x10($v0)
    MEM_H(0X10, ctx->r2) = ctx->r14;
    // 0x802B9708: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x802B970C: lh          $t2, 0x1E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X1E);
    // 0x802B9710: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B9714: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x802B9718: sh          $t0, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r8;
    // 0x802B971C: lh          $v1, 0x14($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14);
    // 0x802B9720: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x802B9724: sh          $zero, 0xA($v0)
    MEM_H(0XA, ctx->r2) = 0;
    // 0x802B9728: addu        $t4, $v1, $t3
    ctx->r12 = ADD32(ctx->r3, ctx->r11);
    // 0x802B972C: sh          $t4, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r12;
    // 0x802B9730: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x802B9734: sh          $zero, 0x2($v0)
    MEM_H(0X2, ctx->r2) = 0;
    // 0x802B9738: lh          $t1, 0xA($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XA);
    // 0x802B973C: lh          $t5, 0x2($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2);
    // 0x802B9740: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x802B9744: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802B9748: sh          $t8, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r24;
    // 0x802B974C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B9750: sh          $t1, 0x8($v0)
    MEM_H(0X8, ctx->r2) = ctx->r9;
    // 0x802B9754: jr          $ra
    // 0x802B9758: sh          $t5, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r13;
    return;
    // 0x802B9758: sh          $t5, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r13;
;}
RECOMP_FUNC void func_802B975C_6CAE0C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B975C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B9760: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802B9764: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x802B9768: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B976C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802B9770: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B9774: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x802B9778: lhu         $v0, 0x0($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X0);
    // 0x802B977C: sll         $a3, $a1, 16
    ctx->r7 = S32(ctx->r5 << 16);
    // 0x802B9780: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x802B9784: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802B9788: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802B978C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B9790: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802B9794: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9798: or          $a2, $t8, $zero
        ctx->r6 = ctx->r24 | 0;
            goto L_802B97FC;
    }
    // 0x802B9798: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x802B979C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B97A0: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97A4: nop
    
            goto L_802B97FC;
    }
    // 0x802B97A4: nop

    // 0x802B97A8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B97AC: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97B0: nop
    
            goto L_802B97FC;
    }
    // 0x802B97B0: nop

    // 0x802B97B4: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B97B8: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97BC: nop
    
            goto L_802B97FC;
    }
    // 0x802B97BC: nop

    // 0x802B97C0: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B97C4: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97C8: nop
    
            goto L_802B97FC;
    }
    // 0x802B97C8: nop

    // 0x802B97CC: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B97D0: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97D4: nop
    
            goto L_802B97FC;
    }
    // 0x802B97D4: nop

    // 0x802B97D8: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802B97DC: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97E0: nop
    
            goto L_802B97FC;
    }
    // 0x802B97E0: nop

    // 0x802B97E4: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802B97E8: beq         $v0, $at, L_802B97FC
    if (ctx->r2 == ctx->r1) {
        // 0x802B97EC: nop
    
            goto L_802B97FC;
    }
    // 0x802B97EC: nop

    // 0x802B97F0: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802B97F4: bne         $v0, $at, L_802B985C
    if (ctx->r2 != ctx->r1) {
        // 0x802B97F8: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802B985C;
    }
    // 0x802B97F8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
L_802B97FC:
    // 0x802B97FC: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B9800: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B9804: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9808: lhu         $t0, 0x2F2($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B980C: lhu         $t2, 0x2FA($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9810: sll         $t1, $t0, 8
    ctx->r9 = S32(ctx->r8 << 8);
    // 0x802B9814: divu        $zero, $t1, $t2
    lo = S32(U32(ctx->r9) / U32(ctx->r10)); hi = S32(U32(ctx->r9) % U32(ctx->r10));
    // 0x802B9818: mflo        $t3
    ctx->r11 = lo;
    // 0x802B981C: sh          $t3, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r11;
    // 0x802B9820: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9824: bne         $t2, $zero, L_802B9830
    if (ctx->r10 != 0) {
        // 0x802B9828: nop
    
            goto L_802B9830;
    }
    // 0x802B9828: nop

    // 0x802B982C: break       7
    do_break(2150340652);
L_802B9830:
    // 0x802B9830: lhu         $t4, 0x2F4($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9834: lhu         $t6, 0x2FA($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9838: sll         $t5, $t4, 8
    ctx->r13 = S32(ctx->r12 << 8);
    // 0x802B983C: divu        $zero, $t5, $t6
    lo = S32(U32(ctx->r13) / U32(ctx->r14)); hi = S32(U32(ctx->r13) % U32(ctx->r14));
    // 0x802B9840: mflo        $t7
    ctx->r15 = lo;
    // 0x802B9844: sh          $t7, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r15;
    // 0x802B9848: bne         $t6, $zero, L_802B9854
    if (ctx->r14 != 0) {
        // 0x802B984C: nop
    
            goto L_802B9854;
    }
    // 0x802B984C: nop

    // 0x802B9850: break       7
    do_break(2150340688);
L_802B9854:
    // 0x802B9854: b           L_802B987C
    // 0x802B9858: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
        goto L_802B987C;
    // 0x802B9858: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
L_802B985C:
    // 0x802B985C: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B9860: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9864: lhu         $t8, 0x2F2($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9868: sh          $t8, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r24;
    // 0x802B986C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9870: lhu         $t9, 0x2F4($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9874: sh          $t9, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r25;
    // 0x802B9878: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
L_802B987C:
    // 0x802B987C: sh          $a2, 0x22($sp)
    MEM_H(0X22, ctx->r29) = ctx->r6;
    // 0x802B9880: jal         0x802BD358
    // 0x802B9884: sh          $a3, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r7;
    func_802BD358_6CEA08(rdram, ctx);
        goto after_0;
    // 0x802B9884: sh          $a3, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r7;
    after_0:
    // 0x802B9888: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x802B988C: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x802B9890: sh          $zero, 0x12($v1)
    MEM_H(0X12, ctx->r3) = 0;
    // 0x802B9894: lh          $t0, 0x12($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X12);
    // 0x802B9898: lw          $t1, 0x18($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X18);
    // 0x802B989C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x802B98A0: sh          $t0, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r8;
    // 0x802B98A4: lh          $t2, 0x0($t1)
    ctx->r10 = MEM_H(ctx->r9, 0X0);
    // 0x802B98A8: sh          $zero, 0xA($v1)
    MEM_H(0XA, ctx->r3) = 0;
    // 0x802B98AC: sh          $zero, 0xC2($v1)
    MEM_H(0XC2, ctx->r3) = 0;
    // 0x802B98B0: lh          $t3, 0xA($v1)
    ctx->r11 = MEM_H(ctx->r3, 0XA);
    // 0x802B98B4: lh          $t4, 0xC2($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XC2);
    // 0x802B98B8: sh          $t2, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r10;
    // 0x802B98BC: sh          $t3, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r11;
    // 0x802B98C0: sh          $t4, 0xC0($v1)
    MEM_H(0XC0, ctx->r3) = ctx->r12;
    // 0x802B98C4: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x802B98C8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B98CC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B98D0: lhu         $v0, 0x0($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X0);
    // 0x802B98D4: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B98D8: lh          $a2, 0x22($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X22);
    // 0x802B98DC: beq         $v0, $at, L_802B9900
    if (ctx->r2 == ctx->r1) {
        // 0x802B98E0: lh          $a3, 0x1E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X1E);
            goto L_802B9900;
    }
    // 0x802B98E0: lh          $a3, 0x1E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X1E);
    // 0x802B98E4: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B98E8: beq         $v0, $at, L_802B9900
    if (ctx->r2 == ctx->r1) {
        // 0x802B98EC: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802B9900;
    }
    // 0x802B98EC: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B98F0: beq         $v0, $at, L_802B9900
    if (ctx->r2 == ctx->r1) {
        // 0x802B98F4: addiu       $at, $zero, 0xB9
        ctx->r1 = ADD32(0, 0XB9);
            goto L_802B9900;
    }
    // 0x802B98F4: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B98F8: bnel        $v0, $at, L_802B998C
    if (ctx->r2 != ctx->r1) {
        // 0x802B98FC: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B998C;
    }
    goto skip_0;
    // 0x802B98FC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_0:
L_802B9900:
    // 0x802B9900: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9904: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x802B9908: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x802B990C: lh          $t7, 0x2F6($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2F6);
    // 0x802B9910: lh          $t6, 0x8($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X8);
    // 0x802B9914: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802B9918: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x802B991C: addu        $t0, $a0, $t9
    ctx->r8 = ADD32(ctx->r4, ctx->r25);
    // 0x802B9920: lh          $t1, 0x0($t0)
    ctx->r9 = MEM_H(ctx->r8, 0X0);
    // 0x802B9924: addiu       $t0, $zero, 0x100
    ctx->r8 = ADD32(0, 0X100);
    // 0x802B9928: lh          $t8, 0x14($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X14);
    // 0x802B992C: sra         $t2, $t1, 7
    ctx->r10 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802B9930: multu       $a3, $t2
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9934: mflo        $t3
    ctx->r11 = lo;
    // 0x802B9938: sra         $t4, $t3, 8
    ctx->r12 = S32(SIGNED(ctx->r11) >> 8);
    // 0x802B993C: srav        $t5, $t4, $a2
    ctx->r13 = S32(SIGNED(ctx->r12) >> (ctx->r6 & 31));
    // 0x802B9940: addu        $t7, $t6, $t5
    ctx->r15 = ADD32(ctx->r14, ctx->r13);
    // 0x802B9944: sh          $t7, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r15;
    // 0x802B9948: lhu         $t9, 0x2F6($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2F6);
    // 0x802B994C: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x802B9950: addiu       $t3, $t2, 0x40
    ctx->r11 = ADD32(ctx->r10, 0X40);
    // 0x802B9954: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x802B9958: sll         $t6, $t4, 1
    ctx->r14 = S32(ctx->r12 << 1);
    // 0x802B995C: addu        $t5, $a0, $t6
    ctx->r13 = ADD32(ctx->r4, ctx->r14);
    // 0x802B9960: lh          $t7, 0x0($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X0);
    // 0x802B9964: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802B9968: subu        $t1, $t0, $t9
    ctx->r9 = SUB32(ctx->r8, ctx->r25);
    // 0x802B996C: multu       $a3, $t1
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9970: mflo        $t2
    ctx->r10 = lo;
    // 0x802B9974: sra         $t3, $t2, 8
    ctx->r11 = S32(SIGNED(ctx->r10) >> 8);
    // 0x802B9978: srav        $t4, $t3, $a2
    ctx->r12 = S32(SIGNED(ctx->r11) >> (ctx->r6 & 31));
    // 0x802B997C: addu        $t6, $t8, $t4
    ctx->r14 = ADD32(ctx->r24, ctx->r12);
    // 0x802B9980: b           L_802B9A20
    // 0x802B9984: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
        goto L_802B9A20;
    // 0x802B9984: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
    // 0x802B9988: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802B998C:
    // 0x802B998C: beq         $v0, $at, L_802B999C
    if (ctx->r2 == ctx->r1) {
        // 0x802B9990: addiu       $at, $zero, 0xB7
        ctx->r1 = ADD32(0, 0XB7);
            goto L_802B999C;
    }
    // 0x802B9990: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B9994: bnel        $v0, $at, L_802B9A24
    if (ctx->r2 != ctx->r1) {
        // 0x802B9998: lh          $v0, 0x14($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X14);
            goto L_802B9A24;
    }
    goto skip_1;
    // 0x802B9998: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
    skip_1:
L_802B999C:
    // 0x802B999C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B99A0: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x802B99A4: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x802B99A8: lh          $t7, 0x2F6($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2F6);
    // 0x802B99AC: lh          $t5, 0x8($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X8);
    // 0x802B99B0: andi        $t0, $t7, 0xFF
    ctx->r8 = ctx->r15 & 0XFF;
    // 0x802B99B4: sll         $t9, $t0, 1
    ctx->r25 = S32(ctx->r8 << 1);
    // 0x802B99B8: addu        $t1, $a0, $t9
    ctx->r9 = ADD32(ctx->r4, ctx->r25);
    // 0x802B99BC: lh          $t2, 0x0($t1)
    ctx->r10 = MEM_H(ctx->r9, 0X0);
    // 0x802B99C0: addiu       $t1, $zero, 0x100
    ctx->r9 = ADD32(0, 0X100);
    // 0x802B99C4: lh          $t0, 0x14($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X14);
    // 0x802B99C8: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802B99CC: multu       $a3, $t3
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B99D0: mflo        $t8
    ctx->r24 = lo;
    // 0x802B99D4: sra         $t4, $t8, 8
    ctx->r12 = S32(SIGNED(ctx->r24) >> 8);
    // 0x802B99D8: srav        $t6, $t4, $a2
    ctx->r14 = S32(SIGNED(ctx->r12) >> (ctx->r6 & 31));
    // 0x802B99DC: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x802B99E0: sh          $t7, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r15;
    // 0x802B99E4: lhu         $t9, 0x2F6($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2F6);
    // 0x802B99E8: sll         $t3, $t9, 1
    ctx->r11 = S32(ctx->r25 << 1);
    // 0x802B99EC: addiu       $t8, $t3, 0x40
    ctx->r24 = ADD32(ctx->r11, 0X40);
    // 0x802B99F0: andi        $t4, $t8, 0xFF
    ctx->r12 = ctx->r24 & 0XFF;
    // 0x802B99F4: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x802B99F8: addu        $t6, $a0, $t5
    ctx->r14 = ADD32(ctx->r4, ctx->r13);
    // 0x802B99FC: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x802B9A00: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802B9A04: subu        $t2, $t1, $t9
    ctx->r10 = SUB32(ctx->r9, ctx->r25);
    // 0x802B9A08: multu       $a3, $t2
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9A0C: mflo        $t3
    ctx->r11 = lo;
    // 0x802B9A10: sra         $t8, $t3, 8
    ctx->r24 = S32(SIGNED(ctx->r11) >> 8);
    // 0x802B9A14: srav        $t4, $t8, $a2
    ctx->r12 = S32(SIGNED(ctx->r24) >> (ctx->r6 & 31));
    // 0x802B9A18: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x802B9A1C: sh          $t5, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r13;
L_802B9A20:
    // 0x802B9A20: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
L_802B9A24:
    // 0x802B9A24: sll         $t6, $a3, 1
    ctx->r14 = S32(ctx->r7 << 1);
    // 0x802B9A28: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B9A2C: addu        $a0, $v0, $t6
    ctx->r4 = ADD32(ctx->r2, ctx->r14);
    // 0x802B9A30: sh          $a0, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r4;
    // 0x802B9A34: lh          $t1, 0xC($v1)
    ctx->r9 = MEM_H(ctx->r3, 0XC);
    // 0x802B9A38: sh          $zero, 0x2($v1)
    MEM_H(0X2, ctx->r3) = 0;
    // 0x802B9A3C: lh          $t7, 0x2($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X2);
    // 0x802B9A40: addu        $t9, $v0, $t1
    ctx->r25 = ADD32(ctx->r2, ctx->r9);
    // 0x802B9A44: sra         $t2, $t9, 1
    ctx->r10 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802B9A48: sh          $a0, 0xC4($v1)
    MEM_H(0XC4, ctx->r3) = ctx->r4;
    // 0x802B9A4C: sh          $t2, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r10;
    // 0x802B9A50: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B9A54: jr          $ra
    // 0x802B9A58: sh          $t7, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r15;
    return;
    // 0x802B9A58: sh          $t7, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r15;
;}
RECOMP_FUNC void func_802B9A5C_6CB10C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B9A5C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802B9A60: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802B9A64: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x802B9A68: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B9A6C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x802B9A70: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x802B9A74: lhu         $v0, 0x0($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X0);
    // 0x802B9A78: sll         $a2, $a1, 16
    ctx->r6 = S32(ctx->r5 << 16);
    // 0x802B9A7C: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x802B9A80: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B9A84: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9A88: or          $a2, $t6, $zero
        ctx->r6 = ctx->r14 | 0;
            goto L_802B9AEC;
    }
    // 0x802B9A88: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x802B9A8C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B9A90: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9A94: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9A94: nop

    // 0x802B9A98: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x802B9A9C: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9AA0: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9AA0: nop

    // 0x802B9AA4: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B9AA8: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9AAC: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9AAC: nop

    // 0x802B9AB0: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B9AB4: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9AB8: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9AB8: nop

    // 0x802B9ABC: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B9AC0: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9AC4: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9AC4: nop

    // 0x802B9AC8: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802B9ACC: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9AD0: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9AD0: nop

    // 0x802B9AD4: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802B9AD8: beq         $v0, $at, L_802B9AEC
    if (ctx->r2 == ctx->r1) {
        // 0x802B9ADC: nop
    
            goto L_802B9AEC;
    }
    // 0x802B9ADC: nop

    // 0x802B9AE0: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802B9AE4: bne         $v0, $at, L_802B9B4C
    if (ctx->r2 != ctx->r1) {
        // 0x802B9AE8: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_802B9B4C;
    }
    // 0x802B9AE8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
L_802B9AEC:
    // 0x802B9AEC: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B9AF0: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B9AF4: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9AF8: lhu         $t8, 0x2F2($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9AFC: lhu         $t0, 0x2FA($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9B00: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x802B9B04: divu        $zero, $t9, $t0
    lo = S32(U32(ctx->r25) / U32(ctx->r8)); hi = S32(U32(ctx->r25) % U32(ctx->r8));
    // 0x802B9B08: mflo        $t1
    ctx->r9 = lo;
    // 0x802B9B0C: sh          $t1, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r9;
    // 0x802B9B10: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9B14: bne         $t0, $zero, L_802B9B20
    if (ctx->r8 != 0) {
        // 0x802B9B18: nop
    
            goto L_802B9B20;
    }
    // 0x802B9B18: nop

    // 0x802B9B1C: break       7
    do_break(2150341404);
L_802B9B20:
    // 0x802B9B20: lhu         $t2, 0x2F4($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9B24: lhu         $t4, 0x2FA($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9B28: sll         $t3, $t2, 8
    ctx->r11 = S32(ctx->r10 << 8);
    // 0x802B9B2C: divu        $zero, $t3, $t4
    lo = S32(U32(ctx->r11) / U32(ctx->r12)); hi = S32(U32(ctx->r11) % U32(ctx->r12));
    // 0x802B9B30: mflo        $t5
    ctx->r13 = lo;
    // 0x802B9B34: sh          $t5, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r13;
    // 0x802B9B38: bne         $t4, $zero, L_802B9B44
    if (ctx->r12 != 0) {
        // 0x802B9B3C: nop
    
            goto L_802B9B44;
    }
    // 0x802B9B3C: nop

    // 0x802B9B40: break       7
    do_break(2150341440);
L_802B9B44:
    // 0x802B9B44: b           L_802B9B6C
    // 0x802B9B48: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
        goto L_802B9B6C;
    // 0x802B9B48: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
L_802B9B4C:
    // 0x802B9B4C: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B9B50: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9B54: lhu         $t6, 0x2F2($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9B58: sh          $t6, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r14;
    // 0x802B9B5C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9B60: lhu         $t7, 0x2F4($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9B64: sh          $t7, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r15;
    // 0x802B9B68: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
L_802B9B6C:
    // 0x802B9B6C: jal         0x802BD358
    // 0x802B9B70: sh          $a2, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r6;
    func_802BD358_6CEA08(rdram, ctx);
        goto after_0;
    // 0x802B9B70: sh          $a2, 0x1E($sp)
    MEM_H(0X1E, ctx->r29) = ctx->r6;
    after_0:
    // 0x802B9B74: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x802B9B78: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x802B9B7C: sh          $zero, 0x12($v1)
    MEM_H(0X12, ctx->r3) = 0;
    // 0x802B9B80: lh          $t8, 0x12($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X12);
    // 0x802B9B84: lw          $t9, 0x18($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X18);
    // 0x802B9B88: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x802B9B8C: sh          $t8, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r24;
    // 0x802B9B90: lh          $t0, 0x0($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X0);
    // 0x802B9B94: sh          $zero, 0xC2($v1)
    MEM_H(0XC2, ctx->r3) = 0;
    // 0x802B9B98: lh          $t1, 0xC2($v1)
    ctx->r9 = MEM_H(ctx->r3, 0XC2);
    // 0x802B9B9C: sh          $zero, 0x2($v1)
    MEM_H(0X2, ctx->r3) = 0;
    // 0x802B9BA0: sh          $zero, 0xA($v1)
    MEM_H(0XA, ctx->r3) = 0;
    // 0x802B9BA4: sh          $t0, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r8;
    // 0x802B9BA8: sh          $t1, 0xC0($v1)
    MEM_H(0XC0, ctx->r3) = ctx->r9;
    // 0x802B9BAC: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x802B9BB0: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802B9BB4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802B9BB8: lhu         $v0, 0x0($t2)
    ctx->r2 = MEM_HU(ctx->r10, 0X0);
    // 0x802B9BBC: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x802B9BC0: lh          $a2, 0x1E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X1E);
    // 0x802B9BC4: beq         $v0, $at, L_802B9BE4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9BC8: addiu       $at, $zero, 0xB6
        ctx->r1 = ADD32(0, 0XB6);
            goto L_802B9BE4;
    }
    // 0x802B9BC8: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B9BCC: beq         $v0, $at, L_802B9BE4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9BD0: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802B9BE4;
    }
    // 0x802B9BD0: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B9BD4: beq         $v0, $at, L_802B9BE4
    if (ctx->r2 == ctx->r1) {
        // 0x802B9BD8: addiu       $at, $zero, 0xB9
        ctx->r1 = ADD32(0, 0XB9);
            goto L_802B9BE4;
    }
    // 0x802B9BD8: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B9BDC: bnel        $v0, $at, L_802B9C68
    if (ctx->r2 != ctx->r1) {
        // 0x802B9BE0: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B9C68;
    }
    goto skip_0;
    // 0x802B9BE0: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_0:
L_802B9BE4:
    // 0x802B9BE4: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9BE8: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x802B9BEC: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x802B9BF0: lhu         $t4, 0x2F6($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2F6);
    // 0x802B9BF4: addiu       $t5, $zero, 0x100
    ctx->r13 = ADD32(0, 0X100);
    // 0x802B9BF8: lh          $t3, 0x14($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X14);
    // 0x802B9BFC: sll         $t7, $t4, 1
    ctx->r15 = S32(ctx->r12 << 1);
    // 0x802B9C00: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x802B9C04: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x802B9C08: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x802B9C0C: addu        $t1, $a0, $t0
    ctx->r9 = ADD32(ctx->r4, ctx->r8);
    // 0x802B9C10: lh          $t2, 0x0($t1)
    ctx->r10 = MEM_H(ctx->r9, 0X0);
    // 0x802B9C14: lh          $t0, 0x10($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X10);
    // 0x802B9C18: sra         $t4, $t2, 7
    ctx->r12 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802B9C1C: subu        $t6, $t5, $t4
    ctx->r14 = SUB32(ctx->r13, ctx->r12);
    // 0x802B9C20: multu       $a2, $t6
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9C24: mflo        $t7
    ctx->r15 = lo;
    // 0x802B9C28: sra         $t8, $t7, 10
    ctx->r24 = S32(SIGNED(ctx->r15) >> 10);
    // 0x802B9C2C: addu        $t9, $t3, $t8
    ctx->r25 = ADD32(ctx->r11, ctx->r24);
    // 0x802B9C30: sh          $t9, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r25;
    // 0x802B9C34: lh          $t1, 0x2F6($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2F6);
    // 0x802B9C38: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x802B9C3C: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
    // 0x802B9C40: addu        $t4, $a0, $t5
    ctx->r12 = ADD32(ctx->r4, ctx->r13);
    // 0x802B9C44: lh          $t6, 0x0($t4)
    ctx->r14 = MEM_H(ctx->r12, 0X0);
    // 0x802B9C48: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802B9C4C: multu       $a2, $t7
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9C50: mflo        $t3
    ctx->r11 = lo;
    // 0x802B9C54: sra         $t8, $t3, 10
    ctx->r24 = S32(SIGNED(ctx->r11) >> 10);
    // 0x802B9C58: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x802B9C5C: b           L_802B9CEC
    // 0x802B9C60: sh          $t9, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r25;
        goto L_802B9CEC;
    // 0x802B9C60: sh          $t9, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r25;
    // 0x802B9C64: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802B9C68:
    // 0x802B9C68: beq         $v0, $at, L_802B9C78
    if (ctx->r2 == ctx->r1) {
        // 0x802B9C6C: addiu       $at, $zero, 0xB7
        ctx->r1 = ADD32(0, 0XB7);
            goto L_802B9C78;
    }
    // 0x802B9C6C: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B9C70: bnel        $v0, $at, L_802B9CF0
    if (ctx->r2 != ctx->r1) {
        // 0x802B9C74: lh          $v0, 0x14($v1)
        ctx->r2 = MEM_H(ctx->r3, 0X14);
            goto L_802B9CF0;
    }
    goto skip_1;
    // 0x802B9C74: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
    skip_1:
L_802B9C78:
    // 0x802B9C78: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x802B9C7C: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x802B9C80: addiu       $a0, $a0, 0x2C78
    ctx->r4 = ADD32(ctx->r4, 0X2C78);
    // 0x802B9C84: lhu         $t2, 0x2F6($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X2F6);
    // 0x802B9C88: lh          $t1, 0x14($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X14);
    // 0x802B9C8C: sll         $t6, $t2, 1
    ctx->r14 = S32(ctx->r10 << 1);
    // 0x802B9C90: addiu       $t7, $t6, 0x40
    ctx->r15 = ADD32(ctx->r14, 0X40);
    // 0x802B9C94: andi        $t3, $t7, 0xFF
    ctx->r11 = ctx->r15 & 0XFF;
    // 0x802B9C98: sll         $t0, $t3, 1
    ctx->r8 = S32(ctx->r11 << 1);
    // 0x802B9C9C: addu        $t8, $a0, $t0
    ctx->r24 = ADD32(ctx->r4, ctx->r8);
    // 0x802B9CA0: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x802B9CA4: lh          $t7, 0x10($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X10);
    // 0x802B9CA8: sra         $t2, $t9, 7
    ctx->r10 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802B9CAC: multu       $a2, $t2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9CB0: mflo        $t5
    ctx->r13 = lo;
    // 0x802B9CB4: sra         $t4, $t5, 10
    ctx->r12 = S32(SIGNED(ctx->r13) >> 10);
    // 0x802B9CB8: addu        $t6, $t1, $t4
    ctx->r14 = ADD32(ctx->r9, ctx->r12);
    // 0x802B9CBC: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
    // 0x802B9CC0: lh          $t3, 0x2F6($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2F6);
    // 0x802B9CC4: andi        $t0, $t3, 0xFF
    ctx->r8 = ctx->r11 & 0XFF;
    // 0x802B9CC8: sll         $t8, $t0, 1
    ctx->r24 = S32(ctx->r8 << 1);
    // 0x802B9CCC: addu        $t9, $a0, $t8
    ctx->r25 = ADD32(ctx->r4, ctx->r24);
    // 0x802B9CD0: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x802B9CD4: sra         $t5, $t2, 7
    ctx->r13 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802B9CD8: multu       $a2, $t5
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9CDC: mflo        $t1
    ctx->r9 = lo;
    // 0x802B9CE0: sra         $t4, $t1, 10
    ctx->r12 = S32(SIGNED(ctx->r9) >> 10);
    // 0x802B9CE4: addu        $t6, $t7, $t4
    ctx->r14 = ADD32(ctx->r15, ctx->r12);
    // 0x802B9CE8: sh          $t6, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r14;
L_802B9CEC:
    // 0x802B9CEC: lh          $v0, 0x14($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X14);
L_802B9CF0:
    // 0x802B9CF0: lh          $a0, 0x10($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X10);
    // 0x802B9CF4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802B9CF8: sll         $t0, $a2, 1
    ctx->r8 = S32(ctx->r6 << 1);
    // 0x802B9CFC: addu        $t3, $v0, $a2
    ctx->r11 = ADD32(ctx->r2, ctx->r6);
    // 0x802B9D00: addu        $a1, $v0, $t0
    ctx->r5 = ADD32(ctx->r2, ctx->r8);
    // 0x802B9D04: sh          $t3, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r11;
    // 0x802B9D08: sh          $a1, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r5;
    // 0x802B9D0C: sh          $a1, 0xC4($v1)
    MEM_H(0XC4, ctx->r3) = ctx->r5;
    // 0x802B9D10: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802B9D14: sh          $a0, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r4;
    // 0x802B9D18: jr          $ra
    // 0x802B9D1C: sh          $a0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r4;
    return;
    // 0x802B9D1C: sh          $a0, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r4;
;}
RECOMP_FUNC void func_802B9D20_6CB3D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802B9D20: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802B9D24: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B9D28: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B9D2C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802B9D30: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802B9D34: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802B9D38: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802B9D3C: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802B9D40: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x802B9D44: addiu       $t0, $zero, 0x3
    ctx->r8 = ADD32(0, 0X3);
    // 0x802B9D48: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802B9D4C: beq         $t0, $v0, L_802B9D9C
    if (ctx->r8 == ctx->r2) {
        // 0x802B9D50: addiu       $ra, $ra, 0x552C
        ctx->r31 = ADD32(ctx->r31, 0X552C);
            goto L_802B9D9C;
    }
    // 0x802B9D50: addiu       $ra, $ra, 0x552C
    ctx->r31 = ADD32(ctx->r31, 0X552C);
    // 0x802B9D54: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B9D58: beql        $v0, $at, L_802B9DA0
    if (ctx->r2 == ctx->r1) {
        // 0x802B9D5C: lw          $v0, 0x0($ra)
        ctx->r2 = MEM_W(ctx->r31, 0X0);
            goto L_802B9DA0;
    }
    goto skip_0;
    // 0x802B9D5C: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    skip_0:
    // 0x802B9D60: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B9D64: beql        $v0, $at, L_802B9DA0
    if (ctx->r2 == ctx->r1) {
        // 0x802B9D68: lw          $v0, 0x0($ra)
        ctx->r2 = MEM_W(ctx->r31, 0X0);
            goto L_802B9DA0;
    }
    goto skip_1;
    // 0x802B9D68: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    skip_1:
    // 0x802B9D6C: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B9D70: beql        $v0, $at, L_802B9DA0
    if (ctx->r2 == ctx->r1) {
        // 0x802B9D74: lw          $v0, 0x0($ra)
        ctx->r2 = MEM_W(ctx->r31, 0X0);
            goto L_802B9DA0;
    }
    goto skip_2;
    // 0x802B9D74: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    skip_2:
    // 0x802B9D78: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802B9D7C: beql        $v0, $at, L_802B9DA0
    if (ctx->r2 == ctx->r1) {
        // 0x802B9D80: lw          $v0, 0x0($ra)
        ctx->r2 = MEM_W(ctx->r31, 0X0);
            goto L_802B9DA0;
    }
    goto skip_3;
    // 0x802B9D80: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    skip_3:
    // 0x802B9D84: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802B9D88: beql        $v0, $at, L_802B9DA0
    if (ctx->r2 == ctx->r1) {
        // 0x802B9D8C: lw          $v0, 0x0($ra)
        ctx->r2 = MEM_W(ctx->r31, 0X0);
            goto L_802B9DA0;
    }
    goto skip_4;
    // 0x802B9D8C: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    skip_4:
    // 0x802B9D90: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802B9D94: bnel        $v0, $at, L_802B9DFC
    if (ctx->r2 != ctx->r1) {
        // 0x802B9D98: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B9DFC;
    }
    goto skip_5;
    // 0x802B9D98: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_5:
L_802B9D9C:
    // 0x802B9D9C: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
L_802B9DA0:
    // 0x802B9DA0: addiu       $t5, $zero, 0x4
    ctx->r13 = ADD32(0, 0X4);
    // 0x802B9DA4: lhu         $t7, 0x2F2($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9DA8: lhu         $t9, 0x2FA($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9DAC: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B9DB0: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802B9DB4: mflo        $t6
    ctx->r14 = lo;
    // 0x802B9DB8: sh          $t6, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r14;
    // 0x802B9DBC: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802B9DC0: bne         $t9, $zero, L_802B9DCC
    if (ctx->r25 != 0) {
        // 0x802B9DC4: nop
    
            goto L_802B9DCC;
    }
    // 0x802B9DC4: nop

    // 0x802B9DC8: break       7
    do_break(2150342088);
L_802B9DCC:
    // 0x802B9DCC: lhu         $t7, 0x2F4($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9DD0: lhu         $t9, 0x2FA($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9DD4: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B9DD8: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802B9DDC: mflo        $t6
    ctx->r14 = lo;
    // 0x802B9DE0: sh          $t6, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r14;
    // 0x802B9DE4: bne         $t9, $zero, L_802B9DF0
    if (ctx->r25 != 0) {
        // 0x802B9DE8: nop
    
            goto L_802B9DF0;
    }
    // 0x802B9DE8: nop

    // 0x802B9DEC: break       7
    do_break(2150342124);
L_802B9DF0:
    // 0x802B9DF0: b           L_802B9E98
    // 0x802B9DF4: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
        goto L_802B9E98;
    // 0x802B9DF4: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x802B9DF8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802B9DFC:
    // 0x802B9DFC: beq         $v0, $at, L_802B9E10
    if (ctx->r2 == ctx->r1) {
        // 0x802B9E00: nop
    
            goto L_802B9E10;
    }
    // 0x802B9E00: nop

    // 0x802B9E04: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B9E08: bne         $v0, $at, L_802B9E74
    if (ctx->r2 != ctx->r1) {
        // 0x802B9E0C: lui         $ra, 0x803D
        ctx->r31 = S32(0X803D << 16);
            goto L_802B9E74;
    }
    // 0x802B9E0C: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
L_802B9E10:
    // 0x802B9E10: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802B9E14: addiu       $ra, $ra, 0x552C
    ctx->r31 = ADD32(ctx->r31, 0X552C);
    // 0x802B9E18: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802B9E1C: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x802B9E20: lhu         $t7, 0x2F2($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9E24: lhu         $t9, 0x2FA($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9E28: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B9E2C: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802B9E30: mflo        $t6
    ctx->r14 = lo;
    // 0x802B9E34: sh          $t6, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r14;
    // 0x802B9E38: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802B9E3C: bne         $t9, $zero, L_802B9E48
    if (ctx->r25 != 0) {
        // 0x802B9E40: nop
    
            goto L_802B9E48;
    }
    // 0x802B9E40: nop

    // 0x802B9E44: break       7
    do_break(2150342212);
L_802B9E48:
    // 0x802B9E48: lhu         $t7, 0x2F4($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9E4C: lhu         $t9, 0x2FA($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2FA);
    // 0x802B9E50: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802B9E54: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802B9E58: mflo        $t6
    ctx->r14 = lo;
    // 0x802B9E5C: sh          $t6, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r14;
    // 0x802B9E60: bne         $t9, $zero, L_802B9E6C
    if (ctx->r25 != 0) {
        // 0x802B9E64: nop
    
            goto L_802B9E6C;
    }
    // 0x802B9E64: nop

    // 0x802B9E68: break       7
    do_break(2150342248);
L_802B9E6C:
    // 0x802B9E6C: b           L_802B9E98
    // 0x802B9E70: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
        goto L_802B9E98;
    // 0x802B9E70: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
L_802B9E74:
    // 0x802B9E74: addiu       $ra, $ra, 0x552C
    ctx->r31 = ADD32(ctx->r31, 0X552C);
    // 0x802B9E78: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802B9E7C: or          $t5, $zero, $zero
    ctx->r13 = 0 | 0;
    // 0x802B9E80: lhu         $t7, 0x2F2($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2F2);
    // 0x802B9E84: sh          $t7, 0x2F6($v0)
    MEM_H(0X2F6, ctx->r2) = ctx->r15;
    // 0x802B9E88: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802B9E8C: lhu         $t8, 0x2F4($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X2F4);
    // 0x802B9E90: sh          $t8, 0x2F8($v0)
    MEM_H(0X2F8, ctx->r2) = ctx->r24;
    // 0x802B9E94: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
L_802B9E98:
    // 0x802B9E98: jal         0x802BD358
    // 0x802B9E9C: sh          $t5, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r13;
    func_802BD358_6CEA08(rdram, ctx);
        goto after_0;
    // 0x802B9E9C: sh          $t5, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r13;
    after_0:
    // 0x802B9EA0: lh          $t7, 0x2A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2A);
    // 0x802B9EA4: addiu       $t0, $zero, 0x3
    ctx->r8 = ADD32(0, 0X3);
    // 0x802B9EA8: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x802B9EAC: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9EB0: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x802B9EB4: sh          $zero, 0x12($v1)
    MEM_H(0X12, ctx->r3) = 0;
    // 0x802B9EB8: lh          $t3, 0x12($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X12);
    // 0x802B9EBC: lw          $t9, 0x20($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X20);
    // 0x802B9EC0: lui         $ra, 0x803D
    ctx->r31 = S32(0X803D << 16);
    // 0x802B9EC4: sh          $t3, 0x10($v1)
    MEM_H(0X10, ctx->r3) = ctx->r11;
    // 0x802B9EC8: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x802B9ECC: sh          $zero, 0x2($v1)
    MEM_H(0X2, ctx->r3) = 0;
    // 0x802B9ED0: sh          $zero, 0xA($v1)
    MEM_H(0XA, ctx->r3) = 0;
    // 0x802B9ED4: mflo        $t8
    ctx->r24 = lo;
    // 0x802B9ED8: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x802B9EDC: lh          $t8, 0x2($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2);
    // 0x802B9EE0: lh          $t4, 0xA($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XA);
    // 0x802B9EE4: addu        $t7, $t6, $t9
    ctx->r15 = ADD32(ctx->r14, ctx->r25);
    // 0x802B9EE8: sh          $t7, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r15;
    // 0x802B9EEC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802B9EF0: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
    // 0x802B9EF4: sh          $t4, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r12;
    // 0x802B9EF8: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802B9EFC: addiu       $ra, $ra, 0x552C
    ctx->r31 = ADD32(ctx->r31, 0X552C);
    // 0x802B9F00: lh          $t5, 0x1C($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X1C);
    // 0x802B9F04: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x802B9F08: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802B9F0C: beql        $t0, $v0, L_802B9F30
    if (ctx->r8 == ctx->r2) {
        // 0x802B9F10: lw          $t8, 0x0($ra)
        ctx->r24 = MEM_W(ctx->r31, 0X0);
            goto L_802B9F30;
    }
    goto skip_6;
    // 0x802B9F10: lw          $t8, 0x0($ra)
    ctx->r24 = MEM_W(ctx->r31, 0X0);
    skip_6:
    // 0x802B9F14: beq         $v0, $at, L_802B9F2C
    if (ctx->r2 == ctx->r1) {
        // 0x802B9F18: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802B9F2C;
    }
    // 0x802B9F18: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802B9F1C: beq         $v0, $at, L_802B9F2C
    if (ctx->r2 == ctx->r1) {
        // 0x802B9F20: addiu       $at, $zero, 0xB9
        ctx->r1 = ADD32(0, 0XB9);
            goto L_802B9F2C;
    }
    // 0x802B9F20: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802B9F24: bnel        $v0, $at, L_802B9F98
    if (ctx->r2 != ctx->r1) {
        // 0x802B9F28: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802B9F98;
    }
    goto skip_7;
    // 0x802B9F28: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_7:
L_802B9F2C:
    // 0x802B9F2C: lw          $t8, 0x0($ra)
    ctx->r24 = MEM_W(ctx->r31, 0X0);
L_802B9F30:
    // 0x802B9F30: lh          $t9, 0x26($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X26);
    // 0x802B9F34: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802B9F38: lhu         $t6, 0x2F6($t8)
    ctx->r14 = MEM_HU(ctx->r24, 0X2F6);
    // 0x802B9F3C: multu       $t5, $t9
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9F40: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x802B9F44: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802B9F48: or          $t6, $t8, $zero
    ctx->r14 = ctx->r24 | 0;
    // 0x802B9F4C: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x802B9F50: andi        $t8, $t9, 0xFF
    ctx->r24 = ctx->r25 & 0XFF;
    // 0x802B9F54: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802B9F58: addu        $t9, $t2, $t6
    ctx->r25 = ADD32(ctx->r10, ctx->r14);
    // 0x802B9F5C: lh          $t8, 0x0($t9)
    ctx->r24 = MEM_H(ctx->r25, 0X0);
    // 0x802B9F60: addiu       $t9, $zero, 0x100
    ctx->r25 = ADD32(0, 0X100);
    // 0x802B9F64: mflo        $t7
    ctx->r15 = lo;
    // 0x802B9F68: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802B9F6C: subu        $t8, $t9, $t6
    ctx->r24 = SUB32(ctx->r25, ctx->r14);
    // 0x802B9F70: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9F74: lh          $t7, 0x14($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X14);
    // 0x802B9F78: lh          $t3, 0x12($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X12);
    // 0x802B9F7C: lh          $t4, 0xA($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XA);
    // 0x802B9F80: mflo        $t9
    ctx->r25 = lo;
    // 0x802B9F84: sra         $t6, $t9, 13
    ctx->r14 = S32(SIGNED(ctx->r25) >> 13);
    // 0x802B9F88: addu        $t8, $t7, $t6
    ctx->r24 = ADD32(ctx->r15, ctx->r14);
    // 0x802B9F8C: b           L_802BA00C
    // 0x802B9F90: sh          $t8, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r24;
        goto L_802BA00C;
    // 0x802B9F90: sh          $t8, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r24;
    // 0x802B9F94: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802B9F98:
    // 0x802B9F98: beq         $v0, $at, L_802B9FA8
    if (ctx->r2 == ctx->r1) {
        // 0x802B9F9C: addiu       $at, $zero, 0xB7
        ctx->r1 = ADD32(0, 0XB7);
            goto L_802B9FA8;
    }
    // 0x802B9F9C: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802B9FA0: bnel        $v0, $at, L_802BA010
    if (ctx->r2 != ctx->r1) {
        // 0x802B9FA4: lh          $a0, 0x14($v1)
        ctx->r4 = MEM_H(ctx->r3, 0X14);
            goto L_802BA010;
    }
    goto skip_8;
    // 0x802B9FA4: lh          $a0, 0x14($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X14);
    skip_8:
L_802B9FA8:
    // 0x802B9FA8: lw          $t6, 0x0($ra)
    ctx->r14 = MEM_W(ctx->r31, 0X0);
    // 0x802B9FAC: lh          $t9, 0x26($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X26);
    // 0x802B9FB0: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802B9FB4: lhu         $t8, 0x2F6($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0X2F6);
    // 0x802B9FB8: multu       $t5, $t9
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9FBC: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x802B9FC0: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802B9FC4: or          $t8, $t6, $zero
    ctx->r24 = ctx->r14 | 0;
    // 0x802B9FC8: addiu       $t9, $t8, 0x40
    ctx->r25 = ADD32(ctx->r24, 0X40);
    // 0x802B9FCC: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x802B9FD0: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802B9FD4: addu        $t9, $t2, $t8
    ctx->r25 = ADD32(ctx->r10, ctx->r24);
    // 0x802B9FD8: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x802B9FDC: addiu       $t9, $zero, 0x100
    ctx->r25 = ADD32(0, 0X100);
    // 0x802B9FE0: mflo        $t7
    ctx->r15 = lo;
    // 0x802B9FE4: sra         $t8, $t6, 7
    ctx->r24 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802B9FE8: subu        $t6, $t9, $t8
    ctx->r14 = SUB32(ctx->r25, ctx->r24);
    // 0x802B9FEC: multu       $t7, $t6
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802B9FF0: lh          $t7, 0x14($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X14);
    // 0x802B9FF4: lh          $t3, 0x12($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X12);
    // 0x802B9FF8: lh          $t4, 0xA($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XA);
    // 0x802B9FFC: mflo        $t9
    ctx->r25 = lo;
    // 0x802BA000: sra         $t8, $t9, 13
    ctx->r24 = S32(SIGNED(ctx->r25) >> 13);
    // 0x802BA004: addu        $t6, $t7, $t8
    ctx->r14 = ADD32(ctx->r15, ctx->r24);
    // 0x802BA008: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
L_802BA00C:
    // 0x802BA00C: lh          $a0, 0x14($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X14);
L_802BA010:
    // 0x802BA010: lh          $t9, 0x26($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X26);
    // 0x802BA014: lh          $t8, 0x26($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X26);
    // 0x802BA018: lw          $v0, 0x0($ra)
    ctx->r2 = MEM_W(ctx->r31, 0X0);
    // 0x802BA01C: addu        $t7, $a0, $t9
    ctx->r15 = ADD32(ctx->r4, ctx->r25);
    // 0x802BA020: sh          $t7, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r15;
    // 0x802BA024: lh          $t7, 0x26($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X26);
    // 0x802BA028: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802BA02C: addu        $t9, $a0, $t6
    ctx->r25 = ADD32(ctx->r4, ctx->r14);
    // 0x802BA030: multu       $t5, $t7
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA034: sh          $t9, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r25;
    // 0x802BA038: lh          $t6, 0x2F6($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA03C: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x802BA040: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x802BA044: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x802BA048: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x802BA04C: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x802BA050: addu        $t9, $t2, $t6
    ctx->r25 = ADD32(ctx->r10, ctx->r14);
    // 0x802BA054: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x802BA058: mflo        $t8
    ctx->r24 = lo;
    // 0x802BA05C: lh          $a3, 0xC($v1)
    ctx->r7 = MEM_H(ctx->r3, 0XC);
    // 0x802BA060: sra         $t6, $t7, 7
    ctx->r14 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802BA064: sra         $t9, $t6, 4
    ctx->r25 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802BA068: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA06C: lh          $t8, 0x8($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X8);
    // 0x802BA070: lh          $t0, 0x10($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X10);
    // 0x802BA074: mflo        $t7
    ctx->r15 = lo;
    // 0x802BA078: sra         $t6, $t7, 8
    ctx->r14 = S32(SIGNED(ctx->r15) >> 8);
    // 0x802BA07C: addu        $t9, $t8, $t6
    ctx->r25 = ADD32(ctx->r24, ctx->r14);
    // 0x802BA080: sh          $t9, 0x8($v1)
    MEM_H(0X8, ctx->r3) = ctx->r25;
    // 0x802BA084: lh          $a2, 0x8($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X8);
    // 0x802BA088: lh          $t7, 0x2E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2E);
    // 0x802BA08C: lh          $t6, 0x2E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X2E);
    // 0x802BA090: subu        $t8, $a2, $t7
    ctx->r24 = SUB32(ctx->r6, ctx->r15);
    // 0x802BA094: multu       $t5, $t6
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA098: sh          $t8, 0x18($v1)
    MEM_H(0X18, ctx->r3) = ctx->r24;
    // 0x802BA09C: lh          $t9, 0x2F6($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA0A0: addiu       $t7, $t9, 0x40
    ctx->r15 = ADD32(ctx->r25, 0X40);
    // 0x802BA0A4: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802BA0A8: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802BA0AC: addu        $t9, $t2, $t6
    ctx->r25 = ADD32(ctx->r10, ctx->r14);
    // 0x802BA0B0: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x802BA0B4: mflo        $a1
    ctx->r5 = lo;
    // 0x802BA0B8: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802BA0BC: sra         $t6, $t8, 4
    ctx->r14 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802BA0C0: multu       $t6, $a1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA0C4: mflo        $t9
    ctx->r25 = lo;
    // 0x802BA0C8: sra         $t7, $t9, 9
    ctx->r15 = S32(SIGNED(ctx->r25) >> 9);
    // 0x802BA0CC: subu        $t8, $t4, $t7
    ctx->r24 = SUB32(ctx->r12, ctx->r15);
    // 0x802BA0D0: sh          $t8, 0x1A($v1)
    MEM_H(0X1A, ctx->r3) = ctx->r24;
    // 0x802BA0D4: lh          $t6, 0x2F6($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA0D8: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x802BA0DC: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x802BA0E0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802BA0E4: addu        $t6, $t2, $t8
    ctx->r14 = ADD32(ctx->r10, ctx->r24);
    // 0x802BA0E8: lh          $t9, 0x0($t6)
    ctx->r25 = MEM_H(ctx->r14, 0X0);
    // 0x802BA0EC: sra         $t7, $t9, 7
    ctx->r15 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802BA0F0: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802BA0F4: multu       $t8, $a1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA0F8: lh          $t8, 0x2E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X2E);
    // 0x802BA0FC: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA100: sra         $t9, $t6, 9
    ctx->r25 = S32(SIGNED(ctx->r14) >> 9);
    // 0x802BA104: addu        $t7, $t9, $a3
    ctx->r15 = ADD32(ctx->r25, ctx->r7);
    // 0x802BA108: addu        $t6, $a2, $t8
    ctx->r14 = ADD32(ctx->r6, ctx->r24);
    // 0x802BA10C: sh          $t7, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r15;
    // 0x802BA110: sh          $t6, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r14;
    // 0x802BA114: lh          $t9, 0x2F6($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA118: addiu       $t7, $t9, 0x40
    ctx->r15 = ADD32(ctx->r25, 0X40);
    // 0x802BA11C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x802BA120: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x802BA124: addu        $t9, $t2, $t6
    ctx->r25 = ADD32(ctx->r10, ctx->r14);
    // 0x802BA128: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x802BA12C: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802BA130: sra         $t6, $t8, 4
    ctx->r14 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802BA134: multu       $t6, $a1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA138: mflo        $t9
    ctx->r25 = lo;
    // 0x802BA13C: sra         $t7, $t9, 9
    ctx->r15 = S32(SIGNED(ctx->r25) >> 9);
    // 0x802BA140: addu        $t8, $t7, $t4
    ctx->r24 = ADD32(ctx->r15, ctx->r12);
    // 0x802BA144: sh          $t8, 0x22($v1)
    MEM_H(0X22, ctx->r3) = ctx->r24;
    // 0x802BA148: lh          $t6, 0x2F6($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA14C: addiu       $t9, $t6, 0x40
    ctx->r25 = ADD32(ctx->r14, 0X40);
    // 0x802BA150: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x802BA154: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802BA158: addu        $t6, $t2, $t8
    ctx->r14 = ADD32(ctx->r10, ctx->r24);
    // 0x802BA15C: lh          $t9, 0x0($t6)
    ctx->r25 = MEM_H(ctx->r14, 0X0);
    // 0x802BA160: sh          $t3, 0x2A($v1)
    MEM_H(0X2A, ctx->r3) = ctx->r11;
    // 0x802BA164: sra         $t7, $t9, 7
    ctx->r15 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802BA168: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802BA16C: multu       $t8, $a1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA170: lh          $t8, 0x32($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X32);
    // 0x802BA174: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA178: sra         $t9, $t6, 9
    ctx->r25 = S32(SIGNED(ctx->r14) >> 9);
    // 0x802BA17C: subu        $t7, $a3, $t9
    ctx->r15 = SUB32(ctx->r7, ctx->r25);
    // 0x802BA180: lh          $t9, 0x2A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2A);
    // 0x802BA184: subu        $t6, $t0, $t8
    ctx->r14 = SUB32(ctx->r8, ctx->r24);
    // 0x802BA188: sh          $t7, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r15;
    // 0x802BA18C: multu       $t5, $t9
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA190: sh          $t6, 0x28($v1)
    MEM_H(0X28, ctx->r3) = ctx->r14;
    // 0x802BA194: lh          $t7, 0x2F6($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA198: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x802BA19C: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x802BA1A0: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x802BA1A4: addu        $t7, $t2, $t9
    ctx->r15 = ADD32(ctx->r10, ctx->r25);
    // 0x802BA1A8: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x802BA1AC: mflo        $t1
    ctx->r9 = lo;
    // 0x802BA1B0: sh          $t3, 0x32($v1)
    MEM_H(0X32, ctx->r3) = ctx->r11;
    // 0x802BA1B4: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802BA1B8: sra         $t9, $t6, 4
    ctx->r25 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802BA1BC: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA1C0: lh          $t9, 0x32($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X32);
    // 0x802BA1C4: mflo        $t7
    ctx->r15 = lo;
    // 0x802BA1C8: sra         $t8, $t7, 8
    ctx->r24 = S32(SIGNED(ctx->r15) >> 8);
    // 0x802BA1CC: addu        $t6, $t8, $a0
    ctx->r14 = ADD32(ctx->r24, ctx->r4);
    // 0x802BA1D0: addu        $t7, $t0, $t9
    ctx->r15 = ADD32(ctx->r8, ctx->r25);
    // 0x802BA1D4: sh          $t6, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = ctx->r14;
    // 0x802BA1D8: sh          $t7, 0x30($v1)
    MEM_H(0X30, ctx->r3) = ctx->r15;
    // 0x802BA1DC: lh          $t8, 0x2F6($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2F6);
    // 0x802BA1E0: addiu       $t6, $t8, 0x40
    ctx->r14 = ADD32(ctx->r24, 0X40);
    // 0x802BA1E4: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x802BA1E8: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x802BA1EC: addu        $t8, $t2, $t7
    ctx->r24 = ADD32(ctx->r10, ctx->r15);
    // 0x802BA1F0: lh          $t6, 0x0($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X0);
    // 0x802BA1F4: sra         $t9, $t6, 7
    ctx->r25 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802BA1F8: sra         $t7, $t9, 4
    ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802BA1FC: multu       $t7, $t1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA200: mflo        $t8
    ctx->r24 = lo;
    // 0x802BA204: sra         $t6, $t8, 8
    ctx->r14 = S32(SIGNED(ctx->r24) >> 8);
    // 0x802BA208: subu        $t9, $a0, $t6
    ctx->r25 = SUB32(ctx->r4, ctx->r14);
    // 0x802BA20C: sh          $t9, 0x34($v1)
    MEM_H(0X34, ctx->r3) = ctx->r25;
    // 0x802BA210: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802BA214: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802BA218: jr          $ra
    // 0x802BA21C: nop

    return;
    // 0x802BA21C: nop

;}
RECOMP_FUNC void func_802BA220_6CB8D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802BA220: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802BA224: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x802BA228: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x802BA22C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802BA230: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802BA234: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802BA238: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802BA23C: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802BA240: lhu         $t0, 0x0($t6)
    ctx->r8 = MEM_HU(ctx->r14, 0X0);
    // 0x802BA244: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802BA248: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802BA24C: beq         $t0, $at, L_802BA29C
    if (ctx->r8 == ctx->r1) {
        // 0x802BA250: addiu       $a3, $a3, 0x552C
        ctx->r7 = ADD32(ctx->r7, 0X552C);
            goto L_802BA29C;
    }
    // 0x802BA250: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802BA254: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802BA258: beql        $t0, $at, L_802BA2A0
    if (ctx->r8 == ctx->r1) {
        // 0x802BA25C: lw          $v1, 0x0($a3)
        ctx->r3 = MEM_W(ctx->r7, 0X0);
            goto L_802BA2A0;
    }
    goto skip_0;
    // 0x802BA25C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    skip_0:
    // 0x802BA260: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802BA264: beql        $t0, $at, L_802BA2A0
    if (ctx->r8 == ctx->r1) {
        // 0x802BA268: lw          $v1, 0x0($a3)
        ctx->r3 = MEM_W(ctx->r7, 0X0);
            goto L_802BA2A0;
    }
    goto skip_1;
    // 0x802BA268: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    skip_1:
    // 0x802BA26C: addiu       $at, $zero, 0xB9
    ctx->r1 = ADD32(0, 0XB9);
    // 0x802BA270: beql        $t0, $at, L_802BA2A0
    if (ctx->r8 == ctx->r1) {
        // 0x802BA274: lw          $v1, 0x0($a3)
        ctx->r3 = MEM_W(ctx->r7, 0X0);
            goto L_802BA2A0;
    }
    goto skip_2;
    // 0x802BA274: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    skip_2:
    // 0x802BA278: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x802BA27C: beql        $t0, $at, L_802BA2A0
    if (ctx->r8 == ctx->r1) {
        // 0x802BA280: lw          $v1, 0x0($a3)
        ctx->r3 = MEM_W(ctx->r7, 0X0);
            goto L_802BA2A0;
    }
    goto skip_3;
    // 0x802BA280: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    skip_3:
    // 0x802BA284: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x802BA288: beql        $t0, $at, L_802BA2A0
    if (ctx->r8 == ctx->r1) {
        // 0x802BA28C: lw          $v1, 0x0($a3)
        ctx->r3 = MEM_W(ctx->r7, 0X0);
            goto L_802BA2A0;
    }
    goto skip_4;
    // 0x802BA28C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    skip_4:
    // 0x802BA290: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x802BA294: bnel        $t0, $at, L_802BA300
    if (ctx->r8 != ctx->r1) {
        // 0x802BA298: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_802BA300;
    }
    goto skip_5;
    // 0x802BA298: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_5:
L_802BA29C:
    // 0x802BA29C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
L_802BA2A0:
    // 0x802BA2A0: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x802BA2A4: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x802BA2A8: lhu         $t7, 0x2F2($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F2);
    // 0x802BA2AC: lhu         $t9, 0x2FA($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X2FA);
    // 0x802BA2B0: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802BA2B4: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802BA2B8: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA2BC: sh          $t6, 0x2F6($v1)
    MEM_H(0X2F6, ctx->r3) = ctx->r14;
    // 0x802BA2C0: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA2C4: bne         $t9, $zero, L_802BA2D0
    if (ctx->r25 != 0) {
        // 0x802BA2C8: nop
    
            goto L_802BA2D0;
    }
    // 0x802BA2C8: nop

    // 0x802BA2CC: break       7
    do_break(2150343372);
L_802BA2D0:
    // 0x802BA2D0: lhu         $t7, 0x2F4($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F4);
    // 0x802BA2D4: lhu         $t9, 0x2FA($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X2FA);
    // 0x802BA2D8: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802BA2DC: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802BA2E0: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA2E4: sh          $t6, 0x2F8($v1)
    MEM_H(0X2F8, ctx->r3) = ctx->r14;
    // 0x802BA2E8: bne         $t9, $zero, L_802BA2F4
    if (ctx->r25 != 0) {
        // 0x802BA2EC: nop
    
            goto L_802BA2F4;
    }
    // 0x802BA2EC: nop

    // 0x802BA2F0: break       7
    do_break(2150343408);
L_802BA2F4:
    // 0x802BA2F4: b           L_802BA3A4
    // 0x802BA2F8: lh          $t9, 0x2E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2E);
        goto L_802BA3A4;
    // 0x802BA2F8: lh          $t9, 0x2E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2E);
    // 0x802BA2FC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_802BA300:
    // 0x802BA300: beq         $t0, $at, L_802BA314
    if (ctx->r8 == ctx->r1) {
        // 0x802BA304: nop
    
            goto L_802BA314;
    }
    // 0x802BA304: nop

    // 0x802BA308: addiu       $at, $zero, 0xB7
    ctx->r1 = ADD32(0, 0XB7);
    // 0x802BA30C: bne         $t0, $at, L_802BA37C
    if (ctx->r8 != ctx->r1) {
        // 0x802BA310: lui         $a3, 0x803D
        ctx->r7 = S32(0X803D << 16);
            goto L_802BA37C;
    }
    // 0x802BA310: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
L_802BA314:
    // 0x802BA314: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802BA318: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802BA31C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA320: addiu       $t4, $zero, 0x6
    ctx->r12 = ADD32(0, 0X6);
    // 0x802BA324: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    // 0x802BA328: lhu         $t7, 0x2F2($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F2);
    // 0x802BA32C: lhu         $t9, 0x2FA($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X2FA);
    // 0x802BA330: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802BA334: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802BA338: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA33C: sh          $t6, 0x2F6($v1)
    MEM_H(0X2F6, ctx->r3) = ctx->r14;
    // 0x802BA340: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA344: bne         $t9, $zero, L_802BA350
    if (ctx->r25 != 0) {
        // 0x802BA348: nop
    
            goto L_802BA350;
    }
    // 0x802BA348: nop

    // 0x802BA34C: break       7
    do_break(2150343500);
L_802BA350:
    // 0x802BA350: lhu         $t7, 0x2F4($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F4);
    // 0x802BA354: lhu         $t9, 0x2FA($v1)
    ctx->r25 = MEM_HU(ctx->r3, 0X2FA);
    // 0x802BA358: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802BA35C: divu        $zero, $t8, $t9
    lo = S32(U32(ctx->r24) / U32(ctx->r25)); hi = S32(U32(ctx->r24) % U32(ctx->r25));
    // 0x802BA360: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA364: sh          $t6, 0x2F8($v1)
    MEM_H(0X2F8, ctx->r3) = ctx->r14;
    // 0x802BA368: bne         $t9, $zero, L_802BA374
    if (ctx->r25 != 0) {
        // 0x802BA36C: nop
    
            goto L_802BA374;
    }
    // 0x802BA36C: nop

    // 0x802BA370: break       7
    do_break(2150343536);
L_802BA374:
    // 0x802BA374: b           L_802BA3A4
    // 0x802BA378: lh          $t9, 0x2E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2E);
        goto L_802BA3A4;
    // 0x802BA378: lh          $t9, 0x2E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2E);
L_802BA37C:
    // 0x802BA37C: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802BA380: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA384: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x802BA388: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802BA38C: lhu         $t7, 0x2F2($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F2);
    // 0x802BA390: sh          $t7, 0x2F6($v1)
    MEM_H(0X2F6, ctx->r3) = ctx->r15;
    // 0x802BA394: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA398: lhu         $t8, 0x2F4($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X2F4);
    // 0x802BA39C: sh          $t8, 0x2F8($v1)
    MEM_H(0X2F8, ctx->r3) = ctx->r24;
    // 0x802BA3A0: lh          $t9, 0x2E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2E);
L_802BA3A4:
    // 0x802BA3A4: lhu         $a0, 0x32($sp)
    ctx->r4 = MEM_HU(ctx->r29, 0X32);
    // 0x802BA3A8: lw          $a1, 0x20($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X20);
    // 0x802BA3AC: multu       $a2, $t9
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA3B0: sh          $t4, 0x1C($sp)
    MEM_H(0X1C, ctx->r29) = ctx->r12;
    // 0x802BA3B4: mflo        $a2
    ctx->r6 = lo;
    // 0x802BA3B8: sra         $t6, $a2, 4
    ctx->r14 = S32(SIGNED(ctx->r6) >> 4);
    // 0x802BA3BC: addiu       $t8, $t6, 0xA
    ctx->r24 = ADD32(ctx->r14, 0XA);
    // 0x802BA3C0: jal         0x802BD21C
    // 0x802BA3C4: sh          $t8, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r24;
    func_802BD21C_6CE8CC(rdram, ctx);
        goto after_0;
    // 0x802BA3C4: sh          $t8, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r24;
    after_0:
    // 0x802BA3C8: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x802BA3CC: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x802BA3D0: sh          $zero, 0x12($v0)
    MEM_H(0X12, ctx->r2) = 0;
    // 0x802BA3D4: lh          $t5, 0x12($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X12);
    // 0x802BA3D8: lw          $t9, 0x20($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X20);
    // 0x802BA3DC: lh          $t7, 0x2A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X2A);
    // 0x802BA3E0: sh          $t5, 0x10($v0)
    MEM_H(0X10, ctx->r2) = ctx->r13;
    // 0x802BA3E4: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x802BA3E8: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x802BA3EC: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x802BA3F0: lh          $t4, 0x1C($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X1C);
    // 0x802BA3F4: lh          $ra, 0x2E($sp)
    ctx->r31 = MEM_H(ctx->r29, 0X2E);
    // 0x802BA3F8: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x802BA3FC: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x802BA400: sh          $t8, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r24;
    // 0x802BA404: multu       $t4, $ra
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r31)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA408: lhu         $t6, 0x2F6($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X2F6);
    // 0x802BA40C: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x802BA410: addiu       $t3, $t3, 0x2C78
    ctx->r11 = ADD32(ctx->r11, 0X2C78);
    // 0x802BA414: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802BA418: or          $t6, $t8, $zero
    ctx->r14 = ctx->r24 | 0;
    // 0x802BA41C: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x802BA420: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802BA424: addu        $t6, $t3, $t8
    ctx->r14 = ADD32(ctx->r11, ctx->r24);
    // 0x802BA428: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x802BA42C: mflo        $t2
    ctx->r10 = lo;
    // 0x802BA430: lh          $t9, 0x14($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X14);
    // 0x802BA434: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802BA438: sra         $t6, $t8, 4
    ctx->r14 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802BA43C: multu       $t2, $t6
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA440: lh          $a2, 0x1A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X1A);
    // 0x802BA444: sh          $zero, 0x0($v0)
    MEM_H(0X0, ctx->r2) = 0;
    // 0x802BA448: sh          $zero, 0x8($v0)
    MEM_H(0X8, ctx->r2) = 0;
    // 0x802BA44C: sh          $a2, 0xA($v0)
    MEM_H(0XA, ctx->r2) = ctx->r6;
    // 0x802BA450: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x802BA454: mflo        $t7
    ctx->r15 = lo;
    // 0x802BA458: sra         $t8, $t7, 9
    ctx->r24 = S32(SIGNED(ctx->r15) >> 9);
    // 0x802BA45C: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x802BA460: sra         $t7, $a2, 1
    ctx->r15 = S32(SIGNED(ctx->r6) >> 1);
    // 0x802BA464: sh          $t6, 0x14($v0)
    MEM_H(0X14, ctx->r2) = ctx->r14;
    // 0x802BA468: sh          $t7, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r15;
    // 0x802BA46C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x802BA470: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x802BA474: lh          $t8, 0x26($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X26);
    // 0x802BA478: lhu         $t0, 0x0($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X0);
    // 0x802BA47C: beq         $t0, $at, L_802BA494
    if (ctx->r8 == ctx->r1) {
        // 0x802BA480: addiu       $at, $zero, 0xB6
        ctx->r1 = ADD32(0, 0XB6);
            goto L_802BA494;
    }
    // 0x802BA480: addiu       $at, $zero, 0xB6
    ctx->r1 = ADD32(0, 0XB6);
    // 0x802BA484: beq         $t0, $at, L_802BA494
    if (ctx->r8 == ctx->r1) {
        // 0x802BA488: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_802BA494;
    }
    // 0x802BA488: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x802BA48C: beql        $t0, $at, L_802BA498
    if (ctx->r8 == ctx->r1) {
        // 0x802BA490: lh          $a0, 0x14($v0)
        ctx->r4 = MEM_H(ctx->r2, 0X14);
            goto L_802BA498;
    }
    goto skip_6;
    // 0x802BA490: lh          $a0, 0x14($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X14);
    skip_6:
L_802BA494:
    // 0x802BA494: lh          $a0, 0x14($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X14);
L_802BA498:
    // 0x802BA498: lh          $t7, 0x26($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X26);
    // 0x802BA49C: lh          $a2, 0x8($v0)
    ctx->r6 = MEM_H(ctx->r2, 0X8);
    // 0x802BA4A0: addu        $t6, $a0, $t8
    ctx->r14 = ADD32(ctx->r4, ctx->r24);
    // 0x802BA4A4: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x802BA4A8: addu        $t8, $a0, $t9
    ctx->r24 = ADD32(ctx->r4, ctx->r25);
    // 0x802BA4AC: sh          $t6, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r14;
    // 0x802BA4B0: sh          $t8, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r24;
    // 0x802BA4B4: lhu         $t7, 0x2F6($v1)
    ctx->r15 = MEM_HU(ctx->r3, 0X2F6);
    // 0x802BA4B8: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x802BA4BC: lh          $a3, 0xA($v0)
    ctx->r7 = MEM_H(ctx->r2, 0XA);
    // 0x802BA4C0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x802BA4C4: or          $t7, $t8, $zero
    ctx->r15 = ctx->r24 | 0;
    // 0x802BA4C8: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802BA4CC: sll         $t8, $t9, 1
    ctx->r24 = S32(ctx->r25 << 1);
    // 0x802BA4D0: addu        $t7, $t3, $t8
    ctx->r15 = ADD32(ctx->r11, ctx->r24);
    // 0x802BA4D4: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802BA4D8: lh          $t0, 0x10($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X10);
    // 0x802BA4DC: sra         $t8, $t9, 7
    ctx->r24 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802BA4E0: sra         $t7, $t8, 4
    ctx->r15 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802BA4E4: multu       $t2, $t7
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA4E8: mflo        $t9
    ctx->r25 = lo;
    // 0x802BA4EC: sra         $t8, $t9, 9
    ctx->r24 = S32(SIGNED(ctx->r25) >> 9);
    // 0x802BA4F0: subu        $t9, $a2, $ra
    ctx->r25 = SUB32(ctx->r6, ctx->r31);
    // 0x802BA4F4: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x802BA4F8: sh          $t7, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r15;
    // 0x802BA4FC: sh          $t9, 0x18($v0)
    MEM_H(0X18, ctx->r2) = ctx->r25;
    // 0x802BA500: lh          $t6, 0x2F6($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2F6);
    // 0x802BA504: lh          $a1, 0xC($v0)
    ctx->r5 = MEM_H(ctx->r2, 0XC);
    // 0x802BA508: andi        $t8, $t6, 0xFF
    ctx->r24 = ctx->r14 & 0XFF;
    // 0x802BA50C: sll         $t7, $t8, 1
    ctx->r15 = S32(ctx->r24 << 1);
    // 0x802BA510: addu        $t9, $t3, $t7
    ctx->r25 = ADD32(ctx->r11, ctx->r15);
    // 0x802BA514: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x802BA518: sh          $a1, 0x1C($v0)
    MEM_H(0X1C, ctx->r2) = ctx->r5;
    // 0x802BA51C: sra         $t8, $t6, 7
    ctx->r24 = S32(SIGNED(ctx->r14) >> 7);
    // 0x802BA520: sra         $t7, $t8, 4
    ctx->r15 = S32(SIGNED(ctx->r24) >> 4);
    // 0x802BA524: multu       $t7, $t2
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA528: addu        $t7, $a2, $ra
    ctx->r15 = ADD32(ctx->r6, ctx->r31);
    // 0x802BA52C: sh          $t7, 0x20($v0)
    MEM_H(0X20, ctx->r2) = ctx->r15;
    // 0x802BA530: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802BA534: mflo        $t9
    ctx->r25 = lo;
    // 0x802BA538: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x802BA53C: addu        $t8, $t6, $a3
    ctx->r24 = ADD32(ctx->r14, ctx->r7);
    // 0x802BA540: sh          $t8, 0x1A($v0)
    MEM_H(0X1A, ctx->r2) = ctx->r24;
    // 0x802BA544: lh          $t9, 0x2F6($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2F6);
    // 0x802BA548: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x802BA54C: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x802BA550: addu        $t7, $t3, $t8
    ctx->r15 = ADD32(ctx->r11, ctx->r24);
    // 0x802BA554: lh          $t9, 0x0($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X0);
    // 0x802BA558: sh          $t5, 0x2A($v0)
    MEM_H(0X2A, ctx->r2) = ctx->r13;
    // 0x802BA55C: sh          $a1, 0x24($v0)
    MEM_H(0X24, ctx->r2) = ctx->r5;
    // 0x802BA560: sra         $t6, $t9, 7
    ctx->r14 = S32(SIGNED(ctx->r25) >> 7);
    // 0x802BA564: sra         $t8, $t6, 4
    ctx->r24 = S32(SIGNED(ctx->r14) >> 4);
    // 0x802BA568: multu       $t8, $t2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA56C: lh          $t8, 0x32($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X32);
    // 0x802BA570: mflo        $t7
    ctx->r15 = lo;
    // 0x802BA574: sra         $t9, $t7, 8
    ctx->r25 = S32(SIGNED(ctx->r15) >> 8);
    // 0x802BA578: subu        $t6, $a3, $t9
    ctx->r14 = SUB32(ctx->r7, ctx->r25);
    // 0x802BA57C: lh          $t9, 0x2A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X2A);
    // 0x802BA580: subu        $t7, $t0, $t8
    ctx->r15 = SUB32(ctx->r8, ctx->r24);
    // 0x802BA584: sh          $t6, 0x22($v0)
    MEM_H(0X22, ctx->r2) = ctx->r14;
    // 0x802BA588: multu       $t4, $t9
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA58C: sh          $t7, 0x28($v0)
    MEM_H(0X28, ctx->r2) = ctx->r15;
    // 0x802BA590: lh          $t6, 0x2F6($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2F6);
    // 0x802BA594: addiu       $t8, $t6, 0x40
    ctx->r24 = ADD32(ctx->r14, 0X40);
    // 0x802BA598: andi        $t7, $t8, 0xFF
    ctx->r15 = ctx->r24 & 0XFF;
    // 0x802BA59C: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x802BA5A0: addu        $t6, $t3, $t9
    ctx->r14 = ADD32(ctx->r11, ctx->r25);
    // 0x802BA5A4: lh          $t8, 0x0($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X0);
    // 0x802BA5A8: mflo        $t1
    ctx->r9 = lo;
    // 0x802BA5AC: sh          $t5, 0x32($v0)
    MEM_H(0X32, ctx->r2) = ctx->r13;
    // 0x802BA5B0: sra         $t7, $t8, 7
    ctx->r15 = S32(SIGNED(ctx->r24) >> 7);
    // 0x802BA5B4: sra         $t9, $t7, 4
    ctx->r25 = S32(SIGNED(ctx->r15) >> 4);
    // 0x802BA5B8: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA5BC: lh          $t9, 0x32($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X32);
    // 0x802BA5C0: mflo        $t6
    ctx->r14 = lo;
    // 0x802BA5C4: sra         $t8, $t6, 10
    ctx->r24 = S32(SIGNED(ctx->r14) >> 10);
    // 0x802BA5C8: addu        $t7, $t8, $a0
    ctx->r15 = ADD32(ctx->r24, ctx->r4);
    // 0x802BA5CC: addu        $t6, $t0, $t9
    ctx->r14 = ADD32(ctx->r8, ctx->r25);
    // 0x802BA5D0: sh          $t7, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = ctx->r15;
    // 0x802BA5D4: sh          $t6, 0x30($v0)
    MEM_H(0X30, ctx->r2) = ctx->r14;
    // 0x802BA5D8: lh          $t8, 0x2F6($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2F6);
    // 0x802BA5DC: addiu       $t7, $t8, 0x40
    ctx->r15 = ADD32(ctx->r24, 0X40);
    // 0x802BA5E0: andi        $t9, $t7, 0xFF
    ctx->r25 = ctx->r15 & 0XFF;
    // 0x802BA5E4: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x802BA5E8: addu        $t8, $t3, $t6
    ctx->r24 = ADD32(ctx->r11, ctx->r14);
    // 0x802BA5EC: lh          $t7, 0x0($t8)
    ctx->r15 = MEM_H(ctx->r24, 0X0);
    // 0x802BA5F0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x802BA5F4: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x802BA5F8: sra         $t6, $t9, 4
    ctx->r14 = S32(SIGNED(ctx->r25) >> 4);
    // 0x802BA5FC: multu       $t6, $t1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802BA600: mflo        $t8
    ctx->r24 = lo;
    // 0x802BA604: sra         $t7, $t8, 10
    ctx->r15 = S32(SIGNED(ctx->r24) >> 10);
    // 0x802BA608: subu        $t9, $a0, $t7
    ctx->r25 = SUB32(ctx->r4, ctx->r15);
    // 0x802BA60C: jr          $ra
    // 0x802BA610: sh          $t9, 0x34($v0)
    MEM_H(0X34, ctx->r2) = ctx->r25;
    return;
    // 0x802BA610: sh          $t9, 0x34($v0)
    MEM_H(0X34, ctx->r2) = ctx->r25;
;}
