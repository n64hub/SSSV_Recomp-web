#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_8035D734_76EDE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035D734: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8035D738: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x8035D73C: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x8035D740: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8035D744: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8035D748: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x8035D74C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035D750: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x8035D754: bne         $v0, $at, L_8035D830
    if (ctx->r2 != ctx->r1) {
        // 0x8035D758: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_8035D830;
    }
    // 0x8035D758: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035D75C: lb          $t6, 0x36A($v1)
    ctx->r14 = MEM_B(ctx->r3, 0X36A);
    // 0x8035D760: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035D764: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D768: bne         $t6, $at, L_8035D7C4
    if (ctx->r14 != ctx->r1) {
        // 0x8035D76C: addiu       $a0, $a0, 0x2ECC
        ctx->r4 = ADD32(ctx->r4, 0X2ECC);
            goto L_8035D7C4;
    }
    // 0x8035D76C: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D770: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035D774: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x8035D778: lhu         $t8, 0x328($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X328);
    // 0x8035D77C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D780: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D784: subu        $v0, $t7, $t8
    ctx->r2 = SUB32(ctx->r15, ctx->r24);
    // 0x8035D788: andi        $t9, $v0, 0xFFFF
    ctx->r25 = ctx->r2 & 0XFFFF;
    // 0x8035D78C: slti        $at, $t9, 0x20
    ctx->r1 = SIGNED(ctx->r25) < 0X20 ? 1 : 0;
    // 0x8035D790: beq         $at, $zero, L_8035D7A8
    if (ctx->r1 == 0) {
        // 0x8035D794: addiu       $t0, $zero, 0x20
        ctx->r8 = ADD32(0, 0X20);
            goto L_8035D7A8;
    }
    // 0x8035D794: addiu       $t0, $zero, 0x20
    ctx->r8 = ADD32(0, 0X20);
    // 0x8035D798: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D79C: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D7A0: b           L_8035D7AC
    // 0x8035D7A4: sh          $t9, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r25;
        goto L_8035D7AC;
    // 0x8035D7A4: sh          $t9, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r25;
L_8035D7A8:
    // 0x8035D7A8: sh          $t0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r8;
L_8035D7AC:
    // 0x8035D7AC: lhu         $t1, 0x0($a0)
    ctx->r9 = MEM_HU(ctx->r4, 0X0);
    // 0x8035D7B0: slti        $at, $t1, 0x20
    ctx->r1 = SIGNED(ctx->r9) < 0X20 ? 1 : 0;
    // 0x8035D7B4: bne         $at, $zero, L_8035D7D8
    if (ctx->r1 != 0) {
        // 0x8035D7B8: nop
    
            goto L_8035D7D8;
    }
    // 0x8035D7B8: nop

    // 0x8035D7BC: b           L_8035D7D8
    // 0x8035D7C0: sb          $zero, 0x36A($v1)
    MEM_B(0X36A, ctx->r3) = 0;
        goto L_8035D7D8;
    // 0x8035D7C0: sb          $zero, 0x36A($v1)
    MEM_B(0X36A, ctx->r3) = 0;
L_8035D7C4:
    // 0x8035D7C4: addiu       $t2, $zero, 0x20
    ctx->r10 = ADD32(0, 0X20);
    // 0x8035D7C8: sh          $t2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r10;
    // 0x8035D7CC: sb          $zero, 0x369($v1)
    MEM_B(0X369, ctx->r3) = 0;
    // 0x8035D7D0: lw          $t3, 0x0($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X0);
    // 0x8035D7D4: sb          $zero, 0x365($t3)
    MEM_B(0X365, ctx->r11) = 0;
L_8035D7D8:
    // 0x8035D7D8: lb          $t5, 0x2D10($t5)
    ctx->r13 = MEM_B(ctx->r13, 0X2D10);
    // 0x8035D7DC: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8035D7E0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035D7E4: bne         $t5, $zero, L_8035D820
    if (ctx->r13 != 0) {
        // 0x8035D7E8: sh          $t4, 0x2ECE($at)
        MEM_H(0X2ECE, ctx->r1) = ctx->r12;
            goto L_8035D820;
    }
    // 0x8035D7E8: sh          $t4, 0x2ECE($at)
    MEM_H(0X2ECE, ctx->r1) = ctx->r12;
    // 0x8035D7EC: jal         0x8012826C
    // 0x8035D7F0: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x8035D7F0: nop

    after_0:
    // 0x8035D7F4: andi        $t6, $v0, 0x3F
    ctx->r14 = ctx->r2 & 0X3F;
    // 0x8035D7F8: bne         $t6, $zero, L_8035D820
    if (ctx->r14 != 0) {
        // 0x8035D7FC: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8035D820;
    }
    // 0x8035D7FC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035D800: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035D804: ori         $t7, $zero, 0xFFC1
    ctx->r15 = 0 | 0XFFC1;
    // 0x8035D808: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8035D80C: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x8035D810: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8035D814: lh          $a3, 0x30($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X30);
    // 0x8035D818: jal         0x802D9C64
    // 0x8035D81C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    create_sparks(rdram, ctx);
        goto after_1;
    // 0x8035D81C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    after_1:
L_8035D820:
    // 0x8035D820: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035D824: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8035D828: b           L_8035D940
    // 0x8035D82C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
        goto L_8035D940;
    // 0x8035D82C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
L_8035D830:
    // 0x8035D830: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x8035D834: beql        $t8, $zero, L_8035D8A8
    if (ctx->r24 == 0) {
        // 0x8035D838: lb          $t3, 0x36A($v1)
        ctx->r11 = MEM_B(ctx->r3, 0X36A);
            goto L_8035D8A8;
    }
    goto skip_0;
    // 0x8035D838: lb          $t3, 0x36A($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X36A);
    skip_0:
    // 0x8035D83C: lb          $t9, 0x36A($v1)
    ctx->r25 = MEM_B(ctx->r3, 0X36A);
    // 0x8035D840: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035D844: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D848: bnel        $t9, $at, L_8035D8A8
    if (ctx->r25 != ctx->r1) {
        // 0x8035D84C: lb          $t3, 0x36A($v1)
        ctx->r11 = MEM_B(ctx->r3, 0X36A);
            goto L_8035D8A8;
    }
    goto skip_1;
    // 0x8035D84C: lb          $t3, 0x36A($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X36A);
    skip_1:
    // 0x8035D850: lh          $a0, 0x2D34($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D34);
    // 0x8035D854: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8035D858: slti        $at, $a0, 0x11
    ctx->r1 = SIGNED(ctx->r4) < 0X11 ? 1 : 0;
    // 0x8035D85C: bnel        $at, $zero, L_8035D8A8
    if (ctx->r1 != 0) {
        // 0x8035D860: lb          $t3, 0x36A($v1)
        ctx->r11 = MEM_B(ctx->r3, 0X36A);
            goto L_8035D8A8;
    }
    goto skip_2;
    // 0x8035D860: lb          $t3, 0x36A($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X36A);
    skip_2:
    // 0x8035D864: addiu       $v0, $a0, -0x10
    ctx->r2 = ADD32(ctx->r4, -0X10);
    // 0x8035D868: sra         $t0, $v0, 1
    ctx->r8 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8035D86C: slti        $at, $t0, 0x20
    ctx->r1 = SIGNED(ctx->r8) < 0X20 ? 1 : 0;
    // 0x8035D870: beq         $at, $zero, L_8035D888
    if (ctx->r1 == 0) {
        // 0x8035D874: lui         $a0, 0x803F
        ctx->r4 = S32(0X803F << 16);
            goto L_8035D888;
    }
    // 0x8035D874: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D878: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D87C: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D880: b           L_8035D894
    // 0x8035D884: sh          $t0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r8;
        goto L_8035D894;
    // 0x8035D884: sh          $t0, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r8;
L_8035D888:
    // 0x8035D888: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D88C: addiu       $t1, $zero, 0x20
    ctx->r9 = ADD32(0, 0X20);
    // 0x8035D890: sh          $t1, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r9;
L_8035D894:
    // 0x8035D894: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035D898: sh          $t2, 0x2ECE($at)
    MEM_H(0X2ECE, ctx->r1) = ctx->r10;
    // 0x8035D89C: b           L_8035D940
    // 0x8035D8A0: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
        goto L_8035D940;
    // 0x8035D8A0: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x8035D8A4: lb          $t3, 0x36A($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X36A);
L_8035D8A8:
    // 0x8035D8A8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035D8AC: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x8035D8B0: bnel        $t3, $at, L_8035D944
    if (ctx->r11 != ctx->r1) {
        // 0x8035D8B4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8035D944;
    }
    goto skip_3;
    // 0x8035D8B4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_3:
    // 0x8035D8B8: lhu         $t4, 0x5544($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X5544);
    // 0x8035D8BC: lhu         $t5, 0x328($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X328);
    // 0x8035D8C0: subu        $v0, $t4, $t5
    ctx->r2 = SUB32(ctx->r12, ctx->r13);
    // 0x8035D8C4: bltz        $v0, L_8035D930
    if (SIGNED(ctx->r2) < 0) {
        // 0x8035D8C8: slti        $at, $v0, 0x18
        ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
            goto L_8035D930;
    }
    // 0x8035D8C8: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    // 0x8035D8CC: beq         $at, $zero, L_8035D930
    if (ctx->r1 == 0) {
        // 0x8035D8D0: lui         $a0, 0x803F
        ctx->r4 = S32(0X803F << 16);
            goto L_8035D930;
    }
    // 0x8035D8D0: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D8D4: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x8035D8D8: addiu       $t7, $zero, 0x20
    ctx->r15 = ADD32(0, 0X20);
    // 0x8035D8DC: subu        $t8, $t7, $t6
    ctx->r24 = SUB32(ctx->r15, ctx->r14);
    // 0x8035D8E0: addiu       $a0, $a0, 0x2ECC
    ctx->r4 = ADD32(ctx->r4, 0X2ECC);
    // 0x8035D8E4: andi        $v1, $t8, 0xFFFF
    ctx->r3 = ctx->r24 & 0XFFFF;
    // 0x8035D8E8: blez        $v1, L_8035D908
    if (SIGNED(ctx->r3) <= 0) {
        // 0x8035D8EC: sh          $t8, 0x0($a0)
        MEM_H(0X0, ctx->r4) = ctx->r24;
            goto L_8035D908;
    }
    // 0x8035D8EC: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
    // 0x8035D8F0: slti        $at, $v1, 0x21
    ctx->r1 = SIGNED(ctx->r3) < 0X21 ? 1 : 0;
    // 0x8035D8F4: beq         $at, $zero, L_8035D908
    if (ctx->r1 == 0) {
        // 0x8035D8F8: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_8035D908;
    }
    // 0x8035D8F8: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8035D8FC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035D900: b           L_8035D90C
    // 0x8035D904: sh          $t9, 0x2ECE($at)
    MEM_H(0X2ECE, ctx->r1) = ctx->r25;
        goto L_8035D90C;
    // 0x8035D904: sh          $t9, 0x2ECE($at)
    MEM_H(0X2ECE, ctx->r1) = ctx->r25;
L_8035D908:
    // 0x8035D908: sh          $zero, 0x0($a0)
    MEM_H(0X0, ctx->r4) = 0;
L_8035D90C:
    // 0x8035D90C: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x8035D910: sra         $t0, $a0, 16
    ctx->r8 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8035D914: or          $a0, $t0, $zero
    ctx->r4 = ctx->r8 | 0;
    // 0x8035D918: jal         0x802DC854
    // 0x8035D91C: addiu       $a1, $zero, 0x18
    ctx->r5 = ADD32(0, 0X18);
    func_802DC854_6EDF04(rdram, ctx);
        goto after_2;
    // 0x8035D91C: addiu       $a1, $zero, 0x18
    ctx->r5 = ADD32(0, 0X18);
    after_2:
    // 0x8035D920: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035D924: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8035D928: b           L_8035D940
    // 0x8035D92C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
        goto L_8035D940;
    // 0x8035D92C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
L_8035D930:
    // 0x8035D930: sb          $zero, 0x36A($v1)
    MEM_B(0X36A, ctx->r3) = 0;
    // 0x8035D934: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035D938: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8035D93C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
L_8035D940:
    // 0x8035D940: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_8035D944:
    // 0x8035D944: beq         $v0, $at, L_8035D96C
    if (ctx->r2 == ctx->r1) {
        // 0x8035D948: lui         $t1, 0x803D
        ctx->r9 = S32(0X803D << 16);
            goto L_8035D96C;
    }
    // 0x8035D948: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8035D94C: lbu         $t1, 0x5538($t1)
    ctx->r9 = MEM_BU(ctx->r9, 0X5538);
    // 0x8035D950: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8035D954: beql        $t1, $zero, L_8035D9D0
    if (ctx->r9 == 0) {
        // 0x8035D958: lh          $t2, 0x348($v1)
        ctx->r10 = MEM_H(ctx->r3, 0X348);
            goto L_8035D9D0;
    }
    goto skip_4;
    // 0x8035D958: lh          $t2, 0x348($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X348);
    skip_4:
    // 0x8035D95C: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x8035D960: lh          $t3, 0x14C($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X14C);
    // 0x8035D964: slti        $at, $t3, 0xF
    ctx->r1 = SIGNED(ctx->r11) < 0XF ? 1 : 0;
    // 0x8035D968: beq         $at, $zero, L_8035D9CC
    if (ctx->r1 == 0) {
        // 0x8035D96C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8035D9CC;
    }
L_8035D96C:
    // 0x8035D96C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035D970: lh          $v0, 0x5540($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5540);
    // 0x8035D974: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8035D978: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035D97C: andi        $t7, $v0, 0xFF
    ctx->r15 = ctx->r2 & 0XFF;
    // 0x8035D980: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x8035D984: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x8035D988: lh          $t8, 0x2C78($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C78);
    // 0x8035D98C: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x8035D990: subu        $t4, $t4, $v0
    ctx->r12 = SUB32(ctx->r12, ctx->r2);
    // 0x8035D994: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8035D998: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x8035D99C: sll         $t0, $t9, 2
    ctx->r8 = S32(ctx->r25 << 2);
    // 0x8035D9A0: sh          $t5, 0x2ED2($at)
    MEM_H(0X2ED2, ctx->r1) = ctx->r13;
    // 0x8035D9A4: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x8035D9A8: sll         $t0, $t0, 4
    ctx->r8 = S32(ctx->r8 << 4);
    // 0x8035D9AC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035D9B0: addiu       $a0, $a0, 0x2ED4
    ctx->r4 = ADD32(ctx->r4, 0X2ED4);
    // 0x8035D9B4: bgez        $t0, L_8035D9C4
    if (SIGNED(ctx->r8) >= 0) {
        // 0x8035D9B8: sra         $t1, $t0, 2
        ctx->r9 = S32(SIGNED(ctx->r8) >> 2);
            goto L_8035D9C4;
    }
    // 0x8035D9B8: sra         $t1, $t0, 2
    ctx->r9 = S32(SIGNED(ctx->r8) >> 2);
    // 0x8035D9BC: addiu       $at, $t0, 0x3
    ctx->r1 = ADD32(ctx->r8, 0X3);
    // 0x8035D9C0: sra         $t1, $at, 2
    ctx->r9 = S32(SIGNED(ctx->r1) >> 2);
L_8035D9C4:
    // 0x8035D9C4: b           L_8035DA50
    // 0x8035D9C8: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
        goto L_8035DA50;
    // 0x8035D9C8: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
L_8035D9CC:
    // 0x8035D9CC: lh          $t2, 0x348($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X348);
L_8035D9D0:
    // 0x8035D9D0: beq         $t2, $zero, L_8035DA3C
    if (ctx->r10 == 0) {
        // 0x8035D9D4: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8035DA3C;
    }
    // 0x8035D9D4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035D9D8: lh          $v0, 0x5540($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5540);
    // 0x8035D9DC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x8035D9E0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035D9E4: sll         $t3, $v0, 2
    ctx->r11 = S32(ctx->r2 << 2);
    // 0x8035D9E8: andi        $t5, $v0, 0xFF
    ctx->r13 = ctx->r2 & 0XFF;
    // 0x8035D9EC: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x8035D9F0: subu        $t3, $t3, $v0
    ctx->r11 = SUB32(ctx->r11, ctx->r2);
    // 0x8035D9F4: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8035D9F8: addu        $t6, $t6, $t7
    ctx->r14 = ADD32(ctx->r14, ctx->r15);
    // 0x8035D9FC: lh          $t6, 0x2C78($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C78);
    // 0x8035DA00: sh          $t4, 0x2ED2($at)
    MEM_H(0X2ED2, ctx->r1) = ctx->r12;
    // 0x8035DA04: lh          $t9, 0x348($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X348);
    // 0x8035DA08: sra         $t8, $t6, 7
    ctx->r24 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8035DA0C: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x8035DA10: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035DA14: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035DA18: addiu       $a0, $a0, 0x2ED4
    ctx->r4 = ADD32(ctx->r4, 0X2ED4);
    // 0x8035DA1C: mflo        $t0
    ctx->r8 = lo;
    // 0x8035DA20: nop

    // 0x8035DA24: nop

    // 0x8035DA28: div         $zero, $t0, $at
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r1)));
    // 0x8035DA2C: mflo        $t1
    ctx->r9 = lo;
    // 0x8035DA30: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
    // 0x8035DA34: b           L_8035DA54
    // 0x8035DA38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8035DA54;
    // 0x8035DA38: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8035DA3C:
    // 0x8035DA3C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035DA40: addiu       $a0, $a0, 0x2ED4
    ctx->r4 = ADD32(ctx->r4, 0X2ED4);
    // 0x8035DA44: sw          $zero, 0x0($a0)
    MEM_W(0X0, ctx->r4) = 0;
    // 0x8035DA48: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035DA4C: sh          $zero, 0x2ED2($at)
    MEM_H(0X2ED2, ctx->r1) = 0;
L_8035DA50:
    // 0x8035DA50: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8035DA54:
    // 0x8035DA54: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8035DA58: jr          $ra
    // 0x8035DA5C: nop

    return;
    // 0x8035DA5C: nop

;}
RECOMP_FUNC void func_8035DA60_76F110(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035DA60: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8035DA64: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x8035DA68: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8035DA6C: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x8035DA70: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8035DA74: lbu         $v1, 0x366($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X366);
    // 0x8035DA78: addiu       $a2, $a2, 0x2EBC
    ctx->r6 = ADD32(ctx->r6, 0X2EBC);
    // 0x8035DA7C: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x8035DA80: bne         $a0, $v1, L_8035DB9C
    if (ctx->r4 != ctx->r3) {
        // 0x8035DA84: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8035DB9C;
    }
    // 0x8035DA84: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035DA88: lhu         $t7, 0x2EE($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DA8C: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x8035DA90: lw          $t6, 0x0($a2)
    ctx->r14 = MEM_W(ctx->r6, 0X0);
    // 0x8035DA94: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8035DA98: addiu       $t0, $t0, 0x2EC0
    ctx->r8 = ADD32(ctx->r8, 0X2EC0);
    // 0x8035DA9C: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8035DAA0: addiu       $t1, $t1, 0x2EC4
    ctx->r9 = ADD32(ctx->r9, 0X2EC4);
    // 0x8035DAA4: bgez        $t7, L_8035DAB8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035DAA8: andi        $t8, $t7, 0xF
        ctx->r24 = ctx->r15 & 0XF;
            goto L_8035DAB8;
    }
    // 0x8035DAA8: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x8035DAAC: beq         $t8, $zero, L_8035DAB8
    if (ctx->r24 == 0) {
        // 0x8035DAB0: nop
    
            goto L_8035DAB8;
    }
    // 0x8035DAB0: nop

    // 0x8035DAB4: addiu       $t8, $t8, -0x10
    ctx->r24 = ADD32(ctx->r24, -0X10);
L_8035DAB8:
    // 0x8035DAB8: sll         $t3, $t8, 4
    ctx->r11 = S32(ctx->r24 << 4);
    // 0x8035DABC: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8035DAC0: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x8035DAC4: addu        $t7, $a3, $t5
    ctx->r15 = ADD32(ctx->r7, ctx->r13);
    // 0x8035DAC8: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8035DACC: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8035DAD0: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x8035DAD4: addu        $t2, $t6, $t9
    ctx->r10 = ADD32(ctx->r14, ctx->r25);
    // 0x8035DAD8: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x8035DADC: lhu         $t4, 0x2EE($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DAE0: bgez        $t4, L_8035DAF4
    if (SIGNED(ctx->r12) >= 0) {
        // 0x8035DAE4: andi        $t5, $t4, 0xF
        ctx->r13 = ctx->r12 & 0XF;
            goto L_8035DAF4;
    }
    // 0x8035DAE4: andi        $t5, $t4, 0xF
    ctx->r13 = ctx->r12 & 0XF;
    // 0x8035DAE8: beq         $t5, $zero, L_8035DAF4
    if (ctx->r13 == 0) {
        // 0x8035DAEC: nop
    
            goto L_8035DAF4;
    }
    // 0x8035DAEC: nop

    // 0x8035DAF0: addiu       $t5, $t5, -0x10
    ctx->r13 = ADD32(ctx->r13, -0X10);
L_8035DAF4:
    // 0x8035DAF4: sll         $t6, $t5, 4
    ctx->r14 = S32(ctx->r13 << 4);
    // 0x8035DAF8: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8035DAFC: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8035DB00: addu        $t4, $a3, $t2
    ctx->r12 = ADD32(ctx->r7, ctx->r10);
    // 0x8035DB04: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x8035DB08: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x8035DB0C: sra         $t7, $t5, 1
    ctx->r15 = S32(SIGNED(ctx->r13) >> 1);
    // 0x8035DB10: addu        $t8, $t3, $t7
    ctx->r24 = ADD32(ctx->r11, ctx->r15);
    // 0x8035DB14: sw          $t8, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r24;
    // 0x8035DB18: lhu         $t9, 0x2EE($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DB1C: bgez        $t9, L_8035DB30
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035DB20: andi        $t2, $t9, 0xF
        ctx->r10 = ctx->r25 & 0XF;
            goto L_8035DB30;
    }
    // 0x8035DB20: andi        $t2, $t9, 0xF
    ctx->r10 = ctx->r25 & 0XF;
    // 0x8035DB24: beq         $t2, $zero, L_8035DB30
    if (ctx->r10 == 0) {
        // 0x8035DB28: nop
    
            goto L_8035DB30;
    }
    // 0x8035DB28: nop

    // 0x8035DB2C: addiu       $t2, $t2, -0x10
    ctx->r10 = ADD32(ctx->r10, -0X10);
L_8035DB30:
    // 0x8035DB30: sll         $t3, $t2, 4
    ctx->r11 = S32(ctx->r10 << 4);
    // 0x8035DB34: andi        $t7, $t3, 0xFF
    ctx->r15 = ctx->r11 & 0XFF;
    // 0x8035DB38: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8035DB3C: addu        $t9, $a3, $t8
    ctx->r25 = ADD32(ctx->r7, ctx->r24);
    // 0x8035DB40: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x8035DB44: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8035DB48: sra         $t4, $t2, 1
    ctx->r12 = S32(SIGNED(ctx->r10) >> 1);
    // 0x8035DB4C: addu        $t5, $t6, $t4
    ctx->r13 = ADD32(ctx->r14, ctx->r12);
    // 0x8035DB50: sw          $t5, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r13;
    // 0x8035DB54: lb          $t3, 0x2D10($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X2D10);
    // 0x8035DB58: bne         $t3, $zero, L_8035DEBC
    if (ctx->r11 != 0) {
        // 0x8035DB5C: nop
    
            goto L_8035DEBC;
    }
    // 0x8035DB5C: nop

    // 0x8035DB60: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DB64: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8035DB68: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8035DB6C: bgez        $v1, L_8035DB80
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035DB70: andi        $t7, $v1, 0xF
        ctx->r15 = ctx->r3 & 0XF;
            goto L_8035DB80;
    }
    // 0x8035DB70: andi        $t7, $v1, 0xF
    ctx->r15 = ctx->r3 & 0XF;
    // 0x8035DB74: beq         $t7, $zero, L_8035DB80
    if (ctx->r15 == 0) {
        // 0x8035DB78: nop
    
            goto L_8035DB80;
    }
    // 0x8035DB78: nop

    // 0x8035DB7C: addiu       $t7, $t7, -0x10
    ctx->r15 = ADD32(ctx->r15, -0X10);
L_8035DB80:
    // 0x8035DB80: bne         $t7, $at, L_8035DB90
    if (ctx->r15 != ctx->r1) {
        // 0x8035DB84: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8035DB90;
    }
    // 0x8035DB84: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035DB88: sb          $t8, 0x2EDE($at)
    MEM_B(0X2EDE, ctx->r1) = ctx->r24;
    // 0x8035DB8C: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
L_8035DB90:
    // 0x8035DB90: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x8035DB94: jr          $ra
    // 0x8035DB98: sh          $t9, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r25;
    return;
    // 0x8035DB98: sh          $t9, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r25;
L_8035DB9C:
    // 0x8035DB9C: beq         $v1, $at, L_8035DEBC
    if (ctx->r3 == ctx->r1) {
        // 0x8035DBA0: nop
    
            goto L_8035DEBC;
    }
    // 0x8035DBA0: nop

    // 0x8035DBA4: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DBA8: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8035DBAC: addiu       $a2, $a2, 0x2EBC
    ctx->r6 = ADD32(ctx->r6, 0X2EBC);
    // 0x8035DBB0: slti        $at, $v1, 0xC1
    ctx->r1 = SIGNED(ctx->r3) < 0XC1 ? 1 : 0;
    // 0x8035DBB4: beq         $at, $zero, L_8035DCD8
    if (ctx->r1 == 0) {
        // 0x8035DBB8: lui         $a3, 0x8015
        ctx->r7 = S32(0X8015 << 16);
            goto L_8035DCD8;
    }
    // 0x8035DBB8: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x8035DBBC: lui         $a3, 0x8015
    ctx->r7 = S32(0X8015 << 16);
    // 0x8035DBC0: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x8035DBC4: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8035DBC8: addiu       $a2, $a2, 0x2EBC
    ctx->r6 = ADD32(ctx->r6, 0X2EBC);
    // 0x8035DBCC: lw          $t2, 0x0($a2)
    ctx->r10 = MEM_W(ctx->r6, 0X0);
    // 0x8035DBD0: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8035DBD4: addiu       $t0, $t0, 0x2EC0
    ctx->r8 = ADD32(ctx->r8, 0X2EC0);
    // 0x8035DBD8: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8035DBDC: addiu       $t1, $t1, 0x2EC4
    ctx->r9 = ADD32(ctx->r9, 0X2EC4);
    // 0x8035DBE0: bgez        $v1, L_8035DBF4
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035DBE4: andi        $t6, $v1, 0x1F
        ctx->r14 = ctx->r3 & 0X1F;
            goto L_8035DBF4;
    }
    // 0x8035DBE4: andi        $t6, $v1, 0x1F
    ctx->r14 = ctx->r3 & 0X1F;
    // 0x8035DBE8: beq         $t6, $zero, L_8035DBF4
    if (ctx->r14 == 0) {
        // 0x8035DBEC: nop
    
            goto L_8035DBF4;
    }
    // 0x8035DBEC: nop

    // 0x8035DBF0: addiu       $t6, $t6, -0x20
    ctx->r14 = ADD32(ctx->r14, -0X20);
L_8035DBF4:
    // 0x8035DBF4: sll         $t3, $t6, 3
    ctx->r11 = S32(ctx->r14 << 3);
    // 0x8035DBF8: andi        $t7, $t3, 0xFF
    ctx->r15 = ctx->r11 & 0XFF;
    // 0x8035DBFC: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8035DC00: addu        $t9, $a3, $t8
    ctx->r25 = ADD32(ctx->r7, ctx->r24);
    // 0x8035DC04: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x8035DC08: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8035DC0C: sra         $t4, $t6, 2
    ctx->r12 = S32(SIGNED(ctx->r14) >> 2);
    // 0x8035DC10: addu        $t5, $t2, $t4
    ctx->r13 = ADD32(ctx->r10, ctx->r12);
    // 0x8035DC14: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x8035DC18: lhu         $t7, 0x2EE($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DC1C: bgez        $t7, L_8035DC30
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035DC20: andi        $t8, $t7, 0x1F
        ctx->r24 = ctx->r15 & 0X1F;
            goto L_8035DC30;
    }
    // 0x8035DC20: andi        $t8, $t7, 0x1F
    ctx->r24 = ctx->r15 & 0X1F;
    // 0x8035DC24: beq         $t8, $zero, L_8035DC30
    if (ctx->r24 == 0) {
        // 0x8035DC28: nop
    
            goto L_8035DC30;
    }
    // 0x8035DC28: nop

    // 0x8035DC2C: addiu       $t8, $t8, -0x20
    ctx->r24 = ADD32(ctx->r24, -0X20);
L_8035DC30:
    // 0x8035DC30: sll         $t2, $t8, 3
    ctx->r10 = S32(ctx->r24 << 3);
    // 0x8035DC34: andi        $t4, $t2, 0xFF
    ctx->r12 = ctx->r10 & 0XFF;
    // 0x8035DC38: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x8035DC3C: addu        $t7, $a3, $t5
    ctx->r15 = ADD32(ctx->r7, ctx->r13);
    // 0x8035DC40: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8035DC44: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x8035DC48: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x8035DC4C: addu        $t6, $t3, $t9
    ctx->r14 = ADD32(ctx->r11, ctx->r25);
    // 0x8035DC50: sw          $t6, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r14;
    // 0x8035DC54: lhu         $t4, 0x2EE($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DC58: bgez        $t4, L_8035DC6C
    if (SIGNED(ctx->r12) >= 0) {
        // 0x8035DC5C: andi        $t5, $t4, 0x1F
        ctx->r13 = ctx->r12 & 0X1F;
            goto L_8035DC6C;
    }
    // 0x8035DC5C: andi        $t5, $t4, 0x1F
    ctx->r13 = ctx->r12 & 0X1F;
    // 0x8035DC60: beq         $t5, $zero, L_8035DC6C
    if (ctx->r13 == 0) {
        // 0x8035DC64: nop
    
            goto L_8035DC6C;
    }
    // 0x8035DC64: nop

    // 0x8035DC68: addiu       $t5, $t5, -0x20
    ctx->r13 = ADD32(ctx->r13, -0X20);
L_8035DC6C:
    // 0x8035DC6C: sll         $t3, $t5, 3
    ctx->r11 = S32(ctx->r13 << 3);
    // 0x8035DC70: andi        $t9, $t3, 0xFF
    ctx->r25 = ctx->r11 & 0XFF;
    // 0x8035DC74: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x8035DC78: addu        $t4, $a3, $t6
    ctx->r12 = ADD32(ctx->r7, ctx->r14);
    // 0x8035DC7C: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x8035DC80: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8035DC84: sra         $t7, $t5, 2
    ctx->r15 = S32(SIGNED(ctx->r13) >> 2);
    // 0x8035DC88: addu        $t8, $t2, $t7
    ctx->r24 = ADD32(ctx->r10, ctx->r15);
    // 0x8035DC8C: sw          $t8, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r24;
    // 0x8035DC90: lb          $t3, 0x2D10($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X2D10);
    // 0x8035DC94: bne         $t3, $zero, L_8035DDE4
    if (ctx->r11 != 0) {
        // 0x8035DC98: nop
    
            goto L_8035DDE4;
    }
    // 0x8035DC98: nop

    // 0x8035DC9C: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DCA0: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x8035DCA4: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8035DCA8: bgez        $v1, L_8035DCBC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035DCAC: andi        $t9, $v1, 0x1F
        ctx->r25 = ctx->r3 & 0X1F;
            goto L_8035DCBC;
    }
    // 0x8035DCAC: andi        $t9, $v1, 0x1F
    ctx->r25 = ctx->r3 & 0X1F;
    // 0x8035DCB0: beq         $t9, $zero, L_8035DCBC
    if (ctx->r25 == 0) {
        // 0x8035DCB4: nop
    
            goto L_8035DCBC;
    }
    // 0x8035DCB4: nop

    // 0x8035DCB8: addiu       $t9, $t9, -0x20
    ctx->r25 = ADD32(ctx->r25, -0X20);
L_8035DCBC:
    // 0x8035DCBC: bne         $t9, $at, L_8035DCCC
    if (ctx->r25 != ctx->r1) {
        // 0x8035DCC0: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8035DCCC;
    }
    // 0x8035DCC0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035DCC4: sb          $t6, 0x2EDE($at)
    MEM_B(0X2EDE, ctx->r1) = ctx->r14;
    // 0x8035DCC8: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
L_8035DCCC:
    // 0x8035DCCC: addiu       $t4, $v1, 0x1
    ctx->r12 = ADD32(ctx->r3, 0X1);
    // 0x8035DCD0: b           L_8035DDE4
    // 0x8035DCD4: sh          $t4, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r12;
        goto L_8035DDE4;
    // 0x8035DCD4: sh          $t4, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r12;
L_8035DCD8:
    // 0x8035DCD8: addiu       $a3, $a3, 0x2C78
    ctx->r7 = ADD32(ctx->r7, 0X2C78);
    // 0x8035DCDC: lw          $t5, 0x0($a2)
    ctx->r13 = MEM_W(ctx->r6, 0X0);
    // 0x8035DCE0: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8035DCE4: addiu       $t0, $t0, 0x2EC0
    ctx->r8 = ADD32(ctx->r8, 0X2EC0);
    // 0x8035DCE8: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8035DCEC: addiu       $t1, $t1, 0x2EC4
    ctx->r9 = ADD32(ctx->r9, 0X2EC4);
    // 0x8035DCF0: bgez        $v1, L_8035DD04
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035DCF4: andi        $t2, $v1, 0x3F
        ctx->r10 = ctx->r3 & 0X3F;
            goto L_8035DD04;
    }
    // 0x8035DCF4: andi        $t2, $v1, 0x3F
    ctx->r10 = ctx->r3 & 0X3F;
    // 0x8035DCF8: beq         $t2, $zero, L_8035DD04
    if (ctx->r10 == 0) {
        // 0x8035DCFC: nop
    
            goto L_8035DD04;
    }
    // 0x8035DCFC: nop

    // 0x8035DD00: addiu       $t2, $t2, -0x40
    ctx->r10 = ADD32(ctx->r10, -0X40);
L_8035DD04:
    // 0x8035DD04: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x8035DD08: andi        $t9, $t3, 0xFF
    ctx->r25 = ctx->r11 & 0XFF;
    // 0x8035DD0C: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x8035DD10: addu        $t4, $a3, $t6
    ctx->r12 = ADD32(ctx->r7, ctx->r14);
    // 0x8035DD14: lh          $t2, 0x0($t4)
    ctx->r10 = MEM_H(ctx->r12, 0X0);
    // 0x8035DD18: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8035DD1C: sra         $t7, $t2, 3
    ctx->r15 = S32(SIGNED(ctx->r10) >> 3);
    // 0x8035DD20: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x8035DD24: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x8035DD28: lhu         $t9, 0x2EE($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DD2C: bgez        $t9, L_8035DD40
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035DD30: andi        $t6, $t9, 0x3F
        ctx->r14 = ctx->r25 & 0X3F;
            goto L_8035DD40;
    }
    // 0x8035DD30: andi        $t6, $t9, 0x3F
    ctx->r14 = ctx->r25 & 0X3F;
    // 0x8035DD34: beq         $t6, $zero, L_8035DD40
    if (ctx->r14 == 0) {
        // 0x8035DD38: nop
    
            goto L_8035DD40;
    }
    // 0x8035DD38: nop

    // 0x8035DD3C: addiu       $t6, $t6, -0x40
    ctx->r14 = ADD32(ctx->r14, -0X40);
L_8035DD40:
    // 0x8035DD40: sll         $t5, $t6, 2
    ctx->r13 = S32(ctx->r14 << 2);
    // 0x8035DD44: andi        $t7, $t5, 0xFF
    ctx->r15 = ctx->r13 & 0XFF;
    // 0x8035DD48: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8035DD4C: addu        $t9, $a3, $t8
    ctx->r25 = ADD32(ctx->r7, ctx->r24);
    // 0x8035DD50: lh          $t6, 0x0($t9)
    ctx->r14 = MEM_H(ctx->r25, 0X0);
    // 0x8035DD54: lw          $t5, 0x0($t1)
    ctx->r13 = MEM_W(ctx->r9, 0X0);
    // 0x8035DD58: sra         $t4, $t6, 3
    ctx->r12 = S32(SIGNED(ctx->r14) >> 3);
    // 0x8035DD5C: addu        $t2, $t3, $t4
    ctx->r10 = ADD32(ctx->r11, ctx->r12);
    // 0x8035DD60: sw          $t2, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r10;
    // 0x8035DD64: lhu         $t7, 0x2EE($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DD68: bgez        $t7, L_8035DD7C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035DD6C: andi        $t8, $t7, 0x3F
        ctx->r24 = ctx->r15 & 0X3F;
            goto L_8035DD7C;
    }
    // 0x8035DD6C: andi        $t8, $t7, 0x3F
    ctx->r24 = ctx->r15 & 0X3F;
    // 0x8035DD70: beq         $t8, $zero, L_8035DD7C
    if (ctx->r24 == 0) {
        // 0x8035DD74: nop
    
            goto L_8035DD7C;
    }
    // 0x8035DD74: nop

    // 0x8035DD78: addiu       $t8, $t8, -0x40
    ctx->r24 = ADD32(ctx->r24, -0X40);
L_8035DD7C:
    // 0x8035DD7C: sll         $t3, $t8, 2
    ctx->r11 = S32(ctx->r24 << 2);
    // 0x8035DD80: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8035DD84: sll         $t2, $t4, 1
    ctx->r10 = S32(ctx->r12 << 1);
    // 0x8035DD88: addu        $t7, $a3, $t2
    ctx->r15 = ADD32(ctx->r7, ctx->r10);
    // 0x8035DD8C: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8035DD90: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x8035DD94: sra         $t9, $t8, 3
    ctx->r25 = S32(SIGNED(ctx->r24) >> 3);
    // 0x8035DD98: addu        $t6, $t5, $t9
    ctx->r14 = ADD32(ctx->r13, ctx->r25);
    // 0x8035DD9C: sw          $t6, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r14;
    // 0x8035DDA0: lb          $t3, 0x2D10($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X2D10);
    // 0x8035DDA4: bne         $t3, $zero, L_8035DDE4
    if (ctx->r11 != 0) {
        // 0x8035DDA8: nop
    
            goto L_8035DDE4;
    }
    // 0x8035DDA8: nop

    // 0x8035DDAC: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DDB0: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035DDB4: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8035DDB8: bgez        $v1, L_8035DDCC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035DDBC: andi        $t4, $v1, 0x3F
        ctx->r12 = ctx->r3 & 0X3F;
            goto L_8035DDCC;
    }
    // 0x8035DDBC: andi        $t4, $v1, 0x3F
    ctx->r12 = ctx->r3 & 0X3F;
    // 0x8035DDC0: beq         $t4, $zero, L_8035DDCC
    if (ctx->r12 == 0) {
        // 0x8035DDC4: nop
    
            goto L_8035DDCC;
    }
    // 0x8035DDC4: nop

    // 0x8035DDC8: addiu       $t4, $t4, -0x40
    ctx->r12 = ADD32(ctx->r12, -0X40);
L_8035DDCC:
    // 0x8035DDCC: bne         $t4, $at, L_8035DDDC
    if (ctx->r12 != ctx->r1) {
        // 0x8035DDD0: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8035DDDC;
    }
    // 0x8035DDD0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035DDD4: sb          $t2, 0x2EDE($at)
    MEM_B(0X2EDE, ctx->r1) = ctx->r10;
    // 0x8035DDD8: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
L_8035DDDC:
    // 0x8035DDDC: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x8035DDE0: sh          $t7, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r15;
L_8035DDE4:
    // 0x8035DDE4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035DDE8: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x8035DDEC: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x8035DDF0: lhu         $v1, 0x0($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X0);
    // 0x8035DDF4: bne         $v1, $at, L_8035DE28
    if (ctx->r3 != ctx->r1) {
        // 0x8035DDF8: nop
    
            goto L_8035DE28;
    }
    // 0x8035DDF8: nop

    // 0x8035DDFC: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8035DE00: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035DE04: lhu         $t5, 0x2EE($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DE08: bgez        $t5, L_8035DE1C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8035DE0C: andi        $t9, $t5, 0x3F
        ctx->r25 = ctx->r13 & 0X3F;
            goto L_8035DE1C;
    }
    // 0x8035DE0C: andi        $t9, $t5, 0x3F
    ctx->r25 = ctx->r13 & 0X3F;
    // 0x8035DE10: beq         $t9, $zero, L_8035DE1C
    if (ctx->r25 == 0) {
        // 0x8035DE14: nop
    
            goto L_8035DE1C;
    }
    // 0x8035DE14: nop

    // 0x8035DE18: addiu       $t9, $t9, -0x40
    ctx->r25 = ADD32(ctx->r25, -0X40);
L_8035DE1C:
    // 0x8035DE1C: sh          $t9, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r25;
    // 0x8035DE20: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8035DE24: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
L_8035DE28:
    // 0x8035DE28: bne         $a0, $v1, L_8035DE5C
    if (ctx->r4 != ctx->r3) {
        // 0x8035DE2C: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_8035DE5C;
    }
    // 0x8035DE2C: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    // 0x8035DE30: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8035DE34: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8035DE38: lhu         $t3, 0x2EE($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DE3C: bgez        $t3, L_8035DE50
    if (SIGNED(ctx->r11) >= 0) {
        // 0x8035DE40: andi        $t4, $t3, 0x3F
        ctx->r12 = ctx->r11 & 0X3F;
            goto L_8035DE50;
    }
    // 0x8035DE40: andi        $t4, $t3, 0x3F
    ctx->r12 = ctx->r11 & 0X3F;
    // 0x8035DE44: beq         $t4, $zero, L_8035DE50
    if (ctx->r12 == 0) {
        // 0x8035DE48: nop
    
            goto L_8035DE50;
    }
    // 0x8035DE48: nop

    // 0x8035DE4C: addiu       $t4, $t4, -0x40
    ctx->r12 = ADD32(ctx->r12, -0X40);
L_8035DE50:
    // 0x8035DE50: sh          $t4, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r12;
    // 0x8035DE54: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x8035DE58: lhu         $v1, 0x0($t2)
    ctx->r3 = MEM_HU(ctx->r10, 0X0);
L_8035DE5C:
    // 0x8035DE5C: bnel        $v1, $at, L_8035DE94
    if (ctx->r3 != ctx->r1) {
        // 0x8035DE60: addiu       $at, $zero, 0x69
        ctx->r1 = ADD32(0, 0X69);
            goto L_8035DE94;
    }
    goto skip_0;
    // 0x8035DE60: addiu       $at, $zero, 0x69
    ctx->r1 = ADD32(0, 0X69);
    skip_0:
    // 0x8035DE64: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8035DE68: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8035DE6C: lhu         $t7, 0x2EE($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DE70: bgez        $t7, L_8035DE84
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035DE74: andi        $t8, $t7, 0x3F
        ctx->r24 = ctx->r15 & 0X3F;
            goto L_8035DE84;
    }
    // 0x8035DE74: andi        $t8, $t7, 0x3F
    ctx->r24 = ctx->r15 & 0X3F;
    // 0x8035DE78: beq         $t8, $zero, L_8035DE84
    if (ctx->r24 == 0) {
        // 0x8035DE7C: nop
    
            goto L_8035DE84;
    }
    // 0x8035DE7C: nop

    // 0x8035DE80: addiu       $t8, $t8, -0x40
    ctx->r24 = ADD32(ctx->r24, -0X40);
L_8035DE84:
    // 0x8035DE84: sh          $t8, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r24;
    // 0x8035DE88: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x8035DE8C: lhu         $v1, 0x0($t5)
    ctx->r3 = MEM_HU(ctx->r13, 0X0);
    // 0x8035DE90: addiu       $at, $zero, 0x69
    ctx->r1 = ADD32(0, 0X69);
L_8035DE94:
    // 0x8035DE94: bne         $v1, $at, L_8035DEBC
    if (ctx->r3 != ctx->r1) {
        // 0x8035DE98: nop
    
            goto L_8035DEBC;
    }
    // 0x8035DE98: nop

    // 0x8035DE9C: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x8035DEA0: lhu         $t9, 0x2EE($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DEA4: bgez        $t9, L_8035DEB8
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035DEA8: andi        $t6, $t9, 0x3F
        ctx->r14 = ctx->r25 & 0X3F;
            goto L_8035DEB8;
    }
    // 0x8035DEA8: andi        $t6, $t9, 0x3F
    ctx->r14 = ctx->r25 & 0X3F;
    // 0x8035DEAC: beq         $t6, $zero, L_8035DEB8
    if (ctx->r14 == 0) {
        // 0x8035DEB0: nop
    
            goto L_8035DEB8;
    }
    // 0x8035DEB0: nop

    // 0x8035DEB4: addiu       $t6, $t6, -0x40
    ctx->r14 = ADD32(ctx->r14, -0X40);
L_8035DEB8:
    // 0x8035DEB8: sh          $t6, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r14;
L_8035DEBC:
    // 0x8035DEBC: jr          $ra
    // 0x8035DEC0: nop

    return;
    // 0x8035DEC0: nop

;}
RECOMP_FUNC void func_8035DEC4_76F574(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035DEC4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035DEC8: addiu       $a0, $a0, 0x552C
    ctx->r4 = ADD32(ctx->r4, 0X552C);
    // 0x8035DECC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8035DED0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035DED4: lbu         $t6, 0x366($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X366);
    // 0x8035DED8: beq         $t6, $at, L_8035E114
    if (ctx->r14 == ctx->r1) {
        // 0x8035DEDC: nop
    
            goto L_8035E114;
    }
    // 0x8035DEDC: nop

    // 0x8035DEE0: lhu         $v1, 0x2EE($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DEE4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035DEE8: addiu       $a1, $a1, 0x2EBC
    ctx->r5 = ADD32(ctx->r5, 0X2EBC);
    // 0x8035DEEC: slti        $at, $v1, 0x181
    ctx->r1 = SIGNED(ctx->r3) < 0X181 ? 1 : 0;
    // 0x8035DEF0: beq         $at, $zero, L_8035DF90
    if (ctx->r1 == 0) {
        // 0x8035DEF4: lui         $a2, 0x8015
        ctx->r6 = S32(0X8015 << 16);
            goto L_8035DF90;
    }
    // 0x8035DEF4: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x8035DEF8: sll         $t2, $v1, 4
    ctx->r10 = S32(ctx->r3 << 4);
    // 0x8035DEFC: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x8035DF00: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x8035DF04: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x8035DF08: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x8035DF0C: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035DF10: addu        $t5, $a2, $t4
    ctx->r13 = ADD32(ctx->r6, ctx->r12);
    // 0x8035DF14: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x8035DF18: addiu       $a1, $a1, 0x2EBC
    ctx->r5 = ADD32(ctx->r5, 0X2EBC);
    // 0x8035DF1C: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x8035DF20: sra         $t8, $t6, 2
    ctx->r24 = S32(SIGNED(ctx->r14) >> 2);
    // 0x8035DF24: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8035DF28: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8035DF2C: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x8035DF30: lhu         $t3, 0x2EE($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DF34: addiu       $a3, $a3, 0x2EC0
    ctx->r7 = ADD32(ctx->r7, 0X2EC0);
    // 0x8035DF38: lw          $t1, 0x0($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X0);
    // 0x8035DF3C: sll         $t6, $t3, 4
    ctx->r14 = S32(ctx->r11 << 4);
    // 0x8035DF40: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x8035DF44: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8035DF48: addu        $t9, $a2, $t8
    ctx->r25 = ADD32(ctx->r6, ctx->r24);
    // 0x8035DF4C: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x8035DF50: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8035DF54: addiu       $t0, $t0, 0x2EC4
    ctx->r8 = ADD32(ctx->r8, 0X2EC4);
    // 0x8035DF58: sra         $t3, $t2, 2
    ctx->r11 = S32(SIGNED(ctx->r10) >> 2);
    // 0x8035DF5C: addu        $t4, $t1, $t3
    ctx->r12 = ADD32(ctx->r9, ctx->r11);
    // 0x8035DF60: sw          $t4, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r12;
    // 0x8035DF64: lhu         $t7, 0x2EE($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DF68: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8035DF6C: sll         $t2, $t7, 4
    ctx->r10 = S32(ctx->r15 << 4);
    // 0x8035DF70: andi        $t1, $t2, 0xFF
    ctx->r9 = ctx->r10 & 0XFF;
    // 0x8035DF74: sll         $t3, $t1, 1
    ctx->r11 = S32(ctx->r9 << 1);
    // 0x8035DF78: addu        $t4, $a2, $t3
    ctx->r12 = ADD32(ctx->r6, ctx->r11);
    // 0x8035DF7C: lh          $t6, 0x0($t4)
    ctx->r14 = MEM_H(ctx->r12, 0X0);
    // 0x8035DF80: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x8035DF84: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x8035DF88: b           L_8035E018
    // 0x8035DF8C: sw          $t8, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r24;
        goto L_8035E018;
    // 0x8035DF8C: sw          $t8, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r24;
L_8035DF90:
    // 0x8035DF90: sll         $t4, $v1, 3
    ctx->r12 = S32(ctx->r3 << 3);
    // 0x8035DF94: andi        $t6, $t4, 0xFF
    ctx->r14 = ctx->r12 & 0XFF;
    // 0x8035DF98: addiu       $a2, $a2, 0x2C78
    ctx->r6 = ADD32(ctx->r6, 0X2C78);
    // 0x8035DF9C: sll         $t5, $t6, 1
    ctx->r13 = S32(ctx->r14 << 1);
    // 0x8035DFA0: addu        $t7, $a2, $t5
    ctx->r15 = ADD32(ctx->r6, ctx->r13);
    // 0x8035DFA4: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8035DFA8: lw          $t9, 0x0($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X0);
    // 0x8035DFAC: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8035DFB0: sra         $t2, $t8, 2
    ctx->r10 = S32(SIGNED(ctx->r24) >> 2);
    // 0x8035DFB4: addu        $t1, $t9, $t2
    ctx->r9 = ADD32(ctx->r25, ctx->r10);
    // 0x8035DFB8: sw          $t1, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r9;
    // 0x8035DFBC: lhu         $t6, 0x2EE($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DFC0: addiu       $a3, $a3, 0x2EC0
    ctx->r7 = ADD32(ctx->r7, 0X2EC0);
    // 0x8035DFC4: lw          $t3, 0x0($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X0);
    // 0x8035DFC8: sll         $t8, $t6, 3
    ctx->r24 = S32(ctx->r14 << 3);
    // 0x8035DFCC: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x8035DFD0: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8035DFD4: addu        $t1, $a2, $t2
    ctx->r9 = ADD32(ctx->r6, ctx->r10);
    // 0x8035DFD8: lh          $t4, 0x0($t1)
    ctx->r12 = MEM_H(ctx->r9, 0X0);
    // 0x8035DFDC: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x8035DFE0: addiu       $t0, $t0, 0x2EC4
    ctx->r8 = ADD32(ctx->r8, 0X2EC4);
    // 0x8035DFE4: sra         $t6, $t4, 2
    ctx->r14 = S32(SIGNED(ctx->r12) >> 2);
    // 0x8035DFE8: addu        $t5, $t3, $t6
    ctx->r13 = ADD32(ctx->r11, ctx->r14);
    // 0x8035DFEC: sw          $t5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r13;
    // 0x8035DFF0: lhu         $t9, 0x2EE($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035DFF4: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8035DFF8: sll         $t4, $t9, 3
    ctx->r12 = S32(ctx->r25 << 3);
    // 0x8035DFFC: andi        $t3, $t4, 0xFF
    ctx->r11 = ctx->r12 & 0XFF;
    // 0x8035E000: sll         $t6, $t3, 1
    ctx->r14 = S32(ctx->r11 << 1);
    // 0x8035E004: addu        $t5, $a2, $t6
    ctx->r13 = ADD32(ctx->r6, ctx->r14);
    // 0x8035E008: lh          $t8, 0x0($t5)
    ctx->r24 = MEM_H(ctx->r13, 0X0);
    // 0x8035E00C: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x8035E010: addu        $t2, $t7, $t9
    ctx->r10 = ADD32(ctx->r15, ctx->r25);
    // 0x8035E014: sw          $t2, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r10;
L_8035E018:
    // 0x8035E018: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8035E01C: lb          $t1, 0x2D10($t1)
    ctx->r9 = MEM_B(ctx->r9, 0X2D10);
    // 0x8035E020: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035E024: bne         $t1, $zero, L_8035E038
    if (ctx->r9 != 0) {
        // 0x8035E028: nop
    
            goto L_8035E038;
    }
    // 0x8035E028: nop

    // 0x8035E02C: lhu         $t4, 0x2EE($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035E030: addiu       $t3, $t4, 0x1
    ctx->r11 = ADD32(ctx->r12, 0X1);
    // 0x8035E034: sh          $t3, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r11;
L_8035E038:
    // 0x8035E038: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8035E03C: addiu       $at, $zero, 0x17
    ctx->r1 = ADD32(0, 0X17);
    // 0x8035E040: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
    // 0x8035E044: bnel        $v1, $at, L_8035E07C
    if (ctx->r3 != ctx->r1) {
        // 0x8035E048: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8035E07C;
    }
    goto skip_0;
    // 0x8035E048: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_0:
    // 0x8035E04C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8035E050: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035E054: lhu         $t5, 0x2EE($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035E058: bgez        $t5, L_8035E06C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8035E05C: andi        $t8, $t5, 0x3F
        ctx->r24 = ctx->r13 & 0X3F;
            goto L_8035E06C;
    }
    // 0x8035E05C: andi        $t8, $t5, 0x3F
    ctx->r24 = ctx->r13 & 0X3F;
    // 0x8035E060: beq         $t8, $zero, L_8035E06C
    if (ctx->r24 == 0) {
        // 0x8035E064: nop
    
            goto L_8035E06C;
    }
    // 0x8035E064: nop

    // 0x8035E068: addiu       $t8, $t8, -0x40
    ctx->r24 = ADD32(ctx->r24, -0X40);
L_8035E06C:
    // 0x8035E06C: sh          $t8, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r24;
    // 0x8035E070: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x8035E074: lhu         $v1, 0x0($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X0);
    // 0x8035E078: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_8035E07C:
    // 0x8035E07C: bnel        $v1, $at, L_8035E0B4
    if (ctx->r3 != ctx->r1) {
        // 0x8035E080: addiu       $at, $zero, 0x2A
        ctx->r1 = ADD32(0, 0X2A);
            goto L_8035E0B4;
    }
    goto skip_1;
    // 0x8035E080: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
    skip_1:
    // 0x8035E084: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8035E088: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8035E08C: lhu         $t9, 0x2EE($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035E090: bgez        $t9, L_8035E0A4
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035E094: andi        $t2, $t9, 0x3F
        ctx->r10 = ctx->r25 & 0X3F;
            goto L_8035E0A4;
    }
    // 0x8035E094: andi        $t2, $t9, 0x3F
    ctx->r10 = ctx->r25 & 0X3F;
    // 0x8035E098: beq         $t2, $zero, L_8035E0A4
    if (ctx->r10 == 0) {
        // 0x8035E09C: nop
    
            goto L_8035E0A4;
    }
    // 0x8035E09C: nop

    // 0x8035E0A0: addiu       $t2, $t2, -0x40
    ctx->r10 = ADD32(ctx->r10, -0X40);
L_8035E0A4:
    // 0x8035E0A4: sh          $t2, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r10;
    // 0x8035E0A8: lw          $t1, 0x5530($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X5530);
    // 0x8035E0AC: lhu         $v1, 0x0($t1)
    ctx->r3 = MEM_HU(ctx->r9, 0X0);
    // 0x8035E0B0: addiu       $at, $zero, 0x2A
    ctx->r1 = ADD32(0, 0X2A);
L_8035E0B4:
    // 0x8035E0B4: bnel        $v1, $at, L_8035E0EC
    if (ctx->r3 != ctx->r1) {
        // 0x8035E0B8: addiu       $at, $zero, 0x69
        ctx->r1 = ADD32(0, 0X69);
            goto L_8035E0EC;
    }
    goto skip_2;
    // 0x8035E0B8: addiu       $at, $zero, 0x69
    ctx->r1 = ADD32(0, 0X69);
    skip_2:
    // 0x8035E0BC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8035E0C0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035E0C4: lhu         $t4, 0x2EE($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035E0C8: bgez        $t4, L_8035E0DC
    if (SIGNED(ctx->r12) >= 0) {
        // 0x8035E0CC: andi        $t3, $t4, 0x3F
        ctx->r11 = ctx->r12 & 0X3F;
            goto L_8035E0DC;
    }
    // 0x8035E0CC: andi        $t3, $t4, 0x3F
    ctx->r11 = ctx->r12 & 0X3F;
    // 0x8035E0D0: beq         $t3, $zero, L_8035E0DC
    if (ctx->r11 == 0) {
        // 0x8035E0D4: nop
    
            goto L_8035E0DC;
    }
    // 0x8035E0D4: nop

    // 0x8035E0D8: addiu       $t3, $t3, -0x40
    ctx->r11 = ADD32(ctx->r11, -0X40);
L_8035E0DC:
    // 0x8035E0DC: sh          $t3, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r11;
    // 0x8035E0E0: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8035E0E4: lhu         $v1, 0x0($t6)
    ctx->r3 = MEM_HU(ctx->r14, 0X0);
    // 0x8035E0E8: addiu       $at, $zero, 0x69
    ctx->r1 = ADD32(0, 0X69);
L_8035E0EC:
    // 0x8035E0EC: bne         $v1, $at, L_8035E114
    if (ctx->r3 != ctx->r1) {
        // 0x8035E0F0: nop
    
            goto L_8035E114;
    }
    // 0x8035E0F0: nop

    // 0x8035E0F4: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x8035E0F8: lhu         $t5, 0x2EE($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2EE);
    // 0x8035E0FC: bgez        $t5, L_8035E110
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8035E100: andi        $t8, $t5, 0x3F
        ctx->r24 = ctx->r13 & 0X3F;
            goto L_8035E110;
    }
    // 0x8035E100: andi        $t8, $t5, 0x3F
    ctx->r24 = ctx->r13 & 0X3F;
    // 0x8035E104: beq         $t8, $zero, L_8035E110
    if (ctx->r24 == 0) {
        // 0x8035E108: nop
    
            goto L_8035E110;
    }
    // 0x8035E108: nop

    // 0x8035E10C: addiu       $t8, $t8, -0x40
    ctx->r24 = ADD32(ctx->r24, -0X40);
L_8035E110:
    // 0x8035E110: sh          $t8, 0x2EE($v0)
    MEM_H(0X2EE, ctx->r2) = ctx->r24;
L_8035E114:
    // 0x8035E114: jr          $ra
    // 0x8035E118: nop

    return;
    // 0x8035E118: nop

;}
RECOMP_FUNC void func_8035E120_76F7D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035E120: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8035E124: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x8035E128: addiu       $a2, $a2, 0x552C
    ctx->r6 = ADD32(ctx->r6, 0X552C);
    // 0x8035E12C: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x8035E130: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x8035E134: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8035E138: addiu       $t9, $zero, 0x400
    ctx->r25 = ADD32(0, 0X400);
    // 0x8035E13C: lh          $t7, 0xDC($t6)
    ctx->r15 = MEM_H(ctx->r14, 0XDC);
    // 0x8035E140: lh          $t8, 0x2E0($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X2E0);
    // 0x8035E144: addiu       $t3, $zero, 0x400
    ctx->r11 = ADD32(0, 0X400);
    // 0x8035E148: addu        $v1, $t7, $t8
    ctx->r3 = ADD32(ctx->r15, ctx->r24);
    // 0x8035E14C: slti        $at, $v1, 0x401
    ctx->r1 = SIGNED(ctx->r3) < 0X401 ? 1 : 0;
    // 0x8035E150: bnel        $at, $zero, L_8035E164
    if (ctx->r1 != 0) {
        // 0x8035E154: sh          $v1, 0x2E0($v0)
        MEM_H(0X2E0, ctx->r2) = ctx->r3;
            goto L_8035E164;
    }
    goto skip_0;
    // 0x8035E154: sh          $v1, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r3;
    skip_0:
    // 0x8035E158: b           L_8035E164
    // 0x8035E15C: sh          $t9, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r25;
        goto L_8035E164;
    // 0x8035E15C: sh          $t9, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r25;
    // 0x8035E160: sh          $v1, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r3;
L_8035E164:
    // 0x8035E164: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8035E168: addiu       $a3, $zero, 0x7FFF
    ctx->r7 = ADD32(0, 0X7FFF);
    // 0x8035E16C: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x8035E170: lh          $v1, 0x2E2($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E2);
    // 0x8035E174: beql        $a3, $v1, L_8035E1A4
    if (ctx->r7 == ctx->r3) {
        // 0x8035E178: lw          $t0, 0x0($a1)
        ctx->r8 = MEM_W(ctx->r5, 0X0);
            goto L_8035E1A4;
    }
    goto skip_1;
    // 0x8035E178: lw          $t0, 0x0($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X0);
    skip_1:
    // 0x8035E17C: beq         $v1, $at, L_8035E1A0
    if (ctx->r3 == ctx->r1) {
        // 0x8035E180: addiu       $a0, $v1, -0x1
        ctx->r4 = ADD32(ctx->r3, -0X1);
            goto L_8035E1A0;
    }
    // 0x8035E180: addiu       $a0, $v1, -0x1
    ctx->r4 = ADD32(ctx->r3, -0X1);
    // 0x8035E184: bgezl       $a0, L_8035E19C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x8035E188: sh          $a0, 0x2E2($v0)
        MEM_H(0X2E2, ctx->r2) = ctx->r4;
            goto L_8035E19C;
    }
    goto skip_2;
    // 0x8035E188: sh          $a0, 0x2E2($v0)
    MEM_H(0X2E2, ctx->r2) = ctx->r4;
    skip_2:
    // 0x8035E18C: sh          $zero, 0x2E2($v0)
    MEM_H(0X2E2, ctx->r2) = 0;
    // 0x8035E190: b           L_8035E1A0
    // 0x8035E194: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
        goto L_8035E1A0;
    // 0x8035E194: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8035E198: sh          $a0, 0x2E2($v0)
    MEM_H(0X2E2, ctx->r2) = ctx->r4;
L_8035E19C:
    // 0x8035E19C: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
L_8035E1A0:
    // 0x8035E1A0: lw          $t0, 0x0($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X0);
L_8035E1A4:
    // 0x8035E1A4: lh          $t2, 0x2E4($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2E4);
    // 0x8035E1A8: lh          $t1, 0xE2($t0)
    ctx->r9 = MEM_H(ctx->r8, 0XE2);
    // 0x8035E1AC: addu        $v1, $t1, $t2
    ctx->r3 = ADD32(ctx->r9, ctx->r10);
    // 0x8035E1B0: slti        $at, $v1, 0x401
    ctx->r1 = SIGNED(ctx->r3) < 0X401 ? 1 : 0;
    // 0x8035E1B4: bnel        $at, $zero, L_8035E1C8
    if (ctx->r1 != 0) {
        // 0x8035E1B8: sh          $v1, 0x2E4($v0)
        MEM_H(0X2E4, ctx->r2) = ctx->r3;
            goto L_8035E1C8;
    }
    goto skip_3;
    // 0x8035E1B8: sh          $v1, 0x2E4($v0)
    MEM_H(0X2E4, ctx->r2) = ctx->r3;
    skip_3:
    // 0x8035E1BC: b           L_8035E1C8
    // 0x8035E1C0: sh          $t3, 0x2E4($v0)
    MEM_H(0X2E4, ctx->r2) = ctx->r11;
        goto L_8035E1C8;
    // 0x8035E1C0: sh          $t3, 0x2E4($v0)
    MEM_H(0X2E4, ctx->r2) = ctx->r11;
    // 0x8035E1C4: sh          $v1, 0x2E4($v0)
    MEM_H(0X2E4, ctx->r2) = ctx->r3;
L_8035E1C8:
    // 0x8035E1C8: lw          $v0, 0x0($a2)
    ctx->r2 = MEM_W(ctx->r6, 0X0);
    // 0x8035E1CC: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x8035E1D0: lh          $v1, 0x2E6($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E6);
    // 0x8035E1D4: beq         $a3, $v1, L_8035E1F8
    if (ctx->r7 == ctx->r3) {
        // 0x8035E1D8: nop
    
            goto L_8035E1F8;
    }
    // 0x8035E1D8: nop

    // 0x8035E1DC: beq         $v1, $at, L_8035E1F8
    if (ctx->r3 == ctx->r1) {
        // 0x8035E1E0: addiu       $a0, $v1, -0x1
        ctx->r4 = ADD32(ctx->r3, -0X1);
            goto L_8035E1F8;
    }
    // 0x8035E1E0: addiu       $a0, $v1, -0x1
    ctx->r4 = ADD32(ctx->r3, -0X1);
    // 0x8035E1E4: bgezl       $a0, L_8035E1F8
    if (SIGNED(ctx->r4) >= 0) {
        // 0x8035E1E8: sh          $a0, 0x2E6($v0)
        MEM_H(0X2E6, ctx->r2) = ctx->r4;
            goto L_8035E1F8;
    }
    goto skip_4;
    // 0x8035E1E8: sh          $a0, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = ctx->r4;
    skip_4:
    // 0x8035E1EC: jr          $ra
    // 0x8035E1F0: sh          $zero, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = 0;
    return;
    // 0x8035E1F0: sh          $zero, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = 0;
    // 0x8035E1F4: sh          $a0, 0x2E6($v0)
    MEM_H(0X2E6, ctx->r2) = ctx->r4;
L_8035E1F8:
    // 0x8035E1F8: jr          $ra
    // 0x8035E1FC: nop

    return;
    // 0x8035E1FC: nop

;}
RECOMP_FUNC void func_8035E200_76F8B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035E200: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8035E204: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x8035E208: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8035E20C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8035E210: addiu       $t0, $t0, 0x5524
    ctx->r8 = ADD32(ctx->r8, 0X5524);
    // 0x8035E214: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8035E218: lh          $a0, 0x2E0($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E0);
    // 0x8035E21C: addiu       $t1, $zero, 0x400
    ctx->r9 = ADD32(0, 0X400);
    // 0x8035E220: lh          $t8, 0xDC($t7)
    ctx->r24 = MEM_H(ctx->r15, 0XDC);
    // 0x8035E224: sll         $v0, $a0, 16
    ctx->r2 = S32(ctx->r4 << 16);
    // 0x8035E228: sra         $t6, $v0, 16
    ctx->r14 = S32(SIGNED(ctx->r2) >> 16);
    // 0x8035E22C: addu        $a1, $t8, $a0
    ctx->r5 = ADD32(ctx->r24, ctx->r4);
    // 0x8035E230: slti        $at, $a1, 0x401
    ctx->r1 = SIGNED(ctx->r5) < 0X401 ? 1 : 0;
    // 0x8035E234: bne         $at, $zero, L_8035E248
    if (ctx->r1 != 0) {
        // 0x8035E238: or          $v0, $t6, $zero
        ctx->r2 = ctx->r14 | 0;
            goto L_8035E248;
    }
    // 0x8035E238: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x8035E23C: addiu       $t1, $zero, 0x400
    ctx->r9 = ADD32(0, 0X400);
    // 0x8035E240: b           L_8035E24C
    // 0x8035E244: sh          $t1, 0x2E0($v1)
    MEM_H(0X2E0, ctx->r3) = ctx->r9;
        goto L_8035E24C;
    // 0x8035E244: sh          $t1, 0x2E0($v1)
    MEM_H(0X2E0, ctx->r3) = ctx->r9;
L_8035E248:
    // 0x8035E248: sh          $a1, 0x2E0($v1)
    MEM_H(0X2E0, ctx->r3) = ctx->r5;
L_8035E24C:
    // 0x8035E24C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8035E250: addiu       $t2, $zero, 0x7FFF
    ctx->r10 = ADD32(0, 0X7FFF);
    // 0x8035E254: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x8035E258: lh          $a0, 0x2E2($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E2);
    // 0x8035E25C: beql        $t2, $a0, L_8035E28C
    if (ctx->r10 == ctx->r4) {
        // 0x8035E260: lw          $t3, 0x0($t0)
        ctx->r11 = MEM_W(ctx->r8, 0X0);
            goto L_8035E28C;
    }
    goto skip_0;
    // 0x8035E260: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    skip_0:
    // 0x8035E264: beq         $a0, $at, L_8035E288
    if (ctx->r4 == ctx->r1) {
        // 0x8035E268: addiu       $a1, $a0, -0x1
        ctx->r5 = ADD32(ctx->r4, -0X1);
            goto L_8035E288;
    }
    // 0x8035E268: addiu       $a1, $a0, -0x1
    ctx->r5 = ADD32(ctx->r4, -0X1);
    // 0x8035E26C: bgezl       $a1, L_8035E284
    if (SIGNED(ctx->r5) >= 0) {
        // 0x8035E270: sh          $a1, 0x2E2($v1)
        MEM_H(0X2E2, ctx->r3) = ctx->r5;
            goto L_8035E284;
    }
    goto skip_1;
    // 0x8035E270: sh          $a1, 0x2E2($v1)
    MEM_H(0X2E2, ctx->r3) = ctx->r5;
    skip_1:
    // 0x8035E274: sh          $zero, 0x2E2($v1)
    MEM_H(0X2E2, ctx->r3) = 0;
    // 0x8035E278: b           L_8035E288
    // 0x8035E27C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
        goto L_8035E288;
    // 0x8035E27C: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8035E280: sh          $a1, 0x2E2($v1)
    MEM_H(0X2E2, ctx->r3) = ctx->r5;
L_8035E284:
    // 0x8035E284: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
L_8035E288:
    // 0x8035E288: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
L_8035E28C:
    // 0x8035E28C: lh          $a0, 0x2E4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E4);
    // 0x8035E290: lh          $t4, 0xE2($t3)
    ctx->r12 = MEM_H(ctx->r11, 0XE2);
    // 0x8035E294: sll         $a1, $a0, 16
    ctx->r5 = S32(ctx->r4 << 16);
    // 0x8035E298: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8035E29C: addu        $a2, $t4, $a0
    ctx->r6 = ADD32(ctx->r12, ctx->r4);
    // 0x8035E2A0: slti        $at, $a2, 0x401
    ctx->r1 = SIGNED(ctx->r6) < 0X401 ? 1 : 0;
    // 0x8035E2A4: bne         $at, $zero, L_8035E2B4
    if (ctx->r1 != 0) {
        // 0x8035E2A8: or          $a1, $t9, $zero
        ctx->r5 = ctx->r25 | 0;
            goto L_8035E2B4;
    }
    // 0x8035E2A8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x8035E2AC: b           L_8035E2B8
    // 0x8035E2B0: sh          $t1, 0x2E4($v1)
    MEM_H(0X2E4, ctx->r3) = ctx->r9;
        goto L_8035E2B8;
    // 0x8035E2B0: sh          $t1, 0x2E4($v1)
    MEM_H(0X2E4, ctx->r3) = ctx->r9;
L_8035E2B4:
    // 0x8035E2B4: sh          $a2, 0x2E4($v1)
    MEM_H(0X2E4, ctx->r3) = ctx->r6;
L_8035E2B8:
    // 0x8035E2B8: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x8035E2BC: addiu       $at, $zero, 0x7FFE
    ctx->r1 = ADD32(0, 0X7FFE);
    // 0x8035E2C0: lh          $a0, 0x2E6($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E6);
    // 0x8035E2C4: beql        $t2, $a0, L_8035E2FC
    if (ctx->r10 == ctx->r4) {
        // 0x8035E2C8: lh          $a0, 0x2E0($v1)
        ctx->r4 = MEM_H(ctx->r3, 0X2E0);
            goto L_8035E2FC;
    }
    goto skip_2;
    // 0x8035E2C8: lh          $a0, 0x2E0($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E0);
    skip_2:
    // 0x8035E2CC: beq         $a0, $at, L_8035E2F8
    if (ctx->r4 == ctx->r1) {
        // 0x8035E2D0: addiu       $a2, $a0, -0x1
        ctx->r6 = ADD32(ctx->r4, -0X1);
            goto L_8035E2F8;
    }
    // 0x8035E2D0: addiu       $a2, $a0, -0x1
    ctx->r6 = ADD32(ctx->r4, -0X1);
    // 0x8035E2D4: bgezl       $a2, L_8035E2F0
    if (SIGNED(ctx->r6) >= 0) {
        // 0x8035E2D8: sh          $a2, 0x2E6($v1)
        MEM_H(0X2E6, ctx->r3) = ctx->r6;
            goto L_8035E2F0;
    }
    goto skip_3;
    // 0x8035E2D8: sh          $a2, 0x2E6($v1)
    MEM_H(0X2E6, ctx->r3) = ctx->r6;
    skip_3:
    // 0x8035E2DC: sh          $zero, 0x2E6($v1)
    MEM_H(0X2E6, ctx->r3) = 0;
    // 0x8035E2E0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E2E4: b           L_8035E2F8
    // 0x8035E2E8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
        goto L_8035E2F8;
    // 0x8035E2E8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8035E2EC: sh          $a2, 0x2E6($v1)
    MEM_H(0X2E6, ctx->r3) = ctx->r6;
L_8035E2F0:
    // 0x8035E2F0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E2F4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
L_8035E2F8:
    // 0x8035E2F8: lh          $a0, 0x2E0($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E0);
L_8035E2FC:
    // 0x8035E2FC: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x8035E300: beq         $at, $zero, L_8035E318
    if (ctx->r1 == 0) {
        // 0x8035E304: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8035E318;
    }
    // 0x8035E304: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E308: bne         $t1, $a0, L_8035E318
    if (ctx->r9 != ctx->r4) {
        // 0x8035E30C: nop
    
            goto L_8035E318;
    }
    // 0x8035E30C: nop

    // 0x8035E310: b           L_8035E318
    // 0x8035E314: nop

        goto L_8035E318;
    // 0x8035E314: nop

L_8035E318:
    // 0x8035E318: lh          $a0, 0x2E4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2E4);
    // 0x8035E31C: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8035E320: addiu       $a3, $a3, 0x2EE0
    ctx->r7 = ADD32(ctx->r7, 0X2EE0);
    // 0x8035E324: slt         $at, $a1, $a0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x8035E328: beql        $at, $zero, L_8035E338
    if (ctx->r1 == 0) {
        // 0x8035E32C: sh          $zero, 0x2($a3)
        MEM_H(0X2, ctx->r7) = 0;
            goto L_8035E338;
    }
    goto skip_4;
    // 0x8035E32C: sh          $zero, 0x2($a3)
    MEM_H(0X2, ctx->r7) = 0;
    skip_4:
    // 0x8035E330: lw          $v0, 0x5524($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5524);
    // 0x8035E334: sh          $zero, 0x2($a3)
    MEM_H(0X2, ctx->r7) = 0;
L_8035E338:
    // 0x8035E338: lh          $t6, 0x2($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X2);
    // 0x8035E33C: jr          $ra
    // 0x8035E340: sh          $t6, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r14;
    return;
    // 0x8035E340: sh          $t6, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r14;
;}
RECOMP_FUNC void func_8035E344_76F9F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035E344: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x8035E348: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x8035E34C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8035E350: lw          $t1, 0x4($a0)
    ctx->r9 = MEM_W(ctx->r4, 0X4);
    // 0x8035E354: lw          $t8, 0x0($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X0);
    // 0x8035E358: sll         $v0, $a1, 2
    ctx->r2 = S32(ctx->r5 << 2);
    // 0x8035E35C: subu        $v0, $v0, $a1
    ctx->r2 = SUB32(ctx->r2, ctx->r5);
    // 0x8035E360: sll         $v0, $v0, 1
    ctx->r2 = S32(ctx->r2 << 1);
    // 0x8035E364: sll         $a2, $a1, 2
    ctx->r6 = S32(ctx->r5 << 2);
    // 0x8035E368: addu        $a3, $t1, $a2
    ctx->r7 = ADD32(ctx->r9, ctx->r6);
    // 0x8035E36C: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x8035E370: lh          $v1, 0xDA($t9)
    ctx->r3 = MEM_H(ctx->r25, 0XDA);
    // 0x8035E374: lh          $t0, 0x2E0($a3)
    ctx->r8 = MEM_H(ctx->r7, 0X2E0);
    // 0x8035E378: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x8035E37C: beq         $at, $zero, L_8035E3DC
    if (ctx->r1 == 0) {
        // 0x8035E380: subu        $t2, $t0, $v1
        ctx->r10 = SUB32(ctx->r8, ctx->r3);
            goto L_8035E3DC;
    }
    // 0x8035E380: subu        $t2, $t0, $v1
    ctx->r10 = SUB32(ctx->r8, ctx->r3);
    // 0x8035E384: sh          $t2, 0x2E0($a3)
    MEM_H(0X2E0, ctx->r7) = ctx->r10;
    // 0x8035E388: lw          $t3, 0x0($a0)
    ctx->r11 = MEM_W(ctx->r4, 0X0);
    // 0x8035E38C: lw          $t6, 0x4($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X4);
    // 0x8035E390: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E394: addu        $t4, $t3, $v0
    ctx->r12 = ADD32(ctx->r11, ctx->r2);
    // 0x8035E398: lh          $t5, 0xDE($t4)
    ctx->r13 = MEM_H(ctx->r12, 0XDE);
    // 0x8035E39C: addu        $t7, $t6, $a2
    ctx->r15 = ADD32(ctx->r14, ctx->r6);
    // 0x8035E3A0: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x8035E3A4: sh          $t5, 0x2E2($t7)
    MEM_H(0X2E2, ctx->r15) = ctx->r13;
    // 0x8035E3A8: lh          $t8, 0x5534($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5534);
    // 0x8035E3AC: sll         $t3, $a1, 1
    ctx->r11 = S32(ctx->r5 << 1);
    // 0x8035E3B0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035E3B4: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x8035E3B8: addu        $t1, $t1, $t9
    ctx->r9 = ADD32(ctx->r9, ctx->r25);
    // 0x8035E3BC: lw          $t1, -0x2274($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X2274);
    // 0x8035E3C0: addu        $at, $at, $t3
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x8035E3C4: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x8035E3C8: bne         $a0, $t1, L_8035E3D4
    if (ctx->r4 != ctx->r9) {
        // 0x8035E3CC: nop
    
            goto L_8035E3D4;
    }
    // 0x8035E3CC: nop

    // 0x8035E3D0: sh          $t2, 0x2EE0($at)
    MEM_H(0X2EE0, ctx->r1) = ctx->r10;
L_8035E3D4:
    // 0x8035E3D4: jr          $ra
    // 0x8035E3D8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x8035E3D8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8035E3DC:
    // 0x8035E3DC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8035E3E0: jr          $ra
    // 0x8035E3E4: nop

    return;
    // 0x8035E3E4: nop

;}
RECOMP_FUNC void recharge_skill(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035E3E8: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8035E3EC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8035E3F0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E3F4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8035E3F8: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8035E3FC: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8035E400: sll         $t1, $t7, 2
    ctx->r9 = S32(ctx->r15 << 2);
    // 0x8035E404: subu        $t1, $t1, $t7
    ctx->r9 = SUB32(ctx->r9, ctx->r15);
    // 0x8035E408: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8035E40C: sll         $t1, $t1, 1
    ctx->r9 = S32(ctx->r9 << 1);
    // 0x8035E410: sll         $t9, $t7, 2
    ctx->r25 = S32(ctx->r15 << 2);
    // 0x8035E414: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x8035E418: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x8035E41C: lh          $t4, 0x2E0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2E0);
    // 0x8035E420: lh          $t3, 0xDA($t2)
    ctx->r11 = MEM_H(ctx->r10, 0XDA);
    // 0x8035E424: addu        $t5, $t4, $t3
    ctx->r13 = ADD32(ctx->r12, ctx->r11);
    // 0x8035E428: jr          $ra
    // 0x8035E42C: sh          $t5, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r13;
    return;
    // 0x8035E42C: sh          $t5, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r13;
;}
RECOMP_FUNC void func_8035E430_76FAE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035E430: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8035E434: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8035E438: addiu       $sp, $sp, -0xD8
    ctx->r29 = ADD32(ctx->r29, -0XD8);
    // 0x8035E43C: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8035E440: lhu         $v1, 0x9C($t0)
    ctx->r3 = MEM_HU(ctx->r8, 0X9C);
    // 0x8035E444: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x8035E448: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E44C: beq         $v1, $at, L_8035E468
    if (ctx->r3 == ctx->r1) {
        // 0x8035E450: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_8035E468;
    }
    // 0x8035E450: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8035E454: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035E458: bne         $v1, $at, L_8035E48C
    if (ctx->r3 != ctx->r1) {
        // 0x8035E45C: addiu       $t7, $zero, 0x1
        ctx->r15 = ADD32(0, 0X1);
            goto L_8035E48C;
    }
    // 0x8035E45C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8035E460: b           L_8035E48C
    // 0x8035E464: sh          $t7, 0xA0($sp)
    MEM_H(0XA0, ctx->r29) = ctx->r15;
        goto L_8035E48C;
    // 0x8035E464: sh          $t7, 0xA0($sp)
    MEM_H(0XA0, ctx->r29) = ctx->r15;
L_8035E468:
    // 0x8035E468: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035E46C: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x8035E470: sh          $t8, 0xA0($sp)
    MEM_H(0XA0, ctx->r29) = ctx->r24;
    // 0x8035E474: lh          $v1, 0x308($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X308);
    // 0x8035E478: blez        $v1, L_8035E48C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x8035E47C: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_8035E48C;
    }
    // 0x8035E47C: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x8035E480: sh          $t6, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r14;
    // 0x8035E484: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8035E488: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
L_8035E48C:
    // 0x8035E48C: lbu         $t9, 0x5538($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X5538);
    // 0x8035E490: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035E494: beq         $t9, $zero, L_8035E4E4
    if (ctx->r25 == 0) {
        // 0x8035E498: nop
    
            goto L_8035E4E4;
    }
    // 0x8035E498: nop

    // 0x8035E49C: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x8035E4A0: lh          $v1, 0xD6($t0)
    ctx->r3 = MEM_H(ctx->r8, 0XD6);
    // 0x8035E4A4: beq         $a0, $v1, L_8035E4C4
    if (ctx->r4 == ctx->r3) {
        // 0x8035E4A8: nop
    
            goto L_8035E4C4;
    }
    // 0x8035E4A8: nop

    // 0x8035E4AC: bne         $v1, $zero, L_8035E4CC
    if (ctx->r3 != 0) {
        // 0x8035E4B0: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8035E4CC;
    }
    // 0x8035E4B0: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8035E4B4: beq         $a0, $at, L_8035E4C4
    if (ctx->r4 == ctx->r1) {
        // 0x8035E4B8: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8035E4C4;
    }
    // 0x8035E4B8: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035E4BC: bnel        $a0, $at, L_8035E4D0
    if (ctx->r4 != ctx->r1) {
        // 0x8035E4C0: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_8035E4D0;
    }
    goto skip_0;
    // 0x8035E4C0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    skip_0:
L_8035E4C4:
    // 0x8035E4C4: b           L_8035E4D0
    // 0x8035E4C8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_8035E4D0;
    // 0x8035E4C8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_8035E4CC:
    // 0x8035E4CC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8035E4D0:
    // 0x8035E4D0: beq         $v1, $zero, L_8035E4E4
    if (ctx->r3 == 0) {
        // 0x8035E4D4: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8035E4E4;
    }
    // 0x8035E4D4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035E4D8: sh          $zero, 0xA2($sp)
    MEM_H(0XA2, ctx->r29) = 0;
    // 0x8035E4DC: b           L_8035E5A8
    // 0x8035E4E0: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_8035E5A8;
    // 0x8035E4E0: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_8035E4E4:
    // 0x8035E4E4: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035E4E8: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x8035E4EC: lh          $v1, 0xD6($t0)
    ctx->r3 = MEM_H(ctx->r8, 0XD6);
    // 0x8035E4F0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E4F4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035E4F8: beq         $a0, $v1, L_8035E518
    if (ctx->r4 == ctx->r3) {
        // 0x8035E4FC: lh          $t9, 0xA0($sp)
        ctx->r25 = MEM_H(ctx->r29, 0XA0);
            goto L_8035E518;
    }
    // 0x8035E4FC: lh          $t9, 0xA0($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA0);
    // 0x8035E500: bne         $v1, $zero, L_8035E520
    if (ctx->r3 != 0) {
        // 0x8035E504: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8035E520;
    }
    // 0x8035E504: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8035E508: beq         $a0, $at, L_8035E518
    if (ctx->r4 == ctx->r1) {
        // 0x8035E50C: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8035E518;
    }
    // 0x8035E50C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035E510: bnel        $a0, $at, L_8035E524
    if (ctx->r4 != ctx->r1) {
        // 0x8035E514: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_8035E524;
    }
    goto skip_1;
    // 0x8035E514: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    skip_1:
L_8035E518:
    // 0x8035E518: b           L_8035E524
    // 0x8035E51C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_8035E524;
    // 0x8035E51C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_8035E520:
    // 0x8035E520: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8035E524:
    // 0x8035E524: lhu         $t8, 0xBA($t0)
    ctx->r24 = MEM_HU(ctx->r8, 0XBA);
    // 0x8035E528: lw          $t7, 0xC($v0)
    ctx->r15 = MEM_W(ctx->r2, 0XC);
    // 0x8035E52C: sll         $a3, $t9, 4
    ctx->r7 = S32(ctx->r25 << 4);
    // 0x8035E530: sll         $t6, $t8, 15
    ctx->r14 = S32(ctx->r24 << 15);
    // 0x8035E534: subu        $a3, $a3, $t9
    ctx->r7 = SUB32(ctx->r7, ctx->r25);
    // 0x8035E538: sll         $t8, $a3, 7
    ctx->r24 = S32(ctx->r7 << 7);
    // 0x8035E53C: addu        $a2, $t7, $t6
    ctx->r6 = ADD32(ctx->r15, ctx->r14);
    // 0x8035E540: sll         $t7, $t8, 2
    ctx->r15 = S32(ctx->r24 << 2);
    // 0x8035E544: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x8035E548: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8035E54C: addu        $t7, $t7, $t8
    ctx->r15 = ADD32(ctx->r15, ctx->r24);
    // 0x8035E550: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8035E554: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x8035E558: lw          $a0, 0x4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X4);
    // 0x8035E55C: lw          $a1, 0x8($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X8);
    // 0x8035E560: bgez        $a3, L_8035E570
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8035E564: sra         $t6, $a3, 5
        ctx->r14 = S32(SIGNED(ctx->r7) >> 5);
            goto L_8035E570;
    }
    // 0x8035E564: sra         $t6, $a3, 5
    ctx->r14 = S32(SIGNED(ctx->r7) >> 5);
    // 0x8035E568: addiu       $at, $a3, 0x1F
    ctx->r1 = ADD32(ctx->r7, 0X1F);
    // 0x8035E56C: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_8035E570:
    // 0x8035E570: addiu       $t7, $zero, 0x32
    ctx->r15 = ADD32(0, 0X32);
    // 0x8035E574: addiu       $t8, $zero, 0x7
    ctx->r24 = ADD32(0, 0X7);
    // 0x8035E578: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035E57C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8035E580: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8035E584: addiu       $t6, $zero, 0x32
    ctx->r14 = ADD32(0, 0X32);
    // 0x8035E588: sltiu       $t7, $v1, 0x1
    ctx->r15 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x8035E58C: addiu       $t8, $zero, 0x32
    ctx->r24 = ADD32(0, 0X32);
    // 0x8035E590: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8035E594: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8035E598: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8035E59C: jal         0x802E89F0
    // 0x8035E5A0: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_0;
    // 0x8035E5A0: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    after_0:
    // 0x8035E5A4: sh          $v0, 0xA2($sp)
    MEM_H(0XA2, ctx->r29) = ctx->r2;
L_8035E5A8:
    // 0x8035E5A8: lh          $t6, 0xA2($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XA2);
    // 0x8035E5AC: bne         $t6, $zero, L_8035F4B0
    if (ctx->r14 != 0) {
        // 0x8035E5B0: nop
    
            goto L_8035F4B0;
    }
    // 0x8035E5B0: nop

    // 0x8035E5B4: jal         0x8034B45C
    // 0x8035E5B8: nop

    func_8034B45C_75CB0C(rdram, ctx);
        goto after_1;
    // 0x8035E5B8: nop

    after_1:
    // 0x8035E5BC: jal         0x8035D120
    // 0x8035E5C0: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_2;
    // 0x8035E5C0: nop

    after_2:
    // 0x8035E5C4: jal         0x8035DA60
    // 0x8035E5C8: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_3;
    // 0x8035E5C8: nop

    after_3:
    // 0x8035E5CC: jal         0x8035D734
    // 0x8035E5D0: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_4;
    // 0x8035E5D0: nop

    after_4:
    // 0x8035E5D4: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035E5D8: lw          $t8, 0x2EBC($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EBC);
    // 0x8035E5DC: lui         $v0, 0xFFFF
    ctx->r2 = S32(0XFFFF << 16);
    // 0x8035E5E0: lui         $v1, 0x1
    ctx->r3 = S32(0X1 << 16);
    // 0x8035E5E4: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x8035E5E8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035E5EC: lw          $t8, 0x2EC0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC0);
    // 0x8035E5F0: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8035E5F4: addu        $t6, $t7, $v1
    ctx->r14 = ADD32(ctx->r15, ctx->r3);
    // 0x8035E5F8: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x8035E5FC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035E600: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x8035E604: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035E608: sw          $t6, 0x2EBC($at)
    MEM_W(0X2EBC, ctx->r1) = ctx->r14;
    // 0x8035E60C: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8035E610: addu        $t6, $t7, $v1
    ctx->r14 = ADD32(ctx->r15, ctx->r3);
    // 0x8035E614: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035E618: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x8035E61C: sw          $t6, 0x2EC0($at)
    MEM_W(0X2EC0, ctx->r1) = ctx->r14;
    // 0x8035E620: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E624: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8035E628: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8035E62C: addu        $t6, $t7, $v1
    ctx->r14 = ADD32(ctx->r15, ctx->r3);
    // 0x8035E630: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035E634: sw          $t6, 0x2EC4($at)
    MEM_W(0X2EC4, ctx->r1) = ctx->r14;
    // 0x8035E638: lbu         $t9, 0x366($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X366);
    // 0x8035E63C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035E640: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E644: bne         $t9, $at, L_8035E6B8
    if (ctx->r25 != ctx->r1) {
        // 0x8035E648: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_8035E6B8;
    }
    // 0x8035E648: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E64C: lw          $v1, 0x5528($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5528);
    // 0x8035E650: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035E654: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
    // 0x8035E658: beq         $a0, $zero, L_8035E7B4
    if (ctx->r4 == 0) {
        // 0x8035E65C: nop
    
            goto L_8035E7B4;
    }
    // 0x8035E65C: nop

    // 0x8035E660: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8035E664: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035E668: sll         $t9, $a0, 3
    ctx->r25 = S32(ctx->r4 << 3);
    // 0x8035E66C: lhu         $t6, 0x9C($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X9C);
    // 0x8035E670: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x8035E674: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x8035E678: bne         $t6, $at, L_8035E698
    if (ctx->r14 != ctx->r1) {
        // 0x8035E67C: addiu       $t7, $zero, 0x21
        ctx->r15 = ADD32(0, 0X21);
            goto L_8035E698;
    }
    // 0x8035E67C: addiu       $t7, $zero, 0x21
    ctx->r15 = ADD32(0, 0X21);
    // 0x8035E680: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8035E684: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E688: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x8035E68C: sb          $t8, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r24;
    // 0x8035E690: b           L_8035E7B4
    // 0x8035E694: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
        goto L_8035E7B4;
    // 0x8035E694: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E698:
    // 0x8035E698: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x8035E69C: subu        $t6, $t6, $a0
    ctx->r14 = SUB32(ctx->r14, ctx->r4);
    // 0x8035E6A0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8035E6A4: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E6A8: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x8035E6AC: sb          $t7, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r15;
    // 0x8035E6B0: b           L_8035E7B4
    // 0x8035E6B4: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
        goto L_8035E7B4;
    // 0x8035E6B4: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E6B8:
    // 0x8035E6B8: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x8035E6BC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8035E6C0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E6C4: beq         $t8, $zero, L_8035E74C
    if (ctx->r24 == 0) {
        // 0x8035E6C8: nop
    
            goto L_8035E74C;
    }
    // 0x8035E6C8: nop

    // 0x8035E6CC: lh          $t9, 0x2D34($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2D34);
    // 0x8035E6D0: slti        $at, $t9, 0x11
    ctx->r1 = SIGNED(ctx->r25) < 0X11 ? 1 : 0;
    // 0x8035E6D4: bne         $at, $zero, L_8035E74C
    if (ctx->r1 != 0) {
        // 0x8035E6D8: nop
    
            goto L_8035E74C;
    }
    // 0x8035E6D8: nop

    // 0x8035E6DC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E6E0: lw          $v1, 0x5528($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5528);
    // 0x8035E6E4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035E6E8: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
    // 0x8035E6EC: beq         $a0, $zero, L_8035E7B4
    if (ctx->r4 == 0) {
        // 0x8035E6F0: nop
    
            goto L_8035E7B4;
    }
    // 0x8035E6F0: nop

    // 0x8035E6F4: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8035E6F8: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035E6FC: sll         $t9, $a0, 3
    ctx->r25 = S32(ctx->r4 << 3);
    // 0x8035E700: lhu         $t6, 0x9C($t7)
    ctx->r14 = MEM_HU(ctx->r15, 0X9C);
    // 0x8035E704: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x8035E708: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x8035E70C: bne         $t6, $at, L_8035E72C
    if (ctx->r14 != ctx->r1) {
        // 0x8035E710: addiu       $t7, $zero, 0x21
        ctx->r15 = ADD32(0, 0X21);
            goto L_8035E72C;
    }
    // 0x8035E710: addiu       $t7, $zero, 0x21
    ctx->r15 = ADD32(0, 0X21);
    // 0x8035E714: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8035E718: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E71C: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x8035E720: sb          $t8, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r24;
    // 0x8035E724: b           L_8035E7B4
    // 0x8035E728: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
        goto L_8035E7B4;
    // 0x8035E728: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E72C:
    // 0x8035E72C: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x8035E730: subu        $t6, $t6, $a0
    ctx->r14 = SUB32(ctx->r14, ctx->r4);
    // 0x8035E734: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8035E738: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E73C: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x8035E740: sb          $t7, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r15;
    // 0x8035E744: b           L_8035E7B4
    // 0x8035E748: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
        goto L_8035E7B4;
    // 0x8035E748: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E74C:
    // 0x8035E74C: lw          $v1, 0x5528($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5528);
    // 0x8035E750: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E754: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
    // 0x8035E758: beq         $a0, $zero, L_8035E7B4
    if (ctx->r4 == 0) {
        // 0x8035E75C: nop
    
            goto L_8035E7B4;
    }
    // 0x8035E75C: nop

    // 0x8035E760: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x8035E764: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035E768: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x8035E76C: lhu         $t9, 0x9C($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X9C);
    // 0x8035E770: subu        $t6, $t6, $a0
    ctx->r14 = SUB32(ctx->r14, ctx->r4);
    // 0x8035E774: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x8035E778: bne         $t9, $at, L_8035E798
    if (ctx->r25 != ctx->r1) {
        // 0x8035E77C: addiu       $t8, $zero, 0x20
        ctx->r24 = ADD32(0, 0X20);
            goto L_8035E798;
    }
    // 0x8035E77C: addiu       $t8, $zero, 0x20
    ctx->r24 = ADD32(0, 0X20);
    // 0x8035E780: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8035E784: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E788: addu        $at, $at, $t6
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x8035E78C: sb          $t7, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r15;
    // 0x8035E790: b           L_8035E7B4
    // 0x8035E794: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
        goto L_8035E7B4;
    // 0x8035E794: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E798:
    // 0x8035E798: sll         $t9, $a0, 3
    ctx->r25 = S32(ctx->r4 << 3);
    // 0x8035E79C: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x8035E7A0: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8035E7A4: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E7A8: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x8035E7AC: sb          $t8, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r24;
    // 0x8035E7B0: lh          $a0, 0x3CA($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X3CA);
L_8035E7B4:
    // 0x8035E7B4: beq         $a0, $zero, L_8035E7E4
    if (ctx->r4 == 0) {
        // 0x8035E7B8: lui         $t7, 0x803A
        ctx->r15 = S32(0X803A << 16);
            goto L_8035E7E4;
    }
    // 0x8035E7B8: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x8035E7BC: lh          $t7, 0x6CE4($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X6CE4);
    // 0x8035E7C0: sll         $t9, $a0, 3
    ctx->r25 = S32(ctx->r4 << 3);
    // 0x8035E7C4: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x8035E7C8: andi        $t6, $t7, 0x8
    ctx->r14 = ctx->r15 & 0X8;
    // 0x8035E7CC: beq         $t6, $zero, L_8035E7E4
    if (ctx->r14 == 0) {
        // 0x8035E7D0: addiu       $t8, $zero, 0x1F
        ctx->r24 = ADD32(0, 0X1F);
            goto L_8035E7E4;
    }
    // 0x8035E7D0: addiu       $t8, $zero, 0x1F
    ctx->r24 = ADD32(0, 0X1F);
    // 0x8035E7D4: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8035E7D8: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035E7DC: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x8035E7E0: sb          $t8, 0xEE($at)
    MEM_B(0XEE, ctx->r1) = ctx->r24;
L_8035E7E4:
    // 0x8035E7E4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035E7E8: lhu         $t7, 0x2ECE($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X2ECE);
    // 0x8035E7EC: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035E7F0: addiu       $a0, $sp, 0xA8
    ctx->r4 = ADD32(ctx->r29, 0XA8);
    // 0x8035E7F4: beq         $t7, $zero, L_8035E808
    if (ctx->r15 == 0) {
        // 0x8035E7F8: addiu       $a1, $zero, 0xCB
        ctx->r5 = ADD32(0, 0XCB);
            goto L_8035E808;
    }
    // 0x8035E7F8: addiu       $a1, $zero, 0xCB
    ctx->r5 = ADD32(0, 0XCB);
    // 0x8035E7FC: lhu         $t6, 0x2ECC($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X2ECC);
    // 0x8035E800: slti        $at, $t6, 0x1F
    ctx->r1 = SIGNED(ctx->r14) < 0X1F ? 1 : 0;
    // 0x8035E804: beq         $at, $zero, L_8035E82C
    if (ctx->r1 == 0) {
        // 0x8035E808: addiu       $a2, $zero, 0xA2
        ctx->r6 = ADD32(0, 0XA2);
            goto L_8035E82C;
    }
L_8035E808:
    // 0x8035E808: addiu       $a2, $zero, 0xA2
    ctx->r6 = ADD32(0, 0XA2);
    // 0x8035E80C: addiu       $a3, $zero, 0x16D
    ctx->r7 = ADD32(0, 0X16D);
    // 0x8035E810: jal         0x802B9130
    // 0x8035E814: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_802B9130_6CA7E0(rdram, ctx);
        goto after_5;
    // 0x8035E814: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_5:
    // 0x8035E818: addiu       $a0, $zero, 0x11C
    ctx->r4 = ADD32(0, 0X11C);
    // 0x8035E81C: jal         0x802C1830
    // 0x8035E820: addiu       $a1, $sp, 0xA8
    ctx->r5 = ADD32(ctx->r29, 0XA8);
    func_802C1830_6D2EE0(rdram, ctx);
        goto after_6;
    // 0x8035E820: addiu       $a1, $sp, 0xA8
    ctx->r5 = ADD32(ctx->r29, 0XA8);
    after_6:
    // 0x8035E824: jal         0x802B964C
    // 0x8035E828: nop

    func_802B964C_6CACFC(rdram, ctx);
        goto after_7;
    // 0x8035E828: nop

    after_7:
L_8035E82C:
    // 0x8035E82C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035E830: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x8035E834: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x8035E838: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E83C: lhu         $v1, 0x9C($t8)
    ctx->r3 = MEM_HU(ctx->r24, 0X9C);
    // 0x8035E840: beq         $v1, $at, L_8035EA04
    if (ctx->r3 == ctx->r1) {
        // 0x8035E844: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_8035EA04;
    }
    // 0x8035E844: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035E848: beq         $v1, $at, L_8035E85C
    if (ctx->r3 == ctx->r1) {
        // 0x8035E84C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8035E85C;
    }
    // 0x8035E84C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E850: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035E854: b           L_8035EC48
    // 0x8035E858: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
        goto L_8035EC48;
    // 0x8035E858: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
L_8035E85C:
    // 0x8035E85C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035E860: addiu       $at, $zero, 0x12
    ctx->r1 = ADD32(0, 0X12);
    // 0x8035E864: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035E868: lbu         $t9, 0x365($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X365);
    // 0x8035E86C: bnel        $t9, $at, L_8035E9F8
    if (ctx->r25 != ctx->r1) {
        // 0x8035E870: sb          $zero, 0x365($v0)
        MEM_B(0X365, ctx->r2) = 0;
            goto L_8035E9F8;
    }
    goto skip_2;
    // 0x8035E870: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
    skip_2:
    // 0x8035E874: lw          $v1, 0x5528($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5528);
    // 0x8035E878: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E87C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035E880: sh          $zero, 0x3C0($v1)
    MEM_H(0X3C0, ctx->r3) = 0;
    // 0x8035E884: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035E888: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x8035E88C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035E890: lhu         $t6, 0x32A($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X32A);
    // 0x8035E894: addiu       $a1, $zero, 0x19
    ctx->r5 = ADD32(0, 0X19);
    // 0x8035E898: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035E89C: subu        $a0, $t7, $t6
    ctx->r4 = SUB32(ctx->r15, ctx->r14);
    // 0x8035E8A0: andi        $t0, $a0, 0xFFFF
    ctx->r8 = ctx->r4 & 0XFFFF;
    // 0x8035E8A4: bne         $t0, $at, L_8035E968
    if (ctx->r8 != ctx->r1) {
        // 0x8035E8A8: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_8035E968;
    }
    // 0x8035E8A8: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x8035E8AC: addiu       $t9, $zero, 0x6
    ctx->r25 = ADD32(0, 0X6);
    // 0x8035E8B0: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x8035E8B4: addiu       $t6, $zero, 0x12C
    ctx->r14 = ADD32(0, 0X12C);
    // 0x8035E8B8: addiu       $t8, $zero, 0x7
    ctx->r24 = ADD32(0, 0X7);
    // 0x8035E8BC: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8035E8C0: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8035E8C4: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8035E8C8: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8035E8CC: addiu       $a3, $zero, 0x16
    ctx->r7 = ADD32(0, 0X16);
    // 0x8035E8D0: jal         0x803224C4
    // 0x8035E8D4: sw          $t0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r8;
    func_803224C4_733B74(rdram, ctx);
        goto after_8;
    // 0x8035E8D4: sw          $t0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r8;
    after_8:
    // 0x8035E8D8: beq         $v0, $zero, L_8035E924
    if (ctx->r2 == 0) {
        // 0x8035E8DC: lw          $t0, 0x54($sp)
        ctx->r8 = MEM_W(ctx->r29, 0X54);
            goto L_8035E924;
    }
    // 0x8035E8DC: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
    // 0x8035E8E0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E8E4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035E8E8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035E8EC: lwc1        $f16, -0x1400($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0X1400);
    // 0x8035E8F0: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x8035E8F4: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035E8F8: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x8035E8FC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8035E900: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x8035E904: sw          $t0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r8;
    // 0x8035E908: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035E90C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035E910: swc1        $f16, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f16.u32l;
    // 0x8035E914: jal         0x8032C360
    // 0x8035E918: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    play_sound_effect_at_location(rdram, ctx);
        goto after_9;
    // 0x8035E918: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_9:
    // 0x8035E91C: b           L_8035E978
    // 0x8035E920: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
        goto L_8035E978;
    // 0x8035E920: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
L_8035E924:
    // 0x8035E924: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035E928: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035E92C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035E930: lwc1        $f18, -0x13FC($at)
    ctx->f18.u32l = MEM_W(ctx->r1, -0X13FC);
    // 0x8035E934: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    // 0x8035E938: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035E93C: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x8035E940: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8035E944: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x8035E948: sw          $t0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r8;
    // 0x8035E94C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035E950: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035E954: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    // 0x8035E958: jal         0x8032C360
    // 0x8035E95C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_10;
    // 0x8035E95C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_10:
    // 0x8035E960: b           L_8035E978
    // 0x8035E964: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
        goto L_8035E978;
    // 0x8035E964: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
L_8035E968:
    // 0x8035E968: slti        $at, $t0, 0x6
    ctx->r1 = SIGNED(ctx->r8) < 0X6 ? 1 : 0;
    // 0x8035E96C: bnel        $at, $zero, L_8035E97C
    if (ctx->r1 != 0) {
        // 0x8035E970: slti        $at, $t0, 0x3
        ctx->r1 = SIGNED(ctx->r8) < 0X3 ? 1 : 0;
            goto L_8035E97C;
    }
    goto skip_3;
    // 0x8035E970: slti        $at, $t0, 0x3
    ctx->r1 = SIGNED(ctx->r8) < 0X3 ? 1 : 0;
    skip_3:
    // 0x8035E974: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_8035E978:
    // 0x8035E978: slti        $at, $t0, 0x3
    ctx->r1 = SIGNED(ctx->r8) < 0X3 ? 1 : 0;
L_8035E97C:
    // 0x8035E97C: beq         $at, $zero, L_8035E994
    if (ctx->r1 == 0) {
        // 0x8035E980: lui         $t7, 0x8020
        ctx->r15 = S32(0X8020 << 16);
            goto L_8035E994;
    }
    // 0x8035E980: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x8035E984: or          $v1, $t0, $zero
    ctx->r3 = ctx->r8 | 0;
    // 0x8035E988: sll         $t9, $v1, 19
    ctx->r25 = S32(ctx->r3 << 19);
    // 0x8035E98C: b           L_8035E9A4
    // 0x8035E990: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
        goto L_8035E9A4;
    // 0x8035E990: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
L_8035E994:
    // 0x8035E994: addiu       $t6, $zero, 0x6
    ctx->r14 = ADD32(0, 0X6);
    // 0x8035E998: subu        $t8, $t6, $t0
    ctx->r24 = SUB32(ctx->r14, ctx->r8);
    // 0x8035E99C: sll         $t9, $t8, 18
    ctx->r25 = S32(ctx->r24 << 18);
    // 0x8035E9A0: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
L_8035E9A4:
    // 0x8035E9A4: sll         $v0, $v1, 2
    ctx->r2 = S32(ctx->r3 << 2);
    // 0x8035E9A8: subu        $v0, $v0, $v1
    ctx->r2 = SUB32(ctx->r2, ctx->r3);
    // 0x8035E9AC: sll         $v0, $v0, 2
    ctx->r2 = S32(ctx->r2 << 2);
    // 0x8035E9B0: addu        $v0, $v0, $v1
    ctx->r2 = ADD32(ctx->r2, ctx->r3);
    // 0x8035E9B4: sll         $v0, $v0, 2
    ctx->r2 = S32(ctx->r2 << 2);
    // 0x8035E9B8: subu        $v0, $v0, $v1
    ctx->r2 = SUB32(ctx->r2, ctx->r3);
    // 0x8035E9BC: sll         $v0, $v0, 2
    ctx->r2 = S32(ctx->r2 << 2);
    // 0x8035E9C0: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x8035E9C4: lh          $t8, 0x3FEA($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FEA);
    // 0x8035E9C8: subu        $v0, $v0, $v1
    ctx->r2 = SUB32(ctx->r2, ctx->r3);
    // 0x8035E9CC: sll         $v0, $v0, 1
    ctx->r2 = S32(ctx->r2 << 1);
    // 0x8035E9D0: sra         $t6, $v0, 5
    ctx->r14 = S32(SIGNED(ctx->r2) >> 5);
    // 0x8035E9D4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8035E9D8: addu        $t9, $t8, $t6
    ctx->r25 = ADD32(ctx->r24, ctx->r14);
    // 0x8035E9DC: sh          $t9, 0x3FEA($at)
    MEM_H(0X3FEA, ctx->r1) = ctx->r25;
    // 0x8035E9E0: lh          $t7, 0x3FF2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FF2);
    // 0x8035E9E4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8035E9E8: addu        $t6, $t7, $t6
    ctx->r14 = ADD32(ctx->r15, ctx->r14);
    // 0x8035E9EC: b           L_8035E9F8
    // 0x8035E9F0: sh          $t6, 0x3FF2($at)
    MEM_H(0X3FF2, ctx->r1) = ctx->r14;
        goto L_8035E9F8;
    // 0x8035E9F0: sh          $t6, 0x3FF2($at)
    MEM_H(0X3FF2, ctx->r1) = ctx->r14;
    // 0x8035E9F4: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_8035E9F8:
    // 0x8035E9F8: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035E9FC: b           L_8035EC48
    // 0x8035EA00: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
        goto L_8035EC48;
    // 0x8035EA00: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
L_8035EA04:
    // 0x8035EA04: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035EA08: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x8035EA0C: lbu         $v1, 0x365($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X365);
    // 0x8035EA10: beq         $v1, $at, L_8035EA30
    if (ctx->r3 == ctx->r1) {
        // 0x8035EA14: addiu       $at, $zero, 0x27
        ctx->r1 = ADD32(0, 0X27);
            goto L_8035EA30;
    }
    // 0x8035EA14: addiu       $at, $zero, 0x27
    ctx->r1 = ADD32(0, 0X27);
    // 0x8035EA18: beq         $v1, $at, L_8035EC40
    if (ctx->r3 == ctx->r1) {
        // 0x8035EA1C: nop
    
            goto L_8035EC40;
    }
    // 0x8035EA1C: nop

    // 0x8035EA20: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
    // 0x8035EA24: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035EA28: b           L_8035EC48
    // 0x8035EA2C: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
        goto L_8035EC48;
    // 0x8035EA2C: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
L_8035EA30:
    // 0x8035EA30: jal         0x8012826C
    // 0x8035EA34: nop

    advance_random_seed(rdram, ctx);
        goto after_11;
    // 0x8035EA34: nop

    after_11:
    // 0x8035EA38: jal         0x8012826C
    // 0x8035EA3C: sh          $v0, 0x60($sp)
    MEM_H(0X60, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x8035EA3C: sh          $v0, 0x60($sp)
    MEM_H(0X60, ctx->r29) = ctx->r2;
    after_12:
    // 0x8035EA40: jal         0x8012826C
    // 0x8035EA44: sh          $v0, 0x62($sp)
    MEM_H(0X62, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_13;
    // 0x8035EA44: sh          $v0, 0x62($sp)
    MEM_H(0X62, ctx->r29) = ctx->r2;
    after_13:
    // 0x8035EA48: jal         0x8012826C
    // 0x8035EA4C: sh          $v0, 0x64($sp)
    MEM_H(0X64, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_14;
    // 0x8035EA4C: sh          $v0, 0x64($sp)
    MEM_H(0X64, ctx->r29) = ctx->r2;
    after_14:
    // 0x8035EA50: jal         0x8012826C
    // 0x8035EA54: sh          $v0, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_15;
    // 0x8035EA54: sh          $v0, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r2;
    after_15:
    // 0x8035EA58: jal         0x8012826C
    // 0x8035EA5C: sh          $v0, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_16;
    // 0x8035EA5C: sh          $v0, 0x68($sp)
    MEM_H(0X68, ctx->r29) = ctx->r2;
    after_16:
    // 0x8035EA60: jal         0x8012826C
    // 0x8035EA64: sh          $v0, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_17;
    // 0x8035EA64: sh          $v0, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r2;
    after_17:
    // 0x8035EA68: jal         0x8012826C
    // 0x8035EA6C: sh          $v0, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_18;
    // 0x8035EA6C: sh          $v0, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r2;
    after_18:
    // 0x8035EA70: jal         0x8012826C
    // 0x8035EA74: sh          $v0, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_19;
    // 0x8035EA74: sh          $v0, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r2;
    after_19:
    // 0x8035EA78: jal         0x8012826C
    // 0x8035EA7C: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_20;
    // 0x8035EA7C: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    after_20:
    // 0x8035EA80: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035EA84: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8035EA88: lhu         $t8, 0x60($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X60);
    // 0x8035EA8C: lhu         $a3, 0x64($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X64);
    // 0x8035EA90: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x8035EA94: andi        $t9, $t8, 0x1F
    ctx->r25 = ctx->r24 & 0X1F;
    // 0x8035EA98: lhu         $t6, 0x62($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X62);
    // 0x8035EA9C: addu        $a0, $t9, $t7
    ctx->r4 = ADD32(ctx->r25, ctx->r15);
    // 0x8035EAA0: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x8035EAA4: andi        $t7, $a3, 0x1
    ctx->r15 = ctx->r7 & 0X1;
    // 0x8035EAA8: addiu       $a3, $t7, 0x19
    ctx->r7 = ADD32(ctx->r15, 0X19);
    // 0x8035EAAC: andi        $t8, $t6, 0x1F
    ctx->r24 = ctx->r14 & 0X1F;
    // 0x8035EAB0: lhu         $t7, 0x66($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X66);
    // 0x8035EAB4: addu        $a1, $t8, $t9
    ctx->r5 = ADD32(ctx->r24, ctx->r25);
    // 0x8035EAB8: lhu         $t9, 0x68($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X68);
    // 0x8035EABC: sll         $t6, $a3, 16
    ctx->r14 = S32(ctx->r7 << 16);
    // 0x8035EAC0: lui         $t0, 0xFFFF
    ctx->r8 = S32(0XFFFF << 16);
    // 0x8035EAC4: ori         $t0, $t0, 0x63C0
    ctx->r8 = ctx->r8 | 0X63C0;
    // 0x8035EAC8: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8035EACC: addu        $t6, $t7, $t0
    ctx->r14 = ADD32(ctx->r15, ctx->r8);
    // 0x8035EAD0: lhu         $t8, 0x6A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X6A);
    // 0x8035EAD4: addu        $t7, $t9, $t0
    ctx->r15 = ADD32(ctx->r25, ctx->r8);
    // 0x8035EAD8: lh          $a2, 0xC($v1)
    ctx->r6 = MEM_H(ctx->r3, 0XC);
    // 0x8035EADC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8035EAE0: lhu         $t7, 0x6C($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X6C);
    // 0x8035EAE4: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x8035EAE8: lhu         $t8, 0x6E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X6E);
    // 0x8035EAEC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8035EAF0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8035EAF4: andi        $t6, $t7, 0x3
    ctx->r14 = ctx->r15 & 0X3;
    // 0x8035EAF8: andi        $t9, $t8, 0x3F
    ctx->r25 = ctx->r24 & 0X3F;
    // 0x8035EAFC: addiu       $t7, $t9, 0xC0
    ctx->r15 = ADD32(ctx->r25, 0XC0);
    // 0x8035EB00: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8035EB04: sll         $t6, $t7, 3
    ctx->r14 = S32(ctx->r15 << 3);
    // 0x8035EB08: andi        $t9, $t6, 0x7C0
    ctx->r25 = ctx->r14 & 0X7C0;
    // 0x8035EB0C: lhu         $t6, 0x70($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X70);
    // 0x8035EB10: ori         $t7, $t9, 0x8001
    ctx->r15 = ctx->r25 | 0X8001;
    // 0x8035EB14: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x8035EB18: andi        $t8, $t6, 0xF
    ctx->r24 = ctx->r14 & 0XF;
    // 0x8035EB1C: addiu       $t9, $t8, 0x41
    ctx->r25 = ADD32(ctx->r24, 0X41);
    // 0x8035EB20: sll         $t7, $t9, 8
    ctx->r15 = S32(ctx->r25 << 8);
    // 0x8035EB24: andi        $t9, $t7, 0xF800
    ctx->r25 = ctx->r15 & 0XF800;
    // 0x8035EB28: andi        $t6, $v0, 0x1F
    ctx->r14 = ctx->r2 & 0X1F;
    // 0x8035EB2C: addiu       $t8, $t6, 0xA
    ctx->r24 = ADD32(ctx->r14, 0XA);
    // 0x8035EB30: ori         $t7, $t9, 0x513
    ctx->r15 = ctx->r25 | 0X513;
    // 0x8035EB34: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8035EB38: sw          $t8, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r24;
    // 0x8035EB3C: addiu       $a1, $a1, -0x10
    ctx->r5 = ADD32(ctx->r5, -0X10);
    // 0x8035EB40: addiu       $a0, $a0, -0x10
    ctx->r4 = ADD32(ctx->r4, -0X10);
    // 0x8035EB44: jal         0x802D5F4C
    // 0x8035EB48: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    create_particle_effect(rdram, ctx);
        goto after_21;
    // 0x8035EB48: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    after_21:
    // 0x8035EB4C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035EB50: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8035EB54: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035EB58: lb          $t9, 0x4A($a0)
    ctx->r25 = MEM_B(ctx->r4, 0X4A);
    // 0x8035EB5C: bne         $t9, $zero, L_8035EBD8
    if (ctx->r25 != 0) {
        // 0x8035EB60: nop
    
            goto L_8035EBD8;
    }
    // 0x8035EB60: nop

    // 0x8035EB64: lh          $t7, 0x5540($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5540);
    // 0x8035EB68: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8035EB6C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035EB70: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x8035EB74: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x8035EB78: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x8035EB7C: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x8035EB80: lh          $t8, 0x2C78($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C78);
    // 0x8035EB84: ldc1        $f8, -0x13F8($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, -0X13F8);
    // 0x8035EB88: lui         $at, 0x4002
    ctx->r1 = S32(0X4002 << 16);
    // 0x8035EB8C: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8035EB90: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8035EB94: mtc1        $at, $f17
    ctx->f_odd[(17 - 1) * 2] = ctx->r1;
    // 0x8035EB98: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x8035EB9C: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x8035EBA0: addiu       $a1, $zero, 0x30
    ctx->r5 = ADD32(0, 0X30);
    // 0x8035EBA4: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x8035EBA8: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8035EBAC: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x8035EBB0: add.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = ctx->f10.d + ctx->f16.d;
    // 0x8035EBB4: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x8035EBB8: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8035EBBC: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
    // 0x8035EBC0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8035EBC4: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x8035EBC8: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8035EBCC: lh          $t8, 0xC($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XC);
    // 0x8035EBD0: jal         0x8032CD70
    // 0x8035EBD4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    func_8032CD70_73E420(rdram, ctx);
        goto after_22;
    // 0x8035EBD4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    after_22:
L_8035EBD8:
    // 0x8035EBD8: jal         0x8012826C
    // 0x8035EBDC: nop

    advance_random_seed(rdram, ctx);
        goto after_23;
    // 0x8035EBDC: nop

    after_23:
    // 0x8035EBE0: andi        $t9, $v0, 0x3F
    ctx->r25 = ctx->r2 & 0X3F;
    // 0x8035EBE4: addiu       $at, $zero, 0x35
    ctx->r1 = ADD32(0, 0X35);
    // 0x8035EBE8: bne         $t9, $at, L_8035EC24
    if (ctx->r25 != ctx->r1) {
        // 0x8035EBEC: addiu       $a0, $zero, 0x6D
        ctx->r4 = ADD32(0, 0X6D);
            goto L_8035EC24;
    }
    // 0x8035EBEC: addiu       $a0, $zero, 0x6D
    ctx->r4 = ADD32(0, 0X6D);
    // 0x8035EBF0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035EBF4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035EBF8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8035EBFC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8035EC00: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x8035EC04: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035EC08: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035EC0C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035EC10: lh          $t6, 0xC($v0)
    ctx->r14 = MEM_H(ctx->r2, 0XC);
    // 0x8035EC14: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035EC18: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x8035EC1C: jal         0x8032C360
    // 0x8035EC20: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    play_sound_effect_at_location(rdram, ctx);
        goto after_24;
    // 0x8035EC20: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_24:
L_8035EC24:
    // 0x8035EC24: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8035EC28: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
    // 0x8035EC2C: jal         0x8037F6CC
    // 0x8035EC30: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    func_8037F6CC_790D7C(rdram, ctx);
        goto after_25;
    // 0x8035EC30: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_25:
    // 0x8035EC34: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035EC38: b           L_8035EC48
    // 0x8035EC3C: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
        goto L_8035EC48;
    // 0x8035EC3C: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
L_8035EC40:
    // 0x8035EC40: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035EC44: lhu         $v1, 0x2ECC($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECC);
L_8035EC48:
    // 0x8035EC48: beq         $v1, $zero, L_8035ECC8
    if (ctx->r3 == 0) {
        // 0x8035EC4C: nop
    
            goto L_8035ECC8;
    }
    // 0x8035EC4C: nop

    // 0x8035EC50: jal         0x802DB8DC
    // 0x8035EC54: nop

    backup_joint_positions(rdram, ctx);
        goto after_26;
    // 0x8035EC54: nop

    after_26:
    // 0x8035EC58: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8035EC5C: lhu         $v1, 0x2ECE($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECE);
    // 0x8035EC60: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035EC64: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x8035EC68: beq         $v1, $at, L_8035EC84
    if (ctx->r3 == ctx->r1) {
        // 0x8035EC6C: addiu       $a0, $a0, 0x3F50
        ctx->r4 = ADD32(ctx->r4, 0X3F50);
            goto L_8035EC84;
    }
    // 0x8035EC6C: addiu       $a0, $a0, 0x3F50
    ctx->r4 = ADD32(ctx->r4, 0X3F50);
    // 0x8035EC70: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035EC74: beq         $v1, $at, L_8035ECA8
    if (ctx->r3 == ctx->r1) {
        // 0x8035EC78: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_8035ECA8;
    }
    // 0x8035EC78: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x8035EC7C: b           L_8035ECC8
    // 0x8035EC80: nop

        goto L_8035ECC8;
    // 0x8035EC80: nop

L_8035EC84:
    // 0x8035EC84: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8035EC88: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x8035EC8C: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8035EC90: addiu       $a3, $a3, 0x3F8C
    ctx->r7 = ADD32(ctx->r7, 0X3F8C);
    // 0x8035EC94: addiu       $a2, $a2, 0x3F70
    ctx->r6 = ADD32(ctx->r6, 0X3F70);
    // 0x8035EC98: jal         0x802DB670
    // 0x8035EC9C: addiu       $a1, $a1, 0x3F60
    ctx->r5 = ADD32(ctx->r5, 0X3F60);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_27;
    // 0x8035EC9C: addiu       $a1, $a1, 0x3F60
    ctx->r5 = ADD32(ctx->r5, 0X3F60);
    after_27:
    // 0x8035ECA0: b           L_8035ECC8
    // 0x8035ECA4: nop

        goto L_8035ECC8;
    // 0x8035ECA4: nop

L_8035ECA8:
    // 0x8035ECA8: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x8035ECAC: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x8035ECB0: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8035ECB4: addiu       $a3, $a3, 0x3FCC
    ctx->r7 = ADD32(ctx->r7, 0X3FCC);
    // 0x8035ECB8: addiu       $a2, $a2, 0x3F70
    ctx->r6 = ADD32(ctx->r6, 0X3F70);
    // 0x8035ECBC: addiu       $a1, $a1, 0x3F60
    ctx->r5 = ADD32(ctx->r5, 0X3F60);
    // 0x8035ECC0: jal         0x802DB670
    // 0x8035ECC4: addiu       $a0, $a0, 0x3F50
    ctx->r4 = ADD32(ctx->r4, 0X3F50);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_28;
    // 0x8035ECC4: addiu       $a0, $a0, 0x3F50
    ctx->r4 = ADD32(ctx->r4, 0X3F50);
    after_28:
L_8035ECC8:
    // 0x8035ECC8: jal         0x8038064C
    // 0x8035ECCC: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_29;
    // 0x8035ECCC: nop

    after_29:
    // 0x8035ECD0: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x8035ECD4: addiu       $t3, $t3, 0x4278
    ctx->r11 = ADD32(ctx->r11, 0X4278);
    // 0x8035ECD8: lw          $t2, 0x0($t3)
    ctx->r10 = MEM_W(ctx->r11, 0X0);
    // 0x8035ECDC: lui         $t5, 0x3
    ctx->r13 = S32(0X3 << 16);
    // 0x8035ECE0: ori         $t5, $t5, 0x8000
    ctx->r13 = ctx->r13 | 0X8000;
    // 0x8035ECE4: addu        $t8, $t2, $t5
    ctx->r24 = ADD32(ctx->r10, ctx->r13);
    // 0x8035ECE8: lw          $t0, 0x918($t8)
    ctx->r8 = MEM_W(ctx->r24, 0X918);
    // 0x8035ECEC: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035ECF0: addiu       $t9, $t0, 0x1E
    ctx->r25 = ADD32(ctx->r8, 0X1E);
    // 0x8035ECF4: slti        $at, $t9, 0xFA
    ctx->r1 = SIGNED(ctx->r25) < 0XFA ? 1 : 0;
    // 0x8035ECF8: beq         $at, $zero, L_8035F4A0
    if (ctx->r1 == 0) {
        // 0x8035ECFC: nop
    
            goto L_8035F4A0;
    }
    // 0x8035ECFC: nop

    // 0x8035ED00: lbu         $t7, 0x2EDA($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDA);
    // 0x8035ED04: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035ED08: beq         $t7, $zero, L_8035F4A0
    if (ctx->r15 == 0) {
        // 0x8035ED0C: nop
    
            goto L_8035F4A0;
    }
    // 0x8035ED0C: nop

    // 0x8035ED10: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x8035ED14: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8035ED18: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035ED1C: bne         $a0, $zero, L_8035ED54
    if (ctx->r4 != 0) {
        // 0x8035ED20: nop
    
            goto L_8035ED54;
    }
    // 0x8035ED20: nop

    // 0x8035ED24: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x8035ED28: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035ED2C: beq         $v0, $zero, L_8035ED54
    if (ctx->r2 == 0) {
        // 0x8035ED30: nop
    
            goto L_8035ED54;
    }
    // 0x8035ED30: nop

    // 0x8035ED34: beq         $v0, $at, L_8035ED54
    if (ctx->r2 == ctx->r1) {
        // 0x8035ED38: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_8035ED54;
    }
    // 0x8035ED38: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035ED3C: bne         $v0, $at, L_8035F4A0
    if (ctx->r2 != ctx->r1) {
        // 0x8035ED40: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_8035F4A0;
    }
    // 0x8035ED40: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035ED44: lbu         $t6, 0x2AA3($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2AA3);
    // 0x8035ED48: slti        $at, $t6, 0xB
    ctx->r1 = SIGNED(ctx->r14) < 0XB ? 1 : 0;
    // 0x8035ED4C: bne         $at, $zero, L_8035F4A0
    if (ctx->r1 != 0) {
        // 0x8035ED50: nop
    
            goto L_8035F4A0;
    }
    // 0x8035ED50: nop

L_8035ED54:
    // 0x8035ED54: lh          $t8, 0x2C18($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C18);
    // 0x8035ED58: bnel        $t8, $zero, L_8035EDB4
    if (ctx->r24 != 0) {
        // 0x8035ED5C: sll         $t9, $t0, 6
        ctx->r25 = S32(ctx->r8 << 6);
            goto L_8035EDB4;
    }
    goto skip_4;
    // 0x8035ED5C: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
    skip_4:
    // 0x8035ED60: beq         $a0, $zero, L_8035EDB0
    if (ctx->r4 == 0) {
        // 0x8035ED64: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_8035EDB0;
    }
    // 0x8035ED64: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8035ED68: lh          $t9, 0x2A98($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2A98);
    // 0x8035ED6C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035ED70: addiu       $t6, $t6, 0x28E0
    ctx->r14 = ADD32(ctx->r14, 0X28E0);
    // 0x8035ED74: sll         $t7, $t9, 3
    ctx->r15 = S32(ctx->r25 << 3);
    // 0x8035ED78: subu        $t7, $t7, $t9
    ctx->r15 = SUB32(ctx->r15, ctx->r25);
    // 0x8035ED7C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8035ED80: subu        $t7, $t7, $t9
    ctx->r15 = SUB32(ctx->r15, ctx->r25);
    // 0x8035ED84: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8035ED88: addu        $v0, $t7, $t6
    ctx->r2 = ADD32(ctx->r15, ctx->r14);
    // 0x8035ED8C: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x8035ED90: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8035ED94: beq         $v1, $at, L_8035EDA4
    if (ctx->r3 == ctx->r1) {
        // 0x8035ED98: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_8035EDA4;
    }
    // 0x8035ED98: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8035ED9C: bnel        $v1, $at, L_8035EDB4
    if (ctx->r3 != ctx->r1) {
        // 0x8035EDA0: sll         $t9, $t0, 6
        ctx->r25 = S32(ctx->r8 << 6);
            goto L_8035EDB4;
    }
    goto skip_5;
    // 0x8035EDA0: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
    skip_5:
L_8035EDA4:
    // 0x8035EDA4: lb          $t8, 0x64($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X64);
    // 0x8035EDA8: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x8035EDAC: beq         $t8, $at, L_8035F4A0
    if (ctx->r24 == ctx->r1) {
        // 0x8035EDB0: sll         $t9, $t0, 6
        ctx->r25 = S32(ctx->r8 << 6);
            goto L_8035F4A0;
    }
L_8035EDB0:
    // 0x8035EDB0: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
L_8035EDB4:
    // 0x8035EDB4: addu        $a0, $t2, $t9
    ctx->r4 = ADD32(ctx->r10, ctx->r25);
    // 0x8035EDB8: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8035EDBC: lh          $v1, 0xA0($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XA0);
    // 0x8035EDC0: lw          $t9, 0x2EB0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB0);
    // 0x8035EDC4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035EDC8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x8035EDCC: multu       $v1, $t9
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EDD0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035EDD4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035EDD8: lh          $t6, 0x302($t7)
    ctx->r14 = MEM_H(ctx->r15, 0X302);
    // 0x8035EDDC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8035EDE0: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x8035EDE4: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x8035EDE8: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x8035EDEC: negu        $t8, $t6
    ctx->r24 = SUB32(0, ctx->r14);
    // 0x8035EDF0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035EDF4: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035EDF8: lw          $t8, 0x2EB4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB4);
    // 0x8035EDFC: mflo        $t7
    ctx->r15 = lo;
    // 0x8035EE00: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8035EE04: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8035EE08: multu       $v1, $t8
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EE0C: bgez        $t7, L_8035EE1C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035EE10: sra         $t6, $t7, 2
        ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
            goto L_8035EE1C;
    }
    // 0x8035EE10: sra         $t6, $t7, 2
    ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
    // 0x8035EE14: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x8035EE18: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_8035EE1C:
    // 0x8035EE1C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8035EE20: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035EE24: lw          $t6, 0x2EB8($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB8);
    // 0x8035EE28: mflo        $t9
    ctx->r25 = lo;
    // 0x8035EE2C: bgez        $t9, L_8035EE3C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035EE30: sra         $t7, $t9, 2
        ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
            goto L_8035EE3C;
    }
    // 0x8035EE30: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8035EE34: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x8035EE38: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_8035EE3C:
    // 0x8035EE3C: multu       $v1, $t6
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EE40: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8035EE44: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035EE48: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035EE4C: lw          $t6, 0x2ED4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2ED4);
    // 0x8035EE50: lh          $t7, 0x2ED2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED2);
    // 0x8035EE54: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8035EE58: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x8035EE5C: mflo        $t8
    ctx->r24 = lo;
    // 0x8035EE60: bgez        $t8, L_8035EE70
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8035EE64: sra         $t9, $t8, 2
        ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
            goto L_8035EE70;
    }
    // 0x8035EE64: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x8035EE68: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x8035EE6C: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_8035EE70:
    // 0x8035EE70: jal         0x80127640
    // 0x8035EE74: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    func_80127640(rdram, ctx);
        goto after_30;
    // 0x8035EE74: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    after_30:
    // 0x8035EE78: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x8035EE7C: addiu       $t4, $t4, -0x6178
    ctx->r12 = ADD32(ctx->r12, -0X6178);
    // 0x8035EE80: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035EE84: lui         $t9, 0x104
    ctx->r25 = S32(0X104 << 16);
    // 0x8035EE88: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x8035EE8C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8035EE90: sw          $t8, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r24;
    // 0x8035EE94: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x8035EE98: addiu       $t3, $t3, 0x4278
    ctx->r11 = ADD32(ctx->r11, 0X4278);
    // 0x8035EE9C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8035EEA0: lw          $t2, 0x0($t3)
    ctx->r10 = MEM_W(ctx->r11, 0X0);
    // 0x8035EEA4: lui         $t5, 0x3
    ctx->r13 = S32(0X3 << 16);
    // 0x8035EEA8: ori         $t5, $t5, 0x8000
    ctx->r13 = ctx->r13 | 0X8000;
    // 0x8035EEAC: addu        $t7, $t2, $t5
    ctx->r15 = ADD32(ctx->r10, ctx->r13);
    // 0x8035EEB0: lw          $t6, 0x918($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X918);
    // 0x8035EEB4: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x8035EEB8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8035EEBC: sll         $t8, $t6, 6
    ctx->r24 = S32(ctx->r14 << 6);
    // 0x8035EEC0: addu        $t9, $t2, $t8
    ctx->r25 = ADD32(ctx->r10, ctx->r24);
    // 0x8035EEC4: addu        $t7, $t9, $at
    ctx->r15 = ADD32(ctx->r25, ctx->r1);
    // 0x8035EEC8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8035EECC: lw          $t2, 0x0($t3)
    ctx->r10 = MEM_W(ctx->r11, 0X0);
    // 0x8035EED0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8035EED4: addiu       $ra, $zero, 0x34
    ctx->r31 = ADD32(0, 0X34);
    // 0x8035EED8: addu        $t6, $t2, $t5
    ctx->r14 = ADD32(ctx->r10, ctx->r13);
    // 0x8035EEDC: lw          $t8, 0x918($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X918);
    // 0x8035EEE0: addu        $at, $at, $t2
    ctx->r1 = ADD32(ctx->r1, ctx->r10);
    // 0x8035EEE4: lui         $t6, 0x600
    ctx->r14 = S32(0X600 << 16);
    // 0x8035EEE8: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8035EEEC: sw          $t9, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r25;
    // 0x8035EEF0: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035EEF4: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8035EEF8: addiu       $t8, $t8, 0x3548
    ctx->r24 = ADD32(ctx->r24, 0X3548);
    // 0x8035EEFC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8035EF00: sw          $t7, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r15;
    // 0x8035EF04: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8035EF08: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8035EF0C: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035EF10: lui         $t6, 0xFF80
    ctx->r14 = S32(0XFF80 << 16);
    // 0x8035EF14: ori         $t6, $t6, 0x80FF
    ctx->r14 = ctx->r14 | 0X80FF;
    // 0x8035EF18: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8035EF1C: sw          $t9, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r25;
    // 0x8035EF20: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8035EF24: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035EF28: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8035EF2C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8035EF30: lw          $t8, 0x2EBC($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EBC);
    // 0x8035EF34: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035EF38: lw          $t7, 0x2EC0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EC0);
    // 0x8035EF3C: multu       $t8, $ra
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r31)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EF40: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035EF44: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x8035EF48: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035EF4C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035EF50: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035EF54: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8035EF58: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8035EF5C: mflo        $a2
    ctx->r6 = lo;
    // 0x8035EF60: sra         $t9, $a2, 6
    ctx->r25 = S32(SIGNED(ctx->r6) >> 6);
    // 0x8035EF64: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x8035EF68: multu       $t7, $ra
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r31)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EF6C: mflo        $a3
    ctx->r7 = lo;
    // 0x8035EF70: sra         $t6, $a3, 6
    ctx->r14 = S32(SIGNED(ctx->r7) >> 6);
    // 0x8035EF74: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8035EF78: multu       $t8, $ra
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r31)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035EF7C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035EF80: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8035EF84: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x8035EF88: addiu       $t8, $t8, 0x7080
    ctx->r24 = ADD32(ctx->r24, 0X7080);
    // 0x8035EF8C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8035EF90: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8035EF94: mflo        $t9
    ctx->r25 = lo;
    // 0x8035EF98: sra         $t7, $t9, 6
    ctx->r15 = S32(SIGNED(ctx->r25) >> 6);
    // 0x8035EF9C: jal         0x802C78B0
    // 0x8035EFA0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x8035EFA0: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    after_31:
    // 0x8035EFA4: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x8035EFA8: addiu       $t4, $t4, -0x6178
    ctx->r12 = ADD32(ctx->r12, -0X6178);
    // 0x8035EFAC: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035EFB0: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x8035EFB4: addiu       $t6, $t6, 0x3618
    ctx->r14 = ADD32(ctx->r14, 0X3618);
    // 0x8035EFB8: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8035EFBC: sw          $t9, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r25;
    // 0x8035EFC0: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8035EFC4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8035EFC8: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8035EFCC: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035EFD0: lui         $t7, 0x1414
    ctx->r15 = S32(0X1414 << 16);
    // 0x8035EFD4: ori         $t7, $t7, 0x14FF
    ctx->r15 = ctx->r15 | 0X14FF;
    // 0x8035EFD8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8035EFDC: sw          $t8, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r24;
    // 0x8035EFE0: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8035EFE4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035EFE8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8035EFEC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8035EFF0: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
    // 0x8035EFF4: bne         $a1, $zero, L_8035F040
    if (ctx->r5 != 0) {
        // 0x8035EFF8: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_8035F040;
    }
    // 0x8035EFF8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035EFFC: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x8035F000: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x8035F004: addiu       $t9, $t9, 0x72F0
    ctx->r25 = ADD32(ctx->r25, 0X72F0);
    // 0x8035F008: ori         $t6, $zero, 0xD000
    ctx->r14 = 0 | 0XD000;
    // 0x8035F00C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8035F010: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8035F014: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x8035F018: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x8035F01C: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F020: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F024: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F028: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F02C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F030: jal         0x802C78B0
    // 0x8035F034: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_32;
    // 0x8035F034: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_32:
    // 0x8035F038: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035F03C: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_8035F040:
    // 0x8035F040: bne         $a1, $zero, L_8035F08C
    if (ctx->r5 != 0) {
        // 0x8035F044: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_8035F08C;
    }
    // 0x8035F044: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035F048: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8035F04C: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x8035F050: addiu       $t8, $t8, 0x72F0
    ctx->r24 = ADD32(ctx->r24, 0X72F0);
    // 0x8035F054: ori         $t7, $zero, 0xD000
    ctx->r15 = 0 | 0XD000;
    // 0x8035F058: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035F05C: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8035F060: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x8035F064: addiu       $a1, $zero, 0xB
    ctx->r5 = ADD32(0, 0XB);
    // 0x8035F068: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F06C: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F070: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F074: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F078: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F07C: jal         0x802C78B0
    // 0x8035F080: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_33;
    // 0x8035F080: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_33:
    // 0x8035F084: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035F088: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_8035F08C:
    // 0x8035F08C: bne         $a1, $zero, L_8035F0D8
    if (ctx->r5 != 0) {
        // 0x8035F090: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_8035F0D8;
    }
    // 0x8035F090: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035F094: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8035F098: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x8035F09C: addiu       $t6, $t6, 0x72F0
    ctx->r14 = ADD32(ctx->r14, 0X72F0);
    // 0x8035F0A0: ori         $t9, $zero, 0xD000
    ctx->r25 = 0 | 0XD000;
    // 0x8035F0A4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8035F0A8: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8035F0AC: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    // 0x8035F0B0: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x8035F0B4: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F0B8: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F0BC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F0C0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F0C4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F0C8: jal         0x802C78B0
    // 0x8035F0CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_34;
    // 0x8035F0CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_34:
    // 0x8035F0D0: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x8035F0D4: lbu         $a1, 0x2EDD($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X2EDD);
L_8035F0D8:
    // 0x8035F0D8: bne         $a1, $zero, L_8035F11C
    if (ctx->r5 != 0) {
        // 0x8035F0DC: addiu       $a0, $zero, 0x10
        ctx->r4 = ADD32(0, 0X10);
            goto L_8035F11C;
    }
    // 0x8035F0DC: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8035F0E0: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8035F0E4: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x8035F0E8: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x8035F0EC: addiu       $t7, $t7, 0x72F0
    ctx->r15 = ADD32(ctx->r15, 0X72F0);
    // 0x8035F0F0: ori         $t8, $zero, 0xD000
    ctx->r24 = 0 | 0XD000;
    // 0x8035F0F4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035F0F8: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8035F0FC: addiu       $a1, $zero, 0x11
    ctx->r5 = ADD32(0, 0X11);
    // 0x8035F100: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F104: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F108: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F10C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F110: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F114: jal         0x802C78B0
    // 0x8035F118: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_35;
    // 0x8035F118: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_35:
L_8035F11C:
    // 0x8035F11C: lh          $t6, 0xA0($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F120: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035F124: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8035F128: bne         $t6, $at, L_8035F168
    if (ctx->r14 != ctx->r1) {
        // 0x8035F12C: addiu       $a1, $zero, 0x1
        ctx->r5 = ADD32(0, 0X1);
            goto L_8035F168;
    }
    // 0x8035F12C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8035F130: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8035F134: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x8035F138: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x8035F13C: addiu       $t7, $t7, 0x7520
    ctx->r15 = ADD32(ctx->r15, 0X7520);
    // 0x8035F140: ori         $t8, $zero, 0xD000
    ctx->r24 = 0 | 0XD000;
    // 0x8035F144: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035F148: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8035F14C: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F150: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F154: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F158: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F15C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F160: jal         0x802C78B0
    // 0x8035F164: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_36;
    // 0x8035F164: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_36:
L_8035F168:
    // 0x8035F168: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F16C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035F170: addiu       $a1, $sp, 0xA6
    ctx->r5 = ADD32(ctx->r29, 0XA6);
    // 0x8035F174: addiu       $a2, $sp, 0xA4
    ctx->r6 = ADD32(ctx->r29, 0XA4);
    // 0x8035F178: lh          $a0, 0x326($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X326);
    // 0x8035F17C: addiu       $t6, $a0, 0x1
    ctx->r14 = ADD32(ctx->r4, 0X1);
    // 0x8035F180: jal         0x8031A150
    // 0x8035F184: sh          $t6, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r14;
    func_8031A150_72B800(rdram, ctx);
        goto after_37;
    // 0x8035F184: sh          $t6, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r14;
    after_37:
    // 0x8035F188: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035F18C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8035F190: addiu       $a1, $sp, 0xA6
    ctx->r5 = ADD32(ctx->r29, 0XA6);
    // 0x8035F194: addiu       $a2, $sp, 0xA4
    ctx->r6 = ADD32(ctx->r29, 0XA4);
    // 0x8035F198: jal         0x8031A278
    // 0x8035F19C: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_38;
    // 0x8035F19C: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_38:
    // 0x8035F1A0: lh          $t8, 0xA6($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XA6);
    // 0x8035F1A4: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x8035F1A8: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035F1AC: beq         $t8, $at, L_8035F1D8
    if (ctx->r24 == ctx->r1) {
        // 0x8035F1B0: addiu       $t4, $t4, -0x6178
        ctx->r12 = ADD32(ctx->r12, -0X6178);
            goto L_8035F1D8;
    }
    // 0x8035F1B0: addiu       $t4, $t4, -0x6178
    ctx->r12 = ADD32(ctx->r12, -0X6178);
    // 0x8035F1B4: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035F1B8: lui         $t6, 0xFF00
    ctx->r14 = S32(0XFF00 << 16);
    // 0x8035F1BC: ori         $t6, $t6, 0xFF
    ctx->r14 = ctx->r14 | 0XFF;
    // 0x8035F1C0: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8035F1C4: sw          $t9, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r25;
    // 0x8035F1C8: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x8035F1CC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8035F1D0: b           L_8035F1F8
    // 0x8035F1D4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
        goto L_8035F1F8;
    // 0x8035F1D4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
L_8035F1D8:
    // 0x8035F1D8: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    // 0x8035F1DC: lui         $t7, 0x9B00
    ctx->r15 = S32(0X9B00 << 16);
    // 0x8035F1E0: ori         $t7, $t7, 0xFF
    ctx->r15 = ctx->r15 | 0XFF;
    // 0x8035F1E4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8035F1E8: sw          $t8, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r24;
    // 0x8035F1EC: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8035F1F0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8035F1F4: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
L_8035F1F8:
    // 0x8035F1F8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035F1FC: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x8035F200: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x8035F204: addiu       $t9, $t9, 0x73B0
    ctx->r25 = ADD32(ctx->r25, 0X73B0);
    // 0x8035F208: ori         $t6, $zero, 0xD000
    ctx->r14 = 0 | 0XD000;
    // 0x8035F20C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8035F210: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8035F214: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8035F218: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8035F21C: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F220: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F224: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F228: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F22C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F230: jal         0x802C78B0
    // 0x8035F234: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_39;
    // 0x8035F234: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_39:
    // 0x8035F238: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8035F23C: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8035F240: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x8035F244: addiu       $t8, $t8, 0x73D8
    ctx->r24 = ADD32(ctx->r24, 0X73D8);
    // 0x8035F248: ori         $t7, $zero, 0xD000
    ctx->r15 = 0 | 0XD000;
    // 0x8035F24C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035F250: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8035F254: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8035F258: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8035F25C: ori         $a2, $zero, 0xD000
    ctx->r6 = 0 | 0XD000;
    // 0x8035F260: ori         $a3, $zero, 0xD000
    ctx->r7 = 0 | 0XD000;
    // 0x8035F264: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F268: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8035F26C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F270: jal         0x802C78B0
    // 0x8035F274: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_40;
    // 0x8035F274: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_40:
    // 0x8035F278: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x8035F27C: lh          $a3, 0x3FEC($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X3FEC);
    // 0x8035F280: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x8035F284: addiu       $t4, $t4, -0x6178
    ctx->r12 = ADD32(ctx->r12, -0X6178);
    // 0x8035F288: sll         $t9, $a3, 15
    ctx->r25 = S32(ctx->r7 << 15);
    // 0x8035F28C: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8035F290: bgez        $a3, L_8035F2A0
    if (SIGNED(ctx->r7) >= 0) {
        // 0x8035F294: sra         $t7, $a3, 4
        ctx->r15 = S32(SIGNED(ctx->r7) >> 4);
            goto L_8035F2A0;
    }
    // 0x8035F294: sra         $t7, $a3, 4
    ctx->r15 = S32(SIGNED(ctx->r7) >> 4);
    // 0x8035F298: addiu       $at, $a3, 0xF
    ctx->r1 = ADD32(ctx->r7, 0XF);
    // 0x8035F29C: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_8035F2A0:
    // 0x8035F2A0: lui         $at, 0xFFEA
    ctx->r1 = S32(0XFFEA << 16);
    // 0x8035F2A4: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x8035F2A8: addu        $a3, $t6, $at
    ctx->r7 = ADD32(ctx->r14, ctx->r1);
    // 0x8035F2AC: sra         $v0, $a3, 10
    ctx->r2 = S32(SIGNED(ctx->r7) >> 10);
    // 0x8035F2B0: bgez        $v0, L_8035F2C0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8035F2B4: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_8035F2C0;
    }
    // 0x8035F2B4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035F2B8: b           L_8035F2C4
    // 0x8035F2BC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_8035F2C4;
    // 0x8035F2BC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_8035F2C0:
    // 0x8035F2C0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_8035F2C4:
    // 0x8035F2C4: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8035F2C8: lui         $a2, 0x8015
    ctx->r6 = S32(0X8015 << 16);
    // 0x8035F2CC: addiu       $ra, $zero, 0xE00
    ctx->r31 = ADD32(0, 0XE00);
    // 0x8035F2D0: lh          $t0, 0x302($t8)
    ctx->r8 = MEM_H(ctx->r24, 0X302);
    // 0x8035F2D4: subu        $t8, $ra, $v1
    ctx->r24 = SUB32(ctx->r31, ctx->r3);
    // 0x8035F2D8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8035F2DC: andi        $t9, $t0, 0xFF
    ctx->r25 = ctx->r8 & 0XFF;
    // 0x8035F2E0: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8035F2E4: addu        $a2, $a2, $t7
    ctx->r6 = ADD32(ctx->r6, ctx->r15);
    // 0x8035F2E8: lh          $a2, 0x2C78($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X2C78);
    // 0x8035F2EC: lh          $t7, 0xA0($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F2F0: lw          $a1, 0x5530($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X5530);
    // 0x8035F2F4: sra         $t6, $a2, 7
    ctx->r14 = S32(SIGNED(ctx->r6) >> 7);
    // 0x8035F2F8: multu       $t6, $t8
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F2FC: lw          $t8, 0x4($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X4);
    // 0x8035F300: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x8035F304: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x8035F308: mflo        $t9
    ctx->r25 = lo;
    // 0x8035F30C: nop

    // 0x8035F310: nop

    // 0x8035F314: multu       $t9, $t7
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F318: addiu       $t9, $t0, 0x40
    ctx->r25 = ADD32(ctx->r8, 0X40);
    // 0x8035F31C: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x8035F320: mflo        $t6
    ctx->r14 = lo;
    // 0x8035F324: addu        $t5, $t6, $t8
    ctx->r13 = ADD32(ctx->r14, ctx->r24);
    // 0x8035F328: bgez        $v0, L_8035F338
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8035F32C: sll         $t6, $t7, 1
        ctx->r14 = S32(ctx->r15 << 1);
            goto L_8035F338;
    }
    // 0x8035F32C: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x8035F330: b           L_8035F338
    // 0x8035F334: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_8035F338;
    // 0x8035F334: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_8035F338:
    // 0x8035F338: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8035F33C: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x8035F340: lh          $v0, 0x2C78($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2C78);
    // 0x8035F344: subu        $t9, $ra, $v1
    ctx->r25 = SUB32(ctx->r31, ctx->r3);
    // 0x8035F348: lh          $t6, 0xA0($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F34C: sra         $t8, $v0, 7
    ctx->r24 = S32(SIGNED(ctx->r2) >> 7);
    // 0x8035F350: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F354: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x8035F358: lw          $t9, 0x8($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X8);
    // 0x8035F35C: sll         $a0, $t6, 2
    ctx->r4 = S32(ctx->r14 << 2);
    // 0x8035F360: subu        $a0, $a0, $t6
    ctx->r4 = SUB32(ctx->r4, ctx->r14);
    // 0x8035F364: sll         $a0, $a0, 8
    ctx->r4 = S32(ctx->r4 << 8);
    // 0x8035F368: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035F36C: mflo        $t7
    ctx->r15 = lo;
    // 0x8035F370: nop

    // 0x8035F374: nop

    // 0x8035F378: multu       $t7, $t6
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F37C: lw          $t7, 0xC($a1)
    ctx->r15 = MEM_W(ctx->r5, 0XC);
    // 0x8035F380: mflo        $t8
    ctx->r24 = lo;
    // 0x8035F384: addu        $t1, $t8, $t9
    ctx->r9 = ADD32(ctx->r24, ctx->r25);
    // 0x8035F388: sll         $t8, $t6, 3
    ctx->r24 = S32(ctx->r14 << 3);
    // 0x8035F38C: multu       $t6, $a3
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F390: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x8035F394: sll         $t8, $t8, 16
    ctx->r24 = S32(ctx->r24 << 16);
    // 0x8035F398: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x8035F39C: mflo        $t7
    ctx->r15 = lo;
    // 0x8035F3A0: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x8035F3A4: lh          $t9, 0xA6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA6);
    // 0x8035F3A8: multu       $v0, $a0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F3AC: sw          $t8, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r24;
    // 0x8035F3B0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8035F3B4: mflo        $t2
    ctx->r10 = lo;
    // 0x8035F3B8: nop

    // 0x8035F3BC: nop

    // 0x8035F3C0: multu       $a2, $a0
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F3C4: mflo        $t3
    ctx->r11 = lo;
    // 0x8035F3C8: negu        $t3, $t3
    ctx->r11 = SUB32(0, ctx->r11);
    // 0x8035F3CC: beql        $t9, $at, L_8035F48C
    if (ctx->r25 == ctx->r1) {
        // 0x8035F3D0: lw          $v0, 0x0($t4)
        ctx->r2 = MEM_W(ctx->r12, 0X0);
            goto L_8035F48C;
    }
    goto skip_6;
    // 0x8035F3D0: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
    skip_6:
    // 0x8035F3D4: lbu         $t7, 0x2AA2($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2AA2);
    // 0x8035F3D8: addu        $a0, $t5, $t2
    ctx->r4 = ADD32(ctx->r13, ctx->r10);
    // 0x8035F3DC: addu        $a1, $t1, $t3
    ctx->r5 = ADD32(ctx->r9, ctx->r11);
    // 0x8035F3E0: bne         $t7, $zero, L_8035F488
    if (ctx->r15 != 0) {
        // 0x8035F3E4: or          $a2, $t8, $zero
        ctx->r6 = ctx->r24 | 0;
            goto L_8035F488;
    }
    // 0x8035F3E4: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x8035F3E8: sll         $a3, $t6, 9
    ctx->r7 = S32(ctx->r14 << 9);
    // 0x8035F3EC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035F3F0: addiu       $t8, $t8, 0x2E08
    ctx->r24 = ADD32(ctx->r24, 0X2E08);
    // 0x8035F3F4: andi        $t9, $a3, 0xFFFF
    ctx->r25 = ctx->r7 & 0XFFFF;
    // 0x8035F3F8: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x8035F3FC: addiu       $t7, $zero, 0x23
    ctx->r15 = ADD32(0, 0X23);
    // 0x8035F400: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035F404: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8035F408: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x8035F40C: sw          $t9, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r25;
    // 0x8035F410: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8035F414: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F418: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F41C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8035F420: sw          $t1, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r9;
    // 0x8035F424: sw          $t2, 0xB8($sp)
    MEM_W(0XB8, ctx->r29) = ctx->r10;
    // 0x8035F428: sw          $t3, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->r11;
    // 0x8035F42C: jal         0x8029CEF0
    // 0x8035F430: sw          $t5, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r13;
    enqueue_dynamic_texture_billboard_6AE5A0(rdram, ctx);
        goto after_41;
    // 0x8035F430: sw          $t5, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r13;
    after_41:
    // 0x8035F434: lw          $t1, 0xC0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XC0);
    // 0x8035F438: lw          $t2, 0xB8($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB8);
    // 0x8035F43C: lw          $t3, 0xB4($sp)
    ctx->r11 = MEM_W(ctx->r29, 0XB4);
    // 0x8035F440: lw          $t5, 0xC4($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XC4);
    // 0x8035F444: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035F448: addiu       $t7, $t7, 0x2E08
    ctx->r15 = ADD32(ctx->r15, 0X2E08);
    // 0x8035F44C: addiu       $t9, $zero, 0x23
    ctx->r25 = ADD32(0, 0X23);
    // 0x8035F450: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x8035F454: lw          $a3, 0x5C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X5C);
    // 0x8035F458: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8035F45C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8035F460: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8035F464: lw          $a2, 0xBC($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XBC);
    // 0x8035F468: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8035F46C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F470: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8035F474: subu        $a1, $t1, $t3
    ctx->r5 = SUB32(ctx->r9, ctx->r11);
    // 0x8035F478: jal         0x8029CEF0
    // 0x8035F47C: subu        $a0, $t5, $t2
    ctx->r4 = SUB32(ctx->r13, ctx->r10);
    enqueue_dynamic_texture_billboard_6AE5A0(rdram, ctx);
        goto after_42;
    // 0x8035F47C: subu        $a0, $t5, $t2
    ctx->r4 = SUB32(ctx->r13, ctx->r10);
    after_42:
    // 0x8035F480: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x8035F484: addiu       $t4, $t4, -0x6178
    ctx->r12 = ADD32(ctx->r12, -0X6178);
L_8035F488:
    // 0x8035F488: lw          $v0, 0x0($t4)
    ctx->r2 = MEM_W(ctx->r12, 0X0);
L_8035F48C:
    // 0x8035F48C: lui         $t9, 0xBD00
    ctx->r25 = S32(0XBD00 << 16);
    // 0x8035F490: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8035F494: sw          $t6, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r14;
    // 0x8035F498: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8035F49C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
L_8035F4A0:
    // 0x8035F4A0: jal         0x8035D6A0
    // 0x8035F4A4: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_43;
    // 0x8035F4A4: nop

    after_43:
    // 0x8035F4A8: b           L_8035F4BC
    // 0x8035F4AC: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
        goto L_8035F4BC;
    // 0x8035F4AC: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
L_8035F4B0:
    // 0x8035F4B0: jal         0x8035D6D0
    // 0x8035F4B4: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_44;
    // 0x8035F4B4: nop

    after_44:
    // 0x8035F4B8: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
L_8035F4BC:
    // 0x8035F4BC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8035F4C0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F4C4: beq         $t5, $zero, L_8035F4D4
    if (ctx->r13 == 0) {
        // 0x8035F4C8: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_8035F4D4;
    }
    // 0x8035F4C8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8035F4CC: bne         $t5, $at, L_8035F598
    if (ctx->r13 != ctx->r1) {
        // 0x8035F4D0: nop
    
            goto L_8035F598;
    }
    // 0x8035F4D0: nop

L_8035F4D4:
    // 0x8035F4D4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035F4D8: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x8035F4DC: lh          $t7, 0xC($v0)
    ctx->r15 = MEM_H(ctx->r2, 0XC);
    // 0x8035F4E0: lhu         $t6, 0xBA($t8)
    ctx->r14 = MEM_HU(ctx->r24, 0XBA);
    // 0x8035F4E4: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8035F4E8: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x8035F4EC: addu        $a2, $t7, $t6
    ctx->r6 = ADD32(ctx->r15, ctx->r14);
    // 0x8035F4F0: lh          $t6, 0xA0($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F4F4: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x8035F4F8: sra         $t8, $t9, 16
    ctx->r24 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8035F4FC: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x8035F500: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x8035F504: sll         $t9, $t9, 4
    ctx->r25 = S32(ctx->r25 << 4);
    // 0x8035F508: lui         $t7, 0x103
    ctx->r15 = S32(0X103 << 16);
    // 0x8035F50C: addiu       $t7, $t7, 0x3190
    ctx->r15 = ADD32(ctx->r15, 0X3190);
    // 0x8035F510: lh          $a3, 0x302($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X302);
    // 0x8035F514: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x8035F518: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8035F51C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035F520: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8035F524: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x8035F528: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x8035F52C: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x8035F530: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8035F534: bgez        $t9, L_8035F544
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035F538: sra         $t8, $t9, 5
        ctx->r24 = S32(SIGNED(ctx->r25) >> 5);
            goto L_8035F544;
    }
    // 0x8035F538: sra         $t8, $t9, 5
    ctx->r24 = S32(SIGNED(ctx->r25) >> 5);
    // 0x8035F53C: addiu       $at, $t9, 0x1F
    ctx->r1 = ADD32(ctx->r25, 0X1F);
    // 0x8035F540: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_8035F544:
    // 0x8035F544: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8035F548: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8035F54C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8035F550: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8035F554: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F558: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x8035F55C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8035F560: addiu       $t8, $zero, 0x9B
    ctx->r24 = ADD32(0, 0X9B);
    // 0x8035F564: bgez        $t7, L_8035F574
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035F568: sra         $t9, $t7, 5
        ctx->r25 = S32(SIGNED(ctx->r15) >> 5);
            goto L_8035F574;
    }
    // 0x8035F568: sra         $t9, $t7, 5
    ctx->r25 = S32(SIGNED(ctx->r15) >> 5);
    // 0x8035F56C: addiu       $at, $t7, 0x1F
    ctx->r1 = ADD32(ctx->r15, 0X1F);
    // 0x8035F570: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_8035F574:
    // 0x8035F574: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8035F578: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8035F57C: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x8035F580: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x8035F584: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8035F588: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8035F58C: jal         0x8034BD20
    // 0x8035F590: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_45;
    // 0x8035F590: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    after_45:
    // 0x8035F594: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
L_8035F598:
    // 0x8035F598: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035F59C: lw          $t7, 0x5528($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5528);
    // 0x8035F5A0: lh          $a0, 0x3CA($t7)
    ctx->r4 = MEM_H(ctx->r15, 0X3CA);
    // 0x8035F5A4: sh          $a0, 0xD6($sp)
    MEM_H(0XD6, ctx->r29) = ctx->r4;
    // 0x8035F5A8: lh          $t9, 0xD6($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XD6);
    // 0x8035F5AC: beq         $t9, $zero, L_8035F7D0
    if (ctx->r25 == 0) {
        // 0x8035F5B0: nop
    
            goto L_8035F7D0;
    }
    // 0x8035F5B0: nop

    // 0x8035F5B4: bne         $t5, $zero, L_8035F7B4
    if (ctx->r13 != 0) {
        // 0x8035F5B8: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_8035F7B4;
    }
    // 0x8035F5B8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8035F5BC: lbu         $t8, 0x2EDB($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X2EDB);
    // 0x8035F5C0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x8035F5C4: addiu       $t4, $t4, 0x3FE0
    ctx->r12 = ADD32(ctx->r12, 0X3FE0);
    // 0x8035F5C8: beql        $t8, $zero, L_8035F7B8
    if (ctx->r24 == 0) {
        // 0x8035F5CC: sll         $t7, $a0, 3
        ctx->r15 = S32(ctx->r4 << 3);
            goto L_8035F7B8;
    }
    goto skip_7;
    // 0x8035F5CC: sll         $t7, $a0, 3
    ctx->r15 = S32(ctx->r4 << 3);
    skip_7:
    // 0x8035F5D0: lh          $t6, 0x12($t4)
    ctx->r14 = MEM_H(ctx->r12, 0X12);
    // 0x8035F5D4: lh          $t8, 0xA0($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F5D8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F5DC: addiu       $t7, $t6, -0xCB
    ctx->r15 = ADD32(ctx->r14, -0XCB);
    // 0x8035F5E0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F5E4: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x8035F5E8: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F5EC: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035F5F0: lh          $t0, 0x302($t6)
    ctx->r8 = MEM_H(ctx->r14, 0X302);
    // 0x8035F5F4: lh          $t3, 0x10($t4)
    ctx->r11 = MEM_H(ctx->r12, 0X10);
    // 0x8035F5F8: andi        $t7, $t0, 0xFF
    ctx->r15 = ctx->r8 & 0XFF;
    // 0x8035F5FC: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x8035F600: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x8035F604: addiu       $t7, $t7, 0x2C78
    ctx->r15 = ADD32(ctx->r15, 0X2C78);
    // 0x8035F608: addu        $t6, $t6, $t7
    ctx->r14 = ADD32(ctx->r14, ctx->r15);
    // 0x8035F60C: lh          $v1, 0x0($t6)
    ctx->r3 = MEM_H(ctx->r14, 0X0);
    // 0x8035F610: mflo        $t2
    ctx->r10 = lo;
    // 0x8035F614: sw          $t9, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r25;
    // 0x8035F618: addiu       $t6, $t0, 0x40
    ctx->r14 = ADD32(ctx->r8, 0X40);
    // 0x8035F61C: multu       $t2, $v1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F620: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8035F624: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x8035F628: addu        $t6, $t9, $t7
    ctx->r14 = ADD32(ctx->r25, ctx->r15);
    // 0x8035F62C: lh          $t1, 0x0($t6)
    ctx->r9 = MEM_H(ctx->r14, 0X0);
    // 0x8035F630: lw          $t6, 0x4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X4);
    // 0x8035F634: lw          $a0, 0x40($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X40);
    // 0x8035F638: mflo        $t9
    ctx->r25 = lo;
    // 0x8035F63C: bgez        $t9, L_8035F64C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035F640: sra         $t7, $t9, 4
        ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
            goto L_8035F64C;
    }
    // 0x8035F640: sra         $t7, $t9, 4
    ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
    // 0x8035F644: addiu       $at, $t9, 0xF
    ctx->r1 = ADD32(ctx->r25, 0XF);
    // 0x8035F648: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_8035F64C:
    // 0x8035F64C: multu       $t1, $t8
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F650: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x8035F654: mflo        $t7
    ctx->r15 = lo;
    // 0x8035F658: nop

    // 0x8035F65C: nop

    // 0x8035F660: multu       $t7, $t3
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F664: mflo        $t6
    ctx->r14 = lo;
    // 0x8035F668: bgez        $t6, L_8035F678
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8035F66C: sra         $t7, $t6, 4
        ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
            goto L_8035F678;
    }
    // 0x8035F66C: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x8035F670: addiu       $at, $t6, 0xF
    ctx->r1 = ADD32(ctx->r14, 0XF);
    // 0x8035F674: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_8035F678:
    // 0x8035F678: multu       $t1, $t2
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F67C: addu        $a1, $t9, $t7
    ctx->r5 = ADD32(ctx->r25, ctx->r15);
    // 0x8035F680: lw          $t6, 0x8($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X8);
    // 0x8035F684: mflo        $t9
    ctx->r25 = lo;
    // 0x8035F688: bgez        $t9, L_8035F698
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8035F68C: sra         $t7, $t9, 4
        ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
            goto L_8035F698;
    }
    // 0x8035F68C: sra         $t7, $t9, 4
    ctx->r15 = S32(SIGNED(ctx->r25) >> 4);
    // 0x8035F690: addiu       $at, $t9, 0xF
    ctx->r1 = ADD32(ctx->r25, 0XF);
    // 0x8035F694: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_8035F698:
    // 0x8035F698: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F69C: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x8035F6A0: mflo        $t6
    ctx->r14 = lo;
    // 0x8035F6A4: nop

    // 0x8035F6A8: nop

    // 0x8035F6AC: multu       $t6, $t8
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F6B0: mflo        $t7
    ctx->r15 = lo;
    // 0x8035F6B4: bgez        $t7, L_8035F6C4
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8035F6B8: sra         $t6, $t7, 4
        ctx->r14 = S32(SIGNED(ctx->r15) >> 4);
            goto L_8035F6C4;
    }
    // 0x8035F6B8: sra         $t6, $t7, 4
    ctx->r14 = S32(SIGNED(ctx->r15) >> 4);
    // 0x8035F6BC: addiu       $at, $t7, 0xF
    ctx->r1 = ADD32(ctx->r15, 0XF);
    // 0x8035F6C0: sra         $t6, $at, 4
    ctx->r14 = S32(SIGNED(ctx->r1) >> 4);
L_8035F6C4:
    // 0x8035F6C4: lh          $t7, 0x14($t4)
    ctx->r15 = MEM_H(ctx->r12, 0X14);
    // 0x8035F6C8: subu        $a2, $t9, $t6
    ctx->r6 = SUB32(ctx->r25, ctx->r14);
    // 0x8035F6CC: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F6D0: lw          $t8, 0xC($v0)
    ctx->r24 = MEM_W(ctx->r2, 0XC);
    // 0x8035F6D4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8035F6D8: mflo        $t9
    ctx->r25 = lo;
    // 0x8035F6DC: sll         $t6, $t9, 15
    ctx->r14 = S32(ctx->r25 << 15);
    // 0x8035F6E0: bgez        $t6, L_8035F6F0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x8035F6E4: sra         $t7, $t6, 4
        ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
            goto L_8035F6F0;
    }
    // 0x8035F6E4: sra         $t7, $t6, 4
    ctx->r15 = S32(SIGNED(ctx->r14) >> 4);
    // 0x8035F6E8: addiu       $at, $t6, 0xF
    ctx->r1 = ADD32(ctx->r14, 0XF);
    // 0x8035F6EC: sra         $t7, $at, 4
    ctx->r15 = S32(SIGNED(ctx->r1) >> 4);
L_8035F6F0:
    // 0x8035F6F0: jal         0x802DE914
    // 0x8035F6F4: addu        $a3, $t7, $t8
    ctx->r7 = ADD32(ctx->r15, ctx->r24);
    func_802DE914_6EFFC4(rdram, ctx);
        goto after_46;
    // 0x8035F6F4: addu        $a3, $t7, $t8
    ctx->r7 = ADD32(ctx->r15, ctx->r24);
    after_46:
    // 0x8035F6F8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F6FC: lw          $t6, 0x5528($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5528);
    // 0x8035F700: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x8035F704: addiu       $t8, $t8, 0xC0
    ctx->r24 = ADD32(ctx->r24, 0XC0);
    // 0x8035F708: lh          $a0, 0x3CA($t6)
    ctx->r4 = MEM_H(ctx->r14, 0X3CA);
    // 0x8035F70C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035F710: sll         $t7, $a0, 3
    ctx->r15 = S32(ctx->r4 << 3);
    // 0x8035F714: subu        $t7, $t7, $a0
    ctx->r15 = SUB32(ctx->r15, ctx->r4);
    // 0x8035F718: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8035F71C: addu        $v0, $t7, $t8
    ctx->r2 = ADD32(ctx->r15, ctx->r24);
    // 0x8035F720: lb          $t9, 0x34($v0)
    ctx->r25 = MEM_B(ctx->r2, 0X34);
    // 0x8035F724: bnel        $t9, $at, L_8035F7AC
    if (ctx->r25 != ctx->r1) {
        // 0x8035F728: sb          $zero, 0x34($v0)
        MEM_B(0X34, ctx->r2) = 0;
            goto L_8035F7AC;
    }
    goto skip_8;
    // 0x8035F728: sb          $zero, 0x34($v0)
    MEM_B(0X34, ctx->r2) = 0;
    skip_8:
    // 0x8035F72C: lb          $v1, 0x2E($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X2E);
    // 0x8035F730: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8035F734: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x8035F738: beq         $v1, $at, L_8035F748
    if (ctx->r3 == ctx->r1) {
        // 0x8035F73C: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_8035F748;
    }
    // 0x8035F73C: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8035F740: bne         $v1, $at, L_8035F778
    if (ctx->r3 != ctx->r1) {
        // 0x8035F744: nop
    
            goto L_8035F778;
    }
    // 0x8035F744: nop

L_8035F748:
    // 0x8035F748: jal         0x802DD244
    // 0x8035F74C: addiu       $a1, $a1, 0x3B4C
    ctx->r5 = ADD32(ctx->r5, 0X3B4C);
    func_802DD244_6EE8F4(rdram, ctx);
        goto after_47;
    // 0x8035F74C: addiu       $a1, $a1, 0x3B4C
    ctx->r5 = ADD32(ctx->r5, 0X3B4C);
    after_47:
    // 0x8035F750: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F754: lw          $t6, 0x5528($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5528);
    // 0x8035F758: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x8035F75C: addiu       $t9, $t9, 0xC0
    ctx->r25 = ADD32(ctx->r25, 0XC0);
    // 0x8035F760: lh          $t7, 0x3CA($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X3CA);
    // 0x8035F764: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x8035F768: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x8035F76C: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x8035F770: b           L_8035F7A8
    // 0x8035F774: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
        goto L_8035F7A8;
    // 0x8035F774: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
L_8035F778:
    // 0x8035F778: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x8035F77C: jal         0x802DD244
    // 0x8035F780: addiu       $a1, $a1, 0x3BAC
    ctx->r5 = ADD32(ctx->r5, 0X3BAC);
    func_802DD244_6EE8F4(rdram, ctx);
        goto after_48;
    // 0x8035F780: addiu       $a1, $a1, 0x3BAC
    ctx->r5 = ADD32(ctx->r5, 0X3BAC);
    after_48:
    // 0x8035F784: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F788: lw          $t6, 0x5528($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5528);
    // 0x8035F78C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x8035F790: addiu       $t9, $t9, 0xC0
    ctx->r25 = ADD32(ctx->r25, 0XC0);
    // 0x8035F794: lh          $t7, 0x3CA($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X3CA);
    // 0x8035F798: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x8035F79C: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x8035F7A0: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x8035F7A4: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
L_8035F7A8:
    // 0x8035F7A8: sb          $zero, 0x34($v0)
    MEM_B(0X34, ctx->r2) = 0;
L_8035F7AC:
    // 0x8035F7AC: b           L_8035F7D0
    // 0x8035F7B0: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
        goto L_8035F7D0;
    // 0x8035F7B0: lh          $t5, 0xA2($sp)
    ctx->r13 = MEM_H(ctx->r29, 0XA2);
L_8035F7B4:
    // 0x8035F7B4: sll         $t7, $a0, 3
    ctx->r15 = S32(ctx->r4 << 3);
L_8035F7B8:
    // 0x8035F7B8: subu        $t7, $t7, $a0
    ctx->r15 = SUB32(ctx->r15, ctx->r4);
    // 0x8035F7BC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8035F7C0: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x8035F7C4: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x8035F7C8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8035F7CC: sb          $t6, 0xF4($at)
    MEM_B(0XF4, ctx->r1) = ctx->r14;
L_8035F7D0:
    // 0x8035F7D0: bnel        $t5, $zero, L_8035F838
    if (ctx->r13 != 0) {
        // 0x8035F7D4: lh          $t9, 0xA0($sp)
        ctx->r25 = MEM_H(ctx->r29, 0XA0);
            goto L_8035F838;
    }
    goto skip_9;
    // 0x8035F7D4: lh          $t9, 0xA0($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA0);
    skip_9:
    // 0x8035F7D8: lh          $t8, 0xA0($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XA0);
    // 0x8035F7DC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035F7E0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035F7E4: bne         $t8, $at, L_8035F80C
    if (ctx->r24 != ctx->r1) {
        // 0x8035F7E8: addiu       $a1, $zero, 0x4C2
        ctx->r5 = ADD32(0, 0X4C2);
            goto L_8035F80C;
    }
    // 0x8035F7E8: addiu       $a1, $zero, 0x4C2
    ctx->r5 = ADD32(0, 0X4C2);
    // 0x8035F7EC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035F7F0: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8035F7F4: addiu       $a1, $zero, 0x261
    ctx->r5 = ADD32(0, 0X261);
    // 0x8035F7F8: addiu       $a2, $zero, 0x65
    ctx->r6 = ADD32(0, 0X65);
    // 0x8035F7FC: jal         0x803034D0
    // 0x8035F800: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_803034D0_714B80(rdram, ctx);
        goto after_49;
    // 0x8035F800: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_49:
    // 0x8035F804: b           L_8035F81C
    // 0x8035F808: nop

        goto L_8035F81C;
    // 0x8035F808: nop

L_8035F80C:
    // 0x8035F80C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8035F810: addiu       $a2, $zero, 0x130
    ctx->r6 = ADD32(0, 0X130);
    // 0x8035F814: jal         0x803034D0
    // 0x8035F818: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_803034D0_714B80(rdram, ctx);
        goto after_50;
    // 0x8035F818: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_50:
L_8035F81C:
    // 0x8035F81C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035F820: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8035F824: jal         0x80303D50
    // 0x8035F828: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    func_80303D50_715400(rdram, ctx);
        goto after_51;
    // 0x8035F828: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    after_51:
    // 0x8035F82C: b           L_8035F888
    // 0x8035F830: nop

        goto L_8035F888;
    // 0x8035F830: nop

    // 0x8035F834: lh          $t9, 0xA0($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XA0);
L_8035F838:
    // 0x8035F838: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035F83C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8035F840: sll         $a2, $t9, 2
    ctx->r6 = S32(ctx->r25 << 2);
    // 0x8035F844: subu        $a2, $a2, $t9
    ctx->r6 = SUB32(ctx->r6, ctx->r25);
    // 0x8035F848: sll         $a2, $a2, 3
    ctx->r6 = S32(ctx->r6 << 3);
    // 0x8035F84C: subu        $a2, $a2, $t9
    ctx->r6 = SUB32(ctx->r6, ctx->r25);
    // 0x8035F850: sll         $a1, $t9, 2
    ctx->r5 = S32(ctx->r25 << 2);
    // 0x8035F854: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    // 0x8035F858: addu        $a1, $a1, $t9
    ctx->r5 = ADD32(ctx->r5, ctx->r25);
    // 0x8035F85C: sll         $a1, $a1, 2
    ctx->r5 = S32(ctx->r5 << 2);
    // 0x8035F860: subu        $a2, $a2, $t9
    ctx->r6 = SUB32(ctx->r6, ctx->r25);
    // 0x8035F864: sll         $a2, $a2, 2
    ctx->r6 = S32(ctx->r6 << 2);
    // 0x8035F868: subu        $a1, $a1, $t9
    ctx->r5 = SUB32(ctx->r5, ctx->r25);
    // 0x8035F86C: sll         $a1, $a1, 5
    ctx->r5 = S32(ctx->r5 << 5);
    // 0x8035F870: addu        $a2, $a2, $t9
    ctx->r6 = ADD32(ctx->r6, ctx->r25);
    // 0x8035F874: andi        $t8, $a2, 0xFFFF
    ctx->r24 = ctx->r6 & 0XFFFF;
    // 0x8035F878: addu        $t6, $a1, $t9
    ctx->r14 = ADD32(ctx->r5, ctx->r25);
    // 0x8035F87C: andi        $a1, $t6, 0xFFFF
    ctx->r5 = ctx->r14 & 0XFFFF;
    // 0x8035F880: jal         0x80303D00
    // 0x8035F884: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    func_80303D00_7153B0(rdram, ctx);
        goto after_52;
    // 0x8035F884: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    after_52:
L_8035F888:
    // 0x8035F888: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035F88C: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x8035F890: bne         $t6, $zero, L_8035F91C
    if (ctx->r14 != 0) {
        // 0x8035F894: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_8035F91C;
    }
    // 0x8035F894: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035F898: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8035F89C: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x8035F8A0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F8A4: lhu         $t9, 0x9C($t7)
    ctx->r25 = MEM_HU(ctx->r15, 0X9C);
    // 0x8035F8A8: bnel        $t9, $at, L_8035F920
    if (ctx->r25 != ctx->r1) {
        // 0x8035F8AC: lw          $ra, 0x3C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X3C);
            goto L_8035F920;
    }
    goto skip_10;
    // 0x8035F8AC: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    skip_10:
    // 0x8035F8B0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035F8B4: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x8035F8B8: lbu         $v1, 0x365($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X365);
    // 0x8035F8BC: beq         $v1, $at, L_8035F8D4
    if (ctx->r3 == ctx->r1) {
        // 0x8035F8C0: addiu       $at, $zero, 0x27
        ctx->r1 = ADD32(0, 0X27);
            goto L_8035F8D4;
    }
    // 0x8035F8C0: addiu       $at, $zero, 0x27
    ctx->r1 = ADD32(0, 0X27);
    // 0x8035F8C4: beql        $v1, $at, L_8035F8F4
    if (ctx->r3 == ctx->r1) {
        // 0x8035F8C8: lh          $v1, 0x2EC($v0)
        ctx->r3 = MEM_H(ctx->r2, 0X2EC);
            goto L_8035F8F4;
    }
    goto skip_11;
    // 0x8035F8C8: lh          $v1, 0x2EC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2EC);
    skip_11:
    // 0x8035F8CC: b           L_8035F91C
    // 0x8035F8D0: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
        goto L_8035F91C;
    // 0x8035F8D0: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_8035F8D4:
    // 0x8035F8D4: lh          $v1, 0x2EC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2EC);
    // 0x8035F8D8: bgtz        $v1, L_8035F8E8
    if (SIGNED(ctx->r3) > 0) {
        // 0x8035F8DC: addiu       $t8, $v1, -0x1
        ctx->r24 = ADD32(ctx->r3, -0X1);
            goto L_8035F8E8;
    }
    // 0x8035F8DC: addiu       $t8, $v1, -0x1
    ctx->r24 = ADD32(ctx->r3, -0X1);
    // 0x8035F8E0: b           L_8035F91C
    // 0x8035F8E4: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
        goto L_8035F91C;
    // 0x8035F8E4: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_8035F8E8:
    // 0x8035F8E8: b           L_8035F91C
    // 0x8035F8EC: sh          $t8, 0x2EC($v0)
    MEM_H(0X2EC, ctx->r2) = ctx->r24;
        goto L_8035F91C;
    // 0x8035F8EC: sh          $t8, 0x2EC($v0)
    MEM_H(0X2EC, ctx->r2) = ctx->r24;
    // 0x8035F8F0: lh          $v1, 0x2EC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2EC);
L_8035F8F4:
    // 0x8035F8F4: bgtz        $v1, L_8035F918
    if (SIGNED(ctx->r3) > 0) {
        // 0x8035F8F8: addiu       $t9, $v1, -0x1
        ctx->r25 = ADD32(ctx->r3, -0X1);
            goto L_8035F918;
    }
    // 0x8035F8F8: addiu       $t9, $v1, -0x1
    ctx->r25 = ADD32(ctx->r3, -0X1);
    // 0x8035F8FC: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
    // 0x8035F900: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F904: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035F908: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8035F90C: andi        $t7, $t6, 0xFFF1
    ctx->r15 = ctx->r14 & 0XFFF1;
    // 0x8035F910: b           L_8035F91C
    // 0x8035F914: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
        goto L_8035F91C;
    // 0x8035F914: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
L_8035F918:
    // 0x8035F918: sh          $t9, 0x2EC($v0)
    MEM_H(0X2EC, ctx->r2) = ctx->r25;
L_8035F91C:
    // 0x8035F91C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_8035F920:
    // 0x8035F920: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
    // 0x8035F924: jr          $ra
    // 0x8035F928: nop

    return;
    // 0x8035F928: nop

;}
RECOMP_FUNC void func_8035F92C_770FDC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035F92C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035F930: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035F934: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8035F938: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8035F93C: lbu         $v1, 0x162($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X162);
    // 0x8035F940: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035F944: beq         $v1, $at, L_8035F954
    if (ctx->r3 == ctx->r1) {
        // 0x8035F948: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_8035F954;
    }
    // 0x8035F948: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8035F94C: bne         $v1, $at, L_8035FA44
    if (ctx->r3 != ctx->r1) {
        // 0x8035F950: nop
    
            goto L_8035FA44;
    }
    // 0x8035F950: nop

L_8035F954:
    // 0x8035F954: lw          $t6, 0x6C($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X6C);
    // 0x8035F958: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035F95C: bne         $t6, $zero, L_8035FA44
    if (ctx->r14 != 0) {
        // 0x8035F960: nop
    
            goto L_8035FA44;
    }
    // 0x8035F960: nop

    // 0x8035F964: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x8035F968: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x8035F96C: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x8035F970: lh          $v1, 0x302($t7)
    ctx->r3 = MEM_H(ctx->r15, 0X302);
    // 0x8035F974: addiu       $t1, $zero, 0x14
    ctx->r9 = ADD32(0, 0X14);
    // 0x8035F978: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x8035F97C: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    // 0x8035F980: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8035F984: addu        $t3, $t0, $t2
    ctx->r11 = ADD32(ctx->r8, ctx->r10);
    // 0x8035F988: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x8035F98C: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x8035F990: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8035F994: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x8035F998: multu       $t5, $t1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F99C: addiu       $t4, $v1, 0x40
    ctx->r12 = ADD32(ctx->r3, 0X40);
    // 0x8035F9A0: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x8035F9A4: addiu       $a3, $zero, 0x228
    ctx->r7 = ADD32(0, 0X228);
    // 0x8035F9A8: mflo        $t6
    ctx->r14 = lo;
    // 0x8035F9AC: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x8035F9B0: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8035F9B4: subu        $a0, $t8, $t7
    ctx->r4 = SUB32(ctx->r24, ctx->r15);
    // 0x8035F9B8: addu        $t8, $t0, $t6
    ctx->r24 = ADD32(ctx->r8, ctx->r14);
    // 0x8035F9BC: lh          $t7, 0x0($t8)
    ctx->r15 = MEM_H(ctx->r24, 0X0);
    // 0x8035F9C0: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x8035F9C4: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8035F9C8: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8035F9CC: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035F9D0: addiu       $t9, $zero, 0x21
    ctx->r25 = ADD32(0, 0X21);
    // 0x8035F9D4: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x8035F9D8: addiu       $t8, $zero, 0x6E
    ctx->r24 = ADD32(0, 0X6E);
    // 0x8035F9DC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035F9E0: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8035F9E4: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8035F9E8: sw          $v0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r2;
    // 0x8035F9EC: mflo        $t2
    ctx->r10 = lo;
    // 0x8035F9F0: sra         $t4, $t2, 8
    ctx->r12 = S32(SIGNED(ctx->r10) >> 8);
    // 0x8035F9F4: subu        $a1, $t3, $t4
    ctx->r5 = SUB32(ctx->r11, ctx->r12);
    // 0x8035F9F8: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x8035F9FC: jal         0x802FF0A4
    // 0x8035FA00: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    spawn_temporary_object(rdram, ctx);
        goto after_0;
    // 0x8035FA00: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    after_0:
    // 0x8035FA04: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FA08: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FA0C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8035FA10: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8035FA14: lh          $t2, 0x8($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X8);
    // 0x8035FA18: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035FA1C: addiu       $a0, $zero, 0x9C
    ctx->r4 = ADD32(0, 0X9C);
    // 0x8035FA20: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x8035FA24: lh          $t3, 0xC($v0)
    ctx->r11 = MEM_H(ctx->r2, 0XC);
    // 0x8035FA28: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035FA2C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FA30: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8035FA34: jal         0x8032C360
    // 0x8035FA38: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x8035FA38: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    after_1:
    // 0x8035FA3C: b           L_8035FA50
    // 0x8035FA40: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_8035FA50;
    // 0x8035FA40: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8035FA44:
    // 0x8035FA44: jal         0x8035E3E8
    // 0x8035FA48: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    recharge_skill(rdram, ctx);
        goto after_2;
    // 0x8035FA48: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_2:
    // 0x8035FA4C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8035FA50:
    // 0x8035FA50: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8035FA54: jr          $ra
    // 0x8035FA58: nop

    return;
    // 0x8035FA58: nop

;}
RECOMP_FUNC void func_8035FA5C_77110C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FA5C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FA60: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x8035FA64: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035FA68: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x8035FA6C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x8035FA70: addiu       $t8, $zero, 0x12
    ctx->r24 = ADD32(0, 0X12);
    // 0x8035FA74: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x8035FA78: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x8035FA7C: jr          $ra
    // 0x8035FA80: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    return;
    // 0x8035FA80: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
;}
RECOMP_FUNC void func_8035FA84_771134(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FA84: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035FA88: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8035FA8C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8035FA90: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8035FA94: lbu         $v0, 0x162($t6)
    ctx->r2 = MEM_BU(ctx->r14, 0X162);
    // 0x8035FA98: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8035FA9C: beq         $v0, $at, L_8035FAAC
    if (ctx->r2 == ctx->r1) {
        // 0x8035FAA0: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_8035FAAC;
    }
    // 0x8035FAA0: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x8035FAA4: bne         $v0, $at, L_8035FABC
    if (ctx->r2 != ctx->r1) {
        // 0x8035FAA8: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_8035FABC;
    }
    // 0x8035FAA8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
L_8035FAAC:
    // 0x8035FAAC: jal         0x8035FAEC
    // 0x8035FAB0: nop

    func_8035FAEC_77119C(rdram, ctx);
        goto after_0;
    // 0x8035FAB0: nop

    after_0:
    // 0x8035FAB4: b           L_8035FAE0
    // 0x8035FAB8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8035FAE0;
    // 0x8035FAB8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8035FABC:
    // 0x8035FABC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FAC0: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x8035FAC4: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8035FAC8: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x8035FACC: addiu       $t9, $zero, 0x13
    ctx->r25 = ADD32(0, 0X13);
    // 0x8035FAD0: sh          $t7, 0x32A($t8)
    MEM_H(0X32A, ctx->r24) = ctx->r15;
    // 0x8035FAD4: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x8035FAD8: sb          $t9, 0x365($t0)
    MEM_B(0X365, ctx->r8) = ctx->r25;
    // 0x8035FADC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8035FAE0:
    // 0x8035FAE0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8035FAE4: jr          $ra
    // 0x8035FAE8: nop

    return;
    // 0x8035FAE8: nop

;}
RECOMP_FUNC void func_8035FAEC_77119C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FAEC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FAF0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8035FAF4: addiu       $at, $zero, 0x13
    ctx->r1 = ADD32(0, 0X13);
    // 0x8035FAF8: lbu         $t6, 0x365($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X365);
    // 0x8035FAFC: bne         $t6, $at, L_8035FB08
    if (ctx->r14 != ctx->r1) {
        // 0x8035FB00: nop
    
            goto L_8035FB08;
    }
    // 0x8035FB00: nop

    // 0x8035FB04: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_8035FB08:
    // 0x8035FB08: jr          $ra
    // 0x8035FB0C: nop

    return;
    // 0x8035FB0C: nop

;}
RECOMP_FUNC void func_8035FB10_7711C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FB10: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FB14: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FB18: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FB1C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8035FB20: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8035FB24: lh          $t6, 0x308($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X308);
    // 0x8035FB28: bne         $t6, $zero, L_8035FBB4
    if (ctx->r14 != 0) {
        // 0x8035FB2C: nop
    
            goto L_8035FBB4;
    }
    // 0x8035FB2C: nop

    // 0x8035FB30: lb          $t7, 0x2B5($v0)
    ctx->r15 = MEM_B(ctx->r2, 0X2B5);
    // 0x8035FB34: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8035FB38: addiu       $a1, $zero, 0x7000
    ctx->r5 = ADD32(0, 0X7000);
    // 0x8035FB3C: beq         $t7, $zero, L_8035FB94
    if (ctx->r15 == 0) {
        // 0x8035FB40: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8035FB94;
    }
    // 0x8035FB40: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FB44: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FB48: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FB4C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035FB50: lwc1        $f4, -0x13F0($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0X13F0);
    // 0x8035FB54: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x8035FB58: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035FB5C: addiu       $a0, $zero, 0xB8
    ctx->r4 = ADD32(0, 0XB8);
    // 0x8035FB60: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035FB64: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x8035FB68: addiu       $a1, $zero, 0x7000
    ctx->r5 = ADD32(0, 0X7000);
    // 0x8035FB6C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FB70: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8035FB74: jal         0x8032C360
    // 0x8035FB78: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8035FB78: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_0:
    // 0x8035FB7C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FB80: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FB84: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x8035FB88: addiu       $t0, $zero, 0x50
    ctx->r8 = ADD32(0, 0X50);
    // 0x8035FB8C: b           L_8035FBB4
    // 0x8035FB90: sh          $t0, 0x308($t1)
    MEM_H(0X308, ctx->r9) = ctx->r8;
        goto L_8035FBB4;
    // 0x8035FB90: sh          $t0, 0x308($t1)
    MEM_H(0X308, ctx->r9) = ctx->r8;
L_8035FB94:
    // 0x8035FB94: lui         $a3, 0x3FA6
    ctx->r7 = S32(0X3FA6 << 16);
    // 0x8035FB98: jal         0x8032C508
    // 0x8035FB9C: ori         $a3, $a3, 0x6666
    ctx->r7 = ctx->r7 | 0X6666;
    func_8032C508_73DBB8(rdram, ctx);
        goto after_1;
    // 0x8035FB9C: ori         $a3, $a3, 0x6666
    ctx->r7 = ctx->r7 | 0X6666;
    after_1:
    // 0x8035FBA0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FBA4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FBA8: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x8035FBAC: addiu       $t2, $zero, 0x50
    ctx->r10 = ADD32(0, 0X50);
    // 0x8035FBB0: sh          $t2, 0x308($t3)
    MEM_H(0X308, ctx->r11) = ctx->r10;
L_8035FBB4:
    // 0x8035FBB4: jal         0x8037E9AC
    // 0x8035FBB8: nop

    func_8037E9AC_79005C(rdram, ctx);
        goto after_2;
    // 0x8035FBB8: nop

    after_2:
    // 0x8035FBBC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FBC0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FBC4: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x8035FBC8: beq         $v0, $zero, L_8035FBE8
    if (ctx->r2 == 0) {
        // 0x8035FBCC: sw          $v0, 0x2CC($t4)
        MEM_W(0X2CC, ctx->r12) = ctx->r2;
            goto L_8035FBE8;
    }
    // 0x8035FBCC: sw          $v0, 0x2CC($t4)
    MEM_W(0X2CC, ctx->r12) = ctx->r2;
    // 0x8035FBD0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FBD4: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8035FBD8: andi        $t6, $t5, 0xFFF1
    ctx->r14 = ctx->r13 & 0XFFF1;
    // 0x8035FBDC: ori         $t7, $t6, 0x2
    ctx->r15 = ctx->r14 | 0X2;
    // 0x8035FBE0: b           L_8035FBF8
    // 0x8035FBE4: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
        goto L_8035FBF8;
    // 0x8035FBE4: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
L_8035FBE8:
    // 0x8035FBE8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FBEC: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8035FBF0: andi        $t9, $t8, 0xFFF1
    ctx->r25 = ctx->r24 & 0XFFF1;
    // 0x8035FBF4: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
L_8035FBF8:
    // 0x8035FBF8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8035FBFC: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8035FC00: jr          $ra
    // 0x8035FC04: nop

    return;
    // 0x8035FC04: nop

;}
RECOMP_FUNC void func_8035FC08_7712B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FC08: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FC0C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FC10: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FC14: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8035FC18: andi        $t7, $t6, 0xFFF1
    ctx->r15 = ctx->r14 & 0XFFF1;
    // 0x8035FC1C: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x8035FC20: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x8035FC24: jr          $ra
    // 0x8035FC28: sw          $zero, 0x2CC($t8)
    MEM_W(0X2CC, ctx->r24) = 0;
    return;
    // 0x8035FC28: sw          $zero, 0x2CC($t8)
    MEM_W(0X2CC, ctx->r24) = 0;
;}
RECOMP_FUNC void rat_drop_mine(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FC2C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FC30: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FC34: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8035FC38: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8035FC3C: lbu         $v1, 0x162($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X162);
    // 0x8035FC40: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8035FC44: beq         $v1, $at, L_8035FC54
    if (ctx->r3 == ctx->r1) {
        // 0x8035FC48: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_8035FC54;
    }
    // 0x8035FC48: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8035FC4C: bnel        $v1, $at, L_8035FD40
    if (ctx->r3 != ctx->r1) {
        // 0x8035FC50: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_8035FD40;
    }
    goto skip_0;
    // 0x8035FC50: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
L_8035FC54:
    // 0x8035FC54: lw          $t6, 0x6C($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X6C);
    // 0x8035FC58: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8035FC5C: bnel        $t6, $zero, L_8035FD40
    if (ctx->r14 != 0) {
        // 0x8035FC60: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_8035FD40;
    }
    goto skip_1;
    // 0x8035FC60: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_1:
    // 0x8035FC64: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x8035FC68: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x8035FC6C: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x8035FC70: lh          $v1, 0x302($t7)
    ctx->r3 = MEM_H(ctx->r15, 0X302);
    // 0x8035FC74: addiu       $t1, $zero, 0x14
    ctx->r9 = ADD32(0, 0X14);
    // 0x8035FC78: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x8035FC7C: andi        $t9, $v1, 0xFF
    ctx->r25 = ctx->r3 & 0XFF;
    // 0x8035FC80: sll         $t2, $t9, 1
    ctx->r10 = S32(ctx->r25 << 1);
    // 0x8035FC84: addu        $t3, $t0, $t2
    ctx->r11 = ADD32(ctx->r8, ctx->r10);
    // 0x8035FC88: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x8035FC8C: lh          $t3, 0x8($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X8);
    // 0x8035FC90: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8035FC94: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x8035FC98: multu       $t5, $t1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035FC9C: addiu       $t4, $v1, 0x40
    ctx->r12 = ADD32(ctx->r3, 0X40);
    // 0x8035FCA0: andi        $t5, $t4, 0xFF
    ctx->r13 = ctx->r12 & 0XFF;
    // 0x8035FCA4: addiu       $a3, $zero, 0x228
    ctx->r7 = ADD32(0, 0X228);
    // 0x8035FCA8: mflo        $t6
    ctx->r14 = lo;
    // 0x8035FCAC: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x8035FCB0: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8035FCB4: subu        $a0, $t8, $t7
    ctx->r4 = SUB32(ctx->r24, ctx->r15);
    // 0x8035FCB8: addu        $t8, $t0, $t6
    ctx->r24 = ADD32(ctx->r8, ctx->r14);
    // 0x8035FCBC: lh          $t7, 0x0($t8)
    ctx->r15 = MEM_H(ctx->r24, 0X0);
    // 0x8035FCC0: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x8035FCC4: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8035FCC8: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8035FCCC: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8035FCD0: addiu       $t9, $zero, 0x21
    ctx->r25 = ADD32(0, 0X21);
    // 0x8035FCD4: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x8035FCD8: addiu       $t8, $zero, 0x96
    ctx->r24 = ADD32(0, 0X96);
    // 0x8035FCDC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8035FCE0: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8035FCE4: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8035FCE8: sw          $v0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r2;
    // 0x8035FCEC: mflo        $t2
    ctx->r10 = lo;
    // 0x8035FCF0: sra         $t4, $t2, 8
    ctx->r12 = S32(SIGNED(ctx->r10) >> 8);
    // 0x8035FCF4: subu        $a1, $t3, $t4
    ctx->r5 = SUB32(ctx->r11, ctx->r12);
    // 0x8035FCF8: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x8035FCFC: jal         0x802FF0A4
    // 0x8035FD00: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    spawn_temporary_object(rdram, ctx);
        goto after_0;
    // 0x8035FD00: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    after_0:
    // 0x8035FD04: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FD08: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FD0C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8035FD10: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8035FD14: lh          $t2, 0x8($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X8);
    // 0x8035FD18: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035FD1C: addiu       $a0, $zero, 0x9C
    ctx->r4 = ADD32(0, 0X9C);
    // 0x8035FD20: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x8035FD24: lh          $t3, 0xC($v0)
    ctx->r11 = MEM_H(ctx->r2, 0XC);
    // 0x8035FD28: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035FD2C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FD30: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8035FD34: jal         0x8032C360
    // 0x8035FD38: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x8035FD38: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    after_1:
    // 0x8035FD3C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8035FD40:
    // 0x8035FD40: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8035FD44: jr          $ra
    // 0x8035FD48: nop

    return;
    // 0x8035FD48: nop

;}
RECOMP_FUNC void rat_bite(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FD4C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FD50: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FD54: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035FD58: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x8035FD5C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x8035FD60: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8035FD64: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8035FD68: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x8035FD6C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x8035FD70: addiu       $t8, $zero, 0x12
    ctx->r24 = ADD32(0, 0X12);
    // 0x8035FD74: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FD78: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    // 0x8035FD7C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FD80: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035FD84: lwc1        $f4, -0x13EC($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0X13EC);
    // 0x8035FD88: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x8035FD8C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035FD90: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x8035FD94: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8035FD98: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x8035FD9C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8035FDA0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FDA4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8035FDA8: jal         0x8032C360
    // 0x8035FDAC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8035FDAC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x8035FDB0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8035FDB4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8035FDB8: jr          $ra
    // 0x8035FDBC: nop

    return;
    // 0x8035FDBC: nop

;}
RECOMP_FUNC void king_rat_bugel_call(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FDC0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FDC4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FDC8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FDCC: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8035FDD0: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8035FDD4: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x8035FDD8: lh          $t6, 0x308($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X308);
    // 0x8035FDDC: addiu       $a0, $zero, 0xB8
    ctx->r4 = ADD32(0, 0XB8);
    // 0x8035FDE0: addiu       $a1, $zero, 0x7000
    ctx->r5 = ADD32(0, 0X7000);
    // 0x8035FDE4: bnel        $t6, $zero, L_8035FE38
    if (ctx->r14 != 0) {
        // 0x8035FDE8: lh          $t1, 0x2A($sp)
        ctx->r9 = MEM_H(ctx->r29, 0X2A);
            goto L_8035FE38;
    }
    goto skip_0;
    // 0x8035FDE8: lh          $t1, 0x2A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X2A);
    skip_0:
    // 0x8035FDEC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FDF0: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x8035FDF4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8035FDF8: lwc1        $f4, -0x13E8($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0X13E8);
    // 0x8035FDFC: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x8035FE00: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x8035FE04: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8035FE08: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8035FE0C: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x8035FE10: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8035FE14: jal         0x8032C360
    // 0x8035FE18: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8035FE18: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_0:
    // 0x8035FE1C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8035FE20: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8035FE24: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x8035FE28: addiu       $t9, $zero, 0x50
    ctx->r25 = ADD32(0, 0X50);
    // 0x8035FE2C: sh          $t9, 0x308($t0)
    MEM_H(0X308, ctx->r8) = ctx->r25;
    // 0x8035FE30: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FE34: lh          $t1, 0x2A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X2A);
L_8035FE38:
    // 0x8035FE38: addiu       $t2, $zero, 0x27
    ctx->r10 = ADD32(0, 0X27);
    // 0x8035FE3C: sh          $t1, 0x2EC($v0)
    MEM_H(0X2EC, ctx->r2) = ctx->r9;
    // 0x8035FE40: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x8035FE44: sb          $t2, 0x365($t3)
    MEM_B(0X365, ctx->r11) = ctx->r10;
    // 0x8035FE48: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8035FE4C: lbu         $t4, 0x2B4($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8035FE50: andi        $t5, $t4, 0xFFF1
    ctx->r13 = ctx->r12 & 0XFFF1;
    // 0x8035FE54: ori         $t6, $t5, 0x2
    ctx->r14 = ctx->r13 | 0X2;
    // 0x8035FE58: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x8035FE5C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8035FE60: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8035FE64: jr          $ra
    // 0x8035FE68: nop

    return;
    // 0x8035FE68: nop

;}
RECOMP_FUNC void king_rat_fart(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FE6C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8035FE70: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x8035FE74: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8035FE78: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8035FE7C: addiu       $t9, $zero, 0x13
    ctx->r25 = ADD32(0, 0X13);
    // 0x8035FE80: sh          $a0, 0x2EC($t8)
    MEM_H(0X2EC, ctx->r24) = ctx->r4;
    // 0x8035FE84: lw          $t0, 0x0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X0);
    // 0x8035FE88: jr          $ra
    // 0x8035FE8C: sb          $t9, 0x365($t0)
    MEM_B(0X365, ctx->r8) = ctx->r25;
    return;
    // 0x8035FE8C: sb          $t9, 0x365($t0)
    MEM_B(0X365, ctx->r8) = ctx->r25;
;}
RECOMP_FUNC void update_sheep_or_ram(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8035FE90: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035FE94: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x8035FE98: addiu       $sp, $sp, -0x98
    ctx->r29 = ADD32(ctx->r29, -0X98);
    // 0x8035FE9C: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x8035FEA0: bne         $a0, $zero, L_8035FFA0
    if (ctx->r4 != 0) {
        // 0x8035FEA4: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_8035FFA0;
    }
    // 0x8035FEA4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8035FEA8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8035FEAC: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x8035FEB0: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x8035FEB4: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8035FEB8: lhu         $t7, 0x9C($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X9C);
    // 0x8035FEBC: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x8035FEC0: bne         $t7, $at, L_8035FFA0
    if (ctx->r15 != ctx->r1) {
        // 0x8035FEC4: nop
    
            goto L_8035FFA0;
    }
    // 0x8035FEC4: nop

    // 0x8035FEC8: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x8035FECC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8035FED0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8035FED4: lbu         $t8, 0x162($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X162);
    // 0x8035FED8: bne         $t8, $at, L_8035FFA0
    if (ctx->r24 != ctx->r1) {
        // 0x8035FEDC: nop
    
            goto L_8035FFA0;
    }
    // 0x8035FEDC: nop

    // 0x8035FEE0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x8035FEE4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035FEE8: lbu         $t5, 0x366($t9)
    ctx->r13 = MEM_BU(ctx->r25, 0X366);
    // 0x8035FEEC: beq         $t5, $at, L_8035FFA0
    if (ctx->r13 == ctx->r1) {
        // 0x8035FEF0: nop
    
            goto L_8035FFA0;
    }
    // 0x8035FEF0: nop

    // 0x8035FEF4: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x8035FEF8: lui         $at, 0x9
    ctx->r1 = S32(0X9 << 16);
    // 0x8035FEFC: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8035FF00: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8035FF04: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x8035FF08: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x8035FF0C: lui         $at, 0xFFFD
    ctx->r1 = S32(0XFFFD << 16);
    // 0x8035FF10: addu        $t5, $t9, $at
    ctx->r13 = ADD32(ctx->r25, ctx->r1);
    // 0x8035FF14: sw          $t5, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r13;
    // 0x8035FF18: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x8035FF1C: lui         $t6, 0x803A
    ctx->r14 = S32(0X803A << 16);
    // 0x8035FF20: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x8035FF24: lw          $v1, 0x24($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X24);
    // 0x8035FF28: bgez        $v1, L_8035FF4C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8035FF2C: nop
    
            goto L_8035FF4C;
    }
    // 0x8035FF2C: nop

    // 0x8035FF30: lw          $t6, 0x5B0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5B0);
    // 0x8035FF34: sll         $t7, $t6, 4
    ctx->r15 = S32(ctx->r14 << 4);
    // 0x8035FF38: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8035FF3C: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x8035FF40: addu        $t9, $v1, $t8
    ctx->r25 = ADD32(ctx->r3, ctx->r24);
    // 0x8035FF44: b           L_8035FF5C
    // 0x8035FF48: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
        goto L_8035FF5C;
    // 0x8035FF48: sw          $t9, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r25;
L_8035FF4C:
    // 0x8035FF4C: lw          $t5, 0x5B0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B0);
    // 0x8035FF50: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x8035FF54: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x8035FF58: sw          $t7, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r15;
L_8035FF5C:
    // 0x8035FF5C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8035FF60: lh          $t9, 0x5540($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5540);
    // 0x8035FF64: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x8035FF68: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8035FF6C: sll         $t7, $t9, 2
    ctx->r15 = S32(ctx->r25 << 2);
    // 0x8035FF70: addiu       $t9, $t7, 0x40
    ctx->r25 = ADD32(ctx->r15, 0X40);
    // 0x8035FF74: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x8035FF78: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8035FF7C: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x8035FF80: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x8035FF84: lh          $t7, 0x2C78($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C78);
    // 0x8035FF88: lw          $t8, 0x24($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X24);
    // 0x8035FF8C: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8035FF90: sll         $t5, $t9, 8
    ctx->r13 = S32(ctx->r25 << 8);
    // 0x8035FF94: addu        $t6, $t8, $t5
    ctx->r14 = ADD32(ctx->r24, ctx->r13);
    // 0x8035FF98: sw          $t6, 0x24($v0)
    MEM_W(0X24, ctx->r2) = ctx->r14;
    // 0x8035FF9C: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
L_8035FFA0:
    // 0x8035FFA0: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8035FFA4: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x8035FFA8: beq         $a0, $zero, L_8035FFFC
    if (ctx->r4 == 0) {
        // 0x8035FFAC: lw          $t0, 0x5524($t0)
        ctx->r8 = MEM_W(ctx->r8, 0X5524);
            goto L_8035FFFC;
    }
    // 0x8035FFAC: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x8035FFB0: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x8035FFB4: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x8035FFB8: lh          $v1, 0xD6($t0)
    ctx->r3 = MEM_H(ctx->r8, 0XD6);
    // 0x8035FFBC: beq         $a0, $v1, L_8035FFDC
    if (ctx->r4 == ctx->r3) {
        // 0x8035FFC0: nop
    
            goto L_8035FFDC;
    }
    // 0x8035FFC0: nop

    // 0x8035FFC4: bne         $v1, $zero, L_8035FFE4
    if (ctx->r3 != 0) {
        // 0x8035FFC8: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8035FFE4;
    }
    // 0x8035FFC8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8035FFCC: beq         $a0, $at, L_8035FFDC
    if (ctx->r4 == ctx->r1) {
        // 0x8035FFD0: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_8035FFDC;
    }
    // 0x8035FFD0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8035FFD4: bnel        $a0, $at, L_8035FFE8
    if (ctx->r4 != ctx->r1) {
        // 0x8035FFD8: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_8035FFE8;
    }
    goto skip_0;
    // 0x8035FFD8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    skip_0:
L_8035FFDC:
    // 0x8035FFDC: b           L_8035FFE8
    // 0x8035FFE0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_8035FFE8;
    // 0x8035FFE0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_8035FFE4:
    // 0x8035FFE4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8035FFE8:
    // 0x8035FFE8: beq         $v1, $zero, L_8035FFFC
    if (ctx->r3 == 0) {
        // 0x8035FFEC: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_8035FFFC;
    }
    // 0x8035FFEC: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8035FFF0: sh          $zero, 0x8C($sp)
    MEM_H(0X8C, ctx->r29) = 0;
    // 0x8035FFF4: b           L_80360090
    // 0x8035FFF8: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_80360090;
    // 0x8035FFF8: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_8035FFFC:
    // 0x8035FFFC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80360000: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x80360004: lh          $v1, 0xD6($t0)
    ctx->r3 = MEM_H(ctx->r8, 0XD6);
    // 0x80360008: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8036000C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80360010: beq         $a0, $v1, L_80360030
    if (ctx->r4 == ctx->r3) {
        // 0x80360014: addiu       $a3, $zero, 0x5F0
        ctx->r7 = ADD32(0, 0X5F0);
            goto L_80360030;
    }
    // 0x80360014: addiu       $a3, $zero, 0x5F0
    ctx->r7 = ADD32(0, 0X5F0);
    // 0x80360018: bne         $v1, $zero, L_80360038
    if (ctx->r3 != 0) {
        // 0x8036001C: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80360038;
    }
    // 0x8036001C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80360020: beq         $a0, $at, L_80360030
    if (ctx->r4 == ctx->r1) {
        // 0x80360024: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80360030;
    }
    // 0x80360024: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80360028: bnel        $a0, $at, L_8036003C
    if (ctx->r4 != ctx->r1) {
        // 0x8036002C: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_8036003C;
    }
    goto skip_1;
    // 0x8036002C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    skip_1:
L_80360030:
    // 0x80360030: b           L_8036003C
    // 0x80360034: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_8036003C;
    // 0x80360034: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80360038:
    // 0x80360038: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8036003C:
    // 0x8036003C: lw          $t7, 0xC($v0)
    ctx->r15 = MEM_W(ctx->r2, 0XC);
    // 0x80360040: lhu         $t9, 0xBA($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0XBA);
    // 0x80360044: lw          $a0, 0x4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X4);
    // 0x80360048: lw          $a1, 0x8($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X8);
    // 0x8036004C: sll         $t8, $t9, 15
    ctx->r24 = S32(ctx->r25 << 15);
    // 0x80360050: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x80360054: sltiu       $t8, $v1, 0x1
    ctx->r24 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x80360058: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8036005C: addiu       $t9, $zero, 0x94
    ctx->r25 = ADD32(0, 0X94);
    // 0x80360060: addiu       $t5, $zero, 0x94
    ctx->r13 = ADD32(0, 0X94);
    // 0x80360064: addiu       $t6, $zero, 0x94
    ctx->r14 = ADD32(0, 0X94);
    // 0x80360068: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8036006C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x80360070: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80360074: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80360078: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8036007C: jal         0x802E89F0
    // 0x80360080: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_0;
    // 0x80360080: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_0:
    // 0x80360084: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x80360088: addiu       $t1, $t1, 0x5530
    ctx->r9 = ADD32(ctx->r9, 0X5530);
    // 0x8036008C: sh          $v0, 0x8C($sp)
    MEM_H(0X8C, ctx->r29) = ctx->r2;
L_80360090:
    // 0x80360090: lh          $t5, 0x8C($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X8C);
    // 0x80360094: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80360098: bne         $t5, $zero, L_80360CA0
    if (ctx->r13 != 0) {
        // 0x8036009C: nop
    
            goto L_80360CA0;
    }
    // 0x8036009C: nop

    // 0x803600A0: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x803600A4: beq         $t6, $zero, L_80360100
    if (ctx->r14 == 0) {
        // 0x803600A8: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80360100;
    }
    // 0x803600A8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803600AC: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x803600B0: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x803600B4: lhu         $t7, 0x9C($t9)
    ctx->r15 = MEM_HU(ctx->r25, 0X9C);
    // 0x803600B8: bne         $t7, $at, L_80360100
    if (ctx->r15 != ctx->r1) {
        // 0x803600BC: nop
    
            goto L_80360100;
    }
    // 0x803600BC: nop

    // 0x803600C0: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x803600C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803600C8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803600CC: lbu         $t5, 0x162($t8)
    ctx->r13 = MEM_BU(ctx->r24, 0X162);
    // 0x803600D0: bne         $t5, $at, L_80360100
    if (ctx->r13 != ctx->r1) {
        // 0x803600D4: nop
    
            goto L_80360100;
    }
    // 0x803600D4: nop

    // 0x803600D8: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x803600DC: addiu       $t6, $zero, 0x400
    ctx->r14 = ADD32(0, 0X400);
    // 0x803600E0: lh          $v1, 0x2E0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2E0);
    // 0x803600E4: addiu       $v1, $v1, 0x32
    ctx->r3 = ADD32(ctx->r3, 0X32);
    // 0x803600E8: slti        $at, $v1, 0x401
    ctx->r1 = SIGNED(ctx->r3) < 0X401 ? 1 : 0;
    // 0x803600EC: bnel        $at, $zero, L_80360100
    if (ctx->r1 != 0) {
        // 0x803600F0: sh          $v1, 0x2E0($v0)
        MEM_H(0X2E0, ctx->r2) = ctx->r3;
            goto L_80360100;
    }
    goto skip_2;
    // 0x803600F0: sh          $v1, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r3;
    skip_2:
    // 0x803600F4: b           L_80360100
    // 0x803600F8: sh          $t6, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r14;
        goto L_80360100;
    // 0x803600F8: sh          $t6, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r14;
    // 0x803600FC: sh          $v1, 0x2E0($v0)
    MEM_H(0X2E0, ctx->r2) = ctx->r3;
L_80360100:
    // 0x80360100: jal         0x8034B298
    // 0x80360104: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_1;
    // 0x80360104: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_1:
    // 0x80360108: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8036010C: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80360110: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80360114: lbu         $t7, 0x366($t9)
    ctx->r15 = MEM_BU(ctx->r25, 0X366);
    // 0x80360118: beq         $t7, $at, L_80360128
    if (ctx->r15 == ctx->r1) {
        // 0x8036011C: nop
    
            goto L_80360128;
    }
    // 0x8036011C: nop

    // 0x80360120: jal         0x803622DC
    // 0x80360124: nop

    func_803622DC_77398C(rdram, ctx);
        goto after_2;
    // 0x80360124: nop

    after_2:
L_80360128:
    // 0x80360128: jal         0x8035D120
    // 0x8036012C: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_3;
    // 0x8036012C: nop

    after_3:
    // 0x80360130: jal         0x8035D734
    // 0x80360134: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_4;
    // 0x80360134: nop

    after_4:
    // 0x80360138: jal         0x8034BB38
    // 0x8036013C: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    func_8034BB38_75D1E8(rdram, ctx);
        goto after_5;
    // 0x8036013C: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    after_5:
    // 0x80360140: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80360144: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80360148: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8036014C: lbu         $v0, 0x366($t8)
    ctx->r2 = MEM_BU(ctx->r24, 0X366);
    // 0x80360150: beq         $v0, $at, L_80360160
    if (ctx->r2 == ctx->r1) {
        // 0x80360154: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80360160;
    }
    // 0x80360154: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80360158: bne         $v0, $at, L_80360190
    if (ctx->r2 != ctx->r1) {
        // 0x8036015C: nop
    
            goto L_80360190;
    }
    // 0x8036015C: nop

L_80360160:
    // 0x80360160: jal         0x8012826C
    // 0x80360164: nop

    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x80360164: nop

    after_6:
    // 0x80360168: andi        $t5, $v0, 0xFF
    ctx->r13 = ctx->r2 & 0XFF;
    // 0x8036016C: addiu       $at, $zero, 0x9C
    ctx->r1 = ADD32(0, 0X9C);
    // 0x80360170: bne         $t5, $at, L_80360190
    if (ctx->r13 != ctx->r1) {
        // 0x80360174: lui         $t6, 0x803F
        ctx->r14 = S32(0X803F << 16);
            goto L_80360190;
    }
    // 0x80360174: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80360178: lh          $t6, 0x2DA2($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2DA2);
    // 0x8036017C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80360180: beq         $t6, $at, L_80360190
    if (ctx->r14 == ctx->r1) {
        // 0x80360184: nop
    
            goto L_80360190;
    }
    // 0x80360184: nop

    // 0x80360188: jal         0x8037FEDC
    // 0x8036018C: nop

    sheep_follow_leader(rdram, ctx);
        goto after_7;
    // 0x8036018C: nop

    after_7:
L_80360190:
    // 0x80360190: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80360194: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80360198: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8036019C: lbu         $v1, 0x365($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X365);
    // 0x803601A0: beq         $v1, $zero, L_803602A0
    if (ctx->r3 == 0) {
        // 0x803601A4: nop
    
            goto L_803602A0;
    }
    // 0x803601A4: nop

    // 0x803601A8: beq         $v1, $at, L_803601C0
    if (ctx->r3 == ctx->r1) {
        // 0x803601AC: addiu       $at, $zero, 0x2D
        ctx->r1 = ADD32(0, 0X2D);
            goto L_803601C0;
    }
    // 0x803601AC: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x803601B0: beq         $v1, $at, L_80360258
    if (ctx->r3 == ctx->r1) {
        // 0x803601B4: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_80360258;
    }
    // 0x803601B4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803601B8: b           L_803602A0
    // 0x803601BC: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
        goto L_803602A0;
    // 0x803601BC: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_803601C0:
    // 0x803601C0: jal         0x802DCCAC
    // 0x803601C4: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    func_802DCCAC_6EE35C(rdram, ctx);
        goto after_8;
    // 0x803601C4: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    after_8:
    // 0x803601C8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x803601CC: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x803601D0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803601D4: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x803601D8: lhu         $t8, 0x32A($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X32A);
    // 0x803601DC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803601E0: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    // 0x803601E4: subu        $t5, $t9, $t8
    ctx->r13 = SUB32(ctx->r25, ctx->r24);
    // 0x803601E8: bne         $t5, $at, L_803602A0
    if (ctx->r13 != ctx->r1) {
        // 0x803601EC: addiu       $a1, $zero, 0x2E
        ctx->r5 = ADD32(0, 0X2E);
            goto L_803602A0;
    }
    // 0x803601EC: addiu       $a1, $zero, 0x2E
    ctx->r5 = ADD32(0, 0X2E);
    // 0x803601F0: addiu       $t6, $zero, 0xC
    ctx->r14 = ADD32(0, 0XC);
    // 0x803601F4: addiu       $t7, $zero, 0x10
    ctx->r15 = ADD32(0, 0X10);
    // 0x803601F8: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x803601FC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80360200: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80360204: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x80360208: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8036020C: jal         0x803224C4
    // 0x80360210: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_9;
    // 0x80360210: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_9:
    // 0x80360214: beq         $v0, $zero, L_803602A0
    if (ctx->r2 == 0) {
        // 0x80360218: addiu       $a0, $zero, 0x48
        ctx->r4 = ADD32(0, 0X48);
            goto L_803602A0;
    }
    // 0x80360218: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    // 0x8036021C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80360220: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80360224: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80360228: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8036022C: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x80360230: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80360234: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80360238: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8036023C: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x80360240: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80360244: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80360248: jal         0x8032C360
    // 0x8036024C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_10;
    // 0x8036024C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_10:
    // 0x80360250: b           L_803602A0
    // 0x80360254: nop

        goto L_803602A0;
    // 0x80360254: nop

L_80360258:
    // 0x80360258: lhu         $t5, 0x5544($t5)
    ctx->r13 = MEM_HU(ctx->r13, 0X5544);
    // 0x8036025C: lhu         $t6, 0x32A($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X32A);
    // 0x80360260: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80360264: subu        $v1, $t5, $t6
    ctx->r3 = SUB32(ctx->r13, ctx->r14);
    // 0x80360268: andi        $t7, $v1, 0xFFFF
    ctx->r15 = ctx->r3 & 0XFFFF;
    // 0x8036026C: slti        $at, $t7, 0x10
    ctx->r1 = SIGNED(ctx->r15) < 0X10 ? 1 : 0;
    // 0x80360270: bne         $at, $zero, L_80360280
    if (ctx->r1 != 0) {
        // 0x80360274: or          $v1, $t7, $zero
        ctx->r3 = ctx->r15 | 0;
            goto L_80360280;
    }
    // 0x80360274: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x80360278: b           L_803602A0
    // 0x8036027C: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
        goto L_803602A0;
    // 0x8036027C: sb          $zero, 0x365($v0)
    MEM_B(0X365, ctx->r2) = 0;
L_80360280:
    // 0x80360280: sll         $t8, $v1, 1
    ctx->r24 = S32(ctx->r3 << 1);
    // 0x80360284: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x80360288: addu        $t5, $t5, $t8
    ctx->r13 = ADD32(ctx->r13, ctx->r24);
    // 0x8036028C: lh          $t5, 0x41D8($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X41D8);
    // 0x80360290: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80360294: sh          $t9, 0x2ECE($at)
    MEM_H(0X2ECE, ctx->r1) = ctx->r25;
    // 0x80360298: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8036029C: sh          $t5, 0x2ECC($at)
    MEM_H(0X2ECC, ctx->r1) = ctx->r13;
L_803602A0:
    // 0x803602A0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803602A4: lhu         $t6, 0x2ECE($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X2ECE);
    // 0x803602A8: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803602AC: addiu       $a1, $zero, 0xB2
    ctx->r5 = ADD32(0, 0XB2);
    // 0x803602B0: beq         $t6, $zero, L_803602C8
    if (ctx->r14 == 0) {
        // 0x803602B4: addiu       $a2, $zero, 0x76
        ctx->r6 = ADD32(0, 0X76);
            goto L_803602C8;
    }
    // 0x803602B4: addiu       $a2, $zero, 0x76
    ctx->r6 = ADD32(0, 0X76);
    // 0x803602B8: lhu         $a0, 0x2ECC($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X2ECC);
    // 0x803602BC: slti        $at, $a0, 0x1F
    ctx->r1 = SIGNED(ctx->r4) < 0X1F ? 1 : 0;
    // 0x803602C0: beq         $at, $zero, L_803603AC
    if (ctx->r1 == 0) {
        // 0x803602C4: nop
    
            goto L_803603AC;
    }
    // 0x803602C4: nop

L_803602C8:
    // 0x803602C8: addiu       $a0, $sp, 0x94
    ctx->r4 = ADD32(ctx->r29, 0X94);
    // 0x803602CC: addiu       $a3, $zero, 0x33F
    ctx->r7 = ADD32(0, 0X33F);
    // 0x803602D0: jal         0x802B9130
    // 0x803602D4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_802B9130_6CA7E0(rdram, ctx);
        goto after_11;
    // 0x803602D4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_11:
    // 0x803602D8: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x803602DC: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x803602E0: addiu       $t5, $t5, 0x4070
    ctx->r13 = ADD32(ctx->r13, 0X4070);
    // 0x803602E4: addiu       $t8, $t8, 0x4040
    ctx->r24 = ADD32(ctx->r24, 0X4040);
    // 0x803602E8: addiu       $t7, $zero, 0x80
    ctx->r15 = ADD32(0, 0X80);
    // 0x803602EC: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x803602F0: addiu       $t6, $zero, 0x33F
    ctx->r14 = ADD32(0, 0X33F);
    // 0x803602F4: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x803602F8: addiu       $t9, $t9, 0x4010
    ctx->r25 = ADD32(ctx->r25, 0X4010);
    // 0x803602FC: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80360300: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x80360304: lui         $t5, 0x803B
    ctx->r13 = S32(0X803B << 16);
    // 0x80360308: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x8036030C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80360310: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80360314: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80360318: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    // 0x8036031C: addiu       $t7, $sp, 0x94
    ctx->r15 = ADD32(ctx->r29, 0X94);
    // 0x80360320: addiu       $t6, $t6, 0x40E4
    ctx->r14 = ADD32(ctx->r14, 0X40E4);
    // 0x80360324: addiu       $t9, $zero, 0x80
    ctx->r25 = ADD32(0, 0X80);
    // 0x80360328: addiu       $t8, $t8, 0x4084
    ctx->r24 = ADD32(ctx->r24, 0X4084);
    // 0x8036032C: addiu       $t5, $t5, 0x40B4
    ctx->r13 = ADD32(ctx->r13, 0X40B4);
    // 0x80360330: sw          $t5, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r13;
    // 0x80360334: sw          $t8, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r24;
    // 0x80360338: sw          $t9, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r25;
    // 0x8036033C: sw          $t6, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r14;
    // 0x80360340: sw          $t7, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r15;
    // 0x80360344: addiu       $a0, $zero, 0x33F
    ctx->r4 = ADD32(0, 0X33F);
    // 0x80360348: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8036034C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80360350: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x80360354: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80360358: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x8036035C: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80360360: jal         0x802BF3C0
    // 0x80360364: sw          $zero, 0x38($sp)
    MEM_W(0X38, ctx->r29) = 0;
    update_limbs_rigid(rdram, ctx);
        goto after_12;
    // 0x80360364: sw          $zero, 0x38($sp)
    MEM_W(0X38, ctx->r29) = 0;
    after_12:
    // 0x80360368: jal         0x802B964C
    // 0x8036036C: nop

    func_802B964C_6CACFC(rdram, ctx);
        goto after_13;
    // 0x8036036C: nop

    after_13:
    // 0x80360370: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x80360374: addiu       $t1, $t1, 0x3FE0
    ctx->r9 = ADD32(ctx->r9, 0X3FE0);
    // 0x80360378: lh          $v0, 0x0($t1)
    ctx->r2 = MEM_H(ctx->r9, 0X0);
    // 0x8036037C: lh          $v1, 0x4($t1)
    ctx->r3 = MEM_H(ctx->r9, 0X4);
    // 0x80360380: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80360384: sh          $v0, 0xD8($t1)
    MEM_H(0XD8, ctx->r9) = ctx->r2;
    // 0x80360388: sh          $v0, 0xD0($t1)
    MEM_H(0XD0, ctx->r9) = ctx->r2;
    // 0x8036038C: lh          $v0, 0x2($t1)
    ctx->r2 = MEM_H(ctx->r9, 0X2);
    // 0x80360390: addiu       $t9, $v1, 0x251
    ctx->r25 = ADD32(ctx->r3, 0X251);
    // 0x80360394: addiu       $t8, $v1, -0x251
    ctx->r24 = ADD32(ctx->r3, -0X251);
    // 0x80360398: sh          $t9, 0xD4($t1)
    MEM_H(0XD4, ctx->r9) = ctx->r25;
    // 0x8036039C: sh          $t8, 0xDC($t1)
    MEM_H(0XDC, ctx->r9) = ctx->r24;
    // 0x803603A0: sh          $v0, 0xDA($t1)
    MEM_H(0XDA, ctx->r9) = ctx->r2;
    // 0x803603A4: sh          $v0, 0xD2($t1)
    MEM_H(0XD2, ctx->r9) = ctx->r2;
    // 0x803603A8: lhu         $a0, 0x2ECC($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X2ECC);
L_803603AC:
    // 0x803603AC: beq         $a0, $zero, L_8036042C
    if (ctx->r4 == 0) {
        // 0x803603B0: nop
    
            goto L_8036042C;
    }
    // 0x803603B0: nop

    // 0x803603B4: jal         0x802DB8DC
    // 0x803603B8: nop

    backup_joint_positions(rdram, ctx);
        goto after_14;
    // 0x803603B8: nop

    after_14:
    // 0x803603BC: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803603C0: lhu         $v1, 0x2ECE($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X2ECE);
    // 0x803603C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803603C8: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803603CC: beq         $v1, $at, L_803603E8
    if (ctx->r3 == ctx->r1) {
        // 0x803603D0: addiu       $a0, $a0, 0x40F8
        ctx->r4 = ADD32(ctx->r4, 0X40F8);
            goto L_803603E8;
    }
    // 0x803603D0: addiu       $a0, $a0, 0x40F8
    ctx->r4 = ADD32(ctx->r4, 0X40F8);
    // 0x803603D4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803603D8: beq         $v1, $at, L_8036040C
    if (ctx->r3 == ctx->r1) {
        // 0x803603DC: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_8036040C;
    }
    // 0x803603DC: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x803603E0: b           L_8036042C
    // 0x803603E4: nop

        goto L_8036042C;
    // 0x803603E4: nop

L_803603E8:
    // 0x803603E8: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x803603EC: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x803603F0: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x803603F4: addiu       $a3, $a3, 0x4130
    ctx->r7 = ADD32(ctx->r7, 0X4130);
    // 0x803603F8: addiu       $a2, $a2, 0x4118
    ctx->r6 = ADD32(ctx->r6, 0X4118);
    // 0x803603FC: jal         0x802DB670
    // 0x80360400: addiu       $a1, $a1, 0x4108
    ctx->r5 = ADD32(ctx->r5, 0X4108);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_15;
    // 0x80360400: addiu       $a1, $a1, 0x4108
    ctx->r5 = ADD32(ctx->r5, 0X4108);
    after_15:
    // 0x80360404: b           L_8036042C
    // 0x80360408: nop

        goto L_8036042C;
    // 0x80360408: nop

L_8036040C:
    // 0x8036040C: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80360410: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80360414: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80360418: addiu       $a3, $a3, 0x4168
    ctx->r7 = ADD32(ctx->r7, 0X4168);
    // 0x8036041C: addiu       $a2, $a2, 0x4118
    ctx->r6 = ADD32(ctx->r6, 0X4118);
    // 0x80360420: addiu       $a1, $a1, 0x4108
    ctx->r5 = ADD32(ctx->r5, 0X4108);
    // 0x80360424: jal         0x802DB670
    // 0x80360428: addiu       $a0, $a0, 0x40F8
    ctx->r4 = ADD32(ctx->r4, 0X40F8);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_16;
    // 0x80360428: addiu       $a0, $a0, 0x40F8
    ctx->r4 = ADD32(ctx->r4, 0X40F8);
    after_16:
L_8036042C:
    // 0x8036042C: jal         0x8038064C
    // 0x80360430: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_17;
    // 0x80360430: nop

    after_17:
    // 0x80360434: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x80360438: addiu       $t3, $t3, 0x4278
    ctx->r11 = ADD32(ctx->r11, 0X4278);
    // 0x8036043C: lw          $t0, 0x0($t3)
    ctx->r8 = MEM_W(ctx->r11, 0X0);
    // 0x80360440: lui         $t4, 0x3
    ctx->r12 = S32(0X3 << 16);
    // 0x80360444: ori         $t4, $t4, 0x8000
    ctx->r12 = ctx->r12 | 0X8000;
    // 0x80360448: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x8036044C: lw          $t2, 0x918($t5)
    ctx->r10 = MEM_W(ctx->r13, 0X918);
    // 0x80360450: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80360454: addiu       $t6, $t2, 0x1E
    ctx->r14 = ADD32(ctx->r10, 0X1E);
    // 0x80360458: slti        $at, $t6, 0xFA
    ctx->r1 = SIGNED(ctx->r14) < 0XFA ? 1 : 0;
    // 0x8036045C: beq         $at, $zero, L_80360C90
    if (ctx->r1 == 0) {
        // 0x80360460: nop
    
            goto L_80360C90;
    }
    // 0x80360460: nop

    // 0x80360464: lbu         $t7, 0x2EDA($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDA);
    // 0x80360468: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8036046C: beq         $t7, $zero, L_80360C90
    if (ctx->r15 == 0) {
        // 0x80360470: nop
    
            goto L_80360C90;
    }
    // 0x80360470: nop

    // 0x80360474: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80360478: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8036047C: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80360480: bne         $a0, $zero, L_803604B8
    if (ctx->r4 != 0) {
        // 0x80360484: nop
    
            goto L_803604B8;
    }
    // 0x80360484: nop

    // 0x80360488: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x8036048C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80360490: beq         $v0, $zero, L_803604B8
    if (ctx->r2 == 0) {
        // 0x80360494: nop
    
            goto L_803604B8;
    }
    // 0x80360494: nop

    // 0x80360498: beq         $v0, $at, L_803604B8
    if (ctx->r2 == ctx->r1) {
        // 0x8036049C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803604B8;
    }
    // 0x8036049C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803604A0: bne         $v0, $at, L_80360C90
    if (ctx->r2 != ctx->r1) {
        // 0x803604A4: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_80360C90;
    }
    // 0x803604A4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803604A8: lbu         $t9, 0x2AA3($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2AA3);
    // 0x803604AC: slti        $at, $t9, 0xB
    ctx->r1 = SIGNED(ctx->r25) < 0XB ? 1 : 0;
    // 0x803604B0: bne         $at, $zero, L_80360C90
    if (ctx->r1 != 0) {
        // 0x803604B4: nop
    
            goto L_80360C90;
    }
    // 0x803604B4: nop

L_803604B8:
    // 0x803604B8: lh          $t8, 0x2C18($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C18);
    // 0x803604BC: bne         $t8, $zero, L_80360514
    if (ctx->r24 != 0) {
        // 0x803604C0: nop
    
            goto L_80360514;
    }
    // 0x803604C0: nop

    // 0x803604C4: beq         $a0, $zero, L_80360514
    if (ctx->r4 == 0) {
        // 0x803604C8: lui         $t5, 0x803F
        ctx->r13 = S32(0X803F << 16);
            goto L_80360514;
    }
    // 0x803604C8: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803604CC: lh          $t5, 0x2A98($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2A98);
    // 0x803604D0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803604D4: addiu       $t7, $t7, 0x28E0
    ctx->r15 = ADD32(ctx->r15, 0X28E0);
    // 0x803604D8: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x803604DC: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x803604E0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x803604E4: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x803604E8: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x803604EC: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x803604F0: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x803604F4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803604F8: beq         $v1, $at, L_80360508
    if (ctx->r3 == ctx->r1) {
        // 0x803604FC: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80360508;
    }
    // 0x803604FC: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80360500: bne         $v1, $at, L_80360514
    if (ctx->r3 != ctx->r1) {
        // 0x80360504: nop
    
            goto L_80360514;
    }
    // 0x80360504: nop

L_80360508:
    // 0x80360508: lb          $t9, 0x64($v0)
    ctx->r25 = MEM_B(ctx->r2, 0X64);
    // 0x8036050C: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80360510: beq         $t9, $at, L_80360C90
    if (ctx->r25 == ctx->r1) {
        // 0x80360514: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_80360C90;
    }
L_80360514:
    // 0x80360514: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80360518: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x8036051C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80360520: lw          $t9, 0x2EB0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB0);
    // 0x80360524: lh          $t6, 0x302($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X302);
    // 0x80360528: sll         $t8, $t2, 6
    ctx->r24 = S32(ctx->r10 << 6);
    // 0x8036052C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80360530: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80360534: addu        $a0, $t0, $t8
    ctx->r4 = ADD32(ctx->r8, ctx->r24);
    // 0x80360538: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8036053C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80360540: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80360544: negu        $t7, $t6
    ctx->r15 = SUB32(0, ctx->r14);
    // 0x80360548: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x8036054C: lw          $t5, 0x2EB4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EB4);
    // 0x80360550: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x80360554: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x80360558: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x8036055C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80360560: bgez        $t9, L_80360570
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80360564: sra         $t8, $t9, 2
        ctx->r24 = S32(SIGNED(ctx->r25) >> 2);
            goto L_80360570;
    }
    // 0x80360564: sra         $t8, $t9, 2
    ctx->r24 = S32(SIGNED(ctx->r25) >> 2);
    // 0x80360568: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x8036056C: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_80360570:
    // 0x80360570: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80360574: lw          $t7, 0x2EB8($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EB8);
    // 0x80360578: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8036057C: bgez        $t5, L_8036058C
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80360580: sra         $t6, $t5, 2
        ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
            goto L_8036058C;
    }
    // 0x80360580: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80360584: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x80360588: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_8036058C:
    // 0x8036058C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80360590: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80360594: lh          $t8, 0x2ED2($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED2);
    // 0x80360598: lw          $t5, 0x2ED4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2ED4);
    // 0x8036059C: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x803605A0: bgez        $t7, L_803605B0
    if (SIGNED(ctx->r15) >= 0) {
        // 0x803605A4: sra         $t9, $t7, 2
        ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
            goto L_803605B0;
    }
    // 0x803605A4: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x803605A8: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x803605AC: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_803605B0:
    // 0x803605B0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x803605B4: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x803605B8: jal         0x80127640
    // 0x803605BC: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    func_80127640(rdram, ctx);
        goto after_18;
    // 0x803605BC: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    after_18:
    // 0x803605C0: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x803605C4: addiu       $t2, $t2, -0x6178
    ctx->r10 = ADD32(ctx->r10, -0X6178);
    // 0x803605C8: lw          $v0, 0x0($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X0);
    // 0x803605CC: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x803605D0: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x803605D4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803605D8: sw          $t6, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r14;
    // 0x803605DC: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x803605E0: addiu       $t3, $t3, 0x4278
    ctx->r11 = ADD32(ctx->r11, 0X4278);
    // 0x803605E4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803605E8: lw          $t0, 0x0($t3)
    ctx->r8 = MEM_W(ctx->r11, 0X0);
    // 0x803605EC: lui         $t4, 0x3
    ctx->r12 = S32(0X3 << 16);
    // 0x803605F0: ori         $t4, $t4, 0x8000
    ctx->r12 = ctx->r12 | 0X8000;
    // 0x803605F4: addu        $t9, $t0, $t4
    ctx->r25 = ADD32(ctx->r8, ctx->r12);
    // 0x803605F8: lw          $t8, 0x918($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X918);
    // 0x803605FC: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80360600: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80360604: sll         $t5, $t8, 6
    ctx->r13 = S32(ctx->r24 << 6);
    // 0x80360608: addu        $t6, $t0, $t5
    ctx->r14 = ADD32(ctx->r8, ctx->r13);
    // 0x8036060C: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x80360610: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80360614: lw          $t0, 0x0($t3)
    ctx->r8 = MEM_W(ctx->r11, 0X0);
    // 0x80360618: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8036061C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80360620: addu        $t9, $t0, $t4
    ctx->r25 = ADD32(ctx->r8, ctx->r12);
    // 0x80360624: lw          $t8, 0x918($t9)
    ctx->r24 = MEM_W(ctx->r25, 0X918);
    // 0x80360628: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8036062C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80360630: addiu       $t5, $t8, 0x1
    ctx->r13 = ADD32(ctx->r24, 0X1);
    // 0x80360634: sw          $t5, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r13;
    // 0x80360638: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x8036063C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80360640: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80360644: lhu         $a0, 0xBA($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XBA);
    // 0x80360648: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x8036064C: sll         $t7, $a0, 3
    ctx->r15 = S32(ctx->r4 << 3);
    // 0x80360650: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x80360654: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360658: lwc1        $f6, -0x13E0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0X13E0);
    // 0x8036065C: mflo        $t9
    ctx->r25 = lo;
    // 0x80360660: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x80360664: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80360668: jal         0x8038C230
    // 0x8036066C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_19;
    // 0x8036066C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    after_19:
    // 0x80360670: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80360674: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80360678: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8036067C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360680: lbu         $t7, 0x366($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X366);
    // 0x80360684: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360688: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x8036068C: beq         $t7, $at, L_803606DC
    if (ctx->r15 == ctx->r1) {
        // 0x80360690: addiu       $a1, $zero, 0x1B
        ctx->r5 = ADD32(0, 0X1B);
            goto L_803606DC;
    }
    // 0x80360690: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x80360694: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80360698: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x8036069C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803606A0: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x803606A4: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x803606A8: addiu       $t8, $t8, 0x2D90
    ctx->r24 = ADD32(ctx->r24, 0X2D90);
    // 0x803606AC: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x803606B0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803606B4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803606B8: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x803606BC: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x803606C0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803606C4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803606C8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803606CC: jal         0x802C78B0
    // 0x803606D0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_20;
    // 0x803606D0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_20:
    // 0x803606D4: b           L_8036070C
    // 0x803606D8: nop

        goto L_8036070C;
    // 0x803606D8: nop

L_803606DC:
    // 0x803606DC: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803606E0: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x803606E4: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x803606E8: addiu       $t7, $t7, 0x32E8
    ctx->r15 = ADD32(ctx->r15, 0X32E8);
    // 0x803606EC: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803606F0: addu        $a3, $a2, $zero
    ctx->r7 = ADD32(ctx->r6, 0);
    // 0x803606F4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803606F8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803606FC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80360700: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360704: jal         0x802C78B0
    // 0x80360708: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_21;
    // 0x80360708: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_21:
L_8036070C:
    // 0x8036070C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80360710: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x80360714: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x80360718: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8036071C: lhu         $v0, 0x0($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X0);
    // 0x80360720: beq         $v0, $at, L_80360738
    if (ctx->r2 == ctx->r1) {
        // 0x80360724: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_80360738;
    }
    // 0x80360724: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x80360728: beq         $v0, $at, L_80360738
    if (ctx->r2 == ctx->r1) {
        // 0x8036072C: addiu       $at, $zero, 0x8D
        ctx->r1 = ADD32(0, 0X8D);
            goto L_80360738;
    }
    // 0x8036072C: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x80360730: bnel        $v0, $at, L_803607C8
    if (ctx->r2 != ctx->r1) {
        // 0x80360734: addiu       $t6, $zero, -0x1
        ctx->r14 = ADD32(0, -0X1);
            goto L_803607C8;
    }
    goto skip_3;
    // 0x80360734: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    skip_3:
L_80360738:
    // 0x80360738: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8036073C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360740: ldc1        $f16, -0x13D8($at)
    CHECK_FR(ctx, 16);
    ctx->f16.u64 = LD(ctx->r1, -0X13D8);
    // 0x80360744: lh          $t5, 0x35A($t8)
    ctx->r13 = MEM_H(ctx->r24, 0X35A);
    // 0x80360748: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x8036074C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80360750: negu        $t6, $t5
    ctx->r14 = SUB32(0, ctx->r13);
    // 0x80360754: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80360758: nop

    // 0x8036075C: cvt.d.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.d = CVT_D_W(ctx->f8.u32l);
    // 0x80360760: div.d       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f16.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f16.d);
    // 0x80360764: trunc.w.d   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x80360768: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x8036076C: nop

    // 0x80360770: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x80360774: jal         0x803032DC
    // 0x80360778: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    func_803032DC_71498C(rdram, ctx);
        goto after_22;
    // 0x80360778: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    after_22:
    // 0x8036077C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80360780: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80360784: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360788: ldc1        $f10, -0x13D0($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X13D0);
    // 0x8036078C: lh          $t6, 0x35A($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X35A);
    // 0x80360790: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    // 0x80360794: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80360798: negu        $t7, $t6
    ctx->r15 = SUB32(0, ctx->r14);
    // 0x8036079C: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x803607A0: nop

    // 0x803607A4: cvt.d.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.d = CVT_D_W(ctx->f6.u32l);
    // 0x803607A8: div.d       $f16, $f8, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f16.d = DIV_D(ctx->f8.d, ctx->f10.d);
    // 0x803607AC: trunc.w.d   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_D(ctx->f16.d);
    // 0x803607B0: mfc1        $a2, $f18
    ctx->r6 = (int32_t)ctx->f18.u32l;
    // 0x803607B4: nop

    // 0x803607B8: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x803607BC: jal         0x803032DC
    // 0x803607C0: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    func_803032DC_71498C(rdram, ctx);
        goto after_23;
    // 0x803607C0: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    after_23:
    // 0x803607C4: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
L_803607C8:
    // 0x803607C8: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x803607CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x803607D0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803607D4: addiu       $a0, $zero, 0x164
    ctx->r4 = ADD32(0, 0X164);
    // 0x803607D8: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x803607DC: addiu       $a2, $zero, 0x1B
    ctx->r6 = ADD32(0, 0X1B);
    // 0x803607E0: jal         0x8038CCF0
    // 0x803607E4: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    func_8038CCF0_79E3A0(rdram, ctx);
        goto after_24;
    // 0x803607E4: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_24:
    // 0x803607E8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803607EC: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x803607F0: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x803607F4: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x803607F8: lhu         $v1, 0x9C($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X9C);
    // 0x803607FC: addiu       $t1, $t1, 0x3FE0
    ctx->r9 = ADD32(ctx->r9, 0X3FE0);
    // 0x80360800: beq         $v1, $at, L_8036081C
    if (ctx->r3 == ctx->r1) {
        // 0x80360804: addiu       $at, $zero, 0x22
        ctx->r1 = ADD32(0, 0X22);
            goto L_8036081C;
    }
    // 0x80360804: addiu       $at, $zero, 0x22
    ctx->r1 = ADD32(0, 0X22);
    // 0x80360808: beq         $v1, $at, L_80360874
    if (ctx->r3 == ctx->r1) {
        // 0x8036080C: lui         $a2, 0x1
        ctx->r6 = S32(0X1 << 16);
            goto L_80360874;
    }
    // 0x8036080C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360810: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80360814: b           L_80360908
    // 0x80360818: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
        goto L_80360908;
    // 0x80360818: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
L_8036081C:
    // 0x8036081C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80360820: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
    // 0x80360824: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x80360828: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x8036082C: bne         $v1, $zero, L_80360908
    if (ctx->r3 != 0) {
        // 0x80360830: lui         $a2, 0x1
        ctx->r6 = S32(0X1 << 16);
            goto L_80360908;
    }
    // 0x80360830: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360834: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80360838: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x8036083C: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80360840: addiu       $t6, $t6, 0x36B0
    ctx->r14 = ADD32(ctx->r14, 0X36B0);
    // 0x80360844: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360848: addu        $a3, $a2, $zero
    ctx->r7 = ADD32(ctx->r6, 0);
    // 0x8036084C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80360850: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80360854: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80360858: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8036085C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360860: jal         0x802C78B0
    // 0x80360864: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_25;
    // 0x80360864: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_25:
    // 0x80360868: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8036086C: b           L_80360908
    // 0x80360870: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
        goto L_80360908;
    // 0x80360870: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
L_80360874:
    // 0x80360874: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80360878: lh          $v0, 0x2ED8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2ED8);
    // 0x8036087C: lh          $t9, 0xD2($t1)
    ctx->r25 = MEM_H(ctx->r9, 0XD2);
    // 0x80360880: lh          $t5, 0xDA($t1)
    ctx->r13 = MEM_H(ctx->r9, 0XDA);
    // 0x80360884: sll         $t7, $v0, 5
    ctx->r15 = S32(ctx->r2 << 5);
    // 0x80360888: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x8036088C: addu        $t6, $t5, $t7
    ctx->r14 = ADD32(ctx->r13, ctx->r15);
    // 0x80360890: sh          $t8, 0xD2($t1)
    MEM_H(0XD2, ctx->r9) = ctx->r24;
    // 0x80360894: sh          $t6, 0xDA($t1)
    MEM_H(0XDA, ctx->r9) = ctx->r14;
    // 0x80360898: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8036089C: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x803608A0: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803608A4: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x803608A8: addiu       $t9, $t9, 0x3DE0
    ctx->r25 = ADD32(ctx->r25, 0X3DE0);
    // 0x803608AC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803608B0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803608B4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803608B8: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x803608BC: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x803608C0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803608C4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803608C8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803608CC: jal         0x802C78B0
    // 0x803608D0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_26;
    // 0x803608D0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_26:
    // 0x803608D4: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x803608D8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803608DC: lh          $v0, 0x2ED8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2ED8);
    // 0x803608E0: addiu       $t1, $t1, 0x3FE0
    ctx->r9 = ADD32(ctx->r9, 0X3FE0);
    // 0x803608E4: lh          $t5, 0xD2($t1)
    ctx->r13 = MEM_H(ctx->r9, 0XD2);
    // 0x803608E8: lh          $t7, 0xDA($t1)
    ctx->r15 = MEM_H(ctx->r9, 0XDA);
    // 0x803608EC: sll         $t8, $v0, 5
    ctx->r24 = S32(ctx->r2 << 5);
    // 0x803608F0: subu        $t6, $t5, $t8
    ctx->r14 = SUB32(ctx->r13, ctx->r24);
    // 0x803608F4: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x803608F8: sh          $t6, 0xD2($t1)
    MEM_H(0XD2, ctx->r9) = ctx->r14;
    // 0x803608FC: sh          $t9, 0xDA($t1)
    MEM_H(0XDA, ctx->r9) = ctx->r25;
    // 0x80360900: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80360904: lbu         $v1, 0x2EDD($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2EDD);
L_80360908:
    // 0x80360908: bne         $v1, $zero, L_8036094C
    if (ctx->r3 != 0) {
        // 0x8036090C: lui         $a2, 0x1
        ctx->r6 = S32(0X1 << 16);
            goto L_8036094C;
    }
    // 0x8036090C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360910: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80360914: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80360918: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x8036091C: addiu       $t5, $t5, 0x3580
    ctx->r13 = ADD32(ctx->r13, 0X3580);
    // 0x80360920: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360924: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80360928: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8036092C: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80360930: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x80360934: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x80360938: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8036093C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80360940: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360944: jal         0x802C78B0
    // 0x80360948: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_27;
    // 0x80360948: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_27:
L_8036094C:
    // 0x8036094C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80360950: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80360954: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360958: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x8036095C: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360960: addiu       $t7, $t7, 0x3580
    ctx->r15 = ADD32(ctx->r15, 0X3580);
    // 0x80360964: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80360968: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8036096C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80360970: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    // 0x80360974: addiu       $a1, $zero, 0xD
    ctx->r5 = ADD32(0, 0XD);
    // 0x80360978: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8036097C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80360980: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360984: jal         0x802C78B0
    // 0x80360988: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_28;
    // 0x80360988: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_28:
    // 0x8036098C: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x80360990: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x80360994: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x80360998: lui         $t8, 0xB600
    ctx->r24 = S32(0XB600 << 16);
    // 0x8036099C: addiu       $t5, $zero, 0x2000
    ctx->r13 = ADD32(0, 0X2000);
    // 0x803609A0: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x803609A4: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x803609A8: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x803609AC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x803609B0: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x803609B4: addiu       $t9, $zero, 0x1000
    ctx->r25 = ADD32(0, 0X1000);
    // 0x803609B8: lui         $t7, 0xB700
    ctx->r15 = S32(0XB700 << 16);
    // 0x803609BC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803609C0: sw          $t6, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r14;
    // 0x803609C4: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x803609C8: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803609CC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803609D0: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x803609D4: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x803609D8: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x803609DC: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x803609E0: addiu       $t6, $t6, 0x3580
    ctx->r14 = ADD32(ctx->r14, 0X3580);
    // 0x803609E4: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x803609E8: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x803609EC: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x803609F0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x803609F4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803609F8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803609FC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80360A00: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x80360A04: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x80360A08: jal         0x802C78B0
    // 0x80360A0C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x80360A0C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_29:
    // 0x80360A10: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80360A14: lbu         $t7, 0x2EDD($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDD);
    // 0x80360A18: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360A1C: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360A20: bne         $t7, $zero, L_80360A60
    if (ctx->r15 != 0) {
        // 0x80360A24: addiu       $a0, $zero, 0x6
        ctx->r4 = ADD32(0, 0X6);
            goto L_80360A60;
    }
    // 0x80360A24: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x80360A28: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80360A2C: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80360A30: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x80360A34: addiu       $t5, $t5, 0x3580
    ctx->r13 = ADD32(ctx->r13, 0X3580);
    // 0x80360A38: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80360A3C: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80360A40: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80360A44: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    // 0x80360A48: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80360A4C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80360A50: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80360A54: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360A58: jal         0x802C78B0
    // 0x80360A5C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_30;
    // 0x80360A5C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_30:
L_80360A60:
    // 0x80360A60: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80360A64: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80360A68: addiu       $at, $zero, 0x21
    ctx->r1 = ADD32(0, 0X21);
    // 0x80360A6C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80360A70: lhu         $t7, 0x9C($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X9C);
    // 0x80360A74: bne         $t7, $at, L_80360BC0
    if (ctx->r15 != ctx->r1) {
        // 0x80360A78: nop
    
            goto L_80360BC0;
    }
    // 0x80360A78: nop

    // 0x80360A7C: lbu         $t9, 0x2EDD($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2EDD);
    // 0x80360A80: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80360A84: bne         $t9, $zero, L_80360BC0
    if (ctx->r25 != 0) {
        // 0x80360A88: nop
    
            goto L_80360BC0;
    }
    // 0x80360A88: nop

    // 0x80360A8C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80360A90: addiu       $a1, $sp, 0x90
    ctx->r5 = ADD32(ctx->r29, 0X90);
    // 0x80360A94: addiu       $a2, $sp, 0x8E
    ctx->r6 = ADD32(ctx->r29, 0X8E);
    // 0x80360A98: lh          $a0, 0x326($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X326);
    // 0x80360A9C: addiu       $t8, $a0, 0x1
    ctx->r24 = ADD32(ctx->r4, 0X1);
    // 0x80360AA0: jal         0x8031A150
    // 0x80360AA4: sh          $t8, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r24;
    func_8031A150_72B800(rdram, ctx);
        goto after_31;
    // 0x80360AA4: sh          $t8, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r24;
    after_31:
    // 0x80360AA8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80360AAC: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80360AB0: addiu       $a1, $sp, 0x90
    ctx->r5 = ADD32(ctx->r29, 0X90);
    // 0x80360AB4: addiu       $a2, $sp, 0x8E
    ctx->r6 = ADD32(ctx->r29, 0X8E);
    // 0x80360AB8: jal         0x8031A278
    // 0x80360ABC: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_32;
    // 0x80360ABC: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_32:
    // 0x80360AC0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80360AC4: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80360AC8: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x80360ACC: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80360AD0: lbu         $t6, 0x365($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X365);
    // 0x80360AD4: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x80360AD8: addiu       $a0, $a0, 0xCC0
    ctx->r4 = ADD32(ctx->r4, 0XCC0);
    // 0x80360ADC: bne         $t6, $at, L_80360AF0
    if (ctx->r14 != ctx->r1) {
        // 0x80360AE0: lui         $a1, 0x100
        ctx->r5 = S32(0X100 << 16);
            goto L_80360AF0;
    }
    // 0x80360AE0: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80360AE4: addiu       $a2, $zero, 0x6
    ctx->r6 = ADD32(0, 0X6);
    // 0x80360AE8: sh          $a2, 0x90($sp)
    MEM_H(0X90, ctx->r29) = ctx->r6;
    // 0x80360AEC: sh          $t7, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r15;
L_80360AF0:
    // 0x80360AF0: lh          $a2, 0x90($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X90);
    // 0x80360AF4: lh          $t8, 0x8E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X8E);
    // 0x80360AF8: lui         $t6, 0x803C
    ctx->r14 = S32(0X803C << 16);
    // 0x80360AFC: sll         $t9, $a2, 1
    ctx->r25 = S32(ctx->r6 << 1);
    // 0x80360B00: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80360B04: sll         $t5, $t8, 1
    ctx->r13 = S32(ctx->r24 << 1);
    // 0x80360B08: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x80360B0C: addu        $a2, $a2, $t9
    ctx->r6 = ADD32(ctx->r6, ctx->r25);
    // 0x80360B10: lh          $a2, -0x2AB6($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2AB6);
    // 0x80360B14: lh          $t6, -0x29FE($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X29FE);
    // 0x80360B18: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80360B1C: sh          $a2, 0x90($sp)
    MEM_H(0X90, ctx->r29) = ctx->r6;
    // 0x80360B20: jal         0x80356BD8
    // 0x80360B24: sh          $t6, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r14;
    func_80356BD8_768288(rdram, ctx);
        goto after_33;
    // 0x80360B24: sh          $t6, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r14;
    after_33:
    // 0x80360B28: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80360B2C: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80360B30: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360B34: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80360B38: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360B3C: addiu       $t9, $t9, 0x37A0
    ctx->r25 = ADD32(ctx->r25, 0X37A0);
    // 0x80360B40: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80360B44: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80360B48: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80360B4C: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x80360B50: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x80360B54: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80360B58: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80360B5C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360B60: jal         0x802C78B0
    // 0x80360B64: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_34;
    // 0x80360B64: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_34:
    // 0x80360B68: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80360B6C: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80360B70: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80360B74: addiu       $a0, $a0, 0xCC0
    ctx->r4 = ADD32(ctx->r4, 0XCC0);
    // 0x80360B78: jal         0x80356BD8
    // 0x80360B7C: lh          $a2, 0x8E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8E);
    func_80356BD8_768288(rdram, ctx);
        goto after_35;
    // 0x80360B7C: lh          $a2, 0x8E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8E);
    after_35:
    // 0x80360B80: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80360B84: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80360B88: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80360B8C: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x80360B90: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80360B94: addiu       $t5, $t5, 0x37C0
    ctx->r13 = ADD32(ctx->r13, 0X37C0);
    // 0x80360B98: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80360B9C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80360BA0: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80360BA4: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x80360BA8: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x80360BAC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80360BB0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80360BB4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360BB8: jal         0x802C78B0
    // 0x80360BBC: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_36;
    // 0x80360BBC: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_36:
L_80360BC0:
    // 0x80360BC0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80360BC4: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80360BC8: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x80360BCC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80360BD0: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x80360BD4: beq         $v0, $at, L_80360BEC
    if (ctx->r2 == ctx->r1) {
        // 0x80360BD8: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_80360BEC;
    }
    // 0x80360BD8: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x80360BDC: beq         $v0, $at, L_80360BEC
    if (ctx->r2 == ctx->r1) {
        // 0x80360BE0: addiu       $at, $zero, 0x8D
        ctx->r1 = ADD32(0, 0X8D);
            goto L_80360BEC;
    }
    // 0x80360BE0: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x80360BE4: bne         $v0, $at, L_80360C70
    if (ctx->r2 != ctx->r1) {
        // 0x80360BE8: nop
    
            goto L_80360C70;
    }
    // 0x80360BE8: nop

L_80360BEC:
    // 0x80360BEC: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80360BF0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360BF4: ldc1        $f8, -0x13C8($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, -0X13C8);
    // 0x80360BF8: lh          $t9, 0x35A($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X35A);
    // 0x80360BFC: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x80360C00: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80360C04: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x80360C08: nop

    // 0x80360C0C: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x80360C10: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x80360C14: trunc.w.d   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_D(ctx->f10.d);
    // 0x80360C18: mfc1        $a2, $f16
    ctx->r6 = (int32_t)ctx->f16.u32l;
    // 0x80360C1C: nop

    // 0x80360C20: sll         $t5, $a2, 16
    ctx->r13 = S32(ctx->r6 << 16);
    // 0x80360C24: jal         0x803032DC
    // 0x80360C28: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    func_803032DC_71498C(rdram, ctx);
        goto after_37;
    // 0x80360C28: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    after_37:
    // 0x80360C2C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80360C30: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80360C34: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360C38: ldc1        $f6, -0x13C0($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X13C0);
    // 0x80360C3C: lh          $t9, 0x35A($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X35A);
    // 0x80360C40: addiu       $a0, $zero, 0x1B
    ctx->r4 = ADD32(0, 0X1B);
    // 0x80360C44: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80360C48: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x80360C4C: nop

    // 0x80360C50: cvt.d.w     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.d = CVT_D_W(ctx->f18.u32l);
    // 0x80360C54: div.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = DIV_D(ctx->f4.d, ctx->f6.d);
    // 0x80360C58: trunc.w.d   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_D(ctx->f8.d);
    // 0x80360C5C: mfc1        $a2, $f10
    ctx->r6 = (int32_t)ctx->f10.u32l;
    // 0x80360C60: nop

    // 0x80360C64: sll         $t5, $a2, 16
    ctx->r13 = S32(ctx->r6 << 16);
    // 0x80360C68: jal         0x803032DC
    // 0x80360C6C: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    func_803032DC_71498C(rdram, ctx);
        goto after_38;
    // 0x80360C6C: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    after_38:
L_80360C70:
    // 0x80360C70: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80360C74: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80360C78: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80360C7C: lui         $t9, 0xBD00
    ctx->r25 = S32(0XBD00 << 16);
    // 0x80360C80: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80360C84: sw          $t7, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r15;
    // 0x80360C88: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80360C8C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
L_80360C90:
    // 0x80360C90: jal         0x8035D6A0
    // 0x80360C94: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_39;
    // 0x80360C94: nop

    after_39:
    // 0x80360C98: b           L_80360CAC
    // 0x80360C9C: lh          $v1, 0x8C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X8C);
        goto L_80360CAC;
    // 0x80360C9C: lh          $v1, 0x8C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X8C);
L_80360CA0:
    // 0x80360CA0: jal         0x8035D6D0
    // 0x80360CA4: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_40;
    // 0x80360CA4: nop

    after_40:
    // 0x80360CA8: lh          $v1, 0x8C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X8C);
L_80360CAC:
    // 0x80360CAC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80360CB0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80360CB4: beq         $v1, $zero, L_80360CC4
    if (ctx->r3 == 0) {
        // 0x80360CB8: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_80360CC4;
    }
    // 0x80360CB8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80360CBC: bne         $v1, $at, L_80360D38
    if (ctx->r3 != ctx->r1) {
        // 0x80360CC0: nop
    
            goto L_80360D38;
    }
    // 0x80360CC0: nop

L_80360CC4:
    // 0x80360CC4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80360CC8: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x80360CCC: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x80360CD0: lhu         $t6, 0xBA($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0XBA);
    // 0x80360CD4: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x80360CD8: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x80360CDC: lh          $a3, 0x302($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X302);
    // 0x80360CE0: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80360CE4: addu        $a2, $t8, $t7
    ctx->r6 = ADD32(ctx->r24, ctx->r15);
    // 0x80360CE8: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x80360CEC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80360CF0: lbu         $t5, 0x5538($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X5538);
    // 0x80360CF4: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80360CF8: lui         $t6, 0x103
    ctx->r14 = S32(0X103 << 16);
    // 0x80360CFC: addiu       $t6, $t6, 0x3190
    ctx->r14 = ADD32(ctx->r14, 0X3190);
    // 0x80360D00: addiu       $t9, $zero, 0x9B
    ctx->r25 = ADD32(0, 0X9B);
    // 0x80360D04: addiu       $t7, $zero, 0x15
    ctx->r15 = ADD32(0, 0X15);
    // 0x80360D08: addiu       $t8, $zero, 0x15
    ctx->r24 = ADD32(0, 0X15);
    // 0x80360D0C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80360D10: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80360D14: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80360D18: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80360D1C: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80360D20: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80360D24: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80360D28: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80360D2C: jal         0x8034BD20
    // 0x80360D30: sw          $t5, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r13;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_41;
    // 0x80360D30: sw          $t5, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r13;
    after_41:
    // 0x80360D34: lh          $v1, 0x8C($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X8C);
L_80360D38:
    // 0x80360D38: bne         $v1, $zero, L_80360D74
    if (ctx->r3 != 0) {
        // 0x80360D3C: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80360D74;
    }
    // 0x80360D3C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80360D40: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80360D44: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80360D48: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80360D4C: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x80360D50: addiu       $a3, $zero, 0x251
    ctx->r7 = ADD32(0, 0X251);
    // 0x80360D54: jal         0x80303820
    // 0x80360D58: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_42;
    // 0x80360D58: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_42:
    // 0x80360D5C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80360D60: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80360D64: jal         0x80303D50
    // 0x80360D68: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    func_80303D50_715400(rdram, ctx);
        goto after_43;
    // 0x80360D68: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    after_43:
    // 0x80360D6C: b           L_80360D88
    // 0x80360D70: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
        goto L_80360D88;
    // 0x80360D70: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_80360D74:
    // 0x80360D74: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80360D78: addiu       $a1, $zero, 0x37A
    ctx->r5 = ADD32(0, 0X37A);
    // 0x80360D7C: jal         0x80303D00
    // 0x80360D80: addiu       $a2, $zero, 0x3F1
    ctx->r6 = ADD32(0, 0X3F1);
    func_80303D00_7153B0(rdram, ctx);
        goto after_44;
    // 0x80360D80: addiu       $a2, $zero, 0x3F1
    ctx->r6 = ADD32(0, 0X3F1);
    after_44:
    // 0x80360D84: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_80360D88:
    // 0x80360D88: addiu       $sp, $sp, 0x98
    ctx->r29 = ADD32(ctx->r29, 0X98);
    // 0x80360D8C: jr          $ra
    // 0x80360D90: nop

    return;
    // 0x80360D90: nop

;}
RECOMP_FUNC void update_springy_thingy_or_springy_ram(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80360D94: addiu       $sp, $sp, -0xB8
    ctx->r29 = ADD32(ctx->r29, -0XB8);
    // 0x80360D98: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x80360D9C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80360DA0: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80360DA4: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80360DA8: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x80360DAC: lhu         $v0, 0x0($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X0);
    // 0x80360DB0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80360DB4: beq         $v0, $at, L_80360DCC
    if (ctx->r2 == ctx->r1) {
        // 0x80360DB8: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_80360DCC;
    }
    // 0x80360DB8: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    // 0x80360DBC: beql        $v0, $at, L_80360DD8
    if (ctx->r2 == ctx->r1) {
        // 0x80360DC0: addiu       $v0, $zero, 0x60
        ctx->r2 = ADD32(0, 0X60);
            goto L_80360DD8;
    }
    goto skip_0;
    // 0x80360DC0: addiu       $v0, $zero, 0x60
    ctx->r2 = ADD32(0, 0X60);
    skip_0:
    // 0x80360DC4: b           L_80360DD8
    // 0x80360DC8: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
        goto L_80360DD8;
    // 0x80360DC8: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
L_80360DCC:
    // 0x80360DCC: b           L_80360DD8
    // 0x80360DD0: addiu       $v0, $zero, 0x50
    ctx->r2 = ADD32(0, 0X50);
        goto L_80360DD8;
    // 0x80360DD0: addiu       $v0, $zero, 0x50
    ctx->r2 = ADD32(0, 0X50);
    // 0x80360DD4: addiu       $v0, $zero, 0x60
    ctx->r2 = ADD32(0, 0X60);
L_80360DD8:
    // 0x80360DD8: lbu         $t6, 0x162($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X162);
    // 0x80360DDC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80360DE0: bne         $t6, $at, L_8036108C
    if (ctx->r14 != ctx->r1) {
        // 0x80360DE4: nop
    
            goto L_8036108C;
    }
    // 0x80360DE4: nop

    // 0x80360DE8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80360DEC: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80360DF0: mtc1        $zero, $f17
    ctx->f_odd[(17 - 1) * 2] = 0;
    // 0x80360DF4: lh          $a0, 0x30C($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X30C);
    // 0x80360DF8: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x80360DFC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80360E00: slt         $at, $a0, $v0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80360E04: beq         $at, $zero, L_80360E30
    if (ctx->r1 == 0) {
        // 0x80360E08: addiu       $a1, $a0, 0x9
        ctx->r5 = ADD32(ctx->r4, 0X9);
            goto L_80360E30;
    }
    // 0x80360E08: addiu       $a1, $a0, 0x9
    ctx->r5 = ADD32(ctx->r4, 0X9);
    // 0x80360E0C: slt         $at, $v0, $a1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x80360E10: beql        $at, $zero, L_80360E24
    if (ctx->r1 == 0) {
        // 0x80360E14: sh          $a1, 0x30C($v1)
        MEM_H(0X30C, ctx->r3) = ctx->r5;
            goto L_80360E24;
    }
    goto skip_1;
    // 0x80360E14: sh          $a1, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r5;
    skip_1:
    // 0x80360E18: b           L_80360E24
    // 0x80360E1C: sh          $v0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r2;
        goto L_80360E24;
    // 0x80360E1C: sh          $v0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r2;
    // 0x80360E20: sh          $a1, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r5;
L_80360E24:
    // 0x80360E24: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80360E28: b           L_80360E68
    // 0x80360E2C: lh          $a0, 0x30C($t7)
    ctx->r4 = MEM_H(ctx->r15, 0X30C);
        goto L_80360E68;
    // 0x80360E2C: lh          $a0, 0x30C($t7)
    ctx->r4 = MEM_H(ctx->r15, 0X30C);
L_80360E30:
    // 0x80360E30: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80360E34: beq         $at, $zero, L_80360E68
    if (ctx->r1 == 0) {
        // 0x80360E38: addiu       $a1, $a0, -0x1
        ctx->r5 = ADD32(ctx->r4, -0X1);
            goto L_80360E68;
    }
    // 0x80360E38: addiu       $a1, $a0, -0x1
    ctx->r5 = ADD32(ctx->r4, -0X1);
    // 0x80360E3C: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80360E40: beq         $at, $zero, L_80360E5C
    if (ctx->r1 == 0) {
        // 0x80360E44: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80360E5C;
    }
    // 0x80360E44: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80360E48: sh          $v0, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r2;
    // 0x80360E4C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80360E50: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80360E54: b           L_80360E68
    // 0x80360E58: lh          $a0, 0x30C($t8)
    ctx->r4 = MEM_H(ctx->r24, 0X30C);
        goto L_80360E68;
    // 0x80360E58: lh          $a0, 0x30C($t8)
    ctx->r4 = MEM_H(ctx->r24, 0X30C);
L_80360E5C:
    // 0x80360E5C: sh          $a1, 0x30C($v1)
    MEM_H(0X30C, ctx->r3) = ctx->r5;
    // 0x80360E60: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80360E64: lh          $a0, 0x30C($t9)
    ctx->r4 = MEM_H(ctx->r25, 0X30C);
L_80360E68:
    // 0x80360E68: addiu       $t2, $a0, -0x8
    ctx->r10 = ADD32(ctx->r4, -0X8);
    // 0x80360E6C: mtc1        $t2, $f4
    ctx->f4.u32l = ctx->r10;
    // 0x80360E70: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80360E74: mtc1        $at, $f15
    ctx->f_odd[(15 - 1) * 2] = ctx->r1;
    // 0x80360E78: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x80360E7C: lui         $at, 0x4056
    ctx->r1 = S32(0X4056 << 16);
    // 0x80360E80: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80360E84: mtc1        $zero, $f14
    ctx->f14.u32l = 0;
    // 0x80360E88: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80360E8C: div.d       $f12, $f6, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f12.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x80360E90: c.lt.d      $f14, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f14.d < ctx->f12.d;
    // 0x80360E94: nop

    // 0x80360E98: bc1fl       L_80360EAC
    if (!c1cs) {
        // 0x80360E9C: mov.d       $f0, $f12
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.d = ctx->f12.d;
            goto L_80360EAC;
    }
    goto skip_2;
    // 0x80360E9C: mov.d       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.d = ctx->f12.d;
    skip_2:
    // 0x80360EA0: b           L_80360EAC
    // 0x80360EA4: mov.d       $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    ctx->f0.d = ctx->f14.d;
        goto L_80360EAC;
    // 0x80360EA4: mov.d       $f0, $f14
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 14);
    ctx->f0.d = ctx->f14.d;
    // 0x80360EA8: mov.d       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.d = ctx->f12.d;
L_80360EAC:
    // 0x80360EAC: c.lt.d      $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.d < ctx->f16.d;
    // 0x80360EB0: nop

    // 0x80360EB4: bc1fl       L_80360EC8
    if (!c1cs) {
        // 0x80360EB8: c.lt.d      $f14, $f12
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f14.d < ctx->f12.d;
            goto L_80360EC8;
    }
    goto skip_3;
    // 0x80360EB8: c.lt.d      $f14, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f14.d < ctx->f12.d;
    skip_3:
    // 0x80360EBC: b           L_80360EE4
    // 0x80360EC0: cvt.s.d     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f12.fl = CVT_S_D(ctx->f16.d);
        goto L_80360EE4;
    // 0x80360EC0: cvt.s.d     $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f12.fl = CVT_S_D(ctx->f16.d);
    // 0x80360EC4: c.lt.d      $f14, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f14.d < ctx->f12.d;
L_80360EC8:
    // 0x80360EC8: nop

    // 0x80360ECC: bc1fl       L_80360EE0
    if (!c1cs) {
        // 0x80360ED0: mov.d       $f2, $f12
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    ctx->f2.d = ctx->f12.d;
            goto L_80360EE0;
    }
    goto skip_4;
    // 0x80360ED0: mov.d       $f2, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    ctx->f2.d = ctx->f12.d;
    skip_4:
    // 0x80360ED4: b           L_80360EE0
    // 0x80360ED8: mov.d       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.d = ctx->f14.d;
        goto L_80360EE0;
    // 0x80360ED8: mov.d       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.d = ctx->f14.d;
    // 0x80360EDC: mov.d       $f2, $f12
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 12);
    ctx->f2.d = ctx->f12.d;
L_80360EE0:
    // 0x80360EE0: cvt.s.d     $f12, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.d); 
    ctx->f12.fl = CVT_S_D(ctx->f2.d);
L_80360EE4:
    // 0x80360EE4: mul.s       $f12, $f12, $f12
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f12.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x80360EE8: cvt.d.s     $f14, $f12
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f14.d = CVT_D_S(ctx->f12.fl);
    // 0x80360EEC: c.eq.d      $f16, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.d == ctx->f14.d;
    // 0x80360EF0: nop

    // 0x80360EF4: bc1t        L_80361010
    if (c1cs) {
        // 0x80360EF8: nop
    
            goto L_80361010;
    }
    // 0x80360EF8: nop

    // 0x80360EFC: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80360F00: lb          $t3, 0x4A($s0)
    ctx->r11 = MEM_B(ctx->r16, 0X4A);
    // 0x80360F04: bne         $t3, $zero, L_80361010
    if (ctx->r11 != 0) {
        // 0x80360F08: nop
    
            goto L_80361010;
    }
    // 0x80360F08: nop

    // 0x80360F0C: mtc1        $a0, $f10
    ctx->f10.u32l = ctx->r4;
    // 0x80360F10: lui         $at, 0x4044
    ctx->r1 = S32(0X4044 << 16);
    // 0x80360F14: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80360F18: cvt.d.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.d = CVT_D_W(ctx->f10.u32l);
    // 0x80360F1C: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80360F20: mtc1        $zero, $f17
    ctx->f_odd[(17 - 1) * 2] = 0;
    // 0x80360F24: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x80360F28: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80360F2C: div.d       $f0, $f4, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f0.d = DIV_D(ctx->f4.d, ctx->f6.d);
    // 0x80360F30: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80360F34: c.lt.d      $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.d < ctx->f16.d;
    // 0x80360F38: nop

    // 0x80360F3C: bc1fl       L_80360F50
    if (!c1cs) {
        // 0x80360F40: mov.d       $f2, $f0
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
            goto L_80360F50;
    }
    goto skip_5;
    // 0x80360F40: mov.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
    skip_5:
    // 0x80360F44: b           L_80360F50
    // 0x80360F48: neg.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f2.d = -ctx->f0.d;
        goto L_80360F50;
    // 0x80360F48: neg.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f2.d = -ctx->f0.d;
    // 0x80360F4C: mov.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
L_80360F50:
    // 0x80360F50: ldc1        $f18, -0x13B8($at)
    CHECK_FR(ctx, 18);
    ctx->f18.u64 = LD(ctx->r1, -0X13B8);
    // 0x80360F54: lui         $at, 0x46B4
    ctx->r1 = S32(0X46B4 << 16);
    // 0x80360F58: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80360F5C: c.lt.d      $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    c1cs = ctx->f2.d < ctx->f18.d;
    // 0x80360F60: lui         $at, 0x4008
    ctx->r1 = S32(0X4008 << 16);
    // 0x80360F64: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80360F68: mul.s       $f10, $f12, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f12.fl, ctx->f8.fl);
    // 0x80360F6C: bc1fl       L_80360F80
    if (!c1cs) {
        // 0x80360F70: c.lt.d      $f0, $f16
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.d < ctx->f16.d;
            goto L_80360F80;
    }
    goto skip_6;
    // 0x80360F70: c.lt.d      $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.d < ctx->f16.d;
    skip_6:
    // 0x80360F74: b           L_80360F9C
    // 0x80360F78: mov.d       $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    ctx->f0.d = ctx->f18.d;
        goto L_80360F9C;
    // 0x80360F78: mov.d       $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    ctx->f0.d = ctx->f18.d;
    // 0x80360F7C: c.lt.d      $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f0.d < ctx->f16.d;
L_80360F80:
    // 0x80360F80: nop

    // 0x80360F84: bc1fl       L_80360F98
    if (!c1cs) {
        // 0x80360F88: mov.d       $f2, $f0
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
            goto L_80360F98;
    }
    goto skip_7;
    // 0x80360F88: mov.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
    skip_7:
    // 0x80360F8C: b           L_80360F98
    // 0x80360F90: neg.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f2.d = -ctx->f0.d;
        goto L_80360F98;
    // 0x80360F90: neg.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.d); 
    ctx->f2.d = -ctx->f0.d;
    // 0x80360F94: mov.d       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.d = ctx->f0.d;
L_80360F98:
    // 0x80360F98: mov.d       $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    ctx->f0.d = ctx->f2.d;
L_80360F9C:
    // 0x80360F9C: div.d       $f8, $f0, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = DIV_D(ctx->f0.d, ctx->f6.d);
    // 0x80360FA0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80360FA4: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x80360FA8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80360FAC: trunc.w.s   $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80360FB0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80360FB4: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x80360FB8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80360FBC: mfc1        $a2, $f4
    ctx->r6 = (int32_t)ctx->f4.u32l;
    // 0x80360FC0: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80360FC4: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x80360FC8: sll         $t5, $a2, 16
    ctx->r13 = S32(ctx->r6 << 16);
    // 0x80360FCC: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80360FD0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80360FD4: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x80360FD8: addiu       $a1, $zero, 0x7D
    ctx->r5 = ADD32(0, 0X7D);
    // 0x80360FDC: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x80360FE0: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x80360FE4: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x80360FE8: lw          $t4, 0x20($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X20);
    // 0x80360FEC: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    // 0x80360FF0: lw          $t5, 0x24($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X24);
    // 0x80360FF4: sdc1        $f14, 0x58($sp)
    CHECK_FR(ctx, 14);
    SD(ctx->f14.u64, 0X58, ctx->r29);
    // 0x80360FF8: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    // 0x80360FFC: cvt.s.d     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f10.fl = CVT_S_D(ctx->f8.d);
    // 0x80361000: mfc1        $a3, $f10
    ctx->r7 = (int32_t)ctx->f10.u32l;
    // 0x80361004: jal         0x8032CED0
    // 0x80361008: nop

    func_8032CED0_73E580(rdram, ctx);
        goto after_0;
    // 0x80361008: nop

    after_0:
    // 0x8036100C: ldc1        $f14, 0x58($sp)
    CHECK_FR(ctx, 14);
    ctx->f14.u64 = LD(ctx->r29, 0X58);
L_80361010:
    // 0x80361010: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80361014: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80361018: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x8036101C: beq         $t6, $zero, L_8036108C
    if (ctx->r14 == 0) {
        // 0x80361020: nop
    
            goto L_8036108C;
    }
    // 0x80361020: nop

    // 0x80361024: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x80361028: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x8036102C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80361030: c.lt.d      $f4, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f4.d < ctx->f14.d;
    // 0x80361034: nop

    // 0x80361038: bc1f        L_8036108C
    if (!c1cs) {
        // 0x8036103C: nop
    
            goto L_8036108C;
    }
    // 0x8036103C: nop

    // 0x80361040: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x80361044: andi        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 & 0X1;
    // 0x80361048: bne         $t8, $zero, L_8036108C
    if (ctx->r24 != 0) {
        // 0x8036104C: nop
    
            goto L_8036108C;
    }
    // 0x8036104C: nop

    // 0x80361050: jal         0x8012826C
    // 0x80361054: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x80361054: nop

    after_1:
    // 0x80361058: andi        $t9, $v0, 0x20
    ctx->r25 = ctx->r2 & 0X20;
    // 0x8036105C: beq         $t9, $zero, L_8036108C
    if (ctx->r25 == 0) {
        // 0x80361060: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_8036108C;
    }
    // 0x80361060: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361064: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361068: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8036106C: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x80361070: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x80361074: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x80361078: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x8036107C: lhu         $a0, 0x7C($t0)
    ctx->r4 = MEM_HU(ctx->r8, 0X7C);
    // 0x80361080: lhu         $a1, 0x9C($t0)
    ctx->r5 = MEM_HU(ctx->r8, 0X9C);
    // 0x80361084: jal         0x8032CA90
    // 0x80361088: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    func_8032CA90_73E140(rdram, ctx);
        goto after_2;
    // 0x80361088: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    after_2:
L_8036108C:
    // 0x8036108C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80361090: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
    // 0x80361094: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361098: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8036109C: beq         $v0, $zero, L_80361194
    if (ctx->r2 == 0) {
        // 0x803610A0: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_80361194;
    }
    // 0x803610A0: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x803610A4: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x803610A8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803610AC: lbu         $t4, 0x162($t3)
    ctx->r12 = MEM_BU(ctx->r11, 0X162);
    // 0x803610B0: bnel        $t4, $at, L_80361198
    if (ctx->r12 != ctx->r1) {
        // 0x803610B4: sb          $zero, 0x369($v1)
        MEM_B(0X369, ctx->r3) = 0;
            goto L_80361198;
    }
    goto skip_8;
    // 0x803610B4: sb          $zero, 0x369($v1)
    MEM_B(0X369, ctx->r3) = 0;
    skip_8:
    // 0x803610B8: lbu         $a0, 0x369($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X369);
    // 0x803610BC: lui         $t5, 0x801F
    ctx->r13 = S32(0X801F << 16);
    // 0x803610C0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803610C4: bne         $a0, $zero, L_803610EC
    if (ctx->r4 != 0) {
        // 0x803610C8: nop
    
            goto L_803610EC;
    }
    // 0x803610C8: nop

    // 0x803610CC: lhu         $t5, -0x6176($t5)
    ctx->r13 = MEM_HU(ctx->r13, -0X6176);
    // 0x803610D0: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x803610D4: bne         $t5, $zero, L_803611A0
    if (ctx->r13 != 0) {
        // 0x803610D8: nop
    
            goto L_803611A0;
    }
    // 0x803610D8: nop

    // 0x803610DC: sb          $t6, 0x369($v1)
    MEM_B(0X369, ctx->r3) = ctx->r14;
    // 0x803610E0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803610E4: b           L_803611A0
    // 0x803610E8: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
        goto L_803611A0;
    // 0x803610E8: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
L_803610EC:
    // 0x803610EC: bne         $a0, $at, L_803611A0
    if (ctx->r4 != ctx->r1) {
        // 0x803610F0: lui         $t7, 0x801F
        ctx->r15 = S32(0X801F << 16);
            goto L_803611A0;
    }
    // 0x803610F0: lui         $t7, 0x801F
    ctx->r15 = S32(0X801F << 16);
    // 0x803610F4: lhu         $t7, -0x6176($t7)
    ctx->r15 = MEM_HU(ctx->r15, -0X6176);
    // 0x803610F8: beq         $t7, $zero, L_803611A0
    if (ctx->r15 == 0) {
        // 0x803610FC: nop
    
            goto L_803611A0;
    }
    // 0x803610FC: nop

    // 0x80361100: lbu         $t8, 0x36D($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X36D);
    // 0x80361104: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x80361108: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    // 0x8036110C: slti        $at, $t8, 0xB
    ctx->r1 = SIGNED(ctx->r24) < 0XB ? 1 : 0;
    // 0x80361110: bne         $at, $zero, L_803611A0
    if (ctx->r1 != 0) {
        // 0x80361114: lui         $a1, 0x803D
        ctx->r5 = S32(0X803D << 16);
            goto L_803611A0;
    }
    // 0x80361114: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80361118: sb          $t9, 0x369($v1)
    MEM_B(0X369, ctx->r3) = ctx->r25;
    // 0x8036111C: jal         0x802DBA58
    // 0x80361120: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    func_802DBA58_6ED108(rdram, ctx);
        goto after_3;
    // 0x80361120: lw          $a1, 0x552C($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X552C);
    after_3:
    // 0x80361124: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361128: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x8036112C: addiu       $t2, $zero, 0xE
    ctx->r10 = ADD32(0, 0XE);
    // 0x80361130: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    // 0x80361134: lh          $v0, 0x24($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X24);
    // 0x80361138: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8036113C: addiu       $v0, $v0, 0x9
    ctx->r2 = ADD32(ctx->r2, 0X9);
    // 0x80361140: slti        $at, $v0, 0xE
    ctx->r1 = SIGNED(ctx->r2) < 0XE ? 1 : 0;
    // 0x80361144: beql        $at, $zero, L_80361158
    if (ctx->r1 == 0) {
        // 0x80361148: sh          $v0, 0x24($s0)
        MEM_H(0X24, ctx->r16) = ctx->r2;
            goto L_80361158;
    }
    goto skip_9;
    // 0x80361148: sh          $v0, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r2;
    skip_9:
    // 0x8036114C: b           L_80361158
    // 0x80361150: sh          $t2, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r10;
        goto L_80361158;
    // 0x80361150: sh          $t2, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r10;
    // 0x80361154: sh          $v0, 0x24($s0)
    MEM_H(0X24, ctx->r16) = ctx->r2;
L_80361158:
    // 0x80361158: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8036115C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361160: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80361164: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80361168: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x8036116C: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x80361170: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80361174: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80361178: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x8036117C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80361180: jal         0x8032C360
    // 0x80361184: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    play_sound_effect_at_location(rdram, ctx);
        goto after_4;
    // 0x80361184: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_4:
    // 0x80361188: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8036118C: b           L_803611A0
    // 0x80361190: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
        goto L_803611A0;
    // 0x80361190: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
L_80361194:
    // 0x80361194: sb          $zero, 0x369($v1)
    MEM_B(0X369, ctx->r3) = 0;
L_80361198:
    // 0x80361198: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8036119C: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
L_803611A0:
    // 0x803611A0: beq         $v0, $zero, L_803611F8
    if (ctx->r2 == 0) {
        // 0x803611A4: lui         $t5, 0x803D
        ctx->r13 = S32(0X803D << 16);
            goto L_803611F8;
    }
    // 0x803611A4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803611A8: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x803611AC: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x803611B0: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x803611B4: lh          $v0, 0xD6($t5)
    ctx->r2 = MEM_H(ctx->r13, 0XD6);
    // 0x803611B8: beq         $a0, $v0, L_803611D8
    if (ctx->r4 == ctx->r2) {
        // 0x803611BC: nop
    
            goto L_803611D8;
    }
    // 0x803611BC: nop

    // 0x803611C0: bne         $v0, $zero, L_803611E0
    if (ctx->r2 != 0) {
        // 0x803611C4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803611E0;
    }
    // 0x803611C4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803611C8: beq         $a0, $at, L_803611D8
    if (ctx->r4 == ctx->r1) {
        // 0x803611CC: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803611D8;
    }
    // 0x803611CC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803611D0: bnel        $a0, $at, L_803611E4
    if (ctx->r4 != ctx->r1) {
        // 0x803611D4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803611E4;
    }
    goto skip_10;
    // 0x803611D4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_10:
L_803611D8:
    // 0x803611D8: b           L_803611E4
    // 0x803611DC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803611E4;
    // 0x803611DC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803611E0:
    // 0x803611E0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803611E4:
    // 0x803611E4: beq         $v0, $zero, L_803611F8
    if (ctx->r2 == 0) {
        // 0x803611E8: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_803611F8;
    }
    // 0x803611E8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803611EC: sh          $zero, 0xAC($sp)
    MEM_H(0XAC, ctx->r29) = 0;
    // 0x803611F0: b           L_8036128C
    // 0x803611F4: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_8036128C;
    // 0x803611F4: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_803611F8:
    // 0x803611F8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803611FC: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x80361200: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80361204: lh          $a0, 0x2D70($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X2D70);
    // 0x80361208: lh          $v0, 0xD6($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XD6);
    // 0x8036120C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361210: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361214: beq         $a0, $v0, L_80361234
    if (ctx->r4 == ctx->r2) {
        // 0x80361218: addiu       $a3, $zero, 0x5F0
        ctx->r7 = ADD32(0, 0X5F0);
            goto L_80361234;
    }
    // 0x80361218: addiu       $a3, $zero, 0x5F0
    ctx->r7 = ADD32(0, 0X5F0);
    // 0x8036121C: bne         $v0, $zero, L_8036123C
    if (ctx->r2 != 0) {
        // 0x80361220: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8036123C;
    }
    // 0x80361220: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80361224: beq         $a0, $at, L_80361234
    if (ctx->r4 == ctx->r1) {
        // 0x80361228: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80361234;
    }
    // 0x80361228: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8036122C: bnel        $a0, $at, L_80361240
    if (ctx->r4 != ctx->r1) {
        // 0x80361230: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80361240;
    }
    goto skip_11;
    // 0x80361230: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_11:
L_80361234:
    // 0x80361234: b           L_80361240
    // 0x80361238: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80361240;
    // 0x80361238: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8036123C:
    // 0x8036123C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80361240:
    // 0x80361240: lw          $t6, 0xC($v1)
    ctx->r14 = MEM_W(ctx->r3, 0XC);
    // 0x80361244: lhu         $t7, 0xBA($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0XBA);
    // 0x80361248: lw          $a0, 0x4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X4);
    // 0x8036124C: lw          $a1, 0x8($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X8);
    // 0x80361250: addiu       $t9, $zero, 0x94
    ctx->r25 = ADD32(0, 0X94);
    // 0x80361254: addiu       $t2, $zero, 0x94
    ctx->r10 = ADD32(0, 0X94);
    // 0x80361258: addiu       $t3, $zero, 0x94
    ctx->r11 = ADD32(0, 0X94);
    // 0x8036125C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80361260: sltiu       $t5, $v0, 0x1
    ctx->r13 = ctx->r2 < 0X1 ? 1 : 0;
    // 0x80361264: sll         $t8, $t7, 15
    ctx->r24 = S32(ctx->r15 << 15);
    // 0x80361268: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x8036126C: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x80361270: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x80361274: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x80361278: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8036127C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80361280: jal         0x802E89F0
    // 0x80361284: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_5;
    // 0x80361284: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    after_5:
    // 0x80361288: sh          $v0, 0xAC($sp)
    MEM_H(0XAC, ctx->r29) = ctx->r2;
L_8036128C:
    // 0x8036128C: lh          $t7, 0xAC($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XAC);
    // 0x80361290: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361294: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80361298: bne         $t7, $zero, L_803621E4
    if (ctx->r15 != 0) {
        // 0x8036129C: nop
    
            goto L_803621E4;
    }
    // 0x8036129C: nop

    // 0x803612A0: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803612A4: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x803612A8: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x803612AC: lhu         $t8, 0x35E($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X35E);
    // 0x803612B0: lb          $t2, 0x2D10($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X2D10);
    // 0x803612B4: subu        $v0, $t6, $t8
    ctx->r2 = SUB32(ctx->r14, ctx->r24);
    // 0x803612B8: bne         $t2, $zero, L_8036144C
    if (ctx->r10 != 0) {
        // 0x803612BC: andi        $t9, $v0, 0xFFFF
        ctx->r25 = ctx->r2 & 0XFFFF;
            goto L_8036144C;
    }
    // 0x803612BC: andi        $t9, $v0, 0xFFFF
    ctx->r25 = ctx->r2 & 0XFFFF;
    // 0x803612C0: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x803612C4: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x803612C8: lb          $t4, 0x4A($t3)
    ctx->r12 = MEM_B(ctx->r11, 0X4A);
    // 0x803612CC: bnel        $t4, $zero, L_80361450
    if (ctx->r12 != 0) {
        // 0x803612D0: sh          $zero, 0x312($v1)
        MEM_H(0X312, ctx->r3) = 0;
            goto L_80361450;
    }
    goto skip_12;
    // 0x803612D0: sh          $zero, 0x312($v1)
    MEM_H(0X312, ctx->r3) = 0;
    skip_12:
    // 0x803612D4: beq         $t9, $zero, L_8036144C
    if (ctx->r25 == 0) {
        // 0x803612D8: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_8036144C;
    }
    // 0x803612D8: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x803612DC: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x803612E0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803612E4: beq         $v0, $at, L_803612F4
    if (ctx->r2 == ctx->r1) {
        // 0x803612E8: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_803612F4;
    }
    // 0x803612E8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803612EC: bnel        $v0, $at, L_80361450
    if (ctx->r2 != ctx->r1) {
        // 0x803612F0: sh          $zero, 0x312($v1)
        MEM_H(0X312, ctx->r3) = 0;
            goto L_80361450;
    }
    goto skip_13;
    // 0x803612F0: sh          $zero, 0x312($v1)
    MEM_H(0X312, ctx->r3) = 0;
    skip_13:
L_803612F4:
    // 0x803612F4: lh          $v0, 0x312($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X312);
    // 0x803612F8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803612FC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80361300: beq         $v0, $zero, L_80361334
    if (ctx->r2 == 0) {
        // 0x80361304: addiu       $t5, $v0, -0x1
        ctx->r13 = ADD32(ctx->r2, -0X1);
            goto L_80361334;
    }
    // 0x80361304: addiu       $t5, $v0, -0x1
    ctx->r13 = ADD32(ctx->r2, -0X1);
    // 0x80361308: sh          $t5, 0x312($v1)
    MEM_H(0X312, ctx->r3) = ctx->r13;
    // 0x8036130C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80361310: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361314: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361318: lh          $t8, 0x310($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X310);
    // 0x8036131C: lh          $t7, 0x2C($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2C);
    // 0x80361320: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x80361324: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x80361328: sh          $t2, 0x2C($s0)
    MEM_H(0X2C, ctx->r16) = ctx->r10;
    // 0x8036132C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361330: lh          $v0, 0x312($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X312);
L_80361334:
    // 0x80361334: bne         $v0, $zero, L_80361450
    if (ctx->r2 != 0) {
        // 0x80361338: addiu       $at, $zero, 0xFA
        ctx->r1 = ADD32(0, 0XFA);
            goto L_80361450;
    }
    // 0x80361338: addiu       $at, $zero, 0xFA
    ctx->r1 = ADD32(0, 0XFA);
    // 0x8036133C: andi        $v0, $a0, 0xFF
    ctx->r2 = ctx->r4 & 0XFF;
    // 0x80361340: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361344: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_80361394;
    }
    // 0x80361344: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80361348: addiu       $at, $zero, 0x8C
    ctx->r1 = ADD32(0, 0X8C);
    // 0x8036134C: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361350: addiu       $at, $zero, 0xA0
        ctx->r1 = ADD32(0, 0XA0);
            goto L_80361394;
    }
    // 0x80361350: addiu       $at, $zero, 0xA0
    ctx->r1 = ADD32(0, 0XA0);
    // 0x80361354: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361358: addiu       $at, $zero, 0xAA
        ctx->r1 = ADD32(0, 0XAA);
            goto L_80361394;
    }
    // 0x80361358: addiu       $at, $zero, 0xAA
    ctx->r1 = ADD32(0, 0XAA);
    // 0x8036135C: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361360: addiu       $at, $zero, 0xB4
        ctx->r1 = ADD32(0, 0XB4);
            goto L_80361394;
    }
    // 0x80361360: addiu       $at, $zero, 0xB4
    ctx->r1 = ADD32(0, 0XB4);
    // 0x80361364: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361368: addiu       $at, $zero, 0xC8
        ctx->r1 = ADD32(0, 0XC8);
            goto L_80361394;
    }
    // 0x80361368: addiu       $at, $zero, 0xC8
    ctx->r1 = ADD32(0, 0XC8);
    // 0x8036136C: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361370: addiu       $at, $zero, 0xDC
        ctx->r1 = ADD32(0, 0XDC);
            goto L_80361394;
    }
    // 0x80361370: addiu       $at, $zero, 0xDC
    ctx->r1 = ADD32(0, 0XDC);
    // 0x80361374: bne         $v0, $at, L_80361450
    if (ctx->r2 != ctx->r1) {
        // 0x80361378: nop
    
            goto L_80361450;
    }
    // 0x80361378: nop

    // 0x8036137C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x80361380: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80361384: beq         $v0, $at, L_80361394
    if (ctx->r2 == ctx->r1) {
        // 0x80361388: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80361394;
    }
    // 0x80361388: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8036138C: bne         $v0, $at, L_80361450
    if (ctx->r2 != ctx->r1) {
        // 0x80361390: nop
    
            goto L_80361450;
    }
    // 0x80361390: nop

L_80361394:
    // 0x80361394: lbu         $t3, 0x5538($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X5538);
    // 0x80361398: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x8036139C: beq         $t3, $zero, L_80361404
    if (ctx->r11 == 0) {
        // 0x803613A0: nop
    
            goto L_80361404;
    }
    // 0x803613A0: nop

    // 0x803613A4: lh          $t4, 0x2A98($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2A98);
    // 0x803613A8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803613AC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803613B0: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x803613B4: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x803613B8: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x803613BC: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x803613C0: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x803613C4: addu        $v0, $v0, $t5
    ctx->r2 = ADD32(ctx->r2, ctx->r13);
    // 0x803613C8: lh          $v0, 0x28E0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X28E0);
    // 0x803613CC: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613D0: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80361450;
    }
    // 0x803613D0: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803613D4: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613D8: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80361450;
    }
    // 0x803613D8: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803613DC: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613E0: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_80361450;
    }
    // 0x803613E0: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x803613E4: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613E8: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_80361450;
    }
    // 0x803613E8: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x803613EC: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613F0: addiu       $at, $zero, 0x1C
        ctx->r1 = ADD32(0, 0X1C);
            goto L_80361450;
    }
    // 0x803613F0: addiu       $at, $zero, 0x1C
    ctx->r1 = ADD32(0, 0X1C);
    // 0x803613F4: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x803613F8: addiu       $at, $zero, 0x1A
        ctx->r1 = ADD32(0, 0X1A);
            goto L_80361450;
    }
    // 0x803613F8: addiu       $at, $zero, 0x1A
    ctx->r1 = ADD32(0, 0X1A);
    // 0x803613FC: beq         $v0, $at, L_80361450
    if (ctx->r2 == ctx->r1) {
        // 0x80361400: nop
    
            goto L_80361450;
    }
    // 0x80361400: nop

L_80361404:
    // 0x80361404: jal         0x8012826C
    // 0x80361408: nop

    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x80361408: nop

    after_6:
    // 0x8036140C: andi        $t6, $v0, 0x1
    ctx->r14 = ctx->r2 & 0X1;
    // 0x80361410: beq         $t6, $zero, L_8036142C
    if (ctx->r14 == 0) {
        // 0x80361414: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_8036142C;
    }
    // 0x80361414: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80361418: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8036141C: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80361420: addiu       $t7, $zero, 0xC
    ctx->r15 = ADD32(0, 0XC);
    // 0x80361424: b           L_8036143C
    // 0x80361428: sh          $t7, 0x310($t8)
    MEM_H(0X310, ctx->r24) = ctx->r15;
        goto L_8036143C;
    // 0x80361428: sh          $t7, 0x310($t8)
    MEM_H(0X310, ctx->r24) = ctx->r15;
L_8036142C:
    // 0x8036142C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80361430: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x80361434: addiu       $t9, $zero, -0xC
    ctx->r25 = ADD32(0, -0XC);
    // 0x80361438: sh          $t9, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r25;
L_8036143C:
    // 0x8036143C: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80361440: addiu       $t3, $zero, 0x40
    ctx->r11 = ADD32(0, 0X40);
    // 0x80361444: b           L_80361450
    // 0x80361448: sh          $t3, 0x312($t4)
    MEM_H(0X312, ctx->r12) = ctx->r11;
        goto L_80361450;
    // 0x80361448: sh          $t3, 0x312($t4)
    MEM_H(0X312, ctx->r12) = ctx->r11;
L_8036144C:
    // 0x8036144C: sh          $zero, 0x312($v1)
    MEM_H(0X312, ctx->r3) = 0;
L_80361450:
    // 0x80361450: jal         0x8034B298
    // 0x80361454: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_7;
    // 0x80361454: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_7:
    // 0x80361458: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8036145C: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80361460: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80361464: lbu         $t6, 0x366($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X366);
    // 0x80361468: beq         $t6, $at, L_80361478
    if (ctx->r14 == ctx->r1) {
        // 0x8036146C: nop
    
            goto L_80361478;
    }
    // 0x8036146C: nop

    // 0x80361470: jal         0x803622DC
    // 0x80361474: nop

    func_803622DC_77398C(rdram, ctx);
        goto after_8;
    // 0x80361474: nop

    after_8:
L_80361478:
    // 0x80361478: jal         0x8035D120
    // 0x8036147C: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_9;
    // 0x8036147C: nop

    after_9:
    // 0x80361480: jal         0x8035D734
    // 0x80361484: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_10;
    // 0x80361484: nop

    after_10:
    // 0x80361488: jal         0x8034BB38
    // 0x8036148C: addiu       $a0, $zero, 0xFA
    ctx->r4 = ADD32(0, 0XFA);
    func_8034BB38_75D1E8(rdram, ctx);
        goto after_11;
    // 0x8036148C: addiu       $a0, $zero, 0xFA
    ctx->r4 = ADD32(0, 0XFA);
    after_11:
    // 0x80361490: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80361494: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80361498: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8036149C: lbu         $v0, 0x366($t7)
    ctx->r2 = MEM_BU(ctx->r15, 0X366);
    // 0x803614A0: beq         $v0, $at, L_803614B0
    if (ctx->r2 == ctx->r1) {
        // 0x803614A4: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803614B0;
    }
    // 0x803614A4: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803614A8: bne         $v0, $at, L_803614DC
    if (ctx->r2 != ctx->r1) {
        // 0x803614AC: nop
    
            goto L_803614DC;
    }
    // 0x803614AC: nop

L_803614B0:
    // 0x803614B0: jal         0x8012826C
    // 0x803614B4: nop

    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x803614B4: nop

    after_12:
    // 0x803614B8: andi        $t8, $v0, 0xFF
    ctx->r24 = ctx->r2 & 0XFF;
    // 0x803614BC: addiu       $at, $zero, 0x9C
    ctx->r1 = ADD32(0, 0X9C);
    // 0x803614C0: bne         $t8, $at, L_803614DC
    if (ctx->r24 != ctx->r1) {
        // 0x803614C4: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_803614DC;
    }
    // 0x803614C4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803614C8: lh          $t9, 0x6450($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X6450);
    // 0x803614CC: beq         $t9, $zero, L_803614DC
    if (ctx->r25 == 0) {
        // 0x803614D0: nop
    
            goto L_803614DC;
    }
    // 0x803614D0: nop

    // 0x803614D4: jal         0x8037FEDC
    // 0x803614D8: nop

    sheep_follow_leader(rdram, ctx);
        goto after_13;
    // 0x803614D8: nop

    after_13:
L_803614DC:
    // 0x803614DC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803614E0: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803614E4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803614E8: lbu         $v0, 0x365($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X365);
    // 0x803614EC: beq         $v0, $zero, L_80361594
    if (ctx->r2 == 0) {
        // 0x803614F0: nop
    
            goto L_80361594;
    }
    // 0x803614F0: nop

    // 0x803614F4: beq         $v0, $at, L_80361504
    if (ctx->r2 == ctx->r1) {
        // 0x803614F8: nop
    
            goto L_80361504;
    }
    // 0x803614F8: nop

    // 0x803614FC: b           L_80361594
    // 0x80361500: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
        goto L_80361594;
    // 0x80361500: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_80361504:
    // 0x80361504: jal         0x802DCCAC
    // 0x80361508: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    func_802DCCAC_6EE35C(rdram, ctx);
        goto after_14;
    // 0x80361508: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    after_14:
    // 0x8036150C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80361510: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x80361514: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80361518: lhu         $t2, 0x5544($t2)
    ctx->r10 = MEM_HU(ctx->r10, 0X5544);
    // 0x8036151C: lhu         $t4, 0x32A($t3)
    ctx->r12 = MEM_HU(ctx->r11, 0X32A);
    // 0x80361520: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80361524: addiu       $a0, $zero, 0x2E
    ctx->r4 = ADD32(0, 0X2E);
    // 0x80361528: subu        $t5, $t2, $t4
    ctx->r13 = SUB32(ctx->r10, ctx->r12);
    // 0x8036152C: bne         $t5, $at, L_80361594
    if (ctx->r13 != ctx->r1) {
        // 0x80361530: addiu       $a1, $zero, 0x2E
        ctx->r5 = ADD32(0, 0X2E);
            goto L_80361594;
    }
    // 0x80361530: addiu       $a1, $zero, 0x2E
    ctx->r5 = ADD32(0, 0X2E);
    // 0x80361534: addiu       $t6, $zero, 0xC
    ctx->r14 = ADD32(0, 0XC);
    // 0x80361538: addiu       $t7, $zero, 0x10
    ctx->r15 = ADD32(0, 0X10);
    // 0x8036153C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80361540: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80361544: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80361548: addiu       $a3, $zero, 0x14
    ctx->r7 = ADD32(0, 0X14);
    // 0x8036154C: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80361550: jal         0x803224C4
    // 0x80361554: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_15;
    // 0x80361554: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_15:
    // 0x80361558: beq         $v0, $zero, L_80361594
    if (ctx->r2 == 0) {
        // 0x8036155C: addiu       $a0, $zero, 0x48
        ctx->r4 = ADD32(0, 0X48);
            goto L_80361594;
    }
    // 0x8036155C: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    // 0x80361560: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361564: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361568: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8036156C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80361570: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x80361574: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x80361578: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8036157C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80361580: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x80361584: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80361588: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x8036158C: jal         0x8032C360
    // 0x80361590: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_16;
    // 0x80361590: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_16:
L_80361594:
    // 0x80361594: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x80361598: lhu         $t3, 0x2ECE($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X2ECE);
    // 0x8036159C: addiu       $s0, $sp, 0xB4
    ctx->r16 = ADD32(ctx->r29, 0XB4);
    // 0x803615A0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803615A4: beq         $t3, $zero, L_803615B8
    if (ctx->r11 == 0) {
        // 0x803615A8: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_803615B8;
    }
    // 0x803615A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803615AC: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
    // 0x803615B0: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x803615B4: beq         $at, $zero, L_803615E0
    if (ctx->r1 == 0) {
        // 0x803615B8: addiu       $a1, $zero, 0x251
        ctx->r5 = ADD32(0, 0X251);
            goto L_803615E0;
    }
L_803615B8:
    // 0x803615B8: addiu       $a1, $zero, 0x251
    ctx->r5 = ADD32(0, 0X251);
    // 0x803615BC: addiu       $a2, $zero, 0x3F1
    ctx->r6 = ADD32(0, 0X3F1);
    // 0x803615C0: jal         0x802B96D0
    // 0x803615C4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B96D0_6CAD80(rdram, ctx);
        goto after_17;
    // 0x803615C4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_17:
    // 0x803615C8: addiu       $a0, $zero, 0x3F1
    ctx->r4 = ADD32(0, 0X3F1);
    // 0x803615CC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803615D0: jal         0x802C1A44
    // 0x803615D4: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    func_802C1A44_6D30F4(rdram, ctx);
        goto after_18;
    // 0x803615D4: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_18:
    // 0x803615D8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803615DC: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_803615E0:
    // 0x803615E0: beq         $v0, $zero, L_80361660
    if (ctx->r2 == 0) {
        // 0x803615E4: nop
    
            goto L_80361660;
    }
    // 0x803615E4: nop

    // 0x803615E8: jal         0x802DB8DC
    // 0x803615EC: nop

    backup_joint_positions(rdram, ctx);
        goto after_19;
    // 0x803615EC: nop

    after_19:
    // 0x803615F0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803615F4: lhu         $v0, 0x2ECE($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECE);
    // 0x803615F8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803615FC: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80361600: beq         $v0, $at, L_8036161C
    if (ctx->r2 == ctx->r1) {
        // 0x80361604: addiu       $a0, $a0, 0x41A0
        ctx->r4 = ADD32(ctx->r4, 0X41A0);
            goto L_8036161C;
    }
    // 0x80361604: addiu       $a0, $a0, 0x41A0
    ctx->r4 = ADD32(ctx->r4, 0X41A0);
    // 0x80361608: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8036160C: beq         $v0, $at, L_80361640
    if (ctx->r2 == ctx->r1) {
        // 0x80361610: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_80361640;
    }
    // 0x80361610: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80361614: b           L_80361660
    // 0x80361618: nop

        goto L_80361660;
    // 0x80361618: nop

L_8036161C:
    // 0x8036161C: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80361620: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80361624: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80361628: addiu       $a3, $a3, 0x41B0
    ctx->r7 = ADD32(ctx->r7, 0X41B0);
    // 0x8036162C: addiu       $a2, $a2, 0x41A8
    ctx->r6 = ADD32(ctx->r6, 0X41A8);
    // 0x80361630: jal         0x802DB670
    // 0x80361634: addiu       $a1, $a1, 0x41A4
    ctx->r5 = ADD32(ctx->r5, 0X41A4);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_20;
    // 0x80361634: addiu       $a1, $a1, 0x41A4
    ctx->r5 = ADD32(ctx->r5, 0X41A4);
    after_20:
    // 0x80361638: b           L_80361660
    // 0x8036163C: nop

        goto L_80361660;
    // 0x8036163C: nop

L_80361640:
    // 0x80361640: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80361644: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80361648: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x8036164C: addiu       $a3, $a3, 0x41C4
    ctx->r7 = ADD32(ctx->r7, 0X41C4);
    // 0x80361650: addiu       $a2, $a2, 0x41A8
    ctx->r6 = ADD32(ctx->r6, 0X41A8);
    // 0x80361654: addiu       $a1, $a1, 0x41A4
    ctx->r5 = ADD32(ctx->r5, 0X41A4);
    // 0x80361658: jal         0x802DB670
    // 0x8036165C: addiu       $a0, $a0, 0x41A0
    ctx->r4 = ADD32(ctx->r4, 0X41A0);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_21;
    // 0x8036165C: addiu       $a0, $a0, 0x41A0
    ctx->r4 = ADD32(ctx->r4, 0X41A0);
    after_21:
L_80361660:
    // 0x80361660: jal         0x8038064C
    // 0x80361664: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_22;
    // 0x80361664: nop

    after_22:
    // 0x80361668: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8036166C: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80361670: lui         $t1, 0x4
    ctx->r9 = S32(0X4 << 16);
    // 0x80361674: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80361678: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x8036167C: lw          $t1, -0x76E8($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X76E8);
    // 0x80361680: addiu       $t2, $t1, 0x1E
    ctx->r10 = ADD32(ctx->r9, 0X1E);
    // 0x80361684: slti        $at, $t2, 0xFA
    ctx->r1 = SIGNED(ctx->r10) < 0XFA ? 1 : 0;
    // 0x80361688: beq         $at, $zero, L_803621D4
    if (ctx->r1 == 0) {
        // 0x8036168C: nop
    
            goto L_803621D4;
    }
    // 0x8036168C: nop

    // 0x80361690: lbu         $t4, 0x2EDA($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X2EDA);
    // 0x80361694: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80361698: beq         $t4, $zero, L_803621D4
    if (ctx->r12 == 0) {
        // 0x8036169C: nop
    
            goto L_803621D4;
    }
    // 0x8036169C: nop

    // 0x803616A0: lbu         $v0, 0x5538($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X5538);
    // 0x803616A4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803616A8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803616AC: bne         $v0, $zero, L_803616E4
    if (ctx->r2 != 0) {
        // 0x803616B0: nop
    
            goto L_803616E4;
    }
    // 0x803616B0: nop

    // 0x803616B4: lbu         $v1, 0x2AA2($v1)
    ctx->r3 = MEM_BU(ctx->r3, 0X2AA2);
    // 0x803616B8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803616BC: beq         $v1, $zero, L_803616E4
    if (ctx->r3 == 0) {
        // 0x803616C0: nop
    
            goto L_803616E4;
    }
    // 0x803616C0: nop

    // 0x803616C4: beq         $v1, $at, L_803616E4
    if (ctx->r3 == ctx->r1) {
        // 0x803616C8: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803616E4;
    }
    // 0x803616C8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803616CC: bne         $v1, $at, L_803621D4
    if (ctx->r3 != ctx->r1) {
        // 0x803616D0: lui         $t5, 0x803F
        ctx->r13 = S32(0X803F << 16);
            goto L_803621D4;
    }
    // 0x803616D0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803616D4: lbu         $t5, 0x2AA3($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X2AA3);
    // 0x803616D8: slti        $at, $t5, 0xB
    ctx->r1 = SIGNED(ctx->r13) < 0XB ? 1 : 0;
    // 0x803616DC: bne         $at, $zero, L_803621D4
    if (ctx->r1 != 0) {
        // 0x803616E0: nop
    
            goto L_803621D4;
    }
    // 0x803616E0: nop

L_803616E4:
    // 0x803616E4: lh          $t6, 0x2C18($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C18);
    // 0x803616E8: bne         $t6, $zero, L_80361740
    if (ctx->r14 != 0) {
        // 0x803616EC: nop
    
            goto L_80361740;
    }
    // 0x803616EC: nop

    // 0x803616F0: beq         $v0, $zero, L_80361740
    if (ctx->r2 == 0) {
        // 0x803616F4: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_80361740;
    }
    // 0x803616F4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803616F8: lh          $t7, 0x2A98($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2A98);
    // 0x803616FC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80361700: addiu       $t9, $t9, 0x28E0
    ctx->r25 = ADD32(ctx->r25, 0X28E0);
    // 0x80361704: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x80361708: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x8036170C: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x80361710: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x80361714: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80361718: addu        $v1, $t8, $t9
    ctx->r3 = ADD32(ctx->r24, ctx->r25);
    // 0x8036171C: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x80361720: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80361724: beq         $v0, $at, L_80361734
    if (ctx->r2 == ctx->r1) {
        // 0x80361728: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80361734;
    }
    // 0x80361728: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x8036172C: bne         $v0, $at, L_80361740
    if (ctx->r2 != ctx->r1) {
        // 0x80361730: nop
    
            goto L_80361740;
    }
    // 0x80361730: nop

L_80361734:
    // 0x80361734: lb          $t3, 0x64($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X64);
    // 0x80361738: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x8036173C: beq         $t3, $at, L_803621D4
    if (ctx->r11 == ctx->r1) {
        // 0x80361740: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_803621D4;
    }
L_80361740:
    // 0x80361740: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361744: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361748: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8036174C: lbu         $t2, 0x369($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X369);
    // 0x80361750: bnel        $t2, $at, L_80361ADC
    if (ctx->r10 != ctx->r1) {
        // 0x80361754: sh          $zero, 0xAA($sp)
        MEM_H(0XAA, ctx->r29) = 0;
            goto L_80361ADC;
    }
    goto skip_14;
    // 0x80361754: sh          $zero, 0xAA($sp)
    MEM_H(0XAA, ctx->r29) = 0;
    skip_14:
    // 0x80361758: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8036175C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x80361760: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80361764: lui         $at, 0xFFFC
    ctx->r1 = S32(0XFFFC << 16);
    // 0x80361768: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x8036176C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    // 0x80361770: lui         $v1, 0xFFF8
    ctx->r3 = S32(0XFFF8 << 16);
    // 0x80361774: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x80361778: bne         $at, $zero, L_80361790
    if (ctx->r1 != 0) {
        // 0x8036177C: lui         $at, 0xFFFE
        ctx->r1 = S32(0XFFFE << 16);
            goto L_80361790;
    }
    // 0x8036177C: lui         $at, 0xFFFE
    ctx->r1 = S32(0XFFFE << 16);
    // 0x80361780: addu        $t4, $v0, $at
    ctx->r12 = ADD32(ctx->r2, ctx->r1);
    // 0x80361784: sw          $t4, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r12;
    // 0x80361788: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x8036178C: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
L_80361790:
    // 0x80361790: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80361794: beq         $at, $zero, L_803617B8
    if (ctx->r1 == 0) {
        // 0x80361798: sll         $t5, $v0, 2
        ctx->r13 = S32(ctx->r2 << 2);
            goto L_803617B8;
    }
    // 0x80361798: sll         $t5, $v0, 2
    ctx->r13 = S32(ctx->r2 << 2);
    // 0x8036179C: subu        $t5, $t5, $v0
    ctx->r13 = SUB32(ctx->r13, ctx->r2);
    // 0x803617A0: lui         $at, 0x18
    ctx->r1 = S32(0X18 << 16);
    // 0x803617A4: addu        $t6, $t5, $at
    ctx->r14 = ADD32(ctx->r13, ctx->r1);
    // 0x803617A8: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x803617AC: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x803617B0: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x803617B4: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
L_803617B8:
    // 0x803617B8: lw          $t9, 0x1C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X1C);
    // 0x803617BC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803617C0: sra         $t3, $t9, 1
    ctx->r11 = S32(SIGNED(ctx->r25) >> 1);
    // 0x803617C4: sw          $t3, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r11;
    // 0x803617C8: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x803617CC: lw          $t2, 0x20($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X20);
    // 0x803617D0: sra         $t4, $t2, 1
    ctx->r12 = S32(SIGNED(ctx->r10) >> 1);
    // 0x803617D4: sw          $t4, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r12;
    // 0x803617D8: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x803617DC: lb          $t5, 0x4A($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X4A);
    // 0x803617E0: bne         $t5, $zero, L_80361860
    if (ctx->r13 != 0) {
        // 0x803617E4: nop
    
            goto L_80361860;
    }
    // 0x803617E4: nop

    // 0x803617E8: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x803617EC: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x803617F0: lui         $at, 0x3F60
    ctx->r1 = S32(0X3F60 << 16);
    // 0x803617F4: sll         $t9, $t6, 5
    ctx->r25 = S32(ctx->r14 << 5);
    // 0x803617F8: andi        $t3, $t9, 0xFF
    ctx->r11 = ctx->r25 & 0XFF;
    // 0x803617FC: sll         $t2, $t3, 1
    ctx->r10 = S32(ctx->r11 << 1);
    // 0x80361800: addu        $t4, $t4, $t2
    ctx->r12 = ADD32(ctx->r12, ctx->r10);
    // 0x80361804: lh          $t4, 0x2C78($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C78);
    // 0x80361808: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x8036180C: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80361810: sra         $t5, $t4, 7
    ctx->r13 = S32(SIGNED(ctx->r12) >> 7);
    // 0x80361814: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x80361818: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8036181C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80361820: cvt.d.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.d = CVT_D_W(ctx->f10.u32l);
    // 0x80361824: ldc1        $f10, -0x13B0($at)
    CHECK_FR(ctx, 10);
    ctx->f10.u64 = LD(ctx->r1, -0X13B0);
    // 0x80361828: addiu       $a1, $zero, 0x1F
    ctx->r5 = ADD32(0, 0X1F);
    // 0x8036182C: addiu       $a2, $zero, 0x5000
    ctx->r6 = ADD32(0, 0X5000);
    // 0x80361830: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80361834: mul.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f4.d, ctx->f6.d);
    // 0x80361838: add.d       $f4, $f8, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f4.d = ctx->f8.d + ctx->f10.d;
    // 0x8036183C: cvt.s.d     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f6.fl = CVT_S_D(ctx->f4.d);
    // 0x80361840: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x80361844: lh          $t6, 0x4($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X4);
    // 0x80361848: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8036184C: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x80361850: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80361854: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x80361858: jal         0x8032CD70
    // 0x8036185C: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    func_8032CD70_73E420(rdram, ctx);
        goto after_23;
    // 0x8036185C: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    after_23:
L_80361860:
    // 0x80361860: jal         0x8012826C
    // 0x80361864: nop

    advance_random_seed(rdram, ctx);
        goto after_24;
    // 0x80361864: nop

    after_24:
    // 0x80361868: jal         0x8012826C
    // 0x8036186C: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_25;
    // 0x8036186C: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    after_25:
    // 0x80361870: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361874: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361878: lhu         $t9, 0x70($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X70);
    // 0x8036187C: andi        $t4, $v0, 0xF
    ctx->r12 = ctx->r2 & 0XF;
    // 0x80361880: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x80361884: lh          $t2, 0x4($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X4);
    // 0x80361888: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x8036188C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x80361890: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x80361894: andi        $t3, $t9, 0xF
    ctx->r11 = ctx->r25 & 0XF;
    // 0x80361898: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8036189C: lw          $t9, 0x20($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X20);
    // 0x803618A0: addu        $a0, $t3, $t2
    ctx->r4 = ADD32(ctx->r11, ctx->r10);
    // 0x803618A4: addu        $a1, $t4, $t5
    ctx->r5 = ADD32(ctx->r12, ctx->r13);
    // 0x803618A8: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x803618AC: lw          $t3, 0x24($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X24);
    // 0x803618B0: addiu       $t5, $zero, 0x6319
    ctx->r13 = ADD32(0, 0X6319);
    // 0x803618B4: ori         $t4, $zero, 0x9CE7
    ctx->r12 = 0 | 0X9CE7;
    // 0x803618B8: addiu       $t2, $zero, 0x1E
    ctx->r10 = ADD32(0, 0X1E);
    // 0x803618BC: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x803618C0: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x803618C4: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x803618C8: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x803618CC: addiu       $a1, $a1, -0x8
    ctx->r5 = ADD32(ctx->r5, -0X8);
    // 0x803618D0: addiu       $a0, $a0, -0x8
    ctx->r4 = ADD32(ctx->r4, -0X8);
    // 0x803618D4: addiu       $a3, $zero, 0x15
    ctx->r7 = ADD32(0, 0X15);
    // 0x803618D8: addu        $a2, $t6, $t7
    ctx->r6 = ADD32(ctx->r14, ctx->r15);
    // 0x803618DC: jal         0x802D5F4C
    // 0x803618E0: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    create_particle_effect(rdram, ctx);
        goto after_26;
    // 0x803618E0: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    after_26:
    // 0x803618E4: jal         0x8012826C
    // 0x803618E8: nop

    advance_random_seed(rdram, ctx);
        goto after_27;
    // 0x803618E8: nop

    after_27:
    // 0x803618EC: andi        $t6, $v0, 0xF
    ctx->r14 = ctx->r2 & 0XF;
    // 0x803618F0: bne         $t6, $zero, L_80361974
    if (ctx->r14 != 0) {
        // 0x803618F4: nop
    
            goto L_80361974;
    }
    // 0x803618F4: nop

    // 0x803618F8: jal         0x8012826C
    // 0x803618FC: nop

    advance_random_seed(rdram, ctx);
        goto after_28;
    // 0x803618FC: nop

    after_28:
    // 0x80361900: jal         0x8012826C
    // 0x80361904: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_29;
    // 0x80361904: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    after_29:
    // 0x80361908: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8036190C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361910: lhu         $t7, 0x70($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X70);
    // 0x80361914: andi        $t3, $v0, 0x3
    ctx->r11 = ctx->r2 & 0X3;
    // 0x80361918: lw          $t4, 0x1C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X1C);
    // 0x8036191C: lh          $t9, 0x4($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X4);
    // 0x80361920: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x80361924: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x80361928: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8036192C: lw          $t5, 0x20($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X20);
    // 0x80361930: andi        $t8, $t7, 0x3
    ctx->r24 = ctx->r15 & 0X3;
    // 0x80361934: addu        $a0, $t8, $t9
    ctx->r4 = ADD32(ctx->r24, ctx->r25);
    // 0x80361938: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x8036193C: lw          $t6, 0x24($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X24);
    // 0x80361940: ori         $t9, $zero, 0xFFE1
    ctx->r25 = 0 | 0XFFE1;
    // 0x80361944: ori         $t8, $zero, 0xFFC1
    ctx->r24 = 0 | 0XFFC1;
    // 0x80361948: addiu       $t7, $zero, 0x1E
    ctx->r15 = ADD32(0, 0X1E);
    // 0x8036194C: addu        $a1, $t3, $t2
    ctx->r5 = ADD32(ctx->r11, ctx->r10);
    // 0x80361950: addiu       $a1, $a1, -0x2
    ctx->r5 = ADD32(ctx->r5, -0X2);
    // 0x80361954: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80361958: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8036195C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80361960: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80361964: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x80361968: addiu       $a3, $zero, 0x24
    ctx->r7 = ADD32(0, 0X24);
    // 0x8036196C: jal         0x802D5F4C
    // 0x80361970: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    create_particle_effect(rdram, ctx);
        goto after_30;
    // 0x80361970: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    after_30:
L_80361974:
    // 0x80361974: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80361978: lh          $t3, 0x5540($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X5540);
    // 0x8036197C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361980: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361984: sll         $t2, $t3, 5
    ctx->r10 = S32(ctx->r11 << 5);
    // 0x80361988: sh          $t2, 0xAA($sp)
    MEM_H(0XAA, ctx->r29) = ctx->r10;
    // 0x8036198C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x80361990: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x80361994: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x80361998: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x8036199C: addiu       $t5, $zero, 0x14
    ctx->r13 = ADD32(0, 0X14);
    // 0x803619A0: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x803619A4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x803619A8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803619AC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803619B0: jal         0x80322A58
    // 0x803619B4: addiu       $a3, $zero, 0x12
    ctx->r7 = ADD32(0, 0X12);
    func_80322A58_734108(rdram, ctx);
        goto after_31;
    // 0x803619B4: addiu       $a3, $zero, 0x12
    ctx->r7 = ADD32(0, 0X12);
    after_31:
    // 0x803619B8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803619BC: bne         $v0, $at, L_80361AB8
    if (ctx->r2 != ctx->r1) {
        // 0x803619C0: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_80361AB8;
    }
    // 0x803619C0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803619C4: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x803619C8: sb          $zero, 0x369($t6)
    MEM_B(0X369, ctx->r14) = 0;
    // 0x803619CC: sh          $zero, 0xA6($sp)
    MEM_H(0XA6, ctx->r29) = 0;
L_803619D0:
    // 0x803619D0: jal         0x8012826C
    // 0x803619D4: nop

    advance_random_seed(rdram, ctx);
        goto after_32;
    // 0x803619D4: nop

    after_32:
    // 0x803619D8: jal         0x8012826C
    // 0x803619DC: sh          $v0, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_33;
    // 0x803619DC: sh          $v0, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r2;
    after_33:
    // 0x803619E0: jal         0x8012826C
    // 0x803619E4: sh          $v0, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_34;
    // 0x803619E4: sh          $v0, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r2;
    after_34:
    // 0x803619E8: jal         0x8012826C
    // 0x803619EC: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_35;
    // 0x803619EC: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
    after_35:
    // 0x803619F0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803619F4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x803619F8: lhu         $t7, 0x6C($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X6C);
    // 0x803619FC: lhu         $t2, 0x6E($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X6E);
    // 0x80361A00: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x80361A04: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x80361A08: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x80361A0C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x80361A10: lhu         $t7, 0x70($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X70);
    // 0x80361A14: addiu       $t9, $t8, -0x7
    ctx->r25 = ADD32(ctx->r24, -0X7);
    // 0x80361A18: andi        $t4, $t2, 0xF
    ctx->r12 = ctx->r10 & 0XF;
    // 0x80361A1C: addiu       $t5, $t4, -0x7
    ctx->r13 = ADD32(ctx->r12, -0X7);
    // 0x80361A20: sll         $t3, $t9, 16
    ctx->r11 = S32(ctx->r25 << 16);
    // 0x80361A24: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80361A28: andi        $t3, $v0, 0x3
    ctx->r11 = ctx->r2 & 0X3;
    // 0x80361A2C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80361A30: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x80361A34: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80361A38: ori         $t5, $zero, 0xCE59
    ctx->r13 = 0 | 0XCE59;
    // 0x80361A3C: addiu       $t2, $t3, 0x4
    ctx->r10 = ADD32(ctx->r11, 0X4);
    // 0x80361A40: ori         $t4, $zero, 0xFFC1
    ctx->r12 = 0 | 0XFFC1;
    // 0x80361A44: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x80361A48: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x80361A4C: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80361A50: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80361A54: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80361A58: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80361A5C: jal         0x802D5F4C
    // 0x80361A60: addiu       $a3, $zero, 0x18
    ctx->r7 = ADD32(0, 0X18);
    create_particle_effect(rdram, ctx);
        goto after_36;
    // 0x80361A60: addiu       $a3, $zero, 0x18
    ctx->r7 = ADD32(0, 0X18);
    after_36:
    // 0x80361A64: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361A68: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361A6C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80361A70: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80361A74: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x80361A78: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x80361A7C: addiu       $a0, $zero, 0x48
    ctx->r4 = ADD32(0, 0X48);
    // 0x80361A80: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80361A84: lh          $t7, 0xC($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XC);
    // 0x80361A88: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80361A8C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80361A90: swc1        $f8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f8.u32l;
    // 0x80361A94: jal         0x8032C360
    // 0x80361A98: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    play_sound_effect_at_location(rdram, ctx);
        goto after_37;
    // 0x80361A98: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_37:
    // 0x80361A9C: lh          $v0, 0xA6($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XA6);
    // 0x80361AA0: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80361AA4: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x80361AA8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80361AAC: slti        $at, $t9, 0x4
    ctx->r1 = SIGNED(ctx->r25) < 0X4 ? 1 : 0;
    // 0x80361AB0: bne         $at, $zero, L_803619D0
    if (ctx->r1 != 0) {
        // 0x80361AB4: sh          $t9, 0xA6($sp)
        MEM_H(0XA6, ctx->r29) = ctx->r25;
            goto L_803619D0;
    }
    // 0x80361AB4: sh          $t9, 0xA6($sp)
    MEM_H(0XA6, ctx->r29) = ctx->r25;
L_80361AB8:
    // 0x80361AB8: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80361ABC: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80361AC0: lui         $t1, 0x4
    ctx->r9 = S32(0X4 << 16);
    // 0x80361AC4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361AC8: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x80361ACC: lw          $t1, -0x76E8($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X76E8);
    // 0x80361AD0: b           L_80361ADC
    // 0x80361AD4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
        goto L_80361ADC;
    // 0x80361AD4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361AD8: sh          $zero, 0xAA($sp)
    MEM_H(0XAA, ctx->r29) = 0;
L_80361ADC:
    // 0x80361ADC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361AE0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80361AE4: lw          $t6, 0x2EB0($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB0);
    // 0x80361AE8: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361AEC: sll         $t3, $t1, 6
    ctx->r11 = S32(ctx->r9 << 6);
    // 0x80361AF0: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80361AF4: lh          $t2, 0xAA($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XAA);
    // 0x80361AF8: lh          $t4, 0x302($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X302);
    // 0x80361AFC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80361B00: addu        $a0, $t0, $t3
    ctx->r4 = ADD32(ctx->r8, ctx->r11);
    // 0x80361B04: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80361B08: lw          $t8, 0x2EB4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB4);
    // 0x80361B0C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80361B10: subu        $t5, $t2, $t4
    ctx->r13 = SUB32(ctx->r10, ctx->r12);
    // 0x80361B14: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x80361B18: lw          $a1, 0x4($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X4);
    // 0x80361B1C: lw          $a2, 0x8($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X8);
    // 0x80361B20: lw          $a3, 0xC($s0)
    ctx->r7 = MEM_W(ctx->r16, 0XC);
    // 0x80361B24: lw          $t3, 0x2EB8($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X2EB8);
    // 0x80361B28: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80361B2C: bgez        $t6, L_80361B3C
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80361B30: sra         $t7, $t6, 2
        ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
            goto L_80361B3C;
    }
    // 0x80361B30: sra         $t7, $t6, 2
    ctx->r15 = S32(SIGNED(ctx->r14) >> 2);
    // 0x80361B34: addiu       $at, $t6, 0x3
    ctx->r1 = ADD32(ctx->r14, 0X3);
    // 0x80361B38: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_80361B3C:
    // 0x80361B3C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80361B40: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80361B44: lh          $t4, 0x2ED2($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2ED2);
    // 0x80361B48: lw          $t5, 0x2ED4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2ED4);
    // 0x80361B4C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80361B50: bgez        $t8, L_80361B60
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80361B54: sra         $t9, $t8, 2
        ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
            goto L_80361B60;
    }
    // 0x80361B54: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80361B58: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x80361B5C: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_80361B60:
    // 0x80361B60: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80361B64: bgez        $t3, L_80361B74
    if (SIGNED(ctx->r11) >= 0) {
        // 0x80361B68: sra         $t2, $t3, 2
        ctx->r10 = S32(SIGNED(ctx->r11) >> 2);
            goto L_80361B74;
    }
    // 0x80361B68: sra         $t2, $t3, 2
    ctx->r10 = S32(SIGNED(ctx->r11) >> 2);
    // 0x80361B6C: addiu       $at, $t3, 0x3
    ctx->r1 = ADD32(ctx->r11, 0X3);
    // 0x80361B70: sra         $t2, $at, 2
    ctx->r10 = S32(SIGNED(ctx->r1) >> 2);
L_80361B74:
    // 0x80361B74: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x80361B78: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x80361B7C: jal         0x80127640
    // 0x80361B80: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    func_80127640(rdram, ctx);
        goto after_38;
    // 0x80361B80: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    after_38:
    // 0x80361B84: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x80361B88: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x80361B8C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x80361B90: lui         $t7, 0x104
    ctx->r15 = S32(0X104 << 16);
    // 0x80361B94: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x80361B98: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80361B9C: sw          $t6, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r14;
    // 0x80361BA0: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80361BA4: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80361BA8: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80361BAC: lui         $t8, 0x4
    ctx->r24 = S32(0X4 << 16);
    // 0x80361BB0: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80361BB4: addu        $t8, $t8, $t0
    ctx->r24 = ADD32(ctx->r24, ctx->r8);
    // 0x80361BB8: lw          $t8, -0x76E8($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X76E8);
    // 0x80361BBC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80361BC0: lui         $t4, 0x4
    ctx->r12 = S32(0X4 << 16);
    // 0x80361BC4: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x80361BC8: addu        $t3, $t0, $t9
    ctx->r11 = ADD32(ctx->r8, ctx->r25);
    // 0x80361BCC: addu        $t2, $t3, $at
    ctx->r10 = ADD32(ctx->r11, ctx->r1);
    // 0x80361BD0: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80361BD4: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x80361BD8: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80361BDC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80361BE0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80361BE4: addu        $t4, $t4, $t0
    ctx->r12 = ADD32(ctx->r12, ctx->r8);
    // 0x80361BE8: lw          $t4, -0x76E8($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X76E8);
    // 0x80361BEC: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x80361BF0: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80361BF4: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x80361BF8: sw          $t5, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r13;
    // 0x80361BFC: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80361C00: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80361C04: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80361C08: lhu         $a0, 0xBA($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XBA);
    // 0x80361C0C: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x80361C10: sll         $t7, $a0, 3
    ctx->r15 = S32(ctx->r4 << 3);
    // 0x80361C14: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x80361C18: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80361C1C: lwc1        $f10, -0x13A8($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0X13A8);
    // 0x80361C20: mflo        $t8
    ctx->r24 = lo;
    // 0x80361C24: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80361C28: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80361C2C: jal         0x8038C230
    // 0x80361C30: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_39;
    // 0x80361C30: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    after_39:
    // 0x80361C34: lui         $a3, 0xBEC2
    ctx->r7 = S32(0XBEC2 << 16);
    // 0x80361C38: addiu       $t2, $zero, 0xBB8
    ctx->r10 = ADD32(0, 0XBB8);
    // 0x80361C3C: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80361C40: ori         $a3, $a3, 0x8F5C
    ctx->r7 = ctx->r7 | 0X8F5C;
    // 0x80361C44: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80361C48: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80361C4C: jal         0x8038C484
    // 0x80361C50: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    func_8038C484_79DB34(rdram, ctx);
        goto after_40;
    // 0x80361C50: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    after_40:
    // 0x80361C54: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80361C58: lb          $t4, 0x2D10($t4)
    ctx->r12 = MEM_B(ctx->r12, 0X2D10);
    // 0x80361C5C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361C60: bne         $t4, $zero, L_80361CE8
    if (ctx->r12 != 0) {
        // 0x80361C64: nop
    
            goto L_80361CE8;
    }
    // 0x80361C64: nop

    // 0x80361C68: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361C6C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80361C70: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x80361C74: beq         $v0, $at, L_80361CE8
    if (ctx->r2 == ctx->r1) {
        // 0x80361C78: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80361CE8;
    }
    // 0x80361C78: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80361C7C: beq         $v0, $at, L_80361CE8
    if (ctx->r2 == ctx->r1) {
        // 0x80361C80: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_80361CE8;
    }
    // 0x80361C80: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361C84: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x80361C88: lh          $t5, 0x308($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X308);
    // 0x80361C8C: lh          $t6, 0x30A($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X30A);
    // 0x80361C90: lh          $t8, 0x24($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X24);
    // 0x80361C94: addiu       $t2, $zero, 0x3
    ctx->r10 = ADD32(0, 0X3);
    // 0x80361C98: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x80361C9C: sll         $t9, $t8, 4
    ctx->r25 = S32(ctx->r24 << 4);
    // 0x80361CA0: subu        $t3, $t7, $t9
    ctx->r11 = SUB32(ctx->r15, ctx->r25);
    // 0x80361CA4: addiu       $t4, $zero, 0x3
    ctx->r12 = ADD32(0, 0X3);
    // 0x80361CA8: sh          $t3, 0xB2($sp)
    MEM_H(0XB2, ctx->r29) = ctx->r11;
    // 0x80361CAC: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x80361CB0: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80361CB4: lh          $t5, 0x24($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X24);
    // 0x80361CB8: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x80361CBC: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80361CC0: sll         $t6, $t5, 4
    ctx->r14 = S32(ctx->r13 << 4);
    // 0x80361CC4: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80361CC8: addiu       $a0, $sp, 0xB2
    ctx->r4 = ADD32(ctx->r29, 0XB2);
    // 0x80361CCC: addiu       $a1, $v1, 0x30A
    ctx->r5 = ADD32(ctx->r3, 0X30A);
    // 0x80361CD0: addiu       $a2, $zero, 0x60
    ctx->r6 = ADD32(0, 0X60);
    // 0x80361CD4: jal         0x80300130
    // 0x80361CD8: addiu       $a3, $zero, -0x100
    ctx->r7 = ADD32(0, -0X100);
    func_80300130_7117E0(rdram, ctx);
        goto after_41;
    // 0x80361CD8: addiu       $a3, $zero, -0x100
    ctx->r7 = ADD32(0, -0X100);
    after_41:
    // 0x80361CDC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361CE0: b           L_80361CF8
    // 0x80361CE4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
        goto L_80361CF8;
    // 0x80361CE4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
L_80361CE8:
    // 0x80361CE8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361CEC: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361CF0: lh          $t7, 0x308($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X308);
    // 0x80361CF4: sh          $t7, 0xB2($sp)
    MEM_H(0XB2, ctx->r29) = ctx->r15;
L_80361CF8:
    // 0x80361CF8: lh          $t9, 0xB2($sp)
    ctx->r25 = MEM_H(ctx->r29, 0XB2);
    // 0x80361CFC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80361D00: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x80361D04: sh          $t9, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r25;
    // 0x80361D08: lw          $t3, 0x5530($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5530);
    // 0x80361D0C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361D10: lhu         $v0, 0x0($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X0);
    // 0x80361D14: beq         $v0, $at, L_80361D24
    if (ctx->r2 == ctx->r1) {
        // 0x80361D18: addiu       $at, $zero, 0x90
        ctx->r1 = ADD32(0, 0X90);
            goto L_80361D24;
    }
    // 0x80361D18: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x80361D1C: bnel        $v0, $at, L_80361D4C
    if (ctx->r2 != ctx->r1) {
        // 0x80361D20: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_80361D4C;
    }
    goto skip_15;
    // 0x80361D20: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    skip_15:
L_80361D24:
    // 0x80361D24: lh          $s0, 0x5540($s0)
    ctx->r16 = MEM_H(ctx->r16, 0X5540);
    // 0x80361D28: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80361D2C: sll         $t2, $s0, 5
    ctx->r10 = S32(ctx->r16 << 5);
    // 0x80361D30: andi        $t4, $t2, 0xFF
    ctx->r12 = ctx->r10 & 0XFF;
    // 0x80361D34: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80361D38: jal         0x8034B848
    // 0x80361D3C: sra         $s0, $t5, 16
    ctx->r16 = S32(SIGNED(ctx->r13) >> 16);
    func_8034B848_75CEF8(rdram, ctx);
        goto after_42;
    // 0x80361D3C: sra         $s0, $t5, 16
    ctx->r16 = S32(SIGNED(ctx->r13) >> 16);
    after_42:
    // 0x80361D40: b           L_80361D80
    // 0x80361D44: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
        goto L_80361D80;
    // 0x80361D44: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
    // 0x80361D48: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
L_80361D4C:
    // 0x80361D4C: bne         $v0, $at, L_80361D7C
    if (ctx->r2 != ctx->r1) {
        // 0x80361D50: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_80361D7C;
    }
    // 0x80361D50: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80361D54: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80361D58: lh          $s0, 0x5540($s0)
    ctx->r16 = MEM_H(ctx->r16, 0X5540);
    // 0x80361D5C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80361D60: sll         $t8, $s0, 6
    ctx->r24 = S32(ctx->r16 << 6);
    // 0x80361D64: andi        $t7, $t8, 0xFF
    ctx->r15 = ctx->r24 & 0XFF;
    // 0x80361D68: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80361D6C: jal         0x8034B848
    // 0x80361D70: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    func_8034B848_75CEF8(rdram, ctx);
        goto after_43;
    // 0x80361D70: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    after_43:
    // 0x80361D74: b           L_80361D80
    // 0x80361D78: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
        goto L_80361D80;
    // 0x80361D78: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
L_80361D7C:
    // 0x80361D7C: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
L_80361D80:
    // 0x80361D80: lui         $t4, 0x1
    ctx->r12 = S32(0X1 << 16);
    // 0x80361D84: addiu       $v0, $zero, 0x4C
    ctx->r2 = ADD32(0, 0X4C);
    // 0x80361D88: sll         $t2, $v1, 6
    ctx->r10 = S32(ctx->r3 << 6);
    // 0x80361D8C: subu        $t5, $t4, $t2
    ctx->r13 = SUB32(ctx->r12, ctx->r10);
    // 0x80361D90: multu       $t5, $v0
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80361D94: sll         $t8, $v1, 7
    ctx->r24 = S32(ctx->r3 << 7);
    // 0x80361D98: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80361D9C: lui         $at, 0x4C
    ctx->r1 = S32(0X4C << 16);
    // 0x80361DA0: lh          $t4, 0x2ED0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2ED0);
    // 0x80361DA4: lui         $t2, 0x400
    ctx->r10 = S32(0X400 << 16);
    // 0x80361DA8: addiu       $t2, $t2, 0x39E0
    ctx->r10 = ADD32(ctx->r10, 0X39E0);
    // 0x80361DAC: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    // 0x80361DB0: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80361DB4: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x80361DB8: mflo        $a2
    ctx->r6 = lo;
    // 0x80361DBC: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80361DC0: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80361DC4: multu       $t8, $v0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80361DC8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80361DCC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80361DD0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80361DD4: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x80361DD8: mflo        $t7
    ctx->r15 = lo;
    // 0x80361DDC: addu        $t9, $t7, $at
    ctx->r25 = ADD32(ctx->r15, ctx->r1);
    // 0x80361DE0: sra         $t3, $t9, 6
    ctx->r11 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80361DE4: jal         0x802C78B0
    // 0x80361DE8: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_44;
    // 0x80361DE8: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    after_44:
    // 0x80361DEC: lh          $v0, 0xB2($sp)
    ctx->r2 = MEM_H(ctx->r29, 0XB2);
    // 0x80361DF0: lui         $s0, 0x8020
    ctx->r16 = S32(0X8020 << 16);
    // 0x80361DF4: addiu       $s0, $s0, 0x3FE0
    ctx->r16 = ADD32(ctx->r16, 0X3FE0);
    // 0x80361DF8: sll         $t5, $v0, 7
    ctx->r13 = S32(ctx->r2 << 7);
    // 0x80361DFC: lh          $t8, 0x14($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X14);
    // 0x80361E00: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x80361E04: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x80361E08: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80361E0C: lui         $t0, 0x1
    ctx->r8 = S32(0X1 << 16);
    // 0x80361E10: lui         $t1, 0x4C
    ctx->r9 = S32(0X4C << 16);
    // 0x80361E14: bgez        $v0, L_80361E24
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80361E18: sra         $t6, $v0, 5
        ctx->r14 = S32(SIGNED(ctx->r2) >> 5);
            goto L_80361E24;
    }
    // 0x80361E18: sra         $t6, $v0, 5
    ctx->r14 = S32(SIGNED(ctx->r2) >> 5);
    // 0x80361E1C: addiu       $at, $v0, 0x1F
    ctx->r1 = ADD32(ctx->r2, 0X1F);
    // 0x80361E20: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_80361E24:
    // 0x80361E24: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x80361E28: addu        $t3, $t9, $t6
    ctx->r11 = ADD32(ctx->r25, ctx->r14);
    // 0x80361E2C: sh          $t7, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r15;
    // 0x80361E30: sh          $t3, 0xC($s0)
    MEM_H(0XC, ctx->r16) = ctx->r11;
    // 0x80361E34: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80361E38: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
    // 0x80361E3C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80361E40: lbu         $t2, 0x366($t4)
    ctx->r10 = MEM_BU(ctx->r12, 0X366);
    // 0x80361E44: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80361E48: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80361E4C: beq         $t2, $at, L_80361EC4
    if (ctx->r10 == ctx->r1) {
        // 0x80361E50: sll         $t6, $v1, 4
        ctx->r14 = S32(ctx->r3 << 4);
            goto L_80361EC4;
    }
    // 0x80361E50: sll         $t6, $v1, 4
    ctx->r14 = S32(ctx->r3 << 4);
    // 0x80361E54: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
    // 0x80361E58: addiu       $v0, $zero, 0x4C
    ctx->r2 = ADD32(0, 0X4C);
    // 0x80361E5C: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x80361E60: sll         $t5, $v1, 4
    ctx->r13 = S32(ctx->r3 << 4);
    // 0x80361E64: subu        $t6, $t0, $t5
    ctx->r14 = SUB32(ctx->r8, ctx->r13);
    // 0x80361E68: multu       $t6, $v0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80361E6C: sll         $t7, $v1, 5
    ctx->r15 = S32(ctx->r3 << 5);
    // 0x80361E70: lh          $t2, 0x2ED0($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2ED0);
    // 0x80361E74: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x80361E78: addiu       $t5, $t5, 0x2D90
    ctx->r13 = ADD32(ctx->r13, 0X2D90);
    // 0x80361E7C: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80361E80: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80361E84: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80361E88: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80361E8C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80361E90: mflo        $a2
    ctx->r6 = lo;
    // 0x80361E94: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80361E98: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80361E9C: multu       $t7, $v0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80361EA0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80361EA4: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x80361EA8: mflo        $t9
    ctx->r25 = lo;
    // 0x80361EAC: addu        $t3, $t9, $t1
    ctx->r11 = ADD32(ctx->r25, ctx->r9);
    // 0x80361EB0: sra         $t4, $t3, 6
    ctx->r12 = S32(SIGNED(ctx->r11) >> 6);
    // 0x80361EB4: jal         0x802C78B0
    // 0x80361EB8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_45;
    // 0x80361EB8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_45:
    // 0x80361EBC: b           L_80361F30
    // 0x80361EC0: nop

        goto L_80361F30;
    // 0x80361EC0: nop

L_80361EC4:
    // 0x80361EC4: sll         $t9, $v1, 5
    ctx->r25 = S32(ctx->r3 << 5);
    // 0x80361EC8: sll         $t3, $t9, 2
    ctx->r11 = S32(ctx->r25 << 2);
    // 0x80361ECC: subu        $a2, $t0, $t6
    ctx->r6 = SUB32(ctx->r8, ctx->r14);
    // 0x80361ED0: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x80361ED4: addu        $t3, $t3, $t9
    ctx->r11 = ADD32(ctx->r11, ctx->r25);
    // 0x80361ED8: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x80361EDC: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x80361EE0: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80361EE4: subu        $t3, $t3, $t9
    ctx->r11 = SUB32(ctx->r11, ctx->r25);
    // 0x80361EE8: sll         $t3, $t3, 2
    ctx->r11 = S32(ctx->r11 << 2);
    // 0x80361EEC: subu        $t8, $t8, $a2
    ctx->r24 = SUB32(ctx->r24, ctx->r6);
    // 0x80361EF0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80361EF4: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x80361EF8: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80361EFC: addu        $t4, $t3, $t1
    ctx->r12 = ADD32(ctx->r11, ctx->r9);
    // 0x80361F00: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80361F04: addiu       $t6, $t6, 0x32E8
    ctx->r14 = ADD32(ctx->r14, 0X32E8);
    // 0x80361F08: sra         $t2, $t4, 6
    ctx->r10 = S32(SIGNED(ctx->r12) >> 6);
    // 0x80361F0C: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80361F10: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80361F14: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80361F18: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80361F1C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80361F20: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80361F24: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80361F28: jal         0x802C78B0
    // 0x80361F2C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_46;
    // 0x80361F2C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_46:
L_80361F30:
    // 0x80361F30: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80361F34: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x80361F38: addiu       $at, $zero, 0x23
    ctx->r1 = ADD32(0, 0X23);
    // 0x80361F3C: lhu         $v0, 0x9C($t8)
    ctx->r2 = MEM_HU(ctx->r24, 0X9C);
    // 0x80361F40: beq         $v0, $at, L_80361F58
    if (ctx->r2 == ctx->r1) {
        // 0x80361F44: addiu       $at, $zero, 0x24
        ctx->r1 = ADD32(0, 0X24);
            goto L_80361F58;
    }
    // 0x80361F44: addiu       $at, $zero, 0x24
    ctx->r1 = ADD32(0, 0X24);
    // 0x80361F48: beq         $v0, $at, L_80362130
    if (ctx->r2 == ctx->r1) {
        // 0x80361F4C: lui         $a2, 0x1
        ctx->r6 = S32(0X1 << 16);
            goto L_80362130;
    }
    // 0x80361F4C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80361F50: b           L_803621B4
    // 0x80361F54: nop

        goto L_803621B4;
    // 0x80361F54: nop

L_80361F58:
    // 0x80361F58: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80361F5C: lbu         $v0, 0x2EDD($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2EDD);
    // 0x80361F60: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80361F64: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80361F68: bne         $v0, $zero, L_80361FAC
    if (ctx->r2 != 0) {
        // 0x80361F6C: addiu       $a0, $zero, 0x1
        ctx->r4 = ADD32(0, 0X1);
            goto L_80361FAC;
    }
    // 0x80361F6C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80361F70: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80361F74: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80361F78: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80361F7C: addiu       $t9, $t9, 0x36B0
    ctx->r25 = ADD32(ctx->r25, 0X36B0);
    // 0x80361F80: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80361F84: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80361F88: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80361F8C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80361F90: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80361F94: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80361F98: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80361F9C: jal         0x802C78B0
    // 0x80361FA0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_47;
    // 0x80361FA0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_47:
    // 0x80361FA4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80361FA8: lbu         $v0, 0x2EDD($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2EDD);
L_80361FAC:
    // 0x80361FAC: bne         $v0, $zero, L_803621B4
    if (ctx->r2 != 0) {
        // 0x80361FB0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_803621B4;
    }
    // 0x80361FB0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80361FB4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80361FB8: addiu       $s0, $sp, 0xB0
    ctx->r16 = ADD32(ctx->r29, 0XB0);
    // 0x80361FBC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80361FC0: lh          $a0, 0x326($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X326);
    // 0x80361FC4: addiu       $a2, $sp, 0xAE
    ctx->r6 = ADD32(ctx->r29, 0XAE);
    // 0x80361FC8: addiu       $t3, $a0, 0x1
    ctx->r11 = ADD32(ctx->r4, 0X1);
    // 0x80361FCC: jal         0x8031A150
    // 0x80361FD0: sh          $t3, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r11;
    func_8031A150_72B800(rdram, ctx);
        goto after_48;
    // 0x80361FD0: sh          $t3, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r11;
    after_48:
    // 0x80361FD4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80361FD8: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80361FDC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80361FE0: addiu       $a2, $sp, 0xAE
    ctx->r6 = ADD32(ctx->r29, 0XAE);
    // 0x80361FE4: jal         0x8031A278
    // 0x80361FE8: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_49;
    // 0x80361FE8: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_49:
    // 0x80361FEC: lh          $a2, 0xB0($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XB0);
    // 0x80361FF0: lh          $t2, 0xAE($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XAE);
    // 0x80361FF4: lui         $t6, 0x803C
    ctx->r14 = S32(0X803C << 16);
    // 0x80361FF8: sll         $t4, $a2, 1
    ctx->r12 = S32(ctx->r6 << 1);
    // 0x80361FFC: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80362000: sll         $t5, $t2, 1
    ctx->r13 = S32(ctx->r10 << 1);
    // 0x80362004: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x80362008: addu        $a2, $a2, $t4
    ctx->r6 = ADD32(ctx->r6, ctx->r12);
    // 0x8036200C: lh          $a2, -0x2AB6($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2AB6);
    // 0x80362010: lh          $t6, -0x29FE($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X29FE);
    // 0x80362014: lui         $s0, 0x100
    ctx->r16 = S32(0X100 << 16);
    // 0x80362018: addiu       $s0, $s0, 0xCC0
    ctx->r16 = ADD32(ctx->r16, 0XCC0);
    // 0x8036201C: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80362020: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x80362024: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80362028: sh          $a2, 0xB0($sp)
    MEM_H(0XB0, ctx->r29) = ctx->r6;
    // 0x8036202C: jal         0x80356BD8
    // 0x80362030: sh          $t6, 0xAE($sp)
    MEM_H(0XAE, ctx->r29) = ctx->r14;
    func_80356BD8_768288(rdram, ctx);
        goto after_50;
    // 0x80362030: sh          $t6, 0xAE($sp)
    MEM_H(0XAE, ctx->r29) = ctx->r14;
    after_50:
    // 0x80362034: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
    // 0x80362038: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8036203C: lw          $v0, 0x2EC8($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X2EC8);
    // 0x80362040: sll         $t8, $v1, 4
    ctx->r24 = S32(ctx->r3 << 4);
    // 0x80362044: addiu       $t0, $zero, 0x4C
    ctx->r8 = ADD32(0, 0X4C);
    // 0x80362048: subu        $t7, $v0, $t8
    ctx->r15 = SUB32(ctx->r2, ctx->r24);
    // 0x8036204C: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362050: sll         $t3, $v1, 5
    ctx->r11 = S32(ctx->r3 << 5);
    // 0x80362054: addu        $t4, $t3, $v0
    ctx->r12 = ADD32(ctx->r11, ctx->r2);
    // 0x80362058: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8036205C: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80362060: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80362064: addiu       $t8, $t8, 0x37A0
    ctx->r24 = ADD32(ctx->r24, 0X37A0);
    // 0x80362068: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8036206C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80362070: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80362074: mflo        $a2
    ctx->r6 = lo;
    // 0x80362078: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x8036207C: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80362080: multu       $t4, $t0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362084: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80362088: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8036208C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80362090: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80362094: mflo        $t2
    ctx->r10 = lo;
    // 0x80362098: sra         $t5, $t2, 6
    ctx->r13 = S32(SIGNED(ctx->r10) >> 6);
    // 0x8036209C: jal         0x802C78B0
    // 0x803620A0: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_51;
    // 0x803620A0: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_51:
    // 0x803620A4: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x803620A8: addiu       $a1, $a1, 0x620
    ctx->r5 = ADD32(ctx->r5, 0X620);
    // 0x803620AC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803620B0: jal         0x80356BD8
    // 0x803620B4: lh          $a2, 0xAE($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XAE);
    func_80356BD8_768288(rdram, ctx);
        goto after_52;
    // 0x803620B4: lh          $a2, 0xAE($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XAE);
    after_52:
    // 0x803620B8: lh          $v1, 0xB2($sp)
    ctx->r3 = MEM_H(ctx->r29, 0XB2);
    // 0x803620BC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803620C0: lw          $v0, 0x2EC8($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X2EC8);
    // 0x803620C4: sll         $t7, $v1, 4
    ctx->r15 = S32(ctx->r3 << 4);
    // 0x803620C8: addiu       $t0, $zero, 0x4C
    ctx->r8 = ADD32(0, 0X4C);
    // 0x803620CC: subu        $t9, $v0, $t7
    ctx->r25 = SUB32(ctx->r2, ctx->r15);
    // 0x803620D0: multu       $t9, $t0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803620D4: sll         $t4, $v1, 5
    ctx->r12 = S32(ctx->r3 << 5);
    // 0x803620D8: addu        $t2, $t4, $v0
    ctx->r10 = ADD32(ctx->r12, ctx->r2);
    // 0x803620DC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803620E0: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x803620E4: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x803620E8: addiu       $t7, $t7, 0x37C0
    ctx->r15 = ADD32(ctx->r15, 0X37C0);
    // 0x803620EC: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803620F0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803620F4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803620F8: mflo        $a2
    ctx->r6 = lo;
    // 0x803620FC: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80362100: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80362104: multu       $t2, $t0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362108: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8036210C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80362110: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80362114: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80362118: mflo        $t5
    ctx->r13 = lo;
    // 0x8036211C: sra         $t6, $t5, 6
    ctx->r14 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80362120: jal         0x802C78B0
    // 0x80362124: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_53;
    // 0x80362124: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_53:
    // 0x80362128: b           L_803621B4
    // 0x8036212C: nop

        goto L_803621B4;
    // 0x8036212C: nop

L_80362130:
    // 0x80362130: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80362134: lh          $v0, 0x2ED8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2ED8);
    // 0x80362138: lh          $t3, 0xA($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XA);
    // 0x8036213C: lh          $t2, 0x12($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X12);
    // 0x80362140: sll         $t9, $v0, 5
    ctx->r25 = S32(ctx->r2 << 5);
    // 0x80362144: addu        $t4, $t3, $t9
    ctx->r12 = ADD32(ctx->r11, ctx->r25);
    // 0x80362148: addu        $t5, $t2, $t9
    ctx->r13 = ADD32(ctx->r10, ctx->r25);
    // 0x8036214C: sh          $t4, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r12;
    // 0x80362150: sh          $t5, 0x12($s0)
    MEM_H(0X12, ctx->r16) = ctx->r13;
    // 0x80362154: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80362158: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8036215C: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80362160: ori         $a2, $a2, 0x3000
    ctx->r6 = ctx->r6 | 0X3000;
    // 0x80362164: addiu       $t8, $t8, 0x3DE0
    ctx->r24 = ADD32(ctx->r24, 0X3DE0);
    // 0x80362168: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8036216C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80362170: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80362174: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80362178: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8036217C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80362180: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80362184: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80362188: jal         0x802C78B0
    // 0x8036218C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_54;
    // 0x8036218C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_54:
    // 0x80362190: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80362194: lh          $v0, 0x2ED8($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2ED8);
    // 0x80362198: lh          $t9, 0xA($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XA);
    // 0x8036219C: lh          $t4, 0x12($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X12);
    // 0x803621A0: sll         $t7, $v0, 5
    ctx->r15 = S32(ctx->r2 << 5);
    // 0x803621A4: subu        $t3, $t9, $t7
    ctx->r11 = SUB32(ctx->r25, ctx->r15);
    // 0x803621A8: subu        $t2, $t4, $t7
    ctx->r10 = SUB32(ctx->r12, ctx->r15);
    // 0x803621AC: sh          $t3, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r11;
    // 0x803621B0: sh          $t2, 0x12($s0)
    MEM_H(0X12, ctx->r16) = ctx->r10;
L_803621B4:
    // 0x803621B4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803621B8: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x803621BC: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x803621C0: lui         $t6, 0xBD00
    ctx->r14 = S32(0XBD00 << 16);
    // 0x803621C4: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x803621C8: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x803621CC: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x803621D0: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
L_803621D4:
    // 0x803621D4: jal         0x8035D6A0
    // 0x803621D8: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_55;
    // 0x803621D8: nop

    after_55:
    // 0x803621DC: b           L_803621F0
    // 0x803621E0: lh          $t8, 0xAC($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XAC);
        goto L_803621F0;
    // 0x803621E0: lh          $t8, 0xAC($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XAC);
L_803621E4:
    // 0x803621E4: jal         0x8035D6D0
    // 0x803621E8: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_56;
    // 0x803621E8: nop

    after_56:
    // 0x803621EC: lh          $t8, 0xAC($sp)
    ctx->r24 = MEM_H(ctx->r29, 0XAC);
L_803621F0:
    // 0x803621F0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803621F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803621F8: beq         $t8, $zero, L_80362208
    if (ctx->r24 == 0) {
        // 0x803621FC: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80362208;
    }
    // 0x803621FC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80362200: bnel        $t8, $at, L_8036227C
    if (ctx->r24 != ctx->r1) {
        // 0x80362204: lh          $t4, 0xAC($sp)
        ctx->r12 = MEM_H(ctx->r29, 0XAC);
            goto L_8036227C;
    }
    goto skip_16;
    // 0x80362204: lh          $t4, 0xAC($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XAC);
    skip_16:
L_80362208:
    // 0x80362208: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8036220C: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80362210: lui         $t6, 0x103
    ctx->r14 = S32(0X103 << 16);
    // 0x80362214: lh          $t7, 0xC($v1)
    ctx->r15 = MEM_H(ctx->r3, 0XC);
    // 0x80362218: lhu         $t3, 0xBA($t9)
    ctx->r11 = MEM_HU(ctx->r25, 0XBA);
    // 0x8036221C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x80362220: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x80362224: lh          $a3, 0x302($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X302);
    // 0x80362228: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x8036222C: addu        $a2, $t7, $t4
    ctx->r6 = ADD32(ctx->r15, ctx->r12);
    // 0x80362230: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80362234: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x80362238: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x8036223C: addiu       $t3, $zero, 0x9B
    ctx->r11 = ADD32(0, 0X9B);
    // 0x80362240: addiu       $t9, $zero, 0x15
    ctx->r25 = ADD32(0, 0X15);
    // 0x80362244: addiu       $t6, $t6, 0x3190
    ctx->r14 = ADD32(ctx->r14, 0X3190);
    // 0x80362248: addiu       $t8, $zero, 0x15
    ctx->r24 = ADD32(0, 0X15);
    // 0x8036224C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80362250: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80362254: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x80362258: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x8036225C: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80362260: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80362264: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80362268: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8036226C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80362270: jal         0x8034BD20
    // 0x80362274: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_57;
    // 0x80362274: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    after_57:
    // 0x80362278: lh          $t4, 0xAC($sp)
    ctx->r12 = MEM_H(ctx->r29, 0XAC);
L_8036227C:
    // 0x8036227C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80362280: addiu       $a1, $zero, 0x37A
    ctx->r5 = ADD32(0, 0X37A);
    // 0x80362284: bne         $t4, $zero, L_803622C0
    if (ctx->r12 != 0) {
        // 0x80362288: addiu       $a2, $zero, 0x3F1
        ctx->r6 = ADD32(0, 0X3F1);
            goto L_803622C0;
    }
    // 0x80362288: addiu       $a2, $zero, 0x3F1
    ctx->r6 = ADD32(0, 0X3F1);
    // 0x8036228C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80362290: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80362294: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80362298: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x8036229C: addiu       $a3, $zero, 0x251
    ctx->r7 = ADD32(0, 0X251);
    // 0x803622A0: jal         0x80303820
    // 0x803622A4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_58;
    // 0x803622A4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_58:
    // 0x803622A8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803622AC: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x803622B0: jal         0x80303D50
    // 0x803622B4: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    func_80303D50_715400(rdram, ctx);
        goto after_59;
    // 0x803622B4: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    after_59:
    // 0x803622B8: b           L_803622CC
    // 0x803622BC: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
        goto L_803622CC;
    // 0x803622BC: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
L_803622C0:
    // 0x803622C0: jal         0x80303D00
    // 0x803622C4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    func_80303D00_7153B0(rdram, ctx);
        goto after_60;
    // 0x803622C4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    after_60:
    // 0x803622C8: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
L_803622CC:
    // 0x803622CC: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x803622D0: addiu       $sp, $sp, 0xB8
    ctx->r29 = ADD32(ctx->r29, 0XB8);
    // 0x803622D4: jr          $ra
    // 0x803622D8: nop

    return;
    // 0x803622D8: nop

;}
RECOMP_FUNC void func_803622DC_77398C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803622DC: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x803622E0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803622E4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803622E8: lhu         $t6, 0x2EF0($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X2EF0);
    // 0x803622EC: lhu         $v1, 0x5544($v1)
    ctx->r3 = MEM_HU(ctx->r3, 0X5544);
    // 0x803622F0: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x803622F4: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x803622F8: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x803622FC: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80362300: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80362304: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80362308: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8036230C: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80362310: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80362314: beq         $v1, $t6, L_803625E8
    if (ctx->r3 == ctx->r14) {
        // 0x80362318: sw          $s0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r16;
            goto L_803625E8;
    }
    // 0x80362318: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8036231C: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80362320: lw          $v0, -0x613C($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X613C);
    // 0x80362324: lui         $a0, 0xFF
    ctx->r4 = S32(0XFF << 16);
    // 0x80362328: ori         $a0, $a0, 0xFFFF
    ctx->r4 = ctx->r4 | 0XFFFF;
    // 0x8036232C: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80362330: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80362334: addiu       $t7, $t7, 0x2F28
    ctx->r15 = ADD32(ctx->r15, 0X2F28);
    // 0x80362338: addiu       $t9, $t9, 0x29D0
    ctx->r25 = ADD32(ctx->r25, 0X29D0);
    // 0x8036233C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80362340: and         $t8, $t7, $a0
    ctx->r24 = ctx->r15 & ctx->r4;
    // 0x80362344: and         $t2, $t9, $a0
    ctx->r10 = ctx->r25 & ctx->r4;
    // 0x80362348: lui         $s6, 0x803D
    ctx->r22 = S32(0X803D << 16);
    // 0x8036234C: lui         $s4, 0x8015
    ctx->r20 = S32(0X8015 << 16);
    // 0x80362350: sh          $v1, 0x2EF0($at)
    MEM_H(0X2EF0, ctx->r1) = ctx->r3;
    // 0x80362354: addiu       $s4, $s4, 0x2C78
    ctx->r20 = ADD32(ctx->r20, 0X2C78);
    // 0x80362358: addiu       $s6, $s6, 0x5540
    ctx->r22 = ADD32(ctx->r22, 0X5540);
    // 0x8036235C: or          $s5, $zero, $zero
    ctx->r21 = 0 | 0;
    // 0x80362360: addiu       $s7, $zero, 0x7F
    ctx->r23 = ADD32(0, 0X7F);
    // 0x80362364: addu        $fp, $t8, $v0
    ctx->r30 = ADD32(ctx->r24, ctx->r2);
    // 0x80362368: addu        $t1, $t2, $v0
    ctx->r9 = ADD32(ctx->r10, ctx->r2);
L_8036236C:
    // 0x8036236C: sll         $a0, $s5, 4
    ctx->r4 = S32(ctx->r21 << 4);
    // 0x80362370: addu        $v1, $fp, $a0
    ctx->r3 = ADD32(ctx->r30, ctx->r4);
    // 0x80362374: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x80362378: lh          $t5, 0x0($s6)
    ctx->r13 = MEM_H(ctx->r22, 0X0);
    // 0x8036237C: addu        $s3, $t1, $a0
    ctx->r19 = ADD32(ctx->r9, ctx->r4);
    // 0x80362380: or          $t4, $v0, $zero
    ctx->r12 = ctx->r2 | 0;
    // 0x80362384: sll         $a3, $t4, 4
    ctx->r7 = S32(ctx->r12 << 4);
    // 0x80362388: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x8036238C: addu        $t9, $a3, $t6
    ctx->r25 = ADD32(ctx->r7, ctx->r14);
    // 0x80362390: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x80362394: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x80362398: addu        $t4, $s4, $t3
    ctx->r12 = ADD32(ctx->r20, ctx->r11);
    // 0x8036239C: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x803623A0: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x803623A4: multu       $t6, $v0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803623A8: mflo        $t7
    ctx->r15 = lo;
    // 0x803623AC: sra         $t8, $t7, 12
    ctx->r24 = S32(SIGNED(ctx->r15) >> 12);
    // 0x803623B0: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x803623B4: sh          $t9, 0x0($s3)
    MEM_H(0X0, ctx->r19) = ctx->r25;
    // 0x803623B8: lh          $t2, 0x0($s6)
    ctx->r10 = MEM_H(ctx->r22, 0X0);
    // 0x803623BC: lh          $a1, 0x2($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X2);
    // 0x803623C0: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x803623C4: addu        $t6, $a3, $t3
    ctx->r14 = ADD32(ctx->r7, ctx->r11);
    // 0x803623C8: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x803623CC: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x803623D0: addu        $t9, $s4, $t8
    ctx->r25 = ADD32(ctx->r20, ctx->r24);
    // 0x803623D4: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x803623D8: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x803623DC: multu       $t3, $a1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803623E0: mflo        $t4
    ctx->r12 = lo;
    // 0x803623E4: sra         $t5, $t4, 12
    ctx->r13 = S32(SIGNED(ctx->r12) >> 12);
    // 0x803623E8: addu        $t6, $t5, $a1
    ctx->r14 = ADD32(ctx->r13, ctx->r5);
    // 0x803623EC: sh          $t6, 0x2($s3)
    MEM_H(0X2, ctx->r19) = ctx->r14;
    // 0x803623F0: lh          $t7, 0x0($s6)
    ctx->r15 = MEM_H(ctx->r22, 0X0);
    // 0x803623F4: lh          $a2, 0x4($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X4);
    // 0x803623F8: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x803623FC: addu        $t3, $a3, $t8
    ctx->r11 = ADD32(ctx->r7, ctx->r24);
    // 0x80362400: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x80362404: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x80362408: addu        $t6, $s4, $t5
    ctx->r14 = ADD32(ctx->r20, ctx->r13);
    // 0x8036240C: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x80362410: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80362414: multu       $t8, $a2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362418: mflo        $t9
    ctx->r25 = lo;
    // 0x8036241C: sra         $t2, $t9, 12
    ctx->r10 = S32(SIGNED(ctx->r25) >> 12);
    // 0x80362420: addu        $t3, $t2, $a2
    ctx->r11 = ADD32(ctx->r10, ctx->r6);
    // 0x80362424: sh          $t3, 0x4($s3)
    MEM_H(0X4, ctx->r19) = ctx->r11;
    // 0x80362428: lh          $t4, 0x0($s6)
    ctx->r12 = MEM_H(ctx->r22, 0X0);
    // 0x8036242C: lb          $s0, 0xC($v1)
    ctx->r16 = MEM_B(ctx->r3, 0XC);
    // 0x80362430: lb          $s1, 0xD($v1)
    ctx->r17 = MEM_B(ctx->r3, 0XD);
    // 0x80362434: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x80362438: addu        $t7, $a3, $t5
    ctx->r15 = ADD32(ctx->r7, ctx->r13);
    // 0x8036243C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x80362440: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80362444: addu        $t2, $s4, $t9
    ctx->r10 = ADD32(ctx->r20, ctx->r25);
    // 0x80362448: lh          $a0, 0x0($t2)
    ctx->r4 = MEM_H(ctx->r10, 0X0);
    // 0x8036244C: addiu       $t7, $t7, 0x40
    ctx->r15 = ADD32(ctx->r15, 0X40);
    // 0x80362450: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x80362454: sra         $t3, $a0, 7
    ctx->r11 = S32(SIGNED(ctx->r4) >> 7);
    // 0x80362458: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x8036245C: addu        $s0, $s0, $t4
    ctx->r16 = ADD32(ctx->r16, ctx->r12);
    // 0x80362460: sll         $t5, $s0, 16
    ctx->r13 = S32(ctx->r16 << 16);
    // 0x80362464: sra         $s0, $t5, 16
    ctx->r16 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80362468: multu       $s0, $s0
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8036246C: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80362470: addu        $t2, $s4, $t9
    ctx->r10 = ADD32(ctx->r20, ctx->r25);
    // 0x80362474: lh          $t3, 0x0($t2)
    ctx->r11 = MEM_H(ctx->r10, 0X0);
    // 0x80362478: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x8036247C: lb          $s2, 0xE($v1)
    ctx->r18 = MEM_B(ctx->r3, 0XE);
    // 0x80362480: sra         $t4, $t3, 7
    ctx->r12 = S32(SIGNED(ctx->r11) >> 7);
    // 0x80362484: sra         $t5, $t4, 2
    ctx->r13 = S32(SIGNED(ctx->r12) >> 2);
    // 0x80362488: addu        $s1, $s1, $t5
    ctx->r17 = ADD32(ctx->r17, ctx->r13);
    // 0x8036248C: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x80362490: mflo        $t2
    ctx->r10 = lo;
    // 0x80362494: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80362498: subu        $s2, $s2, $a0
    ctx->r18 = SUB32(ctx->r18, ctx->r4);
    // 0x8036249C: multu       $t7, $t7
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803624A0: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x803624A4: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803624A8: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x803624AC: sw          $t1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r9;
    // 0x803624B0: mflo        $t3
    ctx->r11 = lo;
    // 0x803624B4: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x803624B8: nop

    // 0x803624BC: multu       $s2, $s2
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r18)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803624C0: mflo        $t5
    ctx->r13 = lo;
    // 0x803624C4: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x803624C8: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x803624CC: jal         0x80137E10
    // 0x803624D0: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x803624D0: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    after_0:
    // 0x803624D4: multu       $s0, $s7
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803624D8: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x803624DC: addiu       $s5, $s5, 0x1
    ctx->r21 = ADD32(ctx->r21, 0X1);
    // 0x803624E0: lw          $t1, 0x44($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X44);
    // 0x803624E4: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x803624E8: nop

    // 0x803624EC: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x803624F0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803624F4: mflo        $t2
    ctx->r10 = lo;
    // 0x803624F8: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x803624FC: nop

    // 0x80362500: div         $zero, $t2, $t9
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r25))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r25)));
    // 0x80362504: mflo        $s0
    ctx->r16 = lo;
    // 0x80362508: sll         $t3, $s0, 16
    ctx->r11 = S32(ctx->r16 << 16);
    // 0x8036250C: bne         $v0, $zero, L_80362518
    if (ctx->r2 != 0) {
        // 0x80362510: nop
    
            goto L_80362518;
    }
    // 0x80362510: nop

    // 0x80362514: break       7
    do_break(2151032084);
L_80362518:
    // 0x80362518: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8036251C: bne         $v0, $at, L_80362530
    if (ctx->r2 != ctx->r1) {
        // 0x80362520: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80362530;
    }
    // 0x80362520: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80362524: bne         $t2, $at, L_80362530
    if (ctx->r10 != ctx->r1) {
        // 0x80362528: nop
    
            goto L_80362530;
    }
    // 0x80362528: nop

    // 0x8036252C: break       6
    do_break(2151032108);
L_80362530:
    // 0x80362530: multu       $s1, $s7
    result = U64(U32(ctx->r17)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362534: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80362538: sll         $t3, $s5, 16
    ctx->r11 = S32(ctx->r21 << 16);
    // 0x8036253C: or          $s0, $t4, $zero
    ctx->r16 = ctx->r12 | 0;
    // 0x80362540: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80362544: or          $s5, $t4, $zero
    ctx->r21 = ctx->r12 | 0;
    // 0x80362548: sb          $s0, 0xC($s3)
    MEM_B(0XC, ctx->r19) = ctx->r16;
    // 0x8036254C: mflo        $t5
    ctx->r13 = lo;
    // 0x80362550: nop

    // 0x80362554: nop

    // 0x80362558: div         $zero, $t5, $v0
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r2)));
    // 0x8036255C: mflo        $s1
    ctx->r17 = lo;
    // 0x80362560: sll         $t6, $s1, 16
    ctx->r14 = S32(ctx->r17 << 16);
    // 0x80362564: bne         $v0, $zero, L_80362570
    if (ctx->r2 != 0) {
        // 0x80362568: nop
    
            goto L_80362570;
    }
    // 0x80362568: nop

    // 0x8036256C: break       7
    do_break(2151032172);
L_80362570:
    // 0x80362570: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80362574: bne         $v0, $at, L_80362588
    if (ctx->r2 != ctx->r1) {
        // 0x80362578: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80362588;
    }
    // 0x80362578: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8036257C: bne         $t5, $at, L_80362588
    if (ctx->r13 != ctx->r1) {
        // 0x80362580: nop
    
            goto L_80362588;
    }
    // 0x80362580: nop

    // 0x80362584: break       6
    do_break(2151032196);
L_80362588:
    // 0x80362588: multu       $s2, $s7
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r23)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8036258C: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80362590: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x80362594: sb          $s1, 0xD($s3)
    MEM_B(0XD, ctx->r19) = ctx->r17;
    // 0x80362598: mflo        $t8
    ctx->r24 = lo;
    // 0x8036259C: nop

    // 0x803625A0: nop

    // 0x803625A4: div         $zero, $t8, $v0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r2)));
    // 0x803625A8: bne         $v0, $zero, L_803625B4
    if (ctx->r2 != 0) {
        // 0x803625AC: nop
    
            goto L_803625B4;
    }
    // 0x803625AC: nop

    // 0x803625B0: break       7
    do_break(2151032240);
L_803625B4:
    // 0x803625B4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803625B8: bne         $v0, $at, L_803625CC
    if (ctx->r2 != ctx->r1) {
        // 0x803625BC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803625CC;
    }
    // 0x803625BC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803625C0: bne         $t8, $at, L_803625CC
    if (ctx->r24 != ctx->r1) {
        // 0x803625C4: nop
    
            goto L_803625CC;
    }
    // 0x803625C4: nop

    // 0x803625C8: break       6
    do_break(2151032264);
L_803625CC:
    // 0x803625CC: mflo        $s2
    ctx->r18 = lo;
    // 0x803625D0: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x803625D4: slti        $at, $t4, 0x34
    ctx->r1 = SIGNED(ctx->r12) < 0X34 ? 1 : 0;
    // 0x803625D8: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803625DC: or          $s2, $t2, $zero
    ctx->r18 = ctx->r10 | 0;
    // 0x803625E0: bne         $at, $zero, L_8036236C
    if (ctx->r1 != 0) {
        // 0x803625E4: sb          $t2, 0xE($s3)
        MEM_B(0XE, ctx->r19) = ctx->r10;
            goto L_8036236C;
    }
    // 0x803625E4: sb          $t2, 0xE($s3)
    MEM_B(0XE, ctx->r19) = ctx->r10;
L_803625E8:
    // 0x803625E8: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x803625EC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803625F0: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x803625F4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x803625F8: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x803625FC: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80362600: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80362604: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80362608: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x8036260C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80362610: jr          $ra
    // 0x80362614: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    return;
    // 0x80362614: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
;}
RECOMP_FUNC void sheep_float(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362618: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x8036261C: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x80362620: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x80362624: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80362628: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8036262C: lbu         $t6, 0x36D($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X36D);
    // 0x80362630: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80362634: addiu       $a0, $zero, 0x75
    ctx->r4 = ADD32(0, 0X75);
    // 0x80362638: bne         $t6, $at, L_80362678
    if (ctx->r14 != ctx->r1) {
        // 0x8036263C: addiu       $a1, $zero, 0x5000
        ctx->r5 = ADD32(0, 0X5000);
            goto L_80362678;
    }
    // 0x8036263C: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80362640: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80362644: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80362648: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8036264C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80362650: lh          $t7, 0x8($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X8);
    // 0x80362654: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x80362658: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8036265C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80362660: lh          $t8, 0xC($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XC);
    // 0x80362664: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80362668: jal         0x8032C360
    // 0x8036266C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x8036266C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_0:
    // 0x80362670: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80362674: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80362678:
    // 0x80362678: lh          $t9, 0x2E0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2E0);
    // 0x8036267C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80362680: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x80362684: slti        $at, $t9, 0xF
    ctx->r1 = SIGNED(ctx->r25) < 0XF ? 1 : 0;
    // 0x80362688: beql        $at, $zero, L_803627A4
    if (ctx->r1 == 0) {
        // 0x8036268C: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_803627A4;
    }
    goto skip_0;
    // 0x8036268C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_0:
    // 0x80362690: lbu         $t2, 0x365($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X365);
    // 0x80362694: addiu       $at, $zero, 0x2D
    ctx->r1 = ADD32(0, 0X2D);
    // 0x80362698: beql        $t2, $at, L_803627A4
    if (ctx->r10 == ctx->r1) {
        // 0x8036269C: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_803627A4;
    }
    goto skip_1;
    // 0x8036269C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_1:
    // 0x803626A0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803626A4: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x803626A8: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x803626AC: jal         0x80310EE4
    // 0x803626B0: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_1;
    // 0x803626B0: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    after_1:
    // 0x803626B4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803626B8: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x803626BC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803626C0: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x803626C4: sra         $t9, $v0, 16
    ctx->r25 = S32(SIGNED(ctx->r2) >> 16);
    // 0x803626C8: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x803626CC: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x803626D0: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803626D4: sll         $t4, $t3, 7
    ctx->r12 = S32(ctx->r11 << 7);
    // 0x803626D8: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x803626DC: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803626E0: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x803626E4: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x803626E8: addu        $t7, $t4, $t6
    ctx->r15 = ADD32(ctx->r12, ctx->r14);
    // 0x803626EC: addu        $a2, $a2, $t7
    ctx->r6 = ADD32(ctx->r6, ctx->r15);
    // 0x803626F0: lbu         $a2, 0x746($a2)
    ctx->r6 = MEM_BU(ctx->r6, 0X746);
    // 0x803626F4: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x803626F8: slt         $at, $t8, $t9
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x803626FC: beq         $at, $zero, L_80362720
    if (ctx->r1 == 0) {
        // 0x80362700: or          $a2, $t8, $zero
        ctx->r6 = ctx->r24 | 0;
            goto L_80362720;
    }
    // 0x80362700: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80362704: jal         0x80310EE4
    // 0x80362708: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_2;
    // 0x80362708: lbu         $a2, 0x160($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X160);
    after_2:
    // 0x8036270C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80362710: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x80362714: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80362718: b           L_80362724
    // 0x8036271C: sra         $a0, $v0, 16
    ctx->r4 = S32(SIGNED(ctx->r2) >> 16);
        goto L_80362724;
    // 0x8036271C: sra         $a0, $v0, 16
    ctx->r4 = S32(SIGNED(ctx->r2) >> 16);
L_80362720:
    // 0x80362720: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
L_80362724:
    // 0x80362724: lh          $t2, 0xC($v1)
    ctx->r10 = MEM_H(ctx->r3, 0XC);
    // 0x80362728: addiu       $t4, $zero, 0x2D
    ctx->r12 = ADD32(0, 0X2D);
    // 0x8036272C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80362730: subu        $v0, $t2, $a0
    ctx->r2 = SUB32(ctx->r10, ctx->r4);
    // 0x80362734: sll         $t3, $v0, 16
    ctx->r11 = S32(ctx->r2 << 16);
    // 0x80362738: sra         $t5, $t3, 16
    ctx->r13 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8036273C: slti        $at, $t5, 0x61
    ctx->r1 = SIGNED(ctx->r13) < 0X61 ? 1 : 0;
    // 0x80362740: bnel        $at, $zero, L_803627A4
    if (ctx->r1 != 0) {
        // 0x80362744: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_803627A4;
    }
    goto skip_2;
    // 0x80362744: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_2:
    // 0x80362748: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x8036274C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80362750: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80362754: sb          $t4, 0x365($t6)
    MEM_B(0X365, ctx->r14) = ctx->r12;
    // 0x80362758: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8036275C: lhu         $t7, 0x5544($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X5544);
    // 0x80362760: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80362764: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80362768: sh          $t7, 0x32A($t8)
    MEM_H(0X32A, ctx->r24) = ctx->r15;
    // 0x8036276C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80362770: addiu       $a0, $zero, 0x6B
    ctx->r4 = ADD32(0, 0X6B);
    // 0x80362774: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80362778: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x8036277C: lh          $a3, 0x4($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X4);
    // 0x80362780: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80362784: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80362788: lh          $t2, 0xC($v1)
    ctx->r10 = MEM_H(ctx->r3, 0XC);
    // 0x8036278C: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80362790: jal         0x8032C360
    // 0x80362794: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    play_sound_effect_at_location(rdram, ctx);
        goto after_3;
    // 0x80362794: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_3:
    // 0x80362798: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8036279C: addiu       $t0, $t0, 0x5530
    ctx->r8 = ADD32(ctx->r8, 0X5530);
    // 0x803627A0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_803627A4:
    // 0x803627A4: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x803627A8: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x803627AC: lbu         $a0, 0x162($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X162);
    // 0x803627B0: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x803627B4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803627B8: bne         $a2, $a0, L_8036294C
    if (ctx->r6 != ctx->r4) {
        // 0x803627BC: nop
    
            goto L_8036294C;
    }
    // 0x803627BC: nop

    // 0x803627C0: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x803627C4: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x803627C8: addiu       $a1, $a1, 0x5540
    ctx->r5 = ADD32(ctx->r5, 0X5540);
    // 0x803627CC: lh          $t3, 0x30E($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X30E);
    // 0x803627D0: bgez        $t3, L_803627E8
    if (SIGNED(ctx->r11) >= 0) {
        // 0x803627D4: nop
    
            goto L_803627E8;
    }
    // 0x803627D4: nop

    // 0x803627D8: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x803627DC: sh          $t5, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r13;
    // 0x803627E0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803627E4: lbu         $a0, 0x162($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X162);
L_803627E8:
    // 0x803627E8: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x803627EC: beq         $a0, $at, L_80362954
    if (ctx->r4 == ctx->r1) {
        // 0x803627F0: addiu       $a1, $a1, 0x5540
        ctx->r5 = ADD32(ctx->r5, 0X5540);
            goto L_80362954;
    }
    // 0x803627F0: addiu       $a1, $a1, 0x5540
    ctx->r5 = ADD32(ctx->r5, 0X5540);
    // 0x803627F4: lw          $t4, 0x0($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X0);
    // 0x803627F8: lbu         $v0, 0x36D($t4)
    ctx->r2 = MEM_BU(ctx->r12, 0X36D);
    // 0x803627FC: beq         $v0, $zero, L_8036280C
    if (ctx->r2 == 0) {
        // 0x80362800: slti        $at, $v0, 0x8
        ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
            goto L_8036280C;
    }
    // 0x80362800: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x80362804: bnel        $at, $zero, L_80362838
    if (ctx->r1 != 0) {
        // 0x80362808: lw          $t3, 0x24($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X24);
            goto L_80362838;
    }
    goto skip_3;
    // 0x80362808: lw          $t3, 0x24($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X24);
    skip_3:
L_8036280C:
    // 0x8036280C: lw          $t6, 0x24($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X24);
    // 0x80362810: lui         $at, 0x9
    ctx->r1 = S32(0X9 << 16);
    // 0x80362814: multu       $t6, $a2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80362818: mflo        $t7
    ctx->r15 = lo;
    // 0x8036281C: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x80362820: sra         $t9, $t8, 2
    ctx->r25 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80362824: lui         $at, 0xFFFD
    ctx->r1 = S32(0XFFFD << 16);
    // 0x80362828: addu        $t2, $t9, $at
    ctx->r10 = ADD32(ctx->r25, ctx->r1);
    // 0x8036282C: b           L_80362858
    // 0x80362830: sw          $t2, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r10;
        goto L_80362858;
    // 0x80362830: sw          $t2, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r10;
    // 0x80362834: lw          $t3, 0x24($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X24);
L_80362838:
    // 0x80362838: lui         $at, 0x2D
    ctx->r1 = S32(0X2D << 16);
    // 0x8036283C: sll         $t5, $t3, 4
    ctx->r13 = S32(ctx->r11 << 4);
    // 0x80362840: subu        $t5, $t5, $t3
    ctx->r13 = SUB32(ctx->r13, ctx->r11);
    // 0x80362844: addu        $t4, $t5, $at
    ctx->r12 = ADD32(ctx->r13, ctx->r1);
    // 0x80362848: sra         $t6, $t4, 4
    ctx->r14 = S32(SIGNED(ctx->r12) >> 4);
    // 0x8036284C: lui         $at, 0xFFFD
    ctx->r1 = S32(0XFFFD << 16);
    // 0x80362850: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x80362854: sw          $t7, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r15;
L_80362858:
    // 0x80362858: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8036285C: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x80362860: lui         $t5, 0x803A
    ctx->r13 = S32(0X803A << 16);
    // 0x80362864: lw          $v0, 0x24($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X24);
    // 0x80362868: bgez        $v0, L_8036288C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8036286C: nop
    
            goto L_8036288C;
    }
    // 0x8036286C: nop

    // 0x80362870: lw          $t8, 0x5B0($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5B0);
    // 0x80362874: sll         $t9, $t8, 4
    ctx->r25 = S32(ctx->r24 << 4);
    // 0x80362878: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x8036287C: sra         $t2, $t9, 4
    ctx->r10 = S32(SIGNED(ctx->r25) >> 4);
    // 0x80362880: addu        $t3, $v0, $t2
    ctx->r11 = ADD32(ctx->r2, ctx->r10);
    // 0x80362884: b           L_8036289C
    // 0x80362888: sw          $t3, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r11;
        goto L_8036289C;
    // 0x80362888: sw          $t3, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r11;
L_8036288C:
    // 0x8036288C: lw          $t5, 0x5B0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5B0);
    // 0x80362890: sra         $t4, $t5, 2
    ctx->r12 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80362894: addu        $t6, $v0, $t4
    ctx->r14 = ADD32(ctx->r2, ctx->r12);
    // 0x80362898: sw          $t6, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r14;
L_8036289C:
    // 0x8036289C: lw          $t8, 0x0($t1)
    ctx->r24 = MEM_W(ctx->r9, 0X0);
    // 0x803628A0: lh          $t7, 0x0($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X0);
    // 0x803628A4: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x803628A8: lh          $t9, 0x30E($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X30E);
    // 0x803628AC: addiu       $v0, $v0, 0x2C78
    ctx->r2 = ADD32(ctx->r2, 0X2C78);
    // 0x803628B0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803628B4: subu        $t2, $t7, $t9
    ctx->r10 = SUB32(ctx->r15, ctx->r25);
    // 0x803628B8: sll         $t4, $t2, 2
    ctx->r12 = S32(ctx->r10 << 2);
    // 0x803628BC: addiu       $t6, $t4, 0x40
    ctx->r14 = ADD32(ctx->r12, 0X40);
    // 0x803628C0: andi        $t8, $t6, 0xFF
    ctx->r24 = ctx->r14 & 0XFF;
    // 0x803628C4: sll         $t7, $t8, 1
    ctx->r15 = S32(ctx->r24 << 1);
    // 0x803628C8: addu        $t9, $v0, $t7
    ctx->r25 = ADD32(ctx->r2, ctx->r15);
    // 0x803628CC: lh          $t2, 0x0($t9)
    ctx->r10 = MEM_H(ctx->r25, 0X0);
    // 0x803628D0: lw          $t4, 0x24($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X24);
    // 0x803628D4: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x803628D8: sll         $t5, $t3, 8
    ctx->r13 = S32(ctx->r11 << 8);
    // 0x803628DC: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x803628E0: sw          $t6, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r14;
    // 0x803628E4: lh          $t7, 0x0($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X0);
    // 0x803628E8: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803628EC: sll         $t3, $t7, 3
    ctx->r11 = S32(ctx->r15 << 3);
    // 0x803628F0: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x803628F4: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x803628F8: addu        $t6, $v0, $t5
    ctx->r14 = ADD32(ctx->r2, ctx->r13);
    // 0x803628FC: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x80362900: lw          $t8, 0x1C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X1C);
    // 0x80362904: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80362908: sll         $t2, $t9, 8
    ctx->r10 = S32(ctx->r25 << 8);
    // 0x8036290C: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x80362910: sw          $t3, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r11;
    // 0x80362914: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x80362918: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8036291C: sll         $t9, $t5, 2
    ctx->r25 = S32(ctx->r13 << 2);
    // 0x80362920: addiu       $t8, $t9, 0x40
    ctx->r24 = ADD32(ctx->r25, 0X40);
    // 0x80362924: andi        $t2, $t8, 0xFF
    ctx->r10 = ctx->r24 & 0XFF;
    // 0x80362928: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x8036292C: addu        $t5, $v0, $t3
    ctx->r13 = ADD32(ctx->r2, ctx->r11);
    // 0x80362930: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x80362934: lw          $t4, 0x20($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X20);
    // 0x80362938: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8036293C: sll         $t9, $t7, 8
    ctx->r25 = S32(ctx->r15 << 8);
    // 0x80362940: addu        $t8, $t4, $t9
    ctx->r24 = ADD32(ctx->r12, ctx->r25);
    // 0x80362944: b           L_80362954
    // 0x80362948: sw          $t8, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r24;
        goto L_80362954;
    // 0x80362948: sw          $t8, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r24;
L_8036294C:
    // 0x8036294C: jal         0x8035E3E8
    // 0x80362950: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    recharge_skill(rdram, ctx);
        goto after_4;
    // 0x80362950: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_4:
L_80362954:
    // 0x80362954: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80362958: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8036295C: jr          $ra
    // 0x80362960: nop

    return;
    // 0x80362960: nop

;}
RECOMP_FUNC void func_80362964_774014(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362964: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80362968: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8036296C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80362970: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80362974: lbu         $t7, 0x162($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X162);
    // 0x80362978: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8036297C: bne         $t7, $at, L_80362994
    if (ctx->r15 != ctx->r1) {
        // 0x80362980: nop
    
            goto L_80362994;
    }
    // 0x80362980: nop

    // 0x80362984: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80362988: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x8036298C: jr          $ra
    // 0x80362990: sh          $t8, 0x30E($t9)
    MEM_H(0X30E, ctx->r25) = ctx->r24;
    return;
    // 0x80362990: sh          $t8, 0x30E($t9)
    MEM_H(0X30E, ctx->r25) = ctx->r24;
L_80362994:
    // 0x80362994: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80362998: lh          $t0, 0x30E($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X30E);
    // 0x8036299C: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x803629A0: andi        $t2, $t1, 0xFF
    ctx->r10 = ctx->r9 & 0XFF;
    // 0x803629A4: sh          $t2, 0x30E($v0)
    MEM_H(0X30E, ctx->r2) = ctx->r10;
    // 0x803629A8: jr          $ra
    // 0x803629AC: nop

    return;
    // 0x803629AC: nop

;}
RECOMP_FUNC void func_803629B0_774060(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803629B0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803629B4: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x803629B8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803629BC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803629C0: lbu         $v0, 0x162($t6)
    ctx->r2 = MEM_BU(ctx->r14, 0X162);
    // 0x803629C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803629C8: beq         $v0, $at, L_803629D8
    if (ctx->r2 == ctx->r1) {
        // 0x803629CC: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803629D8;
    }
    // 0x803629CC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803629D0: bne         $v0, $at, L_803629E8
    if (ctx->r2 != ctx->r1) {
        // 0x803629D4: nop
    
            goto L_803629E8;
    }
    // 0x803629D4: nop

L_803629D8:
    // 0x803629D8: jal         0x8037FEDC
    // 0x803629DC: nop

    sheep_follow_leader(rdram, ctx);
        goto after_0;
    // 0x803629DC: nop

    after_0:
    // 0x803629E0: b           L_803629F4
    // 0x803629E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803629F4;
    // 0x803629E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803629E8:
    // 0x803629E8: jal         0x8035E3E8
    // 0x803629EC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    recharge_skill(rdram, ctx);
        goto after_1;
    // 0x803629EC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_1:
    // 0x803629F0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803629F4:
    // 0x803629F4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803629F8: jr          $ra
    // 0x803629FC: nop

    return;
    // 0x803629FC: nop

;}
RECOMP_FUNC void func_80362A00_7740B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362A00: jr          $ra
    // 0x80362A04: nop

    return;
    // 0x80362A04: nop

;}
RECOMP_FUNC void func_80362A08_7740B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362A08: jr          $ra
    // 0x80362A0C: nop

    return;
    // 0x80362A0C: nop

;}
RECOMP_FUNC void springy_ram_headbutt(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362A10: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80362A14: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80362A18: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80362A1C: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x80362A20: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80362A24: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80362A28: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80362A2C: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x80362A30: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80362A34: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x80362A38: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80362A3C: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    // 0x80362A40: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80362A44: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80362A48: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80362A4C: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x80362A50: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80362A54: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    // 0x80362A58: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80362A5C: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x80362A60: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80362A64: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80362A68: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80362A6C: jal         0x8032C360
    // 0x80362A70: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80362A70: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x80362A74: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80362A78: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80362A7C: jr          $ra
    // 0x80362A80: nop

    return;
    // 0x80362A80: nop

;}
RECOMP_FUNC void ram_headbutt(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362A84: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80362A88: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80362A8C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80362A90: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x80362A94: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80362A98: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80362A9C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80362AA0: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x80362AA4: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80362AA8: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x80362AAC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80362AB0: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    // 0x80362AB4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80362AB8: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80362ABC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80362AC0: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x80362AC4: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80362AC8: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    // 0x80362ACC: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80362AD0: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x80362AD4: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80362AD8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80362ADC: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80362AE0: jal         0x8032C360
    // 0x80362AE4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80362AE4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x80362AE8: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80362AEC: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80362AF0: jr          $ra
    // 0x80362AF4: nop

    return;
    // 0x80362AF4: nop

;}
RECOMP_FUNC void func_80362B00_7741B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362B00: lb          $t6, 0x4A($a0)
    ctx->r14 = MEM_B(ctx->r4, 0X4A);
    // 0x80362B04: bne         $t6, $zero, L_80362B24
    if (ctx->r14 != 0) {
        // 0x80362B08: nop
    
            goto L_80362B24;
    }
    // 0x80362B08: nop

    // 0x80362B0C: lbu         $v0, 0x366($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X366);
    // 0x80362B10: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80362B14: beq         $v0, $at, L_80362B24
    if (ctx->r2 == ctx->r1) {
        // 0x80362B18: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80362B24;
    }
    // 0x80362B18: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80362B1C: bnel        $v0, $at, L_80362B30
    if (ctx->r2 != ctx->r1) {
        // 0x80362B20: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80362B30;
    }
    goto skip_0;
    // 0x80362B20: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
L_80362B24:
    // 0x80362B24: jr          $ra
    // 0x80362B28: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362B28: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80362B2C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80362B30:
    // 0x80362B30: jr          $ra
    // 0x80362B34: nop

    return;
    // 0x80362B34: nop

;}
RECOMP_FUNC void can_swim(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362B38: lw          $t6, 0x16C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X16C);
    // 0x80362B3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80362B40: lhu         $t7, 0xA0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA0);
    // 0x80362B44: andi        $t8, $t7, 0x4
    ctx->r24 = ctx->r15 & 0X4;
    // 0x80362B48: beq         $t8, $zero, L_80362B58
    if (ctx->r24 == 0) {
        // 0x80362B4C: nop
    
            goto L_80362B58;
    }
    // 0x80362B4C: nop

    // 0x80362B50: jr          $ra
    // 0x80362B54: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362B54: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80362B58:
    // 0x80362B58: jr          $ra
    // 0x80362B5C: nop

    return;
    // 0x80362B5C: nop

;}
RECOMP_FUNC void func_80362B60_774210(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362B60: lbu         $v0, 0x162($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X162);
    // 0x80362B64: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80362B68: andi        $t6, $v0, 0xF
    ctx->r14 = ctx->r2 & 0XF;
    // 0x80362B6C: beq         $t6, $at, L_80362B8C
    if (ctx->r14 == ctx->r1) {
        // 0x80362B70: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80362B8C;
    }
    // 0x80362B70: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80362B74: beq         $t6, $at, L_80362B8C
    if (ctx->r14 == ctx->r1) {
        // 0x80362B78: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_80362B8C;
    }
    // 0x80362B78: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80362B7C: beq         $t6, $at, L_80362B8C
    if (ctx->r14 == ctx->r1) {
        // 0x80362B80: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_80362B8C;
    }
    // 0x80362B80: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80362B84: bne         $t6, $at, L_80362B94
    if (ctx->r14 != ctx->r1) {
        // 0x80362B88: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80362B94;
    }
    // 0x80362B88: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80362B8C:
    // 0x80362B8C: jr          $ra
    // 0x80362B90: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362B90: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80362B94:
    // 0x80362B94: jr          $ra
    // 0x80362B98: nop

    return;
    // 0x80362B98: nop

;}
RECOMP_FUNC void water_hurts(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362B9C: lw          $t6, 0x16C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X16C);
    // 0x80362BA0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80362BA4: lhu         $t7, 0xA0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0XA0);
    // 0x80362BA8: andi        $t8, $t7, 0xC00
    ctx->r24 = ctx->r15 & 0XC00;
    // 0x80362BAC: beq         $t8, $zero, L_80362BBC
    if (ctx->r24 == 0) {
        // 0x80362BB0: nop
    
            goto L_80362BBC;
    }
    // 0x80362BB0: nop

    // 0x80362BB4: jr          $ra
    // 0x80362BB8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362BB8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80362BBC:
    // 0x80362BBC: jr          $ra
    // 0x80362BC0: nop

    return;
    // 0x80362BC0: nop

;}
RECOMP_FUNC void can_fly(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362BC4: lw          $t6, 0x16C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X16C);
    // 0x80362BC8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80362BCC: lhu         $t7, 0x9E($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X9E);
    // 0x80362BD0: andi        $t8, $t7, 0xE0
    ctx->r24 = ctx->r15 & 0XE0;
    // 0x80362BD4: beq         $t8, $zero, L_80362BE4
    if (ctx->r24 == 0) {
        // 0x80362BD8: nop
    
            goto L_80362BE4;
    }
    // 0x80362BD8: nop

    // 0x80362BDC: jr          $ra
    // 0x80362BE0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362BE0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80362BE4:
    // 0x80362BE4: jr          $ra
    // 0x80362BE8: nop

    return;
    // 0x80362BE8: nop

;}
RECOMP_FUNC void func_80362BEC_77429C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362BEC: lbu         $t6, 0x162($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X162);
    // 0x80362BF0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80362BF4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80362BF8: bne         $t6, $at, L_80362C08
    if (ctx->r14 != ctx->r1) {
        // 0x80362BFC: nop
    
            goto L_80362C08;
    }
    // 0x80362BFC: nop

    // 0x80362C00: jr          $ra
    // 0x80362C04: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80362C04: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80362C08:
    // 0x80362C08: jr          $ra
    // 0x80362C0C: nop

    return;
    // 0x80362C0C: nop

;}
RECOMP_FUNC void func_80362C10_7742C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362C10: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80362C14: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80362C18: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80362C1C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80362C20: lh          $t0, 0x8($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X8);
    // 0x80362C24: lh          $t1, 0x2A6($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2A6);
    // 0x80362C28: lh          $t7, 0x2A4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X2A4);
    // 0x80362C2C: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x80362C30: subu        $a1, $t0, $t1
    ctx->r5 = SUB32(ctx->r8, ctx->r9);
    // 0x80362C34: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x80362C38: subu        $a0, $t6, $t7
    ctx->r4 = SUB32(ctx->r14, ctx->r15);
    // 0x80362C3C: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80362C40: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80362C44: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80362C48: lh          $a2, 0x2D6($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X2D6);
    // 0x80362C4C: jal         0x80305084
    // 0x80362C50: lh          $a3, 0x2DA($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2DA);
    func_80305084_716734(rdram, ctx);
        goto after_0;
    // 0x80362C50: lh          $a3, 0x2DA($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2DA);
    after_0:
    // 0x80362C54: slti        $at, $v0, 0x65
    ctx->r1 = SIGNED(ctx->r2) < 0X65 ? 1 : 0;
    // 0x80362C58: bnel        $at, $zero, L_80362CB4
    if (ctx->r1 != 0) {
        // 0x80362C5C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80362CB4;
    }
    goto skip_0;
    // 0x80362C5C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80362C60: lh          $t4, 0x2DC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X2DC);
    // 0x80362C64: addiu       $t5, $zero, 0xA
    ctx->r13 = ADD32(0, 0XA);
    // 0x80362C68: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80362C6C: bne         $t4, $zero, L_80362CA0
    if (ctx->r12 != 0) {
        // 0x80362C70: addiu       $t3, $zero, 0x6
        ctx->r11 = ADD32(0, 0X6);
            goto L_80362CA0;
    }
    // 0x80362C70: addiu       $t3, $zero, 0x6
    ctx->r11 = ADD32(0, 0X6);
    // 0x80362C74: lh          $t6, 0x4($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X4);
    // 0x80362C78: lh          $t7, 0x2A4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2A4);
    // 0x80362C7C: lh          $t9, 0x8($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X8);
    // 0x80362C80: lh          $t0, 0x2A6($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2A6);
    // 0x80362C84: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x80362C88: sb          $t5, 0x275($s0)
    MEM_B(0X275, ctx->r16) = ctx->r13;
    // 0x80362C8C: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x80362C90: sw          $t8, 0x2D4($s0)
    MEM_W(0X2D4, ctx->r16) = ctx->r24;
    // 0x80362C94: sw          $t1, 0x2D8($s0)
    MEM_W(0X2D8, ctx->r16) = ctx->r9;
    // 0x80362C98: b           L_80362CB0
    // 0x80362C9C: sh          $t2, 0x2DC($s0)
    MEM_H(0X2DC, ctx->r16) = ctx->r10;
        goto L_80362CB0;
    // 0x80362C9C: sh          $t2, 0x2DC($s0)
    MEM_H(0X2DC, ctx->r16) = ctx->r10;
L_80362CA0:
    // 0x80362CA0: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x80362CA4: sb          $t3, 0x2A0($s0)
    MEM_B(0X2A0, ctx->r16) = ctx->r11;
    // 0x80362CA8: sb          $t4, 0x275($s0)
    MEM_B(0X275, ctx->r16) = ctx->r12;
    // 0x80362CAC: sh          $zero, 0x2DC($s0)
    MEM_H(0X2DC, ctx->r16) = 0;
L_80362CB0:
    // 0x80362CB0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80362CB4:
    // 0x80362CB4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80362CB8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80362CBC: jr          $ra
    // 0x80362CC0: nop

    return;
    // 0x80362CC0: nop

;}
RECOMP_FUNC void func_80362CC4_774374(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80362CC4: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x80362CC8: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80362CCC: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80362CD0: lhu         $t6, 0x28C($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X28C);
    // 0x80362CD4: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80362CD8: sltiu       $at, $t6, 0xB
    ctx->r1 = ctx->r14 < 0XB ? 1 : 0;
    // 0x80362CDC: beq         $at, $zero, L_803633B0
    if (ctx->r1 == 0) {
        // 0x80362CE0: sll         $t6, $t6, 2
        ctx->r14 = S32(ctx->r14 << 2);
            goto L_803633B0;
    }
    // 0x80362CE0: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80362CE4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80362CE8: addu        $at, $at, $t6
    gpr jr_addend_80362CF0 = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x80362CEC: lw          $t6, -0x13A0($at)
    ctx->r14 = ADD32(ctx->r1, -0X13A0);
    // 0x80362CF0: jr          $t6
    // 0x80362CF4: nop

    switch (jr_addend_80362CF0 >> 2) {
        case 0: goto L_803633B0; break;
        case 1: goto L_80362CF8; break;
        case 2: goto L_80362E0C; break;
        case 3: goto L_80362E28; break;
        case 4: goto L_80362F4C; break;
        case 5: goto L_803630F4; break;
        case 6: goto L_80363110; break;
        case 7: goto L_80363140; break;
        case 8: goto L_803631B4; break;
        case 9: goto L_8036322C; break;
        case 10: goto L_8036338C; break;
        default: switch_error(__func__, 0x80362CF0, 0x803BEC60);
    }
    // 0x80362CF4: nop

L_80362CF8:
    // 0x80362CF8: lbu         $t7, 0x2A0($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2A0);
    // 0x80362CFC: bnel        $t7, $zero, L_803633B4
    if (ctx->r15 != 0) {
        // 0x80362D00: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_0;
    // 0x80362D00: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x80362D04: lh          $a0, 0x296($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X296);
    // 0x80362D08: sra         $t8, $a0, 12
    ctx->r24 = S32(SIGNED(ctx->r4) >> 12);
    // 0x80362D0C: blez        $t8, L_80362D34
    if (SIGNED(ctx->r24) <= 0) {
        // 0x80362D10: or          $a0, $t8, $zero
        ctx->r4 = ctx->r24 | 0;
            goto L_80362D34;
    }
    // 0x80362D10: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80362D14: lw          $t9, 0x29C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X29C);
    // 0x80362D18: lb          $v1, 0x295($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X295);
    // 0x80362D1C: lbu         $t2, 0x0($t9)
    ctx->r10 = MEM_BU(ctx->r25, 0X0);
    // 0x80362D20: slt         $v0, $v1, $t2
    ctx->r2 = SIGNED(ctx->r3) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x80362D24: xori        $v0, $v0, 0x1
    ctx->r2 = ctx->r2 ^ 0X1;
    // 0x80362D28: andi        $t3, $v0, 0xFF
    ctx->r11 = ctx->r2 & 0XFF;
    // 0x80362D2C: b           L_80362D44
    // 0x80362D30: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
        goto L_80362D44;
    // 0x80362D30: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
L_80362D34:
    // 0x80362D34: lb          $v1, 0x295($s0)
    ctx->r3 = MEM_B(ctx->r16, 0X295);
    // 0x80362D38: slti        $v0, $v1, 0x0
    ctx->r2 = SIGNED(ctx->r3) < 0X0 ? 1 : 0;
    // 0x80362D3C: andi        $t4, $v0, 0xFF
    ctx->r12 = ctx->r2 & 0XFF;
    // 0x80362D40: or          $v0, $t4, $zero
    ctx->r2 = ctx->r12 | 0;
L_80362D44:
    // 0x80362D44: beq         $v0, $zero, L_80362D94
    if (ctx->r2 == 0) {
        // 0x80362D48: sll         $t3, $v1, 2
        ctx->r11 = S32(ctx->r3 << 2);
            goto L_80362D94;
    }
    // 0x80362D48: sll         $t3, $v1, 2
    ctx->r11 = S32(ctx->r3 << 2);
    // 0x80362D4C: lbu         $t5, 0x296($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X296);
    // 0x80362D50: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80362D54: andi        $t6, $t5, 0xF
    ctx->r14 = ctx->r13 & 0XF;
    // 0x80362D58: bne         $t6, $at, L_80362D70
    if (ctx->r14 != ctx->r1) {
        // 0x80362D5C: nop
    
            goto L_80362D70;
    }
    // 0x80362D5C: nop

    // 0x80362D60: jal         0x80363CC8
    // 0x80362D64: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x80362D64: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x80362D68: b           L_803633B0
    // 0x80362D6C: sh          $zero, 0x28C($s0)
    MEM_H(0X28C, ctx->r16) = 0;
        goto L_803633B0;
    // 0x80362D6C: sh          $zero, 0x28C($s0)
    MEM_H(0X28C, ctx->r16) = 0;
L_80362D70:
    // 0x80362D70: blezl       $a0, L_80362D84
    if (SIGNED(ctx->r4) <= 0) {
        // 0x80362D74: lw          $t7, 0x29C($s0)
        ctx->r15 = MEM_W(ctx->r16, 0X29C);
            goto L_80362D84;
    }
    goto skip_1;
    // 0x80362D74: lw          $t7, 0x29C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X29C);
    skip_1:
    // 0x80362D78: b           L_803633B0
    // 0x80362D7C: sb          $zero, 0x295($s0)
    MEM_B(0X295, ctx->r16) = 0;
        goto L_803633B0;
    // 0x80362D7C: sb          $zero, 0x295($s0)
    MEM_B(0X295, ctx->r16) = 0;
    // 0x80362D80: lw          $t7, 0x29C($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X29C);
L_80362D84:
    // 0x80362D84: lbu         $t8, 0x0($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X0);
    // 0x80362D88: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x80362D8C: b           L_803633B0
    // 0x80362D90: sb          $t9, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r25;
        goto L_803633B0;
    // 0x80362D90: sb          $t9, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r25;
L_80362D94:
    // 0x80362D94: lw          $t2, 0x29C($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X29C);
    // 0x80362D98: subu        $t3, $t3, $v1
    ctx->r11 = SUB32(ctx->r11, ctx->r3);
    // 0x80362D9C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80362DA0: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x80362DA4: lbu         $a1, 0x1($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X1);
    // 0x80362DA8: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    // 0x80362DAC: lbu         $a3, 0x3($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0X3);
    // 0x80362DB0: sll         $t4, $a1, 6
    ctx->r12 = S32(ctx->r5 << 6);
    // 0x80362DB4: addiu       $a1, $t4, 0x20
    ctx->r5 = ADD32(ctx->r12, 0X20);
    // 0x80362DB8: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x80362DBC: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80362DC0: lb          $t5, 0x298($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X298);
    // 0x80362DC4: sll         $t7, $a2, 6
    ctx->r15 = S32(ctx->r6 << 6);
    // 0x80362DC8: sll         $t2, $a3, 6
    ctx->r10 = S32(ctx->r7 << 6);
    // 0x80362DCC: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80362DD0: lbu         $t6, 0x297($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X297);
    // 0x80362DD4: addiu       $a3, $t2, 0x20
    ctx->r7 = ADD32(ctx->r10, 0X20);
    // 0x80362DD8: addiu       $a2, $t7, 0x20
    ctx->r6 = ADD32(ctx->r15, 0X20);
    // 0x80362DDC: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x80362DE0: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x80362DE4: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80362DE8: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80362DEC: jal         0x80363C48
    // 0x80362DF0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    set_nav_state_goto_point(rdram, ctx);
        goto after_1;
    // 0x80362DF0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_1:
    // 0x80362DF4: lh          $t8, 0x296($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X296);
    // 0x80362DF8: lb          $t7, 0x295($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X295);
    // 0x80362DFC: sra         $t9, $t8, 12
    ctx->r25 = S32(SIGNED(ctx->r24) >> 12);
    // 0x80362E00: addu        $t2, $t7, $t9
    ctx->r10 = ADD32(ctx->r15, ctx->r25);
    // 0x80362E04: b           L_803633B0
    // 0x80362E08: sb          $t2, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r10;
        goto L_803633B0;
    // 0x80362E08: sb          $t2, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r10;
L_80362E0C:
    // 0x80362E0C: lbu         $t3, 0x2A0($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2A0);
    // 0x80362E10: bnel        $t3, $zero, L_803633B4
    if (ctx->r11 != 0) {
        // 0x80362E14: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_2;
    // 0x80362E14: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_2:
    // 0x80362E18: jal         0x803638E8
    // 0x80362E1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_2;
    // 0x80362E1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
    // 0x80362E20: b           L_803633B4
    // 0x80362E24: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x80362E24: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80362E28:
    // 0x80362E28: lbu         $t4, 0x2A0($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X2A0);
    // 0x80362E2C: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80362E30: bnel        $t4, $zero, L_803633B4
    if (ctx->r12 != 0) {
        // 0x80362E34: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_3;
    // 0x80362E34: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_3:
    // 0x80362E38: lbu         $t5, 0x294($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X294);
    // 0x80362E3C: addiu       $t8, $t8, -0x6C50
    ctx->r24 = ADD32(ctx->r24, -0X6C50);
    // 0x80362E40: lh          $v1, 0x290($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X290);
    // 0x80362E44: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x80362E48: addu        $v0, $t6, $t8
    ctx->r2 = ADD32(ctx->r14, ctx->r24);
    // 0x80362E4C: lbu         $a0, 0x3($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X3);
    // 0x80362E50: lbu         $t0, 0x0($v0)
    ctx->r8 = MEM_BU(ctx->r2, 0X0);
    // 0x80362E54: lbu         $t1, 0x4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X4);
    // 0x80362E58: lbu         $a1, 0x1($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X1);
    // 0x80362E5C: subu        $a2, $a0, $t0
    ctx->r6 = SUB32(ctx->r4, ctx->r8);
    // 0x80362E60: sra         $t7, $a2, 2
    ctx->r15 = S32(SIGNED(ctx->r6) >> 2);
    // 0x80362E64: subu        $a3, $t1, $a1
    ctx->r7 = SUB32(ctx->r9, ctx->r5);
    // 0x80362E68: sra         $t3, $a3, 2
    ctx->r11 = S32(SIGNED(ctx->r7) >> 2);
    // 0x80362E6C: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80362E70: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80362E74: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80362E78: beq         $v1, $zero, L_80362EAC
    if (ctx->r3 == 0) {
        // 0x80362E7C: sra         $a3, $t4, 16
        ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
            goto L_80362EAC;
    }
    // 0x80362E7C: sra         $a3, $t4, 16
    ctx->r7 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80362E80: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80362E84: beq         $v1, $at, L_80362EC0
    if (ctx->r3 == ctx->r1) {
        // 0x80362E88: subu        $t7, $a0, $a2
        ctx->r15 = SUB32(ctx->r4, ctx->r6);
            goto L_80362EC0;
    }
    // 0x80362E88: subu        $t7, $a0, $a2
    ctx->r15 = SUB32(ctx->r4, ctx->r6);
    // 0x80362E8C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80362E90: beq         $v1, $at, L_80362ED0
    if (ctx->r3 == ctx->r1) {
        // 0x80362E94: subu        $t2, $a0, $a2
        ctx->r10 = SUB32(ctx->r4, ctx->r6);
            goto L_80362ED0;
    }
    // 0x80362E94: subu        $t2, $a0, $a2
    ctx->r10 = SUB32(ctx->r4, ctx->r6);
    // 0x80362E98: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80362E9C: beq         $v1, $at, L_80362EE0
    if (ctx->r3 == ctx->r1) {
        // 0x80362EA0: addu        $t4, $t0, $a2
        ctx->r12 = ADD32(ctx->r8, ctx->r6);
            goto L_80362EE0;
    }
    // 0x80362EA0: addu        $t4, $t0, $a2
    ctx->r12 = ADD32(ctx->r8, ctx->r6);
    // 0x80362EA4: b           L_80362EF0
    // 0x80362EA8: lh          $a1, 0x54($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X54);
        goto L_80362EF0;
    // 0x80362EA8: lh          $a1, 0x54($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X54);
L_80362EAC:
    // 0x80362EAC: addu        $t6, $t0, $a2
    ctx->r14 = ADD32(ctx->r8, ctx->r6);
    // 0x80362EB0: addu        $t8, $a1, $a3
    ctx->r24 = ADD32(ctx->r5, ctx->r7);
    // 0x80362EB4: sh          $t6, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r14;
    // 0x80362EB8: b           L_80362EEC
    // 0x80362EBC: sh          $t8, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r24;
        goto L_80362EEC;
    // 0x80362EBC: sh          $t8, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r24;
L_80362EC0:
    // 0x80362EC0: addu        $t9, $a1, $a3
    ctx->r25 = ADD32(ctx->r5, ctx->r7);
    // 0x80362EC4: sh          $t7, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r15;
    // 0x80362EC8: b           L_80362EEC
    // 0x80362ECC: sh          $t9, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r25;
        goto L_80362EEC;
    // 0x80362ECC: sh          $t9, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r25;
L_80362ED0:
    // 0x80362ED0: subu        $t3, $t1, $a3
    ctx->r11 = SUB32(ctx->r9, ctx->r7);
    // 0x80362ED4: sh          $t2, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r10;
    // 0x80362ED8: b           L_80362EEC
    // 0x80362EDC: sh          $t3, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r11;
        goto L_80362EEC;
    // 0x80362EDC: sh          $t3, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r11;
L_80362EE0:
    // 0x80362EE0: subu        $t5, $t1, $a3
    ctx->r13 = SUB32(ctx->r9, ctx->r7);
    // 0x80362EE4: sh          $t4, 0x54($sp)
    MEM_H(0X54, ctx->r29) = ctx->r12;
    // 0x80362EE8: sh          $t5, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r13;
L_80362EEC:
    // 0x80362EEC: lh          $a1, 0x54($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X54);
L_80362EF0:
    // 0x80362EF0: lh          $a2, 0x52($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X52);
    // 0x80362EF4: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x80362EF8: sll         $t6, $a1, 6
    ctx->r14 = S32(ctx->r5 << 6);
    // 0x80362EFC: sll         $t9, $a2, 6
    ctx->r25 = S32(ctx->r6 << 6);
    // 0x80362F00: addiu       $a2, $t9, 0x20
    ctx->r6 = ADD32(ctx->r25, 0X20);
    // 0x80362F04: addiu       $a1, $t6, 0x20
    ctx->r5 = ADD32(ctx->r14, 0X20);
    // 0x80362F08: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80362F0C: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x80362F10: addiu       $t5, $zero, 0x20
    ctx->r13 = ADD32(0, 0X20);
    // 0x80362F14: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x80362F18: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80362F1C: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80362F20: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80362F24: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80362F28: jal         0x80363C48
    // 0x80362F2C: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    set_nav_state_goto_point(rdram, ctx);
        goto after_3;
    // 0x80362F2C: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_3:
    // 0x80362F30: lh          $t6, 0x290($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X290);
    // 0x80362F34: addiu       $t8, $t6, 0x1
    ctx->r24 = ADD32(ctx->r14, 0X1);
    // 0x80362F38: sh          $t8, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r24;
    // 0x80362F3C: lh          $t7, 0x290($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X290);
    // 0x80362F40: andi        $t9, $t7, 0x3
    ctx->r25 = ctx->r15 & 0X3;
    // 0x80362F44: b           L_803633B0
    // 0x80362F48: sh          $t9, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r25;
        goto L_803633B0;
    // 0x80362F48: sh          $t9, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r25;
L_80362F4C:
    // 0x80362F4C: lbu         $v1, 0x28E($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X28E);
    // 0x80362F50: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80362F54: beql        $v1, $zero, L_803630C0
    if (ctx->r3 == 0) {
        // 0x80362F58: lbu         $t3, 0x2A0($s0)
        ctx->r11 = MEM_BU(ctx->r16, 0X2A0);
            goto L_803630C0;
    }
    goto skip_4;
    // 0x80362F58: lbu         $t3, 0x2A0($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2A0);
    skip_4:
    // 0x80362F5C: bnel        $v1, $at, L_803633B4
    if (ctx->r3 != ctx->r1) {
        // 0x80362F60: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_5;
    // 0x80362F60: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_5:
    // 0x80362F64: lh          $v0, 0x290($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X290);
    // 0x80362F68: bne         $v0, $zero, L_803630B4
    if (ctx->r2 != 0) {
        // 0x80362F6C: addiu       $t2, $v0, -0x1
        ctx->r10 = ADD32(ctx->r2, -0X1);
            goto L_803630B4;
    }
    // 0x80362F6C: addiu       $t2, $v0, -0x1
    ctx->r10 = ADD32(ctx->r2, -0X1);
    // 0x80362F70: lbu         $t2, 0x294($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X294);
    // 0x80362F74: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80362F78: addiu       $t4, $t4, -0x6C50
    ctx->r12 = ADD32(ctx->r12, -0X6C50);
    // 0x80362F7C: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x80362F80: addu        $v0, $t3, $t4
    ctx->r2 = ADD32(ctx->r11, ctx->r12);
    // 0x80362F84: lbu         $t5, 0x3($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X3);
    // 0x80362F88: lbu         $t6, 0x0($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X0);
    // 0x80362F8C: lbu         $t2, 0x4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X4);
    // 0x80362F90: lbu         $t3, 0x1($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X1);
    // 0x80362F94: subu        $v1, $t5, $t6
    ctx->r3 = SUB32(ctx->r13, ctx->r14);
    // 0x80362F98: addiu       $t8, $v1, -0x1
    ctx->r24 = ADD32(ctx->r3, -0X1);
    // 0x80362F9C: subu        $t0, $t2, $t3
    ctx->r8 = SUB32(ctx->r10, ctx->r11);
    // 0x80362FA0: sll         $t7, $t8, 22
    ctx->r15 = S32(ctx->r24 << 22);
    // 0x80362FA4: addiu       $t4, $t0, -0x1
    ctx->r12 = ADD32(ctx->r8, -0X1);
    // 0x80362FA8: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80362FAC: sll         $t5, $t4, 22
    ctx->r13 = S32(ctx->r12 << 22);
    // 0x80362FB0: bgtz        $v1, L_80362FBC
    if (SIGNED(ctx->r3) > 0) {
        // 0x80362FB4: sra         $t0, $t5, 16
        ctx->r8 = S32(SIGNED(ctx->r13) >> 16);
            goto L_80362FBC;
    }
    // 0x80362FB4: sra         $t0, $t5, 16
    ctx->r8 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80362FB8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80362FBC:
    // 0x80362FBC: bgtzl       $t0, L_80362FCC
    if (SIGNED(ctx->r8) > 0) {
        // 0x80362FC0: sh          $v1, 0x48($sp)
        MEM_H(0X48, ctx->r29) = ctx->r3;
            goto L_80362FCC;
    }
    goto skip_6;
    // 0x80362FC0: sh          $v1, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r3;
    skip_6:
    // 0x80362FC4: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80362FC8: sh          $v1, 0x48($sp)
    MEM_H(0X48, ctx->r29) = ctx->r3;
L_80362FCC:
    // 0x80362FCC: jal         0x8012826C
    // 0x80362FD0: sh          $t0, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r8;
    advance_random_seed(rdram, ctx);
        goto after_4;
    // 0x80362FD0: sh          $t0, 0x46($sp)
    MEM_H(0X46, ctx->r29) = ctx->r8;
    after_4:
    // 0x80362FD4: lh          $v1, 0x48($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X48);
    // 0x80362FD8: lbu         $t7, 0x294($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X294);
    // 0x80362FDC: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x80362FE0: div         $zero, $v0, $v1
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r3)));
    // 0x80362FE4: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x80362FE8: addu        $t2, $t2, $t9
    ctx->r10 = ADD32(ctx->r10, ctx->r25);
    // 0x80362FEC: lbu         $t2, -0x6C50($t2)
    ctx->r10 = MEM_BU(ctx->r10, -0X6C50);
    // 0x80362FF0: mfhi        $t8
    ctx->r24 = hi;
    // 0x80362FF4: lh          $t0, 0x46($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X46);
    // 0x80362FF8: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x80362FFC: sll         $t4, $t3, 6
    ctx->r12 = S32(ctx->r11 << 6);
    // 0x80363000: addu        $t5, $t8, $t4
    ctx->r13 = ADD32(ctx->r24, ctx->r12);
    // 0x80363004: bne         $v1, $zero, L_80363010
    if (ctx->r3 != 0) {
        // 0x80363008: nop
    
            goto L_80363010;
    }
    // 0x80363008: nop

    // 0x8036300C: break       7
    do_break(2151034892);
L_80363010:
    // 0x80363010: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80363014: bne         $v1, $at, L_80363028
    if (ctx->r3 != ctx->r1) {
        // 0x80363018: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80363028;
    }
    // 0x80363018: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8036301C: bne         $v0, $at, L_80363028
    if (ctx->r2 != ctx->r1) {
        // 0x80363020: nop
    
            goto L_80363028;
    }
    // 0x80363020: nop

    // 0x80363024: break       6
    do_break(2151034916);
L_80363028:
    // 0x80363028: sh          $t5, 0x4C($sp)
    MEM_H(0X4C, ctx->r29) = ctx->r13;
    // 0x8036302C: jal         0x8012826C
    // 0x80363030: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x80363030: nop

    after_5:
    // 0x80363034: lh          $t0, 0x46($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X46);
    // 0x80363038: lbu         $t7, 0x294($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X294);
    // 0x8036303C: lui         $t2, 0x803F
    ctx->r10 = S32(0X803F << 16);
    // 0x80363040: div         $zero, $v0, $t0
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r8))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r8)));
    // 0x80363044: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x80363048: addu        $t2, $t2, $t9
    ctx->r10 = ADD32(ctx->r10, ctx->r25);
    // 0x8036304C: lbu         $t2, -0x6C4F($t2)
    ctx->r10 = MEM_BU(ctx->r10, -0X6C4F);
    // 0x80363050: mfhi        $t6
    ctx->r14 = hi;
    // 0x80363054: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x80363058: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x8036305C: sll         $t8, $t3, 6
    ctx->r24 = S32(ctx->r11 << 6);
    // 0x80363060: addu        $a2, $t6, $t8
    ctx->r6 = ADD32(ctx->r14, ctx->r24);
    // 0x80363064: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x80363068: addiu       $t7, $zero, 0xA
    ctx->r15 = ADD32(0, 0XA);
    // 0x8036306C: bne         $t0, $zero, L_80363078
    if (ctx->r8 != 0) {
        // 0x80363070: nop
    
            goto L_80363078;
    }
    // 0x80363070: nop

    // 0x80363074: break       7
    do_break(2151034996);
L_80363078:
    // 0x80363078: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8036307C: bne         $t0, $at, L_80363090
    if (ctx->r8 != ctx->r1) {
        // 0x80363080: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80363090;
    }
    // 0x80363080: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80363084: bne         $v0, $at, L_80363090
    if (ctx->r2 != ctx->r1) {
        // 0x80363088: nop
    
            goto L_80363090;
    }
    // 0x80363088: nop

    // 0x8036308C: break       6
    do_break(2151035020);
L_80363090:
    // 0x80363090: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80363094: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80363098: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8036309C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803630A0: lh          $a1, 0x4C($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X4C);
    // 0x803630A4: jal         0x80363C48
    // 0x803630A8: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    set_nav_state_goto_point(rdram, ctx);
        goto after_6;
    // 0x803630A8: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_6:
    // 0x803630AC: b           L_803633B0
    // 0x803630B0: sb          $zero, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = 0;
        goto L_803633B0;
    // 0x803630B0: sb          $zero, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = 0;
L_803630B4:
    // 0x803630B4: b           L_803633B0
    // 0x803630B8: sh          $t2, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r10;
        goto L_803633B0;
    // 0x803630B8: sh          $t2, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r10;
    // 0x803630BC: lbu         $t3, 0x2A0($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2A0);
L_803630C0:
    // 0x803630C0: bnel        $t3, $zero, L_803633B4
    if (ctx->r11 != 0) {
        // 0x803630C4: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_7;
    // 0x803630C4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_7:
    // 0x803630C8: jal         0x8012826C
    // 0x803630CC: nop

    advance_random_seed(rdram, ctx);
        goto after_7;
    // 0x803630CC: nop

    after_7:
    // 0x803630D0: andi        $t6, $v0, 0x3F
    ctx->r14 = ctx->r2 & 0X3F;
    // 0x803630D4: addiu       $t8, $t6, 0x3C
    ctx->r24 = ADD32(ctx->r14, 0X3C);
    // 0x803630D8: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x803630DC: sh          $t8, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r24;
    // 0x803630E0: sb          $t4, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = ctx->r12;
    // 0x803630E4: jal         0x80363CC8
    // 0x803630E8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_8;
    // 0x803630E8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_8:
    // 0x803630EC: b           L_803633B4
    // 0x803630F0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x803630F0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_803630F4:
    // 0x803630F4: lbu         $t5, 0x2A0($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2A0);
    // 0x803630F8: bnel        $t5, $zero, L_803633B4
    if (ctx->r13 != 0) {
        // 0x803630FC: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_8;
    // 0x803630FC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_8:
    // 0x80363100: jal         0x803638E8
    // 0x80363104: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_9;
    // 0x80363104: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_9:
    // 0x80363108: b           L_803633B4
    // 0x8036310C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x8036310C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80363110:
    // 0x80363110: lh          $t9, 0x294($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X294);
    // 0x80363114: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80363118: lh          $t7, 0x2C($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2C);
    // 0x8036311C: sll         $t2, $t9, 8
    ctx->r10 = S32(ctx->r25 << 8);
    // 0x80363120: div         $zero, $t2, $at
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r1)));
    // 0x80363124: mflo        $t3
    ctx->r11 = lo;
    // 0x80363128: bnel        $t7, $t3, L_803633B4
    if (ctx->r15 != ctx->r11) {
        // 0x8036312C: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_9;
    // 0x8036312C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_9:
    // 0x80363130: jal         0x803638E8
    // 0x80363134: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_10;
    // 0x80363134: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_10:
    // 0x80363138: b           L_803633B4
    // 0x8036313C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x8036313C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80363140:
    // 0x80363140: lw          $v0, 0x294($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X294);
    // 0x80363144: lh          $t8, 0x4($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X4);
    // 0x80363148: lh          $t5, 0x8($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X8);
    // 0x8036314C: lh          $t6, 0x4($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X4);
    // 0x80363150: lh          $t4, 0x8($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X8);
    // 0x80363154: subu        $v1, $t6, $t8
    ctx->r3 = SUB32(ctx->r14, ctx->r24);
    // 0x80363158: subu        $a2, $t4, $t5
    ctx->r6 = SUB32(ctx->r12, ctx->r13);
    // 0x8036315C: sll         $a1, $a2, 16
    ctx->r5 = S32(ctx->r6 << 16);
    // 0x80363160: sll         $a0, $v1, 16
    ctx->r4 = S32(ctx->r3 << 16);
    // 0x80363164: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80363168: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8036316C: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x80363170: jal         0x801284B8
    // 0x80363174: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    func_801284B8(rdram, ctx);
        goto after_11;
    // 0x80363174: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    after_11:
    // 0x80363178: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x8036317C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80363180: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80363184: mflo        $t7
    ctx->r15 = lo;
    // 0x80363188: sll         $t3, $t7, 16
    ctx->r11 = S32(ctx->r15 << 16);
    // 0x8036318C: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80363190: jal         0x803051F0
    // 0x80363194: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    func_803051F0_7168A0(rdram, ctx);
        goto after_12;
    // 0x80363194: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    after_12:
    // 0x80363198: slti        $at, $v0, 0x6
    ctx->r1 = SIGNED(ctx->r2) < 0X6 ? 1 : 0;
    // 0x8036319C: beql        $at, $zero, L_803633B4
    if (ctx->r1 == 0) {
        // 0x803631A0: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_10;
    // 0x803631A0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_10:
    // 0x803631A4: jal         0x803638E8
    // 0x803631A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_13;
    // 0x803631A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_13:
    // 0x803631AC: b           L_803633B4
    // 0x803631B0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x803631B0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_803631B4:
    // 0x803631B4: lbu         $t8, 0x29A($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X29A);
    // 0x803631B8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803631BC: addiu       $v1, $v1, 0x5534
    ctx->r3 = ADD32(ctx->r3, 0X5534);
    // 0x803631C0: beq         $t8, $zero, L_8036320C
    if (ctx->r24 == 0) {
        // 0x803631C4: nop
    
            goto L_8036320C;
    }
    // 0x803631C4: nop

    // 0x803631C8: lh          $t4, 0x0($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X0);
    // 0x803631CC: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x803631D0: addiu       $v0, $v0, -0x6128
    ctx->r2 = ADD32(ctx->r2, -0X6128);
    // 0x803631D4: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x803631D8: addu        $t9, $v0, $t5
    ctx->r25 = ADD32(ctx->r2, ctx->r13);
    // 0x803631DC: lw          $t2, 0x3EB4($t9)
    ctx->r10 = MEM_W(ctx->r25, 0X3EB4);
    // 0x803631E0: sw          $t2, 0x294($s0)
    MEM_W(0X294, ctx->r16) = ctx->r10;
    // 0x803631E4: lh          $t7, 0x0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X0);
    // 0x803631E8: sll         $t3, $t7, 3
    ctx->r11 = S32(ctx->r15 << 3);
    // 0x803631EC: addu        $t6, $v0, $t3
    ctx->r14 = ADD32(ctx->r2, ctx->r11);
    // 0x803631F0: lw          $t8, 0x3EB4($t6)
    ctx->r24 = MEM_W(ctx->r14, 0X3EB4);
    // 0x803631F4: sw          $t8, 0x2AC($s0)
    MEM_W(0X2AC, ctx->r16) = ctx->r24;
    // 0x803631F8: lh          $t4, 0x0($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X0);
    // 0x803631FC: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x80363200: addu        $t9, $v0, $t5
    ctx->r25 = ADD32(ctx->r2, ctx->r13);
    // 0x80363204: lw          $t2, 0x3EB4($t9)
    ctx->r10 = MEM_W(ctx->r25, 0X3EB4);
    // 0x80363208: sw          $t2, 0x2CC($s0)
    MEM_W(0X2CC, ctx->r16) = ctx->r10;
L_8036320C:
    // 0x8036320C: jal         0x803099BC
    // 0x80363210: nop

    func_803099BC_71B06C(rdram, ctx);
        goto after_14;
    // 0x80363210: nop

    after_14:
    // 0x80363214: bnel        $v0, $zero, L_803633B4
    if (ctx->r2 != 0) {
        // 0x80363218: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_11;
    // 0x80363218: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_11:
    // 0x8036321C: jal         0x803638E8
    // 0x80363220: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_15;
    // 0x80363220: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_15:
    // 0x80363224: b           L_803633B4
    // 0x80363228: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x80363228: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8036322C:
    // 0x8036322C: lw          $t7, 0x294($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X294);
    // 0x80363230: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80363234: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80363238: sw          $t7, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r15;
    // 0x8036323C: lbu         $t6, 0x26C($t7)
    ctx->r14 = MEM_BU(ctx->r15, 0X26C);
    // 0x80363240: beql        $t6, $zero, L_80363264
    if (ctx->r14 == 0) {
        // 0x80363244: lbu         $v1, 0x28E($s0)
        ctx->r3 = MEM_BU(ctx->r16, 0X28E);
            goto L_80363264;
    }
    goto skip_12;
    // 0x80363244: lbu         $v1, 0x28E($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X28E);
    skip_12:
    // 0x80363248: jal         0x803153B0
    // 0x8036324C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    load_commands_into_object(rdram, ctx);
        goto after_16;
    // 0x8036324C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_16:
    // 0x80363250: jal         0x803638E8
    // 0x80363254: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_17;
    // 0x80363254: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_17:
    // 0x80363258: b           L_803633B4
    // 0x8036325C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x8036325C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80363260: lbu         $v1, 0x28E($s0)
    ctx->r3 = MEM_BU(ctx->r16, 0X28E);
L_80363264:
    // 0x80363264: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80363268: beql        $v1, $zero, L_80363290
    if (ctx->r3 == 0) {
        // 0x8036326C: lbu         $t8, 0x2A0($s0)
        ctx->r24 = MEM_BU(ctx->r16, 0X2A0);
            goto L_80363290;
    }
    goto skip_13;
    // 0x8036326C: lbu         $t8, 0x2A0($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2A0);
    skip_13:
    // 0x80363270: beq         $v1, $at, L_803632E8
    if (ctx->r3 == ctx->r1) {
        // 0x80363274: lw          $t8, 0x28($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X28);
            goto L_803632E8;
    }
    // 0x80363274: lw          $t8, 0x28($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X28);
    // 0x80363278: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8036327C: beql        $v1, $at, L_80363364
    if (ctx->r3 == ctx->r1) {
        // 0x80363280: lh          $t2, 0x290($s0)
        ctx->r10 = MEM_H(ctx->r16, 0X290);
            goto L_80363364;
    }
    goto skip_14;
    // 0x80363280: lh          $t2, 0x290($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X290);
    skip_14:
    // 0x80363284: b           L_803633B4
    // 0x80363288: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x80363288: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8036328C: lbu         $t8, 0x2A0($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2A0);
L_80363290:
    // 0x80363290: lw          $t4, 0x28($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X28);
    // 0x80363294: bnel        $t8, $zero, L_803633B4
    if (ctx->r24 != 0) {
        // 0x80363298: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_15;
    // 0x80363298: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_15:
    // 0x8036329C: lh          $t5, 0x1C($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X1C);
    // 0x803632A0: lh          $t9, 0x20($t4)
    ctx->r25 = MEM_H(ctx->r12, 0X20);
    // 0x803632A4: lh          $t7, 0x24($t4)
    ctx->r15 = MEM_H(ctx->r12, 0X24);
    // 0x803632A8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803632AC: or          $t2, $t5, $t9
    ctx->r10 = ctx->r13 | ctx->r25;
    // 0x803632B0: or          $t3, $t2, $t7
    ctx->r11 = ctx->r10 | ctx->r15;
    // 0x803632B4: bne         $t3, $zero, L_803632D4
    if (ctx->r11 != 0) {
        // 0x803632B8: lw          $a1, 0x28($sp)
        ctx->r5 = MEM_W(ctx->r29, 0X28);
            goto L_803632D4;
    }
    // 0x803632B8: lw          $a1, 0x28($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X28);
    // 0x803632BC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x803632C0: jal         0x80363E88
    // 0x803632C4: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    set_nav_state_follow_target(rdram, ctx);
        goto after_18;
    // 0x803632C4: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    after_18:
    // 0x803632C8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x803632CC: b           L_803633B0
    // 0x803632D0: sb          $t6, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = ctx->r14;
        goto L_803633B0;
    // 0x803632D0: sb          $t6, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = ctx->r14;
L_803632D4:
    // 0x803632D4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803632D8: jal         0x80363DB4
    // 0x803632DC: lh          $a3, 0x298($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X298);
    set_nav_state_chase_attack(rdram, ctx);
        goto after_19;
    // 0x803632DC: lh          $a3, 0x298($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X298);
    after_19:
    // 0x803632E0: b           L_803633B4
    // 0x803632E4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x803632E4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_803632E8:
    // 0x803632E8: lh          $t5, 0x4($t8)
    ctx->r13 = MEM_H(ctx->r24, 0X4);
    // 0x803632EC: lh          $t9, 0x4($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X4);
    // 0x803632F0: lh          $t2, 0x8($t8)
    ctx->r10 = MEM_H(ctx->r24, 0X8);
    // 0x803632F4: lh          $t7, 0x8($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X8);
    // 0x803632F8: subu        $v0, $t5, $t9
    ctx->r2 = SUB32(ctx->r13, ctx->r25);
    // 0x803632FC: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x80363300: subu        $v1, $t2, $t7
    ctx->r3 = SUB32(ctx->r10, ctx->r15);
    // 0x80363304: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x80363308: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8036330C: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80363310: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80363314: jal         0x801284B8
    // 0x80363318: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    func_801284B8(rdram, ctx);
        goto after_20;
    // 0x80363318: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    after_20:
    // 0x8036331C: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x80363320: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80363324: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80363328: mflo        $t6
    ctx->r14 = lo;
    // 0x8036332C: sll         $t5, $t6, 16
    ctx->r13 = S32(ctx->r14 << 16);
    // 0x80363330: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80363334: jal         0x803051F0
    // 0x80363338: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    func_803051F0_7168A0(rdram, ctx);
        goto after_21;
    // 0x80363338: lh          $a1, 0x2C($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2C);
    after_21:
    // 0x8036333C: slti        $at, $v0, 0x4
    ctx->r1 = SIGNED(ctx->r2) < 0X4 ? 1 : 0;
    // 0x80363340: beq         $at, $zero, L_803633B0
    if (ctx->r1 == 0) {
        // 0x80363344: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_803633B0;
    }
    // 0x80363344: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80363348: jal         0x8037B754
    // 0x8036334C: lw          $a1, 0x294($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X294);
    func_8037B754_78CE04(rdram, ctx);
        goto after_22;
    // 0x8036334C: lw          $a1, 0x294($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X294);
    after_22:
    // 0x80363350: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80363354: sh          $zero, 0x290($s0)
    MEM_H(0X290, ctx->r16) = 0;
    // 0x80363358: b           L_803633B0
    // 0x8036335C: sb          $t8, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = ctx->r24;
        goto L_803633B0;
    // 0x8036335C: sb          $t8, 0x28E($s0)
    MEM_B(0X28E, ctx->r16) = ctx->r24;
    // 0x80363360: lh          $t2, 0x290($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X290);
L_80363364:
    // 0x80363364: addiu       $t7, $t2, 0x1
    ctx->r15 = ADD32(ctx->r10, 0X1);
    // 0x80363368: sh          $t7, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r15;
    // 0x8036336C: lh          $t3, 0x290($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X290);
    // 0x80363370: slti        $at, $t3, 0x15
    ctx->r1 = SIGNED(ctx->r11) < 0X15 ? 1 : 0;
    // 0x80363374: bnel        $at, $zero, L_803633B4
    if (ctx->r1 != 0) {
        // 0x80363378: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_16;
    // 0x80363378: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_16:
    // 0x8036337C: jal         0x803638E8
    // 0x80363380: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_23;
    // 0x80363380: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_23:
    // 0x80363384: b           L_803633B4
    // 0x80363388: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_803633B4;
    // 0x80363388: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_8036338C:
    // 0x8036338C: lh          $t4, 0x290($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X290);
    // 0x80363390: addiu       $t6, $t4, 0x1
    ctx->r14 = ADD32(ctx->r12, 0X1);
    // 0x80363394: sh          $t6, 0x290($s0)
    MEM_H(0X290, ctx->r16) = ctx->r14;
    // 0x80363398: lh          $t5, 0x290($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X290);
    // 0x8036339C: slti        $at, $t5, 0x3D
    ctx->r1 = SIGNED(ctx->r13) < 0X3D ? 1 : 0;
    // 0x803633A0: bnel        $at, $zero, L_803633B4
    if (ctx->r1 != 0) {
        // 0x803633A4: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_803633B4;
    }
    goto skip_17;
    // 0x803633A4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_17:
    // 0x803633A8: jal         0x803638E8
    // 0x803633AC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    reset_waypoint_mode(rdram, ctx);
        goto after_24;
    // 0x803633AC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_24:
L_803633B0:
    // 0x803633B0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_803633B4:
    // 0x803633B4: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x803633B8: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x803633BC: jr          $ra
    // 0x803633C0: nop

    return;
    // 0x803633C0: nop

;}
RECOMP_FUNC void func_803633C4_774A74(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803633C4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803633C8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803633CC: lbu         $t6, 0x2A0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X2A0);
    // 0x803633D0: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x803633D4: sltiu       $at, $t6, 0x9
    ctx->r1 = ctx->r14 < 0X9 ? 1 : 0;
    // 0x803633D8: beq         $at, $zero, L_80363728
    if (ctx->r1 == 0) {
        // 0x803633DC: sll         $t6, $t6, 2
        ctx->r14 = S32(ctx->r14 << 2);
            goto L_80363728;
    }
    // 0x803633DC: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x803633E0: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803633E4: addu        $at, $at, $t6
    gpr jr_addend_803633EC = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x803633E8: lw          $t6, -0x1374($at)
    ctx->r14 = ADD32(ctx->r1, -0X1374);
    // 0x803633EC: jr          $t6
    // 0x803633F0: nop

    switch (jr_addend_803633EC >> 2) {
        case 0: goto L_80363728; break;
        case 1: goto L_803633F4; break;
        case 2: goto L_80363468; break;
        case 3: goto L_80363508; break;
        case 4: goto L_80363548; break;
        case 5: goto L_80363728; break;
        case 6: goto L_803635E8; break;
        case 7: goto L_80363728; break;
        case 8: goto L_80363664; break;
        default: switch_error(__func__, 0x803633EC, 0x803BEC8C);
    }
    // 0x803633F0: nop

L_803633F4:
    // 0x803633F4: lh          $t7, 0x2A4($a2)
    ctx->r15 = MEM_H(ctx->r6, 0X2A4);
    // 0x803633F8: lh          $t8, 0x4($a2)
    ctx->r24 = MEM_H(ctx->r6, 0X4);
    // 0x803633FC: subu        $v0, $t7, $t8
    ctx->r2 = SUB32(ctx->r15, ctx->r24);
    // 0x80363400: bgez        $v0, L_80363410
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80363404: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80363410;
    }
    // 0x80363404: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80363408: b           L_80363410
    // 0x8036340C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80363410;
    // 0x8036340C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_80363410:
    // 0x80363410: lbu         $a0, 0x2A2($a2)
    ctx->r4 = MEM_BU(ctx->r6, 0X2A2);
    // 0x80363414: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80363418: beq         $at, $zero, L_80363458
    if (ctx->r1 == 0) {
        // 0x8036341C: nop
    
            goto L_80363458;
    }
    // 0x8036341C: nop

    // 0x80363420: lh          $t9, 0x2A6($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X2A6);
    // 0x80363424: lh          $t0, 0x8($a2)
    ctx->r8 = MEM_H(ctx->r6, 0X8);
    // 0x80363428: subu        $v0, $t9, $t0
    ctx->r2 = SUB32(ctx->r25, ctx->r8);
    // 0x8036342C: bgez        $v0, L_8036343C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80363430: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_8036343C;
    }
    // 0x80363430: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80363434: b           L_8036343C
    // 0x80363438: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_8036343C;
    // 0x80363438: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_8036343C:
    // 0x8036343C: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80363440: beq         $at, $zero, L_80363458
    if (ctx->r1 == 0) {
        // 0x80363444: nop
    
            goto L_80363458;
    }
    // 0x80363444: nop

    // 0x80363448: jal         0x80363CC8
    // 0x8036344C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x8036344C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_0:
    // 0x80363450: b           L_8036372C
    // 0x80363454: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8036372C;
    // 0x80363454: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80363458:
    // 0x80363458: jal         0x80362C10
    // 0x8036345C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    func_80362C10_7742C0(rdram, ctx);
        goto after_1;
    // 0x8036345C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_1:
    // 0x80363460: b           L_8036372C
    // 0x80363464: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8036372C;
    // 0x80363464: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80363468:
    // 0x80363468: lbu         $t1, 0x2B0($a2)
    ctx->r9 = MEM_BU(ctx->r6, 0X2B0);
    // 0x8036346C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80363470: beql        $t1, $zero, L_80363494
    if (ctx->r9 == 0) {
        // 0x80363474: lw          $a0, 0x2AC($a2)
        ctx->r4 = MEM_W(ctx->r6, 0X2AC);
            goto L_80363494;
    }
    goto skip_0;
    // 0x80363474: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    skip_0:
    // 0x80363478: lh          $t2, 0x5534($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X5534);
    // 0x8036347C: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x80363480: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x80363484: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x80363488: lw          $t4, -0x2274($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X2274);
    // 0x8036348C: sw          $t4, 0x2AC($a2)
    MEM_W(0X2AC, ctx->r6) = ctx->r12;
    // 0x80363490: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
L_80363494:
    // 0x80363494: lbu         $t5, 0x26C($a0)
    ctx->r13 = MEM_BU(ctx->r4, 0X26C);
    // 0x80363498: beql        $t5, $zero, L_803634B4
    if (ctx->r13 == 0) {
        // 0x8036349C: lh          $t6, 0x4($a0)
        ctx->r14 = MEM_H(ctx->r4, 0X4);
            goto L_803634B4;
    }
    goto skip_1;
    // 0x8036349C: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    skip_1:
    // 0x803634A0: jal         0x80363CC8
    // 0x803634A4: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_2;
    // 0x803634A4: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_2:
    // 0x803634A8: b           L_8036372C
    // 0x803634AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8036372C;
    // 0x803634AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803634B0: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
L_803634B4:
    // 0x803634B4: sh          $t6, 0x278($a2)
    MEM_H(0X278, ctx->r6) = ctx->r14;
    // 0x803634B8: lh          $t7, 0x8($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X8);
    // 0x803634BC: sh          $t7, 0x27A($a2)
    MEM_H(0X27A, ctx->r6) = ctx->r15;
    // 0x803634C0: jal         0x80362BC4
    // 0x803634C4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    can_fly(rdram, ctx);
        goto after_3;
    // 0x803634C4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_3:
    // 0x803634C8: bne         $v0, $zero, L_803634E4
    if (ctx->r2 != 0) {
        // 0x803634CC: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_803634E4;
    }
    // 0x803634CC: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x803634D0: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803634D4: jal         0x80362B60
    // 0x803634D8: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    func_80362B60_774210(rdram, ctx);
        goto after_4;
    // 0x803634D8: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_4:
    // 0x803634DC: beq         $v0, $zero, L_80363728
    if (ctx->r2 == 0) {
        // 0x803634E0: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_80363728;
    }
    // 0x803634E0: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
L_803634E4:
    // 0x803634E4: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803634E8: lh          $t2, 0x2A8($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X2A8);
    // 0x803634EC: lhu         $t9, 0x42($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X42);
    // 0x803634F0: lh          $t8, 0xC($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XC);
    // 0x803634F4: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x803634F8: addu        $t1, $t8, $t0
    ctx->r9 = ADD32(ctx->r24, ctx->r8);
    // 0x803634FC: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x80363500: b           L_80363728
    // 0x80363504: sh          $t3, 0x27C($a2)
    MEM_H(0X27C, ctx->r6) = ctx->r11;
        goto L_80363728;
    // 0x80363504: sh          $t3, 0x27C($a2)
    MEM_H(0X27C, ctx->r6) = ctx->r11;
L_80363508:
    // 0x80363508: lbu         $t4, 0x2B0($a2)
    ctx->r12 = MEM_BU(ctx->r6, 0X2B0);
    // 0x8036350C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80363510: beql        $t4, $zero, L_80363534
    if (ctx->r12 == 0) {
        // 0x80363514: lw          $a0, 0x2AC($a2)
        ctx->r4 = MEM_W(ctx->r6, 0X2AC);
            goto L_80363534;
    }
    goto skip_2;
    // 0x80363514: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    skip_2:
    // 0x80363518: lh          $t5, 0x5534($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5534);
    // 0x8036351C: lui         $t7, 0x801E
    ctx->r15 = S32(0X801E << 16);
    // 0x80363520: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x80363524: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80363528: lw          $t7, -0x2274($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X2274);
    // 0x8036352C: sw          $t7, 0x2AC($a2)
    MEM_W(0X2AC, ctx->r6) = ctx->r15;
    // 0x80363530: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
L_80363534:
    // 0x80363534: lh          $t9, 0x4($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X4);
    // 0x80363538: sh          $t9, 0x278($a2)
    MEM_H(0X278, ctx->r6) = ctx->r25;
    // 0x8036353C: lh          $t8, 0x8($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X8);
    // 0x80363540: b           L_80363728
    // 0x80363544: sh          $t8, 0x27A($a2)
    MEM_H(0X27A, ctx->r6) = ctx->r24;
        goto L_80363728;
    // 0x80363544: sh          $t8, 0x27A($a2)
    MEM_H(0X27A, ctx->r6) = ctx->r24;
L_80363548:
    // 0x80363548: lbu         $t0, 0x2B0($a2)
    ctx->r8 = MEM_BU(ctx->r6, 0X2B0);
    // 0x8036354C: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x80363550: beql        $t0, $zero, L_80363574
    if (ctx->r8 == 0) {
        // 0x80363554: lw          $a0, 0x2AC($a2)
        ctx->r4 = MEM_W(ctx->r6, 0X2AC);
            goto L_80363574;
    }
    goto skip_3;
    // 0x80363554: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    skip_3:
    // 0x80363558: lh          $t1, 0x5534($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5534);
    // 0x8036355C: lui         $t3, 0x801E
    ctx->r11 = S32(0X801E << 16);
    // 0x80363560: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x80363564: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x80363568: lw          $t3, -0x2274($t3)
    ctx->r11 = MEM_W(ctx->r11, -0X2274);
    // 0x8036356C: sw          $t3, 0x2AC($a2)
    MEM_W(0X2AC, ctx->r6) = ctx->r11;
    // 0x80363570: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
L_80363574:
    // 0x80363574: lbu         $t4, 0x26C($a0)
    ctx->r12 = MEM_BU(ctx->r4, 0X26C);
    // 0x80363578: beql        $t4, $zero, L_80363594
    if (ctx->r12 == 0) {
        // 0x8036357C: lh          $t5, 0x4($a0)
        ctx->r13 = MEM_H(ctx->r4, 0X4);
            goto L_80363594;
    }
    goto skip_4;
    // 0x8036357C: lh          $t5, 0x4($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X4);
    skip_4:
    // 0x80363580: jal         0x80363CC8
    // 0x80363584: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_5;
    // 0x80363584: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_5:
    // 0x80363588: b           L_8036372C
    // 0x8036358C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8036372C;
    // 0x8036358C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80363590: lh          $t5, 0x4($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X4);
L_80363594:
    // 0x80363594: sh          $t5, 0x278($a2)
    MEM_H(0X278, ctx->r6) = ctx->r13;
    // 0x80363598: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x8036359C: sh          $t6, 0x27A($a2)
    MEM_H(0X27A, ctx->r6) = ctx->r14;
    // 0x803635A0: jal         0x80362BC4
    // 0x803635A4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    can_fly(rdram, ctx);
        goto after_6;
    // 0x803635A4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_6:
    // 0x803635A8: bne         $v0, $zero, L_803635C4
    if (ctx->r2 != 0) {
        // 0x803635AC: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_803635C4;
    }
    // 0x803635AC: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x803635B0: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803635B4: jal         0x80362B60
    // 0x803635B8: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    func_80362B60_774210(rdram, ctx);
        goto after_7;
    // 0x803635B8: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_7:
    // 0x803635BC: beq         $v0, $zero, L_80363728
    if (ctx->r2 == 0) {
        // 0x803635C0: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_80363728;
    }
    // 0x803635C0: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
L_803635C4:
    // 0x803635C4: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803635C8: lh          $t1, 0x2A8($a2)
    ctx->r9 = MEM_H(ctx->r6, 0X2A8);
    // 0x803635CC: lhu         $t9, 0x42($a0)
    ctx->r25 = MEM_HU(ctx->r4, 0X42);
    // 0x803635D0: lh          $t7, 0xC($a0)
    ctx->r15 = MEM_H(ctx->r4, 0XC);
    // 0x803635D4: sra         $t8, $t9, 1
    ctx->r24 = S32(SIGNED(ctx->r25) >> 1);
    // 0x803635D8: addu        $t0, $t7, $t8
    ctx->r8 = ADD32(ctx->r15, ctx->r24);
    // 0x803635DC: subu        $t2, $t0, $t1
    ctx->r10 = SUB32(ctx->r8, ctx->r9);
    // 0x803635E0: b           L_80363728
    // 0x803635E4: sh          $t2, 0x27C($a2)
    MEM_H(0X27C, ctx->r6) = ctx->r10;
        goto L_80363728;
    // 0x803635E4: sh          $t2, 0x27C($a2)
    MEM_H(0X27C, ctx->r6) = ctx->r10;
L_803635E8:
    // 0x803635E8: lh          $t3, 0x2A4($a2)
    ctx->r11 = MEM_H(ctx->r6, 0X2A4);
    // 0x803635EC: lh          $t4, 0x4($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X4);
    // 0x803635F0: lh          $t5, 0x2A6($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X2A6);
    // 0x803635F4: lh          $t6, 0x8($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X8);
    // 0x803635F8: subu        $v0, $t3, $t4
    ctx->r2 = SUB32(ctx->r11, ctx->r12);
    // 0x803635FC: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x80363600: subu        $v1, $t5, $t6
    ctx->r3 = SUB32(ctx->r13, ctx->r14);
    // 0x80363604: sll         $a1, $v1, 16
    ctx->r5 = S32(ctx->r3 << 16);
    // 0x80363608: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8036360C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80363610: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80363614: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80363618: jal         0x801284B8
    // 0x8036361C: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    func_801284B8(rdram, ctx);
        goto after_8;
    // 0x8036361C: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_8:
    // 0x80363620: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x80363624: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80363628: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x8036362C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x80363630: mflo        $t8
    ctx->r24 = lo;
    // 0x80363634: sll         $t0, $t8, 16
    ctx->r8 = S32(ctx->r24 << 16);
    // 0x80363638: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8036363C: jal         0x803051F0
    // 0x80363640: lh          $a1, 0x2C($a2)
    ctx->r5 = MEM_H(ctx->r6, 0X2C);
    func_803051F0_7168A0(rdram, ctx);
        goto after_9;
    // 0x80363640: lh          $a1, 0x2C($a2)
    ctx->r5 = MEM_H(ctx->r6, 0X2C);
    after_9:
    // 0x80363644: slti        $at, $v0, 0x6
    ctx->r1 = SIGNED(ctx->r2) < 0X6 ? 1 : 0;
    // 0x80363648: beq         $at, $zero, L_80363728
    if (ctx->r1 == 0) {
        // 0x8036364C: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_80363728;
    }
    // 0x8036364C: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x80363650: lb          $t3, 0x2A1($a2)
    ctx->r11 = MEM_B(ctx->r6, 0X2A1);
    // 0x80363654: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80363658: sb          $t2, 0x2A0($a2)
    MEM_B(0X2A0, ctx->r6) = ctx->r10;
    // 0x8036365C: b           L_80363728
    // 0x80363660: sb          $t3, 0x275($a2)
    MEM_B(0X275, ctx->r6) = ctx->r11;
        goto L_80363728;
    // 0x80363660: sb          $t3, 0x275($a2)
    MEM_B(0X275, ctx->r6) = ctx->r11;
L_80363664:
    // 0x80363664: lbu         $t4, 0x2B0($a2)
    ctx->r12 = MEM_BU(ctx->r6, 0X2B0);
    // 0x80363668: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8036366C: beql        $t4, $zero, L_80363690
    if (ctx->r12 == 0) {
        // 0x80363670: lw          $a0, 0x2AC($a2)
        ctx->r4 = MEM_W(ctx->r6, 0X2AC);
            goto L_80363690;
    }
    goto skip_5;
    // 0x80363670: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    skip_5:
    // 0x80363674: lh          $t5, 0x5534($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X5534);
    // 0x80363678: lui         $t9, 0x801E
    ctx->r25 = S32(0X801E << 16);
    // 0x8036367C: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x80363680: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x80363684: lw          $t9, -0x2274($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X2274);
    // 0x80363688: sw          $t9, 0x2AC($a2)
    MEM_W(0X2AC, ctx->r6) = ctx->r25;
    // 0x8036368C: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
L_80363690:
    // 0x80363690: lbu         $t7, 0x26C($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X26C);
    // 0x80363694: beql        $t7, $zero, L_803636B0
    if (ctx->r15 == 0) {
        // 0x80363698: lh          $t8, 0x4($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X4);
            goto L_803636B0;
    }
    goto skip_6;
    // 0x80363698: lh          $t8, 0x4($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X4);
    skip_6:
    // 0x8036369C: jal         0x80363CC8
    // 0x803636A0: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_10;
    // 0x803636A0: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_10:
    // 0x803636A4: b           L_8036372C
    // 0x803636A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8036372C;
    // 0x803636A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803636AC: lh          $t8, 0x4($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X4);
L_803636B0:
    // 0x803636B0: sh          $t8, 0x278($a2)
    MEM_H(0X278, ctx->r6) = ctx->r24;
    // 0x803636B4: lh          $t0, 0x8($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X8);
    // 0x803636B8: sh          $t0, 0x27A($a2)
    MEM_H(0X27A, ctx->r6) = ctx->r8;
    // 0x803636BC: jal         0x80362BC4
    // 0x803636C0: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    can_fly(rdram, ctx);
        goto after_11;
    // 0x803636C0: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_11:
    // 0x803636C4: bne         $v0, $zero, L_803636E0
    if (ctx->r2 != 0) {
        // 0x803636C8: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_803636E0;
    }
    // 0x803636C8: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x803636CC: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803636D0: jal         0x80362B60
    // 0x803636D4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    func_80362B60_774210(rdram, ctx);
        goto after_12;
    // 0x803636D4: sw          $a2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r6;
    after_12:
    // 0x803636D8: beq         $v0, $zero, L_80363700
    if (ctx->r2 == 0) {
        // 0x803636DC: lw          $a2, 0x18($sp)
        ctx->r6 = MEM_W(ctx->r29, 0X18);
            goto L_80363700;
    }
    // 0x803636DC: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
L_803636E0:
    // 0x803636E0: lw          $a0, 0x2AC($a2)
    ctx->r4 = MEM_W(ctx->r6, 0X2AC);
    // 0x803636E4: lh          $t5, 0x2A8($a2)
    ctx->r13 = MEM_H(ctx->r6, 0X2A8);
    // 0x803636E8: lhu         $t2, 0x42($a0)
    ctx->r10 = MEM_HU(ctx->r4, 0X42);
    // 0x803636EC: lh          $t1, 0xC($a0)
    ctx->r9 = MEM_H(ctx->r4, 0XC);
    // 0x803636F0: sra         $t3, $t2, 1
    ctx->r11 = S32(SIGNED(ctx->r10) >> 1);
    // 0x803636F4: addu        $t4, $t1, $t3
    ctx->r12 = ADD32(ctx->r9, ctx->r11);
    // 0x803636F8: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x803636FC: sh          $t6, 0x27C($a2)
    MEM_H(0X27C, ctx->r6) = ctx->r14;
L_80363700:
    // 0x80363700: lbu         $t9, 0x5C($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X5C);
    // 0x80363704: andi        $t7, $t9, 0x5
    ctx->r15 = ctx->r25 & 0X5;
    // 0x80363708: beql        $t7, $zero, L_8036372C
    if (ctx->r15 == 0) {
        // 0x8036370C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8036372C;
    }
    goto skip_7;
    // 0x8036370C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x80363710: lw          $t8, 0x2AC($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X2AC);
    // 0x80363714: lw          $t0, 0x60($a2)
    ctx->r8 = MEM_W(ctx->r6, 0X60);
    // 0x80363718: bnel        $t8, $t0, L_8036372C
    if (ctx->r24 != ctx->r8) {
        // 0x8036371C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8036372C;
    }
    goto skip_8;
    // 0x8036371C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x80363720: jal         0x80363CC8
    // 0x80363724: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    set_nav_state_idle(rdram, ctx);
        goto after_13;
    // 0x80363724: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_13:
L_80363728:
    // 0x80363728: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8036372C:
    // 0x8036372C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80363730: jr          $ra
    // 0x80363734: nop

    return;
    // 0x80363734: nop

;}
RECOMP_FUNC void set_nav_state_engage_other(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363738: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8036373C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80363740: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x80363744: lw          $t6, 0x320($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X320);
    // 0x80363748: addiu       $t7, $zero, 0x9
    ctx->r15 = ADD32(0, 0X9);
    // 0x8036374C: bne         $t6, $zero, L_80363784
    if (ctx->r14 != 0) {
        // 0x80363750: nop
    
            goto L_80363784;
    }
    // 0x80363750: nop

    // 0x80363754: sb          $zero, 0x28E($a0)
    MEM_B(0X28E, ctx->r4) = 0;
    // 0x80363758: sh          $t7, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r15;
    // 0x8036375C: lhu         $v0, 0x22($sp)
    ctx->r2 = MEM_HU(ctx->r29, 0X22);
    // 0x80363760: sw          $a1, 0x294($a0)
    MEM_W(0X294, ctx->r4) = ctx->r5;
    // 0x80363764: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80363768: sll         $a3, $v0, 16
    ctx->r7 = S32(ctx->r2 << 16);
    // 0x8036376C: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80363770: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80363774: jal         0x80363DB4
    // 0x80363778: sh          $v0, 0x298($a0)
    MEM_H(0X298, ctx->r4) = ctx->r2;
    set_nav_state_chase_attack(rdram, ctx);
        goto after_0;
    // 0x80363778: sh          $v0, 0x298($a0)
    MEM_H(0X298, ctx->r4) = ctx->r2;
    after_0:
    // 0x8036377C: b           L_80363790
    // 0x80363780: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80363790;
    // 0x80363780: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80363784:
    // 0x80363784: jal         0x803638E8
    // 0x80363788: nop

    reset_waypoint_mode(rdram, ctx);
        goto after_1;
    // 0x80363788: nop

    after_1:
    // 0x8036378C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80363790:
    // 0x80363790: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80363794: jr          $ra
    // 0x80363798: nop

    return;
    // 0x80363798: nop

;}
RECOMP_FUNC void func_8036379C_774E4C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8036379C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803637A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803637A4: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x803637A8: sh          $t6, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r14;
    // 0x803637AC: sh          $zero, 0x290($a0)
    MEM_H(0X290, ctx->r4) = 0;
    // 0x803637B0: jal         0x8037B784
    // 0x803637B4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    func_8037B784_78CE34(rdram, ctx);
        goto after_0;
    // 0x803637B4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x803637B8: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x803637BC: lw          $t7, 0x320($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X320);
    // 0x803637C0: sw          $t7, 0x2AC($a0)
    MEM_W(0X2AC, ctx->r4) = ctx->r15;
    // 0x803637C4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803637C8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803637CC: jr          $ra
    // 0x803637D0: nop

    return;
    // 0x803637D0: nop

;}
RECOMP_FUNC void set_nav_state_engage_player(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803637D4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803637D8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803637DC: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x803637E0: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    // 0x803637E4: sh          $t7, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r15;
    // 0x803637E8: sh          $a2, 0x298($a0)
    MEM_H(0X298, ctx->r4) = ctx->r6;
    // 0x803637EC: sw          $a1, 0x294($a0)
    MEM_W(0X294, ctx->r4) = ctx->r5;
    // 0x803637F0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803637F4: lh          $t8, 0x5534($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5534);
    // 0x803637F8: lui         $t0, 0x801E
    ctx->r8 = S32(0X801E << 16);
    // 0x803637FC: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x80363800: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x80363804: lw          $t0, -0x2274($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X2274);
    // 0x80363808: xor         $t1, $a1, $t0
    ctx->r9 = ctx->r5 ^ ctx->r8;
    // 0x8036380C: sltiu       $t1, $t1, 0x1
    ctx->r9 = ctx->r9 < 0X1 ? 1 : 0;
    // 0x80363810: sb          $t1, 0x29A($a0)
    MEM_B(0X29A, ctx->r4) = ctx->r9;
    // 0x80363814: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80363818: jal         0x80363CC8
    // 0x8036381C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x8036381C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80363820: jal         0x80309E4C
    // 0x80363824: lw          $a0, 0x1C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X1C);
    func_80309E4C_71B4FC(rdram, ctx);
        goto after_1;
    // 0x80363824: lw          $a0, 0x1C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X1C);
    after_1:
    // 0x80363828: lw          $a3, 0x18($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X18);
    // 0x8036382C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80363830: sb          $t2, 0x270($a3)
    MEM_B(0X270, ctx->r7) = ctx->r10;
    // 0x80363834: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80363838: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8036383C: jr          $ra
    // 0x80363840: nop

    return;
    // 0x80363840: nop

;}
RECOMP_FUNC void func_80363844_774EF4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363844: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80363848: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8036384C: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x80363850: addiu       $t6, $zero, 0x6
    ctx->r14 = ADD32(0, 0X6);
    // 0x80363854: sh          $t6, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r14;
    // 0x80363858: lh          $t7, 0x1E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X1E);
    // 0x8036385C: addiu       $a2, $zero, -0x80
    ctx->r6 = ADD32(0, -0X80);
    // 0x80363860: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    // 0x80363864: sh          $t7, 0x294($a0)
    MEM_H(0X294, ctx->r4) = ctx->r15;
    // 0x80363868: jal         0x80363FB8
    // 0x8036386C: lhu         $a1, 0x1E($sp)
    ctx->r5 = MEM_HU(ctx->r29, 0X1E);
    set_nav_state_scripted(rdram, ctx);
        goto after_0;
    // 0x8036386C: lhu         $a1, 0x1E($sp)
    ctx->r5 = MEM_HU(ctx->r29, 0X1E);
    after_0:
    // 0x80363870: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80363874: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80363878: jr          $ra
    // 0x8036387C: nop

    return;
    // 0x8036387C: nop

;}
RECOMP_FUNC void set_waypoint_follow_target(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363880: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80363884: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80363888: addiu       $t6, $zero, 0x7
    ctx->r14 = ADD32(0, 0X7);
    // 0x8036388C: sh          $t6, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r14;
    // 0x80363890: jal         0x80363E88
    // 0x80363894: sw          $a1, 0x294($a0)
    MEM_W(0X294, ctx->r4) = ctx->r5;
    set_nav_state_follow_target(rdram, ctx);
        goto after_0;
    // 0x80363894: sw          $a1, 0x294($a0)
    MEM_W(0X294, ctx->r4) = ctx->r5;
    after_0:
    // 0x80363898: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8036389C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803638A0: jr          $ra
    // 0x803638A4: nop

    return;
    // 0x803638A4: nop

;}
RECOMP_FUNC void func_803638A8_774F58(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803638A8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803638AC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803638B0: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x803638B4: sll         $a3, $a2, 16
    ctx->r7 = S32(ctx->r6 << 16);
    // 0x803638B8: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803638BC: addiu       $t7, $zero, 0x5
    ctx->r15 = ADD32(0, 0X5);
    // 0x803638C0: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x803638C4: sh          $t7, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r15;
    // 0x803638C8: sw          $a1, 0x294($a0)
    MEM_W(0X294, ctx->r4) = ctx->r5;
    // 0x803638CC: sh          $t6, 0x298($a0)
    MEM_H(0X298, ctx->r4) = ctx->r14;
    // 0x803638D0: jal         0x80363DB4
    // 0x803638D4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    set_nav_state_chase_attack(rdram, ctx);
        goto after_0;
    // 0x803638D4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    after_0:
    // 0x803638D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803638DC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803638E0: jr          $ra
    // 0x803638E4: nop

    return;
    // 0x803638E4: nop

;}
RECOMP_FUNC void reset_waypoint_mode(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803638E8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803638EC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803638F0: sh          $zero, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = 0;
    // 0x803638F4: jal         0x80363CC8
    // 0x803638F8: sw          $zero, 0x2CC($a0)
    MEM_W(0X2CC, ctx->r4) = 0;
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x803638F8: sw          $zero, 0x2CC($a0)
    MEM_W(0X2CC, ctx->r4) = 0;
    after_0:
    // 0x803638FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80363900: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80363904: jr          $ra
    // 0x80363908: nop

    return;
    // 0x80363908: nop

;}
RECOMP_FUNC void func_8036390C_774FBC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8036390C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80363910: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x80363914: lbu         $t6, 0x27($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X27);
    // 0x80363918: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x8036391C: lb          $t8, 0x2F($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X2F);
    // 0x80363920: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x80363924: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80363928: addu        $t0, $t0, $t7
    ctx->r8 = ADD32(ctx->r8, ctx->r15);
    // 0x8036392C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80363930: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x80363934: bgez        $t8, L_80363950
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80363938: lw          $t0, -0x71A0($t0)
        ctx->r8 = MEM_W(ctx->r8, -0X71A0);
            goto L_80363950;
    }
    // 0x80363938: lw          $t0, -0x71A0($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X71A0);
    // 0x8036393C: lbu         $t1, 0x0($t0)
    ctx->r9 = MEM_BU(ctx->r8, 0X0);
    // 0x80363940: addiu       $t1, $t1, -0x2
    ctx->r9 = ADD32(ctx->r9, -0X2);
    // 0x80363944: sll         $t9, $t1, 16
    ctx->r25 = S32(ctx->r9 << 16);
    // 0x80363948: b           L_80363954
    // 0x8036394C: sra         $t1, $t9, 16
    ctx->r9 = S32(SIGNED(ctx->r25) >> 16);
        goto L_80363954;
    // 0x8036394C: sra         $t1, $t9, 16
    ctx->r9 = S32(SIGNED(ctx->r25) >> 16);
L_80363950:
    // 0x80363950: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
L_80363954:
    // 0x80363954: lbu         $t2, 0x37($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X37);
    // 0x80363958: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8036395C: sh          $t4, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r12;
    // 0x80363960: lbu         $t5, 0x27($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X27);
    // 0x80363964: sb          $t1, 0x295($a0)
    MEM_B(0X295, ctx->r4) = ctx->r9;
    // 0x80363968: lb          $t4, 0x296($a0)
    ctx->r12 = MEM_B(ctx->r4, 0X296);
    // 0x8036396C: sb          $t5, 0x294($a0)
    MEM_B(0X294, ctx->r4) = ctx->r13;
    // 0x80363970: lb          $t8, 0x2F($sp)
    ctx->r24 = MEM_B(ctx->r29, 0X2F);
    // 0x80363974: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80363978: sll         $t6, $t1, 2
    ctx->r14 = S32(ctx->r9 << 2);
    // 0x8036397C: sll         $t3, $t8, 4
    ctx->r11 = S32(ctx->r24 << 4);
    // 0x80363980: or          $t4, $t3, $t5
    ctx->r12 = ctx->r11 | ctx->r13;
    // 0x80363984: sb          $t4, 0x296($a0)
    MEM_B(0X296, ctx->r4) = ctx->r12;
    // 0x80363988: lbu         $v1, 0x2B($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X2B);
    // 0x8036398C: andi        $t3, $t4, 0xF0
    ctx->r11 = ctx->r12 & 0XF0;
    // 0x80363990: subu        $t6, $t6, $t1
    ctx->r14 = SUB32(ctx->r14, ctx->r9);
    // 0x80363994: sb          $v1, 0x298($a0)
    MEM_B(0X298, ctx->r4) = ctx->r3;
    // 0x80363998: lbu         $t8, 0x33($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X33);
    // 0x8036399C: sw          $t0, 0x29C($a0)
    MEM_W(0X29C, ctx->r4) = ctx->r8;
    // 0x803639A0: addu        $v0, $t0, $t6
    ctx->r2 = ADD32(ctx->r8, ctx->r14);
    // 0x803639A4: andi        $t9, $t8, 0xF
    ctx->r25 = ctx->r24 & 0XF;
    // 0x803639A8: or          $t5, $t9, $t3
    ctx->r13 = ctx->r25 | ctx->r11;
    // 0x803639AC: sb          $t5, 0x296($a0)
    MEM_B(0X296, ctx->r4) = ctx->r13;
    // 0x803639B0: sb          $t2, 0x297($a0)
    MEM_B(0X297, ctx->r4) = ctx->r10;
    // 0x803639B4: lbu         $a1, 0x1($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X1);
    // 0x803639B8: lbu         $a3, 0x3($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0X3);
    // 0x803639BC: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    // 0x803639C0: sll         $t7, $a1, 6
    ctx->r15 = S32(ctx->r5 << 6);
    // 0x803639C4: addiu       $a1, $t7, 0x20
    ctx->r5 = ADD32(ctx->r15, 0X20);
    // 0x803639C8: sll         $t6, $a3, 6
    ctx->r14 = S32(ctx->r7 << 6);
    // 0x803639CC: sll         $t9, $a2, 6
    ctx->r25 = S32(ctx->r6 << 6);
    // 0x803639D0: addiu       $a2, $t9, 0x20
    ctx->r6 = ADD32(ctx->r25, 0X20);
    // 0x803639D4: addiu       $a3, $t6, 0x20
    ctx->r7 = ADD32(ctx->r14, 0X20);
    // 0x803639D8: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x803639DC: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x803639E0: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803639E4: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803639E8: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x803639EC: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803639F0: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x803639F4: jal         0x80363C48
    // 0x803639F8: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    set_nav_state_goto_point(rdram, ctx);
        goto after_0;
    // 0x803639F8: sw          $v1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r3;
    after_0:
    // 0x803639FC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80363A00: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80363A04: jr          $ra
    // 0x80363A08: nop

    return;
    // 0x80363A08: nop

;}
RECOMP_FUNC void func_80363A0C_7750BC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363A0C: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80363A10: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x80363A14: lbu         $t6, 0x37($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X37);
    // 0x80363A18: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80363A1C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80363A20: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80363A24: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x80363A28: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x80363A2C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80363A30: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x80363A34: addu        $a0, $a0, $t7
    ctx->r4 = ADD32(ctx->r4, ctx->r15);
    // 0x80363A38: lw          $a0, -0x71A0($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X71A0);
    // 0x80363A3C: lh          $a3, 0xC($s0)
    ctx->r7 = MEM_H(ctx->r16, 0XC);
    // 0x80363A40: lh          $a2, 0x8($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X8);
    // 0x80363A44: lh          $a1, 0x4($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X4);
    // 0x80363A48: jal         0x80319B4C
    // 0x80363A4C: sw          $a0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r4;
    get_closest_waypoint_index(rdram, ctx);
        goto after_0;
    // 0x80363A4C: sw          $a0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r4;
    after_0:
    // 0x80363A50: lbu         $t2, 0x47($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X47);
    // 0x80363A54: lw          $t3, 0x2C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X2C);
    // 0x80363A58: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80363A5C: sh          $t8, 0x28C($s0)
    MEM_H(0X28C, ctx->r16) = ctx->r24;
    // 0x80363A60: lbu         $t9, 0x37($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X37);
    // 0x80363A64: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x80363A68: sra         $t4, $t0, 16
    ctx->r12 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80363A6C: sb          $t4, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r12;
    // 0x80363A70: or          $t0, $t4, $zero
    ctx->r8 = ctx->r12 | 0;
    // 0x80363A74: sb          $t9, 0x294($s0)
    MEM_B(0X294, ctx->r16) = ctx->r25;
    // 0x80363A78: lb          $t7, 0x3F($sp)
    ctx->r15 = MEM_B(ctx->r29, 0X3F);
    // 0x80363A7C: lb          $t4, 0x296($s0)
    ctx->r12 = MEM_B(ctx->r16, 0X296);
    // 0x80363A80: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80363A84: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x80363A88: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80363A8C: or          $t6, $t9, $t5
    ctx->r14 = ctx->r25 | ctx->r13;
    // 0x80363A90: sb          $t6, 0x296($s0)
    MEM_B(0X296, ctx->r16) = ctx->r14;
    // 0x80363A94: lbu         $t1, 0x3B($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X3B);
    // 0x80363A98: or          $t9, $t6, $zero
    ctx->r25 = ctx->r14 | 0;
    // 0x80363A9C: andi        $t5, $t9, 0xF0
    ctx->r13 = ctx->r25 & 0XF0;
    // 0x80363AA0: sb          $t1, 0x298($s0)
    MEM_B(0X298, ctx->r16) = ctx->r9;
    // 0x80363AA4: lbu         $t8, 0x43($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X43);
    // 0x80363AA8: sll         $t7, $t0, 2
    ctx->r15 = S32(ctx->r8 << 2);
    // 0x80363AAC: subu        $t7, $t7, $t0
    ctx->r15 = SUB32(ctx->r15, ctx->r8);
    // 0x80363AB0: andi        $t4, $t8, 0xF
    ctx->r12 = ctx->r24 & 0XF;
    // 0x80363AB4: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80363AB8: sb          $t6, 0x296($s0)
    MEM_B(0X296, ctx->r16) = ctx->r14;
    // 0x80363ABC: sb          $t2, 0x297($s0)
    MEM_B(0X297, ctx->r16) = ctx->r10;
    // 0x80363AC0: sw          $t3, 0x29C($s0)
    MEM_W(0X29C, ctx->r16) = ctx->r11;
    // 0x80363AC4: addu        $v1, $t3, $t7
    ctx->r3 = ADD32(ctx->r11, ctx->r15);
    // 0x80363AC8: lbu         $a1, 0x1($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0X1);
    // 0x80363ACC: lbu         $a2, 0x2($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X2);
    // 0x80363AD0: lbu         $a3, 0x3($v1)
    ctx->r7 = MEM_BU(ctx->r3, 0X3);
    // 0x80363AD4: sll         $t8, $a1, 6
    ctx->r24 = S32(ctx->r5 << 6);
    // 0x80363AD8: addiu       $a1, $t8, 0x20
    ctx->r5 = ADD32(ctx->r24, 0X20);
    // 0x80363ADC: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80363AE0: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80363AE4: sll         $t8, $a3, 6
    ctx->r24 = S32(ctx->r7 << 6);
    // 0x80363AE8: addiu       $a3, $t8, 0x20
    ctx->r7 = ADD32(ctx->r24, 0X20);
    // 0x80363AEC: addiu       $a2, $t5, 0x20
    ctx->r6 = ADD32(ctx->r13, 0X20);
    // 0x80363AF0: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80363AF4: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x80363AF8: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x80363AFC: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80363B00: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80363B04: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x80363B08: jal         0x80363C48
    // 0x80363B0C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    set_nav_state_goto_point(rdram, ctx);
        goto after_1;
    // 0x80363B0C: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    after_1:
    // 0x80363B10: lb          $t5, 0x295($s0)
    ctx->r13 = MEM_B(ctx->r16, 0X295);
    // 0x80363B14: lb          $t6, 0x3F($sp)
    ctx->r14 = MEM_B(ctx->r29, 0X3F);
    // 0x80363B18: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x80363B1C: sb          $t7, 0x295($s0)
    MEM_B(0X295, ctx->r16) = ctx->r15;
    // 0x80363B20: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80363B24: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x80363B28: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80363B2C: jr          $ra
    // 0x80363B30: nop

    return;
    // 0x80363B30: nop

;}
RECOMP_FUNC void func_80363B34_7751E4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363B34: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80363B38: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80363B3C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x80363B40: addiu       $t6, $zero, 0x3
    ctx->r14 = ADD32(0, 0X3);
    // 0x80363B44: sh          $t6, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r14;
    // 0x80363B48: lhu         $t7, 0x26($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X26);
    // 0x80363B4C: lh          $a2, 0x8($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X8);
    // 0x80363B50: lh          $a1, 0x4($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X4);
    // 0x80363B54: sb          $t7, 0x294($a0)
    MEM_B(0X294, ctx->r4) = ctx->r15;
    // 0x80363B58: addiu       $t8, $zero, 0xA
    ctx->r24 = ADD32(0, 0XA);
    // 0x80363B5C: addiu       $t9, $zero, 0x20
    ctx->r25 = ADD32(0, 0X20);
    // 0x80363B60: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80363B64: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80363B68: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80363B6C: jal         0x80363C48
    // 0x80363B70: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    set_nav_state_goto_point(rdram, ctx);
        goto after_0;
    // 0x80363B70: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_0:
    // 0x80363B74: jal         0x8012826C
    // 0x80363B78: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x80363B78: nop

    after_1:
    // 0x80363B7C: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x80363B80: andi        $t0, $v0, 0x3
    ctx->r8 = ctx->r2 & 0X3;
    // 0x80363B84: sh          $t0, 0x290($a0)
    MEM_H(0X290, ctx->r4) = ctx->r8;
    // 0x80363B88: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80363B8C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80363B90: jr          $ra
    // 0x80363B94: nop

    return;
    // 0x80363B94: nop

;}
RECOMP_FUNC void func_80363B98_775248(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363B98: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80363B9C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x80363BA0: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x80363BA4: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x80363BA8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80363BAC: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80363BB0: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x80363BB4: sll         $t0, $a3, 16
    ctx->r8 = S32(ctx->r7 << 16);
    // 0x80363BB8: sra         $a3, $t0, 16
    ctx->r7 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80363BBC: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80363BC0: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80363BC4: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x80363BC8: sh          $t2, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r10;
    // 0x80363BCC: sh          $a1, 0x296($a0)
    MEM_H(0X296, ctx->r4) = ctx->r5;
    // 0x80363BD0: sh          $a2, 0x298($a0)
    MEM_H(0X298, ctx->r4) = ctx->r6;
    // 0x80363BD4: sh          $a3, 0x29A($a0)
    MEM_H(0X29A, ctx->r4) = ctx->r7;
    // 0x80363BD8: lb          $t3, 0x33($sp)
    ctx->r11 = MEM_B(ctx->r29, 0X33);
    // 0x80363BDC: sb          $t3, 0x294($a0)
    MEM_B(0X294, ctx->r4) = ctx->r11;
    // 0x80363BE0: lbu         $t4, 0x37($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X37);
    // 0x80363BE4: sb          $t4, 0x295($a0)
    MEM_B(0X295, ctx->r4) = ctx->r12;
    // 0x80363BE8: lbu         $t6, 0x37($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X37);
    // 0x80363BEC: lb          $t5, 0x33($sp)
    ctx->r13 = MEM_B(ctx->r29, 0X33);
    // 0x80363BF0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80363BF4: jal         0x80363C48
    // 0x80363BF8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    set_nav_state_goto_point(rdram, ctx);
        goto after_0;
    // 0x80363BF8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_0:
    // 0x80363BFC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80363C00: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80363C04: jr          $ra
    // 0x80363C08: nop

    return;
    // 0x80363C08: nop

;}
RECOMP_FUNC void func_80363C0C_7752BC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363C0C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80363C10: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80363C14: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x80363C18: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x80363C1C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80363C20: addiu       $t9, $zero, 0x1E
    ctx->r25 = ADD32(0, 0X1E);
    // 0x80363C24: sh          $t7, 0x28C($a0)
    MEM_H(0X28C, ctx->r4) = ctx->r15;
    // 0x80363C28: sb          $t8, 0x28E($a0)
    MEM_B(0X28E, ctx->r4) = ctx->r24;
    // 0x80363C2C: sh          $t9, 0x290($a0)
    MEM_H(0X290, ctx->r4) = ctx->r25;
    // 0x80363C30: jal         0x80363CC8
    // 0x80363C34: sb          $a1, 0x294($a0)
    MEM_B(0X294, ctx->r4) = ctx->r5;
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x80363C34: sb          $a1, 0x294($a0)
    MEM_B(0X294, ctx->r4) = ctx->r5;
    after_0:
    // 0x80363C38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80363C3C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80363C40: jr          $ra
    // 0x80363C44: nop

    return;
    // 0x80363C44: nop

;}
RECOMP_FUNC void set_nav_state_goto_point(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80363C48: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80363C4C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80363C50: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80363C54: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80363C58: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x80363C5C: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80363C60: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80363C64: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80363C68: sb          $t2, 0x2A0($a0)
    MEM_B(0X2A0, ctx->r4) = ctx->r10;
    // 0x80363C6C: sh          $a1, 0x2A4($a0)
    MEM_H(0X2A4, ctx->r4) = ctx->r5;
    // 0x80363C70: sh          $a2, 0x2A6($a0)
    MEM_H(0X2A6, ctx->r4) = ctx->r6;
    // 0x80363C74: sh          $a3, 0x2A8($a0)
    MEM_H(0X2A8, ctx->r4) = ctx->r7;
    // 0x80363C78: lb          $t3, 0x13($sp)
    ctx->r11 = MEM_B(ctx->r29, 0X13);
    // 0x80363C7C: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x80363C80: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
    // 0x80363C84: sb          $t3, 0x2A1($a0)
    MEM_B(0X2A1, ctx->r4) = ctx->r11;
    // 0x80363C88: lbu         $t4, 0x17($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0X17);
    // 0x80363C8C: sw          $zero, 0x2AC($a0)
    MEM_W(0X2AC, ctx->r4) = 0;
    // 0x80363C90: sb          $t5, 0x274($a0)
    MEM_B(0X274, ctx->r4) = ctx->r13;
    // 0x80363C94: sb          $t4, 0x2A2($a0)
    MEM_B(0X2A2, ctx->r4) = ctx->r12;
    // 0x80363C98: lb          $t6, 0x13($sp)
    ctx->r14 = MEM_B(ctx->r29, 0X13);
    // 0x80363C9C: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x80363CA0: subu        $t8, $t7, $a1
    ctx->r24 = SUB32(ctx->r15, ctx->r5);
    // 0x80363CA4: sh          $a1, 0x278($a0)
    MEM_H(0X278, ctx->r4) = ctx->r5;
    // 0x80363CA8: subu        $t0, $t9, $a2
    ctx->r8 = SUB32(ctx->r25, ctx->r6);
    // 0x80363CAC: sh          $a2, 0x27A($a0)
    MEM_H(0X27A, ctx->r4) = ctx->r6;
    // 0x80363CB0: sh          $a3, 0x27C($a0)
    MEM_H(0X27C, ctx->r4) = ctx->r7;
    // 0x80363CB4: sw          $t8, 0x2D4($a0)
    MEM_W(0X2D4, ctx->r4) = ctx->r24;
    // 0x80363CB8: sw          $t0, 0x2D8($a0)
    MEM_W(0X2D8, ctx->r4) = ctx->r8;
    // 0x80363CBC: sh          $zero, 0x2DC($a0)
    MEM_H(0X2DC, ctx->r4) = 0;
    // 0x80363CC0: jr          $ra
    // 0x80363CC4: sb          $t6, 0x275($a0)
    MEM_B(0X275, ctx->r4) = ctx->r14;
    return;
    // 0x80363CC4: sb          $t6, 0x275($a0)
    MEM_B(0X275, ctx->r4) = ctx->r14;
;}
