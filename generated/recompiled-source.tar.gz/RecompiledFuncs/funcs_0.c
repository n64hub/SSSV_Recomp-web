#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void recomp_entrypoint(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80125900: lui         $t0, 0x8016
    ctx->r8 = S32(0X8016 << 16);
    // 0x80125904: lui         $t1, 0x13
    ctx->r9 = S32(0X13 << 16);
    // 0x80125908: addiu       $t0, $t0, -0x1E30
    ctx->r8 = ADD32(ctx->r8, -0X1E30);
    // 0x8012590C: ori         $t1, $t1, 0x6C80
    ctx->r9 = ctx->r9 | 0X6C80;
L_80125910:
    // 0x80125910: addi        $t1, $t1, -0x8
    ctx->r9 = ADD32(ctx->r9, -0X8);
    // 0x80125914: sw          $zero, 0x0($t0)
    MEM_W(0X0, ctx->r8) = 0;
    // 0x80125918: sw          $zero, 0x4($t0)
    MEM_W(0X4, ctx->r8) = 0;
    // 0x8012591C: bne         $t1, $zero, L_80125910
    if (ctx->r9 != 0) {
        // 0x80125920: addi        $t0, $t0, 0x8
        ctx->r8 = ADD32(ctx->r8, 0X8);
            goto L_80125910;
    }
    // 0x80125920: addi        $t0, $t0, 0x8
    ctx->r8 = ADD32(ctx->r8, 0X8);
    // 0x80125924: lui         $t2, 0x8012
    ctx->r10 = S32(0X8012 << 16);
    // 0x80125928: lui         $sp, 0x8016
    ctx->r29 = S32(0X8016 << 16);
    // 0x8012592C: addiu       $t2, $t2, 0x5950
    ctx->r10 = ADD32(ctx->r10, 0X5950);
    // 0x80125930: jr          $t2
    // 0x80125934: addiu       $sp, $sp, 0x3D0
    ctx->r29 = ADD32(ctx->r29, 0X3D0);
    LOOKUP_FUNC(ctx->r10)(rdram, ctx);
    return;
    // 0x80125934: addiu       $sp, $sp, 0x3D0
    ctx->r29 = ADD32(ctx->r29, 0X3D0);
    // 0x80125938: nop

    // 0x8012593C: nop

    // 0x80125940: nop

    // 0x80125944: nop

    // 0x80125948: nop

    // 0x8012594C: nop

;}
RECOMP_FUNC void func_80125950(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80125950: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80125954: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80125958: jal         0x801378C0
    // 0x8012595C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    osInitialize_recomp(rdram, ctx);
        goto after_0;
    // 0x8012595C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x80125960: jal         0x80129AD0
    // 0x80125964: nop

    clear_framebuffer(rdram, ctx);
        goto after_1;
    // 0x80125964: nop

    after_1:
    // 0x80125968: jal         0x801355B0
    // 0x8012596C: nop

    init2(rdram, ctx);
        goto after_2;
    // 0x8012596C: nop

    after_2:
    // 0x80125970: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80125974: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80125978: jr          $ra
    // 0x8012597C: nop

    return;
    // 0x8012597C: nop

;}
RECOMP_FUNC void build_rotate_scale_translate_matrix(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80125980: addiu       $sp, $sp, -0xC8
    ctx->r29 = ADD32(ctx->r29, -0XC8);
    // 0x80125984: lh          $t6, 0xDA($sp)
    ctx->r14 = MEM_H(ctx->r29, 0XDA);
    // 0x80125988: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8012598C: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x80125990: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80125994: sw          $a1, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r5;
    // 0x80125998: addu        $t0, $t7, $t8
    ctx->r8 = ADD32(ctx->r15, ctx->r24);
    // 0x8012599C: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x801259A0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801259A4: sw          $a0, 0xC8($sp)
    MEM_W(0XC8, ctx->r29) = ctx->r4;
    // 0x801259A8: sw          $a2, 0xD0($sp)
    MEM_W(0XD0, ctx->r29) = ctx->r6;
    // 0x801259AC: sw          $a3, 0xD4($sp)
    MEM_W(0XD4, ctx->r29) = ctx->r7;
    // 0x801259B0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x801259B4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801259B8: sw          $t0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r8;
    // 0x801259BC: jal         0x80137BF4
    // 0x801259C0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_0;
    // 0x801259C0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_0:
    // 0x801259C4: lw          $t0, 0x34($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X34);
    // 0x801259C8: sw          $v0, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r2;
    // 0x801259CC: sw          $v1, 0xC4($sp)
    MEM_W(0XC4, ctx->r29) = ctx->r3;
    // 0x801259D0: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x801259D4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801259D8: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x801259DC: jal         0x80137BF4
    // 0x801259E0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_1;
    // 0x801259E0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_1:
    // 0x801259E4: lh          $t2, 0xDE($sp)
    ctx->r10 = MEM_H(ctx->r29, 0XDE);
    // 0x801259E8: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x801259EC: addiu       $t4, $t4, 0x2350
    ctx->r12 = ADD32(ctx->r12, 0X2350);
    // 0x801259F0: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x801259F4: addu        $t0, $t3, $t4
    ctx->r8 = ADD32(ctx->r11, ctx->r12);
    // 0x801259F8: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x801259FC: sw          $v0, 0xB8($sp)
    MEM_W(0XB8, ctx->r29) = ctx->r2;
    // 0x80125A00: sw          $v1, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r3;
    // 0x80125A04: sw          $t0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r8;
    // 0x80125A08: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125A0C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80125A10: jal         0x80137BF4
    // 0x80125A14: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_2;
    // 0x80125A14: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_2:
    // 0x80125A18: lw          $t0, 0x34($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X34);
    // 0x80125A1C: sw          $v0, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r2;
    // 0x80125A20: sw          $v1, 0xB4($sp)
    MEM_W(0XB4, ctx->r29) = ctx->r3;
    // 0x80125A24: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x80125A28: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125A2C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80125A30: jal         0x80137BF4
    // 0x80125A34: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_3;
    // 0x80125A34: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_3:
    // 0x80125A38: lh          $t7, 0xE2($sp)
    ctx->r15 = MEM_H(ctx->r29, 0XE2);
    // 0x80125A3C: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x80125A40: addiu       $t9, $t9, 0x2350
    ctx->r25 = ADD32(ctx->r25, 0X2350);
    // 0x80125A44: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80125A48: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x80125A4C: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x80125A50: sw          $v0, 0xA8($sp)
    MEM_W(0XA8, ctx->r29) = ctx->r2;
    // 0x80125A54: sw          $v1, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r3;
    // 0x80125A58: sw          $t0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r8;
    // 0x80125A5C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125A60: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80125A64: jal         0x80137BF4
    // 0x80125A68: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_4;
    // 0x80125A68: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_4:
    // 0x80125A6C: lw          $t0, 0x34($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X34);
    // 0x80125A70: sw          $v0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r2;
    // 0x80125A74: sw          $v1, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r3;
    // 0x80125A78: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x80125A7C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125A80: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80125A84: jal         0x80137BF4
    // 0x80125A88: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_5;
    // 0x80125A88: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_5:
    // 0x80125A8C: sw          $v0, 0x98($sp)
    MEM_W(0X98, ctx->r29) = ctx->r2;
    // 0x80125A90: sw          $v1, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r3;
    // 0x80125A94: lw          $a0, 0xB8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB8);
    // 0x80125A98: lw          $a1, 0xBC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XBC);
    // 0x80125A9C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125AA0: jal         0x80137CB8
    // 0x80125AA4: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_6;
    // 0x80125AA4: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_6:
    // 0x80125AA8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125AAC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125AB0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125AB4: jal         0x80137C5C
    // 0x80125AB8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_7;
    // 0x80125AB8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_7:
    // 0x80125ABC: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x80125AC0: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x80125AC4: lw          $a0, 0xB0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB0);
    // 0x80125AC8: lw          $a1, 0xB4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XB4);
    // 0x80125ACC: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80125AD0: jal         0x80137CB8
    // 0x80125AD4: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    __ll_mul_recomp(rdram, ctx);
        goto after_8;
    // 0x80125AD4: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    after_8:
    // 0x80125AD8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125ADC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125AE0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125AE4: jal         0x80137C5C
    // 0x80125AE8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_9;
    // 0x80125AE8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_9:
    // 0x80125AEC: lw          $a0, 0xC0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC0);
    // 0x80125AF0: lw          $a1, 0xC4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XC4);
    // 0x80125AF4: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125AF8: jal         0x80137CB8
    // 0x80125AFC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_10;
    // 0x80125AFC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_10:
    // 0x80125B00: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125B04: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125B08: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125B0C: jal         0x80137C5C
    // 0x80125B10: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_11;
    // 0x80125B10: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_11:
    // 0x80125B14: lw          $a1, 0xE4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XE4);
    // 0x80125B18: lw          $t6, 0x40($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X40);
    // 0x80125B1C: lw          $t7, 0x44($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X44);
    // 0x80125B20: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80125B24: subu        $a2, $t6, $v0
    ctx->r6 = SUB32(ctx->r14, ctx->r2);
    // 0x80125B28: sltu        $at, $t7, $v1
    ctx->r1 = ctx->r15 < ctx->r3 ? 1 : 0;
    // 0x80125B2C: subu        $a2, $a2, $at
    ctx->r6 = SUB32(ctx->r6, ctx->r1);
    // 0x80125B30: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x80125B34: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x80125B38: jal         0x80137CB8
    // 0x80125B3C: subu        $a3, $t7, $v1
    ctx->r7 = SUB32(ctx->r15, ctx->r3);
    __ll_mul_recomp(rdram, ctx);
        goto after_12;
    // 0x80125B3C: subu        $a3, $t7, $v1
    ctx->r7 = SUB32(ctx->r15, ctx->r3);
    after_12:
    // 0x80125B40: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125B44: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125B48: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125B4C: jal         0x80137C5C
    // 0x80125B50: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_13;
    // 0x80125B50: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_13:
    // 0x80125B54: sw          $v0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r2;
    // 0x80125B58: sw          $v1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r3;
    // 0x80125B5C: lw          $a0, 0xC0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC0);
    // 0x80125B60: lw          $a1, 0xC4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XC4);
    // 0x80125B64: lw          $a2, 0xA8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA8);
    // 0x80125B68: jal         0x80137CB8
    // 0x80125B6C: lw          $a3, 0xAC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XAC);
    __ll_mul_recomp(rdram, ctx);
        goto after_14;
    // 0x80125B6C: lw          $a3, 0xAC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XAC);
    after_14:
    // 0x80125B70: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125B74: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125B78: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125B7C: jal         0x80137C5C
    // 0x80125B80: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_15;
    // 0x80125B80: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_15:
    // 0x80125B84: lw          $a1, 0xE8($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XE8);
    // 0x80125B88: sltiu       $at, $v1, 0x1
    ctx->r1 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x80125B8C: nor         $a2, $v0, $zero
    ctx->r6 = ~(ctx->r2 | 0);
    // 0x80125B90: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80125B94: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80125B98: addu        $a2, $a2, $at
    ctx->r6 = ADD32(ctx->r6, ctx->r1);
    // 0x80125B9C: negu        $a3, $v1
    ctx->r7 = SUB32(0, ctx->r3);
    // 0x80125BA0: jal         0x80137CB8
    // 0x80125BA4: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    __ll_mul_recomp(rdram, ctx);
        goto after_16;
    // 0x80125BA4: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    after_16:
    // 0x80125BA8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125BAC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125BB0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125BB4: jal         0x80137C5C
    // 0x80125BB8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_17;
    // 0x80125BB8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_17:
    // 0x80125BBC: lw          $a0, 0x74($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X74);
    // 0x80125BC0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125BC4: jal         0x8012635C
    // 0x80125BC8: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    func_8012635C(rdram, ctx);
        goto after_18;
    // 0x80125BC8: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    after_18:
    // 0x80125BCC: lw          $a0, 0xB8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB8);
    // 0x80125BD0: lw          $a1, 0xBC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XBC);
    // 0x80125BD4: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80125BD8: jal         0x80137CB8
    // 0x80125BDC: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    __ll_mul_recomp(rdram, ctx);
        goto after_19;
    // 0x80125BDC: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    after_19:
    // 0x80125BE0: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125BE4: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125BE8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125BEC: jal         0x80137C5C
    // 0x80125BF0: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_20;
    // 0x80125BF0: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_20:
    // 0x80125BF4: sw          $v0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r2;
    // 0x80125BF8: sw          $v1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r3;
    // 0x80125BFC: lw          $a0, 0xB0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB0);
    // 0x80125C00: lw          $a1, 0xB4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XB4);
    // 0x80125C04: lw          $a2, 0x98($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X98);
    // 0x80125C08: jal         0x80137CB8
    // 0x80125C0C: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    __ll_mul_recomp(rdram, ctx);
        goto after_21;
    // 0x80125C0C: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    after_21:
    // 0x80125C10: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125C14: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125C18: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125C1C: jal         0x80137C5C
    // 0x80125C20: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_22;
    // 0x80125C20: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_22:
    // 0x80125C24: lw          $a0, 0xC0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC0);
    // 0x80125C28: lw          $a1, 0xC4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XC4);
    // 0x80125C2C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125C30: jal         0x80137CB8
    // 0x80125C34: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_23;
    // 0x80125C34: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_23:
    // 0x80125C38: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125C3C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125C40: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125C44: jal         0x80137C5C
    // 0x80125C48: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_24;
    // 0x80125C48: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_24:
    // 0x80125C4C: lw          $t8, 0x60($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X60);
    // 0x80125C50: lw          $t9, 0x64($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X64);
    // 0x80125C54: lw          $a1, 0xEC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XEC);
    // 0x80125C58: nor         $t2, $t8, $zero
    ctx->r10 = ~(ctx->r24 | 0);
    // 0x80125C5C: sltiu       $at, $t9, 0x1
    ctx->r1 = ctx->r25 < 0X1 ? 1 : 0;
    // 0x80125C60: addu        $t2, $t2, $at
    ctx->r10 = ADD32(ctx->r10, ctx->r1);
    // 0x80125C64: negu        $t3, $t9
    ctx->r11 = SUB32(0, ctx->r25);
    // 0x80125C68: sltu        $at, $t3, $v1
    ctx->r1 = ctx->r11 < ctx->r3 ? 1 : 0;
    // 0x80125C6C: subu        $a2, $t2, $v0
    ctx->r6 = SUB32(ctx->r10, ctx->r2);
    // 0x80125C70: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80125C74: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80125C78: subu        $a2, $a2, $at
    ctx->r6 = SUB32(ctx->r6, ctx->r1);
    // 0x80125C7C: subu        $a3, $t3, $v1
    ctx->r7 = SUB32(ctx->r11, ctx->r3);
    // 0x80125C80: jal         0x80137CB8
    // 0x80125C84: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    __ll_mul_recomp(rdram, ctx);
        goto after_25;
    // 0x80125C84: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_25:
    // 0x80125C88: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125C8C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125C90: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125C94: jal         0x80137C5C
    // 0x80125C98: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_26;
    // 0x80125C98: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_26:
    // 0x80125C9C: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125CA0: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80125CA4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80125CA8: jal         0x8012635C
    // 0x80125CAC: addiu       $a2, $a2, 0x4
    ctx->r6 = ADD32(ctx->r6, 0X4);
    func_8012635C(rdram, ctx);
        goto after_27;
    // 0x80125CAC: addiu       $a2, $a2, 0x4
    ctx->r6 = ADD32(ctx->r6, 0X4);
    after_27:
    // 0x80125CB0: lw          $a0, 0xC0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC0);
    // 0x80125CB4: lw          $a1, 0xC4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XC4);
    // 0x80125CB8: lw          $a2, 0x98($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X98);
    // 0x80125CBC: jal         0x80137CB8
    // 0x80125CC0: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    __ll_mul_recomp(rdram, ctx);
        goto after_28;
    // 0x80125CC0: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    after_28:
    // 0x80125CC4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125CC8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125CCC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125CD0: jal         0x80137C5C
    // 0x80125CD4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_29;
    // 0x80125CD4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_29:
    // 0x80125CD8: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x80125CDC: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x80125CE0: lw          $a0, 0xB0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB0);
    // 0x80125CE4: lw          $a1, 0xB4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XB4);
    // 0x80125CE8: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80125CEC: jal         0x80137CB8
    // 0x80125CF0: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    __ll_mul_recomp(rdram, ctx);
        goto after_30;
    // 0x80125CF0: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    after_30:
    // 0x80125CF4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125CF8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125CFC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125D00: jal         0x80137C5C
    // 0x80125D04: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_31;
    // 0x80125D04: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_31:
    // 0x80125D08: lw          $a0, 0xB8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB8);
    // 0x80125D0C: lw          $a1, 0xBC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XBC);
    // 0x80125D10: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125D14: jal         0x80137CB8
    // 0x80125D18: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_32;
    // 0x80125D18: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_32:
    // 0x80125D1C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125D20: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125D24: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125D28: jal         0x80137C5C
    // 0x80125D2C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_33;
    // 0x80125D2C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_33:
    // 0x80125D30: lw          $t5, 0x44($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X44);
    // 0x80125D34: lw          $t4, 0x40($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X40);
    // 0x80125D38: lw          $a0, 0x28($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X28);
    // 0x80125D3C: addu        $a3, $v1, $t5
    ctx->r7 = ADD32(ctx->r3, ctx->r13);
    // 0x80125D40: sltu        $at, $a3, $t5
    ctx->r1 = ctx->r7 < ctx->r13 ? 1 : 0;
    // 0x80125D44: addu        $a2, $at, $v0
    ctx->r6 = ADD32(ctx->r1, ctx->r2);
    // 0x80125D48: lw          $a1, 0x2C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X2C);
    // 0x80125D4C: jal         0x80137CB8
    // 0x80125D50: addu        $a2, $a2, $t4
    ctx->r6 = ADD32(ctx->r6, ctx->r12);
    __ll_mul_recomp(rdram, ctx);
        goto after_34;
    // 0x80125D50: addu        $a2, $a2, $t4
    ctx->r6 = ADD32(ctx->r6, ctx->r12);
    after_34:
    // 0x80125D54: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125D58: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125D5C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125D60: jal         0x80137C5C
    // 0x80125D64: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_35;
    // 0x80125D64: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_35:
    // 0x80125D68: sw          $v0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r2;
    // 0x80125D6C: sw          $v1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r3;
    // 0x80125D70: lw          $a0, 0xB8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB8);
    // 0x80125D74: lw          $a1, 0xBC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XBC);
    // 0x80125D78: lw          $a2, 0xA8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA8);
    // 0x80125D7C: jal         0x80137CB8
    // 0x80125D80: lw          $a3, 0xAC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XAC);
    __ll_mul_recomp(rdram, ctx);
        goto after_36;
    // 0x80125D80: lw          $a3, 0xAC($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XAC);
    after_36:
    // 0x80125D84: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125D88: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125D8C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125D90: jal         0x80137C5C
    // 0x80125D94: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_37;
    // 0x80125D94: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_37:
    // 0x80125D98: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x80125D9C: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x80125DA0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125DA4: jal         0x80137CB8
    // 0x80125DA8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_38;
    // 0x80125DA8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_38:
    // 0x80125DAC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125DB0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125DB4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125DB8: jal         0x80137C5C
    // 0x80125DBC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_39;
    // 0x80125DBC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_39:
    // 0x80125DC0: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125DC4: lw          $a0, 0x74($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X74);
    // 0x80125DC8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125DCC: jal         0x8012635C
    // 0x80125DD0: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    func_8012635C(rdram, ctx);
        goto after_40;
    // 0x80125DD0: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    after_40:
    // 0x80125DD4: lw          $a0, 0xC0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XC0);
    // 0x80125DD8: lw          $a1, 0xC4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XC4);
    // 0x80125DDC: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80125DE0: jal         0x80137CB8
    // 0x80125DE4: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    __ll_mul_recomp(rdram, ctx);
        goto after_41;
    // 0x80125DE4: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    after_41:
    // 0x80125DE8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125DEC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125DF0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125DF4: jal         0x80137C5C
    // 0x80125DF8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_42;
    // 0x80125DF8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_42:
    // 0x80125DFC: sw          $v0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r2;
    // 0x80125E00: sw          $v1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r3;
    // 0x80125E04: lw          $a0, 0xB0($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB0);
    // 0x80125E08: lw          $a1, 0xB4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XB4);
    // 0x80125E0C: lw          $a2, 0x98($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X98);
    // 0x80125E10: jal         0x80137CB8
    // 0x80125E14: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    __ll_mul_recomp(rdram, ctx);
        goto after_43;
    // 0x80125E14: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    after_43:
    // 0x80125E18: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125E1C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125E20: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125E24: jal         0x80137C5C
    // 0x80125E28: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_44;
    // 0x80125E28: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_44:
    // 0x80125E2C: lw          $a0, 0xB8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XB8);
    // 0x80125E30: lw          $a1, 0xBC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XBC);
    // 0x80125E34: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125E38: jal         0x80137CB8
    // 0x80125E3C: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_45;
    // 0x80125E3C: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_45:
    // 0x80125E40: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125E44: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125E48: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125E4C: jal         0x80137C5C
    // 0x80125E50: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_46;
    // 0x80125E50: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_46:
    // 0x80125E54: lw          $t8, 0x60($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X60);
    // 0x80125E58: lw          $t9, 0x64($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X64);
    // 0x80125E5C: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x80125E60: subu        $a2, $v0, $t8
    ctx->r6 = SUB32(ctx->r2, ctx->r24);
    // 0x80125E64: sltu        $at, $v1, $t9
    ctx->r1 = ctx->r3 < ctx->r25 ? 1 : 0;
    // 0x80125E68: subu        $a2, $a2, $at
    ctx->r6 = SUB32(ctx->r6, ctx->r1);
    // 0x80125E6C: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80125E70: jal         0x80137CB8
    // 0x80125E74: subu        $a3, $v1, $t9
    ctx->r7 = SUB32(ctx->r3, ctx->r25);
    __ll_mul_recomp(rdram, ctx);
        goto after_47;
    // 0x80125E74: subu        $a3, $v1, $t9
    ctx->r7 = SUB32(ctx->r3, ctx->r25);
    after_47:
    // 0x80125E78: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125E7C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125E80: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125E84: jal         0x80137C5C
    // 0x80125E88: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_48;
    // 0x80125E88: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_48:
    // 0x80125E8C: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125E90: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80125E94: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80125E98: jal         0x8012635C
    // 0x80125E9C: addiu       $a2, $a2, 0xC
    ctx->r6 = ADD32(ctx->r6, 0XC);
    func_8012635C(rdram, ctx);
        goto after_49;
    // 0x80125E9C: addiu       $a2, $a2, 0xC
    ctx->r6 = ADD32(ctx->r6, 0XC);
    after_49:
    // 0x80125EA0: lw          $a0, 0xA8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XA8);
    // 0x80125EA4: lw          $a1, 0xAC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XAC);
    // 0x80125EA8: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80125EAC: jal         0x80137CB8
    // 0x80125EB0: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    __ll_mul_recomp(rdram, ctx);
        goto after_50;
    // 0x80125EB0: lw          $a3, 0xA4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XA4);
    after_50:
    // 0x80125EB4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125EB8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125EBC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125EC0: jal         0x80137C5C
    // 0x80125EC4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_51;
    // 0x80125EC4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_51:
    // 0x80125EC8: lw          $a0, 0x28($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X28);
    // 0x80125ECC: lw          $a1, 0x2C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X2C);
    // 0x80125ED0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125ED4: jal         0x80137CB8
    // 0x80125ED8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_52;
    // 0x80125ED8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_52:
    // 0x80125EDC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125EE0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125EE4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125EE8: jal         0x80137C5C
    // 0x80125EEC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_53;
    // 0x80125EEC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_53:
    // 0x80125EF0: lw          $a2, 0xB0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XB0);
    // 0x80125EF4: lw          $a3, 0xB4($sp)
    ctx->r7 = MEM_W(ctx->r29, 0XB4);
    // 0x80125EF8: sw          $v0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r2;
    // 0x80125EFC: nor         $a2, $a2, $zero
    ctx->r6 = ~(ctx->r6 | 0);
    // 0x80125F00: sltiu       $at, $a3, 0x1
    ctx->r1 = ctx->r7 < 0X1 ? 1 : 0;
    // 0x80125F04: addu        $a2, $a2, $at
    ctx->r6 = ADD32(ctx->r6, ctx->r1);
    // 0x80125F08: sw          $v1, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r3;
    // 0x80125F0C: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x80125F10: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x80125F14: jal         0x80137CB8
    // 0x80125F18: negu        $a3, $a3
    ctx->r7 = SUB32(0, ctx->r7);
    __ll_mul_recomp(rdram, ctx);
        goto after_54;
    // 0x80125F18: negu        $a3, $a3
    ctx->r7 = SUB32(0, ctx->r7);
    after_54:
    // 0x80125F1C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125F20: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125F24: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125F28: jal         0x80137C5C
    // 0x80125F2C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_55;
    // 0x80125F2C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_55:
    // 0x80125F30: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125F34: lw          $a0, 0x84($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X84);
    // 0x80125F38: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125F3C: jal         0x8012635C
    // 0x80125F40: addiu       $a2, $a2, 0x10
    ctx->r6 = ADD32(ctx->r6, 0X10);
    func_8012635C(rdram, ctx);
        goto after_56;
    // 0x80125F40: addiu       $a2, $a2, 0x10
    ctx->r6 = ADD32(ctx->r6, 0X10);
    after_56:
    // 0x80125F44: lw          $a0, 0xA8($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XA8);
    // 0x80125F48: lw          $a1, 0xAC($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XAC);
    // 0x80125F4C: lw          $a2, 0x98($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X98);
    // 0x80125F50: jal         0x80137CB8
    // 0x80125F54: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    __ll_mul_recomp(rdram, ctx);
        goto after_57;
    // 0x80125F54: lw          $a3, 0x9C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X9C);
    after_57:
    // 0x80125F58: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125F5C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125F60: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125F64: jal         0x80137C5C
    // 0x80125F68: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_58;
    // 0x80125F68: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_58:
    // 0x80125F6C: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x80125F70: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80125F74: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80125F78: jal         0x80137CB8
    // 0x80125F7C: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_59;
    // 0x80125F7C: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_59:
    // 0x80125F80: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80125F84: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80125F88: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80125F8C: jal         0x80137C5C
    // 0x80125F90: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_60;
    // 0x80125F90: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_60:
    // 0x80125F94: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125F98: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80125F9C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80125FA0: jal         0x8012635C
    // 0x80125FA4: addiu       $a2, $a2, 0x14
    ctx->r6 = ADD32(ctx->r6, 0X14);
    func_8012635C(rdram, ctx);
        goto after_61;
    // 0x80125FA4: addiu       $a2, $a2, 0x14
    ctx->r6 = ADD32(ctx->r6, 0X14);
    after_61:
    // 0x80125FA8: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125FAC: lw          $a0, 0xCC($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XCC);
    // 0x80125FB0: lw          $a1, 0xD0($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XD0);
    // 0x80125FB4: jal         0x8012635C
    // 0x80125FB8: addiu       $a2, $a2, 0x18
    ctx->r6 = ADD32(ctx->r6, 0X18);
    func_8012635C(rdram, ctx);
        goto after_62;
    // 0x80125FB8: addiu       $a2, $a2, 0x18
    ctx->r6 = ADD32(ctx->r6, 0X18);
    after_62:
    // 0x80125FBC: lw          $a2, 0xC8($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XC8);
    // 0x80125FC0: lw          $a0, 0xD4($sp)
    ctx->r4 = MEM_W(ctx->r29, 0XD4);
    // 0x80125FC4: lui         $a1, 0x1
    ctx->r5 = S32(0X1 << 16);
    // 0x80125FC8: jal         0x8012635C
    // 0x80125FCC: addiu       $a2, $a2, 0x1C
    ctx->r6 = ADD32(ctx->r6, 0X1C);
    func_8012635C(rdram, ctx);
        goto after_63;
    // 0x80125FCC: addiu       $a2, $a2, 0x1C
    ctx->r6 = ADD32(ctx->r6, 0X1C);
    after_63:
    // 0x80125FD0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80125FD4: addiu       $sp, $sp, 0xC8
    ctx->r29 = ADD32(ctx->r29, 0XC8);
    // 0x80125FD8: jr          $ra
    // 0x80125FDC: nop

    return;
    // 0x80125FDC: nop

;}
RECOMP_FUNC void func_80125FE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80125FE0: addiu       $sp, $sp, -0x88
    ctx->r29 = ADD32(ctx->r29, -0X88);
    // 0x80125FE4: lh          $t6, 0x9A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X9A);
    // 0x80125FE8: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80125FEC: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x80125FF0: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80125FF4: sw          $a1, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r5;
    // 0x80125FF8: addu        $t0, $t7, $t8
    ctx->r8 = ADD32(ctx->r15, ctx->r24);
    // 0x80125FFC: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x80126000: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80126004: sw          $a0, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r4;
    // 0x80126008: sw          $a2, 0x90($sp)
    MEM_W(0X90, ctx->r29) = ctx->r6;
    // 0x8012600C: sw          $a3, 0x94($sp)
    MEM_W(0X94, ctx->r29) = ctx->r7;
    // 0x80126010: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80126014: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126018: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x8012601C: jal         0x80137BF4
    // 0x80126020: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_0;
    // 0x80126020: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_0:
    // 0x80126024: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x80126028: sw          $v0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r2;
    // 0x8012602C: sw          $v1, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r3;
    // 0x80126030: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x80126034: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126038: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x8012603C: jal         0x80137BF4
    // 0x80126040: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_1;
    // 0x80126040: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_1:
    // 0x80126044: lh          $t2, 0x9E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X9E);
    // 0x80126048: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x8012604C: addiu       $t4, $t4, 0x2350
    ctx->r12 = ADD32(ctx->r12, 0X2350);
    // 0x80126050: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x80126054: addu        $t0, $t3, $t4
    ctx->r8 = ADD32(ctx->r11, ctx->r12);
    // 0x80126058: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x8012605C: sw          $v0, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r2;
    // 0x80126060: sw          $v1, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r3;
    // 0x80126064: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x80126068: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x8012606C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80126070: jal         0x80137BF4
    // 0x80126074: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_2;
    // 0x80126074: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_2:
    // 0x80126078: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x8012607C: sw          $v0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r2;
    // 0x80126080: sw          $v1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r3;
    // 0x80126084: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x80126088: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x8012608C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80126090: jal         0x80137BF4
    // 0x80126094: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_3;
    // 0x80126094: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_3:
    // 0x80126098: lw          $a1, 0xA0($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XA0);
    // 0x8012609C: sw          $v0, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r2;
    // 0x801260A0: sw          $v1, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r3;
    // 0x801260A4: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x801260A8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x801260AC: jal         0x80137CB8
    // 0x801260B0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_4;
    // 0x801260B0: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_4:
    // 0x801260B4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801260B8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801260BC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801260C0: jal         0x80137C5C
    // 0x801260C4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_5;
    // 0x801260C4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_5:
    // 0x801260C8: lw          $t8, 0xA0($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XA0);
    // 0x801260CC: sw          $v0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r2;
    // 0x801260D0: sw          $v1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r3;
    // 0x801260D4: negu        $a1, $t8
    ctx->r5 = SUB32(0, ctx->r24);
    // 0x801260D8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x801260DC: lw          $a2, 0x70($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X70);
    // 0x801260E0: jal         0x80137CB8
    // 0x801260E4: lw          $a3, 0x74($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X74);
    __ll_mul_recomp(rdram, ctx);
        goto after_6;
    // 0x801260E4: lw          $a3, 0x74($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X74);
    after_6:
    // 0x801260E8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801260EC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801260F0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801260F4: jal         0x80137C5C
    // 0x801260F8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_7;
    // 0x801260F8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_7:
    // 0x801260FC: lw          $a0, 0x54($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X54);
    // 0x80126100: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80126104: jal         0x8012635C
    // 0x80126108: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    func_8012635C(rdram, ctx);
        goto after_8;
    // 0x80126108: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    after_8:
    // 0x8012610C: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x80126110: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80126114: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80126118: jal         0x8012635C
    // 0x8012611C: addiu       $a2, $a2, 0x4
    ctx->r6 = ADD32(ctx->r6, 0X4);
    func_8012635C(rdram, ctx);
        goto after_9;
    // 0x8012611C: addiu       $a2, $a2, 0x4
    ctx->r6 = ADD32(ctx->r6, 0X4);
    after_9:
    // 0x80126120: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x80126124: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x80126128: lw          $a2, 0x78($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X78);
    // 0x8012612C: jal         0x80137CB8
    // 0x80126130: lw          $a3, 0x7C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X7C);
    __ll_mul_recomp(rdram, ctx);
        goto after_10;
    // 0x80126130: lw          $a3, 0x7C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X7C);
    after_10:
    // 0x80126134: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80126138: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012613C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126140: jal         0x80137C5C
    // 0x80126144: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_11;
    // 0x80126144: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_11:
    // 0x80126148: lw          $a1, 0xA4($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XA4);
    // 0x8012614C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80126150: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x80126154: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80126158: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8012615C: jal         0x80137CB8
    // 0x80126160: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    __ll_mul_recomp(rdram, ctx);
        goto after_12;
    // 0x80126160: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_12:
    // 0x80126164: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80126168: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012616C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126170: jal         0x80137C5C
    // 0x80126174: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_13;
    // 0x80126174: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_13:
    // 0x80126178: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x8012617C: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x80126180: lw          $a0, 0x68($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X68);
    // 0x80126184: lw          $a1, 0x6C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X6C);
    // 0x80126188: lw          $a2, 0x78($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X78);
    // 0x8012618C: jal         0x80137CB8
    // 0x80126190: lw          $a3, 0x7C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X7C);
    __ll_mul_recomp(rdram, ctx);
        goto after_14;
    // 0x80126190: lw          $a3, 0x7C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X7C);
    after_14:
    // 0x80126194: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80126198: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012619C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801261A0: jal         0x80137C5C
    // 0x801261A4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_15;
    // 0x801261A4: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_15:
    // 0x801261A8: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x801261AC: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x801261B0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x801261B4: jal         0x80137CB8
    // 0x801261B8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_16;
    // 0x801261B8: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_16:
    // 0x801261BC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801261C0: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801261C4: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801261C8: jal         0x80137C5C
    // 0x801261CC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_17;
    // 0x801261CC: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_17:
    // 0x801261D0: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x801261D4: lw          $a0, 0x44($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X44);
    // 0x801261D8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801261DC: jal         0x8012635C
    // 0x801261E0: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    func_8012635C(rdram, ctx);
        goto after_18;
    // 0x801261E0: addiu       $a2, $a2, 0x8
    ctx->r6 = ADD32(ctx->r6, 0X8);
    after_18:
    // 0x801261E4: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x801261E8: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x801261EC: lw          $a2, 0x80($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X80);
    // 0x801261F0: jal         0x80137CB8
    // 0x801261F4: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    __ll_mul_recomp(rdram, ctx);
        goto after_19;
    // 0x801261F4: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    after_19:
    // 0x801261F8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801261FC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80126200: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126204: jal         0x80137C5C
    // 0x80126208: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_20;
    // 0x80126208: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_20:
    // 0x8012620C: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x80126210: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80126214: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80126218: jal         0x8012635C
    // 0x8012621C: addiu       $a2, $a2, 0xC
    ctx->r6 = ADD32(ctx->r6, 0XC);
    func_8012635C(rdram, ctx);
        goto after_21;
    // 0x8012621C: addiu       $a2, $a2, 0xC
    ctx->r6 = ADD32(ctx->r6, 0XC);
    after_21:
    // 0x80126220: lw          $a0, 0x70($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X70);
    // 0x80126224: lw          $a1, 0x74($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X74);
    // 0x80126228: lw          $a2, 0x80($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X80);
    // 0x8012622C: jal         0x80137CB8
    // 0x80126230: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    __ll_mul_recomp(rdram, ctx);
        goto after_22;
    // 0x80126230: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    after_22:
    // 0x80126234: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80126238: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012623C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126240: jal         0x80137C5C
    // 0x80126244: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_23;
    // 0x80126244: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_23:
    // 0x80126248: lw          $t8, 0xA8($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XA8);
    // 0x8012624C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80126250: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x80126254: negu        $a1, $t8
    ctx->r5 = SUB32(0, ctx->r24);
    // 0x80126258: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x8012625C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80126260: jal         0x80137CB8
    // 0x80126264: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    __ll_mul_recomp(rdram, ctx);
        goto after_24;
    // 0x80126264: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_24:
    // 0x80126268: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012626C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80126270: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126274: jal         0x80137C5C
    // 0x80126278: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_25;
    // 0x80126278: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_25:
    // 0x8012627C: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x80126280: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x80126284: lw          $a0, 0x68($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X68);
    // 0x80126288: lw          $a1, 0x6C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X6C);
    // 0x8012628C: lw          $a2, 0x80($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X80);
    // 0x80126290: jal         0x80137CB8
    // 0x80126294: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    __ll_mul_recomp(rdram, ctx);
        goto after_26;
    // 0x80126294: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    after_26:
    // 0x80126298: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012629C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801262A0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801262A4: jal         0x80137C5C
    // 0x801262A8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_27;
    // 0x801262A8: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_27:
    // 0x801262AC: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x801262B0: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x801262B4: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x801262B8: jal         0x80137CB8
    // 0x801262BC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    __ll_mul_recomp(rdram, ctx);
        goto after_28;
    // 0x801262BC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    after_28:
    // 0x801262C0: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801262C4: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801262C8: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801262CC: jal         0x80137C5C
    // 0x801262D0: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_29;
    // 0x801262D0: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_29:
    // 0x801262D4: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x801262D8: lw          $a0, 0x44($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X44);
    // 0x801262DC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801262E0: jal         0x8012635C
    // 0x801262E4: addiu       $a2, $a2, 0x10
    ctx->r6 = ADD32(ctx->r6, 0X10);
    func_8012635C(rdram, ctx);
        goto after_30;
    // 0x801262E4: addiu       $a2, $a2, 0x10
    ctx->r6 = ADD32(ctx->r6, 0X10);
    after_30:
    // 0x801262E8: lw          $a1, 0xA8($sp)
    ctx->r5 = MEM_W(ctx->r29, 0XA8);
    // 0x801262EC: lw          $a2, 0x78($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X78);
    // 0x801262F0: lw          $a3, 0x7C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X7C);
    // 0x801262F4: jal         0x80137CB8
    // 0x801262F8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_mul_recomp(rdram, ctx);
        goto after_31;
    // 0x801262F8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_31:
    // 0x801262FC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80126300: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80126304: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80126308: jal         0x80137C5C
    // 0x8012630C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    __ll_div_recomp(rdram, ctx);
        goto after_32;
    // 0x8012630C: lui         $a3, 0x1
    ctx->r7 = S32(0X1 << 16);
    after_32:
    // 0x80126310: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x80126314: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80126318: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8012631C: jal         0x8012635C
    // 0x80126320: addiu       $a2, $a2, 0x14
    ctx->r6 = ADD32(ctx->r6, 0X14);
    func_8012635C(rdram, ctx);
        goto after_33;
    // 0x80126320: addiu       $a2, $a2, 0x14
    ctx->r6 = ADD32(ctx->r6, 0X14);
    after_33:
    // 0x80126324: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x80126328: lw          $a0, 0x8C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X8C);
    // 0x8012632C: lw          $a1, 0x90($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X90);
    // 0x80126330: jal         0x8012635C
    // 0x80126334: addiu       $a2, $a2, 0x18
    ctx->r6 = ADD32(ctx->r6, 0X18);
    func_8012635C(rdram, ctx);
        goto after_34;
    // 0x80126334: addiu       $a2, $a2, 0x18
    ctx->r6 = ADD32(ctx->r6, 0X18);
    after_34:
    // 0x80126338: lw          $a2, 0x88($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X88);
    // 0x8012633C: lw          $a0, 0x94($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X94);
    // 0x80126340: lui         $a1, 0x1
    ctx->r5 = S32(0X1 << 16);
    // 0x80126344: jal         0x8012635C
    // 0x80126348: addiu       $a2, $a2, 0x1C
    ctx->r6 = ADD32(ctx->r6, 0X1C);
    func_8012635C(rdram, ctx);
        goto after_35;
    // 0x80126348: addiu       $a2, $a2, 0x1C
    ctx->r6 = ADD32(ctx->r6, 0X1C);
    after_35:
    // 0x8012634C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80126350: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
    // 0x80126354: jr          $ra
    // 0x80126358: nop

    return;
    // 0x80126358: nop

;}
RECOMP_FUNC void func_8012635C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012635C: lui         $at, 0xFFFF
    ctx->r1 = S32(0XFFFF << 16);
    // 0x80126360: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80126364: andi        $t8, $t7, 0xFFFF
    ctx->r24 = ctx->r15 & 0XFFFF;
    // 0x80126368: and         $t6, $a0, $at
    ctx->r14 = ctx->r4 & ctx->r1;
    // 0x8012636C: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80126370: andi        $t1, $a1, 0xFFFF
    ctx->r9 = ctx->r5 & 0XFFFF;
    // 0x80126374: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x80126378: or          $t2, $t0, $t1
    ctx->r10 = ctx->r8 | ctx->r9;
    // 0x8012637C: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80126380: jr          $ra
    // 0x80126384: sw          $t2, 0x20($a2)
    MEM_W(0X20, ctx->r6) = ctx->r10;
    return;
    // 0x80126384: sw          $t2, 0x20($a2)
    MEM_W(0X20, ctx->r6) = ctx->r10;
;}
RECOMP_FUNC void func_80126388(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80126388: addiu       $sp, $sp, -0x70
    ctx->r29 = ADD32(ctx->r29, -0X70);
    // 0x8012638C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80126390: lui         $ra, 0x8020
    ctx->r31 = S32(0X8020 << 16);
    // 0x80126394: addiu       $ra, $ra, 0x3FE0
    ctx->r31 = ADD32(ctx->r31, 0X3FE0);
    // 0x80126398: andi        $t8, $a0, 0xFFFF
    ctx->r24 = ctx->r4 & 0XFFFF;
    // 0x8012639C: andi        $t9, $a1, 0xFFFF
    ctx->r25 = ctx->r5 & 0XFFFF;
    // 0x801263A0: sll         $t6, $t9, 3
    ctx->r14 = S32(ctx->r25 << 3);
    // 0x801263A4: sll         $t7, $t8, 3
    ctx->r15 = S32(ctx->r24 << 3);
    // 0x801263A8: addu        $v1, $ra, $t7
    ctx->r3 = ADD32(ctx->r31, ctx->r15);
    // 0x801263AC: addu        $v0, $ra, $t6
    ctx->r2 = ADD32(ctx->r31, ctx->r14);
    // 0x801263B0: lh          $t0, 0x0($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X0);
    // 0x801263B4: lh          $t1, 0x0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X0);
    // 0x801263B8: sw          $a0, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r4;
    // 0x801263BC: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x801263C0: sw          $a1, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r5;
    // 0x801263C4: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x801263C8: addu        $t8, $t0, $t1
    ctx->r24 = ADD32(ctx->r8, ctx->r9);
    // 0x801263CC: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x801263D0: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x801263D4: lh          $t2, 0x2($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2);
    // 0x801263D8: lh          $t3, 0x2($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2);
    // 0x801263DC: lh          $t4, 0x4($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X4);
    // 0x801263E0: lh          $t5, 0x4($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X4);
    // 0x801263E4: addu        $t8, $t2, $t3
    ctx->r24 = ADD32(ctx->r10, ctx->r11);
    // 0x801263E8: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x801263EC: sw          $a2, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r6;
    // 0x801263F0: sw          $a3, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r7;
    // 0x801263F4: bgez        $t6, L_80126404
    if (SIGNED(ctx->r14) >= 0) {
        // 0x801263F8: sra         $t7, $t6, 3
        ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
            goto L_80126404;
    }
    // 0x801263F8: sra         $t7, $t6, 3
    ctx->r15 = S32(SIGNED(ctx->r14) >> 3);
    // 0x801263FC: addiu       $at, $t6, 0x7
    ctx->r1 = ADD32(ctx->r14, 0X7);
    // 0x80126400: sra         $t7, $at, 3
    ctx->r15 = S32(SIGNED(ctx->r1) >> 3);
L_80126404:
    // 0x80126404: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80126408: addu        $t9, $t4, $t5
    ctx->r25 = ADD32(ctx->r12, ctx->r13);
    // 0x8012640C: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    // 0x80126410: bgez        $t6, L_80126420
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80126414: sra         $t8, $t6, 3
        ctx->r24 = S32(SIGNED(ctx->r14) >> 3);
            goto L_80126420;
    }
    // 0x80126414: sra         $t8, $t6, 3
    ctx->r24 = S32(SIGNED(ctx->r14) >> 3);
    // 0x80126418: addiu       $at, $t6, 0x7
    ctx->r1 = ADD32(ctx->r14, 0X7);
    // 0x8012641C: sra         $t8, $at, 3
    ctx->r24 = S32(SIGNED(ctx->r1) >> 3);
L_80126420:
    // 0x80126420: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80126424: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x80126428: sw          $t8, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r24;
    // 0x8012642C: bgez        $t9, L_8012643C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80126430: sra         $t6, $t9, 3
        ctx->r14 = S32(SIGNED(ctx->r25) >> 3);
            goto L_8012643C;
    }
    // 0x80126430: sra         $t6, $t9, 3
    ctx->r14 = S32(SIGNED(ctx->r25) >> 3);
    // 0x80126434: addiu       $at, $t9, 0x7
    ctx->r1 = ADD32(ctx->r25, 0X7);
    // 0x80126438: sra         $t6, $at, 3
    ctx->r14 = S32(SIGNED(ctx->r1) >> 3);
L_8012643C:
    // 0x8012643C: lh          $t9, 0x86($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X86);
    // 0x80126440: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80126444: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x80126448: multu       $t9, $t7
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012644C: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80126450: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80126454: mflo        $t8
    ctx->r24 = lo;
    // 0x80126458: sra         $t6, $t8, 4
    ctx->r14 = S32(SIGNED(ctx->r24) >> 4);
    // 0x8012645C: lw          $t8, 0x18($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X18);
    // 0x80126460: addu        $t6, $t6, $t7
    ctx->r14 = ADD32(ctx->r14, ctx->r15);
    // 0x80126464: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    // 0x80126468: multu       $t9, $t8
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012646C: mflo        $t7
    ctx->r15 = lo;
    // 0x80126470: sra         $t6, $t7, 4
    ctx->r14 = S32(SIGNED(ctx->r15) >> 4);
    // 0x80126474: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x80126478: lw          $t6, 0x1C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X1C);
    // 0x8012647C: sw          $t7, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r15;
    // 0x80126480: multu       $t9, $t6
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126484: mflo        $t8
    ctx->r24 = lo;
    // 0x80126488: sra         $t7, $t8, 3
    ctx->r15 = S32(SIGNED(ctx->r24) >> 3);
    // 0x8012648C: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x80126490: subu        $t8, $t0, $t1
    ctx->r24 = SUB32(ctx->r8, ctx->r9);
    // 0x80126494: subu        $t7, $t2, $t3
    ctx->r15 = SUB32(ctx->r10, ctx->r11);
    // 0x80126498: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x8012649C: sw          $t9, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r25;
    // 0x801264A0: sw          $t8, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r24;
    // 0x801264A4: sw          $t7, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r15;
    // 0x801264A8: bne         $t8, $zero, L_801264F4
    if (ctx->r24 != 0) {
        // 0x801264AC: sw          $t6, 0x64($sp)
        MEM_W(0X64, ctx->r29) = ctx->r14;
            goto L_801264F4;
    }
    // 0x801264AC: sw          $t6, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r14;
    // 0x801264B0: bnel        $t7, $zero, L_801264F8
    if (ctx->r15 != 0) {
        // 0x801264B4: lw          $v0, 0x6C($sp)
        ctx->r2 = MEM_W(ctx->r29, 0X6C);
            goto L_801264F8;
    }
    goto skip_0;
    // 0x801264B4: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
    skip_0:
    // 0x801264B8: lbu         $t7, 0x93($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X93);
    // 0x801264BC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801264C0: addiu       $t2, $zero, 0x400
    ctx->r10 = ADD32(0, 0X400);
    // 0x801264C4: bne         $t7, $at, L_801264E4
    if (ctx->r15 != ctx->r1) {
        // 0x801264C8: or          $t3, $zero, $zero
        ctx->r11 = 0 | 0;
            goto L_801264E4;
    }
    // 0x801264C8: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
    // 0x801264CC: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x801264D0: addiu       $t3, $zero, 0x400
    ctx->r11 = ADD32(0, 0X400);
    // 0x801264D4: addiu       $a3, $zero, 0x400
    ctx->r7 = ADD32(0, 0X400);
    // 0x801264D8: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x801264DC: b           L_80126630
    // 0x801264E0: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
        goto L_80126630;
    // 0x801264E0: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
L_801264E4:
    // 0x801264E4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x801264E8: addiu       $t0, $zero, -0x400
    ctx->r8 = ADD32(0, -0X400);
    // 0x801264EC: b           L_80126630
    // 0x801264F0: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
        goto L_80126630;
    // 0x801264F0: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
L_801264F4:
    // 0x801264F4: lw          $v0, 0x6C($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X6C);
L_801264F8:
    // 0x801264F8: lbu         $t9, 0x93($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X93);
    // 0x801264FC: lw          $t6, 0x68($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X68);
    // 0x80126500: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x80126504: or          $t3, $v0, $zero
    ctx->r11 = ctx->r2 | 0;
    // 0x80126508: bne         $t9, $at, L_80126524
    if (ctx->r25 != ctx->r1) {
        // 0x8012650C: or          $t2, $t6, $zero
        ctx->r10 = ctx->r14 | 0;
            goto L_80126524;
    }
    // 0x8012650C: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
    // 0x80126510: bgezl       $v0, L_8012653C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80126514: lw          $t7, 0x64($sp)
        ctx->r15 = MEM_W(ctx->r29, 0X64);
            goto L_8012653C;
    }
    goto skip_1;
    // 0x80126514: lw          $t7, 0x64($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X64);
    skip_1:
    // 0x80126518: negu        $t2, $t6
    ctx->r10 = SUB32(0, ctx->r14);
    // 0x8012651C: b           L_80126538
    // 0x80126520: negu        $t3, $v0
    ctx->r11 = SUB32(0, ctx->r2);
        goto L_80126538;
    // 0x80126520: negu        $t3, $v0
    ctx->r11 = SUB32(0, ctx->r2);
L_80126524:
    // 0x80126524: lw          $t8, 0x68($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X68);
    // 0x80126528: bgezl       $t8, L_8012653C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8012652C: lw          $t7, 0x64($sp)
        ctx->r15 = MEM_W(ctx->r29, 0X64);
            goto L_8012653C;
    }
    goto skip_2;
    // 0x8012652C: lw          $t7, 0x64($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X64);
    skip_2:
    // 0x80126530: negu        $t2, $t8
    ctx->r10 = SUB32(0, ctx->r24);
    // 0x80126534: negu        $t3, $v0
    ctx->r11 = SUB32(0, ctx->r2);
L_80126538:
    // 0x80126538: lw          $t7, 0x64($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X64);
L_8012653C:
    // 0x8012653C: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    // 0x80126540: lw          $t8, 0x68($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X68);
    // 0x80126544: multu       $t3, $t7
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126548: mflo        $v1
    ctx->r3 = lo;
    // 0x8012654C: bgez        $v1, L_8012655C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80126550: sra         $v0, $v1, 8
        ctx->r2 = S32(SIGNED(ctx->r3) >> 8);
            goto L_8012655C;
    }
    // 0x80126550: sra         $v0, $v1, 8
    ctx->r2 = S32(SIGNED(ctx->r3) >> 8);
    // 0x80126554: addiu       $at, $v1, 0xFF
    ctx->r1 = ADD32(ctx->r3, 0XFF);
    // 0x80126558: sra         $v0, $at, 8
    ctx->r2 = S32(SIGNED(ctx->r1) >> 8);
L_8012655C:
    // 0x8012655C: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x80126560: multu       $t7, $t2
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126564: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    // 0x80126568: mflo        $a1
    ctx->r5 = lo;
    // 0x8012656C: bgez        $a1, L_8012657C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80126570: sra         $a0, $a1, 8
        ctx->r4 = S32(SIGNED(ctx->r5) >> 8);
            goto L_8012657C;
    }
    // 0x80126570: sra         $a0, $a1, 8
    ctx->r4 = S32(SIGNED(ctx->r5) >> 8);
    // 0x80126574: addiu       $at, $a1, 0xFF
    ctx->r1 = ADD32(ctx->r5, 0XFF);
    // 0x80126578: sra         $a0, $at, 8
    ctx->r4 = S32(SIGNED(ctx->r1) >> 8);
L_8012657C:
    // 0x8012657C: multu       $t9, $t3
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126580: or          $t0, $a0, $zero
    ctx->r8 = ctx->r4 | 0;
    // 0x80126584: mflo        $t6
    ctx->r14 = lo;
    // 0x80126588: nop

    // 0x8012658C: nop

    // 0x80126590: multu       $t8, $t2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126594: mflo        $t7
    ctx->r15 = lo;
    // 0x80126598: subu        $a2, $t6, $t7
    ctx->r6 = SUB32(ctx->r14, ctx->r15);
    // 0x8012659C: bgez        $a2, L_801265AC
    if (SIGNED(ctx->r6) >= 0) {
        // 0x801265A0: sra         $t4, $a2, 8
        ctx->r12 = S32(SIGNED(ctx->r6) >> 8);
            goto L_801265AC;
    }
    // 0x801265A0: sra         $t4, $a2, 8
    ctx->r12 = S32(SIGNED(ctx->r6) >> 8);
    // 0x801265A4: addiu       $at, $a2, 0xFF
    ctx->r1 = ADD32(ctx->r6, 0XFF);
    // 0x801265A8: sra         $t4, $at, 8
    ctx->r12 = S32(SIGNED(ctx->r1) >> 8);
L_801265AC:
    // 0x801265AC: bne         $v0, $zero, L_80126630
    if (ctx->r2 != 0) {
        // 0x801265B0: or          $t1, $t4, $zero
        ctx->r9 = ctx->r12 | 0;
            goto L_80126630;
    }
    // 0x801265B0: or          $t1, $t4, $zero
    ctx->r9 = ctx->r12 | 0;
    // 0x801265B4: bnel        $a0, $zero, L_80126634
    if (ctx->r4 != 0) {
        // 0x801265B8: lw          $t9, 0x6C($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X6C);
            goto L_80126634;
    }
    goto skip_3;
    // 0x801265B8: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    skip_3:
    // 0x801265BC: bnel        $t4, $zero, L_80126634
    if (ctx->r12 != 0) {
        // 0x801265C0: lw          $t9, 0x6C($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X6C);
            goto L_80126634;
    }
    goto skip_4;
    // 0x801265C0: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    skip_4:
    // 0x801265C4: bne         $v0, $zero, L_801265E8
    if (ctx->r2 != 0) {
        // 0x801265C8: nop
    
            goto L_801265E8;
    }
    // 0x801265C8: nop

    // 0x801265CC: bgez        $v1, L_801265DC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x801265D0: nop
    
            goto L_801265DC;
    }
    // 0x801265D0: nop

    // 0x801265D4: b           L_801265E8
    // 0x801265D8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
        goto L_801265E8;
    // 0x801265D8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
L_801265DC:
    // 0x801265DC: blez        $v1, L_801265E8
    if (SIGNED(ctx->r3) <= 0) {
        // 0x801265E0: nop
    
            goto L_801265E8;
    }
    // 0x801265E0: nop

    // 0x801265E4: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
L_801265E8:
    // 0x801265E8: bne         $a0, $zero, L_8012660C
    if (ctx->r4 != 0) {
        // 0x801265EC: nop
    
            goto L_8012660C;
    }
    // 0x801265EC: nop

    // 0x801265F0: bgez        $a1, L_80126600
    if (SIGNED(ctx->r5) >= 0) {
        // 0x801265F4: nop
    
            goto L_80126600;
    }
    // 0x801265F4: nop

    // 0x801265F8: b           L_8012660C
    // 0x801265FC: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
        goto L_8012660C;
    // 0x801265FC: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
L_80126600:
    // 0x80126600: blez        $a1, L_8012660C
    if (SIGNED(ctx->r5) <= 0) {
        // 0x80126604: nop
    
            goto L_8012660C;
    }
    // 0x80126604: nop

    // 0x80126608: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
L_8012660C:
    // 0x8012660C: bnel        $t4, $zero, L_80126634
    if (ctx->r12 != 0) {
        // 0x80126610: lw          $t9, 0x6C($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X6C);
            goto L_80126634;
    }
    goto skip_5;
    // 0x80126610: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    skip_5:
    // 0x80126614: bgez        $a2, L_80126624
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80126618: nop
    
            goto L_80126624;
    }
    // 0x80126618: nop

    // 0x8012661C: b           L_80126630
    // 0x80126620: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
        goto L_80126630;
    // 0x80126620: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
L_80126624:
    // 0x80126624: blezl       $a2, L_80126634
    if (SIGNED(ctx->r6) <= 0) {
        // 0x80126628: lw          $t9, 0x6C($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X6C);
            goto L_80126634;
    }
    goto skip_6;
    // 0x80126628: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    skip_6:
    // 0x8012662C: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
L_80126630:
    // 0x80126630: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
L_80126634:
    // 0x80126634: lw          $t8, 0x68($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X68);
    // 0x80126638: lw          $t6, 0x64($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X64);
    // 0x8012663C: mtc1        $t9, $f18
    ctx->f18.u32l = ctx->r25;
    // 0x80126640: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80126644: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x80126648: cvt.s.w     $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    ctx->f0.fl = CVT_S_W(ctx->f18.u32l);
    // 0x8012664C: sw          $a3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r7;
    // 0x80126650: sw          $t0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r8;
    // 0x80126654: sw          $t1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r9;
    // 0x80126658: sw          $t2, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r10;
    // 0x8012665C: cvt.s.w     $f2, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    ctx->f2.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80126660: mul.s       $f8, $f0, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x80126664: sw          $t3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r11;
    // 0x80126668: mul.s       $f10, $f2, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x8012666C: cvt.s.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80126670: add.s       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x80126674: mul.s       $f4, $f14, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x80126678: jal         0x80137E10
    // 0x8012667C: add.s       $f12, $f18, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f18.fl + ctx->f4.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x8012667C: add.s       $f12, $f18, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f18.fl + ctx->f4.fl;
    after_0:
    // 0x80126680: lw          $t2, 0x60($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X60);
    // 0x80126684: lw          $t3, 0x5C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X5C);
    // 0x80126688: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8012668C: mtc1        $t2, $f8
    ctx->f8.u32l = ctx->r10;
    // 0x80126690: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x80126694: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x80126698: cvt.s.w     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    ctx->f2.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8012669C: mfc1        $a0, $f6
    ctx->r4 = (int32_t)ctx->f6.u32l;
    // 0x801266A0: nop

    // 0x801266A4: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x801266A8: cvt.s.w     $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    ctx->f14.fl = CVT_S_W(ctx->f10.u32l);
    // 0x801266AC: mul.s       $f4, $f2, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x801266B0: sra         $t8, $t9, 16
    ctx->r24 = S32(SIGNED(ctx->r25) >> 16);
    // 0x801266B4: sw          $t8, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r24;
    // 0x801266B8: mul.s       $f6, $f14, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x801266BC: cvt.s.w     $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    ctx->f16.fl = CVT_S_W(ctx->f18.u32l);
    // 0x801266C0: add.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x801266C4: mul.s       $f10, $f16, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x801266C8: jal         0x80137E10
    // 0x801266CC: add.s       $f12, $f8, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f10.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_1;
    // 0x801266CC: add.s       $f12, $f8, $f10
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f12.fl = ctx->f8.fl + ctx->f10.fl;
    after_1:
    // 0x801266D0: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    // 0x801266D4: lw          $t0, 0x50($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X50);
    // 0x801266D8: lw          $t1, 0x4C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X4C);
    // 0x801266DC: mtc1        $a3, $f4
    ctx->f4.u32l = ctx->r7;
    // 0x801266E0: mtc1        $t0, $f6
    ctx->f6.u32l = ctx->r8;
    // 0x801266E4: trunc.w.s   $f18, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    ctx->f18.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x801266E8: mtc1        $t1, $f8
    ctx->f8.u32l = ctx->r9;
    // 0x801266EC: cvt.s.w     $f2, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    ctx->f2.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801266F0: mfc1        $v1, $f18
    ctx->r3 = (int32_t)ctx->f18.u32l;
    // 0x801266F4: nop

    // 0x801266F8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x801266FC: cvt.s.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80126700: mul.s       $f10, $f2, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f10.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x80126704: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80126708: sw          $t9, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r25;
    // 0x8012670C: mul.s       $f18, $f14, $f14
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f18.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x80126710: cvt.s.w     $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80126714: add.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f18.fl;
    // 0x80126718: mul.s       $f6, $f16, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x8012671C: jal         0x80137E10
    // 0x80126720: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_2;
    // 0x80126720: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    after_2:
    // 0x80126724: lw          $a0, 0x3C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X3C);
    // 0x80126728: lw          $v1, 0x38($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X38);
    // 0x8012672C: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    // 0x80126730: lw          $t0, 0x50($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X50);
    // 0x80126734: lw          $t1, 0x4C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X4C);
    // 0x80126738: lw          $t2, 0x60($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X60);
    // 0x8012673C: bne         $a0, $zero, L_8012674C
    if (ctx->r4 != 0) {
        // 0x80126740: lw          $t3, 0x5C($sp)
        ctx->r11 = MEM_W(ctx->r29, 0X5C);
            goto L_8012674C;
    }
    // 0x80126740: lw          $t3, 0x5C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X5C);
    // 0x80126744: b           L_80126CB4
    // 0x80126748: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80126CB4;
    // 0x80126748: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8012674C:
    // 0x8012674C: bnel        $v1, $zero, L_80126760
    if (ctx->r3 != 0) {
        // 0x80126750: trunc.w.s   $f8, $f0
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = TRUNC_W_S(ctx->f0.fl);
            goto L_80126760;
    }
    goto skip_7;
    // 0x80126750: trunc.w.s   $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = TRUNC_W_S(ctx->f0.fl);
    skip_7:
    // 0x80126754: b           L_80126CB4
    // 0x80126758: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80126CB4;
    // 0x80126758: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8012675C: trunc.w.s   $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = TRUNC_W_S(ctx->f0.fl);
L_80126760:
    // 0x80126760: lw          $t4, 0x78($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X78);
    // 0x80126764: lw          $t9, 0x6C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X6C);
    // 0x80126768: mfc1        $v0, $f8
    ctx->r2 = (int32_t)ctx->f8.u32l;
    // 0x8012676C: nop

    // 0x80126770: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x80126774: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80126778: bne         $t7, $zero, L_80126788
    if (ctx->r15 != 0) {
        // 0x8012677C: or          $v0, $t7, $zero
        ctx->r2 = ctx->r15 | 0;
            goto L_80126788;
    }
    // 0x8012677C: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x80126780: b           L_80126CB4
    // 0x80126784: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80126CB4;
    // 0x80126784: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80126788:
    // 0x80126788: multu       $t9, $t4
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012678C: lw          $t9, 0x7C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X7C);
    // 0x80126790: lw          $t7, 0x68($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X68);
    // 0x80126794: lw          $a1, 0x80($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X80);
    // 0x80126798: lui         $ra, 0x8015
    ctx->r31 = S32(0X8015 << 16);
    // 0x8012679C: addiu       $ra, $ra, 0x2C78
    ctx->r31 = ADD32(ctx->r31, 0X2C78);
    // 0x801267A0: mflo        $t8
    ctx->r24 = lo;
    // 0x801267A4: nop

    // 0x801267A8: nop

    // 0x801267AC: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x801267B0: mflo        $t6
    ctx->r14 = lo;
    // 0x801267B4: sw          $t6, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r14;
    // 0x801267B8: bne         $a0, $zero, L_801267C4
    if (ctx->r4 != 0) {
        // 0x801267BC: nop
    
            goto L_801267C4;
    }
    // 0x801267BC: nop

    // 0x801267C0: break       7
    do_break(2148689856);
L_801267C4:
    // 0x801267C4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801267C8: bne         $a0, $at, L_801267DC
    if (ctx->r4 != ctx->r1) {
        // 0x801267CC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801267DC;
    }
    // 0x801267CC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801267D0: bne         $t8, $at, L_801267DC
    if (ctx->r24 != ctx->r1) {
        // 0x801267D4: nop
    
            goto L_801267DC;
    }
    // 0x801267D4: nop

    // 0x801267D8: break       6
    do_break(2148689880);
L_801267DC:
    // 0x801267DC: multu       $t7, $t9
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801267E0: lw          $t7, 0x64($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X64);
    // 0x801267E4: mflo        $t8
    ctx->r24 = lo;
    // 0x801267E8: nop

    // 0x801267EC: nop

    // 0x801267F0: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x801267F4: mflo        $t6
    ctx->r14 = lo;
    // 0x801267F8: sw          $t6, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r14;
    // 0x801267FC: bne         $a0, $zero, L_80126808
    if (ctx->r4 != 0) {
        // 0x80126800: nop
    
            goto L_80126808;
    }
    // 0x80126800: nop

    // 0x80126804: break       7
    do_break(2148689924);
L_80126808:
    // 0x80126808: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8012680C: bne         $a0, $at, L_80126820
    if (ctx->r4 != ctx->r1) {
        // 0x80126810: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80126820;
    }
    // 0x80126810: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80126814: bne         $t8, $at, L_80126820
    if (ctx->r24 != ctx->r1) {
        // 0x80126818: nop
    
            goto L_80126820;
    }
    // 0x80126818: nop

    // 0x8012681C: break       6
    do_break(2148689948);
L_80126820:
    // 0x80126820: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126824: mflo        $t8
    ctx->r24 = lo;
    // 0x80126828: nop

    // 0x8012682C: nop

    // 0x80126830: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x80126834: mflo        $t6
    ctx->r14 = lo;
    // 0x80126838: sw          $t6, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r14;
    // 0x8012683C: bne         $a0, $zero, L_80126848
    if (ctx->r4 != 0) {
        // 0x80126840: nop
    
            goto L_80126848;
    }
    // 0x80126840: nop

    // 0x80126844: break       7
    do_break(2148689988);
L_80126848:
    // 0x80126848: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8012684C: bne         $a0, $at, L_80126860
    if (ctx->r4 != ctx->r1) {
        // 0x80126850: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80126860;
    }
    // 0x80126850: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80126854: bne         $t8, $at, L_80126860
    if (ctx->r24 != ctx->r1) {
        // 0x80126858: nop
    
            goto L_80126860;
    }
    // 0x80126858: nop

    // 0x8012685C: break       6
    do_break(2148690012);
L_80126860:
    // 0x80126860: multu       $t2, $t4
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126864: sra         $t6, $t4, 3
    ctx->r14 = S32(SIGNED(ctx->r12) >> 3);
    // 0x80126868: lh          $t4, 0x8A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X8A);
    // 0x8012686C: mflo        $t7
    ctx->r15 = lo;
    // 0x80126870: nop

    // 0x80126874: nop

    // 0x80126878: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x8012687C: mflo        $t2
    ctx->r10 = lo;
    // 0x80126880: bne         $v1, $zero, L_8012688C
    if (ctx->r3 != 0) {
        // 0x80126884: nop
    
            goto L_8012688C;
    }
    // 0x80126884: nop

    // 0x80126888: break       7
    do_break(2148690056);
L_8012688C:
    // 0x8012688C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80126890: bne         $v1, $at, L_801268A4
    if (ctx->r3 != ctx->r1) {
        // 0x80126894: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801268A4;
    }
    // 0x80126894: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80126898: bne         $t7, $at, L_801268A4
    if (ctx->r15 != ctx->r1) {
        // 0x8012689C: nop
    
            goto L_801268A4;
    }
    // 0x8012689C: nop

    // 0x801268A0: break       6
    do_break(2148690080);
L_801268A4:
    // 0x801268A4: multu       $t3, $t9
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801268A8: mflo        $t8
    ctx->r24 = lo;
    // 0x801268AC: nop

    // 0x801268B0: nop

    // 0x801268B4: div         $zero, $t8, $v1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r3)));
    // 0x801268B8: mflo        $t3
    ctx->r11 = lo;
    // 0x801268BC: bne         $v1, $zero, L_801268C8
    if (ctx->r3 != 0) {
        // 0x801268C0: nop
    
            goto L_801268C8;
    }
    // 0x801268C0: nop

    // 0x801268C4: break       7
    do_break(2148690116);
L_801268C8:
    // 0x801268C8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801268CC: bne         $v1, $at, L_801268E0
    if (ctx->r3 != ctx->r1) {
        // 0x801268D0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801268E0;
    }
    // 0x801268D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801268D4: bne         $t8, $at, L_801268E0
    if (ctx->r24 != ctx->r1) {
        // 0x801268D8: nop
    
            goto L_801268E0;
    }
    // 0x801268D8: nop

    // 0x801268DC: break       6
    do_break(2148690140);
L_801268E0:
    // 0x801268E0: div         $zero, $zero, $v1
    lo = S32(S64(S32(0)) / S64(S32(ctx->r3))); hi = S32(S64(S32(0)) % S64(S32(ctx->r3)));
    // 0x801268E4: mflo        $a2
    ctx->r6 = lo;
    // 0x801268E8: bne         $v1, $zero, L_801268F4
    if (ctx->r3 != 0) {
        // 0x801268EC: nop
    
            goto L_801268F4;
    }
    // 0x801268EC: nop

    // 0x801268F0: break       7
    do_break(2148690160);
L_801268F4:
    // 0x801268F4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801268F8: bne         $v1, $at, L_8012690C
    if (ctx->r3 != ctx->r1) {
        // 0x801268FC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012690C;
    }
    // 0x801268FC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80126900: bne         $zero, $at, L_8012690C
    if (0 != ctx->r1) {
        // 0x80126904: nop
    
            goto L_8012690C;
    }
    // 0x80126904: nop

    // 0x80126908: break       6
    do_break(2148690184);
L_8012690C:
    // 0x8012690C: multu       $t6, $a3
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126910: sra         $t6, $t9, 3
    ctx->r14 = S32(SIGNED(ctx->r25) >> 3);
    // 0x80126914: sra         $t9, $a1, 3
    ctx->r25 = S32(SIGNED(ctx->r5) >> 3);
    // 0x80126918: lbu         $v1, 0x8F($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X8F);
    // 0x8012691C: mflo        $t7
    ctx->r15 = lo;
    // 0x80126920: nop

    // 0x80126924: nop

    // 0x80126928: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x8012692C: mflo        $a3
    ctx->r7 = lo;
    // 0x80126930: sll         $t8, $a3, 3
    ctx->r24 = S32(ctx->r7 << 3);
    // 0x80126934: bne         $v0, $zero, L_80126940
    if (ctx->r2 != 0) {
        // 0x80126938: nop
    
            goto L_80126940;
    }
    // 0x80126938: nop

    // 0x8012693C: break       7
    do_break(2148690236);
L_80126940:
    // 0x80126940: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80126944: bne         $v0, $at, L_80126958
    if (ctx->r2 != ctx->r1) {
        // 0x80126948: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80126958;
    }
    // 0x80126948: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012694C: bne         $t7, $at, L_80126958
    if (ctx->r15 != ctx->r1) {
        // 0x80126950: nop
    
            goto L_80126958;
    }
    // 0x80126950: nop

    // 0x80126954: break       6
    do_break(2148690260);
L_80126958:
    // 0x80126958: multu       $t6, $t0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012695C: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80126960: mflo        $t7
    ctx->r15 = lo;
    // 0x80126964: nop

    // 0x80126968: nop

    // 0x8012696C: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x80126970: mflo        $t0
    ctx->r8 = lo;
    // 0x80126974: sll         $t8, $t0, 3
    ctx->r24 = S32(ctx->r8 << 3);
    // 0x80126978: bne         $v0, $zero, L_80126984
    if (ctx->r2 != 0) {
        // 0x8012697C: nop
    
            goto L_80126984;
    }
    // 0x8012697C: nop

    // 0x80126980: break       7
    do_break(2148690304);
L_80126984:
    // 0x80126984: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80126988: bne         $v0, $at, L_8012699C
    if (ctx->r2 != ctx->r1) {
        // 0x8012698C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012699C;
    }
    // 0x8012698C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80126990: bne         $t7, $at, L_8012699C
    if (ctx->r15 != ctx->r1) {
        // 0x80126994: nop
    
            goto L_8012699C;
    }
    // 0x80126994: nop

    // 0x80126998: break       6
    do_break(2148690328);
L_8012699C:
    // 0x8012699C: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801269A0: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
    // 0x801269A4: andi        $t8, $t4, 0xFF
    ctx->r24 = ctx->r12 & 0XFF;
    // 0x801269A8: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x801269AC: mflo        $t6
    ctx->r14 = lo;
    // 0x801269B0: nop

    // 0x801269B4: nop

    // 0x801269B8: div         $zero, $t6, $v0
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r2)));
    // 0x801269BC: bne         $v0, $zero, L_801269C8
    if (ctx->r2 != 0) {
        // 0x801269C0: nop
    
            goto L_801269C8;
    }
    // 0x801269C0: nop

    // 0x801269C4: break       7
    do_break(2148690372);
L_801269C8:
    // 0x801269C8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801269CC: bne         $v0, $at, L_801269E0
    if (ctx->r2 != ctx->r1) {
        // 0x801269D0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801269E0;
    }
    // 0x801269D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801269D4: bne         $t6, $at, L_801269E0
    if (ctx->r14 != ctx->r1) {
        // 0x801269D8: nop
    
            goto L_801269E0;
    }
    // 0x801269D8: nop

    // 0x801269DC: break       6
    do_break(2148690396);
L_801269E0:
    // 0x801269E0: mflo        $t1
    ctx->r9 = lo;
    // 0x801269E4: sll         $t7, $t1, 3
    ctx->r15 = S32(ctx->r9 << 3);
    // 0x801269E8: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
    // 0x801269EC: beq         $v1, $zero, L_80126A4C
    if (ctx->r3 == 0) {
        // 0x801269F0: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80126A4C;
    }
    // 0x801269F0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801269F4: beq         $v1, $at, L_80126A14
    if (ctx->r3 == ctx->r1) {
        // 0x801269F8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80126A14;
    }
    // 0x801269F8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x801269FC: beq         $v1, $at, L_80126A24
    if (ctx->r3 == ctx->r1) {
        // 0x80126A00: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80126A24;
    }
    // 0x80126A00: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80126A04: beql        $v1, $at, L_80126A38
    if (ctx->r3 == ctx->r1) {
        // 0x80126A08: negu        $t2, $t2
        ctx->r10 = SUB32(0, ctx->r10);
            goto L_80126A38;
    }
    goto skip_8;
    // 0x80126A08: negu        $t2, $t2
    ctx->r10 = SUB32(0, ctx->r10);
    skip_8:
    // 0x80126A0C: b           L_80126A4C
    // 0x80126A10: nop

        goto L_80126A4C;
    // 0x80126A10: nop

L_80126A14:
    // 0x80126A14: negu        $t2, $t2
    ctx->r10 = SUB32(0, ctx->r10);
    // 0x80126A18: negu        $t3, $t3
    ctx->r11 = SUB32(0, ctx->r11);
    // 0x80126A1C: b           L_80126A4C
    // 0x80126A20: negu        $a2, $a2
    ctx->r6 = SUB32(0, ctx->r6);
        goto L_80126A4C;
    // 0x80126A20: negu        $a2, $a2
    ctx->r6 = SUB32(0, ctx->r6);
L_80126A24:
    // 0x80126A24: negu        $a3, $a3
    ctx->r7 = SUB32(0, ctx->r7);
    // 0x80126A28: negu        $t0, $t0
    ctx->r8 = SUB32(0, ctx->r8);
    // 0x80126A2C: b           L_80126A4C
    // 0x80126A30: negu        $t1, $t1
    ctx->r9 = SUB32(0, ctx->r9);
        goto L_80126A4C;
    // 0x80126A30: negu        $t1, $t1
    ctx->r9 = SUB32(0, ctx->r9);
    // 0x80126A34: negu        $t2, $t2
    ctx->r10 = SUB32(0, ctx->r10);
L_80126A38:
    // 0x80126A38: negu        $t3, $t3
    ctx->r11 = SUB32(0, ctx->r11);
    // 0x80126A3C: negu        $a2, $a2
    ctx->r6 = SUB32(0, ctx->r6);
    // 0x80126A40: negu        $a3, $a3
    ctx->r7 = SUB32(0, ctx->r7);
    // 0x80126A44: negu        $t0, $t0
    ctx->r8 = SUB32(0, ctx->r8);
    // 0x80126A48: negu        $t1, $t1
    ctx->r9 = SUB32(0, ctx->r9);
L_80126A4C:
    // 0x80126A4C: beq         $t4, $zero, L_80126B60
    if (ctx->r12 == 0) {
        // 0x80126A50: addu        $t6, $ra, $t9
        ctx->r14 = ADD32(ctx->r31, ctx->r25);
            goto L_80126B60;
    }
    // 0x80126A50: addu        $t6, $ra, $t9
    ctx->r14 = ADD32(ctx->r31, ctx->r25);
    // 0x80126A54: lh          $v0, 0x0($t6)
    ctx->r2 = MEM_H(ctx->r14, 0X0);
    // 0x80126A58: addiu       $t8, $t4, 0x40
    ctx->r24 = ADD32(ctx->r12, 0X40);
    // 0x80126A5C: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x80126A60: sra         $t7, $v0, 7
    ctx->r15 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80126A64: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x80126A68: multu       $v0, $a3
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126A6C: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x80126A70: addu        $t7, $ra, $t6
    ctx->r15 = ADD32(ctx->r31, ctx->r14);
    // 0x80126A74: lh          $v1, 0x0($t7)
    ctx->r3 = MEM_H(ctx->r15, 0X0);
    // 0x80126A78: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x80126A7C: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x80126A80: sra         $t8, $v1, 7
    ctx->r24 = S32(SIGNED(ctx->r3) >> 7);
    // 0x80126A84: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x80126A88: or          $t5, $a2, $zero
    ctx->r13 = ctx->r6 | 0;
    // 0x80126A8C: mflo        $t9
    ctx->r25 = lo;
    // 0x80126A90: nop

    // 0x80126A94: nop

    // 0x80126A98: multu       $t2, $t8
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126A9C: mflo        $t6
    ctx->r14 = lo;
    // 0x80126AA0: addu        $t2, $t9, $t6
    ctx->r10 = ADD32(ctx->r25, ctx->r14);
    // 0x80126AA4: sra         $t7, $t2, 8
    ctx->r15 = S32(SIGNED(ctx->r10) >> 8);
    // 0x80126AA8: multu       $v0, $t0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126AAC: or          $t2, $t7, $zero
    ctx->r10 = ctx->r15 | 0;
    // 0x80126AB0: mflo        $t8
    ctx->r24 = lo;
    // 0x80126AB4: nop

    // 0x80126AB8: nop

    // 0x80126ABC: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126AC0: mflo        $t9
    ctx->r25 = lo;
    // 0x80126AC4: addu        $t3, $t8, $t9
    ctx->r11 = ADD32(ctx->r24, ctx->r25);
    // 0x80126AC8: sra         $t6, $t3, 8
    ctx->r14 = S32(SIGNED(ctx->r11) >> 8);
    // 0x80126ACC: multu       $v0, $t1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126AD0: or          $t3, $t6, $zero
    ctx->r11 = ctx->r14 | 0;
    // 0x80126AD4: mflo        $t7
    ctx->r15 = lo;
    // 0x80126AD8: nop

    // 0x80126ADC: nop

    // 0x80126AE0: multu       $a2, $v1
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126AE4: mflo        $t8
    ctx->r24 = lo;
    // 0x80126AE8: addu        $a2, $t7, $t8
    ctx->r6 = ADD32(ctx->r15, ctx->r24);
    // 0x80126AEC: sra         $t9, $a2, 8
    ctx->r25 = S32(SIGNED(ctx->r6) >> 8);
    // 0x80126AF0: multu       $a3, $v1
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126AF4: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x80126AF8: mflo        $t6
    ctx->r14 = lo;
    // 0x80126AFC: nop

    // 0x80126B00: nop

    // 0x80126B04: multu       $v0, $a0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126B08: mflo        $t7
    ctx->r15 = lo;
    // 0x80126B0C: subu        $a3, $t6, $t7
    ctx->r7 = SUB32(ctx->r14, ctx->r15);
    // 0x80126B10: sra         $t8, $a3, 8
    ctx->r24 = S32(SIGNED(ctx->r7) >> 8);
    // 0x80126B14: multu       $t0, $v1
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126B18: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80126B1C: mflo        $t9
    ctx->r25 = lo;
    // 0x80126B20: nop

    // 0x80126B24: nop

    // 0x80126B28: multu       $v0, $a1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126B2C: mflo        $t6
    ctx->r14 = lo;
    // 0x80126B30: subu        $t0, $t9, $t6
    ctx->r8 = SUB32(ctx->r25, ctx->r14);
    // 0x80126B34: sra         $t7, $t0, 8
    ctx->r15 = S32(SIGNED(ctx->r8) >> 8);
    // 0x80126B38: multu       $t1, $v1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126B3C: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
    // 0x80126B40: mflo        $t8
    ctx->r24 = lo;
    // 0x80126B44: nop

    // 0x80126B48: nop

    // 0x80126B4C: multu       $v0, $t5
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126B50: mflo        $t9
    ctx->r25 = lo;
    // 0x80126B54: subu        $t1, $t8, $t9
    ctx->r9 = SUB32(ctx->r24, ctx->r25);
    // 0x80126B58: sra         $t6, $t1, 8
    ctx->r14 = S32(SIGNED(ctx->r9) >> 8);
    // 0x80126B5C: or          $t1, $t6, $zero
    ctx->r9 = ctx->r14 | 0;
L_80126B60:
    // 0x80126B60: lw          $t7, 0x6C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X6C);
    // 0x80126B64: lw          $t8, 0x68($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X68);
    // 0x80126B68: lw          $v1, 0x94($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X94);
    // 0x80126B6C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80126B70: lhu         $t9, 0x24($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X24);
    // 0x80126B74: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80126B78: lhu         $t7, 0x20($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X20);
    // 0x80126B7C: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80126B80: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80126B84: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80126B88: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80126B8C: lhu         $t9, 0x26($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X26);
    // 0x80126B90: lhu         $t7, 0x22($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X22);
    // 0x80126B94: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80126B98: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80126B9C: sw          $t8, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r24;
    // 0x80126BA0: lw          $t9, 0x64($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X64);
    // 0x80126BA4: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80126BA8: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80126BAC: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126BB0: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x80126BB4: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80126BB8: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126BBC: sw          $t9, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r25;
    // 0x80126BC0: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    // 0x80126BC4: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80126BC8: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    // 0x80126BCC: lhu         $t8, 0x20($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X20);
    // 0x80126BD0: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126BD4: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80126BD8: sw          $t9, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r25;
    // 0x80126BDC: lhu         $t6, 0x26($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X26);
    // 0x80126BE0: lhu         $t8, 0x22($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X22);
    // 0x80126BE4: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126BE8: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80126BEC: sw          $t9, 0x28($v1)
    MEM_W(0X28, ctx->r3) = ctx->r25;
    // 0x80126BF0: sw          $a2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r6;
    // 0x80126BF4: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80126BF8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126BFC: sw          $t7, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->r15;
    // 0x80126C00: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80126C04: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126C08: sw          $t9, 0x2C($v1)
    MEM_W(0X2C, ctx->r3) = ctx->r25;
    // 0x80126C0C: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x80126C10: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80126C14: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x80126C18: lhu         $t8, 0x20($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X20);
    // 0x80126C1C: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126C20: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80126C24: sw          $t9, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->r25;
    // 0x80126C28: lhu         $t6, 0x26($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X26);
    // 0x80126C2C: lhu         $t8, 0x22($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X22);
    // 0x80126C30: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126C34: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80126C38: sw          $t9, 0x30($v1)
    MEM_W(0X30, ctx->r3) = ctx->r25;
    // 0x80126C3C: sw          $t1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r9;
    // 0x80126C40: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80126C44: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126C48: sw          $t7, 0x14($v1)
    MEM_W(0X14, ctx->r3) = ctx->r15;
    // 0x80126C4C: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80126C50: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126C54: sw          $t9, 0x34($v1)
    MEM_W(0X34, ctx->r3) = ctx->r25;
    // 0x80126C58: lw          $t6, 0x30($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X30);
    // 0x80126C5C: lw          $t7, 0x2C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X2C);
    // 0x80126C60: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80126C64: lhu         $t8, 0x24($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X24);
    // 0x80126C68: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80126C6C: lhu         $t6, 0x20($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X20);
    // 0x80126C70: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126C74: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80126C78: sw          $t7, 0x18($v1)
    MEM_W(0X18, ctx->r3) = ctx->r15;
    // 0x80126C7C: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80126C80: lhu         $t6, 0x22($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X22);
    // 0x80126C84: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126C88: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80126C8C: sw          $t7, 0x38($v1)
    MEM_W(0X38, ctx->r3) = ctx->r15;
    // 0x80126C90: lw          $t8, 0x28($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X28);
    // 0x80126C94: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80126C98: lhu         $t9, 0x24($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X24);
    // 0x80126C9C: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80126CA0: ori         $t7, $t6, 0x1
    ctx->r15 = ctx->r14 | 0X1;
    // 0x80126CA4: sw          $t7, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r15;
    // 0x80126CA8: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80126CAC: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126CB0: sw          $t9, 0x3C($v1)
    MEM_W(0X3C, ctx->r3) = ctx->r25;
L_80126CB4:
    // 0x80126CB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80126CB8: addiu       $sp, $sp, 0x70
    ctx->r29 = ADD32(ctx->r29, 0X70);
    // 0x80126CBC: jr          $ra
    // 0x80126CC0: nop

    return;
    // 0x80126CC0: nop

;}
RECOMP_FUNC void func_80126CC4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80126CC4: addiu       $sp, $sp, -0x10
    ctx->r29 = ADD32(ctx->r29, -0X10);
    // 0x80126CC8: sw          $a0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r4;
    // 0x80126CCC: lw          $t0, 0x0($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X0);
    // 0x80126CD0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80126CD4: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80126CD8: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80126CDC: sh          $t1, 0xC($sp)
    MEM_H(0XC, ctx->r29) = ctx->r9;
    // 0x80126CE0: lw          $t2, 0x20($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X20);
    // 0x80126CE4: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x80126CE8: addiu       $t9, $t9, 0x2350
    ctx->r25 = ADD32(ctx->r25, 0X2350);
    // 0x80126CEC: sll         $t8, $a0, 1
    ctx->r24 = S32(ctx->r4 << 1);
    // 0x80126CF0: sra         $t3, $t2, 16
    ctx->r11 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80126CF4: addu        $v1, $t8, $t9
    ctx->r3 = ADD32(ctx->r24, ctx->r25);
    // 0x80126CF8: sh          $t3, 0xE($sp)
    MEM_H(0XE, ctx->r29) = ctx->r11;
    // 0x80126CFC: lh          $a2, 0x384($v1)
    ctx->r6 = MEM_H(ctx->r3, 0X384);
    // 0x80126D00: lw          $t6, 0xC($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XC);
    // 0x80126D04: lw          $t4, 0x0($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X0);
    // 0x80126D08: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80126D0C: multu       $a2, $t6
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126D10: sh          $t4, 0x8($sp)
    MEM_H(0X8, ctx->r29) = ctx->r12;
    // 0x80126D14: lw          $t5, 0x20($a1)
    ctx->r13 = MEM_W(ctx->r5, 0X20);
    // 0x80126D18: sh          $t5, 0xA($sp)
    MEM_H(0XA, ctx->r29) = ctx->r13;
    // 0x80126D1C: lw          $t8, 0x8($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X8);
    // 0x80126D20: mflo        $t7
    ctx->r15 = lo;
    // 0x80126D24: nop

    // 0x80126D28: nop

    // 0x80126D2C: multu       $v0, $t8
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126D30: mflo        $t9
    ctx->r25 = lo;
    // 0x80126D34: addu        $t0, $t7, $t9
    ctx->r8 = ADD32(ctx->r15, ctx->r25);
    // 0x80126D38: bgez        $t0, L_80126D48
    if (SIGNED(ctx->r8) >= 0) {
        // 0x80126D3C: sra         $t1, $t0, 8
        ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
            goto L_80126D48;
    }
    // 0x80126D3C: sra         $t1, $t0, 8
    ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
    // 0x80126D40: addiu       $at, $t0, 0xFF
    ctx->r1 = ADD32(ctx->r8, 0XFF);
    // 0x80126D44: sra         $t1, $at, 8
    ctx->r9 = S32(SIGNED(ctx->r1) >> 8);
L_80126D48:
    // 0x80126D48: multu       $a2, $t8
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126D4C: sw          $t1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r9;
    // 0x80126D50: lhu         $t7, 0x4($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X4);
    // 0x80126D54: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80126D58: mflo        $t2
    ctx->r10 = lo;
    // 0x80126D5C: nop

    // 0x80126D60: nop

    // 0x80126D64: multu       $v0, $t6
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126D68: mflo        $t3
    ctx->r11 = lo;
    // 0x80126D6C: subu        $t4, $t2, $t3
    ctx->r12 = SUB32(ctx->r10, ctx->r11);
    // 0x80126D70: bgez        $t4, L_80126D80
    if (SIGNED(ctx->r12) >= 0) {
        // 0x80126D74: sra         $t5, $t4, 8
        ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
            goto L_80126D80;
    }
    // 0x80126D74: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80126D78: addiu       $at, $t4, 0xFF
    ctx->r1 = ADD32(ctx->r12, 0XFF);
    // 0x80126D7C: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_80126D80:
    // 0x80126D80: sw          $t5, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r13;
    // 0x80126D84: lhu         $t0, 0x0($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X0);
    // 0x80126D88: lw          $t4, 0x8($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X8);
    // 0x80126D8C: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x80126D90: sw          $t1, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r9;
    // 0x80126D94: lhu         $t8, 0x6($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X6);
    // 0x80126D98: lhu         $t2, 0x2($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X2);
    // 0x80126D9C: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80126DA0: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80126DA4: or          $t3, $t6, $t2
    ctx->r11 = ctx->r14 | ctx->r10;
    // 0x80126DA8: sw          $t3, 0x20($a1)
    MEM_W(0X20, ctx->r5) = ctx->r11;
    // 0x80126DAC: sh          $t5, 0xC($sp)
    MEM_H(0XC, ctx->r29) = ctx->r13;
    // 0x80126DB0: lw          $t7, 0x28($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X28);
    // 0x80126DB4: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80126DB8: sh          $t9, 0xE($sp)
    MEM_H(0XE, ctx->r29) = ctx->r25;
    // 0x80126DBC: lw          $t8, 0xC($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XC);
    // 0x80126DC0: lw          $t0, 0x8($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X8);
    // 0x80126DC4: multu       $a2, $t8
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126DC8: sh          $t0, 0x8($sp)
    MEM_H(0X8, ctx->r29) = ctx->r8;
    // 0x80126DCC: lw          $t1, 0x28($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X28);
    // 0x80126DD0: sh          $t1, 0xA($sp)
    MEM_H(0XA, ctx->r29) = ctx->r9;
    // 0x80126DD4: lw          $t2, 0x8($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X8);
    // 0x80126DD8: mflo        $t6
    ctx->r14 = lo;
    // 0x80126DDC: nop

    // 0x80126DE0: nop

    // 0x80126DE4: multu       $v0, $t2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126DE8: mflo        $t3
    ctx->r11 = lo;
    // 0x80126DEC: addu        $t4, $t6, $t3
    ctx->r12 = ADD32(ctx->r14, ctx->r11);
    // 0x80126DF0: bgez        $t4, L_80126E00
    if (SIGNED(ctx->r12) >= 0) {
        // 0x80126DF4: sra         $t5, $t4, 8
        ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
            goto L_80126E00;
    }
    // 0x80126DF4: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80126DF8: addiu       $at, $t4, 0xFF
    ctx->r1 = ADD32(ctx->r12, 0XFF);
    // 0x80126DFC: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_80126E00:
    // 0x80126E00: multu       $a2, $t2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126E04: sw          $t5, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r13;
    // 0x80126E08: lhu         $t6, 0x4($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X4);
    // 0x80126E0C: sll         $t3, $t6, 16
    ctx->r11 = S32(ctx->r14 << 16);
    // 0x80126E10: mflo        $t7
    ctx->r15 = lo;
    // 0x80126E14: nop

    // 0x80126E18: nop

    // 0x80126E1C: multu       $v0, $t8
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126E20: mflo        $t9
    ctx->r25 = lo;
    // 0x80126E24: subu        $t0, $t7, $t9
    ctx->r8 = SUB32(ctx->r15, ctx->r25);
    // 0x80126E28: bgez        $t0, L_80126E38
    if (SIGNED(ctx->r8) >= 0) {
        // 0x80126E2C: sra         $t1, $t0, 8
        ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
            goto L_80126E38;
    }
    // 0x80126E2C: sra         $t1, $t0, 8
    ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
    // 0x80126E30: addiu       $at, $t0, 0xFF
    ctx->r1 = ADD32(ctx->r8, 0XFF);
    // 0x80126E34: sra         $t1, $at, 8
    ctx->r9 = S32(SIGNED(ctx->r1) >> 8);
L_80126E38:
    // 0x80126E38: sw          $t1, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r9;
    // 0x80126E3C: lhu         $t4, 0x0($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X0);
    // 0x80126E40: lw          $t0, 0x10($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X10);
    // 0x80126E44: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x80126E48: sw          $t5, 0x8($a1)
    MEM_W(0X8, ctx->r5) = ctx->r13;
    // 0x80126E4C: lhu         $t2, 0x6($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X6);
    // 0x80126E50: lhu         $t7, 0x2($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2);
    // 0x80126E54: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80126E58: sll         $t8, $t2, 16
    ctx->r24 = S32(ctx->r10 << 16);
    // 0x80126E5C: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x80126E60: sw          $t9, 0x28($a1)
    MEM_W(0X28, ctx->r5) = ctx->r25;
    // 0x80126E64: sh          $t1, 0xC($sp)
    MEM_H(0XC, ctx->r29) = ctx->r9;
    // 0x80126E68: lw          $t6, 0x30($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X30);
    // 0x80126E6C: sra         $t3, $t6, 16
    ctx->r11 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80126E70: sh          $t3, 0xE($sp)
    MEM_H(0XE, ctx->r29) = ctx->r11;
    // 0x80126E74: lw          $t2, 0xC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XC);
    // 0x80126E78: lw          $t4, 0x10($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X10);
    // 0x80126E7C: multu       $a2, $t2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126E80: sh          $t4, 0x8($sp)
    MEM_H(0X8, ctx->r29) = ctx->r12;
    // 0x80126E84: lw          $t5, 0x30($a1)
    ctx->r13 = MEM_W(ctx->r5, 0X30);
    // 0x80126E88: sh          $t5, 0xA($sp)
    MEM_H(0XA, ctx->r29) = ctx->r13;
    // 0x80126E8C: lw          $t7, 0x8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X8);
    // 0x80126E90: mflo        $t8
    ctx->r24 = lo;
    // 0x80126E94: nop

    // 0x80126E98: nop

    // 0x80126E9C: multu       $v0, $t7
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126EA0: mflo        $t9
    ctx->r25 = lo;
    // 0x80126EA4: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x80126EA8: bgez        $t0, L_80126EB8
    if (SIGNED(ctx->r8) >= 0) {
        // 0x80126EAC: sra         $t1, $t0, 8
        ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
            goto L_80126EB8;
    }
    // 0x80126EAC: sra         $t1, $t0, 8
    ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
    // 0x80126EB0: addiu       $at, $t0, 0xFF
    ctx->r1 = ADD32(ctx->r8, 0XFF);
    // 0x80126EB4: sra         $t1, $at, 8
    ctx->r9 = S32(SIGNED(ctx->r1) >> 8);
L_80126EB8:
    // 0x80126EB8: multu       $a2, $t7
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126EBC: sw          $t1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r9;
    // 0x80126EC0: lhu         $t8, 0x4($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X4);
    // 0x80126EC4: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80126EC8: mflo        $t6
    ctx->r14 = lo;
    // 0x80126ECC: nop

    // 0x80126ED0: nop

    // 0x80126ED4: multu       $v0, $t2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126ED8: mflo        $t3
    ctx->r11 = lo;
    // 0x80126EDC: subu        $t4, $t6, $t3
    ctx->r12 = SUB32(ctx->r14, ctx->r11);
    // 0x80126EE0: bgez        $t4, L_80126EF0
    if (SIGNED(ctx->r12) >= 0) {
        // 0x80126EE4: sra         $t5, $t4, 8
        ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
            goto L_80126EF0;
    }
    // 0x80126EE4: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80126EE8: addiu       $at, $t4, 0xFF
    ctx->r1 = ADD32(ctx->r12, 0XFF);
    // 0x80126EEC: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_80126EF0:
    // 0x80126EF0: sw          $t5, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r13;
    // 0x80126EF4: lhu         $t0, 0x0($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X0);
    // 0x80126EF8: lw          $t4, 0x18($a1)
    ctx->r12 = MEM_W(ctx->r5, 0X18);
    // 0x80126EFC: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x80126F00: sw          $t1, 0x10($a1)
    MEM_W(0X10, ctx->r5) = ctx->r9;
    // 0x80126F04: lhu         $t7, 0x6($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X6);
    // 0x80126F08: lhu         $t6, 0x2($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X2);
    // 0x80126F0C: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80126F10: sll         $t2, $t7, 16
    ctx->r10 = S32(ctx->r15 << 16);
    // 0x80126F14: or          $t3, $t2, $t6
    ctx->r11 = ctx->r10 | ctx->r14;
    // 0x80126F18: sw          $t3, 0x30($a1)
    MEM_W(0X30, ctx->r5) = ctx->r11;
    // 0x80126F1C: sh          $t5, 0xC($sp)
    MEM_H(0XC, ctx->r29) = ctx->r13;
    // 0x80126F20: lw          $t8, 0x38($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X38);
    // 0x80126F24: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80126F28: sh          $t9, 0xE($sp)
    MEM_H(0XE, ctx->r29) = ctx->r25;
    // 0x80126F2C: lw          $t7, 0xC($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XC);
    // 0x80126F30: lw          $t0, 0x18($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X18);
    // 0x80126F34: multu       $a2, $t7
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126F38: sh          $t0, 0x8($sp)
    MEM_H(0X8, ctx->r29) = ctx->r8;
    // 0x80126F3C: lw          $t1, 0x38($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X38);
    // 0x80126F40: sh          $t1, 0xA($sp)
    MEM_H(0XA, ctx->r29) = ctx->r9;
    // 0x80126F44: lw          $t6, 0x8($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X8);
    // 0x80126F48: mflo        $t2
    ctx->r10 = lo;
    // 0x80126F4C: nop

    // 0x80126F50: nop

    // 0x80126F54: multu       $v0, $t6
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126F58: mflo        $t3
    ctx->r11 = lo;
    // 0x80126F5C: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x80126F60: bgez        $t4, L_80126F70
    if (SIGNED(ctx->r12) >= 0) {
        // 0x80126F64: sra         $t5, $t4, 8
        ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
            goto L_80126F70;
    }
    // 0x80126F64: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80126F68: addiu       $at, $t4, 0xFF
    ctx->r1 = ADD32(ctx->r12, 0XFF);
    // 0x80126F6C: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_80126F70:
    // 0x80126F70: multu       $a2, $t6
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126F74: sw          $t5, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r13;
    // 0x80126F78: lhu         $t2, 0x4($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X4);
    // 0x80126F7C: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80126F80: mflo        $t8
    ctx->r24 = lo;
    // 0x80126F84: nop

    // 0x80126F88: nop

    // 0x80126F8C: multu       $v0, $t7
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80126F90: mflo        $t9
    ctx->r25 = lo;
    // 0x80126F94: subu        $t0, $t8, $t9
    ctx->r8 = SUB32(ctx->r24, ctx->r25);
    // 0x80126F98: bgez        $t0, L_80126FA8
    if (SIGNED(ctx->r8) >= 0) {
        // 0x80126F9C: sra         $t1, $t0, 8
        ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
            goto L_80126FA8;
    }
    // 0x80126F9C: sra         $t1, $t0, 8
    ctx->r9 = S32(SIGNED(ctx->r8) >> 8);
    // 0x80126FA0: addiu       $at, $t0, 0xFF
    ctx->r1 = ADD32(ctx->r8, 0XFF);
    // 0x80126FA4: sra         $t1, $at, 8
    ctx->r9 = S32(SIGNED(ctx->r1) >> 8);
L_80126FA8:
    // 0x80126FA8: sw          $t1, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r9;
    // 0x80126FAC: lhu         $t4, 0x0($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X0);
    // 0x80126FB0: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x80126FB4: sw          $t5, 0x18($a1)
    MEM_W(0X18, ctx->r5) = ctx->r13;
    // 0x80126FB8: lhu         $t6, 0x6($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X6);
    // 0x80126FBC: lhu         $t8, 0x2($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2);
    // 0x80126FC0: addiu       $sp, $sp, 0x10
    ctx->r29 = ADD32(ctx->r29, 0X10);
    // 0x80126FC4: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80126FC8: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80126FCC: jr          $ra
    // 0x80126FD0: sw          $t9, 0x38($a1)
    MEM_W(0X38, ctx->r5) = ctx->r25;
    return;
    // 0x80126FD0: sw          $t9, 0x38($a1)
    MEM_W(0X38, ctx->r5) = ctx->r25;
;}
RECOMP_FUNC void func_80126FD4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80126FD4: addiu       $sp, $sp, -0x78
    ctx->r29 = ADD32(ctx->r29, -0X78);
    // 0x80126FD8: lw          $t8, 0x88($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X88);
    // 0x80126FDC: addu        $t6, $a0, $a3
    ctx->r14 = ADD32(ctx->r4, ctx->r7);
    // 0x80126FE0: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80126FE4: sw          $t7, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r15;
    // 0x80126FE8: lw          $t7, 0x8C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X8C);
    // 0x80126FEC: addu        $t9, $a1, $t8
    ctx->r25 = ADD32(ctx->r5, ctx->r24);
    // 0x80126FF0: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80126FF4: sw          $t6, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r14;
    // 0x80126FF8: addu        $t9, $a2, $t7
    ctx->r25 = ADD32(ctx->r6, ctx->r15);
    // 0x80126FFC: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80127000: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    // 0x80127004: sra         $t9, $a0, 8
    ctx->r25 = S32(SIGNED(ctx->r4) >> 8);
    // 0x80127008: sra         $t6, $a1, 8
    ctx->r14 = S32(SIGNED(ctx->r5) >> 8);
    // 0x8012700C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80127010: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80127014: sra         $t9, $a2, 8
    ctx->r25 = S32(SIGNED(ctx->r6) >> 8);
    // 0x80127018: sra         $t6, $a3, 8
    ctx->r14 = S32(SIGNED(ctx->r7) >> 8);
    // 0x8012701C: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x80127020: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80127024: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x80127028: subu        $t8, $a3, $a0
    ctx->r24 = SUB32(ctx->r7, ctx->r4);
    // 0x8012702C: sra         $t6, $t7, 8
    ctx->r14 = S32(SIGNED(ctx->r15) >> 8);
    // 0x80127030: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80127034: sw          $t9, 0x88($sp)
    MEM_W(0X88, ctx->r29) = ctx->r25;
    // 0x80127038: sw          $t6, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r14;
    // 0x8012703C: bne         $t8, $zero, L_8012706C
    if (ctx->r24 != 0) {
        // 0x80127040: sw          $t8, 0x24($sp)
        MEM_W(0X24, ctx->r29) = ctx->r24;
            goto L_8012706C;
    }
    // 0x80127040: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80127044: subu        $t2, $t9, $a1
    ctx->r10 = SUB32(ctx->r25, ctx->r5);
    // 0x80127048: bne         $t2, $zero, L_8012706C
    if (ctx->r10 != 0) {
        // 0x8012704C: addiu       $t3, $zero, 0x400
        ctx->r11 = ADD32(0, 0X400);
            goto L_8012706C;
    }
    // 0x8012704C: addiu       $t3, $zero, 0x400
    ctx->r11 = ADD32(0, 0X400);
    // 0x80127050: subu        $t8, $t6, $a2
    ctx->r24 = SUB32(ctx->r14, ctx->r6);
    // 0x80127054: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x80127058: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8012705C: addiu       $t0, $zero, -0x400
    ctx->r8 = ADD32(0, -0X400);
    // 0x80127060: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80127064: b           L_80127174
    // 0x80127068: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
        goto L_80127174;
    // 0x80127068: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
L_8012706C:
    // 0x8012706C: lw          $t7, 0x88($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X88);
    // 0x80127070: lw          $v0, 0x24($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X24);
    // 0x80127074: lw          $t9, 0x8C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X8C);
    // 0x80127078: subu        $t2, $t7, $a1
    ctx->r10 = SUB32(ctx->r15, ctx->r5);
    // 0x8012707C: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x80127080: or          $t3, $t2, $zero
    ctx->r11 = ctx->r10 | 0;
    // 0x80127084: bgez        $t2, L_80127094
    if (SIGNED(ctx->r10) >= 0) {
        // 0x80127088: or          $t4, $v0, $zero
        ctx->r12 = ctx->r2 | 0;
            goto L_80127094;
    }
    // 0x80127088: or          $t4, $v0, $zero
    ctx->r12 = ctx->r2 | 0;
    // 0x8012708C: negu        $t3, $t2
    ctx->r11 = SUB32(0, ctx->r10);
    // 0x80127090: negu        $t4, $v0
    ctx->r12 = SUB32(0, ctx->r2);
L_80127094:
    // 0x80127094: subu        $t6, $t9, $a2
    ctx->r14 = SUB32(ctx->r25, ctx->r6);
    // 0x80127098: multu       $t4, $t6
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012709C: lw          $t8, 0x24($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X24);
    // 0x801270A0: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x801270A4: mflo        $v1
    ctx->r3 = lo;
    // 0x801270A8: bgez        $v1, L_801270B8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x801270AC: sra         $v0, $v1, 9
        ctx->r2 = S32(SIGNED(ctx->r3) >> 9);
            goto L_801270B8;
    }
    // 0x801270AC: sra         $v0, $v1, 9
    ctx->r2 = S32(SIGNED(ctx->r3) >> 9);
    // 0x801270B0: addiu       $at, $v1, 0x1FF
    ctx->r1 = ADD32(ctx->r3, 0X1FF);
    // 0x801270B4: sra         $v0, $at, 9
    ctx->r2 = S32(SIGNED(ctx->r1) >> 9);
L_801270B8:
    // 0x801270B8: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x801270BC: multu       $t6, $t3
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801270C0: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    // 0x801270C4: mflo        $a0
    ctx->r4 = lo;
    // 0x801270C8: bgez        $a0, L_801270D8
    if (SIGNED(ctx->r4) >= 0) {
        // 0x801270CC: sra         $t5, $a0, 9
        ctx->r13 = S32(SIGNED(ctx->r4) >> 9);
            goto L_801270D8;
    }
    // 0x801270CC: sra         $t5, $a0, 9
    ctx->r13 = S32(SIGNED(ctx->r4) >> 9);
    // 0x801270D0: addiu       $at, $a0, 0x1FF
    ctx->r1 = ADD32(ctx->r4, 0X1FF);
    // 0x801270D4: sra         $t5, $at, 9
    ctx->r13 = S32(SIGNED(ctx->r1) >> 9);
L_801270D8:
    // 0x801270D8: multu       $t8, $t4
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801270DC: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x801270E0: mflo        $t7
    ctx->r15 = lo;
    // 0x801270E4: nop

    // 0x801270E8: nop

    // 0x801270EC: multu       $t2, $t3
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801270F0: mflo        $t9
    ctx->r25 = lo;
    // 0x801270F4: subu        $a1, $t7, $t9
    ctx->r5 = SUB32(ctx->r15, ctx->r25);
    // 0x801270F8: bgez        $a1, L_80127108
    if (SIGNED(ctx->r5) >= 0) {
        // 0x801270FC: sra         $ra, $a1, 9
        ctx->r31 = S32(SIGNED(ctx->r5) >> 9);
            goto L_80127108;
    }
    // 0x801270FC: sra         $ra, $a1, 9
    ctx->r31 = S32(SIGNED(ctx->r5) >> 9);
    // 0x80127100: addiu       $at, $a1, 0x1FF
    ctx->r1 = ADD32(ctx->r5, 0X1FF);
    // 0x80127104: sra         $ra, $at, 9
    ctx->r31 = S32(SIGNED(ctx->r1) >> 9);
L_80127108:
    // 0x80127108: bne         $v0, $zero, L_8012712C
    if (ctx->r2 != 0) {
        // 0x8012710C: or          $t1, $ra, $zero
        ctx->r9 = ctx->r31 | 0;
            goto L_8012712C;
    }
    // 0x8012710C: or          $t1, $ra, $zero
    ctx->r9 = ctx->r31 | 0;
    // 0x80127110: bgez        $v1, L_80127120
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80127114: nop
    
            goto L_80127120;
    }
    // 0x80127114: nop

    // 0x80127118: b           L_8012712C
    // 0x8012711C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
        goto L_8012712C;
    // 0x8012711C: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
L_80127120:
    // 0x80127120: blez        $v1, L_8012712C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80127124: nop
    
            goto L_8012712C;
    }
    // 0x80127124: nop

    // 0x80127128: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
L_8012712C:
    // 0x8012712C: bne         $t5, $zero, L_80127150
    if (ctx->r13 != 0) {
        // 0x80127130: nop
    
            goto L_80127150;
    }
    // 0x80127130: nop

    // 0x80127134: bgez        $a0, L_80127144
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80127138: nop
    
            goto L_80127144;
    }
    // 0x80127138: nop

    // 0x8012713C: b           L_80127150
    // 0x80127140: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
        goto L_80127150;
    // 0x80127140: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
L_80127144:
    // 0x80127144: blez        $a0, L_80127150
    if (SIGNED(ctx->r4) <= 0) {
        // 0x80127148: nop
    
            goto L_80127150;
    }
    // 0x80127148: nop

    // 0x8012714C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
L_80127150:
    // 0x80127150: bnel        $ra, $zero, L_80127178
    if (ctx->r31 != 0) {
        // 0x80127154: lw          $t6, 0x24($sp)
        ctx->r14 = MEM_W(ctx->r29, 0X24);
            goto L_80127178;
    }
    goto skip_0;
    // 0x80127154: lw          $t6, 0x24($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x80127158: bgez        $a1, L_80127168
    if (SIGNED(ctx->r5) >= 0) {
        // 0x8012715C: nop
    
            goto L_80127168;
    }
    // 0x8012715C: nop

    // 0x80127160: b           L_80127174
    // 0x80127164: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
        goto L_80127174;
    // 0x80127164: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
L_80127168:
    // 0x80127168: blezl       $a1, L_80127178
    if (SIGNED(ctx->r5) <= 0) {
        // 0x8012716C: lw          $t6, 0x24($sp)
        ctx->r14 = MEM_W(ctx->r29, 0X24);
            goto L_80127178;
    }
    goto skip_1;
    // 0x8012716C: lw          $t6, 0x24($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X24);
    skip_1:
    // 0x80127170: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
L_80127174:
    // 0x80127174: lw          $t6, 0x24($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X24);
L_80127178:
    // 0x80127178: mtc1        $t2, $f6
    ctx->f6.u32l = ctx->r10;
    // 0x8012717C: lw          $t8, 0x1C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X1C);
    // 0x80127180: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80127184: cvt.s.w     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    ctx->f2.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80127188: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x8012718C: sw          $a3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r7;
    // 0x80127190: sw          $t0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r8;
    // 0x80127194: sw          $t1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r9;
    // 0x80127198: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012719C: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x801271A0: sw          $t3, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r11;
    // 0x801271A4: sw          $t4, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r12;
    // 0x801271A8: cvt.s.w     $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    ctx->f14.fl = CVT_S_W(ctx->f8.u32l);
    // 0x801271AC: mul.s       $f10, $f0, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x801271B0: nop

    // 0x801271B4: mul.s       $f18, $f2, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x801271B8: add.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl + ctx->f18.fl;
    // 0x801271BC: mul.s       $f6, $f14, $f14
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f6.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x801271C0: jal         0x80137E10
    // 0x801271C4: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x801271C4: add.s       $f12, $f4, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f4.fl + ctx->f6.fl;
    after_0:
    // 0x801271C8: lw          $t3, 0x68($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X68);
    // 0x801271CC: lw          $t4, 0x64($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X64);
    // 0x801271D0: trunc.w.s   $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x801271D4: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x801271D8: mtc1        $t4, $f18
    ctx->f18.u32l = ctx->r12;
    // 0x801271DC: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x801271E0: cvt.s.w     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
    // 0x801271E4: mfc1        $a2, $f8
    ctx->r6 = (int32_t)ctx->f8.u32l;
    // 0x801271E8: nop

    // 0x801271EC: sw          $a2, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r6;
    // 0x801271F0: cvt.s.w     $f14, $f18
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 18);
    ctx->f14.fl = CVT_S_W(ctx->f18.u32l);
    // 0x801271F4: mul.s       $f6, $f2, $f2
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f6.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x801271F8: nop

    // 0x801271FC: mul.s       $f8, $f14, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x80127200: cvt.s.w     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80127204: add.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f8.fl;
    // 0x80127208: mul.s       $f18, $f16, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x8012720C: jal         0x80137E10
    // 0x80127210: add.s       $f12, $f10, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f10.fl + ctx->f18.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_1;
    // 0x80127210: add.s       $f12, $f10, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f10.fl + ctx->f18.fl;
    after_1:
    // 0x80127214: lw          $a3, 0x5C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X5C);
    // 0x80127218: lw          $t0, 0x58($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X58);
    // 0x8012721C: lw          $t1, 0x54($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X54);
    // 0x80127220: mtc1        $a3, $f6
    ctx->f6.u32l = ctx->r7;
    // 0x80127224: mtc1        $t0, $f8
    ctx->f8.u32l = ctx->r8;
    // 0x80127228: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8012722C: mtc1        $t1, $f10
    ctx->f10.u32l = ctx->r9;
    // 0x80127230: cvt.s.w     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    ctx->f2.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80127234: mfc1        $v1, $f4
    ctx->r3 = (int32_t)ctx->f4.u32l;
    // 0x80127238: nop

    // 0x8012723C: sw          $v1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r3;
    // 0x80127240: cvt.s.w     $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    ctx->f14.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80127244: mul.s       $f18, $f2, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x80127248: nop

    // 0x8012724C: mul.s       $f4, $f14, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x80127250: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80127254: add.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x80127258: mul.s       $f8, $f16, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x8012725C: jal         0x80137E10
    // 0x80127260: add.s       $f12, $f6, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f6.fl + ctx->f8.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_2;
    // 0x80127260: add.s       $f12, $f6, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f12.fl = ctx->f6.fl + ctx->f8.fl;
    after_2:
    // 0x80127264: lw          $a2, 0x44($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X44);
    // 0x80127268: lw          $v1, 0x40($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X40);
    // 0x8012726C: lw          $a3, 0x5C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X5C);
    // 0x80127270: lw          $t0, 0x58($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X58);
    // 0x80127274: lw          $t1, 0x54($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X54);
    // 0x80127278: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
    // 0x8012727C: lw          $t3, 0x68($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X68);
    // 0x80127280: bne         $a2, $zero, L_80127290
    if (ctx->r6 != 0) {
        // 0x80127284: lw          $t4, 0x64($sp)
        ctx->r12 = MEM_W(ctx->r29, 0X64);
            goto L_80127290;
    }
    // 0x80127284: lw          $t4, 0x64($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X64);
    // 0x80127288: b           L_80127630
    // 0x8012728C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80127630;
    // 0x8012728C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80127290:
    // 0x80127290: bnel        $v1, $zero, L_801272A4
    if (ctx->r3 != 0) {
        // 0x80127294: trunc.w.s   $f10, $f0
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = TRUNC_W_S(ctx->f0.fl);
            goto L_801272A4;
    }
    goto skip_2;
    // 0x80127294: trunc.w.s   $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = TRUNC_W_S(ctx->f0.fl);
    skip_2:
    // 0x80127298: b           L_80127630
    // 0x8012729C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80127630;
    // 0x8012729C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x801272A0: trunc.w.s   $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = TRUNC_W_S(ctx->f0.fl);
L_801272A4:
    // 0x801272A4: lw          $a1, 0x90($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X90);
    // 0x801272A8: lw          $t8, 0x24($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X24);
    // 0x801272AC: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x801272B0: nop

    // 0x801272B4: bne         $v0, $zero, L_801272C4
    if (ctx->r2 != 0) {
        // 0x801272B8: nop
    
            goto L_801272C4;
    }
    // 0x801272B8: nop

    // 0x801272BC: b           L_80127630
    // 0x801272C0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80127630;
    // 0x801272C0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_801272C4:
    // 0x801272C4: multu       $t8, $a1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801272C8: lw          $t6, 0x1C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X1C);
    // 0x801272CC: lw          $a0, 0x94($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X94);
    // 0x801272D0: mflo        $t7
    ctx->r15 = lo;
    // 0x801272D4: nop

    // 0x801272D8: nop

    // 0x801272DC: div         $zero, $t7, $a2
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r6)));
    // 0x801272E0: mflo        $t5
    ctx->r13 = lo;
    // 0x801272E4: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    // 0x801272E8: bne         $a2, $zero, L_801272F4
    if (ctx->r6 != 0) {
        // 0x801272EC: nop
    
            goto L_801272F4;
    }
    // 0x801272EC: nop

    // 0x801272F0: break       7
    do_break(2148692720);
L_801272F4:
    // 0x801272F4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801272F8: bne         $a2, $at, L_8012730C
    if (ctx->r6 != ctx->r1) {
        // 0x801272FC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012730C;
    }
    // 0x801272FC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127300: bne         $t7, $at, L_8012730C
    if (ctx->r15 != ctx->r1) {
        // 0x80127304: nop
    
            goto L_8012730C;
    }
    // 0x80127304: nop

    // 0x80127308: break       6
    do_break(2148692744);
L_8012730C:
    // 0x8012730C: multu       $t2, $a1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127310: mflo        $t9
    ctx->r25 = lo;
    // 0x80127314: nop

    // 0x80127318: nop

    // 0x8012731C: div         $zero, $t9, $a2
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r6)));
    // 0x80127320: mflo        $ra
    ctx->r31 = lo;
    // 0x80127324: sw          $ra, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r31;
    // 0x80127328: bne         $a2, $zero, L_80127334
    if (ctx->r6 != 0) {
        // 0x8012732C: nop
    
            goto L_80127334;
    }
    // 0x8012732C: nop

    // 0x80127330: break       7
    do_break(2148692784);
L_80127334:
    // 0x80127334: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127338: bne         $a2, $at, L_8012734C
    if (ctx->r6 != ctx->r1) {
        // 0x8012733C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012734C;
    }
    // 0x8012733C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127340: bne         $t9, $at, L_8012734C
    if (ctx->r25 != ctx->r1) {
        // 0x80127344: nop
    
            goto L_8012734C;
    }
    // 0x80127344: nop

    // 0x80127348: break       6
    do_break(2148692808);
L_8012734C:
    // 0x8012734C: multu       $t6, $a1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127350: mflo        $t8
    ctx->r24 = lo;
    // 0x80127354: nop

    // 0x80127358: nop

    // 0x8012735C: div         $zero, $t8, $a2
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r6)));
    // 0x80127360: mflo        $t7
    ctx->r15 = lo;
    // 0x80127364: sw          $t7, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r15;
    // 0x80127368: bne         $a2, $zero, L_80127374
    if (ctx->r6 != 0) {
        // 0x8012736C: nop
    
            goto L_80127374;
    }
    // 0x8012736C: nop

    // 0x80127370: break       7
    do_break(2148692848);
L_80127374:
    // 0x80127374: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127378: bne         $a2, $at, L_8012738C
    if (ctx->r6 != ctx->r1) {
        // 0x8012737C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012738C;
    }
    // 0x8012737C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127380: bne         $t8, $at, L_8012738C
    if (ctx->r24 != ctx->r1) {
        // 0x80127384: nop
    
            goto L_8012738C;
    }
    // 0x80127384: nop

    // 0x80127388: break       6
    do_break(2148692872);
L_8012738C:
    // 0x8012738C: multu       $t3, $a0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127390: mflo        $t9
    ctx->r25 = lo;
    // 0x80127394: nop

    // 0x80127398: nop

    // 0x8012739C: div         $zero, $t9, $v1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r3)));
    // 0x801273A0: mflo        $t3
    ctx->r11 = lo;
    // 0x801273A4: bne         $v1, $zero, L_801273B0
    if (ctx->r3 != 0) {
        // 0x801273A8: nop
    
            goto L_801273B0;
    }
    // 0x801273A8: nop

    // 0x801273AC: break       7
    do_break(2148692908);
L_801273B0:
    // 0x801273B0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801273B4: bne         $v1, $at, L_801273C8
    if (ctx->r3 != ctx->r1) {
        // 0x801273B8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801273C8;
    }
    // 0x801273B8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801273BC: bne         $t9, $at, L_801273C8
    if (ctx->r25 != ctx->r1) {
        // 0x801273C0: nop
    
            goto L_801273C8;
    }
    // 0x801273C0: nop

    // 0x801273C4: break       6
    do_break(2148692932);
L_801273C8:
    // 0x801273C8: multu       $t4, $a0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801273CC: mflo        $t6
    ctx->r14 = lo;
    // 0x801273D0: nop

    // 0x801273D4: nop

    // 0x801273D8: div         $zero, $t6, $v1
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r3)));
    // 0x801273DC: mflo        $t4
    ctx->r12 = lo;
    // 0x801273E0: bne         $v1, $zero, L_801273EC
    if (ctx->r3 != 0) {
        // 0x801273E4: nop
    
            goto L_801273EC;
    }
    // 0x801273E4: nop

    // 0x801273E8: break       7
    do_break(2148692968);
L_801273EC:
    // 0x801273EC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801273F0: bne         $v1, $at, L_80127404
    if (ctx->r3 != ctx->r1) {
        // 0x801273F4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127404;
    }
    // 0x801273F4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801273F8: bne         $t6, $at, L_80127404
    if (ctx->r14 != ctx->r1) {
        // 0x801273FC: nop
    
            goto L_80127404;
    }
    // 0x801273FC: nop

    // 0x80127400: break       6
    do_break(2148692992);
L_80127404:
    // 0x80127404: div         $zero, $zero, $v1
    lo = S32(S64(S32(0)) / S64(S32(ctx->r3))); hi = S32(S64(S32(0)) % S64(S32(ctx->r3)));
    // 0x80127408: mflo        $t8
    ctx->r24 = lo;
    // 0x8012740C: sw          $t8, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r24;
    // 0x80127410: bne         $v1, $zero, L_8012741C
    if (ctx->r3 != 0) {
        // 0x80127414: nop
    
            goto L_8012741C;
    }
    // 0x80127414: nop

    // 0x80127418: break       7
    do_break(2148693016);
L_8012741C:
    // 0x8012741C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127420: bne         $v1, $at, L_80127434
    if (ctx->r3 != ctx->r1) {
        // 0x80127424: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127434;
    }
    // 0x80127424: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127428: bne         $zero, $at, L_80127434
    if (0 != ctx->r1) {
        // 0x8012742C: nop
    
            goto L_80127434;
    }
    // 0x8012742C: nop

    // 0x80127430: break       6
    do_break(2148693040);
L_80127434:
    // 0x80127434: multu       $a3, $a0
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127438: lhu         $t8, 0x2C($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2C);
    // 0x8012743C: lw          $v1, 0x98($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X98);
    // 0x80127440: mflo        $t7
    ctx->r15 = lo;
    // 0x80127444: nop

    // 0x80127448: nop

    // 0x8012744C: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x80127450: mflo        $a3
    ctx->r7 = lo;
    // 0x80127454: bne         $v0, $zero, L_80127460
    if (ctx->r2 != 0) {
        // 0x80127458: nop
    
            goto L_80127460;
    }
    // 0x80127458: nop

    // 0x8012745C: break       7
    do_break(2148693084);
L_80127460:
    // 0x80127460: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127464: bne         $v0, $at, L_80127478
    if (ctx->r2 != ctx->r1) {
        // 0x80127468: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127478;
    }
    // 0x80127468: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012746C: bne         $t7, $at, L_80127478
    if (ctx->r15 != ctx->r1) {
        // 0x80127470: nop
    
            goto L_80127478;
    }
    // 0x80127470: nop

    // 0x80127474: break       6
    do_break(2148693108);
L_80127478:
    // 0x80127478: multu       $t0, $a0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012747C: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x80127480: mflo        $t9
    ctx->r25 = lo;
    // 0x80127484: nop

    // 0x80127488: nop

    // 0x8012748C: div         $zero, $t9, $v0
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r2)));
    // 0x80127490: mflo        $t0
    ctx->r8 = lo;
    // 0x80127494: bne         $v0, $zero, L_801274A0
    if (ctx->r2 != 0) {
        // 0x80127498: nop
    
            goto L_801274A0;
    }
    // 0x80127498: nop

    // 0x8012749C: break       7
    do_break(2148693148);
L_801274A0:
    // 0x801274A0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801274A4: bne         $v0, $at, L_801274B8
    if (ctx->r2 != ctx->r1) {
        // 0x801274A8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801274B8;
    }
    // 0x801274A8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801274AC: bne         $t9, $at, L_801274B8
    if (ctx->r25 != ctx->r1) {
        // 0x801274B0: nop
    
            goto L_801274B8;
    }
    // 0x801274B0: nop

    // 0x801274B4: break       6
    do_break(2148693172);
L_801274B8:
    // 0x801274B8: multu       $t1, $a0
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801274BC: lhu         $t9, 0x28($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X28);
    // 0x801274C0: mflo        $t6
    ctx->r14 = lo;
    // 0x801274C4: nop

    // 0x801274C8: nop

    // 0x801274CC: div         $zero, $t6, $v0
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r2)));
    // 0x801274D0: bne         $v0, $zero, L_801274DC
    if (ctx->r2 != 0) {
        // 0x801274D4: nop
    
            goto L_801274DC;
    }
    // 0x801274D4: nop

    // 0x801274D8: break       7
    do_break(2148693208);
L_801274DC:
    // 0x801274DC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801274E0: bne         $v0, $at, L_801274F4
    if (ctx->r2 != ctx->r1) {
        // 0x801274E4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801274F4;
    }
    // 0x801274E4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801274E8: bne         $t6, $at, L_801274F4
    if (ctx->r14 != ctx->r1) {
        // 0x801274EC: nop
    
            goto L_801274F4;
    }
    // 0x801274EC: nop

    // 0x801274F0: break       6
    do_break(2148693232);
L_801274F4:
    // 0x801274F4: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x801274F8: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x801274FC: lhu         $t8, 0x2E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2E);
    // 0x80127500: lhu         $t9, 0x2A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127504: mflo        $t1
    ctx->r9 = lo;
    // 0x80127508: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x8012750C: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x80127510: sw          $t6, 0x20($v1)
    MEM_W(0X20, ctx->r3) = ctx->r14;
    // 0x80127514: lw          $t8, 0x6C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X6C);
    // 0x80127518: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8012751C: sw          $t8, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r24;
    // 0x80127520: lhu         $t7, 0x2C($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2C);
    // 0x80127524: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80127528: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8012752C: lhu         $t6, 0x2E($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X2E);
    // 0x80127530: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x80127534: sw          $t8, 0x24($v1)
    MEM_W(0X24, ctx->r3) = ctx->r24;
    // 0x80127538: sw          $t3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r11;
    // 0x8012753C: lhu         $t7, 0x2C($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2C);
    // 0x80127540: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    // 0x80127544: lhu         $t6, 0x28($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X28);
    // 0x80127548: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8012754C: or          $t8, $t9, $t6
    ctx->r24 = ctx->r25 | ctx->r14;
    // 0x80127550: sw          $t8, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r24;
    // 0x80127554: lhu         $t7, 0x2E($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2E);
    // 0x80127558: lhu         $t6, 0x2A($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X2A);
    // 0x8012755C: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80127560: or          $t8, $t9, $t6
    ctx->r24 = ctx->r25 | ctx->r14;
    // 0x80127564: sw          $t8, 0x28($v1)
    MEM_W(0X28, ctx->r3) = ctx->r24;
    // 0x80127568: lw          $t7, 0x60($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X60);
    // 0x8012756C: sw          $t7, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r15;
    // 0x80127570: lhu         $t9, 0x2C($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2C);
    // 0x80127574: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80127578: sw          $t6, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->r14;
    // 0x8012757C: lhu         $t8, 0x2E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2E);
    // 0x80127580: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x80127584: sw          $t7, 0x2C($v1)
    MEM_W(0X2C, ctx->r3) = ctx->r15;
    // 0x80127588: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x8012758C: lhu         $t9, 0x2C($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2C);
    // 0x80127590: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    // 0x80127594: lhu         $t8, 0x28($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X28);
    // 0x80127598: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x8012759C: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x801275A0: sw          $t7, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->r15;
    // 0x801275A4: lhu         $t9, 0x2E($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2E);
    // 0x801275A8: lhu         $t8, 0x2A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2A);
    // 0x801275AC: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x801275B0: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x801275B4: sw          $t7, 0x30($v1)
    MEM_W(0X30, ctx->r3) = ctx->r15;
    // 0x801275B8: sw          $t1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r9;
    // 0x801275BC: lhu         $t9, 0x2C($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2C);
    // 0x801275C0: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x801275C4: sw          $t6, 0x14($v1)
    MEM_W(0X14, ctx->r3) = ctx->r14;
    // 0x801275C8: lhu         $t8, 0x2E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2E);
    // 0x801275CC: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x801275D0: sw          $t7, 0x34($v1)
    MEM_W(0X34, ctx->r3) = ctx->r15;
    // 0x801275D4: lw          $t9, 0x38($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X38);
    // 0x801275D8: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x801275DC: sw          $t9, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r25;
    // 0x801275E0: lhu         $t8, 0x2C($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2C);
    // 0x801275E4: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x801275E8: lhu         $t9, 0x28($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X28);
    // 0x801275EC: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x801275F0: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x801275F4: sw          $t6, 0x18($v1)
    MEM_W(0X18, ctx->r3) = ctx->r14;
    // 0x801275F8: lhu         $t8, 0x2E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2E);
    // 0x801275FC: lhu         $t9, 0x2A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127600: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x80127604: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x80127608: sw          $t6, 0x38($v1)
    MEM_W(0X38, ctx->r3) = ctx->r14;
    // 0x8012760C: lw          $t8, 0x30($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X30);
    // 0x80127610: sw          $t8, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r24;
    // 0x80127614: lhu         $t7, 0x2C($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2C);
    // 0x80127618: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x8012761C: ori         $t6, $t9, 0x1
    ctx->r14 = ctx->r25 | 0X1;
    // 0x80127620: sw          $t6, 0x1C($v1)
    MEM_W(0X1C, ctx->r3) = ctx->r14;
    // 0x80127624: lhu         $t8, 0x2E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2E);
    // 0x80127628: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x8012762C: sw          $t7, 0x3C($v1)
    MEM_W(0X3C, ctx->r3) = ctx->r15;
L_80127630:
    // 0x80127630: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80127634: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
    // 0x80127638: jr          $ra
    // 0x8012763C: nop

    return;
    // 0x8012763C: nop

;}
RECOMP_FUNC void func_80127640(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80127640: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x80127644: lh          $t6, 0x72($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X72);
    // 0x80127648: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x8012764C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80127650: andi        $t7, $t6, 0xFF
    ctx->r15 = ctx->r14 & 0XFF;
    // 0x80127654: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80127658: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x8012765C: lh          $t9, 0x2C78($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2C78);
    // 0x80127660: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x80127664: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80127668: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8012766C: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x80127670: sw          $a3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r7;
    // 0x80127674: sra         $a1, $t9, 7
    ctx->r5 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80127678: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x8012767C: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x80127680: jal         0x80137BF4
    // 0x80127684: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    __ll_lshift_recomp(rdram, ctx);
        goto after_0;
    // 0x80127684: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    after_0:
    // 0x80127688: lh          $t2, 0x72($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X72);
    // 0x8012768C: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80127690: sw          $v0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r2;
    // 0x80127694: addiu       $t3, $t2, 0x40
    ctx->r11 = ADD32(ctx->r10, 0X40);
    // 0x80127698: andi        $t4, $t3, 0xFF
    ctx->r12 = ctx->r11 & 0XFF;
    // 0x8012769C: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x801276A0: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x801276A4: lh          $t6, 0x2C78($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C78);
    // 0x801276A8: sw          $v1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r3;
    // 0x801276AC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801276B0: sra         $a1, $t6, 7
    ctx->r5 = S32(SIGNED(ctx->r14) >> 7);
    // 0x801276B4: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x801276B8: jal         0x80137BF4
    // 0x801276BC: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    __ll_lshift_recomp(rdram, ctx);
        goto after_1;
    // 0x801276BC: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    after_1:
    // 0x801276C0: lh          $t8, 0x72($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X72);
    // 0x801276C4: lh          $t9, 0x82($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X82);
    // 0x801276C8: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x801276CC: sw          $v0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r2;
    // 0x801276D0: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x801276D4: andi        $t1, $t0, 0xFF
    ctx->r9 = ctx->r8 & 0XFF;
    // 0x801276D8: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x801276DC: sra         $t0, $t2, 16
    ctx->r8 = S32(SIGNED(ctx->r10) >> 16);
    // 0x801276E0: andi        $t4, $t0, 0xFF
    ctx->r12 = ctx->r8 & 0XFF;
    // 0x801276E4: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x801276E8: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x801276EC: lh          $t6, 0x2C78($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2C78);
    // 0x801276F0: sw          $v1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r3;
    // 0x801276F4: sw          $t0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r8;
    // 0x801276F8: sra         $a1, $t6, 7
    ctx->r5 = S32(SIGNED(ctx->r14) >> 7);
    // 0x801276FC: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80127700: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80127704: jal         0x80137BF4
    // 0x80127708: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    __ll_lshift_recomp(rdram, ctx);
        goto after_2;
    // 0x80127708: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    after_2:
    // 0x8012770C: lw          $t0, 0x2C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X2C);
    // 0x80127710: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x80127714: sw          $v0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r2;
    // 0x80127718: addiu       $t8, $t0, 0x40
    ctx->r24 = ADD32(ctx->r8, 0X40);
    // 0x8012771C: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x80127720: sll         $t1, $t9, 1
    ctx->r9 = S32(ctx->r25 << 1);
    // 0x80127724: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x80127728: lh          $t2, 0x2C78($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2C78);
    // 0x8012772C: sw          $v1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r3;
    // 0x80127730: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80127734: sra         $a1, $t2, 7
    ctx->r5 = S32(SIGNED(ctx->r10) >> 7);
    // 0x80127738: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x8012773C: jal         0x80137BF4
    // 0x80127740: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    __ll_lshift_recomp(rdram, ctx);
        goto after_3;
    // 0x80127740: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    after_3:
    // 0x80127744: lw          $a3, 0x74($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X74);
    // 0x80127748: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x8012774C: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x80127750: sra         $a2, $a3, 31
    ctx->r6 = S32(SIGNED(ctx->r7) >> 31);
    // 0x80127754: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x80127758: lw          $a0, 0x50($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X50);
    // 0x8012775C: lw          $a1, 0x54($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X54);
    // 0x80127760: jal         0x80137CB8
    // 0x80127764: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    __ll_mul_recomp(rdram, ctx);
        goto after_4;
    // 0x80127764: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    after_4:
    // 0x80127768: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012776C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80127770: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80127774: jal         0x80137DE4
    // 0x80127778: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_5;
    // 0x80127778: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_5:
    // 0x8012777C: sw          $v1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r3;
    // 0x80127780: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x80127784: lw          $a1, 0x5C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X5C);
    // 0x80127788: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x8012778C: jal         0x80137CB8
    // 0x80127790: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    __ll_mul_recomp(rdram, ctx);
        goto after_6;
    // 0x80127790: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    after_6:
    // 0x80127794: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80127798: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012779C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801277A0: jal         0x80137DE4
    // 0x801277A4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_7;
    // 0x801277A4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_7:
    // 0x801277A8: lhu         $t9, 0x3C($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X3C);
    // 0x801277AC: sw          $v1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r3;
    // 0x801277B0: lhu         $t2, 0x38($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X38);
    // 0x801277B4: sll         $t1, $t9, 16
    ctx->r9 = S32(ctx->r25 << 16);
    // 0x801277B8: or          $t3, $t1, $t2
    ctx->r11 = ctx->r9 | ctx->r10;
    // 0x801277BC: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x801277C0: lhu         $t4, 0x3E($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X3E);
    // 0x801277C4: lhu         $t7, 0x3A($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X3A);
    // 0x801277C8: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x801277CC: sll         $t6, $t4, 16
    ctx->r14 = S32(ctx->r12 << 16);
    // 0x801277D0: or          $t5, $t6, $t7
    ctx->r13 = ctx->r14 | ctx->r15;
    // 0x801277D4: sw          $t5, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r13;
    // 0x801277D8: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
    // 0x801277DC: lw          $a3, 0x78($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X78);
    // 0x801277E0: lw          $a1, 0x5C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X5C);
    // 0x801277E4: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x801277E8: sra         $a2, $a3, 31
    ctx->r6 = S32(SIGNED(ctx->r7) >> 31);
    // 0x801277EC: sltiu       $at, $a1, 0x1
    ctx->r1 = ctx->r5 < 0X1 ? 1 : 0;
    // 0x801277F0: nor         $a0, $a0, $zero
    ctx->r4 = ~(ctx->r4 | 0);
    // 0x801277F4: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x801277F8: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x801277FC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x80127800: jal         0x80137CB8
    // 0x80127804: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    __ll_mul_recomp(rdram, ctx);
        goto after_8;
    // 0x80127804: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    after_8:
    // 0x80127808: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012780C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80127810: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80127814: jal         0x80137DE4
    // 0x80127818: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_9;
    // 0x80127818: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_9:
    // 0x8012781C: sw          $v1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r3;
    // 0x80127820: lw          $a0, 0x50($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X50);
    // 0x80127824: lw          $a1, 0x54($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X54);
    // 0x80127828: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x8012782C: jal         0x80137CB8
    // 0x80127830: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    __ll_mul_recomp(rdram, ctx);
        goto after_10;
    // 0x80127830: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    after_10:
    // 0x80127834: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80127838: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x8012783C: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x80127840: jal         0x80137DE4
    // 0x80127844: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_11;
    // 0x80127844: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_11:
    // 0x80127848: lhu         $t4, 0x3C($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X3C);
    // 0x8012784C: sw          $v1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r3;
    // 0x80127850: lhu         $t7, 0x38($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X38);
    // 0x80127854: sll         $t6, $t4, 16
    ctx->r14 = S32(ctx->r12 << 16);
    // 0x80127858: or          $t5, $t6, $t7
    ctx->r13 = ctx->r14 | ctx->r15;
    // 0x8012785C: sw          $t5, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r13;
    // 0x80127860: lhu         $t8, 0x3E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X3E);
    // 0x80127864: lhu         $t3, 0x3A($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X3A);
    // 0x80127868: sw          $zero, 0xC($s0)
    MEM_W(0XC, ctx->r16) = 0;
    // 0x8012786C: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x80127870: or          $t9, $t2, $t3
    ctx->r25 = ctx->r10 | ctx->r11;
    // 0x80127874: sw          $t9, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r25;
    // 0x80127878: sw          $zero, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = 0;
    // 0x8012787C: lw          $a3, 0x84($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X84);
    // 0x80127880: lw          $a1, 0x44($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X44);
    // 0x80127884: lw          $a0, 0x40($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X40);
    // 0x80127888: sra         $a2, $a3, 31
    ctx->r6 = S32(SIGNED(ctx->r7) >> 31);
    // 0x8012788C: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x80127890: jal         0x80137CB8
    // 0x80127894: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    __ll_mul_recomp(rdram, ctx);
        goto after_12;
    // 0x80127894: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    after_12:
    // 0x80127898: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8012789C: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801278A0: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801278A4: jal         0x80137DE4
    // 0x801278A8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_13;
    // 0x801278A8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_13:
    // 0x801278AC: sw          $v1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r3;
    // 0x801278B0: lw          $a0, 0x48($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X48);
    // 0x801278B4: lw          $a1, 0x4C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4C);
    // 0x801278B8: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x801278BC: jal         0x80137CB8
    // 0x801278C0: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    __ll_mul_recomp(rdram, ctx);
        goto after_14;
    // 0x801278C0: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    after_14:
    // 0x801278C4: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x801278C8: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x801278CC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801278D0: jal         0x80137DE4
    // 0x801278D4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    __ll_rshift_recomp(rdram, ctx);
        goto after_15;
    // 0x801278D4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_15:
    // 0x801278D8: lhu         $t8, 0x3C($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X3C);
    // 0x801278DC: sw          $v1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r3;
    // 0x801278E0: lhu         $t3, 0x38($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X38);
    // 0x801278E4: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x801278E8: or          $t9, $t2, $t3
    ctx->r25 = ctx->r10 | ctx->r11;
    // 0x801278EC: sw          $t9, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r25;
    // 0x801278F0: lhu         $t1, 0x3E($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X3E);
    // 0x801278F4: lhu         $t5, 0x3A($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X3A);
    // 0x801278F8: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x801278FC: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80127900: sw          $t6, 0x30($s0)
    MEM_W(0X30, ctx->r16) = ctx->r14;
    // 0x80127904: lw          $t7, 0x7C($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X7C);
    // 0x80127908: sw          $t7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r15;
    // 0x8012790C: lhu         $t8, 0x3C($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X3C);
    // 0x80127910: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x80127914: sw          $t2, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r10;
    // 0x80127918: lhu         $t3, 0x3E($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X3E);
    // 0x8012791C: sll         $t9, $t3, 16
    ctx->r25 = S32(ctx->r11 << 16);
    // 0x80127920: sw          $t9, 0x34($s0)
    MEM_W(0X34, ctx->r16) = ctx->r25;
    // 0x80127924: lw          $t1, 0x64($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X64);
    // 0x80127928: lw          $t4, 0x68($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X68);
    // 0x8012792C: sw          $t1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r9;
    // 0x80127930: lhu         $t5, 0x3C($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X3C);
    // 0x80127934: sw          $t4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r12;
    // 0x80127938: lhu         $t7, 0x38($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X38);
    // 0x8012793C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80127940: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80127944: sw          $t8, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r24;
    // 0x80127948: lhu         $t2, 0x3E($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X3E);
    // 0x8012794C: lhu         $t9, 0x3A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X3A);
    // 0x80127950: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80127954: or          $t1, $t3, $t9
    ctx->r9 = ctx->r11 | ctx->r25;
    // 0x80127958: sw          $t1, 0x38($s0)
    MEM_W(0X38, ctx->r16) = ctx->r9;
    // 0x8012795C: lw          $t4, 0x6C($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X6C);
    // 0x80127960: sw          $t4, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r12;
    // 0x80127964: lhu         $t5, 0x3C($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X3C);
    // 0x80127968: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8012796C: ori         $t7, $t6, 0x1
    ctx->r15 = ctx->r14 | 0X1;
    // 0x80127970: sw          $t7, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r15;
    // 0x80127974: lhu         $t8, 0x3E($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X3E);
    // 0x80127978: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x8012797C: sw          $t2, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = ctx->r10;
    // 0x80127980: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80127984: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80127988: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x8012798C: jr          $ra
    // 0x80127990: nop

    return;
    // 0x80127990: nop

;}
RECOMP_FUNC void func_80127994(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80127994: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
    // 0x80127998: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x8012799C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801279A0: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x801279A4: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801279A8: mtc1        $s0, $f6
    ctx->f6.u32l = ctx->r16;
    // 0x801279AC: mtc1        $a2, $f8
    ctx->f8.u32l = ctx->r6;
    // 0x801279B0: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801279B4: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x801279B8: cvt.s.w     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    ctx->f2.fl = CVT_S_W(ctx->f6.u32l);
    // 0x801279BC: mul.s       $f10, $f0, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x801279C0: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x801279C4: sw          $a3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r7;
    // 0x801279C8: mul.s       $f16, $f2, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = MUL_S(ctx->f2.fl, ctx->f2.fl);
    // 0x801279CC: cvt.s.w     $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    ctx->f14.fl = CVT_S_W(ctx->f8.u32l);
    // 0x801279D0: add.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f10.fl + ctx->f16.fl;
    // 0x801279D4: mul.s       $f4, $f14, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x801279D8: jal         0x80137E10
    // 0x801279DC: add.s       $f12, $f18, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f18.fl + ctx->f4.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_0;
    // 0x801279DC: add.s       $f12, $f18, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f12.fl = ctx->f18.fl + ctx->f4.fl;
    after_0:
    // 0x801279E0: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x801279E4: lw          $a0, 0x48($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X48);
    // 0x801279E8: lw          $a2, 0x50($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X50);
    // 0x801279EC: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    // 0x801279F0: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x801279F4: sll         $t8, $s0, 10
    ctx->r24 = S32(ctx->r16 << 10);
    // 0x801279F8: sll         $t7, $a0, 10
    ctx->r15 = S32(ctx->r4 << 10);
    // 0x801279FC: bne         $v0, $zero, L_80127A14
    if (ctx->r2 != 0) {
        // 0x80127A00: nop
    
            goto L_80127A14;
    }
    // 0x80127A00: nop

    // 0x80127A04: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80127A08: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80127A0C: b           L_80127A9C
    // 0x80127A10: addiu       $a2, $zero, 0x400
    ctx->r6 = ADD32(0, 0X400);
        goto L_80127A9C;
    // 0x80127A10: addiu       $a2, $zero, 0x400
    ctx->r6 = ADD32(0, 0X400);
L_80127A14:
    // 0x80127A14: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x80127A18: mflo        $a0
    ctx->r4 = lo;
    // 0x80127A1C: sll         $t9, $a2, 10
    ctx->r25 = S32(ctx->r6 << 10);
    // 0x80127A20: bne         $v0, $zero, L_80127A2C
    if (ctx->r2 != 0) {
        // 0x80127A24: nop
    
            goto L_80127A2C;
    }
    // 0x80127A24: nop

    // 0x80127A28: break       7
    do_break(2148694568);
L_80127A2C:
    // 0x80127A2C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127A30: bne         $v0, $at, L_80127A44
    if (ctx->r2 != ctx->r1) {
        // 0x80127A34: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127A44;
    }
    // 0x80127A34: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127A38: bne         $t7, $at, L_80127A44
    if (ctx->r15 != ctx->r1) {
        // 0x80127A3C: nop
    
            goto L_80127A44;
    }
    // 0x80127A3C: nop

    // 0x80127A40: break       6
    do_break(2148694592);
L_80127A44:
    // 0x80127A44: div         $zero, $t8, $v0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r2)));
    // 0x80127A48: mflo        $s0
    ctx->r16 = lo;
    // 0x80127A4C: bne         $v0, $zero, L_80127A58
    if (ctx->r2 != 0) {
        // 0x80127A50: nop
    
            goto L_80127A58;
    }
    // 0x80127A50: nop

    // 0x80127A54: break       7
    do_break(2148694612);
L_80127A58:
    // 0x80127A58: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127A5C: bne         $v0, $at, L_80127A70
    if (ctx->r2 != ctx->r1) {
        // 0x80127A60: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127A70;
    }
    // 0x80127A60: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127A64: bne         $t8, $at, L_80127A70
    if (ctx->r24 != ctx->r1) {
        // 0x80127A68: nop
    
            goto L_80127A70;
    }
    // 0x80127A68: nop

    // 0x80127A6C: break       6
    do_break(2148694636);
L_80127A70:
    // 0x80127A70: div         $zero, $t9, $v0
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r2)));
    // 0x80127A74: mflo        $a2
    ctx->r6 = lo;
    // 0x80127A78: bne         $v0, $zero, L_80127A84
    if (ctx->r2 != 0) {
        // 0x80127A7C: nop
    
            goto L_80127A84;
    }
    // 0x80127A7C: nop

    // 0x80127A80: break       7
    do_break(2148694656);
L_80127A84:
    // 0x80127A84: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127A88: bne         $v0, $at, L_80127A9C
    if (ctx->r2 != ctx->r1) {
        // 0x80127A8C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127A9C;
    }
    // 0x80127A8C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127A90: bne         $t9, $at, L_80127A9C
    if (ctx->r25 != ctx->r1) {
        // 0x80127A94: nop
    
            goto L_80127A9C;
    }
    // 0x80127A94: nop

    // 0x80127A98: break       6
    do_break(2148694680);
L_80127A9C:
    // 0x80127A9C: mtc1        $a2, $f8
    ctx->f8.u32l = ctx->r6;
    // 0x80127AA0: negu        $t1, $a0
    ctx->r9 = SUB32(0, ctx->r4);
    // 0x80127AA4: mtc1        $t1, $f10
    ctx->f10.u32l = ctx->r9;
    // 0x80127AA8: cvt.s.w     $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    ctx->f14.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80127AAC: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x80127AB0: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x80127AB4: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x80127AB8: sw          $a3, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r7;
    // 0x80127ABC: cvt.s.w     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    ctx->f0.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80127AC0: mul.s       $f16, $f14, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f16.fl = MUL_S(ctx->f14.fl, ctx->f14.fl);
    // 0x80127AC4: nop

    // 0x80127AC8: mul.s       $f18, $f0, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f18.fl = MUL_S(ctx->f0.fl, ctx->f0.fl);
    // 0x80127ACC: jal         0x80137E10
    // 0x80127AD0: add.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f16.fl + ctx->f18.fl;
    sqrtf_recomp(rdram, ctx);
        goto after_1;
    // 0x80127AD0: add.s       $f12, $f16, $f18
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f12.fl = ctx->f16.fl + ctx->f18.fl;
    after_1:
    // 0x80127AD4: trunc.w.s   $f4, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    ctx->f4.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x80127AD8: lw          $a2, 0x50($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X50);
    // 0x80127ADC: lw          $t1, 0x20($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X20);
    // 0x80127AE0: lw          $a3, 0x54($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X54);
    // 0x80127AE4: mfc1        $v0, $f4
    ctx->r2 = (int32_t)ctx->f4.u32l;
    // 0x80127AE8: sll         $t3, $a2, 10
    ctx->r11 = S32(ctx->r6 << 10);
    // 0x80127AEC: sll         $t4, $t1, 10
    ctx->r12 = S32(ctx->r9 << 10);
    // 0x80127AF0: div         $zero, $t3, $v0
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r2)));
    // 0x80127AF4: mflo        $v1
    ctx->r3 = lo;
    // 0x80127AF8: sll         $t5, $v1, 6
    ctx->r13 = S32(ctx->r3 << 6);
    // 0x80127AFC: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    // 0x80127B00: div         $zero, $zero, $v0
    lo = S32(S64(S32(0)) / S64(S32(ctx->r2))); hi = S32(S64(S32(0)) % S64(S32(ctx->r2)));
    // 0x80127B04: mflo        $a1
    ctx->r5 = lo;
    // 0x80127B08: sll         $t6, $a1, 6
    ctx->r14 = S32(ctx->r5 << 6);
    // 0x80127B0C: lhu         $t7, 0x28($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X28);
    // 0x80127B10: div         $zero, $t4, $v0
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r2)));
    // 0x80127B14: mflo        $t0
    ctx->r8 = lo;
    // 0x80127B18: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80127B1C: lhu         $t9, 0x24($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X24);
    // 0x80127B20: multu       $a1, $a2
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127B24: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80127B28: lw          $a0, 0x48($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X48);
    // 0x80127B2C: bne         $v0, $zero, L_80127B38
    if (ctx->r2 != 0) {
        // 0x80127B30: nop
    
            goto L_80127B38;
    }
    // 0x80127B30: nop

    // 0x80127B34: break       7
    do_break(2148694836);
L_80127B38:
    // 0x80127B38: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127B3C: bne         $v0, $at, L_80127B50
    if (ctx->r2 != ctx->r1) {
        // 0x80127B40: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127B50;
    }
    // 0x80127B40: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127B44: bne         $t3, $at, L_80127B50
    if (ctx->r11 != ctx->r1) {
        // 0x80127B48: nop
    
            goto L_80127B50;
    }
    // 0x80127B48: nop

    // 0x80127B4C: break       6
    do_break(2148694860);
L_80127B50:
    // 0x80127B50: or          $t2, $t8, $t9
    ctx->r10 = ctx->r24 | ctx->r25;
    // 0x80127B54: bne         $v0, $zero, L_80127B60
    if (ctx->r2 != 0) {
        // 0x80127B58: nop
    
            goto L_80127B60;
    }
    // 0x80127B58: nop

    // 0x80127B5C: break       7
    do_break(2148694876);
L_80127B60:
    // 0x80127B60: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127B64: bne         $v0, $at, L_80127B78
    if (ctx->r2 != ctx->r1) {
        // 0x80127B68: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127B78;
    }
    // 0x80127B68: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127B6C: bne         $zero, $at, L_80127B78
    if (0 != ctx->r1) {
        // 0x80127B70: nop
    
            goto L_80127B78;
    }
    // 0x80127B70: nop

    // 0x80127B74: break       6
    do_break(2148694900);
L_80127B78:
    // 0x80127B78: sw          $t2, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r10;
    // 0x80127B7C: lhu         $t3, 0x2A($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127B80: lhu         $t5, 0x26($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X26);
    // 0x80127B84: bne         $v0, $zero, L_80127B90
    if (ctx->r2 != 0) {
        // 0x80127B88: nop
    
            goto L_80127B90;
    }
    // 0x80127B88: nop

    // 0x80127B8C: break       7
    do_break(2148694924);
L_80127B90:
    // 0x80127B90: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80127B94: bne         $v0, $at, L_80127BA8
    if (ctx->r2 != ctx->r1) {
        // 0x80127B98: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80127BA8;
    }
    // 0x80127B98: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80127B9C: bne         $t4, $at, L_80127BA8
    if (ctx->r12 != ctx->r1) {
        // 0x80127BA0: nop
    
            goto L_80127BA8;
    }
    // 0x80127BA0: nop

    // 0x80127BA4: break       6
    do_break(2148694948);
L_80127BA8:
    // 0x80127BA8: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80127BAC: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80127BB0: mflo        $t4
    ctx->r12 = lo;
    // 0x80127BB4: sll         $t7, $t0, 6
    ctx->r15 = S32(ctx->r8 << 6);
    // 0x80127BB8: sw          $t6, 0x20($a3)
    MEM_W(0X20, ctx->r7) = ctx->r14;
    // 0x80127BBC: multu       $t0, $s0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127BC0: sw          $t7, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r15;
    // 0x80127BC4: lhu         $t8, 0x28($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X28);
    // 0x80127BC8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80127BCC: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127BD0: sw          $t9, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r25;
    // 0x80127BD4: lhu         $t2, 0x2A($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127BD8: mflo        $t5
    ctx->r13 = lo;
    // 0x80127BDC: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80127BE0: sw          $t3, 0x24($a3)
    MEM_W(0X24, ctx->r7) = ctx->r11;
    // 0x80127BE4: multu       $t0, $a0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127BE8: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x80127BEC: negu        $t7, $t6
    ctx->r15 = SUB32(0, ctx->r14);
    // 0x80127BF0: sra         $t8, $t7, 10
    ctx->r24 = S32(SIGNED(ctx->r15) >> 10);
    // 0x80127BF4: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x80127BF8: sw          $t9, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r25;
    // 0x80127BFC: lhu         $t8, 0x28($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X28);
    // 0x80127C00: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127C04: mflo        $t2
    ctx->r10 = lo;
    // 0x80127C08: nop

    // 0x80127C0C: nop

    // 0x80127C10: multu       $v1, $a2
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127C14: mflo        $t3
    ctx->r11 = lo;
    // 0x80127C18: subu        $t4, $t2, $t3
    ctx->r12 = SUB32(ctx->r10, ctx->r11);
    // 0x80127C1C: negu        $t5, $t4
    ctx->r13 = SUB32(0, ctx->r12);
    // 0x80127C20: multu       $v1, $s0
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127C24: sra         $t6, $t5, 10
    ctx->r14 = S32(SIGNED(ctx->r13) >> 10);
    // 0x80127C28: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80127C2C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80127C30: lhu         $t2, 0x24($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X24);
    // 0x80127C34: or          $t3, $t9, $t2
    ctx->r11 = ctx->r25 | ctx->r10;
    // 0x80127C38: sw          $t3, 0x8($a3)
    MEM_W(0X8, ctx->r7) = ctx->r11;
    // 0x80127C3C: lhu         $t4, 0x2A($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127C40: mflo        $t8
    ctx->r24 = lo;
    // 0x80127C44: lhu         $t6, 0x26($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X26);
    // 0x80127C48: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80127C4C: multu       $a1, $a0
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80127C50: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80127C54: sw          $t7, 0x28($a3)
    MEM_W(0X28, ctx->r7) = ctx->r15;
    // 0x80127C58: mflo        $t9
    ctx->r25 = lo;
    // 0x80127C5C: subu        $t2, $t8, $t9
    ctx->r10 = SUB32(ctx->r24, ctx->r25);
    // 0x80127C60: negu        $t3, $t2
    ctx->r11 = SUB32(0, ctx->r10);
    // 0x80127C64: sra         $t4, $t3, 10
    ctx->r12 = S32(SIGNED(ctx->r11) >> 10);
    // 0x80127C68: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x80127C6C: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    // 0x80127C70: lhu         $t6, 0x28($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X28);
    // 0x80127C74: sll         $t2, $a0, 6
    ctx->r10 = S32(ctx->r4 << 6);
    // 0x80127C78: sll         $t3, $s0, 6
    ctx->r11 = S32(ctx->r16 << 6);
    // 0x80127C7C: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80127C80: sw          $t7, 0xC($a3)
    MEM_W(0XC, ctx->r7) = ctx->r15;
    // 0x80127C84: lhu         $t8, 0x2A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127C88: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127C8C: sw          $t9, 0x2C($a3)
    MEM_W(0X2C, ctx->r7) = ctx->r25;
    // 0x80127C90: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x80127C94: lhu         $t4, 0x28($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X28);
    // 0x80127C98: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x80127C9C: lhu         $t6, 0x24($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X24);
    // 0x80127CA0: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80127CA4: sll         $t4, $a2, 6
    ctx->r12 = S32(ctx->r6 << 6);
    // 0x80127CA8: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80127CAC: sw          $t7, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r15;
    // 0x80127CB0: lhu         $t8, 0x2A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127CB4: lhu         $t2, 0x26($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X26);
    // 0x80127CB8: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127CBC: or          $t3, $t9, $t2
    ctx->r11 = ctx->r25 | ctx->r10;
    // 0x80127CC0: sw          $t3, 0x30($a3)
    MEM_W(0X30, ctx->r7) = ctx->r11;
    // 0x80127CC4: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    // 0x80127CC8: lhu         $t5, 0x28($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X28);
    // 0x80127CCC: lui         $t9, 0x1
    ctx->r25 = S32(0X1 << 16);
    // 0x80127CD0: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80127CD4: sw          $t6, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r14;
    // 0x80127CD8: lhu         $t7, 0x2A($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127CDC: sw          $zero, 0x18($a3)
    MEM_W(0X18, ctx->r7) = 0;
    // 0x80127CE0: sw          $zero, 0x38($a3)
    MEM_W(0X38, ctx->r7) = 0;
    // 0x80127CE4: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80127CE8: sw          $t8, 0x34($a3)
    MEM_W(0X34, ctx->r7) = ctx->r24;
    // 0x80127CEC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80127CF0: lhu         $t2, 0x28($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X28);
    // 0x80127CF4: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80127CF8: lhu         $t4, 0x24($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X24);
    // 0x80127CFC: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80127D00: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x80127D04: sw          $t5, 0x1C($a3)
    MEM_W(0X1C, ctx->r7) = ctx->r13;
    // 0x80127D08: lhu         $t6, 0x2A($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X2A);
    // 0x80127D0C: lhu         $t8, 0x26($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X26);
    // 0x80127D10: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80127D14: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80127D18: sw          $t9, 0x3C($a3)
    MEM_W(0X3C, ctx->r7) = ctx->r25;
    // 0x80127D1C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80127D20: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80127D24: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x80127D28: jr          $ra
    // 0x80127D2C: nop

    return;
    // 0x80127D2C: nop

;}
RECOMP_FUNC void func_80127D30(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80127D30: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x80127D34: lui         $v0, 0x1
    ctx->r2 = S32(0X1 << 16);
    // 0x80127D38: sw          $v0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r2;
    // 0x80127D3C: lhu         $t8, 0x4($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X4);
    // 0x80127D40: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127D44: lhu         $t0, 0x0($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X0);
    // 0x80127D48: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127D4C: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x80127D50: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x80127D54: sw          $t1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r9;
    // 0x80127D58: lhu         $t2, 0x6($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X6);
    // 0x80127D5C: lhu         $t4, 0x2($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X2);
    // 0x80127D60: or          $t6, $a1, $zero
    ctx->r14 = ctx->r5 | 0;
    // 0x80127D64: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80127D68: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x80127D6C: sw          $t5, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r13;
    // 0x80127D70: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80127D74: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127D78: lhu         $t6, 0x4($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X4);
    // 0x80127D7C: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127D80: lhu         $t8, 0x0($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X0);
    // 0x80127D84: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80127D88: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80127D8C: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x80127D90: lhu         $t0, 0x6($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X6);
    // 0x80127D94: lhu         $t2, 0x2($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X2);
    // 0x80127D98: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x80127D9C: or          $t3, $t1, $t2
    ctx->r11 = ctx->r9 | ctx->r10;
    // 0x80127DA0: sw          $t3, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r11;
    // 0x80127DA4: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127DA8: lhu         $t4, 0x4($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X4);
    // 0x80127DAC: sw          $v0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r2;
    // 0x80127DB0: lhu         $t6, 0x0($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X0);
    // 0x80127DB4: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80127DB8: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80127DBC: sw          $t7, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r15;
    // 0x80127DC0: lhu         $t8, 0x6($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X6);
    // 0x80127DC4: lhu         $t0, 0x2($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X2);
    // 0x80127DC8: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80127DCC: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x80127DD0: sw          $t1, 0x28($a0)
    MEM_W(0X28, ctx->r4) = ctx->r9;
    // 0x80127DD4: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127DD8: lhu         $t2, 0x4($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X4);
    // 0x80127DDC: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127DE0: lhu         $t4, 0x0($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X0);
    // 0x80127DE4: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80127DE8: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x80127DEC: sw          $t5, 0xC($a0)
    MEM_W(0XC, ctx->r4) = ctx->r13;
    // 0x80127DF0: lhu         $t6, 0x6($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X6);
    // 0x80127DF4: lhu         $t8, 0x2($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X2);
    // 0x80127DF8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80127DFC: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80127E00: sw          $t9, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = ctx->r25;
    // 0x80127E04: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127E08: lhu         $t0, 0x4($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X4);
    // 0x80127E0C: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127E10: lhu         $t2, 0x0($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X0);
    // 0x80127E14: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x80127E18: lui         $t8, 0xFFFF
    ctx->r24 = S32(0XFFFF << 16);
    // 0x80127E1C: or          $t3, $t1, $t2
    ctx->r11 = ctx->r9 | ctx->r10;
    // 0x80127E20: sw          $t3, 0x10($a0)
    MEM_W(0X10, ctx->r4) = ctx->r11;
    // 0x80127E24: lhu         $t4, 0x6($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X6);
    // 0x80127E28: lhu         $t6, 0x2($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X2);
    // 0x80127E2C: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80127E30: or          $t7, $t5, $t6
    ctx->r15 = ctx->r13 | ctx->r14;
    // 0x80127E34: sw          $t7, 0x30($a0)
    MEM_W(0X30, ctx->r4) = ctx->r15;
    // 0x80127E38: sw          $t8, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r24;
    // 0x80127E3C: lhu         $t9, 0x4($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X4);
    // 0x80127E40: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127E44: lhu         $t1, 0x0($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X0);
    // 0x80127E48: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x80127E4C: or          $t2, $t0, $t1
    ctx->r10 = ctx->r8 | ctx->r9;
    // 0x80127E50: sw          $t2, 0x14($a0)
    MEM_W(0X14, ctx->r4) = ctx->r10;
    // 0x80127E54: lhu         $t3, 0x6($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X6);
    // 0x80127E58: lhu         $t5, 0x2($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X2);
    // 0x80127E5C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80127E60: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80127E64: sw          $t6, 0x34($a0)
    MEM_W(0X34, ctx->r4) = ctx->r14;
    // 0x80127E68: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127E6C: lhu         $t7, 0x4($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X4);
    // 0x80127E70: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127E74: lhu         $t9, 0x0($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X0);
    // 0x80127E78: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80127E7C: sll         $t5, $a1, 17
    ctx->r13 = S32(ctx->r5 << 17);
    // 0x80127E80: or          $t0, $t8, $t9
    ctx->r8 = ctx->r24 | ctx->r25;
    // 0x80127E84: sw          $t0, 0x18($a0)
    MEM_W(0X18, ctx->r4) = ctx->r8;
    // 0x80127E88: lhu         $t1, 0x6($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X6);
    // 0x80127E8C: lhu         $t3, 0x2($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X2);
    // 0x80127E90: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x80127E94: or          $t4, $t2, $t3
    ctx->r12 = ctx->r10 | ctx->r11;
    // 0x80127E98: sw          $t4, 0x38($a0)
    MEM_W(0X38, ctx->r4) = ctx->r12;
    // 0x80127E9C: sw          $t5, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r13;
    // 0x80127EA0: lhu         $t6, 0x4($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X4);
    // 0x80127EA4: sw          $v0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r2;
    // 0x80127EA8: lhu         $t8, 0x0($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X0);
    // 0x80127EAC: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80127EB0: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80127EB4: sw          $t9, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r25;
    // 0x80127EB8: lhu         $t0, 0x6($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X6);
    // 0x80127EBC: lhu         $t2, 0x2($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X2);
    // 0x80127EC0: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    // 0x80127EC4: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x80127EC8: or          $t3, $t1, $t2
    ctx->r11 = ctx->r9 | ctx->r10;
    // 0x80127ECC: jr          $ra
    // 0x80127ED0: sw          $t3, 0x3C($a0)
    MEM_W(0X3C, ctx->r4) = ctx->r11;
    return;
    // 0x80127ED0: sw          $t3, 0x3C($a0)
    MEM_W(0X3C, ctx->r4) = ctx->r11;
;}
RECOMP_FUNC void func_80127ED4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80127ED4: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x80127ED8: lui         $t8, 0xFFFF
    ctx->r24 = S32(0XFFFF << 16);
    // 0x80127EDC: sw          $t8, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r24;
    // 0x80127EE0: lhu         $t9, 0x4($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X4);
    // 0x80127EE4: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127EE8: lhu         $t1, 0x0($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X0);
    // 0x80127EEC: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x80127EF0: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x80127EF4: or          $t2, $t0, $t1
    ctx->r10 = ctx->r8 | ctx->r9;
    // 0x80127EF8: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x80127EFC: lhu         $t3, 0x6($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X6);
    // 0x80127F00: lhu         $t5, 0x2($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X2);
    // 0x80127F04: or          $t6, $a1, $zero
    ctx->r14 = ctx->r5 | 0;
    // 0x80127F08: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80127F0C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80127F10: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80127F14: sw          $t6, 0x20($a0)
    MEM_W(0X20, ctx->r4) = ctx->r14;
    // 0x80127F18: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127F1C: lhu         $t7, 0x4($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X4);
    // 0x80127F20: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127F24: lhu         $t9, 0x0($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X0);
    // 0x80127F28: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80127F2C: lui         $v0, 0x1
    ctx->r2 = S32(0X1 << 16);
    // 0x80127F30: or          $t0, $t8, $t9
    ctx->r8 = ctx->r24 | ctx->r25;
    // 0x80127F34: sw          $t0, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r8;
    // 0x80127F38: lhu         $t1, 0x6($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X6);
    // 0x80127F3C: lhu         $t3, 0x2($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X2);
    // 0x80127F40: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x80127F44: or          $t4, $t2, $t3
    ctx->r12 = ctx->r10 | ctx->r11;
    // 0x80127F48: sw          $t4, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r12;
    // 0x80127F4C: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127F50: lhu         $t5, 0x4($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X4);
    // 0x80127F54: sw          $v0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r2;
    // 0x80127F58: lhu         $t7, 0x0($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X0);
    // 0x80127F5C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80127F60: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80127F64: sw          $t8, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r24;
    // 0x80127F68: lhu         $t9, 0x6($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X6);
    // 0x80127F6C: lhu         $t1, 0x2($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X2);
    // 0x80127F70: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x80127F74: or          $t2, $t0, $t1
    ctx->r10 = ctx->r8 | ctx->r9;
    // 0x80127F78: sw          $t2, 0x28($a0)
    MEM_W(0X28, ctx->r4) = ctx->r10;
    // 0x80127F7C: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127F80: lhu         $t3, 0x4($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X4);
    // 0x80127F84: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127F88: lhu         $t5, 0x0($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X0);
    // 0x80127F8C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80127F90: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x80127F94: sw          $t6, 0xC($a0)
    MEM_W(0XC, ctx->r4) = ctx->r14;
    // 0x80127F98: lhu         $t7, 0x6($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X6);
    // 0x80127F9C: lhu         $t9, 0x2($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X2);
    // 0x80127FA0: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80127FA4: or          $t0, $t8, $t9
    ctx->r8 = ctx->r24 | ctx->r25;
    // 0x80127FA8: sw          $t0, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = ctx->r8;
    // 0x80127FAC: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80127FB0: lhu         $t1, 0x4($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X4);
    // 0x80127FB4: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127FB8: lhu         $t3, 0x0($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X0);
    // 0x80127FBC: sll         $t2, $t1, 16
    ctx->r10 = S32(ctx->r9 << 16);
    // 0x80127FC0: or          $t4, $t2, $t3
    ctx->r12 = ctx->r10 | ctx->r11;
    // 0x80127FC4: sw          $t4, 0x10($a0)
    MEM_W(0X10, ctx->r4) = ctx->r12;
    // 0x80127FC8: lhu         $t5, 0x6($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X6);
    // 0x80127FCC: lhu         $t7, 0x2($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X2);
    // 0x80127FD0: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80127FD4: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x80127FD8: sw          $t8, 0x30($a0)
    MEM_W(0X30, ctx->r4) = ctx->r24;
    // 0x80127FDC: sw          $v0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r2;
    // 0x80127FE0: lhu         $t9, 0x4($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X4);
    // 0x80127FE4: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x80127FE8: lhu         $t1, 0x0($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X0);
    // 0x80127FEC: sll         $t0, $t9, 16
    ctx->r8 = S32(ctx->r25 << 16);
    // 0x80127FF0: sll         $t7, $a1, 17
    ctx->r15 = S32(ctx->r5 << 17);
    // 0x80127FF4: or          $t2, $t0, $t1
    ctx->r10 = ctx->r8 | ctx->r9;
    // 0x80127FF8: sw          $t2, 0x14($a0)
    MEM_W(0X14, ctx->r4) = ctx->r10;
    // 0x80127FFC: lhu         $t3, 0x6($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X6);
    // 0x80128000: lhu         $t5, 0x2($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X2);
    // 0x80128004: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80128008: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x8012800C: sw          $t6, 0x34($a0)
    MEM_W(0X34, ctx->r4) = ctx->r14;
    // 0x80128010: sw          $t7, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r15;
    // 0x80128014: lhu         $t8, 0x4($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X4);
    // 0x80128018: sw          $zero, 0x0($sp)
    MEM_W(0X0, ctx->r29) = 0;
    // 0x8012801C: lhu         $t0, 0x0($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X0);
    // 0x80128020: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80128024: or          $t1, $t9, $t0
    ctx->r9 = ctx->r25 | ctx->r8;
    // 0x80128028: sw          $t1, 0x18($a0)
    MEM_W(0X18, ctx->r4) = ctx->r9;
    // 0x8012802C: lhu         $t2, 0x6($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X6);
    // 0x80128030: lhu         $t4, 0x2($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X2);
    // 0x80128034: sll         $t3, $t2, 16
    ctx->r11 = S32(ctx->r10 << 16);
    // 0x80128038: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x8012803C: sw          $t5, 0x38($a0)
    MEM_W(0X38, ctx->r4) = ctx->r13;
    // 0x80128040: sw          $zero, 0x4($sp)
    MEM_W(0X4, ctx->r29) = 0;
    // 0x80128044: lhu         $t6, 0x4($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X4);
    // 0x80128048: sw          $v0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r2;
    // 0x8012804C: lhu         $t8, 0x0($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X0);
    // 0x80128050: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80128054: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80128058: sw          $t9, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = ctx->r25;
    // 0x8012805C: lhu         $t0, 0x6($sp)
    ctx->r8 = MEM_HU(ctx->r29, 0X6);
    // 0x80128060: lhu         $t2, 0x2($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X2);
    // 0x80128064: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    // 0x80128068: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x8012806C: or          $t3, $t1, $t2
    ctx->r11 = ctx->r9 | ctx->r10;
    // 0x80128070: jr          $ra
    // 0x80128074: sw          $t3, 0x3C($a0)
    MEM_W(0X3C, ctx->r4) = ctx->r11;
    return;
    // 0x80128074: sw          $t3, 0x3C($a0)
    MEM_W(0X3C, ctx->r4) = ctx->r11;
;}
RECOMP_FUNC void func_80128078(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128078: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x8012807C: sw          $a2, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r6;
    // 0x80128080: lh          $t6, 0x52($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X52);
    // 0x80128084: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80128088: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x8012808C: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80128090: sw          $a1, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r5;
    // 0x80128094: addu        $t0, $t7, $t8
    ctx->r8 = ADD32(ctx->r15, ctx->r24);
    // 0x80128098: lh          $a1, 0x2D0($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X2D0);
    // 0x8012809C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801280A0: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x801280A4: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801280A8: sw          $t0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r8;
    // 0x801280AC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801280B0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x801280B4: jal         0x80137BF4
    // 0x801280B8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_0;
    // 0x801280B8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_0:
    // 0x801280BC: lw          $t0, 0x2C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X2C);
    // 0x801280C0: sw          $v0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r2;
    // 0x801280C4: sw          $v1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r3;
    // 0x801280C8: lh          $a1, 0x384($t0)
    ctx->r5 = MEM_H(ctx->r8, 0X384);
    // 0x801280CC: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x801280D0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x801280D4: jal         0x80137BF4
    // 0x801280D8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    __ll_lshift_recomp(rdram, ctx);
        goto after_1;
    // 0x801280D8: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    after_1:
    // 0x801280DC: lui         $t2, 0x1
    ctx->r10 = S32(0X1 << 16);
    // 0x801280E0: sw          $t2, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r10;
    // 0x801280E4: lhu         $t3, 0x34($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X34);
    // 0x801280E8: sw          $v0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r2;
    // 0x801280EC: sw          $v1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r3;
    // 0x801280F0: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x801280F4: sw          $t4, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r12;
    // 0x801280F8: lhu         $t5, 0x36($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X36);
    // 0x801280FC: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x80128100: sw          $zero, 0x24($s0)
    MEM_W(0X24, ctx->r16) = 0;
    // 0x80128104: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80128108: sw          $t6, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r14;
    // 0x8012810C: sw          $v1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r3;
    // 0x80128110: lhu         $t7, 0x30($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X30);
    // 0x80128114: sw          $t7, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r15;
    // 0x80128118: lhu         $t8, 0x32($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X32);
    // 0x8012811C: sw          $t8, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->r24;
    // 0x80128120: lw          $t3, 0x44($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X44);
    // 0x80128124: sw          $t3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r11;
    // 0x80128128: lhu         $t1, 0x34($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X34);
    // 0x8012812C: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x80128130: sw          $t4, 0xC($s0)
    MEM_W(0XC, ctx->r16) = ctx->r12;
    // 0x80128134: lhu         $t5, 0x36($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X36);
    // 0x80128138: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x8012813C: sw          $t6, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = ctx->r14;
    // 0x80128140: lw          $t9, 0x44($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X44);
    // 0x80128144: negu        $t3, $t9
    ctx->r11 = SUB32(0, ctx->r25);
    // 0x80128148: sw          $t3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r11;
    // 0x8012814C: lhu         $t1, 0x30($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X30);
    // 0x80128150: sw          $t1, 0x10($s0)
    MEM_W(0X10, ctx->r16) = ctx->r9;
    // 0x80128154: lhu         $t4, 0x32($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X32);
    // 0x80128158: sw          $t4, 0x30($s0)
    MEM_W(0X30, ctx->r16) = ctx->r12;
    // 0x8012815C: sw          $v1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r3;
    // 0x80128160: lhu         $t5, 0x34($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X34);
    // 0x80128164: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80128168: sw          $t6, 0x14($s0)
    MEM_W(0X14, ctx->r16) = ctx->r14;
    // 0x8012816C: lhu         $t8, 0x36($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X36);
    // 0x80128170: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80128174: sw          $t9, 0x34($s0)
    MEM_W(0X34, ctx->r16) = ctx->r25;
    // 0x80128178: lh          $a1, 0x4E($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X4E);
    // 0x8012817C: lw          $a3, 0x44($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X44);
    // 0x80128180: lw          $a2, 0x40($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X40);
    // 0x80128184: sra         $a0, $a1, 31
    ctx->r4 = S32(SIGNED(ctx->r5) >> 31);
    // 0x80128188: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x8012818C: jal         0x80137CB8
    // 0x80128190: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    __ll_mul_recomp(rdram, ctx);
        goto after_2;
    // 0x80128190: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    after_2:
    // 0x80128194: sw          $v1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r3;
    // 0x80128198: lhu         $t7, 0x30($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X30);
    // 0x8012819C: sw          $t7, 0x18($s0)
    MEM_W(0X18, ctx->r16) = ctx->r15;
    // 0x801281A0: lhu         $t1, 0x32($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X32);
    // 0x801281A4: sw          $t1, 0x38($s0)
    MEM_W(0X38, ctx->r16) = ctx->r9;
    // 0x801281A8: lw          $a3, 0x3C($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X3C);
    // 0x801281AC: lw          $a2, 0x38($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X38);
    // 0x801281B0: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x801281B4: jal         0x80137CB8
    // 0x801281B8: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    __ll_mul_recomp(rdram, ctx);
        goto after_3;
    // 0x801281B8: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    after_3:
    // 0x801281BC: lh          $t6, 0x4E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X4E);
    // 0x801281C0: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x801281C4: subu        $t5, $t8, $v1
    ctx->r13 = SUB32(ctx->r24, ctx->r3);
    // 0x801281C8: sw          $t5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r13;
    // 0x801281CC: lhu         $t7, 0x34($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X34);
    // 0x801281D0: sll         $t1, $t7, 16
    ctx->r9 = S32(ctx->r15 << 16);
    // 0x801281D4: ori         $t6, $t1, 0x1
    ctx->r14 = ctx->r9 | 0X1;
    // 0x801281D8: sw          $t6, 0x1C($s0)
    MEM_W(0X1C, ctx->r16) = ctx->r14;
    // 0x801281DC: lhu         $t8, 0x36($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X36);
    // 0x801281E0: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x801281E4: sw          $t2, 0x3C($s0)
    MEM_W(0X3C, ctx->r16) = ctx->r10;
    // 0x801281E8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x801281EC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801281F0: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x801281F4: jr          $ra
    // 0x801281F8: nop

    return;
    // 0x801281F8: nop

;}
RECOMP_FUNC void func_80128200(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128200: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x80128204: addiu       $a0, $a0, 0x1430
    ctx->r4 = ADD32(ctx->r4, 0X1430);
    // 0x80128208: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012820C: sll         $t6, $v1, 2
    ctx->r14 = S32(ctx->r3 << 2);
    // 0x80128210: addiu       $v1, $t6, 0x2
    ctx->r3 = ADD32(ctx->r14, 0X2);
    // 0x80128214: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80128218: multu       $v1, $t7
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012821C: mflo        $v1
    ctx->r3 = lo;
    // 0x80128220: srl         $v0, $v1, 2
    ctx->r2 = S32(U32(ctx->r3) >> 2);
    // 0x80128224: jr          $ra
    // 0x80128228: sw          $v0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r2;
    return;
    // 0x80128228: sw          $v0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r2;
;}
RECOMP_FUNC void func_8012822C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012822C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80128230: bne         $a0, $zero, L_80128258
    if (ctx->r4 != 0) {
        // 0x80128234: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_80128258;
    }
    // 0x80128234: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80128238: jal         0x80137E20
    // 0x8012823C: nop

    osGetTime_recomp(rdram, ctx);
        goto after_0;
    // 0x8012823C: nop

    after_0:
    // 0x80128240: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80128244: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
    // 0x80128248: addiu       $a2, $zero, 0x0
    ctx->r6 = ADD32(0, 0X0);
    // 0x8012824C: jal         0x80137B50
    // 0x80128250: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    __ull_rshift_recomp(rdram, ctx);
        goto after_1;
    // 0x80128250: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_1:
    // 0x80128254: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_80128258:
    // 0x80128258: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8012825C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80128260: sw          $a0, 0x1430($at)
    MEM_W(0X1430, ctx->r1) = ctx->r4;
    // 0x80128264: jr          $ra
    // 0x80128268: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x80128268: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void advance_random_seed(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012826C: lui         $a1, 0x8015
    ctx->r5 = S32(0X8015 << 16);
    // 0x80128270: addiu       $a1, $a1, 0x1434
    ctx->r5 = ADD32(ctx->r5, 0X1434);
    // 0x80128274: lhu         $a0, 0x0($a1)
    ctx->r4 = MEM_HU(ctx->r5, 0X0);
    // 0x80128278: sll         $t6, $a0, 1
    ctx->r14 = S32(ctx->r4 << 1);
    // 0x8012827C: andi        $t7, $a0, 0x8000
    ctx->r15 = ctx->r4 & 0X8000;
    // 0x80128280: beq         $t7, $zero, L_80128290
    if (ctx->r15 == 0) {
        // 0x80128284: sh          $t6, 0x0($a1)
        MEM_H(0X0, ctx->r5) = ctx->r14;
            goto L_80128290;
    }
    // 0x80128284: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
    // 0x80128288: xori        $t9, $t6, 0x1
    ctx->r25 = ctx->r14 ^ 0X1;
    // 0x8012828C: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
L_80128290:
    // 0x80128290: andi        $t0, $a0, 0x2000
    ctx->r8 = ctx->r4 & 0X2000;
    // 0x80128294: beq         $t0, $zero, L_801282A8
    if (ctx->r8 == 0) {
        // 0x80128298: andi        $t3, $a0, 0x10
        ctx->r11 = ctx->r4 & 0X10;
            goto L_801282A8;
    }
    // 0x80128298: andi        $t3, $a0, 0x10
    ctx->r11 = ctx->r4 & 0X10;
    // 0x8012829C: lhu         $t1, 0x0($a1)
    ctx->r9 = MEM_HU(ctx->r5, 0X0);
    // 0x801282A0: xori        $t2, $t1, 0x1
    ctx->r10 = ctx->r9 ^ 0X1;
    // 0x801282A4: sh          $t2, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r10;
L_801282A8:
    // 0x801282A8: beq         $t3, $zero, L_801282BC
    if (ctx->r11 == 0) {
        // 0x801282AC: nop
    
            goto L_801282BC;
    }
    // 0x801282AC: nop

    // 0x801282B0: lhu         $t4, 0x0($a1)
    ctx->r12 = MEM_HU(ctx->r5, 0X0);
    // 0x801282B4: xori        $t5, $t4, 0x1
    ctx->r13 = ctx->r12 ^ 0X1;
    // 0x801282B8: sh          $t5, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r13;
L_801282BC:
    // 0x801282BC: jr          $ra
    // 0x801282C0: lhu         $v0, 0x0($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X0);
    return;
    // 0x801282C0: lhu         $v0, 0x0($a1)
    ctx->r2 = MEM_HU(ctx->r5, 0X0);
;}
RECOMP_FUNC void func_801282C4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801282C4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801282C8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801282CC: jal         0x8012826C
    // 0x801282D0: nop

    advance_random_seed(rdram, ctx);
        goto after_0;
    // 0x801282D0: nop

    after_0:
    // 0x801282D4: jal         0x8012826C
    // 0x801282D8: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x801282D8: nop

    after_1:
    // 0x801282DC: jal         0x8012826C
    // 0x801282E0: nop

    advance_random_seed(rdram, ctx);
        goto after_2;
    // 0x801282E0: nop

    after_2:
    // 0x801282E4: jal         0x8012826C
    // 0x801282E8: nop

    advance_random_seed(rdram, ctx);
        goto after_3;
    // 0x801282E8: nop

    after_3:
    // 0x801282EC: jal         0x8012826C
    // 0x801282F0: nop

    advance_random_seed(rdram, ctx);
        goto after_4;
    // 0x801282F0: nop

    after_4:
    // 0x801282F4: jal         0x8012826C
    // 0x801282F8: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x801282F8: nop

    after_5:
    // 0x801282FC: jal         0x8012826C
    // 0x80128300: nop

    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x80128300: nop

    after_6:
    // 0x80128304: jal         0x8012826C
    // 0x80128308: nop

    advance_random_seed(rdram, ctx);
        goto after_7;
    // 0x80128308: nop

    after_7:
    // 0x8012830C: jal         0x8012826C
    // 0x80128310: nop

    advance_random_seed(rdram, ctx);
        goto after_8;
    // 0x80128310: nop

    after_8:
    // 0x80128314: jal         0x8012826C
    // 0x80128318: nop

    advance_random_seed(rdram, ctx);
        goto after_9;
    // 0x80128318: nop

    after_9:
    // 0x8012831C: jal         0x8012826C
    // 0x80128320: nop

    advance_random_seed(rdram, ctx);
        goto after_10;
    // 0x80128320: nop

    after_10:
    // 0x80128324: jal         0x8012826C
    // 0x80128328: nop

    advance_random_seed(rdram, ctx);
        goto after_11;
    // 0x80128328: nop

    after_11:
    // 0x8012832C: jal         0x8012826C
    // 0x80128330: nop

    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x80128330: nop

    after_12:
    // 0x80128334: jal         0x8012826C
    // 0x80128338: nop

    advance_random_seed(rdram, ctx);
        goto after_13;
    // 0x80128338: nop

    after_13:
    // 0x8012833C: jal         0x8012826C
    // 0x80128340: nop

    advance_random_seed(rdram, ctx);
        goto after_14;
    // 0x80128340: nop

    after_14:
    // 0x80128344: jal         0x8012826C
    // 0x80128348: nop

    advance_random_seed(rdram, ctx);
        goto after_15;
    // 0x80128348: nop

    after_15:
    // 0x8012834C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80128350: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80128354: jr          $ra
    // 0x80128358: nop

    return;
    // 0x80128358: nop

;}
RECOMP_FUNC void func_8012835C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012835C: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80128360: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80128364: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80128368: bltz        $t7, L_80128384
    if (SIGNED(ctx->r15) < 0) {
        // 0x8012836C: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_80128384;
    }
    // 0x8012836C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80128370: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80128374: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80128378: addu        $v0, $v0, $t8
    ctx->r2 = ADD32(ctx->r2, ctx->r24);
    // 0x8012837C: jr          $ra
    // 0x80128380: lh          $v0, 0x2040($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2040);
    return;
    // 0x80128380: lh          $v0, 0x2040($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2040);
L_80128384:
    // 0x80128384: negu        $t9, $a0
    ctx->r25 = SUB32(0, ctx->r4);
    // 0x80128388: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x8012838C: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80128390: addu        $v0, $v0, $t0
    ctx->r2 = ADD32(ctx->r2, ctx->r8);
    // 0x80128394: lh          $v0, 0x2040($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2040);
    // 0x80128398: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x8012839C: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x801283A0: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    // 0x801283A4: jr          $ra
    // 0x801283A8: nop

    return;
    // 0x801283A8: nop

;}
RECOMP_FUNC void func_801283AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801283AC: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x801283B0: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x801283B4: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x801283B8: bltz        $t7, L_801283E4
    if (SIGNED(ctx->r15) < 0) {
        // 0x801283BC: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_801283E4;
    }
    // 0x801283BC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x801283C0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x801283C4: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x801283C8: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x801283CC: lh          $t9, 0x2040($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2040);
    // 0x801283D0: addiu       $t0, $zero, 0x5A
    ctx->r8 = ADD32(0, 0X5A);
    // 0x801283D4: subu        $v0, $t0, $t9
    ctx->r2 = SUB32(ctx->r8, ctx->r25);
    // 0x801283D8: sll         $t1, $v0, 16
    ctx->r9 = S32(ctx->r2 << 16);
    // 0x801283DC: jr          $ra
    // 0x801283E0: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
    return;
    // 0x801283E0: sra         $v0, $t1, 16
    ctx->r2 = S32(SIGNED(ctx->r9) >> 16);
L_801283E4:
    // 0x801283E4: negu        $t3, $a0
    ctx->r11 = SUB32(0, ctx->r4);
    // 0x801283E8: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x801283EC: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x801283F0: addu        $v0, $v0, $t4
    ctx->r2 = ADD32(ctx->r2, ctx->r12);
    // 0x801283F4: lh          $v0, 0x2040($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2040);
    // 0x801283F8: addiu       $v0, $v0, 0x5A
    ctx->r2 = ADD32(ctx->r2, 0X5A);
    // 0x801283FC: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x80128400: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80128404: jr          $ra
    // 0x80128408: nop

    return;
    // 0x80128408: nop

;}
RECOMP_FUNC void func_8012840C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012840C: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80128410: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80128414: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x80128418: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8012841C: jr          $ra
    // 0x80128420: lb          $v0, 0x2248($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X2248);
    return;
    // 0x80128420: lb          $v0, 0x2248($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X2248);
;}
RECOMP_FUNC void func_80128424(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128424: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80128428: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x8012842C: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80128430: lb          $t7, 0x2248($t7)
    ctx->r15 = MEM_B(ctx->r15, 0X2248);
    // 0x80128434: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x80128438: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8012843C: subu        $v0, $t8, $t7
    ctx->r2 = SUB32(ctx->r24, ctx->r15);
    // 0x80128440: sll         $t9, $v0, 24
    ctx->r25 = S32(ctx->r2 << 24);
    // 0x80128444: jr          $ra
    // 0x80128448: sra         $v0, $t9, 24
    ctx->r2 = S32(SIGNED(ctx->r25) >> 24);
    return;
    // 0x80128448: sra         $v0, $t9, 24
    ctx->r2 = S32(SIGNED(ctx->r25) >> 24);
;}
RECOMP_FUNC void func_8012844C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012844C: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80128450: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80128454: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80128458: slti        $at, $a0, 0x800
    ctx->r1 = SIGNED(ctx->r4) < 0X800 ? 1 : 0;
    // 0x8012845C: bnel        $at, $zero, L_80128470
    if (ctx->r1 != 0) {
        // 0x80128460: slti        $at, $a0, -0x7FF
        ctx->r1 = SIGNED(ctx->r4) < -0X7FF ? 1 : 0;
            goto L_80128470;
    }
    goto skip_0;
    // 0x80128460: slti        $at, $a0, -0x7FF
    ctx->r1 = SIGNED(ctx->r4) < -0X7FF ? 1 : 0;
    skip_0:
    // 0x80128464: jr          $ra
    // 0x80128468: addiu       $v0, $zero, 0x59
    ctx->r2 = ADD32(0, 0X59);
    return;
    // 0x80128468: addiu       $v0, $zero, 0x59
    ctx->r2 = ADD32(0, 0X59);
    // 0x8012846C: slti        $at, $a0, -0x7FF
    ctx->r1 = SIGNED(ctx->r4) < -0X7FF ? 1 : 0;
L_80128470:
    // 0x80128470: beq         $at, $zero, L_80128480
    if (ctx->r1 == 0) {
        // 0x80128474: nop
    
            goto L_80128480;
    }
    // 0x80128474: nop

    // 0x80128478: jr          $ra
    // 0x8012847C: addiu       $v0, $zero, -0x59
    ctx->r2 = ADD32(0, -0X59);
    return;
    // 0x8012847C: addiu       $v0, $zero, -0x59
    ctx->r2 = ADD32(0, -0X59);
L_80128480:
    // 0x80128480: bgez        $a0, L_801284A8
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80128484: lui         $v0, 0x8015
        ctx->r2 = S32(0X8015 << 16);
            goto L_801284A8;
    }
    // 0x80128484: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80128488: negu        $t8, $a0
    ctx->r24 = SUB32(0, ctx->r4);
    // 0x8012848C: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80128490: addu        $v0, $v0, $t8
    ctx->r2 = ADD32(ctx->r2, ctx->r24);
    // 0x80128494: lbu         $v0, 0x1438($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X1438);
    // 0x80128498: negu        $v0, $v0
    ctx->r2 = SUB32(0, ctx->r2);
    // 0x8012849C: sll         $t9, $v0, 16
    ctx->r25 = S32(ctx->r2 << 16);
    // 0x801284A0: jr          $ra
    // 0x801284A4: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
    return;
    // 0x801284A4: sra         $v0, $t9, 16
    ctx->r2 = S32(SIGNED(ctx->r25) >> 16);
L_801284A8:
    // 0x801284A8: addu        $v0, $v0, $a0
    ctx->r2 = ADD32(ctx->r2, ctx->r4);
    // 0x801284AC: lbu         $v0, 0x1438($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X1438);
    // 0x801284B0: jr          $ra
    // 0x801284B4: nop

    return;
    // 0x801284B4: nop

;}
RECOMP_FUNC void func_801284B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801284B8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801284BC: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x801284C0: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x801284C4: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x801284C8: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x801284CC: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x801284D0: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x801284D4: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x801284D8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801284DC: bgez        $t6, L_801284EC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x801284E0: sw          $a0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r4;
            goto L_801284EC;
    }
    // 0x801284E0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x801284E4: b           L_801284F0
    // 0x801284E8: negu        $v1, $a2
    ctx->r3 = SUB32(0, ctx->r6);
        goto L_801284F0;
    // 0x801284E8: negu        $v1, $a2
    ctx->r3 = SUB32(0, ctx->r6);
L_801284EC:
    // 0x801284EC: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_801284F0:
    // 0x801284F0: bgez        $a1, L_80128500
    if (SIGNED(ctx->r5) >= 0) {
        // 0x801284F4: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_80128500;
    }
    // 0x801284F4: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x801284F8: b           L_80128500
    // 0x801284FC: negu        $v0, $a1
    ctx->r2 = SUB32(0, ctx->r5);
        goto L_80128500;
    // 0x801284FC: negu        $v0, $a1
    ctx->r2 = SUB32(0, ctx->r5);
L_80128500:
    // 0x80128500: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80128504: beq         $at, $zero, L_801285E0
    if (ctx->r1 == 0) {
        // 0x80128508: nop
    
            goto L_801285E0;
    }
    // 0x80128508: nop

    // 0x8012850C: blez        $a1, L_80128574
    if (SIGNED(ctx->r5) <= 0) {
        // 0x80128510: nop
    
            goto L_80128574;
    }
    // 0x80128510: nop

    // 0x80128514: sll         $t9, $a2, 6
    ctx->r25 = S32(ctx->r6 << 6);
    // 0x80128518: div         $zero, $t9, $a1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r5))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r5)));
    // 0x8012851C: mflo        $a0
    ctx->r4 = lo;
    // 0x80128520: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80128524: bne         $a1, $zero, L_80128530
    if (ctx->r5 != 0) {
        // 0x80128528: nop
    
            goto L_80128530;
    }
    // 0x80128528: nop

    // 0x8012852C: break       7
    do_break(2148697388);
L_80128530:
    // 0x80128530: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128534: bne         $a1, $at, L_80128548
    if (ctx->r5 != ctx->r1) {
        // 0x80128538: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128548;
    }
    // 0x80128538: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8012853C: bne         $t9, $at, L_80128548
    if (ctx->r25 != ctx->r1) {
        // 0x80128540: nop
    
            goto L_80128548;
    }
    // 0x80128540: nop

    // 0x80128544: break       6
    do_break(2148697412);
L_80128548:
    // 0x80128548: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8012854C: jal         0x8012844C
    // 0x80128550: nop

    func_8012844C(rdram, ctx);
        goto after_0;
    // 0x80128550: nop

    after_0:
    // 0x80128554: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80128558: sra         $t2, $v1, 16
    ctx->r10 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8012855C: bgez        $v0, L_801286A4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80128560: or          $v1, $t2, $zero
        ctx->r3 = ctx->r10 | 0;
            goto L_801286A4;
    }
    // 0x80128560: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
    // 0x80128564: addiu       $v1, $v0, 0x168
    ctx->r3 = ADD32(ctx->r2, 0X168);
    // 0x80128568: sll         $t3, $v1, 16
    ctx->r11 = S32(ctx->r3 << 16);
    // 0x8012856C: b           L_801286A4
    // 0x80128570: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
        goto L_801286A4;
    // 0x80128570: sra         $v1, $t3, 16
    ctx->r3 = S32(SIGNED(ctx->r11) >> 16);
L_80128574:
    // 0x80128574: bgez        $a1, L_801285C8
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80128578: sll         $t5, $a2, 6
        ctx->r13 = S32(ctx->r6 << 6);
            goto L_801285C8;
    }
    // 0x80128578: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x8012857C: div         $zero, $t5, $a1
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r5))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r5)));
    // 0x80128580: mflo        $a0
    ctx->r4 = lo;
    // 0x80128584: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80128588: bne         $a1, $zero, L_80128594
    if (ctx->r5 != 0) {
        // 0x8012858C: nop
    
            goto L_80128594;
    }
    // 0x8012858C: nop

    // 0x80128590: break       7
    do_break(2148697488);
L_80128594:
    // 0x80128594: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128598: bne         $a1, $at, L_801285AC
    if (ctx->r5 != ctx->r1) {
        // 0x8012859C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801285AC;
    }
    // 0x8012859C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801285A0: bne         $t5, $at, L_801285AC
    if (ctx->r13 != ctx->r1) {
        // 0x801285A4: nop
    
            goto L_801285AC;
    }
    // 0x801285A4: nop

    // 0x801285A8: break       6
    do_break(2148697512);
L_801285AC:
    // 0x801285AC: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x801285B0: jal         0x8012844C
    // 0x801285B4: nop

    func_8012844C(rdram, ctx);
        goto after_1;
    // 0x801285B4: nop

    after_1:
    // 0x801285B8: addiu       $v1, $v0, 0xB4
    ctx->r3 = ADD32(ctx->r2, 0XB4);
    // 0x801285BC: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x801285C0: b           L_801286A4
    // 0x801285C4: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
        goto L_801286A4;
    // 0x801285C4: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_801285C8:
    // 0x801285C8: bltz        $a2, L_801285D8
    if (SIGNED(ctx->r6) < 0) {
        // 0x801285CC: nop
    
            goto L_801285D8;
    }
    // 0x801285CC: nop

    // 0x801285D0: b           L_801286A4
    // 0x801285D4: addiu       $v1, $zero, 0x5A
    ctx->r3 = ADD32(0, 0X5A);
        goto L_801286A4;
    // 0x801285D4: addiu       $v1, $zero, 0x5A
    ctx->r3 = ADD32(0, 0X5A);
L_801285D8:
    // 0x801285D8: b           L_801286A4
    // 0x801285DC: addiu       $v1, $zero, 0x10E
    ctx->r3 = ADD32(0, 0X10E);
        goto L_801286A4;
    // 0x801285DC: addiu       $v1, $zero, 0x10E
    ctx->r3 = ADD32(0, 0X10E);
L_801285E0:
    // 0x801285E0: blez        $a2, L_8012863C
    if (SIGNED(ctx->r6) <= 0) {
        // 0x801285E4: nop
    
            goto L_8012863C;
    }
    // 0x801285E4: nop

    // 0x801285E8: sll         $t0, $a1, 6
    ctx->r8 = S32(ctx->r5 << 6);
    // 0x801285EC: div         $zero, $t0, $a2
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r6)));
    // 0x801285F0: mflo        $a0
    ctx->r4 = lo;
    // 0x801285F4: sll         $t1, $a0, 16
    ctx->r9 = S32(ctx->r4 << 16);
    // 0x801285F8: bne         $a2, $zero, L_80128604
    if (ctx->r6 != 0) {
        // 0x801285FC: nop
    
            goto L_80128604;
    }
    // 0x801285FC: nop

    // 0x80128600: break       7
    do_break(2148697600);
L_80128604:
    // 0x80128604: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128608: bne         $a2, $at, L_8012861C
    if (ctx->r6 != ctx->r1) {
        // 0x8012860C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8012861C;
    }
    // 0x8012860C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128610: bne         $t0, $at, L_8012861C
    if (ctx->r8 != ctx->r1) {
        // 0x80128614: nop
    
            goto L_8012861C;
    }
    // 0x80128614: nop

    // 0x80128618: break       6
    do_break(2148697624);
L_8012861C:
    // 0x8012861C: sra         $a0, $t1, 16
    ctx->r4 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80128620: jal         0x8012844C
    // 0x80128624: nop

    func_8012844C(rdram, ctx);
        goto after_2;
    // 0x80128624: nop

    after_2:
    // 0x80128628: addiu       $t3, $zero, 0x5A
    ctx->r11 = ADD32(0, 0X5A);
    // 0x8012862C: subu        $v1, $t3, $v0
    ctx->r3 = SUB32(ctx->r11, ctx->r2);
    // 0x80128630: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x80128634: b           L_801286A4
    // 0x80128638: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
        goto L_801286A4;
    // 0x80128638: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
L_8012863C:
    // 0x8012863C: bgez        $a2, L_80128694
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80128640: sll         $t6, $a1, 6
        ctx->r14 = S32(ctx->r5 << 6);
            goto L_80128694;
    }
    // 0x80128640: sll         $t6, $a1, 6
    ctx->r14 = S32(ctx->r5 << 6);
    // 0x80128644: div         $zero, $t6, $a2
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r6)));
    // 0x80128648: mflo        $a0
    ctx->r4 = lo;
    // 0x8012864C: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80128650: bne         $a2, $zero, L_8012865C
    if (ctx->r6 != 0) {
        // 0x80128654: nop
    
            goto L_8012865C;
    }
    // 0x80128654: nop

    // 0x80128658: break       7
    do_break(2148697688);
L_8012865C:
    // 0x8012865C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128660: bne         $a2, $at, L_80128674
    if (ctx->r6 != ctx->r1) {
        // 0x80128664: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128674;
    }
    // 0x80128664: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128668: bne         $t6, $at, L_80128674
    if (ctx->r14 != ctx->r1) {
        // 0x8012866C: nop
    
            goto L_80128674;
    }
    // 0x8012866C: nop

    // 0x80128670: break       6
    do_break(2148697712);
L_80128674:
    // 0x80128674: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80128678: jal         0x8012844C
    // 0x8012867C: nop

    func_8012844C(rdram, ctx);
        goto after_3;
    // 0x8012867C: nop

    after_3:
    // 0x80128680: addiu       $t9, $zero, 0x10E
    ctx->r25 = ADD32(0, 0X10E);
    // 0x80128684: subu        $v1, $t9, $v0
    ctx->r3 = SUB32(ctx->r25, ctx->r2);
    // 0x80128688: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x8012868C: b           L_801286A4
    // 0x80128690: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
        goto L_801286A4;
    // 0x80128690: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
L_80128694:
    // 0x80128694: bltz        $a1, L_801286A4
    if (SIGNED(ctx->r5) < 0) {
        // 0x80128698: addiu       $v1, $zero, 0xB4
        ctx->r3 = ADD32(0, 0XB4);
            goto L_801286A4;
    }
    // 0x80128698: addiu       $v1, $zero, 0xB4
    ctx->r3 = ADD32(0, 0XB4);
    // 0x8012869C: b           L_801286A4
    // 0x801286A0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_801286A4;
    // 0x801286A0: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_801286A4:
    // 0x801286A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x801286A8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x801286AC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x801286B0: jr          $ra
    // 0x801286B4: nop

    return;
    // 0x801286B4: nop

;}
RECOMP_FUNC void func_801286B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801286B8: mtc1        $zero, $f16
    ctx->f16.u32l = 0;
    // 0x801286BC: nop

    // 0x801286C0: c.lt.s      $f12, $f16
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f12.fl < ctx->f16.fl;
    // 0x801286C4: nop

    // 0x801286C8: bc1fl       L_801286DC
    if (!c1cs) {
        // 0x801286CC: mov.s       $f0, $f12
        CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
            goto L_801286DC;
    }
    goto skip_0;
    // 0x801286CC: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
    skip_0:
    // 0x801286D0: b           L_801286DC
    // 0x801286D4: neg.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.fl = -ctx->f12.fl;
        goto L_801286DC;
    // 0x801286D4: neg.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.fl = -ctx->f12.fl;
    // 0x801286D8: mov.s       $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    ctx->f0.fl = ctx->f12.fl;
L_801286DC:
    // 0x801286DC: c.lt.s      $f14, $f16
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    c1cs = ctx->f14.fl < ctx->f16.fl;
    // 0x801286E0: nop

    // 0x801286E4: bc1fl       L_801286F8
    if (!c1cs) {
        // 0x801286E8: mov.s       $f2, $f14
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.fl = ctx->f14.fl;
            goto L_801286F8;
    }
    goto skip_1;
    // 0x801286E8: mov.s       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.fl = ctx->f14.fl;
    skip_1:
    // 0x801286EC: b           L_801286F8
    // 0x801286F0: neg.s       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f2.fl = -ctx->f14.fl;
        goto L_801286F8;
    // 0x801286F0: neg.s       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f2.fl = -ctx->f14.fl;
    // 0x801286F4: mov.s       $f2, $f14
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 14);
    ctx->f2.fl = ctx->f14.fl;
L_801286F8:
    // 0x801286F8: c.lt.s      $f0, $f2
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f0.fl < ctx->f2.fl;
    // 0x801286FC: nop

    // 0x80128700: bc1fl       L_80128988
    if (!c1cs) {
        // 0x80128704: c.lt.s      $f16, $f14
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.fl < ctx->f14.fl;
            goto L_80128988;
    }
    goto skip_2;
    // 0x80128704: c.lt.s      $f16, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.fl < ctx->f14.fl;
    skip_2:
    // 0x80128708: c.lt.s      $f16, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.fl < ctx->f14.fl;
    // 0x8012870C: nop

    // 0x80128710: bc1fl       L_8012884C
    if (!c1cs) {
        // 0x80128714: c.lt.s      $f16, $f12
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
            goto L_8012884C;
    }
    goto skip_3;
    // 0x80128714: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
    skip_3:
    // 0x80128718: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
    // 0x8012871C: nop

    // 0x80128720: bc1fl       L_801287B4
    if (!c1cs) {
        // 0x80128724: neg.s       $f10, $f12
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
            goto L_801287B4;
    }
    goto skip_4;
    // 0x80128724: neg.s       $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
    skip_4:
    // 0x80128728: div.s       $f4, $f12, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = DIV_S(ctx->f12.fl, ctx->f14.fl);
    // 0x8012872C: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x80128730: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80128734: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80128738: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x8012873C: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80128740: addiu       $t0, $t0, 0x1C38
    ctx->r8 = ADD32(ctx->r8, 0X1C38);
    // 0x80128744: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x80128748: mul.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = MUL_D(ctx->f6.d, ctx->f8.d);
    // 0x8012874C: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80128750: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80128754: cvt.s.d     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f2.fl = CVT_S_D(ctx->f10.d);
    // 0x80128758: trunc.w.s   $f18, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    ctx->f18.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x8012875C: mfc1        $v0, $f18
    ctx->r2 = (int32_t)ctx->f18.u32l;
    // 0x80128760: nop

    // 0x80128764: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80128768: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8012876C: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x80128770: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x80128774: addu        $v1, $t9, $t0
    ctx->r3 = ADD32(ctx->r25, ctx->r8);
    // 0x80128778: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012877C: lwc1        $f4, 0x0($v1)
    ctx->f4.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128780: sub.s       $f16, $f2, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f6.fl;
    // 0x80128784: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x80128788: cvt.d.s     $f10, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f10.d = CVT_D_S(ctx->f16.fl);
    // 0x8012878C: sub.d       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f10.d); 
    ctx->f18.d = ctx->f8.d - ctx->f10.d;
    // 0x80128790: lwc1        $f10, 0x4($v1)
    ctx->f10.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128794: mul.d       $f8, $f18, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f18.d, ctx->f6.d);
    // 0x80128798: nop

    // 0x8012879C: mul.s       $f4, $f10, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x801287A0: cvt.d.s     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f18.d = CVT_D_S(ctx->f4.fl);
    // 0x801287A4: add.d       $f6, $f18, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f8.d); 
    ctx->f6.d = ctx->f18.d + ctx->f8.d;
    // 0x801287A8: jr          $ra
    // 0x801287AC: cvt.s.d     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f0.fl = CVT_S_D(ctx->f6.d);
    return;
    // 0x801287AC: cvt.s.d     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f0.fl = CVT_S_D(ctx->f6.d);
    // 0x801287B0: neg.s       $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
L_801287B4:
    // 0x801287B4: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x801287B8: div.s       $f4, $f10, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = DIV_S(ctx->f10.fl, ctx->f14.fl);
    // 0x801287BC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x801287C0: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x801287C4: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x801287C8: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x801287CC: addiu       $t5, $t5, 0x1C38
    ctx->r13 = ADD32(ctx->r13, 0X1C38);
    // 0x801287D0: cvt.d.s     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f18.d = CVT_D_S(ctx->f4.fl);
    // 0x801287D4: mul.d       $f6, $f18, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f8.d); 
    ctx->f6.d = MUL_D(ctx->f18.d, ctx->f8.d);
    // 0x801287D8: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x801287DC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x801287E0: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x801287E4: cvt.s.d     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f2.fl = CVT_S_D(ctx->f6.d);
    // 0x801287E8: trunc.w.s   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x801287EC: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x801287F0: nop

    // 0x801287F4: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x801287F8: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x801287FC: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x80128800: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80128804: addu        $v1, $t4, $t5
    ctx->r3 = ADD32(ctx->r12, ctx->r13);
    // 0x80128808: cvt.s.w     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    ctx->f18.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012880C: lwc1        $f4, 0x0($v1)
    ctx->f4.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128810: sub.s       $f16, $f2, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f18.fl;
    // 0x80128814: cvt.d.s     $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f18.d = CVT_D_S(ctx->f4.fl);
    // 0x80128818: cvt.d.s     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
    // 0x8012881C: sub.d       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = ctx->f8.d - ctx->f6.d;
    // 0x80128820: lwc1        $f6, 0x4($v1)
    ctx->f6.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128824: mul.d       $f8, $f10, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f8.d = MUL_D(ctx->f10.d, ctx->f18.d);
    // 0x80128828: nop

    // 0x8012882C: mul.s       $f4, $f6, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80128830: ldc1        $f6, -0x53A0($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X53A0);
    // 0x80128834: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
    // 0x80128838: add.d       $f18, $f10, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f8.d); 
    ctx->f18.d = ctx->f10.d + ctx->f8.d;
    // 0x8012883C: sub.d       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f6.d - ctx->f18.d;
    // 0x80128840: jr          $ra
    // 0x80128844: cvt.s.d     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f0.fl = CVT_S_D(ctx->f4.d);
    return;
    // 0x80128844: cvt.s.d     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f0.fl = CVT_S_D(ctx->f4.d);
    // 0x80128848: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
L_8012884C:
    // 0x8012884C: nop

    // 0x80128850: bc1fl       L_801288F4
    if (!c1cs) {
        // 0x80128854: div.s       $f10, $f12, $f14
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = DIV_S(ctx->f12.fl, ctx->f14.fl);
            goto L_801288F4;
    }
    goto skip_5;
    // 0x80128854: div.s       $f10, $f12, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = DIV_S(ctx->f12.fl, ctx->f14.fl);
    skip_5:
    // 0x80128858: neg.s       $f10, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = -ctx->f14.fl;
    // 0x8012885C: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x80128860: div.s       $f8, $f12, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = DIV_S(ctx->f12.fl, ctx->f10.fl);
    // 0x80128864: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x80128868: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x8012886C: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80128870: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80128874: addiu       $t0, $t0, 0x1C38
    ctx->r8 = ADD32(ctx->r8, 0X1C38);
    // 0x80128878: cvt.d.s     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f6.d = CVT_D_S(ctx->f8.fl);
    // 0x8012887C: mul.d       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f6.d, ctx->f18.d);
    // 0x80128880: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x80128884: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x80128888: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x8012888C: cvt.s.d     $f2, $f4
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f2.fl = CVT_S_D(ctx->f4.d);
    // 0x80128890: trunc.w.s   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80128894: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x80128898: nop

    // 0x8012889C: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x801288A0: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x801288A4: mtc1        $v0, $f8
    ctx->f8.u32l = ctx->r2;
    // 0x801288A8: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x801288AC: addu        $v1, $t9, $t0
    ctx->r3 = ADD32(ctx->r25, ctx->r8);
    // 0x801288B0: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x801288B4: lwc1        $f8, 0x0($v1)
    ctx->f8.u32l = MEM_W(ctx->r3, 0X0);
    // 0x801288B8: sub.s       $f16, $f2, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f6.fl;
    // 0x801288BC: cvt.d.s     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f6.d = CVT_D_S(ctx->f8.fl);
    // 0x801288C0: cvt.d.s     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f4.d = CVT_D_S(ctx->f16.fl);
    // 0x801288C4: sub.d       $f10, $f18, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f4.d); 
    ctx->f10.d = ctx->f18.d - ctx->f4.d;
    // 0x801288C8: lwc1        $f4, 0x4($v1)
    ctx->f4.u32l = MEM_W(ctx->r3, 0X4);
    // 0x801288CC: mul.d       $f18, $f10, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f18.d = MUL_D(ctx->f10.d, ctx->f6.d);
    // 0x801288D0: nop

    // 0x801288D4: mul.s       $f8, $f4, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f16.fl);
    // 0x801288D8: ldc1        $f4, -0x5398($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, -0X5398);
    // 0x801288DC: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x801288E0: add.d       $f6, $f10, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f6.d = ctx->f10.d + ctx->f18.d;
    // 0x801288E4: sub.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d - ctx->f6.d;
    // 0x801288E8: jr          $ra
    // 0x801288EC: cvt.s.d     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f0.fl = CVT_S_D(ctx->f8.d);
    return;
    // 0x801288EC: cvt.s.d     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f0.fl = CVT_S_D(ctx->f8.d);
    // 0x801288F0: div.s       $f10, $f12, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = DIV_S(ctx->f12.fl, ctx->f14.fl);
L_801288F4:
    // 0x801288F4: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x801288F8: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x801288FC: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80128900: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80128904: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80128908: addiu       $t5, $t5, 0x1C38
    ctx->r13 = ADD32(ctx->r13, 0X1C38);
    // 0x8012890C: cvt.d.s     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f18.d = CVT_D_S(ctx->f10.fl);
    // 0x80128910: mul.d       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = MUL_D(ctx->f18.d, ctx->f4.d);
    // 0x80128914: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80128918: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x8012891C: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80128920: cvt.s.d     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f2.fl = CVT_S_D(ctx->f6.d);
    // 0x80128924: trunc.w.s   $f8, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    ctx->f8.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80128928: mfc1        $v0, $f8
    ctx->r2 = (int32_t)ctx->f8.u32l;
    // 0x8012892C: nop

    // 0x80128930: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x80128934: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80128938: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x8012893C: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80128940: addu        $v1, $t4, $t5
    ctx->r3 = ADD32(ctx->r12, ctx->r13);
    // 0x80128944: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80128948: lwc1        $f10, 0x0($v1)
    ctx->f10.u32l = MEM_W(ctx->r3, 0X0);
    // 0x8012894C: sub.s       $f16, $f2, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f18.fl;
    // 0x80128950: cvt.d.s     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f18.d = CVT_D_S(ctx->f10.fl);
    // 0x80128954: cvt.d.s     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
    // 0x80128958: sub.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d - ctx->f6.d;
    // 0x8012895C: lwc1        $f6, 0x4($v1)
    ctx->f6.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128960: mul.d       $f4, $f8, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f8.d, ctx->f18.d);
    // 0x80128964: nop

    // 0x80128968: mul.s       $f10, $f6, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f16.fl);
    // 0x8012896C: ldc1        $f6, -0x5390($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X5390);
    // 0x80128970: cvt.d.s     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f8.d = CVT_D_S(ctx->f10.fl);
    // 0x80128974: add.d       $f18, $f8, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f4.d); 
    ctx->f18.d = ctx->f8.d + ctx->f4.d;
    // 0x80128978: add.d       $f10, $f18, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = ctx->f18.d + ctx->f6.d;
    // 0x8012897C: jr          $ra
    // 0x80128980: cvt.s.d     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f0.fl = CVT_S_D(ctx->f10.d);
    return;
    // 0x80128980: cvt.s.d     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f0.fl = CVT_S_D(ctx->f10.d);
    // 0x80128984: c.lt.s      $f16, $f14
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f16.fl < ctx->f14.fl;
L_80128988:
    // 0x80128988: nop

    // 0x8012898C: bc1fl       L_80128AD4
    if (!c1cs) {
        // 0x80128990: c.lt.s      $f16, $f12
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
            goto L_80128AD4;
    }
    goto skip_6;
    // 0x80128990: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
    skip_6:
    // 0x80128994: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
    // 0x80128998: nop

    // 0x8012899C: bc1fl       L_80128A3C
    if (!c1cs) {
        // 0x801289A0: neg.s       $f10, $f12
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
            goto L_80128A3C;
    }
    goto skip_7;
    // 0x801289A0: neg.s       $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
    skip_7:
    // 0x801289A4: div.s       $f8, $f14, $f12
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f8.fl = DIV_S(ctx->f14.fl, ctx->f12.fl);
    // 0x801289A8: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x801289AC: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x801289B0: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x801289B4: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x801289B8: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x801289BC: addiu       $t0, $t0, 0x1C38
    ctx->r8 = ADD32(ctx->r8, 0X1C38);
    // 0x801289C0: cvt.d.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f4.d = CVT_D_S(ctx->f8.fl);
    // 0x801289C4: mul.d       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f18.d); 
    ctx->f6.d = MUL_D(ctx->f4.d, ctx->f18.d);
    // 0x801289C8: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x801289CC: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x801289D0: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x801289D4: cvt.s.d     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f2.fl = CVT_S_D(ctx->f6.d);
    // 0x801289D8: trunc.w.s   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x801289DC: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x801289E0: nop

    // 0x801289E4: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x801289E8: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x801289EC: mtc1        $v0, $f8
    ctx->f8.u32l = ctx->r2;
    // 0x801289F0: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x801289F4: addu        $v1, $t9, $t0
    ctx->r3 = ADD32(ctx->r25, ctx->r8);
    // 0x801289F8: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x801289FC: lwc1        $f8, 0x0($v1)
    ctx->f8.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128A00: sub.s       $f16, $f2, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f4.fl;
    // 0x80128A04: cvt.d.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f4.d = CVT_D_S(ctx->f8.fl);
    // 0x80128A08: cvt.d.s     $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f6.d = CVT_D_S(ctx->f16.fl);
    // 0x80128A0C: sub.d       $f10, $f18, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f6.d); 
    ctx->f10.d = ctx->f18.d - ctx->f6.d;
    // 0x80128A10: lwc1        $f6, 0x4($v1)
    ctx->f6.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128A14: mul.d       $f18, $f10, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f4.d); 
    ctx->f18.d = MUL_D(ctx->f10.d, ctx->f4.d);
    // 0x80128A18: nop

    // 0x80128A1C: mul.s       $f8, $f6, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80128A20: ldc1        $f6, -0x5388($at)
    CHECK_FR(ctx, 6);
    ctx->f6.u64 = LD(ctx->r1, -0X5388);
    // 0x80128A24: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x80128A28: add.d       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f10.d + ctx->f18.d;
    // 0x80128A2C: sub.d       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f4.d); 
    ctx->f8.d = ctx->f6.d - ctx->f4.d;
    // 0x80128A30: jr          $ra
    // 0x80128A34: cvt.s.d     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f0.fl = CVT_S_D(ctx->f8.d);
    return;
    // 0x80128A34: cvt.s.d     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f0.fl = CVT_S_D(ctx->f8.d);
    // 0x80128A38: neg.s       $f10, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = -ctx->f12.fl;
L_80128A3C:
    // 0x80128A3C: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x80128A40: div.s       $f18, $f14, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = DIV_S(ctx->f14.fl, ctx->f10.fl);
    // 0x80128A44: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x80128A48: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80128A4C: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80128A50: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80128A54: addiu       $t5, $t5, 0x1C38
    ctx->r13 = ADD32(ctx->r13, 0X1C38);
    // 0x80128A58: cvt.d.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.d = CVT_D_S(ctx->f18.fl);
    // 0x80128A5C: mul.d       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f4.d); 
    ctx->f8.d = MUL_D(ctx->f6.d, ctx->f4.d);
    // 0x80128A60: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x80128A64: mtc1        $at, $f5
    ctx->f_odd[(5 - 1) * 2] = ctx->r1;
    // 0x80128A68: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80128A6C: cvt.s.d     $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.d); 
    ctx->f2.fl = CVT_S_D(ctx->f8.d);
    // 0x80128A70: trunc.w.s   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80128A74: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x80128A78: nop

    // 0x80128A7C: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x80128A80: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80128A84: mtc1        $v0, $f18
    ctx->f18.u32l = ctx->r2;
    // 0x80128A88: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80128A8C: addu        $v1, $t4, $t5
    ctx->r3 = ADD32(ctx->r12, ctx->r13);
    // 0x80128A90: cvt.s.w     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80128A94: lwc1        $f18, 0x0($v1)
    ctx->f18.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128A98: sub.s       $f16, $f2, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f6.fl;
    // 0x80128A9C: cvt.d.s     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f6.d = CVT_D_S(ctx->f18.fl);
    // 0x80128AA0: cvt.d.s     $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f8.d = CVT_D_S(ctx->f16.fl);
    // 0x80128AA4: sub.d       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = ctx->f4.d - ctx->f8.d;
    // 0x80128AA8: lwc1        $f8, 0x4($v1)
    ctx->f8.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128AAC: mul.d       $f4, $f10, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f4.d = MUL_D(ctx->f10.d, ctx->f6.d);
    // 0x80128AB0: nop

    // 0x80128AB4: mul.s       $f18, $f8, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f8.fl, ctx->f16.fl);
    // 0x80128AB8: ldc1        $f8, -0x5380($at)
    CHECK_FR(ctx, 8);
    ctx->f8.u64 = LD(ctx->r1, -0X5380);
    // 0x80128ABC: cvt.d.s     $f10, $f18
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); 
    ctx->f10.d = CVT_D_S(ctx->f18.fl);
    // 0x80128AC0: add.d       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = ctx->f10.d + ctx->f4.d;
    // 0x80128AC4: add.d       $f18, $f6, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f18.d = ctx->f6.d + ctx->f8.d;
    // 0x80128AC8: jr          $ra
    // 0x80128ACC: cvt.s.d     $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f0.fl = CVT_S_D(ctx->f18.d);
    return;
    // 0x80128ACC: cvt.s.d     $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f0.fl = CVT_S_D(ctx->f18.d);
    // 0x80128AD0: c.lt.s      $f16, $f12
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    c1cs = ctx->f16.fl < ctx->f12.fl;
L_80128AD4:
    // 0x80128AD4: nop

    // 0x80128AD8: bc1fl       L_80128B7C
    if (!c1cs) {
        // 0x80128ADC: div.s       $f10, $f14, $f12
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = DIV_S(ctx->f14.fl, ctx->f12.fl);
            goto L_80128B7C;
    }
    goto skip_8;
    // 0x80128ADC: div.s       $f10, $f14, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = DIV_S(ctx->f14.fl, ctx->f12.fl);
    skip_8:
    // 0x80128AE0: neg.s       $f10, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = -ctx->f14.fl;
    // 0x80128AE4: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x80128AE8: div.s       $f4, $f10, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = DIV_S(ctx->f10.fl, ctx->f12.fl);
    // 0x80128AEC: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80128AF0: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80128AF4: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80128AF8: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80128AFC: addiu       $t0, $t0, 0x1C38
    ctx->r8 = ADD32(ctx->r8, 0X1C38);
    // 0x80128B00: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x80128B04: mul.d       $f18, $f6, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f18.d = MUL_D(ctx->f6.d, ctx->f8.d);
    // 0x80128B08: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80128B0C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80128B10: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80128B14: cvt.s.d     $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f2.fl = CVT_S_D(ctx->f18.d);
    // 0x80128B18: trunc.w.s   $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    ctx->f10.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80128B1C: mfc1        $v0, $f10
    ctx->r2 = (int32_t)ctx->f10.u32l;
    // 0x80128B20: nop

    // 0x80128B24: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80128B28: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80128B2C: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    // 0x80128B30: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x80128B34: addu        $v1, $t9, $t0
    ctx->r3 = ADD32(ctx->r25, ctx->r8);
    // 0x80128B38: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80128B3C: lwc1        $f4, 0x0($v1)
    ctx->f4.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128B40: sub.s       $f16, $f2, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f6.fl;
    // 0x80128B44: cvt.d.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f6.d = CVT_D_S(ctx->f4.fl);
    // 0x80128B48: cvt.d.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f18.d = CVT_D_S(ctx->f16.fl);
    // 0x80128B4C: sub.d       $f10, $f8, $f18
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f18.d); 
    ctx->f10.d = ctx->f8.d - ctx->f18.d;
    // 0x80128B50: lwc1        $f18, 0x4($v1)
    ctx->f18.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128B54: mul.d       $f8, $f10, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = MUL_D(ctx->f10.d, ctx->f6.d);
    // 0x80128B58: nop

    // 0x80128B5C: mul.s       $f4, $f18, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f16.fl);
    // 0x80128B60: ldc1        $f18, -0x5378($at)
    CHECK_FR(ctx, 18);
    ctx->f18.u64 = LD(ctx->r1, -0X5378);
    // 0x80128B64: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
    // 0x80128B68: add.d       $f6, $f10, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f8.d); 
    ctx->f6.d = ctx->f10.d + ctx->f8.d;
    // 0x80128B6C: add.d       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f6.d + ctx->f18.d;
    // 0x80128B70: jr          $ra
    // 0x80128B74: cvt.s.d     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f0.fl = CVT_S_D(ctx->f4.d);
    return;
    // 0x80128B74: cvt.s.d     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f0.fl = CVT_S_D(ctx->f4.d);
    // 0x80128B78: div.s       $f10, $f14, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = DIV_S(ctx->f14.fl, ctx->f12.fl);
L_80128B7C:
    // 0x80128B7C: lui         $at, 0x4070
    ctx->r1 = S32(0X4070 << 16);
    // 0x80128B80: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80128B84: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80128B88: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80128B8C: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80128B90: addiu       $t5, $t5, 0x1C38
    ctx->r13 = ADD32(ctx->r13, 0X1C38);
    // 0x80128B94: cvt.d.s     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f8.d = CVT_D_S(ctx->f10.fl);
    // 0x80128B98: mul.d       $f18, $f8, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f6.d); 
    ctx->f18.d = MUL_D(ctx->f8.d, ctx->f6.d);
    // 0x80128B9C: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80128BA0: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80128BA4: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80128BA8: cvt.s.d     $f2, $f18
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f2.fl = CVT_S_D(ctx->f18.d);
    // 0x80128BAC: trunc.w.s   $f4, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    ctx->f4.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80128BB0: mfc1        $v0, $f4
    ctx->r2 = (int32_t)ctx->f4.u32l;
    // 0x80128BB4: nop

    // 0x80128BB8: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x80128BBC: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80128BC0: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x80128BC4: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80128BC8: addu        $v1, $t4, $t5
    ctx->r3 = ADD32(ctx->r12, ctx->r13);
    // 0x80128BCC: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80128BD0: lwc1        $f10, 0x0($v1)
    ctx->f10.u32l = MEM_W(ctx->r3, 0X0);
    // 0x80128BD4: sub.s       $f16, $f2, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f2.fl - ctx->f8.fl;
    // 0x80128BD8: cvt.d.s     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f8.d = CVT_D_S(ctx->f10.fl);
    // 0x80128BDC: cvt.d.s     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f18.d = CVT_D_S(ctx->f16.fl);
    // 0x80128BE0: sub.d       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = ctx->f6.d - ctx->f18.d;
    // 0x80128BE4: lwc1        $f18, 0x4($v1)
    ctx->f18.u32l = MEM_W(ctx->r3, 0X4);
    // 0x80128BE8: mul.d       $f6, $f4, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f8.d); 
    ctx->f6.d = MUL_D(ctx->f4.d, ctx->f8.d);
    // 0x80128BEC: nop

    // 0x80128BF0: mul.s       $f10, $f18, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = MUL_S(ctx->f18.fl, ctx->f16.fl);
    // 0x80128BF4: ldc1        $f18, -0x5370($at)
    CHECK_FR(ctx, 18);
    ctx->f18.u64 = LD(ctx->r1, -0X5370);
    // 0x80128BF8: cvt.d.s     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f4.d = CVT_D_S(ctx->f10.fl);
    // 0x80128BFC: add.d       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.d); NAN_CHECK(ctx->f6.d); 
    ctx->f8.d = ctx->f4.d + ctx->f6.d;
    // 0x80128C00: sub.d       $f10, $f18, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = ctx->f18.d - ctx->f8.d;
    // 0x80128C04: cvt.s.d     $f0, $f10
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f0.fl = CVT_S_D(ctx->f10.d);
    // 0x80128C08: jr          $ra
    // 0x80128C0C: nop

    return;
    // 0x80128C0C: nop

;}
RECOMP_FUNC void func_80128C10(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128C10: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80128C14: subu        $v1, $a3, $a1
    ctx->r3 = SUB32(ctx->r7, ctx->r5);
    // 0x80128C18: bne         $v1, $zero, L_80128C24
    if (ctx->r3 != 0) {
        // 0x80128C1C: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_80128C24;
    }
    // 0x80128C1C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80128C20: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80128C24:
    // 0x80128C24: subu        $v0, $a2, $a0
    ctx->r2 = SUB32(ctx->r6, ctx->r4);
    // 0x80128C28: blez        $v0, L_80128CDC
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80128C2C: nop
    
            goto L_80128CDC;
    }
    // 0x80128C2C: nop

    // 0x80128C30: blezl       $v1, L_80128C90
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80128C34: sll         $t2, $v0, 6
        ctx->r10 = S32(ctx->r2 << 6);
            goto L_80128C90;
    }
    goto skip_0;
    // 0x80128C34: sll         $t2, $v0, 6
    ctx->r10 = S32(ctx->r2 << 6);
    skip_0:
    // 0x80128C38: sll         $t6, $v0, 6
    ctx->r14 = S32(ctx->r2 << 6);
    // 0x80128C3C: div         $zero, $t6, $v1
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r3)));
    // 0x80128C40: mflo        $a0
    ctx->r4 = lo;
    // 0x80128C44: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80128C48: bne         $v1, $zero, L_80128C54
    if (ctx->r3 != 0) {
        // 0x80128C4C: nop
    
            goto L_80128C54;
    }
    // 0x80128C4C: nop

    // 0x80128C50: break       7
    do_break(2148699216);
L_80128C54:
    // 0x80128C54: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128C58: bne         $v1, $at, L_80128C6C
    if (ctx->r3 != ctx->r1) {
        // 0x80128C5C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128C6C;
    }
    // 0x80128C5C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128C60: bne         $t6, $at, L_80128C6C
    if (ctx->r14 != ctx->r1) {
        // 0x80128C64: nop
    
            goto L_80128C6C;
    }
    // 0x80128C64: nop

    // 0x80128C68: break       6
    do_break(2148699240);
L_80128C6C:
    // 0x80128C6C: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80128C70: jal         0x8012844C
    // 0x80128C74: nop

    func_8012844C(rdram, ctx);
        goto after_0;
    // 0x80128C74: nop

    after_0:
    // 0x80128C78: addiu       $t9, $zero, 0xB4
    ctx->r25 = ADD32(0, 0XB4);
    // 0x80128C7C: subu        $v1, $t9, $v0
    ctx->r3 = SUB32(ctx->r25, ctx->r2);
    // 0x80128C80: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x80128C84: b           L_80128D88
    // 0x80128C88: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
        goto L_80128D88;
    // 0x80128C88: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80128C8C: sll         $t2, $v0, 6
    ctx->r10 = S32(ctx->r2 << 6);
L_80128C90:
    // 0x80128C90: div         $zero, $t2, $v1
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r3)));
    // 0x80128C94: mflo        $a0
    ctx->r4 = lo;
    // 0x80128C98: sll         $t3, $a0, 16
    ctx->r11 = S32(ctx->r4 << 16);
    // 0x80128C9C: bne         $v1, $zero, L_80128CA8
    if (ctx->r3 != 0) {
        // 0x80128CA0: nop
    
            goto L_80128CA8;
    }
    // 0x80128CA0: nop

    // 0x80128CA4: break       7
    do_break(2148699300);
L_80128CA8:
    // 0x80128CA8: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128CAC: bne         $v1, $at, L_80128CC0
    if (ctx->r3 != ctx->r1) {
        // 0x80128CB0: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128CC0;
    }
    // 0x80128CB0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128CB4: bne         $t2, $at, L_80128CC0
    if (ctx->r10 != ctx->r1) {
        // 0x80128CB8: nop
    
            goto L_80128CC0;
    }
    // 0x80128CB8: nop

    // 0x80128CBC: break       6
    do_break(2148699324);
L_80128CC0:
    // 0x80128CC0: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80128CC4: jal         0x8012844C
    // 0x80128CC8: nop

    func_8012844C(rdram, ctx);
        goto after_1;
    // 0x80128CC8: nop

    after_1:
    // 0x80128CCC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80128CD0: sll         $t5, $v1, 16
    ctx->r13 = S32(ctx->r3 << 16);
    // 0x80128CD4: b           L_80128D88
    // 0x80128CD8: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
        goto L_80128D88;
    // 0x80128CD8: sra         $v1, $t5, 16
    ctx->r3 = S32(SIGNED(ctx->r13) >> 16);
L_80128CDC:
    // 0x80128CDC: blezl       $v1, L_80128D3C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80128CE0: sll         $t3, $v0, 6
        ctx->r11 = S32(ctx->r2 << 6);
            goto L_80128D3C;
    }
    goto skip_1;
    // 0x80128CE0: sll         $t3, $v0, 6
    ctx->r11 = S32(ctx->r2 << 6);
    skip_1:
    // 0x80128CE4: sll         $t7, $v0, 6
    ctx->r15 = S32(ctx->r2 << 6);
    // 0x80128CE8: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x80128CEC: mflo        $a0
    ctx->r4 = lo;
    // 0x80128CF0: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80128CF4: bne         $v1, $zero, L_80128D00
    if (ctx->r3 != 0) {
        // 0x80128CF8: nop
    
            goto L_80128D00;
    }
    // 0x80128CF8: nop

    // 0x80128CFC: break       7
    do_break(2148699388);
L_80128D00:
    // 0x80128D00: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128D04: bne         $v1, $at, L_80128D18
    if (ctx->r3 != ctx->r1) {
        // 0x80128D08: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128D18;
    }
    // 0x80128D08: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128D0C: bne         $t7, $at, L_80128D18
    if (ctx->r15 != ctx->r1) {
        // 0x80128D10: nop
    
            goto L_80128D18;
    }
    // 0x80128D10: nop

    // 0x80128D14: break       6
    do_break(2148699412);
L_80128D18:
    // 0x80128D18: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80128D1C: jal         0x8012844C
    // 0x80128D20: nop

    func_8012844C(rdram, ctx);
        goto after_2;
    // 0x80128D20: nop

    after_2:
    // 0x80128D24: addiu       $t0, $zero, 0xB4
    ctx->r8 = ADD32(0, 0XB4);
    // 0x80128D28: subu        $v1, $t0, $v0
    ctx->r3 = SUB32(ctx->r8, ctx->r2);
    // 0x80128D2C: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x80128D30: b           L_80128D88
    // 0x80128D34: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
        goto L_80128D88;
    // 0x80128D34: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80128D38: sll         $t3, $v0, 6
    ctx->r11 = S32(ctx->r2 << 6);
L_80128D3C:
    // 0x80128D3C: div         $zero, $t3, $v1
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r3)));
    // 0x80128D40: mflo        $a0
    ctx->r4 = lo;
    // 0x80128D44: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x80128D48: bne         $v1, $zero, L_80128D54
    if (ctx->r3 != 0) {
        // 0x80128D4C: nop
    
            goto L_80128D54;
    }
    // 0x80128D4C: nop

    // 0x80128D50: break       7
    do_break(2148699472);
L_80128D54:
    // 0x80128D54: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80128D58: bne         $v1, $at, L_80128D6C
    if (ctx->r3 != ctx->r1) {
        // 0x80128D5C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80128D6C;
    }
    // 0x80128D5C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80128D60: bne         $t3, $at, L_80128D6C
    if (ctx->r11 != ctx->r1) {
        // 0x80128D64: nop
    
            goto L_80128D6C;
    }
    // 0x80128D64: nop

    // 0x80128D68: break       6
    do_break(2148699496);
L_80128D6C:
    // 0x80128D6C: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80128D70: jal         0x8012844C
    // 0x80128D74: nop

    func_8012844C(rdram, ctx);
        goto after_3;
    // 0x80128D74: nop

    after_3:
    // 0x80128D78: addiu       $t6, $zero, 0x168
    ctx->r14 = ADD32(0, 0X168);
    // 0x80128D7C: subu        $v1, $t6, $v0
    ctx->r3 = SUB32(ctx->r14, ctx->r2);
    // 0x80128D80: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x80128D84: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
L_80128D88:
    // 0x80128D88: bgez        $v1, L_80128DA0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80128D8C: addiu       $t3, $zero, 0x168
        ctx->r11 = ADD32(0, 0X168);
            goto L_80128DA0;
    }
    // 0x80128D8C: addiu       $t3, $zero, 0x168
    ctx->r11 = ADD32(0, 0X168);
    // 0x80128D90: addiu       $v1, $v1, 0x168
    ctx->r3 = ADD32(ctx->r3, 0X168);
    // 0x80128D94: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x80128D98: b           L_80128DB8
    // 0x80128D9C: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
        goto L_80128DB8;
    // 0x80128D9C: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
L_80128DA0:
    // 0x80128DA0: slti        $at, $v1, 0x168
    ctx->r1 = SIGNED(ctx->r3) < 0X168 ? 1 : 0;
    // 0x80128DA4: bnel        $at, $zero, L_80128DBC
    if (ctx->r1 != 0) {
        // 0x80128DA8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80128DBC;
    }
    goto skip_2;
    // 0x80128DA8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x80128DAC: addiu       $v1, $v1, -0x168
    ctx->r3 = ADD32(ctx->r3, -0X168);
    // 0x80128DB0: sll         $t1, $v1, 16
    ctx->r9 = S32(ctx->r3 << 16);
    // 0x80128DB4: sra         $v1, $t1, 16
    ctx->r3 = S32(SIGNED(ctx->r9) >> 16);
L_80128DB8:
    // 0x80128DB8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80128DBC:
    // 0x80128DBC: subu        $v1, $t3, $v1
    ctx->r3 = SUB32(ctx->r11, ctx->r3);
    // 0x80128DC0: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x80128DC4: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80128DC8: jr          $ra
    // 0x80128DCC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x80128DCC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void strlen_sssv(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128DD0: bnel        $a0, $zero, L_80128DE4
    if (ctx->r4 != 0) {
        // 0x80128DD4: lbu         $t6, 0x0($a0)
        ctx->r14 = MEM_BU(ctx->r4, 0X0);
            goto L_80128DE4;
    }
    goto skip_0;
    // 0x80128DD4: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    skip_0:
    // 0x80128DD8: jr          $ra
    // 0x80128DDC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80128DDC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80128DE0: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
L_80128DE4:
    // 0x80128DE4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80128DE8: beql        $t6, $zero, L_80128E10
    if (ctx->r14 == 0) {
        // 0x80128DEC: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_80128E10;
    }
    goto skip_1;
    // 0x80128DEC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    skip_1:
    // 0x80128DF0: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_80128DF4:
    // 0x80128DF4: andi        $t7, $v1, 0xFFFF
    ctx->r15 = ctx->r3 & 0XFFFF;
    // 0x80128DF8: addu        $t8, $t7, $a0
    ctx->r24 = ADD32(ctx->r15, ctx->r4);
    // 0x80128DFC: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x80128E00: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x80128E04: bnel        $t9, $zero, L_80128DF4
    if (ctx->r25 != 0) {
        // 0x80128E08: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_80128DF4;
    }
    goto skip_2;
    // 0x80128E08: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    skip_2:
    // 0x80128E0C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
L_80128E10:
    // 0x80128E10: jr          $ra
    // 0x80128E14: nop

    return;
    // 0x80128E14: nop

;}
RECOMP_FUNC void strcat_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128E18: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80128E1C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80128E20: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x80128E24: jal         0x80128DD0
    // 0x80128E28: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    strlen_sssv(rdram, ctx);
        goto after_0;
    // 0x80128E28: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x80128E2C: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80128E30: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x80128E34: andi        $v1, $v0, 0xFFFF
    ctx->r3 = ctx->r2 & 0XFFFF;
    // 0x80128E38: lbu         $t6, 0x0($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X0);
    // 0x80128E3C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80128E40: beql        $t6, $zero, L_80128E7C
    if (ctx->r14 == 0) {
        // 0x80128E44: addu        $t1, $a2, $v1
        ctx->r9 = ADD32(ctx->r6, ctx->r3);
            goto L_80128E7C;
    }
    goto skip_0;
    // 0x80128E44: addu        $t1, $a2, $v1
    ctx->r9 = ADD32(ctx->r6, ctx->r3);
    skip_0:
    // 0x80128E48: lbu         $v0, 0x0($a1)
    ctx->r2 = MEM_BU(ctx->r5, 0X0);
L_80128E4C:
    // 0x80128E4C: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80128E50: addu        $t7, $a2, $v1
    ctx->r15 = ADD32(ctx->r6, ctx->r3);
    // 0x80128E54: andi        $t9, $a0, 0xFFFF
    ctx->r25 = ctx->r4 & 0XFFFF;
    // 0x80128E58: sb          $v0, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r2;
    // 0x80128E5C: addu        $t0, $t9, $a1
    ctx->r8 = ADD32(ctx->r25, ctx->r5);
    // 0x80128E60: lbu         $v0, 0x0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X0);
    // 0x80128E64: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80128E68: andi        $t8, $v1, 0xFFFF
    ctx->r24 = ctx->r3 & 0XFFFF;
    // 0x80128E6C: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x80128E70: bne         $v0, $zero, L_80128E4C
    if (ctx->r2 != 0) {
        // 0x80128E74: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_80128E4C;
    }
    // 0x80128E74: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80128E78: addu        $t1, $a2, $v1
    ctx->r9 = ADD32(ctx->r6, ctx->r3);
L_80128E7C:
    // 0x80128E7C: sb          $zero, 0x0($t1)
    MEM_B(0X0, ctx->r9) = 0;
    // 0x80128E80: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80128E84: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80128E88: jr          $ra
    // 0x80128E8C: nop

    return;
    // 0x80128E8C: nop

;}
RECOMP_FUNC void strcpy_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128E90: lbu         $t6, 0x0($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X0);
    // 0x80128E94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80128E98: beql        $t6, $zero, L_80128ECC
    if (ctx->r14 == 0) {
        // 0x80128E9C: addu        $t0, $a0, $v0
        ctx->r8 = ADD32(ctx->r4, ctx->r2);
            goto L_80128ECC;
    }
    goto skip_0;
    // 0x80128E9C: addu        $t0, $a0, $v0
    ctx->r8 = ADD32(ctx->r4, ctx->r2);
    skip_0:
    // 0x80128EA0: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80128EA4: addu        $t7, $a0, $v0
    ctx->r15 = ADD32(ctx->r4, ctx->r2);
L_80128EA8:
    // 0x80128EA8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80128EAC: andi        $t8, $v0, 0xFFFF
    ctx->r24 = ctx->r2 & 0XFFFF;
    // 0x80128EB0: sb          $v1, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r3;
    // 0x80128EB4: addu        $t9, $t8, $a1
    ctx->r25 = ADD32(ctx->r24, ctx->r5);
    // 0x80128EB8: lbu         $v1, 0x0($t9)
    ctx->r3 = MEM_BU(ctx->r25, 0X0);
    // 0x80128EBC: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x80128EC0: bnel        $v1, $zero, L_80128EA8
    if (ctx->r3 != 0) {
        // 0x80128EC4: addu        $t7, $a0, $v0
        ctx->r15 = ADD32(ctx->r4, ctx->r2);
            goto L_80128EA8;
    }
    goto skip_1;
    // 0x80128EC4: addu        $t7, $a0, $v0
    ctx->r15 = ADD32(ctx->r4, ctx->r2);
    skip_1:
    // 0x80128EC8: addu        $t0, $a0, $v0
    ctx->r8 = ADD32(ctx->r4, ctx->r2);
L_80128ECC:
    // 0x80128ECC: jr          $ra
    // 0x80128ED0: sb          $zero, 0x0($t0)
    MEM_B(0X0, ctx->r8) = 0;
    return;
    // 0x80128ED0: sb          $zero, 0x0($t0)
    MEM_B(0X0, ctx->r8) = 0;
;}
RECOMP_FUNC void strncpy_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128ED4: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80128ED8: lbu         $t8, 0x0($a1)
    ctx->r24 = MEM_BU(ctx->r5, 0X0);
    // 0x80128EDC: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x80128EE0: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80128EE4: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x80128EE8: beq         $t8, $zero, L_80128F2C
    if (ctx->r24 == 0) {
        // 0x80128EEC: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80128F2C;
    }
    // 0x80128EEC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80128EF0: blezl       $t7, L_80128F30
    if (SIGNED(ctx->r15) <= 0) {
        // 0x80128EF4: addu        $t3, $a0, $v0
        ctx->r11 = ADD32(ctx->r4, ctx->r2);
            goto L_80128F30;
    }
    goto skip_0;
    // 0x80128EF4: addu        $t3, $a0, $v0
    ctx->r11 = ADD32(ctx->r4, ctx->r2);
    skip_0:
    // 0x80128EF8: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80128EFC: addu        $t0, $a0, $v0
    ctx->r8 = ADD32(ctx->r4, ctx->r2);
L_80128F00:
    // 0x80128F00: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80128F04: andi        $t1, $v0, 0xFFFF
    ctx->r9 = ctx->r2 & 0XFFFF;
    // 0x80128F08: sb          $v1, 0x0($t0)
    MEM_B(0X0, ctx->r8) = ctx->r3;
    // 0x80128F0C: addu        $t2, $t1, $a1
    ctx->r10 = ADD32(ctx->r9, ctx->r5);
    // 0x80128F10: lbu         $v1, 0x0($t2)
    ctx->r3 = MEM_BU(ctx->r10, 0X0);
    // 0x80128F14: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
    // 0x80128F18: slt         $at, $t1, $a2
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80128F1C: beql        $v1, $zero, L_80128F30
    if (ctx->r3 == 0) {
        // 0x80128F20: addu        $t3, $a0, $v0
        ctx->r11 = ADD32(ctx->r4, ctx->r2);
            goto L_80128F30;
    }
    goto skip_1;
    // 0x80128F20: addu        $t3, $a0, $v0
    ctx->r11 = ADD32(ctx->r4, ctx->r2);
    skip_1:
    // 0x80128F24: bnel        $at, $zero, L_80128F00
    if (ctx->r1 != 0) {
        // 0x80128F28: addu        $t0, $a0, $v0
        ctx->r8 = ADD32(ctx->r4, ctx->r2);
            goto L_80128F00;
    }
    goto skip_2;
    // 0x80128F28: addu        $t0, $a0, $v0
    ctx->r8 = ADD32(ctx->r4, ctx->r2);
    skip_2:
L_80128F2C:
    // 0x80128F2C: addu        $t3, $a0, $v0
    ctx->r11 = ADD32(ctx->r4, ctx->r2);
L_80128F30:
    // 0x80128F30: jr          $ra
    // 0x80128F34: sb          $zero, 0x0($t3)
    MEM_B(0X0, ctx->r11) = 0;
    return;
    // 0x80128F34: sb          $zero, 0x0($t3)
    MEM_B(0X0, ctx->r11) = 0;
;}
RECOMP_FUNC void strcmp_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128F38: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x80128F3C: bne         $v0, $zero, L_80128F58
    if (ctx->r2 != 0) {
        // 0x80128F40: nop
    
            goto L_80128F58;
    }
    // 0x80128F40: nop

    // 0x80128F44: lbu         $t6, 0x0($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X0);
    // 0x80128F48: bne         $t6, $zero, L_80128F58
    if (ctx->r14 != 0) {
        // 0x80128F4C: nop
    
            goto L_80128F58;
    }
    // 0x80128F4C: nop

    // 0x80128F50: jr          $ra
    // 0x80128F54: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80128F54: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80128F58:
    // 0x80128F58: beql        $v0, $zero, L_80128F98
    if (ctx->r2 == 0) {
        // 0x80128F5C: lbu         $t7, 0x0($a1)
        ctx->r15 = MEM_BU(ctx->r5, 0X0);
            goto L_80128F98;
    }
    goto skip_0;
    // 0x80128F5C: lbu         $t7, 0x0($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X0);
    skip_0:
    // 0x80128F60: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80128F64: beq         $v1, $zero, L_80128F94
    if (ctx->r3 == 0) {
        // 0x80128F68: addiu       $a0, $a0, 0x1
        ctx->r4 = ADD32(ctx->r4, 0X1);
            goto L_80128F94;
    }
    // 0x80128F68: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
L_80128F6C:
    // 0x80128F6C: beq         $v0, $v1, L_80128F7C
    if (ctx->r2 == ctx->r3) {
        // 0x80128F70: addiu       $a1, $a1, 0x1
        ctx->r5 = ADD32(ctx->r5, 0X1);
            goto L_80128F7C;
    }
    // 0x80128F70: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x80128F74: jr          $ra
    // 0x80128F78: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80128F78: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80128F7C:
    // 0x80128F7C: lbu         $v0, 0x0($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X0);
    // 0x80128F80: beql        $v0, $zero, L_80128F98
    if (ctx->r2 == 0) {
        // 0x80128F84: lbu         $t7, 0x0($a1)
        ctx->r15 = MEM_BU(ctx->r5, 0X0);
            goto L_80128F98;
    }
    goto skip_1;
    // 0x80128F84: lbu         $t7, 0x0($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X0);
    skip_1:
    // 0x80128F88: lbu         $v1, 0x0($a1)
    ctx->r3 = MEM_BU(ctx->r5, 0X0);
    // 0x80128F8C: bnel        $v1, $zero, L_80128F6C
    if (ctx->r3 != 0) {
        // 0x80128F90: addiu       $a0, $a0, 0x1
        ctx->r4 = ADD32(ctx->r4, 0X1);
            goto L_80128F6C;
    }
    goto skip_2;
    // 0x80128F90: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    skip_2:
L_80128F94:
    // 0x80128F94: lbu         $t7, 0x0($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X0);
L_80128F98:
    // 0x80128F98: bnel        $v0, $t7, L_80128FAC
    if (ctx->r2 != ctx->r15) {
        // 0x80128F9C: addiu       $v0, $zero, 0x1
        ctx->r2 = ADD32(0, 0X1);
            goto L_80128FAC;
    }
    goto skip_3;
    // 0x80128F9C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    skip_3:
    // 0x80128FA0: jr          $ra
    // 0x80128FA4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    return;
    // 0x80128FA4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80128FA8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80128FAC:
    // 0x80128FAC: jr          $ra
    // 0x80128FB0: nop

    return;
    // 0x80128FB0: nop

;}
RECOMP_FUNC void bzero_sssv(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80128FB4: andi        $v1, $a0, 0x7
    ctx->r3 = ctx->r4 & 0X7;
    // 0x80128FB8: beq         $v1, $zero, L_80128FFC
    if (ctx->r3 == 0) {
        // 0x80128FBC: addiu       $t6, $zero, 0x8
        ctx->r14 = ADD32(0, 0X8);
            goto L_80128FFC;
    }
    // 0x80128FBC: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    // 0x80128FC0: subu        $v0, $t6, $v1
    ctx->r2 = SUB32(ctx->r14, ctx->r3);
    // 0x80128FC4: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80128FC8: beq         $at, $zero, L_80128FD4
    if (ctx->r1 == 0) {
        // 0x80128FCC: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80128FD4;
    }
    // 0x80128FCC: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x80128FD0: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
L_80128FD4:
    // 0x80128FD4: subu        $a1, $a1, $v0
    ctx->r5 = SUB32(ctx->r5, ctx->r2);
    // 0x80128FD8: slt         $a2, $zero, $v0
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80128FDC: beq         $a2, $zero, L_80128FF8
    if (ctx->r6 == 0) {
        // 0x80128FE0: addiu       $v0, $v0, -0x1
        ctx->r2 = ADD32(ctx->r2, -0X1);
            goto L_80128FF8;
    }
    // 0x80128FE0: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
L_80128FE4:
    // 0x80128FE4: slt         $a2, $zero, $v0
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80128FE8: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x80128FEC: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
    // 0x80128FF0: bne         $a2, $zero, L_80128FE4
    if (ctx->r6 != 0) {
        // 0x80128FF4: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_80128FE4;
    }
    // 0x80128FF4: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_80128FF8:
    // 0x80128FF8: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_80128FFC:
    // 0x80128FFC: sra         $t7, $a1, 3
    ctx->r15 = S32(SIGNED(ctx->r5) >> 3);
    // 0x80129000: andi        $v0, $a1, 0x7
    ctx->r2 = ctx->r5 & 0X7;
    // 0x80129004: slt         $a2, $zero, $t7
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80129008: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x8012900C: beq         $a2, $zero, L_80129034
    if (ctx->r6 == 0) {
        // 0x80129010: addiu       $a1, $t7, -0x1
        ctx->r5 = ADD32(ctx->r15, -0X1);
            goto L_80129034;
    }
    // 0x80129010: addiu       $a1, $t7, -0x1
    ctx->r5 = ADD32(ctx->r15, -0X1);
L_80129014:
    // 0x80129014: addiu       $t8, $zero, 0x0
    ctx->r24 = ADD32(0, 0X0);
    // 0x80129018: addiu       $t9, $zero, 0x0
    ctx->r25 = ADD32(0, 0X0);
    // 0x8012901C: slt         $a2, $zero, $a1
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x80129020: addiu       $a1, $a1, -0x1
    ctx->r5 = ADD32(ctx->r5, -0X1);
    // 0x80129024: sw          $t9, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r25;
    // 0x80129028: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x8012902C: bne         $a2, $zero, L_80129014
    if (ctx->r6 != 0) {
        // 0x80129030: addiu       $a3, $a3, 0x8
        ctx->r7 = ADD32(ctx->r7, 0X8);
            goto L_80129014;
    }
    // 0x80129030: addiu       $a3, $a3, 0x8
    ctx->r7 = ADD32(ctx->r7, 0X8);
L_80129034:
    // 0x80129034: slt         $a2, $zero, $v0
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80129038: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x8012903C: beq         $a2, $zero, L_80129058
    if (ctx->r6 == 0) {
        // 0x80129040: addiu       $v0, $v0, -0x1
        ctx->r2 = ADD32(ctx->r2, -0X1);
            goto L_80129058;
    }
    // 0x80129040: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
L_80129044:
    // 0x80129044: slt         $a2, $zero, $v0
    ctx->r6 = SIGNED(0) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80129048: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x8012904C: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
    // 0x80129050: bne         $a2, $zero, L_80129044
    if (ctx->r6 != 0) {
        // 0x80129054: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_80129044;
    }
    // 0x80129054: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_80129058:
    // 0x80129058: jr          $ra
    // 0x8012905C: nop

    return;
    // 0x8012905C: nop

;}
RECOMP_FUNC void memset_words(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129060: sltiu       $v0, $a2, 0x1
    ctx->r2 = ctx->r6 < 0X1 ? 1 : 0;
    // 0x80129064: xori        $v0, $v0, 0x1
    ctx->r2 = ctx->r2 ^ 0X1;
    // 0x80129068: beq         $v0, $zero, L_80129088
    if (ctx->r2 == 0) {
        // 0x8012906C: addiu       $a2, $a2, -0x1
        ctx->r6 = ADD32(ctx->r6, -0X1);
            goto L_80129088;
    }
    // 0x8012906C: addiu       $a2, $a2, -0x1
    ctx->r6 = ADD32(ctx->r6, -0X1);
L_80129070:
    // 0x80129070: sltiu       $v0, $a2, 0x1
    ctx->r2 = ctx->r6 < 0X1 ? 1 : 0;
    // 0x80129074: xori        $v0, $v0, 0x1
    ctx->r2 = ctx->r2 ^ 0X1;
    // 0x80129078: addiu       $a2, $a2, -0x1
    ctx->r6 = ADD32(ctx->r6, -0X1);
    // 0x8012907C: sw          $a1, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r5;
    // 0x80129080: bne         $v0, $zero, L_80129070
    if (ctx->r2 != 0) {
        // 0x80129084: addiu       $a0, $a0, 0x4
        ctx->r4 = ADD32(ctx->r4, 0X4);
            goto L_80129070;
    }
    // 0x80129084: addiu       $a0, $a0, 0x4
    ctx->r4 = ADD32(ctx->r4, 0X4);
L_80129088:
    // 0x80129088: jr          $ra
    // 0x8012908C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    return;
    // 0x8012908C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
;}
RECOMP_FUNC void memset_bytes(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129090: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80129094: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80129098: sltiu       $at, $a2, 0x4
    ctx->r1 = ctx->r6 < 0X4 ? 1 : 0;
    // 0x8012909C: andi        $s0, $a1, 0xFF
    ctx->r16 = ctx->r5 & 0XFF;
    // 0x801290A0: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801290A4: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x801290A8: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x801290AC: bne         $at, $zero, L_801290EC
    if (ctx->r1 != 0) {
        // 0x801290B0: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_801290EC;
    }
    // 0x801290B0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    // 0x801290B4: sll         $t6, $s0, 8
    ctx->r14 = S32(ctx->r16 << 8);
    // 0x801290B8: or          $v1, $t6, $s0
    ctx->r3 = ctx->r14 | ctx->r16;
    // 0x801290BC: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x801290C0: or          $a1, $t7, $v1
    ctx->r5 = ctx->r15 | ctx->r3;
    // 0x801290C4: or          $v0, $s0, $zero
    ctx->r2 = ctx->r16 | 0;
    // 0x801290C8: srl         $a2, $a2, 2
    ctx->r6 = S32(U32(ctx->r6) >> 2);
    // 0x801290CC: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x801290D0: jal         0x80129060
    // 0x801290D4: sw          $a3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r7;
    memset_words(rdram, ctx);
        goto after_0;
    // 0x801290D4: sw          $a3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r7;
    after_0:
    // 0x801290D8: lw          $a3, 0x28($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X28);
    // 0x801290DC: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x801290E0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x801290E4: andi        $t8, $a3, 0x3
    ctx->r24 = ctx->r7 & 0X3;
    // 0x801290E8: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
L_801290EC:
    // 0x801290EC: sltiu       $v0, $a3, 0x1
    ctx->r2 = ctx->r7 < 0X1 ? 1 : 0;
    // 0x801290F0: xori        $v0, $v0, 0x1
    ctx->r2 = ctx->r2 ^ 0X1;
    // 0x801290F4: beq         $v0, $zero, L_80129114
    if (ctx->r2 == 0) {
        // 0x801290F8: addiu       $a3, $a3, -0x1
        ctx->r7 = ADD32(ctx->r7, -0X1);
            goto L_80129114;
    }
    // 0x801290F8: addiu       $a3, $a3, -0x1
    ctx->r7 = ADD32(ctx->r7, -0X1);
L_801290FC:
    // 0x801290FC: sltiu       $v0, $a3, 0x1
    ctx->r2 = ctx->r7 < 0X1 ? 1 : 0;
    // 0x80129100: xori        $v0, $v0, 0x1
    ctx->r2 = ctx->r2 ^ 0X1;
    // 0x80129104: addiu       $a3, $a3, -0x1
    ctx->r7 = ADD32(ctx->r7, -0X1);
    // 0x80129108: sb          $s0, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r16;
    // 0x8012910C: bne         $v0, $zero, L_801290FC
    if (ctx->r2 != 0) {
        // 0x80129110: addiu       $v1, $v1, 0x1
        ctx->r3 = ADD32(ctx->r3, 0X1);
            goto L_801290FC;
    }
    // 0x80129110: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
L_80129114:
    // 0x80129114: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80129118: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012911C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80129120: jr          $ra
    // 0x80129124: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    return;
    // 0x80129124: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
;}
RECOMP_FUNC void rand_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129128: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8012912C: lw          $v1, 0x2E80($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X2E80);
    // 0x80129130: lui         $at, 0x41C6
    ctx->r1 = S32(0X41C6 << 16);
    // 0x80129134: ori         $at, $at, 0x4E6D
    ctx->r1 = ctx->r1 | 0X4E6D;
    // 0x80129138: multu       $v1, $at
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r1)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012913C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80129140: mflo        $t6
    ctx->r14 = lo;
    // 0x80129144: addiu       $v1, $t6, 0x3039
    ctx->r3 = ADD32(ctx->r14, 0X3039);
    // 0x80129148: srl         $t7, $v1, 16
    ctx->r15 = S32(U32(ctx->r3) >> 16);
    // 0x8012914C: andi        $v0, $t7, 0x7FFF
    ctx->r2 = ctx->r15 & 0X7FFF;
    // 0x80129150: jr          $ra
    // 0x80129154: sw          $v1, 0x2E80($at)
    MEM_W(0X2E80, ctx->r1) = ctx->r3;
    return;
    // 0x80129154: sw          $v1, 0x2E80($at)
    MEM_W(0X2E80, ctx->r1) = ctx->r3;
;}
RECOMP_FUNC void memcpy_sssv(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129158: sltiu       $a3, $a2, 0x1
    ctx->r7 = ctx->r6 < 0X1 ? 1 : 0;
    // 0x8012915C: xori        $a3, $a3, 0x1
    ctx->r7 = ctx->r7 ^ 0X1;
    // 0x80129160: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x80129164: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x80129168: beq         $a3, $zero, L_80129190
    if (ctx->r7 == 0) {
        // 0x8012916C: addiu       $a2, $a2, -0x1
        ctx->r6 = ADD32(ctx->r6, -0X1);
            goto L_80129190;
    }
    // 0x8012916C: addiu       $a2, $a2, -0x1
    ctx->r6 = ADD32(ctx->r6, -0X1);
L_80129170:
    // 0x80129170: lbu         $t6, 0x0($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X0);
    // 0x80129174: sltiu       $a3, $a2, 0x1
    ctx->r7 = ctx->r6 < 0X1 ? 1 : 0;
    // 0x80129178: xori        $a3, $a3, 0x1
    ctx->r7 = ctx->r7 ^ 0X1;
    // 0x8012917C: addiu       $a2, $a2, -0x1
    ctx->r6 = ADD32(ctx->r6, -0X1);
    // 0x80129180: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80129184: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80129188: bne         $a3, $zero, L_80129170
    if (ctx->r7 != 0) {
        // 0x8012918C: sb          $t6, -0x1($v1)
        MEM_B(-0X1, ctx->r3) = ctx->r14;
            goto L_80129170;
    }
    // 0x8012918C: sb          $t6, -0x1($v1)
    MEM_B(-0X1, ctx->r3) = ctx->r14;
L_80129190:
    // 0x80129190: jr          $ra
    // 0x80129194: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    return;
    // 0x80129194: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
;}
RECOMP_FUNC void func_80129198(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129198: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8012919C: jr          $ra
    // 0x801291A0: nop

    return;
    // 0x801291A0: nop

;}
RECOMP_FUNC void func_801291A4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801291A4: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x801291A8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801291AC: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x801291B0: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x801291B4: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x801291B8: lbu         $t7, 0x0($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X0);
    // 0x801291BC: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x801291C0: beql        $t7, $zero, L_801291F4
    if (ctx->r15 == 0) {
        // 0x801291C4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_801291F4;
    }
    goto skip_0;
    // 0x801291C4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x801291C8: lbu         $s1, 0x0($a0)
    ctx->r17 = MEM_BU(ctx->r4, 0X0);
    // 0x801291CC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
L_801291D0:
    // 0x801291D0: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x801291D4: jal         0x80129198
    // 0x801291D8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    func_80129198(rdram, ctx);
        goto after_0;
    // 0x801291D8: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    after_0:
    // 0x801291DC: lbu         $s1, 0x1($s0)
    ctx->r17 = MEM_BU(ctx->r16, 0X1);
    // 0x801291E0: sb          $v0, 0x0($s0)
    MEM_B(0X0, ctx->r16) = ctx->r2;
    // 0x801291E4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x801291E8: bnel        $s1, $zero, L_801291D0
    if (ctx->r17 != 0) {
        // 0x801291EC: sll         $a0, $s1, 16
        ctx->r4 = S32(ctx->r17 << 16);
            goto L_801291D0;
    }
    goto skip_1;
    // 0x801291EC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    skip_1:
    // 0x801291F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801291F4:
    // 0x801291F4: lw          $v0, 0x20($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X20);
    // 0x801291F8: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x801291FC: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80129200: jr          $ra
    // 0x80129204: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x80129204: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void read_rom_header(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129210: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80129214: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80129218: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012921C: addiu       $a1, $a1, 0x4240
    ctx->r5 = ADD32(ctx->r5, 0X4240);
    // 0x80129220: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    // 0x80129224: jal         0x80129290
    // 0x80129228: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    dma_read(rdram, ctx);
        goto after_0;
    // 0x80129228: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    after_0:
    // 0x8012922C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129230: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80129234: jr          $ra
    // 0x80129238: nop

    return;
    // 0x80129238: nop

;}
RECOMP_FUNC void set_region(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012923C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80129240: addiu       $v1, $v1, 0x4240
    ctx->r3 = ADD32(ctx->r3, 0X4240);
    // 0x80129244: lbu         $v0, 0x1E($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X1E);
    // 0x80129248: addiu       $at, $zero, 0x45
    ctx->r1 = ADD32(0, 0X45);
    // 0x8012924C: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80129250: beq         $v0, $at, L_80129284
    if (ctx->r2 == ctx->r1) {
        // 0x80129254: addiu       $at, $zero, 0x4A
        ctx->r1 = ADD32(0, 0X4A);
            goto L_80129284;
    }
    // 0x80129254: addiu       $at, $zero, 0x4A
    ctx->r1 = ADD32(0, 0X4A);
    // 0x80129258: beq         $v0, $at, L_80129274
    if (ctx->r2 == ctx->r1) {
        // 0x8012925C: addiu       $at, $zero, 0x50
        ctx->r1 = ADD32(0, 0X50);
            goto L_80129274;
    }
    // 0x8012925C: addiu       $at, $zero, 0x50
    ctx->r1 = ADD32(0, 0X50);
    // 0x80129260: beq         $v0, $at, L_8012927C
    if (ctx->r2 == ctx->r1) {
        // 0x80129264: addiu       $t7, $zero, 0x1
        ctx->r15 = ADD32(0, 0X1);
            goto L_8012927C;
    }
    // 0x80129264: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80129268: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8012926C: jr          $ra
    // 0x80129270: sh          $t6, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r14;
    return;
    // 0x80129270: sh          $t6, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r14;
L_80129274:
    // 0x80129274: jr          $ra
    // 0x80129278: sh          $zero, 0x20($v1)
    MEM_H(0X20, ctx->r3) = 0;
    return;
    // 0x80129278: sh          $zero, 0x20($v1)
    MEM_H(0X20, ctx->r3) = 0;
L_8012927C:
    // 0x8012927C: jr          $ra
    // 0x80129280: sh          $t7, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r15;
    return;
    // 0x80129280: sh          $t7, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r15;
L_80129284:
    // 0x80129284: sh          $t8, 0x20($v1)
    MEM_H(0X20, ctx->r3) = ctx->r24;
    // 0x80129288: jr          $ra
    // 0x8012928C: nop

    return;
    // 0x8012928C: nop

;}
RECOMP_FUNC void dma_read(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    load_overlays(ctx->r4, ctx->r5, ctx->r6);
    // 0x80129290: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80129294: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80129298: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x8012929C: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x801292A0: jal         0x80137EB0
    // 0x801292A4: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_0;
    // 0x801292A4: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    after_0:
    // 0x801292A8: lw          $t6, 0x34($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X34);
    // 0x801292AC: lw          $t7, 0x38($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X38);
    // 0x801292B0: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x801292B4: addiu       $t8, $t8, -0x2F88
    ctx->r24 = ADD32(ctx->r24, -0X2F88);
    // 0x801292B8: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x801292BC: addiu       $a0, $a0, -0x2F40
    ctx->r4 = ADD32(ctx->r4, -0X2F40);
    // 0x801292C0: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x801292C4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x801292C8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x801292CC: lw          $a3, 0x30($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X30);
    // 0x801292D0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x801292D4: jal         0x80137EE0
    // 0x801292D8: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    osPiStartDma_recomp(rdram, ctx);
        goto after_1;
    // 0x801292D8: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_1:
    // 0x801292DC: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x801292E0: addiu       $a0, $a0, -0x2F88
    ctx->r4 = ADD32(ctx->r4, -0X2F88);
    // 0x801292E4: addiu       $a1, $sp, 0x2C
    ctx->r5 = ADD32(ctx->r29, 0X2C);
    // 0x801292E8: jal         0x80137FF0
    // 0x801292EC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osRecvMesg_recomp(rdram, ctx);
        goto after_2;
    // 0x801292EC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_2:
    // 0x801292F0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x801292F4: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x801292F8: jr          $ra
    // 0x801292FC: nop

    return;
    // 0x801292FC: nop

;}
RECOMP_FUNC void load_segments(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129300: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80129304: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80129308: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8012930C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80129310: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x80129314: lw          $s0, 0x0($a0)
    ctx->r16 = MEM_W(ctx->r4, 0X0);
    // 0x80129318: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x8012931C: ori         $t7, $t7, 0x6
    ctx->r15 = ctx->r15 | 0X6;
    // 0x80129320: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x80129324: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80129328: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012932C: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x80129330: lw          $s0, 0x0($a0)
    ctx->r16 = MEM_W(ctx->r4, 0X0);
    // 0x80129334: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x80129338: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x8012933C: addiu       $t8, $s0, 0x8
    ctx->r24 = ADD32(ctx->r16, 0X8);
    // 0x80129340: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80129344: ori         $t9, $t9, 0x406
    ctx->r25 = ctx->r25 | 0X406;
    // 0x80129348: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8012934C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80129350: lw          $a0, -0x618C($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X618C);
    // 0x80129354: jal         0x80138130
    // 0x80129358: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_0;
    // 0x80129358: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    after_0:
    // 0x8012935C: lw          $v1, 0x30($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X30);
    // 0x80129360: lui         $t1, 0xBC00
    ctx->r9 = S32(0XBC00 << 16);
    // 0x80129364: ori         $t1, $t1, 0x806
    ctx->r9 = ctx->r9 | 0X806;
    // 0x80129368: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
    // 0x8012936C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80129370: addiu       $t0, $s0, 0x8
    ctx->r8 = ADD32(ctx->r16, 0X8);
    // 0x80129374: sw          $t0, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r8;
    // 0x80129378: sw          $t1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r9;
    // 0x8012937C: lw          $a0, 0x3C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X3C);
    // 0x80129380: jal         0x80138130
    // 0x80129384: sw          $s0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x80129384: sw          $s0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r16;
    after_1:
    // 0x80129388: lw          $a1, 0x2C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X2C);
    // 0x8012938C: lui         $t3, 0xBC00
    ctx->r11 = S32(0XBC00 << 16);
    // 0x80129390: ori         $t3, $t3, 0xC06
    ctx->r11 = ctx->r11 | 0XC06;
    // 0x80129394: sw          $v0, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r2;
    // 0x80129398: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8012939C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x801293A0: addiu       $t2, $s0, 0x8
    ctx->r10 = ADD32(ctx->r16, 0X8);
    // 0x801293A4: sw          $t2, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r10;
    // 0x801293A8: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x801293AC: lw          $a0, -0x6190($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6190);
    // 0x801293B0: jal         0x80138130
    // 0x801293B4: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_2;
    // 0x801293B4: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    after_2:
    // 0x801293B8: lw          $v1, 0x28($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X28);
    // 0x801293BC: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x801293C0: ori         $t5, $t5, 0x1406
    ctx->r13 = ctx->r13 | 0X1406;
    // 0x801293C4: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
    // 0x801293C8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x801293CC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x801293D0: addiu       $t4, $s0, 0x8
    ctx->r12 = ADD32(ctx->r16, 0X8);
    // 0x801293D4: sw          $t4, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r12;
    // 0x801293D8: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x801293DC: lw          $a0, -0x6188($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X6188);
    // 0x801293E0: jal         0x80138130
    // 0x801293E4: sw          $s0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_3;
    // 0x801293E4: sw          $s0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r16;
    after_3:
    // 0x801293E8: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x801293EC: lui         $t7, 0xFE00
    ctx->r15 = S32(0XFE00 << 16);
    // 0x801293F0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x801293F4: sw          $v0, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r2;
    // 0x801293F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x801293FC: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x80129400: addiu       $t6, $s0, 0x8
    ctx->r14 = ADD32(ctx->r16, 0X8);
    // 0x80129404: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x80129408: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8012940C: jal         0x80138130
    // 0x80129410: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_4;
    // 0x80129410: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    after_4:
    // 0x80129414: lw          $v1, 0x20($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X20);
    // 0x80129418: sw          $v0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r2;
    // 0x8012941C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80129420: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80129424: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80129428: jr          $ra
    // 0x8012942C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x8012942C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void clear_depth_buffer(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129430: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80129434: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80129438: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8012943C: lui         $t7, 0xED00
    ctx->r15 = S32(0XED00 << 16);
    // 0x80129440: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x80129444: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80129448: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012944C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80129450: lh          $t8, 0x3FD0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD0);
    // 0x80129454: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x80129458: lh          $t4, 0x3FD2($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD2);
    // 0x8012945C: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80129460: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80129464: mtc1        $t4, $f16
    ctx->f16.u32l = ctx->r12;
    // 0x80129468: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8012946C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80129470: lui         $t4, 0xBA00
    ctx->r12 = S32(0XBA00 << 16);
    // 0x80129474: ori         $t4, $t4, 0x1402
    ctx->r12 = ctx->r12 | 0X1402;
    // 0x80129478: lui         $t5, 0x30
    ctx->r13 = S32(0X30 << 16);
    // 0x8012947C: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80129480: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80129484: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x80129488: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x8012948C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80129490: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80129494: mfc1        $t1, $f10
    ctx->r9 = (int32_t)ctx->f10.u32l;
    // 0x80129498: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x8012949C: andi        $t2, $t1, 0xFFF
    ctx->r10 = ctx->r9 & 0XFFF;
    // 0x801294A0: sll         $t3, $t2, 12
    ctx->r11 = S32(ctx->r10 << 12);
    // 0x801294A4: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x801294A8: or          $t8, $t3, $t7
    ctx->r24 = ctx->r11 | ctx->r15;
    // 0x801294AC: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x801294B0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801294B4: lui         $t1, 0xE700
    ctx->r9 = S32(0XE700 << 16);
    // 0x801294B8: lui         $t3, 0xFF10
    ctx->r11 = S32(0XFF10 << 16);
    // 0x801294BC: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x801294C0: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x801294C4: sw          $t1, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r9;
    // 0x801294C8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801294CC: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801294D0: ori         $t3, $t3, 0x13F
    ctx->r11 = ctx->r11 | 0X13F;
    // 0x801294D4: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x801294D8: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x801294DC: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x801294E0: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x801294E4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801294E8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801294EC: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801294F0: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x801294F4: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x801294F8: sw          $a1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r5;
    // 0x801294FC: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x80129500: jal         0x80138130
    // 0x80129504: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_0;
    // 0x80129504: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    after_0:
    // 0x80129508: lw          $t0, 0x18($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X18);
    // 0x8012950C: lw          $a1, 0x28($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X28);
    // 0x80129510: lui         $t9, 0xFFFC
    ctx->r25 = S32(0XFFFC << 16);
    // 0x80129514: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x80129518: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x8012951C: ori         $t9, $t9, 0xFFFC
    ctx->r25 = ctx->r25 | 0XFFFC;
    // 0x80129520: lui         $t8, 0xF700
    ctx->r24 = S32(0XF700 << 16);
    // 0x80129524: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80129528: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x8012952C: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x80129530: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80129534: lw          $v1, 0x0($a1)
    ctx->r3 = MEM_W(ctx->r5, 0X0);
    // 0x80129538: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8012953C: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80129540: addiu       $t1, $v1, 0x8
    ctx->r9 = ADD32(ctx->r3, 0X8);
    // 0x80129544: sw          $t1, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r9;
    // 0x80129548: lh          $t2, 0x3FD0($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X3FD0);
    // 0x8012954C: lh          $t7, 0x3FD2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X3FD2);
    // 0x80129550: lui         $at, 0xF600
    ctx->r1 = S32(0XF600 << 16);
    // 0x80129554: addiu       $t4, $t2, -0x8
    ctx->r12 = ADD32(ctx->r10, -0X8);
    // 0x80129558: andi        $t5, $t4, 0x3FF
    ctx->r13 = ctx->r12 & 0X3FF;
    // 0x8012955C: addiu       $t8, $t7, -0x8
    ctx->r24 = ADD32(ctx->r15, -0X8);
    // 0x80129560: andi        $t9, $t8, 0x3FF
    ctx->r25 = ctx->r24 & 0X3FF;
    // 0x80129564: sll         $t6, $t5, 14
    ctx->r14 = S32(ctx->r13 << 14);
    // 0x80129568: or          $t3, $t6, $at
    ctx->r11 = ctx->r14 | ctx->r1;
    // 0x8012956C: sll         $t1, $t9, 2
    ctx->r9 = S32(ctx->r25 << 2);
    // 0x80129570: lui         $t4, 0x2
    ctx->r12 = S32(0X2 << 16);
    // 0x80129574: ori         $t4, $t4, 0x20
    ctx->r12 = ctx->r12 | 0X20;
    // 0x80129578: or          $t2, $t3, $t1
    ctx->r10 = ctx->r11 | ctx->r9;
    // 0x8012957C: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x80129580: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    // 0x80129584: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129588: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8012958C: jr          $ra
    // 0x80129590: nop

    return;
    // 0x80129590: nop

;}
RECOMP_FUNC void init_f3dex_render(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129594: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80129598: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012959C: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801295A0: lui         $t1, 0xE700
    ctx->r9 = S32(0XE700 << 16);
    // 0x801295A4: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x801295A8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801295AC: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801295B0: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801295B4: sw          $t1, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r9;
    // 0x801295B8: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801295BC: addiu       $t9, $t9, -0x28F0
    ctx->r25 = ADD32(ctx->r25, -0X28F0);
    // 0x801295C0: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x801295C4: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x801295C8: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x801295CC: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x801295D0: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x801295D4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801295D8: lui         $t3, 0xAF00
    ctx->r11 = S32(0XAF00 << 16);
    // 0x801295DC: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x801295E0: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x801295E4: sw          $t2, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r10;
    // 0x801295E8: addiu       $t4, $t4, -0xE30
    ctx->r12 = ADD32(ctx->r12, -0XE30);
    // 0x801295EC: ori         $t3, $t3, 0x7FF
    ctx->r11 = ctx->r11 | 0X7FF;
    // 0x801295F0: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x801295F4: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    // 0x801295F8: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801295FC: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x80129600: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x80129604: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80129608: sw          $t1, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r9;
    // 0x8012960C: jal         0x80129300
    // 0x80129610: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    load_segments(rdram, ctx);
        goto after_0;
    // 0x80129610: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    after_0:
    // 0x80129614: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x80129618: lui         $t7, 0xFF10
    ctx->r15 = S32(0XFF10 << 16);
    // 0x8012961C: ori         $t7, $t7, 0x13F
    ctx->r15 = ctx->r15 | 0X13F;
    // 0x80129620: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129624: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x80129628: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x8012962C: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80129630: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80129634: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80129638: jal         0x80138130
    // 0x8012963C: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x8012963C: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    after_1:
    // 0x80129640: lw          $t0, 0x18($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X18);
    // 0x80129644: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x80129648: lui         $t9, 0xED02
    ctx->r25 = S32(0XED02 << 16);
    // 0x8012964C: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x80129650: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129654: ori         $t9, $t9, 0x20
    ctx->r25 = ctx->r25 | 0X20;
    // 0x80129658: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8012965C: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80129660: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80129664: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80129668: lh          $t2, 0x3FD0($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X3FD0);
    // 0x8012966C: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x80129670: lh          $t8, 0x3FD2($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD2);
    // 0x80129674: addiu       $t3, $t2, -0x8
    ctx->r11 = ADD32(ctx->r10, -0X8);
    // 0x80129678: mtc1        $t3, $f4
    ctx->f4.u32l = ctx->r11;
    // 0x8012967C: addiu       $t9, $t8, -0x8
    ctx->r25 = ADD32(ctx->r24, -0X8);
    // 0x80129680: mtc1        $t9, $f16
    ctx->f16.u32l = ctx->r25;
    // 0x80129684: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80129688: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x8012968C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80129690: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x80129694: ori         $t8, $t8, 0x602
    ctx->r24 = ctx->r24 | 0X602;
    // 0x80129698: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8012969C: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x801296A0: addiu       $t9, $zero, 0x40
    ctx->r25 = ADD32(0, 0X40);
    // 0x801296A4: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x801296A8: ori         $t0, $zero, 0xFFFD
    ctx->r8 = 0 | 0XFFFD;
    // 0x801296AC: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x801296B0: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x801296B4: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x801296B8: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x801296BC: mfc1        $t3, $f6
    ctx->r11 = (int32_t)ctx->f6.u32l;
    // 0x801296C0: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x801296C4: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x801296C8: andi        $t4, $t3, 0xFFF
    ctx->r12 = ctx->r11 & 0XFFF;
    // 0x801296CC: or          $t5, $t7, $t4
    ctx->r13 = ctx->r15 | ctx->r12;
    // 0x801296D0: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x801296D4: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801296D8: lui         $t3, 0xBA00
    ctx->r11 = S32(0XBA00 << 16);
    // 0x801296DC: ori         $t3, $t3, 0x402
    ctx->r11 = ctx->r11 | 0X402;
    // 0x801296E0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801296E4: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x801296E8: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x801296EC: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x801296F0: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801296F4: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x801296F8: ori         $t4, $t4, 0x404
    ctx->r12 = ctx->r12 | 0X404;
    // 0x801296FC: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x80129700: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x80129704: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80129708: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x8012970C: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129710: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x80129714: ori         $t6, $t6, 0xC04
    ctx->r14 = ctx->r14 | 0XC04;
    // 0x80129718: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8012971C: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80129720: sw          $a3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r7;
    // 0x80129724: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x80129728: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8012972C: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x80129730: ori         $t9, $t9, 0x1404
    ctx->r25 = ctx->r25 | 0X1404;
    // 0x80129734: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x80129738: sw          $t5, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r13;
    // 0x8012973C: sw          $a3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r7;
    // 0x80129740: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80129744: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129748: lui         $t3, 0xBC00
    ctx->r11 = S32(0XBC00 << 16);
    // 0x8012974C: ori         $t3, $t3, 0x1C04
    ctx->r11 = ctx->r11 | 0X1C04;
    // 0x80129750: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80129754: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80129758: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x8012975C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80129760: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129764: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x80129768: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x8012976C: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x80129770: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80129774: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129778: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x8012977C: jr          $ra
    // 0x80129780: nop

    return;
    // 0x80129780: nop

;}
RECOMP_FUNC void begin_f3dex_render(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129784: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80129788: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8012978C: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80129790: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80129794: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80129798: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x8012979C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801297A0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x801297A4: jal         0x80129300
    // 0x801297A8: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    load_segments(rdram, ctx);
        goto after_0;
    // 0x801297A8: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    after_0:
    // 0x801297AC: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x801297B0: lui         $t9, 0xFF10
    ctx->r25 = S32(0XFF10 << 16);
    // 0x801297B4: ori         $t9, $t9, 0x13F
    ctx->r25 = ctx->r25 | 0X13F;
    // 0x801297B8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801297BC: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x801297C0: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x801297C4: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x801297C8: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x801297CC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x801297D0: jal         0x80138130
    // 0x801297D4: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x801297D4: sw          $v1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r3;
    after_1:
    // 0x801297D8: lw          $t0, 0x18($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X18);
    // 0x801297DC: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x801297E0: lui         $t3, 0xED02
    ctx->r11 = S32(0XED02 << 16);
    // 0x801297E4: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x801297E8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801297EC: ori         $t3, $t3, 0x20
    ctx->r11 = ctx->r11 | 0X20;
    // 0x801297F0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x801297F4: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x801297F8: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x801297FC: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80129800: lh          $t4, 0x3FD0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD0);
    // 0x80129804: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80129808: lh          $t2, 0x3FD2($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X3FD2);
    // 0x8012980C: addiu       $t5, $t4, -0x8
    ctx->r13 = ADD32(ctx->r12, -0X8);
    // 0x80129810: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x80129814: addiu       $t3, $t2, -0x8
    ctx->r11 = ADD32(ctx->r10, -0X8);
    // 0x80129818: mtc1        $t3, $f16
    ctx->f16.u32l = ctx->r11;
    // 0x8012981C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80129820: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80129824: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80129828: lui         $t2, 0xBA00
    ctx->r10 = S32(0XBA00 << 16);
    // 0x8012982C: ori         $t2, $t2, 0x602
    ctx->r10 = ctx->r10 | 0X602;
    // 0x80129830: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80129834: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80129838: addiu       $t3, $zero, 0x40
    ctx->r11 = ADD32(0, 0X40);
    // 0x8012983C: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x80129840: ori         $t0, $zero, 0xFFFD
    ctx->r8 = 0 | 0XFFFD;
    // 0x80129844: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80129848: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8012984C: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80129850: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x80129854: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x80129858: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8012985C: sll         $t9, $t8, 12
    ctx->r25 = S32(ctx->r24 << 12);
    // 0x80129860: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x80129864: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80129868: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8012986C: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129870: lui         $t5, 0xBA00
    ctx->r13 = S32(0XBA00 << 16);
    // 0x80129874: ori         $t5, $t5, 0x402
    ctx->r13 = ctx->r13 | 0X402;
    // 0x80129878: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8012987C: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80129880: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
    // 0x80129884: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x80129888: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8012988C: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x80129890: ori         $t6, $t6, 0x404
    ctx->r14 = ctx->r14 | 0X404;
    // 0x80129894: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x80129898: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x8012989C: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801298A0: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x801298A4: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801298A8: lui         $t8, 0xBC00
    ctx->r24 = S32(0XBC00 << 16);
    // 0x801298AC: ori         $t8, $t8, 0xC04
    ctx->r24 = ctx->r24 | 0XC04;
    // 0x801298B0: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x801298B4: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x801298B8: sw          $a3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r7;
    // 0x801298BC: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x801298C0: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801298C4: lui         $t3, 0xBC00
    ctx->r11 = S32(0XBC00 << 16);
    // 0x801298C8: ori         $t3, $t3, 0x1404
    ctx->r11 = ctx->r11 | 0X1404;
    // 0x801298CC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x801298D0: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x801298D4: sw          $a3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r7;
    // 0x801298D8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x801298DC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801298E0: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x801298E4: ori         $t5, $t5, 0x1C04
    ctx->r13 = ctx->r13 | 0X1C04;
    // 0x801298E8: addiu       $t2, $v1, 0x8
    ctx->r10 = ADD32(ctx->r3, 0X8);
    // 0x801298EC: sw          $t2, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r10;
    // 0x801298F0: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x801298F4: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x801298F8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801298FC: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x80129900: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x80129904: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x80129908: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x8012990C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129910: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80129914: jr          $ra
    // 0x80129918: nop

    return;
    // 0x80129918: nop

;}
RECOMP_FUNC void begin_f3dex_render_sync(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012991C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80129920: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80129924: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80129928: lui         $t0, 0xE700
    ctx->r8 = S32(0XE700 << 16);
    // 0x8012992C: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80129930: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80129934: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80129938: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x8012993C: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80129940: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80129944: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80129948: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8012994C: sw          $t0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r8;
    // 0x80129950: jal         0x80129300
    // 0x80129954: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    load_segments(rdram, ctx);
        goto after_0;
    // 0x80129954: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    after_0:
    // 0x80129958: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x8012995C: lui         $t9, 0xFF10
    ctx->r25 = S32(0XFF10 << 16);
    // 0x80129960: ori         $t9, $t9, 0x13F
    ctx->r25 = ctx->r25 | 0X13F;
    // 0x80129964: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129968: lui         $a0, 0x8010
    ctx->r4 = S32(0X8010 << 16);
    // 0x8012996C: addiu       $a0, $a0, 0x0
    ctx->r4 = ADD32(ctx->r4, 0X0);
    // 0x80129970: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80129974: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80129978: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8012997C: jal         0x80138130
    // 0x80129980: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x80129980: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    after_1:
    // 0x80129984: lw          $t0, 0x1C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X1C);
    // 0x80129988: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x8012998C: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x80129990: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x80129994: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129998: addiu       $t2, $zero, 0x3
    ctx->r10 = ADD32(0, 0X3);
    // 0x8012999C: ori         $t5, $t5, 0x404
    ctx->r13 = ctx->r13 | 0X404;
    // 0x801299A0: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x801299A4: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x801299A8: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x801299AC: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x801299B0: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801299B4: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x801299B8: ori         $t7, $t7, 0xC04
    ctx->r15 = ctx->r15 | 0XC04;
    // 0x801299BC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801299C0: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x801299C4: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x801299C8: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x801299CC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801299D0: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x801299D4: ori         $t3, $zero, 0xFFFD
    ctx->r11 = 0 | 0XFFFD;
    // 0x801299D8: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x801299DC: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x801299E0: ori         $t9, $t9, 0x1404
    ctx->r25 = ctx->r25 | 0X1404;
    // 0x801299E4: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x801299E8: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
    // 0x801299EC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801299F0: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x801299F4: ori         $t5, $t5, 0x1C04
    ctx->r13 = ctx->r13 | 0X1C04;
    // 0x801299F8: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x801299FC: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x80129A00: sw          $t3, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r11;
    // 0x80129A04: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x80129A08: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129A0C: lui         $t7, 0xED02
    ctx->r15 = S32(0XED02 << 16);
    // 0x80129A10: ori         $t7, $t7, 0x20
    ctx->r15 = ctx->r15 | 0X20;
    // 0x80129A14: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80129A18: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80129A1C: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x80129A20: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80129A24: lh          $t8, 0x3FD0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD0);
    // 0x80129A28: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80129A2C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80129A30: addiu       $t9, $t8, -0x8
    ctx->r25 = ADD32(ctx->r24, -0X8);
    // 0x80129A34: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x80129A38: lh          $t8, 0x3FD2($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FD2);
    // 0x80129A3C: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x80129A40: lui         $t4, 0xBA00
    ctx->r12 = S32(0XBA00 << 16);
    // 0x80129A44: addiu       $t9, $t8, -0x8
    ctx->r25 = ADD32(ctx->r24, -0X8);
    // 0x80129A48: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80129A4C: mtc1        $t9, $f16
    ctx->f16.u32l = ctx->r25;
    // 0x80129A50: ori         $t4, $t4, 0x602
    ctx->r12 = ctx->r12 | 0X602;
    // 0x80129A54: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80129A58: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80129A5C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80129A60: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80129A64: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x80129A68: nop

    // 0x80129A6C: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x80129A70: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80129A74: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x80129A78: mfc1        $t5, $f6
    ctx->r13 = (int32_t)ctx->f6.u32l;
    // 0x80129A7C: nop

    // 0x80129A80: andi        $t6, $t5, 0xFFF
    ctx->r14 = ctx->r13 & 0XFFF;
    // 0x80129A84: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x80129A88: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80129A8C: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129A90: addiu       $t5, $zero, 0x40
    ctx->r13 = ADD32(0, 0X40);
    // 0x80129A94: lui         $t6, 0xBA00
    ctx->r14 = S32(0XBA00 << 16);
    // 0x80129A98: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x80129A9C: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80129AA0: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x80129AA4: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x80129AA8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80129AAC: ori         $t6, $t6, 0x402
    ctx->r14 = ctx->r14 | 0X402;
    // 0x80129AB0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80129AB4: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    // 0x80129AB8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80129ABC: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80129AC0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129AC4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80129AC8: jr          $ra
    // 0x80129ACC: nop

    return;
    // 0x80129ACC: nop

;}
RECOMP_FUNC void clear_framebuffer(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129AD0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80129AD4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80129AD8: lui         $a0, 0x8000
    ctx->r4 = S32(0X8000 << 16);
    // 0x80129ADC: lui         $a1, 0x2
    ctx->r5 = S32(0X2 << 16);
    // 0x80129AE0: ori         $a1, $a1, 0x5800
    ctx->r5 = ctx->r5 | 0X5800;
    // 0x80129AE4: jal         0x80128FB4
    // 0x80129AE8: addiu       $a0, $a0, 0x400
    ctx->r4 = ADD32(ctx->r4, 0X400);
    bzero_sssv(rdram, ctx);
        goto after_0;
    // 0x80129AE8: addiu       $a0, $a0, 0x400
    ctx->r4 = ADD32(ctx->r4, 0X400);
    after_0:
    // 0x80129AEC: lui         $a0, 0x8002
    ctx->r4 = S32(0X8002 << 16);
    // 0x80129AF0: lui         $a1, 0x2
    ctx->r5 = S32(0X2 << 16);
    // 0x80129AF4: ori         $a1, $a1, 0x5800
    ctx->r5 = ctx->r5 | 0X5800;
    // 0x80129AF8: jal         0x80128FB4
    // 0x80129AFC: addiu       $a0, $a0, 0x5C00
    ctx->r4 = ADD32(ctx->r4, 0X5C00);
    bzero_sssv(rdram, ctx);
        goto after_1;
    // 0x80129AFC: addiu       $a0, $a0, 0x5C00
    ctx->r4 = ADD32(ctx->r4, 0X5C00);
    after_1:
    // 0x80129B00: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80129B04: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80129B08: jr          $ra
    // 0x80129B0C: nop

    return;
    // 0x80129B0C: nop

;}
RECOMP_FUNC void thread6(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129B10: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80129B14: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80129B18: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129B1C: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80129B20: sh          $t6, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r14;
    // 0x80129B24: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80129B28: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129B2C: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x80129B30: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129B34: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80129B38: sh          $t7, 0x4292($at)
    MEM_H(0X4292, ctx->r1) = ctx->r15;
    // 0x80129B3C: addiu       $a1, $a1, 0x2C0
    ctx->r5 = ADD32(ctx->r5, 0X2C0);
    // 0x80129B40: addiu       $a0, $a0, -0x2FB8
    ctx->r4 = ADD32(ctx->r4, -0X2FB8);
    // 0x80129B44: jal         0x801381B0
    // 0x80129B48: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_0;
    // 0x80129B48: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    after_0:
    // 0x80129B4C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129B50: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80129B54: addiu       $a1, $a1, 0xFC8
    ctx->r5 = ADD32(ctx->r5, 0XFC8);
    // 0x80129B58: addiu       $a0, $a0, -0x2F88
    ctx->r4 = ADD32(ctx->r4, -0X2F88);
    // 0x80129B5C: jal         0x801381B0
    // 0x80129B60: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_1;
    // 0x80129B60: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_1:
    // 0x80129B64: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129B68: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80129B6C: addiu       $a1, $a1, 0x1058
    ctx->r5 = ADD32(ctx->r5, 0X1058);
    // 0x80129B70: addiu       $a0, $a0, 0x1060
    ctx->r4 = ADD32(ctx->r4, 0X1060);
    // 0x80129B74: jal         0x801381B0
    // 0x80129B78: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_2;
    // 0x80129B78: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_2:
    // 0x80129B7C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129B80: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80129B84: addiu       $a1, $a1, 0x105C
    ctx->r5 = ADD32(ctx->r5, 0X105C);
    // 0x80129B88: addiu       $a0, $a0, 0x1078
    ctx->r4 = ADD32(ctx->r4, 0X1078);
    // 0x80129B8C: jal         0x801381B0
    // 0x80129B90: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_3;
    // 0x80129B90: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_3:
    // 0x80129B94: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80129B98: jal         0x801381E0
    // 0x80129B9C: addiu       $a0, $a0, 0x6720
    ctx->r4 = ADD32(ctx->r4, 0X6720);
    osStartThread_recomp(rdram, ctx);
        goto after_4;
    // 0x80129B9C: addiu       $a0, $a0, 0x6720
    ctx->r4 = ADD32(ctx->r4, 0X6720);
    after_4:
    // 0x80129BA0: jal         0x80129210
    // 0x80129BA4: nop

    read_rom_header(rdram, ctx);
        goto after_5;
    // 0x80129BA4: nop

    after_5:
    // 0x80129BA8: jal         0x8012923C
    // 0x80129BAC: nop

    set_region(rdram, ctx);
        goto after_6;
    // 0x80129BAC: nop

    after_6:
    // 0x80129BB0: jal         0x8012A870
    // 0x80129BB4: nop

    initialise_tv_mode(rdram, ctx);
        goto after_7;
    // 0x80129BB4: nop

    after_7:
    // 0x80129BB8: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80129BBC: lui         $a1, 0x8016
    ctx->r5 = S32(0X8016 << 16);
    // 0x80129BC0: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80129BC4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80129BC8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80129BCC: lbu         $a3, 0x53E9($a3)
    ctx->r7 = MEM_BU(ctx->r7, 0X53E9);
    // 0x80129BD0: addiu       $a1, $a1, 0x2658
    ctx->r5 = ADD32(ctx->r5, 0X2658);
    // 0x80129BD4: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    // 0x80129BD8: jal         0x80138B40
    // 0x80129BDC: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    osCreateScheduler(rdram, ctx);
        goto after_8;
    // 0x80129BDC: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    after_8:
    // 0x80129BE0: jal         0x80138C70
    // 0x80129BE4: addiu       $a0, $zero, 0x62
    ctx->r4 = ADD32(0, 0X62);
    osViSetSpecialFeatures_recomp(rdram, ctx);
        goto after_9;
    // 0x80129BE4: addiu       $a0, $zero, 0x62
    ctx->r4 = ADD32(0, 0X62);
    after_9:
    // 0x80129BE8: addiu       $t9, $zero, 0x140
    ctx->r25 = ADD32(0, 0X140);
    // 0x80129BEC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129BF0: sh          $t9, 0x3FD0($at)
    MEM_H(0X3FD0, ctx->r1) = ctx->r25;
    // 0x80129BF4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129BF8: addiu       $t0, $zero, 0xF0
    ctx->r8 = ADD32(0, 0XF0);
    // 0x80129BFC: sh          $t0, 0x3FD2($at)
    MEM_H(0X3FD2, ctx->r1) = ctx->r8;
    // 0x80129C00: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80129C04: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80129C08: sw          $zero, 0x10D0($at)
    MEM_W(0X10D0, ctx->r1) = 0;
    // 0x80129C0C: jal         0x80131BF0
    // 0x80129C10: addiu       $a0, $a0, 0x6328
    ctx->r4 = ADD32(ctx->r4, 0X6328);
    initialise_audio(rdram, ctx);
        goto after_10;
    // 0x80129C10: addiu       $a0, $a0, 0x6328
    ctx->r4 = ADD32(ctx->r4, 0X6328);
    after_10:
    // 0x80129C14: lui         $v0, 0x8016
    ctx->r2 = S32(0X8016 << 16);
    // 0x80129C18: addiu       $v0, $v0, 0x2658
    ctx->r2 = ADD32(ctx->r2, 0X2658);
    // 0x80129C1C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C20: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x80129C24: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80129C28: sh          $a0, -0x4458($at)
    MEM_H(-0X4458, ctx->r1) = ctx->r4;
    // 0x80129C2C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C30: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80129C34: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80129C38: sh          $a1, -0x4438($at)
    MEM_H(-0X4438, ctx->r1) = ctx->r5;
    // 0x80129C3C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C40: lui         $t1, 0x8000
    ctx->r9 = S32(0X8000 << 16);
    // 0x80129C44: addiu       $t1, $t1, 0x400
    ctx->r9 = ADD32(ctx->r9, 0X400);
    // 0x80129C48: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80129C4C: lui         $v1, 0x801A
    ctx->r3 = S32(0X801A << 16);
    // 0x80129C50: sw          $t1, -0x4418($at)
    MEM_W(-0X4418, ctx->r1) = ctx->r9;
    // 0x80129C54: addiu       $v1, $v1, -0x59A8
    ctx->r3 = ADD32(ctx->r3, -0X59A8);
    // 0x80129C58: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C5C: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80129C60: sh          $a0, -0x868($at)
    MEM_H(-0X868, ctx->r1) = ctx->r4;
    // 0x80129C64: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C68: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80129C6C: sh          $a1, -0x848($at)
    MEM_H(-0X848, ctx->r1) = ctx->r5;
    // 0x80129C70: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80129C74: lui         $t2, 0x8002
    ctx->r10 = S32(0X8002 << 16);
    // 0x80129C78: addiu       $t2, $t2, 0x5C00
    ctx->r10 = ADD32(ctx->r10, 0X5C00);
    // 0x80129C7C: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80129C80: jal         0x80129AD0
    // 0x80129C84: sw          $t2, -0x828($at)
    MEM_W(-0X828, ctx->r1) = ctx->r10;
    clear_framebuffer(rdram, ctx);
        goto after_11;
    // 0x80129C84: sw          $t2, -0x828($at)
    MEM_W(-0X828, ctx->r1) = ctx->r10;
    after_11:
    // 0x80129C88: addiu       $t3, $zero, 0x5
    ctx->r11 = ADD32(0, 0X5);
    // 0x80129C8C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80129C90: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129C94: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80129C98: sh          $t3, -0x61C8($at)
    MEM_H(-0X61C8, ctx->r1) = ctx->r11;
    // 0x80129C9C: addiu       $a1, $a1, 0xF40
    ctx->r5 = ADD32(ctx->r5, 0XF40);
    // 0x80129CA0: addiu       $a0, $a0, -0x2FA0
    ctx->r4 = ADD32(ctx->r4, -0X2FA0);
    // 0x80129CA4: jal         0x801381B0
    // 0x80129CA8: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_12;
    // 0x80129CA8: addiu       $a2, $zero, 0x20
    ctx->r6 = ADD32(0, 0X20);
    after_12:
    // 0x80129CAC: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80129CB0: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x80129CB4: lui         $a2, 0x8029
    ctx->r6 = S32(0X8029 << 16);
    // 0x80129CB8: addiu       $a2, $a2, -0x2FA0
    ctx->r6 = ADD32(ctx->r6, -0X2FA0);
    // 0x80129CBC: addiu       $a1, $a1, 0x42A0
    ctx->r5 = ADD32(ctx->r5, 0X42A0);
    // 0x80129CC0: jal         0x80138AF0
    // 0x80129CC4: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    osScAddClient(rdram, ctx);
        goto after_13;
    // 0x80129CC4: addiu       $a0, $a0, 0x3D0
    ctx->r4 = ADD32(ctx->r4, 0X3D0);
    after_13:
    // 0x80129CC8: jal         0x80136CE0
    // 0x80129CCC: nop

    init_controllers(rdram, ctx);
        goto after_14;
    // 0x80129CCC: nop

    after_14:
    // 0x80129CD0: bgtz        $v0, L_80129CFC
    if (SIGNED(ctx->r2) > 0) {
        // 0x80129CD4: addiu       $t5, $zero, 0x1
        ctx->r13 = ADD32(0, 0X1);
            goto L_80129CFC;
    }
    // 0x80129CD4: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x80129CD8: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x80129CDC: addiu       $v0, $v0, 0x12D0
    ctx->r2 = ADD32(ctx->r2, 0X12D0);
    // 0x80129CE0: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80129CE4: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80129CE8: sh          $zero, 0x12D8($at)
    MEM_H(0X12D8, ctx->r1) = 0;
    // 0x80129CEC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129CF0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80129CF4: b           L_80129D1C
    // 0x80129CF8: sh          $t4, 0x4270($at)
    MEM_H(0X4270, ctx->r1) = ctx->r12;
        goto L_80129D1C;
    // 0x80129CF8: sh          $t4, 0x4270($at)
    MEM_H(0X4270, ctx->r1) = ctx->r12;
L_80129CFC:
    // 0x80129CFC: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x80129D00: addiu       $v0, $v0, 0x12D0
    ctx->r2 = ADD32(ctx->r2, 0X12D0);
    // 0x80129D04: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80129D08: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80129D0C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80129D10: sh          $t6, 0x12D8($at)
    MEM_H(0X12D8, ctx->r1) = ctx->r14;
    // 0x80129D14: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D18: sh          $zero, 0x4270($at)
    MEM_H(0X4270, ctx->r1) = 0;
L_80129D1C:
    // 0x80129D1C: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80129D20: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D24: bne         $t7, $zero, L_80129D30
    if (ctx->r15 != 0) {
        // 0x80129D28: nop
    
            goto L_80129D30;
    }
    // 0x80129D28: nop

    // 0x80129D2C: sh          $zero, 0x4284($at)
    MEM_H(0X4284, ctx->r1) = 0;
L_80129D30:
    // 0x80129D30: jal         0x80130C04
    // 0x80129D34: nop

    clear_player_eeprom_state(rdram, ctx);
        goto after_15;
    // 0x80129D34: nop

    after_15:
    // 0x80129D38: jal         0x80130E44
    // 0x80129D3C: nop

    func_80130E44(rdram, ctx);
        goto after_16;
    // 0x80129D3C: nop

    after_16:
    // 0x80129D40: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D44: sb          $zero, 0x4288($at)
    MEM_B(0X4288, ctx->r1) = 0;
    // 0x80129D48: jal         0x8012C070
    // 0x80129D4C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    load_overlay(rdram, ctx);
        goto after_17;
    // 0x80129D4C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_17:
    // 0x80129D50: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80129D54: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D58: sh          $v0, 0x4284($at)
    MEM_H(0X4284, ctx->r1) = ctx->r2;
    // 0x80129D5C: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D60: sh          $v0, 0x4290($at)
    MEM_H(0X4290, ctx->r1) = ctx->r2;
    // 0x80129D64: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D68: sh          $v0, 0x427C($at)
    MEM_H(0X427C, ctx->r1) = ctx->r2;
    // 0x80129D6C: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D70: addiu       $t8, $zero, 0xC7
    ctx->r24 = ADD32(0, 0XC7);
    // 0x80129D74: sh          $t8, 0x4280($at)
    MEM_H(0X4280, ctx->r1) = ctx->r24;
    // 0x80129D78: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129D7C: addiu       $t9, $zero, 0x63
    ctx->r25 = ADD32(0, 0X63);
    // 0x80129D80: sh          $t9, 0x4282($at)
    MEM_H(0X4282, ctx->r1) = ctx->r25;
L_80129D84:
    // 0x80129D84: jal         0x80129DC0
    // 0x80129D88: nop

    thread6_loop(rdram, ctx);
        goto after_18;
    // 0x80129D88: nop

    after_18:
    // 0x80129D8C: b           L_80129D84
    // 0x80129D90: nop

        goto L_80129D84;
    // 0x80129D90: nop

    // 0x80129D94: nop

    // 0x80129D98: nop

    // 0x80129D9C: nop

    // 0x80129DA0: nop

    // 0x80129DA4: nop

    // 0x80129DA8: nop

    // 0x80129DAC: nop

    // 0x80129DB0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80129DB4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80129DB8: jr          $ra
    // 0x80129DBC: nop

    return;
    // 0x80129DBC: nop

;}
RECOMP_FUNC void thread6_loop(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80129DC0: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x80129DC4: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80129DC8: sb          $zero, -0x6138($at)
    MEM_B(-0X6138, ctx->r1) = 0;
    // 0x80129DCC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80129DD0: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x80129DD4: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80129DD8: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x80129DDC: sb          $zero, -0x6137($at)
    MEM_B(-0X6137, ctx->r1) = 0;
    // 0x80129DE0: lui         $s2, 0x8015
    ctx->r18 = S32(0X8015 << 16);
    // 0x80129DE4: lui         $s3, 0x8020
    ctx->r19 = S32(0X8020 << 16);
    // 0x80129DE8: lui         $s6, 0x8015
    ctx->r22 = S32(0X8015 << 16);
    // 0x80129DEC: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x80129DF0: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x80129DF4: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x80129DF8: addiu       $s6, $s6, 0x2EB8
    ctx->r22 = ADD32(ctx->r22, 0X2EB8);
    // 0x80129DFC: addiu       $s3, $s3, 0x42A8
    ctx->r19 = ADD32(ctx->r19, 0X42A8);
    // 0x80129E00: addiu       $s2, $s2, 0x2EBC
    ctx->r18 = ADD32(ctx->r18, 0X2EBC);
    // 0x80129E04: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x80129E08: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x80129E0C: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80129E10: lui         $s4, 0x8020
    ctx->r20 = S32(0X8020 << 16);
    // 0x80129E14: lui         $s5, 0x8020
    ctx->r21 = S32(0X8020 << 16);
    // 0x80129E18: lui         $fp, 0x8020
    ctx->r30 = S32(0X8020 << 16);
    // 0x80129E1C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80129E20: sh          $zero, 0x0($s6)
    MEM_H(0X0, ctx->r22) = 0;
    // 0x80129E24: sh          $zero, 0x0($s2)
    MEM_H(0X0, ctx->r18) = 0;
    // 0x80129E28: sh          $zero, 0x0($s3)
    MEM_H(0X0, ctx->r19) = 0;
    // 0x80129E2C: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80129E30: addiu       $fp, $fp, 0x4290
    ctx->r30 = ADD32(ctx->r30, 0X4290);
    // 0x80129E34: addiu       $s5, $s5, 0x4292
    ctx->r21 = ADD32(ctx->r21, 0X4292);
    // 0x80129E38: addiu       $s4, $s4, 0x4284
    ctx->r20 = ADD32(ctx->r20, 0X4284);
    // 0x80129E3C: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
    // 0x80129E40: addiu       $s7, $zero, 0x2
    ctx->r23 = ADD32(0, 0X2);
L_80129E44:
    // 0x80129E44: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
L_80129E48:
    // 0x80129E48: beql        $s7, $v0, L_80129ED0
    if (ctx->r23 == ctx->r2) {
        // 0x80129E4C: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80129ED0;
    }
    goto skip_0;
    // 0x80129E4C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    skip_0:
    // 0x80129E50: beq         $s0, $v0, L_80129ECC
    if (ctx->r16 == ctx->r2) {
        // 0x80129E54: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80129ECC;
    }
    // 0x80129E54: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80129E58: beq         $v0, $at, L_80129ECC
    if (ctx->r2 == ctx->r1) {
        // 0x80129E5C: addiu       $at, $zero, 0x8
        ctx->r1 = ADD32(0, 0X8);
            goto L_80129ECC;
    }
    // 0x80129E5C: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x80129E60: beql        $v0, $at, L_80129ED0
    if (ctx->r2 == ctx->r1) {
        // 0x80129E64: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80129ED0;
    }
    goto skip_1;
    // 0x80129E64: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    skip_1:
    // 0x80129E68: jal         0x80133738
    // 0x80129E6C: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    stop_all_sounds(rdram, ctx);
        goto after_0;
    // 0x80129E6C: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    after_0:
    // 0x80129E70: jal         0x801328F8
    // 0x80129E74: nop

    func_801328F8(rdram, ctx);
        goto after_1;
    // 0x80129E74: nop

    after_1:
    // 0x80129E78: sh          $s0, 0x0($fp)
    MEM_H(0X0, ctx->r30) = ctx->r16;
    // 0x80129E7C: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80129E80: sh          $zero, 0x645C($at)
    MEM_H(0X645C, ctx->r1) = 0;
    // 0x80129E84: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
    // 0x80129E88: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80129E8C: beq         $v0, $at, L_80129EAC
    if (ctx->r2 == ctx->r1) {
        // 0x80129E90: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80129EAC;
    }
    // 0x80129E90: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80129E94: beq         $v0, $at, L_80129EC0
    if (ctx->r2 == ctx->r1) {
        // 0x80129E98: addiu       $at, $zero, 0x7
        ctx->r1 = ADD32(0, 0X7);
            goto L_80129EC0;
    }
    // 0x80129E98: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80129E9C: beq         $v0, $at, L_80129EC8
    if (ctx->r2 == ctx->r1) {
        // 0x80129EA0: addiu       $t7, $zero, 0x8
        ctx->r15 = ADD32(0, 0X8);
            goto L_80129EC8;
    }
    // 0x80129EA0: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    // 0x80129EA4: b           L_80129ED0
    // 0x80129EA8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
        goto L_80129ED0;
    // 0x80129EA8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
L_80129EAC:
    // 0x80129EAC: jal         0x8012AC40
    // 0x80129EB0: nop

    set_tv_mode_normal(rdram, ctx);
        goto after_2;
    // 0x80129EB0: nop

    after_2:
    // 0x80129EB4: addiu       $t6, $zero, 0x5
    ctx->r14 = ADD32(0, 0X5);
    // 0x80129EB8: b           L_80129ECC
    // 0x80129EBC: sh          $t6, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r14;
        goto L_80129ECC;
    // 0x80129EBC: sh          $t6, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r14;
L_80129EC0:
    // 0x80129EC0: b           L_80129ECC
    // 0x80129EC4: sh          $s7, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r23;
        goto L_80129ECC;
    // 0x80129EC4: sh          $s7, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r23;
L_80129EC8:
    // 0x80129EC8: sh          $t7, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r15;
L_80129ECC:
    // 0x80129ECC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
L_80129ED0:
    // 0x80129ED0: bne         $s1, $at, L_80129F34
    if (ctx->r17 != ctx->r1) {
        // 0x80129ED4: addiu       $t8, $zero, 0x1
        ctx->r24 = ADD32(0, 0X1);
            goto L_80129F34;
    }
    // 0x80129ED4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80129ED8: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80129EDC: sh          $s0, 0x427C($at)
    MEM_H(0X427C, ctx->r1) = ctx->r16;
    // 0x80129EE0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80129EE4: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x80129EE8: jal         0x801328F8
    // 0x80129EEC: sb          $t8, 0x2E98($at)
    MEM_B(0X2E98, ctx->r1) = ctx->r24;
    func_801328F8(rdram, ctx);
        goto after_3;
    // 0x80129EEC: sb          $t8, 0x2E98($at)
    MEM_B(0X2E98, ctx->r1) = ctx->r24;
    after_3:
    // 0x80129EF0: jal         0x801328F8
    // 0x80129EF4: nop

    func_801328F8(rdram, ctx);
        goto after_4;
    // 0x80129EF4: nop

    after_4:
    // 0x80129EF8: jal         0x801328F8
    // 0x80129EFC: nop

    func_801328F8(rdram, ctx);
        goto after_5;
    // 0x80129EFC: nop

    after_5:
    // 0x80129F00: jal         0x801328F8
    // 0x80129F04: nop

    func_801328F8(rdram, ctx);
        goto after_6;
    // 0x80129F04: nop

    after_6:
    // 0x80129F08: lui         $a0, 0x8015
    ctx->r4 = S32(0X8015 << 16);
    // 0x80129F0C: jal         0x8012C070
    // 0x80129F10: lbu         $a0, 0x2E90($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X2E90);
    load_overlay(rdram, ctx);
        goto after_7;
    // 0x80129F10: lbu         $a0, 0x2E90($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X2E90);
    after_7:
    // 0x80129F14: jal         0x801328F8
    // 0x80129F18: nop

    func_801328F8(rdram, ctx);
        goto after_8;
    // 0x80129F18: nop

    after_8:
    // 0x80129F1C: jal         0x801328F8
    // 0x80129F20: nop

    func_801328F8(rdram, ctx);
        goto after_9;
    // 0x80129F20: nop

    after_9:
    // 0x80129F24: jal         0x801328F8
    // 0x80129F28: nop

    func_801328F8(rdram, ctx);
        goto after_10;
    // 0x80129F28: nop

    after_10:
    // 0x80129F2C: jal         0x801328F8
    // 0x80129F30: nop

    func_801328F8(rdram, ctx);
        goto after_11;
    // 0x80129F30: nop

    after_11:
L_80129F34:
    // 0x80129F34: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80129F38: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x80129F3C: addiu       $a1, $a1, 0x4298
    ctx->r5 = ADD32(ctx->r5, 0X4298);
    // 0x80129F40: addiu       $a0, $a0, -0x2FA0
    ctx->r4 = ADD32(ctx->r4, -0X2FA0);
    // 0x80129F44: jal         0x80137FF0
    // 0x80129F48: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_12;
    // 0x80129F48: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_12:
    // 0x80129F4C: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80129F50: lw          $t9, 0x4298($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4298);
    // 0x80129F54: lh          $v0, 0x0($t9)
    ctx->r2 = MEM_H(ctx->r25, 0X0);
    // 0x80129F58: beql        $v0, $s0, L_80129F88
    if (ctx->r2 == ctx->r16) {
        // 0x80129F5C: lh          $t0, 0x0($s5)
        ctx->r8 = MEM_H(ctx->r21, 0X0);
            goto L_80129F88;
    }
    goto skip_2;
    // 0x80129F5C: lh          $t0, 0x0($s5)
    ctx->r8 = MEM_H(ctx->r21, 0X0);
    skip_2:
    // 0x80129F60: beq         $v0, $s7, L_8012A1AC
    if (ctx->r2 == ctx->r23) {
        // 0x80129F64: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8012A1AC;
    }
    // 0x80129F64: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80129F68: beq         $v0, $at, L_8012A208
    if (ctx->r2 == ctx->r1) {
        // 0x80129F6C: lui         $t6, 0x8015
        ctx->r14 = S32(0X8015 << 16);
            goto L_8012A208;
    }
    // 0x80129F6C: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80129F70: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x80129F74: beql        $v0, $at, L_80129E48
    if (ctx->r2 == ctx->r1) {
        // 0x80129F78: lh          $v0, 0x0($s4)
        ctx->r2 = MEM_H(ctx->r20, 0X0);
            goto L_80129E48;
    }
    goto skip_3;
    // 0x80129F78: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
    skip_3:
    // 0x80129F7C: b           L_80129E48
    // 0x80129F80: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
        goto L_80129E48;
    // 0x80129F80: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
    // 0x80129F84: lh          $t0, 0x0($s5)
    ctx->r8 = MEM_H(ctx->r21, 0X0);
L_80129F88:
    // 0x80129F88: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80129F8C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80129F90: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x80129F94: beq         $s1, $zero, L_80129FA8
    if (ctx->r17 == 0) {
        // 0x80129F98: sh          $t1, 0x0($s5)
        MEM_H(0X0, ctx->r21) = ctx->r9;
            goto L_80129FA8;
    }
    // 0x80129F98: sh          $t1, 0x0($s5)
    MEM_H(0X0, ctx->r21) = ctx->r9;
    // 0x80129F9C: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x80129FA0: sll         $t2, $s1, 24
    ctx->r10 = S32(ctx->r17 << 24);
    // 0x80129FA4: sra         $s1, $t2, 24
    ctx->r17 = S32(SIGNED(ctx->r10) >> 24);
L_80129FA8:
    // 0x80129FA8: lh          $v0, -0x612C($v0)
    ctx->r2 = MEM_H(ctx->r2, -0X612C);
    // 0x80129FAC: beq         $v0, $zero, L_80129FB8
    if (ctx->r2 == 0) {
        // 0x80129FB0: addiu       $t4, $v0, -0x1
        ctx->r12 = ADD32(ctx->r2, -0X1);
            goto L_80129FB8;
    }
    // 0x80129FB0: addiu       $t4, $v0, -0x1
    ctx->r12 = ADD32(ctx->r2, -0X1);
    // 0x80129FB4: sh          $t4, -0x612C($at)
    MEM_H(-0X612C, ctx->r1) = ctx->r12;
L_80129FB8:
    // 0x80129FB8: lhu         $t5, 0x0($s2)
    ctx->r13 = MEM_HU(ctx->r18, 0X0);
    // 0x80129FBC: slti        $at, $t5, 0x2
    ctx->r1 = SIGNED(ctx->r13) < 0X2 ? 1 : 0;
    // 0x80129FC0: beql        $at, $zero, L_8012A16C
    if (ctx->r1 == 0) {
        // 0x80129FC4: lh          $t8, 0x0($s3)
        ctx->r24 = MEM_H(ctx->r19, 0X0);
            goto L_8012A16C;
    }
    goto skip_4;
    // 0x80129FC4: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
    skip_4:
    // 0x80129FC8: bnel        $s1, $zero, L_8012A16C
    if (ctx->r17 != 0) {
        // 0x80129FCC: lh          $t8, 0x0($s3)
        ctx->r24 = MEM_H(ctx->r19, 0X0);
            goto L_8012A16C;
    }
    goto skip_5;
    // 0x80129FCC: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
    skip_5:
    // 0x80129FD0: lh          $t6, 0x0($s5)
    ctx->r14 = MEM_H(ctx->r21, 0X0);
    // 0x80129FD4: lh          $t7, 0x0($fp)
    ctx->r15 = MEM_H(ctx->r30, 0X0);
    // 0x80129FD8: slt         $at, $t6, $t7
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80129FDC: bnel        $at, $zero, L_8012A16C
    if (ctx->r1 != 0) {
        // 0x80129FE0: lh          $t8, 0x0($s3)
        ctx->r24 = MEM_H(ctx->r19, 0X0);
            goto L_8012A16C;
    }
    goto skip_6;
    // 0x80129FE0: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
    skip_6:
    // 0x80129FE4: jal         0x80136F64
    // 0x80129FE8: nop

    func_80136F64(rdram, ctx);
        goto after_13;
    // 0x80129FE8: nop

    after_13:
    // 0x80129FEC: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80129FF0: lh          $t8, 0x12D8($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X12D8);
    // 0x80129FF4: beql        $t8, $zero, L_8012A058
    if (ctx->r24 == 0) {
        // 0x80129FF8: lhu         $t0, 0x0($s6)
        ctx->r8 = MEM_HU(ctx->r22, 0X0);
            goto L_8012A058;
    }
    goto skip_7;
    // 0x80129FF8: lhu         $t0, 0x0($s6)
    ctx->r8 = MEM_HU(ctx->r22, 0X0);
    skip_7:
    // 0x80129FFC: jal         0x801370F4
    // 0x8012A000: nop

    func_801370F4(rdram, ctx);
        goto after_14;
    // 0x8012A000: nop

    after_14:
    // 0x8012A004: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A008: jal         0x80138E30
    // 0x8012A00C: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    osContStartReadData_recomp(rdram, ctx);
        goto after_15;
    // 0x8012A00C: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    after_15:
    // 0x8012A010: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A014: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x8012A018: addiu       $a1, $a1, 0x42EC
    ctx->r5 = ADD32(ctx->r5, 0X42EC);
    // 0x8012A01C: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    // 0x8012A020: jal         0x80137FF0
    // 0x8012A024: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_16;
    // 0x8012A024: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_16:
    // 0x8012A028: jal         0x8013713C
    // 0x8012A02C: nop

    func_8013713C(rdram, ctx);
        goto after_17;
    // 0x8012A02C: nop

    after_17:
    // 0x8012A030: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A034: jal         0x80138EBC
    // 0x8012A038: addiu       $a0, $a0, 0x10E8
    ctx->r4 = ADD32(ctx->r4, 0X10E8);
    osContGetReadData_recomp(rdram, ctx);
        goto after_18;
    // 0x8012A038: addiu       $a0, $a0, 0x10E8
    ctx->r4 = ADD32(ctx->r4, 0X10E8);
    after_18:
    // 0x8012A03C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x8012A040: sw          $s0, 0x12D0($at)
    MEM_W(0X12D0, ctx->r1) = ctx->r16;
    // 0x8012A044: lui         $t9, 0x8029
    ctx->r25 = S32(0X8029 << 16);
    // 0x8012A048: addiu       $t9, $t9, 0x10E8
    ctx->r25 = ADD32(ctx->r25, 0X10E8);
    // 0x8012A04C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x8012A050: sw          $t9, 0x10D0($at)
    MEM_W(0X10D0, ctx->r1) = ctx->r25;
    // 0x8012A054: lhu         $t0, 0x0($s6)
    ctx->r8 = MEM_HU(ctx->r22, 0X0);
L_8012A058:
    // 0x8012A058: lui         $t2, 0x8016
    ctx->r10 = S32(0X8016 << 16);
    // 0x8012A05C: addiu       $t2, $t2, 0x2658
    ctx->r10 = ADD32(ctx->r10, 0X2658);
    // 0x8012A060: sll         $t1, $t0, 4
    ctx->r9 = S32(ctx->r8 << 4);
    // 0x8012A064: subu        $t1, $t1, $t0
    ctx->r9 = SUB32(ctx->r9, ctx->r8);
    // 0x8012A068: sll         $t1, $t1, 4
    ctx->r9 = S32(ctx->r9 << 4);
    // 0x8012A06C: subu        $t1, $t1, $t0
    ctx->r9 = SUB32(ctx->r9, ctx->r8);
    // 0x8012A070: sll         $t1, $t1, 6
    ctx->r9 = S32(ctx->r9 << 6);
    // 0x8012A074: subu        $t1, $t1, $t0
    ctx->r9 = SUB32(ctx->r9, ctx->r8);
    // 0x8012A078: sll         $t1, $t1, 4
    ctx->r9 = S32(ctx->r9 << 4);
    // 0x8012A07C: sh          $zero, 0x0($s5)
    MEM_H(0X0, ctx->r21) = 0;
    // 0x8012A080: addu        $t3, $t1, $t2
    ctx->r11 = ADD32(ctx->r9, ctx->r10);
    // 0x8012A084: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012A088: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A08C: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8012A090: sw          $t3, 0x428C($at)
    MEM_W(0X428C, ctx->r1) = ctx->r11;
    // 0x8012A094: lw          $a1, 0x1054($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X1054);
    // 0x8012A098: addiu       $a0, $a0, 0x1060
    ctx->r4 = ADD32(ctx->r4, 0X1060);
    // 0x8012A09C: jal         0x80139050
    // 0x8012A0A0: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_19;
    // 0x8012A0A0: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_19:
    // 0x8012A0A4: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A0A8: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8012A0AC: lw          $a1, 0x1054($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X1054);
    // 0x8012A0B0: addiu       $a0, $a0, 0x1078
    ctx->r4 = ADD32(ctx->r4, 0X1078);
    // 0x8012A0B4: jal         0x80137FF0
    // 0x8012A0B8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_20;
    // 0x8012A0B8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_20:
    // 0x8012A0BC: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8012A0C0: addiu       $v0, $v0, 0x2EA0
    ctx->r2 = ADD32(ctx->r2, 0X2EA0);
    // 0x8012A0C4: lh          $t4, 0x0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X0);
    // 0x8012A0C8: subu        $t5, $s0, $t4
    ctx->r13 = SUB32(ctx->r16, ctx->r12);
    // 0x8012A0CC: jal         0x8012A750
    // 0x8012A0D0: sh          $t5, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r13;
    no_controller_message(rdram, ctx);
        goto after_21;
    // 0x8012A0D0: sh          $t5, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r13;
    after_21:
    // 0x8012A0D4: jal         0x8012A490
    // 0x8012A0D8: nop

    end_display_lists(rdram, ctx);
        goto after_22;
    // 0x8012A0D8: nop

    after_22:
    // 0x8012A0DC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A0E0: jal         0x80131070
    // 0x8012A0E4: sb          $zero, -0x6138($at)
    MEM_B(-0X6138, ctx->r1) = 0;
    reset_task_list(rdram, ctx);
        goto after_23;
    // 0x8012A0E4: sb          $zero, -0x6138($at)
    MEM_B(-0X6138, ctx->r1) = 0;
    after_23:
    // 0x8012A0E8: lhu         $t6, 0x0($s6)
    ctx->r14 = MEM_HU(ctx->r22, 0X0);
    // 0x8012A0EC: lui         $t9, 0x801E
    ctx->r25 = S32(0X801E << 16);
    // 0x8012A0F0: lw          $t9, -0x6184($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X6184);
    // 0x8012A0F4: sll         $t7, $t6, 4
    ctx->r15 = S32(ctx->r14 << 4);
    // 0x8012A0F8: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8012A0FC: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012A100: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8012A104: sll         $t7, $t7, 6
    ctx->r15 = S32(ctx->r15 << 6);
    // 0x8012A108: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8012A10C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x8012A110: sll         $t7, $t7, 4
    ctx->r15 = S32(ctx->r15 << 4);
    // 0x8012A114: addiu       $t8, $t8, 0x2658
    ctx->r24 = ADD32(ctx->r24, 0X2658);
    // 0x8012A118: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    // 0x8012A11C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8012A120: subu        $a2, $t9, $a0
    ctx->r6 = SUB32(ctx->r25, ctx->r4);
    // 0x8012A124: addiu       $a2, $a2, -0x4E0
    ctx->r6 = ADD32(ctx->r6, -0X4E0);
    // 0x8012A128: ori         $at, $at, 0xBBC8
    ctx->r1 = ctx->r1 | 0XBBC8;
    // 0x8012A12C: addu        $t2, $a0, $at
    ctx->r10 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A130: sra         $t0, $a2, 3
    ctx->r8 = S32(SIGNED(ctx->r6) >> 3);
    // 0x8012A134: addiu       $t3, $zero, 0x63
    ctx->r11 = ADD32(0, 0X63);
    // 0x8012A138: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x8012A13C: sll         $a2, $t0, 3
    ctx->r6 = S32(ctx->r8 << 3);
    // 0x8012A140: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x8012A144: addiu       $a1, $a0, 0x4E0
    ctx->r5 = ADD32(ctx->r4, 0X4E0);
    // 0x8012A148: jal         0x8013107C
    // 0x8012A14C: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    func_8013107C(rdram, ctx);
        goto after_24;
    // 0x8012A14C: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    after_24:
    // 0x8012A150: lhu         $t4, 0x0($s2)
    ctx->r12 = MEM_HU(ctx->r18, 0X0);
    // 0x8012A154: lhu         $t6, 0x0($s6)
    ctx->r14 = MEM_HU(ctx->r22, 0X0);
    // 0x8012A158: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8012A15C: xori        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 ^ 0X1;
    // 0x8012A160: sh          $t5, 0x0($s2)
    MEM_H(0X0, ctx->r18) = ctx->r13;
    // 0x8012A164: sh          $t7, 0x0($s6)
    MEM_H(0X0, ctx->r22) = ctx->r15;
    // 0x8012A168: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
L_8012A16C:
    // 0x8012A16C: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x8012A170: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8012A174: sh          $t9, 0x0($s3)
    MEM_H(0X0, ctx->r19) = ctx->r25;
    // 0x8012A178: lh          $t0, 0x0($s3)
    ctx->r8 = MEM_H(ctx->r19, 0X0);
    // 0x8012A17C: slti        $at, $t0, 0x10
    ctx->r1 = SIGNED(ctx->r8) < 0X10 ? 1 : 0;
    // 0x8012A180: bne         $at, $zero, L_8012A18C
    if (ctx->r1 != 0) {
        // 0x8012A184: nop
    
            goto L_8012A18C;
    }
    // 0x8012A184: nop

    // 0x8012A188: sh          $zero, 0x0($s3)
    MEM_H(0X0, ctx->r19) = 0;
L_8012A18C:
    // 0x8012A18C: lh          $t1, 0x2E9C($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2E9C);
    // 0x8012A190: slti        $at, $t1, 0x10
    ctx->r1 = SIGNED(ctx->r9) < 0X10 ? 1 : 0;
    // 0x8012A194: beql        $at, $zero, L_80129E48
    if (ctx->r1 == 0) {
        // 0x8012A198: lh          $v0, 0x0($s4)
        ctx->r2 = MEM_H(ctx->r20, 0X0);
            goto L_80129E48;
    }
    goto skip_8;
    // 0x8012A198: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
    skip_8:
    // 0x8012A19C: jal         0x801328F8
    // 0x8012A1A0: nop

    func_801328F8(rdram, ctx);
        goto after_25;
    // 0x8012A1A0: nop

    after_25:
    // 0x8012A1A4: b           L_80129E48
    // 0x8012A1A8: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
        goto L_80129E48;
    // 0x8012A1A8: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
L_8012A1AC:
    // 0x8012A1AC: lh          $v0, 0x0($fp)
    ctx->r2 = MEM_H(ctx->r30, 0X0);
    // 0x8012A1B0: bnel        $s0, $v0, L_8012A1CC
    if (ctx->r16 != ctx->r2) {
        // 0x8012A1B4: lh          $t2, 0x0($s5)
        ctx->r10 = MEM_H(ctx->r21, 0X0);
            goto L_8012A1CC;
    }
    goto skip_9;
    // 0x8012A1B4: lh          $t2, 0x0($s5)
    ctx->r10 = MEM_H(ctx->r21, 0X0);
    skip_9:
    // 0x8012A1B8: jal         0x8012AB94
    // 0x8012A1BC: nop

    set_screen_scaling(rdram, ctx);
        goto after_26;
    // 0x8012A1BC: nop

    after_26:
    // 0x8012A1C0: b           L_8012A1E4
    // 0x8012A1C4: nop

        goto L_8012A1E4;
    // 0x8012A1C4: nop

    // 0x8012A1C8: lh          $t2, 0x0($s5)
    ctx->r10 = MEM_H(ctx->r21, 0X0);
L_8012A1CC:
    // 0x8012A1CC: addiu       $t3, $v0, -0x1
    ctx->r11 = ADD32(ctx->r2, -0X1);
    // 0x8012A1D0: slt         $at, $t2, $t3
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x8012A1D4: bne         $at, $zero, L_8012A1E4
    if (ctx->r1 != 0) {
        // 0x8012A1D8: nop
    
            goto L_8012A1E4;
    }
    // 0x8012A1D8: nop

    // 0x8012A1DC: jal         0x8012AB94
    // 0x8012A1E0: nop

    set_screen_scaling(rdram, ctx);
        goto after_27;
    // 0x8012A1E0: nop

    after_27:
L_8012A1E4:
    // 0x8012A1E4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8012A1E8: sh          $zero, 0x2EA4($at)
    MEM_H(0X2EA4, ctx->r1) = 0;
    // 0x8012A1EC: sh          $zero, 0x0($s3)
    MEM_H(0X0, ctx->r19) = 0;
    // 0x8012A1F0: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A1F4: sb          $zero, -0x6137($at)
    MEM_B(-0X6137, ctx->r1) = 0;
    // 0x8012A1F8: lhu         $t4, 0x0($s2)
    ctx->r12 = MEM_HU(ctx->r18, 0X0);
    if (ctx->r12 == 0) { ctx->r12 = 1; }
    // 0x8012A1FC: addiu       $t5, $t4, -0x1
    ctx->r13 = ADD32(ctx->r12, -0X1);
    // 0x8012A200: b           L_80129E44
    // 0x8012A204: sh          $t5, 0x0($s2)
    MEM_H(0X0, ctx->r18) = ctx->r13;
        goto L_80129E44;
    // 0x8012A204: sh          $t5, 0x0($s2)
    MEM_H(0X0, ctx->r18) = ctx->r13;
L_8012A208:
    // 0x8012A208: lh          $t6, 0x2E9C($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2E9C);
    // 0x8012A20C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8012A210: bnel        $t6, $zero, L_80129E48
    if (ctx->r14 != 0) {
        // 0x8012A214: lh          $v0, 0x0($s4)
        ctx->r2 = MEM_H(ctx->r20, 0X0);
            goto L_80129E48;
    }
    goto skip_10;
    // 0x8012A214: lh          $v0, 0x0($s4)
    ctx->r2 = MEM_H(ctx->r20, 0X0);
    skip_10:
    // 0x8012A218: b           L_80129E44
    // 0x8012A21C: sh          $s0, 0x2E9C($at)
    MEM_H(0X2E9C, ctx->r1) = ctx->r16;
        goto L_80129E44;
    // 0x8012A21C: sh          $s0, 0x2E9C($at)
    MEM_H(0X2E9C, ctx->r1) = ctx->r16;
    // 0x8012A220: nop

    // 0x8012A224: nop

    // 0x8012A228: nop

    // 0x8012A22C: nop

    // 0x8012A230: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8012A234: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x8012A238: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x8012A23C: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x8012A240: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x8012A244: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x8012A248: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x8012A24C: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x8012A250: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8012A254: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x8012A258: jr          $ra
    // 0x8012A25C: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x8012A25C: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void thread7(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A260: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x8012A264: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8012A268: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x8012A26C: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x8012A270: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8012A274: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8012A278: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8012A27C: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8012A280: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8012A284: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x8012A288: lui         $s0, 0x801E
    ctx->r16 = S32(0X801E << 16);
    // 0x8012A28C: lui         $s2, 0x1
    ctx->r18 = S32(0X1 << 16);
    // 0x8012A290: lui         $s3, 0x8029
    ctx->r19 = S32(0X8029 << 16);
    // 0x8012A294: lui         $s4, 0x8029
    ctx->r20 = S32(0X8029 << 16);
    // 0x8012A298: lui         $s5, 0x8020
    ctx->r21 = S32(0X8020 << 16);
    // 0x8012A29C: lui         $s6, 0x8020
    ctx->r22 = S32(0X8020 << 16);
    // 0x8012A2A0: lui         $s7, 0x801E
    ctx->r23 = S32(0X801E << 16);
    // 0x8012A2A4: lui         $fp, 0x801E
    ctx->r30 = S32(0X801E << 16);
    // 0x8012A2A8: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8012A2AC: addiu       $fp, $fp, -0x6170
    ctx->r30 = ADD32(ctx->r30, -0X6170);
    // 0x8012A2B0: addiu       $s7, $s7, -0x6184
    ctx->r23 = ADD32(ctx->r23, -0X6184);
    // 0x8012A2B4: addiu       $s6, $s6, 0x4278
    ctx->r22 = ADD32(ctx->r22, 0X4278);
    // 0x8012A2B8: addiu       $s5, $s5, 0x428C
    ctx->r21 = ADD32(ctx->r21, 0X428C);
    // 0x8012A2BC: addiu       $s4, $s4, 0x1060
    ctx->r20 = ADD32(ctx->r20, 0X1060);
    // 0x8012A2C0: addiu       $s3, $s3, 0x1054
    ctx->r19 = ADD32(ctx->r19, 0X1054);
    // 0x8012A2C4: ori         $s2, $s2, 0x9A0
    ctx->r18 = ctx->r18 | 0X9A0;
    // 0x8012A2C8: addiu       $s0, $s0, -0x6168
    ctx->r16 = ADD32(ctx->r16, -0X6168);
    // 0x8012A2CC: addiu       $s1, $zero, 0x2BC0
    ctx->r17 = ADD32(0, 0X2BC0);
    // 0x8012A2D0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
L_8012A2D4:
    // 0x8012A2D4: lw          $a1, 0x0($s3)
    ctx->r5 = MEM_W(ctx->r19, 0X0);
    // 0x8012A2D8: jal         0x80137FF0
    // 0x8012A2DC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x8012A2DC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x8012A2E0: lw          $a0, 0x0($s5)
    ctx->r4 = MEM_W(ctx->r21, 0X0);
    // 0x8012A2E4: ori         $at, $zero, 0xDFA0
    ctx->r1 = 0 | 0XDFA0;
    // 0x8012A2E8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8012A2EC: addu        $t6, $a0, $at
    ctx->r14 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A2F0: ori         $at, $zero, 0x81E0
    ctx->r1 = 0 | 0X81E0;
    // 0x8012A2F4: addiu       $a1, $a0, 0x4E0
    ctx->r5 = ADD32(ctx->r4, 0X4E0);
    // 0x8012A2F8: addu        $t7, $a0, $at
    ctx->r15 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A2FC: sw          $a1, 0x0($s6)
    MEM_W(0X0, ctx->r22) = ctx->r5;
    // 0x8012A300: sw          $a1, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r5;
    // 0x8012A304: sw          $t6, 0x0($fp)
    MEM_W(0X0, ctx->r30) = ctx->r14;
    // 0x8012A308: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A30C: sw          $t7, -0x616C($at)
    MEM_W(-0X616C, ctx->r1) = ctx->r15;
    // 0x8012A310: ori         $at, $zero, 0x9AE0
    ctx->r1 = 0 | 0X9AE0;
    // 0x8012A314: addu        $t8, $a0, $at
    ctx->r24 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A318: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A31C: sw          $t8, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r24;
    // 0x8012A320: ori         $at, $zero, 0xC060
    ctx->r1 = 0 | 0XC060;
    // 0x8012A324: addu        $t9, $a0, $at
    ctx->r25 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A328: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A32C: sw          $t9, -0x6174($at)
    MEM_W(-0X6174, ctx->r1) = ctx->r25;
    // 0x8012A330: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x8012A334: ori         $at, $at, 0x6C80
    ctx->r1 = ctx->r1 | 0X6C80;
    // 0x8012A338: addu        $t0, $a0, $at
    ctx->r8 = ADD32(ctx->r4, ctx->r1);
    // 0x8012A33C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8012A340: sw          $t0, -0x6148($at)
    MEM_W(-0X6148, ctx->r1) = ctx->r8;
    sssv_begin_main_display_list(rdram, ctx);
    // 0x8012A344: lw          $v1, 0x0($s6)
    ctx->r3 = MEM_W(ctx->r22, 0X0);
L_8012A348:
    // 0x8012A348: multu       $v0, $s1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8012A34C: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x8012A350: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8012A354: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x8012A358: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8012A35C: slti        $at, $v0, 0x8
    ctx->r1 = SIGNED(ctx->r2) < 0X8 ? 1 : 0;
    // 0x8012A360: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    // 0x8012A364: mflo        $t1
    ctx->r9 = lo;
    // 0x8012A368: addu        $t2, $v1, $t1
    ctx->r10 = ADD32(ctx->r3, ctx->r9);
    // 0x8012A36C: addu        $t3, $t2, $s2
    ctx->r11 = ADD32(ctx->r10, ctx->r18);
    // 0x8012A370: bne         $at, $zero, L_8012A348
    if (ctx->r1 != 0) {
        // 0x8012A374: sw          $t3, 0x0($t5)
        MEM_W(0X0, ctx->r13) = ctx->r11;
            goto L_8012A348;
    }
    // 0x8012A374: sw          $t3, 0x0($t5)
    MEM_W(0X0, ctx->r13) = ctx->r11;
    // 0x8012A378: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x8012A37C: lh          $t8, 0x2E9C($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2E9C);
    // 0x8012A380: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8012A384: sw          $a0, 0x4274($at)
    MEM_W(0X4274, ctx->r1) = ctx->r4;
    // 0x8012A388: bne         $t8, $zero, L_8012A3A0
    if (ctx->r24 != 0) {
        // 0x8012A38C: nop
    
            goto L_8012A3A0;
    }
    // 0x8012A38C: nop

    // 0x8012A390: jal         0x80294E50
    // 0x8012A394: nop

    LOOKUP_FUNC(0x80294E50)(rdram, ctx);
        goto after_1;
    // 0x8012A394: nop

    after_1:
    // 0x8012A398: b           L_8012A3A8
    // 0x8012A39C: nop

        goto L_8012A3A8;
    // 0x8012A39C: nop

L_8012A3A0:
    // 0x8012A3A0: jal         0x8012A588
    // 0x8012A3A4: nop

    func_8012A588(rdram, ctx);
        goto after_2;
    // 0x8012A3A4: nop

    after_2:
L_8012A3A8:
    // 0x8012A3A8: jal         0x80137EB0
    // 0x8012A3AC: nop

    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_3;
    // 0x8012A3AC: nop

    after_3:
    // 0x8012A3B0: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8012A3B4: addiu       $a0, $a0, 0x1078
    ctx->r4 = ADD32(ctx->r4, 0X1078);
    // 0x8012A3B8: lw          $a1, 0x0($s3)
    ctx->r5 = MEM_W(ctx->r19, 0X0);
    // 0x8012A3BC: jal         0x80139050
    // 0x8012A3C0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSendMesg_recomp(rdram, ctx);
        goto after_4;
    // 0x8012A3C0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_4:
    // 0x8012A3C4: b           L_8012A2D4
    // 0x8012A3C8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
        goto L_8012A2D4;
    // 0x8012A3C8: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x8012A3CC: nop

    // 0x8012A3D0: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8012A3D4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8012A3D8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8012A3DC: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x8012A3E0: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x8012A3E4: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x8012A3E8: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8012A3EC: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x8012A3F0: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x8012A3F4: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x8012A3F8: jr          $ra
    // 0x8012A3FC: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x8012A3FC: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_8012A400(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8012A400: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8012A404: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x8012A408: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x8012A40C: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x8012A410: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8012A414: lui         $s1, 0x8020
    ctx->r17 = S32(0X8020 << 16);
    // 0x8012A418: lui         $s2, 0x8029
    ctx->r18 = S32(0X8029 << 16);
    // 0x8012A41C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x8012A420: addiu       $s2, $s2, -0x2FA0
    ctx->r18 = ADD32(ctx->r18, -0X2FA0);
    // 0x8012A424: addiu       $s1, $s1, 0x4298
    ctx->r17 = ADD32(ctx->r17, 0X4298);
    // 0x8012A428: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8012A42C: addiu       $s3, $zero, 0x2
    ctx->r19 = ADD32(0, 0X2);
    // 0x8012A430: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
L_8012A434:
    // 0x8012A434: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8012A438: jal         0x80137FF0
    // 0x8012A43C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x8012A43C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x8012A440: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x8012A444: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x8012A448: bnel        $s3, $t7, L_8012A458
    if (ctx->r19 != ctx->r15) {
        // 0x8012A44C: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_8012A458;
    }
    goto skip_0;
    // 0x8012A44C: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x8012A450: addiu       $s0, $zero, 0x64
    ctx->r16 = ADD32(0, 0X64);
    // 0x8012A454: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_8012A458:
    // 0x8012A458: sll         $t8, $s0, 16
    ctx->r24 = S32(ctx->r16 << 16);
    // 0x8012A45C: sra         $s0, $t8, 16
    ctx->r16 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8012A460: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x8012A464: bnel        $at, $zero, L_8012A434
    if (ctx->r1 != 0) {
        // 0x8012A468: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_8012A434;
    }
    goto skip_1;
    // 0x8012A468: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    skip_1:
    // 0x8012A46C: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8012A470: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8012A474: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x8012A478: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x8012A47C: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x8012A480: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x8012A484: sh          $zero, 0x2EBC($at)
    MEM_H(0X2EBC, ctx->r1) = 0;
    // 0x8012A488: jr          $ra
    // 0x8012A48C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x8012A48C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
