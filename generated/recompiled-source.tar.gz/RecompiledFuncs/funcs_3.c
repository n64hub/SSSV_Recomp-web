#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_801337BC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801337BC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x801337C0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801337C4: sh          $t8, 0x52A8($at)
    MEM_H(0X52A8, ctx->r1) = ctx->r24;
    // 0x801337C8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801337CC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x801337D0: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x801337D4: jr          $ra
    // 0x801337D8: sb          $a0, 0x5164($at)
    MEM_B(0X5164, ctx->r1) = ctx->r4;
    return;
    // 0x801337D8: sb          $a0, 0x5164($at)
    MEM_B(0X5164, ctx->r1) = ctx->r4;
;}
RECOMP_FUNC void start_sequence_volume_fade(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801337DC: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x801337E0: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x801337E4: mtc1        $a1, $f12
    ctx->f12.u32l = ctx->r5;
    // 0x801337E8: mtc1        $a3, $f14
    ctx->f14.u32l = ctx->r7;
    // 0x801337EC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x801337F0: bgtz        $t7, L_80133854
    if (SIGNED(ctx->r15) > 0) {
        // 0x801337F4: sw          $a2, 0x8($sp)
        MEM_W(0X8, ctx->r29) = ctx->r6;
            goto L_80133854;
    }
    // 0x801337F4: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x801337F8: lwc1        $f6, 0x8($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X8);
    // 0x801337FC: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x80133800: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80133804: sub.s       $f8, $f6, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f14.fl;
    // 0x80133808: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013380C: sll         $v0, $t7, 2
    ctx->r2 = S32(ctx->r15 << 2);
    // 0x80133810: div.s       $f4, $f14, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = DIV_S(ctx->f14.fl, ctx->f0.fl);
    // 0x80133814: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133818: swc1        $f12, 0x46AC($at)
    MEM_W(0X46AC, ctx->r1) = ctx->f12.u32l;
    // 0x8013381C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133820: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133824: swc1        $f12, 0x46B0($at)
    MEM_W(0X46B0, ctx->r1) = ctx->f12.u32l;
    // 0x80133828: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013382C: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133830: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80133834: div.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = DIV_S(ctx->f8.fl, ctx->f0.fl);
    // 0x80133838: swc1        $f4, 0x46B4($at)
    MEM_W(0X46B4, ctx->r1) = ctx->f4.u32l;
    // 0x8013383C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133840: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133844: swc1        $f10, 0x46B8($at)
    MEM_W(0X46B8, ctx->r1) = ctx->f10.u32l;
    // 0x80133848: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013384C: addu        $at, $at, $t7
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80133850: sb          $t8, 0x46A8($at)
    MEM_B(0X46A8, ctx->r1) = ctx->r24;
L_80133854:
    // 0x80133854: jr          $ra
    // 0x80133858: nop

    return;
    // 0x80133858: nop

;}
RECOMP_FUNC void start_sfx_volume_fade(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013385C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80133860: lwc1        $f4, 0x8($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X8);
    // 0x80133864: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x80133868: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x8013386C: sub.s       $f8, $f14, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f14.fl - ctx->f4.fl;
    // 0x80133870: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133874: swc1        $f12, 0x46C0($at)
    MEM_W(0X46C0, ctx->r1) = ctx->f12.u32l;
    // 0x80133878: div.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = DIV_S(ctx->f4.fl, ctx->f0.fl);
    // 0x8013387C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133880: swc1        $f12, 0x46C4($at)
    MEM_W(0X46C4, ctx->r1) = ctx->f12.u32l;
    // 0x80133884: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133888: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8013388C: div.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = DIV_S(ctx->f8.fl, ctx->f0.fl);
    // 0x80133890: swc1        $f6, 0x46C8($at)
    MEM_W(0X46C8, ctx->r1) = ctx->f6.u32l;
    // 0x80133894: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133898: swc1        $f10, 0x46CC($at)
    MEM_W(0X46CC, ctx->r1) = ctx->f10.u32l;
    // 0x8013389C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801338A0: jr          $ra
    // 0x801338A4: sb          $t6, 0x46BC($at)
    MEM_B(0X46BC, ctx->r1) = ctx->r14;
    return;
    // 0x801338A4: sb          $t6, 0x46BC($at)
    MEM_B(0X46BC, ctx->r1) = ctx->r14;
;}
RECOMP_FUNC void func_801338A8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801338A8: sll         $a2, $a0, 16
    ctx->r6 = S32(ctx->r4 << 16);
    // 0x801338AC: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x801338B0: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x801338B4: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x801338B8: lbu         $t7, 0x5168($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5168);
    // 0x801338BC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801338C0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x801338C4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801338C8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x801338CC: bne         $v0, $t7, L_8013399C
    if (ctx->r2 != ctx->r15) {
        // 0x801338D0: or          $a2, $t6, $zero
        ctx->r6 = ctx->r14 | 0;
            goto L_8013399C;
    }
    // 0x801338D0: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x801338D4: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x801338D8: addu        $t8, $t8, $t6
    ctx->r24 = ADD32(ctx->r24, ctx->r14);
    // 0x801338DC: lb          $t8, 0x46A8($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X46A8);
    // 0x801338E0: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x801338E4: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x801338E8: bne         $v0, $t8, L_8013399C
    if (ctx->r2 != ctx->r24) {
        // 0x801338EC: addu        $t0, $t0, $t9
        ctx->r8 = ADD32(ctx->r8, ctx->r25);
            goto L_8013399C;
    }
    // 0x801338EC: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x801338F0: lh          $t0, 0x516C($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X516C);
    // 0x801338F4: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x801338F8: sll         $v0, $t6, 2
    ctx->r2 = S32(ctx->r14 << 2);
    // 0x801338FC: sll         $t1, $t0, 1
    ctx->r9 = S32(ctx->r8 << 1);
    // 0x80133900: addu        $t2, $t2, $t1
    ctx->r10 = ADD32(ctx->r10, ctx->r9);
    // 0x80133904: lh          $t2, 0x50F8($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X50F8);
    // 0x80133908: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013390C: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133910: mtc1        $t2, $f4
    ctx->f4.u32l = ctx->r10;
    // 0x80133914: lwc1        $f6, 0x46B8($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X46B8);
    // 0x80133918: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013391C: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133920: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133924: lwc1        $f8, 0x46AC($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46AC);
    // 0x80133928: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013392C: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133930: lwc1        $f18, 0x46B0($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X46B0);
    // 0x80133934: mul.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80133938: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013393C: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133940: lwc1        $f8, 0x46B4($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X46B4);
    // 0x80133944: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133948: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x8013394C: addu        $a0, $a0, $v0
    ctx->r4 = ADD32(ctx->r4, ctx->r2);
    // 0x80133950: mul.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x80133954: lw          $a0, 0x63C8($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63C8);
    // 0x80133958: sh          $t6, 0x1A($sp)
    MEM_H(0X1A, ctx->r29) = ctx->r14;
    // 0x8013395C: mul.s       $f6, $f8, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x80133960: div.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80133964: lwc1        $f16, 0x46D0($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X46D0);
    // 0x80133968: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013396C: lwc1        $f8, 0x517C($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X517C);
    // 0x80133970: add.s       $f10, $f4, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x80133974: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80133978: nop

    // 0x8013397C: mul.s       $f4, $f18, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f8.fl);
    // 0x80133980: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80133984: mfc1        $a1, $f6
    ctx->r5 = (int32_t)ctx->f6.u32l;
    // 0x80133988: nop

    // 0x8013398C: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x80133990: jal         0x8013B870
    // 0x80133994: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    alSeqpSetVol(rdram, ctx);
        goto after_0;
    // 0x80133994: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    after_0:
    // 0x80133998: lh          $a2, 0x1A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X1A);
L_8013399C:
    // 0x8013399C: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x801339A0: addiu       $t7, $t7, 0x46AC
    ctx->r15 = ADD32(ctx->r15, 0X46AC);
    // 0x801339A4: sll         $t6, $a2, 2
    ctx->r14 = S32(ctx->r6 << 2);
    // 0x801339A8: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x801339AC: lwc1        $f0, 0x0($v0)
    ctx->f0.u32l = MEM_W(ctx->r2, 0X0);
    // 0x801339B0: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x801339B4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x801339B8: c.eq.s      $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f10.fl == ctx->f0.fl;
    // 0x801339BC: nop

    // 0x801339C0: bc1fl       L_801339DC
    if (!c1cs) {
        // 0x801339C4: mtc1        $at, $f16
        ctx->f16.u32l = ctx->r1;
            goto L_801339DC;
    }
    goto skip_0;
    // 0x801339C4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    skip_0:
    // 0x801339C8: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x801339CC: addu        $at, $at, $a2
    ctx->r1 = ADD32(ctx->r1, ctx->r6);
    // 0x801339D0: b           L_801339E8
    // 0x801339D4: sb          $zero, 0x46A8($at)
    MEM_B(0X46A8, ctx->r1) = 0;
        goto L_801339E8;
    // 0x801339D4: sb          $zero, 0x46A8($at)
    MEM_B(0X46A8, ctx->r1) = 0;
    // 0x801339D8: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
L_801339DC:
    // 0x801339DC: nop

    // 0x801339E0: sub.s       $f18, $f0, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = ctx->f0.fl - ctx->f16.fl;
    // 0x801339E4: swc1        $f18, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f18.u32l;
L_801339E8:
    // 0x801339E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x801339EC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x801339F0: jr          $ra
    // 0x801339F4: nop

    return;
    // 0x801339F4: nop

;}
RECOMP_FUNC void func_801339F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801339F8: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x801339FC: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80133A00: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80133A04: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80133A08: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x80133A0C: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80133A10: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80133A14: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80133A18: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80133A1C: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80133A20: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80133A24: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80133A28: beq         $t6, $zero, L_80133B44
    if (ctx->r14 == 0) {
        // 0x80133A2C: sw          $s0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r16;
            goto L_80133B44;
    }
    // 0x80133A2C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80133A30: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80133A34: lw          $s0, 0x631C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X631C);
    // 0x80133A38: lui         $fp, 0x8015
    ctx->r30 = S32(0X8015 << 16);
    // 0x80133A3C: addiu       $fp, $fp, 0x46C4
    ctx->r30 = ADD32(ctx->r30, 0X46C4);
    // 0x80133A40: beq         $s0, $zero, L_80133B00
    if (ctx->r16 == 0) {
        // 0x80133A44: lui         $s7, 0x8015
        ctx->r23 = S32(0X8015 << 16);
            goto L_80133B00;
    }
    // 0x80133A44: lui         $s7, 0x8015
    ctx->r23 = S32(0X8015 << 16);
    // 0x80133A48: lui         $s6, 0x8015
    ctx->r22 = S32(0X8015 << 16);
    // 0x80133A4C: lui         $s5, 0x8015
    ctx->r21 = S32(0X8015 << 16);
    // 0x80133A50: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80133A54: lui         $s2, 0x8028
    ctx->r18 = S32(0X8028 << 16);
    // 0x80133A58: addiu       $s2, $s2, 0x6310
    ctx->r18 = ADD32(ctx->r18, 0X6310);
    // 0x80133A5C: addiu       $s3, $s3, 0x46C0
    ctx->r19 = ADD32(ctx->r19, 0X46C0);
    // 0x80133A60: addiu       $s5, $s5, 0x46BC
    ctx->r21 = ADD32(ctx->r21, 0X46BC);
    // 0x80133A64: addiu       $s6, $s6, 0x46C8
    ctx->r22 = ADD32(ctx->r22, 0X46C8);
    // 0x80133A68: addiu       $s7, $s7, 0x46CC
    ctx->r23 = ADD32(ctx->r23, 0X46CC);
    // 0x80133A6C: addiu       $s4, $zero, 0x1
    ctx->r20 = ADD32(0, 0X1);
    // 0x80133A70: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
L_80133A74:
    // 0x80133A74: bltzl       $a1, L_80133AF8
    if (SIGNED(ctx->r5) < 0) {
        // 0x80133A78: lw          $s0, 0x30($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X30);
            goto L_80133AF8;
    }
    goto skip_0;
    // 0x80133A78: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
    skip_0:
    // 0x80133A7C: lb          $t7, 0x0($s5)
    ctx->r15 = MEM_B(ctx->r21, 0X0);
    // 0x80133A80: bnel        $s4, $t7, L_80133AF8
    if (ctx->r20 != ctx->r15) {
        // 0x80133A84: lw          $s0, 0x30($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X30);
            goto L_80133AF8;
    }
    goto skip_1;
    // 0x80133A84: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
    skip_1:
    // 0x80133A88: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x80133A8C: lwc1        $f8, 0x0($s3)
    ctx->f8.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80133A90: lwc1        $f6, 0x0($s7)
    ctx->f6.u32l = MEM_W(ctx->r23, 0X0);
    // 0x80133A94: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80133A98: lwc1        $f18, 0x0($fp)
    ctx->f18.u32l = MEM_W(ctx->r30, 0X0);
    // 0x80133A9C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133AA0: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133AA4: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    // 0x80133AA8: mul.s       $f10, $f0, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80133AAC: lwc1        $f8, 0x0($s6)
    ctx->f8.u32l = MEM_W(ctx->r22, 0X0);
    // 0x80133AB0: mul.s       $f16, $f6, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f6.fl, ctx->f10.fl);
    // 0x80133AB4: div.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = DIV_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80133AB8: lwc1        $f16, 0x46D4($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X46D4);
    // 0x80133ABC: mul.s       $f6, $f0, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = MUL_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80133AC0: add.s       $f10, $f6, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f6.fl + ctx->f4.fl;
    // 0x80133AC4: mul.s       $f18, $f10, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f10.fl, ctx->f16.fl);
    // 0x80133AC8: trunc.w.s   $f8, $f18
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    ctx->f8.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80133ACC: mfc1        $s1, $f8
    ctx->r17 = (int32_t)ctx->f8.u32l;
    // 0x80133AD0: nop

    // 0x80133AD4: sll         $t0, $s1, 16
    ctx->r8 = S32(ctx->r17 << 16);
    // 0x80133AD8: jal         0x8013B980
    // 0x80133ADC: sra         $s1, $t0, 16
    ctx->r17 = S32(SIGNED(ctx->r8) >> 16);
    alSndpSetSound(rdram, ctx);
        goto after_0;
    // 0x80133ADC: sra         $s1, $t0, 16
    ctx->r17 = S32(SIGNED(ctx->r8) >> 16);
    after_0:
    // 0x80133AE0: sll         $a1, $s1, 16
    ctx->r5 = S32(ctx->r17 << 16);
    // 0x80133AE4: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80133AE8: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x80133AEC: jal         0x8013BA00
    // 0x80133AF0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    alSndpSetVol(rdram, ctx);
        goto after_1;
    // 0x80133AF0: lw          $a0, 0x0($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X0);
    after_1:
    // 0x80133AF4: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
L_80133AF8:
    // 0x80133AF8: bnel        $s0, $zero, L_80133A74
    if (ctx->r16 != 0) {
        // 0x80133AFC: lh          $a1, 0x22($s0)
        ctx->r5 = MEM_H(ctx->r16, 0X22);
            goto L_80133A74;
    }
    goto skip_2;
    // 0x80133AFC: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    skip_2:
L_80133B00:
    // 0x80133B00: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80133B04: addiu       $s3, $s3, 0x46C0
    ctx->r19 = ADD32(ctx->r19, 0X46C0);
    // 0x80133B08: lwc1        $f0, 0x0($s3)
    ctx->f0.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80133B0C: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80133B10: lui         $s5, 0x8015
    ctx->r21 = S32(0X8015 << 16);
    // 0x80133B14: addiu       $s5, $s5, 0x46BC
    ctx->r21 = ADD32(ctx->r21, 0X46BC);
    // 0x80133B18: c.eq.s      $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f6.fl == ctx->f0.fl;
    // 0x80133B1C: nop

    // 0x80133B20: bc1fl       L_80133B34
    if (!c1cs) {
        // 0x80133B24: lui         $at, 0x3F80
        ctx->r1 = S32(0X3F80 << 16);
            goto L_80133B34;
    }
    goto skip_3;
    // 0x80133B24: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    skip_3:
    // 0x80133B28: b           L_80133B44
    // 0x80133B2C: sb          $zero, 0x0($s5)
    MEM_B(0X0, ctx->r21) = 0;
        goto L_80133B44;
    // 0x80133B2C: sb          $zero, 0x0($s5)
    MEM_B(0X0, ctx->r21) = 0;
    // 0x80133B30: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
L_80133B34:
    // 0x80133B34: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80133B38: nop

    // 0x80133B3C: sub.s       $f10, $f0, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f0.fl - ctx->f4.fl;
    // 0x80133B40: swc1        $f10, 0x0($s3)
    MEM_W(0X0, ctx->r19) = ctx->f10.u32l;
L_80133B44:
    // 0x80133B44: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80133B48: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80133B4C: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80133B50: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80133B54: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80133B58: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80133B5C: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80133B60: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80133B64: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80133B68: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80133B6C: jr          $ra
    // 0x80133B70: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x80133B70: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void set_sfx_volume(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133B74: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80133B78: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80133B7C: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80133B80: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
    // 0x80133B84: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x80133B88: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80133B8C: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133B90: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133B94: div.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80133B98: jr          $ra
    // 0x80133B9C: swc1        $f10, 0x46D4($at)
    MEM_W(0X46D4, ctx->r1) = ctx->f10.u32l;
    return;
    // 0x80133B9C: swc1        $f10, 0x46D4($at)
    MEM_W(0X46D4, ctx->r1) = ctx->f10.u32l;
;}
RECOMP_FUNC void set_music_volume(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133BA0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80133BA4: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80133BA8: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80133BAC: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80133BB0: mtc1        $a0, $f4
    ctx->f4.u32l = ctx->r4;
    // 0x80133BB4: lui         $at, 0x41A0
    ctx->r1 = S32(0X41A0 << 16);
    // 0x80133BB8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80133BBC: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133BC0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80133BC4: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133BC8: div.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80133BCC: jal         0x80133C50
    // 0x80133BD0: swc1        $f10, 0x46D0($at)
    MEM_W(0X46D0, ctx->r1) = ctx->f10.u32l;
    func_80133C50(rdram, ctx);
        goto after_0;
    // 0x80133BD0: swc1        $f10, 0x46D0($at)
    MEM_W(0X46D0, ctx->r1) = ctx->f10.u32l;
    after_0:
    // 0x80133BD4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80133BD8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80133BDC: jr          $ra
    // 0x80133BE0: nop

    return;
    // 0x80133BE0: nop

;}
RECOMP_FUNC void func_80133BE4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133BE4: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80133BE8: lw          $t6, 0x5154($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5154);
    // 0x80133BEC: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80133BF0: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80133BF4: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80133BF8: beq         $t6, $zero, L_80133C3C
    if (ctx->r14 == 0) {
        // 0x80133BFC: sw          $s0, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r16;
            goto L_80133C3C;
    }
    // 0x80133BFC: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80133C00: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80133C04: lw          $s0, 0x631C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X631C);
    // 0x80133C08: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x80133C0C: beql        $s0, $zero, L_80133C40
    if (ctx->r16 == 0) {
        // 0x80133C10: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80133C40;
    }
    goto skip_0;
    // 0x80133C10: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80133C14: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
L_80133C18:
    // 0x80133C18: bltzl       $a1, L_80133C34
    if (SIGNED(ctx->r5) < 0) {
        // 0x80133C1C: lw          $s0, 0x30($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X30);
            goto L_80133C34;
    }
    goto skip_1;
    // 0x80133C1C: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
    skip_1:
    // 0x80133C20: jal         0x8013B980
    // 0x80133C24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpSetSound(rdram, ctx);
        goto after_0;
    // 0x80133C24: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_0:
    // 0x80133C28: jal         0x8013BB60
    // 0x80133C2C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    alSndpGetState(rdram, ctx);
        goto after_1;
    // 0x80133C2C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_1:
    // 0x80133C30: lw          $s0, 0x30($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X30);
L_80133C34:
    // 0x80133C34: bnel        $s0, $zero, L_80133C18
    if (ctx->r16 != 0) {
        // 0x80133C38: lh          $a1, 0x22($s0)
        ctx->r5 = MEM_H(ctx->r16, 0X22);
            goto L_80133C18;
    }
    goto skip_2;
    // 0x80133C38: lh          $a1, 0x22($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X22);
    skip_2:
L_80133C3C:
    // 0x80133C3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80133C40:
    // 0x80133C40: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80133C44: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80133C48: jr          $ra
    // 0x80133C4C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x80133C4C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void func_80133C50(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133C50: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x80133C54: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x80133C58: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x80133C5C: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x80133C60: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x80133C64: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80133C68: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x80133C6C: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x80133C70: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x80133C74: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x80133C78: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x80133C7C: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80133C80: lui         $s2, 0x8015
    ctx->r18 = S32(0X8015 << 16);
    // 0x80133C84: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80133C88: lui         $s4, 0x8015
    ctx->r20 = S32(0X8015 << 16);
    // 0x80133C8C: lui         $s6, 0x8015
    ctx->r22 = S32(0X8015 << 16);
    // 0x80133C90: lui         $s7, 0x8015
    ctx->r23 = S32(0X8015 << 16);
    // 0x80133C94: lui         $fp, 0x8015
    ctx->r30 = S32(0X8015 << 16);
    // 0x80133C98: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x80133C9C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80133CA0: addiu       $fp, $fp, 0x46D8
    ctx->r30 = ADD32(ctx->r30, 0X46D8);
    // 0x80133CA4: addiu       $s7, $s7, 0x5168
    ctx->r23 = ADD32(ctx->r23, 0X5168);
    // 0x80133CA8: addiu       $s6, $s6, 0x516C
    ctx->r22 = ADD32(ctx->r22, 0X516C);
    // 0x80133CAC: addiu       $s4, $s4, 0x517C
    ctx->r20 = ADD32(ctx->r20, 0X517C);
    // 0x80133CB0: addiu       $s3, $s3, 0x46D0
    ctx->r19 = ADD32(ctx->r19, 0X46D0);
    // 0x80133CB4: addiu       $s2, $s2, 0x50F8
    ctx->r18 = ADD32(ctx->r18, 0X50F8);
    // 0x80133CB8: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80133CBC: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    // 0x80133CC0: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x80133CC4: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
L_80133CC8:
    // 0x80133CC8: addu        $t7, $s6, $t6
    ctx->r15 = ADD32(ctx->r22, ctx->r14);
    // 0x80133CCC: lh          $v1, 0x0($t7)
    ctx->r3 = MEM_H(ctx->r15, 0X0);
    // 0x80133CD0: addu        $t8, $s7, $s0
    ctx->r24 = ADD32(ctx->r23, ctx->r16);
    // 0x80133CD4: beql        $s5, $v1, L_80133E00
    if (ctx->r21 == ctx->r3) {
        // 0x80133CD8: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80133E00;
    }
    goto skip_0;
    // 0x80133CD8: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x80133CDC: lbu         $t9, 0x0($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X0);
    // 0x80133CE0: bnel        $s1, $t9, L_80133E00
    if (ctx->r17 != ctx->r25) {
        // 0x80133CE4: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80133E00;
    }
    goto skip_1;
    // 0x80133CE4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_1:
    // 0x80133CE8: lh          $t0, 0x0($fp)
    ctx->r8 = MEM_H(ctx->r30, 0X0);
    // 0x80133CEC: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x80133CF0: addu        $t1, $t1, $s0
    ctx->r9 = ADD32(ctx->r9, ctx->r16);
    // 0x80133CF4: mtc1        $t0, $f4
    ctx->f4.u32l = ctx->r8;
    // 0x80133CF8: lb          $t1, 0x46A8($t1)
    ctx->r9 = MEM_B(ctx->r9, 0X46A8);
    // 0x80133CFC: sll         $t2, $v1, 1
    ctx->r10 = S32(ctx->r3 << 1);
    // 0x80133D00: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133D04: sll         $t8, $v1, 1
    ctx->r24 = S32(ctx->r3 << 1);
    // 0x80133D08: addu        $t3, $s2, $t2
    ctx->r11 = ADD32(ctx->r18, ctx->r10);
    // 0x80133D0C: addu        $t9, $s2, $t8
    ctx->r25 = ADD32(ctx->r18, ctx->r24);
    // 0x80133D10: bne         $s1, $t1, L_80133D98
    if (ctx->r17 != ctx->r9) {
        // 0x80133D14: div.s       $f2, $f6, $f20
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f20.fl);
            goto L_80133D98;
    }
    // 0x80133D14: div.s       $f2, $f6, $f20
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f20.fl); 
    ctx->f2.fl = DIV_S(ctx->f6.fl, ctx->f20.fl);
    // 0x80133D18: lh          $t4, 0x0($t3)
    ctx->r12 = MEM_H(ctx->r11, 0X0);
    // 0x80133D1C: sll         $v0, $s0, 2
    ctx->r2 = S32(ctx->r16 << 2);
    // 0x80133D20: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133D24: mtc1        $t4, $f8
    ctx->f8.u32l = ctx->r12;
    // 0x80133D28: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133D2C: lwc1        $f10, 0x46B8($at)
    ctx->f10.u32l = MEM_W(ctx->r1, 0X46B8);
    // 0x80133D30: cvt.s.w     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    ctx->f0.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80133D34: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133D38: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133D3C: lwc1        $f16, 0x46AC($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X46AC);
    // 0x80133D40: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133D44: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133D48: mul.s       $f18, $f0, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f0.fl, ctx->f16.fl);
    // 0x80133D4C: lwc1        $f6, 0x46B0($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X46B0);
    // 0x80133D50: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133D54: addu        $at, $at, $v0
    ctx->r1 = ADD32(ctx->r1, ctx->r2);
    // 0x80133D58: lwc1        $f16, 0x46B4($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X46B4);
    // 0x80133D5C: mul.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f18.fl);
    // 0x80133D60: div.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f4.fl, ctx->f6.fl);
    // 0x80133D64: lwc1        $f4, 0x0($s3)
    ctx->f4.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80133D68: mul.s       $f10, $f16, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f16.fl, ctx->f0.fl);
    // 0x80133D6C: lwc1        $f16, 0x0($s4)
    ctx->f16.u32l = MEM_W(ctx->r20, 0X0);
    // 0x80133D70: add.s       $f18, $f8, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f18.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x80133D74: mul.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80133D78: nop

    // 0x80133D7C: mul.s       $f8, $f6, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80133D80: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80133D84: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x80133D88: nop

    // 0x80133D8C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80133D90: b           L_80133DCC
    // 0x80133D94: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
        goto L_80133DCC;
    // 0x80133D94: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
L_80133D98:
    // 0x80133D98: lh          $t0, 0x0($t9)
    ctx->r8 = MEM_H(ctx->r25, 0X0);
    // 0x80133D9C: lwc1        $f18, 0x0($s4)
    ctx->f18.u32l = MEM_W(ctx->r20, 0X0);
    // 0x80133DA0: lwc1        $f4, 0x0($s3)
    ctx->f4.u32l = MEM_W(ctx->r19, 0X0);
    // 0x80133DA4: mtc1        $t0, $f16
    ctx->f16.u32l = ctx->r8;
    // 0x80133DA8: sll         $v0, $s0, 2
    ctx->r2 = S32(ctx->r16 << 2);
    // 0x80133DAC: mul.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80133DB0: cvt.s.w     $f8, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    ctx->f8.fl = CVT_S_W(ctx->f16.u32l);
    // 0x80133DB4: mul.s       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f6.fl);
    // 0x80133DB8: trunc.w.s   $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x80133DBC: mfc1        $a1, $f18
    ctx->r5 = (int32_t)ctx->f18.u32l;
    // 0x80133DC0: nop

    // 0x80133DC4: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x80133DC8: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
L_80133DCC:
    // 0x80133DCC: mtc1        $a1, $f4
    ctx->f4.u32l = ctx->r5;
    // 0x80133DD0: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133DD4: addu        $a0, $a0, $v0
    ctx->r4 = ADD32(ctx->r4, ctx->r2);
    // 0x80133DD8: cvt.s.w     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80133DDC: lw          $a0, 0x63C8($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63C8);
    // 0x80133DE0: mul.s       $f8, $f16, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = MUL_S(ctx->f16.fl, ctx->f2.fl);
    // 0x80133DE4: trunc.w.s   $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80133DE8: mfc1        $a1, $f6
    ctx->r5 = (int32_t)ctx->f6.u32l;
    // 0x80133DEC: nop

    // 0x80133DF0: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x80133DF4: jal         0x8013B870
    // 0x80133DF8: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    alSeqpSetVol(rdram, ctx);
        goto after_0;
    // 0x80133DF8: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    after_0:
    // 0x80133DFC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80133E00:
    // 0x80133E00: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x80133E04: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80133E08: blezl       $s0, L_80133CC8
    if (SIGNED(ctx->r16) <= 0) {
        // 0x80133E0C: sll         $t6, $s0, 1
        ctx->r14 = S32(ctx->r16 << 1);
            goto L_80133CC8;
    }
    goto skip_2;
    // 0x80133E0C: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    skip_2:
    // 0x80133E10: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x80133E14: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x80133E18: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x80133E1C: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x80133E20: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x80133E24: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x80133E28: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x80133E2C: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x80133E30: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x80133E34: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x80133E38: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x80133E3C: jr          $ra
    // 0x80133E40: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x80133E40: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void func_80133E44(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133E44: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80133E48: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80133E4C: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133E50: lui         $a1, 0x8028
    ctx->r5 = S32(0X8028 << 16);
    // 0x80133E54: addiu       $a1, $a1, 0x6460
    ctx->r5 = ADD32(ctx->r5, 0X6460);
    // 0x80133E58: jal         0x8013AD70
    // 0x80133E5C: lw          $a0, 0x63CC($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63CC);
    alCSeqGetLoc(rdram, ctx);
        goto after_0;
    // 0x80133E5C: lw          $a0, 0x63CC($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63CC);
    after_0:
    // 0x80133E60: lui         $t6, 0x8028
    ctx->r14 = S32(0X8028 << 16);
    // 0x80133E64: lh          $t6, 0x645C($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X645C);
    // 0x80133E68: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80133E6C: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133E70: sh          $t6, 0x5180($at)
    MEM_H(0X5180, ctx->r1) = ctx->r14;
    // 0x80133E74: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133E78: sh          $zero, 0x5184($at)
    MEM_H(0X5184, ctx->r1) = 0;
    // 0x80133E7C: jr          $ra
    // 0x80133E80: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    return;
    // 0x80133E80: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
;}
RECOMP_FUNC void func_80133E84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133E84: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80133E88: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x80133E8C: lh          $t6, 0x5180($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5180);
    // 0x80133E90: lh          $v0, 0x645C($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X645C);
    // 0x80133E94: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80133E98: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80133E9C: bnel        $v0, $t6, L_80133EEC
    if (ctx->r2 != ctx->r14) {
        // 0x80133EA0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80133EEC;
    }
    goto skip_0;
    // 0x80133EA0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x80133EA4: beq         $v0, $zero, L_80133EE8
    if (ctx->r2 == 0) {
        // 0x80133EA8: lui         $v0, 0x8015
        ctx->r2 = S32(0X8015 << 16);
            goto L_80133EE8;
    }
    // 0x80133EA8: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80133EAC: addiu       $v0, $v0, 0x5184
    ctx->r2 = ADD32(ctx->r2, 0X5184);
    // 0x80133EB0: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x80133EB4: lui         $a1, 0x8028
    ctx->r5 = S32(0X8028 << 16);
    // 0x80133EB8: addiu       $a1, $a1, 0x6460
    ctx->r5 = ADD32(ctx->r5, 0X6460);
    // 0x80133EBC: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80133EC0: sh          $t8, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r24;
    // 0x80133EC4: lh          $t9, 0x0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X0);
    // 0x80133EC8: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80133ECC: slti        $at, $t9, 0x3
    ctx->r1 = SIGNED(ctx->r25) < 0X3 ? 1 : 0;
    // 0x80133ED0: bnel        $at, $zero, L_80133EEC
    if (ctx->r1 != 0) {
        // 0x80133ED4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80133EEC;
    }
    goto skip_1;
    // 0x80133ED4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80133ED8: jal         0x8013AE10
    // 0x80133EDC: lw          $a0, 0x63CC($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63CC);
    alCSeqSetLoc(rdram, ctx);
        goto after_0;
    // 0x80133EDC: lw          $a0, 0x63CC($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X63CC);
    after_0:
    // 0x80133EE0: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80133EE4: sh          $zero, 0x5180($at)
    MEM_H(0X5180, ctx->r1) = 0;
L_80133EE8:
    // 0x80133EE8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80133EEC:
    // 0x80133EEC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80133EF0: jr          $ra
    // 0x80133EF4: nop

    return;
    // 0x80133EF4: nop

;}
RECOMP_FUNC void alCSPNew(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80133F00: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x80133F04: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80133F08: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x80133F0C: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x80133F10: lw          $a2, 0xC($a1)
    ctx->r6 = MEM_W(ctx->r5, 0XC);
    // 0x80133F14: sw          $zero, 0x20($a0)
    MEM_W(0X20, ctx->r4) = 0;
    // 0x80133F18: sw          $zero, 0x18($a0)
    MEM_W(0X18, ctx->r4) = 0;
    // 0x80133F1C: lui         $t6, 0x8016
    ctx->r14 = S32(0X8016 << 16);
    // 0x80133F20: lw          $t6, -0x5960($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X5960);
    // 0x80133F24: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x80133F28: addiu       $t8, $zero, 0x1E8
    ctx->r24 = ADD32(0, 0X1E8);
    // 0x80133F2C: addiu       $t9, $zero, 0x7FFF
    ctx->r25 = ADD32(0, 0X7FFF);
    // 0x80133F30: addiu       $t0, $zero, 0x3E80
    ctx->r8 = ADD32(0, 0X3E80);
    // 0x80133F34: sh          $t7, 0x30($a0)
    MEM_H(0X30, ctx->r4) = ctx->r15;
    // 0x80133F38: sw          $t8, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r24;
    // 0x80133F3C: sw          $zero, 0x28($a0)
    MEM_W(0X28, ctx->r4) = 0;
    // 0x80133F40: sw          $zero, 0x2C($a0)
    MEM_W(0X2C, ctx->r4) = 0;
    // 0x80133F44: sh          $t9, 0x32($a0)
    MEM_H(0X32, ctx->r4) = ctx->r25;
    // 0x80133F48: sw          $t0, 0x5C($a0)
    MEM_W(0X5C, ctx->r4) = ctx->r8;
    // 0x80133F4C: sw          $zero, 0x1C($a0)
    MEM_W(0X1C, ctx->r4) = 0;
    // 0x80133F50: sw          $t6, 0x14($a0)
    MEM_W(0X14, ctx->r4) = ctx->r14;
    // 0x80133F54: lw          $t1, 0x10($a1)
    ctx->r9 = MEM_W(ctx->r5, 0X10);
    // 0x80133F58: addiu       $t4, $zero, 0x9
    ctx->r12 = ADD32(0, 0X9);
    // 0x80133F5C: or          $s1, $a1, $zero
    ctx->r17 = ctx->r5 | 0;
    // 0x80133F60: sw          $t1, 0x70($a0)
    MEM_W(0X70, ctx->r4) = ctx->r9;
    // 0x80133F64: lw          $t2, 0x14($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X14);
    // 0x80133F68: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80133F6C: addiu       $t6, $zero, 0x10
    ctx->r14 = ADD32(0, 0X10);
    // 0x80133F70: sw          $t2, 0x74($a0)
    MEM_W(0X74, ctx->r4) = ctx->r10;
    // 0x80133F74: lw          $t3, 0x18($a1)
    ctx->r11 = MEM_W(ctx->r5, 0X18);
    // 0x80133F78: sh          $t4, 0x38($a0)
    MEM_H(0X38, ctx->r4) = ctx->r12;
    // 0x80133F7C: sw          $t3, 0x78($a0)
    MEM_W(0X78, ctx->r4) = ctx->r11;
    // 0x80133F80: lbu         $t5, 0x8($a1)
    ctx->r13 = MEM_BU(ctx->r5, 0X8);
    // 0x80133F84: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80133F88: sb          $t5, 0x34($a0)
    MEM_B(0X34, ctx->r4) = ctx->r13;
    // 0x80133F8C: lbu         $a3, 0x8($s1)
    ctx->r7 = MEM_BU(ctx->r17, 0X8);
    // 0x80133F90: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80133F94: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80133F98: jal         0x80139A40
    // 0x80133F9C: sw          $a2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r6;
    alHeapDBAlloc(rdram, ctx);
        goto after_0;
    // 0x80133F9C: sw          $a2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r6;
    after_0:
    // 0x80133FA0: sw          $v0, 0x60($s0)
    MEM_W(0X60, ctx->r16) = ctx->r2;
    // 0x80133FA4: jal         0x8013D3C4
    // 0x80133FA8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __initChanState(rdram, ctx);
        goto after_1;
    // 0x80133FA8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x80133FAC: lw          $a3, 0x0($s1)
    ctx->r7 = MEM_W(ctx->r17, 0X0);
    // 0x80133FB0: addiu       $t7, $zero, 0x38
    ctx->r15 = ADD32(0, 0X38);
    // 0x80133FB4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80133FB8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80133FBC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80133FC0: jal         0x80139A40
    // 0x80133FC4: lw          $a2, 0x2C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X2C);
    alHeapDBAlloc(rdram, ctx);
        goto after_2;
    // 0x80133FC4: lw          $a2, 0x2C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X2C);
    after_2:
    // 0x80133FC8: sw          $zero, 0x6C($s0)
    MEM_W(0X6C, ctx->r16) = 0;
    // 0x80133FCC: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x80133FD0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80133FD4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80133FD8: blez        $t8, L_80134008
    if (SIGNED(ctx->r24) <= 0) {
        // 0x80133FDC: addiu       $t1, $zero, 0x1C
        ctx->r9 = ADD32(0, 0X1C);
            goto L_80134008;
    }
    // 0x80133FDC: addiu       $t1, $zero, 0x1C
    ctx->r9 = ADD32(0, 0X1C);
    // 0x80133FE0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80133FE4: lw          $t9, 0x6C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X6C);
L_80133FE8:
    // 0x80133FE8: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80133FEC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80133FF0: sw          $v1, 0x6C($s0)
    MEM_W(0X6C, ctx->r16) = ctx->r3;
    // 0x80133FF4: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x80133FF8: addiu       $v1, $v1, 0x38
    ctx->r3 = ADD32(ctx->r3, 0X38);
    // 0x80133FFC: slt         $at, $a0, $t0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x80134000: bnel        $at, $zero, L_80133FE8
    if (ctx->r1 != 0) {
        // 0x80134004: lw          $t9, 0x6C($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X6C);
            goto L_80133FE8;
    }
    goto skip_0;
    // 0x80134004: lw          $t9, 0x6C($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X6C);
    skip_0:
L_80134008:
    // 0x80134008: sw          $zero, 0x64($s0)
    MEM_W(0X64, ctx->r16) = 0;
    // 0x8013400C: sw          $zero, 0x68($s0)
    MEM_W(0X68, ctx->r16) = 0;
    // 0x80134010: lw          $a3, 0x4($s1)
    ctx->r7 = MEM_W(ctx->r17, 0X4);
    // 0x80134014: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80134018: lw          $a2, 0x2C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X2C);
    // 0x8013401C: jal         0x80139A40
    // 0x80134020: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    alHeapDBAlloc(rdram, ctx);
        goto after_3;
    // 0x80134020: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_3:
    // 0x80134024: addiu       $a0, $s0, 0x48
    ctx->r4 = ADD32(ctx->r16, 0X48);
    // 0x80134028: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8013402C: jal         0x8013D88C
    // 0x80134030: lw          $a2, 0x4($s1)
    ctx->r6 = MEM_W(ctx->r17, 0X4);
    alEvtqNew(rdram, ctx);
        goto after_4;
    // 0x80134030: lw          $a2, 0x4($s1)
    ctx->r6 = MEM_W(ctx->r17, 0X4);
    after_4:
    // 0x80134034: lui         $t2, 0x8013
    ctx->r10 = S32(0X8013 << 16);
    // 0x80134038: addiu       $t2, $t2, 0x406C
    ctx->r10 = ADD32(ctx->r10, 0X406C);
    // 0x8013403C: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
    // 0x80134040: sw          $t2, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r10;
    // 0x80134044: sw          $s0, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r16;
    // 0x80134048: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x8013404C: lw          $a0, -0x5960($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X5960);
    // 0x80134050: jal         0x8013D900
    // 0x80134054: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    alSynAddPlayer(rdram, ctx);
        goto after_5;
    // 0x80134054: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_5:
    // 0x80134058: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8013405C: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x80134060: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x80134064: jr          $ra
    // 0x80134068: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x80134068: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void __CSPVoiceHandler(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013406C: addiu       $sp, $sp, -0x80
    ctx->r29 = ADD32(ctx->r29, -0X80);
    // 0x80134070: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80134074: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80134078: or          $s2, $a0, $zero
    ctx->r18 = ctx->r4 | 0;
    // 0x8013407C: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x80134080: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80134084: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80134088: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x8013408C: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80134090: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80134094: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80134098: jal         0x80135518
    // 0x8013409C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    func_80135518(rdram, ctx);
        goto after_0;
    // 0x8013409C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    after_0:
    // 0x801340A0: addiu       $s7, $s2, 0x38
    ctx->r23 = ADD32(ctx->r18, 0X38);
    // 0x801340A4: addiu       $s5, $s2, 0x48
    ctx->r21 = ADD32(ctx->r18, 0X48);
    // 0x801340A8: addiu       $fp, $zero, 0x1
    ctx->r30 = ADD32(0, 0X1);
    // 0x801340AC: addiu       $s6, $sp, 0x6C
    ctx->r22 = ADD32(ctx->r29, 0X6C);
L_801340B0:
    // 0x801340B0: jal         0x801352E8
    // 0x801340B4: nop

    func_801352E8(rdram, ctx);
        goto after_1;
    // 0x801340B4: nop

    after_1:
    // 0x801340B8: lhu         $t6, 0x38($s2)
    ctx->r14 = MEM_HU(ctx->r18, 0X38);
    // 0x801340BC: sltiu       $at, $t6, 0x18
    ctx->r1 = ctx->r14 < 0X18 ? 1 : 0;
    // 0x801340C0: beq         $at, $zero, L_80134568
    if (ctx->r1 == 0) {
        // 0x801340C4: sll         $t6, $t6, 2
        ctx->r14 = S32(ctx->r14 << 2);
            goto L_80134568;
    }
    // 0x801340C4: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x801340C8: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x801340CC: addu        $at, $at, $t6
    gpr jr_addend_801340D4 = ctx->r14;
    ctx->r1 = ADD32(ctx->r1, ctx->r14);
    // 0x801340D0: lw          $t6, -0x51F0($at)
    ctx->r14 = ADD32(ctx->r1, -0X51F0);
    // 0x801340D4: jr          $t6
    // 0x801340D8: nop

    switch (jr_addend_801340D4 >> 2) {
        case 0: goto L_801340DC; break;
        case 1: goto L_80134568; break;
        case 2: goto L_80134350; break;
        case 3: goto L_80134568; break;
        case 4: goto L_80134568; break;
        case 5: goto L_8013410C; break;
        case 6: goto L_80134158; break;
        case 7: goto L_80134364; break;
        case 8: goto L_80134568; break;
        case 9: goto L_801340EC; break;
        case 10: goto L_80134378; break;
        case 11: goto L_80134568; break;
        case 12: goto L_80134508; break;
        case 13: goto L_80134524; break;
        case 14: goto L_80134558; break;
        case 15: goto L_801343DC; break;
        case 16: goto L_801343FC; break;
        case 17: goto L_8013446C; break;
        case 18: goto L_80134568; break;
        case 19: goto L_80134568; break;
        case 20: goto L_80134568; break;
        case 21: goto L_80134350; break;
        case 22: goto L_801341BC; break;
        case 23: goto L_801342C8; break;
        default: switch_error(__func__, 0x801340D4, 0x8015AE10);
    }
    // 0x801340D8: nop

L_801340DC:
    // 0x801340DC: jal         0x80134628
    // 0x801340E0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    __CSPHandleNextSeqEvent(rdram, ctx);
        goto after_2;
    // 0x801340E0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_2:
    // 0x801340E4: b           L_8013456C
    // 0x801340E8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x801340E8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801340EC:
    // 0x801340EC: addiu       $t7, $zero, 0x9
    ctx->r15 = ADD32(0, 0X9);
    // 0x801340F0: sh          $t7, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r15;
    // 0x801340F4: lw          $a2, 0x5C($s2)
    ctx->r6 = MEM_W(ctx->r18, 0X5C);
    // 0x801340F8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x801340FC: jal         0x8013D6DC
    // 0x80134100: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    alEvtqPostEvent(rdram, ctx);
        goto after_3;
    // 0x80134100: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    after_3:
    // 0x80134104: b           L_8013456C
    // 0x80134108: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134108: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_8013410C:
    // 0x8013410C: lw          $s0, 0x3C($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X3C);
    // 0x80134110: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x80134114: jal         0x8013D950
    // 0x80134118: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    alSynStopVoice(rdram, ctx);
        goto after_4;
    // 0x80134118: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_4:
    // 0x8013411C: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x80134120: jal         0x8013D9D0
    // 0x80134124: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    alSynFreeVoice(rdram, ctx);
        goto after_5;
    // 0x80134124: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_5:
    // 0x80134128: lw          $s1, 0x10($s0)
    ctx->r17 = MEM_W(ctx->r16, 0X10);
    // 0x8013412C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80134130: lbu         $t8, 0x37($s1)
    ctx->r24 = MEM_BU(ctx->r17, 0X37);
    // 0x80134134: beql        $t8, $zero, L_80134148
    if (ctx->r24 == 0) {
        // 0x80134138: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_80134148;
    }
    goto skip_0;
    // 0x80134138: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    skip_0:
    // 0x8013413C: jal         0x8013D2C0
    // 0x80134140: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    __seqpStopOsc(rdram, ctx);
        goto after_6;
    // 0x80134140: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_6:
    // 0x80134144: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
L_80134148:
    // 0x80134148: jal         0x8013C090
    // 0x8013414C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    __unmapVoice(rdram, ctx);
        goto after_7;
    // 0x8013414C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_7:
    // 0x80134150: b           L_8013456C
    // 0x80134154: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134154: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134158:
    // 0x80134158: lw          $s0, 0x3C($s2)
    ctx->r16 = MEM_W(ctx->r18, 0X3C);
    // 0x8013415C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80134160: lw          $s1, 0x10($s0)
    ctx->r17 = MEM_W(ctx->r16, 0X10);
    // 0x80134164: lbu         $t9, 0x34($s1)
    ctx->r25 = MEM_BU(ctx->r17, 0X34);
    // 0x80134168: bnel        $t9, $zero, L_80134178
    if (ctx->r25 != 0) {
        // 0x8013416C: lw          $s3, 0x40($s2)
        ctx->r19 = MEM_W(ctx->r18, 0X40);
            goto L_80134178;
    }
    goto skip_1;
    // 0x8013416C: lw          $s3, 0x40($s2)
    ctx->r19 = MEM_W(ctx->r18, 0X40);
    skip_1:
    // 0x80134170: sb          $t0, 0x34($s1)
    MEM_B(0X34, ctx->r17) = ctx->r8;
    // 0x80134174: lw          $s3, 0x40($s2)
    ctx->r19 = MEM_W(ctx->r18, 0X40);
L_80134178:
    // 0x80134178: lw          $t1, 0x1C($s2)
    ctx->r9 = MEM_W(ctx->r18, 0X1C);
    // 0x8013417C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80134180: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x80134184: addu        $t2, $t1, $s3
    ctx->r10 = ADD32(ctx->r9, ctx->r19);
    // 0x80134188: sw          $t2, 0x24($s1)
    MEM_W(0X24, ctx->r17) = ctx->r10;
    // 0x8013418C: lbu         $t3, 0x44($s2)
    ctx->r11 = MEM_BU(ctx->r18, 0X44);
    // 0x80134190: jal         0x8013BE34
    // 0x80134194: sb          $t3, 0x30($s1)
    MEM_B(0X30, ctx->r17) = ctx->r11;
    __vsVol(rdram, ctx);
        goto after_8;
    // 0x80134194: sb          $t3, 0x30($s1)
    MEM_B(0X30, ctx->r17) = ctx->r11;
    after_8:
    // 0x80134198: sll         $a2, $v0, 16
    ctx->r6 = S32(ctx->r2 << 16);
    // 0x8013419C: sra         $t4, $a2, 16
    ctx->r12 = S32(SIGNED(ctx->r6) >> 16);
    // 0x801341A0: or          $a2, $t4, $zero
    ctx->r6 = ctx->r12 | 0;
    // 0x801341A4: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x801341A8: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x801341AC: jal         0x8013DA80
    // 0x801341B0: or          $a3, $s3, $zero
    ctx->r7 = ctx->r19 | 0;
    alSynSetVol(rdram, ctx);
        goto after_9;
    // 0x801341B0: or          $a3, $s3, $zero
    ctx->r7 = ctx->r19 | 0;
    after_9:
    // 0x801341B4: b           L_8013456C
    // 0x801341B8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x801341B8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801341BC:
    // 0x801341BC: lw          $t9, 0x74($s2)
    ctx->r25 = MEM_W(ctx->r18, 0X74);
    // 0x801341C0: lw          $s4, 0x40($s2)
    ctx->r20 = MEM_W(ctx->r18, 0X40);
    // 0x801341C4: lw          $s1, 0x3C($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X3C);
    // 0x801341C8: addiu       $a1, $sp, 0x58
    ctx->r5 = ADD32(ctx->r29, 0X58);
    // 0x801341CC: jalr        $t9
    // 0x801341D0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_10;
    // 0x801341D0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_10:
    // 0x801341D4: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x801341D8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x801341DC: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x801341E0: lwc1        $f4, 0x58($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X58);
    // 0x801341E4: or          $s3, $v0, $zero
    ctx->r19 = ctx->r2 | 0;
    // 0x801341E8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x801341EC: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x801341F0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x801341F4: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x801341F8: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x801341FC: nop

    // 0x80134200: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80134204: beql        $t6, $zero, L_80134254
    if (ctx->r14 == 0) {
        // 0x80134208: mfc1        $t6, $f6
        ctx->r14 = (int32_t)ctx->f6.u32l;
            goto L_80134254;
    }
    goto skip_2;
    // 0x80134208: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    skip_2:
    // 0x8013420C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80134210: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80134214: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x80134218: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x8013421C: nop

    // 0x80134220: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x80134224: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80134228: nop

    // 0x8013422C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80134230: bne         $t6, $zero, L_80134248
    if (ctx->r14 != 0) {
        // 0x80134234: nop
    
            goto L_80134248;
    }
    // 0x80134234: nop

    // 0x80134238: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x8013423C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80134240: b           L_80134260
    // 0x80134244: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_80134260;
    // 0x80134244: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_80134248:
    // 0x80134248: b           L_80134260
    // 0x8013424C: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_80134260;
    // 0x8013424C: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x80134250: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
L_80134254:
    // 0x80134254: nop

    // 0x80134258: bltz        $t6, L_80134248
    if (SIGNED(ctx->r14) < 0) {
        // 0x8013425C: nop
    
            goto L_80134248;
    }
    // 0x8013425C: nop

L_80134260:
    // 0x80134260: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x80134264: jal         0x8013BE34
    // 0x80134268: sb          $t6, 0x36($s1)
    MEM_B(0X36, ctx->r17) = ctx->r14;
    __vsVol(rdram, ctx);
        goto after_11;
    // 0x80134268: sb          $t6, 0x36($s1)
    MEM_B(0X36, ctx->r17) = ctx->r14;
    after_11:
    // 0x8013426C: sll         $s0, $v0, 16
    ctx->r16 = S32(ctx->r2 << 16);
    // 0x80134270: sra         $t7, $s0, 16
    ctx->r15 = S32(SIGNED(ctx->r16) >> 16);
    // 0x80134274: or          $s0, $t7, $zero
    ctx->r16 = ctx->r15 | 0;
    // 0x80134278: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8013427C: jal         0x8013BE10
    // 0x80134280: lw          $a1, 0x1C($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X1C);
    __vsDelta(rdram, ctx);
        goto after_12;
    // 0x80134280: lw          $a1, 0x1C($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X1C);
    after_12:
    // 0x80134284: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80134288: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8013428C: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80134290: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x80134294: addiu       $a1, $s1, 0x4
    ctx->r5 = ADD32(ctx->r17, 0X4);
    // 0x80134298: jal         0x8013DA80
    // 0x8013429C: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    alSynSetVol(rdram, ctx);
        goto after_13;
    // 0x8013429C: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    after_13:
    // 0x801342A0: addiu       $t0, $zero, 0x16
    ctx->r8 = ADD32(0, 0X16);
    // 0x801342A4: sh          $t0, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r8;
    // 0x801342A8: sw          $s1, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r17;
    // 0x801342AC: sw          $s4, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r20;
    // 0x801342B0: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x801342B4: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    // 0x801342B8: jal         0x8013D6DC
    // 0x801342BC: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    alEvtqPostEvent(rdram, ctx);
        goto after_14;
    // 0x801342BC: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_14:
    // 0x801342C0: b           L_8013456C
    // 0x801342C4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x801342C4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801342C8:
    // 0x801342C8: lw          $t9, 0x74($s2)
    ctx->r25 = MEM_W(ctx->r18, 0X74);
    // 0x801342CC: lw          $s4, 0x40($s2)
    ctx->r20 = MEM_W(ctx->r18, 0X40);
    // 0x801342D0: lw          $s1, 0x3C($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X3C);
    // 0x801342D4: lbu         $s0, 0x44($s2)
    ctx->r16 = MEM_BU(ctx->r18, 0X44);
    // 0x801342D8: addiu       $a1, $sp, 0x58
    ctx->r5 = ADD32(ctx->r29, 0X58);
    // 0x801342DC: jalr        $t9
    // 0x801342E0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_15;
    // 0x801342E0: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    after_15:
    // 0x801342E4: lwc1        $f8, 0x58($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X58);
    // 0x801342E8: lwc1        $f16, 0x28($s1)
    ctx->f16.u32l = MEM_W(ctx->r17, 0X28);
    // 0x801342EC: sll         $t2, $s0, 4
    ctx->r10 = S32(ctx->r16 << 4);
    // 0x801342F0: swc1        $f8, 0x2C($s1)
    MEM_W(0X2C, ctx->r17) = ctx->f8.u32l;
    // 0x801342F4: lwc1        $f18, 0x2C($s1)
    ctx->f18.u32l = MEM_W(ctx->r17, 0X2C);
    // 0x801342F8: lw          $t1, 0x60($s2)
    ctx->r9 = MEM_W(ctx->r18, 0X60);
    // 0x801342FC: or          $s3, $v0, $zero
    ctx->r19 = ctx->r2 | 0;
    // 0x80134300: mul.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = MUL_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80134304: addu        $t3, $t1, $t2
    ctx->r11 = ADD32(ctx->r9, ctx->r10);
    // 0x80134308: lwc1        $f10, 0xC($t3)
    ctx->f10.u32l = MEM_W(ctx->r11, 0XC);
    // 0x8013430C: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x80134310: addiu       $a1, $s1, 0x4
    ctx->r5 = ADD32(ctx->r17, 0X4);
    // 0x80134314: mul.s       $f6, $f10, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f4.fl);
    // 0x80134318: mfc1        $a2, $f6
    ctx->r6 = (int32_t)ctx->f6.u32l;
    // 0x8013431C: jal         0x8013DB20
    // 0x80134320: nop

    alSynSetPitch(rdram, ctx);
        goto after_16;
    // 0x80134320: nop

    after_16:
    // 0x80134324: addiu       $t4, $zero, 0x17
    ctx->r12 = ADD32(0, 0X17);
    // 0x80134328: sh          $t4, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r12;
    // 0x8013432C: sw          $s1, 0x70($sp)
    MEM_W(0X70, ctx->r29) = ctx->r17;
    // 0x80134330: sw          $s4, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->r20;
    // 0x80134334: sb          $s0, 0x78($sp)
    MEM_B(0X78, ctx->r29) = ctx->r16;
    // 0x80134338: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x8013433C: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    // 0x80134340: jal         0x8013D6DC
    // 0x80134344: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    alEvtqPostEvent(rdram, ctx);
        goto after_17;
    // 0x80134344: or          $a2, $s3, $zero
    ctx->r6 = ctx->r19 | 0;
    after_17:
    // 0x80134348: b           L_8013456C
    // 0x8013434C: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x8013434C: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134350:
    // 0x80134350: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80134354: jal         0x801346F0
    // 0x80134358: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    __CSPHandleMIDIMsg(rdram, ctx);
        goto after_18;
    // 0x80134358: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    after_18:
    // 0x8013435C: b           L_8013456C
    // 0x80134360: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134360: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134364:
    // 0x80134364: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80134368: jal         0x80134FE8
    // 0x8013436C: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    __CSPHandleMetaMsg(rdram, ctx);
        goto after_19;
    // 0x8013436C: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    after_19:
    // 0x80134370: b           L_8013456C
    // 0x80134374: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134374: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134378:
    // 0x80134378: lw          $s1, 0x64($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X64);
    // 0x8013437C: lh          $t5, 0x3C($s2)
    ctx->r13 = MEM_H(ctx->r18, 0X3C);
    // 0x80134380: beq         $s1, $zero, L_80134568
    if (ctx->r17 == 0) {
        // 0x80134384: sh          $t5, 0x32($s2)
        MEM_H(0X32, ctx->r18) = ctx->r13;
            goto L_80134568;
    }
    // 0x80134384: sh          $t5, 0x32($s2)
    MEM_H(0X32, ctx->r18) = ctx->r13;
    // 0x80134388: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_8013438C:
    // 0x8013438C: jal         0x8013BE34
    // 0x80134390: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    __vsVol(rdram, ctx);
        goto after_20;
    // 0x80134390: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    after_20:
    // 0x80134394: sll         $s0, $v0, 16
    ctx->r16 = S32(ctx->r2 << 16);
    // 0x80134398: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x8013439C: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x801343A0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x801343A4: jal         0x8013BE10
    // 0x801343A8: lw          $a1, 0x1C($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X1C);
    __vsDelta(rdram, ctx);
        goto after_21;
    // 0x801343A8: lw          $a1, 0x1C($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X1C);
    after_21:
    // 0x801343AC: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x801343B0: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x801343B4: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x801343B8: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x801343BC: addiu       $a1, $s1, 0x4
    ctx->r5 = ADD32(ctx->r17, 0X4);
    // 0x801343C0: jal         0x8013DA80
    // 0x801343C4: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    alSynSetVol(rdram, ctx);
        goto after_22;
    // 0x801343C4: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    after_22:
    // 0x801343C8: lw          $s1, 0x0($s1)
    ctx->r17 = MEM_W(ctx->r17, 0X0);
    // 0x801343CC: bnel        $s1, $zero, L_8013438C
    if (ctx->r17 != 0) {
        // 0x801343D0: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_8013438C;
    }
    goto skip_3;
    // 0x801343D0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_3:
    // 0x801343D4: b           L_8013456C
    // 0x801343D8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x801343D8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801343DC:
    // 0x801343DC: lw          $t8, 0x2C($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X2C);
    // 0x801343E0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x801343E4: beql        $fp, $t8, L_8013456C
    if (ctx->r30 == ctx->r24) {
        // 0x801343E8: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8013456C;
    }
    goto skip_4;
    // 0x801343E8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_4:
    // 0x801343EC: jal         0x801345B8
    // 0x801343F0: sw          $fp, 0x2C($s2)
    MEM_W(0X2C, ctx->r18) = ctx->r30;
    __CSPPostNextSeqEvent(rdram, ctx);
        goto after_23;
    // 0x801343F0: sw          $fp, 0x2C($s2)
    MEM_W(0X2C, ctx->r18) = ctx->r30;
    after_23:
    // 0x801343F4: b           L_8013456C
    // 0x801343F8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x801343F8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801343FC:
    // 0x801343FC: lw          $t0, 0x2C($s2)
    ctx->r8 = MEM_W(ctx->r18, 0X2C);
    // 0x80134400: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80134404: bnel        $t0, $at, L_8013456C
    if (ctx->r8 != ctx->r1) {
        // 0x80134408: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8013456C;
    }
    goto skip_5;
    // 0x80134408: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_5:
    // 0x8013440C: lw          $s1, 0x64($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X64);
    // 0x80134410: beq         $s1, $zero, L_80134464
    if (ctx->r17 == 0) {
        // 0x80134414: nop
    
            goto L_80134464;
    }
    // 0x80134414: nop

    // 0x80134418: addiu       $s0, $s1, 0x4
    ctx->r16 = ADD32(ctx->r17, 0X4);
L_8013441C:
    // 0x8013441C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80134420: jal         0x8013D950
    // 0x80134424: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    alSynStopVoice(rdram, ctx);
        goto after_24;
    // 0x80134424: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    after_24:
    // 0x80134428: lw          $a0, 0x14($s2)
    ctx->r4 = MEM_W(ctx->r18, 0X14);
    // 0x8013442C: jal         0x8013D9D0
    // 0x80134430: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    alSynFreeVoice(rdram, ctx);
        goto after_25;
    // 0x80134430: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_25:
    // 0x80134434: lbu         $t9, 0x37($s1)
    ctx->r25 = MEM_BU(ctx->r17, 0X37);
    // 0x80134438: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x8013443C: beql        $t9, $zero, L_80134450
    if (ctx->r25 == 0) {
        // 0x80134440: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_80134450;
    }
    goto skip_6;
    // 0x80134440: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    skip_6:
    // 0x80134444: jal         0x8013D2C0
    // 0x80134448: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    __seqpStopOsc(rdram, ctx);
        goto after_26;
    // 0x80134448: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_26:
    // 0x8013444C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
L_80134450:
    // 0x80134450: jal         0x8013C090
    // 0x80134454: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    __unmapVoice(rdram, ctx);
        goto after_27;
    // 0x80134454: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_27:
    // 0x80134458: lw          $s1, 0x64($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X64);
    // 0x8013445C: bnel        $s1, $zero, L_8013441C
    if (ctx->r17 != 0) {
        // 0x80134460: addiu       $s0, $s1, 0x4
        ctx->r16 = ADD32(ctx->r17, 0X4);
            goto L_8013441C;
    }
    goto skip_7;
    // 0x80134460: addiu       $s0, $s1, 0x4
    ctx->r16 = ADD32(ctx->r17, 0X4);
    skip_7:
L_80134464:
    // 0x80134464: b           L_80134568
    // 0x80134468: sw          $zero, 0x2C($s2)
    MEM_W(0X2C, ctx->r18) = 0;
        goto L_80134568;
    // 0x80134468: sw          $zero, 0x2C($s2)
    MEM_W(0X2C, ctx->r18) = 0;
L_8013446C:
    // 0x8013446C: lw          $t1, 0x2C($s2)
    ctx->r9 = MEM_W(ctx->r18, 0X2C);
    // 0x80134470: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80134474: bnel        $fp, $t1, L_8013456C
    if (ctx->r30 != ctx->r9) {
        // 0x80134478: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8013456C;
    }
    goto skip_8;
    // 0x80134478: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_8:
    // 0x8013447C: jal         0x8013D5C0
    // 0x80134480: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    alEvtqFlushType(rdram, ctx);
        goto after_28;
    // 0x80134480: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_28:
    // 0x80134484: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80134488: jal         0x8013D5C0
    // 0x8013448C: addiu       $a1, $zero, 0x15
    ctx->r5 = ADD32(0, 0X15);
    alEvtqFlushType(rdram, ctx);
        goto after_29;
    // 0x8013448C: addiu       $a1, $zero, 0x15
    ctx->r5 = ADD32(0, 0X15);
    after_29:
    // 0x80134490: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80134494: jal         0x8013D5C0
    // 0x80134498: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    alEvtqFlushType(rdram, ctx);
        goto after_30;
    // 0x80134498: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    after_30:
    // 0x8013449C: lw          $s1, 0x64($s2)
    ctx->r17 = MEM_W(ctx->r18, 0X64);
    // 0x801344A0: beql        $s1, $zero, L_801344E0
    if (ctx->r17 == 0) {
        // 0x801344A4: addiu       $t2, $zero, 0x2
        ctx->r10 = ADD32(0, 0X2);
            goto L_801344E0;
    }
    goto skip_9;
    // 0x801344A4: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    skip_9:
    // 0x801344A8: addiu       $s0, $s1, 0x4
    ctx->r16 = ADD32(ctx->r17, 0X4);
L_801344AC:
    // 0x801344AC: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x801344B0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x801344B4: jal         0x8013BFE8
    // 0x801344B8: ori         $a2, $zero, 0xC350
    ctx->r6 = 0 | 0XC350;
    __voiceNeedsNoteKill(rdram, ctx);
        goto after_31;
    // 0x801344B8: ori         $a2, $zero, 0xC350
    ctx->r6 = 0 | 0XC350;
    after_31:
    // 0x801344BC: beq         $v0, $zero, L_801344D0
    if (ctx->r2 == 0) {
        // 0x801344C0: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_801344D0;
    }
    // 0x801344C0: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x801344C4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x801344C8: jal         0x8013BEBC
    // 0x801344CC: ori         $a2, $zero, 0xC350
    ctx->r6 = 0 | 0XC350;
    __seqpReleaseVoice(rdram, ctx);
        goto after_32;
    // 0x801344CC: ori         $a2, $zero, 0xC350
    ctx->r6 = 0 | 0XC350;
    after_32:
L_801344D0:
    // 0x801344D0: lw          $s1, 0x0($s1)
    ctx->r17 = MEM_W(ctx->r17, 0X0);
    // 0x801344D4: bnel        $s1, $zero, L_801344AC
    if (ctx->r17 != 0) {
        // 0x801344D8: addiu       $s0, $s1, 0x4
        ctx->r16 = ADD32(ctx->r17, 0X4);
            goto L_801344AC;
    }
    goto skip_10;
    // 0x801344D8: addiu       $s0, $s1, 0x4
    ctx->r16 = ADD32(ctx->r17, 0X4);
    skip_10:
    // 0x801344DC: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
L_801344E0:
    // 0x801344E0: sw          $t2, 0x2C($s2)
    MEM_W(0X2C, ctx->r18) = ctx->r10;
    // 0x801344E4: addiu       $t3, $zero, 0x10
    ctx->r11 = ADD32(0, 0X10);
    // 0x801344E8: lui         $a2, 0x7FFF
    ctx->r6 = S32(0X7FFF << 16);
    // 0x801344EC: sh          $t3, 0x6C($sp)
    MEM_H(0X6C, ctx->r29) = ctx->r11;
    // 0x801344F0: ori         $a2, $a2, 0xFFFF
    ctx->r6 = ctx->r6 | 0XFFFF;
    // 0x801344F4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x801344F8: jal         0x8013D6DC
    // 0x801344FC: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    alEvtqPostEvent(rdram, ctx);
        goto after_33;
    // 0x801344FC: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    after_33:
    // 0x80134500: b           L_8013456C
    // 0x80134504: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134504: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134508:
    // 0x80134508: lbu         $s0, 0x3C($s2)
    ctx->r16 = MEM_BU(ctx->r18, 0X3C);
    // 0x8013450C: lw          $t5, 0x60($s2)
    ctx->r13 = MEM_W(ctx->r18, 0X60);
    // 0x80134510: lbu         $t4, 0x3D($s2)
    ctx->r12 = MEM_BU(ctx->r18, 0X3D);
    // 0x80134514: sll         $t6, $s0, 4
    ctx->r14 = S32(ctx->r16 << 4);
    // 0x80134518: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x8013451C: b           L_80134568
    // 0x80134520: sb          $t4, 0x8($t7)
    MEM_B(0X8, ctx->r15) = ctx->r12;
        goto L_80134568;
    // 0x80134520: sb          $t4, 0x8($t7)
    MEM_B(0X8, ctx->r15) = ctx->r12;
L_80134524:
    // 0x80134524: lw          $t8, 0x3C($s2)
    ctx->r24 = MEM_W(ctx->r18, 0X3C);
    // 0x80134528: lui         $a1, 0x48F4
    ctx->r5 = S32(0X48F4 << 16);
    // 0x8013452C: ori         $a1, $a1, 0x2400
    ctx->r5 = ctx->r5 | 0X2400;
    // 0x80134530: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80134534: jal         0x80135218
    // 0x80134538: sw          $t8, 0x18($s2)
    MEM_W(0X18, ctx->r18) = ctx->r24;
    __setUsptFromTempo(rdram, ctx);
        goto after_34;
    // 0x80134538: sw          $t8, 0x18($s2)
    MEM_W(0X18, ctx->r18) = ctx->r24;
    after_34:
    // 0x8013453C: lw          $a1, 0x20($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X20);
    // 0x80134540: beql        $a1, $zero, L_8013456C
    if (ctx->r5 == 0) {
        // 0x80134544: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_8013456C;
    }
    goto skip_11;
    // 0x80134544: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    skip_11:
    // 0x80134548: jal         0x8013BD54
    // 0x8013454C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    __initFromBank(rdram, ctx);
        goto after_35;
    // 0x8013454C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_35:
    // 0x80134550: b           L_8013456C
    // 0x80134554: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_8013456C;
    // 0x80134554: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_80134558:
    // 0x80134558: lw          $a1, 0x3C($s2)
    ctx->r5 = MEM_W(ctx->r18, 0X3C);
    // 0x8013455C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80134560: jal         0x8013BD54
    // 0x80134564: sw          $a1, 0x20($s2)
    MEM_W(0X20, ctx->r18) = ctx->r5;
    __initFromBank(rdram, ctx);
        goto after_36;
    // 0x80134564: sw          $a1, 0x20($s2)
    MEM_W(0X20, ctx->r18) = ctx->r5;
    after_36:
L_80134568:
    // 0x80134568: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_8013456C:
    // 0x8013456C: jal         0x8013D800
    // 0x80134570: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    alEvtqNextEvent(rdram, ctx);
        goto after_37;
    // 0x80134570: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    after_37:
    // 0x80134574: beq         $v0, $zero, L_801340B0
    if (ctx->r2 == 0) {
        // 0x80134578: sw          $v0, 0x28($s2)
        MEM_W(0X28, ctx->r18) = ctx->r2;
            goto L_801340B0;
    }
    // 0x80134578: sw          $v0, 0x28($s2)
    MEM_W(0X28, ctx->r18) = ctx->r2;
    // 0x8013457C: lw          $t0, 0x1C($s2)
    ctx->r8 = MEM_W(ctx->r18, 0X1C);
    // 0x80134580: addu        $t9, $t0, $v0
    ctx->r25 = ADD32(ctx->r8, ctx->r2);
    // 0x80134584: sw          $t9, 0x1C($s2)
    MEM_W(0X1C, ctx->r18) = ctx->r25;
    // 0x80134588: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x8013458C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80134590: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80134594: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80134598: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8013459C: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x801345A0: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x801345A4: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x801345A8: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x801345AC: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801345B0: jr          $ra
    // 0x801345B4: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
    return;
    // 0x801345B4: addiu       $sp, $sp, 0x80
    ctx->r29 = ADD32(ctx->r29, 0X80);
;}
RECOMP_FUNC void __CSPPostNextSeqEvent(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801345B8: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x801345BC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801345C0: lw          $t6, 0x2C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X2C);
    // 0x801345C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801345C8: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
    // 0x801345CC: bnel        $t6, $at, L_8013461C
    if (ctx->r14 != ctx->r1) {
        // 0x801345D0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8013461C;
    }
    goto skip_0;
    // 0x801345D0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x801345D4: lw          $a0, 0x18($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X18);
    // 0x801345D8: addiu       $a1, $sp, 0x1C
    ctx->r5 = ADD32(ctx->r29, 0X1C);
    // 0x801345DC: beql        $a0, $zero, L_8013461C
    if (ctx->r4 == 0) {
        // 0x801345E0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8013461C;
    }
    goto skip_1;
    // 0x801345E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x801345E4: jal         0x8013B6BC
    // 0x801345E8: sw          $a3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r7;
    __alCSeqNextDelta(rdram, ctx);
        goto after_0;
    // 0x801345E8: sw          $a3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r7;
    after_0:
    // 0x801345EC: beq         $v0, $zero, L_80134618
    if (ctx->r2 == 0) {
        // 0x801345F0: lw          $a3, 0x30($sp)
        ctx->r7 = MEM_W(ctx->r29, 0X30);
            goto L_80134618;
    }
    // 0x801345F0: lw          $a3, 0x30($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X30);
    // 0x801345F4: sh          $zero, 0x20($sp)
    MEM_H(0X20, ctx->r29) = 0;
    // 0x801345F8: lw          $t7, 0x24($a3)
    ctx->r15 = MEM_W(ctx->r7, 0X24);
    // 0x801345FC: lw          $t8, 0x1C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X1C);
    // 0x80134600: addiu       $a0, $a3, 0x48
    ctx->r4 = ADD32(ctx->r7, 0X48);
    // 0x80134604: addiu       $a1, $sp, 0x20
    ctx->r5 = ADD32(ctx->r29, 0X20);
    // 0x80134608: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8013460C: mflo        $a2
    ctx->r6 = lo;
    // 0x80134610: jal         0x8013D6DC
    // 0x80134614: nop

    alEvtqPostEvent(rdram, ctx);
        goto after_1;
    // 0x80134614: nop

    after_1:
L_80134618:
    // 0x80134618: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8013461C:
    // 0x8013461C: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80134620: jr          $ra
    // 0x80134624: nop

    return;
    // 0x80134624: nop

;}
RECOMP_FUNC void __CSPHandleNextSeqEvent(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80134628: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8013462C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80134630: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80134634: lw          $a2, 0x18($a0)
    ctx->r6 = MEM_W(ctx->r4, 0X18);
    // 0x80134638: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8013463C: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    // 0x80134640: beql        $a2, $zero, L_801346E0
    if (ctx->r6 == 0) {
        // 0x80134644: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_801346E0;
    }
    goto skip_0;
    // 0x80134644: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80134648: jal         0x8013AFD4
    // 0x8013464C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    alCSeqNextEvent(rdram, ctx);
        goto after_0;
    // 0x8013464C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
    after_0:
    // 0x80134650: lh          $t6, 0x28($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X28);
    // 0x80134654: addiu       $a1, $sp, 0x28
    ctx->r5 = ADD32(ctx->r29, 0X28);
    // 0x80134658: addiu       $t7, $t6, -0x1
    ctx->r15 = ADD32(ctx->r14, -0X1);
    // 0x8013465C: sltiu       $at, $t7, 0x14
    ctx->r1 = ctx->r15 < 0X14 ? 1 : 0;
    // 0x80134660: beq         $at, $zero, L_801346DC
    if (ctx->r1 == 0) {
        // 0x80134664: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_801346DC;
    }
    // 0x80134664: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80134668: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x8013466C: addu        $at, $at, $t7
    gpr jr_addend_80134674 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80134670: lw          $t7, -0x5190($at)
    ctx->r15 = ADD32(ctx->r1, -0X5190);
    // 0x80134674: jr          $t7
    // 0x80134678: nop

    switch (jr_addend_80134674 >> 2) {
        case 0: goto L_8013467C; break;
        case 1: goto L_801346DC; break;
        case 2: goto L_80134694; break;
        case 3: goto L_801346AC; break;
        case 4: goto L_801346DC; break;
        case 5: goto L_801346DC; break;
        case 6: goto L_801346DC; break;
        case 7: goto L_801346DC; break;
        case 8: goto L_801346DC; break;
        case 9: goto L_801346DC; break;
        case 10: goto L_801346DC; break;
        case 11: goto L_801346DC; break;
        case 12: goto L_801346DC; break;
        case 13: goto L_801346DC; break;
        case 14: goto L_801346DC; break;
        case 15: goto L_801346DC; break;
        case 16: goto L_801346DC; break;
        case 17: goto L_801346D4; break;
        case 18: goto L_801346D4; break;
        case 19: goto L_801346D4; break;
        default: switch_error(__func__, 0x80134674, 0x8015AE70);
    }
    // 0x80134678: nop

L_8013467C:
    // 0x8013467C: jal         0x801346F0
    // 0x80134680: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __CSPHandleMIDIMsg(rdram, ctx);
        goto after_1;
    // 0x80134680: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x80134684: jal         0x801345B8
    // 0x80134688: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __CSPPostNextSeqEvent(rdram, ctx);
        goto after_2;
    // 0x80134688: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
    // 0x8013468C: b           L_801346E0
    // 0x80134690: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_801346E0;
    // 0x80134690: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80134694:
    // 0x80134694: jal         0x80134FE8
    // 0x80134698: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __CSPHandleMetaMsg(rdram, ctx);
        goto after_3;
    // 0x80134698: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_3:
    // 0x8013469C: jal         0x801345B8
    // 0x801346A0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __CSPPostNextSeqEvent(rdram, ctx);
        goto after_4;
    // 0x801346A0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_4:
    // 0x801346A4: b           L_801346E0
    // 0x801346A8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_801346E0;
    // 0x801346A8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801346AC:
    // 0x801346AC: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x801346B0: sw          $t8, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = ctx->r24;
    // 0x801346B4: addiu       $t9, $zero, 0x10
    ctx->r25 = ADD32(0, 0X10);
    // 0x801346B8: lui         $a2, 0x7FFF
    ctx->r6 = S32(0X7FFF << 16);
    // 0x801346BC: sh          $t9, 0x28($sp)
    MEM_H(0X28, ctx->r29) = ctx->r25;
    // 0x801346C0: ori         $a2, $a2, 0xFFFF
    ctx->r6 = ctx->r6 | 0XFFFF;
    // 0x801346C4: jal         0x8013D6DC
    // 0x801346C8: addiu       $a0, $s0, 0x48
    ctx->r4 = ADD32(ctx->r16, 0X48);
    alEvtqPostEvent(rdram, ctx);
        goto after_5;
    // 0x801346C8: addiu       $a0, $s0, 0x48
    ctx->r4 = ADD32(ctx->r16, 0X48);
    after_5:
    // 0x801346CC: b           L_801346E0
    // 0x801346D0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_801346E0;
    // 0x801346D0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801346D4:
    // 0x801346D4: jal         0x801345B8
    // 0x801346D8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __CSPPostNextSeqEvent(rdram, ctx);
        goto after_6;
    // 0x801346D8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_6:
L_801346DC:
    // 0x801346DC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801346E0:
    // 0x801346E0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801346E4: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x801346E8: jr          $ra
    // 0x801346EC: nop

    return;
    // 0x801346EC: nop

;}
RECOMP_FUNC void __CSPHandleMIDIMsg(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801346F0: addiu       $sp, $sp, -0xC8
    ctx->r29 = ADD32(ctx->r29, -0XC8);
    // 0x801346F4: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x801346F8: sw          $s2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r18;
    // 0x801346FC: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x80134700: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x80134704: lbu         $a3, 0x8($a1)
    ctx->r7 = MEM_BU(ctx->r5, 0X8);
    // 0x80134708: lbu         $t7, 0x9($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X9);
    // 0x8013470C: or          $s0, $a1, $zero
    ctx->r16 = ctx->r5 | 0;
    // 0x80134710: andi        $v1, $a3, 0xF0
    ctx->r3 = ctx->r7 & 0XF0;
    // 0x80134714: sb          $t7, 0xBA($sp)
    MEM_B(0XBA, ctx->r29) = ctx->r15;
    // 0x80134718: lbu         $t8, 0xA($a1)
    ctx->r24 = MEM_BU(ctx->r5, 0XA);
    // 0x8013471C: addiu       $t9, $v1, -0x80
    ctx->r25 = ADD32(ctx->r3, -0X80);
    // 0x80134720: sltiu       $at, $t9, 0x61
    ctx->r1 = ctx->r25 < 0X61 ? 1 : 0;
    // 0x80134724: andi        $t6, $a3, 0xF
    ctx->r14 = ctx->r7 & 0XF;
    // 0x80134728: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x8013472C: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80134730: beq         $at, $zero, L_80134FD0
    if (ctx->r1 == 0) {
        // 0x80134734: sb          $t8, 0xB9($sp)
        MEM_B(0XB9, ctx->r29) = ctx->r24;
            goto L_80134FD0;
    }
    // 0x80134734: sb          $t8, 0xB9($sp)
    MEM_B(0XB9, ctx->r29) = ctx->r24;
    // 0x80134738: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8013473C: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80134740: addu        $at, $at, $t9
    gpr jr_addend_80134748 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80134744: lw          $t9, -0x5140($at)
    ctx->r25 = ADD32(ctx->r1, -0X5140);
    // 0x80134748: jr          $t9
    // 0x8013474C: nop

    switch (jr_addend_80134748 >> 2) {
        case 0: goto L_80134BA4; break;
        case 1: goto L_80134FD0; break;
        case 2: goto L_80134FD0; break;
        case 3: goto L_80134FD0; break;
        case 4: goto L_80134FD0; break;
        case 5: goto L_80134FD0; break;
        case 6: goto L_80134FD0; break;
        case 7: goto L_80134FD0; break;
        case 8: goto L_80134FD0; break;
        case 9: goto L_80134FD0; break;
        case 10: goto L_80134FD0; break;
        case 11: goto L_80134FD0; break;
        case 12: goto L_80134FD0; break;
        case 13: goto L_80134FD0; break;
        case 14: goto L_80134FD0; break;
        case 15: goto L_80134FD0; break;
        case 16: goto L_80134750; break;
        case 17: goto L_80134FD0; break;
        case 18: goto L_80134FD0; break;
        case 19: goto L_80134FD0; break;
        case 20: goto L_80134FD0; break;
        case 21: goto L_80134FD0; break;
        case 22: goto L_80134FD0; break;
        case 23: goto L_80134FD0; break;
        case 24: goto L_80134FD0; break;
        case 25: goto L_80134FD0; break;
        case 26: goto L_80134FD0; break;
        case 27: goto L_80134FD0; break;
        case 28: goto L_80134FD0; break;
        case 29: goto L_80134FD0; break;
        case 30: goto L_80134FD0; break;
        case 31: goto L_80134FD0; break;
        case 32: goto L_80134BFC; break;
        case 33: goto L_80134FD0; break;
        case 34: goto L_80134FD0; break;
        case 35: goto L_80134FD0; break;
        case 36: goto L_80134FD0; break;
        case 37: goto L_80134FD0; break;
        case 38: goto L_80134FD0; break;
        case 39: goto L_80134FD0; break;
        case 40: goto L_80134FD0; break;
        case 41: goto L_80134FD0; break;
        case 42: goto L_80134FD0; break;
        case 43: goto L_80134FD0; break;
        case 44: goto L_80134FD0; break;
        case 45: goto L_80134FD0; break;
        case 46: goto L_80134FD0; break;
        case 47: goto L_80134FD0; break;
        case 48: goto L_80134CB8; break;
        case 49: goto L_80134FD0; break;
        case 50: goto L_80134FD0; break;
        case 51: goto L_80134FD0; break;
        case 52: goto L_80134FD0; break;
        case 53: goto L_80134FD0; break;
        case 54: goto L_80134FD0; break;
        case 55: goto L_80134FD0; break;
        case 56: goto L_80134FD0; break;
        case 57: goto L_80134FD0; break;
        case 58: goto L_80134FD0; break;
        case 59: goto L_80134FD0; break;
        case 60: goto L_80134FD0; break;
        case 61: goto L_80134FD0; break;
        case 62: goto L_80134FD0; break;
        case 63: goto L_80134FD0; break;
        case 64: goto L_80134EEC; break;
        case 65: goto L_80134FD0; break;
        case 66: goto L_80134FD0; break;
        case 67: goto L_80134FD0; break;
        case 68: goto L_80134FD0; break;
        case 69: goto L_80134FD0; break;
        case 70: goto L_80134FD0; break;
        case 71: goto L_80134FD0; break;
        case 72: goto L_80134FD0; break;
        case 73: goto L_80134FD0; break;
        case 74: goto L_80134FD0; break;
        case 75: goto L_80134FD0; break;
        case 76: goto L_80134FD0; break;
        case 77: goto L_80134FD0; break;
        case 78: goto L_80134FD0; break;
        case 79: goto L_80134FD0; break;
        case 80: goto L_80134C54; break;
        case 81: goto L_80134FD0; break;
        case 82: goto L_80134FD0; break;
        case 83: goto L_80134FD0; break;
        case 84: goto L_80134FD0; break;
        case 85: goto L_80134FD0; break;
        case 86: goto L_80134FD0; break;
        case 87: goto L_80134FD0; break;
        case 88: goto L_80134FD0; break;
        case 89: goto L_80134FD0; break;
        case 90: goto L_80134FD0; break;
        case 91: goto L_80134FD0; break;
        case 92: goto L_80134FD0; break;
        case 93: goto L_80134FD0; break;
        case 94: goto L_80134FD0; break;
        case 95: goto L_80134FD0; break;
        case 96: goto L_80134F20; break;
        default: switch_error(__func__, 0x80134748, 0x8015AEC0);
    }
    // 0x8013474C: nop

L_80134750:
    // 0x80134750: lbu         $t0, 0xB9($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134754: addiu       $at, $zero, 0xC
    ctx->r1 = ADD32(0, 0XC);
    // 0x80134758: beql        $t0, $zero, L_80134BA8
    if (ctx->r8 == 0) {
        // 0x8013475C: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80134BA8;
    }
    goto skip_0;
    // 0x8013475C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_0:
    // 0x80134760: bne         $a3, $at, L_80134774
    if (ctx->r7 != ctx->r1) {
        // 0x80134764: or          $s2, $a3, $zero
        ctx->r18 = ctx->r7 | 0;
            goto L_80134774;
    }
    // 0x80134764: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134768: lui         $t1, 0x8028
    ctx->r9 = S32(0X8028 << 16);
    // 0x8013476C: lb          $t1, 0x6458($t1)
    ctx->r9 = MEM_B(ctx->r9, 0X6458);
    // 0x80134770: bne         $t1, $zero, L_80134BA4
    if (ctx->r9 != 0) {
        // 0x80134774: lui         $t2, 0x8028
        ctx->r10 = S32(0X8028 << 16);
            goto L_80134BA4;
    }
L_80134774:
    // 0x80134774: lui         $t2, 0x8028
    ctx->r10 = S32(0X8028 << 16);
    // 0x80134778: lb          $t2, 0x6458($t2)
    ctx->r10 = MEM_B(ctx->r10, 0X6458);
    // 0x8013477C: slti        $at, $s2, 0x9
    ctx->r1 = SIGNED(ctx->r18) < 0X9 ? 1 : 0;
    // 0x80134780: bnel        $t2, $zero, L_8013479C
    if (ctx->r10 != 0) {
        // 0x80134784: lw          $t3, 0x2C($s1)
        ctx->r11 = MEM_W(ctx->r17, 0X2C);
            goto L_8013479C;
    }
    goto skip_1;
    // 0x80134784: lw          $t3, 0x2C($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X2C);
    skip_1:
    // 0x80134788: bne         $at, $zero, L_80134798
    if (ctx->r1 != 0) {
        // 0x8013478C: slti        $at, $s2, 0xC
        ctx->r1 = SIGNED(ctx->r18) < 0XC ? 1 : 0;
            goto L_80134798;
    }
    // 0x8013478C: slti        $at, $s2, 0xC
    ctx->r1 = SIGNED(ctx->r18) < 0XC ? 1 : 0;
    // 0x80134790: bnel        $at, $zero, L_80134BA8
    if (ctx->r1 != 0) {
        // 0x80134794: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80134BA8;
    }
    goto skip_2;
    // 0x80134794: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_2:
L_80134798:
    // 0x80134798: lw          $t3, 0x2C($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X2C);
L_8013479C:
    // 0x8013479C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801347A0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x801347A4: bne         $t3, $at, L_80134FD0
    if (ctx->r11 != ctx->r1) {
        // 0x801347A8: lbu         $a1, 0xBA($sp)
        ctx->r5 = MEM_BU(ctx->r29, 0XBA);
            goto L_80134FD0;
    }
    // 0x801347A8: lbu         $a1, 0xBA($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0XBA);
    // 0x801347AC: lbu         $a2, 0xB9($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0XB9);
    // 0x801347B0: sb          $a3, 0xBB($sp)
    MEM_B(0XBB, ctx->r29) = ctx->r7;
    // 0x801347B4: jal         0x8013C380
    // 0x801347B8: sw          $s0, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r16;
    __lookupSoundQuick(rdram, ctx);
        goto after_0;
    // 0x801347B8: sw          $s0, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r16;
    after_0:
    // 0x801347BC: beq         $v0, $zero, L_80134FD0
    if (ctx->r2 == 0) {
        // 0x801347C0: sw          $v0, 0x80($sp)
        MEM_W(0X80, ctx->r29) = ctx->r2;
            goto L_80134FD0;
    }
    // 0x801347C0: sw          $v0, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r2;
    // 0x801347C4: lbu         $a3, 0xBB($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0XBB);
    // 0x801347C8: lw          $t4, 0x60($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X60);
    // 0x801347CC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x801347D0: sll         $v0, $a3, 4
    ctx->r2 = S32(ctx->r7 << 4);
    // 0x801347D4: addu        $t5, $t4, $v0
    ctx->r13 = ADD32(ctx->r12, ctx->r2);
    // 0x801347D8: lbu         $t6, 0x8($t5)
    ctx->r14 = MEM_BU(ctx->r13, 0X8);
    // 0x801347DC: sh          $zero, 0x86($sp)
    MEM_H(0X86, ctx->r29) = 0;
    // 0x801347E0: sb          $zero, 0x88($sp)
    MEM_B(0X88, ctx->r29) = 0;
    // 0x801347E4: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    // 0x801347E8: lbu         $a1, 0xBA($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0XBA);
    // 0x801347EC: lbu         $a2, 0xB9($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0XB9);
    // 0x801347F0: jal         0x8013C310
    // 0x801347F4: sh          $t6, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r14;
    __mapVoice(rdram, ctx);
        goto after_1;
    // 0x801347F4: sh          $t6, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r14;
    after_1:
    // 0x801347F8: beq         $v0, $zero, L_80134FD0
    if (ctx->r2 == 0) {
        // 0x801347FC: or          $s0, $v0, $zero
        ctx->r16 = ctx->r2 | 0;
            goto L_80134FD0;
    }
    // 0x801347FC: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x80134800: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80134804: bne         $s2, $at, L_80134818
    if (ctx->r18 != ctx->r1) {
        // 0x80134808: addiu       $a1, $s0, 0x4
        ctx->r5 = ADD32(ctx->r16, 0X4);
            goto L_80134818;
    }
    // 0x80134808: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x8013480C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80134810: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x80134814: sb          $t7, 0x52B0($at)
    MEM_B(0X52B0, ctx->r1) = ctx->r15;
L_80134818:
    // 0x80134818: slti        $at, $s2, 0x3
    ctx->r1 = SIGNED(ctx->r18) < 0X3 ? 1 : 0;
    // 0x8013481C: bne         $at, $zero, L_80134830
    if (ctx->r1 != 0) {
        // 0x80134820: addiu       $a2, $sp, 0x84
        ctx->r6 = ADD32(ctx->r29, 0X84);
            goto L_80134830;
    }
    // 0x80134820: addiu       $a2, $sp, 0x84
    ctx->r6 = ADD32(ctx->r29, 0X84);
    // 0x80134824: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80134828: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x8013482C: sb          $t8, 0x52B4($at)
    MEM_B(0X52B4, ctx->r1) = ctx->r24;
L_80134830:
    // 0x80134830: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134834: jal         0x8013DC98
    // 0x80134838: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    alSynAllocVoice(rdram, ctx);
        goto after_2;
    // 0x80134838: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    after_2:
    // 0x8013483C: lw          $v1, 0x80($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X80);
    // 0x80134840: sb          $zero, 0x34($s0)
    MEM_B(0X34, ctx->r16) = 0;
    // 0x80134844: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x80134848: sw          $v1, 0x20($s0)
    MEM_W(0X20, ctx->r16) = ctx->r3;
    // 0x8013484C: lw          $t0, 0x4C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X4C);
    // 0x80134850: lw          $t9, 0x60($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X60);
    // 0x80134854: addu        $t1, $t9, $t0
    ctx->r9 = ADD32(ctx->r25, ctx->r8);
    // 0x80134858: lbu         $t2, 0xB($t1)
    ctx->r10 = MEM_BU(ctx->r9, 0XB);
    // 0x8013485C: slti        $at, $t2, 0x40
    ctx->r1 = SIGNED(ctx->r10) < 0X40 ? 1 : 0;
    // 0x80134860: bnel        $at, $zero, L_80134874
    if (ctx->r1 != 0) {
        // 0x80134864: sb          $zero, 0x35($s0)
        MEM_B(0X35, ctx->r16) = 0;
            goto L_80134874;
    }
    goto skip_3;
    // 0x80134864: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
    skip_3:
    // 0x80134868: b           L_80134874
    // 0x8013486C: sb          $t3, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r11;
        goto L_80134874;
    // 0x8013486C: sb          $t3, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r11;
    // 0x80134870: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
L_80134874:
    // 0x80134874: lw          $v0, 0x4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X4);
    // 0x80134878: lbu         $t4, 0xBA($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0XBA);
    // 0x8013487C: lbu         $t5, 0x4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X4);
    // 0x80134880: lb          $t8, 0x5($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X5);
    // 0x80134884: subu        $t6, $t4, $t5
    ctx->r14 = SUB32(ctx->r12, ctx->r13);
    // 0x80134888: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x8013488C: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x80134890: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80134894: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80134898: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8013489C: addu        $a0, $t7, $t8
    ctx->r4 = ADD32(ctx->r15, ctx->r24);
    // 0x801348A0: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x801348A4: jal         0x8013DDE0
    // 0x801348A8: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    alCents2Ratio(rdram, ctx);
        goto after_3;
    // 0x801348A8: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    after_3:
    // 0x801348AC: swc1        $f0, 0x28($s0)
    MEM_W(0X28, ctx->r16) = ctx->f0.u32l;
    // 0x801348B0: lw          $t1, 0x80($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X80);
    // 0x801348B4: lui         $at, 0x42FE
    ctx->r1 = S32(0X42FE << 16);
    // 0x801348B8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x801348BC: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x801348C0: lbu         $t3, 0xC($t2)
    ctx->r11 = MEM_BU(ctx->r10, 0XC);
    // 0x801348C4: sb          $t3, 0x30($s0)
    MEM_B(0X30, ctx->r16) = ctx->r11;
    // 0x801348C8: lw          $t5, 0x80($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X80);
    // 0x801348CC: lw          $t4, 0x1C($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X1C);
    // 0x801348D0: lw          $t6, 0x0($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X0);
    // 0x801348D4: lw          $t7, 0x0($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X0);
    // 0x801348D8: sb          $zero, 0x37($s0)
    MEM_B(0X37, ctx->r16) = 0;
    // 0x801348DC: addu        $t8, $t4, $t7
    ctx->r24 = ADD32(ctx->r12, ctx->r15);
    // 0x801348E0: sw          $t8, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r24;
    // 0x801348E4: lw          $t0, 0x4C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X4C);
    // 0x801348E8: lw          $t9, 0x60($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X60);
    // 0x801348EC: addu        $t1, $t9, $t0
    ctx->r9 = ADD32(ctx->r25, ctx->r8);
    // 0x801348F0: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x801348F4: swc1        $f4, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->f4.u32l;
    // 0x801348F8: lbu         $a2, 0x4($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X4);
    // 0x801348FC: beql        $a2, $zero, L_80134978
    if (ctx->r6 == 0) {
        // 0x80134900: cfc1        $t8, $FpcCsr
        ctx->r24 = get_cop1_cs();
            goto L_80134978;
    }
    goto skip_4;
    // 0x80134900: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    skip_4:
    // 0x80134904: lw          $v0, 0x70($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X70);
    // 0x80134908: addiu       $a0, $sp, 0x6C
    ctx->r4 = ADD32(ctx->r29, 0X6C);
    // 0x8013490C: beql        $v0, $zero, L_80134978
    if (ctx->r2 == 0) {
        // 0x80134910: cfc1        $t8, $FpcCsr
        ctx->r24 = get_cop1_cs();
            goto L_80134978;
    }
    goto skip_5;
    // 0x80134910: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    skip_5:
    // 0x80134914: lbu         $t2, 0x6($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X6);
    // 0x80134918: lbu         $a3, 0x5($v1)
    ctx->r7 = MEM_BU(ctx->r3, 0X5);
    // 0x8013491C: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    // 0x80134920: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80134924: lbu         $t3, 0x7($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X7);
    // 0x80134928: sw          $v1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r3;
    // 0x8013492C: jalr        $v0
    // 0x80134930: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    LOOKUP_FUNC(ctx->r2)(rdram, ctx);
        goto after_4;
    // 0x80134930: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    after_4:
    // 0x80134934: lw          $v1, 0x68($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X68);
    // 0x80134938: beq         $v0, $zero, L_80134974
    if (ctx->r2 == 0) {
        // 0x8013493C: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_80134974;
    }
    // 0x8013493C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80134940: lw          $t6, 0x6C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X6C);
    // 0x80134944: addiu       $t5, $zero, 0x16
    ctx->r13 = ADD32(0, 0X16);
    // 0x80134948: sh          $t5, 0x9C($sp)
    MEM_H(0X9C, ctx->r29) = ctx->r13;
    // 0x8013494C: sw          $s0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r16;
    // 0x80134950: addiu       $a0, $s1, 0x48
    ctx->r4 = ADD32(ctx->r17, 0X48);
    // 0x80134954: addiu       $a1, $sp, 0x9C
    ctx->r5 = ADD32(ctx->r29, 0X9C);
    // 0x80134958: sw          $v1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r3;
    // 0x8013495C: jal         0x8013D6DC
    // 0x80134960: sw          $t6, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r14;
    alEvtqPostEvent(rdram, ctx);
        goto after_5;
    // 0x80134960: sw          $t6, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r14;
    after_5:
    // 0x80134964: lbu         $t4, 0x37($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X37);
    // 0x80134968: lw          $v1, 0x68($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X68);
    // 0x8013496C: ori         $t7, $t4, 0x1
    ctx->r15 = ctx->r12 | 0X1;
    // 0x80134970: sb          $t7, 0x37($s0)
    MEM_B(0X37, ctx->r16) = ctx->r15;
L_80134974:
    // 0x80134974: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
L_80134978:
    // 0x80134978: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8013497C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x80134980: lwc1        $f6, 0x74($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X74);
    // 0x80134984: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80134988: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x8013498C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x80134990: nop

    // 0x80134994: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x80134998: beql        $t9, $zero, L_801349E8
    if (ctx->r25 == 0) {
        // 0x8013499C: mfc1        $t9, $f8
        ctx->r25 = (int32_t)ctx->f8.u32l;
            goto L_801349E8;
    }
    goto skip_6;
    // 0x8013499C: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    skip_6:
    // 0x801349A0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x801349A4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x801349A8: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x801349AC: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x801349B0: nop

    // 0x801349B4: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x801349B8: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x801349BC: nop

    // 0x801349C0: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x801349C4: bne         $t9, $zero, L_801349DC
    if (ctx->r25 != 0) {
        // 0x801349C8: nop
    
            goto L_801349DC;
    }
    // 0x801349C8: nop

    // 0x801349CC: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
    // 0x801349D0: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801349D4: b           L_801349F4
    // 0x801349D8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_801349F4;
    // 0x801349D8: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_801349DC:
    // 0x801349DC: b           L_801349F4
    // 0x801349E0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_801349F4;
    // 0x801349E0: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x801349E4: mfc1        $t9, $f8
    ctx->r25 = (int32_t)ctx->f8.u32l;
L_801349E8:
    // 0x801349E8: nop

    // 0x801349EC: bltz        $t9, L_801349DC
    if (SIGNED(ctx->r25) < 0) {
        // 0x801349F0: nop
    
            goto L_801349DC;
    }
    // 0x801349F0: nop

L_801349F4:
    // 0x801349F4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x801349F8: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x801349FC: sb          $t9, 0x36($s0)
    MEM_B(0X36, ctx->r16) = ctx->r25;
    // 0x80134A00: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80134A04: swc1        $f10, 0x74($sp)
    MEM_W(0X74, ctx->r29) = ctx->f10.u32l;
    // 0x80134A08: lbu         $a2, 0x8($v1)
    ctx->r6 = MEM_BU(ctx->r3, 0X8);
    // 0x80134A0C: addiu       $t0, $s1, 0x48
    ctx->r8 = ADD32(ctx->r17, 0X48);
    // 0x80134A10: sw          $t0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r8;
    // 0x80134A14: beql        $a2, $zero, L_80134A88
    if (ctx->r6 == 0) {
        // 0x80134A18: lwc1        $f16, 0x74($sp)
        ctx->f16.u32l = MEM_W(ctx->r29, 0X74);
            goto L_80134A88;
    }
    goto skip_7;
    // 0x80134A18: lwc1        $f16, 0x74($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X74);
    skip_7:
    // 0x80134A1C: lw          $v0, 0x70($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X70);
    // 0x80134A20: beql        $v0, $zero, L_80134A88
    if (ctx->r2 == 0) {
        // 0x80134A24: lwc1        $f16, 0x74($sp)
        ctx->f16.u32l = MEM_W(ctx->r29, 0X74);
            goto L_80134A88;
    }
    goto skip_8;
    // 0x80134A24: lwc1        $f16, 0x74($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X74);
    skip_8:
    // 0x80134A28: lbu         $t1, 0xA($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0XA);
    // 0x80134A2C: lbu         $a3, 0x9($v1)
    ctx->r7 = MEM_BU(ctx->r3, 0X9);
    // 0x80134A30: addiu       $a0, $sp, 0x6C
    ctx->r4 = ADD32(ctx->r29, 0X6C);
    // 0x80134A34: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80134A38: lbu         $t2, 0xB($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0XB);
    // 0x80134A3C: addiu       $a1, $sp, 0x74
    ctx->r5 = ADD32(ctx->r29, 0X74);
    // 0x80134A40: jalr        $v0
    // 0x80134A44: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    LOOKUP_FUNC(ctx->r2)(rdram, ctx);
        goto after_6;
    // 0x80134A44: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_6:
    // 0x80134A48: beq         $v0, $zero, L_80134A84
    if (ctx->r2 == 0) {
        // 0x80134A4C: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_80134A84;
    }
    // 0x80134A4C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80134A50: lw          $t5, 0x6C($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X6C);
    // 0x80134A54: lbu         $t6, 0xBB($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XBB);
    // 0x80134A58: addiu       $t3, $zero, 0x17
    ctx->r11 = ADD32(0, 0X17);
    // 0x80134A5C: sh          $t3, 0x9C($sp)
    MEM_H(0X9C, ctx->r29) = ctx->r11;
    // 0x80134A60: sw          $s0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r16;
    // 0x80134A64: lw          $a0, 0x40($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X40);
    // 0x80134A68: addiu       $a1, $sp, 0x9C
    ctx->r5 = ADD32(ctx->r29, 0X9C);
    // 0x80134A6C: sw          $t5, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r13;
    // 0x80134A70: jal         0x8013D6DC
    // 0x80134A74: sb          $t6, 0xA8($sp)
    MEM_B(0XA8, ctx->r29) = ctx->r14;
    alEvtqPostEvent(rdram, ctx);
        goto after_7;
    // 0x80134A74: sb          $t6, 0xA8($sp)
    MEM_B(0XA8, ctx->r29) = ctx->r14;
    after_7:
    // 0x80134A78: lbu         $t4, 0x37($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X37);
    // 0x80134A7C: ori         $t7, $t4, 0x2
    ctx->r15 = ctx->r12 | 0X2;
    // 0x80134A80: sb          $t7, 0x37($s0)
    MEM_B(0X37, ctx->r16) = ctx->r15;
L_80134A84:
    // 0x80134A84: lwc1        $f16, 0x74($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X74);
L_80134A88:
    // 0x80134A88: lwc1        $f4, 0x28($s0)
    ctx->f4.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80134A8C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80134A90: swc1        $f16, 0x2C($s0)
    MEM_W(0X2C, ctx->r16) = ctx->f16.u32l;
    // 0x80134A94: lw          $t9, 0x4C($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X4C);
    // 0x80134A98: lw          $t8, 0x60($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X60);
    // 0x80134A9C: lwc1        $f8, 0x2C($s0)
    ctx->f8.u32l = MEM_W(ctx->r16, 0X2C);
    // 0x80134AA0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80134AA4: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x80134AA8: lwc1        $f18, 0xC($v0)
    ctx->f18.u32l = MEM_W(ctx->r2, 0XC);
    // 0x80134AAC: mul.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80134AB0: nop

    // 0x80134AB4: mul.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80134AB8: swc1        $f10, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->f10.u32l;
    // 0x80134ABC: lbu         $t0, 0xA($v0)
    ctx->r8 = MEM_BU(ctx->r2, 0XA);
    // 0x80134AC0: jal         0x8013C254
    // 0x80134AC4: sb          $t0, 0x73($sp)
    MEM_B(0X73, ctx->r29) = ctx->r8;
    __vsPan(rdram, ctx);
        goto after_8;
    // 0x80134AC4: sb          $t0, 0x73($sp)
    MEM_B(0X73, ctx->r29) = ctx->r8;
    after_8:
    // 0x80134AC8: sb          $v0, 0x93($sp)
    MEM_B(0X93, ctx->r29) = ctx->r2;
    // 0x80134ACC: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80134AD0: jal         0x8013BE34
    // 0x80134AD4: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    __vsVol(rdram, ctx);
        goto after_9;
    // 0x80134AD4: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_9:
    // 0x80134AD8: lw          $t1, 0x80($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X80);
    // 0x80134ADC: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134AE0: lbu         $t3, 0x93($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X93);
    // 0x80134AE4: lw          $t2, 0x0($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X0);
    // 0x80134AE8: lw          $a2, 0x8($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X8);
    // 0x80134AEC: lbu         $t5, 0x73($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X73);
    // 0x80134AF0: lw          $s0, 0x0($t2)
    ctx->r16 = MEM_W(ctx->r10, 0X0);
    // 0x80134AF4: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x80134AF8: lw          $a1, 0x44($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X44);
    // 0x80134AFC: lw          $a3, 0x78($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X78);
    // 0x80134B00: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x80134B04: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80134B08: jal         0x8013DE30
    // 0x80134B0C: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    alSynStartVoiceParams(rdram, ctx);
        goto after_10;
    // 0x80134B0C: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    after_10:
    // 0x80134B10: lw          $t4, 0x44($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X44);
    // 0x80134B14: lw          $t7, 0x80($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X80);
    // 0x80134B18: addiu       $t6, $zero, 0x6
    ctx->r14 = ADD32(0, 0X6);
    // 0x80134B1C: sh          $t6, 0x9C($sp)
    MEM_H(0X9C, ctx->r29) = ctx->r14;
    // 0x80134B20: sw          $t4, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r12;
    // 0x80134B24: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x80134B28: lw          $a0, 0x40($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X40);
    // 0x80134B2C: addiu       $a1, $sp, 0x9C
    ctx->r5 = ADD32(ctx->r29, 0X9C);
    // 0x80134B30: lbu         $t9, 0xD($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0XD);
    // 0x80134B34: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80134B38: sb          $t9, 0xA8($sp)
    MEM_B(0XA8, ctx->r29) = ctx->r25;
    // 0x80134B3C: lw          $t0, 0x0($t7)
    ctx->r8 = MEM_W(ctx->r15, 0X0);
    // 0x80134B40: lw          $t2, 0x4($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X4);
    // 0x80134B44: jal         0x8013D6DC
    // 0x80134B48: sw          $t2, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r10;
    alEvtqPostEvent(rdram, ctx);
        goto after_11;
    // 0x80134B48: sw          $t2, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r10;
    after_11:
    // 0x80134B4C: lw          $v0, 0xCC($sp)
    ctx->r2 = MEM_W(ctx->r29, 0XCC);
    // 0x80134B50: addiu       $t3, $zero, 0x15
    ctx->r11 = ADD32(0, 0X15);
    // 0x80134B54: ori         $t5, $s2, 0x80
    ctx->r13 = ctx->r18 | 0X80;
    // 0x80134B58: lw          $t1, 0xC($v0)
    ctx->r9 = MEM_W(ctx->r2, 0XC);
    // 0x80134B5C: addiu       $v0, $v0, 0x4
    ctx->r2 = ADD32(ctx->r2, 0X4);
    // 0x80134B60: beql        $t1, $zero, L_80134FD4
    if (ctx->r9 == 0) {
        // 0x80134B64: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_9;
    // 0x80134B64: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_9:
    // 0x80134B68: lbu         $t6, 0xBA($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134B6C: sh          $t3, 0x9C($sp)
    MEM_H(0X9C, ctx->r29) = ctx->r11;
    // 0x80134B70: sb          $t5, 0xA4($sp)
    MEM_B(0XA4, ctx->r29) = ctx->r13;
    // 0x80134B74: sb          $zero, 0xA6($sp)
    MEM_B(0XA6, ctx->r29) = 0;
    // 0x80134B78: sb          $t6, 0xA5($sp)
    MEM_B(0XA5, ctx->r29) = ctx->r14;
    // 0x80134B7C: lw          $t8, 0x8($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X8);
    // 0x80134B80: lw          $t4, 0x24($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X24);
    // 0x80134B84: lw          $a0, 0x40($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X40);
    // 0x80134B88: addiu       $a1, $sp, 0x9C
    ctx->r5 = ADD32(ctx->r29, 0X9C);
    // 0x80134B8C: multu       $t4, $t8
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80134B90: mflo        $a2
    ctx->r6 = lo;
    // 0x80134B94: jal         0x8013D6DC
    // 0x80134B98: nop

    alEvtqPostEvent(rdram, ctx);
        goto after_12;
    // 0x80134B98: nop

    after_12:
    // 0x80134B9C: b           L_80134FD4
    // 0x80134BA0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134BA0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134BA4:
    // 0x80134BA4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_80134BA8:
    // 0x80134BA8: lbu         $a1, 0xBA($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134BAC: jal         0x8013C29C
    // 0x80134BB0: andi        $a2, $a3, 0xFF
    ctx->r6 = ctx->r7 & 0XFF;
    __lookupVoice(rdram, ctx);
        goto after_13;
    // 0x80134BB0: andi        $a2, $a3, 0xFF
    ctx->r6 = ctx->r7 & 0XFF;
    after_13:
    // 0x80134BB4: beq         $v0, $zero, L_80134FD0
    if (ctx->r2 == 0) {
        // 0x80134BB8: or          $s0, $v0, $zero
        ctx->r16 = ctx->r2 | 0;
            goto L_80134FD0;
    }
    // 0x80134BB8: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x80134BBC: lbu         $t9, 0x35($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X35);
    // 0x80134BC0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80134BC4: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x80134BC8: bne         $t9, $at, L_80134BD8
    if (ctx->r25 != ctx->r1) {
        // 0x80134BCC: addiu       $t0, $zero, 0x3
        ctx->r8 = ADD32(0, 0X3);
            goto L_80134BD8;
    }
    // 0x80134BCC: addiu       $t0, $zero, 0x3
    ctx->r8 = ADD32(0, 0X3);
    // 0x80134BD0: b           L_80134FD0
    // 0x80134BD4: sb          $t7, 0x35($v0)
    MEM_B(0X35, ctx->r2) = ctx->r15;
        goto L_80134FD0;
    // 0x80134BD4: sb          $t7, 0x35($v0)
    MEM_B(0X35, ctx->r2) = ctx->r15;
L_80134BD8:
    // 0x80134BD8: lw          $t2, 0x20($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X20);
    // 0x80134BDC: sb          $t0, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r8;
    // 0x80134BE0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80134BE4: lw          $t1, 0x0($t2)
    ctx->r9 = MEM_W(ctx->r10, 0X0);
    // 0x80134BE8: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134BEC: jal         0x8013BEBC
    // 0x80134BF0: lw          $a2, 0x8($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X8);
    __seqpReleaseVoice(rdram, ctx);
        goto after_14;
    // 0x80134BF0: lw          $a2, 0x8($t1)
    ctx->r6 = MEM_W(ctx->r9, 0X8);
    after_14:
    // 0x80134BF4: b           L_80134FD4
    // 0x80134BF8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134BF8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134BFC:
    // 0x80134BFC: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80134C00: lbu         $a1, 0xBA($sp)
    ctx->r5 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134C04: jal         0x8013C29C
    // 0x80134C08: andi        $a2, $a3, 0xFF
    ctx->r6 = ctx->r7 & 0XFF;
    __lookupVoice(rdram, ctx);
        goto after_15;
    // 0x80134C08: andi        $a2, $a3, 0xFF
    ctx->r6 = ctx->r7 & 0XFF;
    after_15:
    // 0x80134C0C: beq         $v0, $zero, L_80134FD0
    if (ctx->r2 == 0) {
        // 0x80134C10: or          $s0, $v0, $zero
        ctx->r16 = ctx->r2 | 0;
            goto L_80134FD0;
    }
    // 0x80134C10: or          $s0, $v0, $zero
    ctx->r16 = ctx->r2 | 0;
    // 0x80134C14: lbu         $t3, 0xB9($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134C18: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80134C1C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80134C20: jal         0x8013BE34
    // 0x80134C24: sb          $t3, 0x33($v0)
    MEM_B(0X33, ctx->r2) = ctx->r11;
    __vsVol(rdram, ctx);
        goto after_16;
    // 0x80134C24: sb          $t3, 0x33($v0)
    MEM_B(0X33, ctx->r2) = ctx->r11;
    after_16:
    // 0x80134C28: sh          $v0, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r2;
    // 0x80134C2C: lw          $a1, 0x1C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X1C);
    // 0x80134C30: jal         0x8013BE10
    // 0x80134C34: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __vsDelta(rdram, ctx);
        goto after_17;
    // 0x80134C34: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_17:
    // 0x80134C38: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134C3C: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134C40: lh          $a2, 0x52($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X52);
    // 0x80134C44: jal         0x8013DA80
    // 0x80134C48: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    alSynSetVol(rdram, ctx);
        goto after_18;
    // 0x80134C48: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    after_18:
    // 0x80134C4C: b           L_80134FD4
    // 0x80134C50: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134C50: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134C54:
    // 0x80134C54: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134C58: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134C5C: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134C60: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_10;
    // 0x80134C60: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_10:
    // 0x80134C64: lbu         $t5, 0x31($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X31);
L_80134C68:
    // 0x80134C68: lbu         $t6, 0xBA($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134C6C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80134C70: bne         $s2, $t5, L_80134CA4
    if (ctx->r18 != ctx->r13) {
        // 0x80134C74: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_80134CA4;
    }
    // 0x80134C74: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80134C78: jal         0x8013BE34
    // 0x80134C7C: sb          $t6, 0x33($s0)
    MEM_B(0X33, ctx->r16) = ctx->r14;
    __vsVol(rdram, ctx);
        goto after_19;
    // 0x80134C7C: sb          $t6, 0x33($s0)
    MEM_B(0X33, ctx->r16) = ctx->r14;
    after_19:
    // 0x80134C80: sh          $v0, 0x52($sp)
    MEM_H(0X52, ctx->r29) = ctx->r2;
    // 0x80134C84: lw          $a1, 0x1C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X1C);
    // 0x80134C88: jal         0x8013BE10
    // 0x80134C8C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __vsDelta(rdram, ctx);
        goto after_20;
    // 0x80134C8C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_20:
    // 0x80134C90: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134C94: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134C98: lh          $a2, 0x52($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X52);
    // 0x80134C9C: jal         0x8013DA80
    // 0x80134CA0: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    alSynSetVol(rdram, ctx);
        goto after_21;
    // 0x80134CA0: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    after_21:
L_80134CA4:
    // 0x80134CA4: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    // 0x80134CA8: bnel        $s0, $zero, L_80134C68
    if (ctx->r16 != 0) {
        // 0x80134CAC: lbu         $t5, 0x31($s0)
        ctx->r13 = MEM_BU(ctx->r16, 0X31);
            goto L_80134C68;
    }
    goto skip_11;
    // 0x80134CAC: lbu         $t5, 0x31($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X31);
    skip_11:
    // 0x80134CB0: b           L_80134FD4
    // 0x80134CB4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134CB4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134CB8:
    // 0x80134CB8: lbu         $v0, 0xBA($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134CBC: addiu       $at, $zero, 0x7
    ctx->r1 = ADD32(0, 0X7);
    // 0x80134CC0: beq         $v0, $at, L_80134D50
    if (ctx->r2 == ctx->r1) {
        // 0x80134CC4: addiu       $at, $zero, 0xA
        ctx->r1 = ADD32(0, 0XA);
            goto L_80134D50;
    }
    // 0x80134CC4: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x80134CC8: beq         $v0, $at, L_80134CF0
    if (ctx->r2 == ctx->r1) {
        // 0x80134CCC: addiu       $at, $zero, 0x10
        ctx->r1 = ADD32(0, 0X10);
            goto L_80134CF0;
    }
    // 0x80134CCC: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x80134CD0: beq         $v0, $at, L_80134DD4
    if (ctx->r2 == ctx->r1) {
        // 0x80134CD4: addiu       $at, $zero, 0x40
        ctx->r1 = ADD32(0, 0X40);
            goto L_80134DD4;
    }
    // 0x80134CD4: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x80134CD8: beq         $v0, $at, L_80134DEC
    if (ctx->r2 == ctx->r1) {
        // 0x80134CDC: addiu       $at, $zero, 0x5B
        ctx->r1 = ADD32(0, 0X5B);
            goto L_80134DEC;
    }
    // 0x80134CDC: addiu       $at, $zero, 0x5B
    ctx->r1 = ADD32(0, 0X5B);
    // 0x80134CE0: beql        $v0, $at, L_80134E9C
    if (ctx->r2 == ctx->r1) {
        // 0x80134CE4: lw          $t2, 0x60($s1)
        ctx->r10 = MEM_W(ctx->r17, 0X60);
            goto L_80134E9C;
    }
    goto skip_12;
    // 0x80134CE4: lw          $t2, 0x60($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X60);
    skip_12:
    // 0x80134CE8: b           L_80134FD4
    // 0x80134CEC: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134CEC: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134CF0:
    // 0x80134CF0: lw          $t8, 0x60($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X60);
    // 0x80134CF4: lbu         $t4, 0xB9($sp)
    ctx->r12 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134CF8: sll         $t9, $a3, 4
    ctx->r25 = S32(ctx->r7 << 4);
    // 0x80134CFC: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x80134D00: sb          $t4, 0x7($t7)
    MEM_B(0X7, ctx->r15) = ctx->r12;
    // 0x80134D04: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134D08: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134D0C: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134D10: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_13;
    // 0x80134D10: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_13:
    // 0x80134D14: lbu         $t0, 0x31($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X31);
L_80134D18:
    // 0x80134D18: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80134D1C: bnel        $s2, $t0, L_80134D40
    if (ctx->r18 != ctx->r8) {
        // 0x80134D20: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134D40;
    }
    goto skip_14;
    // 0x80134D20: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_14:
    // 0x80134D24: jal         0x8013C254
    // 0x80134D28: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    __vsPan(rdram, ctx);
        goto after_22;
    // 0x80134D28: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_22:
    // 0x80134D2C: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134D30: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134D34: jal         0x8013DF20
    // 0x80134D38: andi        $a2, $v0, 0xFF
    ctx->r6 = ctx->r2 & 0XFF;
    alSynSetPan(rdram, ctx);
        goto after_23;
    // 0x80134D38: andi        $a2, $v0, 0xFF
    ctx->r6 = ctx->r2 & 0XFF;
    after_23:
    // 0x80134D3C: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_80134D40:
    // 0x80134D40: bnel        $s0, $zero, L_80134D18
    if (ctx->r16 != 0) {
        // 0x80134D44: lbu         $t0, 0x31($s0)
        ctx->r8 = MEM_BU(ctx->r16, 0X31);
            goto L_80134D18;
    }
    goto skip_15;
    // 0x80134D44: lbu         $t0, 0x31($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X31);
    skip_15:
    // 0x80134D48: b           L_80134FD4
    // 0x80134D4C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134D4C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134D50:
    // 0x80134D50: lw          $t1, 0x60($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X60);
    // 0x80134D54: lbu         $t2, 0xB9($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134D58: sll         $t3, $a3, 4
    ctx->r11 = S32(ctx->r7 << 4);
    // 0x80134D5C: addu        $t5, $t1, $t3
    ctx->r13 = ADD32(ctx->r9, ctx->r11);
    // 0x80134D60: sb          $t2, 0x9($t5)
    MEM_B(0X9, ctx->r13) = ctx->r10;
    // 0x80134D64: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134D68: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134D6C: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134D70: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_16;
    // 0x80134D70: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_16:
    // 0x80134D74: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
L_80134D78:
    // 0x80134D78: bnel        $s2, $t6, L_80134DC4
    if (ctx->r18 != ctx->r14) {
        // 0x80134D7C: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134DC4;
    }
    goto skip_17;
    // 0x80134D7C: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_17:
    // 0x80134D80: lbu         $t8, 0x34($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X34);
    // 0x80134D84: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80134D88: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80134D8C: beql        $t8, $at, L_80134DC4
    if (ctx->r24 == ctx->r1) {
        // 0x80134D90: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134DC4;
    }
    goto skip_18;
    // 0x80134D90: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_18:
    // 0x80134D94: jal         0x8013BE34
    // 0x80134D98: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    __vsVol(rdram, ctx);
        goto after_24;
    // 0x80134D98: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    after_24:
    // 0x80134D9C: sh          $v0, 0xAE($sp)
    MEM_H(0XAE, ctx->r29) = ctx->r2;
    // 0x80134DA0: lw          $a1, 0x1C($s1)
    ctx->r5 = MEM_W(ctx->r17, 0X1C);
    // 0x80134DA4: jal         0x8013BE10
    // 0x80134DA8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    __vsDelta(rdram, ctx);
        goto after_25;
    // 0x80134DA8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_25:
    // 0x80134DAC: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134DB0: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134DB4: lh          $a2, 0xAE($sp)
    ctx->r6 = MEM_H(ctx->r29, 0XAE);
    // 0x80134DB8: jal         0x8013DA80
    // 0x80134DBC: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    alSynSetVol(rdram, ctx);
        goto after_26;
    // 0x80134DBC: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
    after_26:
    // 0x80134DC0: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_80134DC4:
    // 0x80134DC4: bnel        $s0, $zero, L_80134D78
    if (ctx->r16 != 0) {
        // 0x80134DC8: lbu         $t6, 0x31($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X31);
            goto L_80134D78;
    }
    goto skip_19;
    // 0x80134DC8: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
    skip_19:
    // 0x80134DCC: b           L_80134FD4
    // 0x80134DD0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134DD0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134DD4:
    // 0x80134DD4: lw          $t4, 0x60($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X60);
    // 0x80134DD8: lbu         $t9, 0xB9($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134DDC: sll         $t7, $a3, 4
    ctx->r15 = S32(ctx->r7 << 4);
    // 0x80134DE0: addu        $t0, $t4, $t7
    ctx->r8 = ADD32(ctx->r12, ctx->r15);
    // 0x80134DE4: b           L_80134FD0
    // 0x80134DE8: sb          $t9, 0x8($t0)
    MEM_B(0X8, ctx->r8) = ctx->r25;
        goto L_80134FD0;
    // 0x80134DE8: sb          $t9, 0x8($t0)
    MEM_B(0X8, ctx->r8) = ctx->r25;
L_80134DEC:
    // 0x80134DEC: lw          $t3, 0x60($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X60);
    // 0x80134DF0: lbu         $t1, 0xB9($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134DF4: sll         $t2, $a3, 4
    ctx->r10 = S32(ctx->r7 << 4);
    // 0x80134DF8: addu        $t5, $t3, $t2
    ctx->r13 = ADD32(ctx->r11, ctx->r10);
    // 0x80134DFC: sb          $t1, 0xB($t5)
    MEM_B(0XB, ctx->r13) = ctx->r9;
    // 0x80134E00: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134E04: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134E08: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134E0C: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_20;
    // 0x80134E0C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_20:
    // 0x80134E10: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
L_80134E14:
    // 0x80134E14: bnel        $s2, $t6, L_80134E88
    if (ctx->r18 != ctx->r14) {
        // 0x80134E18: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134E88;
    }
    goto skip_21;
    // 0x80134E18: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_21:
    // 0x80134E1C: lbu         $v0, 0x35($s0)
    ctx->r2 = MEM_BU(ctx->r16, 0X35);
    // 0x80134E20: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80134E24: lbu         $t8, 0xB9($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134E28: beq         $v0, $at, L_80134E84
    if (ctx->r2 == ctx->r1) {
        // 0x80134E2C: slti        $at, $t8, 0x40
        ctx->r1 = SIGNED(ctx->r24) < 0X40 ? 1 : 0;
            goto L_80134E84;
    }
    // 0x80134E2C: slti        $at, $t8, 0x40
    ctx->r1 = SIGNED(ctx->r24) < 0X40 ? 1 : 0;
    // 0x80134E30: bnel        $at, $zero, L_80134E4C
    if (ctx->r1 != 0) {
        // 0x80134E34: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80134E4C;
    }
    goto skip_22;
    // 0x80134E34: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    skip_22:
    // 0x80134E38: bne         $v0, $zero, L_80134E84
    if (ctx->r2 != 0) {
        // 0x80134E3C: addiu       $t4, $zero, 0x2
        ctx->r12 = ADD32(0, 0X2);
            goto L_80134E84;
    }
    // 0x80134E3C: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x80134E40: b           L_80134E84
    // 0x80134E44: sb          $t4, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r12;
        goto L_80134E84;
    // 0x80134E44: sb          $t4, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r12;
    // 0x80134E48: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
L_80134E4C:
    // 0x80134E4C: bnel        $v0, $at, L_80134E60
    if (ctx->r2 != ctx->r1) {
        // 0x80134E50: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80134E60;
    }
    goto skip_23;
    // 0x80134E50: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    skip_23:
    // 0x80134E54: b           L_80134E84
    // 0x80134E58: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
        goto L_80134E84;
    // 0x80134E58: sb          $zero, 0x35($s0)
    MEM_B(0X35, ctx->r16) = 0;
    // 0x80134E5C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
L_80134E60:
    // 0x80134E60: bne         $v0, $at, L_80134E84
    if (ctx->r2 != ctx->r1) {
        // 0x80134E64: addiu       $t7, $zero, 0x3
        ctx->r15 = ADD32(0, 0X3);
            goto L_80134E84;
    }
    // 0x80134E64: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x80134E68: lw          $t9, 0x20($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X20);
    // 0x80134E6C: sb          $t7, 0x35($s0)
    MEM_B(0X35, ctx->r16) = ctx->r15;
    // 0x80134E70: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80134E74: lw          $t0, 0x0($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X0);
    // 0x80134E78: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134E7C: jal         0x8013BEBC
    // 0x80134E80: lw          $a2, 0x8($t0)
    ctx->r6 = MEM_W(ctx->r8, 0X8);
    __seqpReleaseVoice(rdram, ctx);
        goto after_27;
    // 0x80134E80: lw          $a2, 0x8($t0)
    ctx->r6 = MEM_W(ctx->r8, 0X8);
    after_27:
L_80134E84:
    // 0x80134E84: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_80134E88:
    // 0x80134E88: bnel        $s0, $zero, L_80134E14
    if (ctx->r16 != 0) {
        // 0x80134E8C: lbu         $t6, 0x31($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X31);
            goto L_80134E14;
    }
    goto skip_24;
    // 0x80134E8C: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
    skip_24:
    // 0x80134E90: b           L_80134FD4
    // 0x80134E94: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134E94: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80134E98: lw          $t2, 0x60($s1)
    ctx->r10 = MEM_W(ctx->r17, 0X60);
L_80134E9C:
    // 0x80134E9C: lbu         $t3, 0xB9($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134EA0: sll         $t1, $a3, 4
    ctx->r9 = S32(ctx->r7 << 4);
    // 0x80134EA4: addu        $t5, $t2, $t1
    ctx->r13 = ADD32(ctx->r10, ctx->r9);
    // 0x80134EA8: sb          $t3, 0xA($t5)
    MEM_B(0XA, ctx->r13) = ctx->r11;
    // 0x80134EAC: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134EB0: or          $s2, $a3, $zero
    ctx->r18 = ctx->r7 | 0;
    // 0x80134EB4: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134EB8: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_25;
    // 0x80134EB8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_25:
    // 0x80134EBC: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
L_80134EC0:
    // 0x80134EC0: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134EC4: lbu         $a2, 0xB9($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134EC8: bnel        $s2, $t6, L_80134EDC
    if (ctx->r18 != ctx->r14) {
        // 0x80134ECC: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134EDC;
    }
    goto skip_26;
    // 0x80134ECC: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_26:
    // 0x80134ED0: jal         0x8013DFB0
    // 0x80134ED4: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    alSynSetFXMix(rdram, ctx);
        goto after_28;
    // 0x80134ED4: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    after_28:
    // 0x80134ED8: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_80134EDC:
    // 0x80134EDC: bnel        $s0, $zero, L_80134EC0
    if (ctx->r16 != 0) {
        // 0x80134EE0: lbu         $t6, 0x31($s0)
        ctx->r14 = MEM_BU(ctx->r16, 0X31);
            goto L_80134EC0;
    }
    goto skip_27;
    // 0x80134EE0: lbu         $t6, 0x31($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X31);
    skip_27:
    // 0x80134EE4: b           L_80134FD4
    // 0x80134EE8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134EE8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134EEC:
    // 0x80134EEC: lw          $v0, 0x20($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X20);
    // 0x80134EF0: lbu         $t8, 0xBA($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134EF4: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80134EF8: lh          $t4, 0x0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X0);
    // 0x80134EFC: sll         $t7, $t8, 2
    ctx->r15 = S32(ctx->r24 << 2);
    // 0x80134F00: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80134F04: slt         $at, $t8, $t4
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80134F08: beq         $at, $zero, L_80134FD0
    if (ctx->r1 == 0) {
        // 0x80134F0C: addu        $t9, $v0, $t7
        ctx->r25 = ADD32(ctx->r2, ctx->r15);
            goto L_80134FD0;
    }
    // 0x80134F0C: addu        $t9, $v0, $t7
    ctx->r25 = ADD32(ctx->r2, ctx->r15);
    // 0x80134F10: jal         0x8013BC80
    // 0x80134F14: lw          $a1, 0xC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0XC);
    __setInstChanState(rdram, ctx);
        goto after_29;
    // 0x80134F14: lw          $a1, 0xC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0XC);
    after_29:
    // 0x80134F18: b           L_80134FD4
    // 0x80134F1C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_80134FD4;
    // 0x80134F1C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134F20:
    // 0x80134F20: lw          $t6, 0x60($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X60);
    // 0x80134F24: lbu         $t0, 0xB9($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0XB9);
    // 0x80134F28: lbu         $t1, 0xBA($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0XBA);
    // 0x80134F2C: sll         $v0, $a3, 4
    ctx->r2 = S32(ctx->r7 << 4);
    // 0x80134F30: addu        $t4, $t6, $v0
    ctx->r12 = ADD32(ctx->r14, ctx->r2);
    // 0x80134F34: lh          $t8, 0x4($t4)
    ctx->r24 = MEM_H(ctx->r12, 0X4);
    // 0x80134F38: sll         $t2, $t0, 7
    ctx->r10 = S32(ctx->r8 << 7);
    // 0x80134F3C: addu        $t3, $t2, $t1
    ctx->r11 = ADD32(ctx->r10, ctx->r9);
    // 0x80134F40: addiu       $t5, $t3, -0x2000
    ctx->r13 = ADD32(ctx->r11, -0X2000);
    // 0x80134F44: multu       $t8, $t5
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80134F48: sb          $a3, 0xBB($sp)
    MEM_B(0XBB, ctx->r29) = ctx->r7;
    // 0x80134F4C: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    // 0x80134F50: mflo        $a0
    ctx->r4 = lo;
    // 0x80134F54: bgez        $a0, L_80134F64
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80134F58: sra         $t7, $a0, 13
        ctx->r15 = S32(SIGNED(ctx->r4) >> 13);
            goto L_80134F64;
    }
    // 0x80134F58: sra         $t7, $a0, 13
    ctx->r15 = S32(SIGNED(ctx->r4) >> 13);
    // 0x80134F5C: addiu       $at, $a0, 0x1FFF
    ctx->r1 = ADD32(ctx->r4, 0X1FFF);
    // 0x80134F60: sra         $t7, $at, 13
    ctx->r15 = S32(SIGNED(ctx->r1) >> 13);
L_80134F64:
    // 0x80134F64: jal         0x8013DDE0
    // 0x80134F68: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    alCents2Ratio(rdram, ctx);
        goto after_30;
    // 0x80134F68: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_30:
    // 0x80134F6C: swc1        $f0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->f0.u32l;
    // 0x80134F70: lw          $t9, 0x60($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X60);
    // 0x80134F74: lw          $t0, 0x4C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X4C);
    // 0x80134F78: addu        $t2, $t9, $t0
    ctx->r10 = ADD32(ctx->r25, ctx->r8);
    // 0x80134F7C: swc1        $f0, 0xC($t2)
    MEM_W(0XC, ctx->r10) = ctx->f0.u32l;
    // 0x80134F80: lw          $s0, 0x64($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X64);
    // 0x80134F84: lbu         $s2, 0xBB($sp)
    ctx->r18 = MEM_BU(ctx->r29, 0XBB);
    // 0x80134F88: beql        $s0, $zero, L_80134FD4
    if (ctx->r16 == 0) {
        // 0x80134F8C: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80134FD4;
    }
    goto skip_28;
    // 0x80134F8C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_28:
    // 0x80134F90: lbu         $t1, 0x31($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X31);
L_80134F94:
    // 0x80134F94: lwc1        $f18, 0x5C($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X5C);
    // 0x80134F98: bnel        $s2, $t1, L_80134FC8
    if (ctx->r18 != ctx->r9) {
        // 0x80134F9C: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_80134FC8;
    }
    goto skip_29;
    // 0x80134F9C: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_29:
    // 0x80134FA0: lwc1        $f16, 0x28($s0)
    ctx->f16.u32l = MEM_W(ctx->r16, 0X28);
    // 0x80134FA4: lwc1        $f6, 0x2C($s0)
    ctx->f6.u32l = MEM_W(ctx->r16, 0X2C);
    // 0x80134FA8: lw          $a0, 0x14($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X14);
    // 0x80134FAC: mul.s       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = MUL_S(ctx->f16.fl, ctx->f18.fl);
    // 0x80134FB0: addiu       $a1, $s0, 0x4
    ctx->r5 = ADD32(ctx->r16, 0X4);
    // 0x80134FB4: mul.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x80134FB8: mfc1        $a2, $f8
    ctx->r6 = (int32_t)ctx->f8.u32l;
    // 0x80134FBC: jal         0x8013DB20
    // 0x80134FC0: nop

    alSynSetPitch(rdram, ctx);
        goto after_31;
    // 0x80134FC0: nop

    after_31:
    // 0x80134FC4: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_80134FC8:
    // 0x80134FC8: bnel        $s0, $zero, L_80134F94
    if (ctx->r16 != 0) {
        // 0x80134FCC: lbu         $t1, 0x31($s0)
        ctx->r9 = MEM_BU(ctx->r16, 0X31);
            goto L_80134F94;
    }
    goto skip_30;
    // 0x80134FCC: lbu         $t1, 0x31($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X31);
    skip_30:
L_80134FD0:
    // 0x80134FD0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80134FD4:
    // 0x80134FD4: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x80134FD8: lw          $s1, 0x2C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X2C);
    // 0x80134FDC: lw          $s2, 0x30($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X30);
    // 0x80134FE0: jr          $ra
    // 0x80134FE4: addiu       $sp, $sp, 0xC8
    ctx->r29 = ADD32(ctx->r29, 0XC8);
    return;
    // 0x80134FE4: addiu       $sp, $sp, 0xC8
    ctx->r29 = ADD32(ctx->r29, 0XC8);
;}
RECOMP_FUNC void __CSPHandleMetaMsg(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80134FE8: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x80134FEC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80134FF0: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80134FF4: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80134FF8: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80134FFC: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80135000: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80135004: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80135008: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8013500C: lbu         $t6, 0x8($a1)
    ctx->r14 = MEM_BU(ctx->r5, 0X8);
    // 0x80135010: addiu       $at, $zero, 0xFF
    ctx->r1 = ADD32(0, 0XFF);
    // 0x80135014: or          $s5, $a0, $zero
    ctx->r21 = ctx->r4 | 0;
    // 0x80135018: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    // 0x8013501C: bne         $t6, $at, L_80135150
    if (ctx->r14 != ctx->r1) {
        // 0x80135020: or          $s3, $zero, $zero
        ctx->r19 = 0 | 0;
            goto L_80135150;
    }
    // 0x80135020: or          $s3, $zero, $zero
    ctx->r19 = 0 | 0;
    // 0x80135024: lbu         $t7, 0x9($a1)
    ctx->r15 = MEM_BU(ctx->r5, 0X9);
    // 0x80135028: addiu       $at, $zero, 0x51
    ctx->r1 = ADD32(0, 0X51);
    // 0x8013502C: addiu       $v0, $a1, 0x4
    ctx->r2 = ADD32(ctx->r5, 0X4);
    // 0x80135030: bnel        $t7, $at, L_80135154
    if (ctx->r15 != ctx->r1) {
        // 0x80135034: lw          $ra, 0x34($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X34);
            goto L_80135154;
    }
    goto skip_0;
    // 0x80135034: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    skip_0:
    // 0x80135038: lbu         $t8, 0x7($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X7);
    // 0x8013503C: lbu         $t0, 0x8($v0)
    ctx->r8 = MEM_BU(ctx->r2, 0X8);
    // 0x80135040: lbu         $t3, 0x9($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X9);
    // 0x80135044: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80135048: sll         $t1, $t0, 8
    ctx->r9 = S32(ctx->r8 << 8);
    // 0x8013504C: or          $t2, $t9, $t1
    ctx->r10 = ctx->r25 | ctx->r9;
    // 0x80135050: or          $v1, $t2, $t3
    ctx->r3 = ctx->r10 | ctx->r11;
    // 0x80135054: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x80135058: lw          $s6, 0x24($a0)
    ctx->r22 = MEM_W(ctx->r4, 0X24);
    // 0x8013505C: cvt.s.w     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80135060: mfc1        $a1, $f4
    ctx->r5 = (int32_t)ctx->f4.u32l;
    // 0x80135064: jal         0x80135218
    // 0x80135068: nop

    __setUsptFromTempo(rdram, ctx);
        goto after_0;
    // 0x80135068: nop

    after_0:
    // 0x8013506C: lw          $s0, 0x50($s5)
    ctx->r16 = MEM_W(ctx->r21, 0X50);
    // 0x80135070: beq         $s0, $zero, L_801350E8
    if (ctx->r16 == 0) {
        // 0x80135074: nop
    
            goto L_801350E8;
    }
    // 0x80135074: nop

    // 0x80135078: addiu       $s4, $zero, 0x15
    ctx->r20 = ADD32(0, 0X15);
L_8013507C:
    // 0x8013507C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x80135080: lw          $t4, 0x8($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X8);
    // 0x80135084: lw          $s1, 0x0($s0)
    ctx->r17 = MEM_W(ctx->r16, 0X0);
    // 0x80135088: bne         $s4, $t5, L_801350E0
    if (ctx->r20 != ctx->r13) {
        // 0x8013508C: addu        $s2, $s2, $t4
        ctx->r18 = ADD32(ctx->r18, ctx->r12);
            goto L_801350E0;
    }
    // 0x8013508C: addu        $s2, $s2, $t4
    ctx->r18 = ADD32(ctx->r18, ctx->r12);
    // 0x80135090: jal         0x80139980
    // 0x80135094: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    alUnlink(rdram, ctx);
        goto after_1;
    // 0x80135094: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x80135098: beql        $s3, $zero, L_801350B8
    if (ctx->r19 == 0) {
        // 0x8013509C: sw          $zero, 0x0($s0)
        MEM_W(0X0, ctx->r16) = 0;
            goto L_801350B8;
    }
    goto skip_1;
    // 0x8013509C: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
    skip_1:
    // 0x801350A0: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x801350A4: jal         0x801399B0
    // 0x801350A8: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    alLink(rdram, ctx);
        goto after_2;
    // 0x801350A8: or          $a1, $s3, $zero
    ctx->r5 = ctx->r19 | 0;
    after_2:
    // 0x801350AC: b           L_801350C0
    // 0x801350B0: nop

        goto L_801350C0;
    // 0x801350B0: nop

    // 0x801350B4: sw          $zero, 0x0($s0)
    MEM_W(0X0, ctx->r16) = 0;
L_801350B8:
    // 0x801350B8: sw          $zero, 0x4($s0)
    MEM_W(0X4, ctx->r16) = 0;
    // 0x801350BC: or          $s3, $s0, $zero
    ctx->r19 = ctx->r16 | 0;
L_801350C0:
    // 0x801350C0: beq         $s1, $zero, L_801350DC
    if (ctx->r17 == 0) {
        // 0x801350C4: or          $v1, $s2, $zero
        ctx->r3 = ctx->r18 | 0;
            goto L_801350DC;
    }
    // 0x801350C4: or          $v1, $s2, $zero
    ctx->r3 = ctx->r18 | 0;
    // 0x801350C8: lw          $v0, 0x8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X8);
    // 0x801350CC: lw          $t6, 0x8($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X8);
    // 0x801350D0: subu        $s2, $s2, $v0
    ctx->r18 = SUB32(ctx->r18, ctx->r2);
    // 0x801350D4: addu        $t7, $t6, $v0
    ctx->r15 = ADD32(ctx->r14, ctx->r2);
    // 0x801350D8: sw          $t7, 0x8($s1)
    MEM_W(0X8, ctx->r17) = ctx->r15;
L_801350DC:
    // 0x801350DC: sw          $v1, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r3;
L_801350E0:
    // 0x801350E0: bne         $s1, $zero, L_8013507C
    if (ctx->r17 != 0) {
        // 0x801350E4: or          $s0, $s1, $zero
        ctx->r16 = ctx->r17 | 0;
            goto L_8013507C;
    }
    // 0x801350E4: or          $s0, $s1, $zero
    ctx->r16 = ctx->r17 | 0;
L_801350E8:
    // 0x801350E8: beq         $s3, $zero, L_80135150
    if (ctx->r19 == 0) {
        // 0x801350EC: or          $s0, $s3, $zero
        ctx->r16 = ctx->r19 | 0;
            goto L_80135150;
    }
    // 0x801350EC: or          $s0, $s3, $zero
    ctx->r16 = ctx->r19 | 0;
    // 0x801350F0: addiu       $s2, $s5, 0x48
    ctx->r18 = ADD32(ctx->r21, 0X48);
L_801350F4:
    // 0x801350F4: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x801350F8: lw          $t0, 0x24($s5)
    ctx->r8 = MEM_W(ctx->r21, 0X24);
    // 0x801350FC: lw          $s1, 0x0($s0)
    ctx->r17 = MEM_W(ctx->r16, 0X0);
    // 0x80135100: div         $zero, $t8, $s6
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r22))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r22)));
    // 0x80135104: mflo        $v0
    ctx->r2 = lo;
    // 0x80135108: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x8013510C: bne         $s6, $zero, L_80135118
    if (ctx->r22 != 0) {
        // 0x80135110: nop
    
            goto L_80135118;
    }
    // 0x80135110: nop

    // 0x80135114: break       7
    do_break(2148749588);
L_80135118:
    // 0x80135118: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8013511C: bne         $s6, $at, L_80135130
    if (ctx->r22 != ctx->r1) {
        // 0x80135120: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80135130;
    }
    // 0x80135120: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80135124: bne         $t8, $at, L_80135130
    if (ctx->r24 != ctx->r1) {
        // 0x80135128: nop
    
            goto L_80135130;
    }
    // 0x80135128: nop

    // 0x8013512C: break       6
    do_break(2148749612);
L_80135130:
    // 0x80135130: multu       $t0, $v0
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135134: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80135138: mflo        $t9
    ctx->r25 = lo;
    // 0x8013513C: sw          $t9, 0x8($s0)
    MEM_W(0X8, ctx->r16) = ctx->r25;
    // 0x80135140: jal         0x80135178
    // 0x80135144: nop

    __CSPRepostEvent(rdram, ctx);
        goto after_3;
    // 0x80135144: nop

    after_3:
    // 0x80135148: bne         $s1, $zero, L_801350F4
    if (ctx->r17 != 0) {
        // 0x8013514C: or          $s0, $s1, $zero
        ctx->r16 = ctx->r17 | 0;
            goto L_801350F4;
    }
    // 0x8013514C: or          $s0, $s1, $zero
    ctx->r16 = ctx->r17 | 0;
L_80135150:
    // 0x80135150: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_80135154:
    // 0x80135154: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80135158: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x8013515C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80135160: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80135164: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80135168: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x8013516C: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80135170: jr          $ra
    // 0x80135174: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x80135174: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void __CSPRepostEvent(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80135178: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8013517C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80135180: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80135184: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80135188: jal         0x8013E050
    // 0x8013518C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    osSetIntMask_recomp(rdram, ctx);
        goto after_0;
    // 0x8013518C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    after_0:
    // 0x80135190: lw          $v1, 0x20($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X20);
    // 0x80135194: addiu       $at, $zero, -0x8
    ctx->r1 = ADD32(0, -0X8);
    // 0x80135198: lw          $a3, 0x24($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X24);
    // 0x8013519C: sw          $v0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r2;
    // 0x801351A0: beq         $v1, $at, L_80135200
    if (ctx->r3 == ctx->r1) {
        // 0x801351A4: addiu       $a1, $v1, 0x8
        ctx->r5 = ADD32(ctx->r3, 0X8);
            goto L_80135200;
    }
    // 0x801351A4: addiu       $a1, $v1, 0x8
    ctx->r5 = ADD32(ctx->r3, 0X8);
    // 0x801351A8: lw          $a0, 0x0($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X0);
L_801351AC:
    // 0x801351AC: bnel        $a0, $zero, L_801351C8
    if (ctx->r4 != 0) {
        // 0x801351B0: lw          $v0, 0x8($a3)
        ctx->r2 = MEM_W(ctx->r7, 0X8);
            goto L_801351C8;
    }
    goto skip_0;
    // 0x801351B0: lw          $v0, 0x8($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X8);
    skip_0:
    // 0x801351B4: jal         0x801399B0
    // 0x801351B8: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    alLink(rdram, ctx);
        goto after_1;
    // 0x801351B8: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_1:
    // 0x801351BC: b           L_80135200
    // 0x801351C0: nop

        goto L_80135200;
    // 0x801351C0: nop

    // 0x801351C4: lw          $v0, 0x8($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X8);
L_801351C8:
    // 0x801351C8: lw          $v1, 0x8($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X8);
    // 0x801351CC: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x801351D0: beq         $at, $zero, L_801351F0
    if (ctx->r1 == 0) {
        // 0x801351D4: subu        $t7, $v0, $v1
        ctx->r15 = SUB32(ctx->r2, ctx->r3);
            goto L_801351F0;
    }
    // 0x801351D4: subu        $t7, $v0, $v1
    ctx->r15 = SUB32(ctx->r2, ctx->r3);
    // 0x801351D8: subu        $t6, $v1, $v0
    ctx->r14 = SUB32(ctx->r3, ctx->r2);
    // 0x801351DC: sw          $t6, 0x8($a0)
    MEM_W(0X8, ctx->r4) = ctx->r14;
    // 0x801351E0: jal         0x801399B0
    // 0x801351E4: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    alLink(rdram, ctx);
        goto after_2;
    // 0x801351E4: or          $a0, $a3, $zero
    ctx->r4 = ctx->r7 | 0;
    after_2:
    // 0x801351E8: b           L_80135200
    // 0x801351EC: nop

        goto L_80135200;
    // 0x801351EC: nop

L_801351F0:
    // 0x801351F0: sw          $t7, 0x8($a3)
    MEM_W(0X8, ctx->r7) = ctx->r15;
    // 0x801351F4: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    // 0x801351F8: bnel        $a1, $zero, L_801351AC
    if (ctx->r5 != 0) {
        // 0x801351FC: lw          $a0, 0x0($a1)
        ctx->r4 = MEM_W(ctx->r5, 0X0);
            goto L_801351AC;
    }
    goto skip_1;
    // 0x801351FC: lw          $a0, 0x0($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X0);
    skip_1:
L_80135200:
    // 0x80135200: jal         0x8013E050
    // 0x80135204: lw          $a0, 0x1C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X1C);
    osSetIntMask_recomp(rdram, ctx);
        goto after_3;
    // 0x80135204: lw          $a0, 0x1C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X1C);
    after_3:
    // 0x80135208: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8013520C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80135210: jr          $ra
    // 0x80135214: nop

    return;
    // 0x80135214: nop

;}
RECOMP_FUNC void __setUsptFromTempo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80135218: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8013521C: lh          $v0, 0x46E0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X46E0);
    // 0x80135220: mtc1        $a1, $f12
    ctx->f12.u32l = ctx->r5;
    // 0x80135224: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80135228: bnel        $v0, $zero, L_80135240
    if (ctx->r2 != 0) {
        // 0x8013522C: mtc1        $v0, $f4
        ctx->f4.u32l = ctx->r2;
            goto L_80135240;
    }
    goto skip_0;
    // 0x8013522C: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    skip_0:
    // 0x80135230: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80135234: b           L_80135254
    // 0x80135238: lw          $v0, 0x18($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X18);
        goto L_80135254;
    // 0x80135238: lw          $v0, 0x18($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X18);
    // 0x8013523C: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
L_80135240:
    // 0x80135240: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x80135244: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80135248: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8013524C: div.s       $f0, $f6, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80135250: lw          $v0, 0x18($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X18);
L_80135254:
    // 0x80135254: lui         $at, 0x43F4
    ctx->r1 = S32(0X43F4 << 16);
    // 0x80135258: beql        $v0, $zero, L_801352C4
    if (ctx->r2 == 0) {
        // 0x8013525C: mtc1        $at, $f2
        ctx->f2.u32l = ctx->r1;
            goto L_801352C4;
    }
    goto skip_1;
    // 0x8013525C: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    skip_1:
    // 0x80135260: lwc1        $f10, 0x8($v0)
    ctx->f10.u32l = MEM_W(ctx->r2, 0X8);
    // 0x80135264: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80135268: mul.s       $f16, $f12, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = MUL_S(ctx->f12.fl, ctx->f10.fl);
    // 0x8013526C: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x80135270: mfc1        $t7, $f18
    ctx->r15 = (int32_t)ctx->f18.u32l;
    // 0x80135274: nop

    // 0x80135278: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x8013527C: nop

    // 0x80135280: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80135284: div.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = DIV_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80135288: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8013528C: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x80135290: nop

    // 0x80135294: sw          $t9, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r25;
    // 0x80135298: lwc1        $f16, 0x8($v0)
    ctx->f16.u32l = MEM_W(ctx->r2, 0X8);
    // 0x8013529C: mul.s       $f18, $f12, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = MUL_S(ctx->f12.fl, ctx->f16.fl);
    // 0x801352A0: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x801352A4: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x801352A8: nop

    // 0x801352AC: mtc1        $t1, $f6
    ctx->f6.u32l = ctx->r9;
    // 0x801352B0: nop

    // 0x801352B4: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x801352B8: jr          $ra
    // 0x801352BC: swc1        $f8, 0x6568($at)
    MEM_W(0X6568, ctx->r1) = ctx->f8.u32l;
    return;
    // 0x801352BC: swc1        $f8, 0x6568($at)
    MEM_W(0X6568, ctx->r1) = ctx->f8.u32l;
    // 0x801352C0: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
L_801352C4:
    // 0x801352C4: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x801352C8: div.s       $f10, $f2, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = DIV_S(ctx->f2.fl, ctx->f0.fl);
    // 0x801352CC: trunc.w.s   $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x801352D0: mfc1        $t3, $f16
    ctx->r11 = (int32_t)ctx->f16.u32l;
    // 0x801352D4: nop

    // 0x801352D8: sw          $t3, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r11;
    // 0x801352DC: swc1        $f2, 0x6568($at)
    MEM_W(0X6568, ctx->r1) = ctx->f2.u32l;
    // 0x801352E0: jr          $ra
    // 0x801352E4: nop

    return;
    // 0x801352E4: nop

;}
RECOMP_FUNC void func_801352E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801352E8: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x801352EC: sdc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X18, ctx->r29);
    // 0x801352F0: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x801352F4: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x801352F8: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x801352FC: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x80135300: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80135304: lui         $at, 0x4050
    ctx->r1 = S32(0X4050 << 16);
    // 0x80135308: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x8013530C: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x80135310: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80135314: lui         $s3, 0x8015
    ctx->r19 = S32(0X8015 << 16);
    // 0x80135318: lui         $s4, 0x8015
    ctx->r20 = S32(0X8015 << 16);
    // 0x8013531C: lui         $s6, 0x8028
    ctx->r22 = S32(0X8028 << 16);
    // 0x80135320: lui         $s7, 0x8015
    ctx->r23 = S32(0X8015 << 16);
    // 0x80135324: lui         $fp, 0x8028
    ctx->r30 = S32(0X8028 << 16);
    // 0x80135328: mtc1        $at, $f21
    ctx->f_odd[(21 - 1) * 2] = ctx->r1;
    // 0x8013532C: mtc1        $zero, $f20
    ctx->f20.u32l = 0;
    // 0x80135330: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80135334: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x80135338: addiu       $fp, $fp, 0x6560
    ctx->r30 = ADD32(ctx->r30, 0X6560);
    // 0x8013533C: addiu       $s7, $s7, 0x5160
    ctx->r23 = ADD32(ctx->r23, 0X5160);
    // 0x80135340: addiu       $s6, $s6, 0x63C8
    ctx->r22 = ADD32(ctx->r22, 0X63C8);
    // 0x80135344: addiu       $s4, $s4, 0x5170
    ctx->r20 = ADD32(ctx->r20, 0X5170);
    // 0x80135348: addiu       $s3, $s3, 0x5168
    ctx->r19 = ADD32(ctx->r19, 0X5168);
    // 0x8013534C: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80135350: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x80135354: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
L_80135358:
    // 0x80135358: addu        $t6, $s3, $s0
    ctx->r14 = ADD32(ctx->r19, ctx->r16);
    // 0x8013535C: lbu         $a2, 0x0($t6)
    ctx->r6 = MEM_BU(ctx->r14, 0X0);
    // 0x80135360: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80135364: addiu       $t5, $t5, 0x5164
    ctx->r13 = ADD32(ctx->r13, 0X5164);
    // 0x80135368: bne         $s2, $a2, L_801353F0
    if (ctx->r18 != ctx->r6) {
        // 0x8013536C: addu        $s1, $s0, $t5
        ctx->r17 = ADD32(ctx->r16, ctx->r13);
            goto L_801353F0;
    }
    // 0x8013536C: addu        $s1, $s0, $t5
    ctx->r17 = ADD32(ctx->r16, ctx->r13);
    // 0x80135370: sll         $v0, $s0, 2
    ctx->r2 = S32(ctx->r16 << 2);
    // 0x80135374: addu        $t7, $s6, $v0
    ctx->r15 = ADD32(ctx->r22, ctx->r2);
    // 0x80135378: lw          $v1, 0x0($t7)
    ctx->r3 = MEM_W(ctx->r15, 0X0);
    // 0x8013537C: lw          $t9, 0x0($s7)
    ctx->r25 = MEM_W(ctx->r23, 0X0);
    // 0x80135380: lui         $t1, 0x8028
    ctx->r9 = S32(0X8028 << 16);
    // 0x80135384: lw          $t8, 0x1C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X1C);
    // 0x80135388: lw          $t0, 0x24($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X24);
    // 0x8013538C: addu        $t1, $t1, $v0
    ctx->r9 = ADD32(ctx->r9, ctx->r2);
    // 0x80135390: subu        $a0, $t8, $t9
    ctx->r4 = SUB32(ctx->r24, ctx->r25);
    // 0x80135394: div         $zero, $a0, $t0
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r8))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r8)));
    // 0x80135398: mflo        $a1
    ctx->r5 = lo;
    // 0x8013539C: mtc1        $a1, $f6
    ctx->f6.u32l = ctx->r5;
    // 0x801353A0: lw          $t1, 0x63CC($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X63CC);
    // 0x801353A4: bne         $t0, $zero, L_801353B0
    if (ctx->r8 != 0) {
        // 0x801353A8: nop
    
            goto L_801353B0;
    }
    // 0x801353A8: nop

    // 0x801353AC: break       7
    do_break(2148750252);
L_801353B0:
    // 0x801353B0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801353B4: bne         $t0, $at, L_801353C8
    if (ctx->r8 != ctx->r1) {
        // 0x801353B8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801353C8;
    }
    // 0x801353B8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801353BC: bne         $a0, $at, L_801353C8
    if (ctx->r4 != ctx->r1) {
        // 0x801353C0: nop
    
            goto L_801353C8;
    }
    // 0x801353C0: nop

    // 0x801353C4: break       6
    do_break(2148750276);
L_801353C8:
    // 0x801353C8: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x801353CC: lwc1        $f4, 0x8($t1)
    ctx->f4.u32l = MEM_W(ctx->r9, 0X8);
    // 0x801353D0: mul.s       $f10, $f4, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = MUL_S(ctx->f4.fl, ctx->f8.fl);
    // 0x801353D4: cvt.d.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f16.d = CVT_D_S(ctx->f10.fl);
    // 0x801353D8: mul.d       $f18, $f16, $f20
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 20);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f20.d); 
    ctx->f18.d = MUL_D(ctx->f16.d, ctx->f20.d);
    // 0x801353DC: trunc.w.d   $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x801353E0: mfc1        $t3, $f6
    ctx->r11 = (int32_t)ctx->f6.u32l;
    // 0x801353E4: nop

    // 0x801353E8: andi        $t4, $t3, 0x3F
    ctx->r12 = ctx->r11 & 0X3F;
    // 0x801353EC: sh          $t4, 0x0($fp)
    MEM_H(0X0, ctx->r30) = ctx->r12;
L_801353F0:
    // 0x801353F0: lb          $v0, 0x0($s1)
    ctx->r2 = MEM_B(ctx->r17, 0X0);
    // 0x801353F4: beql        $s5, $v0, L_801354D4
    if (ctx->r21 == ctx->r2) {
        // 0x801353F8: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_801354D4;
    }
    goto skip_0;
    // 0x801353F8: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x801353FC: bne         $s2, $a2, L_80135428
    if (ctx->r18 != ctx->r6) {
        // 0x80135400: sll         $a0, $s0, 24
        ctx->r4 = S32(ctx->r16 << 24);
            goto L_80135428;
    }
    // 0x80135400: sll         $a0, $s0, 24
    ctx->r4 = S32(ctx->r16 << 24);
    // 0x80135404: lb          $t6, 0x0($s4)
    ctx->r14 = MEM_B(ctx->r20, 0X0);
    // 0x80135408: beql        $t6, $v0, L_8013542C
    if (ctx->r14 == ctx->r2) {
        // 0x8013540C: sra         $t8, $a0, 24
        ctx->r24 = S32(SIGNED(ctx->r4) >> 24);
            goto L_8013542C;
    }
    goto skip_1;
    // 0x8013540C: sra         $t8, $a0, 24
    ctx->r24 = S32(SIGNED(ctx->r4) >> 24);
    skip_1:
    // 0x80135410: sll         $a0, $s0, 24
    ctx->r4 = S32(ctx->r16 << 24);
    // 0x80135414: sra         $t7, $a0, 24
    ctx->r15 = S32(SIGNED(ctx->r4) >> 24);
    // 0x80135418: jal         0x80132C48
    // 0x8013541C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    func_80132C48(rdram, ctx);
        goto after_0;
    // 0x8013541C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_0:
    // 0x80135420: b           L_801354D4
    // 0x80135424: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
        goto L_801354D4;
    // 0x80135424: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80135428:
    // 0x80135428: sra         $t8, $a0, 24
    ctx->r24 = S32(SIGNED(ctx->r4) >> 24);
L_8013542C:
    // 0x8013542C: jal         0x8013266C
    // 0x80135430: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    get_seqp_state(rdram, ctx);
        goto after_1;
    // 0x80135430: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    after_1:
    // 0x80135434: bnel        $v0, $zero, L_801354D4
    if (ctx->r2 != 0) {
        // 0x80135438: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_801354D4;
    }
    goto skip_2;
    // 0x80135438: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_2:
    // 0x8013543C: slti        $at, $s0, 0x2
    ctx->r1 = SIGNED(ctx->r16) < 0X2 ? 1 : 0;
    // 0x80135440: beql        $at, $zero, L_801354B0
    if (ctx->r1 == 0) {
        // 0x80135444: lb          $a0, 0x0($s1)
        ctx->r4 = MEM_B(ctx->r17, 0X0);
            goto L_801354B0;
    }
    goto skip_3;
    // 0x80135444: lb          $a0, 0x0($s1)
    ctx->r4 = MEM_B(ctx->r17, 0X0);
    skip_3:
    // 0x80135448: lb          $t9, 0x0($s4)
    ctx->r25 = MEM_B(ctx->r20, 0X0);
    // 0x8013544C: lb          $t0, 0x0($s1)
    ctx->r8 = MEM_B(ctx->r17, 0X0);
    // 0x80135450: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80135454: addiu       $v0, $v0, 0x5174
    ctx->r2 = ADD32(ctx->r2, 0X5174);
    // 0x80135458: bnel        $t9, $t0, L_80135478
    if (ctx->r25 != ctx->r8) {
        // 0x8013545C: addiu       $a0, $s0, 0x1
        ctx->r4 = ADD32(ctx->r16, 0X1);
            goto L_80135478;
    }
    goto skip_4;
    // 0x8013545C: addiu       $a0, $s0, 0x1
    ctx->r4 = ADD32(ctx->r16, 0X1);
    skip_4:
    // 0x80135460: lb          $t1, 0x0($v0)
    ctx->r9 = MEM_B(ctx->r2, 0X0);
    // 0x80135464: sb          $s5, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r21;
    // 0x80135468: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x8013546C: b           L_801354E4
    // 0x80135470: sb          $t2, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r10;
        goto L_801354E4;
    // 0x80135470: sb          $t2, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r10;
    // 0x80135474: addiu       $a0, $s0, 0x1
    ctx->r4 = ADD32(ctx->r16, 0X1);
L_80135478:
    // 0x80135478: bgez        $a0, L_8013548C
    if (SIGNED(ctx->r4) >= 0) {
        // 0x8013547C: andi        $t3, $a0, 0x1
        ctx->r11 = ctx->r4 & 0X1;
            goto L_8013548C;
    }
    // 0x8013547C: andi        $t3, $a0, 0x1
    ctx->r11 = ctx->r4 & 0X1;
    // 0x80135480: beq         $t3, $zero, L_8013548C
    if (ctx->r11 == 0) {
        // 0x80135484: nop
    
            goto L_8013548C;
    }
    // 0x80135484: nop

    // 0x80135488: addiu       $t3, $t3, -0x2
    ctx->r11 = ADD32(ctx->r11, -0X2);
L_8013548C:
    // 0x8013548C: sll         $t4, $t3, 24
    ctx->r12 = S32(ctx->r11 << 24);
    // 0x80135490: sra         $a0, $t4, 24
    ctx->r4 = S32(SIGNED(ctx->r12) >> 24);
    // 0x80135494: addu        $t6, $s3, $a0
    ctx->r14 = ADD32(ctx->r19, ctx->r4);
    // 0x80135498: lbu         $t7, 0x0($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X0);
    // 0x8013549C: bnel        $s2, $t7, L_801354B0
    if (ctx->r18 != ctx->r15) {
        // 0x801354A0: lb          $a0, 0x0($s1)
        ctx->r4 = MEM_B(ctx->r17, 0X0);
            goto L_801354B0;
    }
    goto skip_5;
    // 0x801354A0: lb          $a0, 0x0($s1)
    ctx->r4 = MEM_B(ctx->r17, 0X0);
    skip_5:
    // 0x801354A4: jal         0x80132C48
    // 0x801354A8: nop

    func_80132C48(rdram, ctx);
        goto after_2;
    // 0x801354A8: nop

    after_2:
    // 0x801354AC: lb          $a0, 0x0($s1)
    ctx->r4 = MEM_B(ctx->r17, 0X0);
L_801354B0:
    // 0x801354B0: sll         $a1, $s0, 24
    ctx->r5 = S32(ctx->r16 << 24);
    // 0x801354B4: sra         $t0, $a1, 24
    ctx->r8 = S32(SIGNED(ctx->r5) >> 24);
    // 0x801354B8: addiu       $a0, $a0, -0x1
    ctx->r4 = ADD32(ctx->r4, -0X1);
    // 0x801354BC: sll         $t8, $a0, 24
    ctx->r24 = S32(ctx->r4 << 24);
    // 0x801354C0: sra         $a0, $t8, 24
    ctx->r4 = S32(SIGNED(ctx->r24) >> 24);
    // 0x801354C4: jal         0x801326A8
    // 0x801354C8: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    func_801326A8(rdram, ctx);
        goto after_3;
    // 0x801354C8: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    after_3:
    // 0x801354CC: sb          $s5, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r21;
    // 0x801354D0: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_801354D4:
    // 0x801354D4: sll         $t1, $s0, 24
    ctx->r9 = S32(ctx->r16 << 24);
    // 0x801354D8: sra         $t2, $t1, 24
    ctx->r10 = S32(SIGNED(ctx->r9) >> 24);
    // 0x801354DC: blez        $t2, L_80135358
    if (SIGNED(ctx->r10) <= 0) {
        // 0x801354E0: or          $s0, $t2, $zero
        ctx->r16 = ctx->r10 | 0;
            goto L_80135358;
    }
    // 0x801354E0: or          $s0, $t2, $zero
    ctx->r16 = ctx->r10 | 0;
L_801354E4:
    // 0x801354E4: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x801354E8: ldc1        $f20, 0x18($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X18);
    // 0x801354EC: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x801354F0: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x801354F4: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x801354F8: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x801354FC: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x80135500: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x80135504: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x80135508: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x8013550C: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x80135510: jr          $ra
    // 0x80135514: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x80135514: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void func_80135518(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80135518: lw          $t6, 0x2C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X2C);
    // 0x8013551C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80135520: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80135524: bne         $t6, $at, L_801355A0
    if (ctx->r14 != ctx->r1) {
        // 0x80135528: nop
    
            goto L_801355A0;
    }
    // 0x80135528: nop

    // 0x8013552C: lh          $t7, 0x46E0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X46E0);
    // 0x80135530: lui         $v0, 0x8028
    ctx->r2 = S32(0X8028 << 16);
    // 0x80135534: addiu       $v0, $v0, 0x6564
    ctx->r2 = ADD32(ctx->r2, 0X6564);
    // 0x80135538: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x8013553C: lwc1        $f6, 0x0($v0)
    ctx->f6.u32l = MEM_W(ctx->r2, 0X0);
    // 0x80135540: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x80135544: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80135548: c.eq.s      $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    c1cs = ctx->f6.fl == ctx->f0.fl;
    // 0x8013554C: nop

    // 0x80135550: bc1t        L_801355A0
    if (c1cs) {
        // 0x80135554: nop
    
            goto L_801355A0;
    }
    // 0x80135554: nop

    // 0x80135558: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8013555C: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x80135560: swc1        $f0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->f0.u32l;
    // 0x80135564: div.s       $f2, $f0, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f2.fl = DIV_S(ctx->f0.fl, ctx->f8.fl);
    // 0x80135568: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8013556C: c.eq.s      $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f2.fl == ctx->f10.fl;
    // 0x80135570: nop

    // 0x80135574: bc1f        L_80135584
    if (!c1cs) {
        // 0x80135578: nop
    
            goto L_80135584;
    }
    // 0x80135578: nop

    // 0x8013557C: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    // 0x80135580: nop

L_80135584:
    // 0x80135584: lui         $at, 0x8028
    ctx->r1 = S32(0X8028 << 16);
    // 0x80135588: lwc1        $f16, 0x6568($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X6568);
    // 0x8013558C: div.s       $f18, $f16, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = DIV_S(ctx->f16.fl, ctx->f2.fl);
    // 0x80135590: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80135594: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x80135598: nop

    // 0x8013559C: sw          $t9, 0x24($a0)
    MEM_W(0X24, ctx->r4) = ctx->r25;
L_801355A0:
    // 0x801355A0: jr          $ra
    // 0x801355A4: nop

    return;
    // 0x801355A4: nop

;}
RECOMP_FUNC void init2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801355B0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x801355B4: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x801355B8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801355BC: addiu       $t6, $t6, -0x2DD0
    ctx->r14 = ADD32(ctx->r14, -0X2DD0);
    // 0x801355C0: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801355C4: lui         $a2, 0x8013
    ctx->r6 = S32(0X8013 << 16);
    // 0x801355C8: addiu       $t7, $zero, 0xA
    ctx->r15 = ADD32(0, 0XA);
    // 0x801355CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x801355D0: addiu       $a2, $a2, 0x5604
    ctx->r6 = ADD32(ctx->r6, 0X5604);
    // 0x801355D4: addiu       $a0, $a0, 0x68D0
    ctx->r4 = ADD32(ctx->r4, 0X68D0);
    // 0x801355D8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x801355DC: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x801355E0: jal         0x80139AA0
    // 0x801355E4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    osCreateThread_recomp(rdram, ctx);
        goto after_0;
    // 0x801355E4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_0:
    // 0x801355E8: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x801355EC: jal         0x801381E0
    // 0x801355F0: addiu       $a0, $a0, 0x68D0
    ctx->r4 = ADD32(ctx->r4, 0X68D0);
    osStartThread_recomp(rdram, ctx);
        goto after_1;
    // 0x801355F0: addiu       $a0, $a0, 0x68D0
    ctx->r4 = ADD32(ctx->r4, 0X68D0);
    after_1:
    // 0x801355F4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x801355F8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x801355FC: jr          $ra
    // 0x80135600: nop

    return;
    // 0x80135600: nop

;}
RECOMP_FUNC void thread1(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80135604: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80135608: lui         $t6, 0x8029
    ctx->r14 = S32(0X8029 << 16);
    // 0x8013560C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80135610: addiu       $t6, $t6, -0x71D0
    ctx->r14 = ADD32(ctx->r14, -0X71D0);
    // 0x80135614: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80135618: lui         $a2, 0x8013
    ctx->r6 = S32(0X8013 << 16);
    // 0x8013561C: addiu       $t7, $zero, 0xA
    ctx->r15 = ADD32(0, 0XA);
    // 0x80135620: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80135624: addiu       $a2, $a2, -0x64F0
    ctx->r6 = ADD32(ctx->r6, -0X64F0);
    // 0x80135628: addiu       $a0, $a0, 0x6570
    ctx->r4 = ADD32(ctx->r4, 0X6570);
    // 0x8013562C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80135630: addiu       $a1, $zero, 0x6
    ctx->r5 = ADD32(0, 0X6);
    // 0x80135634: jal         0x80139AA0
    // 0x80135638: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    osCreateThread_recomp(rdram, ctx);
        goto after_0;
    // 0x80135638: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_0:
    // 0x8013563C: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80135640: addiu       $t8, $t8, -0x4FD0
    ctx->r24 = ADD32(ctx->r24, -0X4FD0);
    // 0x80135644: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x80135648: lui         $a2, 0x8013
    ctx->r6 = S32(0X8013 << 16);
    // 0x8013564C: addiu       $t9, $zero, 0x8
    ctx->r25 = ADD32(0, 0X8);
    // 0x80135650: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80135654: addiu       $a2, $a2, -0x5DA0
    ctx->r6 = ADD32(ctx->r6, -0X5DA0);
    // 0x80135658: addiu       $a0, $a0, 0x6720
    ctx->r4 = ADD32(ctx->r4, 0X6720);
    // 0x8013565C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80135660: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x80135664: jal         0x80139AA0
    // 0x80135668: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    osCreateThread_recomp(rdram, ctx);
        goto after_1;
    // 0x80135668: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_1:
    // 0x8013566C: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80135670: lui         $a2, 0x8029
    ctx->r6 = S32(0X8029 << 16);
    // 0x80135674: addiu       $a2, $a2, -0x9C0
    ctx->r6 = ADD32(ctx->r6, -0X9C0);
    // 0x80135678: addiu       $a1, $a1, -0x2FD0
    ctx->r5 = ADD32(ctx->r5, -0X2FD0);
    // 0x8013567C: addiu       $a0, $zero, 0x96
    ctx->r4 = ADD32(0, 0X96);
    // 0x80135680: jal         0x8013E0F0
    // 0x80135684: addiu       $a3, $zero, 0x320
    ctx->r7 = ADD32(0, 0X320);
    osCreatePiManager_recomp(rdram, ctx);
        goto after_2;
    // 0x80135684: addiu       $a3, $zero, 0x320
    ctx->r7 = ADD32(0, 0X320);
    after_2:
    // 0x80135688: lui         $a0, 0x8028
    ctx->r4 = S32(0X8028 << 16);
    // 0x8013568C: jal         0x801381E0
    // 0x80135690: addiu       $a0, $a0, 0x6570
    ctx->r4 = ADD32(ctx->r4, 0X6570);
    osStartThread_recomp(rdram, ctx);
        goto after_3;
    // 0x80135690: addiu       $a0, $a0, 0x6570
    ctx->r4 = ADD32(ctx->r4, 0X6570);
    after_3:
    // 0x80135694: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80135698: jal         0x8013E280
    // 0x8013569C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    osSetThreadPri_recomp(rdram, ctx);
        goto after_4;
    // 0x8013569C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    after_4:
L_801356A0:
    // 0x801356A0: b           L_801356A0
    pause_self(rdram);
    // 0x801356A4: nop

    // 0x801356A8: nop

    // 0x801356AC: nop

    // 0x801356B0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x801356B4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x801356B8: jr          $ra
    // 0x801356BC: nop

    return;
    // 0x801356BC: nop

;}
RECOMP_FUNC void func_801356C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801356C0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x801356C4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801356C8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x801356CC: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801356D0: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x801356D4: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x801356D8: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x801356DC: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x801356E0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801356E4: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x801356E8: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x801356EC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801356F0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x801356F4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801356F8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x801356FC: lbu         $t0, 0x43($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X43);
    // 0x80135700: beq         $t0, $at, L_80135810
    if (ctx->r8 == ctx->r1) {
        // 0x80135704: addiu       $at, $zero, 0x10
        ctx->r1 = ADD32(0, 0X10);
            goto L_80135810;
    }
    // 0x80135704: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x80135708: bne         $t0, $at, L_80135914
    if (ctx->r8 != ctx->r1) {
        // 0x8013570C: lui         $a0, 0x8016
        ctx->r4 = S32(0X8016 << 16);
            goto L_80135914;
    }
    // 0x8013570C: lui         $a0, 0x8016
    ctx->r4 = S32(0X8016 << 16);
    // 0x80135710: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135714: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    // 0x80135718: lui         $t0, 0xFD10
    ctx->r8 = S32(0XFD10 << 16);
    // 0x8013571C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80135720: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80135724: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80135728: sw          $a3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r7;
    // 0x8013572C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135730: lui         $t1, 0xE600
    ctx->r9 = S32(0XE600 << 16);
    // 0x80135734: lui         $t7, 0x708
    ctx->r15 = S32(0X708 << 16);
    // 0x80135738: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8013573C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80135740: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135744: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x80135748: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8013574C: ori         $t7, $t7, 0x200
    ctx->r15 = ctx->r15 | 0X200;
    // 0x80135750: lui         $t6, 0xF510
    ctx->r14 = S32(0XF510 << 16);
    // 0x80135754: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80135758: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x8013575C: sw          $a3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r7;
    // 0x80135760: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80135764: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135768: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8013576C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80135770: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80135774: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80135778: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8013577C: lui         $t6, 0x73F
    ctx->r14 = S32(0X73F << 16);
    // 0x80135780: ori         $t6, $t6, 0xF100
    ctx->r14 = ctx->r14 | 0XF100;
    // 0x80135784: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80135788: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8013578C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135790: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x80135794: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135798: lui         $t5, 0xF300
    ctx->r13 = S32(0XF300 << 16);
    // 0x8013579C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x801357A0: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x801357A4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x801357A8: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x801357AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801357B0: lui         $t5, 0x8
    ctx->r13 = S32(0X8 << 16);
    // 0x801357B4: lui         $t9, 0xF510
    ctx->r25 = S32(0XF510 << 16);
    // 0x801357B8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x801357BC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x801357C0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801357C4: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x801357C8: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801357CC: ori         $t9, $t9, 0x1000
    ctx->r25 = ctx->r25 | 0X1000;
    // 0x801357D0: ori         $t5, $t5, 0x200
    ctx->r13 = ctx->r13 | 0X200;
    // 0x801357D4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x801357D8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x801357DC: lw          $t1, 0x24($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X24);
    // 0x801357E0: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x801357E4: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x801357E8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x801357EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801357F0: lui         $t8, 0x7
    ctx->r24 = S32(0X7 << 16);
    // 0x801357F4: ori         $t8, $t8, 0xC07C
    ctx->r24 = ctx->r24 | 0XC07C;
    // 0x801357F8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801357FC: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80135800: lui         $t7, 0xF200
    ctx->r15 = S32(0XF200 << 16);
    // 0x80135804: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80135808: b           L_80135928
    // 0x8013580C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
        goto L_80135928;
    // 0x8013580C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
L_80135810:
    // 0x80135810: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135814: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    // 0x80135818: lui         $t1, 0xE600
    ctx->r9 = S32(0XE600 << 16);
    // 0x8013581C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80135820: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135824: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135828: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x8013582C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135830: lui         $t6, 0xFD88
    ctx->r14 = S32(0XFD88 << 16);
    // 0x80135834: lui         $t8, 0xFD90
    ctx->r24 = S32(0XFD90 << 16);
    // 0x80135838: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x8013583C: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80135840: sw          $a3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r7;
    // 0x80135844: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80135848: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8013584C: lui         $t6, 0x708
    ctx->r14 = S32(0X708 << 16);
    // 0x80135850: ori         $t6, $t6, 0x200
    ctx->r14 = ctx->r14 | 0X200;
    // 0x80135854: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80135858: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x8013585C: sw          $a3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r7;
    // 0x80135860: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80135864: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135868: lui         $t5, 0xF590
    ctx->r13 = S32(0XF590 << 16);
    // 0x8013586C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80135870: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135874: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80135878: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x8013587C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135880: lui         $t5, 0x71F
    ctx->r13 = S32(0X71F << 16);
    // 0x80135884: ori         $t5, $t5, 0xF200
    ctx->r13 = ctx->r13 | 0XF200;
    // 0x80135888: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8013588C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80135890: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135894: sw          $t1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r9;
    // 0x80135898: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8013589C: lui         $t9, 0xF300
    ctx->r25 = S32(0XF300 << 16);
    // 0x801358A0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x801358A4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x801358A8: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x801358AC: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x801358B0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801358B4: lui         $t9, 0x8
    ctx->r25 = S32(0X8 << 16);
    // 0x801358B8: lui         $t8, 0xF588
    ctx->r24 = S32(0XF588 << 16);
    // 0x801358BC: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801358C0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x801358C4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801358C8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x801358CC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801358D0: ori         $t8, $t8, 0x800
    ctx->r24 = ctx->r24 | 0X800;
    // 0x801358D4: ori         $t9, $t9, 0x200
    ctx->r25 = ctx->r25 | 0X200;
    // 0x801358D8: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x801358DC: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x801358E0: lw          $t1, 0x24($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X24);
    // 0x801358E4: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x801358E8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x801358EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801358F0: lui         $t7, 0x7
    ctx->r15 = S32(0X7 << 16);
    // 0x801358F4: ori         $t7, $t7, 0xC07C
    ctx->r15 = ctx->r15 | 0XC07C;
    // 0x801358F8: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x801358FC: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80135900: lui         $t6, 0xF200
    ctx->r14 = S32(0XF200 << 16);
    // 0x80135904: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80135908: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8013590C: b           L_80135928
    // 0x80135910: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
        goto L_80135928;
    // 0x80135910: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
L_80135914:
    // 0x80135914: jal         0x8013966C
    // 0x80135918: addiu       $a0, $a0, -0x4FB0
    ctx->r4 = ADD32(ctx->r4, -0X4FB0);
    osSyncPrintf(rdram, ctx);
        goto after_0;
    // 0x80135918: addiu       $a0, $a0, -0x4FB0
    ctx->r4 = ADD32(ctx->r4, -0X4FB0);
    after_0:
    // 0x8013591C: lw          $a2, 0x20($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X20);
    // 0x80135920: lw          $t1, 0x24($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X24);
    // 0x80135924: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
L_80135928:
    // 0x80135928: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x8013592C: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x80135930: or          $a1, $a2, $zero
    ctx->r5 = ctx->r6 | 0;
    // 0x80135934: addiu       $t8, $t0, 0x8
    ctx->r24 = ADD32(ctx->r8, 0X8);
    // 0x80135938: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x8013593C: lw          $t9, 0x28($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X28);
    // 0x80135940: lw          $t8, 0x2C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X2C);
    // 0x80135944: sll         $t2, $t1, 2
    ctx->r10 = S32(ctx->r9 << 2);
    // 0x80135948: addu        $t5, $a2, $t9
    ctx->r13 = ADD32(ctx->r6, ctx->r25);
    // 0x8013594C: sll         $t6, $t5, 18
    ctx->r14 = S32(ctx->r13 << 18);
    // 0x80135950: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80135954: blez        $t7, L_80135964
    if (SIGNED(ctx->r15) <= 0) {
        // 0x80135958: addu        $t9, $t1, $t8
        ctx->r25 = ADD32(ctx->r9, ctx->r24);
            goto L_80135964;
    }
    // 0x80135958: addu        $t9, $t1, $t8
    ctx->r25 = ADD32(ctx->r9, ctx->r24);
    // 0x8013595C: b           L_80135968
    // 0x80135960: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
        goto L_80135968;
    // 0x80135960: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
L_80135964:
    // 0x80135964: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80135968:
    // 0x80135968: sll         $t5, $t9, 18
    ctx->r13 = S32(ctx->r25 << 18);
    // 0x8013596C: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80135970: blez        $t6, L_80135980
    if (SIGNED(ctx->r14) <= 0) {
        // 0x80135974: andi        $t9, $a0, 0xFFF
        ctx->r25 = ctx->r4 & 0XFFF;
            goto L_80135980;
    }
    // 0x80135974: andi        $t9, $a0, 0xFFF
    ctx->r25 = ctx->r4 & 0XFFF;
    // 0x80135978: b           L_80135984
    // 0x8013597C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
        goto L_80135984;
    // 0x8013597C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_80135980:
    // 0x80135980: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_80135984:
    // 0x80135984: andi        $t7, $v1, 0xFFF
    ctx->r15 = ctx->r3 & 0XFFF;
    // 0x80135988: or          $t8, $t7, $at
    ctx->r24 = ctx->r15 | ctx->r1;
    // 0x8013598C: sll         $t5, $t9, 12
    ctx->r13 = S32(ctx->r25 << 12);
    // 0x80135990: sll         $t7, $a1, 18
    ctx->r15 = S32(ctx->r5 << 18);
    // 0x80135994: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80135998: or          $t6, $t8, $t5
    ctx->r14 = ctx->r24 | ctx->r13;
    // 0x8013599C: sw          $t6, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r14;
    // 0x801359A0: blez        $t9, L_801359B0
    if (SIGNED(ctx->r25) <= 0) {
        // 0x801359A4: or          $a1, $t9, $zero
        ctx->r5 = ctx->r25 | 0;
            goto L_801359B0;
    }
    // 0x801359A4: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x801359A8: b           L_801359B4
    // 0x801359AC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
        goto L_801359B4;
    // 0x801359AC: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
L_801359B0:
    // 0x801359B0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_801359B4:
    // 0x801359B4: sll         $a3, $t2, 16
    ctx->r7 = S32(ctx->r10 << 16);
    // 0x801359B8: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x801359BC: blez        $t8, L_801359CC
    if (SIGNED(ctx->r24) <= 0) {
        // 0x801359C0: or          $a3, $t8, $zero
        ctx->r7 = ctx->r24 | 0;
            goto L_801359CC;
    }
    // 0x801359C0: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x801359C4: b           L_801359D0
    // 0x801359C8: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
        goto L_801359D0;
    // 0x801359C8: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_801359CC:
    // 0x801359CC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_801359D0:
    // 0x801359D0: andi        $t6, $a0, 0xFFF
    ctx->r14 = ctx->r4 & 0XFFF;
    // 0x801359D4: sll         $t7, $t6, 12
    ctx->r15 = S32(ctx->r14 << 12);
    // 0x801359D8: andi        $t5, $v1, 0xFFF
    ctx->r13 = ctx->r3 & 0XFFF;
    // 0x801359DC: or          $t9, $t5, $t7
    ctx->r25 = ctx->r13 | ctx->r15;
    // 0x801359E0: sw          $t9, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r25;
    // 0x801359E4: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x801359E8: lui         $t6, 0xB400
    ctx->r14 = S32(0XB400 << 16);
    // 0x801359EC: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x801359F0: addiu       $t8, $t3, 0x8
    ctx->r24 = ADD32(ctx->r11, 0X8);
    // 0x801359F4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x801359F8: bgez        $a1, L_80135A8C
    if (SIGNED(ctx->r5) >= 0) {
        // 0x801359FC: sw          $t6, 0x0($t3)
        MEM_W(0X0, ctx->r11) = ctx->r14;
            goto L_80135A8C;
    }
    // 0x801359FC: sw          $t6, 0x0($t3)
    MEM_W(0X0, ctx->r11) = ctx->r14;
    // 0x80135A00: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80135A04: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80135A08: lwc1        $f4, 0x38($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X38);
    // 0x80135A0C: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x80135A10: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80135A14: div.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = DIV_S(ctx->f4.fl, ctx->f6.fl);
    // 0x80135A18: div.s       $f2, $f10, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f2.fl = DIV_S(ctx->f10.fl, ctx->f8.fl);
    // 0x80135A1C: trunc.w.s   $f16, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    ctx->f16.u32l = TRUNC_W_S(ctx->f2.fl);
    // 0x80135A20: mfc1        $v1, $f16
    ctx->r3 = (int32_t)ctx->f16.u32l;
    // 0x80135A24: nop

    // 0x80135A28: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x80135A2C: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80135A30: bgez        $t9, L_80135A60
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80135A34: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_80135A60;
    }
    // 0x80135A34: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x80135A38: multu       $a1, $t9
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135A3C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135A40: mflo        $v0
    ctx->r2 = lo;
    // 0x80135A44: sra         $t8, $v0, 7
    ctx->r24 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135A48: blez        $t8, L_80135A58
    if (SIGNED(ctx->r24) <= 0) {
        // 0x80135A4C: nop
    
            goto L_80135A58;
    }
    // 0x80135A4C: nop

    // 0x80135A50: b           L_80135AA8
    // 0x80135A54: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
        goto L_80135AA8;
    // 0x80135A54: or          $t0, $t8, $zero
    ctx->r8 = ctx->r24 | 0;
L_80135A58:
    // 0x80135A58: b           L_80135AA8
    // 0x80135A5C: or          $t0, $v1, $zero
    ctx->r8 = ctx->r3 | 0;
        goto L_80135AA8;
    // 0x80135A5C: or          $t0, $v1, $zero
    ctx->r8 = ctx->r3 | 0;
L_80135A60:
    // 0x80135A60: multu       $a1, $v1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135A64: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135A68: mflo        $v0
    ctx->r2 = lo;
    // 0x80135A6C: sra         $t6, $v0, 7
    ctx->r14 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135A70: bgez        $t6, L_80135A80
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80135A74: nop
    
            goto L_80135A80;
    }
    // 0x80135A74: nop

    // 0x80135A78: b           L_80135A80
    // 0x80135A7C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
        goto L_80135A80;
    // 0x80135A7C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_80135A80:
    // 0x80135A80: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x80135A84: b           L_80135AA8
    // 0x80135A88: or          $t0, $v0, $zero
    ctx->r8 = ctx->r2 | 0;
        goto L_80135AA8;
    // 0x80135A88: or          $t0, $v0, $zero
    ctx->r8 = ctx->r2 | 0;
L_80135A8C:
    // 0x80135A8C: lwc1        $f18, 0x38($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X38);
    // 0x80135A90: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80135A94: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x80135A98: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80135A9C: div.s       $f6, $f18, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = DIV_S(ctx->f18.fl, ctx->f4.fl);
    // 0x80135AA0: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x80135AA4: div.s       $f2, $f10, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f2.fl = DIV_S(ctx->f10.fl, ctx->f6.fl);
L_80135AA8:
    // 0x80135AA8: bgez        $t2, L_80135B3C
    if (SIGNED(ctx->r10) >= 0) {
        // 0x80135AAC: lwc1        $f6, 0x3C($sp)
        ctx->f6.u32l = MEM_W(ctx->r29, 0X3C);
            goto L_80135B3C;
    }
    // 0x80135AAC: lwc1        $f6, 0x3C($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X3C);
    // 0x80135AB0: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80135AB4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80135AB8: lwc1        $f8, 0x3C($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X3C);
    // 0x80135ABC: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x80135AC0: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80135AC4: div.s       $f18, $f8, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f18.fl = DIV_S(ctx->f8.fl, ctx->f16.fl);
    // 0x80135AC8: div.s       $f0, $f4, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f0.fl = DIV_S(ctx->f4.fl, ctx->f18.fl);
    // 0x80135ACC: trunc.w.s   $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x80135AD0: mfc1        $v1, $f10
    ctx->r3 = (int32_t)ctx->f10.u32l;
    // 0x80135AD4: nop

    // 0x80135AD8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x80135ADC: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80135AE0: bgez        $t9, L_80135B10
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80135AE4: or          $v1, $t9, $zero
        ctx->r3 = ctx->r25 | 0;
            goto L_80135B10;
    }
    // 0x80135AE4: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
    // 0x80135AE8: multu       $a3, $t9
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135AEC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135AF0: mflo        $v0
    ctx->r2 = lo;
    // 0x80135AF4: sra         $t8, $v0, 7
    ctx->r24 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135AF8: blez        $t8, L_80135B08
    if (SIGNED(ctx->r24) <= 0) {
        // 0x80135AFC: nop
    
            goto L_80135B08;
    }
    // 0x80135AFC: nop

    // 0x80135B00: b           L_80135B58
    // 0x80135B04: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
        goto L_80135B58;
    // 0x80135B04: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
L_80135B08:
    // 0x80135B08: b           L_80135B5C
    // 0x80135B0C: negu        $t5, $v1
    ctx->r13 = SUB32(0, ctx->r3);
        goto L_80135B5C;
    // 0x80135B0C: negu        $t5, $v1
    ctx->r13 = SUB32(0, ctx->r3);
L_80135B10:
    // 0x80135B10: multu       $a3, $v1
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135B14: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135B18: mflo        $v0
    ctx->r2 = lo;
    // 0x80135B1C: sra         $t6, $v0, 7
    ctx->r14 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135B20: bgez        $t6, L_80135B30
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80135B24: nop
    
            goto L_80135B30;
    }
    // 0x80135B24: nop

    // 0x80135B28: b           L_80135B30
    // 0x80135B2C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
        goto L_80135B30;
    // 0x80135B2C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_80135B30:
    // 0x80135B30: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80135B34: b           L_80135B58
    // 0x80135B38: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_80135B58;
    // 0x80135B38: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80135B3C:
    // 0x80135B3C: lui         $at, 0x4000
    ctx->r1 = S32(0X4000 << 16);
    // 0x80135B40: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80135B44: lui         $at, 0x4680
    ctx->r1 = S32(0X4680 << 16);
    // 0x80135B48: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80135B4C: div.s       $f16, $f6, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80135B50: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135B54: div.s       $f0, $f4, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f0.fl = DIV_S(ctx->f4.fl, ctx->f16.fl);
L_80135B58:
    // 0x80135B58: negu        $t5, $v1
    ctx->r13 = SUB32(0, ctx->r3);
L_80135B5C:
    // 0x80135B5C: negu        $t8, $t0
    ctx->r24 = SUB32(0, ctx->r8);
    // 0x80135B60: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80135B64: andi        $t7, $t5, 0xFFFF
    ctx->r15 = ctx->r13 & 0XFFFF;
    // 0x80135B68: or          $t5, $t7, $t6
    ctx->r13 = ctx->r15 | ctx->r14;
    // 0x80135B6C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80135B70: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80135B74: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80135B78: sw          $t5, 0x4($t3)
    MEM_W(0X4, ctx->r11) = ctx->r13;
    // 0x80135B7C: lw          $a0, 0x0($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X0);
    // 0x80135B80: cvt.w.s     $f18, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    ctx->f18.u32l = CVT_W_S(ctx->f2.fl);
    // 0x80135B84: lui         $t8, 0xB300
    ctx->r24 = S32(0XB300 << 16);
    // 0x80135B88: addiu       $t9, $a0, 0x8
    ctx->r25 = ADD32(ctx->r4, 0X8);
    // 0x80135B8C: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135B90: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80135B94: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80135B98: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x80135B9C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80135BA0: beql        $t6, $zero, L_80135BF0
    if (ctx->r14 == 0) {
        // 0x80135BA4: mfc1        $t6, $f18
        ctx->r14 = (int32_t)ctx->f18.u32l;
            goto L_80135BF0;
    }
    goto skip_0;
    // 0x80135BA4: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    skip_0:
    // 0x80135BA8: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80135BAC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80135BB0: sub.s       $f18, $f2, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f18.fl = ctx->f2.fl - ctx->f18.fl;
    // 0x80135BB4: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x80135BB8: nop

    // 0x80135BBC: cvt.w.s     $f18, $f18
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    ctx->f18.u32l = CVT_W_S(ctx->f18.fl);
    // 0x80135BC0: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x80135BC4: nop

    // 0x80135BC8: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x80135BCC: bne         $t6, $zero, L_80135BE4
    if (ctx->r14 != 0) {
        // 0x80135BD0: nop
    
            goto L_80135BE4;
    }
    // 0x80135BD0: nop

    // 0x80135BD4: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
    // 0x80135BD8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80135BDC: b           L_80135BFC
    // 0x80135BE0: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_80135BFC;
    // 0x80135BE0: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_80135BE4:
    // 0x80135BE4: b           L_80135BFC
    // 0x80135BE8: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_80135BFC;
    // 0x80135BE8: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x80135BEC: mfc1        $t6, $f18
    ctx->r14 = (int32_t)ctx->f18.u32l;
L_80135BF0:
    // 0x80135BF0: nop

    // 0x80135BF4: bltz        $t6, L_80135BE4
    if (SIGNED(ctx->r14) < 0) {
        // 0x80135BF8: nop
    
            goto L_80135BE4;
    }
    // 0x80135BF8: nop

L_80135BFC:
    // 0x80135BFC: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80135C00: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80135C04: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x80135C08: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80135C0C: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80135C10: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80135C14: nop

    // 0x80135C18: cvt.w.s     $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = CVT_W_S(ctx->f0.fl);
    // 0x80135C1C: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80135C20: nop

    // 0x80135C24: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80135C28: beql        $t7, $zero, L_80135C78
    if (ctx->r15 == 0) {
        // 0x80135C2C: mfc1        $t7, $f10
        ctx->r15 = (int32_t)ctx->f10.u32l;
            goto L_80135C78;
    }
    goto skip_1;
    // 0x80135C2C: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    skip_1:
    // 0x80135C30: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80135C34: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80135C38: sub.s       $f10, $f0, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f0.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f0.fl - ctx->f10.fl;
    // 0x80135C3C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80135C40: nop

    // 0x80135C44: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x80135C48: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80135C4C: nop

    // 0x80135C50: andi        $t7, $t7, 0x78
    ctx->r15 = ctx->r15 & 0X78;
    // 0x80135C54: bne         $t7, $zero, L_80135C6C
    if (ctx->r15 != 0) {
        // 0x80135C58: nop
    
            goto L_80135C6C;
    }
    // 0x80135C58: nop

    // 0x80135C5C: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x80135C60: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80135C64: b           L_80135C84
    // 0x80135C68: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
        goto L_80135C84;
    // 0x80135C68: or          $t7, $t7, $at
    ctx->r15 = ctx->r15 | ctx->r1;
L_80135C6C:
    // 0x80135C6C: b           L_80135C84
    // 0x80135C70: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
        goto L_80135C84;
    // 0x80135C70: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80135C74: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
L_80135C78:
    // 0x80135C78: nop

    // 0x80135C7C: bltz        $t7, L_80135C6C
    if (SIGNED(ctx->r15) < 0) {
        // 0x80135C80: nop
    
            goto L_80135C6C;
    }
    // 0x80135C80: nop

L_80135C84:
    // 0x80135C84: andi        $t6, $t7, 0xFFFF
    ctx->r14 = ctx->r15 & 0XFFFF;
    // 0x80135C88: or          $t5, $t9, $t6
    ctx->r13 = ctx->r25 | ctx->r14;
    // 0x80135C8C: sw          $t5, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r13;
    // 0x80135C90: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135C94: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80135C98: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x80135C9C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80135CA0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80135CA4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135CA8: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80135CAC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135CB0: ori         $t9, $t9, 0x1402
    ctx->r25 = ctx->r25 | 0X1402;
    // 0x80135CB4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80135CB8: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80135CBC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135CC0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80135CC4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80135CC8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80135CCC: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80135CD0: jr          $ra
    // 0x80135CD4: nop

    return;
    // 0x80135CD4: nop

;}
RECOMP_FUNC void draw_chunked_image(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80135CD8: addiu       $sp, $sp, -0xA0
    ctx->r29 = ADD32(ctx->r29, -0XA0);
    // 0x80135CDC: sw          $s0, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r16;
    // 0x80135CE0: lw          $s0, 0xB0($sp)
    ctx->r16 = MEM_W(ctx->r29, 0XB0);
    // 0x80135CE4: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80135CE8: sw          $fp, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r30;
    // 0x80135CEC: sw          $s7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r23;
    // 0x80135CF0: sw          $s6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r22;
    // 0x80135CF4: sw          $s5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r21;
    // 0x80135CF8: sw          $s4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r20;
    // 0x80135CFC: sw          $s3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r19;
    // 0x80135D00: sw          $s2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r18;
    // 0x80135D04: sw          $s1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r17;
    // 0x80135D08: sw          $a0, 0xA0($sp)
    MEM_W(0XA0, ctx->r29) = ctx->r4;
    // 0x80135D0C: sw          $a3, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r7;
    // 0x80135D10: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135D14: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80135D18: srl         $t8, $a2, 5
    ctx->r24 = S32(U32(ctx->r6) >> 5);
    // 0x80135D1C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80135D20: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80135D24: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135D28: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80135D2C: lw          $t9, 0xAC($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XAC);
    // 0x80135D30: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x80135D34: sw          $t8, 0x8C($sp)
    MEM_W(0X8C, ctx->r29) = ctx->r24;
    // 0x80135D38: addu        $t1, $a1, $t9
    ctx->r9 = ADD32(ctx->r5, ctx->r25);
    // 0x80135D3C: sltu        $at, $a1, $t1
    ctx->r1 = ctx->r5 < ctx->r9 ? 1 : 0;
    // 0x80135D40: beq         $at, $zero, L_80136064
    if (ctx->r1 == 0) {
        // 0x80135D44: lw          $t6, 0xA0($sp)
        ctx->r14 = MEM_W(ctx->r29, 0XA0);
            goto L_80136064;
    }
    // 0x80135D44: lw          $t6, 0xA0($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XA0);
    // 0x80135D48: addu        $s5, $t6, $a2
    ctx->r21 = ADD32(ctx->r14, ctx->r6);
    // 0x80135D4C: sw          $a1, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r5;
    // 0x80135D50: lui         $fp, 0x708
    ctx->r30 = S32(0X708 << 16);
    // 0x80135D54: ori         $fp, $fp, 0x200
    ctx->r30 = ctx->r30 | 0X200;
    // 0x80135D58: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80135D5C: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x80135D60: sw          $t1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r9;
    // 0x80135D64: lui         $ra, 0xF300
    ctx->r31 = S32(0XF300 << 16);
    // 0x80135D68: lui         $s7, 0xF510
    ctx->r23 = S32(0XF510 << 16);
    // 0x80135D6C: lw          $s6, 0xB4($sp)
    ctx->r22 = MEM_W(ctx->r29, 0XB4);
    // 0x80135D70: lui         $s2, 0xE600
    ctx->r18 = S32(0XE600 << 16);
    // 0x80135D74: lui         $s1, 0xFD10
    ctx->r17 = S32(0XFD10 << 16);
L_80135D78:
    // 0x80135D78: addiu       $a0, $v1, 0x20
    ctx->r4 = ADD32(ctx->r3, 0X20);
    // 0x80135D7C: sltu        $at, $a1, $a0
    ctx->r1 = ctx->r5 < ctx->r4 ? 1 : 0;
    // 0x80135D80: beq         $at, $zero, L_80135D9C
    if (ctx->r1 == 0) {
        // 0x80135D84: or          $t1, $a2, $zero
        ctx->r9 = ctx->r6 | 0;
            goto L_80135D9C;
    }
    // 0x80135D84: or          $t1, $a2, $zero
    ctx->r9 = ctx->r6 | 0;
    // 0x80135D88: lw          $t7, 0xA4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XA4);
    // 0x80135D8C: lw          $t9, 0xAC($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XAC);
    // 0x80135D90: subu        $t8, $t7, $v1
    ctx->r24 = SUB32(ctx->r15, ctx->r3);
    // 0x80135D94: b           L_80135DA0
    // 0x80135D98: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
        goto L_80135DA0;
    // 0x80135D98: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
L_80135D9C:
    // 0x80135D9C: addiu       $v0, $zero, 0x20
    ctx->r2 = ADD32(0, 0X20);
L_80135DA0:
    // 0x80135DA0: sltu        $at, $a2, $s5
    ctx->r1 = ctx->r6 < ctx->r21 ? 1 : 0;
    // 0x80135DA4: beq         $at, $zero, L_80136058
    if (ctx->r1 == 0) {
        // 0x80135DA8: sll         $s3, $v1, 2
        ctx->r19 = S32(ctx->r3 << 2);
            goto L_80136058;
    }
    // 0x80135DA8: sll         $s3, $v1, 2
    ctx->r19 = S32(ctx->r3 << 2);
    // 0x80135DAC: lw          $t7, 0xA4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XA4);
    // 0x80135DB0: lw          $t6, 0xA0($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XA0);
    // 0x80135DB4: sll         $t4, $s3, 16
    ctx->r12 = S32(ctx->r19 << 16);
    // 0x80135DB8: subu        $t8, $v1, $t7
    ctx->r24 = SUB32(ctx->r3, ctx->r15);
    // 0x80135DBC: subu        $t3, $t1, $t6
    ctx->r11 = SUB32(ctx->r9, ctx->r14);
    // 0x80135DC0: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80135DC4: bgez        $t8, L_80135DD4
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80135DC8: sra         $t9, $t8, 5
        ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
            goto L_80135DD4;
    }
    // 0x80135DC8: sra         $t9, $t8, 5
    ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
    // 0x80135DCC: addiu       $at, $t8, 0x1F
    ctx->r1 = ADD32(ctx->r24, 0X1F);
    // 0x80135DD0: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80135DD4:
    // 0x80135DD4: lw          $t8, 0x8C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X8C);
    // 0x80135DD8: sll         $t6, $t9, 24
    ctx->r14 = S32(ctx->r25 << 24);
    // 0x80135DDC: sra         $t7, $t6, 24
    ctx->r15 = S32(SIGNED(ctx->r14) >> 24);
    // 0x80135DE0: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80135DE4: addu        $t9, $v1, $v0
    ctx->r25 = ADD32(ctx->r3, ctx->r2);
    // 0x80135DE8: sll         $t6, $t9, 18
    ctx->r14 = S32(ctx->r25 << 18);
    // 0x80135DEC: sra         $t8, $t4, 16
    ctx->r24 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80135DF0: or          $t4, $t8, $zero
    ctx->r12 = ctx->r24 | 0;
    // 0x80135DF4: sra         $t5, $t6, 16
    ctx->r13 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80135DF8: mflo        $s4
    ctx->r20 = lo;
    // 0x80135DFC: nop

    // 0x80135E00: nop

L_80135E04:
    // 0x80135E04: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135E08: addiu       $t2, $t1, 0x20
    ctx->r10 = ADD32(ctx->r9, 0X20);
    // 0x80135E0C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80135E10: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80135E14: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135E18: sw          $s1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r17;
    // 0x80135E1C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80135E20: bgez        $t3, L_80135E30
    if (SIGNED(ctx->r11) >= 0) {
        // 0x80135E24: sra         $t6, $t3, 5
        ctx->r14 = S32(SIGNED(ctx->r11) >> 5);
            goto L_80135E30;
    }
    // 0x80135E24: sra         $t6, $t3, 5
    ctx->r14 = S32(SIGNED(ctx->r11) >> 5);
    // 0x80135E28: addiu       $at, $t3, 0x1F
    ctx->r1 = ADD32(ctx->r11, 0X1F);
    // 0x80135E2C: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_80135E30:
    // 0x80135E30: or          $t8, $t6, $zero
    ctx->r24 = ctx->r14 | 0;
    // 0x80135E34: addu        $t9, $s4, $t8
    ctx->r25 = ADD32(ctx->r20, ctx->r24);
    // 0x80135E38: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x80135E3C: sll         $t7, $t6, 11
    ctx->r15 = S32(ctx->r14 << 11);
    // 0x80135E40: addu        $a2, $s6, $t7
    ctx->r6 = ADD32(ctx->r22, ctx->r15);
    // 0x80135E44: sw          $a2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r6;
    // 0x80135E48: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135E4C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135E50: lui         $at, 0xE400
    ctx->r1 = S32(0XE400 << 16);
    // 0x80135E54: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80135E58: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80135E5C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135E60: sw          $s2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r18;
    // 0x80135E64: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135E68: addiu       $t3, $t3, 0x20
    ctx->r11 = ADD32(ctx->r11, 0X20);
    // 0x80135E6C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80135E70: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135E74: sw          $a2, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r6;
    // 0x80135E78: sw          $s1, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r17;
    // 0x80135E7C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135E80: lui         $t9, 0x73F
    ctx->r25 = S32(0X73F << 16);
    // 0x80135E84: ori         $t9, $t9, 0xF100
    ctx->r25 = ctx->r25 | 0XF100;
    // 0x80135E88: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80135E8C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80135E90: sw          $fp, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r30;
    // 0x80135E94: sw          $s7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r23;
    // 0x80135E98: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135E9C: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80135EA0: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80135EA4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135EA8: sw          $s2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r18;
    // 0x80135EAC: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x80135EB0: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80135EB4: addiu       $t8, $a1, 0x8
    ctx->r24 = ADD32(ctx->r5, 0X8);
    // 0x80135EB8: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80135EBC: sw          $t9, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r25;
    // 0x80135EC0: sw          $ra, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r31;
    // 0x80135EC4: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135EC8: lui         $t9, 0xF510
    ctx->r25 = S32(0XF510 << 16);
    // 0x80135ECC: ori         $t9, $t9, 0x1000
    ctx->r25 = ctx->r25 | 0X1000;
    // 0x80135ED0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80135ED4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80135ED8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80135EDC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80135EE0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135EE4: lui         $t6, 0x8
    ctx->r14 = S32(0X8 << 16);
    // 0x80135EE8: ori         $t6, $t6, 0x200
    ctx->r14 = ctx->r14 | 0X200;
    // 0x80135EEC: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80135EF0: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80135EF4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80135EF8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80135EFC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80135F00: lui         $t9, 0x7
    ctx->r25 = S32(0X7 << 16);
    // 0x80135F04: ori         $t9, $t9, 0xC07C
    ctx->r25 = ctx->r25 | 0XC07C;
    // 0x80135F08: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80135F0C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80135F10: lui         $t8, 0xF200
    ctx->r24 = S32(0XF200 << 16);
    // 0x80135F14: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80135F18: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80135F1C: lw          $a2, 0x0($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X0);
    // 0x80135F20: sll         $t7, $t2, 18
    ctx->r15 = S32(ctx->r10 << 18);
    // 0x80135F24: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80135F28: addiu       $t6, $a2, 0x8
    ctx->r14 = ADD32(ctx->r6, 0X8);
    // 0x80135F2C: blez        $t8, L_80135F3C
    if (SIGNED(ctx->r24) <= 0) {
        // 0x80135F30: sw          $t6, 0x0($s0)
        MEM_W(0X0, ctx->r16) = ctx->r14;
            goto L_80135F3C;
    }
    // 0x80135F30: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80135F34: b           L_80135F3C
    // 0x80135F38: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
        goto L_80135F3C;
    // 0x80135F38: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
L_80135F3C:
    // 0x80135F3C: blez        $t5, L_80135F4C
    if (SIGNED(ctx->r13) <= 0) {
        // 0x80135F40: andi        $t7, $a0, 0xFFF
        ctx->r15 = ctx->r4 & 0XFFF;
            goto L_80135F4C;
    }
    // 0x80135F40: andi        $t7, $a0, 0xFFF
    ctx->r15 = ctx->r4 & 0XFFF;
    // 0x80135F44: b           L_80135F4C
    // 0x80135F48: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
        goto L_80135F4C;
    // 0x80135F48: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
L_80135F4C:
    // 0x80135F4C: andi        $t9, $v1, 0xFFF
    ctx->r25 = ctx->r3 & 0XFFF;
    // 0x80135F50: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x80135F54: or          $t6, $t9, $at
    ctx->r14 = ctx->r25 | ctx->r1;
    // 0x80135F58: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80135F5C: sll         $t7, $a1, 18
    ctx->r15 = S32(ctx->r5 << 18);
    // 0x80135F60: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x80135F64: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80135F68: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80135F6C: blez        $t6, L_80135F7C
    if (SIGNED(ctx->r14) <= 0) {
        // 0x80135F70: sw          $t9, 0x0($a2)
        MEM_W(0X0, ctx->r6) = ctx->r25;
            goto L_80135F7C;
    }
    // 0x80135F70: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80135F74: b           L_80135F80
    // 0x80135F78: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
        goto L_80135F80;
    // 0x80135F78: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
L_80135F7C:
    // 0x80135F7C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80135F80:
    // 0x80135F80: blez        $t4, L_80135F90
    if (SIGNED(ctx->r12) <= 0) {
        // 0x80135F84: andi        $t9, $a0, 0xFFF
        ctx->r25 = ctx->r4 & 0XFFF;
            goto L_80135F90;
    }
    // 0x80135F84: andi        $t9, $a0, 0xFFF
    ctx->r25 = ctx->r4 & 0XFFF;
    // 0x80135F88: b           L_80135F94
    // 0x80135F8C: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
        goto L_80135F94;
    // 0x80135F8C: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
L_80135F90:
    // 0x80135F90: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_80135F94:
    // 0x80135F94: andi        $t8, $v1, 0xFFF
    ctx->r24 = ctx->r3 & 0XFFF;
    // 0x80135F98: sll         $t7, $t9, 12
    ctx->r15 = S32(ctx->r25 << 12);
    // 0x80135F9C: or          $t6, $t8, $t7
    ctx->r14 = ctx->r24 | ctx->r15;
    // 0x80135FA0: sw          $t6, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r14;
    // 0x80135FA4: lw          $a3, 0x0($s0)
    ctx->r7 = MEM_W(ctx->r16, 0X0);
    // 0x80135FA8: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x80135FAC: or          $t1, $t2, $zero
    ctx->r9 = ctx->r10 | 0;
    // 0x80135FB0: addiu       $t9, $a3, 0x8
    ctx->r25 = ADD32(ctx->r7, 0X8);
    // 0x80135FB4: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80135FB8: bgez        $a1, L_80135FE0
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80135FBC: sw          $t8, 0x0($a3)
        MEM_W(0X0, ctx->r7) = ctx->r24;
            goto L_80135FE0;
    }
    // 0x80135FBC: sw          $t8, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r24;
    // 0x80135FC0: sll         $v0, $a1, 10
    ctx->r2 = S32(ctx->r5 << 10);
    // 0x80135FC4: sra         $t7, $v0, 7
    ctx->r15 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135FC8: bgez        $t7, L_80135FD8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80135FCC: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_80135FD8;
    }
    // 0x80135FCC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80135FD0: b           L_80135FE4
    // 0x80135FD4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
        goto L_80135FE4;
    // 0x80135FD4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
L_80135FD8:
    // 0x80135FD8: b           L_80135FE4
    // 0x80135FDC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
        goto L_80135FE4;
    // 0x80135FDC: or          $a1, $v1, $zero
    ctx->r5 = ctx->r3 | 0;
L_80135FE0:
    // 0x80135FE0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
L_80135FE4:
    // 0x80135FE4: bgez        $s3, L_8013600C
    if (SIGNED(ctx->r19) >= 0) {
        // 0x80135FE8: sltu        $at, $t2, $s5
        ctx->r1 = ctx->r10 < ctx->r21 ? 1 : 0;
            goto L_8013600C;
    }
    // 0x80135FE8: sltu        $at, $t2, $s5
    ctx->r1 = ctx->r10 < ctx->r21 ? 1 : 0;
    // 0x80135FEC: sll         $v0, $t4, 10
    ctx->r2 = S32(ctx->r12 << 10);
    // 0x80135FF0: sra         $t6, $v0, 7
    ctx->r14 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80135FF4: bgez        $t6, L_80136004
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80135FF8: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_80136004;
    }
    // 0x80135FF8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80135FFC: b           L_80136010
    // 0x80136000: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
        goto L_80136010;
    // 0x80136000: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
L_80136004:
    // 0x80136004: b           L_80136010
    // 0x80136008: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_80136010;
    // 0x80136008: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_8013600C:
    // 0x8013600C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_80136010:
    // 0x80136010: negu        $t9, $v1
    ctx->r25 = SUB32(0, ctx->r3);
    // 0x80136014: andi        $t8, $t9, 0xFFFF
    ctx->r24 = ctx->r25 & 0XFFFF;
    // 0x80136018: negu        $t6, $a1
    ctx->r14 = SUB32(0, ctx->r5);
    // 0x8013601C: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x80136020: or          $t7, $t8, $t9
    ctx->r15 = ctx->r24 | ctx->r25;
    // 0x80136024: sw          $t7, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r15;
    // 0x80136028: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x8013602C: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80136030: ori         $t9, $t9, 0x400
    ctx->r25 = ctx->r25 | 0X400;
    // 0x80136034: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x80136038: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x8013603C: lui         $t8, 0xB300
    ctx->r24 = S32(0XB300 << 16);
    // 0x80136040: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80136044: bne         $at, $zero, L_80135E04
    if (ctx->r1 != 0) {
        // 0x80136048: sw          $t9, 0x4($v0)
        MEM_W(0X4, ctx->r2) = ctx->r25;
            goto L_80135E04;
    }
    // 0x80136048: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8013604C: lw          $a2, 0xA0($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA0);
    // 0x80136050: lw          $a1, 0x38($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X38);
    // 0x80136054: lw          $a0, 0x34($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X34);
L_80136058:
    // 0x80136058: sltu        $at, $a0, $a1
    ctx->r1 = ctx->r4 < ctx->r5 ? 1 : 0;
    // 0x8013605C: bne         $at, $zero, L_80135D78
    if (ctx->r1 != 0) {
        // 0x80136060: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80135D78;
    }
    // 0x80136060: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80136064:
    // 0x80136064: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80136068: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x8013606C: lui         $t9, 0xBA00
    ctx->r25 = S32(0XBA00 << 16);
    // 0x80136070: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80136074: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80136078: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8013607C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80136080: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80136084: ori         $t9, $t9, 0x1402
    ctx->r25 = ctx->r25 | 0X1402;
    // 0x80136088: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8013608C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80136090: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80136094: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80136098: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x8013609C: lw          $fp, 0x28($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X28);
    // 0x801360A0: lw          $s7, 0x24($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X24);
    // 0x801360A4: lw          $s6, 0x20($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X20);
    // 0x801360A8: lw          $s5, 0x1C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X1C);
    // 0x801360AC: lw          $s4, 0x18($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X18);
    // 0x801360B0: lw          $s3, 0x14($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X14);
    // 0x801360B4: lw          $s2, 0x10($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X10);
    // 0x801360B8: lw          $s1, 0xC($sp)
    ctx->r17 = MEM_W(ctx->r29, 0XC);
    // 0x801360BC: lw          $s0, 0x8($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X8);
    // 0x801360C0: jr          $ra
    // 0x801360C4: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
    return;
    // 0x801360C4: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
;}
RECOMP_FUNC void draw_sprite_with_prim_depth(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801360C8: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x801360CC: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x801360D0: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x801360D4: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x801360D8: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x801360DC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801360E0: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x801360E4: lui         $t9, 0xEE00
    ctx->r25 = S32(0XEE00 << 16);
    // 0x801360E8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x801360EC: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801360F0: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x801360F4: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x801360F8: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x801360FC: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80136100: lui         $t5, 0x4
    ctx->r13 = S32(0X4 << 16);
    // 0x80136104: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80136108: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8013610C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80136110: lhu         $t3, 0x62($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X62);
    // 0x80136114: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80136118: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8013611C: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x80136120: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80136124: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80136128: lhu         $t7, 0x46($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X46);
    // 0x8013612C: lhu         $a3, 0x42($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X42);
    // 0x80136130: addu        $t5, $t5, $v1
    ctx->r13 = ADD32(ctx->r13, ctx->r3);
    // 0x80136134: lw          $t5, -0x76EC($t5)
    ctx->r13 = MEM_W(ctx->r13, -0X76EC);
    // 0x80136138: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x8013613C: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80136140: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x80136144: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x80136148: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8013614C: addu        $a0, $v1, $t6
    ctx->r4 = ADD32(ctx->r3, ctx->r14);
    // 0x80136150: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80136154: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80136158: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8013615C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80136160: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80136164: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80136168: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8013616C: jal         0x8013E360
    // 0x80136170: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    guSprite2DInit(rdram, ctx);
        goto after_0;
    // 0x80136170: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    after_0:
    // 0x80136174: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80136178: lui         $t2, 0x900
    ctx->r10 = S32(0X900 << 16);
    // 0x8013617C: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80136180: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80136184: sw          $t9, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r25;
    // 0x80136188: ori         $t2, $t2, 0x18
    ctx->r10 = ctx->r10 | 0X18;
    // 0x8013618C: addiu       $a3, $a3, 0x4278
    ctx->r7 = ADD32(ctx->r7, 0X4278);
    // 0x80136190: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x80136194: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x80136198: lui         $t0, 0x3
    ctx->r8 = S32(0X3 << 16);
    // 0x8013619C: ori         $t0, $t0, 0x8000
    ctx->r8 = ctx->r8 | 0X8000;
    // 0x801361A0: addu        $t3, $v1, $t0
    ctx->r11 = ADD32(ctx->r3, ctx->r8);
    // 0x801361A4: lw          $t4, 0x914($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X914);
    // 0x801361A8: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
    // 0x801361AC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x801361B0: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x801361B4: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x801361B8: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x801361BC: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x801361C0: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x801361C4: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x801361C8: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x801361CC: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x801361D0: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x801361D4: lui         $at, 0xBE00
    ctx->r1 = S32(0XBE00 << 16);
    // 0x801361D8: addiu       $t8, $a1, 0x8
    ctx->r24 = ADD32(ctx->r5, 0X8);
    // 0x801361DC: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x801361E0: lbu         $t2, 0x53($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X53);
    // 0x801361E4: lbu         $t6, 0x57($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X57);
    // 0x801361E8: sll         $t3, $t2, 8
    ctx->r11 = S32(ctx->r10 << 8);
    // 0x801361EC: or          $t4, $t3, $at
    ctx->r12 = ctx->r11 | ctx->r1;
    // 0x801361F0: or          $t7, $t4, $t6
    ctx->r15 = ctx->r12 | ctx->r14;
    // 0x801361F4: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x801361F8: lhu         $t8, 0x42($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X42);
    // 0x801361FC: lhu         $t9, 0x4A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X4A);
    // 0x80136200: lhu         $t7, 0x4E($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X4E);
    // 0x80136204: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80136208: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x8013620C: lhu         $t6, 0x46($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X46);
    // 0x80136210: bgez        $t8, L_80136228
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80136214: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_80136228;
    }
    // 0x80136214: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80136218: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x8013621C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80136220: nop

    // 0x80136224: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_80136228:
    // 0x80136228: bgez        $t9, L_80136240
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8013622C: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_80136240;
    }
    // 0x8013622C: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80136230: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80136234: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80136238: nop

    // 0x8013623C: add.s       $f16, $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f18.fl;
L_80136240:
    // 0x80136240: div.s       $f4, $f6, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = DIV_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80136244: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80136248: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x8013624C: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80136250: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x80136254: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80136258: nop

    // 0x8013625C: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80136260: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80136264: nop

    // 0x80136268: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x8013626C: beql        $t3, $zero, L_801362BC
    if (ctx->r11 == 0) {
        // 0x80136270: mfc1        $t3, $f10
        ctx->r11 = (int32_t)ctx->f10.u32l;
            goto L_801362BC;
    }
    goto skip_0;
    // 0x80136270: mfc1        $t3, $f10
    ctx->r11 = (int32_t)ctx->f10.u32l;
    skip_0:
    // 0x80136274: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80136278: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x8013627C: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x80136280: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x80136284: nop

    // 0x80136288: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x8013628C: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x80136290: nop

    // 0x80136294: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x80136298: bne         $t3, $zero, L_801362B0
    if (ctx->r11 != 0) {
        // 0x8013629C: nop
    
            goto L_801362B0;
    }
    // 0x8013629C: nop

    // 0x801362A0: mfc1        $t3, $f10
    ctx->r11 = (int32_t)ctx->f10.u32l;
    // 0x801362A4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801362A8: b           L_801362C8
    // 0x801362AC: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
        goto L_801362C8;
    // 0x801362AC: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
L_801362B0:
    // 0x801362B0: b           L_801362C8
    // 0x801362B4: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
        goto L_801362C8;
    // 0x801362B4: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
    // 0x801362B8: mfc1        $t3, $f10
    ctx->r11 = (int32_t)ctx->f10.u32l;
L_801362BC:
    // 0x801362BC: nop

    // 0x801362C0: bltz        $t3, L_801362B0
    if (SIGNED(ctx->r11) < 0) {
        // 0x801362C4: nop
    
            goto L_801362B0;
    }
    // 0x801362C4: nop

L_801362C8:
    // 0x801362C8: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x801362CC: mtc1        $t6, $f18
    ctx->f18.u32l = ctx->r14;
    // 0x801362D0: sll         $t4, $t3, 16
    ctx->r12 = S32(ctx->r11 << 16);
    // 0x801362D4: bgez        $t6, L_801362EC
    if (SIGNED(ctx->r14) >= 0) {
        // 0x801362D8: cvt.s.w     $f6, $f18
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
            goto L_801362EC;
    }
    // 0x801362D8: cvt.s.w     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
    // 0x801362DC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x801362E0: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x801362E4: nop

    // 0x801362E8: add.s       $f6, $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f16.fl;
L_801362EC:
    // 0x801362EC: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x801362F0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x801362F4: bgez        $t7, L_80136308
    if (SIGNED(ctx->r15) >= 0) {
        // 0x801362F8: cvt.s.w     $f8, $f4
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
            goto L_80136308;
    }
    // 0x801362F8: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801362FC: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80136300: nop

    // 0x80136304: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_80136308:
    // 0x80136308: div.s       $f18, $f6, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f18.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x8013630C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80136310: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80136314: mul.s       $f16, $f18, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80136318: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x8013631C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x80136320: nop

    // 0x80136324: cvt.w.s     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80136328: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x8013632C: nop

    // 0x80136330: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x80136334: beql        $t9, $zero, L_80136384
    if (ctx->r25 == 0) {
        // 0x80136338: mfc1        $t9, $f4
        ctx->r25 = (int32_t)ctx->f4.u32l;
            goto L_80136384;
    }
    goto skip_1;
    // 0x80136338: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    skip_1:
    // 0x8013633C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80136340: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80136344: sub.s       $f4, $f16, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f16.fl - ctx->f4.fl;
    // 0x80136348: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x8013634C: nop

    // 0x80136350: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80136354: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x80136358: nop

    // 0x8013635C: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x80136360: bne         $t9, $zero, L_80136378
    if (ctx->r25 != 0) {
        // 0x80136364: nop
    
            goto L_80136378;
    }
    // 0x80136364: nop

    // 0x80136368: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x8013636C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80136370: b           L_80136390
    // 0x80136374: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_80136390;
    // 0x80136374: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_80136378:
    // 0x80136378: b           L_80136390
    // 0x8013637C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_80136390;
    // 0x8013637C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x80136380: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
L_80136384:
    // 0x80136384: nop

    // 0x80136388: bltz        $t9, L_80136378
    if (SIGNED(ctx->r25) < 0) {
        // 0x8013638C: nop
    
            goto L_80136378;
    }
    // 0x8013638C: nop

L_80136390:
    // 0x80136390: andi        $t2, $t9, 0xFFFF
    ctx->r10 = ctx->r25 & 0XFFFF;
    // 0x80136394: or          $t3, $t4, $t2
    ctx->r11 = ctx->r12 | ctx->r10;
    // 0x80136398: sw          $t3, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r11;
    // 0x8013639C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801363A0: lui         $t6, 0xBD00
    ctx->r14 = S32(0XBD00 << 16);
    // 0x801363A4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x801363A8: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x801363AC: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x801363B0: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x801363B4: lhu         $t2, 0x5E($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X5E);
    // 0x801363B8: lhu         $t9, 0x5A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X5A);
    // 0x801363BC: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x801363C0: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x801363C4: andi        $t5, $t3, 0xFFFF
    ctx->r13 = ctx->r11 & 0XFFFF;
    // 0x801363C8: sll         $t4, $t9, 18
    ctx->r12 = S32(ctx->r25 << 18);
    // 0x801363CC: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x801363D0: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x801363D4: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x801363D8: lui         $t3, 0xE700
    ctx->r11 = S32(0XE700 << 16);
    // 0x801363DC: addu        $t7, $v1, $t0
    ctx->r15 = ADD32(ctx->r3, ctx->r8);
    // 0x801363E0: lw          $t8, 0x914($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X914);
    // 0x801363E4: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x801363E8: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x801363EC: sw          $t9, -0x76EC($at)
    MEM_W(-0X76EC, ctx->r1) = ctx->r25;
    // 0x801363F0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x801363F4: addiu       $t2, $v0, 0x8
    ctx->r10 = ADD32(ctx->r2, 0X8);
    // 0x801363F8: sw          $t2, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r10;
    // 0x801363FC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80136400: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80136404: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80136408: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x8013640C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x80136410: jr          $ra
    // 0x80136414: nop

    return;
    // 0x80136414: nop

;}
RECOMP_FUNC void init_sprite2d_render_zdepth(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80136418: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8013641C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80136420: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x80136424: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80136428: lui         $t8, 0x8016
    ctx->r24 = S32(0X8016 << 16);
    // 0x8013642C: addiu       $t8, $t8, -0x38B0
    ctx->r24 = ADD32(ctx->r24, -0X38B0);
    // 0x80136430: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80136434: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80136438: lui         $t7, 0xB400
    ctx->r15 = S32(0XB400 << 16);
    // 0x8013643C: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80136440: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80136444: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80136448: lui         $t3, 0xAF00
    ctx->r11 = S32(0XAF00 << 16);
    // 0x8013644C: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x80136450: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x80136454: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80136458: addiu       $t4, $t4, -0x1D00
    ctx->r12 = ADD32(ctx->r12, -0X1D00);
    // 0x8013645C: ori         $t3, $t3, 0x7FF
    ctx->r11 = ctx->r11 | 0X7FF;
    // 0x80136460: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80136464: sw          $t4, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r12;
    // 0x80136468: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x8013646C: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x80136470: lui         $t8, 0xFF10
    ctx->r24 = S32(0XFF10 << 16);
    // 0x80136474: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x80136478: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x8013647C: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x80136480: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80136484: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80136488: ori         $t8, $t8, 0x13F
    ctx->r24 = ctx->r24 | 0X13F;
    // 0x8013648C: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80136490: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80136494: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80136498: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8013649C: lw          $t9, 0x4274($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4274);
    // 0x801364A0: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
    // 0x801364A4: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x801364A8: addu        $a0, $a0, $t9
    ctx->r4 = ADD32(ctx->r4, ctx->r25);
    // 0x801364AC: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x801364B0: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x801364B4: jal         0x80138130
    // 0x801364B8: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_0;
    // 0x801364B8: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    after_0:
    // 0x801364BC: lw          $t0, 0x1C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X1C);
    // 0x801364C0: lw          $a2, 0x28($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X28);
    // 0x801364C4: lui         $t4, 0x380
    ctx->r12 = S32(0X380 << 16);
    // 0x801364C8: sw          $v0, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r2;
    // 0x801364CC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801364D0: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x801364D4: addiu       $t5, $t5, 0x2EA8
    ctx->r13 = ADD32(ctx->r13, 0X2EA8);
    // 0x801364D8: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x801364DC: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x801364E0: ori         $t4, $t4, 0x10
    ctx->r12 = ctx->r12 | 0X10;
    // 0x801364E4: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x801364E8: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x801364EC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801364F0: lui         $t7, 0xB700
    ctx->r15 = S32(0XB700 << 16);
    // 0x801364F4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x801364F8: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801364FC: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80136500: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80136504: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80136508: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8013650C: lui         $t3, 0xBC00
    ctx->r11 = S32(0XBC00 << 16);
    // 0x80136510: addiu       $t2, $zero, 0x4
    ctx->r10 = ADD32(0, 0X4);
    // 0x80136514: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x80136518: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x8013651C: ori         $t3, $t3, 0x404
    ctx->r11 = ctx->r11 | 0X404;
    // 0x80136520: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80136524: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x80136528: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x8013652C: lui         $t5, 0xBC00
    ctx->r13 = S32(0XBC00 << 16);
    // 0x80136530: ori         $t5, $t5, 0xC04
    ctx->r13 = ctx->r13 | 0XC04;
    // 0x80136534: addiu       $t4, $v1, 0x8
    ctx->r12 = ADD32(ctx->r3, 0X8);
    // 0x80136538: sw          $t4, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r12;
    // 0x8013653C: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x80136540: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x80136544: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80136548: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x8013654C: ori         $t7, $t7, 0x1404
    ctx->r15 = ctx->r15 | 0X1404;
    // 0x80136550: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80136554: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80136558: ori         $t0, $zero, 0xFFFC
    ctx->r8 = 0 | 0XFFFC;
    // 0x8013655C: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x80136560: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80136564: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80136568: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x8013656C: ori         $t9, $t9, 0x1C04
    ctx->r25 = ctx->r25 | 0X1C04;
    // 0x80136570: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x80136574: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80136578: sw          $t0, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r8;
    // 0x8013657C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x80136580: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80136584: lui         $t5, 0x8016
    ctx->r13 = S32(0X8016 << 16);
    // 0x80136588: addiu       $t5, $t5, -0x7B60
    ctx->r13 = ADD32(ctx->r13, -0X7B60);
    // 0x8013658C: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x80136590: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x80136594: lui         $t4, 0x600
    ctx->r12 = S32(0X600 << 16);
    // 0x80136598: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8013659C: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x801365A0: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801365A4: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x801365A8: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x801365AC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801365B0: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x801365B4: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x801365B8: lbu         $t8, 0x2F($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X2F);
    // 0x801365BC: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x801365C0: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x801365C4: sll         $t3, $t8, 16
    ctx->r11 = S32(ctx->r24 << 16);
    // 0x801365C8: or          $t4, $t9, $t3
    ctx->r12 = ctx->r25 | ctx->r11;
    // 0x801365CC: sll         $t5, $t8, 8
    ctx->r13 = S32(ctx->r24 << 8);
    // 0x801365D0: or          $t6, $t4, $t5
    ctx->r14 = ctx->r12 | ctx->r13;
    // 0x801365D4: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x801365D8: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x801365DC: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801365E0: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x801365E4: ori         $t9, $t9, 0x201
    ctx->r25 = ctx->r25 | 0X201;
    // 0x801365E8: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x801365EC: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x801365F0: sw          $t2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r10;
    // 0x801365F4: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x801365F8: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x801365FC: lui         $t5, 0x55
    ctx->r13 = S32(0X55 << 16);
    // 0x80136600: lui         $t4, 0xB900
    ctx->r12 = S32(0XB900 << 16);
    // 0x80136604: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x80136608: sw          $t3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r11;
    // 0x8013660C: ori         $t4, $t4, 0x31D
    ctx->r12 = ctx->r12 | 0X31D;
    // 0x80136610: ori         $t5, $t5, 0x3078
    ctx->r13 = ctx->r13 | 0X3078;
    // 0x80136614: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x80136618: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8013661C: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80136620: lui         $t7, 0xBA00
    ctx->r15 = S32(0XBA00 << 16);
    // 0x80136624: ori         $t7, $t7, 0xC02
    ctx->r15 = ctx->r15 | 0XC02;
    // 0x80136628: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8013662C: sw          $t6, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r14;
    // 0x80136630: addiu       $t8, $zero, 0x3000
    ctx->r24 = ADD32(0, 0X3000);
    // 0x80136634: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80136638: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8013663C: lw          $v1, 0x0($a2)
    ctx->r3 = MEM_W(ctx->r6, 0X0);
    // 0x80136640: lui         $t3, 0xED02
    ctx->r11 = S32(0XED02 << 16);
    // 0x80136644: ori         $t3, $t3, 0x20
    ctx->r11 = ctx->r11 | 0X20;
    // 0x80136648: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8013664C: sw          $t9, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r25;
    // 0x80136650: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x80136654: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80136658: lh          $t4, 0x3FD0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X3FD0);
    // 0x8013665C: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x80136660: lh          $t3, 0x3FD2($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X3FD2);
    // 0x80136664: addiu       $t5, $t4, -0x8
    ctx->r13 = ADD32(ctx->r12, -0X8);
    // 0x80136668: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x8013666C: addiu       $t4, $t3, -0x8
    ctx->r12 = ADD32(ctx->r11, -0X8);
    // 0x80136670: mtc1        $t4, $f16
    ctx->f16.u32l = ctx->r12;
    // 0x80136674: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80136678: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x8013667C: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x80136680: nop

    // 0x80136684: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80136688: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x8013668C: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80136690: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x80136694: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x80136698: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x8013669C: sll         $t9, $t8, 12
    ctx->r25 = S32(ctx->r24 << 12);
    // 0x801366A0: andi        $t7, $t6, 0xFFF
    ctx->r15 = ctx->r14 & 0XFFF;
    // 0x801366A4: or          $t8, $t9, $t7
    ctx->r24 = ctx->r25 | ctx->r15;
    // 0x801366A8: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x801366AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x801366B0: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x801366B4: jr          $ra
    // 0x801366B8: nop

    return;
    // 0x801366B8: nop

;}
RECOMP_FUNC void init_sprite2d_render(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801366BC: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x801366C0: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x801366C4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801366C8: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x801366CC: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x801366D0: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x801366D4: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801366D8: lui         $t2, 0xE700
    ctx->r10 = S32(0XE700 << 16);
    // 0x801366DC: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x801366E0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801366E4: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x801366E8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x801366EC: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x801366F0: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x801366F4: addiu       $t9, $t9, -0x38B0
    ctx->r25 = ADD32(ctx->r25, -0X38B0);
    // 0x801366F8: lui         $t8, 0xB400
    ctx->r24 = S32(0XB400 << 16);
    // 0x801366FC: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80136700: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80136704: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x80136708: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8013670C: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80136710: lui         $t4, 0xAF00
    ctx->r12 = S32(0XAF00 << 16);
    // 0x80136714: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80136718: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x8013671C: sw          $t3, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r11;
    // 0x80136720: addiu       $t5, $t5, -0x1D00
    ctx->r13 = ADD32(ctx->r13, -0X1D00);
    // 0x80136724: ori         $t4, $t4, 0x7FF
    ctx->r12 = ctx->r12 | 0X7FF;
    // 0x80136728: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x8013672C: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x80136730: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80136734: lui         $a1, 0x8020
    ctx->r5 = S32(0X8020 << 16);
    // 0x80136738: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x8013673C: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x80136740: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80136744: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80136748: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x8013674C: jal         0x80129300
    // 0x80136750: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    load_segments(rdram, ctx);
        goto after_0;
    // 0x80136750: lw          $a1, 0x4278($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X4278);
    after_0:
    // 0x80136754: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80136758: lui         $t8, 0xFF10
    ctx->r24 = S32(0XFF10 << 16);
    // 0x8013675C: ori         $t8, $t8, 0x13F
    ctx->r24 = ctx->r24 | 0X13F;
    // 0x80136760: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80136764: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80136768: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x8013676C: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80136770: lw          $t9, 0x4274($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4274);
    // 0x80136774: lui         $a0, 0x4
    ctx->r4 = S32(0X4 << 16);
    // 0x80136778: addu        $a0, $a0, $t9
    ctx->r4 = ADD32(ctx->r4, ctx->r25);
    // 0x8013677C: lw          $a0, -0x4418($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X4418);
    // 0x80136780: jal         0x80138130
    // 0x80136784: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    osVirtualToPhysical_recomp(rdram, ctx);
        goto after_1;
    // 0x80136784: sw          $v1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r3;
    after_1:
    // 0x80136788: lw          $a3, 0x20($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X20);
    // 0x8013678C: lui         $t4, 0x380
    ctx->r12 = S32(0X380 << 16);
    // 0x80136790: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80136794: sw          $v0, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r2;
    // 0x80136798: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8013679C: addiu       $t5, $t5, 0x2EA8
    ctx->r13 = ADD32(ctx->r13, 0X2EA8);
    // 0x801367A0: ori         $t4, $t4, 0x10
    ctx->r12 = ctx->r12 | 0X10;
    // 0x801367A4: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x801367A8: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x801367AC: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x801367B0: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x801367B4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x801367B8: lui         $t7, 0xBC00
    ctx->r15 = S32(0XBC00 << 16);
    // 0x801367BC: addiu       $t1, $zero, 0x4
    ctx->r9 = ADD32(0, 0X4);
    // 0x801367C0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801367C4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x801367C8: ori         $t7, $t7, 0x404
    ctx->r15 = ctx->r15 | 0X404;
    // 0x801367CC: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x801367D0: sw          $t1, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r9;
    // 0x801367D4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x801367D8: lui         $t9, 0xBC00
    ctx->r25 = S32(0XBC00 << 16);
    // 0x801367DC: ori         $t9, $t9, 0xC04
    ctx->r25 = ctx->r25 | 0XC04;
    // 0x801367E0: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x801367E4: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x801367E8: sw          $t1, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r9;
    // 0x801367EC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x801367F0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x801367F4: lui         $t4, 0xBC00
    ctx->r12 = S32(0XBC00 << 16);
    // 0x801367F8: ori         $t4, $t4, 0x1404
    ctx->r12 = ctx->r12 | 0X1404;
    // 0x801367FC: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x80136800: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80136804: ori         $a2, $zero, 0xFFFC
    ctx->r6 = 0 | 0XFFFC;
    // 0x80136808: sw          $a2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r6;
    // 0x8013680C: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x80136810: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80136814: lui         $t6, 0xBC00
    ctx->r14 = S32(0XBC00 << 16);
    // 0x80136818: ori         $t6, $t6, 0x1C04
    ctx->r14 = ctx->r14 | 0X1C04;
    // 0x8013681C: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x80136820: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80136824: sw          $a2, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r6;
    // 0x80136828: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8013682C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80136830: lui         $t9, 0x8016
    ctx->r25 = S32(0X8016 << 16);
    // 0x80136834: addiu       $t9, $t9, -0x7B60
    ctx->r25 = ADD32(ctx->r25, -0X7B60);
    // 0x80136838: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8013683C: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x80136840: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x80136844: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80136848: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8013684C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80136850: lui         $t4, 0xFA00
    ctx->r12 = S32(0XFA00 << 16);
    // 0x80136854: lui         $at, 0x4080
    ctx->r1 = S32(0X4080 << 16);
    // 0x80136858: addiu       $t3, $v1, 0x8
    ctx->r11 = ADD32(ctx->r3, 0X8);
    // 0x8013685C: sw          $t3, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r11;
    // 0x80136860: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x80136864: lbu         $t6, 0x37($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X37);
    // 0x80136868: lbu         $t9, 0x3B($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X3B);
    // 0x8013686C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80136870: sll         $t7, $t6, 24
    ctx->r15 = S32(ctx->r14 << 24);
    // 0x80136874: lbu         $t6, 0x3F($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X3F);
    // 0x80136878: sll         $t3, $t9, 16
    ctx->r11 = S32(ctx->r25 << 16);
    // 0x8013687C: or          $t4, $t7, $t3
    ctx->r12 = ctx->r15 | ctx->r11;
    // 0x80136880: lbu         $t3, 0x43($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X43);
    // 0x80136884: sll         $t8, $t6, 8
    ctx->r24 = S32(ctx->r14 << 8);
    // 0x80136888: or          $t9, $t4, $t8
    ctx->r25 = ctx->r12 | ctx->r24;
    // 0x8013688C: or          $t5, $t9, $t3
    ctx->r13 = ctx->r25 | ctx->r11;
    // 0x80136890: sw          $t5, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r13;
    // 0x80136894: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80136898: lui         $t4, 0xBA00
    ctx->r12 = S32(0XBA00 << 16);
    // 0x8013689C: ori         $t4, $t4, 0xC02
    ctx->r12 = ctx->r12 | 0XC02;
    // 0x801368A0: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x801368A4: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x801368A8: addiu       $t8, $zero, 0x3000
    ctx->r24 = ADD32(0, 0X3000);
    // 0x801368AC: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x801368B0: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x801368B4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x801368B8: lui         $t9, 0xED02
    ctx->r25 = S32(0XED02 << 16);
    // 0x801368BC: ori         $t9, $t9, 0x20
    ctx->r25 = ctx->r25 | 0X20;
    // 0x801368C0: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x801368C4: sw          $t7, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r15;
    // 0x801368C8: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x801368CC: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x801368D0: lh          $t3, 0x3FD0($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X3FD0);
    // 0x801368D4: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x801368D8: lh          $t9, 0x3FD2($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FD2);
    // 0x801368DC: addiu       $t5, $t3, -0x8
    ctx->r13 = ADD32(ctx->r11, -0X8);
    // 0x801368E0: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x801368E4: addiu       $t3, $t9, -0x8
    ctx->r11 = ADD32(ctx->r25, -0X8);
    // 0x801368E8: mtc1        $t3, $f16
    ctx->f16.u32l = ctx->r11;
    // 0x801368EC: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x801368F0: cvt.s.w     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.fl = CVT_S_W(ctx->f16.u32l);
    // 0x801368F4: mul.s       $f8, $f6, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x801368F8: nop

    // 0x801368FC: mul.s       $f4, $f18, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80136900: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x80136904: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x80136908: mfc1        $t4, $f10
    ctx->r12 = (int32_t)ctx->f10.u32l;
    // 0x8013690C: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x80136910: andi        $t8, $t4, 0xFFF
    ctx->r24 = ctx->r12 & 0XFFF;
    // 0x80136914: sll         $t7, $t8, 12
    ctx->r15 = S32(ctx->r24 << 12);
    // 0x80136918: andi        $t4, $t6, 0xFFF
    ctx->r12 = ctx->r14 & 0XFFF;
    // 0x8013691C: or          $t8, $t7, $t4
    ctx->r24 = ctx->r15 | ctx->r12;
    // 0x80136920: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80136924: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80136928: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x8013692C: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x80136930: jr          $ra
    // 0x80136934: nop

    return;
    // 0x80136934: nop

;}
RECOMP_FUNC void draw_sprite(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80136938: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x8013693C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x80136940: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x80136944: sw          $a2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r6;
    // 0x80136948: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x8013694C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80136950: lui         $t7, 0xE700
    ctx->r15 = S32(0XE700 << 16);
    // 0x80136954: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x80136958: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8013695C: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80136960: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80136964: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80136968: lbu         $t0, 0x63($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X63);
    // 0x8013696C: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80136970: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80136974: beq         $t0, $at, L_80136990
    if (ctx->r8 == ctx->r1) {
        // 0x80136978: lui         $t8, 0x4
        ctx->r24 = S32(0X4 << 16);
            goto L_80136990;
    }
    // 0x80136978: lui         $t8, 0x4
    ctx->r24 = S32(0X4 << 16);
    // 0x8013697C: addiu       $at, $zero, 0x10
    ctx->r1 = ADD32(0, 0X10);
    // 0x80136980: beq         $t0, $at, L_801369F0
    if (ctx->r8 == ctx->r1) {
        // 0x80136984: lui         $v1, 0x8020
        ctx->r3 = S32(0X8020 << 16);
            goto L_801369F0;
    }
    // 0x80136984: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80136988: b           L_80136A4C
    // 0x8013698C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
        goto L_80136A4C;
    // 0x8013698C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_80136990:
    // 0x80136990: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80136994: lhu         $a3, 0x42($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X42);
    // 0x80136998: lhu         $t1, 0x46($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X46);
    // 0x8013699C: addu        $t8, $t8, $v1
    ctx->r24 = ADD32(ctx->r24, ctx->r3);
    // 0x801369A0: lw          $t8, -0x76EC($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X76EC);
    // 0x801369A4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x801369A8: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x801369AC: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x801369B0: subu        $t9, $t9, $t8
    ctx->r25 = SUB32(ctx->r25, ctx->r24);
    // 0x801369B4: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x801369B8: addiu       $t2, $zero, 0x4
    ctx->r10 = ADD32(0, 0X4);
    // 0x801369BC: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x801369C0: addu        $a0, $v1, $t9
    ctx->r4 = ADD32(ctx->r3, ctx->r25);
    // 0x801369C4: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x801369C8: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x801369CC: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x801369D0: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x801369D4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x801369D8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x801369DC: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x801369E0: jal         0x8013E360
    // 0x801369E4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    guSprite2DInit(rdram, ctx);
        goto after_0;
    // 0x801369E4: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x801369E8: b           L_80136A4C
    // 0x801369EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
        goto L_80136A4C;
    // 0x801369EC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_801369F0:
    // 0x801369F0: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x801369F4: lui         $t4, 0x4
    ctx->r12 = S32(0X4 << 16);
    // 0x801369F8: lhu         $a3, 0x42($sp)
    ctx->r7 = MEM_HU(ctx->r29, 0X42);
    // 0x801369FC: addu        $t4, $t4, $v1
    ctx->r12 = ADD32(ctx->r12, ctx->r3);
    // 0x80136A00: lw          $t4, -0x76EC($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X76EC);
    // 0x80136A04: lhu         $t6, 0x46($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X46);
    // 0x80136A08: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80136A0C: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x80136A10: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x80136A14: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x80136A18: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x80136A1C: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x80136A20: addu        $a0, $v1, $t5
    ctx->r4 = ADD32(ctx->r3, ctx->r13);
    // 0x80136A24: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80136A28: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80136A2C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80136A30: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80136A34: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80136A38: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80136A3C: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80136A40: jal         0x8013E360
    // 0x80136A44: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    guSprite2DInit(rdram, ctx);
        goto after_1;
    // 0x80136A44: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_1:
    // 0x80136A48: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_80136A4C:
    // 0x80136A4C: lui         $t9, 0x900
    ctx->r25 = S32(0X900 << 16);
    // 0x80136A50: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80136A54: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80136A58: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80136A5C: ori         $t9, $t9, 0x18
    ctx->r25 = ctx->r25 | 0X18;
    // 0x80136A60: addiu       $a3, $a3, 0x4278
    ctx->r7 = ADD32(ctx->r7, 0X4278);
    // 0x80136A64: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80136A68: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x80136A6C: lui         $t0, 0x3
    ctx->r8 = S32(0X3 << 16);
    // 0x80136A70: ori         $t0, $t0, 0x8000
    ctx->r8 = ctx->r8 | 0X8000;
    // 0x80136A74: addu        $t1, $v1, $t0
    ctx->r9 = ADD32(ctx->r3, ctx->r8);
    // 0x80136A78: lw          $t2, 0x914($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X914);
    // 0x80136A7C: lui         $at, 0x4480
    ctx->r1 = S32(0X4480 << 16);
    // 0x80136A80: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x80136A84: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x80136A88: subu        $t3, $t3, $t2
    ctx->r11 = SUB32(ctx->r11, ctx->r10);
    // 0x80136A8C: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x80136A90: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80136A94: ori         $at, $at, 0x2870
    ctx->r1 = ctx->r1 | 0X2870;
    // 0x80136A98: addu        $t4, $v1, $t3
    ctx->r12 = ADD32(ctx->r3, ctx->r11);
    // 0x80136A9C: addu        $t5, $t4, $at
    ctx->r13 = ADD32(ctx->r12, ctx->r1);
    // 0x80136AA0: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80136AA4: lw          $a1, 0x0($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X0);
    // 0x80136AA8: lui         $at, 0xBE00
    ctx->r1 = S32(0XBE00 << 16);
    // 0x80136AAC: addiu       $t6, $a1, 0x8
    ctx->r14 = ADD32(ctx->r5, 0X8);
    // 0x80136AB0: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80136AB4: lbu         $t8, 0x53($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X53);
    // 0x80136AB8: lbu         $t3, 0x57($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X57);
    // 0x80136ABC: sll         $t9, $t8, 8
    ctx->r25 = S32(ctx->r24 << 8);
    // 0x80136AC0: or          $t1, $t9, $at
    ctx->r9 = ctx->r25 | ctx->r1;
    // 0x80136AC4: or          $t4, $t1, $t3
    ctx->r12 = ctx->r9 | ctx->r11;
    // 0x80136AC8: sw          $t4, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r12;
    // 0x80136ACC: lhu         $t5, 0x42($sp)
    ctx->r13 = MEM_HU(ctx->r29, 0X42);
    // 0x80136AD0: lhu         $t6, 0x4A($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X4A);
    // 0x80136AD4: lhu         $t3, 0x4E($sp)
    ctx->r11 = MEM_HU(ctx->r29, 0X4E);
    // 0x80136AD8: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x80136ADC: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x80136AE0: lhu         $t1, 0x46($sp)
    ctx->r9 = MEM_HU(ctx->r29, 0X46);
    // 0x80136AE4: bgez        $t5, L_80136AFC
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80136AE8: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_80136AFC;
    }
    // 0x80136AE8: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80136AEC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80136AF0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x80136AF4: nop

    // 0x80136AF8: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_80136AFC:
    // 0x80136AFC: bgez        $t6, L_80136B14
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80136B00: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_80136B14;
    }
    // 0x80136B00: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80136B04: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80136B08: mtc1        $at, $f18
    ctx->f18.u32l = ctx->r1;
    // 0x80136B0C: nop

    // 0x80136B10: add.s       $f16, $f16, $f18
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f18.fl;
L_80136B14:
    // 0x80136B14: div.s       $f4, $f6, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = DIV_S(ctx->f6.fl, ctx->f16.fl);
    // 0x80136B18: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80136B1C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80136B20: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x80136B24: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x80136B28: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80136B2C: nop

    // 0x80136B30: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x80136B34: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80136B38: nop

    // 0x80136B3C: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x80136B40: beql        $t8, $zero, L_80136B90
    if (ctx->r24 == 0) {
        // 0x80136B44: mfc1        $t8, $f10
        ctx->r24 = (int32_t)ctx->f10.u32l;
            goto L_80136B90;
    }
    goto skip_0;
    // 0x80136B44: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    skip_0:
    // 0x80136B48: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80136B4C: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80136B50: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x80136B54: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x80136B58: nop

    // 0x80136B5C: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x80136B60: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x80136B64: nop

    // 0x80136B68: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x80136B6C: bne         $t8, $zero, L_80136B84
    if (ctx->r24 != 0) {
        // 0x80136B70: nop
    
            goto L_80136B84;
    }
    // 0x80136B70: nop

    // 0x80136B74: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
    // 0x80136B78: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80136B7C: b           L_80136B9C
    // 0x80136B80: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_80136B9C;
    // 0x80136B80: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_80136B84:
    // 0x80136B84: b           L_80136B9C
    // 0x80136B88: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_80136B9C;
    // 0x80136B88: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x80136B8C: mfc1        $t8, $f10
    ctx->r24 = (int32_t)ctx->f10.u32l;
L_80136B90:
    // 0x80136B90: nop

    // 0x80136B94: bltz        $t8, L_80136B84
    if (SIGNED(ctx->r24) < 0) {
        // 0x80136B98: nop
    
            goto L_80136B84;
    }
    // 0x80136B98: nop

L_80136B9C:
    // 0x80136B9C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x80136BA0: mtc1        $t1, $f18
    ctx->f18.u32l = ctx->r9;
    // 0x80136BA4: sll         $t2, $t8, 16
    ctx->r10 = S32(ctx->r24 << 16);
    // 0x80136BA8: bgez        $t1, L_80136BC0
    if (SIGNED(ctx->r9) >= 0) {
        // 0x80136BAC: cvt.s.w     $f6, $f18
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
            goto L_80136BC0;
    }
    // 0x80136BAC: cvt.s.w     $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.fl = CVT_S_W(ctx->f18.u32l);
    // 0x80136BB0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80136BB4: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80136BB8: nop

    // 0x80136BBC: add.s       $f6, $f6, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f16.fl;
L_80136BC0:
    // 0x80136BC0: mtc1        $t3, $f4
    ctx->f4.u32l = ctx->r11;
    // 0x80136BC4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x80136BC8: bgez        $t3, L_80136BDC
    if (SIGNED(ctx->r11) >= 0) {
        // 0x80136BCC: cvt.s.w     $f8, $f4
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
            goto L_80136BDC;
    }
    // 0x80136BCC: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80136BD0: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x80136BD4: nop

    // 0x80136BD8: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_80136BDC:
    // 0x80136BDC: div.s       $f18, $f6, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f18.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x80136BE0: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x80136BE4: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x80136BE8: mul.s       $f16, $f18, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f16.fl = MUL_S(ctx->f18.fl, ctx->f0.fl);
    // 0x80136BEC: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x80136BF0: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x80136BF4: nop

    // 0x80136BF8: cvt.w.s     $f4, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    ctx->f4.u32l = CVT_W_S(ctx->f16.fl);
    // 0x80136BFC: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x80136C00: nop

    // 0x80136C04: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x80136C08: beql        $t5, $zero, L_80136C58
    if (ctx->r13 == 0) {
        // 0x80136C0C: mfc1        $t5, $f4
        ctx->r13 = (int32_t)ctx->f4.u32l;
            goto L_80136C58;
    }
    goto skip_1;
    // 0x80136C0C: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    skip_1:
    // 0x80136C10: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80136C14: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x80136C18: sub.s       $f4, $f16, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f16.fl - ctx->f4.fl;
    // 0x80136C1C: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x80136C20: nop

    // 0x80136C24: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x80136C28: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x80136C2C: nop

    // 0x80136C30: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x80136C34: bne         $t5, $zero, L_80136C4C
    if (ctx->r13 != 0) {
        // 0x80136C38: nop
    
            goto L_80136C4C;
    }
    // 0x80136C38: nop

    // 0x80136C3C: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    // 0x80136C40: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80136C44: b           L_80136C64
    // 0x80136C48: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
        goto L_80136C64;
    // 0x80136C48: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
L_80136C4C:
    // 0x80136C4C: b           L_80136C64
    // 0x80136C50: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
        goto L_80136C64;
    // 0x80136C50: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x80136C54: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
L_80136C58:
    // 0x80136C58: nop

    // 0x80136C5C: bltz        $t5, L_80136C4C
    if (SIGNED(ctx->r13) < 0) {
        // 0x80136C60: nop
    
            goto L_80136C4C;
    }
    // 0x80136C60: nop

L_80136C64:
    // 0x80136C64: andi        $t6, $t5, 0xFFFF
    ctx->r14 = ctx->r13 & 0XFFFF;
    // 0x80136C68: or          $t7, $t2, $t6
    ctx->r15 = ctx->r10 | ctx->r14;
    // 0x80136C6C: sw          $t7, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r15;
    // 0x80136C70: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80136C74: lui         $t9, 0xBD00
    ctx->r25 = S32(0XBD00 << 16);
    // 0x80136C78: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x80136C7C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80136C80: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80136C84: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80136C88: lhu         $t2, 0x5E($sp)
    ctx->r10 = MEM_HU(ctx->r29, 0X5E);
    // 0x80136C8C: lhu         $t4, 0x5A($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X5A);
    // 0x80136C90: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80136C94: sll         $t6, $t2, 2
    ctx->r14 = S32(ctx->r10 << 2);
    // 0x80136C98: andi        $t7, $t6, 0xFFFF
    ctx->r15 = ctx->r14 & 0XFFFF;
    // 0x80136C9C: sll         $t5, $t4, 18
    ctx->r13 = S32(ctx->r12 << 18);
    // 0x80136CA0: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x80136CA4: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80136CA8: lw          $v1, 0x0($a3)
    ctx->r3 = MEM_W(ctx->r7, 0X0);
    // 0x80136CAC: addu        $t9, $v1, $t0
    ctx->r25 = ADD32(ctx->r3, ctx->r8);
    // 0x80136CB0: lw          $t1, 0x914($t9)
    ctx->r9 = MEM_W(ctx->r25, 0X914);
    // 0x80136CB4: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80136CB8: addiu       $t3, $t1, 0x1
    ctx->r11 = ADD32(ctx->r9, 0X1);
    // 0x80136CBC: sw          $t3, -0x76EC($at)
    MEM_W(-0X76EC, ctx->r1) = ctx->r11;
    // 0x80136CC0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80136CC4: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x80136CC8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x80136CCC: jr          $ra
    // 0x80136CD0: nop

    return;
    // 0x80136CD0: nop

;}
RECOMP_FUNC void init_controllers(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80136CE0: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136CE4: sh          $zero, 0x12DA($at)
    MEM_H(0X12DA, ctx->r1) = 0;
    // 0x80136CE8: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136CEC: sh          $zero, 0x12DC($at)
    MEM_H(0X12DC, ctx->r1) = 0;
    // 0x80136CF0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80136CF4: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136CF8: sb          $v0, 0x12DE($at)
    MEM_B(0X12DE, ctx->r1) = ctx->r2;
    // 0x80136CFC: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D00: sb          $v0, 0x12DF($at)
    MEM_B(0X12DF, ctx->r1) = ctx->r2;
    // 0x80136D04: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D08: sb          $v0, 0x12E0($at)
    MEM_B(0X12E0, ctx->r1) = ctx->r2;
    // 0x80136D0C: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x80136D10: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D14: sb          $v0, 0x12E1($at)
    MEM_B(0X12E1, ctx->r1) = ctx->r2;
    // 0x80136D18: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D1C: sb          $v0, 0x12E2($at)
    MEM_B(0X12E2, ctx->r1) = ctx->r2;
    // 0x80136D20: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D24: sb          $v0, 0x12E3($at)
    MEM_B(0X12E3, ctx->r1) = ctx->r2;
    // 0x80136D28: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x80136D2C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D30: lui         $s5, 0x8029
    ctx->r21 = S32(0X8029 << 16);
    // 0x80136D34: sb          $v0, 0x12E4($at)
    MEM_B(0X12E4, ctx->r1) = ctx->r2;
    // 0x80136D38: addiu       $s5, $s5, -0x2F58
    ctx->r21 = ADD32(ctx->r21, -0X2F58);
    // 0x80136D3C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80136D40: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136D44: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80136D48: sw          $fp, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r30;
    // 0x80136D4C: sw          $s7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r23;
    // 0x80136D50: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x80136D54: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x80136D58: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x80136D5C: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x80136D60: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x80136D64: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x80136D68: sb          $v0, 0x12E5($at)
    MEM_B(0X12E5, ctx->r1) = ctx->r2;
    // 0x80136D6C: addiu       $a1, $a1, 0x104C
    ctx->r5 = ADD32(ctx->r5, 0X104C);
    // 0x80136D70: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80136D74: jal         0x801381B0
    // 0x80136D78: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_0;
    // 0x80136D78: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x80136D7C: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    // 0x80136D80: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x80136D84: jal         0x8013E3B0
    // 0x80136D88: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSetEventMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x80136D88: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_1:
    // 0x80136D8C: lui         $s6, 0x8029
    ctx->r22 = S32(0X8029 << 16);
    // 0x80136D90: addiu       $s6, $s6, 0x10D8
    ctx->r22 = ADD32(ctx->r22, 0X10D8);
    // 0x80136D94: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x80136D98: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80136D9C: jal         0x8013E420
    // 0x80136DA0: addiu       $a1, $sp, 0x57
    ctx->r5 = ADD32(ctx->r29, 0X57);
    osContInit_recomp(rdram, ctx);
        goto after_2;
    // 0x80136DA0: addiu       $a1, $sp, 0x57
    ctx->r5 = ADD32(ctx->r29, 0X57);
    after_2:
    // 0x80136DA4: lui         $s7, 0x8016
    ctx->r23 = S32(0X8016 << 16);
    // 0x80136DA8: addiu       $s7, $s7, -0x7ABC
    ctx->r23 = ADD32(ctx->r23, -0X7ABC);
    // 0x80136DAC: sw          $zero, 0x0($s7)
    MEM_W(0X0, ctx->r23) = 0;
    // 0x80136DB0: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80136DB4: lbu         $v1, 0x57($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X57);
    // 0x80136DB8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
L_80136DBC:
    // 0x80136DBC: sllv        $t7, $t6, $s0
    ctx->r15 = S32(ctx->r14 << (ctx->r16 & 31));
    // 0x80136DC0: and         $t8, $v1, $t7
    ctx->r24 = ctx->r3 & ctx->r15;
    // 0x80136DC4: beq         $t8, $zero, L_80136DEC
    if (ctx->r24 == 0) {
        // 0x80136DC8: sll         $t9, $s0, 2
        ctx->r25 = S32(ctx->r16 << 2);
            goto L_80136DEC;
    }
    // 0x80136DC8: sll         $t9, $s0, 2
    ctx->r25 = S32(ctx->r16 << 2);
    // 0x80136DCC: addu        $t0, $s6, $t9
    ctx->r8 = ADD32(ctx->r22, ctx->r25);
    // 0x80136DD0: lbu         $t1, 0x3($t0)
    ctx->r9 = MEM_BU(ctx->r8, 0X3);
    // 0x80136DD4: andi        $t2, $t1, 0x8
    ctx->r10 = ctx->r9 & 0X8;
    // 0x80136DD8: bnel        $t2, $zero, L_80136DF0
    if (ctx->r10 != 0) {
        // 0x80136DDC: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80136DF0;
    }
    goto skip_0;
    // 0x80136DDC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x80136DE0: lw          $t3, 0x0($s7)
    ctx->r11 = MEM_W(ctx->r23, 0X0);
    // 0x80136DE4: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x80136DE8: sw          $t4, 0x0($s7)
    MEM_W(0X0, ctx->r23) = ctx->r12;
L_80136DEC:
    // 0x80136DEC: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80136DF0:
    // 0x80136DF0: sll         $t5, $s0, 16
    ctx->r13 = S32(ctx->r16 << 16);
    // 0x80136DF4: sra         $s0, $t5, 16
    ctx->r16 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80136DF8: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x80136DFC: bnel        $at, $zero, L_80136DBC
    if (ctx->r1 != 0) {
        // 0x80136E00: addiu       $t6, $zero, 0x1
        ctx->r14 = ADD32(0, 0X1);
            goto L_80136DBC;
    }
    goto skip_1;
    // 0x80136E00: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    skip_1:
    // 0x80136E04: jal         0x8013E760
    // 0x80136E08: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    osContSetCh_recomp(rdram, ctx);
        goto after_3;
    // 0x80136E08: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_3:
    // 0x80136E0C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80136E10: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80136E14: addiu       $a1, $a1, 0x12C8
    ctx->r5 = ADD32(ctx->r5, 0X12C8);
    // 0x80136E18: addiu       $a0, $a0, 0x12B0
    ctx->r4 = ADD32(ctx->r4, 0X12B0);
    // 0x80136E1C: jal         0x801381B0
    // 0x80136E20: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_4;
    // 0x80136E20: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_4:
    // 0x80136E24: lui         $s0, 0x8028
    ctx->r16 = S32(0X8028 << 16);
    // 0x80136E28: lui         $t7, 0x8029
    ctx->r15 = S32(0X8029 << 16);
    // 0x80136E2C: addiu       $s0, $s0, 0x6A80
    ctx->r16 = ADD32(ctx->r16, 0X6A80);
    // 0x80136E30: addiu       $t7, $t7, -0x1DD0
    ctx->r15 = ADD32(ctx->r15, -0X1DD0);
    // 0x80136E34: lui         $a2, 0x8013
    ctx->r6 = S32(0X8013 << 16);
    // 0x80136E38: addiu       $t8, $zero, 0x9
    ctx->r24 = ADD32(0, 0X9);
    // 0x80136E3C: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x80136E40: addiu       $a2, $a2, 0x7294
    ctx->r6 = ADD32(ctx->r6, 0X7294);
    // 0x80136E44: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80136E48: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80136E4C: addiu       $a1, $zero, 0x9
    ctx->r5 = ADD32(0, 0X9);
    // 0x80136E50: jal         0x80139AA0
    // 0x80136E54: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    osCreateThread_recomp(rdram, ctx);
        goto after_5;
    // 0x80136E54: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_5:
    // 0x80136E58: jal         0x801381E0
    // 0x80136E5C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    osStartThread_recomp(rdram, ctx);
        goto after_6;
    // 0x80136E5C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_6:
    // 0x80136E60: lui         $fp, 0x8029
    ctx->r30 = S32(0X8029 << 16);
    // 0x80136E64: addiu       $fp, $fp, 0x1090
    ctx->r30 = ADD32(ctx->r30, 0X1090);
    // 0x80136E68: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80136E6C: addiu       $s4, $zero, 0xB
    ctx->r20 = ADD32(0, 0XB);
    // 0x80136E70: addiu       $s3, $zero, 0xA
    ctx->r19 = ADD32(0, 0XA);
    // 0x80136E74: lbu         $t9, 0x57($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X57);
L_80136E78:
    // 0x80136E78: addu        $s2, $fp, $s0
    ctx->r18 = ADD32(ctx->r30, ctx->r16);
    // 0x80136E7C: sb          $zero, 0x0($s2)
    MEM_B(0X0, ctx->r18) = 0;
    // 0x80136E80: srav        $t0, $t9, $s0
    ctx->r8 = S32(SIGNED(ctx->r25) >> (ctx->r16 & 31));
    // 0x80136E84: andi        $t1, $t0, 0x1
    ctx->r9 = ctx->r8 & 0X1;
    // 0x80136E88: beq         $t1, $zero, L_80136F04
    if (ctx->r9 == 0) {
        // 0x80136E8C: sll         $t2, $s0, 2
        ctx->r10 = S32(ctx->r16 << 2);
            goto L_80136F04;
    }
    // 0x80136E8C: sll         $t2, $s0, 2
    ctx->r10 = S32(ctx->r16 << 2);
    // 0x80136E90: addu        $v0, $s6, $t2
    ctx->r2 = ADD32(ctx->r22, ctx->r10);
    // 0x80136E94: lhu         $t3, 0x0($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X0);
    // 0x80136E98: andi        $t4, $t3, 0x4
    ctx->r12 = ctx->r11 & 0X4;
    // 0x80136E9C: beql        $t4, $zero, L_80136F08
    if (ctx->r12 == 0) {
        // 0x80136EA0: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_80136F08;
    }
    goto skip_2;
    // 0x80136EA0: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_2:
    // 0x80136EA4: lbu         $t5, 0x2($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2);
    // 0x80136EA8: sll         $t7, $s0, 2
    ctx->r15 = S32(ctx->r16 << 2);
    // 0x80136EAC: subu        $t7, $t7, $s0
    ctx->r15 = SUB32(ctx->r15, ctx->r16);
    // 0x80136EB0: andi        $t6, $t5, 0x1
    ctx->r14 = ctx->r13 & 0X1;
    // 0x80136EB4: beq         $t6, $zero, L_80136F04
    if (ctx->r14 == 0) {
        // 0x80136EB8: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_80136F04;
    }
    // 0x80136EB8: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80136EBC: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80136EC0: addu        $t7, $t7, $s0
    ctx->r15 = ADD32(ctx->r15, ctx->r16);
    // 0x80136EC4: lui         $t8, 0x8029
    ctx->r24 = S32(0X8029 << 16);
    // 0x80136EC8: addiu       $t8, $t8, 0x1110
    ctx->r24 = ADD32(ctx->r24, 0X1110);
    // 0x80136ECC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80136ED0: addu        $s1, $t7, $t8
    ctx->r17 = ADD32(ctx->r15, ctx->r24);
    // 0x80136ED4: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80136ED8: jal         0x8013E7D0
    // 0x80136EDC: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osPfsInit_recomp(rdram, ctx);
        goto after_7;
    // 0x80136EDC: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_7:
    // 0x80136EE0: beq         $v0, $s3, L_80136EEC
    if (ctx->r2 == ctx->r19) {
        // 0x80136EE4: or          $a0, $s5, $zero
        ctx->r4 = ctx->r21 | 0;
            goto L_80136EEC;
    }
    // 0x80136EE4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x80136EE8: bne         $v0, $s4, L_80136F04
    if (ctx->r2 != ctx->r20) {
        // 0x80136EEC: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_80136F04;
    }
L_80136EEC:
    // 0x80136EEC: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80136EF0: jal         0x8013ED4C
    // 0x80136EF4: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    osMotorInit_recomp(rdram, ctx);
        goto after_8;
    // 0x80136EF4: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    after_8:
    // 0x80136EF8: bne         $v0, $zero, L_80136F04
    if (ctx->r2 != 0) {
        // 0x80136EFC: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_80136F04;
    }
    // 0x80136EFC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80136F00: sb          $t9, 0x0($s2)
    MEM_B(0X0, ctx->r18) = ctx->r25;
L_80136F04:
    // 0x80136F04: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_80136F08:
    // 0x80136F08: sll         $t0, $s0, 16
    ctx->r8 = S32(ctx->r16 << 16);
    // 0x80136F0C: sra         $s0, $t0, 16
    ctx->r16 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80136F10: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x80136F14: bnel        $at, $zero, L_80136E78
    if (ctx->r1 != 0) {
        // 0x80136F18: lbu         $t9, 0x57($sp)
        ctx->r25 = MEM_BU(ctx->r29, 0X57);
            goto L_80136E78;
    }
    goto skip_3;
    // 0x80136F18: lbu         $t9, 0x57($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X57);
    skip_3:
    // 0x80136F1C: jal         0x8013F030
    // 0x80136F20: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    osEepromProbe_recomp(rdram, ctx);
        goto after_9;
    // 0x80136F20: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    after_9:
    // 0x80136F24: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136F28: jal         0x80137168
    // 0x80136F2C: sw          $v0, 0x12D4($at)
    MEM_W(0X12D4, ctx->r1) = ctx->r2;
    func_80137168(rdram, ctx);
        goto after_10;
    // 0x80136F2C: sw          $v0, 0x12D4($at)
    MEM_W(0X12D4, ctx->r1) = ctx->r2;
    after_10:
    // 0x80136F30: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x80136F34: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    // 0x80136F38: lw          $s7, 0x3C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X3C);
    // 0x80136F3C: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x80136F40: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x80136F44: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x80136F48: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x80136F4C: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x80136F50: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x80136F54: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x80136F58: lw          $fp, 0x40($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X40);
    // 0x80136F5C: jr          $ra
    // 0x80136F60: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x80136F60: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void func_80136F64(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80136F64: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x80136F68: lw          $v0, 0x10D0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X10D0);
    // 0x80136F6C: beq         $v0, $zero, L_8013709C
    if (ctx->r2 == 0) {
        // 0x80136F70: nop
    
            goto L_8013709C;
    }
    // 0x80136F70: nop

    // 0x80136F74: lhu         $t6, 0x0($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X0);
    // 0x80136F78: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80136F7C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136F80: andi        $t7, $t6, 0x1000
    ctx->r15 = ctx->r14 & 0X1000;
    // 0x80136F84: beq         $t7, $zero, L_80136F9C
    if (ctx->r15 == 0) {
        // 0x80136F88: nop
    
            goto L_80136F9C;
    }
    // 0x80136F88: nop

    // 0x80136F8C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136F90: sb          $zero, 0x12DE($at)
    MEM_B(0X12DE, ctx->r1) = 0;
    // 0x80136F94: b           L_80136FA0
    // 0x80136F98: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_80136FA0;
    // 0x80136F98: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80136F9C:
    // 0x80136F9C: sb          $v1, 0x12DE($at)
    MEM_B(0X12DE, ctx->r1) = ctx->r3;
L_80136FA0:
    // 0x80136FA0: lhu         $t8, 0x0($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X0);
    // 0x80136FA4: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136FA8: andi        $t9, $t8, 0x8000
    ctx->r25 = ctx->r24 & 0X8000;
    // 0x80136FAC: beq         $t9, $zero, L_80136FC0
    if (ctx->r25 == 0) {
        // 0x80136FB0: nop
    
            goto L_80136FC0;
    }
    // 0x80136FB0: nop

    // 0x80136FB4: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136FB8: b           L_80136FC4
    // 0x80136FBC: sb          $zero, 0x12DF($at)
    MEM_B(0X12DF, ctx->r1) = 0;
        goto L_80136FC4;
    // 0x80136FBC: sb          $zero, 0x12DF($at)
    MEM_B(0X12DF, ctx->r1) = 0;
L_80136FC0:
    // 0x80136FC0: sb          $v1, 0x12DF($at)
    MEM_B(0X12DF, ctx->r1) = ctx->r3;
L_80136FC4:
    // 0x80136FC4: lhu         $t0, 0x0($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X0);
    // 0x80136FC8: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136FCC: andi        $t1, $t0, 0x4000
    ctx->r9 = ctx->r8 & 0X4000;
    // 0x80136FD0: beq         $t1, $zero, L_80136FE4
    if (ctx->r9 == 0) {
        // 0x80136FD4: nop
    
            goto L_80136FE4;
    }
    // 0x80136FD4: nop

    // 0x80136FD8: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136FDC: b           L_80136FE8
    // 0x80136FE0: sb          $zero, 0x12E0($at)
    MEM_B(0X12E0, ctx->r1) = 0;
        goto L_80136FE8;
    // 0x80136FE0: sb          $zero, 0x12E0($at)
    MEM_B(0X12E0, ctx->r1) = 0;
L_80136FE4:
    // 0x80136FE4: sb          $v1, 0x12E0($at)
    MEM_B(0X12E0, ctx->r1) = ctx->r3;
L_80136FE8:
    // 0x80136FE8: lhu         $t2, 0x0($v0)
    ctx->r10 = MEM_HU(ctx->r2, 0X0);
    // 0x80136FEC: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80136FF0: andi        $t3, $t2, 0x800
    ctx->r11 = ctx->r10 & 0X800;
    // 0x80136FF4: beq         $t3, $zero, L_80137008
    if (ctx->r11 == 0) {
        // 0x80136FF8: nop
    
            goto L_80137008;
    }
    // 0x80136FF8: nop

    // 0x80136FFC: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137000: b           L_8013700C
    // 0x80137004: sb          $zero, 0x12E1($at)
    MEM_B(0X12E1, ctx->r1) = 0;
        goto L_8013700C;
    // 0x80137004: sb          $zero, 0x12E1($at)
    MEM_B(0X12E1, ctx->r1) = 0;
L_80137008:
    // 0x80137008: sb          $v1, 0x12E1($at)
    MEM_B(0X12E1, ctx->r1) = ctx->r3;
L_8013700C:
    // 0x8013700C: lhu         $t4, 0x0($v0)
    ctx->r12 = MEM_HU(ctx->r2, 0X0);
    // 0x80137010: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137014: andi        $t5, $t4, 0x400
    ctx->r13 = ctx->r12 & 0X400;
    // 0x80137018: beq         $t5, $zero, L_8013702C
    if (ctx->r13 == 0) {
        // 0x8013701C: nop
    
            goto L_8013702C;
    }
    // 0x8013701C: nop

    // 0x80137020: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137024: b           L_80137030
    // 0x80137028: sb          $zero, 0x12E2($at)
    MEM_B(0X12E2, ctx->r1) = 0;
        goto L_80137030;
    // 0x80137028: sb          $zero, 0x12E2($at)
    MEM_B(0X12E2, ctx->r1) = 0;
L_8013702C:
    // 0x8013702C: sb          $v1, 0x12E2($at)
    MEM_B(0X12E2, ctx->r1) = ctx->r3;
L_80137030:
    // 0x80137030: lhu         $t6, 0x0($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X0);
    // 0x80137034: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137038: andi        $t7, $t6, 0x200
    ctx->r15 = ctx->r14 & 0X200;
    // 0x8013703C: beq         $t7, $zero, L_80137050
    if (ctx->r15 == 0) {
        // 0x80137040: nop
    
            goto L_80137050;
    }
    // 0x80137040: nop

    // 0x80137044: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137048: b           L_80137054
    // 0x8013704C: sb          $zero, 0x12E3($at)
    MEM_B(0X12E3, ctx->r1) = 0;
        goto L_80137054;
    // 0x8013704C: sb          $zero, 0x12E3($at)
    MEM_B(0X12E3, ctx->r1) = 0;
L_80137050:
    // 0x80137050: sb          $v1, 0x12E3($at)
    MEM_B(0X12E3, ctx->r1) = ctx->r3;
L_80137054:
    // 0x80137054: lhu         $t8, 0x0($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X0);
    // 0x80137058: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x8013705C: andi        $t9, $t8, 0x100
    ctx->r25 = ctx->r24 & 0X100;
    // 0x80137060: beq         $t9, $zero, L_80137074
    if (ctx->r25 == 0) {
        // 0x80137064: nop
    
            goto L_80137074;
    }
    // 0x80137064: nop

    // 0x80137068: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x8013706C: b           L_80137078
    // 0x80137070: sb          $zero, 0x12E4($at)
    MEM_B(0X12E4, ctx->r1) = 0;
        goto L_80137078;
    // 0x80137070: sb          $zero, 0x12E4($at)
    MEM_B(0X12E4, ctx->r1) = 0;
L_80137074:
    // 0x80137074: sb          $v1, 0x12E4($at)
    MEM_B(0X12E4, ctx->r1) = ctx->r3;
L_80137078:
    // 0x80137078: lhu         $t0, 0x0($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X0);
    // 0x8013707C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137080: andi        $t1, $t0, 0x2000
    ctx->r9 = ctx->r8 & 0X2000;
    // 0x80137084: beq         $t1, $zero, L_80137098
    if (ctx->r9 == 0) {
        // 0x80137088: nop
    
            goto L_80137098;
    }
    // 0x80137088: nop

    // 0x8013708C: lui         $at, 0x8029
    ctx->r1 = S32(0X8029 << 16);
    // 0x80137090: jr          $ra
    // 0x80137094: sb          $zero, 0x12E5($at)
    MEM_B(0X12E5, ctx->r1) = 0;
    return;
    // 0x80137094: sb          $zero, 0x12E5($at)
    MEM_B(0X12E5, ctx->r1) = 0;
L_80137098:
    // 0x80137098: sb          $v1, 0x12E5($at)
    MEM_B(0X12E5, ctx->r1) = ctx->r3;
L_8013709C:
    // 0x8013709C: jr          $ra
    // 0x801370A0: nop

    return;
    // 0x801370A0: nop

;}
RECOMP_FUNC void func_801370A4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801370A4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x801370A8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801370AC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x801370B0: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x801370B4: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x801370B8: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x801370BC: sh          $t6, -0x7AC0($at)
    MEM_H(-0X7AC0, ctx->r1) = ctx->r14;
    // 0x801370C0: addiu       $a1, $a1, 0x1048
    ctx->r5 = ADD32(ctx->r5, 0X1048);
    // 0x801370C4: addiu       $a0, $a0, -0x2F70
    ctx->r4 = ADD32(ctx->r4, -0X2F70);
    // 0x801370C8: jal         0x801381B0
    // 0x801370CC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_0;
    // 0x801370CC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x801370D0: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x801370D4: addiu       $a0, $a0, -0x2F70
    ctx->r4 = ADD32(ctx->r4, -0X2F70);
    // 0x801370D8: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x801370DC: jal         0x80139050
    // 0x801370E0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x801370E0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_1:
    // 0x801370E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x801370E8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x801370EC: jr          $ra
    // 0x801370F0: nop

    return;
    // 0x801370F0: nop

;}
RECOMP_FUNC void func_801370F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801370F4: lui         $t6, 0x8016
    ctx->r14 = S32(0X8016 << 16);
    // 0x801370F8: lh          $t6, -0x7AC0($t6)
    ctx->r14 = MEM_H(ctx->r14, -0X7AC0);
    // 0x801370FC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80137100: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137104: bne         $t6, $zero, L_80137114
    if (ctx->r14 != 0) {
        // 0x80137108: nop
    
            goto L_80137114;
    }
    // 0x80137108: nop

    // 0x8013710C: jal         0x801370A4
    // 0x80137110: nop

    func_801370A4(rdram, ctx);
        goto after_0;
    // 0x80137110: nop

    after_0:
L_80137114:
    // 0x80137114: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137118: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8013711C: addiu       $a1, $a1, 0x12CC
    ctx->r5 = ADD32(ctx->r5, 0X12CC);
    // 0x80137120: addiu       $a0, $a0, -0x2F70
    ctx->r4 = ADD32(ctx->r4, -0X2F70);
    // 0x80137124: jal         0x80137FF0
    // 0x80137128: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osRecvMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x80137128: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_1:
    // 0x8013712C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80137130: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80137134: jr          $ra
    // 0x80137138: nop

    return;
    // 0x80137138: nop

;}
RECOMP_FUNC void func_8013713C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013713C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80137140: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137144: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137148: addiu       $a0, $a0, -0x2F70
    ctx->r4 = ADD32(ctx->r4, -0X2F70);
    // 0x8013714C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80137150: jal         0x80139050
    // 0x80137154: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x80137154: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_0:
    // 0x80137158: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x8013715C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80137160: jr          $ra
    // 0x80137164: nop

    return;
    // 0x80137164: nop

;}
RECOMP_FUNC void func_80137168(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80137168: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8013716C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80137170: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80137174: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80137178: lui         $s1, 0x8029
    ctx->r17 = S32(0X8029 << 16);
    // 0x8013717C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80137180: addiu       $s1, $s1, 0x1090
    ctx->r17 = ADD32(ctx->r17, 0X1090);
    // 0x80137184: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80137188: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x8013718C: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
L_80137190:
    // 0x80137190: addu        $v0, $s1, $t6
    ctx->r2 = ADD32(ctx->r17, ctx->r14);
    // 0x80137194: sh          $zero, 0x4($v0)
    MEM_H(0X4, ctx->r2) = 0;
    // 0x80137198: sh          $zero, 0xC($v0)
    MEM_H(0XC, ctx->r2) = 0;
    // 0x8013719C: sh          $zero, 0x14($v0)
    MEM_H(0X14, ctx->r2) = 0;
    // 0x801371A0: sh          $zero, 0x1C($v0)
    MEM_H(0X1C, ctx->r2) = 0;
    // 0x801371A4: sh          $zero, 0x24($v0)
    MEM_H(0X24, ctx->r2) = 0;
    // 0x801371A8: sh          $zero, 0x2C($v0)
    MEM_H(0X2C, ctx->r2) = 0;
    // 0x801371AC: sh          $zero, 0x34($v0)
    MEM_H(0X34, ctx->r2) = 0;
    // 0x801371B0: sh          $zero, 0x3C($s1)
    MEM_H(0X3C, ctx->r17) = 0;
    // 0x801371B4: addu        $t7, $s1, $s0
    ctx->r15 = ADD32(ctx->r17, ctx->r16);
    // 0x801371B8: lb          $t8, 0x0($t7)
    ctx->r24 = MEM_B(ctx->r15, 0X0);
    // 0x801371BC: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
    // 0x801371C0: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x801371C4: bnel        $s2, $t8, L_801371D8
    if (ctx->r18 != ctx->r24) {
        // 0x801371C8: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_801371D8;
    }
    goto skip_0;
    // 0x801371C8: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    skip_0:
    // 0x801371CC: jal         0x8013724C
    // 0x801371D0: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    func_8013724C(rdram, ctx);
        goto after_0;
    // 0x801371D0: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    after_0:
    // 0x801371D4: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
L_801371D8:
    // 0x801371D8: sll         $t0, $s0, 16
    ctx->r8 = S32(ctx->r16 << 16);
    // 0x801371DC: sra         $s0, $t0, 16
    ctx->r16 = S32(SIGNED(ctx->r8) >> 16);
    // 0x801371E0: slti        $at, $s0, 0x4
    ctx->r1 = SIGNED(ctx->r16) < 0X4 ? 1 : 0;
    // 0x801371E4: bnel        $at, $zero, L_80137190
    if (ctx->r1 != 0) {
        // 0x801371E8: sll         $t6, $s0, 1
        ctx->r14 = S32(ctx->r16 << 1);
            goto L_80137190;
    }
    goto skip_1;
    // 0x801371E8: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    skip_1:
    // 0x801371EC: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x801371F0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801371F4: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x801371F8: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x801371FC: jr          $ra
    // 0x80137200: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x80137200: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void func_80137204(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80137204: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80137208: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x8013720C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80137210: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80137214: addiu       $a1, $a1, 0x1100
    ctx->r5 = ADD32(ctx->r5, 0X1100);
    // 0x80137218: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8013721C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137220: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x80137224: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137228: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x8013722C: sw          $t6, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r14;
    // 0x80137230: addiu       $a0, $a0, 0x12B0
    ctx->r4 = ADD32(ctx->r4, 0X12B0);
    // 0x80137234: jal         0x80139050
    // 0x80137238: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSendMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x80137238: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x8013723C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80137240: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80137244: jr          $ra
    // 0x80137248: nop

    return;
    // 0x80137248: nop

;}
RECOMP_FUNC void func_8013724C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8013724C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80137250: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x80137254: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80137258: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x8013725C: addiu       $a1, $a1, 0x1100
    ctx->r5 = ADD32(ctx->r5, 0X1100);
    // 0x80137260: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80137264: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137268: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8013726C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137270: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x80137274: sw          $t6, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r14;
    // 0x80137278: addiu       $a0, $a0, 0x12B0
    ctx->r4 = ADD32(ctx->r4, 0X12B0);
    // 0x8013727C: jal         0x80139050
    // 0x80137280: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osSendMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x80137280: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x80137284: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80137288: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8013728C: jr          $ra
    // 0x80137290: nop

    return;
    // 0x80137290: nop

;}
RECOMP_FUNC void thread9(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80137294: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x80137298: sw          $s5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r21;
    // 0x8013729C: sw          $s3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r19;
    // 0x801372A0: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x801372A4: sw          $s7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r23;
    // 0x801372A8: sw          $s6, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r22;
    // 0x801372AC: sw          $s4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r20;
    // 0x801372B0: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x801372B4: lui         $s1, 0x8029
    ctx->r17 = S32(0X8029 << 16);
    // 0x801372B8: lui         $s3, 0x8029
    ctx->r19 = S32(0X8029 << 16);
    // 0x801372BC: lui         $s5, 0x8029
    ctx->r21 = S32(0X8029 << 16);
    // 0x801372C0: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x801372C4: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x801372C8: addiu       $s5, $s5, 0x12B0
    ctx->r21 = ADD32(ctx->r21, 0X12B0);
    // 0x801372CC: addiu       $s3, $s3, 0x1110
    ctx->r19 = ADD32(ctx->r19, 0X1110);
    // 0x801372D0: addiu       $s1, $s1, 0x1090
    ctx->r17 = ADD32(ctx->r17, 0X1090);
    // 0x801372D4: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x801372D8: addiu       $s4, $zero, 0x68
    ctx->r20 = ADD32(0, 0X68);
    // 0x801372DC: addiu       $s6, $sp, 0x44
    ctx->r22 = ADD32(ctx->r29, 0X44);
    // 0x801372E0: addiu       $s7, $zero, 0x2
    ctx->r23 = ADD32(0, 0X2);
    // 0x801372E4: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
L_801372E8:
    // 0x801372E8: or          $a1, $s6, $zero
    ctx->r5 = ctx->r22 | 0;
    // 0x801372EC: jal         0x80137FF0
    // 0x801372F0: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x801372F0: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    after_0:
    // 0x801372F4: jal         0x801370F4
    // 0x801372F8: nop

    func_801370F4(rdram, ctx);
        goto after_1;
    // 0x801372F8: nop

    after_1:
    // 0x801372FC: lw          $t6, 0x44($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X44);
    // 0x80137300: lh          $v0, 0x2($t6)
    ctx->r2 = MEM_H(ctx->r14, 0X2);
    // 0x80137304: lh          $s0, 0x6($t6)
    ctx->r16 = MEM_H(ctx->r14, 0X6);
    // 0x80137308: beq         $v0, $s2, L_80137354
    if (ctx->r2 == ctx->r18) {
        // 0x8013730C: nop
    
            goto L_80137354;
    }
    // 0x8013730C: nop

    // 0x80137310: bne         $v0, $s7, L_8013738C
    if (ctx->r2 != ctx->r23) {
        // 0x80137314: nop
    
            goto L_8013738C;
    }
    // 0x80137314: nop

    // 0x80137318: multu       $s0, $s4
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r20)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8013731C: mflo        $t7
    ctx->r15 = lo;
    // 0x80137320: addu        $a0, $s3, $t7
    ctx->r4 = ADD32(ctx->r19, ctx->r15);
    // 0x80137324: jal         0x8013EA30
    // 0x80137328: nop

    osMotorStart_recomp(rdram, ctx);
        goto after_2;
    // 0x80137328: nop

    after_2:
    // 0x8013732C: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x80137330: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80137334: bne         $t9, $zero, L_8013734C
    if (ctx->r25 != 0) {
        // 0x80137338: addu        $t2, $s1, $s0
        ctx->r10 = ADD32(ctx->r17, ctx->r16);
            goto L_8013734C;
    }
    // 0x80137338: addu        $t2, $s1, $s0
    ctx->r10 = ADD32(ctx->r17, ctx->r16);
    // 0x8013733C: sll         $t0, $s0, 1
    ctx->r8 = S32(ctx->r16 << 1);
    // 0x80137340: addu        $t1, $s1, $t0
    ctx->r9 = ADD32(ctx->r17, ctx->r8);
    // 0x80137344: b           L_8013738C
    // 0x80137348: sh          $s2, 0x4($t1)
    MEM_H(0X4, ctx->r9) = ctx->r18;
        goto L_8013738C;
    // 0x80137348: sh          $s2, 0x4($t1)
    MEM_H(0X4, ctx->r9) = ctx->r18;
L_8013734C:
    // 0x8013734C: b           L_8013738C
    // 0x80137350: sb          $zero, 0x0($t2)
    MEM_B(0X0, ctx->r10) = 0;
        goto L_8013738C;
    // 0x80137350: sb          $zero, 0x0($t2)
    MEM_B(0X0, ctx->r10) = 0;
L_80137354:
    // 0x80137354: multu       $s0, $s4
    result = U64(U32(ctx->r16)) * U64(U32(ctx->r20)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80137358: mflo        $t3
    ctx->r11 = lo;
    // 0x8013735C: addu        $a0, $s3, $t3
    ctx->r4 = ADD32(ctx->r19, ctx->r11);
    // 0x80137360: jal         0x8013E890
    // 0x80137364: nop

    osMotorStop_recomp(rdram, ctx);
        goto after_3;
    // 0x80137364: nop

    after_3:
    // 0x80137368: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x8013736C: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80137370: bne         $t5, $zero, L_80137388
    if (ctx->r13 != 0) {
        // 0x80137374: addu        $t8, $s1, $s0
        ctx->r24 = ADD32(ctx->r17, ctx->r16);
            goto L_80137388;
    }
    // 0x80137374: addu        $t8, $s1, $s0
    ctx->r24 = ADD32(ctx->r17, ctx->r16);
    // 0x80137378: sll         $t6, $s0, 1
    ctx->r14 = S32(ctx->r16 << 1);
    // 0x8013737C: addu        $t7, $s1, $t6
    ctx->r15 = ADD32(ctx->r17, ctx->r14);
    // 0x80137380: b           L_8013738C
    // 0x80137384: sh          $zero, 0x4($t7)
    MEM_H(0X4, ctx->r15) = 0;
        goto L_8013738C;
    // 0x80137384: sh          $zero, 0x4($t7)
    MEM_H(0X4, ctx->r15) = 0;
L_80137388:
    // 0x80137388: sb          $zero, 0x0($t8)
    MEM_B(0X0, ctx->r24) = 0;
L_8013738C:
    // 0x8013738C: jal         0x8013713C
    // 0x80137390: nop

    func_8013713C(rdram, ctx);
        goto after_4;
    // 0x80137390: nop

    after_4:
    // 0x80137394: b           L_801372E8
    // 0x80137398: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
        goto L_801372E8;
    // 0x80137398: or          $a0, $s5, $zero
    ctx->r4 = ctx->r21 | 0;
    // 0x8013739C: nop

    // 0x801373A0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x801373A4: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x801373A8: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x801373AC: lw          $s2, 0x1C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X1C);
    // 0x801373B0: lw          $s3, 0x20($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X20);
    // 0x801373B4: lw          $s4, 0x24($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X24);
    // 0x801373B8: lw          $s5, 0x28($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X28);
    // 0x801373BC: lw          $s6, 0x2C($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X2C);
    // 0x801373C0: lw          $s7, 0x30($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X30);
    // 0x801373C4: jr          $ra
    // 0x801373C8: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x801373C8: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void do_rumble(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801373CC: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x801373D0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x801373D4: lui         $v0, 0x8029
    ctx->r2 = S32(0X8029 << 16);
    // 0x801373D8: addiu       $v0, $v0, 0x1090
    ctx->r2 = ADD32(ctx->r2, 0X1090);
    // 0x801373DC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x801373E0: addu        $t1, $v0, $t7
    ctx->r9 = ADD32(ctx->r2, ctx->r15);
    // 0x801373E4: lb          $t2, 0x0($t1)
    ctx->r10 = MEM_B(ctx->r9, 0X0);
    // 0x801373E8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x801373EC: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x801373F0: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x801373F4: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x801373F8: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x801373FC: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x80137400: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80137404: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80137408: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8013740C: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x80137410: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x80137414: beq         $t2, $zero, L_801375D4
    if (ctx->r10 == 0) {
        // 0x80137418: sra         $t0, $s0, 6
        ctx->r8 = S32(SIGNED(ctx->r16) >> 6);
            goto L_801375D4;
    }
    // 0x80137418: sra         $t0, $s0, 6
    ctx->r8 = S32(SIGNED(ctx->r16) >> 6);
    // 0x8013741C: slti        $at, $t0, 0x15
    ctx->r1 = SIGNED(ctx->r8) < 0X15 ? 1 : 0;
    // 0x80137420: beq         $at, $zero, L_801375D4
    if (ctx->r1 == 0) {
        // 0x80137424: lui         $t3, 0x8020
        ctx->r11 = S32(0X8020 << 16);
            goto L_801375D4;
    }
    // 0x80137424: lui         $t3, 0x8020
    ctx->r11 = S32(0X8020 << 16);
    // 0x80137428: lb          $t3, 0x4288($t3)
    ctx->r11 = MEM_B(ctx->r11, 0X4288);
    // 0x8013742C: sll         $t5, $a0, 1
    ctx->r13 = S32(ctx->r4 << 1);
    // 0x80137430: sra         $t4, $t0, 2
    ctx->r12 = S32(SIGNED(ctx->r8) >> 2);
    // 0x80137434: bne         $t3, $zero, L_801375D4
    if (ctx->r11 != 0) {
        // 0x80137438: addu        $v1, $v0, $t5
        ctx->r3 = ADD32(ctx->r2, ctx->r13);
            goto L_801375D4;
    }
    // 0x80137438: addu        $v1, $v0, $t5
    ctx->r3 = ADD32(ctx->r2, ctx->r13);
    // 0x8013743C: bne         $t4, $zero, L_80137448
    if (ctx->r12 != 0) {
        // 0x80137440: or          $s0, $t4, $zero
        ctx->r16 = ctx->r12 | 0;
            goto L_80137448;
    }
    // 0x80137440: or          $s0, $t4, $zero
    ctx->r16 = ctx->r12 | 0;
    // 0x80137444: addiu       $s0, $zero, 0x1
    ctx->r16 = ADD32(0, 0X1);
L_80137448:
    // 0x80137448: lh          $a1, 0x1C($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X1C);
    // 0x8013744C: beql        $a1, $zero, L_80137524
    if (ctx->r5 == 0) {
        // 0x80137450: lh          $t3, 0x3A($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X3A);
            goto L_80137524;
    }
    goto skip_0;
    // 0x80137450: lh          $t3, 0x3A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X3A);
    skip_0:
    // 0x80137454: lh          $v0, 0x24($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X24);
    // 0x80137458: lh          $a0, 0xC($v1)
    ctx->r4 = MEM_H(ctx->r3, 0XC);
    // 0x8013745C: lh          $t6, 0x14($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X14);
    // 0x80137460: subu        $t8, $a1, $v0
    ctx->r24 = SUB32(ctx->r5, ctx->r2);
    // 0x80137464: lh          $t5, 0x36($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X36);
    // 0x80137468: subu        $t7, $t6, $a0
    ctx->r15 = SUB32(ctx->r14, ctx->r4);
    // 0x8013746C: multu       $t7, $t8
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80137470: lh          $t6, 0x3A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X3A);
    // 0x80137474: addu        $t7, $t6, $a3
    ctx->r15 = ADD32(ctx->r14, ctx->r7);
    // 0x80137478: mflo        $t9
    ctx->r25 = lo;
    // 0x8013747C: nop

    // 0x80137480: nop

    // 0x80137484: div         $zero, $t9, $a1
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r5))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r5)));
    // 0x80137488: mflo        $t0
    ctx->r8 = lo;
    // 0x8013748C: sra         $t1, $t0, 1
    ctx->r9 = S32(SIGNED(ctx->r8) >> 1);
    // 0x80137490: addu        $t2, $t1, $a0
    ctx->r10 = ADD32(ctx->r9, ctx->r4);
    // 0x80137494: multu       $v0, $t2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80137498: bne         $a1, $zero, L_801374A4
    if (ctx->r5 != 0) {
        // 0x8013749C: nop
    
            goto L_801374A4;
    }
    // 0x8013749C: nop

    // 0x801374A0: break       7
    do_break(2148758688);
L_801374A4:
    // 0x801374A4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801374A8: bne         $a1, $at, L_801374BC
    if (ctx->r5 != ctx->r1) {
        // 0x801374AC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_801374BC;
    }
    // 0x801374AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801374B0: bne         $t9, $at, L_801374BC
    if (ctx->r25 != ctx->r1) {
        // 0x801374B4: nop
    
            goto L_801374BC;
    }
    // 0x801374B4: nop

    // 0x801374B8: break       6
    do_break(2148758712);
L_801374BC:
    // 0x801374BC: mflo        $a2
    ctx->r6 = lo;
    // 0x801374C0: sll         $t9, $s0, 1
    ctx->r25 = S32(ctx->r16 << 1);
    // 0x801374C4: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x801374C8: multu       $t5, $t7
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801374CC: sra         $t4, $t3, 16
    ctx->r12 = S32(SIGNED(ctx->r11) >> 16);
    // 0x801374D0: or          $a2, $t4, $zero
    ctx->r6 = ctx->r12 | 0;
    // 0x801374D4: mflo        $t8
    ctx->r24 = lo;
    // 0x801374D8: nop

    // 0x801374DC: nop

    // 0x801374E0: div         $zero, $t8, $t9
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r25))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r25)));
    // 0x801374E4: bne         $t9, $zero, L_801374F0
    if (ctx->r25 != 0) {
        // 0x801374E8: nop
    
            goto L_801374F0;
    }
    // 0x801374E8: nop

    // 0x801374EC: break       7
    do_break(2148758764);
L_801374F0:
    // 0x801374F0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x801374F4: bne         $t9, $at, L_80137508
    if (ctx->r25 != ctx->r1) {
        // 0x801374F8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80137508;
    }
    // 0x801374F8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x801374FC: bne         $t8, $at, L_80137508
    if (ctx->r24 != ctx->r1) {
        // 0x80137500: nop
    
            goto L_80137508;
    }
    // 0x80137500: nop

    // 0x80137504: break       6
    do_break(2148758788);
L_80137508:
    // 0x80137508: mflo        $t0
    ctx->r8 = lo;
    // 0x8013750C: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x80137510: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80137514: slt         $at, $t2, $a2
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80137518: bnel        $at, $zero, L_801375D8
    if (ctx->r1 != 0) {
        // 0x8013751C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_801375D8;
    }
    goto skip_1;
    // 0x8013751C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80137520: lh          $t3, 0x3A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X3A);
L_80137524:
    // 0x80137524: sh          $zero, 0x4($v1)
    MEM_H(0X4, ctx->r3) = 0;
    // 0x80137528: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x8013752C: div         $zero, $t3, $s0
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r16))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r16)));
    // 0x80137530: mflo        $t4
    ctx->r12 = lo;
    // 0x80137534: lh          $t5, 0x36($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X36);
    // 0x80137538: bne         $s0, $zero, L_80137544
    if (ctx->r16 != 0) {
        // 0x8013753C: nop
    
            goto L_80137544;
    }
    // 0x8013753C: nop

    // 0x80137540: break       7
    do_break(2148758848);
L_80137544:
    // 0x80137544: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80137548: bne         $s0, $at, L_8013755C
    if (ctx->r16 != ctx->r1) {
        // 0x8013754C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8013755C;
    }
    // 0x8013754C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80137550: bne         $t3, $at, L_8013755C
    if (ctx->r11 != ctx->r1) {
        // 0x80137554: nop
    
            goto L_8013755C;
    }
    // 0x80137554: nop

    // 0x80137558: break       6
    do_break(2148758872);
L_8013755C:
    // 0x8013755C: div         $zero, $a3, $s0
    lo = S32(S64(S32(ctx->r7)) / S64(S32(ctx->r16))); hi = S32(S64(S32(ctx->r7)) % S64(S32(ctx->r16)));
    // 0x80137560: lh          $t7, 0x36($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X36);
    // 0x80137564: mflo        $t6
    ctx->r14 = lo;
    // 0x80137568: addiu       $t8, $zero, 0x100
    ctx->r24 = ADD32(0, 0X100);
    // 0x8013756C: sh          $t4, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r12;
    // 0x80137570: bne         $s0, $zero, L_8013757C
    if (ctx->r16 != 0) {
        // 0x80137574: nop
    
            goto L_8013757C;
    }
    // 0x80137574: nop

    // 0x80137578: break       7
    do_break(2148758904);
L_8013757C:
    // 0x8013757C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80137580: bne         $s0, $at, L_80137594
    if (ctx->r16 != ctx->r1) {
        // 0x80137584: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80137594;
    }
    // 0x80137584: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80137588: bne         $a3, $at, L_80137594
    if (ctx->r7 != ctx->r1) {
        // 0x8013758C: nop
    
            goto L_80137594;
    }
    // 0x8013758C: nop

    // 0x80137590: break       6
    do_break(2148758928);
L_80137594:
    // 0x80137594: sh          $t6, 0x14($v1)
    MEM_H(0X14, ctx->r3) = ctx->r14;
    // 0x80137598: sh          $zero, 0x2C($v1)
    MEM_H(0X2C, ctx->r3) = 0;
    // 0x8013759C: sh          $t8, 0x34($v1)
    MEM_H(0X34, ctx->r3) = ctx->r24;
    // 0x801375A0: sh          $t5, 0x1C($v1)
    MEM_H(0X1C, ctx->r3) = ctx->r13;
    // 0x801375A4: beq         $t9, $zero, L_801375D4
    if (ctx->r25 == 0) {
        // 0x801375A8: sh          $t7, 0x24($v1)
        MEM_H(0X24, ctx->r3) = ctx->r15;
            goto L_801375D4;
    }
    // 0x801375A8: sh          $t7, 0x24($v1)
    MEM_H(0X24, ctx->r3) = ctx->r15;
    // 0x801375AC: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x801375B0: addiu       $a0, $a0, 0x1110
    ctx->r4 = ADD32(ctx->r4, 0X1110);
    // 0x801375B4: jal         0x8013EA30
    // 0x801375B8: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    osMotorStart_recomp(rdram, ctx);
        goto after_0;
    // 0x801375B8: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    after_0:
    // 0x801375BC: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x801375C0: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x801375C4: bne         $t1, $zero, L_801375D4
    if (ctx->r9 != 0) {
        // 0x801375C8: lw          $v1, 0x24($sp)
        ctx->r3 = MEM_W(ctx->r29, 0X24);
            goto L_801375D4;
    }
    // 0x801375C8: lw          $v1, 0x24($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X24);
    // 0x801375CC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x801375D0: sh          $t2, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r10;
L_801375D4:
    // 0x801375D4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801375D8:
    // 0x801375D8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801375DC: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x801375E0: jr          $ra
    // 0x801375E4: nop

    return;
    // 0x801375E4: nop

;}
RECOMP_FUNC void func_801375E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x801375E8: sll         $a3, $a0, 16
    ctx->r7 = S32(ctx->r4 << 16);
    // 0x801375EC: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x801375F0: addiu       $v1, $v1, 0x1090
    ctx->r3 = ADD32(ctx->r3, 0X1090);
    // 0x801375F4: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x801375F8: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x801375FC: lb          $t8, 0x0($t7)
    ctx->r24 = MEM_B(ctx->r15, 0X0);
    // 0x80137600: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80137604: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137608: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x8013760C: bne         $t8, $zero, L_801376A0
    if (ctx->r24 != 0) {
        // 0x80137610: or          $a3, $t6, $zero
        ctx->r7 = ctx->r14 | 0;
            goto L_801376A0;
    }
    // 0x80137610: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80137614: lui         $a3, 0x8029
    ctx->r7 = S32(0X8029 << 16);
    // 0x80137618: addiu       $a3, $a3, 0x12DC
    ctx->r7 = ADD32(ctx->r7, 0X12DC);
    // 0x8013761C: lh          $t9, 0x0($a3)
    ctx->r25 = MEM_H(ctx->r7, 0X0);
    // 0x80137620: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137624: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80137628: addiu       $t0, $t9, 0x1
    ctx->r8 = ADD32(ctx->r25, 0X1);
    // 0x8013762C: sh          $t0, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r8;
    // 0x80137630: lh          $t1, 0x0($a3)
    ctx->r9 = MEM_H(ctx->r7, 0X0);
    // 0x80137634: addiu       $a1, $a1, 0x1110
    ctx->r5 = ADD32(ctx->r5, 0X1110);
    // 0x80137638: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    // 0x8013763C: slti        $at, $t1, 0x3D
    ctx->r1 = SIGNED(ctx->r9) < 0X3D ? 1 : 0;
    // 0x80137640: bnel        $at, $zero, L_80137834
    if (ctx->r1 != 0) {
        // 0x80137644: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80137834;
    }
    goto skip_0;
    // 0x80137644: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x80137648: jal         0x8013ED4C
    // 0x8013764C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osMotorInit_recomp(rdram, ctx);
        goto after_0;
    // 0x8013764C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_0:
    // 0x80137650: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80137654: lui         $a3, 0x8029
    ctx->r7 = S32(0X8029 << 16);
    // 0x80137658: addiu       $a3, $a3, 0x12DC
    ctx->r7 = ADD32(ctx->r7, 0X12DC);
    // 0x8013765C: bne         $v0, $zero, L_80137670
    if (ctx->r2 != 0) {
        // 0x80137660: addiu       $v1, $v1, 0x1090
        ctx->r3 = ADD32(ctx->r3, 0X1090);
            goto L_80137670;
    }
    // 0x80137660: addiu       $v1, $v1, 0x1090
    ctx->r3 = ADD32(ctx->r3, 0X1090);
    // 0x80137664: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80137668: b           L_80137674
    // 0x8013766C: sb          $t2, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r10;
        goto L_80137674;
    // 0x8013766C: sb          $t2, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r10;
L_80137670:
    // 0x80137670: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
L_80137674:
    // 0x80137674: lb          $t3, 0x0($v1)
    ctx->r11 = MEM_B(ctx->r3, 0X0);
    // 0x80137678: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8013767C: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137680: bne         $t3, $at, L_80137698
    if (ctx->r11 != ctx->r1) {
        // 0x80137684: nop
    
            goto L_80137698;
    }
    // 0x80137684: nop

    // 0x80137688: jal         0x8013E890
    // 0x8013768C: addiu       $a0, $a0, 0x1110
    ctx->r4 = ADD32(ctx->r4, 0X1110);
    osMotorStop_recomp(rdram, ctx);
        goto after_1;
    // 0x8013768C: addiu       $a0, $a0, 0x1110
    ctx->r4 = ADD32(ctx->r4, 0X1110);
    after_1:
    // 0x80137690: lui         $a3, 0x8029
    ctx->r7 = S32(0X8029 << 16);
    // 0x80137694: addiu       $a3, $a3, 0x12DC
    ctx->r7 = ADD32(ctx->r7, 0X12DC);
L_80137698:
    // 0x80137698: b           L_80137830
    // 0x8013769C: sh          $zero, 0x0($a3)
    MEM_H(0X0, ctx->r7) = 0;
        goto L_80137830;
    // 0x8013769C: sh          $zero, 0x0($a3)
    MEM_H(0X0, ctx->r7) = 0;
L_801376A0:
    // 0x801376A0: sll         $t4, $a3, 1
    ctx->r12 = S32(ctx->r7 << 1);
    // 0x801376A4: addu        $a1, $v1, $t4
    ctx->r5 = ADD32(ctx->r3, ctx->r12);
    // 0x801376A8: lh          $a0, 0x1C($a1)
    ctx->r4 = MEM_H(ctx->r5, 0X1C);
    // 0x801376AC: beql        $a0, $zero, L_80137728
    if (ctx->r4 == 0) {
        // 0x801376B0: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_80137728;
    }
    goto skip_1;
    // 0x801376B0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    skip_1:
    // 0x801376B4: lh          $v0, 0xC($a1)
    ctx->r2 = MEM_H(ctx->r5, 0XC);
    // 0x801376B8: lh          $v1, 0x24($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X24);
    // 0x801376BC: lh          $t5, 0x14($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X14);
    // 0x801376C0: subu        $t7, $a0, $v1
    ctx->r15 = SUB32(ctx->r4, ctx->r3);
    // 0x801376C4: subu        $t6, $t5, $v0
    ctx->r14 = SUB32(ctx->r13, ctx->r2);
    // 0x801376C8: multu       $t6, $t7
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801376CC: addiu       $t0, $v1, -0x1
    ctx->r8 = ADD32(ctx->r3, -0X1);
    // 0x801376D0: sh          $t0, 0x24($a1)
    MEM_H(0X24, ctx->r5) = ctx->r8;
    // 0x801376D4: lh          $t1, 0x24($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X24);
    // 0x801376D8: mflo        $t8
    ctx->r24 = lo;
    // 0x801376DC: nop

    // 0x801376E0: nop

    // 0x801376E4: div         $zero, $t8, $a0
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r4))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r4)));
    // 0x801376E8: mflo        $t9
    ctx->r25 = lo;
    // 0x801376EC: addu        $a2, $v0, $t9
    ctx->r6 = ADD32(ctx->r2, ctx->r25);
    // 0x801376F0: bne         $a0, $zero, L_801376FC
    if (ctx->r4 != 0) {
        // 0x801376F4: nop
    
            goto L_801376FC;
    }
    // 0x801376F4: nop

    // 0x801376F8: break       7
    do_break(2148759288);
L_801376FC:
    // 0x801376FC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80137700: bne         $a0, $at, L_80137714
    if (ctx->r4 != ctx->r1) {
        // 0x80137704: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80137714;
    }
    // 0x80137704: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80137708: bne         $t8, $at, L_80137714
    if (ctx->r24 != ctx->r1) {
        // 0x8013770C: nop
    
            goto L_80137714;
    }
    // 0x8013770C: nop

    // 0x80137710: break       6
    do_break(2148759312);
L_80137714:
    // 0x80137714: bnel        $t1, $zero, L_8013772C
    if (ctx->r9 != 0) {
        // 0x80137718: slti        $at, $a2, 0x47
        ctx->r1 = SIGNED(ctx->r6) < 0X47 ? 1 : 0;
            goto L_8013772C;
    }
    goto skip_2;
    // 0x80137718: slti        $at, $a2, 0x47
    ctx->r1 = SIGNED(ctx->r6) < 0X47 ? 1 : 0;
    skip_2:
    // 0x8013771C: b           L_80137728
    // 0x80137720: sh          $zero, 0x1C($a1)
    MEM_H(0X1C, ctx->r5) = 0;
        goto L_80137728;
    // 0x80137720: sh          $zero, 0x1C($a1)
    MEM_H(0X1C, ctx->r5) = 0;
    // 0x80137724: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_80137728:
    // 0x80137728: slti        $at, $a2, 0x47
    ctx->r1 = SIGNED(ctx->r6) < 0X47 ? 1 : 0;
L_8013772C:
    // 0x8013772C: bnel        $at, $zero, L_80137768
    if (ctx->r1 != 0) {
        // 0x80137730: slti        $at, $a2, 0x6
        ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
            goto L_80137768;
    }
    goto skip_3;
    // 0x80137730: slti        $at, $a2, 0x6
    ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
    skip_3:
    // 0x80137734: lh          $t2, 0x4($a1)
    ctx->r10 = MEM_H(ctx->r5, 0X4);
    // 0x80137738: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x8013773C: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80137740: bne         $t2, $zero, L_80137764
    if (ctx->r10 != 0) {
        // 0x80137744: or          $a0, $t3, $zero
        ctx->r4 = ctx->r11 | 0;
            goto L_80137764;
    }
    // 0x80137744: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80137748: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x8013774C: sw          $a2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r6;
    // 0x80137750: jal         0x80137204
    // 0x80137754: sh          $a3, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r7;
    func_80137204(rdram, ctx);
        goto after_2;
    // 0x80137754: sh          $a3, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r7;
    after_2:
    // 0x80137758: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x8013775C: lw          $a2, 0x24($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X24);
    // 0x80137760: lh          $a3, 0x2A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2A);
L_80137764:
    // 0x80137764: slti        $at, $a2, 0x6
    ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
L_80137768:
    // 0x80137768: beql        $at, $zero, L_801377A4
    if (ctx->r1 == 0) {
        // 0x8013776C: slti        $at, $a2, 0x6
        ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
            goto L_801377A4;
    }
    goto skip_4;
    // 0x8013776C: slti        $at, $a2, 0x6
    ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
    skip_4:
    // 0x80137770: lh          $t4, 0x4($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X4);
    // 0x80137774: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x80137778: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8013777C: beq         $t4, $zero, L_801377A0
    if (ctx->r12 == 0) {
        // 0x80137780: or          $a0, $t5, $zero
        ctx->r4 = ctx->r13 | 0;
            goto L_801377A0;
    }
    // 0x80137780: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80137784: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x80137788: sw          $a2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r6;
    // 0x8013778C: jal         0x8013724C
    // 0x80137790: sh          $a3, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r7;
    func_8013724C(rdram, ctx);
        goto after_3;
    // 0x80137790: sh          $a3, 0x2A($sp)
    MEM_H(0X2A, ctx->r29) = ctx->r7;
    after_3:
    // 0x80137794: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80137798: lw          $a2, 0x24($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X24);
    // 0x8013779C: lh          $a3, 0x2A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X2A);
L_801377A0:
    // 0x801377A0: slti        $at, $a2, 0x6
    ctx->r1 = SIGNED(ctx->r6) < 0X6 ? 1 : 0;
L_801377A4:
    // 0x801377A4: bne         $at, $zero, L_80137830
    if (ctx->r1 != 0) {
        // 0x801377A8: slti        $at, $a2, 0x47
        ctx->r1 = SIGNED(ctx->r6) < 0X47 ? 1 : 0;
            goto L_80137830;
    }
    // 0x801377A8: slti        $at, $a2, 0x47
    ctx->r1 = SIGNED(ctx->r6) < 0X47 ? 1 : 0;
    // 0x801377AC: beql        $at, $zero, L_80137834
    if (ctx->r1 == 0) {
        // 0x801377B0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80137834;
    }
    goto skip_5;
    // 0x801377B0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x801377B4: lh          $v0, 0x34($a1)
    ctx->r2 = MEM_H(ctx->r5, 0X34);
    // 0x801377B8: lh          $v1, 0x4($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X4);
    // 0x801377BC: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x801377C0: bne         $at, $zero, L_801377E8
    if (ctx->r1 != 0) {
        // 0x801377C4: addiu       $t6, $v0, -0x100
        ctx->r14 = ADD32(ctx->r2, -0X100);
            goto L_801377E8;
    }
    // 0x801377C4: addiu       $t6, $v0, -0x100
    ctx->r14 = ADD32(ctx->r2, -0X100);
    // 0x801377C8: bne         $v1, $zero, L_80137830
    if (ctx->r3 != 0) {
        // 0x801377CC: sh          $t6, 0x34($a1)
        MEM_H(0X34, ctx->r5) = ctx->r14;
            goto L_80137830;
    }
    // 0x801377CC: sh          $t6, 0x34($a1)
    MEM_H(0X34, ctx->r5) = ctx->r14;
    // 0x801377D0: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x801377D4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x801377D8: jal         0x80137204
    // 0x801377DC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    func_80137204(rdram, ctx);
        goto after_4;
    // 0x801377DC: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    after_4:
    // 0x801377E0: b           L_80137834
    // 0x801377E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80137834;
    // 0x801377E4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801377E8:
    // 0x801377E8: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x801377EC: sll         $a0, $a3, 16
    ctx->r4 = S32(ctx->r7 << 16);
    // 0x801377F0: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x801377F4: mflo        $t8
    ctx->r24 = lo;
    // 0x801377F8: nop

    // 0x801377FC: nop

    // 0x80137800: multu       $t8, $a2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80137804: mflo        $t9
    ctx->r25 = lo;
    // 0x80137808: bgez        $t9, L_80137818
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8013780C: sra         $t0, $t9, 9
        ctx->r8 = S32(SIGNED(ctx->r25) >> 9);
            goto L_80137818;
    }
    // 0x8013780C: sra         $t0, $t9, 9
    ctx->r8 = S32(SIGNED(ctx->r25) >> 9);
    // 0x80137810: addiu       $at, $t9, 0x1FF
    ctx->r1 = ADD32(ctx->r25, 0X1FF);
    // 0x80137814: sra         $t0, $at, 9
    ctx->r8 = S32(SIGNED(ctx->r1) >> 9);
L_80137818:
    // 0x80137818: addu        $t1, $v0, $t0
    ctx->r9 = ADD32(ctx->r2, ctx->r8);
    // 0x8013781C: addiu       $t2, $t1, 0x4
    ctx->r10 = ADD32(ctx->r9, 0X4);
    // 0x80137820: beq         $v1, $zero, L_80137830
    if (ctx->r3 == 0) {
        // 0x80137824: sh          $t2, 0x34($a1)
        MEM_H(0X34, ctx->r5) = ctx->r10;
            goto L_80137830;
    }
    // 0x80137824: sh          $t2, 0x34($a1)
    MEM_H(0X34, ctx->r5) = ctx->r10;
    // 0x80137828: jal         0x8013724C
    // 0x8013782C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    func_8013724C(rdram, ctx);
        goto after_5;
    // 0x8013782C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    after_5:
L_80137830:
    // 0x80137830: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80137834:
    // 0x80137834: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80137838: jr          $ra
    // 0x8013783C: nop

    return;
    // 0x8013783C: nop

;}
RECOMP_FUNC void init_rumble_pak(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80137840: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80137844: addiu       $v1, $v1, 0x1090
    ctx->r3 = ADD32(ctx->r3, 0X1090);
    // 0x80137848: lb          $t6, 0x0($v1)
    ctx->r14 = MEM_B(ctx->r3, 0X0);
    // 0x8013784C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80137850: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80137854: beq         $t6, $zero, L_801378A8
    if (ctx->r14 == 0) {
        // 0x80137858: lui         $a0, 0x8029
        ctx->r4 = S32(0X8029 << 16);
            goto L_801378A8;
    }
    // 0x80137858: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x8013785C: lui         $a1, 0x8029
    ctx->r5 = S32(0X8029 << 16);
    // 0x80137860: addiu       $a1, $a1, 0x1110
    ctx->r5 = ADD32(ctx->r5, 0X1110);
    // 0x80137864: addiu       $a0, $a0, -0x2F58
    ctx->r4 = ADD32(ctx->r4, -0X2F58);
    // 0x80137868: jal         0x8013ED4C
    // 0x8013786C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osMotorInit_recomp(rdram, ctx);
        goto after_0;
    // 0x8013786C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_0:
    // 0x80137870: lui         $v1, 0x8029
    ctx->r3 = S32(0X8029 << 16);
    // 0x80137874: bne         $v0, $zero, L_80137888
    if (ctx->r2 != 0) {
        // 0x80137878: addiu       $v1, $v1, 0x1090
        ctx->r3 = ADD32(ctx->r3, 0X1090);
            goto L_80137888;
    }
    // 0x80137878: addiu       $v1, $v1, 0x1090
    ctx->r3 = ADD32(ctx->r3, 0X1090);
    // 0x8013787C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80137880: b           L_8013788C
    // 0x80137884: sb          $t7, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r15;
        goto L_8013788C;
    // 0x80137884: sb          $t7, 0x0($v1)
    MEM_B(0X0, ctx->r3) = ctx->r15;
L_80137888:
    // 0x80137888: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
L_8013788C:
    // 0x8013788C: lb          $t8, 0x0($v1)
    ctx->r24 = MEM_B(ctx->r3, 0X0);
    // 0x80137890: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80137894: lui         $a0, 0x8029
    ctx->r4 = S32(0X8029 << 16);
    // 0x80137898: bnel        $t8, $at, L_801378AC
    if (ctx->r24 != ctx->r1) {
        // 0x8013789C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_801378AC;
    }
    goto skip_0;
    // 0x8013789C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x801378A0: jal         0x8013E890
    // 0x801378A4: addiu       $a0, $a0, 0x1110
    ctx->r4 = ADD32(ctx->r4, 0X1110);
    osMotorStop_recomp(rdram, ctx);
        goto after_1;
    // 0x801378A4: addiu       $a0, $a0, 0x1110
    ctx->r4 = ADD32(ctx->r4, 0X1110);
    after_1:
L_801378A8:
    // 0x801378A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_801378AC:
    // 0x801378AC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x801378B0: jr          $ra
    // 0x801378B4: nop

    return;
    // 0x801378B4: nop

;}
RECOMP_FUNC void sqrtf_recomp(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80137E10: jr          $ra
    // 0x80137E14: sqrt.s      $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.fl = sqrtf(ctx->f12.fl);
    return;
    // 0x80137E14: sqrt.s      $f0, $f12
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); 
    ctx->f0.fl = sqrtf(ctx->f12.fl);
;}
RECOMP_FUNC void __scTaskReady(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138330: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80138334: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80138338: beq         $a0, $zero, L_8013836C
    if (ctx->r4 == 0) {
        // 0x8013833C: sw          $a0, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r4;
            goto L_8013836C;
    }
    // 0x8013833C: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x80138340: jal         0x80142410
    // 0x80138344: nop

    osViGetCurrentFramebuffer_recomp(rdram, ctx);
        goto after_0;
    // 0x80138344: nop

    after_0:
    // 0x80138348: jal         0x80142450
    // 0x8013834C: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    osViGetNextFramebuffer_recomp(rdram, ctx);
        goto after_1;
    // 0x8013834C: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    after_1:
    // 0x80138350: lw          $t7, 0x18($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X18);
    // 0x80138354: beq         $v0, $t7, L_80138364
    if (ctx->r2 == ctx->r15) {
        // 0x80138358: nop
    
            goto L_80138364;
    }
    // 0x80138358: nop

    // 0x8013835C: b           L_80138370
    // 0x80138360: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80138370;
    // 0x80138360: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80138364:
    // 0x80138364: b           L_80138370
    // 0x80138368: lw          $v0, 0x28($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X28);
        goto L_80138370;
    // 0x80138368: lw          $v0, 0x28($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X28);
L_8013836C:
    // 0x8013836C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80138370:
    // 0x80138370: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80138374: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80138378: jr          $ra
    // 0x8013837C: nop

    return;
    // 0x8013837C: nop

;}
RECOMP_FUNC void __scExec(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138380: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80138384: beq         $s0, $zero, L_801383D4
    if (ctx->r16 == 0) {
        // 0x80138388: sw          $ra, 0x14($sp)
        MEM_W(0X14, ctx->r29) = ctx->r31;
            goto L_801383D4;
    }
    // 0x80138388: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8013838C: lw          $t6, 0x10($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X10);
    // 0x80138390: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80138394: bnel        $t6, $at, L_801383A8
    if (ctx->r14 != ctx->r1) {
        // 0x80138398: lw          $t7, 0x4($s0)
        ctx->r15 = MEM_W(ctx->r16, 0X4);
            goto L_801383A8;
    }
    goto skip_0;
    // 0x80138398: lw          $t7, 0x4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X4);
    skip_0:
    // 0x8013839C: jal         0x80137EB0
    // 0x801383A0: nop

    osWritebackDCacheAll_recomp(rdram, ctx);
        goto after_0;
    // 0x801383A0: nop

    after_0:
    // 0x801383A4: lw          $t7, 0x4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X4);
L_801383A8:
    // 0x801383A8: addiu       $at, $zero, -0x31
    ctx->r1 = ADD32(0, -0X31);
    // 0x801383AC: addiu       $s2, $s0, 0x10
    ctx->r18 = ADD32(ctx->r16, 0X10);
    // 0x801383B0: and         $t8, $t7, $at
    ctx->r24 = ctx->r15 & ctx->r1;
    // 0x801383B4: sw          $t8, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r24;
    // 0x801383B8: jal         0x801425FC
    // 0x801383BC: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    osSpTaskLoad_recomp(rdram, ctx);
        goto after_1;
    // 0x801383BC: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_1:
    // 0x801383C0: jal         0x8014278C
    // 0x801383C4: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    osSpTaskStartGo_recomp(rdram, ctx);
        goto after_2;
    // 0x801383C4: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    after_2:
    // 0x801383C8: bne         $s0, $s1, L_801383D4
    if (ctx->r16 != ctx->r17) {
        // 0x801383CC: sw          $s0, 0x274($s3)
        MEM_W(0X274, ctx->r19) = ctx->r16;
            goto L_801383D4;
    }
    // 0x801383CC: sw          $s0, 0x274($s3)
    MEM_W(0X274, ctx->r19) = ctx->r16;
    // 0x801383D0: sw          $s1, 0x278($s3)
    MEM_W(0X278, ctx->r19) = ctx->r17;
L_801383D4:
    // 0x801383D4: beql        $s1, $zero, L_80138414
    if (ctx->r17 == 0) {
        // 0x801383D8: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80138414;
    }
    goto skip_1;
    // 0x801383D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x801383DC: beql        $s1, $s0, L_80138414
    if (ctx->r17 == ctx->r16) {
        // 0x801383E0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80138414;
    }
    goto skip_2;
    // 0x801383E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x801383E4: lw          $t9, 0x3C($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X3C);
    // 0x801383E8: lw          $a0, 0x38($s1)
    ctx->r4 = MEM_W(ctx->r17, 0X38);
    // 0x801383EC: lw          $a2, 0x0($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X0);
    // 0x801383F0: jal         0x801427D0
    // 0x801383F4: lw          $a3, 0x4($t9)
    ctx->r7 = MEM_W(ctx->r25, 0X4);
    osDpSetNextBuffer_recomp(rdram, ctx);
        goto after_3;
    // 0x801383F4: lw          $a3, 0x4($t9)
    ctx->r7 = MEM_W(ctx->r25, 0X4);
    after_3:
    // 0x801383F8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x801383FC: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80138400: sw          $t6, -0x6690($at)
    MEM_W(-0X6690, ctx->r1) = ctx->r14;
    // 0x80138404: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80138408: sw          $zero, -0x668C($at)
    MEM_W(-0X668C, ctx->r1) = 0;
    // 0x8013840C: sw          $s1, 0x278($s3)
    MEM_W(0X278, ctx->r19) = ctx->r17;
    // 0x80138410: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80138414:
    // 0x80138414: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80138418: jr          $ra
    // 0x8013841C: nop

    return;
    // 0x8013841C: nop

;}
RECOMP_FUNC void __scSchedule(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138420: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80138424: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80138428: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8013842C: or          $t0, $a0, $zero
    ctx->r8 = ctx->r4 | 0;
    // 0x80138430: addiu       $t1, $zero, -0x3
    ctx->r9 = ADD32(0, -0X3);
L_80138434:
    // 0x80138434: lw          $t6, 0x280($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X280);
    // 0x80138438: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x8013843C: lw          $s0, 0x268($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X268);
    // 0x80138440: beq         $t6, $zero, L_8013849C
    if (ctx->r14 == 0) {
        // 0x80138444: lw          $v0, 0x264($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X264);
            goto L_8013849C;
    }
    // 0x80138444: lw          $v0, 0x264($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X264);
    // 0x80138448: andi        $t7, $a3, 0x2
    ctx->r15 = ctx->r7 & 0X2;
    // 0x8013844C: beql        $t7, $zero, L_801384A0
    if (ctx->r15 == 0) {
        // 0x80138450: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_801384A0;
    }
    goto skip_0;
    // 0x80138450: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    skip_0:
    // 0x80138454: beql        $s0, $zero, L_8013847C
    if (ctx->r16 == 0) {
        // 0x80138458: sw          $v0, 0x0($a1)
        MEM_W(0X0, ctx->r5) = ctx->r2;
            goto L_8013847C;
    }
    goto skip_1;
    // 0x80138458: sw          $v0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r2;
    skip_1:
    // 0x8013845C: lw          $t8, 0x8($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X8);
    // 0x80138460: and         $v1, $a3, $t1
    ctx->r3 = ctx->r7 & ctx->r9;
    // 0x80138464: andi        $t9, $t8, 0x10
    ctx->r25 = ctx->r24 & 0X10;
    // 0x80138468: beql        $t9, $zero, L_8013847C
    if (ctx->r25 == 0) {
        // 0x8013846C: sw          $v0, 0x0($a1)
        MEM_W(0X0, ctx->r5) = ctx->r2;
            goto L_8013847C;
    }
    goto skip_2;
    // 0x8013846C: sw          $v0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r2;
    skip_2:
    // 0x80138470: b           L_801385E0
    // 0x80138474: sw          $s0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r16;
        goto L_801385E0;
    // 0x80138474: sw          $s0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r16;
    // 0x80138478: sw          $v0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r2;
L_8013847C:
    // 0x8013847C: lw          $t3, 0x264($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X264);
    // 0x80138480: sw          $zero, 0x280($t0)
    MEM_W(0X280, ctx->r8) = 0;
    // 0x80138484: and         $v1, $a3, $t1
    ctx->r3 = ctx->r7 & ctx->r9;
    // 0x80138488: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x8013848C: bne         $t4, $zero, L_801385E0
    if (ctx->r12 != 0) {
        // 0x80138490: sw          $t4, 0x264($t0)
        MEM_W(0X264, ctx->r8) = ctx->r12;
            goto L_801385E0;
    }
    // 0x80138490: sw          $t4, 0x264($t0)
    MEM_W(0X264, ctx->r8) = ctx->r12;
    // 0x80138494: b           L_801385E0
    // 0x80138498: sw          $zero, 0x26C($t0)
    MEM_W(0X26C, ctx->r8) = 0;
        goto L_801385E0;
    // 0x80138498: sw          $zero, 0x26C($t0)
    MEM_W(0X26C, ctx->r8) = 0;
L_8013849C:
    // 0x8013849C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
L_801384A0:
    // 0x801384A0: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x801384A4: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x801384A8: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x801384AC: sw          $a3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r7;
    // 0x801384B0: jal         0x80138330
    // 0x801384B4: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    __scTaskReady(rdram, ctx);
        goto after_0;
    // 0x801384B4: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    after_0:
    // 0x801384B8: lw          $v1, 0x24($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X24);
    // 0x801384BC: lw          $a1, 0x2C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X2C);
    // 0x801384C0: lw          $a2, 0x30($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X30);
    // 0x801384C4: lw          $a3, 0x34($sp)
    ctx->r7 = MEM_W(ctx->r29, 0X34);
    // 0x801384C8: lw          $t0, 0x28($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X28);
    // 0x801384CC: addiu       $t1, $zero, -0x3
    ctx->r9 = ADD32(0, -0X3);
    // 0x801384D0: beq         $v0, $zero, L_801385E0
    if (ctx->r2 == 0) {
        // 0x801384D4: addiu       $t2, $zero, -0x2
        ctx->r10 = ADD32(0, -0X2);
            goto L_801385E0;
    }
    // 0x801384D4: addiu       $t2, $zero, -0x2
    ctx->r10 = ADD32(0, -0X2);
    // 0x801384D8: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x801384DC: andi        $t7, $t6, 0x7
    ctx->r15 = ctx->r14 & 0X7;
    // 0x801384E0: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x801384E4: sltiu       $at, $t8, 0x7
    ctx->r1 = ctx->r24 < 0X7 ? 1 : 0;
    // 0x801384E8: beq         $at, $zero, L_801385E0
    if (ctx->r1 == 0) {
        // 0x801384EC: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_801385E0;
    }
    // 0x801384EC: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x801384F0: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x801384F4: addu        $at, $at, $t8
    gpr jr_addend_801384FC = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x801384F8: lw          $t8, -0x4F90($at)
    ctx->r24 = ADD32(ctx->r1, -0X4F90);
    // 0x801384FC: jr          $t8
    // 0x80138500: nop

    switch (jr_addend_801384FC >> 2) {
        case 0: goto L_801385E0; break;
        case 1: goto L_8013858C; break;
        case 2: goto L_80138504; break;
        case 3: goto L_801385E0; break;
        case 4: goto L_801385E0; break;
        case 5: goto L_8013858C; break;
        case 6: goto L_8013858C; break;
        default: switch_error(__func__, 0x801384FC, 0x8015B070);
    }
    // 0x80138500: nop

L_80138504:
    // 0x80138504: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
    // 0x80138508: andi        $t4, $a3, 0x2
    ctx->r12 = ctx->r7 & 0X2;
    // 0x8013850C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80138510: andi        $t3, $t9, 0x20
    ctx->r11 = ctx->r25 & 0X20;
    // 0x80138514: beq         $t3, $zero, L_8013855C
    if (ctx->r11 == 0) {
        // 0x80138518: nop
    
            goto L_8013855C;
    }
    // 0x80138518: nop

    // 0x8013851C: beq         $t4, $zero, L_801385E0
    if (ctx->r12 == 0) {
        // 0x80138520: nop
    
            goto L_801385E0;
    }
    // 0x80138520: nop

    // 0x80138524: sw          $s0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r16;
    // 0x80138528: lw          $t5, 0x4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X4);
    // 0x8013852C: and         $v1, $a3, $t1
    ctx->r3 = ctx->r7 & ctx->r9;
    // 0x80138530: andi        $t6, $t5, 0x1
    ctx->r14 = ctx->r13 & 0X1;
    // 0x80138534: beql        $t6, $zero, L_80138548
    if (ctx->r14 == 0) {
        // 0x80138538: lw          $t7, 0x268($t0)
        ctx->r15 = MEM_W(ctx->r8, 0X268);
            goto L_80138548;
    }
    goto skip_3;
    // 0x80138538: lw          $t7, 0x268($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X268);
    skip_3:
    // 0x8013853C: sw          $s0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r16;
    // 0x80138540: and         $v1, $v1, $t2
    ctx->r3 = ctx->r3 & ctx->r10;
    // 0x80138544: lw          $t7, 0x268($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X268);
L_80138548:
    // 0x80138548: lw          $t8, 0x0($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X0);
    // 0x8013854C: bne         $t8, $zero, L_801385E0
    if (ctx->r24 != 0) {
        // 0x80138550: sw          $t8, 0x268($t0)
        MEM_W(0X268, ctx->r8) = ctx->r24;
            goto L_801385E0;
    }
    // 0x80138550: sw          $t8, 0x268($t0)
    MEM_W(0X268, ctx->r8) = ctx->r24;
    // 0x80138554: b           L_801385E0
    // 0x80138558: sw          $zero, 0x270($t0)
    MEM_W(0X270, ctx->r8) = 0;
        goto L_801385E0;
    // 0x80138558: sw          $zero, 0x270($t0)
    MEM_W(0X270, ctx->r8) = 0;
L_8013855C:
    // 0x8013855C: bne         $a3, $at, L_801385E0
    if (ctx->r7 != ctx->r1) {
        // 0x80138560: nop
    
            goto L_801385E0;
    }
    // 0x80138560: nop

    // 0x80138564: sw          $s0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r16;
    // 0x80138568: sw          $s0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r16;
    // 0x8013856C: lw          $t3, 0x268($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X268);
    // 0x80138570: addiu       $at, $zero, -0x4
    ctx->r1 = ADD32(0, -0X4);
    // 0x80138574: and         $v1, $a3, $at
    ctx->r3 = ctx->r7 & ctx->r1;
    // 0x80138578: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x8013857C: bne         $t4, $zero, L_801385E0
    if (ctx->r12 != 0) {
        // 0x80138580: sw          $t4, 0x268($t0)
        MEM_W(0X268, ctx->r8) = ctx->r12;
            goto L_801385E0;
    }
    // 0x80138580: sw          $t4, 0x268($t0)
    MEM_W(0X268, ctx->r8) = ctx->r12;
    // 0x80138584: b           L_801385E0
    // 0x80138588: sw          $zero, 0x270($t0)
    MEM_W(0X270, ctx->r8) = 0;
        goto L_801385E0;
    // 0x80138588: sw          $zero, 0x270($t0)
    MEM_W(0X270, ctx->r8) = 0;
L_8013858C:
    // 0x8013858C: lw          $v0, 0x4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X4);
    // 0x80138590: andi        $t7, $a3, 0x2
    ctx->r15 = ctx->r7 & 0X2;
    // 0x80138594: andi        $t6, $v0, 0x2
    ctx->r14 = ctx->r2 & 0X2;
    // 0x80138598: beq         $t6, $zero, L_801385B4
    if (ctx->r14 == 0) {
        // 0x8013859C: andi        $t8, $v0, 0x1
        ctx->r24 = ctx->r2 & 0X1;
            goto L_801385B4;
    }
    // 0x8013859C: andi        $t8, $v0, 0x1
    ctx->r24 = ctx->r2 & 0X1;
    // 0x801385A0: beq         $t7, $zero, L_801385E0
    if (ctx->r15 == 0) {
        // 0x801385A4: nop
    
            goto L_801385E0;
    }
    // 0x801385A4: nop

    // 0x801385A8: sw          $s0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r16;
    // 0x801385AC: b           L_801385E0
    // 0x801385B0: and         $v1, $a3, $t1
    ctx->r3 = ctx->r7 & ctx->r9;
        goto L_801385E0;
    // 0x801385B0: and         $v1, $a3, $t1
    ctx->r3 = ctx->r7 & ctx->r9;
L_801385B4:
    // 0x801385B4: beq         $t8, $zero, L_801385E0
    if (ctx->r24 == 0) {
        // 0x801385B8: andi        $t9, $a3, 0x1
        ctx->r25 = ctx->r7 & 0X1;
            goto L_801385E0;
    }
    // 0x801385B8: andi        $t9, $a3, 0x1
    ctx->r25 = ctx->r7 & 0X1;
    // 0x801385BC: beq         $t9, $zero, L_801385E0
    if (ctx->r25 == 0) {
        // 0x801385C0: nop
    
            goto L_801385E0;
    }
    // 0x801385C0: nop

    // 0x801385C4: sw          $s0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r16;
    // 0x801385C8: lw          $t3, 0x268($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X268);
    // 0x801385CC: and         $v1, $a3, $t2
    ctx->r3 = ctx->r7 & ctx->r10;
    // 0x801385D0: lw          $t4, 0x0($t3)
    ctx->r12 = MEM_W(ctx->r11, 0X0);
    // 0x801385D4: bne         $t4, $zero, L_801385E0
    if (ctx->r12 != 0) {
        // 0x801385D8: sw          $t4, 0x268($t0)
        MEM_W(0X268, ctx->r8) = ctx->r12;
            goto L_801385E0;
    }
    // 0x801385D8: sw          $t4, 0x268($t0)
    MEM_W(0X268, ctx->r8) = ctx->r12;
    // 0x801385DC: sw          $zero, 0x270($t0)
    MEM_W(0X270, ctx->r8) = 0;
L_801385E0:
    // 0x801385E0: beql        $v1, $a3, L_801385F4
    if (ctx->r3 == ctx->r7) {
        // 0x801385E4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_801385F4;
    }
    goto skip_4;
    // 0x801385E4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x801385E8: b           L_80138434
    // 0x801385EC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
        goto L_80138434;
    // 0x801385EC: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x801385F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_801385F4:
    // 0x801385F4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x801385F8: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x801385FC: jr          $ra
    // 0x80138600: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80138600: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x80138604: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80138608: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8013860C: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    // 0x80138610: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80138614: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80138618: andi        $t7, $t6, 0x3
    ctx->r15 = ctx->r14 & 0X3;
    // 0x8013861C: bne         $t7, $zero, L_80138684
    if (ctx->r15 != 0) {
        // 0x80138620: nop
    
            goto L_80138684;
    }
    // 0x80138620: nop

    // 0x80138624: lw          $a0, 0x50($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X50);
    // 0x80138628: jal         0x80139050
    // 0x8013862C: lw          $a1, 0x54($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X54);
    osSendMesg_recomp(rdram, ctx);
        goto after_1;
    // 0x8013862C: lw          $a1, 0x54($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X54);
    after_1:
    // 0x80138630: lw          $t8, 0x10($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X10);
    // 0x80138634: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80138638: bne         $t8, $at, L_8013867C
    if (ctx->r24 != ctx->r1) {
        // 0x8013863C: nop
    
            goto L_8013867C;
    }
    // 0x8013863C: nop

    // 0x80138640: lw          $v0, 0x8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X8);
    // 0x80138644: andi        $t9, $v0, 0x40
    ctx->r25 = ctx->r2 & 0X40;
    // 0x80138648: beq         $t9, $zero, L_8013867C
    if (ctx->r25 == 0) {
        // 0x8013864C: andi        $t6, $v0, 0x20
        ctx->r14 = ctx->r2 & 0X20;
            goto L_8013867C;
    }
    // 0x8013864C: andi        $t6, $v0, 0x20
    ctx->r14 = ctx->r2 & 0X20;
    // 0x80138650: beq         $t6, $zero, L_8013867C
    if (ctx->r14 == 0) {
        // 0x80138654: lui         $t7, 0x8016
        ctx->r15 = S32(0X8016 << 16);
            goto L_8013867C;
    }
    // 0x80138654: lui         $t7, 0x8016
    ctx->r15 = S32(0X8016 << 16);
    // 0x80138658: lw          $t7, -0x6688($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X6688);
    // 0x8013865C: beq         $t7, $zero, L_80138674
    if (ctx->r15 == 0) {
        // 0x80138660: nop
    
            goto L_80138674;
    }
    // 0x80138660: nop

    // 0x80138664: jal         0x80139390
    // 0x80138668: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    osViBlack_recomp(rdram, ctx);
        goto after_2;
    // 0x80138668: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_2:
    // 0x8013866C: lui         $at, 0x8016
    ctx->r1 = S32(0X8016 << 16);
    // 0x80138670: sw          $zero, -0x6688($at)
    MEM_W(-0X6688, ctx->r1) = 0;
L_80138674:
    // 0x80138674: jal         0x80142490
    // 0x80138678: lw          $a0, 0xC($s0)
    ctx->r4 = MEM_W(ctx->r16, 0XC);
    osViSwapBuffer_recomp(rdram, ctx);
        goto after_3;
    // 0x80138678: lw          $a0, 0xC($s0)
    ctx->r4 = MEM_W(ctx->r16, 0XC);
    after_3:
L_8013867C:
    // 0x8013867C: b           L_80138684
    // 0x80138680: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80138684;
    // 0x80138680: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80138684:
    // 0x80138684: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80138688: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8013868C: jr          $ra
    // 0x80138690: nop

    return;
    // 0x80138690: nop

    // 0x80138694: jr          $ra
    // 0x80138698: nop

    return;
    // 0x80138698: nop

    // 0x8013869C: jr          $ra
    // 0x801386A0: nop

    return;
    // 0x801386A0: nop

    // 0x801386A4: jr          $ra
    // 0x801386A8: nop

    return;
    // 0x801386A8: nop

    // 0x801386AC: jr          $ra
    // 0x801386B0: nop

    return;
    // 0x801386B0: nop

    // 0x801386B4: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x801386B8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x801386BC: sw          $zero, 0x34($sp)
    MEM_W(0X34, ctx->r29) = 0;
    // 0x801386C0: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x801386C4: lw          $t6, 0x27C($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X27C);
    // 0x801386C8: addiu       $s5, $sp, 0x44
    ctx->r21 = ADD32(ctx->r29, 0X44);
    // 0x801386CC: addiu       $s3, $s4, 0x78
    ctx->r19 = ADD32(ctx->r20, 0X78);
    // 0x801386D0: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x801386D4: sw          $t7, 0x27C($s4)
    MEM_W(0X27C, ctx->r20) = ctx->r15;
    // 0x801386D8: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x801386DC: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x801386E0: jal         0x80137FF0
    // 0x801386E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osRecvMesg_recomp(rdram, ctx);
        goto after_4;
    // 0x801386E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_4:
    // 0x801386E8: addiu       $s0, $zero, -0x1
    ctx->r16 = ADD32(0, -0X1);
    // 0x801386EC: beql        $v0, $s0, L_8013877C
    if (ctx->r2 == ctx->r16) {
        // 0x801386F0: lw          $t7, 0x280($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X280);
            goto L_8013877C;
    }
    goto skip_5;
    // 0x801386F0: lw          $t7, 0x280($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X280);
    skip_5:
    // 0x801386F4: addiu       $s2, $zero, 0x1
    ctx->r18 = ADD32(0, 0X1);
    // 0x801386F8: addiu       $s1, $zero, 0x2
    ctx->r17 = ADD32(0, 0X2);
    // 0x801386FC: lw          $t8, 0x44($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X44);
L_80138700:
    // 0x80138700: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x80138704: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    // 0x80138708: lw          $v1, 0x10($t8)
    ctx->r3 = MEM_W(ctx->r24, 0X10);
    // 0x8013870C: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x80138710: bnel        $v1, $s1, L_80138740
    if (ctx->r3 != ctx->r17) {
        // 0x80138714: lw          $v1, 0x270($s4)
        ctx->r3 = MEM_W(ctx->r20, 0X270);
            goto L_80138740;
    }
    goto skip_6;
    // 0x80138714: lw          $v1, 0x270($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X270);
    skip_6:
    // 0x80138718: lw          $v1, 0x26C($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X26C);
    // 0x8013871C: beql        $v1, $zero, L_80138730
    if (ctx->r3 == 0) {
        // 0x80138720: sw          $v0, 0x264($s4)
        MEM_W(0X264, ctx->r20) = ctx->r2;
            goto L_80138730;
    }
    goto skip_7;
    // 0x80138720: sw          $v0, 0x264($s4)
    MEM_W(0X264, ctx->r20) = ctx->r2;
    skip_7:
    // 0x80138724: b           L_80138730
    // 0x80138728: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
        goto L_80138730;
    // 0x80138728: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8013872C: sw          $v0, 0x264($s4)
    MEM_W(0X264, ctx->r20) = ctx->r2;
L_80138730:
    // 0x80138730: sw          $v0, 0x26C($s4)
    MEM_W(0X26C, ctx->r20) = ctx->r2;
    // 0x80138734: b           L_80138758
    // 0x80138738: sw          $s2, 0x280($s4)
    MEM_W(0X280, ctx->r20) = ctx->r18;
        goto L_80138758;
    // 0x80138738: sw          $s2, 0x280($s4)
    MEM_W(0X280, ctx->r20) = ctx->r18;
    // 0x8013873C: lw          $v1, 0x270($s4)
    ctx->r3 = MEM_W(ctx->r20, 0X270);
L_80138740:
    // 0x80138740: beql        $v1, $zero, L_80138754
    if (ctx->r3 == 0) {
        // 0x80138744: sw          $v0, 0x268($s4)
        MEM_W(0X268, ctx->r20) = ctx->r2;
            goto L_80138754;
    }
    goto skip_8;
    // 0x80138744: sw          $v0, 0x268($s4)
    MEM_W(0X268, ctx->r20) = ctx->r2;
    skip_8:
    // 0x80138748: b           L_80138754
    // 0x8013874C: sw          $v0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r2;
        goto L_80138754;
    // 0x8013874C: sw          $v0, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r2;
    // 0x80138750: sw          $v0, 0x268($s4)
    MEM_W(0X268, ctx->r20) = ctx->r2;
L_80138754:
    // 0x80138754: sw          $v0, 0x270($s4)
    MEM_W(0X270, ctx->r20) = ctx->r2;
L_80138758:
    // 0x80138758: lw          $t9, 0x8($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X8);
    // 0x8013875C: sw          $zero, 0x0($v0)
    MEM_W(0X0, ctx->r2) = 0;
    // 0x80138760: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80138764: andi        $t6, $t9, 0x3
    ctx->r14 = ctx->r25 & 0X3;
    // 0x80138768: jal         0x80137FF0
    // 0x8013876C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    osRecvMesg_recomp(rdram, ctx);
        goto after_5;
    // 0x8013876C: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    after_5:
    // 0x80138770: bnel        $v0, $s0, L_80138700
    if (ctx->r2 != ctx->r16) {
        // 0x80138774: lw          $t8, 0x44($sp)
        ctx->r24 = MEM_W(ctx->r29, 0X44);
            goto L_80138700;
    }
    goto skip_9;
    // 0x80138774: lw          $t8, 0x44($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X44);
    skip_9:
    // 0x80138778: lw          $t7, 0x280($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X280);
L_8013877C:
    // 0x8013877C: or          $a0, $s4, $zero
    ctx->r4 = ctx->r20 | 0;
    // 0x80138780: addiu       $a1, $sp, 0x34
    ctx->r5 = ADD32(ctx->r29, 0X34);
    // 0x80138784: beql        $t7, $zero, L_801387C4
    if (ctx->r15 == 0) {
        // 0x80138788: lw          $t7, 0x274($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X274);
            goto L_801387C4;
    }
    goto skip_10;
    // 0x80138788: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
    skip_10:
    // 0x8013878C: lw          $v0, 0x274($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X274);
    // 0x80138790: beql        $v0, $zero, L_801387C4
    if (ctx->r2 == 0) {
        // 0x80138794: lw          $t7, 0x274($s4)
        ctx->r15 = MEM_W(ctx->r20, 0X274);
            goto L_801387C4;
    }
    goto skip_11;
    // 0x80138794: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
    skip_11:
    // 0x80138798: lw          $t8, 0x10($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X10);
    // 0x8013879C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x801387A0: bnel        $t8, $at, L_80138800
    if (ctx->r24 != ctx->r1) {
        // 0x801387A4: lw          $s0, 0x260($s4)
        ctx->r16 = MEM_W(ctx->r20, 0X260);
            goto L_80138800;
    }
    goto skip_12;
    // 0x801387A4: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    skip_12:
    // 0x801387A8: lw          $t9, 0x4($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X4);
    // 0x801387AC: ori         $t6, $t9, 0x10
    ctx->r14 = ctx->r25 | 0X10;
    // 0x801387B0: jal         0x80142880
    // 0x801387B4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    osSpTaskYield_recomp(rdram, ctx);
        goto after_6;
    // 0x801387B4: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    after_6:
    // 0x801387B8: b           L_80138800
    // 0x801387BC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
        goto L_80138800;
    // 0x801387BC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    // 0x801387C0: lw          $t7, 0x274($s4)
    ctx->r15 = MEM_W(ctx->r20, 0X274);
L_801387C4:
    // 0x801387C4: lw          $t6, 0x278($s4)
    ctx->r14 = MEM_W(ctx->r20, 0X278);
    // 0x801387C8: addiu       $a2, $sp, 0x30
    ctx->r6 = ADD32(ctx->r29, 0X30);
    // 0x801387CC: sltiu       $t8, $t7, 0x1
    ctx->r24 = ctx->r15 < 0X1 ? 1 : 0;
    // 0x801387D0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x801387D4: sltiu       $t7, $t6, 0x1
    ctx->r15 = ctx->r14 < 0X1 ? 1 : 0;
    // 0x801387D8: or          $s0, $t9, $t7
    ctx->r16 = ctx->r25 | ctx->r15;
    // 0x801387DC: jal         0x80138420
    // 0x801387E0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    __scSchedule(rdram, ctx);
        goto after_7;
    // 0x801387E0: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    after_7:
    // 0x801387E4: beql        $v0, $s0, L_80138800
    if (ctx->r2 == ctx->r16) {
        // 0x801387E8: lw          $s0, 0x260($s4)
        ctx->r16 = MEM_W(ctx->r20, 0X260);
            goto L_80138800;
    }
    goto skip_13;
    // 0x801387E8: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
    skip_13:
    // 0x801387EC: or          $s3, $s4, $zero
    ctx->r19 = ctx->r20 | 0;
    // 0x801387F0: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x801387F4: jal         0x80138380
    // 0x801387F8: lw          $s1, 0x30($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X30);
    __scExec(rdram, ctx);
        goto after_8;
    // 0x801387F8: lw          $s1, 0x30($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X30);
    after_8:
    // 0x801387FC: lw          $s0, 0x260($s4)
    ctx->r16 = MEM_W(ctx->r20, 0X260);
L_80138800:
    // 0x80138800: beql        $s0, $zero, L_80138828
    if (ctx->r16 == 0) {
        // 0x80138804: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80138828;
    }
    goto skip_14;
    // 0x80138804: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_14:
    // 0x80138808: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
L_8013880C:
    // 0x8013880C: or          $a1, $s4, $zero
    ctx->r5 = ctx->r20 | 0;
    // 0x80138810: jal         0x80139050
    // 0x80138814: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_9;
    // 0x80138814: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_9:
    // 0x80138818: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    // 0x8013881C: bnel        $s0, $zero, L_8013880C
    if (ctx->r16 != 0) {
        // 0x80138820: lw          $a0, 0x4($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X4);
            goto L_8013880C;
    }
    goto skip_15;
    // 0x80138820: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
    skip_15:
    // 0x80138824: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80138828:
    // 0x80138828: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    // 0x8013882C: jr          $ra
    // 0x80138830: nop

    return;
    // 0x80138830: nop

;}
RECOMP_FUNC void func_80138834(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138834: addiu       $sp, $sp, -0x88
    ctx->r29 = ADD32(ctx->r29, -0X88);
    // 0x80138838: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8013883C: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80138840: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80138844: or          $s6, $a0, $zero
    ctx->r22 = ctx->r4 | 0;
    // 0x80138848: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x8013884C: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80138850: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80138854: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80138858: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x8013885C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80138860: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80138864: addiu       $s7, $a0, 0x40
    ctx->r23 = ADD32(ctx->r4, 0X40);
    // 0x80138868: addiu       $fp, $zero, 0x29A
    ctx->r30 = ADD32(0, 0X29A);
L_8013886C:
    // 0x8013886C: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80138870:
    // 0x80138870: addiu       $a1, $sp, 0x84
    ctx->r5 = ADD32(ctx->r29, 0X84);
    // 0x80138874: jal         0x80137FF0
    // 0x80138878: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    osRecvMesg_recomp(rdram, ctx);
        goto after_0;
    // 0x80138878: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    after_0:
    // 0x8013887C: lw          $v1, 0x84($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X84);
    // 0x80138880: addiu       $at, $zero, 0x29B
    ctx->r1 = ADD32(0, 0X29B);
    // 0x80138884: beq         $v1, $fp, L_801388AC
    if (ctx->r3 == ctx->r30) {
        // 0x80138888: nop
    
            goto L_801388AC;
    }
    // 0x80138888: nop

    // 0x8013888C: beq         $v1, $at, L_801388BC
    if (ctx->r3 == ctx->r1) {
        // 0x80138890: addiu       $at, $zero, 0x29C
        ctx->r1 = ADD32(0, 0X29C);
            goto L_801388BC;
    }
    // 0x80138890: addiu       $at, $zero, 0x29C
    ctx->r1 = ADD32(0, 0X29C);
    // 0x80138894: beq         $v1, $at, L_80138988
    if (ctx->r3 == ctx->r1) {
        // 0x80138898: addiu       $at, $zero, 0x29D
        ctx->r1 = ADD32(0, 0X29D);
            goto L_80138988;
    }
    // 0x80138898: addiu       $at, $zero, 0x29D
    ctx->r1 = ADD32(0, 0X29D);
    // 0x8013889C: beql        $v1, $at, L_801389FC
    if (ctx->r3 == ctx->r1) {
        // 0x801388A0: lw          $s0, 0x260($s6)
        ctx->r16 = MEM_W(ctx->r22, 0X260);
            goto L_801389FC;
    }
    goto skip_0;
    // 0x801388A0: lw          $s0, 0x260($s6)
    ctx->r16 = MEM_W(ctx->r22, 0X260);
    skip_0:
    // 0x801388A4: b           L_80138870
    // 0x801388A8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_80138870;
    // 0x801388A8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_801388AC:
    // 0x801388AC: jal         0x801386B4
    // 0x801388B0: or          $s4, $s6, $zero
    ctx->r20 = ctx->r22 | 0;
    static_0_801386B4(rdram, ctx);
        goto after_1;
    // 0x801388B0: or          $s4, $s6, $zero
    ctx->r20 = ctx->r22 | 0;
    after_1:
    // 0x801388B4: b           L_80138870
    // 0x801388B8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_80138870;
    // 0x801388B8: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_801388BC:
    // 0x801388BC: sw          $zero, 0x68($sp)
    MEM_W(0X68, ctx->r29) = 0;
    // 0x801388C0: sw          $zero, 0x64($sp)
    MEM_W(0X64, ctx->r29) = 0;
    // 0x801388C4: lw          $s0, 0x274($s6)
    ctx->r16 = MEM_W(ctx->r22, 0X274);
    // 0x801388C8: sw          $zero, 0x274($s6)
    MEM_W(0X274, ctx->r22) = 0;
    // 0x801388CC: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    // 0x801388D0: andi        $t7, $t6, 0x10
    ctx->r15 = ctx->r14 & 0X10;
    // 0x801388D4: beql        $t7, $zero, L_8013892C
    if (ctx->r15 == 0) {
        // 0x801388D8: lw          $t6, 0x4($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X4);
            goto L_8013892C;
    }
    goto skip_1;
    // 0x801388D8: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    skip_1:
    // 0x801388DC: jal         0x80142390
    // 0x801388E0: addiu       $a0, $s0, 0x10
    ctx->r4 = ADD32(ctx->r16, 0X10);
    osSpTaskYielded_recomp(rdram, ctx);
        goto after_2;
    // 0x801388E0: addiu       $a0, $s0, 0x10
    ctx->r4 = ADD32(ctx->r16, 0X10);
    after_2:
    // 0x801388E4: beql        $v0, $zero, L_8013892C
    if (ctx->r2 == 0) {
        // 0x801388E8: lw          $t6, 0x4($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X4);
            goto L_8013892C;
    }
    goto skip_2;
    // 0x801388E8: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
    skip_2:
    // 0x801388EC: lw          $t8, 0x4($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X4);
    // 0x801388F0: lw          $t6, 0x8($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X8);
    // 0x801388F4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x801388F8: ori         $t9, $t8, 0x20
    ctx->r25 = ctx->r24 | 0X20;
    // 0x801388FC: andi        $t7, $t6, 0x7
    ctx->r15 = ctx->r14 & 0X7;
    // 0x80138900: bne         $t7, $at, L_80138940
    if (ctx->r15 != ctx->r1) {
        // 0x80138904: sw          $t9, 0x4($s0)
        MEM_W(0X4, ctx->r16) = ctx->r25;
            goto L_80138940;
    }
    // 0x80138904: sw          $t9, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r25;
    // 0x80138908: lw          $t8, 0x268($s6)
    ctx->r24 = MEM_W(ctx->r22, 0X268);
    // 0x8013890C: sw          $t8, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r24;
    // 0x80138910: lw          $t9, 0x270($s6)
    ctx->r25 = MEM_W(ctx->r22, 0X270);
    // 0x80138914: sw          $s0, 0x268($s6)
    MEM_W(0X268, ctx->r22) = ctx->r16;
    // 0x80138918: bnel        $t9, $zero, L_80138944
    if (ctx->r25 != 0) {
        // 0x8013891C: lw          $t8, 0x274($s6)
        ctx->r24 = MEM_W(ctx->r22, 0X274);
            goto L_80138944;
    }
    goto skip_3;
    // 0x8013891C: lw          $t8, 0x274($s6)
    ctx->r24 = MEM_W(ctx->r22, 0X274);
    skip_3:
    // 0x80138920: b           L_80138940
    // 0x80138924: sw          $s0, 0x270($s6)
    MEM_W(0X270, ctx->r22) = ctx->r16;
        goto L_80138940;
    // 0x80138924: sw          $s0, 0x270($s6)
    MEM_W(0X270, ctx->r22) = ctx->r16;
    // 0x80138928: lw          $t6, 0x4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X4);
L_8013892C:
    // 0x8013892C: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80138930: and         $t7, $t6, $at
    ctx->r15 = ctx->r14 & ctx->r1;
    // 0x80138934: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x80138938: jal         0x80138604
    // 0x8013893C: sw          $s6, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r22;
    static_0_80138604(rdram, ctx);
        goto after_3;
    // 0x8013893C: sw          $s6, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r22;
    after_3:
L_80138940:
    // 0x80138940: lw          $t8, 0x274($s6)
    ctx->r24 = MEM_W(ctx->r22, 0X274);
L_80138944:
    // 0x80138944: lw          $t7, 0x278($s6)
    ctx->r15 = MEM_W(ctx->r22, 0X278);
    // 0x80138948: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x8013894C: sltiu       $t9, $t8, 0x1
    ctx->r25 = ctx->r24 < 0X1 ? 1 : 0;
    // 0x80138950: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x80138954: sltiu       $t8, $t7, 0x1
    ctx->r24 = ctx->r15 < 0X1 ? 1 : 0;
    // 0x80138958: or          $s0, $t6, $t8
    ctx->r16 = ctx->r14 | ctx->r24;
    // 0x8013895C: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x80138960: addiu       $a1, $sp, 0x68
    ctx->r5 = ADD32(ctx->r29, 0X68);
    // 0x80138964: jal         0x80138420
    // 0x80138968: addiu       $a2, $sp, 0x64
    ctx->r6 = ADD32(ctx->r29, 0X64);
    __scSchedule(rdram, ctx);
        goto after_4;
    // 0x80138968: addiu       $a2, $sp, 0x64
    ctx->r6 = ADD32(ctx->r29, 0X64);
    after_4:
    // 0x8013896C: beq         $v0, $s0, L_8013886C
    if (ctx->r2 == ctx->r16) {
        // 0x80138970: or          $s3, $s6, $zero
        ctx->r19 = ctx->r22 | 0;
            goto L_8013886C;
    }
    // 0x80138970: or          $s3, $s6, $zero
    ctx->r19 = ctx->r22 | 0;
    // 0x80138974: lw          $s0, 0x68($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X68);
    // 0x80138978: jal         0x80138380
    // 0x8013897C: lw          $s1, 0x64($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X64);
    __scExec(rdram, ctx);
        goto after_5;
    // 0x8013897C: lw          $s1, 0x64($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X64);
    after_5:
    // 0x80138980: b           L_80138870
    // 0x80138984: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_80138870;
    // 0x80138984: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
L_80138988:
    // 0x80138988: sw          $zero, 0x50($sp)
    MEM_W(0X50, ctx->r29) = 0;
    // 0x8013898C: sw          $zero, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = 0;
    // 0x80138990: lw          $s0, 0x278($s6)
    ctx->r16 = MEM_W(ctx->r22, 0X278);
    // 0x80138994: sw          $zero, 0x278($s6)
    MEM_W(0X278, ctx->r22) = 0;
    // 0x80138998: addiu       $at, $zero, -0x2
    ctx->r1 = ADD32(0, -0X2);
    // 0x8013899C: lw          $t9, 0x4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X4);
    // 0x801389A0: and         $t7, $t9, $at
    ctx->r15 = ctx->r25 & ctx->r1;
    // 0x801389A4: sw          $t7, 0x4($s0)
    MEM_W(0X4, ctx->r16) = ctx->r15;
    // 0x801389A8: jal         0x80138604
    // 0x801389AC: sw          $s6, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r22;
    static_0_80138604(rdram, ctx);
        goto after_6;
    // 0x801389AC: sw          $s6, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r22;
    after_6:
    // 0x801389B0: lw          $t6, 0x274($s6)
    ctx->r14 = MEM_W(ctx->r22, 0X274);
    // 0x801389B4: lw          $t7, 0x278($s6)
    ctx->r15 = MEM_W(ctx->r22, 0X278);
    // 0x801389B8: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x801389BC: sltiu       $t8, $t6, 0x1
    ctx->r24 = ctx->r14 < 0X1 ? 1 : 0;
    // 0x801389C0: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x801389C4: sltiu       $t6, $t7, 0x1
    ctx->r14 = ctx->r15 < 0X1 ? 1 : 0;
    // 0x801389C8: or          $s0, $t9, $t6
    ctx->r16 = ctx->r25 | ctx->r14;
    // 0x801389CC: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x801389D0: addiu       $a1, $sp, 0x50
    ctx->r5 = ADD32(ctx->r29, 0X50);
    // 0x801389D4: jal         0x80138420
    // 0x801389D8: addiu       $a2, $sp, 0x4C
    ctx->r6 = ADD32(ctx->r29, 0X4C);
    __scSchedule(rdram, ctx);
        goto after_7;
    // 0x801389D8: addiu       $a2, $sp, 0x4C
    ctx->r6 = ADD32(ctx->r29, 0X4C);
    after_7:
    // 0x801389DC: beq         $v0, $s0, L_8013886C
    if (ctx->r2 == ctx->r16) {
        // 0x801389E0: or          $s3, $s6, $zero
        ctx->r19 = ctx->r22 | 0;
            goto L_8013886C;
    }
    // 0x801389E0: or          $s3, $s6, $zero
    ctx->r19 = ctx->r22 | 0;
    // 0x801389E4: lw          $s0, 0x50($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X50);
    // 0x801389E8: jal         0x80138380
    // 0x801389EC: lw          $s1, 0x4C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X4C);
    __scExec(rdram, ctx);
        goto after_8;
    // 0x801389EC: lw          $s1, 0x4C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X4C);
    after_8:
    // 0x801389F0: b           L_80138870
    // 0x801389F4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_80138870;
    // 0x801389F4: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x801389F8: lw          $s0, 0x260($s6)
    ctx->r16 = MEM_W(ctx->r22, 0X260);
L_801389FC:
    // 0x801389FC: addiu       $s1, $s6, 0x20
    ctx->r17 = ADD32(ctx->r22, 0X20);
    // 0x80138A00: beql        $s0, $zero, L_80138870
    if (ctx->r16 == 0) {
        // 0x80138A04: or          $a0, $s7, $zero
        ctx->r4 = ctx->r23 | 0;
            goto L_80138870;
    }
    goto skip_4;
    // 0x80138A04: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    skip_4:
    // 0x80138A08: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
L_80138A0C:
    // 0x80138A0C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80138A10: jal         0x80139050
    // 0x80138A14: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    osSendMesg_recomp(rdram, ctx);
        goto after_9;
    // 0x80138A14: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    after_9:
    // 0x80138A18: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    // 0x80138A1C: bnel        $s0, $zero, L_80138A0C
    if (ctx->r16 != 0) {
        // 0x80138A20: lw          $a0, 0x4($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X4);
            goto L_80138A0C;
    }
    goto skip_5;
    // 0x80138A20: lw          $a0, 0x4($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X4);
    skip_5:
    // 0x80138A24: b           L_80138870
    // 0x80138A28: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
        goto L_80138870;
    // 0x80138A28: or          $a0, $s7, $zero
    ctx->r4 = ctx->r23 | 0;
    // 0x80138A2C: nop

    // 0x80138A30: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80138A34: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80138A38: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80138A3C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80138A40: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80138A44: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80138A48: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80138A4C: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80138A50: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80138A54: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80138A58: jr          $ra
    // 0x80138A5C: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
    return;
    // 0x80138A5C: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
;}
RECOMP_FUNC void osScGetCmdQ(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138A60: jr          $ra
    // 0x80138A64: addiu       $v0, $a0, 0x78
    ctx->r2 = ADD32(ctx->r4, 0X78);
    return;
    // 0x80138A64: addiu       $v0, $a0, 0x78
    ctx->r2 = ADD32(ctx->r4, 0X78);
;}
RECOMP_FUNC void osScRemoveClient(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138A68: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80138A6C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80138A70: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x80138A74: lw          $v1, 0x260($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X260);
    // 0x80138A78: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80138A7C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x80138A80: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80138A84: jal         0x8013E050
    // 0x80138A88: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    osSetIntMask_recomp(rdram, ctx);
        goto after_0;
    // 0x80138A88: sw          $v1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r3;
    after_0:
    // 0x80138A8C: lw          $v1, 0x1C($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X1C);
    // 0x80138A90: lw          $a1, 0x24($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X24);
    // 0x80138A94: lw          $a2, 0x18($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X18);
    // 0x80138A98: beq         $v1, $zero, L_80138AD8
    if (ctx->r3 == 0) {
        // 0x80138A9C: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_80138AD8;
    }
    // 0x80138A9C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_80138AA0:
    // 0x80138AA0: bnel        $v1, $a1, L_80138ACC
    if (ctx->r3 != ctx->r5) {
        // 0x80138AA4: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_80138ACC;
    }
    goto skip_0;
    // 0x80138AA4: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    skip_0:
    // 0x80138AA8: beq         $a2, $zero, L_80138ABC
    if (ctx->r6 == 0) {
        // 0x80138AAC: lw          $t9, 0x20($sp)
        ctx->r25 = MEM_W(ctx->r29, 0X20);
            goto L_80138ABC;
    }
    // 0x80138AAC: lw          $t9, 0x20($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X20);
    // 0x80138AB0: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x80138AB4: b           L_80138AD8
    // 0x80138AB8: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
        goto L_80138AD8;
    // 0x80138AB8: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
L_80138ABC:
    // 0x80138ABC: lw          $t8, 0x0($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X0);
    // 0x80138AC0: b           L_80138AD8
    // 0x80138AC4: sw          $t8, 0x260($t9)
    MEM_W(0X260, ctx->r25) = ctx->r24;
        goto L_80138AD8;
    // 0x80138AC4: sw          $t8, 0x260($t9)
    MEM_W(0X260, ctx->r25) = ctx->r24;
    // 0x80138AC8: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
L_80138ACC:
    // 0x80138ACC: lw          $v1, 0x0($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X0);
    // 0x80138AD0: bne         $v1, $zero, L_80138AA0
    if (ctx->r3 != 0) {
        // 0x80138AD4: nop
    
            goto L_80138AA0;
    }
    // 0x80138AD4: nop

L_80138AD8:
    // 0x80138AD8: jal         0x8013E050
    // 0x80138ADC: nop

    osSetIntMask_recomp(rdram, ctx);
        goto after_1;
    // 0x80138ADC: nop

    after_1:
    // 0x80138AE0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80138AE4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80138AE8: jr          $ra
    // 0x80138AEC: nop

    return;
    // 0x80138AEC: nop

;}
RECOMP_FUNC void osScAddClient(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138AF0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80138AF4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80138AF8: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80138AFC: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x80138B00: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80138B04: jal         0x8013E050
    // 0x80138B08: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    osSetIntMask_recomp(rdram, ctx);
        goto after_0;
    // 0x80138B08: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80138B0C: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80138B10: lw          $t6, 0x20($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X20);
    // 0x80138B14: lw          $v1, 0x18($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X18);
    // 0x80138B18: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80138B1C: sw          $t6, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r14;
    // 0x80138B20: lw          $t7, 0x260($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X260);
    // 0x80138B24: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x80138B28: jal         0x8013E050
    // 0x80138B2C: sw          $a1, 0x260($v1)
    MEM_W(0X260, ctx->r3) = ctx->r5;
    osSetIntMask_recomp(rdram, ctx);
        goto after_1;
    // 0x80138B2C: sw          $a1, 0x260($v1)
    MEM_W(0X260, ctx->r3) = ctx->r5;
    after_1:
    // 0x80138B30: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80138B34: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80138B38: jr          $ra
    // 0x80138B3C: nop

    return;
    // 0x80138B3C: nop

;}
RECOMP_FUNC void osCreateScheduler(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80138B40: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80138B44: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x80138B48: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x80138B4C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80138B50: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x80138B54: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x80138B58: sw          $a3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r7;
    // 0x80138B5C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80138B60: addiu       $t7, $zero, 0x4
    ctx->r15 = ADD32(0, 0X4);
    // 0x80138B64: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x80138B68: sw          $zero, 0x274($a0)
    MEM_W(0X274, ctx->r4) = 0;
    // 0x80138B6C: sw          $zero, 0x278($a0)
    MEM_W(0X278, ctx->r4) = 0;
    // 0x80138B70: sw          $zero, 0x260($a0)
    MEM_W(0X260, ctx->r4) = 0;
    // 0x80138B74: sw          $zero, 0x27C($a0)
    MEM_W(0X27C, ctx->r4) = 0;
    // 0x80138B78: sw          $zero, 0x264($a0)
    MEM_W(0X264, ctx->r4) = 0;
    // 0x80138B7C: sw          $zero, 0x268($a0)
    MEM_W(0X268, ctx->r4) = 0;
    // 0x80138B80: sw          $zero, 0x26C($a0)
    MEM_W(0X26C, ctx->r4) = 0;
    // 0x80138B84: sw          $zero, 0x270($a0)
    MEM_W(0X270, ctx->r4) = 0;
    // 0x80138B88: sh          $t6, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r14;
    // 0x80138B8C: sh          $t7, 0x20($a0)
    MEM_H(0X20, ctx->r4) = ctx->r15;
    // 0x80138B90: addiu       $s1, $a0, 0x40
    ctx->r17 = ADD32(ctx->r4, 0X40);
    // 0x80138B94: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80138B98: addiu       $a1, $s0, 0x58
    ctx->r5 = ADD32(ctx->r16, 0X58);
    // 0x80138B9C: jal         0x801381B0
    // 0x80138BA0: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_0;
    // 0x80138BA0: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    after_0:
    // 0x80138BA4: addiu       $a0, $s0, 0x78
    ctx->r4 = ADD32(ctx->r16, 0X78);
    // 0x80138BA8: addiu       $a1, $s0, 0x90
    ctx->r5 = ADD32(ctx->r16, 0X90);
    // 0x80138BAC: jal         0x801381B0
    // 0x80138BB0: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    osCreateMesgQueue_recomp(rdram, ctx);
        goto after_1;
    // 0x80138BB0: addiu       $a2, $zero, 0x8
    ctx->r6 = ADD32(0, 0X8);
    after_1:
    // 0x80138BB4: jal         0x80141F50
    // 0x80138BB8: addiu       $a0, $zero, 0xFE
    ctx->r4 = ADD32(0, 0XFE);
    osCreateViManager_recomp(rdram, ctx);
        goto after_2;
    // 0x80138BB8: addiu       $a0, $zero, 0xFE
    ctx->r4 = ADD32(0, 0XFE);
    after_2:
    // 0x80138BBC: lbu         $t8, 0x37($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X37);
    // 0x80138BC0: lui         $t0, 0x8016
    ctx->r8 = S32(0X8016 << 16);
    // 0x80138BC4: addiu       $t0, $t0, -0x6680
    ctx->r8 = ADD32(ctx->r8, -0X6680);
    // 0x80138BC8: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x80138BCC: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80138BD0: sll         $t9, $t9, 4
    ctx->r25 = S32(ctx->r25 << 4);
    // 0x80138BD4: jal         0x801422B0
    // 0x80138BD8: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    osViSetMode_recomp(rdram, ctx);
        goto after_3;
    // 0x80138BD8: addu        $a0, $t9, $t0
    ctx->r4 = ADD32(ctx->r25, ctx->r8);
    after_3:
    // 0x80138BDC: jal         0x80139390
    // 0x80138BE0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    osViBlack_recomp(rdram, ctx);
        goto after_4;
    // 0x80138BE0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_4:
    // 0x80138BE4: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x80138BE8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80138BEC: jal         0x8013E3B0
    // 0x80138BF0: addiu       $a2, $zero, 0x29B
    ctx->r6 = ADD32(0, 0X29B);
    osSetEventMesg_recomp(rdram, ctx);
        goto after_5;
    // 0x80138BF0: addiu       $a2, $zero, 0x29B
    ctx->r6 = ADD32(0, 0X29B);
    after_5:
    // 0x80138BF4: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x80138BF8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80138BFC: jal         0x8013E3B0
    // 0x80138C00: addiu       $a2, $zero, 0x29C
    ctx->r6 = ADD32(0, 0X29C);
    osSetEventMesg_recomp(rdram, ctx);
        goto after_6;
    // 0x80138C00: addiu       $a2, $zero, 0x29C
    ctx->r6 = ADD32(0, 0X29C);
    after_6:
    // 0x80138C04: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x80138C08: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80138C0C: jal         0x8013E3B0
    // 0x80138C10: addiu       $a2, $zero, 0x29D
    ctx->r6 = ADD32(0, 0X29D);
    osSetEventMesg_recomp(rdram, ctx);
        goto after_7;
    // 0x80138C10: addiu       $a2, $zero, 0x29D
    ctx->r6 = ADD32(0, 0X29D);
    after_7:
    // 0x80138C14: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80138C18: addiu       $a1, $zero, 0x29A
    ctx->r5 = ADD32(0, 0X29A);
    // 0x80138C1C: jal         0x80142320
    // 0x80138C20: lbu         $a2, 0x3B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X3B);
    osViSetEvent_recomp(rdram, ctx);
        goto after_8;
    // 0x80138C20: lbu         $a2, 0x3B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X3B);
    after_8:
    // 0x80138C24: lw          $t1, 0x2C($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X2C);
    // 0x80138C28: lw          $t2, 0x30($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X30);
    // 0x80138C2C: addiu       $s1, $s0, 0xB0
    ctx->r17 = ADD32(ctx->r16, 0XB0);
    // 0x80138C30: lui         $a2, 0x8014
    ctx->r6 = S32(0X8014 << 16);
    // 0x80138C34: addiu       $a2, $a2, -0x77CC
    ctx->r6 = ADD32(ctx->r6, -0X77CC);
    // 0x80138C38: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x80138C3C: addiu       $a1, $zero, 0x4
    ctx->r5 = ADD32(0, 0X4);
    // 0x80138C40: or          $a3, $s0, $zero
    ctx->r7 = ctx->r16 | 0;
    // 0x80138C44: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80138C48: jal         0x80139AA0
    // 0x80138C4C: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    osCreateThread_recomp(rdram, ctx);
        goto after_9;
    // 0x80138C4C: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    after_9:
    // 0x80138C50: jal         0x801381E0
    // 0x80138C54: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    osStartThread_recomp(rdram, ctx);
        goto after_10;
    // 0x80138C54: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_10:
    // 0x80138C58: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80138C5C: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x80138C60: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x80138C64: jr          $ra
    // 0x80138C68: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x80138C68: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
