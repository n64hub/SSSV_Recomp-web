#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void perform_behavior_dog(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385BE0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80385BE4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80385BE8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80385BEC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80385BF0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385BF4: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80385BF8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80385BFC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80385C00: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385C04: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385C08: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80385C0C: beq         $t6, $zero, L_80385C2C
    if (ctx->r14 == 0) {
        // 0x80385C10: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80385C2C;
    }
    // 0x80385C10: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385C14: beq         $t6, $at, L_80385C50
    if (ctx->r14 == ctx->r1) {
        // 0x80385C18: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80385C50;
    }
    // 0x80385C18: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80385C1C: beql        $t6, $at, L_80385D84
    if (ctx->r14 == ctx->r1) {
        // 0x80385C20: lh          $t9, 0x2D0($v1)
        ctx->r25 = MEM_H(ctx->r3, 0X2D0);
            goto L_80385D84;
    }
    goto skip_0;
    // 0x80385C20: lh          $t9, 0x2D0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x80385C24: b           L_80385DE0
    // 0x80385C28: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80385DE0;
    // 0x80385C28: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80385C2C:
    // 0x80385C2C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385C30: jal         0x80363CE0
    // 0x80385C34: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80385C34: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x80385C38: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385C3C: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80385C40: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80385C44: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80385C48: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80385C4C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80385C50:
    // 0x80385C50: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80385C54: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    // 0x80385C58: beql        $at, $zero, L_80385C94
    if (ctx->r1 == 0) {
        // 0x80385C5C: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80385C94;
    }
    goto skip_1;
    // 0x80385C5C: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_1:
    // 0x80385C60: lw          $t0, 0x2C0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C0);
    // 0x80385C64: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80385C68: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385C6C: bnel        $t0, $zero, L_80385C94
    if (ctx->r8 != 0) {
        // 0x80385C70: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80385C94;
    }
    goto skip_2;
    // 0x80385C70: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_2:
    // 0x80385C74: sw          $t1, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r9;
    // 0x80385C78: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80385C7C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385C80: jal         0x80363E88
    // 0x80385C84: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80385C84: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_1:
    // 0x80385C88: b           L_80385CC8
    // 0x80385C8C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
        goto L_80385CC8;
    // 0x80385C8C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385C90: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
L_80385C94:
    // 0x80385C94: bnel        $at, $zero, L_80385CCC
    if (ctx->r1 != 0) {
        // 0x80385C98: lw          $t5, 0x2C4($v1)
        ctx->r13 = MEM_W(ctx->r3, 0X2C4);
            goto L_80385CCC;
    }
    goto skip_3;
    // 0x80385C98: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x80385C9C: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80385CA0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385CA4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80385CA8: beq         $t3, $zero, L_80385CC8
    if (ctx->r11 == 0) {
        // 0x80385CAC: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80385CC8;
    }
    // 0x80385CAC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385CB0: sw          $zero, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = 0;
    // 0x80385CB4: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80385CB8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385CBC: jal         0x80363CE0
    // 0x80385CC0: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80385CC0: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    after_2:
    // 0x80385CC4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80385CC8:
    // 0x80385CC8: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
L_80385CCC:
    // 0x80385CCC: bgtzl       $t5, L_80385DE0
    if (SIGNED(ctx->r13) > 0) {
        // 0x80385CD0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385DE0;
    }
    goto skip_4;
    // 0x80385CD0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80385CD4: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
    // 0x80385CD8: slti        $at, $t6, 0x33
    ctx->r1 = SIGNED(ctx->r14) < 0X33 ? 1 : 0;
    // 0x80385CDC: beql        $at, $zero, L_80385DE0
    if (ctx->r1 == 0) {
        // 0x80385CE0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385DE0;
    }
    goto skip_5;
    // 0x80385CE0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80385CE4: jal         0x80383830
    // 0x80385CE8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80385CE8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x80385CEC: beql        $v0, $zero, L_80385DE0
    if (ctx->r2 == 0) {
        // 0x80385CF0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385DE0;
    }
    goto skip_6;
    // 0x80385CF0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80385CF4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385CF8: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x80385CFC: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80385D00: sw          $t8, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r24;
    // 0x80385D04: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x80385D08: lw          $t0, 0x2BC($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X2BC);
    // 0x80385D0C: slti        $at, $t0, 0x4
    ctx->r1 = SIGNED(ctx->r8) < 0X4 ? 1 : 0;
    // 0x80385D10: beq         $at, $zero, L_80385D20
    if (ctx->r1 == 0) {
        // 0x80385D14: nop
    
            goto L_80385D20;
    }
    // 0x80385D14: nop

    // 0x80385D18: jal         0x802EEF74
    // 0x80385D1C: nop

    dog_bite(rdram, ctx);
        goto after_4;
    // 0x80385D1C: nop

    after_4:
L_80385D20:
    // 0x80385D20: jal         0x8012826C
    // 0x80385D24: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x80385D24: nop

    after_5:
    // 0x80385D28: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x80385D2C: andi        $t1, $v0, 0x3
    ctx->r9 = ctx->r2 & 0X3;
    // 0x80385D30: addiu       $t2, $t1, 0x5
    ctx->r10 = ADD32(ctx->r9, 0X5);
    // 0x80385D34: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
    // 0x80385D38: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385D3C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385D40: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80385D44: lw          $t4, 0x2BC($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2BC);
    // 0x80385D48: slti        $at, $t4, 0x5
    ctx->r1 = SIGNED(ctx->r12) < 0X5 ? 1 : 0;
    // 0x80385D4C: bnel        $at, $zero, L_80385DE0
    if (ctx->r1 != 0) {
        // 0x80385D50: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80385DE0;
    }
    goto skip_7;
    // 0x80385D50: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80385D54: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385D58: jal         0x80363EDC
    // 0x80385D5C: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80385D5C: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80385D60: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385D64: lbu         $t5, 0x2B4($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80385D68: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80385D6C: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80385D70: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
    // 0x80385D74: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80385D78: b           L_80385DDC
    // 0x80385D7C: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
        goto L_80385DDC;
    // 0x80385D7C: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
    // 0x80385D80: lh          $t9, 0x2D0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2D0);
L_80385D84:
    // 0x80385D84: slti        $at, $t9, 0xC8
    ctx->r1 = SIGNED(ctx->r25) < 0XC8 ? 1 : 0;
    // 0x80385D88: beql        $at, $zero, L_80385DAC
    if (ctx->r1 == 0) {
        // 0x80385D8C: lbu         $t1, 0x2B4($v1)
        ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80385DAC;
    }
    goto skip_8;
    // 0x80385D8C: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
    skip_8:
    // 0x80385D90: lw          $a0, 0x2C0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C0);
    // 0x80385D94: slti        $v0, $a0, 0x3D
    ctx->r2 = SIGNED(ctx->r4) < 0X3D ? 1 : 0;
    // 0x80385D98: addiu       $t0, $a0, 0x1
    ctx->r8 = ADD32(ctx->r4, 0X1);
    // 0x80385D9C: bne         $v0, $zero, L_80385DDC
    if (ctx->r2 != 0) {
        // 0x80385DA0: sw          $t0, 0x2C0($v1)
        MEM_W(0X2C0, ctx->r3) = ctx->r8;
            goto L_80385DDC;
    }
    // 0x80385DA0: sw          $t0, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r8;
    // 0x80385DA4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385DA8: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
L_80385DAC:
    // 0x80385DAC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385DB0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80385DB4: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80385DB8: ori         $t3, $t2, 0x10
    ctx->r11 = ctx->r10 | 0X10;
    // 0x80385DBC: sb          $t3, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r11;
    // 0x80385DC0: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80385DC4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385DC8: sw          $zero, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = 0;
    // 0x80385DCC: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x80385DD0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385DD4: jal         0x80363CE0
    // 0x80385DD8: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x80385DD8: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_7:
L_80385DDC:
    // 0x80385DDC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80385DE0:
    // 0x80385DE0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80385DE4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80385DE8: jr          $ra
    // 0x80385DEC: nop

    return;
    // 0x80385DEC: nop

;}
RECOMP_FUNC void perform_behavior_king_rat(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385DF0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385DF4: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385DF8: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385DFC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80385E00: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80385E04: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80385E08: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80385E0C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385E10: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80385E14: beq         $t6, $zero, L_80385E34
    if (ctx->r14 == 0) {
        // 0x80385E18: nop
    
            goto L_80385E34;
    }
    // 0x80385E18: nop

    // 0x80385E1C: beq         $t6, $at, L_80385E60
    if (ctx->r14 == ctx->r1) {
        // 0x80385E20: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80385E60;
    }
    // 0x80385E20: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80385E24: beql        $t6, $at, L_80385EF4
    if (ctx->r14 == ctx->r1) {
        // 0x80385E28: lh          $a0, 0x2D0($v0)
        ctx->r4 = MEM_H(ctx->r2, 0X2D0);
            goto L_80385EF4;
    }
    goto skip_0;
    // 0x80385E28: lh          $a0, 0x2D0($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80385E2C: b           L_80385F74
    // 0x80385E30: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
        goto L_80385F74;
    // 0x80385E30: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
L_80385E34:
    // 0x80385E34: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385E38: jal         0x80363E88
    // 0x80385E3C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_0;
    // 0x80385E3C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80385E40: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385E44: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385E48: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385E4C: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385E50: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80385E54: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80385E58: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80385E5C: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
L_80385E60:
    // 0x80385E60: lh          $t0, 0x2D0($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X2D0);
    // 0x80385E64: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385E68: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80385E6C: slti        $at, $t0, 0xFB
    ctx->r1 = SIGNED(ctx->r8) < 0XFB ? 1 : 0;
    // 0x80385E70: beql        $at, $zero, L_80385EB4
    if (ctx->r1 == 0) {
        // 0x80385E74: lw          $t5, 0x2C4($v0)
        ctx->r13 = MEM_W(ctx->r2, 0X2C4);
            goto L_80385EB4;
    }
    goto skip_1;
    // 0x80385E74: lw          $t5, 0x2C4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X2C4);
    skip_1:
    // 0x80385E78: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385E7C: jal         0x80363EDC
    // 0x80385E80: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80385E80: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_1:
    // 0x80385E84: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385E88: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385E8C: lw          $t1, 0x0($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X0);
    // 0x80385E90: sw          $zero, 0x2C0($t1)
    MEM_W(0X2C0, ctx->r9) = 0;
    // 0x80385E94: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385E98: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385E9C: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80385EA0: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x80385EA4: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x80385EA8: b           L_80385EE8
    // 0x80385EAC: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
        goto L_80385EE8;
    // 0x80385EAC: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385EB0: lw          $t5, 0x2C4($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X2C4);
L_80385EB4:
    // 0x80385EB4: bgtz        $t5, L_80385EE8
    if (SIGNED(ctx->r13) > 0) {
        // 0x80385EB8: nop
    
            goto L_80385EE8;
    }
    // 0x80385EB8: nop

    // 0x80385EBC: lb          $t6, 0x2B5($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X2B5);
    // 0x80385EC0: blez        $t6, L_80385EE8
    if (SIGNED(ctx->r14) <= 0) {
        // 0x80385EC4: nop
    
            goto L_80385EE8;
    }
    // 0x80385EC4: nop

    // 0x80385EC8: jal         0x8035FDC0
    // 0x80385ECC: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    king_rat_bugel_call(rdram, ctx);
        goto after_2;
    // 0x80385ECC: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    after_2:
    // 0x80385ED0: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385ED4: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385ED8: lw          $t8, 0x0($a3)
    ctx->r24 = MEM_W(ctx->r7, 0X0);
    // 0x80385EDC: addiu       $t7, $zero, 0xFA
    ctx->r15 = ADD32(0, 0XFA);
    // 0x80385EE0: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
    // 0x80385EE4: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
L_80385EE8:
    // 0x80385EE8: b           L_80385F74
    // 0x80385EEC: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
        goto L_80385F74;
    // 0x80385EEC: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385EF0: lh          $a0, 0x2D0($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X2D0);
L_80385EF4:
    // 0x80385EF4: slti        $at, $a0, 0x191
    ctx->r1 = SIGNED(ctx->r4) < 0X191 ? 1 : 0;
    // 0x80385EF8: bnel        $at, $zero, L_80385F3C
    if (ctx->r1 != 0) {
        // 0x80385EFC: lw          $v1, 0x2B8($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X2B8);
            goto L_80385F3C;
    }
    goto skip_2;
    // 0x80385EFC: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    skip_2:
    // 0x80385F00: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385F04: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385F08: jal         0x80363E88
    // 0x80385F0C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_3;
    // 0x80385F0C: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_3:
    // 0x80385F10: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385F14: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385F18: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385F1C: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80385F20: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80385F24: ori         $t1, $t0, 0x10
    ctx->r9 = ctx->r8 | 0X10;
    // 0x80385F28: sb          $t1, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r9;
    // 0x80385F2C: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385F30: b           L_80385F74
    // 0x80385F34: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
        goto L_80385F74;
    // 0x80385F34: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x80385F38: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
L_80385F3C:
    // 0x80385F3C: slti        $at, $a0, 0xC8
    ctx->r1 = SIGNED(ctx->r4) < 0XC8 ? 1 : 0;
    // 0x80385F40: bgtz        $v1, L_80385F74
    if (SIGNED(ctx->r3) > 0) {
        // 0x80385F44: nop
    
            goto L_80385F74;
    }
    // 0x80385F44: nop

    // 0x80385F48: beq         $at, $zero, L_80385F74
    if (ctx->r1 == 0) {
        // 0x80385F4C: nop
    
            goto L_80385F74;
    }
    // 0x80385F4C: nop

    // 0x80385F50: jal         0x8035FE6C
    // 0x80385F54: addiu       $a0, $zero, 0x3C
    ctx->r4 = ADD32(0, 0X3C);
    king_rat_fart(rdram, ctx);
        goto after_4;
    // 0x80385F54: addiu       $a0, $zero, 0x3C
    ctx->r4 = ADD32(0, 0X3C);
    after_4:
    // 0x80385F58: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x80385F5C: addiu       $a3, $a3, 0x552C
    ctx->r7 = ADD32(ctx->r7, 0X552C);
    // 0x80385F60: lw          $t3, 0x0($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X0);
    // 0x80385F64: addiu       $t2, $zero, 0xB4
    ctx->r10 = ADD32(0, 0XB4);
    // 0x80385F68: sw          $t2, 0x2B8($t3)
    MEM_W(0X2B8, ctx->r11) = ctx->r10;
    // 0x80385F6C: lw          $v0, 0x0($a3)
    ctx->r2 = MEM_W(ctx->r7, 0X0);
    // 0x80385F70: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
L_80385F74:
    // 0x80385F74: blez        $v1, L_80385F80
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80385F78: addiu       $t4, $v1, -0x1
        ctx->r12 = ADD32(ctx->r3, -0X1);
            goto L_80385F80;
    }
    // 0x80385F78: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x80385F7C: sw          $t4, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r12;
L_80385F80:
    // 0x80385F80: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80385F84: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80385F88: jr          $ra
    // 0x80385F8C: nop

    return;
    // 0x80385F8C: nop

;}
RECOMP_FUNC void perform_behavior_rat(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80385F90: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80385F94: lh          $v0, 0x63F0($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X63F0);
    // 0x80385F98: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80385F9C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80385FA0: bne         $v0, $zero, L_8038614C
    if (ctx->r2 != 0) {
        // 0x80385FA4: sw          $s0, 0x18($sp)
        MEM_W(0X18, ctx->r29) = ctx->r16;
            goto L_8038614C;
    }
    // 0x80385FA4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80385FA8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80385FAC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80385FB0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385FB4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80385FB8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80385FBC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80385FC0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80385FC4: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80385FC8: beq         $t6, $zero, L_80385FEC
    if (ctx->r14 == 0) {
        // 0x80385FCC: nop
    
            goto L_80385FEC;
    }
    // 0x80385FCC: nop

    // 0x80385FD0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80385FD4: beq         $t6, $a0, L_80386010
    if (ctx->r14 == ctx->r4) {
        // 0x80385FD8: addiu       $a1, $zero, 0x2
        ctx->r5 = ADD32(0, 0X2);
            goto L_80386010;
    }
    // 0x80385FD8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80385FDC: beql        $t6, $a1, L_80386058
    if (ctx->r14 == ctx->r5) {
        // 0x80385FE0: lw          $t5, 0x2C4($v1)
        ctx->r13 = MEM_W(ctx->r3, 0X2C4);
            goto L_80386058;
    }
    goto skip_0;
    // 0x80385FE0: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
    skip_0:
    // 0x80385FE4: b           L_80386444
    // 0x80385FE8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386444;
    // 0x80385FE8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80385FEC:
    // 0x80385FEC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80385FF0: jal         0x80363CE0
    // 0x80385FF4: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80385FF4: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x80385FF8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80385FFC: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386000: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386004: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386008: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x8038600C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80386010:
    // 0x80386010: lh          $t0, 0x2D0($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386014: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386018: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038601C: slti        $at, $t0, 0x65
    ctx->r1 = SIGNED(ctx->r8) < 0X65 ? 1 : 0;
    // 0x80386020: beql        $at, $zero, L_80386444
    if (ctx->r1 == 0) {
        // 0x80386024: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_1;
    // 0x80386024: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80386028: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038602C: jal         0x80363EDC
    // 0x80386030: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80386030: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_1:
    // 0x80386034: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80386038: sw          $zero, 0x2C0($t1)
    MEM_W(0X2C0, ctx->r9) = 0;
    // 0x8038603C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386040: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386044: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80386048: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x8038604C: b           L_80386440
    // 0x80386050: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
        goto L_80386440;
    // 0x80386050: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x80386054: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
L_80386058:
    // 0x80386058: bgtzl       $t5, L_80386088
    if (SIGNED(ctx->r13) > 0) {
        // 0x8038605C: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_80386088;
    }
    goto skip_2;
    // 0x8038605C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_2:
    // 0x80386060: jal         0x80383830
    // 0x80386064: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    target_within_current_fov(rdram, ctx);
        goto after_2;
    // 0x80386064: addiu       $a0, $zero, 0x50
    ctx->r4 = ADD32(0, 0X50);
    after_2:
    // 0x80386068: bnel        $v0, $zero, L_80386088
    if (ctx->r2 != 0) {
        // 0x8038606C: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_80386088;
    }
    goto skip_3;
    // 0x8038606C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_3:
    // 0x80386070: jal         0x8035FC2C
    // 0x80386074: nop

    rat_drop_mine(rdram, ctx);
        goto after_3;
    // 0x80386074: nop

    after_3:
    // 0x80386078: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x8038607C: addiu       $t6, $zero, 0x3C
    ctx->r14 = ADD32(0, 0X3C);
    // 0x80386080: sw          $t6, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r14;
    // 0x80386084: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80386088:
    // 0x80386088: lw          $v0, 0x2C0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2C0);
    // 0x8038608C: blezl       $v0, L_80386114
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80386090: lh          $t6, 0x2D0($v1)
        ctx->r14 = MEM_H(ctx->r3, 0X2D0);
            goto L_80386114;
    }
    goto skip_4;
    // 0x80386090: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
    skip_4:
    // 0x80386094: lh          $t8, 0x2D0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386098: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038609C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803860A0: slti        $at, $t8, 0x96
    ctx->r1 = SIGNED(ctx->r24) < 0X96 ? 1 : 0;
    // 0x803860A4: beq         $at, $zero, L_803860C4
    if (ctx->r1 == 0) {
        // 0x803860A8: addiu       $t0, $v0, -0x1
        ctx->r8 = ADD32(ctx->r2, -0X1);
            goto L_803860C4;
    }
    // 0x803860A8: addiu       $t0, $v0, -0x1
    ctx->r8 = ADD32(ctx->r2, -0X1);
    // 0x803860AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803860B0: jal         0x80363EDC
    // 0x803860B4: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x803860B4: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_4:
    // 0x803860B8: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x803860BC: b           L_80386440
    // 0x803860C0: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
        goto L_80386440;
    // 0x803860C0: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
L_803860C4:
    // 0x803860C4: sw          $t0, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r8;
    // 0x803860C8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803860CC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803860D0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803860D4: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    // 0x803860D8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803860DC: bgtzl       $t1, L_80386444
    if (SIGNED(ctx->r9) > 0) {
        // 0x803860E0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_5;
    // 0x803860E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803860E4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803860E8: jal         0x80363CE0
    // 0x803860EC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x803860EC: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_5:
    // 0x803860F0: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x803860F4: sw          $zero, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = 0;
    // 0x803860F8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803860FC: lbu         $t3, 0x2B4($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386100: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80386104: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x80386108: b           L_80386440
    // 0x8038610C: sb          $t5, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r13;
        goto L_80386440;
    // 0x8038610C: sb          $t5, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r13;
    // 0x80386110: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
L_80386114:
    // 0x80386114: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386118: slti        $at, $t6, 0x12C
    ctx->r1 = SIGNED(ctx->r14) < 0X12C ? 1 : 0;
    // 0x8038611C: bnel        $at, $zero, L_80386444
    if (ctx->r1 != 0) {
        // 0x80386120: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_6;
    // 0x80386120: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80386124: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386128: jal         0x80363E88
    // 0x8038612C: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_6;
    // 0x8038612C: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80386130: jal         0x80140D20
    // 0x80386134: nop

    guRandom(rdram, ctx);
        goto after_7;
    // 0x80386134: nop

    after_7:
    // 0x80386138: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x8038613C: andi        $t7, $v0, 0x3F
    ctx->r15 = ctx->r2 & 0X3F;
    // 0x80386140: addiu       $t8, $t7, 0x96
    ctx->r24 = ADD32(ctx->r15, 0X96);
    // 0x80386144: b           L_80386440
    // 0x80386148: sw          $t8, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = ctx->r24;
        goto L_80386440;
    // 0x80386148: sw          $t8, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = ctx->r24;
L_8038614C:
    // 0x8038614C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80386150: bne         $a0, $v0, L_803862E0
    if (ctx->r4 != ctx->r2) {
        // 0x80386154: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_803862E0;
    }
    // 0x80386154: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386158: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x8038615C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386160: lw          $t0, 0x2B4($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2B4);
    // 0x80386164: srl         $t1, $t0, 28
    ctx->r9 = S32(U32(ctx->r8) >> 28);
    // 0x80386168: sltiu       $at, $t1, 0x5
    ctx->r1 = ctx->r9 < 0X5 ? 1 : 0;
    // 0x8038616C: beq         $at, $zero, L_80386440
    if (ctx->r1 == 0) {
        // 0x80386170: sll         $t1, $t1, 2
        ctx->r9 = S32(ctx->r9 << 2);
            goto L_80386440;
    }
    // 0x80386170: sll         $t1, $t1, 2
    ctx->r9 = S32(ctx->r9 << 2);
    // 0x80386174: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80386178: addu        $at, $at, $t1
    gpr jr_addend_80386180 = ctx->r9;
    ctx->r1 = ADD32(ctx->r1, ctx->r9);
    // 0x8038617C: lw          $t1, -0xBCC($at)
    ctx->r9 = ADD32(ctx->r1, -0XBCC);
    // 0x80386180: jr          $t1
    // 0x80386184: nop

    switch (jr_addend_80386180 >> 2) {
        case 0: goto L_80386188; break;
        case 1: goto L_803861B0; break;
        case 2: goto L_80386200; break;
        case 3: goto L_803862A8; break;
        case 4: goto L_80386440; break;
        default: switch_error(__func__, 0x80386180, 0x803BF434);
    }
    // 0x80386184: nop

L_80386188:
    // 0x80386188: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038618C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386190: jal         0x80363E88
    // 0x80386194: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_8;
    // 0x80386194: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_8:
    // 0x80386198: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038619C: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803861A0: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x803861A4: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x803861A8: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x803861AC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_803861B0:
    // 0x803861B0: lw          $t5, 0x2C0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C0);
    // 0x803861B4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803861B8: addiu       $t6, $t5, -0x1
    ctx->r14 = ADD32(ctx->r13, -0X1);
    // 0x803861BC: sw          $t6, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r14;
    // 0x803861C0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803861C4: lw          $t7, 0x2C0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2C0);
    // 0x803861C8: bgtzl       $t7, L_80386444
    if (SIGNED(ctx->r15) > 0) {
        // 0x803861CC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_7;
    // 0x803861CC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x803861D0: lbu         $t8, 0x2B4($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803861D4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803861D8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803861DC: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x803861E0: ori         $t0, $t9, 0x20
    ctx->r8 = ctx->r25 | 0X20;
    // 0x803861E4: sb          $t0, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r8;
    // 0x803861E8: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x803861EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803861F0: jal         0x80363CE0
    // 0x803861F4: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_9;
    // 0x803861F4: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_9:
    // 0x803861F8: b           L_80386444
    // 0x803861FC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386444;
    // 0x803861FC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386200:
    // 0x80386200: lw          $t2, 0x2C4($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C4);
    // 0x80386204: bgtzl       $t2, L_80386444
    if (SIGNED(ctx->r10) > 0) {
        // 0x80386208: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_8;
    // 0x80386208: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_8:
    // 0x8038620C: lh          $t3, 0x2D0($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386210: slti        $at, $t3, 0x29
    ctx->r1 = SIGNED(ctx->r11) < 0X29 ? 1 : 0;
    // 0x80386214: beql        $at, $zero, L_80386444
    if (ctx->r1 == 0) {
        // 0x80386218: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_9;
    // 0x80386218: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_9:
    // 0x8038621C: jal         0x80383830
    // 0x80386220: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    target_within_current_fov(rdram, ctx);
        goto after_10;
    // 0x80386220: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    after_10:
    // 0x80386224: beql        $v0, $zero, L_80386444
    if (ctx->r2 == 0) {
        // 0x80386228: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_10;
    // 0x80386228: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_10:
    // 0x8038622C: jal         0x8035FD4C
    // 0x80386230: nop

    rat_bite(rdram, ctx);
        goto after_11;
    // 0x80386230: nop

    after_11:
    // 0x80386234: jal         0x8012826C
    // 0x80386238: nop

    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x80386238: nop

    after_12:
    // 0x8038623C: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x80386240: andi        $t4, $v0, 0x3
    ctx->r12 = ctx->r2 & 0X3;
    // 0x80386244: addiu       $t5, $t4, 0x5
    ctx->r13 = ADD32(ctx->r12, 0X5);
    // 0x80386248: sw          $t5, 0x2C4($t6)
    MEM_W(0X2C4, ctx->r14) = ctx->r13;
    // 0x8038624C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386250: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386254: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386258: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x8038625C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386260: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80386264: sw          $t8, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r24;
    // 0x80386268: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038626C: lw          $t9, 0x2BC($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2BC);
    // 0x80386270: slti        $at, $t9, 0x6
    ctx->r1 = SIGNED(ctx->r25) < 0X6 ? 1 : 0;
    // 0x80386274: bnel        $at, $zero, L_80386444
    if (ctx->r1 != 0) {
        // 0x80386278: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_11;
    // 0x80386278: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_11:
    // 0x8038627C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386280: jal         0x80363CE0
    // 0x80386284: lw          $a1, 0x280($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X280);
    set_nav_state_chase_target(rdram, ctx);
        goto after_13;
    // 0x80386284: lw          $a1, 0x280($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X280);
    after_13:
    // 0x80386288: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038628C: lbu         $t0, 0x2B4($v1)
    ctx->r8 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386290: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80386294: ori         $t2, $t1, 0x30
    ctx->r10 = ctx->r9 | 0X30;
    // 0x80386298: sb          $t2, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r10;
    // 0x8038629C: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x803862A0: b           L_80386440
    // 0x803862A4: sw          $zero, 0x2BC($t3)
    MEM_W(0X2BC, ctx->r11) = 0;
        goto L_80386440;
    // 0x803862A4: sw          $zero, 0x2BC($t3)
    MEM_W(0X2BC, ctx->r11) = 0;
L_803862A8:
    // 0x803862A8: lui         $t4, 0x803E
    ctx->r12 = S32(0X803E << 16);
    // 0x803862AC: lw          $t4, 0x4C3C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X4C3C);
    // 0x803862B0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803862B4: slti        $at, $t4, 0x65
    ctx->r1 = SIGNED(ctx->r12) < 0X65 ? 1 : 0;
    // 0x803862B8: beql        $at, $zero, L_80386444
    if (ctx->r1 == 0) {
        // 0x803862BC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_12;
    // 0x803862BC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_12:
    // 0x803862C0: jal         0x80363CC8
    // 0x803862C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_14;
    // 0x803862C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_14:
    // 0x803862C8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803862CC: lbu         $t5, 0x2B4($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803862D0: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x803862D4: ori         $t7, $t6, 0x40
    ctx->r15 = ctx->r14 | 0X40;
    // 0x803862D8: b           L_80386440
    // 0x803862DC: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
        goto L_80386440;
    // 0x803862DC: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
L_803862E0:
    // 0x803862E0: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803862E4: bne         $a1, $v0, L_80386440
    if (ctx->r5 != ctx->r2) {
        // 0x803862E8: lui         $s0, 0x803D
        ctx->r16 = S32(0X803D << 16);
            goto L_80386440;
    }
    // 0x803862E8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803862EC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x803862F0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803862F4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803862F8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803862FC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80386300: srl         $t8, $v0, 28
    ctx->r24 = S32(U32(ctx->r2) >> 28);
    // 0x80386304: beq         $t8, $zero, L_80386324
    if (ctx->r24 == 0) {
        // 0x80386308: nop
    
            goto L_80386324;
    }
    // 0x80386308: nop

    // 0x8038630C: beql        $t8, $a0, L_80386350
    if (ctx->r24 == ctx->r4) {
        // 0x80386310: lw          $t2, 0x2C4($v1)
        ctx->r10 = MEM_W(ctx->r3, 0X2C4);
            goto L_80386350;
    }
    goto skip_13;
    // 0x80386310: lw          $t2, 0x2C4($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C4);
    skip_13:
    // 0x80386314: beql        $t8, $a1, L_803863FC
    if (ctx->r24 == ctx->r5) {
        // 0x80386318: lw          $t7, 0x2C0($v1)
        ctx->r15 = MEM_W(ctx->r3, 0X2C0);
            goto L_803863FC;
    }
    goto skip_14;
    // 0x80386318: lw          $t7, 0x2C0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2C0);
    skip_14:
    // 0x8038631C: b           L_80386444
    // 0x80386320: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386444;
    // 0x80386320: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386324:
    // 0x80386324: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386328: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038632C: jal         0x80363CE0
    // 0x80386330: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_15;
    // 0x80386330: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_15:
    // 0x80386334: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386338: lbu         $t9, 0x2B4($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X2B4);
    // 0x8038633C: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80386340: ori         $t1, $t0, 0x10
    ctx->r9 = ctx->r8 | 0X10;
    // 0x80386344: sb          $t1, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r9;
    // 0x80386348: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038634C: lw          $t2, 0x2C4($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C4);
L_80386350:
    // 0x80386350: bgtzl       $t2, L_80386444
    if (SIGNED(ctx->r10) > 0) {
        // 0x80386354: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_15;
    // 0x80386354: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_15:
    // 0x80386358: lh          $t3, 0x2D0($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X2D0);
    // 0x8038635C: slti        $at, $t3, 0x47
    ctx->r1 = SIGNED(ctx->r11) < 0X47 ? 1 : 0;
    // 0x80386360: beql        $at, $zero, L_80386444
    if (ctx->r1 == 0) {
        // 0x80386364: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_16;
    // 0x80386364: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_16:
    // 0x80386368: jal         0x80383830
    // 0x8038636C: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    target_within_current_fov(rdram, ctx);
        goto after_16;
    // 0x8038636C: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    after_16:
    // 0x80386370: beql        $v0, $zero, L_80386444
    if (ctx->r2 == 0) {
        // 0x80386374: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_17;
    // 0x80386374: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_17:
    // 0x80386378: jal         0x8035FD4C
    // 0x8038637C: nop

    rat_bite(rdram, ctx);
        goto after_17;
    // 0x8038637C: nop

    after_17:
    // 0x80386380: jal         0x8012826C
    // 0x80386384: nop

    advance_random_seed(rdram, ctx);
        goto after_18;
    // 0x80386384: nop

    after_18:
    // 0x80386388: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x8038638C: andi        $t4, $v0, 0x3
    ctx->r12 = ctx->r2 & 0X3;
    // 0x80386390: addiu       $t5, $t4, 0x5
    ctx->r13 = ADD32(ctx->r12, 0X5);
    // 0x80386394: sw          $t5, 0x2C4($t6)
    MEM_W(0X2C4, ctx->r14) = ctx->r13;
    // 0x80386398: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038639C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803863A0: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x803863A4: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x803863A8: sw          $t8, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r24;
    // 0x803863AC: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x803863B0: lw          $t0, 0x2BC($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X2BC);
    // 0x803863B4: slti        $at, $t0, 0x6
    ctx->r1 = SIGNED(ctx->r8) < 0X6 ? 1 : 0;
    // 0x803863B8: bnel        $at, $zero, L_80386444
    if (ctx->r1 != 0) {
        // 0x803863BC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_18;
    // 0x803863BC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_18:
    // 0x803863C0: jal         0x80363CC8
    // 0x803863C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_19;
    // 0x803863C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_19:
    // 0x803863C8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803863CC: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803863D0: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803863D4: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x803863D8: sb          $t3, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r11;
    // 0x803863DC: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x803863E0: jal         0x80140D20
    // 0x803863E4: sw          $zero, 0x2BC($t4)
    MEM_W(0X2BC, ctx->r12) = 0;
    guRandom(rdram, ctx);
        goto after_20;
    // 0x803863E4: sw          $zero, 0x2BC($t4)
    MEM_W(0X2BC, ctx->r12) = 0;
    after_20:
    // 0x803863E8: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x803863EC: andi        $t5, $v0, 0x3F
    ctx->r13 = ctx->r2 & 0X3F;
    // 0x803863F0: b           L_80386440
    // 0x803863F4: sw          $t5, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = ctx->r13;
        goto L_80386440;
    // 0x803863F4: sw          $t5, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = ctx->r13;
    // 0x803863F8: lw          $t7, 0x2C0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2C0);
L_803863FC:
    // 0x803863FC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386400: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386404: addiu       $t8, $t7, -0x1
    ctx->r24 = ADD32(ctx->r15, -0X1);
    // 0x80386408: sw          $t8, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r24;
    // 0x8038640C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386410: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386414: lw          $t9, 0x2C0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386418: bgtzl       $t9, L_80386444
    if (SIGNED(ctx->r25) > 0) {
        // 0x8038641C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386444;
    }
    goto skip_19;
    // 0x8038641C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_19:
    // 0x80386420: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386424: jal         0x80363CE0
    // 0x80386428: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_21;
    // 0x80386428: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_21:
    // 0x8038642C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386430: lbu         $t0, 0x2B4($v1)
    ctx->r8 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386434: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80386438: ori         $t2, $t1, 0x10
    ctx->r10 = ctx->r9 | 0X10;
    // 0x8038643C: sb          $t2, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r10;
L_80386440:
    // 0x80386440: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386444:
    // 0x80386444: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80386448: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8038644C: jr          $ra
    // 0x80386450: nop

    return;
    // 0x80386450: nop

;}
RECOMP_FUNC void perform_behavior_sheep(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80386454: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80386458: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038645C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386460: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80386464: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80386468: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038646C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386470: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80386474: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386478: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038647C: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80386480: beq         $t6, $zero, L_803864A0
    if (ctx->r14 == 0) {
        // 0x80386484: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803864A0;
    }
    // 0x80386484: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386488: beq         $t6, $at, L_803864C4
    if (ctx->r14 == ctx->r1) {
        // 0x8038648C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803864C4;
    }
    // 0x8038648C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80386490: beql        $t6, $at, L_80386590
    if (ctx->r14 == ctx->r1) {
        // 0x80386494: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386590;
    }
    goto skip_0;
    // 0x80386494: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80386498: b           L_80386590
    // 0x8038649C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386590;
    // 0x8038649C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803864A0:
    // 0x803864A0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803864A4: jal         0x80363CE0
    // 0x803864A8: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803864A8: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x803864AC: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803864B0: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803864B4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803864B8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803864BC: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x803864C0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
L_803864C4:
    // 0x803864C4: lw          $t0, 0x2C0($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C0);
    // 0x803864C8: addiu       $t1, $t0, -0x1
    ctx->r9 = ADD32(ctx->r8, -0X1);
    // 0x803864CC: sw          $t1, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r9;
    // 0x803864D0: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x803864D4: lw          $t2, 0x2C0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2C0);
    // 0x803864D8: bgtzl       $t2, L_80386590
    if (SIGNED(ctx->r10) > 0) {
        // 0x803864DC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386590;
    }
    goto skip_1;
    // 0x803864DC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803864E0: lw          $a0, 0x2B8($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2B8);
    // 0x803864E4: slti        $v1, $a0, 0x6
    ctx->r3 = SIGNED(ctx->r4) < 0X6 ? 1 : 0;
    // 0x803864E8: addiu       $t3, $a0, 0x1
    ctx->r11 = ADD32(ctx->r4, 0X1);
    // 0x803864EC: bne         $v1, $zero, L_80386534
    if (ctx->r3 != 0) {
        // 0x803864F0: sw          $t3, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r11;
            goto L_80386534;
    }
    // 0x803864F0: sw          $t3, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r11;
    // 0x803864F4: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x803864F8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803864FC: sb          $zero, 0x270($t4)
    MEM_B(0X270, ctx->r12) = 0;
    // 0x80386500: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80386504: lhu         $t5, 0x2C8($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2C8);
    // 0x80386508: sh          $t5, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r13;
    // 0x8038650C: lw          $v0, 0x0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X0);
    // 0x80386510: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80386514: andi        $t7, $t6, 0xFFF1
    ctx->r15 = ctx->r14 & 0XFFF1;
    // 0x80386518: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x8038651C: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80386520: sw          $zero, 0x2CC($t8)
    MEM_W(0X2CC, ctx->r24) = 0;
    // 0x80386524: jal         0x80363FF0
    // 0x80386528: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_1;
    // 0x80386528: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_1:
    // 0x8038652C: b           L_80386590
    // 0x80386530: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386590;
    // 0x80386530: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386534:
    // 0x80386534: jal         0x8030A958
    // 0x80386538: nop

    animal_jump(rdram, ctx);
        goto after_2;
    // 0x80386538: nop

    after_2:
    // 0x8038653C: jal         0x80140D20
    // 0x80386540: nop

    guRandom(rdram, ctx);
        goto after_3;
    // 0x80386540: nop

    after_3:
    // 0x80386544: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80386548: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038654C: mfhi        $a1
    ctx->r5 = hi;
    // 0x80386550: andi        $t9, $a1, 0xFFFF
    ctx->r25 = ctx->r5 & 0XFFFF;
    // 0x80386554: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386558: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038655C: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80386560: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80386564: jal         0x80363FB8
    // 0x80386568: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    set_nav_state_scripted(rdram, ctx);
        goto after_4;
    // 0x80386568: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_4:
    // 0x8038656C: jal         0x80140D20
    // 0x80386570: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x80386570: nop

    after_5:
    // 0x80386574: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    // 0x80386578: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038657C: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80386580: mfhi        $t0
    ctx->r8 = hi;
    // 0x80386584: addiu       $t1, $t0, 0x14
    ctx->r9 = ADD32(ctx->r8, 0X14);
    // 0x80386588: sw          $t1, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = ctx->r9;
    // 0x8038658C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386590:
    // 0x80386590: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80386594: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80386598: jr          $ra
    // 0x8038659C: nop

    return;
    // 0x8038659C: nop

;}
RECOMP_FUNC void perform_behavior_ram(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803865A0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x803865A4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x803865A8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803865AC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x803865B0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803865B4: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x803865B8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803865BC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803865C0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803865C4: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803865C8: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803865CC: beq         $t6, $zero, L_803865EC
    if (ctx->r14 == 0) {
        // 0x803865D0: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803865EC;
    }
    // 0x803865D0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803865D4: beq         $t6, $at, L_80386610
    if (ctx->r14 == ctx->r1) {
        // 0x803865D8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80386610;
    }
    // 0x803865D8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803865DC: beql        $t6, $at, L_80386744
    if (ctx->r14 == ctx->r1) {
        // 0x803865E0: lh          $t9, 0x2D0($v1)
        ctx->r25 = MEM_H(ctx->r3, 0X2D0);
            goto L_80386744;
    }
    goto skip_0;
    // 0x803865E0: lh          $t9, 0x2D0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x803865E4: b           L_803867A8
    // 0x803865E8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_803867A8;
    // 0x803865E8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803865EC:
    // 0x803865EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803865F0: jal         0x80363CE0
    // 0x803865F4: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803865F4: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x803865F8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803865FC: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386600: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386604: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386608: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x8038660C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80386610:
    // 0x80386610: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386614: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    // 0x80386618: beql        $at, $zero, L_80386654
    if (ctx->r1 == 0) {
        // 0x8038661C: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80386654;
    }
    goto skip_1;
    // 0x8038661C: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_1:
    // 0x80386620: lw          $t0, 0x2C0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386624: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80386628: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038662C: bnel        $t0, $zero, L_80386654
    if (ctx->r8 != 0) {
        // 0x80386630: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80386654;
    }
    goto skip_2;
    // 0x80386630: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_2:
    // 0x80386634: sw          $t1, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r9;
    // 0x80386638: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x8038663C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386640: jal         0x80363E88
    // 0x80386644: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80386644: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_1:
    // 0x80386648: b           L_80386688
    // 0x8038664C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
        goto L_80386688;
    // 0x8038664C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386650: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
L_80386654:
    // 0x80386654: bnel        $at, $zero, L_8038668C
    if (ctx->r1 != 0) {
        // 0x80386658: lw          $t5, 0x2C4($v1)
        ctx->r13 = MEM_W(ctx->r3, 0X2C4);
            goto L_8038668C;
    }
    goto skip_3;
    // 0x80386658: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x8038665C: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386660: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386664: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80386668: beq         $t3, $zero, L_80386688
    if (ctx->r11 == 0) {
        // 0x8038666C: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80386688;
    }
    // 0x8038666C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386670: sw          $zero, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = 0;
    // 0x80386674: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80386678: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038667C: jal         0x80363CE0
    // 0x80386680: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80386680: lw          $a1, 0x2CC($t4)
    ctx->r5 = MEM_W(ctx->r12, 0X2CC);
    after_2:
    // 0x80386684: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80386688:
    // 0x80386688: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
L_8038668C:
    // 0x8038668C: bgtzl       $t5, L_803867A8
    if (SIGNED(ctx->r13) > 0) {
        // 0x80386690: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803867A8;
    }
    goto skip_4;
    // 0x80386690: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80386694: lh          $t6, 0x2D0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386698: slti        $at, $t6, 0x33
    ctx->r1 = SIGNED(ctx->r14) < 0X33 ? 1 : 0;
    // 0x8038669C: beql        $at, $zero, L_803867A8
    if (ctx->r1 == 0) {
        // 0x803866A0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803867A8;
    }
    goto skip_5;
    // 0x803866A0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803866A4: jal         0x80383830
    // 0x803866A8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x803866A8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x803866AC: beql        $v0, $zero, L_803867A8
    if (ctx->r2 == 0) {
        // 0x803866B0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803867A8;
    }
    goto skip_6;
    // 0x803866B0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x803866B4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803866B8: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x803866BC: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x803866C0: sw          $t8, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r24;
    // 0x803866C4: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x803866C8: lw          $t0, 0x2BC($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X2BC);
    // 0x803866CC: slti        $at, $t0, 0x4
    ctx->r1 = SIGNED(ctx->r8) < 0X4 ? 1 : 0;
    // 0x803866D0: beq         $at, $zero, L_803866E0
    if (ctx->r1 == 0) {
        // 0x803866D4: nop
    
            goto L_803866E0;
    }
    // 0x803866D4: nop

    // 0x803866D8: jal         0x80362A84
    // 0x803866DC: nop

    ram_headbutt(rdram, ctx);
        goto after_4;
    // 0x803866DC: nop

    after_4:
L_803866E0:
    // 0x803866E0: jal         0x8012826C
    // 0x803866E4: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x803866E4: nop

    after_5:
    // 0x803866E8: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x803866EC: andi        $t1, $v0, 0x3
    ctx->r9 = ctx->r2 & 0X3;
    // 0x803866F0: addiu       $t2, $t1, 0x5
    ctx->r10 = ADD32(ctx->r9, 0X5);
    // 0x803866F4: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
    // 0x803866F8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803866FC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386700: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80386704: lw          $t4, 0x2BC($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2BC);
    // 0x80386708: slti        $at, $t4, 0x3
    ctx->r1 = SIGNED(ctx->r12) < 0X3 ? 1 : 0;
    // 0x8038670C: bnel        $at, $zero, L_803867A8
    if (ctx->r1 != 0) {
        // 0x80386710: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803867A8;
    }
    goto skip_7;
    // 0x80386710: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80386714: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386718: jal         0x80363EDC
    // 0x8038671C: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x8038671C: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80386720: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386724: lbu         $t5, 0x2B4($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386728: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8038672C: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80386730: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
    // 0x80386734: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x80386738: b           L_803867A4
    // 0x8038673C: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
        goto L_803867A4;
    // 0x8038673C: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
    // 0x80386740: lh          $t9, 0x2D0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2D0);
L_80386744:
    // 0x80386744: slti        $at, $t9, 0xC8
    ctx->r1 = SIGNED(ctx->r25) < 0XC8 ? 1 : 0;
    // 0x80386748: beql        $at, $zero, L_80386774
    if (ctx->r1 == 0) {
        // 0x8038674C: lbu         $t3, 0x2B4($v1)
        ctx->r11 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80386774;
    }
    goto skip_8;
    // 0x8038674C: lbu         $t3, 0x2B4($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X2B4);
    skip_8:
    // 0x80386750: lw          $t0, 0x2C0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386754: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x80386758: sw          $t1, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r9;
    // 0x8038675C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80386760: lw          $t2, 0x2C0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386764: slti        $at, $t2, 0x1E
    ctx->r1 = SIGNED(ctx->r10) < 0X1E ? 1 : 0;
    // 0x80386768: bnel        $at, $zero, L_803867A8
    if (ctx->r1 != 0) {
        // 0x8038676C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803867A8;
    }
    goto skip_9;
    // 0x8038676C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_9:
    // 0x80386770: lbu         $t3, 0x2B4($v1)
    ctx->r11 = MEM_BU(ctx->r3, 0X2B4);
L_80386774:
    // 0x80386774: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386778: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038677C: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80386780: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x80386784: sb          $t5, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r13;
    // 0x80386788: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x8038678C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386790: sw          $zero, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = 0;
    // 0x80386794: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x80386798: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038679C: jal         0x80363CE0
    // 0x803867A0: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x803867A0: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_7:
L_803867A4:
    // 0x803867A4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803867A8:
    // 0x803867A8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803867AC: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x803867B0: jr          $ra
    // 0x803867B4: nop

    return;
    // 0x803867B4: nop

;}
RECOMP_FUNC void perform_behavior_springy_thingy(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803867B8: jr          $ra
    // 0x803867BC: nop

    return;
    // 0x803867BC: nop

;}
RECOMP_FUNC void perform_behavior_springy_ram(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803867C0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803867C4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803867C8: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803867CC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803867D0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803867D4: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803867D8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803867DC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803867E0: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803867E4: beq         $t6, $zero, L_80386810
    if (ctx->r14 == 0) {
        // 0x803867E8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80386810;
    }
    // 0x803867E8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803867EC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803867F0: beq         $t6, $at, L_8038683C
    if (ctx->r14 == ctx->r1) {
        // 0x803867F4: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8038683C;
    }
    // 0x803867F4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803867F8: beq         $t6, $at, L_80386990
    if (ctx->r14 == ctx->r1) {
        // 0x803867FC: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80386990;
    }
    // 0x803867FC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80386800: beql        $t6, $at, L_803869F0
    if (ctx->r14 == ctx->r1) {
        // 0x80386804: lw          $t1, 0x2C0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X2C0);
            goto L_803869F0;
    }
    goto skip_0;
    // 0x80386804: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    skip_0:
    // 0x80386808: b           L_80386A3C
    // 0x8038680C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80386A3C;
    // 0x8038680C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80386810:
    // 0x80386810: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386814: jal         0x80363CE0
    // 0x80386818: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80386818: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x8038681C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386820: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386824: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386828: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x8038682C: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386830: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386834: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80386838: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_8038683C:
    // 0x8038683C: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386840: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    // 0x80386844: beql        $at, $zero, L_80386888
    if (ctx->r1 == 0) {
        // 0x80386848: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80386888;
    }
    goto skip_1;
    // 0x80386848: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_1:
    // 0x8038684C: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386850: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80386854: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386858: bnel        $t1, $zero, L_80386888
    if (ctx->r9 != 0) {
        // 0x8038685C: slti        $at, $v0, 0x33
        ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
            goto L_80386888;
    }
    goto skip_2;
    // 0x8038685C: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
    skip_2:
    // 0x80386860: sw          $t2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r10;
    // 0x80386864: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x80386868: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038686C: jal         0x80363E88
    // 0x80386870: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80386870: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_1:
    // 0x80386874: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386878: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038687C: b           L_803868C4
    // 0x80386880: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
        goto L_803868C4;
    // 0x80386880: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386884: slti        $at, $v0, 0x33
    ctx->r1 = SIGNED(ctx->r2) < 0X33 ? 1 : 0;
L_80386888:
    // 0x80386888: bnel        $at, $zero, L_803868C8
    if (ctx->r1 != 0) {
        // 0x8038688C: lw          $t6, 0x2C4($v1)
        ctx->r14 = MEM_W(ctx->r3, 0X2C4);
            goto L_803868C8;
    }
    goto skip_3;
    // 0x8038688C: lw          $t6, 0x2C4($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x80386890: lw          $t4, 0x2C0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386894: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386898: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038689C: beq         $t4, $zero, L_803868C4
    if (ctx->r12 == 0) {
        // 0x803868A0: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803868C4;
    }
    // 0x803868A0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803868A4: sw          $zero, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = 0;
    // 0x803868A8: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x803868AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803868B0: jal         0x80363CE0
    // 0x803868B4: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x803868B4: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_2:
    // 0x803868B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803868BC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803868C0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_803868C4:
    // 0x803868C4: lw          $t6, 0x2C4($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2C4);
L_803868C8:
    // 0x803868C8: bgtzl       $t6, L_80386A3C
    if (SIGNED(ctx->r14) > 0) {
        // 0x803868CC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80386A3C;
    }
    goto skip_4;
    // 0x803868CC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803868D0: lh          $t7, 0x2D0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X2D0);
    // 0x803868D4: slti        $at, $t7, 0x33
    ctx->r1 = SIGNED(ctx->r15) < 0X33 ? 1 : 0;
    // 0x803868D8: beql        $at, $zero, L_80386A3C
    if (ctx->r1 == 0) {
        // 0x803868DC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80386A3C;
    }
    goto skip_5;
    // 0x803868DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x803868E0: jal         0x80383830
    // 0x803868E4: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x803868E4: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x803868E8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803868EC: beq         $v0, $zero, L_80386A38
    if (ctx->r2 == 0) {
        // 0x803868F0: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80386A38;
    }
    // 0x803868F0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803868F4: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803868F8: lw          $t8, 0x2BC($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X2BC);
    // 0x803868FC: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80386900: sw          $t9, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r25;
    // 0x80386904: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80386908: lw          $t2, 0x2BC($t1)
    ctx->r10 = MEM_W(ctx->r9, 0X2BC);
    // 0x8038690C: slti        $at, $t2, 0x5
    ctx->r1 = SIGNED(ctx->r10) < 0X5 ? 1 : 0;
    // 0x80386910: beq         $at, $zero, L_80386920
    if (ctx->r1 == 0) {
        // 0x80386914: nop
    
            goto L_80386920;
    }
    // 0x80386914: nop

    // 0x80386918: jal         0x80362A84
    // 0x8038691C: nop

    ram_headbutt(rdram, ctx);
        goto after_4;
    // 0x8038691C: nop

    after_4:
L_80386920:
    // 0x80386920: jal         0x8012826C
    // 0x80386924: nop

    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x80386924: nop

    after_5:
    // 0x80386928: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038692C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386930: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x80386934: andi        $t3, $v0, 0x3
    ctx->r11 = ctx->r2 & 0X3;
    // 0x80386938: addiu       $t4, $t3, 0x5
    ctx->r12 = ADD32(ctx->r11, 0X5);
    // 0x8038693C: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x80386940: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386944: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386948: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038694C: lw          $t6, 0x2BC($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2BC);
    // 0x80386950: slti        $at, $t6, 0x5
    ctx->r1 = SIGNED(ctx->r14) < 0X5 ? 1 : 0;
    // 0x80386954: bnel        $at, $zero, L_80386A3C
    if (ctx->r1 != 0) {
        // 0x80386958: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80386A3C;
    }
    goto skip_6;
    // 0x80386958: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_6:
    // 0x8038695C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386960: jal         0x80363EDC
    // 0x80386964: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80386964: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x80386968: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038696C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386970: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386974: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386978: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x8038697C: ori         $t9, $t8, 0x20
    ctx->r25 = ctx->r24 | 0X20;
    // 0x80386980: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80386984: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80386988: b           L_80386A38
    // 0x8038698C: sw          $zero, 0x2BC($t1)
    MEM_W(0X2BC, ctx->r9) = 0;
        goto L_80386A38;
    // 0x8038698C: sw          $zero, 0x2BC($t1)
    MEM_W(0X2BC, ctx->r9) = 0;
L_80386990:
    // 0x80386990: lh          $t2, 0x2D0($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386994: slti        $at, $t2, 0xC8
    ctx->r1 = SIGNED(ctx->r10) < 0XC8 ? 1 : 0;
    // 0x80386998: beql        $at, $zero, L_803869C4
    if (ctx->r1 == 0) {
        // 0x8038699C: lbu         $t6, 0x2B4($v1)
        ctx->r14 = MEM_BU(ctx->r3, 0X2B4);
            goto L_803869C4;
    }
    goto skip_7;
    // 0x8038699C: lbu         $t6, 0x2B4($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X2B4);
    skip_7:
    // 0x803869A0: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x803869A4: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x803869A8: sw          $t4, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r12;
    // 0x803869AC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x803869B0: lw          $t5, 0x2C0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C0);
    // 0x803869B4: slti        $at, $t5, 0x33
    ctx->r1 = SIGNED(ctx->r13) < 0X33 ? 1 : 0;
    // 0x803869B8: bnel        $at, $zero, L_80386A3C
    if (ctx->r1 != 0) {
        // 0x803869BC: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80386A3C;
    }
    goto skip_8;
    // 0x803869BC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x803869C0: lbu         $t6, 0x2B4($v1)
    ctx->r14 = MEM_BU(ctx->r3, 0X2B4);
L_803869C4:
    // 0x803869C4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803869C8: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x803869CC: ori         $t8, $t7, 0x30
    ctx->r24 = ctx->r15 | 0X30;
    // 0x803869D0: sb          $t8, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r24;
    // 0x803869D4: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x803869D8: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
    // 0x803869DC: jal         0x80363CC8
    // 0x803869E0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_7;
    // 0x803869E0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_7:
    // 0x803869E4: b           L_80386A3C
    // 0x803869E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80386A3C;
    // 0x803869E8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803869EC: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
L_803869F0:
    // 0x803869F0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803869F4: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x803869F8: sw          $t2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r10;
    // 0x803869FC: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386A00: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386A04: slti        $at, $t3, 0x47
    ctx->r1 = SIGNED(ctx->r11) < 0X47 ? 1 : 0;
    // 0x80386A08: bnel        $at, $zero, L_80386A3C
    if (ctx->r1 != 0) {
        // 0x80386A0C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80386A3C;
    }
    goto skip_9;
    // 0x80386A0C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_9:
    // 0x80386A10: lbu         $t4, 0x2B4($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386A14: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80386A18: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386A1C: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80386A20: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x80386A24: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
    // 0x80386A28: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x80386A2C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386A30: jal         0x80363CE0
    // 0x80386A34: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_8;
    // 0x80386A34: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_8:
L_80386A38:
    // 0x80386A38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80386A3C:
    // 0x80386A3C: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80386A40: jr          $ra
    // 0x80386A44: nop

    return;
    // 0x80386A44: nop

;}
RECOMP_FUNC void perform_behavior_penguin(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80386A48: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80386A4C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80386A50: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80386A54: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80386A58: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80386A5C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80386A60: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386A64: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80386A68: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386A6C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386A70: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80386A74: beq         $t6, $zero, L_80386A8C
    if (ctx->r14 == 0) {
        // 0x80386A78: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80386A8C;
    }
    // 0x80386A78: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386A7C: beql        $t6, $at, L_80386ABC
    if (ctx->r14 == ctx->r1) {
        // 0x80386A80: lw          $t0, 0x2C0($s0)
        ctx->r8 = MEM_W(ctx->r16, 0X2C0);
            goto L_80386ABC;
    }
    goto skip_0;
    // 0x80386A80: lw          $t0, 0x2C0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C0);
    skip_0:
    // 0x80386A84: b           L_80386BA8
    // 0x80386A88: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386BA8;
    // 0x80386A88: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386A8C:
    // 0x80386A8C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386A90: jal         0x80363CE0
    // 0x80386A94: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80386A94: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80386A98: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80386A9C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80386AA0: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80386AA4: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386AA8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386AAC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386AB0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80386AB4: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80386AB8: lw          $t0, 0x2C0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C0);
L_80386ABC:
    // 0x80386ABC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386AC0: bnel        $t0, $at, L_80386B1C
    if (ctx->r8 != ctx->r1) {
        // 0x80386AC4: lh          $t6, 0x2D0($s0)
        ctx->r14 = MEM_H(ctx->r16, 0X2D0);
            goto L_80386B1C;
    }
    goto skip_1;
    // 0x80386AC4: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
    skip_1:
    // 0x80386AC8: lh          $t1, 0x2D0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2D0);
    // 0x80386ACC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386AD0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80386AD4: slti        $at, $t1, 0x15F
    ctx->r1 = SIGNED(ctx->r9) < 0X15F ? 1 : 0;
    // 0x80386AD8: bne         $at, $zero, L_80386B50
    if (ctx->r1 != 0) {
        // 0x80386ADC: addiu       $a3, $zero, 0xA
        ctx->r7 = ADD32(0, 0XA);
            goto L_80386B50;
    }
    // 0x80386ADC: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80386AE0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386AE4: jal         0x80363CE0
    // 0x80386AE8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_1;
    // 0x80386AE8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80386AEC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80386AF0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80386AF4: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80386AF8: lbu         $t2, 0x2B4($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386AFC: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80386B00: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x80386B04: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
    // 0x80386B08: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x80386B0C: sw          $zero, 0x2C0($t5)
    MEM_W(0X2C0, ctx->r13) = 0;
    // 0x80386B10: b           L_80386B50
    // 0x80386B14: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
        goto L_80386B50;
    // 0x80386B14: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80386B18: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
L_80386B1C:
    // 0x80386B1C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386B20: slti        $at, $t6, 0xFA
    ctx->r1 = SIGNED(ctx->r14) < 0XFA ? 1 : 0;
    // 0x80386B24: beql        $at, $zero, L_80386B54
    if (ctx->r1 == 0) {
        // 0x80386B28: lw          $t9, 0x2C4($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X2C4);
            goto L_80386B54;
    }
    goto skip_2;
    // 0x80386B28: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
    skip_2:
    // 0x80386B2C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386B30: jal         0x80363E88
    // 0x80386B34: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80386B34: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80386B38: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80386B3C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80386B40: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80386B44: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80386B48: sw          $t7, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = ctx->r15;
    // 0x80386B4C: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
L_80386B50:
    // 0x80386B50: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
L_80386B54:
    // 0x80386B54: bgtzl       $t9, L_80386BA8
    if (SIGNED(ctx->r25) > 0) {
        // 0x80386B58: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386BA8;
    }
    goto skip_3;
    // 0x80386B58: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80386B5C: jal         0x80383830
    // 0x80386B60: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80386B60: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x80386B64: beql        $v0, $zero, L_80386BA8
    if (ctx->r2 == 0) {
        // 0x80386B68: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386BA8;
    }
    goto skip_4;
    // 0x80386B68: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80386B6C: jal         0x80140D20
    // 0x80386B70: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x80386B70: nop

    after_4:
    // 0x80386B74: sra         $t0, $v0, 8
    ctx->r8 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80386B78: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80386B7C: div         $zero, $t0, $at
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r1)));
    // 0x80386B80: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80386B84: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80386B88: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x80386B8C: mfhi        $t1
    ctx->r9 = hi;
    // 0x80386B90: addiu       $t2, $t1, 0x14
    ctx->r10 = ADD32(ctx->r9, 0X14);
    // 0x80386B94: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
    // 0x80386B98: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x80386B9C: jal         0x80365D8C
    // 0x80386BA0: lw          $a0, 0x2CC($t4)
    ctx->r4 = MEM_W(ctx->r12, 0X2CC);
    penguin_throw_snowball(rdram, ctx);
        goto after_5;
    // 0x80386BA0: lw          $a0, 0x2CC($t4)
    ctx->r4 = MEM_W(ctx->r12, 0X2CC);
    after_5:
    // 0x80386BA4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386BA8:
    // 0x80386BA8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80386BAC: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80386BB0: jr          $ra
    // 0x80386BB4: nop

    return;
    // 0x80386BB4: nop

;}
RECOMP_FUNC void perform_behavior_polar_bear(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80386BB8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386BBC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386BC0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386BC4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80386BC8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80386BCC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80386BD0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386BD4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386BD8: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80386BDC: beql        $t6, $zero, L_80386C00
    if (ctx->r14 == 0) {
        // 0x80386BE0: lbu         $t7, 0x2B4($v1)
        ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80386C00;
    }
    goto skip_0;
    // 0x80386BE0: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    skip_0:
    // 0x80386BE4: beq         $t6, $at, L_80386C30
    if (ctx->r14 == ctx->r1) {
        // 0x80386BE8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80386C30;
    }
    // 0x80386BE8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80386BEC: beql        $t6, $at, L_80386D0C
    if (ctx->r14 == ctx->r1) {
        // 0x80386BF0: lh          $t8, 0x2D0($v1)
        ctx->r24 = MEM_H(ctx->r3, 0X2D0);
            goto L_80386D0C;
    }
    goto skip_1;
    // 0x80386BF0: lh          $t8, 0x2D0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2D0);
    skip_1:
    // 0x80386BF4: b           L_80386D74
    // 0x80386BF8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80386D74;
    // 0x80386BF8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80386BFC: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
L_80386C00:
    // 0x80386C00: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386C04: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386C08: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386C0C: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386C10: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80386C14: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80386C18: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386C1C: jal         0x80363CE0
    // 0x80386C20: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80386C20: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_0:
    // 0x80386C24: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386C28: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386C2C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80386C30:
    // 0x80386C30: lh          $t2, 0x2D0($v1)
    ctx->r10 = MEM_H(ctx->r3, 0X2D0);
    // 0x80386C34: slti        $at, $t2, 0x32
    ctx->r1 = SIGNED(ctx->r10) < 0X32 ? 1 : 0;
    // 0x80386C38: beql        $at, $zero, L_80386C9C
    if (ctx->r1 == 0) {
        // 0x80386C3C: lw          $t1, 0x2C4($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X2C4);
            goto L_80386C9C;
    }
    goto skip_2;
    // 0x80386C3C: lw          $t1, 0x2C4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C4);
    skip_2:
    // 0x80386C40: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386C44: bgtzl       $t3, L_80386C9C
    if (SIGNED(ctx->r11) > 0) {
        // 0x80386C48: lw          $t1, 0x2C4($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X2C4);
            goto L_80386C9C;
    }
    goto skip_3;
    // 0x80386C48: lw          $t1, 0x2C4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C4);
    skip_3:
    // 0x80386C4C: lw          $t4, 0x2B8($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2B8);
    // 0x80386C50: slti        $at, $t4, 0x2
    ctx->r1 = SIGNED(ctx->r12) < 0X2 ? 1 : 0;
    // 0x80386C54: bnel        $at, $zero, L_80386C9C
    if (ctx->r1 != 0) {
        // 0x80386C58: lw          $t1, 0x2C4($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X2C4);
            goto L_80386C9C;
    }
    goto skip_4;
    // 0x80386C58: lw          $t1, 0x2C4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C4);
    skip_4:
    // 0x80386C5C: lbu         $t5, 0x2B4($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80386C60: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386C64: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80386C68: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80386C6C: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80386C70: sb          $t7, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r15;
    // 0x80386C74: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80386C78: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
    // 0x80386C7C: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x80386C80: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386C84: jal         0x80363EDC
    // 0x80386C88: lw          $a2, 0x2CC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80386C88: lw          $a2, 0x2CC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X2CC);
    after_1:
    // 0x80386C8C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386C90: b           L_80386CF0
    // 0x80386C94: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
        goto L_80386CF0;
    // 0x80386C94: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386C98: lw          $t1, 0x2C4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C4);
L_80386C9C:
    // 0x80386C9C: bgtzl       $t1, L_80386CF4
    if (SIGNED(ctx->r9) > 0) {
        // 0x80386CA0: lw          $v1, 0x0($t0)
        ctx->r3 = MEM_W(ctx->r8, 0X0);
            goto L_80386CF4;
    }
    goto skip_5;
    // 0x80386CA0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    skip_5:
    // 0x80386CA4: jal         0x80383830
    // 0x80386CA8: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    target_within_current_fov(rdram, ctx);
        goto after_2;
    // 0x80386CA8: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
    after_2:
    // 0x80386CAC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386CB0: beq         $v0, $zero, L_80386CF0
    if (ctx->r2 == 0) {
        // 0x80386CB4: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80386CF0;
    }
    // 0x80386CB4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386CB8: jal         0x80368D18
    // 0x80386CBC: nop

    polar_bear_jump_thump(rdram, ctx);
        goto after_3;
    // 0x80386CBC: nop

    after_3:
    // 0x80386CC0: jal         0x80140D20
    // 0x80386CC4: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x80386CC4: nop

    after_4:
    // 0x80386CC8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386CCC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386CD0: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80386CD4: andi        $t2, $v0, 0x3C
    ctx->r10 = ctx->r2 & 0X3C;
    // 0x80386CD8: addiu       $t3, $t2, 0x19
    ctx->r11 = ADD32(ctx->r10, 0X19);
    // 0x80386CDC: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    // 0x80386CE0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386CE4: lw          $t5, 0x2B8($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2B8);
    // 0x80386CE8: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x80386CEC: sw          $t6, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r14;
L_80386CF0:
    // 0x80386CF0: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80386CF4:
    // 0x80386CF4: lw          $a0, 0x2C0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386CF8: blez        $a0, L_80386D70
    if (SIGNED(ctx->r4) <= 0) {
        // 0x80386CFC: addiu       $t7, $a0, -0x1
        ctx->r15 = ADD32(ctx->r4, -0X1);
            goto L_80386D70;
    }
    // 0x80386CFC: addiu       $t7, $a0, -0x1
    ctx->r15 = ADD32(ctx->r4, -0X1);
    // 0x80386D00: b           L_80386D70
    // 0x80386D04: sw          $t7, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r15;
        goto L_80386D70;
    // 0x80386D04: sw          $t7, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r15;
    // 0x80386D08: lh          $t8, 0x2D0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2D0);
L_80386D0C:
    // 0x80386D0C: slti        $at, $t8, 0xAB
    ctx->r1 = SIGNED(ctx->r24) < 0XAB ? 1 : 0;
    // 0x80386D10: beql        $at, $zero, L_80386D34
    if (ctx->r1 == 0) {
        // 0x80386D14: lbu         $t1, 0x2B4($v1)
        ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
            goto L_80386D34;
    }
    goto skip_6;
    // 0x80386D14: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
    skip_6:
    // 0x80386D18: lw          $a0, 0x2C0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C0);
    // 0x80386D1C: slti        $v0, $a0, 0x3D
    ctx->r2 = SIGNED(ctx->r4) < 0X3D ? 1 : 0;
    // 0x80386D20: addiu       $t9, $a0, 0x1
    ctx->r25 = ADD32(ctx->r4, 0X1);
    // 0x80386D24: bne         $v0, $zero, L_80386D70
    if (ctx->r2 != 0) {
        // 0x80386D28: sw          $t9, 0x2C0($v1)
        MEM_W(0X2C0, ctx->r3) = ctx->r25;
            goto L_80386D70;
    }
    // 0x80386D28: sw          $t9, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r25;
    // 0x80386D2C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80386D30: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
L_80386D34:
    // 0x80386D34: addiu       $t5, $zero, 0x50
    ctx->r13 = ADD32(0, 0X50);
    // 0x80386D38: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386D3C: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80386D40: ori         $t3, $t2, 0x10
    ctx->r11 = ctx->r10 | 0X10;
    // 0x80386D44: sb          $t3, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r11;
    // 0x80386D48: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80386D4C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386D50: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386D54: sw          $zero, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = 0;
    // 0x80386D58: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80386D5C: sw          $t5, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = ctx->r13;
    // 0x80386D60: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x80386D64: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386D68: jal         0x80363CE0
    // 0x80386D6C: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x80386D6C: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_5:
L_80386D70:
    // 0x80386D70: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80386D74:
    // 0x80386D74: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80386D78: jr          $ra
    // 0x80386D7C: nop

    return;
    // 0x80386D7C: nop

;}
RECOMP_FUNC void perform_behavior_polar_tank(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80386D80: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80386D84: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80386D88: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386D8C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386D90: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80386D94: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386D98: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80386D9C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386DA0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386DA4: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80386DA8: beq         $t6, $zero, L_80386DD0
    if (ctx->r14 == 0) {
        // 0x80386DAC: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80386DD0;
    }
    // 0x80386DAC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386DB0: beq         $t6, $at, L_80386DFC
    if (ctx->r14 == ctx->r1) {
        // 0x80386DB4: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80386DFC;
    }
    // 0x80386DB4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80386DB8: beq         $t6, $at, L_80386E38
    if (ctx->r14 == ctx->r1) {
        // 0x80386DBC: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80386E38;
    }
    // 0x80386DBC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80386DC0: beql        $t6, $at, L_80386F04
    if (ctx->r14 == ctx->r1) {
        // 0x80386DC4: lw          $t5, 0x2C4($s0)
        ctx->r13 = MEM_W(ctx->r16, 0X2C4);
            goto L_80386F04;
    }
    goto skip_0;
    // 0x80386DC4: lw          $t5, 0x2C4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X2C4);
    skip_0:
    // 0x80386DC8: b           L_80386F74
    // 0x80386DCC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386F74;
    // 0x80386DCC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386DD0:
    // 0x80386DD0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386DD4: jal         0x80363CE0
    // 0x80386DD8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80386DD8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80386DDC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386DE0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386DE4: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386DE8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386DEC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386DF0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80386DF4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386DF8: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80386DFC:
    // 0x80386DFC: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80386E00: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386E04: slti        $at, $t0, 0x12D
    ctx->r1 = SIGNED(ctx->r8) < 0X12D ? 1 : 0;
    // 0x80386E08: beql        $at, $zero, L_80386F74
    if (ctx->r1 == 0) {
        // 0x80386E0C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386F74;
    }
    goto skip_1;
    // 0x80386E0C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80386E10: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386E14: jal         0x80363E88
    // 0x80386E18: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80386E18: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80386E1C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386E20: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386E24: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386E28: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80386E2C: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80386E30: b           L_80386F70
    // 0x80386E34: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_80386F70;
    // 0x80386E34: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
L_80386E38:
    // 0x80386E38: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80386E3C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386E40: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80386E44: slti        $at, $v0, 0x12D
    ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
    // 0x80386E48: bne         $at, $zero, L_80386E78
    if (ctx->r1 != 0) {
        // 0x80386E4C: addiu       $a3, $zero, 0xA
        ctx->r7 = ADD32(0, 0XA);
            goto L_80386E78;
    }
    // 0x80386E4C: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80386E50: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386E54: jal         0x80363CE0
    // 0x80386E58: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80386E58: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80386E5C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386E60: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386E64: lbu         $t4, 0x2B4($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386E68: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80386E6C: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x80386E70: b           L_80386F70
    // 0x80386E74: sb          $t6, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r14;
        goto L_80386F70;
    // 0x80386E74: sb          $t6, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r14;
L_80386E78:
    // 0x80386E78: slti        $at, $v0, 0xC8
    ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
    // 0x80386E7C: beq         $at, $zero, L_80386EB0
    if (ctx->r1 == 0) {
        // 0x80386E80: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80386EB0;
    }
    // 0x80386E80: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386E84: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386E88: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80386E8C: jal         0x80363EDC
    // 0x80386E90: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80386E90: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80386E94: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386E98: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386E9C: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386EA0: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386EA4: ori         $t9, $t8, 0x30
    ctx->r25 = ctx->r24 | 0X30;
    // 0x80386EA8: b           L_80386F70
    // 0x80386EAC: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
        goto L_80386F70;
    // 0x80386EAC: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
L_80386EB0:
    // 0x80386EB0: lw          $t0, 0x2C4($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C4);
    // 0x80386EB4: bgtzl       $t0, L_80386F74
    if (SIGNED(ctx->r8) > 0) {
        // 0x80386EB8: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386F74;
    }
    goto skip_2;
    // 0x80386EB8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x80386EBC: jal         0x80383830
    // 0x80386EC0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80386EC0: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80386EC4: beql        $v0, $zero, L_80386F74
    if (ctx->r2 == 0) {
        // 0x80386EC8: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386F74;
    }
    goto skip_3;
    // 0x80386EC8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80386ECC: jal         0x80140D20
    // 0x80386ED0: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x80386ED0: nop

    after_5:
    // 0x80386ED4: sra         $t1, $v0, 8
    ctx->r9 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80386ED8: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80386EDC: div         $zero, $t1, $at
    lo = S32(S64(S32(ctx->r9)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r9)) % S64(S32(ctx->r1)));
    // 0x80386EE0: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80386EE4: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80386EE8: mfhi        $t2
    ctx->r10 = hi;
    // 0x80386EEC: addiu       $t3, $t2, 0x14
    ctx->r11 = ADD32(ctx->r10, 0X14);
    // 0x80386EF0: jal         0x80368CF0
    // 0x80386EF4: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    polar_tank_fire_cannon(rdram, ctx);
        goto after_6;
    // 0x80386EF4: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    after_6:
    // 0x80386EF8: b           L_80386F74
    // 0x80386EFC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80386F74;
    // 0x80386EFC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80386F00: lw          $t5, 0x2C4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X2C4);
L_80386F04:
    // 0x80386F04: bgtzl       $t5, L_80386F3C
    if (SIGNED(ctx->r13) > 0) {
        // 0x80386F08: lh          $t9, 0x2D0($s0)
        ctx->r25 = MEM_H(ctx->r16, 0X2D0);
            goto L_80386F3C;
    }
    goto skip_4;
    // 0x80386F08: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
    skip_4:
    // 0x80386F0C: jal         0x80368C50
    // 0x80386F10: nop

    polar_tank_drop_mine(rdram, ctx);
        goto after_7;
    // 0x80386F10: nop

    after_7:
    // 0x80386F14: jal         0x80140D20
    // 0x80386F18: nop

    guRandom(rdram, ctx);
        goto after_8;
    // 0x80386F18: nop

    after_8:
    // 0x80386F1C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80386F20: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80386F24: andi        $t6, $v0, 0xF
    ctx->r14 = ctx->r2 & 0XF;
    // 0x80386F28: addiu       $t7, $t6, 0x46
    ctx->r15 = ADD32(ctx->r14, 0X46);
    // 0x80386F2C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386F30: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
    // 0x80386F34: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386F38: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
L_80386F3C:
    // 0x80386F3C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386F40: slti        $at, $t9, 0xFB
    ctx->r1 = SIGNED(ctx->r25) < 0XFB ? 1 : 0;
    // 0x80386F44: bnel        $at, $zero, L_80386F74
    if (ctx->r1 != 0) {
        // 0x80386F48: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80386F74;
    }
    goto skip_5;
    // 0x80386F48: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80386F4C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386F50: jal         0x80363E88
    // 0x80386F54: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_9;
    // 0x80386F54: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_9:
    // 0x80386F58: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80386F5C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80386F60: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80386F64: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80386F68: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x80386F6C: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
L_80386F70:
    // 0x80386F70: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80386F74:
    // 0x80386F74: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80386F78: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80386F7C: jr          $ra
    // 0x80386F80: nop

    return;
    // 0x80386F80: nop

;}
RECOMP_FUNC void perform_behavior_husky(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80386F84: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386F88: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386F8C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80386F90: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80386F94: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80386F98: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x80386F9C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386FA0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80386FA4: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80386FA8: beq         $t6, $zero, L_80386FD8
    if (ctx->r14 == 0) {
        // 0x80386FAC: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80386FD8;
    }
    // 0x80386FAC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80386FB0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80386FB4: beq         $t6, $at, L_80387004
    if (ctx->r14 == ctx->r1) {
        // 0x80386FB8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80387004;
    }
    // 0x80386FB8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80386FBC: beq         $t6, $at, L_80387064
    if (ctx->r14 == ctx->r1) {
        // 0x80386FC0: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80387064;
    }
    // 0x80386FC0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80386FC4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80386FC8: beql        $t6, $at, L_803870A0
    if (ctx->r14 == ctx->r1) {
        // 0x80386FCC: lw          $t3, 0x2C4($v0)
        ctx->r11 = MEM_W(ctx->r2, 0X2C4);
            goto L_803870A0;
    }
    goto skip_0;
    // 0x80386FCC: lw          $t3, 0x2C4($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X2C4);
    skip_0:
    // 0x80386FD0: b           L_80387100
    // 0x80386FD4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80387100;
    // 0x80386FD4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80386FD8:
    // 0x80386FD8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80386FDC: jal         0x80363CE0
    // 0x80386FE0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80386FE0: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80386FE4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80386FE8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80386FEC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80386FF0: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80386FF4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80386FF8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80386FFC: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80387000: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80387004:
    // 0x80387004: lw          $t1, 0x2C4($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X2C4);
    // 0x80387008: bnel        $t1, $zero, L_80387100
    if (ctx->r9 != 0) {
        // 0x8038700C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80387100;
    }
    goto skip_1;
    // 0x8038700C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80387010: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387014: slti        $at, $t2, 0x53
    ctx->r1 = SIGNED(ctx->r10) < 0X53 ? 1 : 0;
    // 0x80387018: beql        $at, $zero, L_80387100
    if (ctx->r1 == 0) {
        // 0x8038701C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80387100;
    }
    goto skip_2;
    // 0x8038701C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x80387020: jal         0x80383830
    // 0x80387024: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_1;
    // 0x80387024: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_1:
    // 0x80387028: beql        $v0, $zero, L_80387100
    if (ctx->r2 == 0) {
        // 0x8038702C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80387100;
    }
    goto skip_3;
    // 0x8038702C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_3:
    // 0x80387030: jal         0x8036C014
    // 0x80387034: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    func_8036C014_77D6C4(rdram, ctx);
        goto after_2;
    // 0x80387034: addiu       $a0, $zero, 0x1E
    ctx->r4 = ADD32(0, 0X1E);
    after_2:
    // 0x80387038: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038703C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80387040: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80387044: addiu       $t3, $zero, 0x3C
    ctx->r11 = ADD32(0, 0X3C);
    // 0x80387048: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    // 0x8038704C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387050: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80387054: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80387058: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x8038705C: b           L_803870FC
    // 0x80387060: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
        goto L_803870FC;
    // 0x80387060: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
L_80387064:
    // 0x80387064: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387068: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038706C: jal         0x80363EDC
    // 0x80387070: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80387070: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_3:
    // 0x80387074: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80387078: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038707C: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x80387080: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
    // 0x80387084: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387088: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8038708C: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x80387090: ori         $t2, $t1, 0x30
    ctx->r10 = ctx->r9 | 0X30;
    // 0x80387094: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80387098: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8038709C: lw          $t3, 0x2C4($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X2C4);
L_803870A0:
    // 0x803870A0: bnel        $t3, $zero, L_80387100
    if (ctx->r11 != 0) {
        // 0x803870A4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80387100;
    }
    goto skip_4;
    // 0x803870A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_4:
    // 0x803870A8: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
    // 0x803870AC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803870B0: slti        $at, $t4, 0xC8
    ctx->r1 = SIGNED(ctx->r12) < 0XC8 ? 1 : 0;
    // 0x803870B4: beql        $at, $zero, L_803870D8
    if (ctx->r1 == 0) {
        // 0x803870B8: lbu         $t6, 0x2B4($v0)
        ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
            goto L_803870D8;
    }
    goto skip_5;
    // 0x803870B8: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    skip_5:
    // 0x803870BC: lw          $a0, 0x2C0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C0);
    // 0x803870C0: slti        $v1, $a0, 0x1E
    ctx->r3 = SIGNED(ctx->r4) < 0X1E ? 1 : 0;
    // 0x803870C4: addiu       $t5, $a0, 0x1
    ctx->r13 = ADD32(ctx->r4, 0X1);
    // 0x803870C8: bne         $v1, $zero, L_803870FC
    if (ctx->r3 != 0) {
        // 0x803870CC: sw          $t5, 0x2C0($v0)
        MEM_W(0X2C0, ctx->r2) = ctx->r13;
            goto L_803870FC;
    }
    // 0x803870CC: sw          $t5, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r13;
    // 0x803870D0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803870D4: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
L_803870D8:
    // 0x803870D8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803870DC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803870E0: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x803870E4: ori         $t8, $t7, 0x10
    ctx->r24 = ctx->r15 | 0X10;
    // 0x803870E8: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    // 0x803870EC: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x803870F0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803870F4: jal         0x80363CE0
    // 0x803870F8: lw          $a1, 0x2CC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_4;
    // 0x803870F8: lw          $a1, 0x2CC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0X2CC);
    after_4:
L_803870FC:
    // 0x803870FC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80387100:
    // 0x80387100: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80387104: jr          $ra
    // 0x80387108: nop

    return;
    // 0x80387108: nop

;}
RECOMP_FUNC void perform_behavior_crazy_husky(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038710C: jr          $ra
    // 0x80387110: nop

    return;
    // 0x80387110: nop

;}
RECOMP_FUNC void perform_behavior_ski_husky(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80387114: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80387118: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038711C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387120: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387124: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80387128: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038712C: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80387130: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387134: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80387138: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x8038713C: beq         $t6, $zero, L_80387164
    if (ctx->r14 == 0) {
        // 0x80387140: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80387164;
    }
    // 0x80387140: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387144: beq         $t6, $at, L_80387190
    if (ctx->r14 == ctx->r1) {
        // 0x80387148: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80387190;
    }
    // 0x80387148: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038714C: beq         $t6, $at, L_803871CC
    if (ctx->r14 == ctx->r1) {
        // 0x80387150: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_803871CC;
    }
    // 0x80387150: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80387154: beql        $t6, $at, L_803872CC
    if (ctx->r14 == ctx->r1) {
        // 0x80387158: lh          $t7, 0x2D0($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X2D0);
            goto L_803872CC;
    }
    goto skip_0;
    // 0x80387158: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x8038715C: b           L_80387320
    // 0x80387160: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387320;
    // 0x80387160: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387164:
    // 0x80387164: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387168: jal         0x80363CE0
    // 0x8038716C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x8038716C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80387170: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387174: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387178: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x8038717C: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387180: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80387184: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80387188: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038718C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80387190:
    // 0x80387190: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80387194: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387198: slti        $at, $t0, 0x191
    ctx->r1 = SIGNED(ctx->r8) < 0X191 ? 1 : 0;
    // 0x8038719C: beql        $at, $zero, L_80387320
    if (ctx->r1 == 0) {
        // 0x803871A0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387320;
    }
    goto skip_1;
    // 0x803871A0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803871A4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803871A8: jal         0x80363E88
    // 0x803871AC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x803871AC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x803871B0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803871B4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x803871B8: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803871BC: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803871C0: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x803871C4: b           L_8038731C
    // 0x803871C8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_8038731C;
    // 0x803871C8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
L_803871CC:
    // 0x803871CC: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x803871D0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803871D4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803871D8: blez        $v1, L_803871EC
    if (SIGNED(ctx->r3) <= 0) {
        // 0x803871DC: addiu       $t4, $v1, -0x1
        ctx->r12 = ADD32(ctx->r3, -0X1);
            goto L_803871EC;
    }
    // 0x803871DC: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x803871E0: sw          $t4, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r12;
    // 0x803871E4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803871E8: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_803871EC:
    // 0x803871EC: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x803871F0: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x803871F4: slti        $at, $v0, 0x1B9
    ctx->r1 = SIGNED(ctx->r2) < 0X1B9 ? 1 : 0;
    // 0x803871F8: bnel        $at, $zero, L_8038722C
    if (ctx->r1 != 0) {
        // 0x803871FC: slti        $at, $v0, 0xFA
        ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
            goto L_8038722C;
    }
    goto skip_2;
    // 0x803871FC: slti        $at, $v0, 0xFA
    ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
    skip_2:
    // 0x80387200: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387204: jal         0x80363CE0
    // 0x80387208: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80387208: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x8038720C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387210: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387214: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387218: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8038721C: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x80387220: b           L_8038731C
    // 0x80387224: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
        goto L_8038731C;
    // 0x80387224: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x80387228: slti        $at, $v0, 0xFA
    ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
L_8038722C:
    // 0x8038722C: beql        $at, $zero, L_80387274
    if (ctx->r1 == 0) {
        // 0x80387230: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80387274;
    }
    goto skip_3;
    // 0x80387230: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80387234: lw          $t8, 0x2C0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387238: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038723C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80387240: bgtzl       $t8, L_80387274
    if (SIGNED(ctx->r24) > 0) {
        // 0x80387244: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80387274;
    }
    goto skip_4;
    // 0x80387244: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80387248: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038724C: jal         0x80363EDC
    // 0x80387250: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80387250: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80387254: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387258: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x8038725C: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387260: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80387264: ori         $t1, $t0, 0x30
    ctx->r9 = ctx->r8 | 0X30;
    // 0x80387268: b           L_8038731C
    // 0x8038726C: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
        goto L_8038731C;
    // 0x8038726C: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
    // 0x80387270: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
L_80387274:
    // 0x80387274: bgtzl       $t2, L_80387320
    if (SIGNED(ctx->r10) > 0) {
        // 0x80387278: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387320;
    }
    goto skip_5;
    // 0x80387278: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x8038727C: jal         0x80383830
    // 0x80387280: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80387280: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_4:
    // 0x80387284: beql        $v0, $zero, L_80387320
    if (ctx->r2 == 0) {
        // 0x80387288: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387320;
    }
    goto skip_6;
    // 0x80387288: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x8038728C: jal         0x80140D20
    // 0x80387290: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x80387290: nop

    after_5:
    // 0x80387294: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80387298: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038729C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803872A0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803872A4: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x803872A8: mfhi        $t3
    ctx->r11 = hi;
    // 0x803872AC: addiu       $t4, $t3, 0x14
    ctx->r12 = ADD32(ctx->r11, 0X14);
    // 0x803872B0: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x803872B4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803872B8: jal         0x8036BEA4
    // 0x803872BC: lw          $a0, 0x2CC($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X2CC);
    ski_husky_fire_missile(rdram, ctx);
        goto after_6;
    // 0x803872BC: lw          $a0, 0x2CC($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X2CC);
    after_6:
    // 0x803872C0: b           L_80387320
    // 0x803872C4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387320;
    // 0x803872C4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x803872C8: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
L_803872CC:
    // 0x803872CC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803872D0: slti        $at, $t7, 0x15F
    ctx->r1 = SIGNED(ctx->r15) < 0X15F ? 1 : 0;
    // 0x803872D4: beq         $at, $zero, L_803872F8
    if (ctx->r1 == 0) {
        // 0x803872D8: nop
    
            goto L_803872F8;
    }
    // 0x803872D8: nop

    // 0x803872DC: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x803872E0: slti        $v0, $v1, 0x47
    ctx->r2 = SIGNED(ctx->r3) < 0X47 ? 1 : 0;
    // 0x803872E4: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x803872E8: bne         $v0, $zero, L_8038731C
    if (ctx->r2 != 0) {
        // 0x803872EC: sw          $t8, 0x2C0($s0)
        MEM_W(0X2C0, ctx->r16) = ctx->r24;
            goto L_8038731C;
    }
    // 0x803872EC: sw          $t8, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r24;
    // 0x803872F0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803872F4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_803872F8:
    // 0x803872F8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803872FC: jal         0x80363E88
    // 0x80387300: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80387300: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80387304: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387308: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x8038730C: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387310: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80387314: ori         $t1, $t0, 0x20
    ctx->r9 = ctx->r8 | 0X20;
    // 0x80387318: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
L_8038731C:
    // 0x8038731C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387320:
    // 0x80387320: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80387324: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80387328: jr          $ra
    // 0x8038732C: nop

    return;
    // 0x8038732C: nop

;}
RECOMP_FUNC void perform_behavior_walrus(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80387330: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80387334: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80387338: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038733C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387340: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80387344: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80387348: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x8038734C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387350: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80387354: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80387358: beq         $t6, $zero, L_80387380
    if (ctx->r14 == 0) {
        // 0x8038735C: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80387380;
    }
    // 0x8038735C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387360: beq         $t6, $at, L_803873AC
    if (ctx->r14 == ctx->r1) {
        // 0x80387364: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803873AC;
    }
    // 0x80387364: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80387368: beq         $t6, $at, L_803873E8
    if (ctx->r14 == ctx->r1) {
        // 0x8038736C: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_803873E8;
    }
    // 0x8038736C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80387370: beql        $t6, $at, L_803874E8
    if (ctx->r14 == ctx->r1) {
        // 0x80387374: lh          $t7, 0x2D0($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X2D0);
            goto L_803874E8;
    }
    goto skip_0;
    // 0x80387374: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80387378: b           L_8038753C
    // 0x8038737C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038753C;
    // 0x8038737C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387380:
    // 0x80387380: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387384: jal         0x80363CE0
    // 0x80387388: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80387388: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x8038738C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387390: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387394: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387398: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x8038739C: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803873A0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x803873A4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803873A8: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_803873AC:
    // 0x803873AC: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x803873B0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803873B4: slti        $at, $t0, 0x191
    ctx->r1 = SIGNED(ctx->r8) < 0X191 ? 1 : 0;
    // 0x803873B8: beql        $at, $zero, L_8038753C
    if (ctx->r1 == 0) {
        // 0x803873BC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038753C;
    }
    goto skip_1;
    // 0x803873BC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803873C0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803873C4: jal         0x80363E88
    // 0x803873C8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x803873C8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x803873CC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803873D0: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x803873D4: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803873D8: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803873DC: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x803873E0: b           L_80387538
    // 0x803873E4: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_80387538;
    // 0x803873E4: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
L_803873E8:
    // 0x803873E8: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x803873EC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803873F0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803873F4: blez        $v1, L_80387408
    if (SIGNED(ctx->r3) <= 0) {
        // 0x803873F8: addiu       $t4, $v1, -0x1
        ctx->r12 = ADD32(ctx->r3, -0X1);
            goto L_80387408;
    }
    // 0x803873F8: addiu       $t4, $v1, -0x1
    ctx->r12 = ADD32(ctx->r3, -0X1);
    // 0x803873FC: sw          $t4, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r12;
    // 0x80387400: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387404: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80387408:
    // 0x80387408: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x8038740C: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80387410: slti        $at, $v0, 0x1B9
    ctx->r1 = SIGNED(ctx->r2) < 0X1B9 ? 1 : 0;
    // 0x80387414: bnel        $at, $zero, L_80387448
    if (ctx->r1 != 0) {
        // 0x80387418: slti        $at, $v0, 0xFA
        ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
            goto L_80387448;
    }
    goto skip_2;
    // 0x80387418: slti        $at, $v0, 0xFA
    ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
    skip_2:
    // 0x8038741C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387420: jal         0x80363CE0
    // 0x80387424: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80387424: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80387428: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038742C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387430: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387434: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80387438: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x8038743C: b           L_80387538
    // 0x80387440: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
        goto L_80387538;
    // 0x80387440: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x80387444: slti        $at, $v0, 0xFA
    ctx->r1 = SIGNED(ctx->r2) < 0XFA ? 1 : 0;
L_80387448:
    // 0x80387448: beql        $at, $zero, L_80387490
    if (ctx->r1 == 0) {
        // 0x8038744C: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80387490;
    }
    goto skip_3;
    // 0x8038744C: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80387450: lw          $t8, 0x2C0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387454: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387458: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8038745C: bgtzl       $t8, L_80387490
    if (SIGNED(ctx->r24) > 0) {
        // 0x80387460: lw          $t2, 0x2C4($s0)
        ctx->r10 = MEM_W(ctx->r16, 0X2C4);
            goto L_80387490;
    }
    goto skip_4;
    // 0x80387460: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80387464: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387468: jal         0x80363EDC
    // 0x8038746C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x8038746C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80387470: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387474: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387478: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x8038747C: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80387480: ori         $t1, $t0, 0x30
    ctx->r9 = ctx->r8 | 0X30;
    // 0x80387484: b           L_80387538
    // 0x80387488: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
        goto L_80387538;
    // 0x80387488: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
    // 0x8038748C: lw          $t2, 0x2C4($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C4);
L_80387490:
    // 0x80387490: bgtzl       $t2, L_8038753C
    if (SIGNED(ctx->r10) > 0) {
        // 0x80387494: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038753C;
    }
    goto skip_5;
    // 0x80387494: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80387498: jal         0x80383830
    // 0x8038749C: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x8038749C: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_4:
    // 0x803874A0: beql        $v0, $zero, L_8038753C
    if (ctx->r2 == 0) {
        // 0x803874A4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038753C;
    }
    goto skip_6;
    // 0x803874A4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x803874A8: jal         0x80140D20
    // 0x803874AC: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x803874AC: nop

    after_5:
    // 0x803874B0: addiu       $at, $zero, 0x1E
    ctx->r1 = ADD32(0, 0X1E);
    // 0x803874B4: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x803874B8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803874BC: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803874C0: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x803874C4: mfhi        $t3
    ctx->r11 = hi;
    // 0x803874C8: addiu       $t4, $t3, 0x1E
    ctx->r12 = ADD32(ctx->r11, 0X1E);
    // 0x803874CC: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x803874D0: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x803874D4: jal         0x80376B88
    // 0x803874D8: lw          $a0, 0x2CC($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X2CC);
    walrus_fire_missile(rdram, ctx);
        goto after_6;
    // 0x803874D8: lw          $a0, 0x2CC($t6)
    ctx->r4 = MEM_W(ctx->r14, 0X2CC);
    after_6:
    // 0x803874DC: b           L_8038753C
    // 0x803874E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038753C;
    // 0x803874E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x803874E4: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
L_803874E8:
    // 0x803874E8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803874EC: slti        $at, $t7, 0x15F
    ctx->r1 = SIGNED(ctx->r15) < 0X15F ? 1 : 0;
    // 0x803874F0: beq         $at, $zero, L_80387514
    if (ctx->r1 == 0) {
        // 0x803874F4: nop
    
            goto L_80387514;
    }
    // 0x803874F4: nop

    // 0x803874F8: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x803874FC: slti        $v0, $v1, 0x47
    ctx->r2 = SIGNED(ctx->r3) < 0X47 ? 1 : 0;
    // 0x80387500: addiu       $t8, $v1, 0x1
    ctx->r24 = ADD32(ctx->r3, 0X1);
    // 0x80387504: bne         $v0, $zero, L_80387538
    if (ctx->r2 != 0) {
        // 0x80387508: sw          $t8, 0x2C0($s0)
        MEM_W(0X2C0, ctx->r16) = ctx->r24;
            goto L_80387538;
    }
    // 0x80387508: sw          $t8, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r24;
    // 0x8038750C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387510: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80387514:
    // 0x80387514: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387518: jal         0x80363E88
    // 0x8038751C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x8038751C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80387520: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387524: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387528: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x8038752C: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80387530: ori         $t1, $t0, 0x20
    ctx->r9 = ctx->r8 | 0X20;
    // 0x80387534: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
L_80387538:
    // 0x80387538: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038753C:
    // 0x8038753C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80387540: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80387544: jr          $ra
    // 0x80387548: nop

    return;
    // 0x80387548: nop

;}
RECOMP_FUNC void perform_behavior_vulture2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038754C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80387550: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80387554: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387558: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8038755C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80387560: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80387564: lw          $t6, 0x2B4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B4);
    // 0x80387568: srl         $t7, $t6, 28
    ctx->r15 = S32(U32(ctx->r14) >> 28);
    // 0x8038756C: sltiu       $at, $t7, 0x5
    ctx->r1 = ctx->r15 < 0X5 ? 1 : 0;
    // 0x80387570: beq         $at, $zero, L_8038776C
    if (ctx->r1 == 0) {
        // 0x80387574: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_8038776C;
    }
    // 0x80387574: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80387578: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038757C: addu        $at, $at, $t7
    gpr jr_addend_80387584 = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80387580: lw          $t7, -0xBB8($at)
    ctx->r15 = ADD32(ctx->r1, -0XBB8);
    // 0x80387584: jr          $t7
    // 0x80387588: nop

    switch (jr_addend_80387584 >> 2) {
        case 0: goto L_8038758C; break;
        case 1: goto L_803875D8; break;
        case 2: goto L_8038761C; break;
        case 3: goto L_80387680; break;
        case 4: goto L_803876F4; break;
        default: switch_error(__func__, 0x80387584, 0x803BF448);
    }
    // 0x80387588: nop

L_8038758C:
    // 0x8038758C: lw          $s0, 0x2CC($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X2CC);
    // 0x80387590: addiu       $t9, $zero, -0x50
    ctx->r25 = ADD32(0, -0X50);
    // 0x80387594: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387598: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x8038759C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803875A0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803875A4: subu        $a2, $t9, $t8
    ctx->r6 = SUB32(ctx->r25, ctx->r24);
    // 0x803875A8: sll         $t1, $a2, 16
    ctx->r9 = S32(ctx->r6 << 16);
    // 0x803875AC: sra         $a2, $t1, 16
    ctx->r6 = S32(SIGNED(ctx->r9) >> 16);
    // 0x803875B0: jal         0x80363CE0
    // 0x803875B4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803875B4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_0:
    // 0x803875B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803875BC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803875C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803875C4: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803875C8: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x803875CC: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x803875D0: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x803875D4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803875D8:
    // 0x803875D8: lh          $t6, 0x2D0($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X2D0);
    // 0x803875DC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803875E0: slti        $at, $t6, 0x2
    ctx->r1 = SIGNED(ctx->r14) < 0X2 ? 1 : 0;
    // 0x803875E4: beql        $at, $zero, L_80387770
    if (ctx->r1 == 0) {
        // 0x803875E8: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387770;
    }
    goto skip_0;
    // 0x803875E8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x803875EC: jal         0x80363CC8
    // 0x803875F0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_1;
    // 0x803875F0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_1:
    // 0x803875F4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803875F8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803875FC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387600: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80387604: andi        $t9, $t7, 0xFF0F
    ctx->r25 = ctx->r15 & 0XFF0F;
    // 0x80387608: ori         $t8, $t9, 0x20
    ctx->r24 = ctx->r25 | 0X20;
    // 0x8038760C: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    // 0x80387610: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80387614: b           L_8038776C
    // 0x80387618: sw          $zero, 0x2B8($t1)
    MEM_W(0X2B8, ctx->r9) = 0;
        goto L_8038776C;
    // 0x80387618: sw          $zero, 0x2B8($t1)
    MEM_W(0X2B8, ctx->r9) = 0;
L_8038761C:
    // 0x8038761C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80387620: lw          $t2, 0x5530($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5530);
    // 0x80387624: lw          $s0, 0x2CC($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X2CC);
    // 0x80387628: lh          $t3, 0xC($t2)
    ctx->r11 = MEM_H(ctx->r10, 0XC);
    // 0x8038762C: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x80387630: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x80387634: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x80387638: subu        $t7, $t5, $t6
    ctx->r15 = SUB32(ctx->r13, ctx->r14);
    // 0x8038763C: slti        $at, $t7, 0xA
    ctx->r1 = SIGNED(ctx->r15) < 0XA ? 1 : 0;
    // 0x80387640: bnel        $at, $zero, L_80387664
    if (ctx->r1 != 0) {
        // 0x80387644: lbu         $t8, 0x2B4($v0)
        ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80387664;
    }
    goto skip_1;
    // 0x80387644: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
    skip_1:
    // 0x80387648: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x8038764C: slti        $a0, $v1, 0x3D
    ctx->r4 = SIGNED(ctx->r3) < 0X3D ? 1 : 0;
    // 0x80387650: addiu       $t9, $v1, 0x1
    ctx->r25 = ADD32(ctx->r3, 0X1);
    // 0x80387654: bne         $a0, $zero, L_8038776C
    if (ctx->r4 != 0) {
        // 0x80387658: sw          $t9, 0x2B8($v0)
        MEM_W(0X2B8, ctx->r2) = ctx->r25;
            goto L_8038776C;
    }
    // 0x80387658: sw          $t9, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r25;
    // 0x8038765C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387660: lbu         $t8, 0x2B4($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X2B4);
L_80387664:
    // 0x80387664: addiu       $t3, $zero, 0x10
    ctx->r11 = ADD32(0, 0X10);
    // 0x80387668: andi        $t1, $t8, 0xFF0F
    ctx->r9 = ctx->r24 & 0XFF0F;
    // 0x8038766C: ori         $t2, $t1, 0x30
    ctx->r10 = ctx->r9 | 0X30;
    // 0x80387670: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80387674: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x80387678: b           L_8038776C
    // 0x8038767C: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
        goto L_8038776C;
    // 0x8038767C: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
L_80387680:
    // 0x80387680: lw          $v1, 0x2C4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C4);
    // 0x80387684: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    // 0x80387688: bgtz        $v1, L_803876D4
    if (SIGNED(ctx->r3) > 0) {
        // 0x8038768C: nop
    
            goto L_803876D4;
    }
    // 0x8038768C: nop

    // 0x80387690: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80387694: addiu       $t1, $zero, -0x50
    ctx->r9 = ADD32(0, -0X50);
    // 0x80387698: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038769C: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x803876A0: ori         $t7, $t6, 0x40
    ctx->r15 = ctx->r14 | 0X40;
    // 0x803876A4: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x803876A8: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x803876AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803876B0: lw          $s0, 0x2CC($t9)
    ctx->r16 = MEM_W(ctx->r25, 0X2CC);
    // 0x803876B4: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x803876B8: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x803876BC: subu        $a1, $t1, $t8
    ctx->r5 = SUB32(ctx->r9, ctx->r24);
    // 0x803876C0: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x803876C4: jal         0x80363EDC
    // 0x803876C8: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    func_80363EDC_77558C(rdram, ctx);
        goto after_2;
    // 0x803876C8: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    after_2:
    // 0x803876CC: b           L_80387770
    // 0x803876D0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387770;
    // 0x803876D0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803876D4:
    // 0x803876D4: div         $zero, $v1, $at
    lo = S32(S64(S32(ctx->r3)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r3)) % S64(S32(ctx->r1)));
    // 0x803876D8: mfhi        $t4
    ctx->r12 = hi;
    // 0x803876DC: bnel        $t4, $zero, L_80387770
    if (ctx->r12 != 0) {
        // 0x803876E0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387770;
    }
    goto skip_2;
    // 0x803876E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x803876E4: jal         0x8036D5CC
    // 0x803876E8: nop

    func_8036D5CC_77EC7C(rdram, ctx);
        goto after_3;
    // 0x803876E8: nop

    after_3:
    // 0x803876EC: b           L_80387770
    // 0x803876F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387770;
    // 0x803876F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803876F4:
    // 0x803876F4: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
    // 0x803876F8: slti        $at, $t5, 0xC9
    ctx->r1 = SIGNED(ctx->r13) < 0XC9 ? 1 : 0;
    // 0x803876FC: beql        $at, $zero, L_80387728
    if (ctx->r1 == 0) {
        // 0x80387700: lbu         $t1, 0x2B4($v0)
        ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
            goto L_80387728;
    }
    goto skip_3;
    // 0x80387700: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    skip_3:
    // 0x80387704: lw          $t6, 0x2C0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2C0);
    // 0x80387708: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038770C: sw          $t7, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r15;
    // 0x80387710: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80387714: lw          $t9, 0x2C0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X2C0);
    // 0x80387718: slti        $at, $t9, 0x79
    ctx->r1 = SIGNED(ctx->r25) < 0X79 ? 1 : 0;
    // 0x8038771C: bnel        $at, $zero, L_80387770
    if (ctx->r1 != 0) {
        // 0x80387720: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387770;
    }
    goto skip_4;
    // 0x80387720: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80387724: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
L_80387728:
    // 0x80387728: addiu       $t6, $zero, -0x50
    ctx->r14 = ADD32(0, -0X50);
    // 0x8038772C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387730: andi        $t8, $t1, 0xFF0F
    ctx->r24 = ctx->r9 & 0XFF0F;
    // 0x80387734: ori         $t2, $t8, 0x10
    ctx->r10 = ctx->r24 | 0X10;
    // 0x80387738: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x8038773C: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x80387740: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387744: sw          $zero, 0x2C0($t3)
    MEM_W(0X2C0, ctx->r11) = 0;
    // 0x80387748: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8038774C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387750: lw          $s0, 0x2CC($t4)
    ctx->r16 = MEM_W(ctx->r12, 0X2CC);
    // 0x80387754: lhu         $t5, 0x42($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X42);
    // 0x80387758: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x8038775C: subu        $a2, $t6, $t5
    ctx->r6 = SUB32(ctx->r14, ctx->r13);
    // 0x80387760: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x80387764: jal         0x80363CE0
    // 0x80387768: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    set_nav_state_chase_target(rdram, ctx);
        goto after_4;
    // 0x80387768: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    after_4:
L_8038776C:
    // 0x8038776C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387770:
    // 0x80387770: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80387774: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80387778: jr          $ra
    // 0x8038777C: nop

    return;
    // 0x8038777C: nop

;}
RECOMP_FUNC void perform_behavior_camel(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80387780: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80387784: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80387788: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x8038778C: addiu       $s1, $s1, 0x552C
    ctx->r17 = ADD32(ctx->r17, 0X552C);
    // 0x80387790: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80387794: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80387798: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038779C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x803877A0: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x803877A4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803877A8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803877AC: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803877B0: beq         $t6, $zero, L_803877D0
    if (ctx->r14 == 0) {
        // 0x803877B4: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803877D0;
    }
    // 0x803877B4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803877B8: beq         $t6, $v1, L_803877F8
    if (ctx->r14 == ctx->r3) {
        // 0x803877BC: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803877F8;
    }
    // 0x803877BC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803877C0: beql        $t6, $at, L_80387928
    if (ctx->r14 == ctx->r1) {
        // 0x803877C4: lh          $t6, 0x2D0($s0)
        ctx->r14 = MEM_H(ctx->r16, 0X2D0);
            goto L_80387928;
    }
    goto skip_0;
    // 0x803877C4: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x803877C8: b           L_80387994
    // 0x803877CC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387994;
    // 0x803877CC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803877D0:
    // 0x803877D0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803877D4: jal         0x80363CE0
    // 0x803877D8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803877D8: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x803877DC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803877E0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x803877E4: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803877E8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803877EC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803877F0: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x803877F4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_803877F8:
    // 0x803877F8: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x803877FC: slti        $at, $v0, 0xE6
    ctx->r1 = SIGNED(ctx->r2) < 0XE6 ? 1 : 0;
    // 0x80387800: beql        $at, $zero, L_8038783C
    if (ctx->r1 == 0) {
        // 0x80387804: slti        $at, $v0, 0xFB
        ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
            goto L_8038783C;
    }
    goto skip_1;
    // 0x80387804: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
    skip_1:
    // 0x80387808: lw          $t0, 0x2C0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C0);
    // 0x8038780C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387810: beql        $v1, $t0, L_8038783C
    if (ctx->r3 == ctx->r8) {
        // 0x80387814: slti        $at, $v0, 0xFB
        ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
            goto L_8038783C;
    }
    goto skip_2;
    // 0x80387814: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
    skip_2:
    // 0x80387818: sw          $v1, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r3;
    // 0x8038781C: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x80387820: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387824: jal         0x80363E88
    // 0x80387828: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80387828: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_1:
    // 0x8038782C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80387830: b           L_80387874
    // 0x80387834: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_80387874;
    // 0x80387834: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80387838: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
L_8038783C:
    // 0x8038783C: bnel        $at, $zero, L_80387878
    if (ctx->r1 != 0) {
        // 0x80387840: lw          $v0, 0x2C4($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X2C4);
            goto L_80387878;
    }
    goto skip_3;
    // 0x80387840: lw          $v0, 0x2C4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80387844: lw          $t2, 0x2C0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387848: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038784C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387850: beq         $t2, $zero, L_80387874
    if (ctx->r10 == 0) {
        // 0x80387854: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80387874;
    }
    // 0x80387854: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387858: sw          $zero, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = 0;
    // 0x8038785C: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x80387860: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387864: jal         0x80363CE0
    // 0x80387868: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80387868: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_2:
    // 0x8038786C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80387870: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80387874:
    // 0x80387874: lw          $v0, 0x2C4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C4);
L_80387878:
    // 0x80387878: bne         $v1, $v0, L_803878E0
    if (ctx->r3 != ctx->r2) {
        // 0x8038787C: nop
    
            goto L_803878E0;
    }
    // 0x8038787C: nop

    // 0x80387880: lw          $t4, 0x2BC($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2BC);
    // 0x80387884: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x80387888: jal         0x80140D20
    // 0x8038788C: sw          $t5, 0x2BC($s0)
    MEM_W(0X2BC, ctx->r16) = ctx->r13;
    guRandom(rdram, ctx);
        goto after_3;
    // 0x8038788C: sw          $t5, 0x2BC($s0)
    MEM_W(0X2BC, ctx->r16) = ctx->r13;
    after_3:
    // 0x80387890: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80387894: andi        $t7, $v0, 0x1
    ctx->r15 = ctx->r2 & 0X1;
    // 0x80387898: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x8038789C: lw          $t6, 0x2BC($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X2BC);
    // 0x803878A0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803878A4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803878A8: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x803878AC: bnel        $at, $zero, L_80387994
    if (ctx->r1 != 0) {
        // 0x803878B0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387994;
    }
    goto skip_4;
    // 0x803878B0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x803878B4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803878B8: jal         0x80363EDC
    // 0x803878BC: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_4;
    // 0x803878BC: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_4:
    // 0x803878C0: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x803878C4: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
    // 0x803878C8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803878CC: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803878D0: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x803878D4: ori         $t2, $t1, 0x20
    ctx->r10 = ctx->r9 | 0X20;
    // 0x803878D8: b           L_80387990
    // 0x803878DC: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
        goto L_80387990;
    // 0x803878DC: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
L_803878E0:
    // 0x803878E0: bgtzl       $v0, L_80387994
    if (SIGNED(ctx->r2) > 0) {
        // 0x803878E4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387994;
    }
    goto skip_5;
    // 0x803878E4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803878E8: lh          $t3, 0x2D0($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X2D0);
    // 0x803878EC: slti        $at, $t3, 0xFB
    ctx->r1 = SIGNED(ctx->r11) < 0XFB ? 1 : 0;
    // 0x803878F0: beql        $at, $zero, L_80387994
    if (ctx->r1 == 0) {
        // 0x803878F4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387994;
    }
    goto skip_6;
    // 0x803878F4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x803878F8: jal         0x80383830
    // 0x803878FC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_5;
    // 0x803878FC: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_5:
    // 0x80387900: beql        $v0, $zero, L_80387994
    if (ctx->r2 == 0) {
        // 0x80387904: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387994;
    }
    goto skip_7;
    // 0x80387904: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80387908: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x8038790C: jal         0x8036F50C
    // 0x80387910: lw          $a0, 0x2CC($t4)
    ctx->r4 = MEM_W(ctx->r12, 0X2CC);
    camel_fire_water_cannon(rdram, ctx);
        goto after_6;
    // 0x80387910: lw          $a0, 0x2CC($t4)
    ctx->r4 = MEM_W(ctx->r12, 0X2CC);
    after_6:
    // 0x80387914: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x80387918: addiu       $t5, $zero, 0x14
    ctx->r13 = ADD32(0, 0X14);
    // 0x8038791C: b           L_80387990
    // 0x80387920: sw          $t5, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r13;
        goto L_80387990;
    // 0x80387920: sw          $t5, 0x2C4($t7)
    MEM_W(0X2C4, ctx->r15) = ctx->r13;
    // 0x80387924: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
L_80387928:
    // 0x80387928: slti        $at, $t6, 0x172
    ctx->r1 = SIGNED(ctx->r14) < 0X172 ? 1 : 0;
    // 0x8038792C: beql        $at, $zero, L_80387958
    if (ctx->r1 == 0) {
        // 0x80387930: lbu         $t1, 0x2B4($s0)
        ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
            goto L_80387958;
    }
    goto skip_8;
    // 0x80387930: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    skip_8:
    // 0x80387934: lw          $t8, 0x2C0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387938: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x8038793C: sw          $t9, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r25;
    // 0x80387940: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80387944: lw          $t0, 0x2C0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387948: slti        $at, $t0, 0x3C
    ctx->r1 = SIGNED(ctx->r8) < 0X3C ? 1 : 0;
    // 0x8038794C: bnel        $at, $zero, L_80387994
    if (ctx->r1 != 0) {
        // 0x80387950: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387994;
    }
    goto skip_9;
    // 0x80387950: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_9:
    // 0x80387954: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
L_80387958:
    // 0x80387958: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038795C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387960: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80387964: ori         $t3, $t2, 0x10
    ctx->r11 = ctx->r10 | 0X10;
    // 0x80387968: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
    // 0x8038796C: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x80387970: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387974: sw          $zero, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = 0;
    // 0x80387978: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x8038797C: sw          $zero, 0x2BC($t5)
    MEM_W(0X2BC, ctx->r13) = 0;
    // 0x80387980: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x80387984: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387988: jal         0x80363CE0
    // 0x8038798C: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_7;
    // 0x8038798C: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_7:
L_80387990:
    // 0x80387990: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387994:
    // 0x80387994: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80387998: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x8038799C: jr          $ra
    // 0x803879A0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x803879A0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void perform_behavior_cannon_camel(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803879A4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803879A8: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x803879AC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803879B0: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803879B4: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x803879B8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803879BC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803879C0: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x803879C4: beq         $t6, $zero, L_803879E0
    if (ctx->r14 == 0) {
        // 0x803879C8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803879E0;
    }
    // 0x803879C8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803879CC: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x803879D0: beql        $t6, $a2, L_80387A14
    if (ctx->r14 == ctx->r6) {
        // 0x803879D4: lw          $a0, 0x2C0($v0)
        ctx->r4 = MEM_W(ctx->r2, 0X2C0);
            goto L_80387A14;
    }
    goto skip_0;
    // 0x803879D4: lw          $a0, 0x2C0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C0);
    skip_0:
    // 0x803879D8: b           L_80387BE8
    // 0x803879DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80387BE8;
    // 0x803879DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803879E0:
    // 0x803879E0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803879E4: jal         0x80363CE0
    // 0x803879E8: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803879E8: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x803879EC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803879F0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x803879F4: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x803879F8: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803879FC: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387A00: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80387A04: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80387A08: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387A0C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80387A10: lw          $a0, 0x2C0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C0);
L_80387A14:
    // 0x80387A14: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80387A18: beq         $a0, $at, L_80387A60
    if (ctx->r4 == ctx->r1) {
        // 0x80387A1C: nop
    
            goto L_80387A60;
    }
    // 0x80387A1C: nop

    // 0x80387A20: lh          $t0, 0x2D0($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387A24: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80387A28: slti        $at, $t0, 0xFA
    ctx->r1 = SIGNED(ctx->r8) < 0XFA ? 1 : 0;
    // 0x80387A2C: beq         $at, $zero, L_80387A60
    if (ctx->r1 == 0) {
        // 0x80387A30: nop
    
            goto L_80387A60;
    }
    // 0x80387A30: nop

    // 0x80387A34: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387A38: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387A3C: jal         0x80363EDC
    // 0x80387A40: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80387A40: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_1:
    // 0x80387A44: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80387A48: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x80387A4C: addiu       $t1, $zero, 0x2
    ctx->r9 = ADD32(0, 0X2);
    // 0x80387A50: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387A54: sw          $t1, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = ctx->r9;
    // 0x80387A58: b           L_80387AE4
    // 0x80387A5C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_80387AE4;
    // 0x80387A5C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80387A60:
    // 0x80387A60: beq         $a2, $a0, L_80387AA4
    if (ctx->r6 == ctx->r4) {
        // 0x80387A64: nop
    
            goto L_80387AA4;
    }
    // 0x80387A64: nop

    // 0x80387A68: lh          $v1, 0x2D0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387A6C: slti        $at, $v1, 0x12C
    ctx->r1 = SIGNED(ctx->r3) < 0X12C ? 1 : 0;
    // 0x80387A70: beq         $at, $zero, L_80387AA4
    if (ctx->r1 == 0) {
        // 0x80387A74: slti        $at, $v1, 0xFB
        ctx->r1 = SIGNED(ctx->r3) < 0XFB ? 1 : 0;
            goto L_80387AA4;
    }
    // 0x80387A74: slti        $at, $v1, 0xFB
    ctx->r1 = SIGNED(ctx->r3) < 0XFB ? 1 : 0;
    // 0x80387A78: bne         $at, $zero, L_80387AA4
    if (ctx->r1 != 0) {
        // 0x80387A7C: lui         $t3, 0x803D
        ctx->r11 = S32(0X803D << 16);
            goto L_80387AA4;
    }
    // 0x80387A7C: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80387A80: sw          $a2, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r6;
    // 0x80387A84: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x80387A88: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387A8C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387A90: jal         0x80363E88
    // 0x80387A94: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80387A94: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_2:
    // 0x80387A98: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387A9C: b           L_80387AE4
    // 0x80387AA0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_80387AE4;
    // 0x80387AA0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80387AA4:
    // 0x80387AA4: beql        $a0, $zero, L_80387AE8
    if (ctx->r4 == 0) {
        // 0x80387AA8: lw          $t6, 0x2B8($v0)
        ctx->r14 = MEM_W(ctx->r2, 0X2B8);
            goto L_80387AE8;
    }
    goto skip_1;
    // 0x80387AA8: lw          $t6, 0x2B8($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B8);
    skip_1:
    // 0x80387AAC: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387AB0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387AB4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80387AB8: slti        $at, $t4, 0x15F
    ctx->r1 = SIGNED(ctx->r12) < 0X15F ? 1 : 0;
    // 0x80387ABC: bne         $at, $zero, L_80387AE4
    if (ctx->r1 != 0) {
        // 0x80387AC0: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_80387AE4;
    }
    // 0x80387AC0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387AC4: sw          $zero, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = 0;
    // 0x80387AC8: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80387ACC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387AD0: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387AD4: jal         0x80363CE0
    // 0x80387AD8: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x80387AD8: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_3:
    // 0x80387ADC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387AE0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80387AE4:
    // 0x80387AE4: lw          $t6, 0x2B8($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B8);
L_80387AE8:
    // 0x80387AE8: bgtzl       $t6, L_80387B70
    if (SIGNED(ctx->r14) > 0) {
        // 0x80387AEC: lw          $t0, 0x2C4($v0)
        ctx->r8 = MEM_W(ctx->r2, 0X2C4);
            goto L_80387B70;
    }
    goto skip_2;
    // 0x80387AEC: lw          $t0, 0x2C4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C4);
    skip_2:
    // 0x80387AF0: lh          $t7, 0x2D0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387AF4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80387AF8: slti        $at, $t7, 0x46
    ctx->r1 = SIGNED(ctx->r15) < 0X46 ? 1 : 0;
    // 0x80387AFC: beql        $at, $zero, L_80387B70
    if (ctx->r1 == 0) {
        // 0x80387B00: lw          $t0, 0x2C4($v0)
        ctx->r8 = MEM_W(ctx->r2, 0X2C4);
            goto L_80387B70;
    }
    goto skip_3;
    // 0x80387B00: lw          $t0, 0x2C4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C4);
    skip_3:
    // 0x80387B04: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    // 0x80387B08: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80387B0C: lh          $t8, 0x4($a2)
    ctx->r24 = MEM_H(ctx->r6, 0X4);
    // 0x80387B10: lh          $t2, 0x8($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X8);
    // 0x80387B14: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x80387B18: lh          $t3, 0x8($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X8);
    // 0x80387B1C: subu        $a0, $t8, $t9
    ctx->r4 = SUB32(ctx->r24, ctx->r25);
    // 0x80387B20: subu        $a1, $t2, $t3
    ctx->r5 = SUB32(ctx->r10, ctx->r11);
    // 0x80387B24: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x80387B28: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80387B2C: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80387B30: jal         0x801284B8
    // 0x80387B34: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    func_801284B8(rdram, ctx);
        goto after_4;
    // 0x80387B34: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    after_4:
    // 0x80387B38: sll         $a0, $v0, 8
    ctx->r4 = S32(ctx->r2 << 8);
    // 0x80387B3C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80387B40: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80387B44: mflo        $t6
    ctx->r14 = lo;
    // 0x80387B48: andi        $a0, $t6, 0xFFFF
    ctx->r4 = ctx->r14 & 0XFFFF;
    // 0x80387B4C: jal         0x8036F740
    // 0x80387B50: nop

    cannon_camel_dash(rdram, ctx);
        goto after_5;
    // 0x80387B50: nop

    after_5:
    // 0x80387B54: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80387B58: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80387B5C: addiu       $t8, $zero, 0x14A
    ctx->r24 = ADD32(0, 0X14A);
    // 0x80387B60: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387B64: sw          $t8, 0x2B8($t9)
    MEM_W(0X2B8, ctx->r25) = ctx->r24;
    // 0x80387B68: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80387B6C: lw          $t0, 0x2C4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X2C4);
L_80387B70:
    // 0x80387B70: addiu       $a1, $zero, 0x5
    ctx->r5 = ADD32(0, 0X5);
    // 0x80387B74: bgtz        $t0, L_80387BCC
    if (SIGNED(ctx->r8) > 0) {
        // 0x80387B78: nop
    
            goto L_80387BCC;
    }
    // 0x80387B78: nop

    // 0x80387B7C: jal         0x803838C8
    // 0x80387B80: lhu         $a0, 0x308($v0)
    ctx->r4 = MEM_HU(ctx->r2, 0X308);
    target_within_custom_fov(rdram, ctx);
        goto after_6;
    // 0x80387B80: lhu         $a0, 0x308($v0)
    ctx->r4 = MEM_HU(ctx->r2, 0X308);
    after_6:
    // 0x80387B84: beq         $v0, $zero, L_80387BCC
    if (ctx->r2 == 0) {
        // 0x80387B88: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_80387BCC;
    }
    // 0x80387B88: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387B8C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80387B90: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x80387B94: slti        $at, $t1, 0x17D
    ctx->r1 = SIGNED(ctx->r9) < 0X17D ? 1 : 0;
    // 0x80387B98: beq         $at, $zero, L_80387BCC
    if (ctx->r1 == 0) {
        // 0x80387B9C: nop
    
            goto L_80387BCC;
    }
    // 0x80387B9C: nop

    // 0x80387BA0: jal         0x8036F5F4
    // 0x80387BA4: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    cannon_camel_fire_cannon(rdram, ctx);
        goto after_7;
    // 0x80387BA4: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    after_7:
    // 0x80387BA8: jal         0x80140D20
    // 0x80387BAC: nop

    guRandom(rdram, ctx);
        goto after_8;
    // 0x80387BAC: nop

    after_8:
    // 0x80387BB0: addiu       $at, $zero, 0x24
    ctx->r1 = ADD32(0, 0X24);
    // 0x80387BB4: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80387BB8: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80387BBC: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80387BC0: mfhi        $t2
    ctx->r10 = hi;
    // 0x80387BC4: addiu       $t3, $t2, 0x19
    ctx->r11 = ADD32(ctx->r10, 0X19);
    // 0x80387BC8: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
L_80387BCC:
    // 0x80387BCC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80387BD0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80387BD4: lw          $v1, 0x2B8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B8);
    // 0x80387BD8: blez        $v1, L_80387BE4
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80387BDC: addiu       $t5, $v1, -0x1
        ctx->r13 = ADD32(ctx->r3, -0X1);
            goto L_80387BE4;
    }
    // 0x80387BDC: addiu       $t5, $v1, -0x1
    ctx->r13 = ADD32(ctx->r3, -0X1);
    // 0x80387BE0: sw          $t5, 0x2B8($v0)
    MEM_W(0X2B8, ctx->r2) = ctx->r13;
L_80387BE4:
    // 0x80387BE4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80387BE8:
    // 0x80387BE8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80387BEC: jr          $ra
    // 0x80387BF0: nop

    return;
    // 0x80387BF0: nop

;}
RECOMP_FUNC void perform_behavior_pogo_kangaroo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80387BF4: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80387BF8: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80387BFC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387C00: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387C04: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80387C08: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80387C0C: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80387C10: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387C14: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80387C18: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80387C1C: beq         $t6, $zero, L_80387C44
    if (ctx->r14 == 0) {
        // 0x80387C20: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80387C44;
    }
    // 0x80387C20: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387C24: beq         $t6, $at, L_80387C70
    if (ctx->r14 == ctx->r1) {
        // 0x80387C28: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80387C70;
    }
    // 0x80387C28: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80387C2C: beq         $t6, $at, L_80387CAC
    if (ctx->r14 == ctx->r1) {
        // 0x80387C30: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80387CAC;
    }
    // 0x80387C30: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80387C34: beql        $t6, $at, L_80387D74
    if (ctx->r14 == ctx->r1) {
        // 0x80387C38: lh          $t4, 0x2D0($s0)
        ctx->r12 = MEM_H(ctx->r16, 0X2D0);
            goto L_80387D74;
    }
    goto skip_0;
    // 0x80387C38: lh          $t4, 0x2D0($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80387C3C: b           L_80387DD0
    // 0x80387C40: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80387DD0;
    // 0x80387C40: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387C44:
    // 0x80387C44: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387C48: jal         0x80363CE0
    // 0x80387C4C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80387C4C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80387C50: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387C54: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387C58: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387C5C: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387C60: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80387C64: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80387C68: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387C6C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80387C70:
    // 0x80387C70: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80387C74: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387C78: slti        $at, $t0, 0x12D
    ctx->r1 = SIGNED(ctx->r8) < 0X12D ? 1 : 0;
    // 0x80387C7C: beql        $at, $zero, L_80387DD0
    if (ctx->r1 == 0) {
        // 0x80387C80: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387DD0;
    }
    goto skip_1;
    // 0x80387C80: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80387C84: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387C88: jal         0x80363E88
    // 0x80387C8C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80387C8C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80387C90: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387C94: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387C98: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387C9C: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80387CA0: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80387CA4: b           L_80387DCC
    // 0x80387CA8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
        goto L_80387DCC;
    // 0x80387CA8: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
L_80387CAC:
    // 0x80387CAC: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80387CB0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387CB4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387CB8: slti        $at, $v0, 0x15F
    ctx->r1 = SIGNED(ctx->r2) < 0X15F ? 1 : 0;
    // 0x80387CBC: bne         $at, $zero, L_80387CEC
    if (ctx->r1 != 0) {
        // 0x80387CC0: addiu       $a3, $zero, 0xA
        ctx->r7 = ADD32(0, 0XA);
            goto L_80387CEC;
    }
    // 0x80387CC0: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80387CC4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387CC8: jal         0x80363CE0
    // 0x80387CCC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80387CCC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80387CD0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387CD4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387CD8: lbu         $t4, 0x2B4($s0)
    ctx->r12 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387CDC: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80387CE0: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x80387CE4: b           L_80387DCC
    // 0x80387CE8: sb          $t6, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r14;
        goto L_80387DCC;
    // 0x80387CE8: sb          $t6, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r14;
L_80387CEC:
    // 0x80387CEC: slti        $at, $v0, 0x96
    ctx->r1 = SIGNED(ctx->r2) < 0X96 ? 1 : 0;
    // 0x80387CF0: beq         $at, $zero, L_80387D24
    if (ctx->r1 == 0) {
        // 0x80387CF4: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80387D24;
    }
    // 0x80387CF4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387CF8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387CFC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80387D00: jal         0x80363EDC
    // 0x80387D04: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80387D04: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80387D08: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387D0C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387D10: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387D14: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387D18: ori         $t9, $t8, 0x30
    ctx->r25 = ctx->r24 | 0X30;
    // 0x80387D1C: b           L_80387DCC
    // 0x80387D20: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
        goto L_80387DCC;
    // 0x80387D20: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
L_80387D24:
    // 0x80387D24: lw          $t0, 0x2C4($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C4);
    // 0x80387D28: bgtzl       $t0, L_80387DD0
    if (SIGNED(ctx->r8) > 0) {
        // 0x80387D2C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387DD0;
    }
    goto skip_2;
    // 0x80387D2C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x80387D30: jal         0x80383830
    // 0x80387D34: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80387D34: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80387D38: beql        $v0, $zero, L_80387DD0
    if (ctx->r2 == 0) {
        // 0x80387D3C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387DD0;
    }
    goto skip_3;
    // 0x80387D3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80387D40: jal         0x80372698
    // 0x80387D44: nop

    func_80372698_783D48(rdram, ctx);
        goto after_5;
    // 0x80387D44: nop

    after_5:
    // 0x80387D48: jal         0x80140D20
    // 0x80387D4C: nop

    guRandom(rdram, ctx);
        goto after_6;
    // 0x80387D4C: nop

    after_6:
    // 0x80387D50: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80387D54: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80387D58: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80387D5C: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x80387D60: mfhi        $t1
    ctx->r9 = hi;
    // 0x80387D64: addiu       $t2, $t1, 0x5A
    ctx->r10 = ADD32(ctx->r9, 0X5A);
    // 0x80387D68: b           L_80387DCC
    // 0x80387D6C: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
        goto L_80387DCC;
    // 0x80387D6C: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
    // 0x80387D70: lh          $t4, 0x2D0($s0)
    ctx->r12 = MEM_H(ctx->r16, 0X2D0);
L_80387D74:
    // 0x80387D74: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387D78: slti        $at, $t4, 0xB5
    ctx->r1 = SIGNED(ctx->r12) < 0XB5 ? 1 : 0;
    // 0x80387D7C: beq         $at, $zero, L_80387DA8
    if (ctx->r1 == 0) {
        // 0x80387D80: nop
    
            goto L_80387DA8;
    }
    // 0x80387D80: nop

    // 0x80387D84: lw          $t5, 0x2C0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387D88: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x80387D8C: sw          $t6, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r14;
    // 0x80387D90: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387D94: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387D98: lw          $t7, 0x2C0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C0);
    // 0x80387D9C: slti        $at, $t7, 0x3D
    ctx->r1 = SIGNED(ctx->r15) < 0X3D ? 1 : 0;
    // 0x80387DA0: bnel        $at, $zero, L_80387DD0
    if (ctx->r1 != 0) {
        // 0x80387DA4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80387DD0;
    }
    goto skip_4;
    // 0x80387DA4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
L_80387DA8:
    // 0x80387DA8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387DAC: jal         0x80363E88
    // 0x80387DB0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80387DB0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80387DB4: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387DB8: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80387DBC: lbu         $t8, 0x2B4($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80387DC0: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80387DC4: ori         $t0, $t9, 0x20
    ctx->r8 = ctx->r25 | 0X20;
    // 0x80387DC8: sb          $t0, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r8;
L_80387DCC:
    // 0x80387DCC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387DD0:
    // 0x80387DD0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80387DD4: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80387DD8: jr          $ra
    // 0x80387DDC: nop

    return;
    // 0x80387DDC: nop

;}
RECOMP_FUNC void perform_behavior_boxing_kangaroo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80387DE0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80387DE4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80387DE8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80387DEC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80387DF0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387DF4: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80387DF8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387DFC: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80387E00: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80387E04: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387E08: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80387E0C: beq         $t6, $zero, L_80387E38
    if (ctx->r14 == 0) {
        // 0x80387E10: nop
    
            goto L_80387E38;
    }
    // 0x80387E10: nop

    // 0x80387E14: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80387E18: beq         $t6, $a2, L_80387E60
    if (ctx->r14 == ctx->r6) {
        // 0x80387E1C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80387E60;
    }
    // 0x80387E1C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80387E20: beq         $t6, $at, L_80387EA4
    if (ctx->r14 == ctx->r1) {
        // 0x80387E24: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80387EA4;
    }
    // 0x80387E24: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80387E28: beql        $t6, $at, L_80387FC0
    if (ctx->r14 == ctx->r1) {
        // 0x80387E2C: lw          $t1, 0x2C0($v1)
        ctx->r9 = MEM_W(ctx->r3, 0X2C0);
            goto L_80387FC0;
    }
    goto skip_0;
    // 0x80387E2C: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    skip_0:
    // 0x80387E30: b           L_8038800C
    // 0x80387E34: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038800C;
    // 0x80387E34: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387E38:
    // 0x80387E38: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387E3C: jal         0x80363CE0
    // 0x80387E40: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80387E40: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x80387E44: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387E48: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80387E4C: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80387E50: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387E54: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80387E58: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80387E5C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80387E60:
    // 0x80387E60: lh          $t0, 0x2D0($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X2D0);
    // 0x80387E64: slti        $at, $t0, 0x28
    ctx->r1 = SIGNED(ctx->r8) < 0X28 ? 1 : 0;
    // 0x80387E68: beql        $at, $zero, L_8038800C
    if (ctx->r1 == 0) {
        // 0x80387E6C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038800C;
    }
    goto skip_1;
    // 0x80387E6C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80387E70: lbu         $t1, 0x2B4($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80387E74: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387E78: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80387E7C: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x80387E80: sb          $t3, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r11;
    // 0x80387E84: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80387E88: sw          $a2, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = ctx->r6;
    // 0x80387E8C: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x80387E90: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387E94: jal         0x80363E88
    // 0x80387E98: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80387E98: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_1:
    // 0x80387E9C: b           L_8038800C
    // 0x80387EA0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038800C;
    // 0x80387EA0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80387EA4:
    // 0x80387EA4: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80387EA8: slti        $at, $v0, 0x28
    ctx->r1 = SIGNED(ctx->r2) < 0X28 ? 1 : 0;
    // 0x80387EAC: beql        $at, $zero, L_80387EE4
    if (ctx->r1 == 0) {
        // 0x80387EB0: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80387EE4;
    }
    goto skip_2;
    // 0x80387EB0: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_2:
    // 0x80387EB4: lw          $t6, 0x2C0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2C0);
    // 0x80387EB8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387EBC: bnel        $t6, $zero, L_80387EE4
    if (ctx->r14 != 0) {
        // 0x80387EC0: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80387EE4;
    }
    goto skip_3;
    // 0x80387EC0: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_3:
    // 0x80387EC4: sw          $a2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r6;
    // 0x80387EC8: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x80387ECC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387ED0: jal         0x80363E88
    // 0x80387ED4: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80387ED4: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_2:
    // 0x80387ED8: b           L_80387F18
    // 0x80387EDC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
        goto L_80387F18;
    // 0x80387EDC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387EE0: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_80387EE4:
    // 0x80387EE4: bnel        $at, $zero, L_80387F1C
    if (ctx->r1 != 0) {
        // 0x80387EE8: lw          $t0, 0x2C4($v1)
        ctx->r8 = MEM_W(ctx->r3, 0X2C4);
            goto L_80387F1C;
    }
    goto skip_4;
    // 0x80387EE8: lw          $t0, 0x2C4($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C4);
    skip_4:
    // 0x80387EEC: lw          $t8, 0x2C0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X2C0);
    // 0x80387EF0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387EF4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387EF8: beq         $t8, $zero, L_80387F18
    if (ctx->r24 == 0) {
        // 0x80387EFC: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80387F18;
    }
    // 0x80387EFC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387F00: sw          $zero, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = 0;
    // 0x80387F04: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x80387F08: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387F0C: jal         0x80363CE0
    // 0x80387F10: lw          $a1, 0x2CC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x80387F10: lw          $a1, 0x2CC($t9)
    ctx->r5 = MEM_W(ctx->r25, 0X2CC);
    after_3:
    // 0x80387F14: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_80387F18:
    // 0x80387F18: lw          $t0, 0x2C4($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C4);
L_80387F1C:
    // 0x80387F1C: bgtzl       $t0, L_8038800C
    if (SIGNED(ctx->r8) > 0) {
        // 0x80387F20: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038800C;
    }
    goto skip_5;
    // 0x80387F20: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80387F24: jal         0x80383830
    // 0x80387F28: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80387F28: addiu       $a0, $zero, 0x28
    ctx->r4 = ADD32(0, 0X28);
    after_4:
    // 0x80387F2C: beql        $v0, $zero, L_8038800C
    if (ctx->r2 == 0) {
        // 0x80387F30: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038800C;
    }
    goto skip_6;
    // 0x80387F30: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80387F34: jal         0x80372604
    // 0x80387F38: nop

    func_80372604_783CB4(rdram, ctx);
        goto after_5;
    // 0x80387F38: nop

    after_5:
    // 0x80387F3C: jal         0x8012826C
    // 0x80387F40: nop

    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x80387F40: nop

    after_6:
    // 0x80387F44: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x80387F48: bgez        $v0, L_80387F5C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80387F4C: andi        $t1, $v0, 0x3
        ctx->r9 = ctx->r2 & 0X3;
            goto L_80387F5C;
    }
    // 0x80387F4C: andi        $t1, $v0, 0x3
    ctx->r9 = ctx->r2 & 0X3;
    // 0x80387F50: beq         $t1, $zero, L_80387F5C
    if (ctx->r9 == 0) {
        // 0x80387F54: nop
    
            goto L_80387F5C;
    }
    // 0x80387F54: nop

    // 0x80387F58: addiu       $t1, $t1, -0x4
    ctx->r9 = ADD32(ctx->r9, -0X4);
L_80387F5C:
    // 0x80387F5C: addiu       $t2, $t1, 0x5
    ctx->r10 = ADD32(ctx->r9, 0X5);
    // 0x80387F60: sw          $t2, 0x2C4($t3)
    MEM_W(0X2C4, ctx->r11) = ctx->r10;
    // 0x80387F64: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387F68: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387F6C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80387F70: lw          $t4, 0x2BC($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2BC);
    // 0x80387F74: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x80387F78: sw          $t5, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r13;
    // 0x80387F7C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387F80: lw          $t6, 0x2BC($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2BC);
    // 0x80387F84: slti        $at, $t6, 0x9
    ctx->r1 = SIGNED(ctx->r14) < 0X9 ? 1 : 0;
    // 0x80387F88: bnel        $at, $zero, L_8038800C
    if (ctx->r1 != 0) {
        // 0x80387F8C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038800C;
    }
    goto skip_7;
    // 0x80387F8C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80387F90: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80387F94: jal         0x80363EDC
    // 0x80387F98: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_7;
    // 0x80387F98: lw          $a2, 0x2CC($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X2CC);
    after_7:
    // 0x80387F9C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387FA0: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80387FA4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80387FA8: ori         $t9, $t8, 0x30
    ctx->r25 = ctx->r24 | 0X30;
    // 0x80387FAC: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80387FB0: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x80387FB4: b           L_80388008
    // 0x80387FB8: sw          $zero, 0x2BC($t0)
    MEM_W(0X2BC, ctx->r8) = 0;
        goto L_80388008;
    // 0x80387FB8: sw          $zero, 0x2BC($t0)
    MEM_W(0X2BC, ctx->r8) = 0;
    // 0x80387FBC: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
L_80387FC0:
    // 0x80387FC0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80387FC4: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x80387FC8: sw          $t2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r10;
    // 0x80387FCC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80387FD0: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80387FD4: slti        $at, $t3, 0x65
    ctx->r1 = SIGNED(ctx->r11) < 0X65 ? 1 : 0;
    // 0x80387FD8: bnel        $at, $zero, L_8038800C
    if (ctx->r1 != 0) {
        // 0x80387FDC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038800C;
    }
    goto skip_8;
    // 0x80387FDC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_8:
    // 0x80387FE0: lbu         $t4, 0x2B4($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80387FE4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80387FE8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80387FEC: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80387FF0: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x80387FF4: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
    // 0x80387FF8: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x80387FFC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388000: jal         0x80363CE0
    // 0x80388004: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_8;
    // 0x80388004: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_8:
L_80388008:
    // 0x80388008: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038800C:
    // 0x8038800C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80388010: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80388014: jr          $ra
    // 0x80388018: nop

    return;
    // 0x80388018: nop

;}
RECOMP_FUNC void perform_behavior_desert_fox(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038801C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80388020: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80388024: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x80388028: addiu       $s1, $s1, 0x552C
    ctx->r17 = ADD32(ctx->r17, 0X552C);
    // 0x8038802C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80388030: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388034: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80388038: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x8038803C: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80388040: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388044: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388048: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x8038804C: beq         $t6, $zero, L_8038806C
    if (ctx->r14 == 0) {
        // 0x80388050: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_8038806C;
    }
    // 0x80388050: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388054: beq         $t6, $v1, L_80388090
    if (ctx->r14 == ctx->r3) {
        // 0x80388058: addiu       $t0, $zero, 0x2
        ctx->r8 = ADD32(0, 0X2);
            goto L_80388090;
    }
    // 0x80388058: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x8038805C: beql        $t6, $t0, L_8038812C
    if (ctx->r14 == ctx->r8) {
        // 0x80388060: lw          $v0, 0x2C0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X2C0);
            goto L_8038812C;
    }
    goto skip_0;
    // 0x80388060: lw          $v0, 0x2C0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C0);
    skip_0:
    // 0x80388064: b           L_80388238
    // 0x80388068: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80388238;
    // 0x80388068: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038806C:
    // 0x8038806C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388070: jal         0x80363CE0
    // 0x80388074: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388074: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80388078: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038807C: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388080: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80388084: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80388088: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x8038808C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_80388090:
    // 0x80388090: lw          $t1, 0x2C4($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X2C4);
    // 0x80388094: bgtzl       $t1, L_803880D8
    if (SIGNED(ctx->r9) > 0) {
        // 0x80388098: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_803880D8;
    }
    goto skip_1;
    // 0x80388098: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_1:
    // 0x8038809C: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x803880A0: slti        $at, $t2, 0xFB
    ctx->r1 = SIGNED(ctx->r10) < 0XFB ? 1 : 0;
    // 0x803880A4: beql        $at, $zero, L_803880D8
    if (ctx->r1 == 0) {
        // 0x803880A8: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_803880D8;
    }
    goto skip_2;
    // 0x803880A8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_2:
    // 0x803880AC: jal         0x80383830
    // 0x803880B0: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    target_within_current_fov(rdram, ctx);
        goto after_1;
    // 0x803880B0: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    after_1:
    // 0x803880B4: beql        $v0, $zero, L_803880D8
    if (ctx->r2 == 0) {
        // 0x803880B8: lw          $s0, 0x0($s1)
        ctx->r16 = MEM_W(ctx->r17, 0X0);
            goto L_803880D8;
    }
    goto skip_3;
    // 0x803880B8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    skip_3:
    // 0x803880BC: jal         0x803745C4
    // 0x803880C0: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    func_803745C4_785C74(rdram, ctx);
        goto after_2;
    // 0x803880C0: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    after_2:
    // 0x803880C4: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x803880C8: addiu       $t3, $zero, 0xB4
    ctx->r11 = ADD32(0, 0XB4);
    // 0x803880CC: b           L_80388234
    // 0x803880D0: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
        goto L_80388234;
    // 0x803880D0: sw          $t3, 0x2C4($t4)
    MEM_W(0X2C4, ctx->r12) = ctx->r11;
    // 0x803880D4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_803880D8:
    // 0x803880D8: lw          $v0, 0x2C4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C4);
    // 0x803880DC: blez        $v0, L_80388234
    if (SIGNED(ctx->r2) <= 0) {
        // 0x803880E0: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80388234;
    }
    // 0x803880E0: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    // 0x803880E4: beq         $at, $zero, L_80388234
    if (ctx->r1 == 0) {
        // 0x803880E8: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80388234;
    }
    // 0x803880E8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803880EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803880F0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803880F4: jal         0x80363EDC
    // 0x803880F8: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x803880F8: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x803880FC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388100: addiu       $t9, $zero, 0xF0
    ctx->r25 = ADD32(0, 0XF0);
    // 0x80388104: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388108: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8038810C: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80388110: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x80388114: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x80388118: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
    // 0x8038811C: lw          $t1, 0x0($s1)
    ctx->r9 = MEM_W(ctx->r17, 0X0);
    // 0x80388120: b           L_80388234
    // 0x80388124: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
        goto L_80388234;
    // 0x80388124: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
    // 0x80388128: lw          $v0, 0x2C0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C0);
L_8038812C:
    // 0x8038812C: bne         $v0, $zero, L_80388164
    if (ctx->r2 != 0) {
        // 0x80388130: nop
    
            goto L_80388164;
    }
    // 0x80388130: nop

    // 0x80388134: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388138: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038813C: slti        $at, $t2, 0x15F
    ctx->r1 = SIGNED(ctx->r10) < 0X15F ? 1 : 0;
    // 0x80388140: bnel        $at, $zero, L_80388200
    if (ctx->r1 != 0) {
        // 0x80388144: lw          $t8, 0x2C4($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388200;
    }
    goto skip_4;
    // 0x80388144: lw          $t8, 0x2C4($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80388148: sw          $v1, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r3;
    // 0x8038814C: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x80388150: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388154: jal         0x80363E88
    // 0x80388158: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_4;
    // 0x80388158: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_4:
    // 0x8038815C: b           L_803881FC
    // 0x80388160: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_803881FC;
    // 0x80388160: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_80388164:
    // 0x80388164: bnel        $v1, $v0, L_803881D4
    if (ctx->r3 != ctx->r2) {
        // 0x80388168: lh          $t6, 0x2D0($s0)
        ctx->r14 = MEM_H(ctx->r16, 0X2D0);
            goto L_803881D4;
    }
    goto skip_5;
    // 0x80388168: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
    skip_5:
    // 0x8038816C: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388170: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388174: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80388178: slti        $at, $v0, 0x12C
    ctx->r1 = SIGNED(ctx->r2) < 0X12C ? 1 : 0;
    // 0x8038817C: beql        $at, $zero, L_803881A4
    if (ctx->r1 == 0) {
        // 0x80388180: slti        $at, $v0, 0x1C3
        ctx->r1 = SIGNED(ctx->r2) < 0X1C3 ? 1 : 0;
            goto L_803881A4;
    }
    goto skip_6;
    // 0x80388180: slti        $at, $v0, 0x1C3
    ctx->r1 = SIGNED(ctx->r2) < 0X1C3 ? 1 : 0;
    skip_6:
    // 0x80388184: sw          $zero, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = 0;
    // 0x80388188: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x8038818C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388190: jal         0x80363EDC
    // 0x80388194: lw          $a2, 0x2CC($t4)
    ctx->r6 = MEM_W(ctx->r12, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_5;
    // 0x80388194: lw          $a2, 0x2CC($t4)
    ctx->r6 = MEM_W(ctx->r12, 0X2CC);
    after_5:
    // 0x80388198: b           L_803881FC
    // 0x8038819C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_803881FC;
    // 0x8038819C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803881A0: slti        $at, $v0, 0x1C3
    ctx->r1 = SIGNED(ctx->r2) < 0X1C3 ? 1 : 0;
L_803881A4:
    // 0x803881A4: bne         $at, $zero, L_803881FC
    if (ctx->r1 != 0) {
        // 0x803881A8: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_803881FC;
    }
    // 0x803881A8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803881AC: sw          $t0, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r8;
    // 0x803881B0: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x803881B4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803881B8: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803881BC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803881C0: jal         0x80363CE0
    // 0x803881C4: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_6;
    // 0x803881C4: lw          $a1, 0x2CC($t5)
    ctx->r5 = MEM_W(ctx->r13, 0X2CC);
    after_6:
    // 0x803881C8: b           L_803881FC
    // 0x803881CC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_803881FC;
    // 0x803881CC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803881D0: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
L_803881D4:
    // 0x803881D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803881D8: slti        $at, $t6, 0x190
    ctx->r1 = SIGNED(ctx->r14) < 0X190 ? 1 : 0;
    // 0x803881DC: beql        $at, $zero, L_80388200
    if (ctx->r1 == 0) {
        // 0x803881E0: lw          $t8, 0x2C4($s0)
        ctx->r24 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388200;
    }
    goto skip_7;
    // 0x803881E0: lw          $t8, 0x2C4($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C4);
    skip_7:
    // 0x803881E4: sw          $v1, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r3;
    // 0x803881E8: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x803881EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803881F0: jal         0x80363E88
    // 0x803881F4: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x803881F4: lw          $a1, 0x2CC($t7)
    ctx->r5 = MEM_W(ctx->r15, 0X2CC);
    after_7:
    // 0x803881F8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_803881FC:
    // 0x803881FC: lw          $t8, 0x2C4($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X2C4);
L_80388200:
    // 0x80388200: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388204: bgtzl       $t8, L_80388238
    if (SIGNED(ctx->r24) > 0) {
        // 0x80388208: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388238;
    }
    goto skip_8;
    // 0x80388208: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_8:
    // 0x8038820C: lbu         $t9, 0x2B4($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388210: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80388214: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388218: andi        $t1, $t9, 0xFF0F
    ctx->r9 = ctx->r25 & 0XFF0F;
    // 0x8038821C: ori         $t2, $t1, 0x10
    ctx->r10 = ctx->r9 | 0X10;
    // 0x80388220: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
    // 0x80388224: lw          $t3, 0x0($s1)
    ctx->r11 = MEM_W(ctx->r17, 0X0);
    // 0x80388228: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038822C: jal         0x80363CE0
    // 0x80388230: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_8;
    // 0x80388230: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_8:
L_80388234:
    // 0x80388234: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388238:
    // 0x80388238: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x8038823C: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80388240: jr          $ra
    // 0x80388244: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x80388244: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void perform_behavior_armed_desert_fox(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388248: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8038824C: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80388250: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x80388254: addiu       $s1, $s1, 0x552C
    ctx->r17 = ADD32(ctx->r17, 0X552C);
    // 0x80388258: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x8038825C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388260: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80388264: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80388268: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x8038826C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388270: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388274: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80388278: beq         $t6, $zero, L_80388298
    if (ctx->r14 == 0) {
        // 0x8038827C: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80388298;
    }
    // 0x8038827C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388280: beq         $t6, $v1, L_803882C0
    if (ctx->r14 == ctx->r3) {
        // 0x80388284: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803882C0;
    }
    // 0x80388284: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80388288: beql        $t6, $at, L_80388398
    if (ctx->r14 == ctx->r1) {
        // 0x8038828C: lh          $t1, 0x2D0($s0)
        ctx->r9 = MEM_H(ctx->r16, 0X2D0);
            goto L_80388398;
    }
    goto skip_0;
    // 0x8038828C: lh          $t1, 0x2D0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80388290: b           L_80388408
    // 0x80388294: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
        goto L_80388408;
    // 0x80388294: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
L_80388298:
    // 0x80388298: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038829C: jal         0x80363CE0
    // 0x803882A0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803882A0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x803882A4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803882A8: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x803882AC: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803882B0: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803882B4: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803882B8: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x803882BC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_803882C0:
    // 0x803882C0: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x803882C4: slti        $at, $v0, 0x64
    ctx->r1 = SIGNED(ctx->r2) < 0X64 ? 1 : 0;
    // 0x803882C8: beql        $at, $zero, L_80388320
    if (ctx->r1 == 0) {
        // 0x803882CC: slti        $at, $v0, 0xC8
        ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
            goto L_80388320;
    }
    goto skip_1;
    // 0x803882CC: slti        $at, $v0, 0xC8
    ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
    skip_1:
    // 0x803882D0: lw          $t0, 0x2B8($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2B8);
    // 0x803882D4: bgtzl       $t0, L_80388320
    if (SIGNED(ctx->r8) > 0) {
        // 0x803882D8: slti        $at, $v0, 0xC8
        ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
            goto L_80388320;
    }
    goto skip_2;
    // 0x803882D8: slti        $at, $v0, 0xC8
    ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
    skip_2:
    // 0x803882DC: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803882E0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803882E4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803882E8: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803882EC: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x803882F0: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
    // 0x803882F4: lw          $t4, 0x0($s1)
    ctx->r12 = MEM_W(ctx->r17, 0X0);
    // 0x803882F8: sw          $zero, 0x2BC($t4)
    MEM_W(0X2BC, ctx->r12) = 0;
    // 0x803882FC: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x80388300: sw          $zero, 0x2C0($t5)
    MEM_W(0X2C0, ctx->r13) = 0;
    // 0x80388304: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x80388308: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038830C: jal         0x80363EDC
    // 0x80388310: lw          $a2, 0x2CC($t6)
    ctx->r6 = MEM_W(ctx->r14, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x80388310: lw          $a2, 0x2CC($t6)
    ctx->r6 = MEM_W(ctx->r14, 0X2CC);
    after_1:
    // 0x80388314: b           L_8038838C
    // 0x80388318: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_8038838C;
    // 0x80388318: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x8038831C: slti        $at, $v0, 0xC8
    ctx->r1 = SIGNED(ctx->r2) < 0XC8 ? 1 : 0;
L_80388320:
    // 0x80388320: beql        $at, $zero, L_80388358
    if (ctx->r1 == 0) {
        // 0x80388324: slti        $at, $v0, 0x12D
        ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
            goto L_80388358;
    }
    goto skip_3;
    // 0x80388324: slti        $at, $v0, 0x12D
    ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
    skip_3:
    // 0x80388328: lw          $t7, 0x2C0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C0);
    // 0x8038832C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388330: bnel        $t7, $zero, L_80388358
    if (ctx->r15 != 0) {
        // 0x80388334: slti        $at, $v0, 0x12D
        ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
            goto L_80388358;
    }
    goto skip_4;
    // 0x80388334: slti        $at, $v0, 0x12D
    ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
    skip_4:
    // 0x80388338: sw          $v1, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r3;
    // 0x8038833C: lw          $t8, 0x0($s1)
    ctx->r24 = MEM_W(ctx->r17, 0X0);
    // 0x80388340: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388344: jal         0x80363E88
    // 0x80388348: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80388348: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_2:
    // 0x8038834C: b           L_8038838C
    // 0x80388350: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
        goto L_8038838C;
    // 0x80388350: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388354: slti        $at, $v0, 0x12D
    ctx->r1 = SIGNED(ctx->r2) < 0X12D ? 1 : 0;
L_80388358:
    // 0x80388358: bne         $at, $zero, L_8038838C
    if (ctx->r1 != 0) {
        // 0x8038835C: nop
    
            goto L_8038838C;
    }
    // 0x8038835C: nop

    // 0x80388360: lw          $t9, 0x2C0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C0);
    // 0x80388364: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388368: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x8038836C: bne         $v1, $t9, L_8038838C
    if (ctx->r3 != ctx->r25) {
        // 0x80388370: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_8038838C;
    }
    // 0x80388370: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388374: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388378: jal         0x80363CE0
    // 0x8038837C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x8038837C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80388380: lw          $t0, 0x0($s1)
    ctx->r8 = MEM_W(ctx->r17, 0X0);
    // 0x80388384: sw          $zero, 0x2C0($t0)
    MEM_W(0X2C0, ctx->r8) = 0;
    // 0x80388388: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_8038838C:
    // 0x8038838C: b           L_80388408
    // 0x80388390: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
        goto L_80388408;
    // 0x80388390: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
    // 0x80388394: lh          $t1, 0x2D0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2D0);
L_80388398:
    // 0x80388398: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038839C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803883A0: slti        $at, $t1, 0xFB
    ctx->r1 = SIGNED(ctx->r9) < 0XFB ? 1 : 0;
    // 0x803883A4: beq         $at, $zero, L_803883CC
    if (ctx->r1 == 0) {
        // 0x803883A8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_803883CC;
    }
    // 0x803883A8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803883AC: lw          $t2, 0x2C0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C0);
    // 0x803883B0: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x803883B4: sw          $t3, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r11;
    // 0x803883B8: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803883BC: lw          $t4, 0x2C0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C0);
    // 0x803883C0: slti        $at, $t4, 0x29
    ctx->r1 = SIGNED(ctx->r12) < 0X29 ? 1 : 0;
    // 0x803883C4: bnel        $at, $zero, L_80388408
    if (ctx->r1 != 0) {
        // 0x803883C8: lw          $v0, 0x2B8($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X2B8);
            goto L_80388408;
    }
    goto skip_5;
    // 0x803883C8: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
    skip_5:
L_803883CC:
    // 0x803883CC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803883D0: jal         0x80363CE0
    // 0x803883D4: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_4;
    // 0x803883D4: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_4:
    // 0x803883D8: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x803883DC: addiu       $t6, $zero, 0x14
    ctx->r14 = ADD32(0, 0X14);
    // 0x803883E0: sw          $zero, 0x2C0($t5)
    MEM_W(0X2C0, ctx->r13) = 0;
    // 0x803883E4: lw          $t7, 0x0($s1)
    ctx->r15 = MEM_W(ctx->r17, 0X0);
    // 0x803883E8: sw          $t6, 0x2B8($t7)
    MEM_W(0X2B8, ctx->r15) = ctx->r14;
    // 0x803883EC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803883F0: lbu         $t8, 0x2B4($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803883F4: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x803883F8: ori         $t0, $t9, 0x10
    ctx->r8 = ctx->r25 | 0X10;
    // 0x803883FC: sb          $t0, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r8;
    // 0x80388400: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388404: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
L_80388408:
    // 0x80388408: blez        $v0, L_80388418
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8038840C: addiu       $t1, $v0, -0x1
        ctx->r9 = ADD32(ctx->r2, -0X1);
            goto L_80388418;
    }
    // 0x8038840C: addiu       $t1, $v0, -0x1
    ctx->r9 = ADD32(ctx->r2, -0X1);
    // 0x80388410: sw          $t1, 0x2B8($s0)
    MEM_W(0X2B8, ctx->r16) = ctx->r9;
    // 0x80388414: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_80388418:
    // 0x80388418: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x8038841C: slti        $at, $t2, 0x191
    ctx->r1 = SIGNED(ctx->r10) < 0X191 ? 1 : 0;
    // 0x80388420: beql        $at, $zero, L_80388470
    if (ctx->r1 == 0) {
        // 0x80388424: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388470;
    }
    goto skip_6;
    // 0x80388424: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80388428: lw          $t3, 0x2C4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X2C4);
    // 0x8038842C: bgtzl       $t3, L_80388470
    if (SIGNED(ctx->r11) > 0) {
        // 0x80388430: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388470;
    }
    goto skip_7;
    // 0x80388430: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80388434: jal         0x80383830
    // 0x80388438: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    target_within_current_fov(rdram, ctx);
        goto after_5;
    // 0x80388438: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    after_5:
    // 0x8038843C: beql        $v0, $zero, L_80388470
    if (ctx->r2 == 0) {
        // 0x80388440: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388470;
    }
    goto skip_8;
    // 0x80388440: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_8:
    // 0x80388444: jal         0x8037460C
    // 0x80388448: nop

    func_8037460C_785CBC(rdram, ctx);
        goto after_6;
    // 0x80388448: nop

    after_6:
    // 0x8038844C: jal         0x80140D20
    // 0x80388450: nop

    guRandom(rdram, ctx);
        goto after_7;
    // 0x80388450: nop

    after_7:
    // 0x80388454: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80388458: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038845C: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x80388460: mfhi        $t4
    ctx->r12 = hi;
    // 0x80388464: addiu       $t5, $t4, 0x11
    ctx->r13 = ADD32(ctx->r12, 0X11);
    // 0x80388468: sw          $t5, 0x2C4($t6)
    MEM_W(0X2C4, ctx->r14) = ctx->r13;
    // 0x8038846C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388470:
    // 0x80388470: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80388474: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80388478: jr          $ra
    // 0x8038847C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x8038847C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void perform_behavior_scorpion(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388480: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80388484: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80388488: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038848C: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x80388490: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388494: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80388498: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038849C: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803884A0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803884A4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803884A8: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x803884AC: beq         $t6, $zero, L_803884D0
    if (ctx->r14 == 0) {
        // 0x803884B0: nop
    
            goto L_803884D0;
    }
    // 0x803884B0: nop

    // 0x803884B4: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x803884B8: beq         $t6, $a2, L_803884F8
    if (ctx->r14 == ctx->r6) {
        // 0x803884BC: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803884F8;
    }
    // 0x803884BC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803884C0: beql        $t6, $at, L_803886C0
    if (ctx->r14 == ctx->r1) {
        // 0x803884C4: lh          $t4, 0x2D0($v1)
        ctx->r12 = MEM_H(ctx->r3, 0X2D0);
            goto L_803886C0;
    }
    goto skip_0;
    // 0x803884C4: lh          $t4, 0x2D0($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x803884C8: b           L_80388724
    // 0x803884CC: lw          $v0, 0x2B8($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B8);
        goto L_80388724;
    // 0x803884CC: lw          $v0, 0x2B8($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B8);
L_803884D0:
    // 0x803884D0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803884D4: jal         0x80363CE0
    // 0x803884D8: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x803884D8: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x803884DC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803884E0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x803884E4: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803884E8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803884EC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803884F0: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x803884F4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_803884F8:
    // 0x803884F8: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x803884FC: slti        $at, $v0, 0x32
    ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
    // 0x80388500: beql        $at, $zero, L_8038853C
    if (ctx->r1 == 0) {
        // 0x80388504: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_8038853C;
    }
    goto skip_1;
    // 0x80388504: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_1:
    // 0x80388508: lw          $t0, 0x2C0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2C0);
    // 0x8038850C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388510: bnel        $t0, $zero, L_8038853C
    if (ctx->r8 != 0) {
        // 0x80388514: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_8038853C;
    }
    goto skip_2;
    // 0x80388514: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_2:
    // 0x80388518: sw          $a2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r6;
    // 0x8038851C: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80388520: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388524: jal         0x80363E88
    // 0x80388528: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80388528: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_1:
    // 0x8038852C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388530: b           L_80388578
    // 0x80388534: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
        goto L_80388578;
    // 0x80388534: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80388538: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_8038853C:
    // 0x8038853C: bnel        $at, $zero, L_8038857C
    if (ctx->r1 != 0) {
        // 0x80388540: slti        $at, $v0, 0xFB
        ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
            goto L_8038857C;
    }
    goto skip_3;
    // 0x80388540: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
    skip_3:
    // 0x80388544: lw          $t2, 0x2C0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X2C0);
    // 0x80388548: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038854C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388550: bnel        $a2, $t2, L_8038857C
    if (ctx->r6 != ctx->r10) {
        // 0x80388554: slti        $at, $v0, 0xFB
        ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
            goto L_8038857C;
    }
    goto skip_4;
    // 0x80388554: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
    skip_4:
    // 0x80388558: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038855C: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    // 0x80388560: jal         0x80363CE0
    // 0x80388564: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80388564: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    after_2:
    // 0x80388568: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x8038856C: sw          $zero, 0x2C0($t3)
    MEM_W(0X2C0, ctx->r11) = 0;
    // 0x80388570: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388574: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
L_80388578:
    // 0x80388578: slti        $at, $v0, 0xFB
    ctx->r1 = SIGNED(ctx->r2) < 0XFB ? 1 : 0;
L_8038857C:
    // 0x8038857C: beql        $at, $zero, L_803885DC
    if (ctx->r1 == 0) {
        // 0x80388580: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_803885DC;
    }
    goto skip_5;
    // 0x80388580: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_5:
    // 0x80388584: lw          $t4, 0x2C4($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X2C4);
    // 0x80388588: bgtzl       $t4, L_803885DC
    if (SIGNED(ctx->r12) > 0) {
        // 0x8038858C: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_803885DC;
    }
    goto skip_6;
    // 0x8038858C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_6:
    // 0x80388590: jal         0x80383830
    // 0x80388594: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x80388594: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_3:
    // 0x80388598: beql        $v0, $zero, L_803885DC
    if (ctx->r2 == 0) {
        // 0x8038859C: lw          $v1, 0x0($s0)
        ctx->r3 = MEM_W(ctx->r16, 0X0);
            goto L_803885DC;
    }
    goto skip_7;
    // 0x8038859C: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    skip_7:
    // 0x803885A0: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x803885A4: jal         0x80379148
    // 0x803885A8: lw          $a0, 0x2CC($t5)
    ctx->r4 = MEM_W(ctx->r13, 0X2CC);
    func_80379148_78A7F8(rdram, ctx);
        goto after_4;
    // 0x803885A8: lw          $a0, 0x2CC($t5)
    ctx->r4 = MEM_W(ctx->r13, 0X2CC);
    after_4:
    // 0x803885AC: jal         0x80140D20
    // 0x803885B0: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x803885B0: nop

    after_5:
    // 0x803885B4: addiu       $at, $zero, 0x32
    ctx->r1 = ADD32(0, 0X32);
    // 0x803885B8: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x803885BC: lw          $t8, 0x0($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X0);
    // 0x803885C0: mfhi        $t6
    ctx->r14 = hi;
    // 0x803885C4: addiu       $t7, $t6, 0x96
    ctx->r15 = ADD32(ctx->r14, 0X96);
    // 0x803885C8: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
    // 0x803885CC: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803885D0: b           L_8038865C
    // 0x803885D4: lw          $a0, 0x2C4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C4);
        goto L_8038865C;
    // 0x803885D4: lw          $a0, 0x2C4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C4);
    // 0x803885D8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_803885DC:
    // 0x803885DC: lh          $t9, 0x2D0($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2D0);
    // 0x803885E0: lw          $a0, 0x2C4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C4);
    // 0x803885E4: slti        $at, $t9, 0x3D
    ctx->r1 = SIGNED(ctx->r25) < 0X3D ? 1 : 0;
    // 0x803885E8: beq         $at, $zero, L_8038865C
    if (ctx->r1 == 0) {
        // 0x803885EC: nop
    
            goto L_8038865C;
    }
    // 0x803885EC: nop

    // 0x803885F0: lw          $t0, 0x2B8($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X2B8);
    // 0x803885F4: bgtz        $t0, L_8038865C
    if (SIGNED(ctx->r8) > 0) {
        // 0x803885F8: nop
    
            goto L_8038865C;
    }
    // 0x803885F8: nop

    // 0x803885FC: lw          $t1, 0x2BC($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2BC);
    // 0x80388600: slti        $at, $t1, 0x6
    ctx->r1 = SIGNED(ctx->r9) < 0X6 ? 1 : 0;
    // 0x80388604: beq         $at, $zero, L_8038865C
    if (ctx->r1 == 0) {
        // 0x80388608: slti        $at, $a0, 0x33
        ctx->r1 = SIGNED(ctx->r4) < 0X33 ? 1 : 0;
            goto L_8038865C;
    }
    // 0x80388608: slti        $at, $a0, 0x33
    ctx->r1 = SIGNED(ctx->r4) < 0X33 ? 1 : 0;
    // 0x8038860C: beq         $at, $zero, L_8038865C
    if (ctx->r1 == 0) {
        // 0x80388610: nop
    
            goto L_8038865C;
    }
    // 0x80388610: nop

    // 0x80388614: jal         0x803791AC
    // 0x80388618: nop

    func_803791AC_78A85C(rdram, ctx);
        goto after_6;
    // 0x80388618: nop

    after_6:
    // 0x8038861C: jal         0x80140D20
    // 0x80388620: nop

    guRandom(rdram, ctx);
        goto after_7;
    // 0x80388620: nop

    after_7:
    // 0x80388624: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x80388628: bgez        $v0, L_8038863C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8038862C: andi        $t2, $v0, 0x7
        ctx->r10 = ctx->r2 & 0X7;
            goto L_8038863C;
    }
    // 0x8038862C: andi        $t2, $v0, 0x7
    ctx->r10 = ctx->r2 & 0X7;
    // 0x80388630: beq         $t2, $zero, L_8038863C
    if (ctx->r10 == 0) {
        // 0x80388634: nop
    
            goto L_8038863C;
    }
    // 0x80388634: nop

    // 0x80388638: addiu       $t2, $t2, -0x8
    ctx->r10 = ADD32(ctx->r10, -0X8);
L_8038863C:
    // 0x8038863C: addiu       $t3, $t2, 0x9
    ctx->r11 = ADD32(ctx->r10, 0X9);
    // 0x80388640: sw          $t3, 0x2B8($t4)
    MEM_W(0X2B8, ctx->r12) = ctx->r11;
    // 0x80388644: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388648: lw          $t5, 0x2BC($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2BC);
    // 0x8038864C: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x80388650: sw          $t6, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r14;
    // 0x80388654: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388658: lw          $a0, 0x2C4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C4);
L_8038865C:
    // 0x8038865C: blez        $a0, L_803886B4
    if (SIGNED(ctx->r4) <= 0) {
        // 0x80388660: nop
    
            goto L_803886B4;
    }
    // 0x80388660: nop

    // 0x80388664: lw          $t7, 0x2BC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2BC);
    // 0x80388668: slti        $at, $t7, 0x6
    ctx->r1 = SIGNED(ctx->r15) < 0X6 ? 1 : 0;
    // 0x8038866C: bne         $at, $zero, L_803886B4
    if (ctx->r1 != 0) {
        // 0x80388670: nop
    
            goto L_803886B4;
    }
    // 0x80388670: nop

    // 0x80388674: lbu         $t8, 0x2B4($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80388678: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038867C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80388680: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80388684: ori         $t0, $t9, 0x20
    ctx->r8 = ctx->r25 | 0X20;
    // 0x80388688: sb          $t0, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r8;
    // 0x8038868C: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80388690: sw          $zero, 0x2BC($t1)
    MEM_W(0X2BC, ctx->r9) = 0;
    // 0x80388694: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80388698: sw          $zero, 0x2C0($t2)
    MEM_W(0X2C0, ctx->r10) = 0;
    // 0x8038869C: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x803886A0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803886A4: jal         0x80363EDC
    // 0x803886A8: lw          $a2, 0x2CC($t3)
    ctx->r6 = MEM_W(ctx->r11, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_8;
    // 0x803886A8: lw          $a2, 0x2CC($t3)
    ctx->r6 = MEM_W(ctx->r11, 0X2CC);
    after_8:
    // 0x803886AC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803886B0: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
L_803886B4:
    // 0x803886B4: b           L_80388724
    // 0x803886B8: lw          $v0, 0x2B8($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B8);
        goto L_80388724;
    // 0x803886B8: lw          $v0, 0x2B8($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B8);
    // 0x803886BC: lh          $t4, 0x2D0($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X2D0);
L_803886C0:
    // 0x803886C0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803886C4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803886C8: slti        $at, $t4, 0x191
    ctx->r1 = SIGNED(ctx->r12) < 0X191 ? 1 : 0;
    // 0x803886CC: beq         $at, $zero, L_803886EC
    if (ctx->r1 == 0) {
        // 0x803886D0: nop
    
            goto L_803886EC;
    }
    // 0x803886D0: nop

    // 0x803886D4: lw          $a0, 0x2C0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C0);
    // 0x803886D8: slti        $v0, $a0, 0x5A
    ctx->r2 = SIGNED(ctx->r4) < 0X5A ? 1 : 0;
    // 0x803886DC: addiu       $t5, $a0, 0x1
    ctx->r13 = ADD32(ctx->r4, 0X1);
    // 0x803886E0: bne         $v0, $zero, L_80388718
    if (ctx->r2 != 0) {
        // 0x803886E4: sw          $t5, 0x2C0($v1)
        MEM_W(0X2C0, ctx->r3) = ctx->r13;
            goto L_80388718;
    }
    // 0x803886E4: sw          $t5, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r13;
    // 0x803886E8: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_803886EC:
    // 0x803886EC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803886F0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803886F4: jal         0x80363CE0
    // 0x803886F8: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_9;
    // 0x803886F8: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_9:
    // 0x803886FC: lw          $t6, 0x0($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X0);
    // 0x80388700: sw          $zero, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = 0;
    // 0x80388704: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80388708: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x8038870C: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80388710: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80388714: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
L_80388718:
    // 0x80388718: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038871C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80388720: lw          $v0, 0x2B8($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B8);
L_80388724:
    // 0x80388724: blez        $v0, L_80388730
    if (SIGNED(ctx->r2) <= 0) {
        // 0x80388728: addiu       $t0, $v0, -0x1
        ctx->r8 = ADD32(ctx->r2, -0X1);
            goto L_80388730;
    }
    // 0x80388728: addiu       $t0, $v0, -0x1
    ctx->r8 = ADD32(ctx->r2, -0X1);
    // 0x8038872C: sw          $t0, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r8;
L_80388730:
    // 0x80388730: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80388734: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80388738: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8038873C: jr          $ra
    // 0x80388740: nop

    return;
    // 0x80388740: nop

;}
RECOMP_FUNC void perform_behavior_gorilla(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388744: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388748: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8038874C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80388750: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80388754: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80388758: lw          $v1, 0x2B4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2B4);
    // 0x8038875C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388760: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388764: srl         $t6, $v1, 28
    ctx->r14 = S32(U32(ctx->r3) >> 28);
    // 0x80388768: beq         $t6, $zero, L_8038878C
    if (ctx->r14 == 0) {
        // 0x8038876C: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_8038878C;
    }
    // 0x8038876C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388770: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80388774: beq         $t6, $at, L_803887B8
    if (ctx->r14 == ctx->r1) {
        // 0x80388778: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803887B8;
    }
    // 0x80388778: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038877C: beql        $t6, $at, L_8038887C
    if (ctx->r14 == ctx->r1) {
        // 0x80388780: lh          $t3, 0x2D0($v0)
        ctx->r11 = MEM_H(ctx->r2, 0X2D0);
            goto L_8038887C;
    }
    goto skip_0;
    // 0x80388780: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
    skip_0:
    // 0x80388784: b           L_803888E4
    // 0x80388788: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803888E4;
    // 0x80388788: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038878C:
    // 0x8038878C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388790: jal         0x80363CE0
    // 0x80388794: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388794: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_0:
    // 0x80388798: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038879C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803887A0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803887A4: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803887A8: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803887AC: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803887B0: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x803887B4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803887B8:
    // 0x803887B8: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x803887BC: slti        $at, $t1, 0x32
    ctx->r1 = SIGNED(ctx->r9) < 0X32 ? 1 : 0;
    // 0x803887C0: beql        $at, $zero, L_80388814
    if (ctx->r1 == 0) {
        // 0x803887C4: lw          $t7, 0x2C4($v0)
        ctx->r15 = MEM_W(ctx->r2, 0X2C4);
            goto L_80388814;
    }
    goto skip_1;
    // 0x803887C4: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
    skip_1:
    // 0x803887C8: lw          $t2, 0x2C0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2C0);
    // 0x803887CC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803887D0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803887D4: bgtzl       $t2, L_80388814
    if (SIGNED(ctx->r10) > 0) {
        // 0x803887D8: lw          $t7, 0x2C4($v0)
        ctx->r15 = MEM_W(ctx->r2, 0X2C4);
            goto L_80388814;
    }
    goto skip_2;
    // 0x803887D8: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
    skip_2:
    // 0x803887DC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803887E0: jal         0x80363EDC
    // 0x803887E4: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x803887E4: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    after_1:
    // 0x803887E8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803887EC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803887F0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803887F4: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803887F8: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x803887FC: ori         $t5, $t4, 0x20
    ctx->r13 = ctx->r12 | 0X20;
    // 0x80388800: sb          $t5, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r13;
    // 0x80388804: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80388808: b           L_80388860
    // 0x8038880C: sw          $zero, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = 0;
        goto L_80388860;
    // 0x8038880C: sw          $zero, 0x2C0($t6)
    MEM_W(0X2C0, ctx->r14) = 0;
    // 0x80388810: lw          $t7, 0x2C4($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X2C4);
L_80388814:
    // 0x80388814: bgtzl       $t7, L_80388864
    if (SIGNED(ctx->r15) > 0) {
        // 0x80388818: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_80388864;
    }
    goto skip_3;
    // 0x80388818: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_3:
    // 0x8038881C: jal         0x80383830
    // 0x80388820: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    target_within_current_fov(rdram, ctx);
        goto after_2;
    // 0x80388820: addiu       $a0, $zero, 0x20
    ctx->r4 = ADD32(0, 0X20);
    after_2:
    // 0x80388824: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388828: beq         $v0, $zero, L_80388860
    if (ctx->r2 == 0) {
        // 0x8038882C: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_80388860;
    }
    // 0x8038882C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388830: jal         0x8037B70C
    // 0x80388834: nop

    func_8037B70C_78CDBC(rdram, ctx);
        goto after_3;
    // 0x80388834: nop

    after_3:
    // 0x80388838: jal         0x80140D20
    // 0x8038883C: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x8038883C: nop

    after_4:
    // 0x80388840: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80388844: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80388848: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8038884C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388850: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80388854: mfhi        $t8
    ctx->r24 = hi;
    // 0x80388858: addiu       $t9, $t8, 0x1E
    ctx->r25 = ADD32(ctx->r24, 0X1E);
    // 0x8038885C: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
L_80388860:
    // 0x80388860: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_80388864:
    // 0x80388864: lw          $a0, 0x2C0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C0);
    // 0x80388868: blez        $a0, L_803888E0
    if (SIGNED(ctx->r4) <= 0) {
        // 0x8038886C: addiu       $t2, $a0, -0x1
        ctx->r10 = ADD32(ctx->r4, -0X1);
            goto L_803888E0;
    }
    // 0x8038886C: addiu       $t2, $a0, -0x1
    ctx->r10 = ADD32(ctx->r4, -0X1);
    // 0x80388870: b           L_803888E0
    // 0x80388874: sw          $t2, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r10;
        goto L_803888E0;
    // 0x80388874: sw          $t2, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r10;
    // 0x80388878: lh          $t3, 0x2D0($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X2D0);
L_8038887C:
    // 0x8038887C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388880: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388884: slti        $at, $t3, 0xAB
    ctx->r1 = SIGNED(ctx->r11) < 0XAB ? 1 : 0;
    // 0x80388888: beq         $at, $zero, L_803888A8
    if (ctx->r1 == 0) {
        // 0x8038888C: nop
    
            goto L_803888A8;
    }
    // 0x8038888C: nop

    // 0x80388890: lw          $a0, 0x2C0($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C0);
    // 0x80388894: slti        $v1, $a0, 0x1F
    ctx->r3 = SIGNED(ctx->r4) < 0X1F ? 1 : 0;
    // 0x80388898: addiu       $t4, $a0, 0x1
    ctx->r12 = ADD32(ctx->r4, 0X1);
    // 0x8038889C: bne         $v1, $zero, L_803888E0
    if (ctx->r3 != 0) {
        // 0x803888A0: sw          $t4, 0x2C0($v0)
        MEM_W(0X2C0, ctx->r2) = ctx->r12;
            goto L_803888E0;
    }
    // 0x803888A0: sw          $t4, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r12;
    // 0x803888A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_803888A8:
    // 0x803888A8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803888AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803888B0: jal         0x80363CE0
    // 0x803888B4: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_5;
    // 0x803888B4: lw          $a1, 0x2CC($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X2CC);
    after_5:
    // 0x803888B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803888BC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x803888C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x803888C4: addiu       $t8, $zero, 0x50
    ctx->r24 = ADD32(0, 0X50);
    // 0x803888C8: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803888CC: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x803888D0: ori         $t7, $t6, 0x10
    ctx->r15 = ctx->r14 | 0X10;
    // 0x803888D4: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x803888D8: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x803888DC: sw          $t8, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = ctx->r24;
L_803888E0:
    // 0x803888E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803888E4:
    // 0x803888E4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803888E8: jr          $ra
    // 0x803888EC: nop

    return;
    // 0x803888EC: nop

;}
RECOMP_FUNC void perform_behavior_elephant(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803888F0: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x803888F4: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x803888F8: lui         $s1, 0x803D
    ctx->r17 = S32(0X803D << 16);
    // 0x803888FC: addiu       $s1, $s1, 0x552C
    ctx->r17 = ADD32(ctx->r17, 0X552C);
    // 0x80388900: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80388904: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388908: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038890C: lw          $t6, 0x2B4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X2B4);
    // 0x80388910: srl         $t7, $t6, 28
    ctx->r15 = S32(U32(ctx->r14) >> 28);
    // 0x80388914: sltiu       $at, $t7, 0x5
    ctx->r1 = ctx->r15 < 0X5 ? 1 : 0;
    // 0x80388918: beq         $at, $zero, L_80388AF8
    if (ctx->r1 == 0) {
        // 0x8038891C: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_80388AF8;
    }
    // 0x8038891C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80388920: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80388924: addu        $at, $at, $t7
    gpr jr_addend_8038892C = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80388928: lw          $t7, -0xBA4($at)
    ctx->r15 = ADD32(ctx->r1, -0XBA4);
    // 0x8038892C: jr          $t7
    // 0x80388930: nop

    switch (jr_addend_8038892C >> 2) {
        case 0: goto L_80388934; break;
        case 1: goto L_80388964; break;
        case 2: goto L_8038899C; break;
        case 3: goto L_80388A30; break;
        case 4: goto L_80388AAC; break;
        default: switch_error(__func__, 0x8038892C, 0x803BF45C);
    }
    // 0x80388930: nop

L_80388934:
    // 0x80388934: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388938: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038893C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    // 0x80388940: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388944: jal         0x80363CE0
    // 0x80388948: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388948: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_0:
    // 0x8038894C: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388950: lbu         $t8, 0x2B4($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388954: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80388958: ori         $t0, $t9, 0x10
    ctx->r8 = ctx->r25 | 0X10;
    // 0x8038895C: sb          $t0, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r8;
    // 0x80388960: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_80388964:
    // 0x80388964: lh          $t1, 0x2D0($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388968: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038896C: slti        $at, $t1, 0xFB
    ctx->r1 = SIGNED(ctx->r9) < 0XFB ? 1 : 0;
    // 0x80388970: beql        $at, $zero, L_80388AFC
    if (ctx->r1 == 0) {
        // 0x80388974: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388AFC;
    }
    goto skip_0;
    // 0x80388974: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80388978: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038897C: jal         0x80363E88
    // 0x80388980: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80388980: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80388984: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388988: lbu         $t2, 0x2B4($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X2B4);
    // 0x8038898C: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80388990: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x80388994: b           L_80388AF8
    // 0x80388998: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
        goto L_80388AF8;
    // 0x80388998: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
L_8038899C:
    // 0x8038899C: lh          $t5, 0x2D0($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X2D0);
    // 0x803889A0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803889A4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803889A8: slti        $at, $t5, 0x137
    ctx->r1 = SIGNED(ctx->r13) < 0X137 ? 1 : 0;
    // 0x803889AC: bne         $at, $zero, L_803889D8
    if (ctx->r1 != 0) {
        // 0x803889B0: addiu       $a3, $zero, 0xA
        ctx->r7 = ADD32(0, 0XA);
            goto L_803889D8;
    }
    // 0x803889B0: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x803889B4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803889B8: jal         0x80363CE0
    // 0x803889BC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x803889BC: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x803889C0: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x803889C4: lbu         $t6, 0x2B4($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803889C8: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x803889CC: ori         $t8, $t7, 0x10
    ctx->r24 = ctx->r15 | 0X10;
    // 0x803889D0: b           L_80388AF8
    // 0x803889D4: sb          $t8, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r24;
        goto L_80388AF8;
    // 0x803889D4: sb          $t8, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r24;
L_803889D8:
    // 0x803889D8: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
    // 0x803889DC: bgtzl       $t9, L_80388AFC
    if (SIGNED(ctx->r25) > 0) {
        // 0x803889E0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388AFC;
    }
    goto skip_1;
    // 0x803889E0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803889E4: jal         0x80383830
    // 0x803889E8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_3;
    // 0x803889E8: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_3:
    // 0x803889EC: beql        $v0, $zero, L_80388AFC
    if (ctx->r2 == 0) {
        // 0x803889F0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388AFC;
    }
    goto skip_2;
    // 0x803889F0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x803889F4: jal         0x8037D268
    // 0x803889F8: addiu       $a0, $zero, 0x5A
    ctx->r4 = ADD32(0, 0X5A);
    func_8037D268_78E918(rdram, ctx);
        goto after_4;
    // 0x803889F8: addiu       $a0, $zero, 0x5A
    ctx->r4 = ADD32(0, 0X5A);
    after_4:
    // 0x803889FC: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388A00: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388A04: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80388A08: ori         $t2, $t1, 0x30
    ctx->r10 = ctx->r9 | 0X30;
    // 0x80388A0C: jal         0x80140D20
    // 0x80388A10: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
    guRandom(rdram, ctx);
        goto after_5;
    // 0x80388A10: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
    after_5:
    // 0x80388A14: lw          $t5, 0x0($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X0);
    // 0x80388A18: andi        $t3, $v0, 0xF
    ctx->r11 = ctx->r2 & 0XF;
    // 0x80388A1C: addiu       $t4, $t3, 0x5A
    ctx->r12 = ADD32(ctx->r11, 0X5A);
    // 0x80388A20: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x80388A24: lw          $t6, 0x0($s1)
    ctx->r14 = MEM_W(ctx->r17, 0X0);
    // 0x80388A28: b           L_80388AF8
    // 0x80388A2C: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
        goto L_80388AF8;
    // 0x80388A2C: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
L_80388A30:
    // 0x80388A30: lw          $t7, 0x2C4($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X2C4);
    // 0x80388A34: slti        $at, $t7, 0x3D
    ctx->r1 = SIGNED(ctx->r15) < 0X3D ? 1 : 0;
    // 0x80388A38: beql        $at, $zero, L_80388AFC
    if (ctx->r1 == 0) {
        // 0x80388A3C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388AFC;
    }
    goto skip_3;
    // 0x80388A3C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80388A40: lh          $t8, 0x2D0($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388A44: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80388A48: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388A4C: slti        $at, $t8, 0x96
    ctx->r1 = SIGNED(ctx->r24) < 0X96 ? 1 : 0;
    // 0x80388A50: beq         $at, $zero, L_80388A88
    if (ctx->r1 == 0) {
        // 0x80388A54: nop
    
            goto L_80388A88;
    }
    // 0x80388A54: nop

    // 0x80388A58: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388A5C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388A60: jal         0x80363EDC
    // 0x80388A64: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_6;
    // 0x80388A64: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_6:
    // 0x80388A68: lw          $t9, 0x0($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X0);
    // 0x80388A6C: sw          $zero, 0x2B8($t9)
    MEM_W(0X2B8, ctx->r25) = 0;
    // 0x80388A70: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388A74: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388A78: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x80388A7C: ori         $t2, $t1, 0x40
    ctx->r10 = ctx->r9 | 0X40;
    // 0x80388A80: b           L_80388AF8
    // 0x80388A84: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
        goto L_80388AF8;
    // 0x80388A84: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
L_80388A88:
    // 0x80388A88: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388A8C: jal         0x80363E88
    // 0x80388A90: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80388A90: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80388A94: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388A98: lbu         $t3, 0x2B4($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388A9C: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80388AA0: ori         $t5, $t4, 0x20
    ctx->r13 = ctx->r12 | 0X20;
    // 0x80388AA4: b           L_80388AF8
    // 0x80388AA8: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
        goto L_80388AF8;
    // 0x80388AA8: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
L_80388AAC:
    // 0x80388AAC: lh          $t6, 0x2D0($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388AB0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388AB4: slti        $at, $t6, 0xAB
    ctx->r1 = SIGNED(ctx->r14) < 0XAB ? 1 : 0;
    // 0x80388AB8: beq         $at, $zero, L_80388AD8
    if (ctx->r1 == 0) {
        // 0x80388ABC: nop
    
            goto L_80388AD8;
    }
    // 0x80388ABC: nop

    // 0x80388AC0: lw          $v0, 0x2B8($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B8);
    // 0x80388AC4: slti        $v1, $v0, 0x3D
    ctx->r3 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    // 0x80388AC8: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x80388ACC: bne         $v1, $zero, L_80388AF8
    if (ctx->r3 != 0) {
        // 0x80388AD0: sw          $t7, 0x2B8($s0)
        MEM_W(0X2B8, ctx->r16) = ctx->r15;
            goto L_80388AF8;
    }
    // 0x80388AD0: sw          $t7, 0x2B8($s0)
    MEM_W(0X2B8, ctx->r16) = ctx->r15;
    // 0x80388AD4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
L_80388AD8:
    // 0x80388AD8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388ADC: jal         0x80363E88
    // 0x80388AE0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_8;
    // 0x80388AE0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_8:
    // 0x80388AE4: lw          $s0, 0x0($s1)
    ctx->r16 = MEM_W(ctx->r17, 0X0);
    // 0x80388AE8: lbu         $t8, 0x2B4($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388AEC: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80388AF0: ori         $t0, $t9, 0x20
    ctx->r8 = ctx->r25 | 0X20;
    // 0x80388AF4: sb          $t0, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r8;
L_80388AF8:
    // 0x80388AF8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388AFC:
    // 0x80388AFC: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x80388B00: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x80388B04: jr          $ra
    // 0x80388B08: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x80388B08: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void perform_behavior_hyena(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388B0C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80388B10: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80388B14: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388B18: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80388B1C: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80388B20: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80388B24: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80388B28: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x80388B2C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388B30: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80388B34: beq         $t6, $zero, L_80388B50
    if (ctx->r14 == 0) {
        // 0x80388B38: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80388B50;
    }
    // 0x80388B38: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388B3C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80388B40: beql        $t6, $a2, L_80388B94
    if (ctx->r14 == ctx->r6) {
        // 0x80388B44: lw          $v0, 0x2C0($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X2C0);
            goto L_80388B94;
    }
    goto skip_0;
    // 0x80388B44: lw          $v0, 0x2C0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C0);
    skip_0:
    // 0x80388B48: b           L_80388CB8
    // 0x80388B4C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80388CB8;
    // 0x80388B4C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388B50:
    // 0x80388B50: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80388B54: jal         0x80363CE0
    // 0x80388B58: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388B58: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80388B5C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388B60: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80388B64: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x80388B68: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x80388B6C: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388B70: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80388B74: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80388B78: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80388B7C: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80388B80: lw          $t1, 0x552C($t1)
    ctx->r9 = MEM_W(ctx->r9, 0X552C);
    // 0x80388B84: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388B88: sw          $t0, 0x2C0($t1)
    MEM_W(0X2C0, ctx->r9) = ctx->r8;
    // 0x80388B8C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80388B90: lw          $v0, 0x2C0($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2C0);
L_80388B94:
    // 0x80388B94: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80388B98: addiu       $v1, $v1, 0x5530
    ctx->r3 = ADD32(ctx->r3, 0X5530);
    // 0x80388B9C: bne         $v0, $zero, L_80388BD8
    if (ctx->r2 != 0) {
        // 0x80388BA0: nop
    
            goto L_80388BD8;
    }
    // 0x80388BA0: nop

    // 0x80388BA4: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388BA8: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80388BAC: slti        $at, $t2, 0xA1
    ctx->r1 = SIGNED(ctx->r10) < 0XA1 ? 1 : 0;
    // 0x80388BB0: bnel        $at, $zero, L_80388C84
    if (ctx->r1 != 0) {
        // 0x80388BB4: lw          $t9, 0x2C4($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388C84;
    }
    goto skip_1;
    // 0x80388BB4: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
    skip_1:
    // 0x80388BB8: sw          $a2, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r6;
    // 0x80388BBC: lw          $t3, 0x552C($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X552C);
    // 0x80388BC0: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80388BC4: jal         0x80363E88
    // 0x80388BC8: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80388BC8: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_1:
    // 0x80388BCC: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388BD0: b           L_80388C80
    // 0x80388BD4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
        goto L_80388C80;
    // 0x80388BD4: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80388BD8:
    // 0x80388BD8: bnel        $a2, $v0, L_80388C54
    if (ctx->r6 != ctx->r2) {
        // 0x80388BDC: lh          $t7, 0x2D0($s0)
        ctx->r15 = MEM_H(ctx->r16, 0X2D0);
            goto L_80388C54;
    }
    goto skip_2;
    // 0x80388BDC: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
    skip_2:
    // 0x80388BE0: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388BE4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80388BE8: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80388BEC: slti        $at, $v0, 0x64
    ctx->r1 = SIGNED(ctx->r2) < 0X64 ? 1 : 0;
    // 0x80388BF0: beql        $at, $zero, L_80388C1C
    if (ctx->r1 == 0) {
        // 0x80388BF4: slti        $at, $v0, 0xB5
        ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
            goto L_80388C1C;
    }
    goto skip_3;
    // 0x80388BF4: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
    skip_3:
    // 0x80388BF8: sw          $zero, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = 0;
    // 0x80388BFC: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80388C00: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80388C04: jal         0x80363EDC
    // 0x80388C08: lw          $a2, 0x2CC($t4)
    ctx->r6 = MEM_W(ctx->r12, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_2;
    // 0x80388C08: lw          $a2, 0x2CC($t4)
    ctx->r6 = MEM_W(ctx->r12, 0X2CC);
    after_2:
    // 0x80388C0C: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388C10: b           L_80388C80
    // 0x80388C14: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
        goto L_80388C80;
    // 0x80388C14: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80388C18: slti        $at, $v0, 0xB5
    ctx->r1 = SIGNED(ctx->r2) < 0XB5 ? 1 : 0;
L_80388C1C:
    // 0x80388C1C: bne         $at, $zero, L_80388C80
    if (ctx->r1 != 0) {
        // 0x80388C20: addiu       $t5, $zero, 0x2
        ctx->r13 = ADD32(0, 0X2);
            goto L_80388C80;
    }
    // 0x80388C20: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x80388C24: sw          $t5, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r13;
    // 0x80388C28: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80388C2C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80388C30: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80388C34: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388C38: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388C3C: jal         0x80363CE0
    // 0x80388C40: lw          $a1, 0x2CC($t6)
    ctx->r5 = MEM_W(ctx->r14, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_3;
    // 0x80388C40: lw          $a1, 0x2CC($t6)
    ctx->r5 = MEM_W(ctx->r14, 0X2CC);
    after_3:
    // 0x80388C44: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388C48: b           L_80388C80
    // 0x80388C4C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
        goto L_80388C80;
    // 0x80388C4C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
    // 0x80388C50: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
L_80388C54:
    // 0x80388C54: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80388C58: slti        $at, $t7, 0xA0
    ctx->r1 = SIGNED(ctx->r15) < 0XA0 ? 1 : 0;
    // 0x80388C5C: beql        $at, $zero, L_80388C84
    if (ctx->r1 == 0) {
        // 0x80388C60: lw          $t9, 0x2C4($s0)
        ctx->r25 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388C84;
    }
    goto skip_4;
    // 0x80388C60: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80388C64: sw          $a2, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r6;
    // 0x80388C68: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80388C6C: lw          $a0, 0x0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X0);
    // 0x80388C70: jal         0x80363E88
    // 0x80388C74: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_4;
    // 0x80388C74: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_4:
    // 0x80388C78: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x80388C7C: lw          $s0, 0x552C($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X552C);
L_80388C80:
    // 0x80388C80: lw          $t9, 0x2C4($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C4);
L_80388C84:
    // 0x80388C84: bgtzl       $t9, L_80388CB8
    if (SIGNED(ctx->r25) > 0) {
        // 0x80388C88: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388CB8;
    }
    goto skip_5;
    // 0x80388C88: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80388C8C: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388C90: slti        $at, $t0, 0xC9
    ctx->r1 = SIGNED(ctx->r8) < 0XC9 ? 1 : 0;
    // 0x80388C94: beql        $at, $zero, L_80388CB8
    if (ctx->r1 == 0) {
        // 0x80388C98: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388CB8;
    }
    goto skip_6;
    // 0x80388C98: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_6:
    // 0x80388C9C: jal         0x8035A590
    // 0x80388CA0: addiu       $a0, $zero, 0x10E
    ctx->r4 = ADD32(0, 0X10E);
    func_8035A590_76BC40(rdram, ctx);
        goto after_5;
    // 0x80388CA0: addiu       $a0, $zero, 0x10E
    ctx->r4 = ADD32(0, 0X10E);
    after_5:
    // 0x80388CA4: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80388CA8: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x80388CAC: addiu       $t1, $zero, 0x1E0
    ctx->r9 = ADD32(0, 0X1E0);
    // 0x80388CB0: sw          $t1, 0x2C4($t2)
    MEM_W(0X2C4, ctx->r10) = ctx->r9;
    // 0x80388CB4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388CB8:
    // 0x80388CB8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80388CBC: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80388CC0: jr          $ra
    // 0x80388CC4: nop

    return;
    // 0x80388CC4: nop

;}
RECOMP_FUNC void perform_behavior_hyena_biker(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388CC8: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80388CCC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388CD0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388CD4: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80388CD8: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388CDC: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80388CE0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80388CE4: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80388CE8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388CEC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388CF0: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80388CF4: beq         $t6, $zero, L_80388D1C
    if (ctx->r14 == 0) {
        // 0x80388CF8: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80388D1C;
    }
    // 0x80388CF8: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388CFC: beq         $t6, $at, L_80388D50
    if (ctx->r14 == ctx->r1) {
        // 0x80388D00: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80388D50;
    }
    // 0x80388D00: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80388D04: beq         $t6, $at, L_80388D90
    if (ctx->r14 == ctx->r1) {
        // 0x80388D08: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80388D90;
    }
    // 0x80388D08: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80388D0C: beql        $t6, $at, L_80388EA0
    if (ctx->r14 == ctx->r1) {
        // 0x80388D10: lh          $t3, 0x2D0($s0)
        ctx->r11 = MEM_H(ctx->r16, 0X2D0);
            goto L_80388EA0;
    }
    goto skip_0;
    // 0x80388D10: lh          $t3, 0x2D0($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80388D14: b           L_80388F00
    // 0x80388D18: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80388F00;
    // 0x80388D18: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388D1C:
    // 0x80388D1C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388D20: jal         0x80363CE0
    // 0x80388D24: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388D24: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80388D28: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388D2C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388D30: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388D34: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388D38: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80388D3C: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80388D40: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x80388D44: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80388D48: sw          $zero, 0x2C0($t1)
    MEM_W(0X2C0, ctx->r9) = 0;
    // 0x80388D4C: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
L_80388D50:
    // 0x80388D50: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388D54: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388D58: slti        $at, $t2, 0x1F5
    ctx->r1 = SIGNED(ctx->r10) < 0X1F5 ? 1 : 0;
    // 0x80388D5C: beql        $at, $zero, L_80388F00
    if (ctx->r1 == 0) {
        // 0x80388D60: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388F00;
    }
    goto skip_1;
    // 0x80388D60: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x80388D64: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388D68: jal         0x80363E88
    // 0x80388D6C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80388D6C: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x80388D70: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388D74: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388D78: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388D7C: lbu         $t3, 0x2B4($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388D80: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80388D84: ori         $t5, $t4, 0x20
    ctx->r13 = ctx->r12 | 0X20;
    // 0x80388D88: b           L_80388EFC
    // 0x80388D8C: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
        goto L_80388EFC;
    // 0x80388D8C: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
L_80388D90:
    // 0x80388D90: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80388D94: blez        $v1, L_80388DA8
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80388D98: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_80388DA8;
    }
    // 0x80388D98: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x80388D9C: sw          $t6, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r14;
    // 0x80388DA0: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388DA4: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
L_80388DA8:
    // 0x80388DA8: bne         $v1, $zero, L_80388DF4
    if (ctx->r3 != 0) {
        // 0x80388DAC: nop
    
            goto L_80388DF4;
    }
    // 0x80388DAC: nop

    // 0x80388DB0: lh          $t7, 0x2D0($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388DB4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388DB8: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80388DBC: slti        $at, $t7, 0x227
    ctx->r1 = SIGNED(ctx->r15) < 0X227 ? 1 : 0;
    // 0x80388DC0: bne         $at, $zero, L_80388DF4
    if (ctx->r1 != 0) {
        // 0x80388DC4: addiu       $a3, $zero, 0xA
        ctx->r7 = ADD32(0, 0XA);
            goto L_80388DF4;
    }
    // 0x80388DC4: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x80388DC8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388DCC: jal         0x80363CE0
    // 0x80388DD0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80388DD0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_2:
    // 0x80388DD4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388DD8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388DDC: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388DE0: lbu         $t8, 0x2B4($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388DE4: andi        $t9, $t8, 0xFF0F
    ctx->r25 = ctx->r24 & 0XFF0F;
    // 0x80388DE8: ori         $t1, $t9, 0x10
    ctx->r9 = ctx->r25 | 0X10;
    // 0x80388DEC: b           L_80388EFC
    // 0x80388DF0: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
        goto L_80388EFC;
    // 0x80388DF0: sb          $t1, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r9;
L_80388DF4:
    // 0x80388DF4: bnel        $v1, $zero, L_80388E44
    if (ctx->r3 != 0) {
        // 0x80388DF8: lw          $t6, 0x2C4($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388E44;
    }
    goto skip_2;
    // 0x80388DF8: lw          $t6, 0x2C4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X2C4);
    skip_2:
    // 0x80388DFC: lh          $t2, 0x2D0($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X2D0);
    // 0x80388E00: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388E04: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80388E08: slti        $at, $t2, 0x12C
    ctx->r1 = SIGNED(ctx->r10) < 0X12C ? 1 : 0;
    // 0x80388E0C: beql        $at, $zero, L_80388E44
    if (ctx->r1 == 0) {
        // 0x80388E10: lw          $t6, 0x2C4($s0)
        ctx->r14 = MEM_W(ctx->r16, 0X2C4);
            goto L_80388E44;
    }
    goto skip_3;
    // 0x80388E10: lw          $t6, 0x2C4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X2C4);
    skip_3:
    // 0x80388E14: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388E18: jal         0x80363EDC
    // 0x80388E1C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_3;
    // 0x80388E1C: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80388E20: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388E24: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388E28: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388E2C: lbu         $t3, 0x2B4($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388E30: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80388E34: ori         $t5, $t4, 0x30
    ctx->r13 = ctx->r12 | 0X30;
    // 0x80388E38: b           L_80388EFC
    // 0x80388E3C: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
        goto L_80388EFC;
    // 0x80388E3C: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
    // 0x80388E40: lw          $t6, 0x2C4($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X2C4);
L_80388E44:
    // 0x80388E44: bgtzl       $t6, L_80388F00
    if (SIGNED(ctx->r14) > 0) {
        // 0x80388E48: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388F00;
    }
    goto skip_4;
    // 0x80388E48: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_4:
    // 0x80388E4C: jal         0x80383830
    // 0x80388E50: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    target_within_current_fov(rdram, ctx);
        goto after_4;
    // 0x80388E50: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    after_4:
    // 0x80388E54: beql        $v0, $zero, L_80388F00
    if (ctx->r2 == 0) {
        // 0x80388E58: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_80388F00;
    }
    goto skip_5;
    // 0x80388E58: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x80388E5C: jal         0x80140D20
    // 0x80388E60: nop

    guRandom(rdram, ctx);
        goto after_5;
    // 0x80388E60: nop

    after_5:
    // 0x80388E64: sra         $t7, $v0, 8
    ctx->r15 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80388E68: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x80388E6C: div         $zero, $t7, $at
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r1)));
    // 0x80388E70: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388E74: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388E78: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x80388E7C: mfhi        $t8
    ctx->r24 = hi;
    // 0x80388E80: addiu       $t9, $t8, 0x14
    ctx->r25 = ADD32(ctx->r24, 0X14);
    // 0x80388E84: sw          $t9, 0x2C4($t1)
    MEM_W(0X2C4, ctx->r9) = ctx->r25;
    // 0x80388E88: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80388E8C: jal         0x8035A420
    // 0x80388E90: lw          $a0, 0x2CC($t2)
    ctx->r4 = MEM_W(ctx->r10, 0X2CC);
    biker_hyena_fire_missile(rdram, ctx);
        goto after_6;
    // 0x80388E90: lw          $a0, 0x2CC($t2)
    ctx->r4 = MEM_W(ctx->r10, 0X2CC);
    after_6:
    // 0x80388E94: b           L_80388F00
    // 0x80388E98: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_80388F00;
    // 0x80388E98: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80388E9C: lh          $t3, 0x2D0($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X2D0);
L_80388EA0:
    // 0x80388EA0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388EA4: slti        $at, $t3, 0x15F
    ctx->r1 = SIGNED(ctx->r11) < 0X15F ? 1 : 0;
    // 0x80388EA8: beq         $at, $zero, L_80388EC8
    if (ctx->r1 == 0) {
        // 0x80388EAC: nop
    
            goto L_80388EC8;
    }
    // 0x80388EAC: nop

    // 0x80388EB0: lw          $v1, 0x2C0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X2C0);
    // 0x80388EB4: slti        $v0, $v1, 0x47
    ctx->r2 = SIGNED(ctx->r3) < 0X47 ? 1 : 0;
    // 0x80388EB8: addiu       $t4, $v1, 0x1
    ctx->r12 = ADD32(ctx->r3, 0X1);
    // 0x80388EBC: bne         $v0, $zero, L_80388EFC
    if (ctx->r2 != 0) {
        // 0x80388EC0: sw          $t4, 0x2C0($s0)
        MEM_W(0X2C0, ctx->r16) = ctx->r12;
            goto L_80388EFC;
    }
    // 0x80388EC0: sw          $t4, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r12;
    // 0x80388EC4: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
L_80388EC8:
    // 0x80388EC8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388ECC: jal         0x80363E88
    // 0x80388ED0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_7;
    // 0x80388ED0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_7:
    // 0x80388ED4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388ED8: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388EDC: lw          $s0, 0x0($t0)
    ctx->r16 = MEM_W(ctx->r8, 0X0);
    // 0x80388EE0: addiu       $t8, $zero, 0x46
    ctx->r24 = ADD32(0, 0X46);
    // 0x80388EE4: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80388EE8: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x80388EEC: ori         $t7, $t6, 0x20
    ctx->r15 = ctx->r14 | 0X20;
    // 0x80388EF0: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x80388EF4: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x80388EF8: sw          $t8, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = ctx->r24;
L_80388EFC:
    // 0x80388EFC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80388F00:
    // 0x80388F00: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80388F04: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80388F08: jr          $ra
    // 0x80388F0C: nop

    return;
    // 0x80388F0C: nop

;}
RECOMP_FUNC void perform_behavior_chameleon(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80388F10: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388F14: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388F18: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80388F1C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80388F20: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80388F24: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x80388F28: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388F2C: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x80388F30: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80388F34: beq         $t6, $zero, L_80388F58
    if (ctx->r14 == 0) {
        // 0x80388F38: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80388F58;
    }
    // 0x80388F38: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388F3C: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80388F40: beq         $t6, $a2, L_80388F88
    if (ctx->r14 == ctx->r6) {
        // 0x80388F44: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80388F88;
    }
    // 0x80388F44: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80388F48: beql        $t6, $at, L_803890E0
    if (ctx->r14 == ctx->r1) {
        // 0x80388F4C: lh          $t1, 0x2D0($v1)
        ctx->r9 = MEM_H(ctx->r3, 0X2D0);
            goto L_803890E0;
    }
    goto skip_0;
    // 0x80388F4C: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
    skip_0:
    // 0x80388F50: b           L_80389144
    // 0x80388F54: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80389144;
    // 0x80388F54: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80388F58:
    // 0x80388F58: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388F5C: jal         0x80363CE0
    // 0x80388F60: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80388F60: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_0:
    // 0x80388F64: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388F68: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388F6C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80388F70: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80388F74: lbu         $t7, 0x2B4($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80388F78: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80388F7C: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x80388F80: sb          $t9, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r25;
    // 0x80388F84: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_80388F88:
    // 0x80388F88: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80388F8C: slti        $at, $v0, 0x32
    ctx->r1 = SIGNED(ctx->r2) < 0X32 ? 1 : 0;
    // 0x80388F90: beql        $at, $zero, L_80388FD4
    if (ctx->r1 == 0) {
        // 0x80388F94: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80388FD4;
    }
    goto skip_1;
    // 0x80388F94: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_1:
    // 0x80388F98: lw          $t1, 0x2C0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2C0);
    // 0x80388F9C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388FA0: bnel        $t1, $zero, L_80388FD4
    if (ctx->r9 != 0) {
        // 0x80388FA4: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80388FD4;
    }
    goto skip_2;
    // 0x80388FA4: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_2:
    // 0x80388FA8: sw          $a2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r6;
    // 0x80388FAC: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x80388FB0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388FB4: jal         0x80363E88
    // 0x80388FB8: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_1;
    // 0x80388FB8: lw          $a1, 0x2CC($t2)
    ctx->r5 = MEM_W(ctx->r10, 0X2CC);
    after_1:
    // 0x80388FBC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80388FC0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80388FC4: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80388FC8: b           L_80389018
    // 0x80388FCC: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
        goto L_80389018;
    // 0x80388FCC: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
    // 0x80388FD0: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_80388FD4:
    // 0x80388FD4: bnel        $at, $zero, L_8038901C
    if (ctx->r1 != 0) {
        // 0x80388FD8: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_8038901C;
    }
    goto skip_3;
    // 0x80388FD8: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_3:
    // 0x80388FDC: lw          $t3, 0x2C0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2C0);
    // 0x80388FE0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80388FE4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80388FE8: bnel        $a2, $t3, L_8038901C
    if (ctx->r6 != ctx->r11) {
        // 0x80388FEC: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_8038901C;
    }
    goto skip_4;
    // 0x80388FEC: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_4:
    // 0x80388FF0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80388FF4: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    // 0x80388FF8: jal         0x80363CE0
    // 0x80388FFC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    set_nav_state_chase_target(rdram, ctx);
        goto after_2;
    // 0x80388FFC: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    after_2:
    // 0x80389000: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80389004: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80389008: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8038900C: sw          $zero, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = 0;
    // 0x80389010: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80389014: lh          $v0, 0x2D0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X2D0);
L_80389018:
    // 0x80389018: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_8038901C:
    // 0x8038901C: beql        $at, $zero, L_80389090
    if (ctx->r1 == 0) {
        // 0x80389020: lw          $t3, 0x2BC($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X2BC);
            goto L_80389090;
    }
    goto skip_5;
    // 0x80389020: lw          $t3, 0x2BC($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2BC);
    skip_5:
    // 0x80389024: lw          $t5, 0x2C4($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2C4);
    // 0x80389028: bgtzl       $t5, L_80389090
    if (SIGNED(ctx->r13) > 0) {
        // 0x8038902C: lw          $t3, 0x2BC($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X2BC);
            goto L_80389090;
    }
    goto skip_6;
    // 0x8038902C: lw          $t3, 0x2BC($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2BC);
    skip_6:
    // 0x80389030: lw          $t6, 0x2BC($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X2BC);
    // 0x80389034: slti        $at, $t6, 0x3
    ctx->r1 = SIGNED(ctx->r14) < 0X3 ? 1 : 0;
    // 0x80389038: beql        $at, $zero, L_80389090
    if (ctx->r1 == 0) {
        // 0x8038903C: lw          $t3, 0x2BC($v1)
        ctx->r11 = MEM_W(ctx->r3, 0X2BC);
            goto L_80389090;
    }
    goto skip_7;
    // 0x8038903C: lw          $t3, 0x2BC($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2BC);
    skip_7:
    // 0x80389040: jal         0x8035C10C
    // 0x80389044: nop

    chameleon_attack_2(rdram, ctx);
        goto after_3;
    // 0x80389044: nop

    after_3:
    // 0x80389048: jal         0x80140D20
    // 0x8038904C: nop

    guRandom(rdram, ctx);
        goto after_4;
    // 0x8038904C: nop

    after_4:
    // 0x80389050: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80389054: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80389058: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8038905C: bgez        $v0, L_80389070
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80389060: andi        $t7, $v0, 0x7
        ctx->r15 = ctx->r2 & 0X7;
            goto L_80389070;
    }
    // 0x80389060: andi        $t7, $v0, 0x7
    ctx->r15 = ctx->r2 & 0X7;
    // 0x80389064: beq         $t7, $zero, L_80389070
    if (ctx->r15 == 0) {
        // 0x80389068: nop
    
            goto L_80389070;
    }
    // 0x80389068: nop

    // 0x8038906C: addiu       $t7, $t7, -0x8
    ctx->r15 = ADD32(ctx->r15, -0X8);
L_80389070:
    // 0x80389070: addiu       $t8, $t7, 0x9
    ctx->r24 = ADD32(ctx->r15, 0X9);
    // 0x80389074: sw          $t8, 0x2C4($t9)
    MEM_W(0X2C4, ctx->r25) = ctx->r24;
    // 0x80389078: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x8038907C: lw          $t1, 0x2BC($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2BC);
    // 0x80389080: addiu       $t2, $t1, 0x1
    ctx->r10 = ADD32(ctx->r9, 0X1);
    // 0x80389084: b           L_80389140
    // 0x80389088: sw          $t2, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r10;
        goto L_80389140;
    // 0x80389088: sw          $t2, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r10;
    // 0x8038908C: lw          $t3, 0x2BC($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2BC);
L_80389090:
    // 0x80389090: slti        $at, $t3, 0x3
    ctx->r1 = SIGNED(ctx->r11) < 0X3 ? 1 : 0;
    // 0x80389094: bnel        $at, $zero, L_80389144
    if (ctx->r1 != 0) {
        // 0x80389098: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80389144;
    }
    goto skip_8;
    // 0x80389098: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_8:
    // 0x8038909C: lbu         $t4, 0x2B4($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803890A0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803890A4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803890A8: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x803890AC: ori         $t6, $t5, 0x20
    ctx->r14 = ctx->r13 | 0X20;
    // 0x803890B0: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
    // 0x803890B4: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x803890B8: sw          $zero, 0x2BC($t7)
    MEM_W(0X2BC, ctx->r15) = 0;
    // 0x803890BC: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x803890C0: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
    // 0x803890C4: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x803890C8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803890CC: jal         0x80363EDC
    // 0x803890D0: lw          $a2, 0x2CC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_5;
    // 0x803890D0: lw          $a2, 0x2CC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0X2CC);
    after_5:
    // 0x803890D4: b           L_80389144
    // 0x803890D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80389144;
    // 0x803890D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803890DC: lh          $t1, 0x2D0($v1)
    ctx->r9 = MEM_H(ctx->r3, 0X2D0);
L_803890E0:
    // 0x803890E0: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x803890E4: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803890E8: slti        $at, $t1, 0xC9
    ctx->r1 = SIGNED(ctx->r9) < 0XC9 ? 1 : 0;
    // 0x803890EC: beq         $at, $zero, L_8038910C
    if (ctx->r1 == 0) {
        // 0x803890F0: nop
    
            goto L_8038910C;
    }
    // 0x803890F0: nop

    // 0x803890F4: lw          $a0, 0x2C0($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2C0);
    // 0x803890F8: slti        $v0, $a0, 0x5A
    ctx->r2 = SIGNED(ctx->r4) < 0X5A ? 1 : 0;
    // 0x803890FC: addiu       $t2, $a0, 0x1
    ctx->r10 = ADD32(ctx->r4, 0X1);
    // 0x80389100: bne         $v0, $zero, L_80389140
    if (ctx->r2 != 0) {
        // 0x80389104: sw          $t2, 0x2C0($v1)
        MEM_W(0X2C0, ctx->r3) = ctx->r10;
            goto L_80389140;
    }
    // 0x80389104: sw          $t2, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r10;
    // 0x80389108: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
L_8038910C:
    // 0x8038910C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389110: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389114: jal         0x80363CE0
    // 0x80389118: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_6;
    // 0x80389118: lw          $a1, 0x2CC($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X2CC);
    after_6:
    // 0x8038911C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80389120: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80389124: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x80389128: sw          $zero, 0x2C0($t3)
    MEM_W(0X2C0, ctx->r11) = 0;
    // 0x8038912C: lw          $v1, 0x0($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X0);
    // 0x80389130: lbu         $t4, 0x2B4($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X2B4);
    // 0x80389134: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x80389138: ori         $t6, $t5, 0x10
    ctx->r14 = ctx->r13 | 0X10;
    // 0x8038913C: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
L_80389140:
    // 0x80389140: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80389144:
    // 0x80389144: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80389148: jr          $ra
    // 0x8038914C: nop

    return;
    // 0x8038914C: nop

;}
RECOMP_FUNC void perform_behavior_sneaky_chameleon(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389150: jr          $ra
    // 0x80389154: nop

    return;
    // 0x80389154: nop

;}
RECOMP_FUNC void perform_behavior_evo(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389158: jr          $ra
    // 0x8038915C: nop

    return;
    // 0x8038915C: nop

;}
RECOMP_FUNC void perform_behavior_king_penguin(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389160: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80389164: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80389168: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8038916C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80389170: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389174: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80389178: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038917C: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80389180: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389184: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80389188: beq         $t6, $zero, L_803891A8
    if (ctx->r14 == 0) {
        // 0x8038918C: nop
    
            goto L_803891A8;
    }
    // 0x8038918C: nop

    // 0x80389190: beq         $t6, $at, L_803891D4
    if (ctx->r14 == ctx->r1) {
        // 0x80389194: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803891D4;
    }
    // 0x80389194: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80389198: beql        $t6, $at, L_8038925C
    if (ctx->r14 == ctx->r1) {
        // 0x8038919C: lh          $t9, 0x2D0($s0)
        ctx->r25 = MEM_H(ctx->r16, 0X2D0);
            goto L_8038925C;
    }
    goto skip_0;
    // 0x8038919C: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x803891A0: b           L_803892C4
    // 0x803891A4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_803892C4;
    // 0x803891A4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803891A8:
    // 0x803891A8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803891AC: jal         0x80363E88
    // 0x803891B0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_0;
    // 0x803891B0: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x803891B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803891B8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803891BC: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x803891C0: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803891C4: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x803891C8: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x803891CC: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x803891D0: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
L_803891D4:
    // 0x803891D4: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x803891D8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803891DC: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803891E0: slti        $at, $t0, 0xFB
    ctx->r1 = SIGNED(ctx->r8) < 0XFB ? 1 : 0;
    // 0x803891E4: beql        $at, $zero, L_80389224
    if (ctx->r1 == 0) {
        // 0x803891E8: lw          $t5, 0x2C4($s0)
        ctx->r13 = MEM_W(ctx->r16, 0X2C4);
            goto L_80389224;
    }
    goto skip_1;
    // 0x803891E8: lw          $t5, 0x2C4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X2C4);
    skip_1:
    // 0x803891EC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803891F0: jal         0x80363EDC
    // 0x803891F4: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_1;
    // 0x803891F4: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_1:
    // 0x803891F8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803891FC: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389200: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x80389204: sw          $zero, 0x2C0($t1)
    MEM_W(0X2C0, ctx->r9) = 0;
    // 0x80389208: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x8038920C: lbu         $t2, 0x2B4($s0)
    ctx->r10 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80389210: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80389214: ori         $t4, $t3, 0x20
    ctx->r12 = ctx->r11 | 0X20;
    // 0x80389218: b           L_803892C0
    // 0x8038921C: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
        goto L_803892C0;
    // 0x8038921C: sb          $t4, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r12;
    // 0x80389220: lw          $t5, 0x2C4($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X2C4);
L_80389224:
    // 0x80389224: bgtzl       $t5, L_803892C4
    if (SIGNED(ctx->r13) > 0) {
        // 0x80389228: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803892C4;
    }
    goto skip_2;
    // 0x80389228: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_2:
    // 0x8038922C: lb          $t6, 0x2B5($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X2B5);
    // 0x80389230: blezl       $t6, L_803892C4
    if (SIGNED(ctx->r14) <= 0) {
        // 0x80389234: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803892C4;
    }
    goto skip_3;
    // 0x80389234: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80389238: jal         0x80365E70
    // 0x8038923C: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    func_80365E70_777520(rdram, ctx);
        goto after_2;
    // 0x8038923C: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    after_2:
    // 0x80389240: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80389244: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389248: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x8038924C: addiu       $t7, $zero, 0xFA
    ctx->r15 = ADD32(0, 0XFA);
    // 0x80389250: b           L_803892C0
    // 0x80389254: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
        goto L_803892C0;
    // 0x80389254: sw          $t7, 0x2C4($t8)
    MEM_W(0X2C4, ctx->r24) = ctx->r15;
    // 0x80389258: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
L_8038925C:
    // 0x8038925C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389260: slti        $at, $t9, 0x191
    ctx->r1 = SIGNED(ctx->r25) < 0X191 ? 1 : 0;
    // 0x80389264: bnel        $at, $zero, L_8038929C
    if (ctx->r1 != 0) {
        // 0x80389268: lw          $t3, 0x2C4($s0)
        ctx->r11 = MEM_W(ctx->r16, 0X2C4);
            goto L_8038929C;
    }
    goto skip_4;
    // 0x80389268: lw          $t3, 0x2C4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x8038926C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389270: jal         0x80363E88
    // 0x80389274: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_3;
    // 0x80389274: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_3:
    // 0x80389278: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038927C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389280: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389284: lbu         $t0, 0x2B4($s0)
    ctx->r8 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80389288: andi        $t1, $t0, 0xFF0F
    ctx->r9 = ctx->r8 & 0XFF0F;
    // 0x8038928C: ori         $t2, $t1, 0x10
    ctx->r10 = ctx->r9 | 0X10;
    // 0x80389290: b           L_803892C0
    // 0x80389294: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
        goto L_803892C0;
    // 0x80389294: sb          $t2, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r10;
    // 0x80389298: lw          $t3, 0x2C4($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X2C4);
L_8038929C:
    // 0x8038929C: bgtzl       $t3, L_803892C4
    if (SIGNED(ctx->r11) > 0) {
        // 0x803892A0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_803892C4;
    }
    goto skip_5;
    // 0x803892A0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803892A4: jal         0x80365E70
    // 0x803892A8: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    func_80365E70_777520(rdram, ctx);
        goto after_4;
    // 0x803892A8: addiu       $a0, $zero, 0x78
    ctx->r4 = ADD32(0, 0X78);
    after_4:
    // 0x803892AC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803892B0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803892B4: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x803892B8: addiu       $t4, $zero, 0xFA
    ctx->r12 = ADD32(0, 0XFA);
    // 0x803892BC: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
L_803892C0:
    // 0x803892C0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_803892C4:
    // 0x803892C4: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803892C8: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x803892CC: jr          $ra
    // 0x803892D0: nop

    return;
    // 0x803892D0: nop

;}
RECOMP_FUNC void perform_behavior_racing_tortoise_defending(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803892D4: jr          $ra
    // 0x803892D8: nop

    return;
    // 0x803892D8: nop

;}
RECOMP_FUNC void perform_behavior_polar_bear_defending(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803892DC: jr          $ra
    // 0x803892E0: nop

    return;
    // 0x803892E0: nop

;}
RECOMP_FUNC void perform_behavior_hard_mouse(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803892E4: jr          $ra
    // 0x803892E8: nop

    return;
    // 0x803892E8: nop

;}
RECOMP_FUNC void perform_behavior_vulture(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803892EC: jr          $ra
    // 0x803892F0: nop

    return;
    // 0x803892F0: nop

;}
RECOMP_FUNC void perform_behavior_seagull(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803892F4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803892F8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803892FC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80389300: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80389304: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80389308: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8038930C: lw          $t6, 0x2B4($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2B4);
    // 0x80389310: srl         $t7, $t6, 28
    ctx->r15 = S32(U32(ctx->r14) >> 28);
    // 0x80389314: sltiu       $at, $t7, 0x5
    ctx->r1 = ctx->r15 < 0X5 ? 1 : 0;
    // 0x80389318: beq         $at, $zero, L_80389508
    if (ctx->r1 == 0) {
        // 0x8038931C: sll         $t7, $t7, 2
        ctx->r15 = S32(ctx->r15 << 2);
            goto L_80389508;
    }
    // 0x8038931C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x80389320: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80389324: addu        $at, $at, $t7
    gpr jr_addend_8038932C = ctx->r15;
    ctx->r1 = ADD32(ctx->r1, ctx->r15);
    // 0x80389328: lw          $t7, -0xB90($at)
    ctx->r15 = ADD32(ctx->r1, -0XB90);
    // 0x8038932C: jr          $t7
    // 0x80389330: nop

    switch (jr_addend_8038932C >> 2) {
        case 0: goto L_80389334; break;
        case 1: goto L_80389380; break;
        case 2: goto L_803893C4; break;
        case 3: goto L_80389410; break;
        case 4: goto L_80389490; break;
        default: switch_error(__func__, 0x8038932C, 0x803BF470);
    }
    // 0x80389330: nop

L_80389334:
    // 0x80389334: lw          $s0, 0x2CC($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X2CC);
    // 0x80389338: addiu       $t9, $zero, -0x50
    ctx->r25 = ADD32(0, -0X50);
    // 0x8038933C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389340: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x80389344: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389348: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x8038934C: subu        $a2, $t9, $t8
    ctx->r6 = SUB32(ctx->r25, ctx->r24);
    // 0x80389350: sll         $t0, $a2, 16
    ctx->r8 = S32(ctx->r6 << 16);
    // 0x80389354: sra         $a2, $t0, 16
    ctx->r6 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80389358: jal         0x80363CE0
    // 0x8038935C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x8038935C: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    after_0:
    // 0x80389360: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80389364: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389368: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x8038936C: lbu         $t2, 0x2B4($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80389370: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80389374: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x80389378: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x8038937C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
L_80389380:
    // 0x80389380: lh          $t5, 0x2D0($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2D0);
    // 0x80389384: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389388: slti        $at, $t5, 0x2
    ctx->r1 = SIGNED(ctx->r13) < 0X2 ? 1 : 0;
    // 0x8038938C: beql        $at, $zero, L_8038950C
    if (ctx->r1 == 0) {
        // 0x80389390: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038950C;
    }
    goto skip_0;
    // 0x80389390: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_0:
    // 0x80389394: jal         0x80363CC8
    // 0x80389398: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_1;
    // 0x80389398: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_1:
    // 0x8038939C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803893A0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803893A4: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803893A8: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803893AC: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x803893B0: ori         $t9, $t7, 0x20
    ctx->r25 = ctx->r15 | 0X20;
    // 0x803893B4: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x803893B8: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803893BC: b           L_80389508
    // 0x803893C0: sw          $zero, 0x2B8($t8)
    MEM_W(0X2B8, ctx->r24) = 0;
        goto L_80389508;
    // 0x803893C0: sw          $zero, 0x2B8($t8)
    MEM_W(0X2B8, ctx->r24) = 0;
L_803893C4:
    // 0x803893C4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803893C8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803893CC: lw          $s0, 0x2CC($v0)
    ctx->r16 = MEM_W(ctx->r2, 0X2CC);
    // 0x803893D0: lh          $t1, 0xC($t0)
    ctx->r9 = MEM_H(ctx->r8, 0XC);
    // 0x803893D4: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x803893D8: lhu         $t4, 0x42($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X42);
    // 0x803893DC: subu        $t3, $t1, $t2
    ctx->r11 = SUB32(ctx->r9, ctx->r10);
    // 0x803893E0: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x803893E4: slti        $at, $t5, 0xA
    ctx->r1 = SIGNED(ctx->r13) < 0XA ? 1 : 0;
    // 0x803893E8: beql        $at, $zero, L_8038950C
    if (ctx->r1 == 0) {
        // 0x803893EC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038950C;
    }
    goto skip_1;
    // 0x803893EC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803893F0: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x803893F4: addiu       $t8, $zero, 0x5B
    ctx->r24 = ADD32(0, 0X5B);
    // 0x803893F8: andi        $t7, $t6, 0xFF0F
    ctx->r15 = ctx->r14 & 0XFF0F;
    // 0x803893FC: ori         $t9, $t7, 0x30
    ctx->r25 = ctx->r15 | 0X30;
    // 0x80389400: sb          $t9, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r25;
    // 0x80389404: lw          $t0, 0x0($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X0);
    // 0x80389408: b           L_80389508
    // 0x8038940C: sw          $t8, 0x2C4($t0)
    MEM_W(0X2C4, ctx->r8) = ctx->r24;
        goto L_80389508;
    // 0x8038940C: sw          $t8, 0x2C4($t0)
    MEM_W(0X2C4, ctx->r8) = ctx->r24;
L_80389410:
    // 0x80389410: lw          $a0, 0x2C4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2C4);
    // 0x80389414: slti        $at, $a0, 0x3C
    ctx->r1 = SIGNED(ctx->r4) < 0X3C ? 1 : 0;
    // 0x80389418: beql        $at, $zero, L_80389470
    if (ctx->r1 == 0) {
        // 0x8038941C: addiu       $at, $zero, 0xF
        ctx->r1 = ADD32(0, 0XF);
            goto L_80389470;
    }
    goto skip_2;
    // 0x8038941C: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
    skip_2:
    // 0x80389420: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80389424: addiu       $t7, $zero, -0x50
    ctx->r15 = ADD32(0, -0X50);
    // 0x80389428: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038942C: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x80389430: ori         $t3, $t2, 0x40
    ctx->r11 = ctx->r10 | 0X40;
    // 0x80389434: sb          $t3, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r11;
    // 0x80389438: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x8038943C: sw          $zero, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = 0;
    // 0x80389440: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x80389444: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389448: lw          $s0, 0x2CC($t5)
    ctx->r16 = MEM_W(ctx->r13, 0X2CC);
    // 0x8038944C: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x80389450: or          $a2, $s0, $zero
    ctx->r6 = ctx->r16 | 0;
    // 0x80389454: subu        $a1, $t7, $t6
    ctx->r5 = SUB32(ctx->r15, ctx->r14);
    // 0x80389458: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x8038945C: jal         0x80363EDC
    // 0x80389460: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    func_80363EDC_77558C(rdram, ctx);
        goto after_2;
    // 0x80389460: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    after_2:
    // 0x80389464: b           L_8038950C
    // 0x80389468: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038950C;
    // 0x80389468: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8038946C: addiu       $at, $zero, 0xF
    ctx->r1 = ADD32(0, 0XF);
L_80389470:
    // 0x80389470: div         $zero, $a0, $at
    lo = S32(S64(S32(ctx->r4)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r4)) % S64(S32(ctx->r1)));
    // 0x80389474: mfhi        $t0
    ctx->r8 = hi;
    // 0x80389478: bnel        $t0, $zero, L_8038950C
    if (ctx->r8 != 0) {
        // 0x8038947C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038950C;
    }
    goto skip_3;
    // 0x8038947C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_3:
    // 0x80389480: jal         0x80381F14
    // 0x80389484: nop

    func_80381F14_7935C4(rdram, ctx);
        goto after_3;
    // 0x80389484: nop

    after_3:
    // 0x80389488: b           L_8038950C
    // 0x8038948C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038950C;
    // 0x8038948C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80389490:
    // 0x80389490: lh          $t1, 0x2D0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X2D0);
    // 0x80389494: slti        $at, $t1, 0xC9
    ctx->r1 = SIGNED(ctx->r9) < 0XC9 ? 1 : 0;
    // 0x80389498: beql        $at, $zero, L_803894C4
    if (ctx->r1 == 0) {
        // 0x8038949C: lbu         $t5, 0x2B4($v0)
        ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
            goto L_803894C4;
    }
    goto skip_4;
    // 0x8038949C: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    skip_4:
    // 0x803894A0: lw          $t2, 0x2C0($v0)
    ctx->r10 = MEM_W(ctx->r2, 0X2C0);
    // 0x803894A4: addiu       $t3, $t2, 0x1
    ctx->r11 = ADD32(ctx->r10, 0X1);
    // 0x803894A8: sw          $t3, 0x2C0($v0)
    MEM_W(0X2C0, ctx->r2) = ctx->r11;
    // 0x803894AC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803894B0: lw          $t4, 0x2C0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X2C0);
    // 0x803894B4: slti        $at, $t4, 0x79
    ctx->r1 = SIGNED(ctx->r12) < 0X79 ? 1 : 0;
    // 0x803894B8: bnel        $at, $zero, L_8038950C
    if (ctx->r1 != 0) {
        // 0x803894BC: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038950C;
    }
    goto skip_5;
    // 0x803894BC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803894C0: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
L_803894C4:
    // 0x803894C4: addiu       $t1, $zero, -0x50
    ctx->r9 = ADD32(0, -0X50);
    // 0x803894C8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803894CC: andi        $t7, $t5, 0xFF0F
    ctx->r15 = ctx->r13 & 0XFF0F;
    // 0x803894D0: ori         $t6, $t7, 0x10
    ctx->r14 = ctx->r15 | 0X10;
    // 0x803894D4: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x803894D8: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x803894DC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803894E0: sw          $zero, 0x2C0($t9)
    MEM_W(0X2C0, ctx->r25) = 0;
    // 0x803894E4: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803894E8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803894EC: lw          $s0, 0x2CC($t8)
    ctx->r16 = MEM_W(ctx->r24, 0X2CC);
    // 0x803894F0: lhu         $t0, 0x42($s0)
    ctx->r8 = MEM_HU(ctx->r16, 0X42);
    // 0x803894F4: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x803894F8: subu        $a2, $t1, $t0
    ctx->r6 = SUB32(ctx->r9, ctx->r8);
    // 0x803894FC: sll         $t2, $a2, 16
    ctx->r10 = S32(ctx->r6 << 16);
    // 0x80389500: jal         0x80363CE0
    // 0x80389504: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    set_nav_state_chase_target(rdram, ctx);
        goto after_4;
    // 0x80389504: sra         $a2, $t2, 16
    ctx->r6 = S32(SIGNED(ctx->r10) >> 16);
    after_4:
L_80389508:
    // 0x80389508: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038950C:
    // 0x8038950C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80389510: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80389514: jr          $ra
    // 0x80389518: nop

    return;
    // 0x80389518: nop

;}
RECOMP_FUNC void perform_behavior_seagull2(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038951C: jr          $ra
    // 0x80389520: nop

    return;
    // 0x80389520: nop

;}
RECOMP_FUNC void perform_behavior_pirana(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389524: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80389528: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038952C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389530: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80389534: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389538: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8038953C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80389540: lw          $v0, 0x2B4($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X2B4);
    // 0x80389544: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389548: addiu       $a2, $zero, -0x1
    ctx->r6 = ADD32(0, -0X1);
    // 0x8038954C: srl         $t6, $v0, 28
    ctx->r14 = S32(U32(ctx->r2) >> 28);
    // 0x80389550: beq         $t6, $zero, L_80389578
    if (ctx->r14 == 0) {
        // 0x80389554: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80389578;
    }
    // 0x80389554: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80389558: beq         $t6, $at, L_803895A4
    if (ctx->r14 == ctx->r1) {
        // 0x8038955C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_803895A4;
    }
    // 0x8038955C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80389560: beq         $t6, $at, L_8038960C
    if (ctx->r14 == ctx->r1) {
        // 0x80389564: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8038960C;
    }
    // 0x80389564: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80389568: beql        $t6, $at, L_803896E0
    if (ctx->r14 == ctx->r1) {
        // 0x8038956C: lh          $t9, 0x2D0($s0)
        ctx->r25 = MEM_H(ctx->r16, 0X2D0);
            goto L_803896E0;
    }
    goto skip_0;
    // 0x8038956C: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
    skip_0:
    // 0x80389570: b           L_8038973C
    // 0x80389574: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038973C;
    // 0x80389574: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_80389578:
    // 0x80389578: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038957C: jal         0x80363CE0
    // 0x80389580: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_0;
    // 0x80389580: lw          $a1, 0x2CC($s0)
    ctx->r5 = MEM_W(ctx->r16, 0X2CC);
    after_0:
    // 0x80389584: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80389588: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8038958C: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389590: lbu         $t7, 0x2B4($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X2B4);
    // 0x80389594: andi        $t8, $t7, 0xFF0F
    ctx->r24 = ctx->r15 & 0XFF0F;
    // 0x80389598: ori         $t9, $t8, 0x10
    ctx->r25 = ctx->r24 | 0X10;
    // 0x8038959C: sb          $t9, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r25;
    // 0x803895A0: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
L_803895A4:
    // 0x803895A4: lh          $t0, 0x2D0($s0)
    ctx->r8 = MEM_H(ctx->r16, 0X2D0);
    // 0x803895A8: slti        $at, $t0, 0x28
    ctx->r1 = SIGNED(ctx->r8) < 0X28 ? 1 : 0;
    // 0x803895AC: beql        $at, $zero, L_8038973C
    if (ctx->r1 == 0) {
        // 0x803895B0: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038973C;
    }
    goto skip_1;
    // 0x803895B0: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_1:
    // 0x803895B4: jal         0x80382CC0
    // 0x803895B8: addiu       $a0, $zero, 0x96
    ctx->r4 = ADD32(0, 0X96);
    func_80382CC0_794370(rdram, ctx);
        goto after_1;
    // 0x803895B8: addiu       $a0, $zero, 0x96
    ctx->r4 = ADD32(0, 0X96);
    after_1:
    // 0x803895BC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803895C0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803895C4: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x803895C8: addiu       $t4, $zero, 0x96
    ctx->r12 = ADD32(0, 0X96);
    // 0x803895CC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x803895D0: lbu         $t1, 0x2B4($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803895D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803895D8: andi        $t2, $t1, 0xFF0F
    ctx->r10 = ctx->r9 & 0XFF0F;
    // 0x803895DC: ori         $t3, $t2, 0x20
    ctx->r11 = ctx->r10 | 0X20;
    // 0x803895E0: sb          $t3, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r11;
    // 0x803895E4: lw          $t5, 0x0($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X0);
    // 0x803895E8: sw          $t4, 0x2C4($t5)
    MEM_W(0X2C4, ctx->r13) = ctx->r12;
    // 0x803895EC: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x803895F0: sw          $t6, 0x2C0($t7)
    MEM_W(0X2C0, ctx->r15) = ctx->r14;
    // 0x803895F4: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803895F8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803895FC: jal         0x80363E88
    // 0x80389600: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_2;
    // 0x80389600: lw          $a1, 0x2CC($t8)
    ctx->r5 = MEM_W(ctx->r24, 0X2CC);
    after_2:
    // 0x80389604: b           L_8038973C
    // 0x80389608: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
        goto L_8038973C;
    // 0x80389608: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038960C:
    // 0x8038960C: lh          $v0, 0x2D0($s0)
    ctx->r2 = MEM_H(ctx->r16, 0X2D0);
    // 0x80389610: slti        $at, $v0, 0x1E
    ctx->r1 = SIGNED(ctx->r2) < 0X1E ? 1 : 0;
    // 0x80389614: beql        $at, $zero, L_80389658
    if (ctx->r1 == 0) {
        // 0x80389618: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80389658;
    }
    goto skip_2;
    // 0x80389618: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_2:
    // 0x8038961C: lw          $t9, 0x2C0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X2C0);
    // 0x80389620: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80389624: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389628: bnel        $t9, $zero, L_80389658
    if (ctx->r25 != 0) {
        // 0x8038962C: slti        $at, $v0, 0x3D
        ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
            goto L_80389658;
    }
    goto skip_3;
    // 0x8038962C: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
    skip_3:
    // 0x80389630: sw          $t0, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r8;
    // 0x80389634: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x80389638: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038963C: jal         0x80363E88
    // 0x80389640: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    set_nav_state_follow_target(rdram, ctx);
        goto after_3;
    // 0x80389640: lw          $a1, 0x2CC($t1)
    ctx->r5 = MEM_W(ctx->r9, 0X2CC);
    after_3:
    // 0x80389644: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80389648: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8038964C: b           L_80389694
    // 0x80389650: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
        goto L_80389694;
    // 0x80389650: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389654: slti        $at, $v0, 0x3D
    ctx->r1 = SIGNED(ctx->r2) < 0X3D ? 1 : 0;
L_80389658:
    // 0x80389658: bnel        $at, $zero, L_80389698
    if (ctx->r1 != 0) {
        // 0x8038965C: lw          $t4, 0x2C4($s0)
        ctx->r12 = MEM_W(ctx->r16, 0X2C4);
            goto L_80389698;
    }
    goto skip_4;
    // 0x8038965C: lw          $t4, 0x2C4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C4);
    skip_4:
    // 0x80389660: lw          $t2, 0x2C0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C0);
    // 0x80389664: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389668: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038966C: beq         $t2, $zero, L_80389694
    if (ctx->r10 == 0) {
        // 0x80389670: addiu       $a3, $zero, 0x10
        ctx->r7 = ADD32(0, 0X10);
            goto L_80389694;
    }
    // 0x80389670: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x80389674: sw          $zero, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = 0;
    // 0x80389678: lw          $t3, 0x0($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X0);
    // 0x8038967C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389680: jal         0x80363CE0
    // 0x80389684: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_4;
    // 0x80389684: lw          $a1, 0x2CC($t3)
    ctx->r5 = MEM_W(ctx->r11, 0X2CC);
    after_4:
    // 0x80389688: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038968C: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80389690: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
L_80389694:
    // 0x80389694: lw          $t4, 0x2C4($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X2C4);
L_80389698:
    // 0x80389698: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038969C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803896A0: bgtzl       $t4, L_8038973C
    if (SIGNED(ctx->r12) > 0) {
        // 0x803896A4: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038973C;
    }
    goto skip_5;
    // 0x803896A4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_5:
    // 0x803896A8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803896AC: jal         0x80363EDC
    // 0x803896B0: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    func_80363EDC_77558C(rdram, ctx);
        goto after_5;
    // 0x803896B0: lw          $a2, 0x2CC($s0)
    ctx->r6 = MEM_W(ctx->r16, 0X2CC);
    after_5:
    // 0x803896B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803896B8: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803896BC: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x803896C0: lbu         $t5, 0x2B4($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X2B4);
    // 0x803896C4: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x803896C8: ori         $t7, $t6, 0x30
    ctx->r15 = ctx->r14 | 0X30;
    // 0x803896CC: sb          $t7, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r15;
    // 0x803896D0: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x803896D4: b           L_80389738
    // 0x803896D8: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
        goto L_80389738;
    // 0x803896D8: sw          $zero, 0x2BC($t8)
    MEM_W(0X2BC, ctx->r24) = 0;
    // 0x803896DC: lh          $t9, 0x2D0($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X2D0);
L_803896E0:
    // 0x803896E0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803896E4: slti        $at, $t9, 0xC8
    ctx->r1 = SIGNED(ctx->r25) < 0XC8 ? 1 : 0;
    // 0x803896E8: beql        $at, $zero, L_80389714
    if (ctx->r1 == 0) {
        // 0x803896EC: lbu         $t3, 0x2B4($s0)
        ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
            goto L_80389714;
    }
    goto skip_6;
    // 0x803896EC: lbu         $t3, 0x2B4($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
    skip_6:
    // 0x803896F0: lw          $t0, 0x2C0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X2C0);
    // 0x803896F4: addiu       $t1, $t0, 0x1
    ctx->r9 = ADD32(ctx->r8, 0X1);
    // 0x803896F8: sw          $t1, 0x2C0($s0)
    MEM_W(0X2C0, ctx->r16) = ctx->r9;
    // 0x803896FC: lw          $s0, 0x0($v1)
    ctx->r16 = MEM_W(ctx->r3, 0X0);
    // 0x80389700: lw          $t2, 0x2C0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X2C0);
    // 0x80389704: slti        $at, $t2, 0x5B
    ctx->r1 = SIGNED(ctx->r10) < 0X5B ? 1 : 0;
    // 0x80389708: bnel        $at, $zero, L_8038973C
    if (ctx->r1 != 0) {
        // 0x8038970C: lw          $ra, 0x1C($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X1C);
            goto L_8038973C;
    }
    goto skip_7;
    // 0x8038970C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    skip_7:
    // 0x80389710: lbu         $t3, 0x2B4($s0)
    ctx->r11 = MEM_BU(ctx->r16, 0X2B4);
L_80389714:
    // 0x80389714: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80389718: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x8038971C: andi        $t4, $t3, 0xFF0F
    ctx->r12 = ctx->r11 & 0XFF0F;
    // 0x80389720: ori         $t5, $t4, 0x10
    ctx->r13 = ctx->r12 | 0X10;
    // 0x80389724: sb          $t5, 0x2B4($s0)
    MEM_B(0X2B4, ctx->r16) = ctx->r13;
    // 0x80389728: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x8038972C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80389730: jal         0x80363CE0
    // 0x80389734: lw          $a1, 0x2CC($t6)
    ctx->r5 = MEM_W(ctx->r14, 0X2CC);
    set_nav_state_chase_target(rdram, ctx);
        goto after_6;
    // 0x80389734: lw          $a1, 0x2CC($t6)
    ctx->r5 = MEM_W(ctx->r14, 0X2CC);
    after_6:
L_80389738:
    // 0x80389738: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
L_8038973C:
    // 0x8038973C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80389740: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x80389744: jr          $ra
    // 0x80389748: nop

    return;
    // 0x80389748: nop

;}
RECOMP_FUNC void perform_behavior_crow(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038974C: jr          $ra
    // 0x80389750: nop

    return;
    // 0x80389750: nop

;}
RECOMP_FUNC void perform_behavior_crow_diver(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389754: jr          $ra
    // 0x80389758: nop

    return;
    // 0x80389758: nop

;}
RECOMP_FUNC void perform_behavior_cool_cod(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038975C: jr          $ra
    // 0x80389760: nop

    return;
    // 0x80389760: nop

;}
RECOMP_FUNC void func_80389764_79AE14(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389764: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80389768: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8038976C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80389770: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80389774: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80389778: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038977C: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80389780: sh          $t6, 0x63F0($at)
    MEM_H(0X63F0, ctx->r1) = ctx->r14;
    // 0x80389784: lhu         $t8, 0x9C($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X9C);
    // 0x80389788: lui         $at, 0x803B
    ctx->r1 = S32(0X803B << 16);
    // 0x8038978C: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x80389790: addu        $at, $at, $t9
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80389794: lw          $t9, 0x5D20($at)
    ctx->r25 = MEM_W(ctx->r1, 0X5D20);
    // 0x80389798: jalr        $t9
    // 0x8038979C: nop

    LOOKUP_FUNC(ctx->r25)(rdram, ctx);
        goto after_0;
    // 0x8038979C: nop

    after_0:
    // 0x803897A0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803897A4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803897A8: jr          $ra
    // 0x803897AC: nop

    return;
    // 0x803897AC: nop

;}
RECOMP_FUNC void func_803897B0_79AE60(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803897B0: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x803897B4: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x803897B8: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x803897BC: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x803897C0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x803897C4: bne         $a1, $t6, L_803897DC
    if (ctx->r5 != ctx->r14) {
        // 0x803897C8: sw          $a0, 0x28($sp)
        MEM_W(0X28, ctx->r29) = ctx->r4;
            goto L_803897DC;
    }
    // 0x803897C8: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x803897CC: addiu       $a3, $zero, 0xA
    ctx->r7 = ADD32(0, 0XA);
    // 0x803897D0: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    // 0x803897D4: b           L_803897E8
    // 0x803897D8: sh          $zero, 0x22($sp)
    MEM_H(0X22, ctx->r29) = 0;
        goto L_803897E8;
    // 0x803897D8: sh          $zero, 0x22($sp)
    MEM_H(0X22, ctx->r29) = 0;
L_803897DC:
    // 0x803897DC: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    // 0x803897E0: addiu       $a0, $zero, 0xF
    ctx->r4 = ADD32(0, 0XF);
    // 0x803897E4: sh          $a1, 0x22($sp)
    MEM_H(0X22, ctx->r29) = ctx->r5;
L_803897E8:
    // 0x803897E8: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x803897EC: addiu       $s0, $s0, 0x552C
    ctx->r16 = ADD32(ctx->r16, 0X552C);
    // 0x803897F0: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803897F4: lw          $v0, 0x2B4($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X2B4);
    // 0x803897F8: srl         $t7, $v0, 28
    ctx->r15 = S32(U32(ctx->r2) >> 28);
    // 0x803897FC: beq         $t7, $zero, L_8038981C
    if (ctx->r15 == 0) {
        // 0x80389800: nop
    
            goto L_8038981C;
    }
    // 0x80389800: nop

    // 0x80389804: beq         $t7, $a1, L_8038987C
    if (ctx->r15 == ctx->r5) {
        // 0x80389808: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8038987C;
    }
    // 0x80389808: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038980C: beql        $t7, $at, L_80389900
    if (ctx->r15 == ctx->r1) {
        // 0x80389810: lw          $t7, 0x2B8($v1)
        ctx->r15 = MEM_W(ctx->r3, 0X2B8);
            goto L_80389900;
    }
    goto skip_0;
    // 0x80389810: lw          $t7, 0x2B8($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2B8);
    skip_0:
    // 0x80389814: b           L_80389980
    // 0x80389818: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
        goto L_80389980;
    // 0x80389818: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
L_8038981C:
    // 0x8038981C: jal         0x80140D20
    // 0x80389820: sh          $a3, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r7;
    guRandom(rdram, ctx);
        goto after_0;
    // 0x80389820: sh          $a3, 0x26($sp)
    MEM_H(0X26, ctx->r29) = ctx->r7;
    after_0:
    // 0x80389824: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80389828: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038982C: mfhi        $a1
    ctx->r5 = hi;
    // 0x80389830: andi        $t8, $a1, 0xFFFF
    ctx->r24 = ctx->r5 & 0XFFFF;
    // 0x80389834: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389838: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038983C: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80389840: lh          $a3, 0x26($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X26);
    // 0x80389844: jal         0x80363FB8
    // 0x80389848: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    set_nav_state_scripted(rdram, ctx);
        goto after_1;
    // 0x80389848: addiu       $a2, $zero, -0xB4
    ctx->r6 = ADD32(0, -0XB4);
    after_1:
    // 0x8038984C: jal         0x80140D20
    // 0x80389850: nop

    guRandom(rdram, ctx);
        goto after_2;
    // 0x80389850: nop

    after_2:
    // 0x80389854: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80389858: andi        $t9, $v0, 0xF
    ctx->r25 = ctx->r2 & 0XF;
    // 0x8038985C: addiu       $t0, $t9, 0x14
    ctx->r8 = ADD32(ctx->r25, 0X14);
    // 0x80389860: sw          $t0, 0x2B8($t1)
    MEM_W(0X2B8, ctx->r9) = ctx->r8;
    // 0x80389864: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80389868: lbu         $t2, 0x2B4($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X2B4);
    // 0x8038986C: andi        $t3, $t2, 0xFF0F
    ctx->r11 = ctx->r10 & 0XFF0F;
    // 0x80389870: ori         $t4, $t3, 0x10
    ctx->r12 = ctx->r11 | 0X10;
    // 0x80389874: sb          $t4, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r12;
    // 0x80389878: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
L_8038987C:
    // 0x8038987C: lw          $t5, 0x2B8($v1)
    ctx->r13 = MEM_W(ctx->r3, 0X2B8);
    // 0x80389880: addiu       $t6, $t5, -0x1
    ctx->r14 = ADD32(ctx->r13, -0X1);
    // 0x80389884: sw          $t6, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r14;
    // 0x80389888: lw          $t7, 0x0($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X0);
    // 0x8038988C: lw          $t8, 0x2B8($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X2B8);
    // 0x80389890: bgtzl       $t8, L_80389980
    if (SIGNED(ctx->r24) > 0) {
        // 0x80389894: lh          $t7, 0x22($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X22);
            goto L_80389980;
    }
    goto skip_1;
    // 0x80389894: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
    skip_1:
    // 0x80389898: jal         0x80140D20
    // 0x8038989C: nop

    guRandom(rdram, ctx);
        goto after_3;
    // 0x8038989C: nop

    after_3:
    // 0x803898A0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803898A4: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x803898A8: mfhi        $a1
    ctx->r5 = hi;
    // 0x803898AC: andi        $t9, $a1, 0xFFFF
    ctx->r25 = ctx->r5 & 0XFFFF;
    // 0x803898B0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803898B4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803898B8: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x803898BC: addiu       $a2, $zero, -0x80
    ctx->r6 = ADD32(0, -0X80);
    // 0x803898C0: jal         0x80363FB8
    // 0x803898C4: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    set_nav_state_scripted(rdram, ctx);
        goto after_4;
    // 0x803898C4: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_4:
    // 0x803898C8: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x803898CC: jal         0x80140D20
    // 0x803898D0: sw          $zero, 0x2B8($t0)
    MEM_W(0X2B8, ctx->r8) = 0;
    guRandom(rdram, ctx);
        goto after_5;
    // 0x803898D0: sw          $zero, 0x2B8($t0)
    MEM_W(0X2B8, ctx->r8) = 0;
    after_5:
    // 0x803898D4: lw          $t3, 0x0($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X0);
    // 0x803898D8: andi        $t1, $v0, 0x3
    ctx->r9 = ctx->r2 & 0X3;
    // 0x803898DC: addiu       $t2, $t1, 0x4
    ctx->r10 = ADD32(ctx->r9, 0X4);
    // 0x803898E0: sw          $t2, 0x2BC($t3)
    MEM_W(0X2BC, ctx->r11) = ctx->r10;
    // 0x803898E4: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x803898E8: lbu         $t4, 0x2B4($v1)
    ctx->r12 = MEM_BU(ctx->r3, 0X2B4);
    // 0x803898EC: andi        $t5, $t4, 0xFF0F
    ctx->r13 = ctx->r12 & 0XFF0F;
    // 0x803898F0: ori         $t6, $t5, 0x20
    ctx->r14 = ctx->r13 | 0X20;
    // 0x803898F4: b           L_8038997C
    // 0x803898F8: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
        goto L_8038997C;
    // 0x803898F8: sb          $t6, 0x2B4($v1)
    MEM_B(0X2B4, ctx->r3) = ctx->r14;
    // 0x803898FC: lw          $t7, 0x2B8($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X2B8);
L_80389900:
    // 0x80389900: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x80389904: sw          $t8, 0x2B8($v1)
    MEM_W(0X2B8, ctx->r3) = ctx->r24;
    // 0x80389908: lw          $t9, 0x0($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X0);
    // 0x8038990C: lw          $t0, 0x2B8($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X2B8);
    // 0x80389910: slt         $at, $t0, $a0
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80389914: bnel        $at, $zero, L_80389980
    if (ctx->r1 != 0) {
        // 0x80389918: lh          $t7, 0x22($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X22);
            goto L_80389980;
    }
    goto skip_2;
    // 0x80389918: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
    skip_2:
    // 0x8038991C: jal         0x80140D20
    // 0x80389920: nop

    guRandom(rdram, ctx);
        goto after_6;
    // 0x80389920: nop

    after_6:
    // 0x80389924: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80389928: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8038992C: mfhi        $a1
    ctx->r5 = hi;
    // 0x80389930: andi        $t1, $a1, 0xFFFF
    ctx->r9 = ctx->r5 & 0XFFFF;
    // 0x80389934: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389938: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038993C: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80389940: addiu       $a2, $zero, -0x80
    ctx->r6 = ADD32(0, -0X80);
    // 0x80389944: jal         0x80363FB8
    // 0x80389948: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    set_nav_state_scripted(rdram, ctx);
        goto after_7;
    // 0x80389948: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    after_7:
    // 0x8038994C: lw          $t2, 0x0($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X0);
    // 0x80389950: sw          $zero, 0x2B8($t2)
    MEM_W(0X2B8, ctx->r10) = 0;
    // 0x80389954: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x80389958: lw          $t3, 0x2BC($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X2BC);
    // 0x8038995C: addiu       $t4, $t3, -0x1
    ctx->r12 = ADD32(ctx->r11, -0X1);
    // 0x80389960: sw          $t4, 0x2BC($v1)
    MEM_W(0X2BC, ctx->r3) = ctx->r12;
    // 0x80389964: lw          $t5, 0x0($s0)
    ctx->r13 = MEM_W(ctx->r16, 0X0);
    // 0x80389968: lw          $t6, 0x2BC($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X2BC);
    // 0x8038996C: bgtzl       $t6, L_80389980
    if (SIGNED(ctx->r14) > 0) {
        // 0x80389970: lh          $t7, 0x22($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X22);
            goto L_80389980;
    }
    goto skip_3;
    // 0x80389970: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
    skip_3:
    // 0x80389974: b           L_803899CC
    // 0x80389978: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803899CC;
    // 0x80389978: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8038997C:
    // 0x8038997C: lh          $t7, 0x22($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X22);
L_80389980:
    // 0x80389980: beql        $t7, $zero, L_803899CC
    if (ctx->r15 == 0) {
        // 0x80389984: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803899CC;
    }
    goto skip_4;
    // 0x80389984: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_4:
    // 0x80389988: lw          $v1, 0x0($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X0);
    // 0x8038998C: lw          $t8, 0x2C0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X2C0);
    // 0x80389990: addiu       $t9, $t8, -0x1
    ctx->r25 = ADD32(ctx->r24, -0X1);
    // 0x80389994: sw          $t9, 0x2C0($v1)
    MEM_W(0X2C0, ctx->r3) = ctx->r25;
    // 0x80389998: lw          $t0, 0x0($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X0);
    // 0x8038999C: lw          $t1, 0x2C0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X2C0);
    // 0x803899A0: bgtzl       $t1, L_803899CC
    if (SIGNED(ctx->r9) > 0) {
        // 0x803899A4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803899CC;
    }
    goto skip_5;
    // 0x803899A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_5:
    // 0x803899A8: jal         0x8030A958
    // 0x803899AC: nop

    animal_jump(rdram, ctx);
        goto after_8;
    // 0x803899AC: nop

    after_8:
    // 0x803899B0: jal         0x80140D20
    // 0x803899B4: nop

    guRandom(rdram, ctx);
        goto after_9;
    // 0x803899B4: nop

    after_9:
    // 0x803899B8: lw          $t4, 0x0($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X0);
    // 0x803899BC: andi        $t2, $v0, 0xF
    ctx->r10 = ctx->r2 & 0XF;
    // 0x803899C0: addiu       $t3, $t2, 0x46
    ctx->r11 = ADD32(ctx->r10, 0X46);
    // 0x803899C4: sw          $t3, 0x2C0($t4)
    MEM_W(0X2C0, ctx->r12) = ctx->r11;
    // 0x803899C8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803899CC:
    // 0x803899CC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x803899D0: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x803899D4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x803899D8: jr          $ra
    // 0x803899DC: nop

    return;
    // 0x803899DC: nop

;}
RECOMP_FUNC void func_803899E0_79B090(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803899E0: lw          $t6, 0x6C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X6C);
    // 0x803899E4: bne         $t6, $zero, L_80389B20
    if (ctx->r14 != 0) {
        // 0x803899E8: nop
    
            goto L_80389B20;
    }
    // 0x803899E8: nop

    // 0x803899EC: lbu         $t7, 0x160($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X160);
    // 0x803899F0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803899F4: bnel        $t7, $at, L_80389A4C
    if (ctx->r15 != ctx->r1) {
        // 0x803899F8: lh          $t7, 0x4($a0)
        ctx->r15 = MEM_H(ctx->r4, 0X4);
            goto L_80389A4C;
    }
    goto skip_0;
    // 0x803899F8: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
    skip_0:
    // 0x803899FC: lh          $t8, 0x4($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X4);
    // 0x80389A00: lh          $t1, 0x8($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X8);
    // 0x80389A04: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x80389A08: sra         $t9, $t8, 6
    ctx->r25 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80389A0C: sll         $t0, $t9, 7
    ctx->r8 = S32(ctx->r25 << 7);
    // 0x80389A10: addu        $t0, $t0, $t9
    ctx->r8 = ADD32(ctx->r8, ctx->r25);
    // 0x80389A14: sra         $t2, $t1, 6
    ctx->r10 = S32(SIGNED(ctx->r9) >> 6);
    // 0x80389A18: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x80389A1C: sll         $t0, $t0, 3
    ctx->r8 = S32(ctx->r8 << 3);
    // 0x80389A20: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x80389A24: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x80389A28: lbu         $t5, 0x743($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X743);
    // 0x80389A2C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x80389A30: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x80389A34: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x80389A38: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80389A3C: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x80389A40: b           L_80389A90
    // 0x80389A44: lb          $v0, 0x1D3B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X1D3B);
        goto L_80389A90;
    // 0x80389A44: lb          $v0, 0x1D3B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X1D3B);
    // 0x80389A48: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
L_80389A4C:
    // 0x80389A4C: lh          $t1, 0x8($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X8);
    // 0x80389A50: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x80389A54: sra         $t8, $t7, 6
    ctx->r24 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80389A58: sll         $t9, $t8, 7
    ctx->r25 = S32(ctx->r24 << 7);
    // 0x80389A5C: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80389A60: sra         $t2, $t1, 6
    ctx->r10 = S32(SIGNED(ctx->r9) >> 6);
    // 0x80389A64: sll         $t0, $t2, 3
    ctx->r8 = S32(ctx->r10 << 3);
    // 0x80389A68: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80389A6C: addu        $t3, $t9, $t0
    ctx->r11 = ADD32(ctx->r25, ctx->r8);
    // 0x80389A70: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x80389A74: lbu         $t4, 0x742($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X742);
    // 0x80389A78: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x80389A7C: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x80389A80: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x80389A84: sll         $t5, $t5, 2
    ctx->r13 = S32(ctx->r13 << 2);
    // 0x80389A88: addu        $v0, $v0, $t5
    ctx->r2 = ADD32(ctx->r2, ctx->r13);
    // 0x80389A8C: lb          $v0, 0x1D3B($v0)
    ctx->r2 = MEM_B(ctx->r2, 0X1D3B);
L_80389A90:
    // 0x80389A90: lb          $v1, 0x4E($a0)
    ctx->r3 = MEM_B(ctx->r4, 0X4E);
    // 0x80389A94: beq         $v0, $v1, L_80389B20
    if (ctx->r2 == ctx->r3) {
        // 0x80389A98: slt         $at, $v0, $v1
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
            goto L_80389B20;
    }
    // 0x80389A98: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80389A9C: beq         $at, $zero, L_80389B1C
    if (ctx->r1 == 0) {
        // 0x80389AA0: addiu       $t7, $v1, 0x1
        ctx->r15 = ADD32(ctx->r3, 0X1);
            goto L_80389B1C;
    }
    // 0x80389AA0: addiu       $t7, $v1, 0x1
    ctx->r15 = ADD32(ctx->r3, 0X1);
    // 0x80389AA4: lw          $v0, 0x1C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X1C);
    // 0x80389AA8: ori         $a2, $zero, 0x8001
    ctx->r6 = 0 | 0X8001;
    // 0x80389AAC: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x80389AB0: bgez        $v0, L_80389AC0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80389AB4: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_80389AC0;
    }
    // 0x80389AB4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80389AB8: b           L_80389AC0
    // 0x80389ABC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_80389AC0;
    // 0x80389ABC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_80389AC0:
    // 0x80389AC0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80389AC4: beq         $at, $zero, L_80389B14
    if (ctx->r1 == 0) {
        // 0x80389AC8: nop
    
            goto L_80389B14;
    }
    // 0x80389AC8: nop

    // 0x80389ACC: lw          $v0, 0x20($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X20);
    // 0x80389AD0: bgez        $v0, L_80389AE0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80389AD4: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_80389AE0;
    }
    // 0x80389AD4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80389AD8: b           L_80389AE0
    // 0x80389ADC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_80389AE0;
    // 0x80389ADC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_80389AE0:
    // 0x80389AE0: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80389AE4: beq         $at, $zero, L_80389B14
    if (ctx->r1 == 0) {
        // 0x80389AE8: nop
    
            goto L_80389B14;
    }
    // 0x80389AE8: nop

    // 0x80389AEC: lw          $v0, 0x24($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X24);
    // 0x80389AF0: lui         $at, 0x5
    ctx->r1 = S32(0X5 << 16);
    // 0x80389AF4: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x80389AF8: bgez        $v0, L_80389B08
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80389AFC: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_80389B08;
    }
    // 0x80389AFC: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80389B00: b           L_80389B08
    // 0x80389B04: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_80389B08;
    // 0x80389B04: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_80389B08:
    // 0x80389B08: slt         $at, $a1, $at
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x80389B0C: bne         $at, $zero, L_80389B20
    if (ctx->r1 != 0) {
        // 0x80389B10: nop
    
            goto L_80389B20;
    }
    // 0x80389B10: nop

L_80389B14:
    // 0x80389B14: jr          $ra
    // 0x80389B18: sb          $t6, 0x4E($a0)
    MEM_B(0X4E, ctx->r4) = ctx->r14;
    return;
    // 0x80389B18: sb          $t6, 0x4E($a0)
    MEM_B(0X4E, ctx->r4) = ctx->r14;
L_80389B1C:
    // 0x80389B1C: sb          $t7, 0x4E($a0)
    MEM_B(0X4E, ctx->r4) = ctx->r15;
L_80389B20:
    // 0x80389B20: jr          $ra
    // 0x80389B24: nop

    return;
    // 0x80389B24: nop

;}
RECOMP_FUNC void func_80389B30_79B1E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80389B30: addiu       $sp, $sp, -0x158
    ctx->r29 = ADD32(ctx->r29, -0X158);
    // 0x80389B34: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80389B38: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80389B3C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x80389B40: sw          $s1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r17;
    // 0x80389B44: sw          $s0, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r16;
    // 0x80389B48: lbu         $v0, 0x162($t6)
    ctx->r2 = MEM_BU(ctx->r14, 0X162);
    // 0x80389B4C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80389B50: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80389B54: beq         $v0, $at, L_80389B64
    if (ctx->r2 == ctx->r1) {
        // 0x80389B58: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80389B64;
    }
    // 0x80389B58: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80389B5C: bne         $v0, $at, L_80389B8C
    if (ctx->r2 != ctx->r1) {
        // 0x80389B60: nop
    
            goto L_80389B8C;
    }
    // 0x80389B60: nop

L_80389B64:
    // 0x80389B64: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x80389B68: addiu       $t7, $zero, 0x400
    ctx->r15 = ADD32(0, 0X400);
    // 0x80389B6C: lh          $v0, 0x2E0($t2)
    ctx->r2 = MEM_H(ctx->r10, 0X2E0);
    // 0x80389B70: addiu       $v0, $v0, 0x32
    ctx->r2 = ADD32(ctx->r2, 0X32);
    // 0x80389B74: slti        $at, $v0, 0x401
    ctx->r1 = SIGNED(ctx->r2) < 0X401 ? 1 : 0;
    // 0x80389B78: bnel        $at, $zero, L_80389B8C
    if (ctx->r1 != 0) {
        // 0x80389B7C: sh          $v0, 0x2E0($t2)
        MEM_H(0X2E0, ctx->r10) = ctx->r2;
            goto L_80389B8C;
    }
    goto skip_0;
    // 0x80389B7C: sh          $v0, 0x2E0($t2)
    MEM_H(0X2E0, ctx->r10) = ctx->r2;
    skip_0:
    // 0x80389B80: b           L_80389B8C
    // 0x80389B84: sh          $t7, 0x2E0($t2)
    MEM_H(0X2E0, ctx->r10) = ctx->r15;
        goto L_80389B8C;
    // 0x80389B84: sh          $t7, 0x2E0($t2)
    MEM_H(0X2E0, ctx->r10) = ctx->r15;
    // 0x80389B88: sh          $v0, 0x2E0($t2)
    MEM_H(0X2E0, ctx->r10) = ctx->r2;
L_80389B8C:
    // 0x80389B8C: jal         0x8034B298
    // 0x80389B90: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_0;
    // 0x80389B90: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_0:
    // 0x80389B94: jal         0x8035D120
    // 0x80389B98: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_1;
    // 0x80389B98: nop

    after_1:
    // 0x80389B9C: jal         0x8035DA60
    // 0x80389BA0: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_2;
    // 0x80389BA0: nop

    after_2:
    // 0x80389BA4: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80389BA8: addiu       $a0, $a0, 0x2EBC
    ctx->r4 = ADD32(ctx->r4, 0X2EBC);
    // 0x80389BAC: lw          $t8, 0x0($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X0);
    // 0x80389BB0: lui         $v0, 0xFFFF
    ctx->r2 = S32(0XFFFF << 16);
    // 0x80389BB4: lui         $a1, 0x803F
    ctx->r5 = S32(0X803F << 16);
    // 0x80389BB8: addiu       $a1, $a1, 0x2EC0
    ctx->r5 = ADD32(ctx->r5, 0X2EC0);
    // 0x80389BBC: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x80389BC0: lw          $t8, 0x0($a1)
    ctx->r24 = MEM_W(ctx->r5, 0X0);
    // 0x80389BC4: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80389BC8: lui         $v1, 0x1
    ctx->r3 = S32(0X1 << 16);
    // 0x80389BCC: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80389BD0: addiu       $a2, $a2, 0x2EC4
    ctx->r6 = ADD32(ctx->r6, 0X2EC4);
    // 0x80389BD4: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80389BD8: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x80389BDC: lw          $t8, 0x0($a2)
    ctx->r24 = MEM_W(ctx->r6, 0X0);
    // 0x80389BE0: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x80389BE4: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80389BE8: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80389BEC: addu        $t9, $t8, $v0
    ctx->r25 = ADD32(ctx->r24, ctx->r2);
    // 0x80389BF0: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x80389BF4: sra         $t6, $t9, 1
    ctx->r14 = S32(SIGNED(ctx->r25) >> 1);
    // 0x80389BF8: addu        $t7, $t6, $v1
    ctx->r15 = ADD32(ctx->r14, ctx->r3);
    // 0x80389BFC: jal         0x8035D734
    // 0x80389C00: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    func_8035D734_76EDE4(rdram, ctx);
        goto after_3;
    // 0x80389C00: sw          $t7, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r15;
    after_3:
    // 0x80389C04: lui         $s1, 0x803F
    ctx->r17 = S32(0X803F << 16);
    // 0x80389C08: addiu       $s1, $s1, 0x2ECE
    ctx->r17 = ADD32(ctx->r17, 0X2ECE);
    // 0x80389C0C: lhu         $v1, 0x0($s1)
    ctx->r3 = MEM_HU(ctx->r17, 0X0);
    // 0x80389C10: addiu       $s0, $sp, 0x148
    ctx->r16 = ADD32(ctx->r29, 0X148);
    // 0x80389C14: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80389C18: beq         $v1, $zero, L_80389C34
    if (ctx->r3 == 0) {
        // 0x80389C1C: or          $a0, $s0, $zero
        ctx->r4 = ctx->r16 | 0;
            goto L_80389C34;
    }
    // 0x80389C1C: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x80389C20: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
    // 0x80389C24: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x80389C28: bne         $at, $zero, L_80389C34
    if (ctx->r1 != 0) {
        // 0x80389C2C: slti        $at, $v1, 0x3
        ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
            goto L_80389C34;
    }
    // 0x80389C2C: slti        $at, $v1, 0x3
    ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
    // 0x80389C30: bne         $at, $zero, L_80389CC4
    if (ctx->r1 != 0) {
        // 0x80389C34: addiu       $t8, $zero, 0x15F
        ctx->r24 = ADD32(0, 0X15F);
            goto L_80389CC4;
    }
L_80389C34:
    // 0x80389C34: addiu       $t8, $zero, 0x15F
    ctx->r24 = ADD32(0, 0X15F);
    // 0x80389C38: addiu       $t9, $zero, 0x138
    ctx->r25 = ADD32(0, 0X138);
    // 0x80389C3C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80389C40: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80389C44: addiu       $a1, $zero, 0x222
    ctx->r5 = ADD32(0, 0X222);
    // 0x80389C48: addiu       $a2, $zero, 0x4C1
    ctx->r6 = ADD32(0, 0X4C1);
    // 0x80389C4C: jal         0x802BA220
    // 0x80389C50: addiu       $a3, $zero, 0x1FB
    ctx->r7 = ADD32(0, 0X1FB);
    func_802BA220_6CB8D0(rdram, ctx);
        goto after_4;
    // 0x80389C50: addiu       $a3, $zero, 0x1FB
    ctx->r7 = ADD32(0, 0X1FB);
    after_4:
    // 0x80389C54: lui         $t6, 0x803B
    ctx->r14 = S32(0X803B << 16);
    // 0x80389C58: lui         $t7, 0x803B
    ctx->r15 = S32(0X803B << 16);
    // 0x80389C5C: addiu       $t7, $t7, 0x5E90
    ctx->r15 = ADD32(ctx->r15, 0X5E90);
    // 0x80389C60: addiu       $t6, $t6, 0x5E60
    ctx->r14 = ADD32(ctx->r14, 0X5E60);
    // 0x80389C64: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80389C68: addiu       $a3, $a3, 0x5E30
    ctx->r7 = ADD32(ctx->r7, 0X5E30);
    // 0x80389C6C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80389C70: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80389C74: addiu       $a0, $zero, 0x29F
    ctx->r4 = ADD32(0, 0X29F);
    // 0x80389C78: addiu       $a1, $zero, 0x222
    ctx->r5 = ADD32(0, 0X222);
    // 0x80389C7C: addiu       $a2, $zero, 0x138
    ctx->r6 = ADD32(0, 0X138);
    // 0x80389C80: jal         0x802C353C
    // 0x80389C84: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    func_802C353C_6D4BEC(rdram, ctx);
        goto after_5;
    // 0x80389C84: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    after_5:
    // 0x80389C88: lui         $t8, 0x803B
    ctx->r24 = S32(0X803B << 16);
    // 0x80389C8C: addiu       $t8, $t8, 0x5F04
    ctx->r24 = ADD32(ctx->r24, 0X5F04);
    // 0x80389C90: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80389C94: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80389C98: addiu       $a3, $a3, 0x5ED4
    ctx->r7 = ADD32(ctx->r7, 0X5ED4);
    // 0x80389C9C: addiu       $a2, $a2, 0x5EA4
    ctx->r6 = ADD32(ctx->r6, 0X5EA4);
    // 0x80389CA0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80389CA4: addiu       $a0, $zero, 0x1D4
    ctx->r4 = ADD32(0, 0X1D4);
    // 0x80389CA8: jal         0x8031FE40
    // 0x80389CAC: addiu       $a1, $zero, 0x271
    ctx->r5 = ADD32(0, 0X271);
    update_limbs_evo(rdram, ctx);
        goto after_6;
    // 0x80389CAC: addiu       $a1, $zero, 0x271
    ctx->r5 = ADD32(0, 0X271);
    after_6:
    // 0x80389CB0: addiu       $a0, $zero, 0x138
    ctx->r4 = ADD32(0, 0X138);
    // 0x80389CB4: jal         0x802C6C00
    // 0x80389CB8: addiu       $a1, $zero, 0xEA
    ctx->r5 = ADD32(0, 0XEA);
    func_802C6C00_6D82B0(rdram, ctx);
        goto after_7;
    // 0x80389CB8: addiu       $a1, $zero, 0xEA
    ctx->r5 = ADD32(0, 0XEA);
    after_7:
    // 0x80389CBC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80389CC0: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_80389CC4:
    // 0x80389CC4: beq         $v0, $zero, L_80389D40
    if (ctx->r2 == 0) {
        // 0x80389CC8: nop
    
            goto L_80389D40;
    }
    // 0x80389CC8: nop

    // 0x80389CCC: jal         0x802DB8DC
    // 0x80389CD0: nop

    backup_joint_positions(rdram, ctx);
        goto after_8;
    // 0x80389CD0: nop

    after_8:
    // 0x80389CD4: lhu         $v1, 0x0($s1)
    ctx->r3 = MEM_HU(ctx->r17, 0X0);
    // 0x80389CD8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80389CDC: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80389CE0: beq         $v1, $at, L_80389CFC
    if (ctx->r3 == ctx->r1) {
        // 0x80389CE4: addiu       $a0, $a0, 0x5F18
        ctx->r4 = ADD32(ctx->r4, 0X5F18);
            goto L_80389CFC;
    }
    // 0x80389CE4: addiu       $a0, $a0, 0x5F18
    ctx->r4 = ADD32(ctx->r4, 0X5F18);
    // 0x80389CE8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80389CEC: beq         $v1, $at, L_80389D20
    if (ctx->r3 == ctx->r1) {
        // 0x80389CF0: lui         $a0, 0x803B
        ctx->r4 = S32(0X803B << 16);
            goto L_80389D20;
    }
    // 0x80389CF0: lui         $a0, 0x803B
    ctx->r4 = S32(0X803B << 16);
    // 0x80389CF4: b           L_80389D40
    // 0x80389CF8: nop

        goto L_80389D40;
    // 0x80389CF8: nop

L_80389CFC:
    // 0x80389CFC: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80389D00: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80389D04: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80389D08: addiu       $a3, $a3, 0x5F64
    ctx->r7 = ADD32(ctx->r7, 0X5F64);
    // 0x80389D0C: addiu       $a2, $a2, 0x5F40
    ctx->r6 = ADD32(ctx->r6, 0X5F40);
    // 0x80389D10: jal         0x802DB670
    // 0x80389D14: addiu       $a1, $a1, 0x5F2C
    ctx->r5 = ADD32(ctx->r5, 0X5F2C);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_9;
    // 0x80389D14: addiu       $a1, $a1, 0x5F2C
    ctx->r5 = ADD32(ctx->r5, 0X5F2C);
    after_9:
    // 0x80389D18: b           L_80389D40
    // 0x80389D1C: nop

        goto L_80389D40;
    // 0x80389D1C: nop

L_80389D20:
    // 0x80389D20: lui         $a1, 0x803B
    ctx->r5 = S32(0X803B << 16);
    // 0x80389D24: lui         $a2, 0x803B
    ctx->r6 = S32(0X803B << 16);
    // 0x80389D28: lui         $a3, 0x803B
    ctx->r7 = S32(0X803B << 16);
    // 0x80389D2C: addiu       $a3, $a3, 0x5FB0
    ctx->r7 = ADD32(ctx->r7, 0X5FB0);
    // 0x80389D30: addiu       $a2, $a2, 0x5F40
    ctx->r6 = ADD32(ctx->r6, 0X5F40);
    // 0x80389D34: addiu       $a1, $a1, 0x5F2C
    ctx->r5 = ADD32(ctx->r5, 0X5F2C);
    // 0x80389D38: jal         0x802DB670
    // 0x80389D3C: addiu       $a0, $a0, 0x5F18
    ctx->r4 = ADD32(ctx->r4, 0X5F18);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_10;
    // 0x80389D3C: addiu       $a0, $a0, 0x5F18
    ctx->r4 = ADD32(ctx->r4, 0X5F18);
    after_10:
L_80389D40:
    // 0x80389D40: jal         0x8038064C
    // 0x80389D44: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_11;
    // 0x80389D44: nop

    after_11:
    // 0x80389D48: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80389D4C: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80389D50: lui         $t1, 0x4
    ctx->r9 = S32(0X4 << 16);
    // 0x80389D54: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80389D58: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x80389D5C: lw          $t1, -0x76E8($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X76E8);
    // 0x80389D60: addiu       $t9, $t1, 0x1E
    ctx->r25 = ADD32(ctx->r9, 0X1E);
    // 0x80389D64: slti        $at, $t9, 0xFA
    ctx->r1 = SIGNED(ctx->r25) < 0XFA ? 1 : 0;
    // 0x80389D68: beq         $at, $zero, L_8038B230
    if (ctx->r1 == 0) {
        // 0x80389D6C: nop
    
            goto L_8038B230;
    }
    // 0x80389D6C: nop

    // 0x80389D70: lbu         $t6, 0x2EDA($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2EDA);
    // 0x80389D74: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80389D78: beq         $t6, $zero, L_8038B230
    if (ctx->r14 == 0) {
        // 0x80389D7C: nop
    
            goto L_8038B230;
    }
    // 0x80389D7C: nop

    // 0x80389D80: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80389D84: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80389D88: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80389D8C: bne         $a0, $zero, L_80389DC4
    if (ctx->r4 != 0) {
        // 0x80389D90: nop
    
            goto L_80389DC4;
    }
    // 0x80389D90: nop

    // 0x80389D94: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x80389D98: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80389D9C: beq         $v0, $zero, L_80389DC4
    if (ctx->r2 == 0) {
        // 0x80389DA0: nop
    
            goto L_80389DC4;
    }
    // 0x80389DA0: nop

    // 0x80389DA4: beq         $v0, $at, L_80389DC4
    if (ctx->r2 == ctx->r1) {
        // 0x80389DA8: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80389DC4;
    }
    // 0x80389DA8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80389DAC: bne         $v0, $at, L_8038B230
    if (ctx->r2 != ctx->r1) {
        // 0x80389DB0: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_8038B230;
    }
    // 0x80389DB0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80389DB4: lbu         $t7, 0x2AA3($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2AA3);
    // 0x80389DB8: slti        $at, $t7, 0xB
    ctx->r1 = SIGNED(ctx->r15) < 0XB ? 1 : 0;
    // 0x80389DBC: bne         $at, $zero, L_8038B230
    if (ctx->r1 != 0) {
        // 0x80389DC0: nop
    
            goto L_8038B230;
    }
    // 0x80389DC0: nop

L_80389DC4:
    // 0x80389DC4: lh          $t8, 0x2C18($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2C18);
    // 0x80389DC8: bne         $t8, $zero, L_80389E20
    if (ctx->r24 != 0) {
        // 0x80389DCC: nop
    
            goto L_80389E20;
    }
    // 0x80389DCC: nop

    // 0x80389DD0: beq         $a0, $zero, L_80389E20
    if (ctx->r4 == 0) {
        // 0x80389DD4: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_80389E20;
    }
    // 0x80389DD4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80389DD8: lh          $t9, 0x2A98($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2A98);
    // 0x80389DDC: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80389DE0: addiu       $t7, $t7, 0x28E0
    ctx->r15 = ADD32(ctx->r15, 0X28E0);
    // 0x80389DE4: sll         $t6, $t9, 3
    ctx->r14 = S32(ctx->r25 << 3);
    // 0x80389DE8: subu        $t6, $t6, $t9
    ctx->r14 = SUB32(ctx->r14, ctx->r25);
    // 0x80389DEC: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80389DF0: subu        $t6, $t6, $t9
    ctx->r14 = SUB32(ctx->r14, ctx->r25);
    // 0x80389DF4: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80389DF8: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x80389DFC: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x80389E00: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80389E04: beq         $v1, $at, L_80389E14
    if (ctx->r3 == ctx->r1) {
        // 0x80389E08: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_80389E14;
    }
    // 0x80389E08: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80389E0C: bne         $v1, $at, L_80389E20
    if (ctx->r3 != ctx->r1) {
        // 0x80389E10: nop
    
            goto L_80389E20;
    }
    // 0x80389E10: nop

L_80389E14:
    // 0x80389E14: lb          $t8, 0x64($v0)
    ctx->r24 = MEM_B(ctx->r2, 0X64);
    // 0x80389E18: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80389E1C: beq         $t8, $at, L_8038B230
    if (ctx->r24 == ctx->r1) {
        // 0x80389E20: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_8038B230;
    }
L_80389E20:
    // 0x80389E20: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80389E24: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80389E28: sll         $t9, $t1, 6
    ctx->r25 = S32(ctx->r9 << 6);
    // 0x80389E2C: addu        $a0, $t0, $t9
    ctx->r4 = ADD32(ctx->r8, ctx->r25);
    // 0x80389E30: lh          $t7, 0x302($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X302);
    // 0x80389E34: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80389E38: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80389E3C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80389E40: lw          $t9, 0x2EB0($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB0);
    // 0x80389E44: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80389E48: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80389E4C: negu        $t8, $t7
    ctx->r24 = SUB32(0, ctx->r15);
    // 0x80389E50: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80389E54: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80389E58: lw          $t7, 0x2EB4($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EB4);
    // 0x80389E5C: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x80389E60: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x80389E64: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x80389E68: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80389E6C: bgez        $t9, L_80389E7C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80389E70: sra         $t6, $t9, 2
        ctx->r14 = S32(SIGNED(ctx->r25) >> 2);
            goto L_80389E7C;
    }
    // 0x80389E70: sra         $t6, $t9, 2
    ctx->r14 = S32(SIGNED(ctx->r25) >> 2);
    // 0x80389E74: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x80389E78: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_80389E7C:
    // 0x80389E7C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80389E80: lw          $t9, 0x2EB8($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB8);
    // 0x80389E84: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80389E88: bgez        $t7, L_80389E98
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80389E8C: sra         $t8, $t7, 2
        ctx->r24 = S32(SIGNED(ctx->r15) >> 2);
            goto L_80389E98;
    }
    // 0x80389E8C: sra         $t8, $t7, 2
    ctx->r24 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80389E90: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x80389E94: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_80389E98:
    // 0x80389E98: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80389E9C: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80389EA0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80389EA4: lh          $t7, 0x2ED2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED2);
    // 0x80389EA8: lw          $t8, 0x2ED4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2ED4);
    // 0x80389EAC: bgez        $t9, L_80389EBC
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80389EB0: sra         $t6, $t9, 2
        ctx->r14 = S32(SIGNED(ctx->r25) >> 2);
            goto L_80389EBC;
    }
    // 0x80389EB0: sra         $t6, $t9, 2
    ctx->r14 = S32(SIGNED(ctx->r25) >> 2);
    // 0x80389EB4: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x80389EB8: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_80389EBC:
    // 0x80389EBC: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80389EC0: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80389EC4: jal         0x80127640
    // 0x80389EC8: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    func_80127640(rdram, ctx);
        goto after_12;
    // 0x80389EC8: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    after_12:
    // 0x80389ECC: lui         $s1, 0x801E
    ctx->r17 = S32(0X801E << 16);
    // 0x80389ED0: addiu       $s1, $s1, -0x6178
    ctx->r17 = ADD32(ctx->r17, -0X6178);
    // 0x80389ED4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x80389ED8: lui         $t3, 0x104
    ctx->r11 = S32(0X104 << 16);
    // 0x80389EDC: ori         $t3, $t3, 0x40
    ctx->r11 = ctx->r11 | 0X40;
    // 0x80389EE0: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80389EE4: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x80389EE8: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x80389EEC: addiu       $t5, $t5, 0x4278
    ctx->r13 = ADD32(ctx->r13, 0X4278);
    // 0x80389EF0: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x80389EF4: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x80389EF8: lui         $ra, 0x3
    ctx->r31 = S32(0X3 << 16);
    // 0x80389EFC: ori         $ra, $ra, 0x8000
    ctx->r31 = ctx->r31 | 0X8000;
    // 0x80389F00: addu        $t6, $t0, $ra
    ctx->r14 = ADD32(ctx->r8, ctx->r31);
    // 0x80389F04: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x80389F08: lui         $s0, 0x8003
    ctx->r16 = S32(0X8003 << 16);
    // 0x80389F0C: ori         $s0, $s0, 0x3590
    ctx->r16 = ctx->r16 | 0X3590;
    // 0x80389F10: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x80389F14: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x80389F18: lui         $t4, 0x801E
    ctx->r12 = S32(0X801E << 16);
    // 0x80389F1C: addu        $t6, $t9, $s0
    ctx->r14 = ADD32(ctx->r25, ctx->r16);
    // 0x80389F20: addiu       $t4, $t4, -0x6170
    ctx->r12 = ADD32(ctx->r12, -0X6170);
    // 0x80389F24: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80389F28: lw          $v1, 0x0($t4)
    ctx->r3 = MEM_W(ctx->r12, 0X0);
    // 0x80389F2C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80389F30: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80389F34: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x80389F38: sw          $t7, 0x0($t4)
    MEM_W(0X0, ctx->r12) = ctx->r15;
    // 0x80389F3C: sw          $t3, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r11;
    // 0x80389F40: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x80389F44: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80389F48: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x80389F4C: addu        $t8, $t0, $ra
    ctx->r24 = ADD32(ctx->r8, ctx->r31);
    // 0x80389F50: lw          $t9, 0x918($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X918);
    // 0x80389F54: sll         $t6, $t9, 6
    ctx->r14 = S32(ctx->r25 << 6);
    // 0x80389F58: addu        $t7, $t0, $t6
    ctx->r15 = ADD32(ctx->r8, ctx->r14);
    // 0x80389F5C: addu        $t8, $t7, $s0
    ctx->r24 = ADD32(ctx->r15, ctx->r16);
    // 0x80389F60: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x80389F64: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x80389F68: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80389F6C: addu        $t9, $t0, $ra
    ctx->r25 = ADD32(ctx->r8, ctx->r31);
    // 0x80389F70: lw          $t6, 0x918($t9)
    ctx->r14 = MEM_W(ctx->r25, 0X918);
    // 0x80389F74: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x80389F78: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80389F7C: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x80389F80: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x80389F84: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80389F88: lhu         $a0, 0xBA($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XBA);
    // 0x80389F8C: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x80389F90: subu        $t9, $t9, $a0
    ctx->r25 = SUB32(ctx->r25, ctx->r4);
    // 0x80389F94: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80389F98: div         $zero, $t9, $at
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r1)));
    // 0x80389F9C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80389FA0: lwc1        $f4, -0xB70($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0XB70);
    // 0x80389FA4: mflo        $t6
    ctx->r14 = lo;
    // 0x80389FA8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80389FAC: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80389FB0: jal         0x8038C230
    // 0x80389FB4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_13;
    // 0x80389FB4: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_13:
    // 0x80389FB8: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80389FBC: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80389FC0: lui         $v1, 0x4
    ctx->r3 = S32(0X4 << 16);
    // 0x80389FC4: lui         $at, 0x40F0
    ctx->r1 = S32(0X40F0 << 16);
    // 0x80389FC8: addu        $v1, $v1, $t0
    ctx->r3 = ADD32(ctx->r3, ctx->r8);
    // 0x80389FCC: lhu         $v1, -0x6CF0($v1)
    ctx->r3 = MEM_HU(ctx->r3, -0X6CF0);
    // 0x80389FD0: mtc1        $at, $f1
    ctx->f_odd[(1 - 1) * 2] = ctx->r1;
    // 0x80389FD4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80389FD8: sll         $t9, $v1, 6
    ctx->r25 = S32(ctx->r3 << 6);
    // 0x80389FDC: ori         $at, $at, 0x8CD0
    ctx->r1 = ctx->r1 | 0X8CD0;
    // 0x80389FE0: addu        $a0, $t0, $t9
    ctx->r4 = ADD32(ctx->r8, ctx->r25);
    // 0x80389FE4: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80389FE8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80389FEC: lwc1        $f6, 0x2C4C($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X2C4C);
    // 0x80389FF0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80389FF4: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80389FF8: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    // 0x80389FFC: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x8038A000: lw          $t8, 0x4($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X4);
    // 0x8038A004: sll         $t6, $v1, 5
    ctx->r14 = S32(ctx->r3 << 5);
    // 0x8038A008: addu        $t7, $t0, $t6
    ctx->r15 = ADD32(ctx->r8, ctx->r14);
    // 0x8038A00C: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x8038A010: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038A014: lui         $s0, 0x3
    ctx->r16 = S32(0X3 << 16);
    // 0x8038A018: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8038A01C: ori         $s0, $s0, 0x8A50
    ctx->r16 = ctx->r16 | 0X8A50;
    // 0x8038A020: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038A024: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8038A028: lw          $a3, 0x2C48($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2C48);
    // 0x8038A02C: lw          $a2, 0x2C44($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2C44);
    // 0x8038A030: cvt.d.s     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.fl); 
    ctx->f16.d = CVT_D_S(ctx->f10.fl);
    // 0x8038A034: addu        $a1, $t7, $s0
    ctx->r5 = ADD32(ctx->r15, ctx->r16);
    // 0x8038A038: div.d       $f18, $f16, $f0
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f0.d); 
    ctx->f18.d = DIV_D(ctx->f16.d, ctx->f0.d);
    // 0x8038A03C: cvt.s.d     $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.d); 
    ctx->f4.fl = CVT_S_D(ctx->f18.d);
    // 0x8038A040: swc1        $f4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f4.u32l;
    // 0x8038A044: lw          $t9, 0x8($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X8);
    // 0x8038A048: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x8038A04C: nop

    // 0x8038A050: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8038A054: cvt.d.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f8.fl); 
    ctx->f10.d = CVT_D_S(ctx->f8.fl);
    // 0x8038A058: div.d       $f16, $f10, $f0
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f0.d); 
    ctx->f16.d = DIV_D(ctx->f10.d, ctx->f0.d);
    // 0x8038A05C: cvt.s.d     $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.d); 
    ctx->f18.fl = CVT_S_D(ctx->f16.d);
    // 0x8038A060: swc1        $f18, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f18.u32l;
    // 0x8038A064: lw          $t6, 0xC($v0)
    ctx->r14 = MEM_W(ctx->r2, 0XC);
    // 0x8038A068: lwc1        $f18, 0x4200($at)
    ctx->f18.u32l = MEM_W(ctx->r1, 0X4200);
    // 0x8038A06C: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038A070: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x8038A074: swc1        $f18, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f18.u32l;
    // 0x8038A078: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8038A07C: lwc1        $f4, 0x4204($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X4204);
    // 0x8038A080: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x8038A084: swc1        $f4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->f4.u32l;
    // 0x8038A088: cvt.d.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.fl); 
    ctx->f8.d = CVT_D_S(ctx->f6.fl);
    // 0x8038A08C: lwc1        $f6, 0x4208($at)
    ctx->f6.u32l = MEM_W(ctx->r1, 0X4208);
    // 0x8038A090: div.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = DIV_D(ctx->f8.d, ctx->f0.d);
    // 0x8038A094: swc1        $f6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->f6.u32l;
    // 0x8038A098: cvt.s.d     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f16.fl = CVT_S_D(ctx->f10.d);
    // 0x8038A09C: jal         0x801404AC
    // 0x8038A0A0: swc1        $f16, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f16.u32l;
    guLookAtReflect(rdram, ctx);
        goto after_14;
    // 0x8038A0A0: swc1        $f16, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f16.u32l;
    after_14:
    // 0x8038A0A4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A0A8: lui         $t8, 0xBA00
    ctx->r24 = S32(0XBA00 << 16);
    // 0x8038A0AC: ori         $t8, $t8, 0xE02
    ctx->r24 = ctx->r24 | 0XE02;
    // 0x8038A0B0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038A0B4: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038A0B8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8038A0BC: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038A0C0: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A0C4: lui         $t6, 0x384
    ctx->r14 = S32(0X384 << 16);
    // 0x8038A0C8: lui         $t5, 0x8020
    ctx->r13 = S32(0X8020 << 16);
    // 0x8038A0CC: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8038A0D0: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8038A0D4: ori         $t6, $t6, 0x10
    ctx->r14 = ctx->r14 | 0X10;
    // 0x8038A0D8: addiu       $t5, $t5, 0x4278
    ctx->r13 = ADD32(ctx->r13, 0X4278);
    // 0x8038A0DC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8038A0E0: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x8038A0E4: lui         $ra, 0x3
    ctx->r31 = S32(0X3 << 16);
    // 0x8038A0E8: ori         $ra, $ra, 0x8000
    ctx->r31 = ctx->r31 | 0X8000;
    // 0x8038A0EC: addu        $t7, $t0, $ra
    ctx->r15 = ADD32(ctx->r8, ctx->r31);
    // 0x8038A0F0: lhu         $t8, 0x1310($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X1310);
    // 0x8038A0F4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038A0F8: ori         $at, $at, 0x8A60
    ctx->r1 = ctx->r1 | 0X8A60;
    // 0x8038A0FC: sll         $t9, $t8, 5
    ctx->r25 = S32(ctx->r24 << 5);
    // 0x8038A100: addu        $t6, $t0, $t9
    ctx->r14 = ADD32(ctx->r8, ctx->r25);
    // 0x8038A104: addu        $t7, $t6, $s0
    ctx->r15 = ADD32(ctx->r14, ctx->r16);
    // 0x8038A108: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8038A10C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A110: lui         $t9, 0x382
    ctx->r25 = S32(0X382 << 16);
    // 0x8038A114: ori         $t9, $t9, 0x10
    ctx->r25 = ctx->r25 | 0X10;
    // 0x8038A118: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A11C: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A120: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038A124: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x8038A128: lui         $t4, 0x600
    ctx->r12 = S32(0X600 << 16);
    // 0x8038A12C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x8038A130: addu        $t6, $t0, $ra
    ctx->r14 = ADD32(ctx->r8, ctx->r31);
    // 0x8038A134: lhu         $t7, 0x1310($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X1310);
    // 0x8038A138: sll         $t8, $t7, 5
    ctx->r24 = S32(ctx->r15 << 5);
    // 0x8038A13C: addu        $t9, $t0, $t8
    ctx->r25 = ADD32(ctx->r8, ctx->r24);
    // 0x8038A140: addu        $t6, $t9, $at
    ctx->r14 = ADD32(ctx->r25, ctx->r1);
    // 0x8038A144: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8038A148: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A14C: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x8038A150: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038A154: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038A158: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038A15C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8038A160: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038A164: lw          $t0, 0x0($t5)
    ctx->r8 = MEM_W(ctx->r13, 0X0);
    // 0x8038A168: addu        $t9, $t0, $ra
    ctx->r25 = ADD32(ctx->r8, ctx->r31);
    // 0x8038A16C: lhu         $t6, 0x1310($t9)
    ctx->r14 = MEM_HU(ctx->r25, 0X1310);
    // 0x8038A170: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8038A174: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038A178: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8038A17C: sh          $t7, -0x6CF0($at)
    MEM_H(-0X6CF0, ctx->r1) = ctx->r15;
    // 0x8038A180: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A184: addiu       $t9, $t9, 0x4270
    ctx->r25 = ADD32(ctx->r25, 0X4270);
    // 0x8038A188: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8038A18C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A190: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A194: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038A198: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8038A19C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A1A0: addiu       $t7, $t7, 0x4AF8
    ctx->r15 = ADD32(ctx->r15, 0X4AF8);
    // 0x8038A1A4: lui         $t9, 0xB900
    ctx->r25 = S32(0XB900 << 16);
    // 0x8038A1A8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8038A1AC: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038A1B0: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8038A1B4: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x8038A1B8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A1BC: ori         $t9, $t9, 0x31D
    ctx->r25 = ctx->r25 | 0X31D;
    // 0x8038A1C0: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x8038A1C4: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A1C8: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A1CC: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038A1D0: lw          $t7, 0x644($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X644);
    // 0x8038A1D4: lui         $at, 0x11
    ctx->r1 = S32(0X11 << 16);
    // 0x8038A1D8: ori         $at, $at, 0x2078
    ctx->r1 = ctx->r1 | 0X2078;
    // 0x8038A1DC: or          $t9, $t7, $at
    ctx->r25 = ctx->r15 | ctx->r1;
    // 0x8038A1E0: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038A1E4: lh          $v1, 0x2E1E($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2E1E);
    // 0x8038A1E8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038A1EC: beql        $v1, $zero, L_8038A26C
    if (ctx->r3 == 0) {
        // 0x8038A1F0: addiu       $t9, $zero, 0xAA
        ctx->r25 = ADD32(0, 0XAA);
            goto L_8038A26C;
    }
    goto skip_1;
    // 0x8038A1F0: addiu       $t9, $zero, 0xAA
    ctx->r25 = ADD32(0, 0XAA);
    skip_1:
    // 0x8038A1F4: beq         $v1, $at, L_8038A2E0
    if (ctx->r3 == ctx->r1) {
        // 0x8038A1F8: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8038A2E0;
    }
    // 0x8038A1F8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038A1FC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8038A200: beq         $v1, $at, L_8038A34C
    if (ctx->r3 == ctx->r1) {
        // 0x8038A204: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_8038A34C;
    }
    // 0x8038A204: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038A208: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8038A20C: lui         $at, 0x3FC0
    ctx->r1 = S32(0X3FC0 << 16);
    // 0x8038A210: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x8038A214: addiu       $v1, $v1, 0x5524
    ctx->r3 = ADD32(ctx->r3, 0X5524);
    // 0x8038A218: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x8038A21C: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8038A220: addiu       $t8, $zero, 0x7000
    ctx->r24 = ADD32(0, 0X7000);
    // 0x8038A224: sh          $t8, 0x134($sp)
    MEM_H(0X134, ctx->r29) = ctx->r24;
    // 0x8038A228: sh          $t7, 0x12A($sp)
    MEM_H(0X12A, ctx->r29) = ctx->r15;
    // 0x8038A22C: addiu       $v0, $zero, 0x780
    ctx->r2 = ADD32(0, 0X780);
    // 0x8038A230: sh          $zero, 0x138($sp)
    MEM_H(0X138, ctx->r29) = 0;
    // 0x8038A234: sh          $zero, 0x12E($sp)
    MEM_H(0X12E, ctx->r29) = 0;
    // 0x8038A238: sh          $zero, 0x12C($sp)
    MEM_H(0X12C, ctx->r29) = 0;
    // 0x8038A23C: swc1        $f8, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f8.u32l;
    // 0x8038A240: sh          $v0, 0xA4($t9)
    MEM_H(0XA4, ctx->r25) = ctx->r2;
    // 0x8038A244: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x8038A248: addiu       $t7, $zero, 0x28
    ctx->r15 = ADD32(0, 0X28);
    // 0x8038A24C: addiu       $t9, $zero, 0x3C
    ctx->r25 = ADD32(0, 0X3C);
    // 0x8038A250: sh          $v0, 0xAA($t6)
    MEM_H(0XAA, ctx->r14) = ctx->r2;
    // 0x8038A254: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x8038A258: sh          $t7, 0xA6($t8)
    MEM_H(0XA6, ctx->r24) = ctx->r15;
    // 0x8038A25C: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x8038A260: b           L_8038A3B4
    // 0x8038A264: sh          $t9, 0xA8($t6)
    MEM_H(0XA8, ctx->r14) = ctx->r25;
        goto L_8038A3B4;
    // 0x8038A264: sh          $t9, 0xA8($t6)
    MEM_H(0XA8, ctx->r14) = ctx->r25;
    // 0x8038A268: addiu       $t9, $zero, 0xAA
    ctx->r25 = ADD32(0, 0XAA);
L_8038A26C:
    // 0x8038A26C: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x8038A270: sh          $t9, 0x12C($sp)
    MEM_H(0X12C, ctx->r29) = ctx->r25;
    // 0x8038A274: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038A278: lwc1        $f10, -0xB6C($at)
    ctx->f10.u32l = MEM_W(ctx->r1, -0XB6C);
    // 0x8038A27C: sh          $t7, 0x138($sp)
    MEM_H(0X138, ctx->r29) = ctx->r15;
    // 0x8038A280: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038A284: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x8038A288: addiu       $t8, $zero, 0x4
    ctx->r24 = ADD32(0, 0X4);
    // 0x8038A28C: addiu       $t7, $zero, 0x4000
    ctx->r15 = ADD32(0, 0X4000);
    // 0x8038A290: sh          $t8, 0x12E($sp)
    MEM_H(0X12E, ctx->r29) = ctx->r24;
    // 0x8038A294: addiu       $t6, $zero, 0x28
    ctx->r14 = ADD32(0, 0X28);
    // 0x8038A298: sh          $t7, 0x134($sp)
    MEM_H(0X134, ctx->r29) = ctx->r15;
    // 0x8038A29C: sh          $t6, 0x12A($sp)
    MEM_H(0X12A, ctx->r29) = ctx->r14;
    // 0x8038A2A0: addiu       $t8, $zero, 0x180
    ctx->r24 = ADD32(0, 0X180);
    // 0x8038A2A4: swc1        $f10, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f10.u32l;
    // 0x8038A2A8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038A2AC: sh          $t8, 0xA4($t9)
    MEM_H(0XA4, ctx->r25) = ctx->r24;
    // 0x8038A2B0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8038A2B4: addiu       $t6, $zero, 0x140
    ctx->r14 = ADD32(0, 0X140);
    // 0x8038A2B8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038A2BC: sh          $t6, 0xAA($t7)
    MEM_H(0XAA, ctx->r15) = ctx->r14;
    // 0x8038A2C0: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x8038A2C4: addiu       $t8, $zero, 0x16
    ctx->r24 = ADD32(0, 0X16);
    // 0x8038A2C8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038A2CC: sh          $t8, 0xA6($t9)
    MEM_H(0XA6, ctx->r25) = ctx->r24;
    // 0x8038A2D0: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8038A2D4: addiu       $t6, $zero, 0x18
    ctx->r14 = ADD32(0, 0X18);
    // 0x8038A2D8: b           L_8038A3B4
    // 0x8038A2DC: sh          $t6, 0xA8($t7)
    MEM_H(0XA8, ctx->r15) = ctx->r14;
        goto L_8038A3B4;
    // 0x8038A2DC: sh          $t6, 0xA8($t7)
    MEM_H(0XA8, ctx->r15) = ctx->r14;
L_8038A2E0:
    // 0x8038A2E0: addiu       $t6, $zero, 0xD2
    ctx->r14 = ADD32(0, 0XD2);
    // 0x8038A2E4: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038A2E8: lwc1        $f16, -0xB68($at)
    ctx->f16.u32l = MEM_W(ctx->r1, -0XB68);
    // 0x8038A2EC: addiu       $v0, $v0, 0x5524
    ctx->r2 = ADD32(ctx->r2, 0X5524);
    // 0x8038A2F0: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x8038A2F4: sh          $t6, 0x12C($sp)
    MEM_H(0X12C, ctx->r29) = ctx->r14;
    // 0x8038A2F8: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x8038A2FC: sh          $t8, 0x138($sp)
    MEM_H(0X138, ctx->r29) = ctx->r24;
    // 0x8038A300: addiu       $t9, $zero, 0x7
    ctx->r25 = ADD32(0, 0X7);
    // 0x8038A304: sh          $t9, 0x12E($sp)
    MEM_H(0X12E, ctx->r29) = ctx->r25;
    // 0x8038A308: addiu       $t7, $zero, 0x5A
    ctx->r15 = ADD32(0, 0X5A);
    // 0x8038A30C: addiu       $t8, $zero, 0x5800
    ctx->r24 = ADD32(0, 0X5800);
    // 0x8038A310: sh          $t7, 0x12A($sp)
    MEM_H(0X12A, ctx->r29) = ctx->r15;
    // 0x8038A314: sh          $t8, 0x134($sp)
    MEM_H(0X134, ctx->r29) = ctx->r24;
    // 0x8038A318: addiu       $t9, $zero, 0x1C0
    ctx->r25 = ADD32(0, 0X1C0);
    // 0x8038A31C: swc1        $f16, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f16.u32l;
    // 0x8038A320: sh          $t9, 0xA4($t6)
    MEM_H(0XA4, ctx->r14) = ctx->r25;
    // 0x8038A324: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8038A328: addiu       $t7, $zero, 0x180
    ctx->r15 = ADD32(0, 0X180);
    // 0x8038A32C: addiu       $t9, $zero, 0x18
    ctx->r25 = ADD32(0, 0X18);
    // 0x8038A330: sh          $t7, 0xAA($t8)
    MEM_H(0XAA, ctx->r24) = ctx->r15;
    // 0x8038A334: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x8038A338: addiu       $t7, $zero, 0x1A
    ctx->r15 = ADD32(0, 0X1A);
    // 0x8038A33C: sh          $t9, 0xA6($t6)
    MEM_H(0XA6, ctx->r14) = ctx->r25;
    // 0x8038A340: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8038A344: b           L_8038A3B4
    // 0x8038A348: sh          $t7, 0xA8($t8)
    MEM_H(0XA8, ctx->r24) = ctx->r15;
        goto L_8038A3B4;
    // 0x8038A348: sh          $t7, 0xA8($t8)
    MEM_H(0XA8, ctx->r24) = ctx->r15;
L_8038A34C:
    // 0x8038A34C: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x8038A350: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038A354: lwc1        $f18, -0xB64($at)
    ctx->f18.u32l = MEM_W(ctx->r1, -0XB64);
    // 0x8038A358: addiu       $v0, $v0, 0x5524
    ctx->r2 = ADD32(ctx->r2, 0X5524);
    // 0x8038A35C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038A360: sh          $t7, 0x12C($sp)
    MEM_H(0X12C, ctx->r29) = ctx->r15;
    // 0x8038A364: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x8038A368: sh          $t9, 0x138($sp)
    MEM_H(0X138, ctx->r29) = ctx->r25;
    // 0x8038A36C: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x8038A370: sh          $t6, 0x12E($sp)
    MEM_H(0X12E, ctx->r29) = ctx->r14;
    // 0x8038A374: addiu       $t8, $zero, 0x8C
    ctx->r24 = ADD32(0, 0X8C);
    // 0x8038A378: addiu       $t9, $zero, 0x6000
    ctx->r25 = ADD32(0, 0X6000);
    // 0x8038A37C: sh          $t8, 0x12A($sp)
    MEM_H(0X12A, ctx->r29) = ctx->r24;
    // 0x8038A380: sh          $t9, 0x134($sp)
    MEM_H(0X134, ctx->r29) = ctx->r25;
    // 0x8038A384: addiu       $t6, $zero, 0x200
    ctx->r14 = ADD32(0, 0X200);
    // 0x8038A388: swc1        $f18, 0x100($sp)
    MEM_W(0X100, ctx->r29) = ctx->f18.u32l;
    // 0x8038A38C: sh          $t6, 0xA4($t7)
    MEM_H(0XA4, ctx->r15) = ctx->r14;
    // 0x8038A390: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x8038A394: addiu       $t8, $zero, 0x1C0
    ctx->r24 = ADD32(0, 0X1C0);
    // 0x8038A398: addiu       $t6, $zero, 0x1A
    ctx->r14 = ADD32(0, 0X1A);
    // 0x8038A39C: sh          $t8, 0xAA($t9)
    MEM_H(0XAA, ctx->r25) = ctx->r24;
    // 0x8038A3A0: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x8038A3A4: addiu       $t8, $zero, 0x1C
    ctx->r24 = ADD32(0, 0X1C);
    // 0x8038A3A8: sh          $t6, 0xA6($t7)
    MEM_H(0XA6, ctx->r15) = ctx->r14;
    // 0x8038A3AC: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x8038A3B0: sh          $t8, 0xA8($t9)
    MEM_H(0XA8, ctx->r25) = ctx->r24;
L_8038A3B4:
    // 0x8038A3B4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038A3B8: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x8038A3BC: lh          $t7, 0x30C($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X30C);
    // 0x8038A3C0: beql        $t7, $zero, L_8038A82C
    if (ctx->r15 == 0) {
        // 0x8038A3C4: lw          $v0, 0x0($s1)
        ctx->r2 = MEM_W(ctx->r17, 0X0);
            goto L_8038A82C;
    }
    goto skip_2;
    // 0x8038A3C4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    skip_2:
    // 0x8038A3C8: jal         0x80323040
    // 0x8038A3CC: nop

    func_80323040_7346F0(rdram, ctx);
        goto after_15;
    // 0x8038A3CC: nop

    after_15:
    // 0x8038A3D0: beq         $v0, $zero, L_8038A4BC
    if (ctx->r2 == 0) {
        // 0x8038A3D4: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_8038A4BC;
    }
    // 0x8038A3D4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x8038A3D8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038A3DC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038A3E0: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x8038A3E4: lhu         $t7, 0x42($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X42);
    // 0x8038A3E8: lh          $t8, 0xC($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XC);
    // 0x8038A3EC: subu        $t6, $t8, $t9
    ctx->r14 = SUB32(ctx->r24, ctx->r25);
    // 0x8038A3F0: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8038A3F4: subu        $s0, $t6, $t8
    ctx->r16 = SUB32(ctx->r14, ctx->r24);
    // 0x8038A3F8: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x8038A3FC: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x8038A400: addiu       $s0, $s0, 0x56
    ctx->r16 = ADD32(ctx->r16, 0X56);
    // 0x8038A404: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x8038A408: subu        $v0, $t6, $t8
    ctx->r2 = SUB32(ctx->r14, ctx->r24);
    // 0x8038A40C: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A410: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038A414: lh          $t7, 0x8($a1)
    ctx->r15 = MEM_H(ctx->r5, 0X8);
    // 0x8038A418: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x8038A41C: subu        $v1, $t9, $t7
    ctx->r3 = SUB32(ctx->r25, ctx->r15);
    // 0x8038A420: mflo        $t6
    ctx->r14 = lo;
    // 0x8038A424: nop

    // 0x8038A428: nop

    // 0x8038A42C: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A430: mflo        $t8
    ctx->r24 = lo;
    // 0x8038A434: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x8038A438: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x8038A43C: jal         0x80137E10
    // 0x8038A440: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    sqrtf_recomp(rdram, ctx);
        goto after_16;
    // 0x8038A440: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    after_16:
    // 0x8038A444: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8038A448: sll         $t7, $s0, 5
    ctx->r15 = S32(ctx->r16 << 5);
    // 0x8038A44C: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x8038A450: nop

    // 0x8038A454: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x8038A458: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x8038A45C: sra         $t6, $v1, 16
    ctx->r14 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8038A460: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038A464: bgtz        $t9, L_8038A470
    if (SIGNED(ctx->r25) > 0) {
        // 0x8038A468: or          $v1, $t6, $zero
        ctx->r3 = ctx->r14 | 0;
            goto L_8038A470;
    }
    // 0x8038A468: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x8038A46C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_8038A470:
    // 0x8038A470: div         $zero, $t7, $v1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r3))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r3)));
    // 0x8038A474: mflo        $a0
    ctx->r4 = lo;
    // 0x8038A478: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8038A47C: bne         $v1, $zero, L_8038A488
    if (ctx->r3 != 0) {
        // 0x8038A480: nop
    
            goto L_8038A488;
    }
    // 0x8038A480: nop

    // 0x8038A484: break       7
    do_break(2151195780);
L_8038A488:
    // 0x8038A488: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8038A48C: bne         $v1, $at, L_8038A4A0
    if (ctx->r3 != ctx->r1) {
        // 0x8038A490: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8038A4A0;
    }
    // 0x8038A490: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8038A494: bne         $t7, $at, L_8038A4A0
    if (ctx->r15 != ctx->r1) {
        // 0x8038A498: nop
    
            goto L_8038A4A0;
    }
    // 0x8038A498: nop

    // 0x8038A49C: break       6
    do_break(2151195804);
L_8038A4A0:
    // 0x8038A4A0: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038A4A4: jal         0x8012844C
    // 0x8038A4A8: nop

    func_8012844C(rdram, ctx);
        goto after_17;
    // 0x8038A4A8: nop

    after_17:
    // 0x8038A4AC: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x8038A4B0: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x8038A4B4: b           L_8038A4C0
    // 0x8038A4B8: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
        goto L_8038A4C0;
    // 0x8038A4B8: sra         $v1, $t9, 16
    ctx->r3 = S32(SIGNED(ctx->r25) >> 16);
L_8038A4BC:
    // 0x8038A4BC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8038A4C0:
    // 0x8038A4C0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038A4C4: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x8038A4C8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038A4CC: lh          $a3, 0x310($t2)
    ctx->r7 = MEM_H(ctx->r10, 0X310);
    // 0x8038A4D0: slt         $at, $a3, $v1
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8038A4D4: beq         $at, $zero, L_8038A4F8
    if (ctx->r1 == 0) {
        // 0x8038A4D8: addiu       $v0, $a3, 0x3
        ctx->r2 = ADD32(ctx->r7, 0X3);
            goto L_8038A4F8;
    }
    // 0x8038A4D8: addiu       $v0, $a3, 0x3
    ctx->r2 = ADD32(ctx->r7, 0X3);
    // 0x8038A4DC: slt         $at, $v1, $v0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8038A4E0: beq         $at, $zero, L_8038A4F0
    if (ctx->r1 == 0) {
        // 0x8038A4E4: nop
    
            goto L_8038A4F0;
    }
    // 0x8038A4E4: nop

    // 0x8038A4E8: b           L_8038A51C
    // 0x8038A4EC: sh          $v1, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r3;
        goto L_8038A51C;
    // 0x8038A4EC: sh          $v1, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r3;
L_8038A4F0:
    // 0x8038A4F0: b           L_8038A51C
    // 0x8038A4F4: sh          $v0, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r2;
        goto L_8038A51C;
    // 0x8038A4F4: sh          $v0, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r2;
L_8038A4F8:
    // 0x8038A4F8: slt         $at, $v1, $a3
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x8038A4FC: beq         $at, $zero, L_8038A51C
    if (ctx->r1 == 0) {
        // 0x8038A500: addiu       $v0, $a3, -0x3
        ctx->r2 = ADD32(ctx->r7, -0X3);
            goto L_8038A51C;
    }
    // 0x8038A500: addiu       $v0, $a3, -0x3
    ctx->r2 = ADD32(ctx->r7, -0X3);
    // 0x8038A504: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x8038A508: beql        $at, $zero, L_8038A51C
    if (ctx->r1 == 0) {
        // 0x8038A50C: sh          $v0, 0x310($t2)
        MEM_H(0X310, ctx->r10) = ctx->r2;
            goto L_8038A51C;
    }
    goto skip_3;
    // 0x8038A50C: sh          $v0, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r2;
    skip_3:
    // 0x8038A510: b           L_8038A51C
    // 0x8038A514: sh          $v1, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r3;
        goto L_8038A51C;
    // 0x8038A514: sh          $v1, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r3;
    // 0x8038A518: sh          $v0, 0x310($t2)
    MEM_H(0X310, ctx->r10) = ctx->r2;
L_8038A51C:
    // 0x8038A51C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038A520: lui         $s0, 0x8015
    ctx->r16 = S32(0X8015 << 16);
    // 0x8038A524: addiu       $s0, $s0, 0x2C78
    ctx->r16 = ADD32(ctx->r16, 0X2C78);
    // 0x8038A528: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x8038A52C: sh          $t6, 0x128($sp)
    MEM_H(0X128, ctx->r29) = ctx->r14;
    // 0x8038A530: lh          $t8, 0x8($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X8);
    // 0x8038A534: sh          $t8, 0x126($sp)
    MEM_H(0X126, ctx->r29) = ctx->r24;
    // 0x8038A538: lh          $t9, 0xC($a0)
    ctx->r25 = MEM_H(ctx->r4, 0XC);
    // 0x8038A53C: sw          $zero, 0x10C($sp)
    MEM_W(0X10C, ctx->r29) = 0;
    // 0x8038A540: addiu       $t7, $t9, 0x56
    ctx->r15 = ADD32(ctx->r25, 0X56);
    // 0x8038A544: sh          $t7, 0x124($sp)
    MEM_H(0X124, ctx->r29) = ctx->r15;
L_8038A548:
    // 0x8038A548: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038A54C: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x8038A550: addiu       $t8, $zero, 0x40
    ctx->r24 = ADD32(0, 0X40);
    // 0x8038A554: lw          $t0, 0x10C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X10C);
    // 0x8038A558: lh          $t6, 0x302($t2)
    ctx->r14 = MEM_H(ctx->r10, 0X302);
    // 0x8038A55C: lh          $a3, 0x310($t2)
    ctx->r7 = MEM_H(ctx->r10, 0X310);
    // 0x8038A560: addiu       $t0, $t0, 0x1
    ctx->r8 = ADD32(ctx->r8, 0X1);
    // 0x8038A564: subu        $v0, $t8, $t6
    ctx->r2 = SUB32(ctx->r24, ctx->r14);
    // 0x8038A568: addiu       $t8, $a3, 0x40
    ctx->r24 = ADD32(ctx->r7, 0X40);
    // 0x8038A56C: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x8038A570: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x8038A574: addu        $t7, $s0, $t9
    ctx->r15 = ADD32(ctx->r16, ctx->r25);
    // 0x8038A578: lh          $v1, 0x0($t7)
    ctx->r3 = MEM_H(ctx->r15, 0X0);
    // 0x8038A57C: addiu       $t6, $v0, 0x40
    ctx->r14 = ADD32(ctx->r2, 0X40);
    // 0x8038A580: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8038A584: sra         $t8, $v1, 7
    ctx->r24 = S32(SIGNED(ctx->r3) >> 7);
    // 0x8038A588: or          $v1, $t8, $zero
    ctx->r3 = ctx->r24 | 0;
    // 0x8038A58C: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8038A590: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x8038A594: lh          $t6, 0x0($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X0);
    // 0x8038A598: addiu       $t1, $zero, 0x600
    ctx->r9 = ADD32(0, 0X600);
    // 0x8038A59C: lh          $a2, 0x124($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X124);
    // 0x8038A5A0: sra         $t9, $t6, 7
    ctx->r25 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8038A5A4: multu       $t9, $v1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A5A8: lh          $t9, 0x128($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X128);
    // 0x8038A5AC: mflo        $t7
    ctx->r15 = lo;
    // 0x8038A5B0: nop

    // 0x8038A5B4: nop

    // 0x8038A5B8: multu       $t7, $t0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A5BC: mflo        $t8
    ctx->r24 = lo;
    // 0x8038A5C0: nop

    // 0x8038A5C4: nop

    // 0x8038A5C8: div         $zero, $t8, $t1
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r9))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r9)));
    // 0x8038A5CC: mflo        $t6
    ctx->r14 = lo;
    // 0x8038A5D0: addu        $a0, $t6, $t9
    ctx->r4 = ADD32(ctx->r14, ctx->r25);
    // 0x8038A5D4: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x8038A5D8: andi        $t6, $v0, 0xFF
    ctx->r14 = ctx->r2 & 0XFF;
    // 0x8038A5DC: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038A5E0: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x8038A5E4: bne         $t1, $zero, L_8038A5F0
    if (ctx->r9 != 0) {
        // 0x8038A5E8: nop
    
            goto L_8038A5F0;
    }
    // 0x8038A5E8: nop

    // 0x8038A5EC: break       7
    do_break(2151196140);
L_8038A5F0:
    // 0x8038A5F0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8038A5F4: bne         $t1, $at, L_8038A608
    if (ctx->r9 != ctx->r1) {
        // 0x8038A5F8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8038A608;
    }
    // 0x8038A5F8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8038A5FC: bne         $t8, $at, L_8038A608
    if (ctx->r24 != ctx->r1) {
        // 0x8038A600: nop
    
            goto L_8038A608;
    }
    // 0x8038A600: nop

    // 0x8038A604: break       6
    do_break(2151196164);
L_8038A608:
    // 0x8038A608: addu        $t7, $s0, $t9
    ctx->r15 = ADD32(ctx->r16, ctx->r25);
    // 0x8038A60C: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8038A610: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8038A614: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A618: lh          $t6, 0x126($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X126);
    // 0x8038A61C: mflo        $t9
    ctx->r25 = lo;
    // 0x8038A620: nop

    // 0x8038A624: nop

    // 0x8038A628: multu       $t9, $t0
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A62C: mflo        $t7
    ctx->r15 = lo;
    // 0x8038A630: nop

    // 0x8038A634: nop

    // 0x8038A638: div         $zero, $t7, $t1
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r9))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r9)));
    // 0x8038A63C: mflo        $t8
    ctx->r24 = lo;
    // 0x8038A640: addu        $a1, $t8, $t6
    ctx->r5 = ADD32(ctx->r24, ctx->r14);
    // 0x8038A644: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x8038A648: andi        $t8, $a3, 0xFF
    ctx->r24 = ctx->r7 & 0XFF;
    // 0x8038A64C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038A650: sll         $t6, $t8, 1
    ctx->r14 = S32(ctx->r24 << 1);
    // 0x8038A654: bne         $t1, $zero, L_8038A660
    if (ctx->r9 != 0) {
        // 0x8038A658: nop
    
            goto L_8038A660;
    }
    // 0x8038A658: nop

    // 0x8038A65C: break       7
    do_break(2151196252);
L_8038A660:
    // 0x8038A660: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8038A664: bne         $t1, $at, L_8038A678
    if (ctx->r9 != ctx->r1) {
        // 0x8038A668: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8038A678;
    }
    // 0x8038A668: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8038A66C: bne         $t7, $at, L_8038A678
    if (ctx->r15 != ctx->r1) {
        // 0x8038A670: nop
    
            goto L_8038A678;
    }
    // 0x8038A670: nop

    // 0x8038A674: break       6
    do_break(2151196276);
L_8038A678:
    // 0x8038A678: addu        $t9, $s0, $t6
    ctx->r25 = ADD32(ctx->r16, ctx->r14);
    // 0x8038A67C: lh          $t7, 0x0($t9)
    ctx->r15 = MEM_H(ctx->r25, 0X0);
    // 0x8038A680: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8038A684: sw          $t0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r8;
    // 0x8038A688: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8038A68C: multu       $t8, $t0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038A690: sh          $a1, 0x120($sp)
    MEM_H(0X120, ctx->r29) = ctx->r5;
    // 0x8038A694: sh          $a0, 0x122($sp)
    MEM_H(0X122, ctx->r29) = ctx->r4;
    // 0x8038A698: mflo        $t6
    ctx->r14 = lo;
    // 0x8038A69C: nop

    // 0x8038A6A0: nop

    // 0x8038A6A4: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x8038A6A8: mflo        $t9
    ctx->r25 = lo;
    // 0x8038A6AC: addu        $t7, $t9, $a2
    ctx->r15 = ADD32(ctx->r25, ctx->r6);
    // 0x8038A6B0: jal         0x803136FC
    // 0x8038A6B4: sh          $t7, 0x11E($sp)
    MEM_H(0X11E, ctx->r29) = ctx->r15;
    func_803136FC_724DAC(rdram, ctx);
        goto after_18;
    // 0x8038A6B4: sh          $t7, 0x11E($sp)
    MEM_H(0X11E, ctx->r29) = ctx->r15;
    after_18:
    // 0x8038A6B8: lh          $t8, 0x128($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X128);
    // 0x8038A6BC: lh          $t6, 0x126($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X126);
    // 0x8038A6C0: lh          $t9, 0x124($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X124);
    // 0x8038A6C4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038A6C8: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x8038A6CC: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8038A6D0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8038A6D4: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8038A6D8: lbu         $t8, 0x160($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X160);
    // 0x8038A6DC: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8038A6E0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038A6E4: lh          $a0, 0x122($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X122);
    // 0x8038A6E8: lh          $a1, 0x120($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X120);
    // 0x8038A6EC: lh          $a2, 0x11E($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X11E);
    // 0x8038A6F0: andi        $a3, $v0, 0xFF
    ctx->r7 = ctx->r2 & 0XFF;
    // 0x8038A6F4: jal         0x8033C9CC
    // 0x8038A6F8: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    func_8033C9CC_74E07C(rdram, ctx);
        goto after_19;
    // 0x8038A6F8: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    after_19:
    // 0x8038A6FC: bne         $v0, $zero, L_8038A714
    if (ctx->r2 != 0) {
        // 0x8038A700: lw          $t0, 0x5C($sp)
        ctx->r8 = MEM_W(ctx->r29, 0X5C);
            goto L_8038A714;
    }
    // 0x8038A700: lw          $t0, 0x5C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X5C);
    // 0x8038A704: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8038A708: bne         $t0, $at, L_8038A548
    if (ctx->r8 != ctx->r1) {
        // 0x8038A70C: sw          $t0, 0x10C($sp)
        MEM_W(0X10C, ctx->r29) = ctx->r8;
            goto L_8038A548;
    }
    // 0x8038A70C: sw          $t0, 0x10C($sp)
    MEM_W(0X10C, ctx->r29) = ctx->r8;
    // 0x8038A710: sw          $t0, 0x10C($sp)
    MEM_W(0X10C, ctx->r29) = ctx->r8;
L_8038A714:
    // 0x8038A714: lh          $t6, 0x120($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X120);
    // 0x8038A718: lh          $t9, 0x11E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X11E);
    // 0x8038A71C: addiu       $t7, $sp, 0x11C
    ctx->r15 = ADD32(ctx->r29, 0X11C);
    // 0x8038A720: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8038A724: addiu       $t6, $sp, 0x118
    ctx->r14 = ADD32(ctx->r29, 0X118);
    // 0x8038A728: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8038A72C: addiu       $t8, $sp, 0x11A
    ctx->r24 = ADD32(ctx->r29, 0X11A);
    // 0x8038A730: lh          $t7, 0x12E($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X12E);
    // 0x8038A734: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8038A738: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x8038A73C: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8038A740: addiu       $t9, $zero, 0xF
    ctx->r25 = ADD32(0, 0XF);
    // 0x8038A744: addiu       $t6, $zero, 0xA
    ctx->r14 = ADD32(0, 0XA);
    // 0x8038A748: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8038A74C: sh          $zero, 0x130($sp)
    MEM_H(0X130, ctx->r29) = 0;
    // 0x8038A750: sw          $t8, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r24;
    // 0x8038A754: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    // 0x8038A758: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038A75C: lh          $a0, 0x128($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X128);
    // 0x8038A760: lh          $a1, 0x126($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X126);
    // 0x8038A764: lh          $a2, 0x124($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X124);
    // 0x8038A768: lh          $a3, 0x122($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X122);
    // 0x8038A76C: jal         0x80322D68
    // 0x8038A770: sw          $t7, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r15;
    func_80322D68_734418(rdram, ctx);
        goto after_20;
    // 0x8038A770: sw          $t7, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r15;
    after_20:
    // 0x8038A774: beq         $v0, $zero, L_8038A828
    if (ctx->r2 == 0) {
        // 0x8038A778: addiu       $t9, $zero, 0x1
        ctx->r25 = ADD32(0, 0X1);
            goto L_8038A828;
    }
    // 0x8038A778: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038A77C: sh          $t9, 0x130($sp)
    MEM_H(0X130, ctx->r29) = ctx->r25;
    // 0x8038A780: sh          $zero, 0x132($sp)
    MEM_H(0X132, ctx->r29) = 0;
L_8038A784:
    // 0x8038A784: jal         0x8012826C
    // 0x8038A788: nop

    advance_random_seed(rdram, ctx);
        goto after_21;
    // 0x8038A788: nop

    after_21:
    // 0x8038A78C: jal         0x8012826C
    // 0x8038A790: sh          $v0, 0x62($sp)
    MEM_H(0X62, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_22;
    // 0x8038A790: sh          $v0, 0x62($sp)
    MEM_H(0X62, ctx->r29) = ctx->r2;
    after_22:
    // 0x8038A794: jal         0x8012826C
    // 0x8038A798: sh          $v0, 0x64($sp)
    MEM_H(0X64, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_23;
    // 0x8038A798: sh          $v0, 0x64($sp)
    MEM_H(0X64, ctx->r29) = ctx->r2;
    after_23:
    // 0x8038A79C: jal         0x8012826C
    // 0x8038A7A0: sh          $v0, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_24;
    // 0x8038A7A0: sh          $v0, 0x66($sp)
    MEM_H(0X66, ctx->r29) = ctx->r2;
    after_24:
    // 0x8038A7A4: lhu         $t7, 0x62($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X62);
    // 0x8038A7A8: lh          $a0, 0x11C($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X11C);
    // 0x8038A7AC: lh          $a1, 0x11A($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X11A);
    // 0x8038A7B0: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x8038A7B4: lhu         $t7, 0x64($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X64);
    // 0x8038A7B8: addiu       $t6, $t8, -0x7
    ctx->r14 = ADD32(ctx->r24, -0X7);
    // 0x8038A7BC: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8038A7C0: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x8038A7C4: lhu         $t7, 0x66($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X66);
    // 0x8038A7C8: addiu       $t6, $t8, -0x7
    ctx->r14 = ADD32(ctx->r24, -0X7);
    // 0x8038A7CC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038A7D0: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8038A7D4: andi        $t8, $t7, 0xF
    ctx->r24 = ctx->r15 & 0XF;
    // 0x8038A7D8: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x8038A7DC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8038A7E0: andi        $t9, $v0, 0x3
    ctx->r25 = ctx->r2 & 0X3;
    // 0x8038A7E4: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8038A7E8: ori         $t6, $zero, 0xFFFF
    ctx->r14 = 0 | 0XFFFF;
    // 0x8038A7EC: addiu       $t7, $t9, 0x4
    ctx->r15 = ADD32(ctx->r25, 0X4);
    // 0x8038A7F0: ori         $t8, $zero, 0xFFFF
    ctx->r24 = 0 | 0XFFFF;
    // 0x8038A7F4: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x8038A7F8: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x8038A7FC: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8038A800: lh          $a2, 0x118($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X118);
    // 0x8038A804: addiu       $a3, $zero, 0x18
    ctx->r7 = ADD32(0, 0X18);
    // 0x8038A808: jal         0x802D5F4C
    // 0x8038A80C: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    create_particle_effect(rdram, ctx);
        goto after_25;
    // 0x8038A80C: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    after_25:
    // 0x8038A810: lh          $v1, 0x132($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X132);
    // 0x8038A814: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x8038A818: sll         $t9, $v1, 16
    ctx->r25 = S32(ctx->r3 << 16);
    // 0x8038A81C: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038A820: blez        $t7, L_8038A784
    if (SIGNED(ctx->r15) <= 0) {
        // 0x8038A824: sh          $t7, 0x132($sp)
        MEM_H(0X132, ctx->r29) = ctx->r15;
            goto L_8038A784;
    }
    // 0x8038A824: sh          $t7, 0x132($sp)
    MEM_H(0X132, ctx->r29) = ctx->r15;
L_8038A828:
    // 0x8038A828: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
L_8038A82C:
    // 0x8038A82C: lui         $t6, 0xFD10
    ctx->r14 = S32(0XFD10 << 16);
    // 0x8038A830: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038A834: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A838: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A83C: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8038A840: lh          $t7, 0x138($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X138);
    // 0x8038A844: lui         $t6, 0x103
    ctx->r14 = S32(0X103 << 16);
    // 0x8038A848: addiu       $t6, $t6, -0xFF0
    ctx->r14 = ADD32(ctx->r14, -0XFF0);
    // 0x8038A84C: sll         $t8, $t7, 11
    ctx->r24 = S32(ctx->r15 << 11);
    // 0x8038A850: addu        $t9, $t8, $t6
    ctx->r25 = ADD32(ctx->r24, ctx->r14);
    // 0x8038A854: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038A858: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A85C: lui         $t6, 0x701
    ctx->r14 = S32(0X701 << 16);
    // 0x8038A860: ori         $t6, $t6, 0x4050
    ctx->r14 = ctx->r14 | 0X4050;
    // 0x8038A864: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038A868: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038A86C: lui         $t8, 0xF510
    ctx->r24 = S32(0XF510 << 16);
    // 0x8038A870: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038A874: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8038A878: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A87C: lui         $t7, 0xE600
    ctx->r15 = S32(0XE600 << 16);
    // 0x8038A880: lui         $t6, 0xF300
    ctx->r14 = S32(0XF300 << 16);
    // 0x8038A884: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8038A888: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8038A88C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8038A890: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8038A894: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A898: lui         $t9, 0x73F
    ctx->r25 = S32(0X73F << 16);
    // 0x8038A89C: ori         $t9, $t9, 0xF100
    ctx->r25 = ctx->r25 | 0XF100;
    // 0x8038A8A0: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A8A4: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A8A8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038A8AC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8038A8B0: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A8B4: lui         $t8, 0xE700
    ctx->r24 = S32(0XE700 << 16);
    // 0x8038A8B8: lui         $t9, 0xF510
    ctx->r25 = S32(0XF510 << 16);
    // 0x8038A8BC: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038A8C0: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038A8C4: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8038A8C8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038A8CC: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A8D0: lui         $t7, 0x1
    ctx->r15 = S32(0X1 << 16);
    // 0x8038A8D4: ori         $t7, $t7, 0x4050
    ctx->r15 = ctx->r15 | 0X4050;
    // 0x8038A8D8: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8038A8DC: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038A8E0: ori         $t9, $t9, 0x1000
    ctx->r25 = ctx->r25 | 0X1000;
    // 0x8038A8E4: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038A8E8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8038A8EC: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038A8F0: lui         $t9, 0x7
    ctx->r25 = S32(0X7 << 16);
    // 0x8038A8F4: ori         $t9, $t9, 0xC07C
    ctx->r25 = ctx->r25 | 0XC07C;
    // 0x8038A8F8: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038A8FC: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038A900: lui         $t6, 0xF200
    ctx->r14 = S32(0XF200 << 16);
    // 0x8038A904: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8038A908: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038A90C: lui         $t8, 0x8020
    ctx->r24 = S32(0X8020 << 16);
    // 0x8038A910: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x8038A914: lh          $t7, 0x4002($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4002);
    // 0x8038A918: lh          $t8, 0x3FFA($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X3FFA);
    // 0x8038A91C: lw          $a2, 0x2EBC($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EBC);
    // 0x8038A920: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x8038A924: subu        $ra, $t7, $t8
    ctx->r31 = SUB32(ctx->r15, ctx->r24);
    // 0x8038A928: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x8038A92C: subu        $t8, $t8, $a2
    ctx->r24 = SUB32(ctx->r24, ctx->r6);
    // 0x8038A930: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x8038A934: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x8038A938: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x8038A93C: sra         $a2, $t8, 6
    ctx->r6 = S32(SIGNED(ctx->r24) >> 6);
    // 0x8038A940: sra         $t6, $ra, 5
    ctx->r14 = S32(SIGNED(ctx->r31) >> 5);
    // 0x8038A944: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038A948: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x8038A94C: lw          $a3, 0x2EC0($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2EC0);
    // 0x8038A950: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x8038A954: sra         $ra, $t9, 16
    ctx->r31 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038A958: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x8038A95C: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
    // 0x8038A960: subu        $t6, $t6, $t8
    ctx->r14 = SUB32(ctx->r14, ctx->r24);
    // 0x8038A964: subu        $t9, $t9, $a3
    ctx->r25 = SUB32(ctx->r25, ctx->r7);
    // 0x8038A968: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8038A96C: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8038A970: addu        $t6, $t6, $t8
    ctx->r14 = ADD32(ctx->r14, ctx->r24);
    // 0x8038A974: addu        $t9, $t9, $a3
    ctx->r25 = ADD32(ctx->r25, ctx->r7);
    // 0x8038A978: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8038A97C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038A980: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8038A984: sra         $a3, $t9, 6
    ctx->r7 = S32(SIGNED(ctx->r25) >> 6);
    // 0x8038A988: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x8038A98C: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038A990: lui         $s0, 0x8015
    ctx->r16 = S32(0X8015 << 16);
    // 0x8038A994: addiu       $t8, $t8, 0x6430
    ctx->r24 = ADD32(ctx->r24, 0X6430);
    // 0x8038A998: sra         $t9, $t6, 6
    ctx->r25 = S32(SIGNED(ctx->r14) >> 6);
    // 0x8038A99C: sw          $ra, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r31;
    // 0x8038A9A0: addiu       $s0, $s0, 0x2C78
    ctx->r16 = ADD32(ctx->r16, 0X2C78);
    // 0x8038A9A4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038A9A8: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038A9AC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038A9B0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038A9B4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038A9B8: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8038A9BC: jal         0x802C78B0
    // 0x8038A9C0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_26;
    // 0x8038A9C0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_26:
    // 0x8038A9C4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038A9C8: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038A9CC: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038A9D0: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038A9D4: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038A9D8: addiu       $t9, $t9, 0x6260
    ctx->r25 = ADD32(ctx->r25, 0X6260);
    // 0x8038A9DC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038A9E0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038A9E4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038A9E8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038A9EC: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038A9F0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038A9F4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038A9F8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038A9FC: jal         0x802C78B0
    // 0x8038AA00: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_27;
    // 0x8038AA00: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_27:
    // 0x8038AA04: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038AA08: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x8038AA0C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AA10: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AA14: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x8038AA18: subu        $t7, $t7, $a2
    ctx->r15 = SUB32(ctx->r15, ctx->r6);
    // 0x8038AA1C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8038AA20: addu        $t7, $t7, $a2
    ctx->r15 = ADD32(ctx->r15, ctx->r6);
    // 0x8038AA24: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8038AA28: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AA2C: addiu       $t9, $t9, 0x5FC0
    ctx->r25 = ADD32(ctx->r25, 0X5FC0);
    // 0x8038AA30: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x8038AA34: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x8038AA38: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x8038AA3C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038AA40: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8038AA44: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x8038AA48: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AA4C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AA50: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AA54: jal         0x802C78B0
    // 0x8038AA58: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_28;
    // 0x8038AA58: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_28:
    // 0x8038AA5C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038AA60: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x8038AA64: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AA68: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AA6C: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x8038AA70: subu        $t7, $t7, $a2
    ctx->r15 = SUB32(ctx->r15, ctx->r6);
    // 0x8038AA74: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8038AA78: addu        $t7, $t7, $a2
    ctx->r15 = ADD32(ctx->r15, ctx->r6);
    // 0x8038AA7C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8038AA80: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AA84: addiu       $t9, $t9, 0x5750
    ctx->r25 = ADD32(ctx->r25, 0X5750);
    // 0x8038AA88: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x8038AA8C: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x8038AA90: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x8038AA94: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038AA98: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    // 0x8038AA9C: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x8038AAA0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AAA4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AAA8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AAAC: jal         0x802C78B0
    // 0x8038AAB0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x8038AAB0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_29:
    // 0x8038AAB4: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038AAB8: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x8038AABC: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AAC0: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AAC4: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x8038AAC8: subu        $t7, $t7, $a2
    ctx->r15 = SUB32(ctx->r15, ctx->r6);
    // 0x8038AACC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x8038AAD0: addu        $t7, $t7, $a2
    ctx->r15 = ADD32(ctx->r15, ctx->r6);
    // 0x8038AAD4: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x8038AAD8: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AADC: addiu       $t9, $t9, 0x4F70
    ctx->r25 = ADD32(ctx->r25, 0X4F70);
    // 0x8038AAE0: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x8038AAE4: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x8038AAE8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x8038AAEC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038AAF0: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    // 0x8038AAF4: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x8038AAF8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AAFC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AB00: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AB04: jal         0x802C78B0
    // 0x8038AB08: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_30;
    // 0x8038AB08: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_30:
    // 0x8038AB0C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038AB10: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8038AB14: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AB18: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038AB1C: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AB20: addiu       $t8, $t8, 0x6680
    ctx->r24 = ADD32(ctx->r24, 0X6680);
    // 0x8038AB24: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038AB28: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038AB2C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038AB30: addiu       $a0, $zero, 0x5
    ctx->r4 = ADD32(0, 0X5);
    // 0x8038AB34: addiu       $a1, $zero, 0xD
    ctx->r5 = ADD32(0, 0XD);
    // 0x8038AB38: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AB3C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AB40: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AB44: jal         0x802C78B0
    // 0x8038AB48: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x8038AB48: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_31:
    // 0x8038AB4C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AB50: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AB54: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AB58: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AB5C: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AB60: addiu       $t9, $t9, 0x54C0
    ctx->r25 = ADD32(ctx->r25, 0X54C0);
    // 0x8038AB64: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038AB68: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038AB6C: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038AB70: addiu       $a0, $zero, 0xD
    ctx->r4 = ADD32(0, 0XD);
    // 0x8038AB74: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x8038AB78: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AB7C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AB80: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AB84: jal         0x802C78B0
    // 0x8038AB88: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_32;
    // 0x8038AB88: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_32:
    // 0x8038AB8C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AB90: lui         $t8, 0xB600
    ctx->r24 = S32(0XB600 << 16);
    // 0x8038AB94: addiu       $t6, $zero, 0x3000
    ctx->r14 = ADD32(0, 0X3000);
    // 0x8038AB98: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038AB9C: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038ABA0: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8038ABA4: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038ABA8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038ABAC: lui         $t7, 0xB700
    ctx->r15 = S32(0XB700 << 16);
    // 0x8038ABB0: addiu       $t8, $zero, 0x1000
    ctx->r24 = ADD32(0, 0X1000);
    // 0x8038ABB4: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8038ABB8: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8038ABBC: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8038ABC0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038ABC4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038ABC8: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038ABCC: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038ABD0: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8038ABD4: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038ABD8: addiu       $t7, $t7, 0x6680
    ctx->r15 = ADD32(ctx->r15, 0X6680);
    // 0x8038ABDC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038ABE0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8038ABE4: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x8038ABE8: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038ABEC: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038ABF0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038ABF4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038ABF8: addiu       $a0, $zero, 0x6
    ctx->r4 = ADD32(0, 0X6);
    // 0x8038ABFC: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    // 0x8038AC00: jal         0x802C78B0
    // 0x8038AC04: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_33;
    // 0x8038AC04: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_33:
    // 0x8038AC08: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8038AC0C: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x8038AC10: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AC14: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AC18: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AC1C: addiu       $t9, $t9, 0x54C0
    ctx->r25 = ADD32(ctx->r25, 0X54C0);
    // 0x8038AC20: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8038AC24: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x8038AC28: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038AC2C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038AC30: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038AC34: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    // 0x8038AC38: addiu       $a1, $zero, 0x11
    ctx->r5 = ADD32(0, 0X11);
    // 0x8038AC3C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AC40: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AC44: jal         0x802C78B0
    // 0x8038AC48: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_34;
    // 0x8038AC48: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_34:
    // 0x8038AC4C: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AC50: lui         $t8, 0xB600
    ctx->r24 = S32(0XB600 << 16);
    // 0x8038AC54: addiu       $t6, $zero, 0x3000
    ctx->r14 = ADD32(0, 0X3000);
    // 0x8038AC58: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038AC5C: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038AC60: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8038AC64: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8038AC68: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AC6C: addiu       $t8, $zero, 0x2000
    ctx->r24 = ADD32(0, 0X2000);
    // 0x8038AC70: lui         $t7, 0xB700
    ctx->r15 = S32(0XB700 << 16);
    // 0x8038AC74: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x8038AC78: sw          $t9, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r25;
    // 0x8038AC7C: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038AC80: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8038AC84: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AC88: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AC8C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AC90: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038AC94: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AC98: addiu       $t9, $t9, 0x5E50
    ctx->r25 = ADD32(ctx->r25, 0X5E50);
    // 0x8038AC9C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x8038ACA0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038ACA4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038ACA8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038ACAC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038ACB0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038ACB4: addiu       $a0, $zero, 0x7
    ctx->r4 = ADD32(0, 0X7);
    // 0x8038ACB8: addiu       $a1, $zero, 0x8
    ctx->r5 = ADD32(0, 0X8);
    // 0x8038ACBC: jal         0x802C78B0
    // 0x8038ACC0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_35;
    // 0x8038ACC0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_35:
    // 0x8038ACC4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038ACC8: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8038ACCC: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038ACD0: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038ACD4: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038ACD8: addiu       $t8, $t8, 0x6570
    ctx->r24 = ADD32(ctx->r24, 0X6570);
    // 0x8038ACDC: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038ACE0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038ACE4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038ACE8: addiu       $a0, $zero, 0x3
    ctx->r4 = ADD32(0, 0X3);
    // 0x8038ACEC: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x8038ACF0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038ACF4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038ACF8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038ACFC: jal         0x802C78B0
    // 0x8038AD00: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_36;
    // 0x8038AD00: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_36:
    // 0x8038AD04: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AD08: lui         $t9, 0xB600
    ctx->r25 = S32(0XB600 << 16);
    // 0x8038AD0C: addiu       $t7, $zero, 0x3000
    ctx->r15 = ADD32(0, 0X3000);
    // 0x8038AD10: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8038AD14: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038AD18: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x8038AD1C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038AD20: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AD24: lui         $t6, 0xB700
    ctx->r14 = S32(0XB700 << 16);
    // 0x8038AD28: addiu       $t9, $zero, 0x1000
    ctx->r25 = ADD32(0, 0X1000);
    // 0x8038AD2C: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038AD30: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038AD34: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8038AD38: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038AD3C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038AD40: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8038AD44: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AD48: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x8038AD4C: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AD50: addiu       $t6, $t6, 0x6570
    ctx->r14 = ADD32(ctx->r14, 0X6570);
    // 0x8038AD54: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8038AD58: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8038AD5C: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8038AD60: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038AD64: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038AD68: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AD6C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AD70: addiu       $a0, $zero, 0x4
    ctx->r4 = ADD32(0, 0X4);
    // 0x8038AD74: addiu       $a1, $zero, 0xA
    ctx->r5 = ADD32(0, 0XA);
    // 0x8038AD78: jal         0x802C78B0
    // 0x8038AD7C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_37;
    // 0x8038AD7C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_37:
    // 0x8038AD80: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x8038AD84: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x8038AD88: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x8038AD8C: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038AD90: ori         $a2, $a2, 0x9000
    ctx->r6 = ctx->r6 | 0X9000;
    // 0x8038AD94: addiu       $t8, $t8, 0x5E50
    ctx->r24 = ADD32(ctx->r24, 0X5E50);
    // 0x8038AD98: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8038AD9C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x8038ADA0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038ADA4: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x8038ADA8: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038ADAC: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x8038ADB0: addiu       $a1, $zero, 0xB
    ctx->r5 = ADD32(0, 0XB);
    // 0x8038ADB4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038ADB8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038ADBC: jal         0x802C78B0
    // 0x8038ADC0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_38;
    // 0x8038ADC0: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_38:
    // 0x8038ADC4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038ADC8: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038ADCC: lui         $t2, 0x600
    ctx->r10 = S32(0X600 << 16);
    // 0x8038ADD0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8038ADD4: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038ADD8: addiu       $t9, $t9, 0x3460
    ctx->r25 = ADD32(ctx->r25, 0X3460);
    // 0x8038ADDC: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x8038ADE0: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x8038ADE4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038ADE8: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038ADEC: addiu       $t8, $t8, 0x3548
    ctx->r24 = ADD32(ctx->r24, 0X3548);
    // 0x8038ADF0: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x8038ADF4: sw          $t7, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r15;
    // 0x8038ADF8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038ADFC: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x8038AE00: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    // 0x8038AE04: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8038AE08: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038AE0C: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x8038AE10: sw          $t6, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r14;
    // 0x8038AE14: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x8038AE18: lh          $t7, 0x5540($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5540);
    // 0x8038AE1C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038AE20: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
    // 0x8038AE24: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x8038AE28: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x8038AE2C: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x8038AE30: addu        $t6, $s0, $t8
    ctx->r14 = ADD32(ctx->r16, ctx->r24);
    // 0x8038AE34: lh          $t9, 0x0($t6)
    ctx->r25 = MEM_H(ctx->r14, 0X0);
    // 0x8038AE38: addiu       $a1, $zero, 0x1A
    ctx->r5 = ADD32(0, 0X1A);
    // 0x8038AE3C: sra         $t7, $t9, 7
    ctx->r15 = S32(SIGNED(ctx->r25) >> 7);
    // 0x8038AE40: sra         $t8, $t7, 3
    ctx->r24 = S32(SIGNED(ctx->r15) >> 3);
    // 0x8038AE44: addiu       $t9, $t8, 0xDF
    ctx->r25 = ADD32(ctx->r24, 0XDF);
    // 0x8038AE48: sll         $t7, $t9, 24
    ctx->r15 = S32(ctx->r25 << 24);
    // 0x8038AE4C: ori         $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 | 0XFF;
    // 0x8038AE50: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x8038AE54: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x8038AE58: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x8038AE5C: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x8038AE60: sll         $t6, $a2, 2
    ctx->r14 = S32(ctx->r6 << 2);
    // 0x8038AE64: subu        $t6, $t6, $a2
    ctx->r14 = SUB32(ctx->r14, ctx->r6);
    // 0x8038AE68: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x8038AE6C: addu        $t6, $t6, $a2
    ctx->r14 = ADD32(ctx->r14, ctx->r6);
    // 0x8038AE70: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x8038AE74: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038AE78: addiu       $t8, $t8, 0x5060
    ctx->r24 = ADD32(ctx->r24, 0X5060);
    // 0x8038AE7C: sra         $a3, $t6, 6
    ctx->r7 = S32(SIGNED(ctx->r14) >> 6);
    // 0x8038AE80: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x8038AE84: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x8038AE88: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038AE8C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AE90: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AE94: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AE98: jal         0x802C78B0
    // 0x8038AE9C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_39;
    // 0x8038AE9C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_39:
    // 0x8038AEA0: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038AEA4: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x8038AEA8: lui         $v0, 0x8020
    ctx->r2 = S32(0X8020 << 16);
    // 0x8038AEAC: addiu       $v0, $v0, 0x3FE0
    ctx->r2 = ADD32(ctx->r2, 0X3FE0);
    // 0x8038AEB0: lh          $t6, 0x30C($t2)
    ctx->r14 = MEM_H(ctx->r10, 0X30C);
    // 0x8038AEB4: beql        $t6, $zero, L_8038B200
    if (ctx->r14 == 0) {
        // 0x8038AEB8: lw          $v0, 0x0($s1)
        ctx->r2 = MEM_W(ctx->r17, 0X0);
            goto L_8038B200;
    }
    goto skip_4;
    // 0x8038AEB8: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
    skip_4:
    // 0x8038AEBC: lh          $t9, 0x98($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X98);
    // 0x8038AEC0: lh          $t3, 0x12C($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X12C);
    // 0x8038AEC4: sh          $t9, 0xD8($v0)
    MEM_H(0XD8, ctx->r2) = ctx->r25;
    // 0x8038AEC8: lh          $t7, 0x310($t2)
    ctx->r15 = MEM_H(ctx->r10, 0X310);
    // 0x8038AECC: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x8038AED0: andi        $t6, $t8, 0xFF
    ctx->r14 = ctx->r24 & 0XFF;
    // 0x8038AED4: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x8038AED8: addu        $t7, $s0, $t9
    ctx->r15 = ADD32(ctx->r16, ctx->r25);
    // 0x8038AEDC: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8038AEE0: lh          $t7, 0x9A($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X9A);
    // 0x8038AEE4: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8038AEE8: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x8038AEEC: addu        $t8, $t9, $t7
    ctx->r24 = ADD32(ctx->r25, ctx->r15);
    // 0x8038AEF0: sh          $t8, 0xDA($v0)
    MEM_H(0XDA, ctx->r2) = ctx->r24;
    // 0x8038AEF4: lh          $t6, 0x310($t2)
    ctx->r14 = MEM_H(ctx->r10, 0X310);
    // 0x8038AEF8: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8038AEFC: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8038AF00: addu        $t8, $s0, $t7
    ctx->r24 = ADD32(ctx->r16, ctx->r15);
    // 0x8038AF04: lh          $t6, 0x0($t8)
    ctx->r14 = MEM_H(ctx->r24, 0X0);
    // 0x8038AF08: lh          $t8, 0x9C($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X9C);
    // 0x8038AF0C: sh          $t3, 0x136($sp)
    MEM_H(0X136, ctx->r29) = ctx->r11;
    // 0x8038AF10: sra         $t9, $t6, 7
    ctx->r25 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8038AF14: sll         $t7, $t9, 1
    ctx->r15 = S32(ctx->r25 << 1);
    // 0x8038AF18: addu        $t6, $t7, $t8
    ctx->r14 = ADD32(ctx->r15, ctx->r24);
    // 0x8038AF1C: jal         0x8012826C
    // 0x8038AF20: sh          $t6, 0xDC($v0)
    MEM_H(0XDC, ctx->r2) = ctx->r14;
    advance_random_seed(rdram, ctx);
        goto after_40;
    // 0x8038AF20: sh          $t6, 0xDC($v0)
    MEM_H(0XDC, ctx->r2) = ctx->r14;
    after_40:
    // 0x8038AF24: andi        $t9, $v0, 0xF
    ctx->r25 = ctx->r2 & 0XF;
    // 0x8038AF28: addiu       $at, $zero, 0xB
    ctx->r1 = ADD32(0, 0XB);
    // 0x8038AF2C: bne         $t9, $at, L_8038AF50
    if (ctx->r25 != ctx->r1) {
        // 0x8038AF30: lh          $t3, 0x136($sp)
        ctx->r11 = MEM_H(ctx->r29, 0X136);
            goto L_8038AF50;
    }
    // 0x8038AF30: lh          $t3, 0x136($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X136);
    // 0x8038AF34: lh          $t3, 0x12C($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X12C);
    // 0x8038AF38: bgez        $t3, L_8038AF48
    if (SIGNED(ctx->r11) >= 0) {
        // 0x8038AF3C: sra         $t7, $t3, 1
        ctx->r15 = S32(SIGNED(ctx->r11) >> 1);
            goto L_8038AF48;
    }
    // 0x8038AF3C: sra         $t7, $t3, 1
    ctx->r15 = S32(SIGNED(ctx->r11) >> 1);
    // 0x8038AF40: addiu       $at, $t3, 0x1
    ctx->r1 = ADD32(ctx->r11, 0X1);
    // 0x8038AF44: sra         $t7, $at, 1
    ctx->r15 = S32(SIGNED(ctx->r1) >> 1);
L_8038AF48:
    // 0x8038AF48: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x8038AF4C: sra         $t3, $t8, 16
    ctx->r11 = S32(SIGNED(ctx->r24) >> 16);
L_8038AF50:
    // 0x8038AF50: lui         $t2, 0x801E
    ctx->r10 = S32(0X801E << 16);
    // 0x8038AF54: addiu       $t2, $t2, -0x6170
    ctx->r10 = ADD32(ctx->r10, -0X6170);
    // 0x8038AF58: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x8038AF5C: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038AF60: addiu       $t8, $t8, 0x4970
    ctx->r24 = ADD32(ctx->r24, 0X4970);
    // 0x8038AF64: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038AF68: sw          $t9, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r25;
    // 0x8038AF6C: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8038AF70: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038AF74: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
    // 0x8038AF78: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x8038AF7C: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x8038AF80: sll         $t8, $t3, 24
    ctx->r24 = S32(ctx->r11 << 24);
    // 0x8038AF84: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8038AF88: sw          $t6, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r14;
    // 0x8038AF8C: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8038AF90: lh          $t6, 0x12A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X12A);
    // 0x8038AF94: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x8038AF98: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8038AF9C: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x8038AFA0: or          $t7, $t8, $t9
    ctx->r15 = ctx->r24 | ctx->r25;
    // 0x8038AFA4: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x8038AFA8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x8038AFAC: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8038AFB0: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x8038AFB4: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x8038AFB8: lui         $t8, 0x4
    ctx->r24 = S32(0X4 << 16);
    // 0x8038AFBC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038AFC0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x8038AFC4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8038AFC8: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8038AFCC: addu        $t8, $t8, $t0
    ctx->r24 = ADD32(ctx->r24, ctx->r8);
    // 0x8038AFD0: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x8038AFD4: lw          $t8, -0x76E8($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X76E8);
    // 0x8038AFD8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038AFDC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038AFE0: sll         $t9, $t8, 6
    ctx->r25 = S32(ctx->r24 << 6);
    // 0x8038AFE4: addu        $t7, $t0, $t9
    ctx->r15 = ADD32(ctx->r8, ctx->r25);
    // 0x8038AFE8: addu        $t6, $t7, $at
    ctx->r14 = ADD32(ctx->r15, ctx->r1);
    // 0x8038AFEC: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x8038AFF0: addiu       $a0, $zero, 0x13
    ctx->r4 = ADD32(0, 0X13);
    // 0x8038AFF4: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x8038AFF8: jal         0x80126388
    // 0x8038AFFC: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    func_80126388(rdram, ctx);
        goto after_41;
    // 0x8038AFFC: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    after_41:
    // 0x8038B000: beq         $v0, $zero, L_8038B16C
    if (ctx->r2 == 0) {
        // 0x8038B004: lui         $t1, 0x801E
        ctx->r9 = S32(0X801E << 16);
            goto L_8038B16C;
    }
    // 0x8038B004: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x8038B008: addiu       $t1, $t1, -0x6170
    ctx->r9 = ADD32(ctx->r9, -0X6170);
    // 0x8038B00C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B010: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038B014: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x8038B018: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8038B01C: sw          $t8, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r24;
    // 0x8038B020: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8038B024: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8038B028: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x8038B02C: lui         $t7, 0x4
    ctx->r15 = S32(0X4 << 16);
    // 0x8038B030: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x8038B034: addu        $t7, $t7, $t0
    ctx->r15 = ADD32(ctx->r15, ctx->r8);
    // 0x8038B038: lw          $t7, -0x76E8($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X76E8);
    // 0x8038B03C: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x8038B040: sll         $t6, $t7, 6
    ctx->r14 = S32(ctx->r15 << 6);
    // 0x8038B044: addu        $t8, $t0, $t6
    ctx->r24 = ADD32(ctx->r8, ctx->r14);
    // 0x8038B048: addu        $t9, $t8, $at
    ctx->r25 = ADD32(ctx->r24, ctx->r1);
    // 0x8038B04C: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x8038B050: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x8038B054: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x8038B058: lui         $t7, 0x4
    ctx->r15 = S32(0X4 << 16);
    // 0x8038B05C: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038B060: addu        $t7, $t7, $t0
    ctx->r15 = ADD32(ctx->r15, ctx->r8);
    // 0x8038B064: lw          $t7, -0x76E8($t7)
    ctx->r15 = MEM_W(ctx->r15, -0X76E8);
    // 0x8038B068: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8038B06C: addiu       $t6, $t7, 0x1
    ctx->r14 = ADD32(ctx->r15, 0X1);
    // 0x8038B070: sw          $t6, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r14;
    // 0x8038B074: lw          $t8, 0x10C($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X10C);
    // 0x8038B078: sltiu       $at, $t8, 0x6
    ctx->r1 = ctx->r24 < 0X6 ? 1 : 0;
    // 0x8038B07C: beq         $at, $zero, L_8038B16C
    if (ctx->r1 == 0) {
        // 0x8038B080: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_8038B16C;
    }
    // 0x8038B080: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x8038B084: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8038B088: addu        $at, $at, $t8
    gpr jr_addend_8038B090 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x8038B08C: lw          $t8, -0xB60($at)
    ctx->r24 = ADD32(ctx->r1, -0XB60);
    // 0x8038B090: jr          $t8
    // 0x8038B094: nop

    switch (jr_addend_8038B090 >> 2) {
        case 0: goto L_8038B098; break;
        case 1: goto L_8038B0BC; break;
        case 2: goto L_8038B0E0; break;
        case 3: goto L_8038B104; break;
        case 4: goto L_8038B128; break;
        case 5: goto L_8038B14C; break;
        default: switch_error(__func__, 0x8038B090, 0x803BF4A0);
    }
    // 0x8038B094: nop

L_8038B098:
    // 0x8038B098: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B09C: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x8038B0A0: addiu       $t6, $t6, 0x6AE8
    ctx->r14 = ADD32(ctx->r14, 0X6AE8);
    // 0x8038B0A4: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038B0A8: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x8038B0AC: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8038B0B0: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038B0B4: b           L_8038B16C
    // 0x8038B0B8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
        goto L_8038B16C;
    // 0x8038B0B8: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
L_8038B0BC:
    // 0x8038B0BC: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B0C0: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8038B0C4: addiu       $t7, $t7, 0x6AB0
    ctx->r15 = ADD32(ctx->r15, 0X6AB0);
    // 0x8038B0C8: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8038B0CC: sw          $t8, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r24;
    // 0x8038B0D0: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x8038B0D4: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8038B0D8: b           L_8038B16C
    // 0x8038B0DC: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
        goto L_8038B16C;
    // 0x8038B0DC: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
L_8038B0E0:
    // 0x8038B0E0: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B0E4: lui         $t9, 0x100
    ctx->r25 = S32(0X100 << 16);
    // 0x8038B0E8: addiu       $t9, $t9, 0x6A78
    ctx->r25 = ADD32(ctx->r25, 0X6A78);
    // 0x8038B0EC: addiu       $t6, $v1, 0x8
    ctx->r14 = ADD32(ctx->r3, 0X8);
    // 0x8038B0F0: sw          $t6, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r14;
    // 0x8038B0F4: lui         $t8, 0x600
    ctx->r24 = S32(0X600 << 16);
    // 0x8038B0F8: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x8038B0FC: b           L_8038B16C
    // 0x8038B100: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
        goto L_8038B16C;
    // 0x8038B100: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
L_8038B104:
    // 0x8038B104: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B108: lui         $t8, 0x100
    ctx->r24 = S32(0X100 << 16);
    // 0x8038B10C: addiu       $t8, $t8, 0x6A40
    ctx->r24 = ADD32(ctx->r24, 0X6A40);
    // 0x8038B110: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x8038B114: sw          $t7, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r15;
    // 0x8038B118: lui         $t6, 0x600
    ctx->r14 = S32(0X600 << 16);
    // 0x8038B11C: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x8038B120: b           L_8038B16C
    // 0x8038B124: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
        goto L_8038B16C;
    // 0x8038B124: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
L_8038B128:
    // 0x8038B128: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B12C: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x8038B130: addiu       $t6, $t6, 0x6A08
    ctx->r14 = ADD32(ctx->r14, 0X6A08);
    // 0x8038B134: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038B138: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x8038B13C: lui         $t7, 0x600
    ctx->r15 = S32(0X600 << 16);
    // 0x8038B140: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x8038B144: b           L_8038B16C
    // 0x8038B148: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
        goto L_8038B16C;
    // 0x8038B148: sw          $t6, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r14;
L_8038B14C:
    // 0x8038B14C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x8038B150: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x8038B154: addiu       $t7, $t7, 0x69D0
    ctx->r15 = ADD32(ctx->r15, 0X69D0);
    // 0x8038B158: addiu       $t8, $v1, 0x8
    ctx->r24 = ADD32(ctx->r3, 0X8);
    // 0x8038B15C: sw          $t8, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r24;
    // 0x8038B160: lui         $t9, 0x600
    ctx->r25 = S32(0X600 << 16);
    // 0x8038B164: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x8038B168: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
L_8038B16C:
    // 0x8038B16C: lh          $t6, 0x130($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X130);
    // 0x8038B170: lwc1        $f8, 0x100($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X100);
    // 0x8038B174: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B178: beq         $t6, $zero, L_8038B1C8
    if (ctx->r14 == 0) {
        // 0x8038B17C: lui         $at, 0x3F80
        ctx->r1 = S32(0X3F80 << 16);
            goto L_8038B1C8;
    }
    // 0x8038B17C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8038B180: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B184: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038B188: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    // 0x8038B18C: lh          $a2, 0x134($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X134);
    // 0x8038B190: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
    // 0x8038B194: addiu       $a1, $zero, 0x11A
    ctx->r5 = ADD32(0, 0X11A);
    // 0x8038B198: addiu       $a2, $a2, 0xF00
    ctx->r6 = ADD32(ctx->r6, 0XF00);
    // 0x8038B19C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x8038B1A0: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x8038B1A4: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x8038B1A8: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8038B1AC: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8038B1B0: lh          $t8, 0xC($a0)
    ctx->r24 = MEM_H(ctx->r4, 0XC);
    // 0x8038B1B4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038B1B8: jal         0x8032CD70
    // 0x8038B1BC: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    func_8032CD70_73E420(rdram, ctx);
        goto after_42;
    // 0x8038B1BC: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    after_42:
    // 0x8038B1C0: b           L_8038B200
    // 0x8038B1C4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
        goto L_8038B200;
    // 0x8038B1C4: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
L_8038B1C8:
    // 0x8038B1C8: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x8038B1CC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x8038B1D0: addiu       $a1, $zero, 0x119
    ctx->r5 = ADD32(0, 0X119);
    // 0x8038B1D4: swc1        $f10, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f10.u32l;
    // 0x8038B1D8: lh          $t9, 0x4($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X4);
    // 0x8038B1DC: lh          $a2, 0x134($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X134);
    // 0x8038B1E0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038B1E4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8038B1E8: lh          $t7, 0x8($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X8);
    // 0x8038B1EC: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x8038B1F0: lh          $t6, 0xC($a0)
    ctx->r14 = MEM_H(ctx->r4, 0XC);
    // 0x8038B1F4: jal         0x8032CD70
    // 0x8038B1F8: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    func_8032CD70_73E420(rdram, ctx);
        goto after_43;
    // 0x8038B1F8: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    after_43:
    // 0x8038B1FC: lw          $v0, 0x0($s1)
    ctx->r2 = MEM_W(ctx->r17, 0X0);
L_8038B200:
    // 0x8038B200: lui         $a2, 0xBD00
    ctx->r6 = S32(0XBD00 << 16);
    // 0x8038B204: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x8038B208: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x8038B20C: sw          $t8, 0x0($s1)
    MEM_W(0X0, ctx->r17) = ctx->r24;
    // 0x8038B210: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x8038B214: sw          $a2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r6;
    // 0x8038B218: lw          $v1, -0x6170($v1)
    ctx->r3 = MEM_W(ctx->r3, -0X6170);
    // 0x8038B21C: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8038B220: addiu       $t9, $v1, 0x8
    ctx->r25 = ADD32(ctx->r3, 0X8);
    // 0x8038B224: sw          $t9, -0x6170($at)
    MEM_W(-0X6170, ctx->r1) = ctx->r25;
    // 0x8038B228: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x8038B22C: sw          $a2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r6;
L_8038B230:
    // 0x8038B230: jal         0x8035D6A0
    // 0x8038B234: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_44;
    // 0x8038B234: nop

    after_44:
    // 0x8038B238: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8038B23C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038B240: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x8038B244: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x8038B248: lhu         $t8, 0xBA($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0XBA);
    // 0x8038B24C: lh          $t7, 0xC($t2)
    ctx->r15 = MEM_H(ctx->r10, 0XC);
    // 0x8038B250: lh          $a0, 0x4($t2)
    ctx->r4 = MEM_H(ctx->r10, 0X4);
    // 0x8038B254: lh          $a1, 0x8($t2)
    ctx->r5 = MEM_H(ctx->r10, 0X8);
    // 0x8038B258: lh          $a3, 0x302($t2)
    ctx->r7 = MEM_H(ctx->r10, 0X302);
    // 0x8038B25C: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x8038B260: addu        $a2, $t7, $t9
    ctx->r6 = ADD32(ctx->r15, ctx->r25);
    // 0x8038B264: lui         $t7, 0x103
    ctx->r15 = S32(0X103 << 16);
    // 0x8038B268: addiu       $t7, $t7, 0x3190
    ctx->r15 = ADD32(ctx->r15, 0X3190);
    // 0x8038B26C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8038B270: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x8038B274: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x8038B278: lbu         $t7, 0x5538($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X5538);
    // 0x8038B27C: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038B280: addiu       $t6, $zero, 0x1C
    ctx->r14 = ADD32(0, 0X1C);
    // 0x8038B284: addiu       $t9, $zero, 0xC
    ctx->r25 = ADD32(0, 0XC);
    // 0x8038B288: addiu       $t8, $zero, 0x9B
    ctx->r24 = ADD32(0, 0X9B);
    // 0x8038B28C: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8038B290: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8038B294: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x8038B298: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x8038B29C: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x8038B2A0: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x8038B2A4: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8038B2A8: jal         0x8034BD20
    // 0x8038B2AC: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_45;
    // 0x8038B2AC: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    after_45:
    // 0x8038B2B0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B2B4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8038B2B8: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8038B2BC: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x8038B2C0: addiu       $a3, $zero, 0x2BF
    ctx->r7 = ADD32(0, 0X2BF);
    // 0x8038B2C4: jal         0x80303820
    // 0x8038B2C8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_46;
    // 0x8038B2C8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_46:
    // 0x8038B2CC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B2D0: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8038B2D4: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038B2D8: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8038B2DC: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038B2E0: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x8038B2E4: jal         0x80303820
    // 0x8038B2E8: addiu       $a3, $zero, 0x2BF
    ctx->r7 = ADD32(0, 0X2BF);
    func_80303820_714ED0(rdram, ctx);
        goto after_47;
    // 0x8038B2E8: addiu       $a3, $zero, 0x2BF
    ctx->r7 = ADD32(0, 0X2BF);
    after_47:
    // 0x8038B2EC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B2F0: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x8038B2F4: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8038B2F8: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8038B2FC: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x8038B300: addiu       $a2, $zero, 0x13
    ctx->r6 = ADD32(0, 0X13);
    // 0x8038B304: jal         0x80303820
    // 0x8038B308: addiu       $a3, $zero, 0x1D4
    ctx->r7 = ADD32(0, 0X1D4);
    func_80303820_714ED0(rdram, ctx);
        goto after_48;
    // 0x8038B308: addiu       $a3, $zero, 0x1D4
    ctx->r7 = ADD32(0, 0X1D4);
    after_48:
    // 0x8038B30C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B310: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8038B314: jal         0x80303D50
    // 0x8038B318: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    func_80303D50_715400(rdram, ctx);
        goto after_49;
    // 0x8038B318: addiu       $a1, $zero, 0x3
    ctx->r5 = ADD32(0, 0X3);
    after_49:
    // 0x8038B31C: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x8038B320: lw          $s0, 0x3C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X3C);
    // 0x8038B324: lw          $s1, 0x40($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X40);
    // 0x8038B328: jr          $ra
    // 0x8038B32C: addiu       $sp, $sp, 0x158
    ctx->r29 = ADD32(ctx->r29, 0X158);
    return;
    // 0x8038B32C: addiu       $sp, $sp, 0x158
    ctx->r29 = ADD32(ctx->r29, 0X158);
;}
RECOMP_FUNC void func_8038B330_79C9E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B330: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x8038B334: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x8038B338: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038B33C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x8038B340: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x8038B344: sw          $fp, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r30;
    // 0x8038B348: sw          $s7, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r23;
    // 0x8038B34C: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x8038B350: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x8038B354: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x8038B358: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x8038B35C: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x8038B360: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x8038B364: lbu         $t6, 0x162($s0)
    ctx->r14 = MEM_BU(ctx->r16, 0X162);
    // 0x8038B368: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038B36C: beq         $t6, $at, L_8038B6F8
    if (ctx->r14 == ctx->r1) {
        // 0x8038B370: nop
    
            goto L_8038B6F8;
    }
    // 0x8038B370: nop

    // 0x8038B374: lb          $t7, 0x4A($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X4A);
    // 0x8038B378: lui         $at, 0x3E80
    ctx->r1 = S32(0X3E80 << 16);
    // 0x8038B37C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038B380: bnel        $t7, $zero, L_8038B3CC
    if (ctx->r15 != 0) {
        // 0x8038B384: lw          $v0, 0x24($s0)
        ctx->r2 = MEM_W(ctx->r16, 0X24);
            goto L_8038B3CC;
    }
    goto skip_0;
    // 0x8038B384: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
    skip_0:
    // 0x8038B388: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x8038B38C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8038B390: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8038B394: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    // 0x8038B398: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x8038B39C: addiu       $a1, $zero, 0x67
    ctx->r5 = ADD32(0, 0X67);
    // 0x8038B3A0: addiu       $a2, $zero, 0x7000
    ctx->r6 = ADD32(0, 0X7000);
    // 0x8038B3A4: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x8038B3A8: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x8038B3AC: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x8038B3B0: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x8038B3B4: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x8038B3B8: jal         0x8032CD70
    // 0x8038B3BC: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    func_8032CD70_73E420(rdram, ctx);
        goto after_0;
    // 0x8038B3BC: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    after_0:
    // 0x8038B3C0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038B3C4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x8038B3C8: lw          $v0, 0x24($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X24);
L_8038B3CC:
    // 0x8038B3CC: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x8038B3D0: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x8038B3D4: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x8038B3D8: bne         $at, $zero, L_8038B410
    if (ctx->r1 != 0) {
        // 0x8038B3DC: addiu       $s2, $zero, -0x10
        ctx->r18 = ADD32(0, -0X10);
            goto L_8038B410;
    }
    // 0x8038B3DC: addiu       $s2, $zero, -0x10
    ctx->r18 = ADD32(0, -0X10);
    // 0x8038B3E0: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x8038B3E4: addu        $v1, $v0, $at
    ctx->r3 = ADD32(ctx->r2, ctx->r1);
    // 0x8038B3E8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8038B3EC: ori         $at, $at, 0xC001
    ctx->r1 = ctx->r1 | 0XC001;
    // 0x8038B3F0: slt         $at, $v1, $at
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x8038B3F4: bne         $at, $zero, L_8038B404
    if (ctx->r1 != 0) {
        // 0x8038B3F8: lui         $t2, 0x3
        ctx->r10 = S32(0X3 << 16);
            goto L_8038B404;
    }
    // 0x8038B3F8: lui         $t2, 0x3
    ctx->r10 = S32(0X3 << 16);
    // 0x8038B3FC: b           L_8038B440
    // 0x8038B400: sw          $v1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r3;
        goto L_8038B440;
    // 0x8038B400: sw          $v1, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r3;
L_8038B404:
    // 0x8038B404: ori         $t2, $t2, 0xC000
    ctx->r10 = ctx->r10 | 0XC000;
    // 0x8038B408: b           L_8038B440
    // 0x8038B40C: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
        goto L_8038B440;
    // 0x8038B40C: sw          $t2, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r10;
L_8038B410:
    // 0x8038B410: lui         $at, 0xFFF6
    ctx->r1 = S32(0XFFF6 << 16);
    // 0x8038B414: ori         $at, $at, 0x1
    ctx->r1 = ctx->r1 | 0X1;
    // 0x8038B418: slt         $at, $v0, $at
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r1) ? 1 : 0;
    // 0x8038B41C: bne         $at, $zero, L_8038B434
    if (ctx->r1 != 0) {
        // 0x8038B420: lui         $at, 0x1
        ctx->r1 = S32(0X1 << 16);
            goto L_8038B434;
    }
    // 0x8038B420: lui         $at, 0x1
    ctx->r1 = S32(0X1 << 16);
    // 0x8038B424: ori         $at, $at, 0xE000
    ctx->r1 = ctx->r1 | 0XE000;
    // 0x8038B428: addu        $t3, $v0, $at
    ctx->r11 = ADD32(ctx->r2, ctx->r1);
    // 0x8038B42C: b           L_8038B440
    // 0x8038B430: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
        goto L_8038B440;
    // 0x8038B430: sw          $t3, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r11;
L_8038B434:
    // 0x8038B434: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8038B438: addu        $t4, $v0, $at
    ctx->r12 = ADD32(ctx->r2, ctx->r1);
    // 0x8038B43C: sw          $t4, 0x24($s0)
    MEM_W(0X24, ctx->r16) = ctx->r12;
L_8038B440:
    // 0x8038B440: lui         $s7, 0x8015
    ctx->r23 = S32(0X8015 << 16);
    // 0x8038B444: addiu       $s7, $s7, 0x2C78
    ctx->r23 = ADD32(ctx->r23, 0X2C78);
L_8038B448:
    // 0x8038B448: jal         0x8012826C
    // 0x8038B44C: nop

    advance_random_seed(rdram, ctx);
        goto after_1;
    // 0x8038B44C: nop

    after_1:
    // 0x8038B450: jal         0x8012826C
    // 0x8038B454: andi        $fp, $v0, 0xFFFF
    ctx->r30 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_2;
    // 0x8038B454: andi        $fp, $v0, 0xFFFF
    ctx->r30 = ctx->r2 & 0XFFFF;
    after_2:
    // 0x8038B458: jal         0x8012826C
    // 0x8038B45C: andi        $s5, $v0, 0xFFFF
    ctx->r21 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_3;
    // 0x8038B45C: andi        $s5, $v0, 0xFFFF
    ctx->r21 = ctx->r2 & 0XFFFF;
    after_3:
    // 0x8038B460: jal         0x8012826C
    // 0x8038B464: andi        $s6, $v0, 0xFFFF
    ctx->r22 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_4;
    // 0x8038B464: andi        $s6, $v0, 0xFFFF
    ctx->r22 = ctx->r2 & 0XFFFF;
    after_4:
    // 0x8038B468: jal         0x8012826C
    // 0x8038B46C: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_5;
    // 0x8038B46C: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
    after_5:
    // 0x8038B470: jal         0x8012826C
    // 0x8038B474: andi        $s4, $v0, 0xFFFF
    ctx->r20 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_6;
    // 0x8038B474: andi        $s4, $v0, 0xFFFF
    ctx->r20 = ctx->r2 & 0XFFFF;
    after_6:
    // 0x8038B478: jal         0x8012826C
    // 0x8038B47C: andi        $s1, $v0, 0xFFFF
    ctx->r17 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_7;
    // 0x8038B47C: andi        $s1, $v0, 0xFFFF
    ctx->r17 = ctx->r2 & 0XFFFF;
    after_7:
    // 0x8038B480: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8038B484: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x8038B488: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038B48C: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x8038B490: lh          $v1, 0x302($t5)
    ctx->r3 = MEM_H(ctx->r13, 0X302);
    // 0x8038B494: andi        $t8, $fp, 0xF
    ctx->r24 = ctx->r30 & 0XF;
    // 0x8038B498: lh          $t9, 0x4($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X4);
    // 0x8038B49C: negu        $v1, $v1
    ctx->r3 = SUB32(0, ctx->r3);
    // 0x8038B4A0: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x8038B4A4: sra         $v1, $t6, 16
    ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8038B4A8: addiu       $t2, $v1, 0x40
    ctx->r10 = ADD32(ctx->r3, 0X40);
    // 0x8038B4AC: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x8038B4B0: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x8038B4B4: addu        $t5, $s7, $t4
    ctx->r13 = ADD32(ctx->r23, ctx->r12);
    // 0x8038B4B8: lh          $t6, 0x0($t5)
    ctx->r14 = MEM_H(ctx->r13, 0X0);
    // 0x8038B4BC: andi        $t5, $v1, 0xFF
    ctx->r13 = ctx->r3 & 0XFF;
    // 0x8038B4C0: addu        $t1, $t8, $t9
    ctx->r9 = ADD32(ctx->r24, ctx->r25);
    // 0x8038B4C4: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x8038B4C8: multu       $s2, $t7
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038B4CC: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x8038B4D0: addu        $t7, $s7, $t6
    ctx->r15 = ADD32(ctx->r23, ctx->r14);
    // 0x8038B4D4: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x8038B4D8: andi        $t6, $s3, 0x7FFF
    ctx->r14 = ctx->r19 & 0X7FFF;
    // 0x8038B4DC: andi        $t2, $s5, 0xF
    ctx->r10 = ctx->r21 & 0XF;
    // 0x8038B4E0: lui         $t0, 0xFFFF
    ctx->r8 = S32(0XFFFF << 16);
    // 0x8038B4E4: andi        $a3, $s6, 0x1
    ctx->r7 = ctx->r22 & 0X1;
    // 0x8038B4E8: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x8038B4EC: addiu       $a3, $a3, 0x19
    ctx->r7 = ADD32(ctx->r7, 0X19);
    // 0x8038B4F0: mflo        $t8
    ctx->r24 = lo;
    // 0x8038B4F4: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x8038B4F8: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8038B4FC: addu        $a0, $t1, $t9
    ctx->r4 = ADD32(ctx->r9, ctx->r25);
    // 0x8038B500: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8038B504: sra         $t1, $t8, 7
    ctx->r9 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8038B508: multu       $s2, $t1
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038B50C: lw          $t8, 0x1C($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X1C);
    // 0x8038B510: ori         $t0, $t0, 0x63C0
    ctx->r8 = ctx->r8 | 0X63C0;
    // 0x8038B514: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x8038B518: addu        $t1, $t7, $t8
    ctx->r9 = ADD32(ctx->r15, ctx->r24);
    // 0x8038B51C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x8038B520: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8038B524: lui         $at, 0xFFFC
    ctx->r1 = S32(0XFFFC << 16);
    // 0x8038B528: ori         $at, $at, 0xF2C0
    ctx->r1 = ctx->r1 | 0XF2C0;
    // 0x8038B52C: addiu       $a0, $a0, -0x8
    ctx->r4 = ADD32(ctx->r4, -0X8);
    // 0x8038B530: mflo        $t9
    ctx->r25 = lo;
    // 0x8038B534: sra         $t2, $t9, 8
    ctx->r10 = S32(SIGNED(ctx->r25) >> 8);
    // 0x8038B538: addu        $t9, $t1, $t0
    ctx->r25 = ADD32(ctx->r9, ctx->r8);
    // 0x8038B53C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x8038B540: lw          $t3, 0x20($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X20);
    // 0x8038B544: addu        $a1, $t4, $t2
    ctx->r5 = ADD32(ctx->r12, ctx->r10);
    // 0x8038B548: andi        $t4, $s4, 0x7FFF
    ctx->r12 = ctx->r20 & 0X7FFF;
    // 0x8038B54C: sll         $t2, $t4, 1
    ctx->r10 = S32(ctx->r12 << 1);
    // 0x8038B550: addu        $t5, $t2, $t3
    ctx->r13 = ADD32(ctx->r10, ctx->r11);
    // 0x8038B554: addu        $t6, $t5, $t0
    ctx->r14 = ADD32(ctx->r13, ctx->r8);
    // 0x8038B558: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8038B55C: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x8038B560: andi        $t3, $v0, 0xF
    ctx->r11 = ctx->r2 & 0XF;
    // 0x8038B564: addiu       $t5, $t3, 0xF
    ctx->r13 = ADD32(ctx->r11, 0XF);
    // 0x8038B568: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x8038B56C: addu        $t1, $t8, $at
    ctx->r9 = ADD32(ctx->r24, ctx->r1);
    // 0x8038B570: addiu       $t2, $zero, 0x39CF
    ctx->r10 = ADD32(0, 0X39CF);
    // 0x8038B574: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8038B578: andi        $t9, $s1, 0xC
    ctx->r25 = ctx->r17 & 0XC;
    // 0x8038B57C: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8038B580: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x8038B584: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    // 0x8038B588: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x8038B58C: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    // 0x8038B590: jal         0x802D5F4C
    // 0x8038B594: addiu       $a1, $a1, -0x8
    ctx->r5 = ADD32(ctx->r5, -0X8);
    create_particle_effect(rdram, ctx);
        goto after_8;
    // 0x8038B594: addiu       $a1, $a1, -0x8
    ctx->r5 = ADD32(ctx->r5, -0X8);
    after_8:
    // 0x8038B598: jal         0x8012826C
    // 0x8038B59C: nop

    advance_random_seed(rdram, ctx);
        goto after_9;
    // 0x8038B59C: nop

    after_9:
    // 0x8038B5A0: jal         0x8012826C
    // 0x8038B5A4: andi        $s5, $v0, 0xFFFF
    ctx->r21 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_10;
    // 0x8038B5A4: andi        $s5, $v0, 0xFFFF
    ctx->r21 = ctx->r2 & 0XFFFF;
    after_10:
    // 0x8038B5A8: jal         0x8012826C
    // 0x8038B5AC: andi        $s6, $v0, 0xFFFF
    ctx->r22 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_11;
    // 0x8038B5AC: andi        $s6, $v0, 0xFFFF
    ctx->r22 = ctx->r2 & 0XFFFF;
    after_11:
    // 0x8038B5B0: jal         0x8012826C
    // 0x8038B5B4: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x8038B5B4: andi        $s3, $v0, 0xFFFF
    ctx->r19 = ctx->r2 & 0XFFFF;
    after_12:
    // 0x8038B5B8: jal         0x8012826C
    // 0x8038B5BC: andi        $s4, $v0, 0xFFFF
    ctx->r20 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_13;
    // 0x8038B5BC: andi        $s4, $v0, 0xFFFF
    ctx->r20 = ctx->r2 & 0XFFFF;
    after_13:
    // 0x8038B5C0: jal         0x8012826C
    // 0x8038B5C4: andi        $s1, $v0, 0xFFFF
    ctx->r17 = ctx->r2 & 0XFFFF;
    advance_random_seed(rdram, ctx);
        goto after_14;
    // 0x8038B5C4: andi        $s1, $v0, 0xFFFF
    ctx->r17 = ctx->r2 & 0XFFFF;
    after_14:
    // 0x8038B5C8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038B5CC: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x8038B5D0: lui         $s0, 0x803D
    ctx->r16 = S32(0X803D << 16);
    // 0x8038B5D4: lw          $s0, 0x5530($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X5530);
    // 0x8038B5D8: lh          $v1, 0x302($t6)
    ctx->r3 = MEM_H(ctx->r14, 0X302);
    // 0x8038B5DC: andi        $t1, $s5, 0xF
    ctx->r9 = ctx->r21 & 0XF;
    // 0x8038B5E0: lh          $t9, 0x4($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X4);
    // 0x8038B5E4: negu        $v1, $v1
    ctx->r3 = SUB32(0, ctx->r3);
    // 0x8038B5E8: sll         $t7, $v1, 16
    ctx->r15 = S32(ctx->r3 << 16);
    // 0x8038B5EC: sra         $v1, $t7, 16
    ctx->r3 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8038B5F0: addiu       $t2, $v1, 0x40
    ctx->r10 = ADD32(ctx->r3, 0X40);
    // 0x8038B5F4: andi        $t3, $t2, 0xFF
    ctx->r11 = ctx->r10 & 0XFF;
    // 0x8038B5F8: sll         $t5, $t3, 1
    ctx->r13 = S32(ctx->r11 << 1);
    // 0x8038B5FC: addu        $t6, $s7, $t5
    ctx->r14 = ADD32(ctx->r23, ctx->r13);
    // 0x8038B600: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x8038B604: andi        $t6, $v1, 0xFF
    ctx->r14 = ctx->r3 & 0XFF;
    // 0x8038B608: addu        $t4, $t1, $t9
    ctx->r12 = ADD32(ctx->r9, ctx->r25);
    // 0x8038B60C: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8038B610: multu       $s2, $t8
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038B614: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8038B618: addu        $t8, $s7, $t7
    ctx->r24 = ADD32(ctx->r23, ctx->r15);
    // 0x8038B61C: lh          $t3, 0x8($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X8);
    // 0x8038B620: andi        $t2, $s6, 0xF
    ctx->r10 = ctx->r22 & 0XF;
    // 0x8038B624: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x8038B628: addu        $t5, $t2, $t3
    ctx->r13 = ADD32(ctx->r10, ctx->r11);
    // 0x8038B62C: lw          $t3, 0x1C($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X1C);
    // 0x8038B630: lui         $at, 0xFFFB
    ctx->r1 = S32(0XFFFB << 16);
    // 0x8038B634: ori         $at, $at, 0x6C20
    ctx->r1 = ctx->r1 | 0X6C20;
    // 0x8038B638: mflo        $t1
    ctx->r9 = lo;
    // 0x8038B63C: sra         $t9, $t1, 8
    ctx->r25 = S32(SIGNED(ctx->r9) >> 8);
    // 0x8038B640: lh          $t1, 0x0($t8)
    ctx->r9 = MEM_H(ctx->r24, 0X0);
    // 0x8038B644: addu        $a0, $t4, $t9
    ctx->r4 = ADD32(ctx->r12, ctx->r25);
    // 0x8038B648: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x8038B64C: sra         $t4, $t1, 7
    ctx->r12 = S32(SIGNED(ctx->r9) >> 7);
    // 0x8038B650: multu       $s2, $t4
    result = U64(U32(ctx->r18)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8038B654: lw          $t6, 0x20($s0)
    ctx->r14 = MEM_W(ctx->r16, 0X20);
    // 0x8038B658: andi        $t1, $s3, 0xF
    ctx->r9 = ctx->r19 & 0XF;
    // 0x8038B65C: addiu       $t4, $t1, 0x19
    ctx->r12 = ADD32(ctx->r9, 0X19);
    // 0x8038B660: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8038B664: lw          $t7, 0x24($s0)
    ctx->r15 = MEM_W(ctx->r16, 0X24);
    // 0x8038B668: andi        $t6, $s4, 0x3F
    ctx->r14 = ctx->r20 & 0X3F;
    // 0x8038B66C: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x8038B670: addu        $t8, $t7, $at
    ctx->r24 = ADD32(ctx->r15, ctx->r1);
    // 0x8038B674: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x8038B678: mflo        $t9
    ctx->r25 = lo;
    // 0x8038B67C: sra         $t2, $t9, 8
    ctx->r10 = S32(SIGNED(ctx->r25) >> 8);
    // 0x8038B680: addu        $a1, $t5, $t2
    ctx->r5 = ADD32(ctx->r13, ctx->r10);
    // 0x8038B684: andi        $t9, $s1, 0x1F
    ctx->r25 = ctx->r17 & 0X1F;
    // 0x8038B688: addiu       $t5, $t9, 0xC0
    ctx->r13 = ADD32(ctx->r25, 0XC0);
    // 0x8038B68C: sll         $t2, $t5, 3
    ctx->r10 = S32(ctx->r13 << 3);
    // 0x8038B690: andi        $t3, $t2, 0x7C0
    ctx->r11 = ctx->r10 & 0X7C0;
    // 0x8038B694: andi        $t5, $v0, 0x3F
    ctx->r13 = ctx->r2 & 0X3F;
    // 0x8038B698: addiu       $t7, $t6, 0xC0
    ctx->r15 = ADD32(ctx->r14, 0XC0);
    // 0x8038B69C: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x8038B6A0: addiu       $t2, $t5, 0xC0
    ctx->r10 = ADD32(ctx->r13, 0XC0);
    // 0x8038B6A4: sll         $t6, $t2, 8
    ctx->r14 = S32(ctx->r10 << 8);
    // 0x8038B6A8: andi        $t1, $t8, 0xF800
    ctx->r9 = ctx->r24 & 0XF800;
    // 0x8038B6AC: or          $t4, $t3, $t1
    ctx->r12 = ctx->r11 | ctx->r9;
    // 0x8038B6B0: andi        $t7, $t6, 0xF800
    ctx->r15 = ctx->r14 & 0XF800;
    // 0x8038B6B4: ori         $t8, $t7, 0x1
    ctx->r24 = ctx->r15 | 0X1;
    // 0x8038B6B8: ori         $t9, $t4, 0x1
    ctx->r25 = ctx->r12 | 0X1;
    // 0x8038B6BC: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x8038B6C0: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x8038B6C4: addiu       $a1, $a1, -0x8
    ctx->r5 = ADD32(ctx->r5, -0X8);
    // 0x8038B6C8: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x8038B6CC: addiu       $a0, $a0, -0x8
    ctx->r4 = ADD32(ctx->r4, -0X8);
    // 0x8038B6D0: jal         0x802D5F4C
    // 0x8038B6D4: addiu       $a3, $zero, 0x3F
    ctx->r7 = ADD32(0, 0X3F);
    create_particle_effect(rdram, ctx);
        goto after_15;
    // 0x8038B6D4: addiu       $a3, $zero, 0x3F
    ctx->r7 = ADD32(0, 0X3F);
    after_15:
    // 0x8038B6D8: addiu       $s2, $s2, 0x20
    ctx->r18 = ADD32(ctx->r18, 0X20);
    // 0x8038B6DC: sll         $t3, $s2, 16
    ctx->r11 = S32(ctx->r18 << 16);
    // 0x8038B6E0: sra         $s2, $t3, 16
    ctx->r18 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8038B6E4: slti        $at, $s2, 0x11
    ctx->r1 = SIGNED(ctx->r18) < 0X11 ? 1 : 0;
    // 0x8038B6E8: bne         $at, $zero, L_8038B448
    if (ctx->r1 != 0) {
        // 0x8038B6EC: nop
    
            goto L_8038B448;
    }
    // 0x8038B6EC: nop

    // 0x8038B6F0: b           L_8038B704
    // 0x8038B6F4: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
        goto L_8038B704;
    // 0x8038B6F4: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_8038B6F8:
    // 0x8038B6F8: jal         0x8035E3E8
    // 0x8038B6FC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    recharge_skill(rdram, ctx);
        goto after_16;
    // 0x8038B6FC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_16:
    // 0x8038B700: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
L_8038B704:
    // 0x8038B704: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x8038B708: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x8038B70C: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x8038B710: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x8038B714: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x8038B718: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x8038B71C: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x8038B720: lw          $s7, 0x54($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X54);
    // 0x8038B724: lw          $fp, 0x58($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X58);
    // 0x8038B728: jr          $ra
    // 0x8038B72C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x8038B72C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void func_8038B730_79CDE0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B730: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8038B734: lw          $t6, 0x5528($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5528);
    // 0x8038B738: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038B73C: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x8038B740: sh          $zero, 0x3C0($t6)
    MEM_H(0X3C0, ctx->r14) = 0;
    // 0x8038B744: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8038B748: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x8038B74C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8038B750: sh          $t7, 0x30C($t8)
    MEM_H(0X30C, ctx->r24) = ctx->r15;
    // 0x8038B754: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x8038B758: lb          $t0, 0x4A($t9)
    ctx->r8 = MEM_B(ctx->r25, 0X4A);
    // 0x8038B75C: beq         $t0, $zero, L_8038B76C
    if (ctx->r8 == 0) {
        // 0x8038B760: nop
    
            goto L_8038B76C;
    }
    // 0x8038B760: nop

    // 0x8038B764: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x8038B768: sh          $zero, 0x30C($t1)
    MEM_H(0X30C, ctx->r9) = 0;
L_8038B76C:
    // 0x8038B76C: jr          $ra
    // 0x8038B770: nop

    return;
    // 0x8038B770: nop

;}
RECOMP_FUNC void func_8038B774_79CE24(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B774: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8038B778: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x8038B77C: lw          $t6, 0x0($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X0);
    // 0x8038B780: sh          $zero, 0x30C($t6)
    MEM_H(0X30C, ctx->r14) = 0;
    // 0x8038B784: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x8038B788: sh          $zero, 0x30E($t7)
    MEM_H(0X30E, ctx->r15) = 0;
    // 0x8038B78C: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x8038B790: jr          $ra
    // 0x8038B794: sh          $zero, 0x310($t8)
    MEM_H(0X310, ctx->r24) = 0;
    return;
    // 0x8038B794: sh          $zero, 0x310($t8)
    MEM_H(0X310, ctx->r24) = 0;
;}
RECOMP_FUNC void func_8038B798_79CE48(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B798: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8038B79C: lh          $a0, 0x5534($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X5534);
    // 0x8038B7A0: lui         $t7, 0x801E
    ctx->r15 = S32(0X801E << 16);
    // 0x8038B7A4: addiu       $t7, $t7, -0x6128
    ctx->r15 = ADD32(ctx->r15, -0X6128);
    // 0x8038B7A8: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x8038B7AC: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x8038B7B0: addiu       $t8, $v0, 0x3EB0
    ctx->r24 = ADD32(ctx->r2, 0X3EB0);
    // 0x8038B7B4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B7B8: sw          $t8, 0x5520($at)
    MEM_W(0X5520, ctx->r1) = ctx->r24;
    // 0x8038B7BC: lw          $t9, 0x3EB0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X3EB0);
    // 0x8038B7C0: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B7C4: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x8038B7C8: sw          $t9, 0x5524($at)
    MEM_W(0X5524, ctx->r1) = ctx->r25;
    // 0x8038B7CC: lw          $t0, 0x3EB4($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X3EB4);
    // 0x8038B7D0: addiu       $a1, $a1, 0x5528
    ctx->r5 = ADD32(ctx->r5, 0X5528);
    // 0x8038B7D4: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B7D8: sw          $t0, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r8;
    // 0x8038B7DC: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x8038B7E0: sw          $t0, 0x552C($at)
    MEM_W(0X552C, ctx->r1) = ctx->r8;
    // 0x8038B7E4: addiu       $a2, $a2, 0x5530
    ctx->r6 = ADD32(ctx->r6, 0X5530);
    // 0x8038B7E8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B7EC: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8038B7F0: sw          $t0, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r8;
    // 0x8038B7F4: sb          $t1, 0x5538($at)
    MEM_B(0X5538, ctx->r1) = ctx->r9;
    // 0x8038B7F8: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B7FC: sh          $a0, 0x553C($at)
    MEM_H(0X553C, ctx->r1) = ctx->r4;
    // 0x8038B800: lui         $at, 0x803D
    ctx->r1 = S32(0X803D << 16);
    // 0x8038B804: sh          $zero, 0x553A($at)
    MEM_H(0X553A, ctx->r1) = 0;
    // 0x8038B808: lw          $t2, 0x0($a2)
    ctx->r10 = MEM_W(ctx->r6, 0X0);
    // 0x8038B80C: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8038B810: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8038B814: lbu         $t3, 0x162($t2)
    ctx->r11 = MEM_BU(ctx->r10, 0X162);
    // 0x8038B818: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8038B81C: bnel        $t3, $at, L_8038B830
    if (ctx->r11 != ctx->r1) {
        // 0x8038B820: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8038B830;
    }
    goto skip_0;
    // 0x8038B820: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x8038B824: jal         0x802A6390
    // 0x8038B828: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_0;
    // 0x8038B828: nop

    after_0:
    // 0x8038B82C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8038B830:
    // 0x8038B830: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8038B834: jr          $ra
    // 0x8038B838: nop

    return;
    // 0x8038B838: nop

;}
RECOMP_FUNC void reset_credits_counters(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B840: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038B844: sh          $zero, 0x6400($at)
    MEM_H(0X6400, ctx->r1) = 0;
    // 0x8038B848: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8038B84C: jr          $ra
    // 0x8038B850: sh          $zero, 0x6402($at)
    MEM_H(0X6402, ctx->r1) = 0;
    return;
    // 0x8038B850: sh          $zero, 0x6402($at)
    MEM_H(0X6402, ctx->r1) = 0;
;}
RECOMP_FUNC void display_credits(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8038B854: addiu       $sp, $sp, -0x108
    ctx->r29 = ADD32(ctx->r29, -0X108);
    // 0x8038B858: sw          $ra, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r31;
    // 0x8038B85C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038B860: sw          $fp, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r30;
    // 0x8038B864: sw          $s7, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r23;
    // 0x8038B868: sw          $s6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r22;
    // 0x8038B86C: sw          $s5, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r21;
    // 0x8038B870: sw          $s4, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r20;
    // 0x8038B874: sw          $s3, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r19;
    // 0x8038B878: sw          $s2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r18;
    // 0x8038B87C: sw          $s1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r17;
    // 0x8038B880: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x8038B884: sdc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    SD(ctx->f20.u64, 0X20, ctx->r29);
    // 0x8038B888: jal         0x8012C1F0
    // 0x8038B88C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    load_default_display_list(rdram, ctx);
        goto after_0;
    // 0x8038B88C: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    after_0:
    // 0x8038B890: addiu       $a0, $zero, 0xFF
    ctx->r4 = ADD32(0, 0XFF);
    // 0x8038B894: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
    // 0x8038B898: addiu       $a2, $zero, 0xFF
    ctx->r6 = ADD32(0, 0XFF);
    // 0x8038B89C: jal         0x8012C214
    // 0x8038B8A0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    set_menu_text_color(rdram, ctx);
        goto after_1;
    // 0x8038B8A0: addiu       $a3, $zero, 0xFF
    ctx->r7 = ADD32(0, 0XFF);
    after_1:
    // 0x8038B8A4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x8038B8A8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x8038B8AC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8038B8B0: jal         0x8012C248
    // 0x8038B8B4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    select_font(rdram, ctx);
        goto after_2;
    // 0x8038B8B4: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_2:
    // 0x8038B8B8: lui         $at, 0x4180
    ctx->r1 = S32(0X4180 << 16);
    // 0x8038B8BC: lui         $s6, 0x803B
    ctx->r22 = S32(0X803B << 16);
    // 0x8038B8C0: lui         $s5, 0x803C
    ctx->r21 = S32(0X803C << 16);
    // 0x8038B8C4: lui         $s4, 0x803F
    ctx->r20 = S32(0X803F << 16);
    // 0x8038B8C8: lui         $s3, 0x803F
    ctx->r19 = S32(0X803F << 16);
    // 0x8038B8CC: mtc1        $at, $f20
    ctx->f20.u32l = ctx->r1;
    // 0x8038B8D0: addiu       $s3, $s3, 0x6400
    ctx->r19 = ADD32(ctx->r19, 0X6400);
    // 0x8038B8D4: addiu       $s4, $s4, 0x6402
    ctx->r20 = ADD32(ctx->r20, 0X6402);
    // 0x8038B8D8: addiu       $s5, $s5, -0x570
    ctx->r21 = ADD32(ctx->r21, -0X570);
    // 0x8038B8DC: addiu       $s6, $s6, 0x6000
    ctx->r22 = ADD32(ctx->r22, 0X6000);
    // 0x8038B8E0: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8038B8E4: addiu       $fp, $zero, 0x4E
    ctx->r30 = ADD32(0, 0X4E);
    // 0x8038B8E8: addiu       $s7, $zero, 0x45
    ctx->r23 = ADD32(0, 0X45);
    // 0x8038B8EC: addiu       $s2, $sp, 0x90
    ctx->r18 = ADD32(ctx->r29, 0X90);
    // 0x8038B8F0: addiu       $s1, $sp, 0x50
    ctx->r17 = ADD32(ctx->r29, 0X50);
    // 0x8038B8F4: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
L_8038B8F8:
    // 0x8038B8F8: sll         $t6, $s0, 2
    ctx->r14 = S32(ctx->r16 << 2);
    // 0x8038B8FC: addu        $t7, $s6, $t6
    ctx->r15 = ADD32(ctx->r22, ctx->r14);
    // 0x8038B900: sll         $t9, $t8, 2
    ctx->r25 = S32(ctx->r24 << 2);
    // 0x8038B904: addu        $t0, $t7, $t9
    ctx->r8 = ADD32(ctx->r15, ctx->r25);
    // 0x8038B908: lw          $a2, 0x0($t0)
    ctx->r6 = MEM_W(ctx->r8, 0X0);
    // 0x8038B90C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038B910: jal         0x801395F4
    // 0x8038B914: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    sprintf_recomp(rdram, ctx);
        goto after_3;
    // 0x8038B914: or          $a1, $s5, $zero
    ctx->r5 = ctx->r21 | 0;
    after_3:
    // 0x8038B918: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    // 0x8038B91C: jal         0x801308B4
    // 0x8038B920: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    prepare_text(rdram, ctx);
        goto after_4;
    // 0x8038B920: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    after_4:
    // 0x8038B924: lbu         $t1, 0x50($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X50);
    // 0x8038B928: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8038B92C: lbu         $t2, 0x51($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X51);
    // 0x8038B930: bne         $s7, $t1, L_8038B958
    if (ctx->r23 != ctx->r9) {
        // 0x8038B934: addiu       $a0, $a0, -0x6184
        ctx->r4 = ADD32(ctx->r4, -0X6184);
            goto L_8038B958;
    }
    // 0x8038B934: addiu       $a0, $a0, -0x6184
    ctx->r4 = ADD32(ctx->r4, -0X6184);
    // 0x8038B938: bne         $fp, $t2, L_8038B958
    if (ctx->r30 != ctx->r10) {
        // 0x8038B93C: lbu         $t3, 0x52($sp)
        ctx->r11 = MEM_BU(ctx->r29, 0X52);
            goto L_8038B958;
    }
    // 0x8038B93C: lbu         $t3, 0x52($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X52);
    // 0x8038B940: addiu       $at, $zero, 0x44
    ctx->r1 = ADD32(0, 0X44);
    // 0x8038B944: bnel        $t3, $at, L_8038B95C
    if (ctx->r11 != ctx->r1) {
        // 0x8038B948: lh          $t6, 0x0($s4)
        ctx->r14 = MEM_H(ctx->r20, 0X0);
            goto L_8038B95C;
    }
    goto skip_0;
    // 0x8038B948: lh          $t6, 0x0($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X0);
    skip_0:
    // 0x8038B94C: sh          $zero, 0x0($s3)
    MEM_H(0X0, ctx->r19) = 0;
    // 0x8038B950: b           L_8038B998
    // 0x8038B954: addiu       $s0, $zero, 0x3E8
    ctx->r16 = ADD32(0, 0X3E8);
        goto L_8038B998;
    // 0x8038B954: addiu       $s0, $zero, 0x3E8
    ctx->r16 = ADD32(0, 0X3E8);
L_8038B958:
    // 0x8038B958: lh          $t6, 0x0($s4)
    ctx->r14 = MEM_H(ctx->r20, 0X0);
L_8038B95C:
    // 0x8038B95C: lui         $a2, 0x8020
    ctx->r6 = S32(0X8020 << 16);
    // 0x8038B960: lh          $a2, 0x3FD0($a2)
    ctx->r6 = MEM_H(ctx->r6, 0X3FD0);
    // 0x8038B964: sll         $t8, $s0, 4
    ctx->r24 = S32(ctx->r16 << 4);
    // 0x8038B968: addu        $a3, $t6, $t8
    ctx->r7 = ADD32(ctx->r14, ctx->r24);
    // 0x8038B96C: andi        $t7, $a3, 0xFFFF
    ctx->r15 = ctx->r7 & 0XFFFF;
    // 0x8038B970: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x8038B974: or          $a1, $s2, $zero
    ctx->r5 = ctx->r18 | 0;
    // 0x8038B978: bgez        $a2, L_8038B988
    if (SIGNED(ctx->r6) >= 0) {
        // 0x8038B97C: sra         $t4, $a2, 1
        ctx->r12 = S32(SIGNED(ctx->r6) >> 1);
            goto L_8038B988;
    }
    // 0x8038B97C: sra         $t4, $a2, 1
    ctx->r12 = S32(SIGNED(ctx->r6) >> 1);
    // 0x8038B980: addiu       $at, $a2, 0x1
    ctx->r1 = ADD32(ctx->r6, 0X1);
    // 0x8038B984: sra         $t4, $at, 1
    ctx->r12 = S32(SIGNED(ctx->r1) >> 1);
L_8038B988:
    // 0x8038B988: andi        $a2, $t4, 0xFFFF
    ctx->r6 = ctx->r12 & 0XFFFF;
    // 0x8038B98C: swc1        $f20, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f20.u32l;
    // 0x8038B990: jal         0x8012C978
    // 0x8038B994: swc1        $f20, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f20.u32l;
    display_text_centered(rdram, ctx);
        goto after_5;
    // 0x8038B994: swc1        $f20, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->f20.u32l;
    after_5:
L_8038B998:
    // 0x8038B998: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8038B99C: sll         $t9, $s0, 16
    ctx->r25 = S32(ctx->r16 << 16);
    // 0x8038B9A0: sra         $s0, $t9, 16
    ctx->r16 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8038B9A4: slti        $at, $s0, 0x10
    ctx->r1 = SIGNED(ctx->r16) < 0X10 ? 1 : 0;
    // 0x8038B9A8: bnel        $at, $zero, L_8038B8F8
    if (ctx->r1 != 0) {
        // 0x8038B9AC: lh          $t8, 0x0($s3)
        ctx->r24 = MEM_H(ctx->r19, 0X0);
            goto L_8038B8F8;
    }
    goto skip_1;
    // 0x8038B9AC: lh          $t8, 0x0($s3)
    ctx->r24 = MEM_H(ctx->r19, 0X0);
    skip_1:
    // 0x8038B9B0: lh          $t1, 0x0($s4)
    ctx->r9 = MEM_H(ctx->r20, 0X0);
    // 0x8038B9B4: addiu       $at, $zero, -0x10
    ctx->r1 = ADD32(0, -0X10);
    // 0x8038B9B8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8038B9BC: addiu       $t2, $t1, -0x1
    ctx->r10 = ADD32(ctx->r9, -0X1);
    // 0x8038B9C0: sh          $t2, 0x0($s4)
    MEM_H(0X0, ctx->r20) = ctx->r10;
    // 0x8038B9C4: lh          $t3, 0x0($s4)
    ctx->r11 = MEM_H(ctx->r20, 0X0);
    // 0x8038B9C8: bnel        $t3, $at, L_8038B9E4
    if (ctx->r11 != ctx->r1) {
        // 0x8038B9CC: slti        $at, $s0, 0x65
        ctx->r1 = SIGNED(ctx->r16) < 0X65 ? 1 : 0;
            goto L_8038B9E4;
    }
    goto skip_2;
    // 0x8038B9CC: slti        $at, $s0, 0x65
    ctx->r1 = SIGNED(ctx->r16) < 0X65 ? 1 : 0;
    skip_2:
    // 0x8038B9D0: lh          $t4, 0x0($s3)
    ctx->r12 = MEM_H(ctx->r19, 0X0);
    // 0x8038B9D4: sh          $zero, 0x0($s4)
    MEM_H(0X0, ctx->r20) = 0;
    // 0x8038B9D8: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8038B9DC: sh          $t5, 0x0($s3)
    MEM_H(0X0, ctx->r19) = ctx->r13;
    // 0x8038B9E0: slti        $at, $s0, 0x65
    ctx->r1 = SIGNED(ctx->r16) < 0X65 ? 1 : 0;
L_8038B9E4:
    // 0x8038B9E4: bne         $at, $zero, L_8038B9F4
    if (ctx->r1 != 0) {
        // 0x8038B9E8: ldc1        $f20, 0x20($sp)
        CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
            goto L_8038B9F4;
    }
    // 0x8038B9E8: ldc1        $f20, 0x20($sp)
    CHECK_FR(ctx, 20);
    ctx->f20.u64 = LD(ctx->r29, 0X20);
    // 0x8038B9EC: b           L_8038B9F4
    // 0x8038B9F0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_8038B9F4;
    // 0x8038B9F0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_8038B9F4:
    // 0x8038B9F4: lw          $ra, 0x4C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X4C);
    // 0x8038B9F8: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x8038B9FC: lw          $s1, 0x2C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X2C);
    // 0x8038BA00: lw          $s2, 0x30($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X30);
    // 0x8038BA04: lw          $s3, 0x34($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X34);
    // 0x8038BA08: lw          $s4, 0x38($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X38);
    // 0x8038BA0C: lw          $s5, 0x3C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X3C);
    // 0x8038BA10: lw          $s6, 0x40($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X40);
    // 0x8038BA14: lw          $s7, 0x44($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X44);
    // 0x8038BA18: lw          $fp, 0x48($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X48);
    // 0x8038BA1C: jr          $ra
    // 0x8038BA20: addiu       $sp, $sp, 0x108
    ctx->r29 = ADD32(ctx->r29, 0X108);
    return;
    // 0x8038BA20: addiu       $sp, $sp, 0x108
    ctx->r29 = ADD32(ctx->r29, 0X108);
;}
