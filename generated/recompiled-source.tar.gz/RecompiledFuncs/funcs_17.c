#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void func_802FC108_70D7B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC108: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FC10C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FC110: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FC114: lh          $v0, 0x15E($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X15E);
    // 0x802FC118: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FC11C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FC120: bne         $v0, $zero, L_802FC140
    if (ctx->r2 != 0) {
        // 0x802FC124: addiu       $t9, $zero, 0x64
        ctx->r25 = ADD32(0, 0X64);
            goto L_802FC140;
    }
    // 0x802FC124: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FC128: lhu         $t0, 0x40($a0)
    ctx->r8 = MEM_HU(ctx->r4, 0X40);
    // 0x802FC12C: sll         $t6, $t0, 5
    ctx->r14 = S32(ctx->r8 << 5);
    // 0x802FC130: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FC134: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FC138: b           L_802FC14C
    // 0x802FC13C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
        goto L_802FC14C;
    // 0x802FC13C: sra         $t0, $t8, 16
    ctx->r8 = S32(SIGNED(ctx->r24) >> 16);
L_802FC140:
    // 0x802FC140: sll         $t0, $v0, 16
    ctx->r8 = S32(ctx->r2 << 16);
    // 0x802FC144: sra         $t1, $t0, 16
    ctx->r9 = S32(SIGNED(ctx->r8) >> 16);
    // 0x802FC148: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
L_802FC14C:
    // 0x802FC14C: lw          $v0, 0x168($s0)
    ctx->r2 = MEM_W(ctx->r16, 0X168);
    // 0x802FC150: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x802FC154: beql        $v0, $zero, L_802FC17C
    if (ctx->r2 == 0) {
        // 0x802FC158: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FC17C;
    }
    goto skip_0;
    // 0x802FC158: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_0:
    // 0x802FC15C: lw          $v1, 0x16C($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X16C);
    // 0x802FC160: lw          $t2, 0x80($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X80);
    // 0x802FC164: sll         $t4, $t2, 18
    ctx->r12 = S32(ctx->r10 << 18);
    // 0x802FC168: bgezl       $t4, L_802FC17C
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FC16C: addiu       $v0, $zero, -0x1
        ctx->r2 = ADD32(0, -0X1);
            goto L_802FC17C;
    }
    goto skip_1;
    // 0x802FC16C: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
    skip_1:
    // 0x802FC170: b           L_802FC17C
    // 0x802FC174: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
        goto L_802FC17C;
    // 0x802FC174: lb          $v0, 0xE6($v1)
    ctx->r2 = MEM_B(ctx->r3, 0XE6);
    // 0x802FC178: addiu       $v0, $zero, -0x1
    ctx->r2 = ADD32(0, -0X1);
L_802FC17C:
    // 0x802FC17C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FC180: lhu         $t6, 0x42($s0)
    ctx->r14 = MEM_HU(ctx->r16, 0X42);
    // 0x802FC184: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FC188: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FC18C: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x802FC190: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x802FC194: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FC198: sw          $v0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r2;
    // 0x802FC19C: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x802FC1A0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FC1A4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FC1A8: jal         0x802FF184
    // 0x802FC1AC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    func_802FF184_710834(rdram, ctx);
        goto after_0;
    // 0x802FC1AC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x802FC1B0: lh          $t1, 0x4($s0)
    ctx->r9 = MEM_H(ctx->r16, 0X4);
    // 0x802FC1B4: sw          $t1, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r9;
    // 0x802FC1B8: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FC1BC: sra         $t4, $t1, 6
    ctx->r12 = S32(SIGNED(ctx->r9) >> 6);
    // 0x802FC1C0: sll         $t6, $t4, 7
    ctx->r14 = S32(ctx->r12 << 7);
    // 0x802FC1C4: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x802FC1C8: sra         $t7, $t2, 6
    ctx->r15 = S32(SIGNED(ctx->r10) >> 6);
    // 0x802FC1CC: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FC1D0: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FC1D4: lui         $t1, 0x803C
    ctx->r9 = S32(0X803C << 16);
    // 0x802FC1D8: addiu       $t1, $t1, 0x740
    ctx->r9 = ADD32(ctx->r9, 0X740);
    // 0x802FC1DC: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x802FC1E0: addu        $v0, $t9, $t1
    ctx->r2 = ADD32(ctx->r25, ctx->r9);
    // 0x802FC1E4: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FC1E8: lbu         $a0, 0x6($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X6);
    // 0x802FC1EC: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FC1F0: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FC1F4: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FC1F8: beq         $at, $zero, L_802FC208
    if (ctx->r1 == 0) {
        // 0x802FC1FC: nop
    
            goto L_802FC208;
    }
    // 0x802FC1FC: nop

    // 0x802FC200: b           L_802FC208
    // 0x802FC204: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
        goto L_802FC208;
    // 0x802FC204: or          $a3, $a0, $zero
    ctx->r7 = ctx->r4 | 0;
L_802FC208:
    // 0x802FC208: lbu         $a1, 0x416($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X416);
    // 0x802FC20C: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FC210: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FC214: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC218: beq         $at, $zero, L_802FC228
    if (ctx->r1 == 0) {
        // 0x802FC21C: nop
    
            goto L_802FC228;
    }
    // 0x802FC21C: nop

    // 0x802FC220: b           L_802FC228
    // 0x802FC224: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC228;
    // 0x802FC224: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC228:
    // 0x802FC228: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FC22C: beq         $at, $zero, L_802FC250
    if (ctx->r1 == 0) {
        // 0x802FC230: lh          $a3, 0x3E($sp)
        ctx->r7 = MEM_H(ctx->r29, 0X3E);
            goto L_802FC250;
    }
    // 0x802FC230: lh          $a3, 0x3E($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X3E);
    // 0x802FC234: slt         $at, $v1, $a0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x802FC238: beq         $at, $zero, L_802FC248
    if (ctx->r1 == 0) {
        // 0x802FC23C: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FC248;
    }
    // 0x802FC23C: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FC240: b           L_802FC268
    // 0x802FC244: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
        goto L_802FC268;
    // 0x802FC244: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_802FC248:
    // 0x802FC248: b           L_802FC268
    // 0x802FC24C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FC268;
    // 0x802FC24C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC250:
    // 0x802FC250: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC254: beq         $at, $zero, L_802FC264
    if (ctx->r1 == 0) {
        // 0x802FC258: or          $v0, $a1, $zero
        ctx->r2 = ctx->r5 | 0;
            goto L_802FC264;
    }
    // 0x802FC258: or          $v0, $a1, $zero
    ctx->r2 = ctx->r5 | 0;
    // 0x802FC25C: b           L_802FC264
    // 0x802FC260: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC264;
    // 0x802FC260: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC264:
    // 0x802FC264: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC268:
    // 0x802FC268: lh          $v0, 0xC($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XC);
    // 0x802FC26C: sll         $t2, $v1, 2
    ctx->r10 = S32(ctx->r3 << 2);
    // 0x802FC270: addiu       $a1, $zero, 0x7
    ctx->r5 = ADD32(0, 0X7);
    // 0x802FC274: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FC278: beq         $at, $zero, L_802FC288
    if (ctx->r1 == 0) {
        // 0x802FC27C: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FC288;
    }
    // 0x802FC27C: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FC280: b           L_802FC288
    // 0x802FC284: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
        goto L_802FC288;
    // 0x802FC284: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
L_802FC288:
    // 0x802FC288: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FC28C: lh          $t3, 0x30($s0)
    ctx->r11 = MEM_H(ctx->r16, 0X30);
    // 0x802FC290: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FC294: lh          $a2, 0x42($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X42);
    // 0x802FC298: sra         $t4, $t3, 2
    ctx->r12 = S32(SIGNED(ctx->r11) >> 2);
    // 0x802FC29C: jal         0x802D7BE0
    // 0x802FC2A0: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FC2A0: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_1:
    // 0x802FC2A4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FC2A8: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FC2AC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FC2B0: jr          $ra
    // 0x802FC2B4: nop

    return;
    // 0x802FC2B4: nop

;}
RECOMP_FUNC void func_802FC2B8_70D968(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC2B8: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FC2BC: sw          $fp, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r30;
    // 0x802FC2C0: sw          $s7, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r23;
    // 0x802FC2C4: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x802FC2C8: sll         $s6, $a0, 16
    ctx->r22 = S32(ctx->r4 << 16);
    // 0x802FC2CC: sll         $s7, $a1, 16
    ctx->r23 = S32(ctx->r5 << 16);
    // 0x802FC2D0: sll         $fp, $a2, 16
    ctx->r30 = S32(ctx->r6 << 16);
    // 0x802FC2D4: sra         $t8, $fp, 16
    ctx->r24 = S32(SIGNED(ctx->r30) >> 16);
    // 0x802FC2D8: sra         $t7, $s7, 16
    ctx->r15 = S32(SIGNED(ctx->r23) >> 16);
    // 0x802FC2DC: sra         $t6, $s6, 16
    ctx->r14 = S32(SIGNED(ctx->r22) >> 16);
    // 0x802FC2E0: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x802FC2E4: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x802FC2E8: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x802FC2EC: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802FC2F0: or          $s6, $t6, $zero
    ctx->r22 = ctx->r14 | 0;
    // 0x802FC2F4: or          $s7, $t7, $zero
    ctx->r23 = ctx->r15 | 0;
    // 0x802FC2F8: or          $fp, $t8, $zero
    ctx->r30 = ctx->r24 | 0;
    // 0x802FC2FC: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x802FC300: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x802FC304: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x802FC308: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x802FC30C: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x802FC310: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x802FC314: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x802FC318: lui         $s3, 0x6
    ctx->r19 = S32(0X6 << 16);
    // 0x802FC31C: lui         $s4, 0xFFFD
    ctx->r20 = S32(0XFFFD << 16);
    // 0x802FC320: lui         $s5, 0x3
    ctx->r21 = S32(0X3 << 16);
L_802FC324:
    // 0x802FC324: jal         0x80128200
    // 0x802FC328: nop

    func_80128200(rdram, ctx);
        goto after_0;
    // 0x802FC328: nop

    after_0:
    // 0x802FC32C: div         $zero, $v0, $s3
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r19)));
    // 0x802FC330: mfhi        $t9
    ctx->r25 = hi;
    // 0x802FC334: addu        $s1, $t9, $s4
    ctx->r17 = ADD32(ctx->r25, ctx->r20);
    // 0x802FC338: bne         $s3, $zero, L_802FC344
    if (ctx->r19 != 0) {
        // 0x802FC33C: nop
    
            goto L_802FC344;
    }
    // 0x802FC33C: nop

    // 0x802FC340: break       7
    do_break(2150613824);
L_802FC344:
    // 0x802FC344: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FC348: bne         $s3, $at, L_802FC35C
    if (ctx->r19 != ctx->r1) {
        // 0x802FC34C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FC35C;
    }
    // 0x802FC34C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FC350: bne         $v0, $at, L_802FC35C
    if (ctx->r2 != ctx->r1) {
        // 0x802FC354: nop
    
            goto L_802FC35C;
    }
    // 0x802FC354: nop

    // 0x802FC358: break       6
    do_break(2150613848);
L_802FC35C:
    // 0x802FC35C: jal         0x80128200
    // 0x802FC360: nop

    func_80128200(rdram, ctx);
        goto after_1;
    // 0x802FC360: nop

    after_1:
    // 0x802FC364: div         $zero, $v0, $s3
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r19)));
    // 0x802FC368: mfhi        $t0
    ctx->r8 = hi;
    // 0x802FC36C: addu        $s2, $t0, $s4
    ctx->r18 = ADD32(ctx->r8, ctx->r20);
    // 0x802FC370: bne         $s3, $zero, L_802FC37C
    if (ctx->r19 != 0) {
        // 0x802FC374: nop
    
            goto L_802FC37C;
    }
    // 0x802FC374: nop

    // 0x802FC378: break       7
    do_break(2150613880);
L_802FC37C:
    // 0x802FC37C: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FC380: bne         $s3, $at, L_802FC394
    if (ctx->r19 != ctx->r1) {
        // 0x802FC384: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FC394;
    }
    // 0x802FC384: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FC388: bne         $v0, $at, L_802FC394
    if (ctx->r2 != ctx->r1) {
        // 0x802FC38C: nop
    
            goto L_802FC394;
    }
    // 0x802FC38C: nop

    // 0x802FC390: break       6
    do_break(2150613904);
L_802FC394:
    // 0x802FC394: jal         0x80128200
    // 0x802FC398: nop

    func_80128200(rdram, ctx);
        goto after_2;
    // 0x802FC398: nop

    after_2:
    // 0x802FC39C: addiu       $t3, $zero, 0x8
    ctx->r11 = ADD32(0, 0X8);
    // 0x802FC3A0: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x802FC3A4: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x802FC3A8: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    // 0x802FC3AC: or          $a2, $fp, $zero
    ctx->r6 = ctx->r30 | 0;
    // 0x802FC3B0: addiu       $a3, $zero, 0x23
    ctx->r7 = ADD32(0, 0X23);
    // 0x802FC3B4: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    // 0x802FC3B8: sw          $s2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r18;
    // 0x802FC3BC: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x802FC3C0: addiu       $at, $at, -0x1
    ctx->r1 = ADD32(ctx->r1, -0X1);
    // 0x802FC3C4: bgez        $v0, L_802FC3D8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FC3C8: and         $t1, $v0, $at
        ctx->r9 = ctx->r2 & ctx->r1;
            goto L_802FC3D8;
    }
    // 0x802FC3C8: and         $t1, $v0, $at
    ctx->r9 = ctx->r2 & ctx->r1;
    // 0x802FC3CC: beq         $t1, $zero, L_802FC3D8
    if (ctx->r9 == 0) {
        // 0x802FC3D0: addiu       $at, $at, 0x1
        ctx->r1 = ADD32(ctx->r1, 0X1);
            goto L_802FC3D8;
    }
    // 0x802FC3D0: addiu       $at, $at, 0x1
    ctx->r1 = ADD32(ctx->r1, 0X1);
    // 0x802FC3D4: subu        $t1, $t1, $at
    ctx->r9 = SUB32(ctx->r9, ctx->r1);
L_802FC3D8:
    // 0x802FC3D8: addu        $t2, $t1, $s5
    ctx->r10 = ADD32(ctx->r9, ctx->r21);
    // 0x802FC3DC: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x802FC3E0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FC3E4: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802FC3E8: jal         0x802D5F4C
    // 0x802FC3EC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    create_particle_effect(rdram, ctx);
        goto after_3;
    // 0x802FC3EC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    after_3:
    // 0x802FC3F0: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x802FC3F4: sll         $t4, $s0, 16
    ctx->r12 = S32(ctx->r16 << 16);
    // 0x802FC3F8: sra         $s0, $t4, 16
    ctx->r16 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FC3FC: slti        $at, $s0, 0xB
    ctx->r1 = SIGNED(ctx->r16) < 0XB ? 1 : 0;
    // 0x802FC400: bne         $at, $zero, L_802FC324
    if (ctx->r1 != 0) {
        // 0x802FC404: nop
    
            goto L_802FC324;
    }
    // 0x802FC404: nop

    // 0x802FC408: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
    // 0x802FC40C: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802FC410: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x802FC414: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x802FC418: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x802FC41C: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x802FC420: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x802FC424: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x802FC428: lw          $s7, 0x54($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X54);
    // 0x802FC42C: lw          $fp, 0x58($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X58);
    // 0x802FC430: jr          $ra
    // 0x802FC434: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x802FC434: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void func_802FC438_70DAE8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC438: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FC43C: sw          $fp, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r30;
    // 0x802FC440: sw          $s7, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r23;
    // 0x802FC444: sw          $s6, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r22;
    // 0x802FC448: sll         $s6, $a0, 16
    ctx->r22 = S32(ctx->r4 << 16);
    // 0x802FC44C: sll         $s7, $a1, 16
    ctx->r23 = S32(ctx->r5 << 16);
    // 0x802FC450: sll         $fp, $a2, 16
    ctx->r30 = S32(ctx->r6 << 16);
    // 0x802FC454: sra         $t8, $fp, 16
    ctx->r24 = S32(SIGNED(ctx->r30) >> 16);
    // 0x802FC458: sra         $t7, $s7, 16
    ctx->r15 = S32(SIGNED(ctx->r23) >> 16);
    // 0x802FC45C: sra         $t6, $s6, 16
    ctx->r14 = S32(SIGNED(ctx->r22) >> 16);
    // 0x802FC460: sw          $s5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r21;
    // 0x802FC464: sw          $s4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r20;
    // 0x802FC468: sw          $s3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r19;
    // 0x802FC46C: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802FC470: or          $s6, $t6, $zero
    ctx->r22 = ctx->r14 | 0;
    // 0x802FC474: or          $s7, $t7, $zero
    ctx->r23 = ctx->r15 | 0;
    // 0x802FC478: or          $fp, $t8, $zero
    ctx->r30 = ctx->r24 | 0;
    // 0x802FC47C: sw          $ra, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r31;
    // 0x802FC480: sw          $s2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r18;
    // 0x802FC484: sw          $s1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r17;
    // 0x802FC488: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x802FC48C: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x802FC490: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x802FC494: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x802FC498: lui         $s3, 0x6
    ctx->r19 = S32(0X6 << 16);
    // 0x802FC49C: lui         $s4, 0xFFFD
    ctx->r20 = S32(0XFFFD << 16);
    // 0x802FC4A0: lui         $s5, 0x3
    ctx->r21 = S32(0X3 << 16);
L_802FC4A4:
    // 0x802FC4A4: jal         0x80128200
    // 0x802FC4A8: nop

    func_80128200(rdram, ctx);
        goto after_0;
    // 0x802FC4A8: nop

    after_0:
    // 0x802FC4AC: div         $zero, $v0, $s3
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r19)));
    // 0x802FC4B0: mfhi        $t9
    ctx->r25 = hi;
    // 0x802FC4B4: addu        $s1, $t9, $s4
    ctx->r17 = ADD32(ctx->r25, ctx->r20);
    // 0x802FC4B8: bne         $s3, $zero, L_802FC4C4
    if (ctx->r19 != 0) {
        // 0x802FC4BC: nop
    
            goto L_802FC4C4;
    }
    // 0x802FC4BC: nop

    // 0x802FC4C0: break       7
    do_break(2150614208);
L_802FC4C4:
    // 0x802FC4C4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FC4C8: bne         $s3, $at, L_802FC4DC
    if (ctx->r19 != ctx->r1) {
        // 0x802FC4CC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FC4DC;
    }
    // 0x802FC4CC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FC4D0: bne         $v0, $at, L_802FC4DC
    if (ctx->r2 != ctx->r1) {
        // 0x802FC4D4: nop
    
            goto L_802FC4DC;
    }
    // 0x802FC4D4: nop

    // 0x802FC4D8: break       6
    do_break(2150614232);
L_802FC4DC:
    // 0x802FC4DC: jal         0x80128200
    // 0x802FC4E0: nop

    func_80128200(rdram, ctx);
        goto after_1;
    // 0x802FC4E0: nop

    after_1:
    // 0x802FC4E4: div         $zero, $v0, $s3
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r19))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r19)));
    // 0x802FC4E8: mfhi        $t0
    ctx->r8 = hi;
    // 0x802FC4EC: addu        $s2, $t0, $s4
    ctx->r18 = ADD32(ctx->r8, ctx->r20);
    // 0x802FC4F0: bne         $s3, $zero, L_802FC4FC
    if (ctx->r19 != 0) {
        // 0x802FC4F4: nop
    
            goto L_802FC4FC;
    }
    // 0x802FC4F4: nop

    // 0x802FC4F8: break       7
    do_break(2150614264);
L_802FC4FC:
    // 0x802FC4FC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x802FC500: bne         $s3, $at, L_802FC514
    if (ctx->r19 != ctx->r1) {
        // 0x802FC504: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_802FC514;
    }
    // 0x802FC504: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FC508: bne         $v0, $at, L_802FC514
    if (ctx->r2 != ctx->r1) {
        // 0x802FC50C: nop
    
            goto L_802FC514;
    }
    // 0x802FC50C: nop

    // 0x802FC510: break       6
    do_break(2150614288);
L_802FC514:
    // 0x802FC514: jal         0x80128200
    // 0x802FC518: nop

    func_80128200(rdram, ctx);
        goto after_2;
    // 0x802FC518: nop

    after_2:
    // 0x802FC51C: addiu       $t3, $zero, 0x8
    ctx->r11 = ADD32(0, 0X8);
    // 0x802FC520: addiu       $t4, $zero, 0x7C1
    ctx->r12 = ADD32(0, 0X7C1);
    // 0x802FC524: addiu       $t5, $zero, 0x9C1
    ctx->r13 = ADD32(0, 0X9C1);
    // 0x802FC528: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x802FC52C: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x802FC530: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x802FC534: or          $a0, $s6, $zero
    ctx->r4 = ctx->r22 | 0;
    // 0x802FC538: or          $a1, $s7, $zero
    ctx->r5 = ctx->r23 | 0;
    // 0x802FC53C: or          $a2, $fp, $zero
    ctx->r6 = ctx->r30 | 0;
    // 0x802FC540: addiu       $a3, $zero, 0x23
    ctx->r7 = ADD32(0, 0X23);
    // 0x802FC544: sw          $s1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r17;
    // 0x802FC548: sw          $s2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r18;
    // 0x802FC54C: lui         $at, 0x2
    ctx->r1 = S32(0X2 << 16);
    // 0x802FC550: addiu       $at, $at, -0x1
    ctx->r1 = ADD32(ctx->r1, -0X1);
    // 0x802FC554: bgez        $v0, L_802FC568
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FC558: and         $t1, $v0, $at
        ctx->r9 = ctx->r2 & ctx->r1;
            goto L_802FC568;
    }
    // 0x802FC558: and         $t1, $v0, $at
    ctx->r9 = ctx->r2 & ctx->r1;
    // 0x802FC55C: beq         $t1, $zero, L_802FC568
    if (ctx->r9 == 0) {
        // 0x802FC560: addiu       $at, $at, 0x1
        ctx->r1 = ADD32(ctx->r1, 0X1);
            goto L_802FC568;
    }
    // 0x802FC560: addiu       $at, $at, 0x1
    ctx->r1 = ADD32(ctx->r1, 0X1);
    // 0x802FC564: subu        $t1, $t1, $at
    ctx->r9 = SUB32(ctx->r9, ctx->r1);
L_802FC568:
    // 0x802FC568: addu        $t2, $t1, $s5
    ctx->r10 = ADD32(ctx->r9, ctx->r21);
    // 0x802FC56C: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x802FC570: jal         0x802D5F4C
    // 0x802FC574: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    create_particle_effect(rdram, ctx);
        goto after_3;
    // 0x802FC574: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    after_3:
    // 0x802FC578: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x802FC57C: sll         $t6, $s0, 16
    ctx->r14 = S32(ctx->r16 << 16);
    // 0x802FC580: sra         $s0, $t6, 16
    ctx->r16 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FC584: slti        $at, $s0, 0x3
    ctx->r1 = SIGNED(ctx->r16) < 0X3 ? 1 : 0;
    // 0x802FC588: bne         $at, $zero, L_802FC4A4
    if (ctx->r1 != 0) {
        // 0x802FC58C: nop
    
            goto L_802FC4A4;
    }
    // 0x802FC58C: nop

    // 0x802FC590: lw          $ra, 0x5C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X5C);
    // 0x802FC594: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802FC598: lw          $s1, 0x3C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X3C);
    // 0x802FC59C: lw          $s2, 0x40($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X40);
    // 0x802FC5A0: lw          $s3, 0x44($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X44);
    // 0x802FC5A4: lw          $s4, 0x48($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X48);
    // 0x802FC5A8: lw          $s5, 0x4C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X4C);
    // 0x802FC5AC: lw          $s6, 0x50($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X50);
    // 0x802FC5B0: lw          $s7, 0x54($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X54);
    // 0x802FC5B4: lw          $fp, 0x58($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X58);
    // 0x802FC5B8: jr          $ra
    // 0x802FC5BC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    return;
    // 0x802FC5BC: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
;}
RECOMP_FUNC void func_802FC5C0_70DC70(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC5C0: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FC5C4: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802FC5C8: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802FC5CC: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x802FC5D0: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x802FC5D4: lui         $t3, 0x803C
    ctx->r11 = S32(0X803C << 16);
    // 0x802FC5D8: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x802FC5DC: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802FC5E0: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802FC5E4: sra         $t0, $t9, 6
    ctx->r8 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802FC5E8: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x802FC5EC: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FC5F0: addu        $t2, $t8, $t1
    ctx->r10 = ADD32(ctx->r24, ctx->r9);
    // 0x802FC5F4: addiu       $t3, $t3, 0x740
    ctx->r11 = ADD32(ctx->r11, 0X740);
    // 0x802FC5F8: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x802FC5FC: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FC600: lbu         $a1, 0x6($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X6);
    // 0x802FC604: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FC608: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FC60C: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FC610: beq         $at, $zero, L_802FC620
    if (ctx->r1 == 0) {
        // 0x802FC614: nop
    
            goto L_802FC620;
    }
    // 0x802FC614: nop

    // 0x802FC618: b           L_802FC620
    // 0x802FC61C: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
        goto L_802FC620;
    // 0x802FC61C: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
L_802FC620:
    // 0x802FC620: lbu         $a0, 0x416($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X416);
    // 0x802FC624: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FC628: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802FC62C: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC630: beq         $at, $zero, L_802FC640
    if (ctx->r1 == 0) {
        // 0x802FC634: nop
    
            goto L_802FC640;
    }
    // 0x802FC634: nop

    // 0x802FC638: b           L_802FC640
    // 0x802FC63C: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC640;
    // 0x802FC63C: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC640:
    // 0x802FC640: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FC644: beq         $at, $zero, L_802FC664
    if (ctx->r1 == 0) {
        // 0x802FC648: slt         $at, $v1, $a1
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_802FC664;
    }
    // 0x802FC648: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FC64C: beq         $at, $zero, L_802FC65C
    if (ctx->r1 == 0) {
        // 0x802FC650: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FC65C;
    }
    // 0x802FC650: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FC654: b           L_802FC67C
    // 0x802FC658: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802FC67C;
    // 0x802FC658: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802FC65C:
    // 0x802FC65C: b           L_802FC67C
    // 0x802FC660: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FC67C;
    // 0x802FC660: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC664:
    // 0x802FC664: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC668: beq         $at, $zero, L_802FC678
    if (ctx->r1 == 0) {
        // 0x802FC66C: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802FC678;
    }
    // 0x802FC66C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802FC670: b           L_802FC678
    // 0x802FC674: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC678;
    // 0x802FC674: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC678:
    // 0x802FC678: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC67C:
    // 0x802FC67C: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802FC680: sll         $t5, $v1, 2
    ctx->r13 = S32(ctx->r3 << 2);
    // 0x802FC684: addiu       $a1, $zero, 0x9
    ctx->r5 = ADD32(0, 0X9);
    // 0x802FC688: slt         $at, $t4, $t5
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802FC68C: beq         $at, $zero, L_802FC69C
    if (ctx->r1 == 0) {
        // 0x802FC690: nop
    
            goto L_802FC69C;
    }
    // 0x802FC690: nop

    // 0x802FC694: b           L_802FC69C
    // 0x802FC698: addiu       $a1, $zero, 0x28
    ctx->r5 = ADD32(0, 0X28);
        goto L_802FC69C;
    // 0x802FC698: addiu       $a1, $zero, 0x28
    ctx->r5 = ADD32(0, 0X28);
L_802FC69C:
    // 0x802FC69C: lbu         $a0, 0x3F($s0)
    ctx->r4 = MEM_BU(ctx->r16, 0X3F);
    // 0x802FC6A0: jal         0x8029A52C
    // 0x802FC6A4: sh          $a1, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r5;
    func_8029A52C_6ABBDC(rdram, ctx);
        goto after_0;
    // 0x802FC6A4: sh          $a1, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r5;
    after_0:
    // 0x802FC6A8: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802FC6AC: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FC6B0: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FC6B4: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FC6B8: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802FC6BC: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    // 0x802FC6C0: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    // 0x802FC6C4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FC6C8: jal         0x802D7BE0
    // 0x802FC6CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FC6CC: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_1:
    // 0x802FC6D0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802FC6D4: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802FC6D8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FC6DC: jr          $ra
    // 0x802FC6E0: nop

    return;
    // 0x802FC6E0: nop

;}
RECOMP_FUNC void func_802FC6E4_70DD94(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC6E4: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FC6E8: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802FC6EC: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x802FC6F0: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x802FC6F4: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x802FC6F8: lui         $t3, 0x803C
    ctx->r11 = S32(0X803C << 16);
    // 0x802FC6FC: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x802FC700: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802FC704: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802FC708: sra         $t0, $t9, 6
    ctx->r8 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802FC70C: sll         $t1, $t0, 3
    ctx->r9 = S32(ctx->r8 << 3);
    // 0x802FC710: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FC714: addu        $t2, $t8, $t1
    ctx->r10 = ADD32(ctx->r24, ctx->r9);
    // 0x802FC718: addiu       $t3, $t3, 0x740
    ctx->r11 = ADD32(ctx->r11, 0X740);
    // 0x802FC71C: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x802FC720: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FC724: lbu         $a1, 0x6($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X6);
    // 0x802FC728: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FC72C: or          $a3, $v1, $zero
    ctx->r7 = ctx->r3 | 0;
    // 0x802FC730: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FC734: beq         $at, $zero, L_802FC744
    if (ctx->r1 == 0) {
        // 0x802FC738: nop
    
            goto L_802FC744;
    }
    // 0x802FC738: nop

    // 0x802FC73C: b           L_802FC744
    // 0x802FC740: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
        goto L_802FC744;
    // 0x802FC740: or          $a3, $a1, $zero
    ctx->r7 = ctx->r5 | 0;
L_802FC744:
    // 0x802FC744: lbu         $a0, 0x416($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X416);
    // 0x802FC748: lbu         $a2, 0xE($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0XE);
    // 0x802FC74C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802FC750: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC754: beq         $at, $zero, L_802FC764
    if (ctx->r1 == 0) {
        // 0x802FC758: nop
    
            goto L_802FC764;
    }
    // 0x802FC758: nop

    // 0x802FC75C: b           L_802FC764
    // 0x802FC760: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC764;
    // 0x802FC760: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC764:
    // 0x802FC764: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FC768: beq         $at, $zero, L_802FC788
    if (ctx->r1 == 0) {
        // 0x802FC76C: slt         $at, $v1, $a1
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_802FC788;
    }
    // 0x802FC76C: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FC770: beq         $at, $zero, L_802FC780
    if (ctx->r1 == 0) {
        // 0x802FC774: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FC780;
    }
    // 0x802FC774: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FC778: b           L_802FC7A0
    // 0x802FC77C: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802FC7A0;
    // 0x802FC77C: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802FC780:
    // 0x802FC780: b           L_802FC7A0
    // 0x802FC784: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FC7A0;
    // 0x802FC784: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC788:
    // 0x802FC788: slt         $at, $a0, $a2
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x802FC78C: beq         $at, $zero, L_802FC79C
    if (ctx->r1 == 0) {
        // 0x802FC790: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_802FC79C;
    }
    // 0x802FC790: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x802FC794: b           L_802FC79C
    // 0x802FC798: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
        goto L_802FC79C;
    // 0x802FC798: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_802FC79C:
    // 0x802FC79C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FC7A0:
    // 0x802FC7A0: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802FC7A4: sll         $t5, $v1, 2
    ctx->r13 = S32(ctx->r3 << 2);
    // 0x802FC7A8: addiu       $a1, $zero, 0x48
    ctx->r5 = ADD32(0, 0X48);
    // 0x802FC7AC: slt         $at, $t4, $t5
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x802FC7B0: beq         $at, $zero, L_802FC7C0
    if (ctx->r1 == 0) {
        // 0x802FC7B4: nop
    
            goto L_802FC7C0;
    }
    // 0x802FC7B4: nop

    // 0x802FC7B8: b           L_802FC7C0
    // 0x802FC7BC: addiu       $a1, $zero, 0x68
    ctx->r5 = ADD32(0, 0X68);
        goto L_802FC7C0;
    // 0x802FC7BC: addiu       $a1, $zero, 0x68
    ctx->r5 = ADD32(0, 0X68);
L_802FC7C0:
    // 0x802FC7C0: lbu         $a0, 0x3F($s0)
    ctx->r4 = MEM_BU(ctx->r16, 0X3F);
    // 0x802FC7C4: jal         0x8029A52C
    // 0x802FC7C8: sh          $a1, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r5;
    func_8029A52C_6ABBDC(rdram, ctx);
        goto after_0;
    // 0x802FC7C8: sh          $a1, 0x36($sp)
    MEM_H(0X36, ctx->r29) = ctx->r5;
    after_0:
    // 0x802FC7CC: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802FC7D0: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FC7D4: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FC7D8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FC7DC: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802FC7E0: sw          $v0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r2;
    // 0x802FC7E4: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    // 0x802FC7E8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FC7EC: jal         0x802D7BE0
    // 0x802FC7F0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_1;
    // 0x802FC7F0: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_1:
    // 0x802FC7F4: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802FC7F8: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x802FC7FC: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FC800: jr          $ra
    // 0x802FC804: nop

    return;
    // 0x802FC804: nop

;}
RECOMP_FUNC void func_802FC808_70DEB8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC808: addiu       $sp, $sp, -0x48
    ctx->r29 = ADD32(ctx->r29, -0X48);
    // 0x802FC80C: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802FC810: sw          $s3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r19;
    // 0x802FC814: sw          $s2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r18;
    // 0x802FC818: sw          $s1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r17;
    // 0x802FC81C: sw          $s0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r16;
    // 0x802FC820: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FC824: lui         $s3, 0x803A
    ctx->r19 = S32(0X803A << 16);
    // 0x802FC828: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FC82C: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
    // 0x802FC830: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x802FC834: sll         $t6, $t6, 1
    ctx->r14 = S32(ctx->r14 << 1);
    // 0x802FC838: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FC83C: sll         $s2, $t7, 16
    ctx->r18 = S32(ctx->r15 << 16);
    // 0x802FC840: sra         $t8, $s2, 16
    ctx->r24 = S32(SIGNED(ctx->r18) >> 16);
    // 0x802FC844: or          $s2, $t8, $zero
    ctx->r18 = ctx->r24 | 0;
    // 0x802FC848: addiu       $s3, $s3, 0x52E8
    ctx->r19 = ADD32(ctx->r19, 0X52E8);
    // 0x802FC84C: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x802FC850: sll         $t3, $s1, 3
    ctx->r11 = S32(ctx->r17 << 3);
L_802FC854:
    // 0x802FC854: addu        $v1, $s3, $t3
    ctx->r3 = ADD32(ctx->r19, ctx->r11);
    // 0x802FC858: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802FC85C: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802FC860: lw          $t7, 0x4($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X4);
    // 0x802FC864: lh          $t9, 0xC($s0)
    ctx->r25 = MEM_H(ctx->r16, 0XC);
    // 0x802FC868: multu       $t4, $v0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FC86C: lhu         $t0, 0x42($s0)
    ctx->r8 = MEM_HU(ctx->r16, 0X42);
    // 0x802FC870: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FC874: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FC878: sra         $t1, $t0, 1
    ctx->r9 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802FC87C: addu        $a2, $t9, $t1
    ctx->r6 = ADD32(ctx->r25, ctx->r9);
    // 0x802FC880: ori         $t1, $zero, 0xB5AC
    ctx->r9 = 0 | 0XB5AC;
    // 0x802FC884: ori         $t9, $zero, 0xB5AC
    ctx->r25 = 0 | 0XB5AC;
    // 0x802FC888: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x802FC88C: sw          $t1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r9;
    // 0x802FC890: mflo        $t5
    ctx->r13 = lo;
    // 0x802FC894: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    // 0x802FC898: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FC89C: multu       $t7, $v0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FC8A0: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802FC8A4: sw          $s2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r18;
    // 0x802FC8A8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FC8AC: addiu       $a3, $zero, 0x17
    ctx->r7 = ADD32(0, 0X17);
    // 0x802FC8B0: mflo        $t8
    ctx->r24 = lo;
    // 0x802FC8B4: sra         $t0, $t8, 11
    ctx->r8 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802FC8B8: jal         0x802D5F4C
    // 0x802FC8BC: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    create_particle_effect(rdram, ctx);
        goto after_0;
    // 0x802FC8BC: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    after_0:
    // 0x802FC8C0: addiu       $s1, $s1, 0x1
    ctx->r17 = ADD32(ctx->r17, 0X1);
    // 0x802FC8C4: sll         $t2, $s1, 16
    ctx->r10 = S32(ctx->r17 << 16);
    // 0x802FC8C8: sra         $s1, $t2, 16
    ctx->r17 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802FC8CC: slti        $at, $s1, 0xA
    ctx->r1 = SIGNED(ctx->r17) < 0XA ? 1 : 0;
    // 0x802FC8D0: bnel        $at, $zero, L_802FC854
    if (ctx->r1 != 0) {
        // 0x802FC8D4: sll         $t3, $s1, 3
        ctx->r11 = S32(ctx->r17 << 3);
            goto L_802FC854;
    }
    goto skip_0;
    // 0x802FC8D4: sll         $t3, $s1, 3
    ctx->r11 = S32(ctx->r17 << 3);
    skip_0:
    // 0x802FC8D8: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x802FC8DC: lw          $s0, 0x34($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X34);
    // 0x802FC8E0: lw          $s1, 0x38($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X38);
    // 0x802FC8E4: lw          $s2, 0x3C($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X3C);
    // 0x802FC8E8: lw          $s3, 0x40($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X40);
    // 0x802FC8EC: jr          $ra
    // 0x802FC8F0: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
    return;
    // 0x802FC8F0: addiu       $sp, $sp, 0x48
    ctx->r29 = ADD32(ctx->r29, 0X48);
;}
RECOMP_FUNC void func_802FC8F4_70DFA4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC8F4: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x802FC8F8: sw          $s0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r16;
    // 0x802FC8FC: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x802FC900: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FC904: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FC908: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x802FC90C: lhu         $t9, 0x42($s0)
    ctx->r25 = MEM_HU(ctx->r16, 0X42);
    // 0x802FC910: lh          $a0, 0x4($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X4);
    // 0x802FC914: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FC918: sll         $t6, $v0, 3
    ctx->r14 = S32(ctx->r2 << 3);
    // 0x802FC91C: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x802FC920: sll         $t6, $t6, 1
    ctx->r14 = S32(ctx->r14 << 1);
    // 0x802FC924: sra         $t7, $t6, 11
    ctx->r15 = S32(SIGNED(ctx->r14) >> 11);
    // 0x802FC928: ori         $t1, $zero, 0xB5AC
    ctx->r9 = 0 | 0XB5AC;
    // 0x802FC92C: ori         $t2, $zero, 0xB5AC
    ctx->r10 = 0 | 0XB5AC;
    // 0x802FC930: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802FC934: sw          $t2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r10;
    // 0x802FC938: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x802FC93C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x802FC940: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802FC944: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FC948: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FC94C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FC950: addiu       $a3, $zero, 0x17
    ctx->r7 = ADD32(0, 0X17);
    // 0x802FC954: jal         0x802D5F4C
    // 0x802FC958: addu        $a2, $t8, $t0
    ctx->r6 = ADD32(ctx->r24, ctx->r8);
    create_particle_effect(rdram, ctx);
        goto after_0;
    // 0x802FC958: addu        $a2, $t8, $t0
    ctx->r6 = ADD32(ctx->r24, ctx->r8);
    after_0:
    // 0x802FC95C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x802FC960: lw          $s0, 0x38($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X38);
    // 0x802FC964: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x802FC968: jr          $ra
    // 0x802FC96C: nop

    return;
    // 0x802FC96C: nop

;}
RECOMP_FUNC void func_802FC970_70E020(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC970: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FC974: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FC978: jal         0x802FCA08
    // 0x802FC97C: lbu         $a1, 0x164($a0)
    ctx->r5 = MEM_BU(ctx->r4, 0X164);
    func_802FCA08_70E0B8(rdram, ctx);
        goto after_0;
    // 0x802FC97C: lbu         $a1, 0x164($a0)
    ctx->r5 = MEM_BU(ctx->r4, 0X164);
    after_0:
    // 0x802FC980: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802FC984: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FC988: jr          $ra
    // 0x802FC98C: nop

    return;
    // 0x802FC98C: nop

;}
RECOMP_FUNC void run_commands(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FC990: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FC994: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FC998: lbu         $t6, 0x26C($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X26C);
    // 0x802FC99C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FC9A0: beql        $t6, $at, L_802FC9FC
    if (ctx->r14 == ctx->r1) {
        // 0x802FC9A4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802FC9FC;
    }
    goto skip_0;
    // 0x802FC9A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802FC9A8: lbu         $a1, 0x164($a0)
    ctx->r5 = MEM_BU(ctx->r4, 0X164);
    // 0x802FC9AC: jal         0x802FCA08
    // 0x802FC9B0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    func_802FCA08_70E0B8(rdram, ctx);
        goto after_0;
    // 0x802FC9B0: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_0:
    // 0x802FC9B4: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x802FC9B8: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802FC9BC: lui         $t0, 0x803E
    ctx->r8 = S32(0X803E << 16);
    // 0x802FC9C0: lhu         $v0, 0x246($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X246);
    // 0x802FC9C4: addiu       $t0, $t0, 0x4D40
    ctx->r8 = ADD32(ctx->r8, 0X4D40);
    // 0x802FC9C8: sb          $t7, 0x26C($a0)
    MEM_B(0X26C, ctx->r4) = ctx->r15;
    // 0x802FC9CC: beq         $v0, $zero, L_802FC9F8
    if (ctx->r2 == 0) {
        // 0x802FC9D0: sll         $t8, $v0, 2
        ctx->r24 = S32(ctx->r2 << 2);
            goto L_802FC9F8;
    }
    // 0x802FC9D0: sll         $t8, $v0, 2
    ctx->r24 = S32(ctx->r2 << 2);
    // 0x802FC9D4: addu        $t8, $t8, $v0
    ctx->r24 = ADD32(ctx->r24, ctx->r2);
    // 0x802FC9D8: sll         $t8, $t8, 1
    ctx->r24 = S32(ctx->r24 << 1);
    // 0x802FC9DC: addiu       $t9, $t8, -0xA
    ctx->r25 = ADD32(ctx->r24, -0XA);
    // 0x802FC9E0: addu        $a1, $t9, $t0
    ctx->r5 = ADD32(ctx->r25, ctx->r8);
    // 0x802FC9E4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802FC9E8: jal         0x803153B0
    // 0x802FC9EC: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    load_commands_into_object(rdram, ctx);
        goto after_1;
    // 0x802FC9EC: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    after_1:
    // 0x802FC9F0: jal         0x803191B0
    // 0x802FC9F4: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    func_803191B0_72A860(rdram, ctx);
        goto after_2;
    // 0x802FC9F4: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    after_2:
L_802FC9F8:
    // 0x802FC9F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802FC9FC:
    // 0x802FC9FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FCA00: jr          $ra
    // 0x802FCA04: nop

    return;
    // 0x802FCA04: nop

;}
RECOMP_FUNC void func_802FCA08_70E0B8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FCA08: andi        $t0, $a1, 0xBFFF
    ctx->r8 = ctx->r5 & 0XBFFF;
    // 0x802FCA0C: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802FCA10: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FCA14: andi        $v1, $a1, 0x4000
    ctx->r3 = ctx->r5 & 0X4000;
    // 0x802FCA18: sra         $t2, $t1, 16
    ctx->r10 = S32(SIGNED(ctx->r9) >> 16);
    // 0x802FCA1C: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FCA20: sltiu       $t8, $v1, 0x1
    ctx->r24 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x802FCA24: sltiu       $at, $t2, 0x1A
    ctx->r1 = ctx->r10 < 0X1A ? 1 : 0;
    // 0x802FCA28: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FCA2C: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FCA30: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x802FCA34: beq         $at, $zero, L_802FD17C
    if (ctx->r1 == 0) {
        // 0x802FCA38: andi        $v1, $t8, 0xFF
        ctx->r3 = ctx->r24 & 0XFF;
            goto L_802FD17C;
    }
    // 0x802FCA38: andi        $v1, $t8, 0xFF
    ctx->r3 = ctx->r24 & 0XFF;
    // 0x802FCA3C: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x802FCA40: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802FCA44: addu        $at, $at, $t3
    gpr jr_addend_802FCA4C = ctx->r11;
    ctx->r1 = ADD32(ctx->r1, ctx->r11);
    // 0x802FCA48: lw          $t3, -0x30D4($at)
    ctx->r11 = ADD32(ctx->r1, -0X30D4);
    // 0x802FCA4C: jr          $t3
    // 0x802FCA50: nop

    switch (jr_addend_802FCA4C >> 2) {
        case 0: goto L_802FD17C; break;
        case 1: goto L_802FCA54; break;
        case 2: goto L_802FCA64; break;
        case 3: goto L_802FCA74; break;
        case 4: goto L_802FCA84; break;
        case 5: goto L_802FD17C; break;
        case 6: goto L_802FCDE8; break;
        case 7: goto L_802FCE14; break;
        case 8: goto L_802FCE24; break;
        case 9: goto L_802FCE34; break;
        case 10: goto L_802FCE44; break;
        case 11: goto L_802FCE54; break;
        case 12: goto L_802FCE8C; break;
        case 13: goto L_802FCEC4; break;
        case 14: goto L_802FCED4; break;
        case 15: goto L_802FCEE4; break;
        case 16: goto L_802FCF10; break;
        case 17: goto L_802FCF50; break;
        case 18: goto L_802FCF6C; break;
        case 19: goto L_802FCF88; break;
        case 20: goto L_802FD07C; break;
        case 21: goto L_802FD098; break;
        case 22: goto L_802FD0D8; break;
        case 23: goto L_802FD0F4; break;
        case 24: goto L_802FD134; break;
        case 25: goto L_802FD174; break;
        default: switch_error(__func__, 0x802FCA4C, 0x803BCF2C);
    }
    // 0x802FCA50: nop

L_802FCA54:
    // 0x802FCA54: jal         0x802FC808
    // 0x802FCA58: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FC808_70DEB8(rdram, ctx);
        goto after_0;
    // 0x802FCA58: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_0:
    // 0x802FCA5C: b           L_802FD180
    // 0x802FCA60: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCA60: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCA64:
    // 0x802FCA64: jal         0x802FB4C0
    // 0x802FCA68: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FB4C0_70CB70(rdram, ctx);
        goto after_1;
    // 0x802FCA68: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_1:
    // 0x802FCA6C: b           L_802FD180
    // 0x802FCA70: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCA70: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCA74:
    // 0x802FCA74: jal         0x802FBBF8
    // 0x802FCA78: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FBBF8_70D2A8(rdram, ctx);
        goto after_2;
    // 0x802FCA78: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_2:
    // 0x802FCA7C: b           L_802FD180
    // 0x802FCA80: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCA80: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCA84:
    // 0x802FCA84: lw          $t4, 0x16C($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X16C);
    // 0x802FCA88: addiu       $at, $zero, 0x22
    ctx->r1 = ADD32(0, 0X22);
    // 0x802FCA8C: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x802FCA90: lhu         $v0, 0x0($t4)
    ctx->r2 = MEM_HU(ctx->r12, 0X0);
    // 0x802FCA94: beq         $v0, $at, L_802FCAC4
    if (ctx->r2 == ctx->r1) {
        // 0x802FCA98: addiu       $at, $zero, 0x3A
        ctx->r1 = ADD32(0, 0X3A);
            goto L_802FCAC4;
    }
    // 0x802FCA98: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x802FCA9C: beq         $v0, $at, L_802FCB24
    if (ctx->r2 == ctx->r1) {
        // 0x802FCAA0: addiu       $a3, $zero, 0x1
        ctx->r7 = ADD32(0, 0X1);
            goto L_802FCB24;
    }
    // 0x802FCAA0: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x802FCAA4: addiu       $at, $zero, 0x3B
    ctx->r1 = ADD32(0, 0X3B);
    // 0x802FCAA8: beq         $v0, $at, L_802FCC00
    if (ctx->r2 == ctx->r1) {
        // 0x802FCAAC: addiu       $a3, $zero, 0x1
        ctx->r7 = ADD32(0, 0X1);
            goto L_802FCC00;
    }
    // 0x802FCAAC: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x802FCAB0: addiu       $at, $zero, 0x3C
    ctx->r1 = ADD32(0, 0X3C);
    // 0x802FCAB4: beq         $v0, $at, L_802FCCDC
    if (ctx->r2 == ctx->r1) {
        // 0x802FCAB8: addiu       $a3, $zero, 0x1
        ctx->r7 = ADD32(0, 0X1);
            goto L_802FCCDC;
    }
    // 0x802FCAB8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x802FCABC: b           L_802FCDB8
    // 0x802FCAC0: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
        goto L_802FCDB8;
    // 0x802FCAC0: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
L_802FCAC4:
    // 0x802FCAC4: beq         $v1, $zero, L_802FCAF4
    if (ctx->r3 == 0) {
        // 0x802FCAC8: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_802FCAF4;
    }
    // 0x802FCAC8: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802FCACC: addiu       $v0, $v0, 0x2D30
    ctx->r2 = ADD32(ctx->r2, 0X2D30);
    // 0x802FCAD0: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x802FCAD4: lh          $t7, 0x6($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X6);
    // 0x802FCAD8: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x802FCADC: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x802FCAE0: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x802FCAE4: addiu       $t0, $t9, 0x3E8
    ctx->r8 = ADD32(ctx->r25, 0X3E8);
    // 0x802FCAE8: sh          $t6, 0xC($v0)
    MEM_H(0XC, ctx->r2) = ctx->r14;
    // 0x802FCAEC: sh          $t8, 0x6($v0)
    MEM_H(0X6, ctx->r2) = ctx->r24;
    // 0x802FCAF0: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
L_802FCAF4:
    // 0x802FCAF4: lhu         $t2, 0x40($s0)
    ctx->r10 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCAF8: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802FCAFC: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCB00: sra         $t3, $t2, 7
    ctx->r11 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802FCB04: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x802FCB08: addu        $a2, $t1, $t4
    ctx->r6 = ADD32(ctx->r9, ctx->r12);
    // 0x802FCB0C: sll         $t5, $a2, 16
    ctx->r13 = S32(ctx->r6 << 16);
    // 0x802FCB10: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FCB14: jal         0x802D9FC4
    // 0x802FCB18: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    do_item_collected_effect(rdram, ctx);
        goto after_3;
    // 0x802FCB18: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_3:
    // 0x802FCB1C: b           L_802FD180
    // 0x802FCB20: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCB20: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCB24:
    // 0x802FCB24: beq         $v1, $zero, L_802FCBD0
    if (ctx->r3 == 0) {
        // 0x802FCB28: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_802FCBD0;
    }
    // 0x802FCB28: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802FCB2C: addiu       $v0, $v0, 0x2D30
    ctx->r2 = ADD32(ctx->r2, 0X2D30);
    // 0x802FCB30: lh          $t7, 0x4($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X4);
    // 0x802FCB34: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCB38: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCB3C: bne         $t7, $zero, L_802FCB80
    if (ctx->r15 != 0) {
        // 0x802FCB40: nop
    
            goto L_802FCB80;
    }
    // 0x802FCB40: nop

    // 0x802FCB44: lh          $t8, 0x0($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X0);
    // 0x802FCB48: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCB4C: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCB50: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802FCB54: addu        $t0, $a0, $t9
    ctx->r8 = ADD32(ctx->r4, ctx->r25);
    // 0x802FCB58: lw          $v0, 0x3EB4($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X3EB4);
    // 0x802FCB5C: addiu       $t2, $zero, 0x7F
    ctx->r10 = ADD32(0, 0X7F);
    // 0x802FCB60: lh          $v1, 0x14C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14C);
    // 0x802FCB64: addiu       $v1, $v1, 0x10
    ctx->r3 = ADD32(ctx->r3, 0X10);
    // 0x802FCB68: slti        $at, $v1, 0x7F
    ctx->r1 = SIGNED(ctx->r3) < 0X7F ? 1 : 0;
    // 0x802FCB6C: beql        $at, $zero, L_802FCB80
    if (ctx->r1 == 0) {
        // 0x802FCB70: sh          $t2, 0x14C($v0)
        MEM_H(0X14C, ctx->r2) = ctx->r10;
            goto L_802FCB80;
    }
    goto skip_0;
    // 0x802FCB70: sh          $t2, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r10;
    skip_0:
    // 0x802FCB74: b           L_802FCB80
    // 0x802FCB78: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
        goto L_802FCB80;
    // 0x802FCB78: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
    // 0x802FCB7C: sh          $t2, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r10;
L_802FCB80:
    // 0x802FCB80: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802FCB84: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802FCB88: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802FCB8C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCB90: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCB94: sh          $zero, 0x348($t3)
    MEM_H(0X348, ctx->r11) = 0;
    // 0x802FCB98: lw          $t1, 0x0($v0)
    ctx->r9 = MEM_W(ctx->r2, 0X0);
    // 0x802FCB9C: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCBA0: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCBA4: sh          $zero, 0x34A($t1)
    MEM_H(0X34A, ctx->r9) = 0;
    // 0x802FCBA8: lh          $t4, 0x0($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X0);
    // 0x802FCBAC: sll         $t5, $t4, 3
    ctx->r13 = S32(ctx->r12 << 3);
    // 0x802FCBB0: addu        $t6, $a0, $t5
    ctx->r14 = ADD32(ctx->r4, ctx->r13);
    // 0x802FCBB4: lw          $t7, 0x3EB4($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X3EB4);
    // 0x802FCBB8: sh          $zero, 0x358($t7)
    MEM_H(0X358, ctx->r15) = 0;
    // 0x802FCBBC: lh          $t8, 0x0($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X0);
    // 0x802FCBC0: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x802FCBC4: addu        $t0, $a0, $t9
    ctx->r8 = ADD32(ctx->r4, ctx->r25);
    // 0x802FCBC8: lw          $t2, 0x3EB4($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X3EB4);
    // 0x802FCBCC: sb          $zero, 0x363($t2)
    MEM_B(0X363, ctx->r10) = 0;
L_802FCBD0:
    // 0x802FCBD0: lhu         $t1, 0x40($s0)
    ctx->r9 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCBD4: lh          $t3, 0xC($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XC);
    // 0x802FCBD8: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCBDC: sra         $t4, $t1, 7
    ctx->r12 = S32(SIGNED(ctx->r9) >> 7);
    // 0x802FCBE0: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x802FCBE4: addu        $a2, $t3, $t5
    ctx->r6 = ADD32(ctx->r11, ctx->r13);
    // 0x802FCBE8: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x802FCBEC: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FCBF0: jal         0x802D9FC4
    // 0x802FCBF4: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    do_item_collected_effect(rdram, ctx);
        goto after_4;
    // 0x802FCBF4: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_4:
    // 0x802FCBF8: b           L_802FD180
    // 0x802FCBFC: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCBFC: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCC00:
    // 0x802FCC00: beq         $v1, $zero, L_802FCCAC
    if (ctx->r3 == 0) {
        // 0x802FCC04: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_802FCCAC;
    }
    // 0x802FCC04: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802FCC08: addiu       $v0, $v0, 0x2D30
    ctx->r2 = ADD32(ctx->r2, 0X2D30);
    // 0x802FCC0C: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x802FCC10: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCC14: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCC18: bne         $t8, $zero, L_802FCC5C
    if (ctx->r24 != 0) {
        // 0x802FCC1C: nop
    
            goto L_802FCC5C;
    }
    // 0x802FCC1C: nop

    // 0x802FCC20: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802FCC24: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCC28: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCC2C: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x802FCC30: addu        $t2, $a0, $t0
    ctx->r10 = ADD32(ctx->r4, ctx->r8);
    // 0x802FCC34: lw          $v0, 0x3EB4($t2)
    ctx->r2 = MEM_W(ctx->r10, 0X3EB4);
    // 0x802FCC38: addiu       $t1, $zero, 0x7F
    ctx->r9 = ADD32(0, 0X7F);
    // 0x802FCC3C: lh          $v1, 0x14C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14C);
    // 0x802FCC40: addiu       $v1, $v1, 0x20
    ctx->r3 = ADD32(ctx->r3, 0X20);
    // 0x802FCC44: slti        $at, $v1, 0x7F
    ctx->r1 = SIGNED(ctx->r3) < 0X7F ? 1 : 0;
    // 0x802FCC48: beql        $at, $zero, L_802FCC5C
    if (ctx->r1 == 0) {
        // 0x802FCC4C: sh          $t1, 0x14C($v0)
        MEM_H(0X14C, ctx->r2) = ctx->r9;
            goto L_802FCC5C;
    }
    goto skip_1;
    // 0x802FCC4C: sh          $t1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r9;
    skip_1:
    // 0x802FCC50: b           L_802FCC5C
    // 0x802FCC54: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
        goto L_802FCC5C;
    // 0x802FCC54: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
    // 0x802FCC58: sh          $t1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r9;
L_802FCC5C:
    // 0x802FCC5C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802FCC60: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802FCC64: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802FCC68: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCC6C: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCC70: sh          $zero, 0x348($t4)
    MEM_H(0X348, ctx->r12) = 0;
    // 0x802FCC74: lw          $t3, 0x0($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X0);
    // 0x802FCC78: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCC7C: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCC80: sh          $zero, 0x34A($t3)
    MEM_H(0X34A, ctx->r11) = 0;
    // 0x802FCC84: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x802FCC88: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x802FCC8C: addu        $t7, $a0, $t6
    ctx->r15 = ADD32(ctx->r4, ctx->r14);
    // 0x802FCC90: lw          $t8, 0x3EB4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X3EB4);
    // 0x802FCC94: sh          $zero, 0x358($t8)
    MEM_H(0X358, ctx->r24) = 0;
    // 0x802FCC98: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802FCC9C: sll         $t0, $t9, 3
    ctx->r8 = S32(ctx->r25 << 3);
    // 0x802FCCA0: addu        $t2, $a0, $t0
    ctx->r10 = ADD32(ctx->r4, ctx->r8);
    // 0x802FCCA4: lw          $t1, 0x3EB4($t2)
    ctx->r9 = MEM_W(ctx->r10, 0X3EB4);
    // 0x802FCCA8: sb          $zero, 0x363($t1)
    MEM_B(0X363, ctx->r9) = 0;
L_802FCCAC:
    // 0x802FCCAC: lhu         $t3, 0x40($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCCB0: lh          $t4, 0xC($s0)
    ctx->r12 = MEM_H(ctx->r16, 0XC);
    // 0x802FCCB4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCCB8: sra         $t5, $t3, 7
    ctx->r13 = S32(SIGNED(ctx->r11) >> 7);
    // 0x802FCCBC: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x802FCCC0: addu        $a2, $t4, $t6
    ctx->r6 = ADD32(ctx->r12, ctx->r14);
    // 0x802FCCC4: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x802FCCC8: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FCCCC: jal         0x802D9FC4
    // 0x802FCCD0: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    do_item_collected_effect(rdram, ctx);
        goto after_5;
    // 0x802FCCD0: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_5:
    // 0x802FCCD4: b           L_802FD180
    // 0x802FCCD8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCCD8: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCCDC:
    // 0x802FCCDC: beq         $v1, $zero, L_802FCD88
    if (ctx->r3 == 0) {
        // 0x802FCCE0: lui         $v0, 0x803F
        ctx->r2 = S32(0X803F << 16);
            goto L_802FCD88;
    }
    // 0x802FCCE0: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x802FCCE4: addiu       $v0, $v0, 0x2D30
    ctx->r2 = ADD32(ctx->r2, 0X2D30);
    // 0x802FCCE8: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    // 0x802FCCEC: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCCF0: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCCF4: bne         $t9, $zero, L_802FCD38
    if (ctx->r25 != 0) {
        // 0x802FCCF8: nop
    
            goto L_802FCD38;
    }
    // 0x802FCCF8: nop

    // 0x802FCCFC: lh          $t0, 0x0($a1)
    ctx->r8 = MEM_H(ctx->r5, 0X0);
    // 0x802FCD00: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCD04: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCD08: sll         $t2, $t0, 3
    ctx->r10 = S32(ctx->r8 << 3);
    // 0x802FCD0C: addu        $t1, $a0, $t2
    ctx->r9 = ADD32(ctx->r4, ctx->r10);
    // 0x802FCD10: lw          $v0, 0x3EB4($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X3EB4);
    // 0x802FCD14: addiu       $t3, $zero, 0x7F
    ctx->r11 = ADD32(0, 0X7F);
    // 0x802FCD18: lh          $v1, 0x14C($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X14C);
    // 0x802FCD1C: addiu       $v1, $v1, 0x40
    ctx->r3 = ADD32(ctx->r3, 0X40);
    // 0x802FCD20: slti        $at, $v1, 0x7F
    ctx->r1 = SIGNED(ctx->r3) < 0X7F ? 1 : 0;
    // 0x802FCD24: beql        $at, $zero, L_802FCD38
    if (ctx->r1 == 0) {
        // 0x802FCD28: sh          $t3, 0x14C($v0)
        MEM_H(0X14C, ctx->r2) = ctx->r11;
            goto L_802FCD38;
    }
    goto skip_2;
    // 0x802FCD28: sh          $t3, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r11;
    skip_2:
    // 0x802FCD2C: b           L_802FCD38
    // 0x802FCD30: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
        goto L_802FCD38;
    // 0x802FCD30: sh          $v1, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r3;
    // 0x802FCD34: sh          $t3, 0x14C($v0)
    MEM_H(0X14C, ctx->r2) = ctx->r11;
L_802FCD38:
    // 0x802FCD38: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x802FCD3C: addiu       $v0, $v0, 0x552C
    ctx->r2 = ADD32(ctx->r2, 0X552C);
    // 0x802FCD40: lw          $t5, 0x0($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X0);
    // 0x802FCD44: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x802FCD48: addiu       $a1, $a1, 0x5534
    ctx->r5 = ADD32(ctx->r5, 0X5534);
    // 0x802FCD4C: sh          $zero, 0x348($t5)
    MEM_H(0X348, ctx->r13) = 0;
    // 0x802FCD50: lw          $t4, 0x0($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X0);
    // 0x802FCD54: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x802FCD58: addiu       $a0, $a0, -0x6128
    ctx->r4 = ADD32(ctx->r4, -0X6128);
    // 0x802FCD5C: sh          $zero, 0x34A($t4)
    MEM_H(0X34A, ctx->r12) = 0;
    // 0x802FCD60: lh          $t6, 0x0($a1)
    ctx->r14 = MEM_H(ctx->r5, 0X0);
    // 0x802FCD64: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x802FCD68: addu        $t8, $a0, $t7
    ctx->r24 = ADD32(ctx->r4, ctx->r15);
    // 0x802FCD6C: lw          $t9, 0x3EB4($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X3EB4);
    // 0x802FCD70: sh          $zero, 0x358($t9)
    MEM_H(0X358, ctx->r25) = 0;
    // 0x802FCD74: lh          $t0, 0x0($a1)
    ctx->r8 = MEM_H(ctx->r5, 0X0);
    // 0x802FCD78: sll         $t2, $t0, 3
    ctx->r10 = S32(ctx->r8 << 3);
    // 0x802FCD7C: addu        $t1, $a0, $t2
    ctx->r9 = ADD32(ctx->r4, ctx->r10);
    // 0x802FCD80: lw          $t3, 0x3EB4($t1)
    ctx->r11 = MEM_W(ctx->r9, 0X3EB4);
    // 0x802FCD84: sb          $zero, 0x363($t3)
    MEM_B(0X363, ctx->r11) = 0;
L_802FCD88:
    // 0x802FCD88: lhu         $t4, 0x40($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCD8C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FCD90: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCD94: sra         $t6, $t4, 7
    ctx->r14 = S32(SIGNED(ctx->r12) >> 7);
    // 0x802FCD98: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x802FCD9C: addu        $a2, $t5, $t7
    ctx->r6 = ADD32(ctx->r13, ctx->r15);
    // 0x802FCDA0: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802FCDA4: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FCDA8: jal         0x802D9FC4
    // 0x802FCDAC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    do_item_collected_effect(rdram, ctx);
        goto after_6;
    // 0x802FCDAC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_6:
    // 0x802FCDB0: b           L_802FD180
    // 0x802FCDB4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCDB4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCDB8:
    // 0x802FCDB8: lhu         $t2, 0x40($s0)
    ctx->r10 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCDBC: lh          $t0, 0xC($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XC);
    // 0x802FCDC0: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCDC4: sra         $t1, $t2, 7
    ctx->r9 = S32(SIGNED(ctx->r10) >> 7);
    // 0x802FCDC8: sll         $t3, $t1, 1
    ctx->r11 = S32(ctx->r9 << 1);
    // 0x802FCDCC: addu        $a2, $t0, $t3
    ctx->r6 = ADD32(ctx->r8, ctx->r11);
    // 0x802FCDD0: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x802FCDD4: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FCDD8: jal         0x802D9FC4
    // 0x802FCDDC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    do_item_collected_effect(rdram, ctx);
        goto after_7;
    // 0x802FCDDC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_7:
    // 0x802FCDE0: b           L_802FD180
    // 0x802FCDE4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCDE4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCDE8:
    // 0x802FCDE8: lhu         $t7, 0x42($s0)
    ctx->r15 = MEM_HU(ctx->r16, 0X42);
    // 0x802FCDEC: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FCDF0: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCDF4: sra         $t8, $t7, 1
    ctx->r24 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802FCDF8: addu        $a2, $t5, $t8
    ctx->r6 = ADD32(ctx->r13, ctx->r24);
    // 0x802FCDFC: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802FCE00: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FCE04: jal         0x802FC2B8
    // 0x802FCE08: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    func_802FC2B8_70D968(rdram, ctx);
        goto after_8;
    // 0x802FCE08: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_8:
    // 0x802FCE0C: b           L_802FD180
    // 0x802FCE10: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE10: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE14:
    // 0x802FCE14: jal         0x802FBF58
    // 0x802FCE18: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FBF58_70D608(rdram, ctx);
        goto after_9;
    // 0x802FCE18: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_9:
    // 0x802FCE1C: b           L_802FD180
    // 0x802FCE20: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE20: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE24:
    // 0x802FCE24: jal         0x802FBDA8
    // 0x802FCE28: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FBDA8_70D458(rdram, ctx);
        goto after_10;
    // 0x802FCE28: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_10:
    // 0x802FCE2C: b           L_802FD180
    // 0x802FCE30: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE30: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE34:
    // 0x802FCE34: jal         0x802FC108
    // 0x802FCE38: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FC108_70D7B8(rdram, ctx);
        goto after_11;
    // 0x802FCE38: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_11:
    // 0x802FCE3C: b           L_802FD180
    // 0x802FCE40: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE40: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE44:
    // 0x802FCE44: jal         0x802FC5C0
    // 0x802FCE48: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FC5C0_70DC70(rdram, ctx);
        goto after_12;
    // 0x802FCE48: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_12:
    // 0x802FCE4C: b           L_802FD180
    // 0x802FCE50: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE50: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE54:
    // 0x802FCE54: lhu         $t0, 0x42($s0)
    ctx->r8 = MEM_HU(ctx->r16, 0X42);
    // 0x802FCE58: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802FCE5C: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCE60: sra         $t3, $t0, 1
    ctx->r11 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802FCE64: addu        $a2, $t1, $t3
    ctx->r6 = ADD32(ctx->r9, ctx->r11);
    // 0x802FCE68: sll         $t4, $a2, 16
    ctx->r12 = S32(ctx->r6 << 16);
    // 0x802FCE6C: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FCE70: lh          $a3, 0x30($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X30);
    // 0x802FCE74: addiu       $t7, $zero, 0x8
    ctx->r15 = ADD32(0, 0X8);
    // 0x802FCE78: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802FCE7C: jal         0x802D760C
    // 0x802FCE80: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    func_802D760C_6E8CBC(rdram, ctx);
        goto after_13;
    // 0x802FCE80: sra         $a2, $t4, 16
    ctx->r6 = S32(SIGNED(ctx->r12) >> 16);
    after_13:
    // 0x802FCE84: b           L_802FD180
    // 0x802FCE88: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCE88: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCE8C:
    // 0x802FCE8C: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x802FCE90: lhu         $t8, 0x42($s0)
    ctx->r24 = MEM_HU(ctx->r16, 0X42);
    // 0x802FCE94: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCE98: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FCE9C: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x802FCEA0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802FCEA4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FCEA8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FCEAC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FCEB0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x802FCEB4: jal         0x802D5B88
    // 0x802FCEB8: addu        $a2, $t5, $t9
    ctx->r6 = ADD32(ctx->r13, ctx->r25);
    create_particle_effect_2(rdram, ctx);
        goto after_14;
    // 0x802FCEB8: addu        $a2, $t5, $t9
    ctx->r6 = ADD32(ctx->r13, ctx->r25);
    after_14:
    // 0x802FCEBC: b           L_802FD180
    // 0x802FCEC0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCEC0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCEC4:
    // 0x802FCEC4: jal         0x802FB680
    // 0x802FCEC8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FB680_70CD30(rdram, ctx);
        goto after_15;
    // 0x802FCEC8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_15:
    // 0x802FCECC: b           L_802FD180
    // 0x802FCED0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCED0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCED4:
    // 0x802FCED4: jal         0x802FBA40
    // 0x802FCED8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FBA40_70D0F0(rdram, ctx);
        goto after_16;
    // 0x802FCED8: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_16:
    // 0x802FCEDC: b           L_802FD180
    // 0x802FCEE0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCEE0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCEE4:
    // 0x802FCEE4: lhu         $t0, 0x42($s0)
    ctx->r8 = MEM_HU(ctx->r16, 0X42);
    // 0x802FCEE8: lh          $t2, 0xC($s0)
    ctx->r10 = MEM_H(ctx->r16, 0XC);
    // 0x802FCEEC: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCEF0: sra         $t1, $t0, 1
    ctx->r9 = S32(SIGNED(ctx->r8) >> 1);
    // 0x802FCEF4: addu        $a2, $t2, $t1
    ctx->r6 = ADD32(ctx->r10, ctx->r9);
    // 0x802FCEF8: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802FCEFC: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802FCF00: jal         0x802FC438
    // 0x802FCF04: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    func_802FC438_70DAE8(rdram, ctx);
        goto after_17;
    // 0x802FCF04: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    after_17:
    // 0x802FCF08: b           L_802FD180
    // 0x802FCF0C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCF0C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCF10:
    // 0x802FCF10: jal         0x802FC6E4
    // 0x802FCF14: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FC6E4_70DD94(rdram, ctx);
        goto after_18;
    // 0x802FCF14: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_18:
    // 0x802FCF18: lh          $t6, 0x8($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X8);
    // 0x802FCF1C: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802FCF20: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802FCF24: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FCF28: lh          $t7, 0xC($s0)
    ctx->r15 = MEM_H(ctx->r16, 0XC);
    // 0x802FCF2C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FCF30: addiu       $a0, $zero, 0x79
    ctx->r4 = ADD32(0, 0X79);
    // 0x802FCF34: addiu       $a1, $zero, 0x6000
    ctx->r5 = ADD32(0, 0X6000);
    // 0x802FCF38: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802FCF3C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802FCF40: jal         0x8032C360
    // 0x802FCF44: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_19;
    // 0x802FCF44: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    after_19:
    // 0x802FCF48: b           L_802FD180
    // 0x802FCF4C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCF4C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCF50:
    // 0x802FCF50: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCF54: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FCF58: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FCF5C: jal         0x802D9FC4
    // 0x802FCF60: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    do_item_collected_effect(rdram, ctx);
        goto after_20;
    // 0x802FCF60: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    after_20:
    // 0x802FCF64: b           L_802FD180
    // 0x802FCF68: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCF68: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCF6C:
    // 0x802FCF6C: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FCF70: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FCF74: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FCF78: jal         0x802D9FC4
    // 0x802FCF7C: addiu       $a3, $zero, 0x4
    ctx->r7 = ADD32(0, 0X4);
    do_item_collected_effect(rdram, ctx);
        goto after_21;
    // 0x802FCF7C: addiu       $a3, $zero, 0x4
    ctx->r7 = ADD32(0, 0X4);
    after_21:
    // 0x802FCF80: b           L_802FD180
    // 0x802FCF84: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FCF84: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FCF88:
    // 0x802FCF88: lh          $v1, 0x15E($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X15E);
    // 0x802FCF8C: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FCF90: bne         $v1, $zero, L_802FCFCC
    if (ctx->r3 != 0) {
        // 0x802FCF94: sll         $v0, $v1, 16
        ctx->r2 = S32(ctx->r3 << 16);
            goto L_802FCFCC;
    }
    // 0x802FCF94: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x802FCF98: lhu         $v0, 0x40($s0)
    ctx->r2 = MEM_HU(ctx->r16, 0X40);
    // 0x802FCF9C: lw          $v1, 0x158($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X158);
    // 0x802FCFA0: sll         $t8, $v0, 5
    ctx->r24 = S32(ctx->r2 << 5);
    // 0x802FCFA4: sra         $t5, $t8, 11
    ctx->r13 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802FCFA8: sll         $t9, $t5, 16
    ctx->r25 = S32(ctx->r13 << 16);
    // 0x802FCFAC: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FCFB0: beq         $v1, $zero, L_802FCFD4
    if (ctx->r3 == 0) {
        // 0x802FCFB4: or          $v0, $t0, $zero
        ctx->r2 = ctx->r8 | 0;
            goto L_802FCFD4;
    }
    // 0x802FCFB4: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x802FCFB8: multu       $t0, $v1
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FCFBC: mflo        $v0
    ctx->r2 = lo;
    // 0x802FCFC0: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x802FCFC4: b           L_802FCFD4
    // 0x802FCFC8: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
        goto L_802FCFD4;
    // 0x802FCFC8: sra         $v0, $t2, 16
    ctx->r2 = S32(SIGNED(ctx->r10) >> 16);
L_802FCFCC:
    // 0x802FCFCC: sra         $t3, $v0, 16
    ctx->r11 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802FCFD0: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
L_802FCFD4:
    // 0x802FCFD4: lw          $v1, 0x168($s0)
    ctx->r3 = MEM_W(ctx->r16, 0X168);
    // 0x802FCFD8: addiu       $t2, $zero, 0x64
    ctx->r10 = ADD32(0, 0X64);
    // 0x802FCFDC: beql        $v1, $zero, L_802FD004
    if (ctx->r3 == 0) {
        // 0x802FCFE0: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FD004;
    }
    goto skip_3;
    // 0x802FCFE0: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_3:
    // 0x802FCFE4: lw          $a0, 0x16C($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X16C);
    // 0x802FCFE8: lw          $t4, 0x80($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X80);
    // 0x802FCFEC: sll         $t7, $t4, 18
    ctx->r15 = S32(ctx->r12 << 18);
    // 0x802FCFF0: bgezl       $t7, L_802FD004
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FCFF4: addiu       $v1, $zero, -0x1
        ctx->r3 = ADD32(0, -0X1);
            goto L_802FD004;
    }
    goto skip_4;
    // 0x802FCFF4: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
    skip_4:
    // 0x802FCFF8: b           L_802FD004
    // 0x802FCFFC: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
        goto L_802FD004;
    // 0x802FCFFC: lb          $v1, 0xE6($a0)
    ctx->r3 = MEM_B(ctx->r4, 0XE6);
    // 0x802FD000: addiu       $v1, $zero, -0x1
    ctx->r3 = ADD32(0, -0X1);
L_802FD004:
    // 0x802FD004: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x802FD008: lhu         $t5, 0x42($s0)
    ctx->r13 = MEM_HU(ctx->r16, 0X42);
    // 0x802FD00C: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FD010: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FD014: sra         $t9, $t5, 1
    ctx->r25 = S32(SIGNED(ctx->r13) >> 1);
    // 0x802FD018: addu        $t0, $t8, $t9
    ctx->r8 = ADD32(ctx->r24, ctx->r25);
    // 0x802FD01C: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x802FD020: sw          $v1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r3;
    // 0x802FD024: sw          $v0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r2;
    // 0x802FD028: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x802FD02C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FD030: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FD034: jal         0x802FF184
    // 0x802FD038: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FF184_710834(rdram, ctx);
        goto after_22;
    // 0x802FD038: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_22:
    // 0x802FD03C: lhu         $t3, 0x42($s0)
    ctx->r11 = MEM_HU(ctx->r16, 0X42);
    // 0x802FD040: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802FD044: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FD048: sra         $t4, $t3, 1
    ctx->r12 = S32(SIGNED(ctx->r11) >> 1);
    // 0x802FD04C: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FD050: addu        $t6, $t1, $t4
    ctx->r14 = ADD32(ctx->r9, ctx->r12);
    // 0x802FD054: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FD058: lh          $t7, 0x30($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X30);
    // 0x802FD05C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FD060: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FD064: sra         $t5, $t7, 1
    ctx->r13 = S32(SIGNED(ctx->r15) >> 1);
    // 0x802FD068: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    // 0x802FD06C: jal         0x802D7BE0
    // 0x802FD070: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_23;
    // 0x802FD070: addiu       $a1, $zero, 0x20
    ctx->r5 = ADD32(0, 0X20);
    after_23:
    // 0x802FD074: b           L_802FD180
    // 0x802FD078: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD078: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD07C:
    // 0x802FD07C: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FD080: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FD084: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FD088: jal         0x802D9FC4
    // 0x802FD08C: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    do_item_collected_effect(rdram, ctx);
        goto after_24;
    // 0x802FD08C: addiu       $a3, $zero, 0x5
    ctx->r7 = ADD32(0, 0X5);
    after_24:
    // 0x802FD090: b           L_802FD180
    // 0x802FD094: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD094: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD098:
    // 0x802FD098: lh          $t8, 0xC($s0)
    ctx->r24 = MEM_H(ctx->r16, 0XC);
    // 0x802FD09C: lhu         $t9, 0x42($s0)
    ctx->r25 = MEM_HU(ctx->r16, 0X42);
    // 0x802FD0A0: lh          $t2, 0x30($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X30);
    // 0x802FD0A4: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FD0A8: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FD0AC: sra         $t0, $t9, 1
    ctx->r8 = S32(SIGNED(ctx->r25) >> 1);
    // 0x802FD0B0: sll         $t3, $t2, 2
    ctx->r11 = S32(ctx->r10 << 2);
    // 0x802FD0B4: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x802FD0B8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802FD0BC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FD0C0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FD0C4: addiu       $a3, $zero, 0x3A
    ctx->r7 = ADD32(0, 0X3A);
    // 0x802FD0C8: jal         0x802D5B88
    // 0x802FD0CC: addu        $a2, $t8, $t0
    ctx->r6 = ADD32(ctx->r24, ctx->r8);
    create_particle_effect_2(rdram, ctx);
        goto after_25;
    // 0x802FD0CC: addu        $a2, $t8, $t0
    ctx->r6 = ADD32(ctx->r24, ctx->r8);
    after_25:
    // 0x802FD0D0: b           L_802FD180
    // 0x802FD0D4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD0D4: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD0D8:
    // 0x802FD0D8: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FD0DC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FD0E0: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FD0E4: jal         0x802D9FC4
    // 0x802FD0E8: addiu       $a3, $zero, 0x6
    ctx->r7 = ADD32(0, 0X6);
    do_item_collected_effect(rdram, ctx);
        goto after_26;
    // 0x802FD0E8: addiu       $a3, $zero, 0x6
    ctx->r7 = ADD32(0, 0X6);
    after_26:
    // 0x802FD0EC: b           L_802FD180
    // 0x802FD0F0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD0F0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD0F4:
    // 0x802FD0F4: lhu         $t4, 0x42($s0)
    ctx->r12 = MEM_HU(ctx->r16, 0X42);
    // 0x802FD0F8: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802FD0FC: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FD100: sra         $t6, $t4, 1
    ctx->r14 = S32(SIGNED(ctx->r12) >> 1);
    // 0x802FD104: lh          $a3, 0x8($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X8);
    // 0x802FD108: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x802FD10C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802FD110: lh          $t5, 0x30($s0)
    ctx->r13 = MEM_H(ctx->r16, 0X30);
    // 0x802FD114: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FD118: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FD11C: sra         $t9, $t5, 2
    ctx->r25 = S32(SIGNED(ctx->r13) >> 2);
    // 0x802FD120: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802FD124: jal         0x802D7BE0
    // 0x802FD128: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    func_802D7BE0_6E9290(rdram, ctx);
        goto after_27;
    // 0x802FD128: addiu       $a1, $zero, 0x10
    ctx->r5 = ADD32(0, 0X10);
    after_27:
    // 0x802FD12C: b           L_802FD180
    // 0x802FD130: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD130: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD134:
    // 0x802FD134: jal         0x802FC6E4
    // 0x802FD138: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FC6E4_70DD94(rdram, ctx);
        goto after_28;
    // 0x802FD138: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_28:
    // 0x802FD13C: lh          $t8, 0x8($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X8);
    // 0x802FD140: lh          $a3, 0x4($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X4);
    // 0x802FD144: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802FD148: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FD14C: lh          $t0, 0xC($s0)
    ctx->r8 = MEM_H(ctx->r16, 0XC);
    // 0x802FD150: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FD154: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x802FD158: addiu       $a1, $zero, 0x6000
    ctx->r5 = ADD32(0, 0X6000);
    // 0x802FD15C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802FD160: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802FD164: jal         0x8032C360
    // 0x802FD168: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    play_sound_effect_at_location(rdram, ctx);
        goto after_29;
    // 0x802FD168: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    after_29:
    // 0x802FD16C: b           L_802FD180
    // 0x802FD170: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
        goto L_802FD180;
    // 0x802FD170: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD174:
    // 0x802FD174: jal         0x802FB85C
    // 0x802FD178: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    func_802FB85C_70CF0C(rdram, ctx);
        goto after_30;
    // 0x802FD178: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    after_30:
L_802FD17C:
    // 0x802FD17C: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
L_802FD180:
    // 0x802FD180: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FD184: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FD188: jr          $ra
    // 0x802FD18C: nop

    return;
    // 0x802FD18C: nop

;}
RECOMP_FUNC void set_floor_level(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD190: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802FD194: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802FD198: lbu         $t1, 0x2B($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X2B);
    // 0x802FD19C: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x802FD1A0: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x802FD1A4: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802FD1A8: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x802FD1AC: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802FD1B0: andi        $s0, $a0, 0xFF
    ctx->r16 = ctx->r4 & 0XFF;
    // 0x802FD1B4: andi        $s1, $a1, 0xFF
    ctx->r17 = ctx->r5 & 0XFF;
    // 0x802FD1B8: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802FD1BC: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802FD1C0: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802FD1C4: bltz        $t1, L_802FD248
    if (SIGNED(ctx->r9) < 0) {
        // 0x802FD1C8: or          $t0, $zero, $zero
        ctx->r8 = 0 | 0;
            goto L_802FD248;
    }
    // 0x802FD1C8: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x802FD1CC: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802FD1D0: lh          $a2, 0x32($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X32);
L_802FD1D4:
    // 0x802FD1D4: bltz        $a1, L_802FD230
    if (SIGNED(ctx->r5) < 0) {
        // 0x802FD1D8: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD230;
    }
    // 0x802FD1D8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802FD1DC: sll         $t7, $s0, 7
    ctx->r15 = S32(ctx->r16 << 7);
    // 0x802FD1E0: sll         $t8, $t0, 7
    ctx->r24 = S32(ctx->r8 << 7);
    // 0x802FD1E4: addu        $t8, $t8, $t0
    ctx->r24 = ADD32(ctx->r24, ctx->r8);
    // 0x802FD1E8: addu        $t7, $t7, $s0
    ctx->r15 = ADD32(ctx->r15, ctx->r16);
    // 0x802FD1EC: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802FD1F0: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FD1F4: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x802FD1F8: sll         $t2, $s1, 3
    ctx->r10 = S32(ctx->r17 << 3);
    // 0x802FD1FC: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802FD200: addiu       $t4, $t4, 0x740
    ctx->r12 = ADD32(ctx->r12, 0X740);
    // 0x802FD204: addu        $t3, $t9, $t2
    ctx->r11 = ADD32(ctx->r25, ctx->r10);
    // 0x802FD208: addu        $v1, $t3, $t4
    ctx->r3 = ADD32(ctx->r11, ctx->r12);
    // 0x802FD20C: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
L_802FD210:
    // 0x802FD210: sll         $t5, $v0, 3
    ctx->r13 = S32(ctx->r2 << 3);
    // 0x802FD214: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802FD218: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802FD21C: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FD220: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802FD224: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x802FD228: beq         $at, $zero, L_802FD210
    if (ctx->r1 == 0) {
        // 0x802FD22C: sb          $a0, 0x0($t6)
        MEM_B(0X0, ctx->r14) = ctx->r4;
            goto L_802FD210;
    }
    // 0x802FD22C: sb          $a0, 0x0($t6)
    MEM_B(0X0, ctx->r14) = ctx->r4;
L_802FD230:
    // 0x802FD230: addiu       $t0, $t0, 0x1
    ctx->r8 = ADD32(ctx->r8, 0X1);
    // 0x802FD234: sll         $t9, $t0, 16
    ctx->r25 = S32(ctx->r8 << 16);
    // 0x802FD238: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FD23C: slt         $at, $t1, $t0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FD240: beq         $at, $zero, L_802FD1D4
    if (ctx->r1 == 0) {
        // 0x802FD244: nop
    
            goto L_802FD1D4;
    }
    // 0x802FD244: nop

L_802FD248:
    // 0x802FD248: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x802FD24C: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x802FD250: jal         0x802DAFAC
    // 0x802FD254: lbu         $a2, 0x2B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X2B);
    func_802DAFAC_6EC65C(rdram, ctx);
        goto after_0;
    // 0x802FD254: lbu         $a2, 0x2B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X2B);
    after_0:
    // 0x802FD258: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802FD25C: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x802FD260: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x802FD264: jr          $ra
    // 0x802FD268: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x802FD268: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void set_water_level(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD26C: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x802FD270: sw          $a2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r6;
    // 0x802FD274: lbu         $t1, 0x2B($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X2B);
    // 0x802FD278: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x802FD27C: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x802FD280: sw          $a3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r7;
    // 0x802FD284: andi        $t6, $a3, 0xFF
    ctx->r14 = ctx->r7 & 0XFF;
    // 0x802FD288: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x802FD28C: andi        $s0, $a0, 0xFF
    ctx->r16 = ctx->r4 & 0XFF;
    // 0x802FD290: andi        $s1, $a1, 0xFF
    ctx->r17 = ctx->r5 & 0XFF;
    // 0x802FD294: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802FD298: sw          $a0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r4;
    // 0x802FD29C: sw          $a1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r5;
    // 0x802FD2A0: bltz        $t1, L_802FD324
    if (SIGNED(ctx->r9) < 0) {
        // 0x802FD2A4: or          $t0, $zero, $zero
        ctx->r8 = 0 | 0;
            goto L_802FD324;
    }
    // 0x802FD2A4: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x802FD2A8: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802FD2AC: lh          $a2, 0x32($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X32);
L_802FD2B0:
    // 0x802FD2B0: bltz        $a1, L_802FD30C
    if (SIGNED(ctx->r5) < 0) {
        // 0x802FD2B4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD30C;
    }
    // 0x802FD2B4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802FD2B8: sll         $t7, $s0, 7
    ctx->r15 = S32(ctx->r16 << 7);
    // 0x802FD2BC: sll         $t8, $t0, 7
    ctx->r24 = S32(ctx->r8 << 7);
    // 0x802FD2C0: addu        $t8, $t8, $t0
    ctx->r24 = ADD32(ctx->r24, ctx->r8);
    // 0x802FD2C4: addu        $t7, $t7, $s0
    ctx->r15 = ADD32(ctx->r15, ctx->r16);
    // 0x802FD2C8: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802FD2CC: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FD2D0: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x802FD2D4: sll         $t2, $s1, 3
    ctx->r10 = S32(ctx->r17 << 3);
    // 0x802FD2D8: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802FD2DC: addiu       $t4, $t4, 0x740
    ctx->r12 = ADD32(ctx->r12, 0X740);
    // 0x802FD2E0: addu        $t3, $t9, $t2
    ctx->r11 = ADD32(ctx->r25, ctx->r10);
    // 0x802FD2E4: addu        $v1, $t3, $t4
    ctx->r3 = ADD32(ctx->r11, ctx->r12);
    // 0x802FD2E8: or          $a0, $a2, $zero
    ctx->r4 = ctx->r6 | 0;
L_802FD2EC:
    // 0x802FD2EC: sll         $t5, $v0, 3
    ctx->r13 = S32(ctx->r2 << 3);
    // 0x802FD2F0: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802FD2F4: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x802FD2F8: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FD2FC: slt         $at, $a1, $v0
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x802FD300: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x802FD304: beq         $at, $zero, L_802FD2EC
    if (ctx->r1 == 0) {
        // 0x802FD308: sb          $a0, 0x6($t6)
        MEM_B(0X6, ctx->r14) = ctx->r4;
            goto L_802FD2EC;
    }
    // 0x802FD308: sb          $a0, 0x6($t6)
    MEM_B(0X6, ctx->r14) = ctx->r4;
L_802FD30C:
    // 0x802FD30C: addiu       $t0, $t0, 0x1
    ctx->r8 = ADD32(ctx->r8, 0X1);
    // 0x802FD310: sll         $t9, $t0, 16
    ctx->r25 = S32(ctx->r8 << 16);
    // 0x802FD314: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FD318: slt         $at, $t1, $t0
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FD31C: beq         $at, $zero, L_802FD2B0
    if (ctx->r1 == 0) {
        // 0x802FD320: nop
    
            goto L_802FD2B0;
    }
    // 0x802FD320: nop

L_802FD324:
    // 0x802FD324: andi        $a0, $s0, 0xFF
    ctx->r4 = ctx->r16 & 0XFF;
    // 0x802FD328: andi        $a1, $s1, 0xFF
    ctx->r5 = ctx->r17 & 0XFF;
    // 0x802FD32C: jal         0x802DAFAC
    // 0x802FD330: lbu         $a2, 0x2B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X2B);
    func_802DAFAC_6EC65C(rdram, ctx);
        goto after_0;
    // 0x802FD330: lbu         $a2, 0x2B($sp)
    ctx->r6 = MEM_BU(ctx->r29, 0X2B);
    after_0:
    // 0x802FD334: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802FD338: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x802FD33C: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x802FD340: jr          $ra
    // 0x802FD344: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    return;
    // 0x802FD344: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
;}
RECOMP_FUNC void func_802FD348_70E9F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD348: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802FD34C: lh          $t7, 0x114($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X114);
    // 0x802FD350: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD354: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x802FD358: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x802FD35C: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x802FD360: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x802FD364: addu        $v0, $v0, $t8
    ctx->r2 = ADD32(ctx->r2, ctx->r24);
    // 0x802FD368: lw          $v0, -0x5EF0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X5EF0);
    // 0x802FD36C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x802FD370: beql        $v0, $zero, L_802FD3B0
    if (ctx->r2 == 0) {
        // 0x802FD374: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD3B0;
    }
    goto skip_0;
    // 0x802FD374: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD378: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
L_802FD37C:
    // 0x802FD37C: lw          $t9, 0x6C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X6C);
    // 0x802FD380: bnel        $a0, $t9, L_802FD3A4
    if (ctx->r4 != ctx->r25) {
        // 0x802FD384: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD3A4;
    }
    goto skip_1;
    // 0x802FD384: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_1:
    // 0x802FD388: lw          $t0, 0x16C($v1)
    ctx->r8 = MEM_W(ctx->r3, 0X16C);
    // 0x802FD38C: lhu         $t1, 0x0($t0)
    ctx->r9 = MEM_HU(ctx->r8, 0X0);
    // 0x802FD390: bnel        $a1, $t1, L_802FD3A4
    if (ctx->r5 != ctx->r9) {
        // 0x802FD394: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD3A4;
    }
    goto skip_2;
    // 0x802FD394: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_2:
    // 0x802FD398: jr          $ra
    // 0x802FD39C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD39C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FD3A0: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
L_802FD3A4:
    // 0x802FD3A4: bnel        $v0, $zero, L_802FD37C
    if (ctx->r2 != 0) {
        // 0x802FD3A8: lw          $v1, 0x8($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X8);
            goto L_802FD37C;
    }
    goto skip_3;
    // 0x802FD3A8: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
    skip_3:
    // 0x802FD3AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD3B0:
    // 0x802FD3B0: jr          $ra
    // 0x802FD3B4: nop

    return;
    // 0x802FD3B4: nop

;}
RECOMP_FUNC void func_802FD3B8_70EA68(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD3B8: lh          $t6, 0x114($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X114);
    // 0x802FD3BC: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD3C0: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FD3C4: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802FD3C8: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802FD3CC: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802FD3D0: lw          $v0, -0x5EF0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X5EF0);
    // 0x802FD3D4: beql        $v0, $zero, L_802FD404
    if (ctx->r2 == 0) {
        // 0x802FD3D8: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD404;
    }
    goto skip_0;
    // 0x802FD3D8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD3DC: lw          $t8, 0x8($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X8);
L_802FD3E0:
    // 0x802FD3E0: lw          $t9, 0x6C($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X6C);
    // 0x802FD3E4: bnel        $a0, $t9, L_802FD3F8
    if (ctx->r4 != ctx->r25) {
        // 0x802FD3E8: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD3F8;
    }
    goto skip_1;
    // 0x802FD3E8: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_1:
    // 0x802FD3EC: jr          $ra
    // 0x802FD3F0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD3F0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FD3F4: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
L_802FD3F8:
    // 0x802FD3F8: bnel        $v0, $zero, L_802FD3E0
    if (ctx->r2 != 0) {
        // 0x802FD3FC: lw          $t8, 0x8($v0)
        ctx->r24 = MEM_W(ctx->r2, 0X8);
            goto L_802FD3E0;
    }
    goto skip_2;
    // 0x802FD3FC: lw          $t8, 0x8($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X8);
    skip_2:
    // 0x802FD400: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD404:
    // 0x802FD404: jr          $ra
    // 0x802FD408: nop

    return;
    // 0x802FD408: nop

;}
RECOMP_FUNC void func_802FD40C_70EABC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD40C: lh          $t6, 0x114($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X114);
    // 0x802FD410: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD414: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FD418: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802FD41C: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802FD420: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802FD424: lw          $v0, -0x5EF0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X5EF0);
    // 0x802FD428: beql        $v0, $zero, L_802FD460
    if (ctx->r2 == 0) {
        // 0x802FD42C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD460;
    }
    goto skip_0;
    // 0x802FD42C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD430: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
L_802FD434:
    // 0x802FD434: lw          $t8, 0x6C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X6C);
    // 0x802FD438: bnel        $a0, $t8, L_802FD454
    if (ctx->r4 != ctx->r24) {
        // 0x802FD43C: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD454;
    }
    goto skip_1;
    // 0x802FD43C: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_1:
    // 0x802FD440: bnel        $a1, $v1, L_802FD454
    if (ctx->r5 != ctx->r3) {
        // 0x802FD444: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD454;
    }
    goto skip_2;
    // 0x802FD444: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_2:
    // 0x802FD448: jr          $ra
    // 0x802FD44C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD44C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FD450: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
L_802FD454:
    // 0x802FD454: bnel        $v0, $zero, L_802FD434
    if (ctx->r2 != 0) {
        // 0x802FD458: lw          $v1, 0x8($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X8);
            goto L_802FD434;
    }
    goto skip_3;
    // 0x802FD458: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
    skip_3:
    // 0x802FD45C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD460:
    // 0x802FD460: jr          $ra
    // 0x802FD464: nop

    return;
    // 0x802FD464: nop

;}
RECOMP_FUNC void func_802FD468_70EB18(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD468: lh          $t6, 0x114($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X114);
    // 0x802FD46C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD470: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FD474: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802FD478: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802FD47C: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802FD480: lw          $v0, -0x5EF0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X5EF0);
    // 0x802FD484: beql        $v0, $zero, L_802FD4C8
    if (ctx->r2 == 0) {
        // 0x802FD488: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD4C8;
    }
    goto skip_0;
    // 0x802FD488: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD48C: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
L_802FD490:
    // 0x802FD490: lw          $t8, 0x6C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X6C);
    // 0x802FD494: bnel        $a0, $t8, L_802FD4BC
    if (ctx->r4 != ctx->r24) {
        // 0x802FD498: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD4BC;
    }
    goto skip_1;
    // 0x802FD498: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_1:
    // 0x802FD49C: lw          $t9, 0x16C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X16C);
    // 0x802FD4A0: lhu         $t0, 0x0($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X0);
    // 0x802FD4A4: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x802FD4A8: bnel        $at, $zero, L_802FD4BC
    if (ctx->r1 != 0) {
        // 0x802FD4AC: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD4BC;
    }
    goto skip_2;
    // 0x802FD4AC: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_2:
    // 0x802FD4B0: jr          $ra
    // 0x802FD4B4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD4B4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FD4B8: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
L_802FD4BC:
    // 0x802FD4BC: bnel        $v0, $zero, L_802FD490
    if (ctx->r2 != 0) {
        // 0x802FD4C0: lw          $v1, 0x8($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X8);
            goto L_802FD490;
    }
    goto skip_3;
    // 0x802FD4C0: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
    skip_3:
    // 0x802FD4C4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD4C8:
    // 0x802FD4C8: jr          $ra
    // 0x802FD4CC: nop

    return;
    // 0x802FD4CC: nop

;}
RECOMP_FUNC void func_802FD4D0_70EB80(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD4D0: lh          $t6, 0x114($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X114);
    // 0x802FD4D4: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD4D8: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FD4DC: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802FD4E0: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802FD4E4: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x802FD4E8: lw          $v0, -0x5EF0($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X5EF0);
    // 0x802FD4EC: beql        $v0, $zero, L_802FD530
    if (ctx->r2 == 0) {
        // 0x802FD4F0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD530;
    }
    goto skip_0;
    // 0x802FD4F0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD4F4: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
L_802FD4F8:
    // 0x802FD4F8: lw          $t8, 0x6C($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X6C);
    // 0x802FD4FC: bnel        $a0, $t8, L_802FD524
    if (ctx->r4 != ctx->r24) {
        // 0x802FD500: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD524;
    }
    goto skip_1;
    // 0x802FD500: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_1:
    // 0x802FD504: lw          $t9, 0x16C($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X16C);
    // 0x802FD508: lhu         $t0, 0x0($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X0);
    // 0x802FD50C: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x802FD510: beql        $at, $zero, L_802FD524
    if (ctx->r1 == 0) {
        // 0x802FD514: lw          $v0, 0x0($v0)
        ctx->r2 = MEM_W(ctx->r2, 0X0);
            goto L_802FD524;
    }
    goto skip_2;
    // 0x802FD514: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
    skip_2:
    // 0x802FD518: jr          $ra
    // 0x802FD51C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD51C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FD520: lw          $v0, 0x0($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X0);
L_802FD524:
    // 0x802FD524: bnel        $v0, $zero, L_802FD4F8
    if (ctx->r2 != 0) {
        // 0x802FD528: lw          $v1, 0x8($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X8);
            goto L_802FD4F8;
    }
    goto skip_3;
    // 0x802FD528: lw          $v1, 0x8($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X8);
    skip_3:
    // 0x802FD52C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD530:
    // 0x802FD530: jr          $ra
    // 0x802FD534: nop

    return;
    // 0x802FD534: nop

;}
RECOMP_FUNC void func_802FD538_70EBE8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD538: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x802FD53C: lh          $t6, 0x1B02($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X1B02);
    // 0x802FD540: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802FD544: blezl       $t6, L_802FD5D4
    if (SIGNED(ctx->r14) <= 0) {
        // 0x802FD548: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_802FD5D4;
    }
    goto skip_0;
    // 0x802FD548: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x802FD54C: lh          $t7, 0x5534($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5534);
    // 0x802FD550: lui         $t9, 0x801E
    ctx->r25 = S32(0X801E << 16);
    // 0x802FD554: addiu       $at, $zero, 0xDD
    ctx->r1 = ADD32(0, 0XDD);
    // 0x802FD558: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FD55C: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x802FD560: lw          $t9, -0x2274($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X2274);
    // 0x802FD564: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x802FD568: addiu       $a2, $a2, 0xC0
    ctx->r6 = ADD32(ctx->r6, 0XC0);
    // 0x802FD56C: lhu         $t0, 0x0($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X0);
    // 0x802FD570: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802FD574: addiu       $a3, $zero, 0x38
    ctx->r7 = ADD32(0, 0X38);
    // 0x802FD578: bne         $t0, $at, L_802FD5D0
    if (ctx->r8 != ctx->r1) {
        // 0x802FD57C: addiu       $a1, $zero, 0x2
        ctx->r5 = ADD32(0, 0X2);
            goto L_802FD5D0;
    }
    // 0x802FD57C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
L_802FD580:
    // 0x802FD580: multu       $v0, $a3
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FD584: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802FD588: sll         $t5, $v0, 16
    ctx->r13 = S32(ctx->r2 << 16);
    // 0x802FD58C: sra         $v0, $t5, 16
    ctx->r2 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FD590: slti        $at, $v0, 0x78
    ctx->r1 = SIGNED(ctx->r2) < 0X78 ? 1 : 0;
    // 0x802FD594: mflo        $t1
    ctx->r9 = lo;
    // 0x802FD598: addu        $v1, $a2, $t1
    ctx->r3 = ADD32(ctx->r6, ctx->r9);
    // 0x802FD59C: lb          $t2, 0x2F($v1)
    ctx->r10 = MEM_B(ctx->r3, 0X2F);
    // 0x802FD5A0: bne         $a1, $t2, L_802FD5C8
    if (ctx->r5 != ctx->r10) {
        // 0x802FD5A4: nop
    
            goto L_802FD5C8;
    }
    // 0x802FD5A4: nop

    // 0x802FD5A8: lw          $t3, 0x4($v1)
    ctx->r11 = MEM_W(ctx->r3, 0X4);
    // 0x802FD5AC: beq         $a0, $t3, L_802FD5C0
    if (ctx->r4 == ctx->r11) {
        // 0x802FD5B0: nop
    
            goto L_802FD5C0;
    }
    // 0x802FD5B0: nop

    // 0x802FD5B4: lw          $t4, 0x0($v1)
    ctx->r12 = MEM_W(ctx->r3, 0X0);
    // 0x802FD5B8: bne         $a0, $t4, L_802FD5C8
    if (ctx->r4 != ctx->r12) {
        // 0x802FD5BC: nop
    
            goto L_802FD5C8;
    }
    // 0x802FD5BC: nop

L_802FD5C0:
    // 0x802FD5C0: jr          $ra
    // 0x802FD5C4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x802FD5C4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_802FD5C8:
    // 0x802FD5C8: bne         $at, $zero, L_802FD580
    if (ctx->r1 != 0) {
        // 0x802FD5CC: nop
    
            goto L_802FD580;
    }
    // 0x802FD5CC: nop

L_802FD5D0:
    // 0x802FD5D0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_802FD5D4:
    // 0x802FD5D4: jr          $ra
    // 0x802FD5D8: nop

    return;
    // 0x802FD5D8: nop

;}
RECOMP_FUNC void func_802FD5DC_70EC8C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD5DC: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802FD5E0: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x802FD5E4: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x802FD5E8: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x802FD5EC: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x802FD5F0: lh          $t6, 0x114($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X114);
    // 0x802FD5F4: lui         $s0, 0x803E
    ctx->r16 = S32(0X803E << 16);
    // 0x802FD5F8: or          $s2, $a0, $zero
    ctx->r18 = ctx->r4 | 0;
    // 0x802FD5FC: sll         $t7, $t6, 2
    ctx->r15 = S32(ctx->r14 << 2);
    // 0x802FD600: subu        $t7, $t7, $t6
    ctx->r15 = SUB32(ctx->r15, ctx->r14);
    // 0x802FD604: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x802FD608: addu        $s0, $s0, $t7
    ctx->r16 = ADD32(ctx->r16, ctx->r15);
    // 0x802FD60C: lw          $s0, -0x5EF0($s0)
    ctx->r16 = MEM_W(ctx->r16, -0X5EF0);
    // 0x802FD610: or          $s1, $zero, $zero
    ctx->r17 = 0 | 0;
    // 0x802FD614: beql        $s0, $zero, L_802FD65C
    if (ctx->r16 == 0) {
        // 0x802FD618: lw          $ra, 0x24($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X24);
            goto L_802FD65C;
    }
    goto skip_0;
    // 0x802FD618: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    skip_0:
    // 0x802FD61C: lw          $a0, 0x8($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X8);
L_802FD620:
    // 0x802FD620: lw          $t8, 0x6C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X6C);
    // 0x802FD624: bnel        $s2, $t8, L_802FD650
    if (ctx->r18 != ctx->r24) {
        // 0x802FD628: lw          $s0, 0x0($s0)
        ctx->r16 = MEM_W(ctx->r16, 0X0);
            goto L_802FD650;
    }
    goto skip_1;
    // 0x802FD628: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
    skip_1:
    // 0x802FD62C: jal         0x802FD5DC
    // 0x802FD630: nop

    func_802FD5DC_70EC8C(rdram, ctx);
        goto after_0;
    // 0x802FD630: nop

    after_0:
    // 0x802FD634: lw          $t9, 0x8($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X8);
    // 0x802FD638: lhu         $t0, 0x44($t9)
    ctx->r8 = MEM_HU(ctx->r25, 0X44);
    // 0x802FD63C: addu        $t1, $s1, $t0
    ctx->r9 = ADD32(ctx->r17, ctx->r8);
    // 0x802FD640: addu        $s1, $t1, $v0
    ctx->r17 = ADD32(ctx->r9, ctx->r2);
    // 0x802FD644: sll         $t2, $s1, 16
    ctx->r10 = S32(ctx->r17 << 16);
    // 0x802FD648: sra         $s1, $t2, 16
    ctx->r17 = S32(SIGNED(ctx->r10) >> 16);
    // 0x802FD64C: lw          $s0, 0x0($s0)
    ctx->r16 = MEM_W(ctx->r16, 0X0);
L_802FD650:
    // 0x802FD650: bnel        $s0, $zero, L_802FD620
    if (ctx->r16 != 0) {
        // 0x802FD654: lw          $a0, 0x8($s0)
        ctx->r4 = MEM_W(ctx->r16, 0X8);
            goto L_802FD620;
    }
    goto skip_2;
    // 0x802FD654: lw          $a0, 0x8($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X8);
    skip_2:
    // 0x802FD658: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_802FD65C:
    // 0x802FD65C: or          $v0, $s1, $zero
    ctx->r2 = ctx->r17 | 0;
    // 0x802FD660: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x802FD664: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x802FD668: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x802FD66C: jr          $ra
    // 0x802FD670: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x802FD670: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void func_802FD674_70ED24(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD674: lw          $v0, 0x16C($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X16C);
    // 0x802FD678: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802FD67C: slti        $at, $v1, 0x100
    ctx->r1 = SIGNED(ctx->r3) < 0X100 ? 1 : 0;
    // 0x802FD680: bnel        $at, $zero, L_802FD700
    if (ctx->r1 != 0) {
        // 0x802FD684: lbu         $a2, 0x2($v0)
        ctx->r6 = MEM_BU(ctx->r2, 0X2);
            goto L_802FD700;
    }
    goto skip_0;
    // 0x802FD684: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    skip_0:
    // 0x802FD688: lbu         $t6, 0x56($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X56);
    // 0x802FD68C: slti        $at, $t6, 0x5
    ctx->r1 = SIGNED(ctx->r14) < 0X5 ? 1 : 0;
    // 0x802FD690: beql        $at, $zero, L_802FD700
    if (ctx->r1 == 0) {
        // 0x802FD694: lbu         $a2, 0x2($v0)
        ctx->r6 = MEM_BU(ctx->r2, 0X2);
            goto L_802FD700;
    }
    goto skip_1;
    // 0x802FD694: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    skip_1:
    // 0x802FD698: lbu         $t7, 0x54($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X54);
    // 0x802FD69C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802FD6A0: addiu       $t4, $zero, 0x5
    ctx->r12 = ADD32(0, 0X5);
    // 0x802FD6A4: ori         $t8, $t7, 0xC
    ctx->r24 = ctx->r15 | 0XC;
    // 0x802FD6A8: sb          $t8, 0x54($a0)
    MEM_B(0X54, ctx->r4) = ctx->r24;
    // 0x802FD6AC: lw          $t9, 0x16C($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X16C);
    // 0x802FD6B0: addiu       $t0, $t0, 0x5534
    ctx->r8 = ADD32(ctx->r8, 0X5534);
    // 0x802FD6B4: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802FD6B8: lhu         $t2, 0x0($t9)
    ctx->r10 = MEM_HU(ctx->r25, 0X0);
    // 0x802FD6BC: sw          $a1, 0x58($a0)
    MEM_W(0X58, ctx->r4) = ctx->r5;
    // 0x802FD6C0: sb          $t4, 0x56($a0)
    MEM_B(0X56, ctx->r4) = ctx->r12;
    // 0x802FD6C4: addiu       $t3, $t2, -0x100
    ctx->r11 = ADD32(ctx->r10, -0X100);
    // 0x802FD6C8: sb          $t3, 0x55($a0)
    MEM_B(0X55, ctx->r4) = ctx->r11;
    // 0x802FD6CC: lh          $t5, 0x0($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X0);
    // 0x802FD6D0: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802FD6D4: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x802FD6D8: addu        $t7, $a3, $t6
    ctx->r15 = ADD32(ctx->r7, ctx->r14);
    // 0x802FD6DC: lw          $t8, 0x3EB4($t7)
    ctx->r24 = MEM_W(ctx->r15, 0X3EB4);
    // 0x802FD6E0: bne         $a1, $t8, L_802FD6F4
    if (ctx->r5 != ctx->r24) {
        // 0x802FD6E4: nop
    
            goto L_802FD6F4;
    }
    // 0x802FD6E4: nop

    // 0x802FD6E8: lbu         $t9, 0x54($a0)
    ctx->r25 = MEM_BU(ctx->r4, 0X54);
    // 0x802FD6EC: ori         $t2, $t9, 0x10
    ctx->r10 = ctx->r25 | 0X10;
    // 0x802FD6F0: sb          $t2, 0x54($a0)
    MEM_B(0X54, ctx->r4) = ctx->r10;
L_802FD6F4:
    // 0x802FD6F4: b           L_802FD7A4
    // 0x802FD6F8: addiu       $t1, $zero, 0x9
    ctx->r9 = ADD32(0, 0X9);
        goto L_802FD7A4;
    // 0x802FD6F8: addiu       $t1, $zero, 0x9
    ctx->r9 = ADD32(0, 0X9);
    // 0x802FD6FC: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
L_802FD700:
    // 0x802FD700: addiu       $t1, $zero, 0x9
    ctx->r9 = ADD32(0, 0X9);
    // 0x802FD704: bnel        $t1, $a2, L_802FD714
    if (ctx->r9 != ctx->r6) {
        // 0x802FD708: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802FD714;
    }
    goto skip_2;
    // 0x802FD708: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    skip_2:
    // 0x802FD70C: bne         $t1, $v1, L_802FD7A4
    if (ctx->r9 != ctx->r3) {
        // 0x802FD710: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_802FD7A4;
    }
    // 0x802FD710: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
L_802FD714:
    // 0x802FD714: beq         $a2, $at, L_802FD728
    if (ctx->r6 == ctx->r1) {
        // 0x802FD718: lbu         $v0, 0x56($a0)
        ctx->r2 = MEM_BU(ctx->r4, 0X56);
            goto L_802FD728;
    }
    // 0x802FD718: lbu         $v0, 0x56($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X56);
    // 0x802FD71C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802FD720: bne         $a2, $at, L_802FD730
    if (ctx->r6 != ctx->r1) {
        // 0x802FD724: addiu       $v1, $zero, 0x2
        ctx->r3 = ADD32(0, 0X2);
            goto L_802FD730;
    }
    // 0x802FD724: addiu       $v1, $zero, 0x2
    ctx->r3 = ADD32(0, 0X2);
L_802FD728:
    // 0x802FD728: b           L_802FD730
    // 0x802FD72C: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
        goto L_802FD730;
    // 0x802FD72C: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
L_802FD730:
    // 0x802FD730: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802FD734: beq         $at, $zero, L_802FD75C
    if (ctx->r1 == 0) {
        // 0x802FD738: lui         $a3, 0x801E
        ctx->r7 = S32(0X801E << 16);
            goto L_802FD75C;
    }
    // 0x802FD738: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802FD73C: lbu         $t3, 0x54($a0)
    ctx->r11 = MEM_BU(ctx->r4, 0X54);
    // 0x802FD740: ori         $t4, $t3, 0x9
    ctx->r12 = ctx->r11 | 0X9;
    // 0x802FD744: sb          $t4, 0x54($a0)
    MEM_B(0X54, ctx->r4) = ctx->r12;
    // 0x802FD748: lw          $t5, 0x16C($a1)
    ctx->r13 = MEM_W(ctx->r5, 0X16C);
    // 0x802FD74C: lhu         $t6, 0x0($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0X0);
    // 0x802FD750: sw          $a1, 0x58($a0)
    MEM_W(0X58, ctx->r4) = ctx->r5;
    // 0x802FD754: sb          $v1, 0x56($a0)
    MEM_B(0X56, ctx->r4) = ctx->r3;
    // 0x802FD758: sb          $t6, 0x55($a0)
    MEM_B(0X55, ctx->r4) = ctx->r14;
L_802FD75C:
    // 0x802FD75C: lw          $t7, 0x16C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X16C);
    // 0x802FD760: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802FD764: addiu       $t0, $t0, 0x5534
    ctx->r8 = ADD32(ctx->r8, 0X5534);
    // 0x802FD768: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x802FD76C: slti        $at, $t8, 0x100
    ctx->r1 = SIGNED(ctx->r24) < 0X100 ? 1 : 0;
    // 0x802FD770: bnel        $at, $zero, L_802FD7A8
    if (ctx->r1 != 0) {
        // 0x802FD774: lw          $v0, 0x16C($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X16C);
            goto L_802FD7A8;
    }
    goto skip_3;
    // 0x802FD774: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
    skip_3:
    // 0x802FD778: lh          $t2, 0x0($t0)
    ctx->r10 = MEM_H(ctx->r8, 0X0);
    // 0x802FD77C: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802FD780: lw          $t9, 0x168($a1)
    ctx->r25 = MEM_W(ctx->r5, 0X168);
    // 0x802FD784: sll         $t3, $t2, 3
    ctx->r11 = S32(ctx->r10 << 3);
    // 0x802FD788: addu        $t4, $a3, $t3
    ctx->r12 = ADD32(ctx->r7, ctx->r11);
    // 0x802FD78C: lw          $t5, 0x3EB4($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X3EB4);
    // 0x802FD790: bnel        $t9, $t5, L_802FD7A8
    if (ctx->r25 != ctx->r13) {
        // 0x802FD794: lw          $v0, 0x16C($a0)
        ctx->r2 = MEM_W(ctx->r4, 0X16C);
            goto L_802FD7A8;
    }
    goto skip_4;
    // 0x802FD794: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
    skip_4:
    // 0x802FD798: lb          $t6, 0x2EB($a0)
    ctx->r14 = MEM_B(ctx->r4, 0X2EB);
    // 0x802FD79C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802FD7A0: sb          $t7, 0x2EB($a0)
    MEM_B(0X2EB, ctx->r4) = ctx->r15;
L_802FD7A4:
    // 0x802FD7A4: lw          $v0, 0x16C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X16C);
L_802FD7A8:
    // 0x802FD7A8: lui         $a3, 0x801E
    ctx->r7 = S32(0X801E << 16);
    // 0x802FD7AC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x802FD7B0: lhu         $v1, 0x0($v0)
    ctx->r3 = MEM_HU(ctx->r2, 0X0);
    // 0x802FD7B4: addiu       $t0, $t0, 0x5534
    ctx->r8 = ADD32(ctx->r8, 0X5534);
    // 0x802FD7B8: addiu       $a3, $a3, -0x6128
    ctx->r7 = ADD32(ctx->r7, -0X6128);
    // 0x802FD7BC: slti        $at, $v1, 0x100
    ctx->r1 = SIGNED(ctx->r3) < 0X100 ? 1 : 0;
    // 0x802FD7C0: bnel        $at, $zero, L_802FD82C
    if (ctx->r1 != 0) {
        // 0x802FD7C4: lbu         $a2, 0x2($v0)
        ctx->r6 = MEM_BU(ctx->r2, 0X2);
            goto L_802FD82C;
    }
    goto skip_5;
    // 0x802FD7C4: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    skip_5:
    // 0x802FD7C8: lbu         $t8, 0x56($a1)
    ctx->r24 = MEM_BU(ctx->r5, 0X56);
    // 0x802FD7CC: slti        $at, $t8, 0x5
    ctx->r1 = SIGNED(ctx->r24) < 0X5 ? 1 : 0;
    // 0x802FD7D0: beql        $at, $zero, L_802FD82C
    if (ctx->r1 == 0) {
        // 0x802FD7D4: lbu         $a2, 0x2($v0)
        ctx->r6 = MEM_BU(ctx->r2, 0X2);
            goto L_802FD82C;
    }
    goto skip_6;
    // 0x802FD7D4: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
    skip_6:
    // 0x802FD7D8: lbu         $t2, 0x54($a1)
    ctx->r10 = MEM_BU(ctx->r5, 0X54);
    // 0x802FD7DC: addiu       $t6, $zero, 0x5
    ctx->r14 = ADD32(0, 0X5);
    // 0x802FD7E0: ori         $t3, $t2, 0xC
    ctx->r11 = ctx->r10 | 0XC;
    // 0x802FD7E4: sb          $t3, 0x54($a1)
    MEM_B(0X54, ctx->r5) = ctx->r11;
    // 0x802FD7E8: lw          $t4, 0x16C($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X16C);
    // 0x802FD7EC: lhu         $t9, 0x0($t4)
    ctx->r25 = MEM_HU(ctx->r12, 0X0);
    // 0x802FD7F0: sw          $a0, 0x58($a1)
    MEM_W(0X58, ctx->r5) = ctx->r4;
    // 0x802FD7F4: sb          $t6, 0x56($a1)
    MEM_B(0X56, ctx->r5) = ctx->r14;
    // 0x802FD7F8: addiu       $t5, $t9, -0x100
    ctx->r13 = ADD32(ctx->r25, -0X100);
    // 0x802FD7FC: sb          $t5, 0x55($a1)
    MEM_B(0X55, ctx->r5) = ctx->r13;
    // 0x802FD800: lh          $t7, 0x0($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X0);
    // 0x802FD804: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FD808: addu        $t2, $a3, $t8
    ctx->r10 = ADD32(ctx->r7, ctx->r24);
    // 0x802FD80C: lw          $t3, 0x3EB4($t2)
    ctx->r11 = MEM_W(ctx->r10, 0X3EB4);
    // 0x802FD810: bne         $a0, $t3, L_802FD8C4
    if (ctx->r4 != ctx->r11) {
        // 0x802FD814: nop
    
            goto L_802FD8C4;
    }
    // 0x802FD814: nop

    // 0x802FD818: lbu         $t4, 0x54($a1)
    ctx->r12 = MEM_BU(ctx->r5, 0X54);
    // 0x802FD81C: ori         $t9, $t4, 0x10
    ctx->r25 = ctx->r12 | 0X10;
    // 0x802FD820: jr          $ra
    // 0x802FD824: sb          $t9, 0x54($a1)
    MEM_B(0X54, ctx->r5) = ctx->r25;
    return;
    // 0x802FD824: sb          $t9, 0x54($a1)
    MEM_B(0X54, ctx->r5) = ctx->r25;
    // 0x802FD828: lbu         $a2, 0x2($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X2);
L_802FD82C:
    // 0x802FD82C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FD830: bne         $t1, $a2, L_802FD840
    if (ctx->r9 != ctx->r6) {
        // 0x802FD834: nop
    
            goto L_802FD840;
    }
    // 0x802FD834: nop

    // 0x802FD838: bne         $t1, $v1, L_802FD8C4
    if (ctx->r9 != ctx->r3) {
        // 0x802FD83C: nop
    
            goto L_802FD8C4;
    }
    // 0x802FD83C: nop

L_802FD840:
    // 0x802FD840: beq         $a2, $at, L_802FD854
    if (ctx->r6 == ctx->r1) {
        // 0x802FD844: lbu         $v0, 0x56($a1)
        ctx->r2 = MEM_BU(ctx->r5, 0X56);
            goto L_802FD854;
    }
    // 0x802FD844: lbu         $v0, 0x56($a1)
    ctx->r2 = MEM_BU(ctx->r5, 0X56);
    // 0x802FD848: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x802FD84C: bne         $a2, $at, L_802FD85C
    if (ctx->r6 != ctx->r1) {
        // 0x802FD850: addiu       $v1, $zero, 0x2
        ctx->r3 = ADD32(0, 0X2);
            goto L_802FD85C;
    }
    // 0x802FD850: addiu       $v1, $zero, 0x2
    ctx->r3 = ADD32(0, 0X2);
L_802FD854:
    // 0x802FD854: b           L_802FD85C
    // 0x802FD858: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
        goto L_802FD85C;
    // 0x802FD858: addiu       $v1, $zero, 0xA
    ctx->r3 = ADD32(0, 0XA);
L_802FD85C:
    // 0x802FD85C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802FD860: beql        $at, $zero, L_802FD88C
    if (ctx->r1 == 0) {
        // 0x802FD864: lw          $t2, 0x16C($a1)
        ctx->r10 = MEM_W(ctx->r5, 0X16C);
            goto L_802FD88C;
    }
    goto skip_7;
    // 0x802FD864: lw          $t2, 0x16C($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X16C);
    skip_7:
    // 0x802FD868: lbu         $t5, 0x54($a1)
    ctx->r13 = MEM_BU(ctx->r5, 0X54);
    // 0x802FD86C: ori         $t6, $t5, 0x9
    ctx->r14 = ctx->r13 | 0X9;
    // 0x802FD870: sb          $t6, 0x54($a1)
    MEM_B(0X54, ctx->r5) = ctx->r14;
    // 0x802FD874: lw          $t7, 0x16C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X16C);
    // 0x802FD878: lhu         $t8, 0x0($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X0);
    // 0x802FD87C: sw          $a0, 0x58($a1)
    MEM_W(0X58, ctx->r5) = ctx->r4;
    // 0x802FD880: sb          $v1, 0x56($a1)
    MEM_B(0X56, ctx->r5) = ctx->r3;
    // 0x802FD884: sb          $t8, 0x55($a1)
    MEM_B(0X55, ctx->r5) = ctx->r24;
    // 0x802FD888: lw          $t2, 0x16C($a1)
    ctx->r10 = MEM_W(ctx->r5, 0X16C);
L_802FD88C:
    // 0x802FD88C: lhu         $t3, 0x0($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X0);
    // 0x802FD890: slti        $at, $t3, 0x100
    ctx->r1 = SIGNED(ctx->r11) < 0X100 ? 1 : 0;
    // 0x802FD894: bne         $at, $zero, L_802FD8C4
    if (ctx->r1 != 0) {
        // 0x802FD898: nop
    
            goto L_802FD8C4;
    }
    // 0x802FD898: nop

    // 0x802FD89C: lh          $t9, 0x0($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X0);
    // 0x802FD8A0: lw          $t4, 0x168($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X168);
    // 0x802FD8A4: sll         $t5, $t9, 3
    ctx->r13 = S32(ctx->r25 << 3);
    // 0x802FD8A8: addu        $t6, $a3, $t5
    ctx->r14 = ADD32(ctx->r7, ctx->r13);
    // 0x802FD8AC: lw          $t7, 0x3EB4($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X3EB4);
    // 0x802FD8B0: bne         $t4, $t7, L_802FD8C4
    if (ctx->r12 != ctx->r15) {
        // 0x802FD8B4: nop
    
            goto L_802FD8C4;
    }
    // 0x802FD8B4: nop

    // 0x802FD8B8: lb          $t8, 0x2EB($a1)
    ctx->r24 = MEM_B(ctx->r5, 0X2EB);
    // 0x802FD8BC: addiu       $t2, $t8, 0x1
    ctx->r10 = ADD32(ctx->r24, 0X1);
    // 0x802FD8C0: sb          $t2, 0x2EB($a1)
    MEM_B(0X2EB, ctx->r5) = ctx->r10;
L_802FD8C4:
    // 0x802FD8C4: jr          $ra
    // 0x802FD8C8: nop

    return;
    // 0x802FD8C8: nop

;}
RECOMP_FUNC void func_802FD8CC_70EF7C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD8CC: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x802FD8D0: addiu       $v1, $v1, 0x2D50
    ctx->r3 = ADD32(ctx->r3, 0X2D50);
    // 0x802FD8D4: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD8D8: lhu         $t6, 0x2($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X2);
    // 0x802FD8DC: lhu         $t8, 0x4($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0X4);
    // 0x802FD8E0: addiu       $v0, $v0, 0x1CE8
    ctx->r2 = ADD32(ctx->r2, 0X1CE8);
    // 0x802FD8E4: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FD8E8: addiu       $a0, $a0, 0x1CF8
    ctx->r4 = ADD32(ctx->r4, 0X1CF8);
    // 0x802FD8EC: lhu         $t1, 0x6($v1)
    ctx->r9 = MEM_HU(ctx->r3, 0X6);
    // 0x802FD8F0: lhu         $t3, 0x8($v1)
    ctx->r11 = MEM_HU(ctx->r3, 0X8);
    // 0x802FD8F4: lhu         $t5, 0xA($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0XA);
    // 0x802FD8F8: sh          $t6, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r14;
    // 0x802FD8FC: sh          $t8, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r24;
    // 0x802FD900: lh          $t7, 0x0($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X0);
    // 0x802FD904: lh          $t9, 0x2($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2);
    // 0x802FD908: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802FD90C: addiu       $a1, $a1, 0x1D02
    ctx->r5 = ADD32(ctx->r5, 0X1D02);
    // 0x802FD910: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
    // 0x802FD914: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD918: sb          $t1, 0x4($v0)
    MEM_B(0X4, ctx->r2) = ctx->r9;
    // 0x802FD91C: sb          $t1, 0x4($a0)
    MEM_B(0X4, ctx->r4) = ctx->r9;
    // 0x802FD920: sb          $t3, 0x5($v0)
    MEM_B(0X5, ctx->r2) = ctx->r11;
    // 0x802FD924: sb          $t3, 0x5($a0)
    MEM_B(0X5, ctx->r4) = ctx->r11;
    // 0x802FD928: sb          $t5, 0x6($v0)
    MEM_B(0X6, ctx->r2) = ctx->r13;
    // 0x802FD92C: sb          $t5, 0x6($a0)
    MEM_B(0X6, ctx->r4) = ctx->r13;
    // 0x802FD930: sh          $t7, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r15;
    // 0x802FD934: sh          $t9, 0x2($a0)
    MEM_H(0X2, ctx->r4) = ctx->r25;
    // 0x802FD938: sh          $zero, 0x1D00($at)
    MEM_H(0X1D00, ctx->r1) = 0;
    // 0x802FD93C: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD940: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802FD944: jr          $ra
    // 0x802FD948: sb          $t7, 0x1D04($at)
    MEM_B(0X1D04, ctx->r1) = ctx->r15;
    return;
    // 0x802FD948: sb          $t7, 0x1D04($at)
    MEM_B(0X1D04, ctx->r1) = ctx->r15;
;}
RECOMP_FUNC void func_802FD94C_70EFFC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD94C: lui         $t3, 0x803E
    ctx->r11 = S32(0X803E << 16);
    // 0x802FD950: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802FD954: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802FD958: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802FD95C: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802FD960: addiu       $t3, $t3, 0x1CF8
    ctx->r11 = ADD32(ctx->r11, 0X1CF8);
    // 0x802FD964: lw          $at, 0x0($t3)
    ctx->r1 = MEM_W(ctx->r11, 0X0);
    // 0x802FD968: lw          $t6, 0x4($t3)
    ctx->r14 = MEM_W(ctx->r11, 0X4);
    // 0x802FD96C: lui         $t2, 0x803E
    ctx->r10 = S32(0X803E << 16);
    // 0x802FD970: addiu       $t2, $t2, 0x1CE0
    ctx->r10 = ADD32(ctx->r10, 0X1CE0);
    // 0x802FD974: sw          $at, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r1;
    // 0x802FD978: sw          $t6, 0x4($t2)
    MEM_W(0X4, ctx->r10) = ctx->r14;
    // 0x802FD97C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD980: addiu       $v0, $v0, 0x1CE8
    ctx->r2 = ADD32(ctx->r2, 0X1CE8);
    // 0x802FD984: lbu         $t7, 0x13($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X13);
    // 0x802FD988: lh          $t8, 0x16($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X16);
    // 0x802FD98C: sh          $a0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r4;
    // 0x802FD990: sh          $a1, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r5;
    // 0x802FD994: sb          $a2, 0x4($v0)
    MEM_B(0X4, ctx->r2) = ctx->r6;
    // 0x802FD998: sb          $a3, 0x5($v0)
    MEM_B(0X5, ctx->r2) = ctx->r7;
    // 0x802FD99C: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD9A0: sb          $t7, 0x6($v0)
    MEM_B(0X6, ctx->r2) = ctx->r15;
    // 0x802FD9A4: sh          $t8, 0x1D00($at)
    MEM_H(0X1D00, ctx->r1) = ctx->r24;
    // 0x802FD9A8: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD9AC: sh          $zero, 0x1D02($at)
    MEM_H(0X1D02, ctx->r1) = 0;
    // 0x802FD9B0: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD9B4: sb          $zero, 0x1D04($at)
    MEM_B(0X1D04, ctx->r1) = 0;
    // 0x802FD9B8: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FD9BC: jr          $ra
    // 0x802FD9C0: sh          $zero, 0x1D0C($at)
    MEM_H(0X1D0C, ctx->r1) = 0;
    return;
    // 0x802FD9C0: sh          $zero, 0x1D0C($at)
    MEM_H(0X1D0C, ctx->r1) = 0;
;}
RECOMP_FUNC void func_802FD9C4_70F074(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FD9C4: lui         $t3, 0x803E
    ctx->r11 = S32(0X803E << 16);
    // 0x802FD9C8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802FD9CC: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802FD9D0: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802FD9D4: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802FD9D8: addiu       $t3, $t3, 0x1CF8
    ctx->r11 = ADD32(ctx->r11, 0X1CF8);
    // 0x802FD9DC: lw          $at, 0x0($t3)
    ctx->r1 = MEM_W(ctx->r11, 0X0);
    // 0x802FD9E0: lw          $t6, 0x4($t3)
    ctx->r14 = MEM_W(ctx->r11, 0X4);
    // 0x802FD9E4: lui         $t2, 0x803E
    ctx->r10 = S32(0X803E << 16);
    // 0x802FD9E8: addiu       $t2, $t2, 0x1CE0
    ctx->r10 = ADD32(ctx->r10, 0X1CE0);
    // 0x802FD9EC: sw          $at, 0x0($t2)
    MEM_W(0X0, ctx->r10) = ctx->r1;
    // 0x802FD9F0: sw          $t6, 0x4($t2)
    MEM_W(0X4, ctx->r10) = ctx->r14;
    // 0x802FD9F4: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FD9F8: addiu       $v0, $v0, 0x1CF0
    ctx->r2 = ADD32(ctx->r2, 0X1CF0);
    // 0x802FD9FC: lbu         $t7, 0x13($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X13);
    // 0x802FDA00: lh          $t8, 0x16($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X16);
    // 0x802FDA04: lh          $t9, 0x1A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X1A);
    // 0x802FDA08: sh          $a0, 0x0($v0)
    MEM_H(0X0, ctx->r2) = ctx->r4;
    // 0x802FDA0C: sh          $a1, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r5;
    // 0x802FDA10: sb          $a2, 0x4($v0)
    MEM_B(0X4, ctx->r2) = ctx->r6;
    // 0x802FDA14: sb          $a3, 0x5($v0)
    MEM_B(0X5, ctx->r2) = ctx->r7;
    // 0x802FDA18: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FDA1C: sb          $t7, 0x6($v0)
    MEM_B(0X6, ctx->r2) = ctx->r15;
    // 0x802FDA20: sh          $t8, 0x1D06($at)
    MEM_H(0X1D06, ctx->r1) = ctx->r24;
    // 0x802FDA24: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FDA28: sh          $t9, 0x1D08($at)
    MEM_H(0X1D08, ctx->r1) = ctx->r25;
    // 0x802FDA2C: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FDA30: sh          $zero, 0x1D0A($at)
    MEM_H(0X1D0A, ctx->r1) = 0;
    // 0x802FDA34: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FDA38: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802FDA3C: jr          $ra
    // 0x802FDA40: sh          $t0, 0x1D0C($at)
    MEM_H(0X1D0C, ctx->r1) = ctx->r8;
    return;
    // 0x802FDA40: sh          $t0, 0x1D0C($at)
    MEM_H(0X1D0C, ctx->r1) = ctx->r8;
;}
RECOMP_FUNC void func_802FDA44_70F0F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FDA44: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FDA48: addiu       $a0, $a0, 0x1D04
    ctx->r4 = ADD32(ctx->r4, 0X1D04);
    // 0x802FDA4C: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x802FDA50: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x802FDA54: addiu       $a2, $a2, 0x1CF8
    ctx->r6 = ADD32(ctx->r6, 0X1CF8);
    // 0x802FDA58: bne         $t6, $zero, L_802FDDF8
    if (ctx->r14 != 0) {
        // 0x802FDA5C: lui         $a3, 0x803E
        ctx->r7 = S32(0X803E << 16);
            goto L_802FDDF8;
    }
    // 0x802FDA5C: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x802FDA60: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802FDA64: addiu       $a1, $a1, 0x1D02
    ctx->r5 = ADD32(ctx->r5, 0X1D02);
    // 0x802FDA68: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FDA6C: lhu         $v0, 0x1D00($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X1D00);
    // 0x802FDA70: lhu         $v1, 0x0($a1)
    ctx->r3 = MEM_HU(ctx->r5, 0X0);
    // 0x802FDA74: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x802FDA78: addiu       $a2, $a2, 0x1CF8
    ctx->r6 = ADD32(ctx->r6, 0X1CF8);
    // 0x802FDA7C: bne         $v0, $v1, L_802FDABC
    if (ctx->r2 != ctx->r3) {
        // 0x802FDA80: lui         $a3, 0x803E
        ctx->r7 = S32(0X803E << 16);
            goto L_802FDABC;
    }
    // 0x802FDA80: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x802FDA84: addiu       $a3, $a3, 0x1CE8
    ctx->r7 = ADD32(ctx->r7, 0X1CE8);
    // 0x802FDA88: lh          $t7, 0x0($a3)
    ctx->r15 = MEM_H(ctx->r7, 0X0);
    // 0x802FDA8C: lh          $t8, 0x2($a3)
    ctx->r24 = MEM_H(ctx->r7, 0X2);
    // 0x802FDA90: lbu         $t9, 0x4($a3)
    ctx->r25 = MEM_BU(ctx->r7, 0X4);
    // 0x802FDA94: lbu         $t0, 0x5($a3)
    ctx->r8 = MEM_BU(ctx->r7, 0X5);
    // 0x802FDA98: lbu         $t1, 0x6($a3)
    ctx->r9 = MEM_BU(ctx->r7, 0X6);
    // 0x802FDA9C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FDAA0: sb          $t2, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r10;
    // 0x802FDAA4: sh          $t7, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r15;
    // 0x802FDAA8: sh          $t8, 0x2($a2)
    MEM_H(0X2, ctx->r6) = ctx->r24;
    // 0x802FDAAC: sb          $t9, 0x4($a2)
    MEM_B(0X4, ctx->r6) = ctx->r25;
    // 0x802FDAB0: sb          $t0, 0x5($a2)
    MEM_B(0X5, ctx->r6) = ctx->r8;
    // 0x802FDAB4: b           L_802FDE24
    // 0x802FDAB8: sb          $t1, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r9;
        goto L_802FDE24;
    // 0x802FDAB8: sb          $t1, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r9;
L_802FDABC:
    // 0x802FDABC: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x802FDAC0: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FDAC4: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x802FDAC8: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x802FDACC: addiu       $a3, $a3, 0x1CE8
    ctx->r7 = ADD32(ctx->r7, 0X1CE8);
    // 0x802FDAD0: addiu       $a2, $a2, 0x1CF8
    ctx->r6 = ADD32(ctx->r6, 0X1CF8);
    // 0x802FDAD4: addiu       $a0, $a0, 0x1CE0
    ctx->r4 = ADD32(ctx->r4, 0X1CE0);
    // 0x802FDAD8: bgez        $v1, L_802FDAF0
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802FDADC: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FDAF0;
    }
    // 0x802FDADC: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDAE0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDAE4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDAE8: nop

    // 0x802FDAEC: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802FDAF0:
    // 0x802FDAF0: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x802FDAF4: bgez        $v0, L_802FDB0C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FDAF8: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FDB0C;
    }
    // 0x802FDAF8: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDAFC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDB00: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDB04: nop

    // 0x802FDB08: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_802FDB0C:
    // 0x802FDB0C: div.s       $f0, $f6, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FDB10: lh          $t3, 0x0($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X0);
    // 0x802FDB14: lh          $t4, 0x0($a3)
    ctx->r12 = MEM_H(ctx->r7, 0X0);
    // 0x802FDB18: lh          $t7, 0x2($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X2);
    // 0x802FDB1C: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x802FDB20: mtc1        $t4, $f8
    ctx->f8.u32l = ctx->r12;
    // 0x802FDB24: lh          $t8, 0x2($a3)
    ctx->r24 = MEM_H(ctx->r7, 0X2);
    // 0x802FDB28: cvt.s.w     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDB2C: lbu         $t1, 0x4($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X4);
    // 0x802FDB30: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FDB34: sub.s       $f4, $f6, $f2
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f2.fl;
    // 0x802FDB38: mul.s       $f10, $f4, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FDB3C: mtc1        $t7, $f4
    ctx->f4.u32l = ctx->r15;
    // 0x802FDB40: nop

    // 0x802FDB44: cvt.s.w     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    ctx->f12.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDB48: add.s       $f8, $f2, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f2.fl + ctx->f10.fl;
    // 0x802FDB4C: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x802FDB50: trunc.w.s   $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802FDB54: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDB58: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x802FDB5C: nop

    // 0x802FDB60: sh          $t6, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r14;
    // 0x802FDB64: sub.s       $f6, $f8, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = ctx->f8.fl - ctx->f12.fl;
    // 0x802FDB68: mul.s       $f4, $f6, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802FDB6C: mtc1        $t1, $f6
    ctx->f6.u32l = ctx->r9;
    // 0x802FDB70: nop

    // 0x802FDB74: cvt.s.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDB78: add.s       $f10, $f12, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f12.fl + ctx->f4.fl;
    // 0x802FDB7C: trunc.w.s   $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x802FDB80: mfc1        $t0, $f8
    ctx->r8 = (int32_t)ctx->f8.u32l;
    // 0x802FDB84: bgez        $t1, L_802FDB9C
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802FDB88: sh          $t0, 0x2($a2)
        MEM_H(0X2, ctx->r6) = ctx->r8;
            goto L_802FDB9C;
    }
    // 0x802FDB88: sh          $t0, 0x2($a2)
    MEM_H(0X2, ctx->r6) = ctx->r8;
    // 0x802FDB8C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDB90: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FDB94: nop

    // 0x802FDB98: add.s       $f14, $f14, $f4
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f14.fl = ctx->f14.fl + ctx->f4.fl;
L_802FDB9C:
    // 0x802FDB9C: lbu         $t2, 0x4($a3)
    ctx->r10 = MEM_BU(ctx->r7, 0X4);
    // 0x802FDBA0: mtc1        $t2, $f10
    ctx->f10.u32l = ctx->r10;
    // 0x802FDBA4: bgez        $t2, L_802FDBBC
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802FDBA8: cvt.s.w     $f8, $f10
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FDBBC;
    }
    // 0x802FDBA8: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDBAC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDBB0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FDBB4: nop

    // 0x802FDBB8: add.s       $f8, $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f6.fl;
L_802FDBBC:
    // 0x802FDBBC: sub.s       $f4, $f8, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f14.fl;
    // 0x802FDBC0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FDBC4: mul.s       $f10, $f4, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FDBC8: add.s       $f6, $f14, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f14.fl + ctx->f10.fl;
    // 0x802FDBCC: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x802FDBD0: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FDBD4: nop

    // 0x802FDBD8: cvt.w.s     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FDBDC: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FDBE0: nop

    // 0x802FDBE4: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x802FDBE8: beq         $t4, $zero, L_802FDC34
    if (ctx->r12 == 0) {
        // 0x802FDBEC: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FDC34;
    }
    // 0x802FDBEC: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FDBF0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDBF4: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FDBF8: sub.s       $f8, $f6, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f8.fl;
    // 0x802FDBFC: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FDC00: nop

    // 0x802FDC04: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FDC08: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FDC0C: nop

    // 0x802FDC10: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x802FDC14: bne         $t4, $zero, L_802FDC2C
    if (ctx->r12 != 0) {
        // 0x802FDC18: nop
    
            goto L_802FDC2C;
    }
    // 0x802FDC18: nop

    // 0x802FDC1C: mfc1        $t4, $f8
    ctx->r12 = (int32_t)ctx->f8.u32l;
    // 0x802FDC20: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FDC24: b           L_802FDC44
    // 0x802FDC28: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
        goto L_802FDC44;
    // 0x802FDC28: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
L_802FDC2C:
    // 0x802FDC2C: b           L_802FDC44
    // 0x802FDC30: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
        goto L_802FDC44;
    // 0x802FDC30: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
L_802FDC34:
    // 0x802FDC34: mfc1        $t4, $f8
    ctx->r12 = (int32_t)ctx->f8.u32l;
    // 0x802FDC38: nop

    // 0x802FDC3C: bltz        $t4, L_802FDC2C
    if (SIGNED(ctx->r12) < 0) {
        // 0x802FDC40: nop
    
            goto L_802FDC2C;
    }
    // 0x802FDC40: nop

L_802FDC44:
    // 0x802FDC44: lbu         $t5, 0x5($a0)
    ctx->r13 = MEM_BU(ctx->r4, 0X5);
    // 0x802FDC48: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x802FDC4C: sb          $t4, 0x4($a2)
    MEM_B(0X4, ctx->r6) = ctx->r12;
    // 0x802FDC50: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x802FDC54: addiu       $t3, $v1, 0x1
    ctx->r11 = ADD32(ctx->r3, 0X1);
    // 0x802FDC58: bgez        $t5, L_802FDC70
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FDC5C: cvt.s.w     $f16, $f4
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FDC70;
    }
    // 0x802FDC5C: cvt.s.w     $f16, $f4
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    ctx->f16.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDC60: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDC64: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FDC68: nop

    // 0x802FDC6C: add.s       $f16, $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f10.fl;
L_802FDC70:
    // 0x802FDC70: lbu         $t6, 0x5($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X5);
    // 0x802FDC74: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x802FDC78: bgez        $t6, L_802FDC90
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802FDC7C: cvt.s.w     $f8, $f6
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FDC90;
    }
    // 0x802FDC7C: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDC80: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDC84: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FDC88: nop

    // 0x802FDC8C: add.s       $f8, $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f4.fl;
L_802FDC90:
    // 0x802FDC90: sub.s       $f10, $f8, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f16.fl;
    // 0x802FDC94: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802FDC98: mul.s       $f6, $f10, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802FDC9C: add.s       $f4, $f16, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f16.fl + ctx->f6.fl;
    // 0x802FDCA0: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x802FDCA4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FDCA8: nop

    // 0x802FDCAC: cvt.w.s     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FDCB0: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FDCB4: nop

    // 0x802FDCB8: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802FDCBC: beq         $t8, $zero, L_802FDD08
    if (ctx->r24 == 0) {
        // 0x802FDCC0: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FDD08;
    }
    // 0x802FDCC0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FDCC4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDCC8: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802FDCCC: sub.s       $f8, $f4, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f8.fl;
    // 0x802FDCD0: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FDCD4: nop

    // 0x802FDCD8: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FDCDC: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FDCE0: nop

    // 0x802FDCE4: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802FDCE8: bne         $t8, $zero, L_802FDD00
    if (ctx->r24 != 0) {
        // 0x802FDCEC: nop
    
            goto L_802FDD00;
    }
    // 0x802FDCEC: nop

    // 0x802FDCF0: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x802FDCF4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FDCF8: b           L_802FDD18
    // 0x802FDCFC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_802FDD18;
    // 0x802FDCFC: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_802FDD00:
    // 0x802FDD00: b           L_802FDD18
    // 0x802FDD04: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_802FDD18;
    // 0x802FDD04: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
L_802FDD08:
    // 0x802FDD08: mfc1        $t8, $f8
    ctx->r24 = (int32_t)ctx->f8.u32l;
    // 0x802FDD0C: nop

    // 0x802FDD10: bltz        $t8, L_802FDD00
    if (SIGNED(ctx->r24) < 0) {
        // 0x802FDD14: nop
    
            goto L_802FDD00;
    }
    // 0x802FDD14: nop

L_802FDD18:
    // 0x802FDD18: lbu         $t9, 0x6($a0)
    ctx->r25 = MEM_BU(ctx->r4, 0X6);
    // 0x802FDD1C: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x802FDD20: sb          $t8, 0x5($a2)
    MEM_B(0X5, ctx->r6) = ctx->r24;
    // 0x802FDD24: mtc1        $t9, $f10
    ctx->f10.u32l = ctx->r25;
    // 0x802FDD28: bgez        $t9, L_802FDD40
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FDD2C: cvt.s.w     $f18, $f10
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FDD40;
    }
    // 0x802FDD2C: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDD30: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDD34: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FDD38: nop

    // 0x802FDD3C: add.s       $f18, $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f6.fl;
L_802FDD40:
    // 0x802FDD40: lbu         $t0, 0x6($a3)
    ctx->r8 = MEM_BU(ctx->r7, 0X6);
    // 0x802FDD44: mtc1        $t0, $f4
    ctx->f4.u32l = ctx->r8;
    // 0x802FDD48: bgez        $t0, L_802FDD60
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802FDD4C: cvt.s.w     $f8, $f4
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FDD60;
    }
    // 0x802FDD4C: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDD50: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDD54: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FDD58: nop

    // 0x802FDD5C: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_802FDD60:
    // 0x802FDD60: sub.s       $f6, $f8, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = ctx->f8.fl - ctx->f18.fl;
    // 0x802FDD64: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FDD68: mul.s       $f4, $f6, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802FDD6C: add.s       $f10, $f18, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f18.fl + ctx->f4.fl;
    // 0x802FDD70: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FDD74: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FDD78: nop

    // 0x802FDD7C: cvt.w.s     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FDD80: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FDD84: nop

    // 0x802FDD88: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FDD8C: beq         $t2, $zero, L_802FDDD8
    if (ctx->r10 == 0) {
        // 0x802FDD90: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FDDD8;
    }
    // 0x802FDD90: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FDD94: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDD98: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FDD9C: sub.s       $f8, $f10, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f8.fl = ctx->f10.fl - ctx->f8.fl;
    // 0x802FDDA0: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FDDA4: nop

    // 0x802FDDA8: cvt.w.s     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FDDAC: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FDDB0: nop

    // 0x802FDDB4: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FDDB8: bne         $t2, $zero, L_802FDDD0
    if (ctx->r10 != 0) {
        // 0x802FDDBC: nop
    
            goto L_802FDDD0;
    }
    // 0x802FDDBC: nop

    // 0x802FDDC0: mfc1        $t2, $f8
    ctx->r10 = (int32_t)ctx->f8.u32l;
    // 0x802FDDC4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FDDC8: b           L_802FDDE8
    // 0x802FDDCC: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
        goto L_802FDDE8;
    // 0x802FDDCC: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
L_802FDDD0:
    // 0x802FDDD0: b           L_802FDDE8
    // 0x802FDDD4: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
        goto L_802FDDE8;
    // 0x802FDDD4: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
L_802FDDD8:
    // 0x802FDDD8: mfc1        $t2, $f8
    ctx->r10 = (int32_t)ctx->f8.u32l;
    // 0x802FDDDC: nop

    // 0x802FDDE0: bltz        $t2, L_802FDDD0
    if (SIGNED(ctx->r10) < 0) {
        // 0x802FDDE4: nop
    
            goto L_802FDDD0;
    }
    // 0x802FDDE4: nop

L_802FDDE8:
    // 0x802FDDE8: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FDDEC: sb          $t2, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r10;
    // 0x802FDDF0: b           L_802FDE24
    // 0x802FDDF4: sh          $t3, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r11;
        goto L_802FDE24;
    // 0x802FDDF4: sh          $t3, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r11;
L_802FDDF8:
    // 0x802FDDF8: addiu       $a3, $a3, 0x1CE8
    ctx->r7 = ADD32(ctx->r7, 0X1CE8);
    // 0x802FDDFC: lh          $t4, 0x0($a3)
    ctx->r12 = MEM_H(ctx->r7, 0X0);
    // 0x802FDE00: lh          $t5, 0x2($a3)
    ctx->r13 = MEM_H(ctx->r7, 0X2);
    // 0x802FDE04: lbu         $t6, 0x4($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X4);
    // 0x802FDE08: lbu         $t7, 0x5($a3)
    ctx->r15 = MEM_BU(ctx->r7, 0X5);
    // 0x802FDE0C: lbu         $t8, 0x6($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X6);
    // 0x802FDE10: sh          $t4, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r12;
    // 0x802FDE14: sh          $t5, 0x2($a2)
    MEM_H(0X2, ctx->r6) = ctx->r13;
    // 0x802FDE18: sb          $t6, 0x4($a2)
    MEM_B(0X4, ctx->r6) = ctx->r14;
    // 0x802FDE1C: sb          $t7, 0x5($a2)
    MEM_B(0X5, ctx->r6) = ctx->r15;
    // 0x802FDE20: sb          $t8, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r24;
L_802FDE24:
    // 0x802FDE24: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802FDE28: addiu       $a1, $a1, 0x1D0C
    ctx->r5 = ADD32(ctx->r5, 0X1D0C);
    // 0x802FDE2C: lh          $t9, 0x0($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X0);
    // 0x802FDE30: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x802FDE34: addiu       $a3, $a3, 0x1D0A
    ctx->r7 = ADD32(ctx->r7, 0X1D0A);
    // 0x802FDE38: beq         $t9, $zero, L_802FE4BC
    if (ctx->r25 == 0) {
        // 0x802FDE3C: lui         $v0, 0x803E
        ctx->r2 = S32(0X803E << 16);
            goto L_802FE4BC;
    }
    // 0x802FDE3C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FDE40: lh          $v0, 0x1D06($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X1D06);
    // 0x802FDE44: lh          $v1, 0x0($a3)
    ctx->r3 = MEM_H(ctx->r7, 0X0);
    // 0x802FDE48: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802FDE4C: bne         $at, $zero, L_802FE170
    if (ctx->r1 != 0) {
        // 0x802FDE50: nop
    
            goto L_802FE170;
    }
    // 0x802FDE50: nop

    // 0x802FDE54: bne         $v0, $zero, L_802FDE68
    if (ctx->r2 != 0) {
        // 0x802FDE58: lui         $at, 0x3F80
        ctx->r1 = S32(0X3F80 << 16);
            goto L_802FDE68;
    }
    // 0x802FDE58: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802FDE5C: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802FDE60: b           L_802FDE7C
    // 0x802FDE64: nop

        goto L_802FDE7C;
    // 0x802FDE64: nop

L_802FDE68:
    // 0x802FDE68: mtc1        $v1, $f6
    ctx->f6.u32l = ctx->r3;
    // 0x802FDE6C: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x802FDE70: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDE74: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDE78: div.s       $f0, $f4, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = DIV_S(ctx->f4.fl, ctx->f8.fl);
L_802FDE7C:
    // 0x802FDE7C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FDE80: addiu       $v0, $v0, 0x1CF0
    ctx->r2 = ADD32(ctx->r2, 0X1CF0);
    // 0x802FDE84: lh          $t1, 0x0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X0);
    // 0x802FDE88: lh          $t0, 0x0($a2)
    ctx->r8 = MEM_H(ctx->r6, 0X0);
    // 0x802FDE8C: lh          $t5, 0x2($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2);
    // 0x802FDE90: mtc1        $t1, $f10
    ctx->f10.u32l = ctx->r9;
    // 0x802FDE94: mtc1        $t0, $f6
    ctx->f6.u32l = ctx->r8;
    // 0x802FDE98: lh          $t4, 0x2($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X2);
    // 0x802FDE9C: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FDEA0: lbu         $t8, 0x4($a2)
    ctx->r24 = MEM_BU(ctx->r6, 0X4);
    // 0x802FDEA4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDEA8: cvt.s.w     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    ctx->f2.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDEAC: sub.s       $f8, $f4, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f2.fl;
    // 0x802FDEB0: mul.s       $f6, $f8, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FDEB4: mtc1        $t4, $f8
    ctx->f8.u32l = ctx->r12;
    // 0x802FDEB8: nop

    // 0x802FDEBC: cvt.s.w     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FDEC0: add.s       $f10, $f2, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f2.fl + ctx->f6.fl;
    // 0x802FDEC4: mtc1        $t5, $f6
    ctx->f6.u32l = ctx->r13;
    // 0x802FDEC8: trunc.w.s   $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x802FDECC: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDED0: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    // 0x802FDED4: nop

    // 0x802FDED8: sh          $t3, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r11;
    // 0x802FDEDC: sub.s       $f4, $f10, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f12.fl;
    // 0x802FDEE0: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FDEE4: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x802FDEE8: nop

    // 0x802FDEEC: cvt.s.w     $f14, $f4
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    ctx->f14.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDEF0: add.s       $f6, $f12, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f12.fl + ctx->f8.fl;
    // 0x802FDEF4: trunc.w.s   $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802FDEF8: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x802FDEFC: bgez        $t8, L_802FDF10
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FDF00: sh          $t7, 0x2($a2)
        MEM_H(0X2, ctx->r6) = ctx->r15;
            goto L_802FDF10;
    }
    // 0x802FDF00: sh          $t7, 0x2($a2)
    MEM_H(0X2, ctx->r6) = ctx->r15;
    // 0x802FDF04: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDF08: nop

    // 0x802FDF0C: add.s       $f14, $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f14.fl = ctx->f14.fl + ctx->f8.fl;
L_802FDF10:
    // 0x802FDF10: lbu         $t9, 0x4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X4);
    // 0x802FDF14: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDF18: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x802FDF1C: bgez        $t9, L_802FDF30
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FDF20: cvt.s.w     $f10, $f6
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FDF30;
    }
    // 0x802FDF20: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FDF24: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FDF28: nop

    // 0x802FDF2C: add.s       $f10, $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f4.fl;
L_802FDF30:
    // 0x802FDF30: sub.s       $f8, $f10, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = ctx->f10.fl - ctx->f14.fl;
    // 0x802FDF34: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FDF38: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FDF3C: mul.s       $f6, $f8, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FDF40: add.s       $f4, $f14, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f14.fl + ctx->f6.fl;
    // 0x802FDF44: cfc1        $t0, $FpcCsr
    ctx->r8 = get_cop1_cs();
    // 0x802FDF48: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FDF4C: nop

    // 0x802FDF50: cvt.w.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FDF54: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FDF58: nop

    // 0x802FDF5C: andi        $t1, $t1, 0x78
    ctx->r9 = ctx->r9 & 0X78;
    // 0x802FDF60: beql        $t1, $zero, L_802FDFB0
    if (ctx->r9 == 0) {
        // 0x802FDF64: mfc1        $t1, $f10
        ctx->r9 = (int32_t)ctx->f10.u32l;
            goto L_802FDFB0;
    }
    goto skip_0;
    // 0x802FDF64: mfc1        $t1, $f10
    ctx->r9 = (int32_t)ctx->f10.u32l;
    skip_0:
    // 0x802FDF68: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FDF6C: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FDF70: sub.s       $f10, $f4, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f4.fl - ctx->f10.fl;
    // 0x802FDF74: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FDF78: nop

    // 0x802FDF7C: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FDF80: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FDF84: nop

    // 0x802FDF88: andi        $t1, $t1, 0x78
    ctx->r9 = ctx->r9 & 0X78;
    // 0x802FDF8C: bne         $t1, $zero, L_802FDFA4
    if (ctx->r9 != 0) {
        // 0x802FDF90: nop
    
            goto L_802FDFA4;
    }
    // 0x802FDF90: nop

    // 0x802FDF94: mfc1        $t1, $f10
    ctx->r9 = (int32_t)ctx->f10.u32l;
    // 0x802FDF98: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FDF9C: b           L_802FDFBC
    // 0x802FDFA0: or          $t1, $t1, $at
    ctx->r9 = ctx->r9 | ctx->r1;
        goto L_802FDFBC;
    // 0x802FDFA0: or          $t1, $t1, $at
    ctx->r9 = ctx->r9 | ctx->r1;
L_802FDFA4:
    // 0x802FDFA4: b           L_802FDFBC
    // 0x802FDFA8: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
        goto L_802FDFBC;
    // 0x802FDFA8: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
    // 0x802FDFAC: mfc1        $t1, $f10
    ctx->r9 = (int32_t)ctx->f10.u32l;
L_802FDFB0:
    // 0x802FDFB0: nop

    // 0x802FDFB4: bltz        $t1, L_802FDFA4
    if (SIGNED(ctx->r9) < 0) {
        // 0x802FDFB8: nop
    
            goto L_802FDFA4;
    }
    // 0x802FDFB8: nop

L_802FDFBC:
    // 0x802FDFBC: lbu         $t2, 0x5($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X5);
    // 0x802FDFC0: ctc1        $t0, $FpcCsr
    set_cop1_cs(ctx->r8);
    // 0x802FDFC4: sb          $t1, 0x4($a2)
    MEM_B(0X4, ctx->r6) = ctx->r9;
    // 0x802FDFC8: mtc1        $t2, $f8
    ctx->f8.u32l = ctx->r10;
    // 0x802FDFCC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDFD0: bgez        $t2, L_802FDFE4
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802FDFD4: cvt.s.w     $f16, $f8
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FDFE4;
    }
    // 0x802FDFD4: cvt.s.w     $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FDFD8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FDFDC: nop

    // 0x802FDFE0: add.s       $f16, $f16, $f6
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f6.fl;
L_802FDFE4:
    // 0x802FDFE4: lbu         $t3, 0x5($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X5);
    // 0x802FDFE8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FDFEC: mtc1        $t3, $f4
    ctx->f4.u32l = ctx->r11;
    // 0x802FDFF0: bgez        $t3, L_802FE004
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802FDFF4: cvt.s.w     $f10, $f4
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FE004;
    }
    // 0x802FDFF4: cvt.s.w     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FDFF8: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FDFFC: nop

    // 0x802FE000: add.s       $f10, $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f8.fl;
L_802FE004:
    // 0x802FE004: sub.s       $f6, $f10, $f16
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f6.fl = ctx->f10.fl - ctx->f16.fl;
    // 0x802FE008: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802FE00C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE010: mul.s       $f4, $f6, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802FE014: add.s       $f8, $f16, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x802FE018: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FE01C: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE020: nop

    // 0x802FE024: cvt.w.s     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FE028: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE02C: nop

    // 0x802FE030: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x802FE034: beql        $t5, $zero, L_802FE084
    if (ctx->r13 == 0) {
        // 0x802FE038: mfc1        $t5, $f10
        ctx->r13 = (int32_t)ctx->f10.u32l;
            goto L_802FE084;
    }
    goto skip_1;
    // 0x802FE038: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    skip_1:
    // 0x802FE03C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE040: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802FE044: sub.s       $f10, $f8, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x802FE048: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE04C: nop

    // 0x802FE050: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FE054: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE058: nop

    // 0x802FE05C: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x802FE060: bne         $t5, $zero, L_802FE078
    if (ctx->r13 != 0) {
        // 0x802FE064: nop
    
            goto L_802FE078;
    }
    // 0x802FE064: nop

    // 0x802FE068: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x802FE06C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE070: b           L_802FE090
    // 0x802FE074: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
        goto L_802FE090;
    // 0x802FE074: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
L_802FE078:
    // 0x802FE078: b           L_802FE090
    // 0x802FE07C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
        goto L_802FE090;
    // 0x802FE07C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x802FE080: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
L_802FE084:
    // 0x802FE084: nop

    // 0x802FE088: bltz        $t5, L_802FE078
    if (SIGNED(ctx->r13) < 0) {
        // 0x802FE08C: nop
    
            goto L_802FE078;
    }
    // 0x802FE08C: nop

L_802FE090:
    // 0x802FE090: lbu         $t6, 0x6($a2)
    ctx->r14 = MEM_BU(ctx->r6, 0X6);
    // 0x802FE094: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FE098: sb          $t5, 0x5($a2)
    MEM_B(0X5, ctx->r6) = ctx->r13;
    // 0x802FE09C: mtc1        $t6, $f6
    ctx->f6.u32l = ctx->r14;
    // 0x802FE0A0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE0A4: bgez        $t6, L_802FE0B8
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802FE0A8: cvt.s.w     $f18, $f6
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FE0B8;
    }
    // 0x802FE0A8: cvt.s.w     $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    ctx->f18.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE0AC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE0B0: nop

    // 0x802FE0B4: add.s       $f18, $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f4.fl;
L_802FE0B8:
    // 0x802FE0B8: lbu         $t7, 0x6($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X6);
    // 0x802FE0BC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE0C0: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x802FE0C4: bgez        $t7, L_802FE0D8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FE0C8: cvt.s.w     $f10, $f8
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE0D8;
    }
    // 0x802FE0C8: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE0CC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE0D0: nop

    // 0x802FE0D4: add.s       $f10, $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f6.fl;
L_802FE0D8:
    // 0x802FE0D8: sub.s       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f18.fl;
    // 0x802FE0DC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FE0E0: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE0E4: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FE0E8: add.s       $f6, $f18, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f18.fl + ctx->f8.fl;
    // 0x802FE0EC: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FE0F0: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FE0F4: nop

    // 0x802FE0F8: cvt.w.s     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FE0FC: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FE100: nop

    // 0x802FE104: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x802FE108: beql        $t9, $zero, L_802FE158
    if (ctx->r25 == 0) {
        // 0x802FE10C: mfc1        $t9, $f10
        ctx->r25 = (int32_t)ctx->f10.u32l;
            goto L_802FE158;
    }
    goto skip_2;
    // 0x802FE10C: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    skip_2:
    // 0x802FE110: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE114: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FE118: sub.s       $f10, $f6, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x802FE11C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FE120: nop

    // 0x802FE124: cvt.w.s     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FE128: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FE12C: nop

    // 0x802FE130: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x802FE134: bne         $t9, $zero, L_802FE14C
    if (ctx->r25 != 0) {
        // 0x802FE138: nop
    
            goto L_802FE14C;
    }
    // 0x802FE138: nop

    // 0x802FE13C: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
    // 0x802FE140: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE144: b           L_802FE164
    // 0x802FE148: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_802FE164;
    // 0x802FE148: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_802FE14C:
    // 0x802FE14C: b           L_802FE164
    // 0x802FE150: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_802FE164;
    // 0x802FE150: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
    // 0x802FE154: mfc1        $t9, $f10
    ctx->r25 = (int32_t)ctx->f10.u32l;
L_802FE158:
    // 0x802FE158: nop

    // 0x802FE15C: bltz        $t9, L_802FE14C
    if (SIGNED(ctx->r25) < 0) {
        // 0x802FE160: nop
    
            goto L_802FE14C;
    }
    // 0x802FE160: nop

L_802FE164:
    // 0x802FE164: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FE168: b           L_802FE4B4
    // 0x802FE16C: sb          $t9, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r25;
        goto L_802FE4B4;
    // 0x802FE16C: sb          $t9, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r25;
L_802FE170:
    // 0x802FE170: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FE174: lh          $a0, 0x1D08($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X1D08);
    // 0x802FE178: addu        $t0, $v0, $a0
    ctx->r8 = ADD32(ctx->r2, ctx->r4);
    // 0x802FE17C: slt         $at, $t0, $v1
    ctx->r1 = SIGNED(ctx->r8) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x802FE180: bnel        $at, $zero, L_802FE4B4
    if (ctx->r1 != 0) {
        // 0x802FE184: sh          $zero, 0x0($a1)
        MEM_H(0X0, ctx->r5) = 0;
            goto L_802FE4B4;
    }
    goto skip_3;
    // 0x802FE184: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
    skip_3:
    // 0x802FE188: bne         $v0, $zero, L_802FE19C
    if (ctx->r2 != 0) {
        // 0x802FE18C: lui         $at, 0x3F80
        ctx->r1 = S32(0X3F80 << 16);
            goto L_802FE19C;
    }
    // 0x802FE18C: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x802FE190: mtc1        $at, $f0
    ctx->f0.u32l = ctx->r1;
    // 0x802FE194: b           L_802FE1BC
    // 0x802FE198: nop

        goto L_802FE1BC;
    // 0x802FE198: nop

L_802FE19C:
    // 0x802FE19C: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x802FE1A0: mtc1        $v0, $f6
    ctx->f6.u32l = ctx->r2;
    // 0x802FE1A4: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FE1A8: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE1AC: mtc1        $a0, $f6
    ctx->f6.u32l = ctx->r4;
    // 0x802FE1B0: sub.s       $f4, $f8, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f10.fl;
    // 0x802FE1B4: cvt.s.w     $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    ctx->f8.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE1B8: div.s       $f0, $f4, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f0.fl = DIV_S(ctx->f4.fl, ctx->f8.fl);
L_802FE1BC:
    // 0x802FE1BC: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FE1C0: addiu       $v0, $v0, 0x1CF0
    ctx->r2 = ADD32(ctx->r2, 0X1CF0);
    // 0x802FE1C4: lh          $t1, 0x0($v0)
    ctx->r9 = MEM_H(ctx->r2, 0X0);
    // 0x802FE1C8: lh          $t2, 0x0($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X0);
    // 0x802FE1CC: lh          $t5, 0x2($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X2);
    // 0x802FE1D0: mtc1        $t1, $f10
    ctx->f10.u32l = ctx->r9;
    // 0x802FE1D4: mtc1        $t2, $f6
    ctx->f6.u32l = ctx->r10;
    // 0x802FE1D8: lh          $t6, 0x2($a2)
    ctx->r14 = MEM_H(ctx->r6, 0X2);
    // 0x802FE1DC: cvt.s.w     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE1E0: lbu         $t9, 0x4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X4);
    // 0x802FE1E4: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE1E8: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE1EC: sub.s       $f8, $f4, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f2.fl;
    // 0x802FE1F0: mul.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FE1F4: mtc1        $t5, $f8
    ctx->f8.u32l = ctx->r13;
    // 0x802FE1F8: nop

    // 0x802FE1FC: cvt.s.w     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE200: add.s       $f6, $f2, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f2.fl + ctx->f10.fl;
    // 0x802FE204: mtc1        $t6, $f10
    ctx->f10.u32l = ctx->r14;
    // 0x802FE208: trunc.w.s   $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.u32l = TRUNC_W_S(ctx->f6.fl);
    // 0x802FE20C: cvt.s.w     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE210: mfc1        $t4, $f4
    ctx->r12 = (int32_t)ctx->f4.u32l;
    // 0x802FE214: nop

    // 0x802FE218: sh          $t4, 0x0($a2)
    MEM_H(0X0, ctx->r6) = ctx->r12;
    // 0x802FE21C: sub.s       $f4, $f6, $f12
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f12.fl;
    // 0x802FE220: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FE224: mtc1        $t9, $f4
    ctx->f4.u32l = ctx->r25;
    // 0x802FE228: nop

    // 0x802FE22C: cvt.s.w     $f14, $f4
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 4);
    ctx->f14.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FE230: add.s       $f10, $f12, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f12.fl + ctx->f8.fl;
    // 0x802FE234: trunc.w.s   $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.u32l = TRUNC_W_S(ctx->f10.fl);
    // 0x802FE238: mfc1        $t8, $f6
    ctx->r24 = (int32_t)ctx->f6.u32l;
    // 0x802FE23C: bgez        $t9, L_802FE250
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FE240: sh          $t8, 0x2($a2)
        MEM_H(0X2, ctx->r6) = ctx->r24;
            goto L_802FE250;
    }
    // 0x802FE240: sh          $t8, 0x2($a2)
    MEM_H(0X2, ctx->r6) = ctx->r24;
    // 0x802FE244: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE248: nop

    // 0x802FE24C: add.s       $f14, $f14, $f8
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f14.fl = ctx->f14.fl + ctx->f8.fl;
L_802FE250:
    // 0x802FE250: lbu         $t0, 0x4($a2)
    ctx->r8 = MEM_BU(ctx->r6, 0X4);
    // 0x802FE254: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE258: mtc1        $t0, $f10
    ctx->f10.u32l = ctx->r8;
    // 0x802FE25C: bgez        $t0, L_802FE270
    if (SIGNED(ctx->r8) >= 0) {
        // 0x802FE260: cvt.s.w     $f6, $f10
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE270;
    }
    // 0x802FE260: cvt.s.w     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE264: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE268: nop

    // 0x802FE26C: add.s       $f6, $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f4.fl;
L_802FE270:
    // 0x802FE270: sub.s       $f8, $f6, $f14
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f8.fl = ctx->f6.fl - ctx->f14.fl;
    // 0x802FE274: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FE278: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE27C: mul.s       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FE280: add.s       $f4, $f14, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f14.fl + ctx->f10.fl;
    // 0x802FE284: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FE288: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FE28C: nop

    // 0x802FE290: cvt.w.s     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FE294: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FE298: nop

    // 0x802FE29C: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FE2A0: beql        $t2, $zero, L_802FE2F0
    if (ctx->r10 == 0) {
        // 0x802FE2A4: mfc1        $t2, $f6
        ctx->r10 = (int32_t)ctx->f6.u32l;
            goto L_802FE2F0;
    }
    goto skip_4;
    // 0x802FE2A4: mfc1        $t2, $f6
    ctx->r10 = (int32_t)ctx->f6.u32l;
    skip_4:
    // 0x802FE2A8: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE2AC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FE2B0: sub.s       $f6, $f4, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f6.fl;
    // 0x802FE2B4: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FE2B8: nop

    // 0x802FE2BC: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FE2C0: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FE2C4: nop

    // 0x802FE2C8: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FE2CC: bne         $t2, $zero, L_802FE2E4
    if (ctx->r10 != 0) {
        // 0x802FE2D0: nop
    
            goto L_802FE2E4;
    }
    // 0x802FE2D0: nop

    // 0x802FE2D4: mfc1        $t2, $f6
    ctx->r10 = (int32_t)ctx->f6.u32l;
    // 0x802FE2D8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE2DC: b           L_802FE2FC
    // 0x802FE2E0: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
        goto L_802FE2FC;
    // 0x802FE2E0: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
L_802FE2E4:
    // 0x802FE2E4: b           L_802FE2FC
    // 0x802FE2E8: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
        goto L_802FE2FC;
    // 0x802FE2E8: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
    // 0x802FE2EC: mfc1        $t2, $f6
    ctx->r10 = (int32_t)ctx->f6.u32l;
L_802FE2F0:
    // 0x802FE2F0: nop

    // 0x802FE2F4: bltz        $t2, L_802FE2E4
    if (SIGNED(ctx->r10) < 0) {
        // 0x802FE2F8: nop
    
            goto L_802FE2E4;
    }
    // 0x802FE2F8: nop

L_802FE2FC:
    // 0x802FE2FC: lbu         $t3, 0x5($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X5);
    // 0x802FE300: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FE304: sb          $t2, 0x4($a2)
    MEM_B(0X4, ctx->r6) = ctx->r10;
    // 0x802FE308: mtc1        $t3, $f8
    ctx->f8.u32l = ctx->r11;
    // 0x802FE30C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE310: bgez        $t3, L_802FE324
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802FE314: cvt.s.w     $f16, $f8
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE324;
    }
    // 0x802FE314: cvt.s.w     $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    ctx->f16.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE318: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE31C: nop

    // 0x802FE320: add.s       $f16, $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f10.fl;
L_802FE324:
    // 0x802FE324: lbu         $t4, 0x5($a2)
    ctx->r12 = MEM_BU(ctx->r6, 0X5);
    // 0x802FE328: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE32C: mtc1        $t4, $f4
    ctx->f4.u32l = ctx->r12;
    // 0x802FE330: bgez        $t4, L_802FE344
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FE334: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FE344;
    }
    // 0x802FE334: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FE338: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE33C: nop

    // 0x802FE340: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802FE344:
    // 0x802FE344: sub.s       $f10, $f6, $f16
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f10.fl = ctx->f6.fl - ctx->f16.fl;
    // 0x802FE348: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802FE34C: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE350: mul.s       $f4, $f10, $f0
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f4.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802FE354: add.s       $f8, $f16, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f8.fl = ctx->f16.fl + ctx->f4.fl;
    // 0x802FE358: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE35C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x802FE360: nop

    // 0x802FE364: cvt.w.s     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FE368: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x802FE36C: nop

    // 0x802FE370: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x802FE374: beql        $t6, $zero, L_802FE3C4
    if (ctx->r14 == 0) {
        // 0x802FE378: mfc1        $t6, $f6
        ctx->r14 = (int32_t)ctx->f6.u32l;
            goto L_802FE3C4;
    }
    goto skip_5;
    // 0x802FE378: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    skip_5:
    // 0x802FE37C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE380: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802FE384: sub.s       $f6, $f8, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f8.fl - ctx->f6.fl;
    // 0x802FE388: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x802FE38C: nop

    // 0x802FE390: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FE394: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x802FE398: nop

    // 0x802FE39C: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x802FE3A0: bne         $t6, $zero, L_802FE3B8
    if (ctx->r14 != 0) {
        // 0x802FE3A4: nop
    
            goto L_802FE3B8;
    }
    // 0x802FE3A4: nop

    // 0x802FE3A8: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
    // 0x802FE3AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE3B0: b           L_802FE3D0
    // 0x802FE3B4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_802FE3D0;
    // 0x802FE3B4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_802FE3B8:
    // 0x802FE3B8: b           L_802FE3D0
    // 0x802FE3BC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_802FE3D0;
    // 0x802FE3BC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
    // 0x802FE3C0: mfc1        $t6, $f6
    ctx->r14 = (int32_t)ctx->f6.u32l;
L_802FE3C4:
    // 0x802FE3C4: nop

    // 0x802FE3C8: bltz        $t6, L_802FE3B8
    if (SIGNED(ctx->r14) < 0) {
        // 0x802FE3CC: nop
    
            goto L_802FE3B8;
    }
    // 0x802FE3CC: nop

L_802FE3D0:
    // 0x802FE3D0: lbu         $t7, 0x6($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X6);
    // 0x802FE3D4: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE3D8: sb          $t6, 0x5($a2)
    MEM_B(0X5, ctx->r6) = ctx->r14;
    // 0x802FE3DC: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x802FE3E0: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE3E4: bgez        $t7, L_802FE3F8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FE3E8: cvt.s.w     $f18, $f10
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE3F8;
    }
    // 0x802FE3E8: cvt.s.w     $f18, $f10
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    ctx->f18.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE3EC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE3F0: nop

    // 0x802FE3F4: add.s       $f18, $f18, $f4
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f4.fl;
L_802FE3F8:
    // 0x802FE3F8: lbu         $t8, 0x6($a2)
    ctx->r24 = MEM_BU(ctx->r6, 0X6);
    // 0x802FE3FC: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE400: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802FE404: bgez        $t8, L_802FE418
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FE408: cvt.s.w     $f6, $f8
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE418;
    }
    // 0x802FE408: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE40C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE410: nop

    // 0x802FE414: add.s       $f6, $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f10.fl;
L_802FE418:
    // 0x802FE418: sub.s       $f4, $f6, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f18.fl;
    // 0x802FE41C: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802FE420: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE424: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FE428: add.s       $f10, $f18, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f18.fl + ctx->f8.fl;
    // 0x802FE42C: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FE430: ctc1        $t0, $FpcCsr
    set_cop1_cs(ctx->r8);
    // 0x802FE434: nop

    // 0x802FE438: cvt.w.s     $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    ctx->f6.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FE43C: cfc1        $t0, $FpcCsr
    ctx->r8 = get_cop1_cs();
    // 0x802FE440: nop

    // 0x802FE444: andi        $t0, $t0, 0x78
    ctx->r8 = ctx->r8 & 0X78;
    // 0x802FE448: beql        $t0, $zero, L_802FE498
    if (ctx->r8 == 0) {
        // 0x802FE44C: mfc1        $t0, $f6
        ctx->r8 = (int32_t)ctx->f6.u32l;
            goto L_802FE498;
    }
    goto skip_6;
    // 0x802FE44C: mfc1        $t0, $f6
    ctx->r8 = (int32_t)ctx->f6.u32l;
    skip_6:
    // 0x802FE450: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE454: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x802FE458: sub.s       $f6, $f10, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f6.fl = ctx->f10.fl - ctx->f6.fl;
    // 0x802FE45C: ctc1        $t0, $FpcCsr
    set_cop1_cs(ctx->r8);
    // 0x802FE460: nop

    // 0x802FE464: cvt.w.s     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FE468: cfc1        $t0, $FpcCsr
    ctx->r8 = get_cop1_cs();
    // 0x802FE46C: nop

    // 0x802FE470: andi        $t0, $t0, 0x78
    ctx->r8 = ctx->r8 & 0X78;
    // 0x802FE474: bne         $t0, $zero, L_802FE48C
    if (ctx->r8 != 0) {
        // 0x802FE478: nop
    
            goto L_802FE48C;
    }
    // 0x802FE478: nop

    // 0x802FE47C: mfc1        $t0, $f6
    ctx->r8 = (int32_t)ctx->f6.u32l;
    // 0x802FE480: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE484: b           L_802FE4A4
    // 0x802FE488: or          $t0, $t0, $at
    ctx->r8 = ctx->r8 | ctx->r1;
        goto L_802FE4A4;
    // 0x802FE488: or          $t0, $t0, $at
    ctx->r8 = ctx->r8 | ctx->r1;
L_802FE48C:
    // 0x802FE48C: b           L_802FE4A4
    // 0x802FE490: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
        goto L_802FE4A4;
    // 0x802FE490: addiu       $t0, $zero, -0x1
    ctx->r8 = ADD32(0, -0X1);
    // 0x802FE494: mfc1        $t0, $f6
    ctx->r8 = (int32_t)ctx->f6.u32l;
L_802FE498:
    // 0x802FE498: nop

    // 0x802FE49C: bltz        $t0, L_802FE48C
    if (SIGNED(ctx->r8) < 0) {
        // 0x802FE4A0: nop
    
            goto L_802FE48C;
    }
    // 0x802FE4A0: nop

L_802FE4A4:
    // 0x802FE4A4: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FE4A8: b           L_802FE4B4
    // 0x802FE4AC: sb          $t0, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r8;
        goto L_802FE4B4;
    // 0x802FE4AC: sb          $t0, 0x6($a2)
    MEM_B(0X6, ctx->r6) = ctx->r8;
    // 0x802FE4B0: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
L_802FE4B4:
    // 0x802FE4B4: addiu       $t1, $v1, 0x1
    ctx->r9 = ADD32(ctx->r3, 0X1);
    // 0x802FE4B8: sh          $t1, 0x0($a3)
    MEM_H(0X0, ctx->r7) = ctx->r9;
L_802FE4BC:
    // 0x802FE4BC: jr          $ra
    // 0x802FE4C0: nop

    return;
    // 0x802FE4C0: nop

;}
RECOMP_FUNC void func_802FE4C4_70FB74(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FE4C4: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x802FE4C8: addiu       $v1, $v1, 0x2D50
    ctx->r3 = ADD32(ctx->r3, 0X2D50);
    // 0x802FE4CC: lbu         $t7, 0x54($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X54);
    // 0x802FE4D0: lbu         $t9, 0x55($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X55);
    // 0x802FE4D4: lbu         $t1, 0x56($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X56);
    // 0x802FE4D8: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FE4DC: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FE4E0: addiu       $a0, $a0, 0x1D20
    ctx->r4 = ADD32(ctx->r4, 0X1D20);
    // 0x802FE4E4: addiu       $v0, $v0, 0x1D18
    ctx->r2 = ADD32(ctx->r2, 0X1D18);
    // 0x802FE4E8: sb          $t7, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r15;
    // 0x802FE4EC: sb          $t7, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r15;
    // 0x802FE4F0: sb          $t9, 0x1($v0)
    MEM_B(0X1, ctx->r2) = ctx->r25;
    // 0x802FE4F4: sb          $t9, 0x1($a0)
    MEM_B(0X1, ctx->r4) = ctx->r25;
    // 0x802FE4F8: sb          $t1, 0x2($v0)
    MEM_B(0X2, ctx->r2) = ctx->r9;
    // 0x802FE4FC: sb          $t1, 0x2($a0)
    MEM_B(0X2, ctx->r4) = ctx->r9;
    // 0x802FE500: lbu         $t2, 0x57($v1)
    ctx->r10 = MEM_BU(ctx->r3, 0X57);
    // 0x802FE504: lbu         $t5, 0x58($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X58);
    // 0x802FE508: lbu         $t7, 0x59($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X59);
    // 0x802FE50C: lbu         $t9, 0x5A($v1)
    ctx->r25 = MEM_BU(ctx->r3, 0X5A);
    // 0x802FE510: lbu         $t1, 0x5B($v1)
    ctx->r9 = MEM_BU(ctx->r3, 0X5B);
    // 0x802FE514: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802FE518: addiu       $a1, $a1, 0x1D2A
    ctx->r5 = ADD32(ctx->r5, 0X1D2A);
    // 0x802FE51C: sh          $zero, 0x0($a1)
    MEM_H(0X0, ctx->r5) = 0;
    // 0x802FE520: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FE524: sb          $t2, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r10;
    // 0x802FE528: sb          $t2, 0x3($a0)
    MEM_B(0X3, ctx->r4) = ctx->r10;
    // 0x802FE52C: sb          $t5, 0x4($v0)
    MEM_B(0X4, ctx->r2) = ctx->r13;
    // 0x802FE530: sb          $t5, 0x4($a0)
    MEM_B(0X4, ctx->r4) = ctx->r13;
    // 0x802FE534: sb          $t7, 0x5($v0)
    MEM_B(0X5, ctx->r2) = ctx->r15;
    // 0x802FE538: sb          $t7, 0x5($a0)
    MEM_B(0X5, ctx->r4) = ctx->r15;
    // 0x802FE53C: sb          $t9, 0x6($v0)
    MEM_B(0X6, ctx->r2) = ctx->r25;
    // 0x802FE540: sb          $t9, 0x6($a0)
    MEM_B(0X6, ctx->r4) = ctx->r25;
    // 0x802FE544: sb          $t1, 0x7($v0)
    MEM_B(0X7, ctx->r2) = ctx->r9;
    // 0x802FE548: sb          $t1, 0x7($a0)
    MEM_B(0X7, ctx->r4) = ctx->r9;
    // 0x802FE54C: sh          $zero, 0x1D28($at)
    MEM_H(0X1D28, ctx->r1) = 0;
    // 0x802FE550: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FE554: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FE558: jr          $ra
    // 0x802FE55C: sb          $t3, 0x1D2C($at)
    MEM_B(0X1D2C, ctx->r1) = ctx->r11;
    return;
    // 0x802FE55C: sb          $t3, 0x1D2C($at)
    MEM_B(0X1D2C, ctx->r1) = ctx->r11;
;}
RECOMP_FUNC void func_802FE560_70FC10(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FE560: lui         $t1, 0x803E
    ctx->r9 = S32(0X803E << 16);
    // 0x802FE564: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802FE568: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802FE56C: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802FE570: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802FE574: addiu       $t1, $t1, 0x1D20
    ctx->r9 = ADD32(ctx->r9, 0X1D20);
    // 0x802FE578: lw          $at, 0x0($t1)
    ctx->r1 = MEM_W(ctx->r9, 0X0);
    // 0x802FE57C: lw          $t4, 0x4($t1)
    ctx->r12 = MEM_W(ctx->r9, 0X4);
    // 0x802FE580: lui         $t0, 0x803E
    ctx->r8 = S32(0X803E << 16);
    // 0x802FE584: addiu       $t0, $t0, 0x1D10
    ctx->r8 = ADD32(ctx->r8, 0X1D10);
    // 0x802FE588: sw          $at, 0x0($t0)
    MEM_W(0X0, ctx->r8) = ctx->r1;
    // 0x802FE58C: sw          $t4, 0x4($t0)
    MEM_W(0X4, ctx->r8) = ctx->r12;
    // 0x802FE590: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FE594: addiu       $v0, $v0, 0x1D18
    ctx->r2 = ADD32(ctx->r2, 0X1D18);
    // 0x802FE598: lbu         $t5, 0x13($sp)
    ctx->r13 = MEM_BU(ctx->r29, 0X13);
    // 0x802FE59C: lbu         $t6, 0x17($sp)
    ctx->r14 = MEM_BU(ctx->r29, 0X17);
    // 0x802FE5A0: lh          $t7, 0x1A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X1A);
    // 0x802FE5A4: lbu         $t8, 0x1F($sp)
    ctx->r24 = MEM_BU(ctx->r29, 0X1F);
    // 0x802FE5A8: lh          $t9, 0x22($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X22);
    // 0x802FE5AC: sb          $a0, 0x0($v0)
    MEM_B(0X0, ctx->r2) = ctx->r4;
    // 0x802FE5B0: sb          $a1, 0x1($v0)
    MEM_B(0X1, ctx->r2) = ctx->r5;
    // 0x802FE5B4: sb          $a2, 0x2($v0)
    MEM_B(0X2, ctx->r2) = ctx->r6;
    // 0x802FE5B8: sb          $a3, 0x3($v0)
    MEM_B(0X3, ctx->r2) = ctx->r7;
    // 0x802FE5BC: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FE5C0: sb          $t5, 0x4($v0)
    MEM_B(0X4, ctx->r2) = ctx->r13;
    // 0x802FE5C4: sb          $t6, 0x5($v0)
    MEM_B(0X5, ctx->r2) = ctx->r14;
    // 0x802FE5C8: sb          $t7, 0x6($v0)
    MEM_B(0X6, ctx->r2) = ctx->r15;
    // 0x802FE5CC: sb          $t8, 0x7($v0)
    MEM_B(0X7, ctx->r2) = ctx->r24;
    // 0x802FE5D0: sh          $t9, 0x1D28($at)
    MEM_H(0X1D28, ctx->r1) = ctx->r25;
    // 0x802FE5D4: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FE5D8: sh          $zero, 0x1D2A($at)
    MEM_H(0X1D2A, ctx->r1) = 0;
    // 0x802FE5DC: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x802FE5E0: jr          $ra
    // 0x802FE5E4: sb          $zero, 0x1D2C($at)
    MEM_B(0X1D2C, ctx->r1) = 0;
    return;
    // 0x802FE5E4: sb          $zero, 0x1D2C($at)
    MEM_B(0X1D2C, ctx->r1) = 0;
;}
RECOMP_FUNC void func_802FE5E8_70FC98(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FE5E8: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FE5EC: addiu       $a0, $a0, 0x1D2C
    ctx->r4 = ADD32(ctx->r4, 0X1D2C);
    // 0x802FE5F0: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x802FE5F4: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x802FE5F8: addiu       $sp, $sp, -0x10
    ctx->r29 = ADD32(ctx->r29, -0X10);
    // 0x802FE5FC: bne         $t6, $zero, L_802FED60
    if (ctx->r14 != 0) {
        // 0x802FE600: addiu       $a1, $a1, 0x1D2A
        ctx->r5 = ADD32(ctx->r5, 0X1D2A);
            goto L_802FED60;
    }
    // 0x802FE600: addiu       $a1, $a1, 0x1D2A
    ctx->r5 = ADD32(ctx->r5, 0X1D2A);
    // 0x802FE604: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x802FE608: lhu         $v0, 0x1D28($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X1D28);
    // 0x802FE60C: lhu         $v1, 0x0($a1)
    ctx->r3 = MEM_HU(ctx->r5, 0X0);
    // 0x802FE610: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x802FE614: addiu       $a2, $a2, 0x1D10
    ctx->r6 = ADD32(ctx->r6, 0X1D10);
    // 0x802FE618: bne         $v0, $v1, L_802FE628
    if (ctx->r2 != ctx->r3) {
        // 0x802FE61C: lui         $a3, 0x803E
        ctx->r7 = S32(0X803E << 16);
            goto L_802FE628;
    }
    // 0x802FE61C: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x802FE620: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x802FE624: sb          $t7, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r15;
L_802FE628:
    // 0x802FE628: mtc1        $v1, $f4
    ctx->f4.u32l = ctx->r3;
    // 0x802FE62C: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x802FE630: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x802FE634: addiu       $t0, $t0, 0x2D50
    ctx->r8 = ADD32(ctx->r8, 0X2D50);
    // 0x802FE638: addiu       $a0, $a0, 0x1D20
    ctx->r4 = ADD32(ctx->r4, 0X1D20);
    // 0x802FE63C: addiu       $a3, $a3, 0x1D18
    ctx->r7 = ADD32(ctx->r7, 0X1D18);
    // 0x802FE640: bgez        $v1, L_802FE658
    if (SIGNED(ctx->r3) >= 0) {
        // 0x802FE644: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FE658;
    }
    // 0x802FE644: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FE648: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE64C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE650: nop

    // 0x802FE654: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802FE658:
    // 0x802FE658: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x802FE65C: bgez        $v0, L_802FE674
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FE660: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE674;
    }
    // 0x802FE660: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE664: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE668: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE66C: nop

    // 0x802FE670: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_802FE674:
    // 0x802FE674: lbu         $t8, 0x0($a2)
    ctx->r24 = MEM_BU(ctx->r6, 0X0);
    // 0x802FE678: div.s       $f0, $f6, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f0.fl = DIV_S(ctx->f6.fl, ctx->f4.fl);
    // 0x802FE67C: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x802FE680: bgez        $t8, L_802FE698
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FE684: cvt.s.w     $f2, $f10
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE698;
    }
    // 0x802FE684: cvt.s.w     $f2, $f10
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 10);
    ctx->f2.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE688: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE68C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE690: nop

    // 0x802FE694: add.s       $f2, $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f2.fl = ctx->f2.fl + ctx->f8.fl;
L_802FE698:
    // 0x802FE698: lbu         $t9, 0x0($a3)
    ctx->r25 = MEM_BU(ctx->r7, 0X0);
    // 0x802FE69C: mtc1        $t9, $f6
    ctx->f6.u32l = ctx->r25;
    // 0x802FE6A0: bgez        $t9, L_802FE6B8
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FE6A4: cvt.s.w     $f4, $f6
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FE6B8;
    }
    // 0x802FE6A4: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE6A8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE6AC: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE6B0: nop

    // 0x802FE6B4: add.s       $f4, $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f10.fl;
L_802FE6B8:
    // 0x802FE6B8: sub.s       $f8, $f4, $f2
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f2.fl;
    // 0x802FE6BC: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FE6C0: mul.s       $f6, $f8, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FE6C4: add.s       $f10, $f2, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f2.fl + ctx->f6.fl;
    // 0x802FE6C8: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FE6CC: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FE6D0: nop

    // 0x802FE6D4: cvt.w.s     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FE6D8: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FE6DC: nop

    // 0x802FE6E0: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FE6E4: beq         $t2, $zero, L_802FE730
    if (ctx->r10 == 0) {
        // 0x802FE6E8: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FE730;
    }
    // 0x802FE6E8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE6EC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE6F0: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FE6F4: sub.s       $f4, $f10, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f4.fl;
    // 0x802FE6F8: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FE6FC: nop

    // 0x802FE700: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FE704: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FE708: nop

    // 0x802FE70C: andi        $t2, $t2, 0x78
    ctx->r10 = ctx->r10 & 0X78;
    // 0x802FE710: bne         $t2, $zero, L_802FE728
    if (ctx->r10 != 0) {
        // 0x802FE714: nop
    
            goto L_802FE728;
    }
    // 0x802FE714: nop

    // 0x802FE718: mfc1        $t2, $f4
    ctx->r10 = (int32_t)ctx->f4.u32l;
    // 0x802FE71C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE720: b           L_802FE740
    // 0x802FE724: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
        goto L_802FE740;
    // 0x802FE724: or          $t2, $t2, $at
    ctx->r10 = ctx->r10 | ctx->r1;
L_802FE728:
    // 0x802FE728: b           L_802FE740
    // 0x802FE72C: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
        goto L_802FE740;
    // 0x802FE72C: addiu       $t2, $zero, -0x1
    ctx->r10 = ADD32(0, -0X1);
L_802FE730:
    // 0x802FE730: mfc1        $t2, $f4
    ctx->r10 = (int32_t)ctx->f4.u32l;
    // 0x802FE734: nop

    // 0x802FE738: bltz        $t2, L_802FE728
    if (SIGNED(ctx->r10) < 0) {
        // 0x802FE73C: nop
    
            goto L_802FE728;
    }
    // 0x802FE73C: nop

L_802FE740:
    // 0x802FE740: lbu         $t3, 0x1($a2)
    ctx->r11 = MEM_BU(ctx->r6, 0X1);
    // 0x802FE744: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FE748: sb          $t2, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r10;
    // 0x802FE74C: mtc1        $t3, $f8
    ctx->f8.u32l = ctx->r11;
    // 0x802FE750: bgez        $t3, L_802FE768
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802FE754: cvt.s.w     $f12, $f8
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE768;
    }
    // 0x802FE754: cvt.s.w     $f12, $f8
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 8);
    ctx->f12.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE758: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE75C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE760: nop

    // 0x802FE764: add.s       $f12, $f12, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = ctx->f12.fl + ctx->f6.fl;
L_802FE768:
    // 0x802FE768: lbu         $t4, 0x1($a3)
    ctx->r12 = MEM_BU(ctx->r7, 0X1);
    // 0x802FE76C: mtc1        $t4, $f10
    ctx->f10.u32l = ctx->r12;
    // 0x802FE770: bgez        $t4, L_802FE788
    if (SIGNED(ctx->r12) >= 0) {
        // 0x802FE774: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE788;
    }
    // 0x802FE774: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE778: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE77C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE780: nop

    // 0x802FE784: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_802FE788:
    // 0x802FE788: sub.s       $f6, $f4, $f12
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f12.fl;
    // 0x802FE78C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802FE790: mul.s       $f10, $f6, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802FE794: add.s       $f8, $f12, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f12.fl + ctx->f10.fl;
    // 0x802FE798: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE79C: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x802FE7A0: nop

    // 0x802FE7A4: cvt.w.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FE7A8: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x802FE7AC: nop

    // 0x802FE7B0: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x802FE7B4: beq         $t6, $zero, L_802FE800
    if (ctx->r14 == 0) {
        // 0x802FE7B8: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FE800;
    }
    // 0x802FE7B8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE7BC: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE7C0: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x802FE7C4: sub.s       $f4, $f8, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f4.fl;
    // 0x802FE7C8: ctc1        $t6, $FpcCsr
    set_cop1_cs(ctx->r14);
    // 0x802FE7CC: nop

    // 0x802FE7D0: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FE7D4: cfc1        $t6, $FpcCsr
    ctx->r14 = get_cop1_cs();
    // 0x802FE7D8: nop

    // 0x802FE7DC: andi        $t6, $t6, 0x78
    ctx->r14 = ctx->r14 & 0X78;
    // 0x802FE7E0: bne         $t6, $zero, L_802FE7F8
    if (ctx->r14 != 0) {
        // 0x802FE7E4: nop
    
            goto L_802FE7F8;
    }
    // 0x802FE7E4: nop

    // 0x802FE7E8: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    // 0x802FE7EC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE7F0: b           L_802FE810
    // 0x802FE7F4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
        goto L_802FE810;
    // 0x802FE7F4: or          $t6, $t6, $at
    ctx->r14 = ctx->r14 | ctx->r1;
L_802FE7F8:
    // 0x802FE7F8: b           L_802FE810
    // 0x802FE7FC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
        goto L_802FE810;
    // 0x802FE7FC: addiu       $t6, $zero, -0x1
    ctx->r14 = ADD32(0, -0X1);
L_802FE800:
    // 0x802FE800: mfc1        $t6, $f4
    ctx->r14 = (int32_t)ctx->f4.u32l;
    // 0x802FE804: nop

    // 0x802FE808: bltz        $t6, L_802FE7F8
    if (SIGNED(ctx->r14) < 0) {
        // 0x802FE80C: nop
    
            goto L_802FE7F8;
    }
    // 0x802FE80C: nop

L_802FE810:
    // 0x802FE810: lbu         $t7, 0x2($a2)
    ctx->r15 = MEM_BU(ctx->r6, 0X2);
    // 0x802FE814: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE818: sb          $t6, 0x1($a0)
    MEM_B(0X1, ctx->r4) = ctx->r14;
    // 0x802FE81C: mtc1        $t7, $f6
    ctx->f6.u32l = ctx->r15;
    // 0x802FE820: bgez        $t7, L_802FE838
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FE824: cvt.s.w     $f14, $f6
        CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FE838;
    }
    // 0x802FE824: cvt.s.w     $f14, $f6
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    ctx->f14.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE828: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE82C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE830: nop

    // 0x802FE834: add.s       $f14, $f14, $f10
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f14.fl = ctx->f14.fl + ctx->f10.fl;
L_802FE838:
    // 0x802FE838: lbu         $t8, 0x2($a3)
    ctx->r24 = MEM_BU(ctx->r7, 0X2);
    // 0x802FE83C: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x802FE840: bgez        $t8, L_802FE858
    if (SIGNED(ctx->r24) >= 0) {
        // 0x802FE844: cvt.s.w     $f4, $f8
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE858;
    }
    // 0x802FE844: cvt.s.w     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE848: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE84C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE850: nop

    // 0x802FE854: add.s       $f4, $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f6.fl;
L_802FE858:
    // 0x802FE858: sub.s       $f10, $f4, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f14.fl); 
    ctx->f10.fl = ctx->f4.fl - ctx->f14.fl;
    // 0x802FE85C: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FE860: mul.s       $f8, $f10, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f10.fl, ctx->f0.fl);
    // 0x802FE864: add.s       $f6, $f14, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f14.fl + ctx->f8.fl;
    // 0x802FE868: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FE86C: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FE870: nop

    // 0x802FE874: cvt.w.s     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FE878: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FE87C: nop

    // 0x802FE880: andi        $t1, $t1, 0x78
    ctx->r9 = ctx->r9 & 0X78;
    // 0x802FE884: beq         $t1, $zero, L_802FE8D0
    if (ctx->r9 == 0) {
        // 0x802FE888: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FE8D0;
    }
    // 0x802FE888: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE88C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE890: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FE894: sub.s       $f4, $f6, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f4.fl;
    // 0x802FE898: ctc1        $t1, $FpcCsr
    set_cop1_cs(ctx->r9);
    // 0x802FE89C: nop

    // 0x802FE8A0: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FE8A4: cfc1        $t1, $FpcCsr
    ctx->r9 = get_cop1_cs();
    // 0x802FE8A8: nop

    // 0x802FE8AC: andi        $t1, $t1, 0x78
    ctx->r9 = ctx->r9 & 0X78;
    // 0x802FE8B0: bne         $t1, $zero, L_802FE8C8
    if (ctx->r9 != 0) {
        // 0x802FE8B4: nop
    
            goto L_802FE8C8;
    }
    // 0x802FE8B4: nop

    // 0x802FE8B8: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x802FE8BC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE8C0: b           L_802FE8E0
    // 0x802FE8C4: or          $t1, $t1, $at
    ctx->r9 = ctx->r9 | ctx->r1;
        goto L_802FE8E0;
    // 0x802FE8C4: or          $t1, $t1, $at
    ctx->r9 = ctx->r9 | ctx->r1;
L_802FE8C8:
    // 0x802FE8C8: b           L_802FE8E0
    // 0x802FE8CC: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
        goto L_802FE8E0;
    // 0x802FE8CC: addiu       $t1, $zero, -0x1
    ctx->r9 = ADD32(0, -0X1);
L_802FE8D0:
    // 0x802FE8D0: mfc1        $t1, $f4
    ctx->r9 = (int32_t)ctx->f4.u32l;
    // 0x802FE8D4: nop

    // 0x802FE8D8: bltz        $t1, L_802FE8C8
    if (SIGNED(ctx->r9) < 0) {
        // 0x802FE8DC: nop
    
            goto L_802FE8C8;
    }
    // 0x802FE8DC: nop

L_802FE8E0:
    // 0x802FE8E0: lbu         $t2, 0x3($a2)
    ctx->r10 = MEM_BU(ctx->r6, 0X3);
    // 0x802FE8E4: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FE8E8: sb          $t1, 0x2($a0)
    MEM_B(0X2, ctx->r4) = ctx->r9;
    // 0x802FE8EC: mtc1        $t2, $f10
    ctx->f10.u32l = ctx->r10;
    // 0x802FE8F0: bgez        $t2, L_802FE908
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802FE8F4: cvt.s.w     $f16, $f10
        CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE908;
    }
    // 0x802FE8F4: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE8F8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE8FC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE900: nop

    // 0x802FE904: add.s       $f16, $f16, $f8
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f16.fl = ctx->f16.fl + ctx->f8.fl;
L_802FE908:
    // 0x802FE908: lbu         $t3, 0x3($a3)
    ctx->r11 = MEM_BU(ctx->r7, 0X3);
    // 0x802FE90C: mtc1        $t3, $f6
    ctx->f6.u32l = ctx->r11;
    // 0x802FE910: bgez        $t3, L_802FE928
    if (SIGNED(ctx->r11) >= 0) {
        // 0x802FE914: cvt.s.w     $f4, $f6
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FE928;
    }
    // 0x802FE914: cvt.s.w     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FE918: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE91C: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FE920: nop

    // 0x802FE924: add.s       $f4, $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f10.fl;
L_802FE928:
    // 0x802FE928: sub.s       $f8, $f4, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = ctx->f4.fl - ctx->f16.fl;
    // 0x802FE92C: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802FE930: mul.s       $f6, $f8, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f8.fl, ctx->f0.fl);
    // 0x802FE934: add.s       $f10, $f16, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f16.fl + ctx->f6.fl;
    // 0x802FE938: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FE93C: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE940: nop

    // 0x802FE944: cvt.w.s     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FE948: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE94C: nop

    // 0x802FE950: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x802FE954: beq         $t5, $zero, L_802FE9A0
    if (ctx->r13 == 0) {
        // 0x802FE958: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FE9A0;
    }
    // 0x802FE958: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FE95C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FE960: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x802FE964: sub.s       $f4, $f10, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f4.fl;
    // 0x802FE968: ctc1        $t5, $FpcCsr
    set_cop1_cs(ctx->r13);
    // 0x802FE96C: nop

    // 0x802FE970: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FE974: cfc1        $t5, $FpcCsr
    ctx->r13 = get_cop1_cs();
    // 0x802FE978: nop

    // 0x802FE97C: andi        $t5, $t5, 0x78
    ctx->r13 = ctx->r13 & 0X78;
    // 0x802FE980: bne         $t5, $zero, L_802FE998
    if (ctx->r13 != 0) {
        // 0x802FE984: nop
    
            goto L_802FE998;
    }
    // 0x802FE984: nop

    // 0x802FE988: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    // 0x802FE98C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FE990: b           L_802FE9B0
    // 0x802FE994: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
        goto L_802FE9B0;
    // 0x802FE994: or          $t5, $t5, $at
    ctx->r13 = ctx->r13 | ctx->r1;
L_802FE998:
    // 0x802FE998: b           L_802FE9B0
    // 0x802FE99C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
        goto L_802FE9B0;
    // 0x802FE99C: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
L_802FE9A0:
    // 0x802FE9A0: mfc1        $t5, $f4
    ctx->r13 = (int32_t)ctx->f4.u32l;
    // 0x802FE9A4: nop

    // 0x802FE9A8: bltz        $t5, L_802FE998
    if (SIGNED(ctx->r13) < 0) {
        // 0x802FE9AC: nop
    
            goto L_802FE998;
    }
    // 0x802FE9AC: nop

L_802FE9B0:
    // 0x802FE9B0: lbu         $t6, 0x4($a2)
    ctx->r14 = MEM_BU(ctx->r6, 0X4);
    // 0x802FE9B4: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FE9B8: sb          $t5, 0x3($a0)
    MEM_B(0X3, ctx->r4) = ctx->r13;
    // 0x802FE9BC: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x802FE9C0: bgez        $t6, L_802FE9D8
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802FE9C4: cvt.s.w     $f18, $f8
        CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    ctx->f18.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FE9D8;
    }
    // 0x802FE9C4: cvt.s.w     $f18, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 8);
    ctx->f18.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FE9C8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE9CC: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FE9D0: nop

    // 0x802FE9D4: add.s       $f18, $f18, $f6
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f18.fl = ctx->f18.fl + ctx->f6.fl;
L_802FE9D8:
    // 0x802FE9D8: lbu         $t7, 0x4($a3)
    ctx->r15 = MEM_BU(ctx->r7, 0X4);
    // 0x802FE9DC: mtc1        $t7, $f10
    ctx->f10.u32l = ctx->r15;
    // 0x802FE9E0: bgez        $t7, L_802FE9F8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x802FE9E4: cvt.s.w     $f4, $f10
        CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FE9F8;
    }
    // 0x802FE9E4: cvt.s.w     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FE9E8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FE9EC: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FE9F0: nop

    // 0x802FE9F4: add.s       $f4, $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f4.fl + ctx->f8.fl;
L_802FE9F8:
    // 0x802FE9F8: sub.s       $f6, $f4, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = ctx->f4.fl - ctx->f18.fl;
    // 0x802FE9FC: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FEA00: mul.s       $f10, $f6, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f6.fl, ctx->f0.fl);
    // 0x802FEA04: add.s       $f8, $f18, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f18.fl + ctx->f10.fl;
    // 0x802FEA08: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FEA0C: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FEA10: nop

    // 0x802FEA14: cvt.w.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FEA18: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FEA1C: nop

    // 0x802FEA20: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x802FEA24: beq         $t9, $zero, L_802FEA70
    if (ctx->r25 == 0) {
        // 0x802FEA28: lui         $at, 0x4F00
        ctx->r1 = S32(0X4F00 << 16);
            goto L_802FEA70;
    }
    // 0x802FEA28: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FEA2C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FEA30: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FEA34: sub.s       $f4, $f8, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f4.fl;
    // 0x802FEA38: ctc1        $t9, $FpcCsr
    set_cop1_cs(ctx->r25);
    // 0x802FEA3C: nop

    // 0x802FEA40: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FEA44: cfc1        $t9, $FpcCsr
    ctx->r25 = get_cop1_cs();
    // 0x802FEA48: nop

    // 0x802FEA4C: andi        $t9, $t9, 0x78
    ctx->r25 = ctx->r25 & 0X78;
    // 0x802FEA50: bne         $t9, $zero, L_802FEA68
    if (ctx->r25 != 0) {
        // 0x802FEA54: nop
    
            goto L_802FEA68;
    }
    // 0x802FEA54: nop

    // 0x802FEA58: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x802FEA5C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FEA60: b           L_802FEA80
    // 0x802FEA64: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
        goto L_802FEA80;
    // 0x802FEA64: or          $t9, $t9, $at
    ctx->r25 = ctx->r25 | ctx->r1;
L_802FEA68:
    // 0x802FEA68: b           L_802FEA80
    // 0x802FEA6C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
        goto L_802FEA80;
    // 0x802FEA6C: addiu       $t9, $zero, -0x1
    ctx->r25 = ADD32(0, -0X1);
L_802FEA70:
    // 0x802FEA70: mfc1        $t9, $f4
    ctx->r25 = (int32_t)ctx->f4.u32l;
    // 0x802FEA74: nop

    // 0x802FEA78: bltz        $t9, L_802FEA68
    if (SIGNED(ctx->r25) < 0) {
        // 0x802FEA7C: nop
    
            goto L_802FEA68;
    }
    // 0x802FEA7C: nop

L_802FEA80:
    // 0x802FEA80: lbu         $t1, 0x5($a2)
    ctx->r9 = MEM_BU(ctx->r6, 0X5);
    // 0x802FEA84: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FEA88: sb          $t9, 0x4($a0)
    MEM_B(0X4, ctx->r4) = ctx->r25;
    // 0x802FEA8C: mtc1        $t1, $f6
    ctx->f6.u32l = ctx->r9;
    // 0x802FEA90: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEA94: bgez        $t1, L_802FEAA8
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802FEA98: cvt.s.w     $f10, $f6
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
            goto L_802FEAA8;
    }
    // 0x802FEA98: cvt.s.w     $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    ctx->f10.fl = CVT_S_W(ctx->f6.u32l);
    // 0x802FEA9C: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FEAA0: nop

    // 0x802FEAA4: add.s       $f10, $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f8.fl;
L_802FEAA8:
    // 0x802FEAA8: lbu         $t2, 0x5($a3)
    ctx->r10 = MEM_BU(ctx->r7, 0X5);
    // 0x802FEAAC: swc1        $f10, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f10.u32l;
    // 0x802FEAB0: lwc1        $f10, 0x0($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X0);
    // 0x802FEAB4: mtc1        $t2, $f4
    ctx->f4.u32l = ctx->r10;
    // 0x802FEAB8: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEABC: bgez        $t2, L_802FEAD0
    if (SIGNED(ctx->r10) >= 0) {
        // 0x802FEAC0: cvt.s.w     $f6, $f4
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FEAD0;
    }
    // 0x802FEAC0: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FEAC4: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FEAC8: nop

    // 0x802FEACC: add.s       $f6, $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f8.fl;
L_802FEAD0:
    // 0x802FEAD0: sub.s       $f4, $f6, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f10.fl;
    // 0x802FEAD4: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FEAD8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FEADC: mul.s       $f8, $f4, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FEAE0: add.s       $f6, $f10, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f6.fl = ctx->f10.fl + ctx->f8.fl;
    // 0x802FEAE4: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x802FEAE8: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FEAEC: nop

    // 0x802FEAF0: cvt.w.s     $f4, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    ctx->f4.u32l = CVT_W_S(ctx->f6.fl);
    // 0x802FEAF4: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FEAF8: nop

    // 0x802FEAFC: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x802FEB00: beql        $t4, $zero, L_802FEB50
    if (ctx->r12 == 0) {
        // 0x802FEB04: mfc1        $t4, $f4
        ctx->r12 = (int32_t)ctx->f4.u32l;
            goto L_802FEB50;
    }
    goto skip_0;
    // 0x802FEB04: mfc1        $t4, $f4
    ctx->r12 = (int32_t)ctx->f4.u32l;
    skip_0:
    // 0x802FEB08: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FEB0C: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FEB10: sub.s       $f4, $f6, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f6.fl - ctx->f4.fl;
    // 0x802FEB14: ctc1        $t4, $FpcCsr
    set_cop1_cs(ctx->r12);
    // 0x802FEB18: nop

    // 0x802FEB1C: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FEB20: cfc1        $t4, $FpcCsr
    ctx->r12 = get_cop1_cs();
    // 0x802FEB24: nop

    // 0x802FEB28: andi        $t4, $t4, 0x78
    ctx->r12 = ctx->r12 & 0X78;
    // 0x802FEB2C: bne         $t4, $zero, L_802FEB44
    if (ctx->r12 != 0) {
        // 0x802FEB30: nop
    
            goto L_802FEB44;
    }
    // 0x802FEB30: nop

    // 0x802FEB34: mfc1        $t4, $f4
    ctx->r12 = (int32_t)ctx->f4.u32l;
    // 0x802FEB38: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FEB3C: b           L_802FEB5C
    // 0x802FEB40: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
        goto L_802FEB5C;
    // 0x802FEB40: or          $t4, $t4, $at
    ctx->r12 = ctx->r12 | ctx->r1;
L_802FEB44:
    // 0x802FEB44: b           L_802FEB5C
    // 0x802FEB48: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
        goto L_802FEB5C;
    // 0x802FEB48: addiu       $t4, $zero, -0x1
    ctx->r12 = ADD32(0, -0X1);
    // 0x802FEB4C: mfc1        $t4, $f4
    ctx->r12 = (int32_t)ctx->f4.u32l;
L_802FEB50:
    // 0x802FEB50: nop

    // 0x802FEB54: bltz        $t4, L_802FEB44
    if (SIGNED(ctx->r12) < 0) {
        // 0x802FEB58: nop
    
            goto L_802FEB44;
    }
    // 0x802FEB58: nop

L_802FEB5C:
    // 0x802FEB5C: lbu         $t5, 0x6($a2)
    ctx->r13 = MEM_BU(ctx->r6, 0X6);
    // 0x802FEB60: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x802FEB64: sb          $t4, 0x5($a0)
    MEM_B(0X5, ctx->r4) = ctx->r12;
    // 0x802FEB68: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    // 0x802FEB6C: addiu       $t4, $v1, 0x1
    ctx->r12 = ADD32(ctx->r3, 0X1);
    // 0x802FEB70: bgez        $t5, L_802FEB88
    if (SIGNED(ctx->r13) >= 0) {
        // 0x802FEB74: cvt.s.w     $f8, $f10
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
            goto L_802FEB88;
    }
    // 0x802FEB74: cvt.s.w     $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    ctx->f8.fl = CVT_S_W(ctx->f10.u32l);
    // 0x802FEB78: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEB7C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FEB80: nop

    // 0x802FEB84: add.s       $f8, $f8, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f6.fl;
L_802FEB88:
    // 0x802FEB88: lbu         $t6, 0x6($a3)
    ctx->r14 = MEM_BU(ctx->r7, 0X6);
    // 0x802FEB8C: swc1        $f8, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f8.u32l;
    // 0x802FEB90: lwc1        $f8, 0x0($sp)
    ctx->f8.u32l = MEM_W(ctx->r29, 0X0);
    // 0x802FEB94: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802FEB98: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEB9C: bgez        $t6, L_802FEBB0
    if (SIGNED(ctx->r14) >= 0) {
        // 0x802FEBA0: cvt.s.w     $f10, $f4
        CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FEBB0;
    }
    // 0x802FEBA0: cvt.s.w     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    ctx->f10.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FEBA4: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FEBA8: nop

    // 0x802FEBAC: add.s       $f10, $f10, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f10.fl + ctx->f6.fl;
L_802FEBB0:
    // 0x802FEBB0: sub.s       $f4, $f10, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f8.fl;
    // 0x802FEBB4: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802FEBB8: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FEBBC: mul.s       $f6, $f4, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f6.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FEBC0: add.s       $f10, $f8, $f6
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f10.fl = ctx->f8.fl + ctx->f6.fl;
    // 0x802FEBC4: cfc1        $t7, $FpcCsr
    ctx->r15 = get_cop1_cs();
    // 0x802FEBC8: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FEBCC: nop

    // 0x802FEBD0: cvt.w.s     $f4, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    ctx->f4.u32l = CVT_W_S(ctx->f10.fl);
    // 0x802FEBD4: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FEBD8: nop

    // 0x802FEBDC: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802FEBE0: beql        $t8, $zero, L_802FEC30
    if (ctx->r24 == 0) {
        // 0x802FEBE4: mfc1        $t8, $f4
        ctx->r24 = (int32_t)ctx->f4.u32l;
            goto L_802FEC30;
    }
    goto skip_1;
    // 0x802FEBE4: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
    skip_1:
    // 0x802FEBE8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FEBEC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x802FEBF0: sub.s       $f4, $f10, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f10.fl - ctx->f4.fl;
    // 0x802FEBF4: ctc1        $t8, $FpcCsr
    set_cop1_cs(ctx->r24);
    // 0x802FEBF8: nop

    // 0x802FEBFC: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FEC00: cfc1        $t8, $FpcCsr
    ctx->r24 = get_cop1_cs();
    // 0x802FEC04: nop

    // 0x802FEC08: andi        $t8, $t8, 0x78
    ctx->r24 = ctx->r24 & 0X78;
    // 0x802FEC0C: bne         $t8, $zero, L_802FEC24
    if (ctx->r24 != 0) {
        // 0x802FEC10: nop
    
            goto L_802FEC24;
    }
    // 0x802FEC10: nop

    // 0x802FEC14: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
    // 0x802FEC18: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FEC1C: b           L_802FEC3C
    // 0x802FEC20: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
        goto L_802FEC3C;
    // 0x802FEC20: or          $t8, $t8, $at
    ctx->r24 = ctx->r24 | ctx->r1;
L_802FEC24:
    // 0x802FEC24: b           L_802FEC3C
    // 0x802FEC28: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
        goto L_802FEC3C;
    // 0x802FEC28: addiu       $t8, $zero, -0x1
    ctx->r24 = ADD32(0, -0X1);
    // 0x802FEC2C: mfc1        $t8, $f4
    ctx->r24 = (int32_t)ctx->f4.u32l;
L_802FEC30:
    // 0x802FEC30: nop

    // 0x802FEC34: bltz        $t8, L_802FEC24
    if (SIGNED(ctx->r24) < 0) {
        // 0x802FEC38: nop
    
            goto L_802FEC24;
    }
    // 0x802FEC38: nop

L_802FEC3C:
    // 0x802FEC3C: lbu         $t9, 0x7($a2)
    ctx->r25 = MEM_BU(ctx->r6, 0X7);
    // 0x802FEC40: ctc1        $t7, $FpcCsr
    set_cop1_cs(ctx->r15);
    // 0x802FEC44: sb          $t8, 0x6($a0)
    MEM_B(0X6, ctx->r4) = ctx->r24;
    // 0x802FEC48: mtc1        $t9, $f8
    ctx->f8.u32l = ctx->r25;
    // 0x802FEC4C: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEC50: bgez        $t9, L_802FEC64
    if (SIGNED(ctx->r25) >= 0) {
        // 0x802FEC54: cvt.s.w     $f6, $f8
        CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
            goto L_802FEC64;
    }
    // 0x802FEC54: cvt.s.w     $f6, $f8
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    ctx->f6.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FEC58: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FEC5C: nop

    // 0x802FEC60: add.s       $f6, $f6, $f10
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f6.fl = ctx->f6.fl + ctx->f10.fl;
L_802FEC64:
    // 0x802FEC64: lbu         $t1, 0x7($a3)
    ctx->r9 = MEM_BU(ctx->r7, 0X7);
    // 0x802FEC68: swc1        $f6, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->f6.u32l;
    // 0x802FEC6C: lwc1        $f6, 0x0($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X0);
    // 0x802FEC70: mtc1        $t1, $f4
    ctx->f4.u32l = ctx->r9;
    // 0x802FEC74: lui         $at, 0x4F80
    ctx->r1 = S32(0X4F80 << 16);
    // 0x802FEC78: bgez        $t1, L_802FEC8C
    if (SIGNED(ctx->r9) >= 0) {
        // 0x802FEC7C: cvt.s.w     $f8, $f4
        CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
            goto L_802FEC8C;
    }
    // 0x802FEC7C: cvt.s.w     $f8, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    ctx->f8.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FEC80: mtc1        $at, $f10
    ctx->f10.u32l = ctx->r1;
    // 0x802FEC84: nop

    // 0x802FEC88: add.s       $f8, $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f8.fl + ctx->f10.fl;
L_802FEC8C:
    // 0x802FEC8C: sub.s       $f4, $f8, $f6
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f6.fl;
    // 0x802FEC90: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FEC94: lui         $at, 0x4F00
    ctx->r1 = S32(0X4F00 << 16);
    // 0x802FEC98: mul.s       $f10, $f4, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f10.fl = MUL_S(ctx->f4.fl, ctx->f0.fl);
    // 0x802FEC9C: add.s       $f8, $f6, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f8.fl = ctx->f6.fl + ctx->f10.fl;
    // 0x802FECA0: cfc1        $t2, $FpcCsr
    ctx->r10 = get_cop1_cs();
    // 0x802FECA4: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x802FECA8: nop

    // 0x802FECAC: cvt.w.s     $f4, $f8
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    ctx->f4.u32l = CVT_W_S(ctx->f8.fl);
    // 0x802FECB0: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x802FECB4: nop

    // 0x802FECB8: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x802FECBC: beql        $t3, $zero, L_802FED0C
    if (ctx->r11 == 0) {
        // 0x802FECC0: mfc1        $t3, $f4
        ctx->r11 = (int32_t)ctx->f4.u32l;
            goto L_802FED0C;
    }
    goto skip_2;
    // 0x802FECC0: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    skip_2:
    // 0x802FECC4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x802FECC8: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FECCC: sub.s       $f4, $f8, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f4.fl); 
    ctx->f4.fl = ctx->f8.fl - ctx->f4.fl;
    // 0x802FECD0: ctc1        $t3, $FpcCsr
    set_cop1_cs(ctx->r11);
    // 0x802FECD4: nop

    // 0x802FECD8: cvt.w.s     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.u32l = CVT_W_S(ctx->f4.fl);
    // 0x802FECDC: cfc1        $t3, $FpcCsr
    ctx->r11 = get_cop1_cs();
    // 0x802FECE0: nop

    // 0x802FECE4: andi        $t3, $t3, 0x78
    ctx->r11 = ctx->r11 & 0X78;
    // 0x802FECE8: bne         $t3, $zero, L_802FED00
    if (ctx->r11 != 0) {
        // 0x802FECEC: nop
    
            goto L_802FED00;
    }
    // 0x802FECEC: nop

    // 0x802FECF0: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
    // 0x802FECF4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x802FECF8: b           L_802FED18
    // 0x802FECFC: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
        goto L_802FED18;
    // 0x802FECFC: or          $t3, $t3, $at
    ctx->r11 = ctx->r11 | ctx->r1;
L_802FED00:
    // 0x802FED00: b           L_802FED18
    // 0x802FED04: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
        goto L_802FED18;
    // 0x802FED04: addiu       $t3, $zero, -0x1
    ctx->r11 = ADD32(0, -0X1);
    // 0x802FED08: mfc1        $t3, $f4
    ctx->r11 = (int32_t)ctx->f4.u32l;
L_802FED0C:
    // 0x802FED0C: nop

    // 0x802FED10: bltz        $t3, L_802FED00
    if (SIGNED(ctx->r11) < 0) {
        // 0x802FED14: nop
    
            goto L_802FED00;
    }
    // 0x802FED14: nop

L_802FED18:
    // 0x802FED18: ctc1        $t2, $FpcCsr
    set_cop1_cs(ctx->r10);
    // 0x802FED1C: lbu         $t5, 0x0($a0)
    ctx->r13 = MEM_BU(ctx->r4, 0X0);
    // 0x802FED20: lbu         $t6, 0x1($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X1);
    // 0x802FED24: lbu         $t7, 0x2($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X2);
    // 0x802FED28: lbu         $t8, 0x3($a0)
    ctx->r24 = MEM_BU(ctx->r4, 0X3);
    // 0x802FED2C: lbu         $t9, 0x4($a0)
    ctx->r25 = MEM_BU(ctx->r4, 0X4);
    // 0x802FED30: lbu         $t1, 0x5($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X5);
    // 0x802FED34: lbu         $t2, 0x6($a0)
    ctx->r10 = MEM_BU(ctx->r4, 0X6);
    // 0x802FED38: sb          $t3, 0x7($a0)
    MEM_B(0X7, ctx->r4) = ctx->r11;
    // 0x802FED3C: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
    // 0x802FED40: sb          $t3, 0x5B($t0)
    MEM_B(0X5B, ctx->r8) = ctx->r11;
    // 0x802FED44: sb          $t5, 0x54($t0)
    MEM_B(0X54, ctx->r8) = ctx->r13;
    // 0x802FED48: sb          $t6, 0x55($t0)
    MEM_B(0X55, ctx->r8) = ctx->r14;
    // 0x802FED4C: sb          $t7, 0x56($t0)
    MEM_B(0X56, ctx->r8) = ctx->r15;
    // 0x802FED50: sb          $t8, 0x57($t0)
    MEM_B(0X57, ctx->r8) = ctx->r24;
    // 0x802FED54: sb          $t9, 0x58($t0)
    MEM_B(0X58, ctx->r8) = ctx->r25;
    // 0x802FED58: sb          $t1, 0x59($t0)
    MEM_B(0X59, ctx->r8) = ctx->r9;
    // 0x802FED5C: sb          $t2, 0x5A($t0)
    MEM_B(0X5A, ctx->r8) = ctx->r10;
L_802FED60:
    // 0x802FED60: jr          $ra
    // 0x802FED64: addiu       $sp, $sp, 0x10
    ctx->r29 = ADD32(ctx->r29, 0X10);
    return;
    // 0x802FED64: addiu       $sp, $sp, 0x10
    ctx->r29 = ADD32(ctx->r29, 0X10);
;}
RECOMP_FUNC void func_802FED68_710418(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FED68: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802FED6C: lh          $t6, 0x7E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X7E);
    // 0x802FED70: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802FED74: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x802FED78: sw          $a1, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r5;
    // 0x802FED7C: sw          $a2, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r6;
    // 0x802FED80: sw          $a3, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r7;
    // 0x802FED84: addiu       $t7, $sp, 0x50
    ctx->r15 = ADD32(ctx->r29, 0X50);
    // 0x802FED88: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x802FED8C: lh          $a3, 0x7A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7A);
    // 0x802FED90: lh          $a2, 0x76($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X76);
    // 0x802FED94: lh          $a1, 0x72($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X72);
    // 0x802FED98: lh          $a0, 0x6E($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X6E);
    // 0x802FED9C: jal         0x802F5F44
    // 0x802FEDA0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_0;
    // 0x802FEDA0: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    after_0:
    // 0x802FEDA4: lh          $t8, 0x82($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X82);
    // 0x802FEDA8: lh          $t1, 0x7E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X7E);
    // 0x802FEDAC: addiu       $t2, $sp, 0x48
    ctx->r10 = ADD32(ctx->r29, 0X48);
    // 0x802FEDB0: sll         $t9, $t8, 24
    ctx->r25 = S32(ctx->r24 << 24);
    // 0x802FEDB4: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FEDB8: sw          $t2, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r10;
    // 0x802FEDBC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FEDC0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x802FEDC4: lh          $a3, 0x7A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7A);
    // 0x802FEDC8: jal         0x802F5F44
    // 0x802FEDCC: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    func_802F5F44_7075F4(rdram, ctx);
        goto after_1;
    // 0x802FEDCC: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    after_1:
    // 0x802FEDD0: lh          $t3, 0x62($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X62);
    // 0x802FEDD4: lh          $t4, 0x50($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X50);
    // 0x802FEDD8: lh          $t7, 0x66($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X66);
    // 0x802FEDDC: lh          $t8, 0x52($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X52);
    // 0x802FEDE0: addu        $a0, $t3, $t4
    ctx->r4 = ADD32(ctx->r11, ctx->r12);
    // 0x802FEDE4: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x802FEDE8: addu        $a1, $t7, $t8
    ctx->r5 = ADD32(ctx->r15, ctx->r24);
    // 0x802FEDEC: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x802FEDF0: lh          $t5, 0x7E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X7E);
    // 0x802FEDF4: lw          $t6, 0x5C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X5C);
    // 0x802FEDF8: lwc1        $f4, 0x84($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X84);
    // 0x802FEDFC: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x802FEE00: lw          $v0, 0x58($sp)
    ctx->r2 = MEM_W(ctx->r29, 0X58);
    // 0x802FEE04: lh          $t1, 0x6A($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X6A);
    // 0x802FEE08: lh          $t2, 0x54($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X54);
    // 0x802FEE0C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x802FEE10: addiu       $t9, $zero, 0xFA
    ctx->r25 = ADD32(0, 0XFA);
    // 0x802FEE14: addiu       $t8, $zero, 0xA
    ctx->r24 = ADD32(0, 0XA);
    // 0x802FEE18: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x802FEE1C: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x802FEE20: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x802FEE24: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x802FEE28: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x802FEE2C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x802FEE30: swc1        $f4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->f4.u32l;
    // 0x802FEE34: lhu         $t0, 0x40($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X40);
    // 0x802FEE38: addu        $a2, $t1, $t2
    ctx->r6 = ADD32(ctx->r9, ctx->r10);
    // 0x802FEE3C: sll         $t3, $a2, 16
    ctx->r11 = S32(ctx->r6 << 16);
    // 0x802FEE40: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802FEE44: lh          $t3, 0x48($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X48);
    // 0x802FEE48: lh          $t5, 0x4A($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X4A);
    // 0x802FEE4C: lh          $t7, 0x4C($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X4C);
    // 0x802FEE50: sll         $t1, $t0, 2
    ctx->r9 = S32(ctx->r8 << 2);
    // 0x802FEE54: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x802FEE58: sll         $t1, $t1, 1
    ctx->r9 = S32(ctx->r9 << 1);
    // 0x802FEE5C: sra         $t2, $t1, 11
    ctx->r10 = S32(SIGNED(ctx->r9) >> 11);
    // 0x802FEE60: sll         $t4, $t3, 8
    ctx->r12 = S32(ctx->r11 << 8);
    // 0x802FEE64: sll         $t6, $t5, 8
    ctx->r14 = S32(ctx->r13 << 8);
    // 0x802FEE68: sll         $t8, $t7, 8
    ctx->r24 = S32(ctx->r15 << 8);
    // 0x802FEE6C: sw          $t8, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r24;
    // 0x802FEE70: sw          $t6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r14;
    // 0x802FEE74: sw          $t4, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r12;
    // 0x802FEE78: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x802FEE7C: lh          $a3, 0x7A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X7A);
    // 0x802FEE80: jal         0x802FEE98
    // 0x802FEE84: sw          $v0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r2;
    fire_homing_missile(rdram, ctx);
        goto after_2;
    // 0x802FEE84: sw          $v0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r2;
    after_2:
    // 0x802FEE88: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x802FEE8C: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802FEE90: jr          $ra
    // 0x802FEE94: nop

    return;
    // 0x802FEE94: nop

;}
RECOMP_FUNC void fire_homing_missile(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FEE98: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FEE9C: lui         $at, 0x4500
    ctx->r1 = S32(0X4500 << 16);
    // 0x802FEEA0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FEEA4: lwc1        $f4, 0x80($sp)
    ctx->f4.u32l = MEM_W(ctx->r29, 0X80);
    // 0x802FEEA8: lh          $t6, 0x8E($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X8E);
    // 0x802FEEAC: lh          $t8, 0x92($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X92);
    // 0x802FEEB0: mul.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x802FEEB4: lh          $t0, 0x96($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X96);
    // 0x802FEEB8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802FEEBC: sw          $a3, 0x6C($sp)
    MEM_W(0X6C, ctx->r29) = ctx->r7;
    // 0x802FEEC0: lh          $t2, 0x6E($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X6E);
    // 0x802FEEC4: lh          $t3, 0x72($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X72);
    // 0x802FEEC8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x802FEECC: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802FEED0: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802FEED4: sw          $a0, 0x60($sp)
    MEM_W(0X60, ctx->r29) = ctx->r4;
    // 0x802FEED8: sw          $a1, 0x64($sp)
    MEM_W(0X64, ctx->r29) = ctx->r5;
    // 0x802FEEDC: mfc1        $t5, $f10
    ctx->r13 = (int32_t)ctx->f10.u32l;
    // 0x802FEEE0: sw          $a2, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r6;
    // 0x802FEEE4: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802FEEE8: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802FEEEC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FEEF0: sll         $t1, $t0, 16
    ctx->r9 = S32(ctx->r8 << 16);
    // 0x802FEEF4: lh          $a3, 0x6A($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X6A);
    // 0x802FEEF8: lh          $a2, 0x66($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X66);
    // 0x802FEEFC: lh          $a1, 0x62($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X62);
    // 0x802FEF00: sw          $t1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r9;
    // 0x802FEF04: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x802FEF08: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802FEF0C: addiu       $a0, $zero, 0x12
    ctx->r4 = ADD32(0, 0X12);
    // 0x802FEF10: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x802FEF14: jal         0x802C9564
    // 0x802FEF18: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    static_2_802C9564(rdram, ctx);
        goto after_0;
    // 0x802FEF18: sw          $t3, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r11;
    after_0:
    // 0x802FEF1C: beq         $v0, $zero, L_802FF094
    if (ctx->r2 == 0) {
        // 0x802FEF20: addiu       $t8, $zero, 0xF
        ctx->r24 = ADD32(0, 0XF);
            goto L_802FF094;
    }
    // 0x802FEF20: addiu       $t8, $zero, 0xF
    ctx->r24 = ADD32(0, 0XF);
    // 0x802FEF24: sb          $t8, 0x15C($v0)
    MEM_B(0X15C, ctx->r2) = ctx->r24;
    // 0x802FEF28: lw          $t9, 0x98($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X98);
    // 0x802FEF2C: sw          $t9, 0x168($v0)
    MEM_W(0X168, ctx->r2) = ctx->r25;
    // 0x802FEF30: lh          $t0, 0x7A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X7A);
    // 0x802FEF34: sh          $t0, 0x150($v0)
    MEM_H(0X150, ctx->r2) = ctx->r8;
    // 0x802FEF38: lh          $t1, 0x7E($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X7E);
    // 0x802FEF3C: sh          $t1, 0x152($v0)
    MEM_H(0X152, ctx->r2) = ctx->r9;
    // 0x802FEF40: lw          $t2, 0x74($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X74);
    // 0x802FEF44: sw          $t2, 0x188($v0)
    MEM_W(0X188, ctx->r2) = ctx->r10;
    // 0x802FEF48: lh          $t3, 0x86($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X86);
    // 0x802FEF4C: sb          $t3, 0x154($v0)
    MEM_B(0X154, ctx->r2) = ctx->r11;
    // 0x802FEF50: lh          $t4, 0x8A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X8A);
    // 0x802FEF54: sh          $t4, 0x15E($v0)
    MEM_H(0X15E, ctx->r2) = ctx->r12;
    // 0x802FEF58: jal         0x80128200
    // 0x802FEF5C: sw          $v0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r2;
    func_80128200(rdram, ctx);
        goto after_1;
    // 0x802FEF5C: sw          $v0, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r2;
    after_1:
    // 0x802FEF60: lw          $a0, 0x5C($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X5C);
    // 0x802FEF64: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x802FEF68: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802FEF6C: sh          $v0, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r2;
    // 0x802FEF70: lh          $t5, 0x7E($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X7E);
    // 0x802FEF74: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x802FEF78: addiu       $t0, $zero, 0xFF
    ctx->r8 = ADD32(0, 0XFF);
    // 0x802FEF7C: slti        $at, $t5, 0x14
    ctx->r1 = SIGNED(ctx->r13) < 0X14 ? 1 : 0;
    // 0x802FEF80: beq         $at, $zero, L_802FF01C
    if (ctx->r1 == 0) {
        // 0x802FEF84: addiu       $t1, $zero, 0x9B
        ctx->r9 = ADD32(0, 0X9B);
            goto L_802FF01C;
    }
    // 0x802FEF84: addiu       $t1, $zero, 0x9B
    ctx->r9 = ADD32(0, 0X9B);
    // 0x802FEF88: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FEF8C: addiu       $t0, $zero, 0xFF
    ctx->r8 = ADD32(0, 0XFF);
    // 0x802FEF90: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x802FEF94: sll         $a2, $v0, 2
    ctx->r6 = S32(ctx->r2 << 2);
    // 0x802FEF98: negu        $at, $v0
    ctx->r1 = SUB32(0, ctx->r2);
    // 0x802FEF9C: sll         $t8, $at, 4
    ctx->r24 = S32(ctx->r1 << 4);
    // 0x802FEFA0: subu        $a2, $a2, $v0
    ctx->r6 = SUB32(ctx->r6, ctx->r2);
    // 0x802FEFA4: sll         $a2, $a2, 3
    ctx->r6 = S32(ctx->r6 << 3);
    // 0x802FEFA8: subu        $t8, $t8, $at
    ctx->r24 = SUB32(ctx->r24, ctx->r1);
    // 0x802FEFAC: sll         $t8, $t8, 1
    ctx->r24 = S32(ctx->r24 << 1);
    // 0x802FEFB0: addu        $a2, $a2, $v0
    ctx->r6 = ADD32(ctx->r6, ctx->r2);
    // 0x802FEFB4: sra         $t6, $a2, 11
    ctx->r14 = S32(SIGNED(ctx->r6) >> 11);
    // 0x802FEFB8: sra         $t9, $t8, 11
    ctx->r25 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802FEFBC: addiu       $t2, $zero, 0xB9
    ctx->r10 = ADD32(0, 0XB9);
    // 0x802FEFC0: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x802FEFC4: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FEFC8: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    // 0x802FEFCC: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x802FEFD0: sw          $t2, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r10;
    // 0x802FEFD4: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802FEFD8: andi        $a2, $t6, 0xFF
    ctx->r6 = ctx->r14 & 0XFF;
    // 0x802FEFDC: sw          $t1, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r9;
    // 0x802FEFE0: sw          $t0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r8;
    // 0x802FEFE4: sw          $zero, 0x48($sp)
    MEM_W(0X48, ctx->r29) = 0;
    // 0x802FEFE8: sw          $zero, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = 0;
    // 0x802FEFEC: sw          $zero, 0x38($sp)
    MEM_W(0X38, ctx->r29) = 0;
    // 0x802FEFF0: sw          $zero, 0x34($sp)
    MEM_W(0X34, ctx->r29) = 0;
    // 0x802FEFF4: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x802FEFF8: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802FEFFC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF000: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF004: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FF008: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x802FF00C: jal         0x8039DDA4
    // 0x802FF010: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    add_regular_trail(rdram, ctx);
        goto after_2;
    // 0x802FF010: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_2:
    // 0x802FF014: b           L_802FF098
    // 0x802FF018: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
        goto L_802FF098;
    // 0x802FF018: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_802FF01C:
    // 0x802FF01C: lhu         $v0, 0x40($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X40);
    // 0x802FF020: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FF024: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FF028: sll         $a2, $v0, 2
    ctx->r6 = S32(ctx->r2 << 2);
    // 0x802FF02C: negu        $at, $v0
    ctx->r1 = SUB32(0, ctx->r2);
    // 0x802FF030: sll         $t7, $at, 4
    ctx->r15 = S32(ctx->r1 << 4);
    // 0x802FF034: subu        $a2, $a2, $v0
    ctx->r6 = SUB32(ctx->r6, ctx->r2);
    // 0x802FF038: sll         $a2, $a2, 3
    ctx->r6 = S32(ctx->r6 << 3);
    // 0x802FF03C: subu        $t7, $t7, $at
    ctx->r15 = SUB32(ctx->r15, ctx->r1);
    // 0x802FF040: sll         $t7, $t7, 1
    ctx->r15 = S32(ctx->r15 << 1);
    // 0x802FF044: addu        $a2, $a2, $v0
    ctx->r6 = ADD32(ctx->r6, ctx->r2);
    // 0x802FF048: sra         $t5, $a2, 11
    ctx->r13 = S32(SIGNED(ctx->r6) >> 11);
    // 0x802FF04C: sra         $t8, $t7, 11
    ctx->r24 = S32(SIGNED(ctx->r15) >> 11);
    // 0x802FF050: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    // 0x802FF054: andi        $a2, $t5, 0xFF
    ctx->r6 = ctx->r13 & 0XFF;
    // 0x802FF058: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    // 0x802FF05C: sw          $t2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r10;
    // 0x802FF060: sw          $zero, 0x48($sp)
    MEM_W(0X48, ctx->r29) = 0;
    // 0x802FF064: sw          $zero, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = 0;
    // 0x802FF068: sw          $zero, 0x38($sp)
    MEM_W(0X38, ctx->r29) = 0;
    // 0x802FF06C: sw          $zero, 0x34($sp)
    MEM_W(0X34, ctx->r29) = 0;
    // 0x802FF070: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x802FF074: sw          $t1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r9;
    // 0x802FF078: sw          $t0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r8;
    // 0x802FF07C: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802FF080: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF084: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FF088: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF08C: jal         0x8039DDA4
    // 0x802FF090: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    add_regular_trail(rdram, ctx);
        goto after_3;
    // 0x802FF090: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_3:
L_802FF094:
    // 0x802FF094: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_802FF098:
    // 0x802FF098: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x802FF09C: jr          $ra
    // 0x802FF0A0: nop

    return;
    // 0x802FF0A0: nop

;}
RECOMP_FUNC void spawn_temporary_object(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF0A4: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x802FF0A8: lw          $t6, 0x44($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X44);
    // 0x802FF0AC: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x802FF0B0: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x802FF0B4: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x802FF0B8: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x802FF0BC: sw          $a3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r7;
    // 0x802FF0C0: lh          $a1, 0x36($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X36);
    // 0x802FF0C4: lh          $a0, 0x32($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X32);
    // 0x802FF0C8: jal         0x80310EE4
    // 0x802FF0CC: lbu         $a2, 0x160($t6)
    ctx->r6 = MEM_BU(ctx->r14, 0X160);
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x802FF0CC: lbu         $a2, 0x160($t6)
    ctx->r6 = MEM_BU(ctx->r14, 0X160);
    after_0:
    // 0x802FF0D0: lh          $t9, 0x3E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X3E);
    // 0x802FF0D4: sra         $a3, $v0, 16
    ctx->r7 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802FF0D8: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x802FF0DC: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FF0E0: lbu         $a0, 0x4F($sp)
    ctx->r4 = MEM_BU(ctx->r29, 0X4F);
    // 0x802FF0E4: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x802FF0E8: lh          $a2, 0x36($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X36);
    // 0x802FF0EC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FF0F0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FF0F4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF0F8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802FF0FC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF100: jal         0x802C9564
    // 0x802FF104: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    static_2_802C9564(rdram, ctx);
        goto after_1;
    // 0x802FF104: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    after_1:
    // 0x802FF108: beq         $v0, $zero, L_802FF130
    if (ctx->r2 == 0) {
        // 0x802FF10C: addiu       $t0, $zero, 0x32
        ctx->r8 = ADD32(0, 0X32);
            goto L_802FF130;
    }
    // 0x802FF10C: addiu       $t0, $zero, 0x32
    ctx->r8 = ADD32(0, 0X32);
    // 0x802FF110: sb          $t0, 0x15C($v0)
    MEM_B(0X15C, ctx->r2) = ctx->r8;
    // 0x802FF114: lw          $t1, 0x44($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X44);
    // 0x802FF118: sw          $t1, 0x168($v0)
    MEM_W(0X168, ctx->r2) = ctx->r9;
    // 0x802FF11C: lbu         $t2, 0x43($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X43);
    // 0x802FF120: sb          $t2, 0x154($v0)
    MEM_B(0X154, ctx->r2) = ctx->r10;
    // 0x802FF124: lh          $t3, 0x4A($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X4A);
    // 0x802FF128: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x802FF12C: sh          $t4, 0x15E($v0)
    MEM_H(0X15E, ctx->r2) = ctx->r12;
L_802FF130:
    // 0x802FF130: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x802FF134: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    // 0x802FF138: jr          $ra
    // 0x802FF13C: nop

    return;
    // 0x802FF13C: nop

;}
RECOMP_FUNC void func_802FF140_7107F0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF140: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x802FF144: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802FF148: sh          $zero, 0x5330($at)
    MEM_H(0X5330, ctx->r1) = 0;
    // 0x802FF14C: addiu       $v1, $v1, 0x1BE8
    ctx->r3 = ADD32(ctx->r3, 0X1BE8);
    // 0x802FF150: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802FF154: addiu       $a0, $zero, 0x18
    ctx->r4 = ADD32(0, 0X18);
L_802FF158:
    // 0x802FF158: multu       $v0, $a0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FF15C: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x802FF160: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x802FF164: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FF168: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x802FF16C: mflo        $t6
    ctx->r14 = lo;
    // 0x802FF170: addu        $t7, $v1, $t6
    ctx->r15 = ADD32(ctx->r3, ctx->r14);
    // 0x802FF174: bne         $at, $zero, L_802FF158
    if (ctx->r1 != 0) {
        // 0x802FF178: sb          $zero, 0x0($t7)
        MEM_B(0X0, ctx->r15) = 0;
            goto L_802FF158;
    }
    // 0x802FF178: sb          $zero, 0x0($t7)
    MEM_B(0X0, ctx->r15) = 0;
    // 0x802FF17C: jr          $ra
    // 0x802FF180: nop

    return;
    // 0x802FF180: nop

;}
RECOMP_FUNC void func_802FF184_710834(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF184: lui         $t0, 0x803A
    ctx->r8 = S32(0X803A << 16);
    // 0x802FF188: addiu       $t0, $t0, 0x5330
    ctx->r8 = ADD32(ctx->r8, 0X5330);
    // 0x802FF18C: lh          $v0, 0x0($t0)
    ctx->r2 = MEM_H(ctx->r8, 0X0);
    // 0x802FF190: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x802FF194: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x802FF198: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x802FF19C: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x802FF1A0: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x802FF1A4: sll         $t3, $a3, 16
    ctx->r11 = S32(ctx->r7 << 16);
    // 0x802FF1A8: slti        $at, $v0, 0xA
    ctx->r1 = SIGNED(ctx->r2) < 0XA ? 1 : 0;
    // 0x802FF1AC: sra         $a3, $t3, 16
    ctx->r7 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802FF1B0: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FF1B4: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FF1B8: beq         $at, $zero, L_802FF254
    if (ctx->r1 == 0) {
        // 0x802FF1BC: sw          $a0, 0x0($sp)
        MEM_W(0X0, ctx->r29) = ctx->r4;
            goto L_802FF254;
    }
    // 0x802FF1BC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x802FF1C0: lui         $t1, 0x803E
    ctx->r9 = S32(0X803E << 16);
    // 0x802FF1C4: addiu       $t1, $t1, 0x1BE8
    ctx->r9 = ADD32(ctx->r9, 0X1BE8);
    // 0x802FF1C8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x802FF1CC: addiu       $t2, $zero, 0x18
    ctx->r10 = ADD32(0, 0X18);
L_802FF1D0:
    // 0x802FF1D0: multu       $v1, $t2
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FF1D4: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x802FF1D8: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x802FF1DC: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FF1E0: slti        $at, $v1, 0xA
    ctx->r1 = SIGNED(ctx->r3) < 0XA ? 1 : 0;
    // 0x802FF1E4: mflo        $t5
    ctx->r13 = lo;
    // 0x802FF1E8: addu        $a0, $t1, $t5
    ctx->r4 = ADD32(ctx->r9, ctx->r13);
    // 0x802FF1EC: lbu         $t6, 0x0($a0)
    ctx->r14 = MEM_BU(ctx->r4, 0X0);
    // 0x802FF1F0: bne         $t6, $zero, L_802FF24C
    if (ctx->r14 != 0) {
        // 0x802FF1F4: nop
    
            goto L_802FF24C;
    }
    // 0x802FF1F4: nop

    // 0x802FF1F8: lh          $t7, 0x12($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X12);
    // 0x802FF1FC: lh          $t8, 0x1E($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X1E);
    // 0x802FF200: lh          $t9, 0x22($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X22);
    // 0x802FF204: lh          $t3, 0x26($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X26);
    // 0x802FF208: lw          $t4, 0x0($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X0);
    // 0x802FF20C: lh          $t5, 0x16($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X16);
    // 0x802FF210: lh          $t6, 0x1A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X1A);
    // 0x802FF214: sh          $t7, 0x6($a0)
    MEM_H(0X6, ctx->r4) = ctx->r15;
    // 0x802FF218: sh          $a2, 0x2($a0)
    MEM_H(0X2, ctx->r4) = ctx->r6;
    // 0x802FF21C: sh          $a3, 0x4($a0)
    MEM_H(0X4, ctx->r4) = ctx->r7;
    // 0x802FF220: sb          $a1, 0x0($a0)
    MEM_B(0X0, ctx->r4) = ctx->r5;
    // 0x802FF224: sb          $zero, 0x1($a0)
    MEM_B(0X1, ctx->r4) = 0;
    // 0x802FF228: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x802FF22C: sh          $t8, 0xC($a0)
    MEM_H(0XC, ctx->r4) = ctx->r24;
    // 0x802FF230: sh          $t9, 0xE($a0)
    MEM_H(0XE, ctx->r4) = ctx->r25;
    // 0x802FF234: sh          $t3, 0x10($a0)
    MEM_H(0X10, ctx->r4) = ctx->r11;
    // 0x802FF238: sw          $t4, 0x14($a0)
    MEM_W(0X14, ctx->r4) = ctx->r12;
    // 0x802FF23C: sh          $t5, 0xA($a0)
    MEM_H(0XA, ctx->r4) = ctx->r13;
    // 0x802FF240: sh          $t6, 0x8($a0)
    MEM_H(0X8, ctx->r4) = ctx->r14;
    // 0x802FF244: jr          $ra
    // 0x802FF248: sh          $t7, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r15;
    return;
    // 0x802FF248: sh          $t7, 0x0($t0)
    MEM_H(0X0, ctx->r8) = ctx->r15;
L_802FF24C:
    // 0x802FF24C: bne         $at, $zero, L_802FF1D0
    if (ctx->r1 != 0) {
        // 0x802FF250: nop
    
            goto L_802FF1D0;
    }
    // 0x802FF250: nop

L_802FF254:
    // 0x802FF254: jr          $ra
    // 0x802FF258: nop

    return;
    // 0x802FF258: nop

;}
RECOMP_FUNC void func_802FF25C_71090C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF25C: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802FF260: sw          $s7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r23;
    // 0x802FF264: sw          $s6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r22;
    // 0x802FF268: sw          $s2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r18;
    // 0x802FF26C: sw          $fp, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r30;
    // 0x802FF270: sw          $s4, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r20;
    // 0x802FF274: lui         $s2, 0x801E
    ctx->r18 = S32(0X801E << 16);
    // 0x802FF278: lui         $s6, 0x8020
    ctx->r22 = S32(0X8020 << 16);
    // 0x802FF27C: lui         $s7, 0x3
    ctx->r23 = S32(0X3 << 16);
    // 0x802FF280: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802FF284: sw          $s5, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r21;
    // 0x802FF288: sw          $s3, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r19;
    // 0x802FF28C: sw          $s1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r17;
    // 0x802FF290: sw          $s0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r16;
    // 0x802FF294: ori         $s7, $s7, 0x8000
    ctx->r23 = ctx->r23 | 0X8000;
    // 0x802FF298: addiu       $s6, $s6, 0x4278
    ctx->r22 = ADD32(ctx->r22, 0X4278);
    // 0x802FF29C: addiu       $s2, $s2, -0x6170
    ctx->r18 = ADD32(ctx->r18, -0X6170);
    // 0x802FF2A0: or          $s4, $zero, $zero
    ctx->r20 = 0 | 0;
    // 0x802FF2A4: lui         $fp, 0x600
    ctx->r30 = S32(0X600 << 16);
    // 0x802FF2A8: sll         $t6, $s4, 2
    ctx->r14 = S32(ctx->r20 << 2);
L_802FF2AC:
    // 0x802FF2AC: subu        $t6, $t6, $s4
    ctx->r14 = SUB32(ctx->r14, ctx->r20);
    // 0x802FF2B0: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x802FF2B4: addiu       $t7, $t7, 0x1BE8
    ctx->r15 = ADD32(ctx->r15, 0X1BE8);
    // 0x802FF2B8: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x802FF2BC: addu        $s0, $t6, $t7
    ctx->r16 = ADD32(ctx->r14, ctx->r15);
    // 0x802FF2C0: lbu         $t8, 0x0($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X0);
    // 0x802FF2C4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FF2C8: lui         $s3, 0x100
    ctx->r19 = S32(0X100 << 16);
    // 0x802FF2CC: bne         $t8, $at, L_802FF4F8
    if (ctx->r24 != ctx->r1) {
        // 0x802FF2D0: addiu       $s3, $s3, 0x4970
        ctx->r19 = ADD32(ctx->r19, 0X4970);
            goto L_802FF4F8;
    }
    // 0x802FF2D0: addiu       $s3, $s3, 0x4970
    ctx->r19 = ADD32(ctx->r19, 0X4970);
    // 0x802FF2D4: lbu         $t9, 0x1($s0)
    ctx->r25 = MEM_BU(ctx->r16, 0X1);
    // 0x802FF2D8: lh          $t1, 0xC($s0)
    ctx->r9 = MEM_H(ctx->r16, 0XC);
    // 0x802FF2DC: addiu       $at, $zero, 0x64
    ctx->r1 = ADD32(0, 0X64);
    // 0x802FF2E0: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x802FF2E4: multu       $t9, $t1
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x802FF2E8: lh          $a1, 0x2($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2);
    // 0x802FF2EC: addu        $t5, $s1, $s7
    ctx->r13 = ADD32(ctx->r17, ctx->r23);
    // 0x802FF2F0: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x802FF2F4: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FF2F8: lh          $a3, 0x6($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X6);
    // 0x802FF2FC: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x802FF300: lui         $s5, 0x102
    ctx->r21 = S32(0X102 << 16);
    // 0x802FF304: addu        $a0, $s1, $t7
    ctx->r4 = ADD32(ctx->r17, ctx->r15);
    // 0x802FF308: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x802FF30C: mflo        $v0
    ctx->r2 = lo;
    // 0x802FF310: sll         $t2, $v0, 16
    ctx->r10 = S32(ctx->r2 << 16);
    // 0x802FF314: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x802FF318: div         $zero, $t2, $at
    lo = S32(S64(S32(ctx->r10)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r10)) % S64(S32(ctx->r1)));
    // 0x802FF31C: mflo        $t3
    ctx->r11 = lo;
    // 0x802FF320: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    // 0x802FF324: lh          $t3, 0xA($s0)
    ctx->r11 = MEM_H(ctx->r16, 0XA);
    // 0x802FF328: lh          $t2, 0x8($s0)
    ctx->r10 = MEM_H(ctx->r16, 0X8);
    // 0x802FF32C: sll         $t1, $a3, 16
    ctx->r9 = S32(ctx->r7 << 16);
    // 0x802FF330: addiu       $s5, $s5, -0x5000
    ctx->r21 = ADD32(ctx->r21, -0X5000);
    // 0x802FF334: bgez        $v0, L_802FF344
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF338: sra         $t4, $v0, 4
        ctx->r12 = S32(SIGNED(ctx->r2) >> 4);
            goto L_802FF344;
    }
    // 0x802FF338: sra         $t4, $v0, 4
    ctx->r12 = S32(SIGNED(ctx->r2) >> 4);
    // 0x802FF33C: addiu       $at, $v0, 0xF
    ctx->r1 = ADD32(ctx->r2, 0XF);
    // 0x802FF340: sra         $t4, $at, 4
    ctx->r12 = S32(SIGNED(ctx->r1) >> 4);
L_802FF344:
    // 0x802FF344: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x802FF348: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x802FF34C: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x802FF350: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x802FF354: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x802FF358: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x802FF35C: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x802FF360: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x802FF364: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x802FF368: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x802FF36C: jal         0x80125FE0
    // 0x802FF370: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    func_80125FE0(rdram, ctx);
        goto after_0;
    // 0x802FF370: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    after_0:
    // 0x802FF374: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x802FF378: lui         $t5, 0x104
    ctx->r13 = S32(0X104 << 16);
    // 0x802FF37C: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x802FF380: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x802FF384: sw          $t4, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r12;
    // 0x802FF388: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x802FF38C: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x802FF390: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x802FF394: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x802FF398: addu        $t6, $s1, $s7
    ctx->r14 = ADD32(ctx->r17, ctx->r23);
    // 0x802FF39C: lw          $t7, 0x918($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X918);
    // 0x802FF3A0: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x802FF3A4: sll         $t8, $t7, 6
    ctx->r24 = S32(ctx->r15 << 6);
    // 0x802FF3A8: addu        $t9, $s1, $t8
    ctx->r25 = ADD32(ctx->r17, ctx->r24);
    // 0x802FF3AC: addu        $t1, $t9, $at
    ctx->r9 = ADD32(ctx->r25, ctx->r1);
    // 0x802FF3B0: sw          $t1, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r9;
    // 0x802FF3B4: lw          $s1, 0x0($s6)
    ctx->r17 = MEM_W(ctx->r22, 0X0);
    // 0x802FF3B8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x802FF3BC: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x802FF3C0: addu        $t2, $s1, $s7
    ctx->r10 = ADD32(ctx->r17, ctx->r23);
    // 0x802FF3C4: lw          $t3, 0x918($t2)
    ctx->r11 = MEM_W(ctx->r10, 0X918);
    // 0x802FF3C8: addu        $at, $at, $s1
    ctx->r1 = ADD32(ctx->r1, ctx->r17);
    // 0x802FF3CC: addiu       $t2, $zero, 0x100
    ctx->r10 = ADD32(0, 0X100);
    // 0x802FF3D0: addiu       $t4, $t3, 0x1
    ctx->r12 = ADD32(ctx->r11, 0X1);
    // 0x802FF3D4: sw          $t4, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r12;
    // 0x802FF3D8: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x802FF3DC: addiu       $t4, $zero, 0x80
    ctx->r12 = ADD32(0, 0X80);
    // 0x802FF3E0: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x802FF3E4: sw          $t5, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r13;
    // 0x802FF3E8: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802FF3EC: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x802FF3F0: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x802FF3F4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x802FF3F8: sw          $t7, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r15;
    // 0x802FF3FC: sw          $s3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r19;
    // 0x802FF400: sw          $fp, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r30;
    // 0x802FF404: lw          $a3, 0x0($s2)
    ctx->r7 = MEM_W(ctx->r18, 0X0);
    // 0x802FF408: addiu       $t8, $a3, 0x8
    ctx->r24 = ADD32(ctx->r7, 0X8);
    // 0x802FF40C: sw          $t8, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r24;
    // 0x802FF410: sw          $t9, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r25;
    // 0x802FF414: lbu         $a2, 0x1($s0)
    ctx->r6 = MEM_BU(ctx->r16, 0X1);
    // 0x802FF418: sll         $t1, $a2, 4
    ctx->r9 = S32(ctx->r6 << 4);
    // 0x802FF41C: subu        $t0, $t2, $t1
    ctx->r8 = SUB32(ctx->r10, ctx->r9);
    // 0x802FF420: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x802FF424: bne         $at, $zero, L_802FF434
    if (ctx->r1 != 0) {
        // 0x802FF428: sll         $t3, $a2, 3
        ctx->r11 = S32(ctx->r6 << 3);
            goto L_802FF434;
    }
    // 0x802FF428: sll         $t3, $a2, 3
    ctx->r11 = S32(ctx->r6 << 3);
    // 0x802FF42C: b           L_802FF438
    // 0x802FF430: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
        goto L_802FF438;
    // 0x802FF430: addiu       $a1, $zero, 0xFF
    ctx->r5 = ADD32(0, 0XFF);
L_802FF434:
    // 0x802FF434: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
L_802FF438:
    // 0x802FF438: subu        $t5, $t4, $t3
    ctx->r13 = SUB32(ctx->r12, ctx->r11);
    // 0x802FF43C: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x802FF440: lui         $at, 0xFF00
    ctx->r1 = S32(0XFF00 << 16);
    // 0x802FF444: andi        $t8, $a1, 0xFF
    ctx->r24 = ctx->r5 & 0XFF;
    // 0x802FF448: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x802FF44C: or          $t7, $t6, $at
    ctx->r15 = ctx->r14 | ctx->r1;
    // 0x802FF450: or          $t2, $t7, $t9
    ctx->r10 = ctx->r15 | ctx->r25;
    // 0x802FF454: sw          $t2, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r10;
    // 0x802FF458: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x802FF45C: lui         $t3, 0xBD00
    ctx->r11 = S32(0XBD00 << 16);
    // 0x802FF460: addiu       $t1, $v0, 0x8
    ctx->r9 = ADD32(ctx->r2, 0X8);
    // 0x802FF464: sw          $t1, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r9;
    // 0x802FF468: sw          $s5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r21;
    // 0x802FF46C: sw          $fp, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r30;
    // 0x802FF470: lw          $v0, 0x0($s2)
    ctx->r2 = MEM_W(ctx->r18, 0X0);
    // 0x802FF474: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x802FF478: sw          $t4, 0x0($s2)
    MEM_W(0X0, ctx->r18) = ctx->r12;
    // 0x802FF47C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x802FF480: sw          $t3, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r11;
    // 0x802FF484: lbu         $t5, 0x1($s0)
    ctx->r13 = MEM_BU(ctx->r16, 0X1);
    // 0x802FF488: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x802FF48C: bne         $t5, $zero, L_802FF49C
    if (ctx->r13 != 0) {
        // 0x802FF490: nop
    
            goto L_802FF49C;
    }
    // 0x802FF490: nop

    // 0x802FF494: b           L_802FF49C
    // 0x802FF498: lh          $v0, 0xE($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XE);
        goto L_802FF49C;
    // 0x802FF498: lh          $v0, 0xE($s0)
    ctx->r2 = MEM_H(ctx->r16, 0XE);
L_802FF49C:
    // 0x802FF49C: lh          $t6, 0xC($s0)
    ctx->r14 = MEM_H(ctx->r16, 0XC);
    // 0x802FF4A0: lh          $t8, 0x10($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X10);
    // 0x802FF4A4: lw          $a0, 0x14($s0)
    ctx->r4 = MEM_W(ctx->r16, 0X14);
    // 0x802FF4A8: lh          $a1, 0x2($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X2);
    // 0x802FF4AC: lh          $a2, 0x4($s0)
    ctx->r6 = MEM_H(ctx->r16, 0X4);
    // 0x802FF4B0: lh          $a3, 0x6($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X6);
    // 0x802FF4B4: sw          $v0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r2;
    // 0x802FF4B8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FF4BC: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x802FF4C0: jal         0x802F7940
    // 0x802FF4C4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    func_802F7940_708FF0(rdram, ctx);
        goto after_1;
    // 0x802FF4C4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    after_1:
    // 0x802FF4C8: lbu         $t7, 0x1($s0)
    ctx->r15 = MEM_BU(ctx->r16, 0X1);
    // 0x802FF4CC: lui         $t1, 0x803A
    ctx->r9 = S32(0X803A << 16);
    // 0x802FF4D0: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x802FF4D4: andi        $t2, $t9, 0xFF
    ctx->r10 = ctx->r25 & 0XFF;
    // 0x802FF4D8: slti        $at, $t2, 0x10
    ctx->r1 = SIGNED(ctx->r10) < 0X10 ? 1 : 0;
    // 0x802FF4DC: bne         $at, $zero, L_802FF4F8
    if (ctx->r1 != 0) {
        // 0x802FF4E0: sb          $t9, 0x1($s0)
        MEM_B(0X1, ctx->r16) = ctx->r25;
            goto L_802FF4F8;
    }
    // 0x802FF4E0: sb          $t9, 0x1($s0)
    MEM_B(0X1, ctx->r16) = ctx->r25;
    // 0x802FF4E4: sb          $zero, 0x0($s0)
    MEM_B(0X0, ctx->r16) = 0;
    // 0x802FF4E8: lh          $t1, 0x5330($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X5330);
    // 0x802FF4EC: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x802FF4F0: addiu       $t4, $t1, -0x1
    ctx->r12 = ADD32(ctx->r9, -0X1);
    // 0x802FF4F4: sh          $t4, 0x5330($at)
    MEM_H(0X5330, ctx->r1) = ctx->r12;
L_802FF4F8:
    // 0x802FF4F8: addiu       $s4, $s4, 0x1
    ctx->r20 = ADD32(ctx->r20, 0X1);
    // 0x802FF4FC: sll         $t3, $s4, 16
    ctx->r11 = S32(ctx->r20 << 16);
    // 0x802FF500: sra         $s4, $t3, 16
    ctx->r20 = S32(SIGNED(ctx->r11) >> 16);
    // 0x802FF504: slti        $at, $s4, 0xA
    ctx->r1 = SIGNED(ctx->r20) < 0XA ? 1 : 0;
    // 0x802FF508: bnel        $at, $zero, L_802FF2AC
    if (ctx->r1 != 0) {
        // 0x802FF50C: sll         $t6, $s4, 2
        ctx->r14 = S32(ctx->r20 << 2);
            goto L_802FF2AC;
    }
    goto skip_0;
    // 0x802FF50C: sll         $t6, $s4, 2
    ctx->r14 = S32(ctx->r20 << 2);
    skip_0:
    // 0x802FF510: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x802FF514: lw          $s0, 0x30($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X30);
    // 0x802FF518: lw          $s1, 0x34($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X34);
    // 0x802FF51C: lw          $s2, 0x38($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X38);
    // 0x802FF520: lw          $s3, 0x3C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X3C);
    // 0x802FF524: lw          $s4, 0x40($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X40);
    // 0x802FF528: lw          $s5, 0x44($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X44);
    // 0x802FF52C: lw          $s6, 0x48($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X48);
    // 0x802FF530: lw          $s7, 0x4C($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X4C);
    // 0x802FF534: lw          $fp, 0x50($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X50);
    // 0x802FF538: jr          $ra
    // 0x802FF53C: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    return;
    // 0x802FF53C: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
;}
RECOMP_FUNC void func_802FF540_710BF0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF540: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802FF544: addiu       $t3, $t3, 0x52D4
    ctx->r11 = ADD32(ctx->r11, 0X52D4);
    // 0x802FF548: lh          $v0, 0x0($t3)
    ctx->r2 = MEM_H(ctx->r11, 0X0);
    // 0x802FF54C: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x802FF550: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x802FF554: beq         $v0, $zero, L_802FF564
    if (ctx->r2 == 0) {
        // 0x802FF558: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_802FF564;
    }
    // 0x802FF558: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x802FF55C: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x802FF560: sh          $t6, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r14;
L_802FF564:
    // 0x802FF564: lbu         $t7, -0x71A9($t7)
    ctx->r15 = MEM_BU(ctx->r15, -0X71A9);
    // 0x802FF568: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802FF56C: addiu       $t2, $zero, 0x100
    ctx->r10 = ADD32(0, 0X100);
    // 0x802FF570: beql        $t7, $zero, L_802FF664
    if (ctx->r15 == 0) {
        // 0x802FF574: lh          $a3, 0x8($a0)
        ctx->r7 = MEM_H(ctx->r4, 0X8);
            goto L_802FF664;
    }
    goto skip_0;
    // 0x802FF574: lh          $a3, 0x8($a0)
    ctx->r7 = MEM_H(ctx->r4, 0X8);
    skip_0:
    // 0x802FF578: lwc1        $f4, 0x2C48($at)
    ctx->f4.u32l = MEM_W(ctx->r1, 0X2C48);
    // 0x802FF57C: lh          $a3, 0x8($a0)
    ctx->r7 = MEM_H(ctx->r4, 0X8);
    // 0x802FF580: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802FF584: trunc.w.s   $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.u32l = TRUNC_W_S(ctx->f4.fl);
    // 0x802FF588: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
    // 0x802FF58C: nop

    // 0x802FF590: sll         $t4, $t9, 16
    ctx->r12 = S32(ctx->r25 << 16);
    // 0x802FF594: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x802FF598: subu        $v0, $a3, $t5
    ctx->r2 = SUB32(ctx->r7, ctx->r13);
    // 0x802FF59C: bgez        $v0, L_802FF5AC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF5A0: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_802FF5AC;
    }
    // 0x802FF5A0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x802FF5A4: b           L_802FF5AC
    // 0x802FF5A8: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_802FF5AC;
    // 0x802FF5A8: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_802FF5AC:
    // 0x802FF5AC: lwc1        $f8, 0x2C44($at)
    ctx->f8.u32l = MEM_W(ctx->r1, 0X2C44);
    // 0x802FF5B0: lh          $t0, 0x4($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X4);
    // 0x802FF5B4: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x802FF5B8: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802FF5BC: mfc1        $t7, $f10
    ctx->r15 = (int32_t)ctx->f10.u32l;
    // 0x802FF5C0: nop

    // 0x802FF5C4: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x802FF5C8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x802FF5CC: subu        $v0, $t0, $t9
    ctx->r2 = SUB32(ctx->r8, ctx->r25);
    // 0x802FF5D0: bgez        $v0, L_802FF5E0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF5D4: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802FF5E0;
    }
    // 0x802FF5D4: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802FF5D8: b           L_802FF5E0
    // 0x802FF5DC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802FF5E0;
    // 0x802FF5DC: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802FF5E0:
    // 0x802FF5E0: lwc1        $f16, 0x2C4C($at)
    ctx->f16.u32l = MEM_W(ctx->r1, 0X2C4C);
    // 0x802FF5E4: lh          $t1, 0xC($a0)
    ctx->r9 = MEM_H(ctx->r4, 0XC);
    // 0x802FF5E8: trunc.w.s   $f18, $f16
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    ctx->f18.u32l = TRUNC_W_S(ctx->f16.fl);
    // 0x802FF5EC: mfc1        $t5, $f18
    ctx->r13 = (int32_t)ctx->f18.u32l;
    // 0x802FF5F0: nop

    // 0x802FF5F4: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x802FF5F8: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x802FF5FC: subu        $v0, $t1, $t7
    ctx->r2 = SUB32(ctx->r9, ctx->r15);
    // 0x802FF600: bgez        $v0, L_802FF610
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF604: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802FF610;
    }
    // 0x802FF604: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802FF608: b           L_802FF610
    // 0x802FF60C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802FF610;
    // 0x802FF60C: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802FF610:
    // 0x802FF610: addu        $t8, $v1, $a1
    ctx->r24 = ADD32(ctx->r3, ctx->r5);
    // 0x802FF614: addu        $v0, $t8, $a2
    ctx->r2 = ADD32(ctx->r24, ctx->r6);
    // 0x802FF618: slti        $at, $v0, 0x200
    ctx->r1 = SIGNED(ctx->r2) < 0X200 ? 1 : 0;
    // 0x802FF61C: beql        $at, $zero, L_802FF630
    if (ctx->r1 == 0) {
        // 0x802FF620: slti        $at, $v0, 0x1400
        ctx->r1 = SIGNED(ctx->r2) < 0X1400 ? 1 : 0;
            goto L_802FF630;
    }
    goto skip_1;
    // 0x802FF620: slti        $at, $v0, 0x1400
    ctx->r1 = SIGNED(ctx->r2) < 0X1400 ? 1 : 0;
    skip_1:
    // 0x802FF624: b           L_802FF66C
    // 0x802FF628: addiu       $t2, $zero, 0x100
    ctx->r10 = ADD32(0, 0X100);
        goto L_802FF66C;
    // 0x802FF628: addiu       $t2, $zero, 0x100
    ctx->r10 = ADD32(0, 0X100);
    // 0x802FF62C: slti        $at, $v0, 0x1400
    ctx->r1 = SIGNED(ctx->r2) < 0X1400 ? 1 : 0;
L_802FF630:
    // 0x802FF630: beq         $at, $zero, L_802FF658
    if (ctx->r1 == 0) {
        // 0x802FF634: sll         $t9, $v0, 8
        ctx->r25 = S32(ctx->r2 << 8);
            goto L_802FF658;
    }
    // 0x802FF634: sll         $t9, $v0, 8
    ctx->r25 = S32(ctx->r2 << 8);
    // 0x802FF638: lui         $at, 0xFFFE
    ctx->r1 = S32(0XFFFE << 16);
    // 0x802FF63C: addu        $t4, $t9, $at
    ctx->r12 = ADD32(ctx->r25, ctx->r1);
    // 0x802FF640: addiu       $at, $zero, 0x1200
    ctx->r1 = ADD32(0, 0X1200);
    // 0x802FF644: div         $zero, $t4, $at
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r1)));
    // 0x802FF648: mflo        $t5
    ctx->r13 = lo;
    // 0x802FF64C: addiu       $t6, $zero, 0x100
    ctx->r14 = ADD32(0, 0X100);
    // 0x802FF650: b           L_802FF66C
    // 0x802FF654: subu        $t2, $t6, $t5
    ctx->r10 = SUB32(ctx->r14, ctx->r13);
        goto L_802FF66C;
    // 0x802FF654: subu        $t2, $t6, $t5
    ctx->r10 = SUB32(ctx->r14, ctx->r13);
L_802FF658:
    // 0x802FF658: b           L_802FF66C
    // 0x802FF65C: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
        goto L_802FF66C;
    // 0x802FF65C: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x802FF660: lh          $a3, 0x8($a0)
    ctx->r7 = MEM_H(ctx->r4, 0X8);
L_802FF664:
    // 0x802FF664: lh          $t0, 0x4($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X4);
    // 0x802FF668: lh          $t1, 0xC($a0)
    ctx->r9 = MEM_H(ctx->r4, 0XC);
L_802FF66C:
    // 0x802FF66C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x802FF670: lh          $t7, 0x5534($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5534);
    // 0x802FF674: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x802FF678: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x802FF67C: addu        $v1, $v1, $t8
    ctx->r3 = ADD32(ctx->r3, ctx->r24);
    // 0x802FF680: lw          $v1, -0x2274($v1)
    ctx->r3 = MEM_W(ctx->r3, -0X2274);
    // 0x802FF684: lh          $t9, 0x8($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X8);
    // 0x802FF688: subu        $v0, $a3, $t9
    ctx->r2 = SUB32(ctx->r7, ctx->r25);
    // 0x802FF68C: bgez        $v0, L_802FF69C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF690: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_802FF69C;
    }
    // 0x802FF690: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x802FF694: b           L_802FF69C
    // 0x802FF698: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_802FF69C;
    // 0x802FF698: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_802FF69C:
    // 0x802FF69C: lh          $t4, 0x4($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X4);
    // 0x802FF6A0: subu        $v0, $t0, $t4
    ctx->r2 = SUB32(ctx->r8, ctx->r12);
    // 0x802FF6A4: bgez        $v0, L_802FF6B4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF6A8: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_802FF6B4;
    }
    // 0x802FF6A8: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x802FF6AC: b           L_802FF6B4
    // 0x802FF6B0: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
        goto L_802FF6B4;
    // 0x802FF6B0: negu        $a1, $v0
    ctx->r5 = SUB32(0, ctx->r2);
L_802FF6B4:
    // 0x802FF6B4: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x802FF6B8: subu        $v0, $t1, $t6
    ctx->r2 = SUB32(ctx->r9, ctx->r14);
    // 0x802FF6BC: bgez        $v0, L_802FF6CC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x802FF6C0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_802FF6CC;
    }
    // 0x802FF6C0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x802FF6C4: b           L_802FF6CC
    // 0x802FF6C8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_802FF6CC;
    // 0x802FF6C8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_802FF6CC:
    // 0x802FF6CC: addu        $t5, $v1, $a1
    ctx->r13 = ADD32(ctx->r3, ctx->r5);
    // 0x802FF6D0: addu        $v0, $t5, $a2
    ctx->r2 = ADD32(ctx->r13, ctx->r6);
    // 0x802FF6D4: slti        $at, $v0, 0xC0
    ctx->r1 = SIGNED(ctx->r2) < 0XC0 ? 1 : 0;
    // 0x802FF6D8: beq         $at, $zero, L_802FF778
    if (ctx->r1 == 0) {
        // 0x802FF6DC: nop
    
            goto L_802FF778;
    }
    // 0x802FF6DC: nop

    // 0x802FF6E0: lh          $t7, 0x0($t3)
    ctx->r15 = MEM_H(ctx->r11, 0X0);
    // 0x802FF6E4: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x802FF6E8: bne         $t7, $zero, L_802FF778
    if (ctx->r15 != 0) {
        // 0x802FF6EC: nop
    
            goto L_802FF778;
    }
    // 0x802FF6EC: nop

    // 0x802FF6F0: lbu         $t8, 0x52B0($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X52B0);
    // 0x802FF6F4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x802FF6F8: slti        $at, $v0, 0x80
    ctx->r1 = SIGNED(ctx->r2) < 0X80 ? 1 : 0;
    // 0x802FF6FC: bne         $t8, $zero, L_802FF710
    if (ctx->r24 != 0) {
        // 0x802FF700: nop
    
            goto L_802FF710;
    }
    // 0x802FF700: nop

    // 0x802FF704: lh          $t9, 0x2D24($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2D24);
    // 0x802FF708: beq         $t9, $zero, L_802FF778
    if (ctx->r25 == 0) {
        // 0x802FF70C: nop
    
            goto L_802FF778;
    }
    // 0x802FF70C: nop

L_802FF710:
    // 0x802FF710: beq         $at, $zero, L_802FF748
    if (ctx->r1 == 0) {
        // 0x802FF714: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_802FF748;
    }
    // 0x802FF714: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FF718: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x802FF71C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x802FF720: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x802FF724: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x802FF728: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
    // 0x802FF72C: addiu       $a3, $zero, 0x28
    ctx->r7 = ADD32(0, 0X28);
    // 0x802FF730: jal         0x801373CC
    // 0x802FF734: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    do_rumble(rdram, ctx);
        goto after_0;
    // 0x802FF734: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    after_0:
    // 0x802FF738: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802FF73C: addiu       $t3, $t3, 0x52D4
    ctx->r11 = ADD32(ctx->r11, 0X52D4);
    // 0x802FF740: b           L_802FF770
    // 0x802FF744: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
        goto L_802FF770;
    // 0x802FF744: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
L_802FF748:
    // 0x802FF748: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x802FF74C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x802FF750: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FF754: addiu       $a2, $zero, 0x28
    ctx->r6 = ADD32(0, 0X28);
    // 0x802FF758: addiu       $a3, $zero, 0x28
    ctx->r7 = ADD32(0, 0X28);
    // 0x802FF75C: jal         0x801373CC
    // 0x802FF760: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    do_rumble(rdram, ctx);
        goto after_1;
    // 0x802FF760: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    after_1:
    // 0x802FF764: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x802FF768: addiu       $t3, $t3, 0x52D4
    ctx->r11 = ADD32(ctx->r11, 0X52D4);
    // 0x802FF76C: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
L_802FF770:
    // 0x802FF770: addiu       $t5, $zero, 0x5
    ctx->r13 = ADD32(0, 0X5);
    // 0x802FF774: sh          $t5, 0x0($t3)
    MEM_H(0X0, ctx->r11) = ctx->r13;
L_802FF778:
    // 0x802FF778: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x802FF77C: addiu       $v1, $v1, 0x1BE0
    ctx->r3 = ADD32(ctx->r3, 0X1BE0);
    // 0x802FF780: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x802FF784: slt         $at, $v0, $t2
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x802FF788: beql        $at, $zero, L_802FF79C
    if (ctx->r1 == 0) {
        // 0x802FF78C: mtc1        $v0, $f4
        ctx->f4.u32l = ctx->r2;
            goto L_802FF79C;
    }
    goto skip_2;
    // 0x802FF78C: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
    skip_2:
    // 0x802FF790: sw          $t2, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r10;
    // 0x802FF794: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
    // 0x802FF798: mtc1        $v0, $f4
    ctx->f4.u32l = ctx->r2;
L_802FF79C:
    // 0x802FF79C: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802FF7A0: mtc1        $at, $f8
    ctx->f8.u32l = ctx->r1;
    // 0x802FF7A4: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FF7A8: lui         $v1, 0x8028
    ctx->r3 = S32(0X8028 << 16);
    // 0x802FF7AC: lui         $at, 0x8015
    ctx->r1 = S32(0X8015 << 16);
    // 0x802FF7B0: addiu       $v1, $v1, 0x645A
    ctx->r3 = ADD32(ctx->r3, 0X645A);
    // 0x802FF7B4: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x802FF7B8: div.s       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f8.fl); 
    ctx->f10.fl = DIV_S(ctx->f6.fl, ctx->f8.fl);
    // 0x802FF7BC: swc1        $f10, 0x517C($at)
    MEM_W(0X517C, ctx->r1) = ctx->f10.u32l;
    // 0x802FF7C0: lh          $t7, 0x0($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X0);
    // 0x802FF7C4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x802FF7C8: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x802FF7CC: jr          $ra
    // 0x802FF7D0: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
    return;
    // 0x802FF7D0: sh          $t8, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r24;
;}
RECOMP_FUNC void func_802FF7D4_710E84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF7D4: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FF7D8: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FF7DC: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x802FF7E0: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802FF7E4: lh          $a1, 0x8($t6)
    ctx->r5 = MEM_H(ctx->r14, 0X8);
    // 0x802FF7E8: lh          $a2, 0xC($t6)
    ctx->r6 = MEM_H(ctx->r14, 0XC);
    // 0x802FF7EC: lh          $a0, 0x4($a0)
    ctx->r4 = MEM_H(ctx->r4, 0X4);
    // 0x802FF7F0: addiu       $t7, $zero, 0x14
    ctx->r15 = ADD32(0, 0X14);
    // 0x802FF7F4: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x802FF7F8: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802FF7FC: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802FF800: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF804: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF808: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FF80C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FF810: jal         0x802D5F4C
    // 0x802FF814: addiu       $a3, $zero, 0x7C
    ctx->r7 = ADD32(0, 0X7C);
    create_particle_effect(rdram, ctx);
        goto after_0;
    // 0x802FF814: addiu       $a3, $zero, 0x7C
    ctx->r7 = ADD32(0, 0X7C);
    after_0:
    // 0x802FF818: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FF81C: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FF820: jr          $ra
    // 0x802FF824: nop

    return;
    // 0x802FF824: nop

;}
RECOMP_FUNC void func_802FF828_710ED8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FF828: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802FF82C: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802FF830: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x802FF834: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x802FF838: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802FF83C: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x802FF840: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802FF844: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802FF848: sra         $t1, $t9, 6
    ctx->r9 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802FF84C: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x802FF850: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FF854: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x802FF858: addiu       $t4, $t4, 0x740
    ctx->r12 = ADD32(ctx->r12, 0X740);
    // 0x802FF85C: addu        $v0, $t3, $t4
    ctx->r2 = ADD32(ctx->r11, ctx->r12);
    // 0x802FF860: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FF864: lbu         $a1, 0x6($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X6);
    // 0x802FF868: or          $t0, $v1, $zero
    ctx->r8 = ctx->r3 | 0;
    // 0x802FF86C: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FF870: beq         $at, $zero, L_802FF880
    if (ctx->r1 == 0) {
        // 0x802FF874: nop
    
            goto L_802FF880;
    }
    // 0x802FF874: nop

    // 0x802FF878: b           L_802FF880
    // 0x802FF87C: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
        goto L_802FF880;
    // 0x802FF87C: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
L_802FF880:
    // 0x802FF880: lbu         $a2, 0x416($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X416);
    // 0x802FF884: lbu         $a3, 0xE($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0XE);
    // 0x802FF888: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802FF88C: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FF890: beq         $at, $zero, L_802FF8A0
    if (ctx->r1 == 0) {
        // 0x802FF894: nop
    
            goto L_802FF8A0;
    }
    // 0x802FF894: nop

    // 0x802FF898: b           L_802FF8A0
    // 0x802FF89C: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
        goto L_802FF8A0;
    // 0x802FF89C: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
L_802FF8A0:
    // 0x802FF8A0: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FF8A4: beq         $at, $zero, L_802FF8C4
    if (ctx->r1 == 0) {
        // 0x802FF8A8: slt         $at, $v1, $a1
        ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_802FF8C4;
    }
    // 0x802FF8A8: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FF8AC: beq         $at, $zero, L_802FF8BC
    if (ctx->r1 == 0) {
        // 0x802FF8B0: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FF8BC;
    }
    // 0x802FF8B0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FF8B4: b           L_802FF8DC
    // 0x802FF8B8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802FF8DC;
    // 0x802FF8B8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802FF8BC:
    // 0x802FF8BC: b           L_802FF8DC
    // 0x802FF8C0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FF8DC;
    // 0x802FF8C0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FF8C4:
    // 0x802FF8C4: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FF8C8: beq         $at, $zero, L_802FF8D8
    if (ctx->r1 == 0) {
        // 0x802FF8CC: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802FF8D8;
    }
    // 0x802FF8CC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802FF8D0: b           L_802FF8D8
    // 0x802FF8D4: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
        goto L_802FF8D8;
    // 0x802FF8D4: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
L_802FF8D8:
    // 0x802FF8D8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FF8DC:
    // 0x802FF8DC: lh          $t5, 0xC($a0)
    ctx->r13 = MEM_H(ctx->r4, 0XC);
    // 0x802FF8E0: sll         $t6, $v1, 2
    ctx->r14 = S32(ctx->r3 << 2);
    // 0x802FF8E4: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802FF8E8: beql        $at, $zero, L_802FF900
    if (ctx->r1 == 0) {
        // 0x802FF8EC: lhu         $a2, 0x40($a0)
        ctx->r6 = MEM_HU(ctx->r4, 0X40);
            goto L_802FF900;
    }
    goto skip_0;
    // 0x802FF8EC: lhu         $a2, 0x40($a0)
    ctx->r6 = MEM_HU(ctx->r4, 0X40);
    skip_0:
    // 0x802FF8F0: jal         0x802FC990
    // 0x802FF8F4: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    run_commands(rdram, ctx);
        goto after_0;
    // 0x802FF8F4: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    after_0:
    // 0x802FF8F8: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x802FF8FC: lhu         $a2, 0x40($a0)
    ctx->r6 = MEM_HU(ctx->r4, 0X40);
L_802FF900:
    // 0x802FF900: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x802FF904: addiu       $t2, $zero, 0x9B
    ctx->r10 = ADD32(0, 0X9B);
    // 0x802FF908: sll         $t7, $a2, 2
    ctx->r15 = S32(ctx->r6 << 2);
    // 0x802FF90C: addu        $t7, $t7, $a2
    ctx->r15 = ADD32(ctx->r15, ctx->r6);
    // 0x802FF910: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x802FF914: sra         $t9, $t7, 11
    ctx->r25 = S32(SIGNED(ctx->r15) >> 11);
    // 0x802FF918: andi        $a2, $t9, 0xFF
    ctx->r6 = ctx->r25 & 0XFF;
    // 0x802FF91C: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FF920: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x802FF924: addiu       $t3, $zero, 0x9B
    ctx->r11 = ADD32(0, 0X9B);
    // 0x802FF928: addiu       $t4, $zero, 0xFF
    ctx->r12 = ADD32(0, 0XFF);
    // 0x802FF92C: addiu       $t5, $zero, 0xFF
    ctx->r13 = ADD32(0, 0XFF);
    // 0x802FF930: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x802FF934: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FF938: sw          $t1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r9;
    // 0x802FF93C: sw          $t6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r14;
    // 0x802FF940: sw          $t5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r13;
    // 0x802FF944: sw          $t4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r12;
    // 0x802FF948: sw          $t3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r11;
    // 0x802FF94C: sw          $t7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r15;
    // 0x802FF950: sw          $t9, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r25;
    // 0x802FF954: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x802FF958: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x802FF95C: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x802FF960: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x802FF964: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF968: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802FF96C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF970: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FF974: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FF978: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802FF97C: jal         0x8039DDA4
    // 0x802FF980: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    add_regular_trail(rdram, ctx);
        goto after_1;
    // 0x802FF980: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_1:
    // 0x802FF984: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x802FF988: addiu       $t4, $zero, 0xFF
    ctx->r12 = ADD32(0, 0XFF);
    // 0x802FF98C: addiu       $t5, $zero, 0x9B
    ctx->r13 = ADD32(0, 0X9B);
    // 0x802FF990: lhu         $a2, 0x40($a0)
    ctx->r6 = MEM_HU(ctx->r4, 0X40);
    // 0x802FF994: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x802FF998: addiu       $t6, $zero, 0x9B
    ctx->r14 = ADD32(0, 0X9B);
    // 0x802FF99C: sll         $t8, $a2, 2
    ctx->r24 = S32(ctx->r6 << 2);
    // 0x802FF9A0: addu        $t8, $t8, $a2
    ctx->r24 = ADD32(ctx->r24, ctx->r6);
    // 0x802FF9A4: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FF9A8: sra         $t2, $t8, 11
    ctx->r10 = S32(SIGNED(ctx->r24) >> 11);
    // 0x802FF9AC: andi        $a2, $t2, 0xFF
    ctx->r6 = ctx->r10 & 0XFF;
    // 0x802FF9B0: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x802FF9B4: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x802FF9B8: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x802FF9BC: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x802FF9C0: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x802FF9C4: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FF9C8: addiu       $t4, $a0, 0xC30
    ctx->r12 = ADD32(ctx->r4, 0XC30);
    // 0x802FF9CC: sw          $t4, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r12;
    // 0x802FF9D0: sw          $t3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r11;
    // 0x802FF9D4: sw          $t1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r9;
    // 0x802FF9D8: sw          $t9, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r25;
    // 0x802FF9DC: sw          $t7, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r15;
    // 0x802FF9E0: sw          $t8, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r24;
    // 0x802FF9E4: sw          $t2, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r10;
    // 0x802FF9E8: sw          $t6, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r14;
    // 0x802FF9EC: sw          $t5, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r13;
    // 0x802FF9F0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x802FF9F4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x802FF9F8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FF9FC: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FFA00: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FFA04: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FFA08: jal         0x8039DDA4
    // 0x802FFA0C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    add_regular_trail(rdram, ctx);
        goto after_2;
    // 0x802FFA0C: addiu       $a3, $zero, 0x10
    ctx->r7 = ADD32(0, 0X10);
    after_2:
    // 0x802FFA10: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
    // 0x802FFA14: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802FFA18: jr          $ra
    // 0x802FFA1C: nop

    return;
    // 0x802FFA1C: nop

;}
RECOMP_FUNC void func_802FFA20_7110D0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFA20: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802FFA24: sw          $ra, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r31;
    // 0x802FFA28: lh          $t6, 0x4($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X4);
    // 0x802FFA2C: lh          $t9, 0x8($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X8);
    // 0x802FFA30: lui         $t4, 0x803C
    ctx->r12 = S32(0X803C << 16);
    // 0x802FFA34: sra         $t7, $t6, 6
    ctx->r15 = S32(SIGNED(ctx->r14) >> 6);
    // 0x802FFA38: sll         $t8, $t7, 7
    ctx->r24 = S32(ctx->r15 << 7);
    // 0x802FFA3C: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x802FFA40: sra         $t1, $t9, 6
    ctx->r9 = S32(SIGNED(ctx->r25) >> 6);
    // 0x802FFA44: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x802FFA48: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x802FFA4C: addu        $t3, $t8, $t2
    ctx->r11 = ADD32(ctx->r24, ctx->r10);
    // 0x802FFA50: addiu       $t4, $t4, 0x740
    ctx->r12 = ADD32(ctx->r12, 0X740);
    // 0x802FFA54: addu        $v0, $t3, $t4
    ctx->r2 = ADD32(ctx->r11, ctx->r12);
    // 0x802FFA58: lbu         $v1, 0x40E($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X40E);
    // 0x802FFA5C: lbu         $a1, 0x6($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X6);
    // 0x802FFA60: or          $t0, $v1, $zero
    ctx->r8 = ctx->r3 | 0;
    // 0x802FFA64: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FFA68: beq         $at, $zero, L_802FFA78
    if (ctx->r1 == 0) {
        // 0x802FFA6C: nop
    
            goto L_802FFA78;
    }
    // 0x802FFA6C: nop

    // 0x802FFA70: b           L_802FFA78
    // 0x802FFA74: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
        goto L_802FFA78;
    // 0x802FFA74: or          $t0, $a1, $zero
    ctx->r8 = ctx->r5 | 0;
L_802FFA78:
    // 0x802FFA78: lbu         $a2, 0x416($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X416);
    // 0x802FFA7C: lbu         $a3, 0xE($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0XE);
    // 0x802FFA80: addiu       $t3, $zero, 0x64
    ctx->r11 = ADD32(0, 0X64);
    // 0x802FFA84: addiu       $t4, $zero, 0x64
    ctx->r12 = ADD32(0, 0X64);
    // 0x802FFA88: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FFA8C: beq         $at, $zero, L_802FFA9C
    if (ctx->r1 == 0) {
        // 0x802FFA90: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802FFA9C;
    }
    // 0x802FFA90: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802FFA94: b           L_802FFA9C
    // 0x802FFA98: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
        goto L_802FFA9C;
    // 0x802FFA98: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
L_802FFA9C:
    // 0x802FFA9C: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x802FFAA0: beq         $at, $zero, L_802FFAC4
    if (ctx->r1 == 0) {
        // 0x802FFAA4: addiu       $t2, $zero, 0xFF
        ctx->r10 = ADD32(0, 0XFF);
            goto L_802FFAC4;
    }
    // 0x802FFAA4: addiu       $t2, $zero, 0xFF
    ctx->r10 = ADD32(0, 0XFF);
    // 0x802FFAA8: slt         $at, $v1, $a1
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x802FFAAC: beq         $at, $zero, L_802FFABC
    if (ctx->r1 == 0) {
        // 0x802FFAB0: or          $v0, $v1, $zero
        ctx->r2 = ctx->r3 | 0;
            goto L_802FFABC;
    }
    // 0x802FFAB0: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x802FFAB4: b           L_802FFADC
    // 0x802FFAB8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_802FFADC;
    // 0x802FFAB8: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
L_802FFABC:
    // 0x802FFABC: b           L_802FFADC
    // 0x802FFAC0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FFADC;
    // 0x802FFAC0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FFAC4:
    // 0x802FFAC4: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x802FFAC8: beq         $at, $zero, L_802FFAD8
    if (ctx->r1 == 0) {
        // 0x802FFACC: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_802FFAD8;
    }
    // 0x802FFACC: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    // 0x802FFAD0: b           L_802FFAD8
    // 0x802FFAD4: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
        goto L_802FFAD8;
    // 0x802FFAD4: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
L_802FFAD8:
    // 0x802FFAD8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FFADC:
    // 0x802FFADC: lh          $t5, 0xC($a0)
    ctx->r13 = MEM_H(ctx->r4, 0XC);
    // 0x802FFAE0: sll         $t6, $v1, 2
    ctx->r14 = S32(ctx->r3 << 2);
    // 0x802FFAE4: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x802FFAE8: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x802FFAEC: beq         $at, $zero, L_802FFB04
    if (ctx->r1 == 0) {
        // 0x802FFAF0: addiu       $a3, $zero, 0x8
        ctx->r7 = ADD32(0, 0X8);
            goto L_802FFB04;
    }
    // 0x802FFAF0: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    // 0x802FFAF4: jal         0x802FC990
    // 0x802FFAF8: nop

    run_commands(rdram, ctx);
        goto after_0;
    // 0x802FFAF8: nop

    after_0:
    // 0x802FFAFC: b           L_802FFC28
    // 0x802FFB00: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
        goto L_802FFC28;
    // 0x802FFB00: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_802FFB04:
    // 0x802FFB04: lbu         $t7, 0x154($a0)
    ctx->r15 = MEM_BU(ctx->r4, 0X154);
    // 0x802FFB08: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FFB0C: addiu       $t5, $zero, 0xFF
    ctx->r13 = ADD32(0, 0XFF);
    // 0x802FFB10: bne         $t7, $zero, L_802FFB1C
    if (ctx->r15 != 0) {
        // 0x802FFB14: addiu       $t6, $zero, 0x9B
        ctx->r14 = ADD32(0, 0X9B);
            goto L_802FFB1C;
    }
    // 0x802FFB14: addiu       $t6, $zero, 0x9B
    ctx->r14 = ADD32(0, 0X9B);
    // 0x802FFB18: sb          $t9, 0x154($a0)
    MEM_B(0X154, ctx->r4) = ctx->r25;
L_802FFB1C:
    // 0x802FFB1C: lhu         $a2, 0x40($a0)
    ctx->r6 = MEM_HU(ctx->r4, 0X40);
    // 0x802FFB20: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x802FFB24: sw          $t3, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r11;
    // 0x802FFB28: sll         $t1, $a2, 2
    ctx->r9 = S32(ctx->r6 << 2);
    // 0x802FFB2C: addu        $t1, $t1, $a2
    ctx->r9 = ADD32(ctx->r9, ctx->r6);
    // 0x802FFB30: sll         $t1, $t1, 3
    ctx->r9 = S32(ctx->r9 << 3);
    // 0x802FFB34: sra         $t8, $t1, 11
    ctx->r24 = S32(SIGNED(ctx->r9) >> 11);
    // 0x802FFB38: andi        $a2, $t8, 0xFF
    ctx->r6 = ctx->r24 & 0XFF;
    // 0x802FFB3C: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x802FFB40: addiu       $t1, $zero, 0xFF
    ctx->r9 = ADD32(0, 0XFF);
    // 0x802FFB44: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x802FFB48: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x802FFB4C: addiu       $t7, $zero, 0x9B
    ctx->r15 = ADD32(0, 0X9B);
    // 0x802FFB50: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x802FFB54: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    // 0x802FFB58: sw          $t7, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r15;
    // 0x802FFB5C: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
    // 0x802FFB60: sw          $t3, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r11;
    // 0x802FFB64: sw          $t1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r9;
    // 0x802FFB68: sw          $t8, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r24;
    // 0x802FFB6C: sw          $a0, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r4;
    // 0x802FFB70: sw          $a0, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r4;
    // 0x802FFB74: sw          $t2, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r10;
    // 0x802FFB78: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x802FFB7C: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x802FFB80: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FFB84: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FFB88: jal         0x8039DDA4
    // 0x802FFB8C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    add_regular_trail(rdram, ctx);
        goto after_1;
    // 0x802FFB8C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_1:
    // 0x802FFB90: lw          $a0, 0x58($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X58);
    // 0x802FFB94: addiu       $t9, $zero, 0x64
    ctx->r25 = ADD32(0, 0X64);
    // 0x802FFB98: addiu       $t1, $zero, 0x64
    ctx->r9 = ADD32(0, 0X64);
    // 0x802FFB9C: lhu         $a2, 0x40($a0)
    ctx->r6 = MEM_HU(ctx->r4, 0X40);
    // 0x802FFBA0: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x802FFBA4: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x802FFBA8: sll         $t5, $a2, 2
    ctx->r13 = S32(ctx->r6 << 2);
    // 0x802FFBAC: addu        $t5, $t5, $a2
    ctx->r13 = ADD32(ctx->r13, ctx->r6);
    // 0x802FFBB0: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x802FFBB4: sra         $t6, $t5, 11
    ctx->r14 = S32(SIGNED(ctx->r13) >> 11);
    // 0x802FFBB8: andi        $a2, $t6, 0xFF
    ctx->r6 = ctx->r14 & 0XFF;
    // 0x802FFBBC: sw          $t1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r9;
    // 0x802FFBC0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x802FFBC4: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x802FFBC8: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x802FFBCC: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x802FFBD0: addiu       $t5, $zero, 0xFF
    ctx->r13 = ADD32(0, 0XFF);
    // 0x802FFBD4: addiu       $t2, $zero, 0x9B
    ctx->r10 = ADD32(0, 0X9B);
    // 0x802FFBD8: addiu       $t3, $zero, 0x9B
    ctx->r11 = ADD32(0, 0X9B);
    // 0x802FFBDC: addiu       $t4, $zero, 0xFF
    ctx->r12 = ADD32(0, 0XFF);
    // 0x802FFBE0: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x802FFBE4: addiu       $t8, $a0, 0xC30
    ctx->r24 = ADD32(ctx->r4, 0XC30);
    // 0x802FFBE8: sw          $t8, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r24;
    // 0x802FFBEC: sw          $t7, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r15;
    // 0x802FFBF0: sw          $t4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r12;
    // 0x802FFBF4: sw          $t3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r11;
    // 0x802FFBF8: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x802FFBFC: sw          $t5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r13;
    // 0x802FFC00: sw          $t6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r14;
    // 0x802FFC04: sw          $t1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r9;
    // 0x802FFC08: sw          $t9, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r25;
    // 0x802FFC0C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x802FFC10: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FFC14: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FFC18: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x802FFC1C: jal         0x8039DDA4
    // 0x802FFC20: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    add_regular_trail(rdram, ctx);
        goto after_2;
    // 0x802FFC20: addiu       $a3, $zero, 0x8
    ctx->r7 = ADD32(0, 0X8);
    after_2:
    // 0x802FFC24: lw          $ra, 0x54($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X54);
L_802FFC28:
    // 0x802FFC28: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802FFC2C: jr          $ra
    // 0x802FFC30: nop

    return;
    // 0x802FFC30: nop

;}
RECOMP_FUNC void func_802FFC34_7112E4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFC34: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x802FFC38: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802FFC3C: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x802FFC40: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802FFC44: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x802FFC48: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FFC4C: bnel        $t6, $at, L_802FFD40
    if (ctx->r14 != ctx->r1) {
        // 0x802FFC50: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_802FFD40;
    }
    goto skip_0;
    // 0x802FFC50: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_0:
    // 0x802FFC54: lw          $v0, 0x158($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X158);
    // 0x802FFC58: addiu       $v1, $zero, 0xFF
    ctx->r3 = ADD32(0, 0XFF);
    // 0x802FFC5C: slti        $at, $v0, 0xFF
    ctx->r1 = SIGNED(ctx->r2) < 0XFF ? 1 : 0;
    // 0x802FFC60: beq         $at, $zero, L_802FFC70
    if (ctx->r1 == 0) {
        // 0x802FFC64: nop
    
            goto L_802FFC70;
    }
    // 0x802FFC64: nop

    // 0x802FFC68: b           L_802FFC70
    // 0x802FFC6C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_802FFC70;
    // 0x802FFC6C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_802FFC70:
    // 0x802FFC70: lw          $t8, 0x200($s0)
    ctx->r24 = MEM_W(ctx->r16, 0X200);
    // 0x802FFC74: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FFC78: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FFC7C: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FFC80: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x802FFC84: lw          $t9, 0x204($s0)
    ctx->r25 = MEM_W(ctx->r16, 0X204);
    // 0x802FFC88: sll         $a3, $v1, 16
    ctx->r7 = S32(ctx->r3 << 16);
    // 0x802FFC8C: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x802FFC90: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x802FFC94: lw          $t0, 0x208($s0)
    ctx->r8 = MEM_W(ctx->r16, 0X208);
    // 0x802FFC98: sw          $t7, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r15;
    // 0x802FFC9C: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x802FFCA0: jal         0x802F2B54
    // 0x802FFCA4: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    add_light_at_location(rdram, ctx);
        goto after_0;
    // 0x802FFCA4: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    after_0:
    // 0x802FFCA8: lbu         $t1, 0x163($s0)
    ctx->r9 = MEM_BU(ctx->r16, 0X163);
    // 0x802FFCAC: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802FFCB0: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x802FFCB4: andi        $t2, $t1, 0x8
    ctx->r10 = ctx->r9 & 0X8;
    // 0x802FFCB8: bnel        $t2, $zero, L_802FFD40
    if (ctx->r10 != 0) {
        // 0x802FFCBC: lw          $ra, 0x44($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X44);
            goto L_802FFD40;
    }
    goto skip_1;
    // 0x802FFCBC: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    skip_1:
    // 0x802FFCC0: lh          $a3, 0x2C($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2C);
    // 0x802FFCC4: lhu         $v1, 0x40($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X40);
    // 0x802FFCC8: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x802FFCCC: sll         $t5, $a3, 8
    ctx->r13 = S32(ctx->r7 << 8);
    // 0x802FFCD0: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x802FFCD4: sll         $t3, $v1, 6
    ctx->r11 = S32(ctx->r3 << 6);
    // 0x802FFCD8: sra         $t4, $t3, 11
    ctx->r12 = S32(SIGNED(ctx->r11) >> 11);
    // 0x802FFCDC: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x802FFCE0: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x802FFCE4: lw          $t9, -0x7C8C($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X7C8C);
    // 0x802FFCE8: lw          $t1, 0x48($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X48);
    // 0x802FFCEC: sll         $v0, $t4, 16
    ctx->r2 = S32(ctx->r12 << 16);
    // 0x802FFCF0: sra         $t0, $v0, 16
    ctx->r8 = S32(SIGNED(ctx->r2) >> 16);
    // 0x802FFCF4: sw          $t0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r8;
    // 0x802FFCF8: sw          $t0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r8;
    // 0x802FFCFC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x802FFD00: sw          $t1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r9;
    // 0x802FFD04: lw          $t2, 0x200($s0)
    ctx->r10 = MEM_W(ctx->r16, 0X200);
    // 0x802FFD08: mflo        $t6
    ctx->r14 = lo;
    // 0x802FFD0C: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x802FFD10: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x802FFD14: lw          $t3, 0x204($s0)
    ctx->r11 = MEM_W(ctx->r16, 0X204);
    // 0x802FFD18: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x802FFD1C: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x802FFD20: sw          $t3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r11;
    // 0x802FFD24: lw          $t4, 0x208($s0)
    ctx->r12 = MEM_W(ctx->r16, 0X208);
    // 0x802FFD28: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x802FFD2C: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    // 0x802FFD30: or          $v0, $t0, $zero
    ctx->r2 = ctx->r8 | 0;
    // 0x802FFD34: jal         0x8034BD20
    // 0x802FFD38: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_1;
    // 0x802FFD38: sw          $t4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r12;
    after_1:
    // 0x802FFD3C: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
L_802FFD40:
    // 0x802FFD40: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x802FFD44: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    // 0x802FFD48: jr          $ra
    // 0x802FFD4C: nop

    return;
    // 0x802FFD4C: nop

;}
RECOMP_FUNC void func_802FFD50_711400(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFD50: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FFD54: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FFD58: lw          $t6, 0x1C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X1C);
    // 0x802FFD5C: lw          $t7, 0x20($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X20);
    // 0x802FFD60: lw          $t8, 0x24($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X24);
    // 0x802FFD64: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x802FFD68: mtc1        $t7, $f8
    ctx->f8.u32l = ctx->r15;
    // 0x802FFD6C: lui         $at, 0x4780
    ctx->r1 = S32(0X4780 << 16);
    // 0x802FFD70: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FFD74: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    // 0x802FFD78: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x802FFD7C: or          $a1, $a0, $zero
    ctx->r5 = ctx->r4 | 0;
    // 0x802FFD80: cvt.s.w     $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.fl = CVT_S_W(ctx->f8.u32l);
    // 0x802FFD84: div.s       $f16, $f6, $f2
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f16.fl = DIV_S(ctx->f6.fl, ctx->f2.fl);
    // 0x802FFD88: cvt.s.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.fl = CVT_S_W(ctx->f4.u32l);
    // 0x802FFD8C: div.s       $f12, $f10, $f2
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f10.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f12.fl = DIV_S(ctx->f10.fl, ctx->f2.fl);
    // 0x802FFD90: mul.s       $f8, $f16, $f16
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f8.fl = MUL_S(ctx->f16.fl, ctx->f16.fl);
    // 0x802FFD94: div.s       $f18, $f6, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = DIV_S(ctx->f6.fl, ctx->f2.fl);
    // 0x802FFD98: mul.s       $f10, $f12, $f12
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 12);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f12.fl); 
    ctx->f10.fl = MUL_S(ctx->f12.fl, ctx->f12.fl);
    // 0x802FFD9C: add.s       $f4, $f8, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f8.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = ctx->f8.fl + ctx->f10.fl;
    // 0x802FFDA0: mul.s       $f6, $f18, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f18.fl); 
    ctx->f6.fl = MUL_S(ctx->f18.fl, ctx->f18.fl);
    // 0x802FFDA4: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x802FFDA8: mtc1        $zero, $f10
    ctx->f10.u32l = 0;
    // 0x802FFDAC: add.s       $f0, $f4, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f0.fl = ctx->f4.fl + ctx->f6.fl;
    // 0x802FFDB0: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x802FFDB4: c.lt.s      $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f0.fl < ctx->f8.fl;
    // 0x802FFDB8: swc1        $f0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->f0.u32l;
    // 0x802FFDBC: lwc1        $f6, 0x34($sp)
    ctx->f6.u32l = MEM_W(ctx->r29, 0X34);
    // 0x802FFDC0: bc1fl       L_802FFDD4
    if (!c1cs) {
        // 0x802FFDC4: mov.s       $f2, $f0
        CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
            goto L_802FFDD4;
    }
    goto skip_0;
    // 0x802FFDC4: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
    skip_0:
    // 0x802FFDC8: b           L_802FFDD4
    // 0x802FFDCC: neg.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = -ctx->f0.fl;
        goto L_802FFDD4;
    // 0x802FFDCC: neg.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = -ctx->f0.fl;
    // 0x802FFDD0: mov.s       $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    ctx->f2.fl = ctx->f0.fl;
L_802FFDD4:
    // 0x802FFDD4: c.lt.s      $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    c1cs = ctx->f10.fl < ctx->f2.fl;
    // 0x802FFDD8: nop

    // 0x802FFDDC: bc1fl       L_802FFE88
    if (!c1cs) {
        // 0x802FFDE0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802FFE88;
    }
    goto skip_1;
    // 0x802FFDE0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802FFDE4: div.s       $f14, $f12, $f0
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f12.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f14.fl = DIV_S(ctx->f12.fl, ctx->f0.fl);
    // 0x802FFDE8: mtc1        $zero, $f4
    ctx->f4.u32l = 0;
    // 0x802FFDEC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x802FFDF0: c.eq.s      $f4, $f14
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    c1cs = ctx->f4.fl == ctx->f14.fl;
    // 0x802FFDF4: nop

    // 0x802FFDF8: bc1fl       L_802FFE08
    if (!c1cs) {
        // 0x802FFDFC: div.s       $f12, $f16, $f6
        CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f6.fl);
            goto L_802FFE08;
    }
    goto skip_2;
    // 0x802FFDFC: div.s       $f12, $f16, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f6.fl);
    skip_2:
    // 0x802FFE00: lwc1        $f14, -0x306C($at)
    ctx->f14.u32l = MEM_W(ctx->r1, -0X306C);
    // 0x802FFE04: div.s       $f12, $f16, $f6
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f12.fl = DIV_S(ctx->f16.fl, ctx->f6.fl);
L_802FFE08:
    // 0x802FFE08: sw          $a1, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r5;
    // 0x802FFE0C: jal         0x801286B8
    // 0x802FFE10: swc1        $f18, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f18.u32l;
    func_801286B8(rdram, ctx);
        goto after_0;
    // 0x802FFE10: swc1        $f18, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->f18.u32l;
    after_0:
    // 0x802FFE14: trunc.w.s   $f8, $f0
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    ctx->f8.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x802FFE18: lw          $a1, 0x38($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X38);
    // 0x802FFE1C: lwc1        $f18, 0x1C($sp)
    ctx->f18.u32l = MEM_W(ctx->r29, 0X1C);
    // 0x802FFE20: lui         $at, 0x4380
    ctx->r1 = S32(0X4380 << 16);
    // 0x802FFE24: mfc1        $t0, $f8
    ctx->r8 = (int32_t)ctx->f8.u32l;
    // 0x802FFE28: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x802FFE2C: sh          $t0, 0x2C($a1)
    MEM_H(0X2C, ctx->r5) = ctx->r8;
    // 0x802FFE30: lwc1        $f10, 0x34($sp)
    ctx->f10.u32l = MEM_W(ctx->r29, 0X34);
    // 0x802FFE34: div.s       $f4, $f18, $f10
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f18.fl); NAN_CHECK(ctx->f10.fl); 
    ctx->f4.fl = DIV_S(ctx->f18.fl, ctx->f10.fl);
    // 0x802FFE38: mul.s       $f8, $f4, $f6
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f4.fl); NAN_CHECK(ctx->f6.fl); 
    ctx->f8.fl = MUL_S(ctx->f4.fl, ctx->f6.fl);
    // 0x802FFE3C: trunc.w.s   $f10, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    ctx->f10.u32l = TRUNC_W_S(ctx->f8.fl);
    // 0x802FFE40: mfc1        $a0, $f10
    ctx->r4 = (int32_t)ctx->f10.u32l;
    // 0x802FFE44: nop

    // 0x802FFE48: sll         $t2, $a0, 16
    ctx->r10 = S32(ctx->r4 << 16);
    // 0x802FFE4C: jal         0x8012835C
    // 0x802FFE50: sra         $a0, $t2, 16
    ctx->r4 = S32(SIGNED(ctx->r10) >> 16);
    func_8012835C(rdram, ctx);
        goto after_1;
    // 0x802FFE50: sra         $a0, $t2, 16
    ctx->r4 = S32(SIGNED(ctx->r10) >> 16);
    after_1:
    // 0x802FFE54: lw          $a1, 0x38($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X38);
    // 0x802FFE58: sh          $v0, 0x2E($a1)
    MEM_H(0X2E, ctx->r5) = ctx->r2;
    // 0x802FFE5C: lh          $v1, 0x2E($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X2E);
    // 0x802FFE60: bltz        $v1, L_802FFE6C
    if (SIGNED(ctx->r3) < 0) {
        // 0x802FFE64: slti        $at, $v1, 0x169
        ctx->r1 = SIGNED(ctx->r3) < 0X169 ? 1 : 0;
            goto L_802FFE6C;
    }
    // 0x802FFE64: slti        $at, $v1, 0x169
    ctx->r1 = SIGNED(ctx->r3) < 0X169 ? 1 : 0;
    // 0x802FFE68: bne         $at, $zero, L_802FFE84
    if (ctx->r1 != 0) {
        // 0x802FFE6C: addiu       $t4, $v1, 0x5A0
        ctx->r12 = ADD32(ctx->r3, 0X5A0);
            goto L_802FFE84;
    }
L_802FFE6C:
    // 0x802FFE6C: addiu       $t4, $v1, 0x5A0
    ctx->r12 = ADD32(ctx->r3, 0X5A0);
    // 0x802FFE70: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x802FFE74: div         $zero, $t4, $at
    lo = S32(S64(S32(ctx->r12)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r12)) % S64(S32(ctx->r1)));
    // 0x802FFE78: mfhi        $t5
    ctx->r13 = hi;
    // 0x802FFE7C: sh          $t5, 0x2E($a1)
    MEM_H(0X2E, ctx->r5) = ctx->r13;
    // 0x802FFE80: nop

L_802FFE84:
    // 0x802FFE84: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802FFE88:
    // 0x802FFE88: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FFE8C: jr          $ra
    // 0x802FFE90: nop

    return;
    // 0x802FFE90: nop

;}
RECOMP_FUNC void func_802FFE94_711544(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFE94: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FFE98: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FFE9C: lh          $t6, 0x14E($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X14E);
    // 0x802FFEA0: lw          $t9, 0x200($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X200);
    // 0x802FFEA4: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x802FFEA8: andi        $t8, $t7, 0x1F
    ctx->r24 = ctx->r15 & 0X1F;
    // 0x802FFEAC: andi        $t0, $t9, 0x1
    ctx->r8 = ctx->r25 & 0X1;
    // 0x802FFEB0: beq         $t0, $zero, L_802FFEC0
    if (ctx->r8 == 0) {
        // 0x802FFEB4: sh          $t8, 0x14E($a0)
        MEM_H(0X14E, ctx->r4) = ctx->r24;
            goto L_802FFEC0;
    }
    // 0x802FFEB4: sh          $t8, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r24;
    // 0x802FFEB8: jal         0x802FFD50
    // 0x802FFEBC: nop

    func_802FFD50_711400(rdram, ctx);
        goto after_0;
    // 0x802FFEBC: nop

    after_0:
L_802FFEC0:
    // 0x802FFEC0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802FFEC4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FFEC8: jr          $ra
    // 0x802FFECC: nop

    return;
    // 0x802FFECC: nop

;}
RECOMP_FUNC void func_802FFED0_711580(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFED0: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FFED4: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FFED8: lw          $t6, 0x158($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X158);
    // 0x802FFEDC: beql        $t6, $zero, L_802FFEF0
    if (ctx->r14 == 0) {
        // 0x802FFEE0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802FFEF0;
    }
    goto skip_0;
    // 0x802FFEE0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x802FFEE4: jal         0x802FFD50
    // 0x802FFEE8: nop

    func_802FFD50_711400(rdram, ctx);
        goto after_0;
    // 0x802FFEE8: nop

    after_0:
    // 0x802FFEEC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802FFEF0:
    // 0x802FFEF0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FFEF4: jr          $ra
    // 0x802FFEF8: nop

    return;
    // 0x802FFEF8: nop

;}
RECOMP_FUNC void func_802FFEFC_7115AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFEFC: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FFF00: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FFF04: lhu         $t6, 0x0($a0)
    ctx->r14 = MEM_HU(ctx->r4, 0X0);
    // 0x802FFF08: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x802FFF0C: bnel        $v0, $t6, L_802FFF34
    if (ctx->r2 != ctx->r14) {
        // 0x802FFF10: lh          $t8, 0x14E($a0)
        ctx->r24 = MEM_H(ctx->r4, 0X14E);
            goto L_802FFF34;
    }
    goto skip_0;
    // 0x802FFF10: lh          $t8, 0x14E($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X14E);
    skip_0:
    // 0x802FFF14: lh          $t7, 0x14E($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X14E);
    // 0x802FFF18: bnel        $t7, $zero, L_802FFF44
    if (ctx->r15 != 0) {
        // 0x802FFF1C: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802FFF44;
    }
    goto skip_1;
    // 0x802FFF1C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x802FFF20: jal         0x8034419C
    // 0x802FFF24: sh          $v0, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r2;
    func_8034419C_75584C(rdram, ctx);
        goto after_0;
    // 0x802FFF24: sh          $v0, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = ctx->r2;
    after_0:
    // 0x802FFF28: b           L_802FFF44
    // 0x802FFF2C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_802FFF44;
    // 0x802FFF2C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802FFF30: lh          $t8, 0x14E($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X14E);
L_802FFF34:
    // 0x802FFF34: bnel        $v0, $t8, L_802FFF44
    if (ctx->r2 != ctx->r24) {
        // 0x802FFF38: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_802FFF44;
    }
    goto skip_2;
    // 0x802FFF38: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
    // 0x802FFF3C: sh          $zero, 0x14E($a0)
    MEM_H(0X14E, ctx->r4) = 0;
    // 0x802FFF40: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_802FFF44:
    // 0x802FFF44: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FFF48: jr          $ra
    // 0x802FFF4C: nop

    return;
    // 0x802FFF4C: nop

;}
RECOMP_FUNC void func_802FFF50_711600(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFF50: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x802FFF54: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x802FFF58: jal         0x802FFED0
    // 0x802FFF5C: nop

    func_802FFED0_711580(rdram, ctx);
        goto after_0;
    // 0x802FFF5C: nop

    after_0:
    // 0x802FFF60: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x802FFF64: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x802FFF68: jr          $ra
    // 0x802FFF6C: nop

    return;
    // 0x802FFF6C: nop

;}
RECOMP_FUNC void func_802FFF70_711620(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFF70: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x802FFF74: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x802FFF78: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x802FFF7C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x802FFF80: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x802FFF84: or          $t6, $a0, $zero
    ctx->r14 = ctx->r4 | 0;
    // 0x802FFF88: lh          $t7, 0x4($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X4);
    // 0x802FFF8C: addiu       $a0, $a0, 0x22
    ctx->r4 = ADD32(ctx->r4, 0X22);
    // 0x802FFF90: addiu       $a1, $zero, 0x9F
    ctx->r5 = ADD32(0, 0X9F);
    // 0x802FFF94: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x802FFF98: lh          $t8, 0x8($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X8);
    // 0x802FFF9C: addiu       $a2, $zero, 0x3000
    ctx->r6 = ADD32(0, 0X3000);
    // 0x802FFFA0: lui         $a3, 0x3F80
    ctx->r7 = S32(0X3F80 << 16);
    // 0x802FFFA4: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x802FFFA8: lh          $t9, 0xC($t6)
    ctx->r25 = MEM_H(ctx->r14, 0XC);
    // 0x802FFFAC: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x802FFFB0: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x802FFFB4: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x802FFFB8: jal         0x8032CED0
    // 0x802FFFBC: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    func_8032CED0_73E580(rdram, ctx);
        goto after_0;
    // 0x802FFFBC: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    after_0:
    // 0x802FFFC0: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x802FFFC4: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    // 0x802FFFC8: jr          $ra
    // 0x802FFFCC: nop

    return;
    // 0x802FFFCC: nop

;}
RECOMP_FUNC void func_802FFFD0_711680(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x802FFFD0: addiu       $sp, $sp, -0x60
    ctx->r29 = ADD32(ctx->r29, -0X60);
    // 0x802FFFD4: sw          $ra, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r31;
    // 0x802FFFD8: sw          $s0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r16;
    // 0x802FFFDC: lw          $t6, 0x16C($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X16C);
    // 0x802FFFE0: addiu       $at, $zero, 0x3C
    ctx->r1 = ADD32(0, 0X3C);
    // 0x802FFFE4: or          $s0, $a0, $zero
    ctx->r16 = ctx->r4 | 0;
    // 0x802FFFE8: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x802FFFEC: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x802FFFF0: addiu       $t8, $zero, 0xFF
    ctx->r24 = ADD32(0, 0XFF);
    // 0x802FFFF4: bne         $v0, $at, L_80300010
    if (ctx->r2 != ctx->r1) {
        // 0x802FFFF8: addiu       $a3, $zero, 0x80
        ctx->r7 = ADD32(0, 0X80);
            goto L_80300010;
    }
    // 0x802FFFF8: addiu       $a3, $zero, 0x80
    ctx->r7 = ADD32(0, 0X80);
    // 0x802FFFFC: addiu       $t9, $zero, 0xFF
    ctx->r25 = ADD32(0, 0XFF);
    // 0x80300000: sb          $t9, 0x5D($sp)
    MEM_B(0X5D, ctx->r29) = ctx->r25;
    // 0x80300004: sb          $t7, 0x5F($sp)
    MEM_B(0X5F, ctx->r29) = ctx->r15;
    // 0x80300008: b           L_80300050
    // 0x8030000C: sb          $t8, 0x5E($sp)
    MEM_B(0X5E, ctx->r29) = ctx->r24;
        goto L_80300050;
    // 0x8030000C: sb          $t8, 0x5E($sp)
    MEM_B(0X5E, ctx->r29) = ctx->r24;
L_80300010:
    // 0x80300010: addiu       $at, $zero, 0x3B
    ctx->r1 = ADD32(0, 0X3B);
    // 0x80300014: bne         $v0, $at, L_80300034
    if (ctx->r2 != ctx->r1) {
        // 0x80300018: addiu       $t3, $zero, 0xFF
        ctx->r11 = ADD32(0, 0XFF);
            goto L_80300034;
    }
    // 0x80300018: addiu       $t3, $zero, 0xFF
    ctx->r11 = ADD32(0, 0XFF);
    // 0x8030001C: addiu       $t4, $zero, 0xA0
    ctx->r12 = ADD32(0, 0XA0);
    // 0x80300020: addiu       $t5, $zero, 0xFF
    ctx->r13 = ADD32(0, 0XFF);
    // 0x80300024: sb          $t5, 0x5D($sp)
    MEM_B(0X5D, ctx->r29) = ctx->r13;
    // 0x80300028: sb          $t4, 0x5E($sp)
    MEM_B(0X5E, ctx->r29) = ctx->r12;
    // 0x8030002C: b           L_80300050
    // 0x80300030: sb          $t3, 0x5F($sp)
    MEM_B(0X5F, ctx->r29) = ctx->r11;
        goto L_80300050;
    // 0x80300030: sb          $t3, 0x5F($sp)
    MEM_B(0X5F, ctx->r29) = ctx->r11;
L_80300034:
    // 0x80300034: addiu       $at, $zero, 0x3A
    ctx->r1 = ADD32(0, 0X3A);
    // 0x80300038: bne         $v0, $at, L_80300050
    if (ctx->r2 != ctx->r1) {
        // 0x8030003C: addiu       $t6, $zero, 0xFF
        ctx->r14 = ADD32(0, 0XFF);
            goto L_80300050;
    }
    // 0x8030003C: addiu       $t6, $zero, 0xFF
    ctx->r14 = ADD32(0, 0XFF);
    // 0x80300040: addiu       $t7, $zero, 0xFF
    ctx->r15 = ADD32(0, 0XFF);
    // 0x80300044: sb          $t7, 0x5D($sp)
    MEM_B(0X5D, ctx->r29) = ctx->r15;
    // 0x80300048: sb          $t6, 0x5F($sp)
    MEM_B(0X5F, ctx->r29) = ctx->r14;
    // 0x8030004C: sb          $zero, 0x5E($sp)
    MEM_B(0X5E, ctx->r29) = 0;
L_80300050:
    // 0x80300050: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x80300054: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x80300058: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x8030005C: lbu         $t0, 0x5F($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0X5F);
    // 0x80300060: lbu         $t1, 0x5E($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X5E);
    // 0x80300064: lbu         $t2, 0x5D($sp)
    ctx->r10 = MEM_BU(ctx->r29, 0X5D);
    // 0x80300068: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x8030006C: sw          $t0, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r8;
    // 0x80300070: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    // 0x80300074: sw          $t1, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r9;
    // 0x80300078: sw          $t2, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r10;
    // 0x8030007C: jal         0x802F2B54
    // 0x80300080: sw          $t2, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r10;
    add_light_at_location(rdram, ctx);
        goto after_0;
    // 0x80300080: sw          $t2, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r10;
    after_0:
    // 0x80300084: lbu         $t8, 0x163($s0)
    ctx->r24 = MEM_BU(ctx->r16, 0X163);
    // 0x80300088: lw          $t0, 0x54($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X54);
    // 0x8030008C: lw          $t1, 0x50($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X50);
    // 0x80300090: andi        $t9, $t8, 0x8
    ctx->r25 = ctx->r24 & 0X8;
    // 0x80300094: bne         $t9, $zero, L_80300114
    if (ctx->r25 != 0) {
        // 0x80300098: lw          $t2, 0x4C($sp)
        ctx->r10 = MEM_W(ctx->r29, 0X4C);
            goto L_80300114;
    }
    // 0x80300098: lw          $t2, 0x4C($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X4C);
    // 0x8030009C: lh          $a3, 0x2C($s0)
    ctx->r7 = MEM_H(ctx->r16, 0X2C);
    // 0x803000A0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803000A4: lhu         $v1, 0x40($s0)
    ctx->r3 = MEM_HU(ctx->r16, 0X40);
    // 0x803000A8: sll         $t5, $a3, 8
    ctx->r13 = S32(ctx->r7 << 8);
    // 0x803000AC: div         $zero, $t5, $at
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r1)));
    // 0x803000B0: lh          $a0, 0x4($s0)
    ctx->r4 = MEM_H(ctx->r16, 0X4);
    // 0x803000B4: lh          $a1, 0x8($s0)
    ctx->r5 = MEM_H(ctx->r16, 0X8);
    // 0x803000B8: lh          $a2, 0xC($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XC);
    // 0x803000BC: sll         $t3, $v1, 5
    ctx->r11 = S32(ctx->r3 << 5);
    // 0x803000C0: sra         $t4, $t3, 11
    ctx->r12 = S32(SIGNED(ctx->r11) >> 11);
    // 0x803000C4: sll         $v0, $t4, 16
    ctx->r2 = S32(ctx->r12 << 16);
    // 0x803000C8: lui         $t9, 0x803B
    ctx->r25 = S32(0X803B << 16);
    // 0x803000CC: lw          $t9, -0x7C8C($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X7C8C);
    // 0x803000D0: sra         $t3, $v0, 16
    ctx->r11 = S32(SIGNED(ctx->r2) >> 16);
    // 0x803000D4: mflo        $t6
    ctx->r14 = lo;
    // 0x803000D8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x803000DC: addiu       $t4, $zero, 0x40
    ctx->r12 = ADD32(0, 0X40);
    // 0x803000E0: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x803000E4: sw          $t5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r13;
    // 0x803000E8: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x803000EC: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803000F0: or          $v0, $t3, $zero
    ctx->r2 = ctx->r11 | 0;
    // 0x803000F4: sw          $t3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r11;
    // 0x803000F8: sw          $t3, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r11;
    // 0x803000FC: sw          $zero, 0x30($sp)
    MEM_W(0X30, ctx->r29) = 0;
    // 0x80300100: sw          $t2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r10;
    // 0x80300104: sw          $t1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r9;
    // 0x80300108: sw          $t0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r8;
    // 0x8030010C: jal         0x8034BD20
    // 0x80300110: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_1;
    // 0x80300110: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_1:
L_80300114:
    // 0x80300114: lw          $ra, 0x44($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X44);
    // 0x80300118: lw          $s0, 0x40($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X40);
    // 0x8030011C: addiu       $sp, $sp, 0x60
    ctx->r29 = ADD32(ctx->r29, 0X60);
    // 0x80300120: jr          $ra
    // 0x80300124: nop

    return;
    // 0x80300124: nop

;}
RECOMP_FUNC void func_80300130_7117E0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80300130: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80300134: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80300138: lh          $v0, 0x0($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X0);
    // 0x8030013C: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x80300140: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x80300144: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80300148: bgez        $v0, L_8030016C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8030014C: sra         $a2, $t6, 16
        ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
            goto L_8030016C;
    }
    // 0x8030014C: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80300150: lh          $t1, 0x12($sp)
    ctx->r9 = MEM_H(ctx->r29, 0X12);
    // 0x80300154: lh          $t3, 0x0($a1)
    ctx->r11 = MEM_H(ctx->r5, 0X0);
    // 0x80300158: negu        $t0, $v0
    ctx->r8 = SUB32(0, ctx->r2);
    // 0x8030015C: srav        $t2, $t0, $t1
    ctx->r10 = S32(SIGNED(ctx->r8) >> (ctx->r9 & 31));
    // 0x80300160: addu        $t4, $t3, $t2
    ctx->r12 = ADD32(ctx->r11, ctx->r10);
    // 0x80300164: b           L_80300180
    // 0x80300168: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
        goto L_80300180;
    // 0x80300168: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
L_8030016C:
    // 0x8030016C: lh          $t6, 0x16($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X16);
    // 0x80300170: lh          $t5, 0x0($a1)
    ctx->r13 = MEM_H(ctx->r5, 0X0);
    // 0x80300174: srav        $t7, $v0, $t6
    ctx->r15 = S32(SIGNED(ctx->r2) >> (ctx->r14 & 31));
    // 0x80300178: subu        $t8, $t5, $t7
    ctx->r24 = SUB32(ctx->r13, ctx->r15);
    // 0x8030017C: sh          $t8, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r24;
L_80300180:
    // 0x80300180: lh          $v0, 0x1E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X1E);
    // 0x80300184: lh          $v1, 0x0($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X0);
    // 0x80300188: negu        $t0, $v0
    ctx->r8 = SUB32(0, ctx->r2);
    // 0x8030018C: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80300190: beq         $at, $zero, L_803001A4
    if (ctx->r1 == 0) {
        // 0x80300194: addiu       $t9, $v1, -0x1
        ctx->r25 = ADD32(ctx->r3, -0X1);
            goto L_803001A4;
    }
    // 0x80300194: addiu       $t9, $v1, -0x1
    ctx->r25 = ADD32(ctx->r3, -0X1);
    // 0x80300198: sh          $t9, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r25;
    // 0x8030019C: b           L_803001B8
    // 0x803001A0: lh          $v1, 0x0($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X0);
        goto L_803001B8;
    // 0x803001A0: lh          $v1, 0x0($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X0);
L_803001A4:
    // 0x803001A4: slt         $at, $v1, $t0
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x803001A8: beq         $at, $zero, L_803001B8
    if (ctx->r1 == 0) {
        // 0x803001AC: addiu       $t1, $v1, 0x1
        ctx->r9 = ADD32(ctx->r3, 0X1);
            goto L_803001B8;
    }
    // 0x803001AC: addiu       $t1, $v1, 0x1
    ctx->r9 = ADD32(ctx->r3, 0X1);
    // 0x803001B0: sh          $t1, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r9;
    // 0x803001B4: lh          $v1, 0x0($a1)
    ctx->r3 = MEM_H(ctx->r5, 0X0);
L_803001B8:
    // 0x803001B8: lh          $t3, 0x0($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X0);
    // 0x803001BC: addu        $t2, $t3, $v1
    ctx->r10 = ADD32(ctx->r11, ctx->r3);
    // 0x803001C0: sh          $t2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r10;
    // 0x803001C4: lh          $v0, 0x0($a0)
    ctx->r2 = MEM_H(ctx->r4, 0X0);
    // 0x803001C8: slt         $at, $v0, $a3
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x803001CC: beql        $at, $zero, L_803001E8
    if (ctx->r1 == 0) {
        // 0x803001D0: slt         $at, $a2, $v0
        ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r2) ? 1 : 0;
            goto L_803001E8;
    }
    goto skip_0;
    // 0x803001D0: slt         $at, $a2, $v0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r2) ? 1 : 0;
    skip_0:
    // 0x803001D4: sh          $a3, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r7;
    // 0x803001D8: lh          $t4, 0x1A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X1A);
    // 0x803001DC: jr          $ra
    // 0x803001E0: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
    return;
    // 0x803001E0: sh          $t4, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r12;
    // 0x803001E4: slt         $at, $a2, $v0
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r2) ? 1 : 0;
L_803001E8:
    // 0x803001E8: beq         $at, $zero, L_803001FC
    if (ctx->r1 == 0) {
        // 0x803001EC: nop
    
            goto L_803001FC;
    }
    // 0x803001EC: nop

    // 0x803001F0: sh          $a2, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r6;
    // 0x803001F4: lh          $t6, 0x1A($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X1A);
    // 0x803001F8: sh          $t6, 0x0($a1)
    MEM_H(0X0, ctx->r5) = ctx->r14;
L_803001FC:
    // 0x803001FC: jr          $ra
    // 0x80300200: nop

    return;
    // 0x80300200: nop

;}
RECOMP_FUNC void func_80300210_7118C0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80300210: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80300214: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80300218: addiu       $sp, $sp, -0xA0
    ctx->r29 = ADD32(ctx->r29, -0XA0);
    // 0x8030021C: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80300220: beq         $t6, $zero, L_80300278
    if (ctx->r14 == 0) {
        // 0x80300224: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_80300278;
    }
    // 0x80300224: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80300228: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8030022C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80300230: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x80300234: lh          $v0, 0xD6($t7)
    ctx->r2 = MEM_H(ctx->r15, 0XD6);
    // 0x80300238: beq         $v1, $v0, L_80300258
    if (ctx->r3 == ctx->r2) {
        // 0x8030023C: nop
    
            goto L_80300258;
    }
    // 0x8030023C: nop

    // 0x80300240: bne         $v0, $zero, L_80300260
    if (ctx->r2 != 0) {
        // 0x80300244: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80300260;
    }
    // 0x80300244: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80300248: beq         $v1, $at, L_80300258
    if (ctx->r3 == ctx->r1) {
        // 0x8030024C: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80300258;
    }
    // 0x8030024C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80300250: bnel        $v1, $at, L_80300264
    if (ctx->r3 != ctx->r1) {
        // 0x80300254: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_80300264;
    }
    goto skip_0;
    // 0x80300254: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    skip_0:
L_80300258:
    // 0x80300258: b           L_80300264
    // 0x8030025C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
        goto L_80300264;
    // 0x8030025C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
L_80300260:
    // 0x80300260: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_80300264:
    // 0x80300264: beq         $a0, $zero, L_80300278
    if (ctx->r4 == 0) {
        // 0x80300268: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_80300278;
    }
    // 0x80300268: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8030026C: sh          $zero, 0x88($sp)
    MEM_H(0X88, ctx->r29) = 0;
    // 0x80300270: b           L_80300310
    // 0x80300274: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_80300310;
    // 0x80300274: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_80300278:
    // 0x80300278: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030027C: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x80300280: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80300284: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x80300288: lh          $v0, 0xD6($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XD6);
    // 0x8030028C: addiu       $a3, $zero, 0x900
    ctx->r7 = ADD32(0, 0X900);
    // 0x80300290: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x80300294: beq         $v1, $v0, L_803002B4
    if (ctx->r3 == ctx->r2) {
        // 0x80300298: addiu       $t6, $zero, 0x9B
        ctx->r14 = ADD32(0, 0X9B);
            goto L_803002B4;
    }
    // 0x80300298: addiu       $t6, $zero, 0x9B
    ctx->r14 = ADD32(0, 0X9B);
    // 0x8030029C: bne         $v0, $zero, L_803002BC
    if (ctx->r2 != 0) {
        // 0x803002A0: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803002BC;
    }
    // 0x803002A0: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803002A4: beq         $v1, $at, L_803002B4
    if (ctx->r3 == ctx->r1) {
        // 0x803002A8: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803002B4;
    }
    // 0x803002A8: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803002AC: bnel        $v1, $at, L_803002C0
    if (ctx->r3 != ctx->r1) {
        // 0x803002B0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803002C0;
    }
    goto skip_1;
    // 0x803002B0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
L_803002B4:
    // 0x803002B4: b           L_803002C0
    // 0x803002B8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803002C0;
    // 0x803002B8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803002BC:
    // 0x803002BC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803002C0:
    // 0x803002C0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803002C4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803002C8: lhu         $t9, 0xBA($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0XBA);
    // 0x803002CC: addiu       $t7, $zero, 0x9B
    ctx->r15 = ADD32(0, 0X9B);
    // 0x803002D0: lw          $t8, 0xC($v1)
    ctx->r24 = MEM_W(ctx->r3, 0XC);
    // 0x803002D4: lw          $a0, 0x4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X4);
    // 0x803002D8: lw          $a1, 0x8($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X8);
    // 0x803002DC: sll         $t4, $t9, 15
    ctx->r12 = S32(ctx->r25 << 15);
    // 0x803002E0: addu        $a2, $t8, $t4
    ctx->r6 = ADD32(ctx->r24, ctx->r12);
    // 0x803002E4: sltiu       $t4, $v0, 0x1
    ctx->r12 = ctx->r2 < 0X1 ? 1 : 0;
    // 0x803002E8: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x803002EC: addiu       $t9, $zero, 0x9B
    ctx->r25 = ADD32(0, 0X9B);
    // 0x803002F0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x803002F4: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x803002F8: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x803002FC: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80300300: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80300304: jal         0x802E89F0
    // 0x80300308: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_0;
    // 0x80300308: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_0:
    // 0x8030030C: sh          $v0, 0x88($sp)
    MEM_H(0X88, ctx->r29) = ctx->r2;
L_80300310:
    // 0x80300310: lh          $t5, 0x88($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X88);
    // 0x80300314: bne         $t5, $zero, L_80301134
    if (ctx->r13 != 0) {
        // 0x80300318: nop
    
            goto L_80301134;
    }
    // 0x80300318: nop

    // 0x8030031C: jal         0x8038C768
    // 0x80300320: nop

    func_8038C768_79DE18(rdram, ctx);
        goto after_1;
    // 0x80300320: nop

    after_1:
    // 0x80300324: jal         0x8034B298
    // 0x80300328: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_2;
    // 0x80300328: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_2:
    // 0x8030032C: jal         0x8035D120
    // 0x80300330: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_3;
    // 0x80300330: nop

    after_3:
    // 0x80300334: jal         0x8035DA60
    // 0x80300338: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_4;
    // 0x80300338: nop

    after_4:
    // 0x8030033C: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x80300340: addiu       $a1, $zero, 0xF
    ctx->r5 = ADD32(0, 0XF);
    // 0x80300344: jal         0x8034B64C
    // 0x80300348: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    func_8034B64C_75CCFC(rdram, ctx);
        goto after_5;
    // 0x80300348: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    after_5:
    // 0x8030034C: jal         0x8035D734
    // 0x80300350: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_6;
    // 0x80300350: nop

    after_6:
    // 0x80300354: jal         0x8034BB38
    // 0x80300358: addiu       $a0, $zero, 0xC8
    ctx->r4 = ADD32(0, 0XC8);
    func_8034BB38_75D1E8(rdram, ctx);
        goto after_7;
    // 0x80300358: addiu       $a0, $zero, 0xC8
    ctx->r4 = ADD32(0, 0XC8);
    after_7:
    // 0x8030035C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80300360: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80300364: addiu       $t6, $zero, 0x8
    ctx->r14 = ADD32(0, 0X8);
    // 0x80300368: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    // 0x8030036C: lbu         $t7, 0x365($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X365);
    // 0x80300370: addiu       $at, $zero, 0x1D
    ctx->r1 = ADD32(0, 0X1D);
    // 0x80300374: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80300378: bnel        $t7, $at, L_8030071C
    if (ctx->r15 != ctx->r1) {
        // 0x8030037C: sb          $zero, 0x365($v1)
        MEM_B(0X365, ctx->r3) = 0;
            goto L_8030071C;
    }
    goto skip_2;
    // 0x8030037C: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
    skip_2:
    // 0x80300380: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x80300384: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80300388: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8030038C: lbu         $a0, 0x162($t9)
    ctx->r4 = MEM_BU(ctx->r25, 0X162);
    // 0x80300390: bne         $a0, $at, L_80300710
    if (ctx->r4 != ctx->r1) {
        // 0x80300394: nop
    
            goto L_80300710;
    }
    // 0x80300394: nop

    // 0x80300398: lhu         $t8, 0x5544($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X5544);
    // 0x8030039C: lhu         $t4, 0x32A($v1)
    ctx->r12 = MEM_HU(ctx->r3, 0X32A);
    // 0x803003A0: subu        $v0, $t8, $t4
    ctx->r2 = SUB32(ctx->r24, ctx->r12);
    // 0x803003A4: andi        $t5, $v0, 0xFFFF
    ctx->r13 = ctx->r2 & 0XFFFF;
    // 0x803003A8: slti        $at, $t5, 0xA
    ctx->r1 = SIGNED(ctx->r13) < 0XA ? 1 : 0;
    // 0x803003AC: beq         $at, $zero, L_8030046C
    if (ctx->r1 == 0) {
        // 0x803003B0: or          $a1, $t5, $zero
        ctx->r5 = ctx->r13 | 0;
            goto L_8030046C;
    }
    // 0x803003B0: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x803003B4: jal         0x8012826C
    // 0x803003B8: sw          $t5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r13;
    advance_random_seed(rdram, ctx);
        goto after_8;
    // 0x803003B8: sw          $t5, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r13;
    after_8:
    // 0x803003BC: lw          $a1, 0x4C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X4C);
    // 0x803003C0: andi        $t7, $v0, 0x1FF
    ctx->r15 = ctx->r2 & 0X1FF;
    // 0x803003C4: sll         $t9, $t7, 21
    ctx->r25 = S32(ctx->r15 << 21);
    // 0x803003C8: addiu       $v1, $a1, -0x2
    ctx->r3 = ADD32(ctx->r5, -0X2);
    // 0x803003CC: bgez        $v1, L_803003DC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x803003D0: sra         $t8, $t9, 16
        ctx->r24 = S32(SIGNED(ctx->r25) >> 16);
            goto L_803003DC;
    }
    // 0x803003D0: sra         $t8, $t9, 16
    ctx->r24 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803003D4: b           L_803003E0
    // 0x803003D8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
        goto L_803003E0;
    // 0x803003D8: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
L_803003DC:
    // 0x803003DC: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_803003E0:
    // 0x803003E0: addiu       $t6, $a0, 0x8
    ctx->r14 = ADD32(ctx->r4, 0X8);
    // 0x803003E4: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x803003E8: lw          $t4, 0x2EB0($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X2EB0);
    // 0x803003EC: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    // 0x803003F0: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803003F4: lw          $t6, 0x2EB4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2EB4);
    // 0x803003F8: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803003FC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300400: addu        $t5, $t4, $t8
    ctx->r13 = ADD32(ctx->r12, ctx->r24);
    // 0x80300404: lw          $t9, 0x2EB8($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB8);
    // 0x80300408: sw          $t5, 0x2EB0($at)
    MEM_W(0X2EB0, ctx->r1) = ctx->r13;
    // 0x8030040C: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x80300410: addu        $t7, $t6, $t8
    ctx->r15 = ADD32(ctx->r14, ctx->r24);
    // 0x80300414: sw          $t7, 0x2EB4($at)
    MEM_W(0X2EB4, ctx->r1) = ctx->r15;
    // 0x80300418: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8030041C: addu        $t8, $t9, $t8
    ctx->r24 = ADD32(ctx->r25, ctx->r24);
    // 0x80300420: sw          $t8, 0x2EB8($at)
    MEM_W(0X2EB8, ctx->r1) = ctx->r24;
    // 0x80300424: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80300428: bne         $a1, $at, L_8030071C
    if (ctx->r5 != ctx->r1) {
        // 0x8030042C: addiu       $a0, $zero, 0x53
        ctx->r4 = ADD32(0, 0X53);
            goto L_8030071C;
    }
    // 0x8030042C: addiu       $a0, $zero, 0x53
    ctx->r4 = ADD32(0, 0X53);
    // 0x80300430: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80300434: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80300438: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8030043C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80300440: lh          $t4, 0x8($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X8);
    // 0x80300444: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80300448: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8030044C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80300450: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x80300454: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80300458: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8030045C: jal         0x8032C360
    // 0x80300460: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    play_sound_effect_at_location(rdram, ctx);
        goto after_9;
    // 0x80300460: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_9:
    // 0x80300464: b           L_8030071C
    // 0x80300468: nop

        goto L_8030071C;
    // 0x80300468: nop

L_8030046C:
    // 0x8030046C: addiu       $at, $zero, 0xA
    ctx->r1 = ADD32(0, 0XA);
    // 0x80300470: bne         $a1, $at, L_80300498
    if (ctx->r5 != ctx->r1) {
        // 0x80300474: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_80300498;
    }
    // 0x80300474: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80300478: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030047C: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x80300480: lw          $t7, 0x0($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X0);
    // 0x80300484: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80300488: sh          $t6, 0x3A8($t7)
    MEM_H(0X3A8, ctx->r15) = ctx->r14;
    // 0x8030048C: lw          $t9, 0x0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X0);
    // 0x80300490: b           L_8030071C
    // 0x80300494: sh          $zero, 0x3AA($t9)
    MEM_H(0X3AA, ctx->r25) = 0;
        goto L_8030071C;
    // 0x80300494: sh          $zero, 0x3AA($t9)
    MEM_H(0X3AA, ctx->r25) = 0;
L_80300498:
    // 0x80300498: addiu       $v0, $v0, 0x5528
    ctx->r2 = ADD32(ctx->r2, 0X5528);
    // 0x8030049C: lw          $t8, 0x0($v0)
    ctx->r24 = MEM_W(ctx->r2, 0X0);
    // 0x803004A0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803004A4: lhu         $t4, 0x3A8($t8)
    ctx->r12 = MEM_HU(ctx->r24, 0X3A8);
    // 0x803004A8: bne         $t4, $at, L_80300708
    if (ctx->r12 != ctx->r1) {
        // 0x803004AC: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80300708;
    }
    // 0x803004AC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803004B0: bne         $a0, $at, L_80300708
    if (ctx->r4 != ctx->r1) {
        // 0x803004B4: addiu       $t5, $a1, -0xA
        ctx->r13 = ADD32(ctx->r5, -0XA);
            goto L_80300708;
    }
    // 0x803004B4: addiu       $t5, $a1, -0xA
    ctx->r13 = ADD32(ctx->r5, -0XA);
    // 0x803004B8: addiu       $t6, $zero, 0x10
    ctx->r14 = ADD32(0, 0X10);
    // 0x803004BC: andi        $t7, $t5, 0x7
    ctx->r15 = ctx->r13 & 0X7;
    // 0x803004C0: bne         $t7, $zero, L_8030071C
    if (ctx->r15 != 0) {
        // 0x803004C4: sh          $t6, 0x86($sp)
        MEM_H(0X86, ctx->r29) = ctx->r14;
            goto L_8030071C;
    }
    // 0x803004C4: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    // 0x803004C8: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x803004CC: jal         0x8037D340
    // 0x803004D0: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
    func_8037D340_78E9F0(rdram, ctx);
        goto after_10;
    // 0x803004D0: addiu       $a1, $zero, 0x100
    ctx->r5 = ADD32(0, 0X100);
    after_10:
    // 0x803004D4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803004D8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x803004DC: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803004E0: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x803004E4: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    // 0x803004E8: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x803004EC: addiu       $a0, $zero, 0x4B
    ctx->r4 = ADD32(0, 0X4B);
    // 0x803004F0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803004F4: lh          $t8, 0xC($v0)
    ctx->r24 = MEM_H(ctx->r2, 0XC);
    // 0x803004F8: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x803004FC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80300500: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80300504: jal         0x8032C360
    // 0x80300508: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    play_sound_effect_at_location(rdram, ctx);
        goto after_11;
    // 0x80300508: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_11:
    // 0x8030050C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80300510: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80300514: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80300518: addiu       $t7, $t7, 0x2C78
    ctx->r15 = ADD32(ctx->r15, 0X2C78);
    // 0x8030051C: lh          $a0, 0x302($t4)
    ctx->r4 = MEM_H(ctx->r12, 0X302);
    // 0x80300520: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300524: lh          $v1, 0x405A($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X405A);
    // 0x80300528: andi        $t5, $a0, 0xFF
    ctx->r13 = ctx->r4 & 0XFF;
    // 0x8030052C: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x80300530: addu        $t9, $t6, $t7
    ctx->r25 = ADD32(ctx->r14, ctx->r15);
    // 0x80300534: lh          $a1, 0x0($t9)
    ctx->r5 = MEM_H(ctx->r25, 0X0);
    // 0x80300538: addiu       $t8, $a0, 0x40
    ctx->r24 = ADD32(ctx->r4, 0X40);
    // 0x8030053C: andi        $t4, $t8, 0xFF
    ctx->r12 = ctx->r24 & 0XFF;
    // 0x80300540: multu       $v1, $a1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80300544: sll         $t5, $t4, 1
    ctx->r13 = S32(ctx->r12 << 1);
    // 0x80300548: addu        $t6, $t5, $t7
    ctx->r14 = ADD32(ctx->r13, ctx->r15);
    // 0x8030054C: lui         $a3, 0x8020
    ctx->r7 = S32(0X8020 << 16);
    // 0x80300550: lh          $a3, 0x4058($a3)
    ctx->r7 = MEM_H(ctx->r7, 0X4058);
    // 0x80300554: lh          $a2, 0x0($t6)
    ctx->r6 = MEM_H(ctx->r14, 0X0);
    // 0x80300558: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030055C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80300560: mflo        $t9
    ctx->r25 = lo;
    // 0x80300564: bgez        $t9, L_80300574
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80300568: sra         $t8, $t9, 4
        ctx->r24 = S32(SIGNED(ctx->r25) >> 4);
            goto L_80300574;
    }
    // 0x80300568: sra         $t8, $t9, 4
    ctx->r24 = S32(SIGNED(ctx->r25) >> 4);
    // 0x8030056C: addiu       $at, $t9, 0xF
    ctx->r1 = ADD32(ctx->r25, 0XF);
    // 0x80300570: sra         $t8, $at, 4
    ctx->r24 = S32(SIGNED(ctx->r1) >> 4);
L_80300574:
    // 0x80300574: multu       $a2, $a3
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80300578: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    // 0x8030057C: mflo        $t4
    ctx->r12 = lo;
    // 0x80300580: bgez        $t4, L_80300590
    if (SIGNED(ctx->r12) >= 0) {
        // 0x80300584: sra         $t5, $t4, 4
        ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
            goto L_80300590;
    }
    // 0x80300584: sra         $t5, $t4, 4
    ctx->r13 = S32(SIGNED(ctx->r12) >> 4);
    // 0x80300588: addiu       $at, $t4, 0xF
    ctx->r1 = ADD32(ctx->r12, 0XF);
    // 0x8030058C: sra         $t5, $at, 4
    ctx->r13 = S32(SIGNED(ctx->r1) >> 4);
L_80300590:
    // 0x80300590: multu       $a2, $v1
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80300594: addu        $t7, $t8, $t5
    ctx->r15 = ADD32(ctx->r24, ctx->r13);
    // 0x80300598: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8030059C: addu        $t4, $t6, $t9
    ctx->r12 = ADD32(ctx->r14, ctx->r25);
    // 0x803005A0: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x803005A4: mflo        $t8
    ctx->r24 = lo;
    // 0x803005A8: bgez        $t8, L_803005B8
    if (SIGNED(ctx->r24) >= 0) {
        // 0x803005AC: sra         $t5, $t8, 4
        ctx->r13 = S32(SIGNED(ctx->r24) >> 4);
            goto L_803005B8;
    }
    // 0x803005AC: sra         $t5, $t8, 4
    ctx->r13 = S32(SIGNED(ctx->r24) >> 4);
    // 0x803005B0: addiu       $at, $t8, 0xF
    ctx->r1 = ADD32(ctx->r24, 0XF);
    // 0x803005B4: sra         $t5, $at, 4
    ctx->r13 = S32(SIGNED(ctx->r1) >> 4);
L_803005B8:
    // 0x803005B8: multu       $a3, $a1
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803005BC: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x803005C0: sh          $zero, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = 0;
    // 0x803005C4: mflo        $t7
    ctx->r15 = lo;
    // 0x803005C8: bgez        $t7, L_803005D8
    if (SIGNED(ctx->r15) >= 0) {
        // 0x803005CC: sra         $t6, $t7, 4
        ctx->r14 = S32(SIGNED(ctx->r15) >> 4);
            goto L_803005D8;
    }
    // 0x803005CC: sra         $t6, $t7, 4
    ctx->r14 = S32(SIGNED(ctx->r15) >> 4);
    // 0x803005D0: addiu       $at, $t7, 0xF
    ctx->r1 = ADD32(ctx->r15, 0XF);
    // 0x803005D4: sra         $t6, $at, 4
    ctx->r14 = S32(SIGNED(ctx->r1) >> 4);
L_803005D8:
    // 0x803005D8: subu        $t9, $t5, $t6
    ctx->r25 = SUB32(ctx->r13, ctx->r14);
    // 0x803005DC: sra         $t4, $t9, 16
    ctx->r12 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803005E0: addu        $t7, $t4, $t8
    ctx->r15 = ADD32(ctx->r12, ctx->r24);
    // 0x803005E4: sh          $t7, 0x80($sp)
    MEM_H(0X80, ctx->r29) = ctx->r15;
L_803005E8:
    // 0x803005E8: jal         0x8012826C
    // 0x803005EC: nop

    advance_random_seed(rdram, ctx);
        goto after_12;
    // 0x803005EC: nop

    after_12:
    // 0x803005F0: jal         0x8012826C
    // 0x803005F4: sh          $v0, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_13;
    // 0x803005F4: sh          $v0, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r2;
    after_13:
    // 0x803005F8: jal         0x8012826C
    // 0x803005FC: sh          $v0, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_14;
    // 0x803005FC: sh          $v0, 0x5A($sp)
    MEM_H(0X5A, ctx->r29) = ctx->r2;
    after_14:
    // 0x80300600: jal         0x8012826C
    // 0x80300604: sh          $v0, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r2;
    advance_random_seed(rdram, ctx);
        goto after_15;
    // 0x80300604: sh          $v0, 0x5C($sp)
    MEM_H(0X5C, ctx->r29) = ctx->r2;
    after_15:
    // 0x80300608: lhu         $t6, 0x58($sp)
    ctx->r14 = MEM_HU(ctx->r29, 0X58);
    // 0x8030060C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80300610: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x80300614: lhu         $t7, 0x5A($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X5A);
    // 0x80300618: andi        $t9, $t6, 0xF
    ctx->r25 = ctx->r14 & 0XF;
    // 0x8030061C: addiu       $t4, $t9, -0x7
    ctx->r12 = ADD32(ctx->r25, -0X7);
    // 0x80300620: sll         $t8, $t4, 15
    ctx->r24 = S32(ctx->r12 << 15);
    // 0x80300624: lh          $a2, 0xC($t5)
    ctx->r6 = MEM_H(ctx->r13, 0XC);
    // 0x80300628: lhu         $t4, 0x5C($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X5C);
    // 0x8030062C: andi        $t5, $t7, 0xF
    ctx->r13 = ctx->r15 & 0XF;
    // 0x80300630: addiu       $t6, $t5, -0x7
    ctx->r14 = ADD32(ctx->r13, -0X7);
    // 0x80300634: sll         $t9, $t6, 15
    ctx->r25 = S32(ctx->r14 << 15);
    // 0x80300638: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8030063C: andi        $t8, $t4, 0xF
    ctx->r24 = ctx->r12 & 0XF;
    // 0x80300640: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x80300644: andi        $t5, $v0, 0x3
    ctx->r13 = ctx->r2 & 0X3;
    // 0x80300648: addiu       $t6, $t5, 0x4
    ctx->r14 = ADD32(ctx->r13, 0X4);
    // 0x8030064C: ori         $t9, $zero, 0xFFFF
    ctx->r25 = 0 | 0XFFFF;
    // 0x80300650: sll         $t7, $t8, 15
    ctx->r15 = S32(ctx->r24 << 15);
    // 0x80300654: ori         $t4, $zero, 0xCE73
    ctx->r12 = 0 | 0XCE73;
    // 0x80300658: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x8030065C: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80300660: sw          $t9, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r25;
    // 0x80300664: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80300668: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x8030066C: lh          $a0, 0x82($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X82);
    // 0x80300670: lh          $a1, 0x80($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X80);
    // 0x80300674: jal         0x802D5F4C
    // 0x80300678: addiu       $a3, $zero, 0x18
    ctx->r7 = ADD32(0, 0X18);
    create_particle_effect(rdram, ctx);
        goto after_16;
    // 0x80300678: addiu       $a3, $zero, 0x18
    ctx->r7 = ADD32(0, 0X18);
    after_16:
    // 0x8030067C: lh          $v1, 0x7E($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X7E);
    // 0x80300680: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x80300684: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x80300688: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8030068C: slti        $at, $t7, 0x3
    ctx->r1 = SIGNED(ctx->r15) < 0X3 ? 1 : 0;
    // 0x80300690: bne         $at, $zero, L_803005E8
    if (ctx->r1 != 0) {
        // 0x80300694: sh          $t7, 0x7E($sp)
        MEM_H(0X7E, ctx->r29) = ctx->r15;
            goto L_803005E8;
    }
    // 0x80300694: sh          $t7, 0x7E($sp)
    MEM_H(0X7E, ctx->r29) = ctx->r15;
    // 0x80300698: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x8030069C: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x803006A0: lui         $t6, 0x2
    ctx->r14 = S32(0X2 << 16);
    // 0x803006A4: addiu       $t9, $zero, 0x32
    ctx->r25 = ADD32(0, 0X32);
    // 0x803006A8: lh          $a2, 0xC($t5)
    ctx->r6 = MEM_H(ctx->r13, 0XC);
    // 0x803006AC: ori         $t4, $zero, 0x9CE7
    ctx->r12 = 0 | 0X9CE7;
    // 0x803006B0: addiu       $t8, $zero, 0x6319
    ctx->r24 = ADD32(0, 0X6319);
    // 0x803006B4: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x803006B8: sw          $t4, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r12;
    // 0x803006BC: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x803006C0: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x803006C4: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x803006C8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803006CC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x803006D0: lh          $a0, 0x82($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X82);
    // 0x803006D4: lh          $a1, 0x80($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X80);
    // 0x803006D8: jal         0x802D5F4C
    // 0x803006DC: addiu       $a3, $zero, 0x15
    ctx->r7 = ADD32(0, 0X15);
    create_particle_effect(rdram, ctx);
        goto after_17;
    // 0x803006DC: addiu       $a3, $zero, 0x15
    ctx->r7 = ADD32(0, 0X15);
    after_17:
    // 0x803006E0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803006E4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803006E8: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803006EC: lbu         $a0, 0x366($v1)
    ctx->r4 = MEM_BU(ctx->r3, 0X366);
    // 0x803006F0: beq         $a0, $at, L_8030071C
    if (ctx->r4 == ctx->r1) {
        // 0x803006F4: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_8030071C;
    }
    // 0x803006F4: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803006F8: beq         $a0, $at, L_8030071C
    if (ctx->r4 == ctx->r1) {
        // 0x803006FC: nop
    
            goto L_8030071C;
    }
    // 0x803006FC: nop

    // 0x80300700: b           L_8030071C
    // 0x80300704: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
        goto L_8030071C;
    // 0x80300704: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_80300708:
    // 0x80300708: b           L_8030071C
    // 0x8030070C: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
        goto L_8030071C;
    // 0x8030070C: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_80300710:
    // 0x80300710: b           L_8030071C
    // 0x80300714: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
        goto L_8030071C;
    // 0x80300714: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
    // 0x80300718: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_8030071C:
    // 0x8030071C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80300720: lhu         $t7, 0x2ECE($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X2ECE);
    // 0x80300724: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300728: addiu       $a0, $sp, 0x90
    ctx->r4 = ADD32(ctx->r29, 0X90);
    // 0x8030072C: beq         $t7, $zero, L_80300740
    if (ctx->r15 == 0) {
        // 0x80300730: addiu       $a1, $zero, 0x177
        ctx->r5 = ADD32(0, 0X177);
            goto L_80300740;
    }
    // 0x80300730: addiu       $a1, $zero, 0x177
    ctx->r5 = ADD32(0, 0X177);
    // 0x80300734: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
    // 0x80300738: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x8030073C: beq         $at, $zero, L_8030076C
    if (ctx->r1 == 0) {
        // 0x80300740: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8030076C;
    }
L_80300740:
    // 0x80300740: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80300744: jal         0x802B96D0
    // 0x80300748: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B96D0_6CAD80(rdram, ctx);
        goto after_18;
    // 0x80300748: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_18:
    // 0x8030074C: addiu       $a0, $zero, 0x339
    ctx->r4 = ADD32(0, 0X339);
    // 0x80300750: jal         0x802C1A88
    // 0x80300754: addiu       $a1, $sp, 0x90
    ctx->r5 = ADD32(ctx->r29, 0X90);
    func_802C1A88_6D3138(rdram, ctx);
        goto after_19;
    // 0x80300754: addiu       $a1, $sp, 0x90
    ctx->r5 = ADD32(ctx->r29, 0X90);
    after_19:
    // 0x80300758: addiu       $a0, $zero, 0x1C2
    ctx->r4 = ADD32(0, 0X1C2);
    // 0x8030075C: jal         0x802C5EF4
    // 0x80300760: addiu       $a1, $zero, 0x12C
    ctx->r5 = ADD32(0, 0X12C);
    func_802C5EF4_6D75A4(rdram, ctx);
        goto after_20;
    // 0x80300760: addiu       $a1, $zero, 0x12C
    ctx->r5 = ADD32(0, 0X12C);
    after_20:
    // 0x80300764: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300768: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_8030076C:
    // 0x8030076C: beq         $v0, $zero, L_803007EC
    if (ctx->r2 == 0) {
        // 0x80300770: nop
    
            goto L_803007EC;
    }
    // 0x80300770: nop

    // 0x80300774: jal         0x802DB8DC
    // 0x80300778: nop

    backup_joint_positions(rdram, ctx);
        goto after_21;
    // 0x80300778: nop

    after_21:
    // 0x8030077C: lui         $a0, 0x803F
    ctx->r4 = S32(0X803F << 16);
    // 0x80300780: lhu         $a0, 0x2ECE($a0)
    ctx->r4 = MEM_HU(ctx->r4, 0X2ECE);
    // 0x80300784: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80300788: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x8030078C: beq         $a0, $at, L_803007A8
    if (ctx->r4 == ctx->r1) {
        // 0x80300790: addiu       $a1, $a1, 0x534C
        ctx->r5 = ADD32(ctx->r5, 0X534C);
            goto L_803007A8;
    }
    // 0x80300790: addiu       $a1, $a1, 0x534C
    ctx->r5 = ADD32(ctx->r5, 0X534C);
    // 0x80300794: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80300798: beq         $a0, $at, L_803007CC
    if (ctx->r4 == ctx->r1) {
        // 0x8030079C: lui         $a1, 0x803A
        ctx->r5 = S32(0X803A << 16);
            goto L_803007CC;
    }
    // 0x8030079C: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x803007A0: b           L_803007EC
    // 0x803007A4: nop

        goto L_803007EC;
    // 0x803007A4: nop

L_803007A8:
    // 0x803007A8: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x803007AC: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x803007B0: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x803007B4: addiu       $a3, $a3, 0x536C
    ctx->r7 = ADD32(ctx->r7, 0X536C);
    // 0x803007B8: addiu       $a2, $a2, 0x5358
    ctx->r6 = ADD32(ctx->r6, 0X5358);
    // 0x803007BC: jal         0x802DB670
    // 0x803007C0: addiu       $a0, $a0, 0x5340
    ctx->r4 = ADD32(ctx->r4, 0X5340);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_22;
    // 0x803007C0: addiu       $a0, $a0, 0x5340
    ctx->r4 = ADD32(ctx->r4, 0X5340);
    after_22:
    // 0x803007C4: b           L_803007EC
    // 0x803007C8: nop

        goto L_803007EC;
    // 0x803007C8: nop

L_803007CC:
    // 0x803007CC: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x803007D0: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x803007D4: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x803007D8: addiu       $a3, $a3, 0x5398
    ctx->r7 = ADD32(ctx->r7, 0X5398);
    // 0x803007DC: addiu       $a2, $a2, 0x5358
    ctx->r6 = ADD32(ctx->r6, 0X5358);
    // 0x803007E0: addiu       $a0, $a0, 0x5340
    ctx->r4 = ADD32(ctx->r4, 0X5340);
    // 0x803007E4: jal         0x802DB670
    // 0x803007E8: addiu       $a1, $a1, 0x534C
    ctx->r5 = ADD32(ctx->r5, 0X534C);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_23;
    // 0x803007E8: addiu       $a1, $a1, 0x534C
    ctx->r5 = ADD32(ctx->r5, 0X534C);
    after_23:
L_803007EC:
    // 0x803007EC: jal         0x8038064C
    // 0x803007F0: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_24;
    // 0x803007F0: nop

    after_24:
    // 0x803007F4: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x803007F8: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x803007FC: lui         $t0, 0x4
    ctx->r8 = S32(0X4 << 16);
    // 0x80300800: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80300804: addu        $t0, $t0, $v1
    ctx->r8 = ADD32(ctx->r8, ctx->r3);
    // 0x80300808: lw          $t0, -0x76E8($t0)
    ctx->r8 = MEM_W(ctx->r8, -0X76E8);
    // 0x8030080C: addiu       $t5, $t0, 0x1E
    ctx->r13 = ADD32(ctx->r8, 0X1E);
    // 0x80300810: slti        $at, $t5, 0xFA
    ctx->r1 = SIGNED(ctx->r13) < 0XFA ? 1 : 0;
    // 0x80300814: beq         $at, $zero, L_80301124
    if (ctx->r1 == 0) {
        // 0x80300818: nop
    
            goto L_80301124;
    }
    // 0x80300818: nop

    // 0x8030081C: lbu         $t6, 0x2EDA($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2EDA);
    // 0x80300820: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80300824: beq         $t6, $zero, L_80301124
    if (ctx->r14 == 0) {
        // 0x80300828: nop
    
            goto L_80301124;
    }
    // 0x80300828: nop

    // 0x8030082C: lbu         $a1, 0x5538($a1)
    ctx->r5 = MEM_BU(ctx->r5, 0X5538);
    // 0x80300830: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300834: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80300838: bne         $a1, $zero, L_80300870
    if (ctx->r5 != 0) {
        // 0x8030083C: nop
    
            goto L_80300870;
    }
    // 0x8030083C: nop

    // 0x80300840: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x80300844: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80300848: beq         $v0, $zero, L_80300870
    if (ctx->r2 == 0) {
        // 0x8030084C: nop
    
            goto L_80300870;
    }
    // 0x8030084C: nop

    // 0x80300850: beq         $v0, $at, L_80300870
    if (ctx->r2 == ctx->r1) {
        // 0x80300854: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80300870;
    }
    // 0x80300854: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80300858: bne         $v0, $at, L_80301124
    if (ctx->r2 != ctx->r1) {
        // 0x8030085C: lui         $t9, 0x803F
        ctx->r25 = S32(0X803F << 16);
            goto L_80301124;
    }
    // 0x8030085C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300860: lbu         $t9, 0x2AA3($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2AA3);
    // 0x80300864: slti        $at, $t9, 0xB
    ctx->r1 = SIGNED(ctx->r25) < 0XB ? 1 : 0;
    // 0x80300868: bne         $at, $zero, L_80301124
    if (ctx->r1 != 0) {
        // 0x8030086C: nop
    
            goto L_80301124;
    }
    // 0x8030086C: nop

L_80300870:
    // 0x80300870: lh          $t4, 0x2C18($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C18);
    // 0x80300874: sll         $t9, $t0, 6
    ctx->r25 = S32(ctx->r8 << 6);
    // 0x80300878: bne         $t4, $zero, L_803008D0
    if (ctx->r12 != 0) {
        // 0x8030087C: nop
    
            goto L_803008D0;
    }
    // 0x8030087C: nop

    // 0x80300880: beq         $a1, $zero, L_803008D0
    if (ctx->r5 == 0) {
        // 0x80300884: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_803008D0;
    }
    // 0x80300884: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80300888: lh          $t8, 0x2A98($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2A98);
    // 0x8030088C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80300890: addiu       $t5, $t5, 0x28E0
    ctx->r13 = ADD32(ctx->r13, 0X28E0);
    // 0x80300894: sll         $t7, $t8, 3
    ctx->r15 = S32(ctx->r24 << 3);
    // 0x80300898: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x8030089C: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x803008A0: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x803008A4: sll         $t7, $t7, 2
    ctx->r15 = S32(ctx->r15 << 2);
    // 0x803008A8: addu        $v0, $t7, $t5
    ctx->r2 = ADD32(ctx->r15, ctx->r13);
    // 0x803008AC: lh          $a0, 0x0($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X0);
    // 0x803008B0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803008B4: beq         $a0, $at, L_803008C4
    if (ctx->r4 == ctx->r1) {
        // 0x803008B8: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803008C4;
    }
    // 0x803008B8: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803008BC: bne         $a0, $at, L_803008D0
    if (ctx->r4 != ctx->r1) {
        // 0x803008C0: nop
    
            goto L_803008D0;
    }
    // 0x803008C0: nop

L_803008C4:
    // 0x803008C4: lb          $t6, 0x64($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X64);
    // 0x803008C8: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x803008CC: beq         $t6, $at, L_80301124
    if (ctx->r14 == ctx->r1) {
        // 0x803008D0: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_80301124;
    }
L_803008D0:
    // 0x803008D0: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x803008D4: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x803008D8: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803008DC: lw          $t5, 0x2EB0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EB0);
    // 0x803008E0: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803008E4: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803008E8: addu        $a0, $v1, $t9
    ctx->r4 = ADD32(ctx->r3, ctx->r25);
    // 0x803008EC: lh          $t8, 0x302($t4)
    ctx->r24 = MEM_H(ctx->r12, 0X302);
    // 0x803008F0: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x803008F4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803008F8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x803008FC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300900: lw          $t9, 0x2EB4($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2EB4);
    // 0x80300904: negu        $t7, $t8
    ctx->r15 = SUB32(0, ctx->r24);
    // 0x80300908: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8030090C: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x80300910: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x80300914: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x80300918: lw          $t8, 0x2EB8($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB8);
    // 0x8030091C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80300920: bgez        $t5, L_80300930
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80300924: sra         $t6, $t5, 2
        ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
            goto L_80300930;
    }
    // 0x80300924: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80300928: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x8030092C: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_80300930:
    // 0x80300930: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80300934: bgez        $t9, L_80300944
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80300938: sra         $t4, $t9, 2
        ctx->r12 = S32(SIGNED(ctx->r25) >> 2);
            goto L_80300944;
    }
    // 0x80300938: sra         $t4, $t9, 2
    ctx->r12 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8030093C: addiu       $at, $t9, 0x3
    ctx->r1 = ADD32(ctx->r25, 0X3);
    // 0x80300940: sra         $t4, $at, 2
    ctx->r12 = S32(SIGNED(ctx->r1) >> 2);
L_80300944:
    // 0x80300944: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80300948: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x8030094C: lh          $t5, 0x2ED2($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED2);
    // 0x80300950: lw          $t6, 0x2ED4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2ED4);
    // 0x80300954: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x80300958: bgez        $t8, L_80300968
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8030095C: sra         $t7, $t8, 2
        ctx->r15 = S32(SIGNED(ctx->r24) >> 2);
            goto L_80300968;
    }
    // 0x8030095C: sra         $t7, $t8, 2
    ctx->r15 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80300960: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x80300964: sra         $t7, $at, 2
    ctx->r15 = S32(SIGNED(ctx->r1) >> 2);
L_80300968:
    // 0x80300968: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x8030096C: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x80300970: jal         0x80127640
    // 0x80300974: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    func_80127640(rdram, ctx);
        goto after_25;
    // 0x80300974: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    after_25:
    // 0x80300978: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x8030097C: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x80300980: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x80300984: lui         $t4, 0x104
    ctx->r12 = S32(0X104 << 16);
    // 0x80300988: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x8030098C: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80300990: sw          $t9, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r25;
    // 0x80300994: ori         $t4, $t4, 0x40
    ctx->r12 = ctx->r12 | 0X40;
    // 0x80300998: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x8030099C: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x803009A0: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x803009A4: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803009A8: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x803009AC: addu        $t8, $v1, $t3
    ctx->r24 = ADD32(ctx->r3, ctx->r11);
    // 0x803009B0: lw          $t7, 0x918($t8)
    ctx->r15 = MEM_W(ctx->r24, 0X918);
    // 0x803009B4: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803009B8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803009BC: sll         $t5, $t7, 6
    ctx->r13 = S32(ctx->r15 << 6);
    // 0x803009C0: addu        $t6, $v1, $t5
    ctx->r14 = ADD32(ctx->r3, ctx->r13);
    // 0x803009C4: addu        $t9, $t6, $at
    ctx->r25 = ADD32(ctx->r14, ctx->r1);
    // 0x803009C8: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x803009CC: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x803009D0: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803009D4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803009D8: addu        $t4, $v1, $t3
    ctx->r12 = ADD32(ctx->r3, ctx->r11);
    // 0x803009DC: lw          $t8, 0x918($t4)
    ctx->r24 = MEM_W(ctx->r12, 0X918);
    // 0x803009E0: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x803009E4: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x803009E8: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x803009EC: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x803009F0: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x803009F4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803009F8: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x803009FC: lhu         $a0, 0xBA($t5)
    ctx->r4 = MEM_HU(ctx->r13, 0XBA);
    // 0x80300A00: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x80300A04: sll         $t6, $a0, 2
    ctx->r14 = S32(ctx->r4 << 2);
    // 0x80300A08: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x80300A0C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80300A10: lwc1        $f8, -0x3060($at)
    ctx->f8.u32l = MEM_W(ctx->r1, -0X3060);
    // 0x80300A14: mflo        $t9
    ctx->r25 = lo;
    // 0x80300A18: sll         $t4, $t9, 16
    ctx->r12 = S32(ctx->r25 << 16);
    // 0x80300A1C: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80300A20: jal         0x8038C230
    // 0x80300A24: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_26;
    // 0x80300A24: swc1        $f8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f8.u32l;
    after_26:
    // 0x80300A28: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80300A2C: addiu       $t2, $t2, 0x552C
    ctx->r10 = ADD32(ctx->r10, 0X552C);
    // 0x80300A30: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x80300A34: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80300A38: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80300A3C: lh          $t7, 0x308($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X308);
    // 0x80300A40: lh          $t5, 0x30A($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X30A);
    // 0x80300A44: lh          $t9, 0x24($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X24);
    // 0x80300A48: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80300A4C: addu        $t6, $t7, $t5
    ctx->r14 = ADD32(ctx->r15, ctx->r13);
    // 0x80300A50: sll         $t4, $t9, 4
    ctx->r12 = S32(ctx->r25 << 4);
    // 0x80300A54: subu        $t8, $t6, $t4
    ctx->r24 = SUB32(ctx->r14, ctx->r12);
    // 0x80300A58: sh          $t8, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r24;
    // 0x80300A5C: lbu         $t7, 0x366($v1)
    ctx->r15 = MEM_BU(ctx->r3, 0X366);
    // 0x80300A60: beq         $t7, $at, L_80300ABC
    if (ctx->r15 == ctx->r1) {
        // 0x80300A64: lui         $t5, 0x803F
        ctx->r13 = S32(0X803F << 16);
            goto L_80300ABC;
    }
    // 0x80300A64: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80300A68: lb          $t5, 0x2D10($t5)
    ctx->r13 = MEM_B(ctx->r13, 0X2D10);
    // 0x80300A6C: addiu       $a0, $sp, 0x9A
    ctx->r4 = ADD32(ctx->r29, 0X9A);
    // 0x80300A70: addiu       $a1, $v1, 0x30A
    ctx->r5 = ADD32(ctx->r3, 0X30A);
    // 0x80300A74: bne         $t5, $zero, L_80300ABC
    if (ctx->r13 != 0) {
        // 0x80300A78: addiu       $a2, $zero, 0x14
        ctx->r6 = ADD32(0, 0X14);
            goto L_80300ABC;
    }
    // 0x80300A78: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    // 0x80300A7C: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x80300A80: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x80300A84: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80300A88: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80300A8C: lh          $t4, 0x24($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X24);
    // 0x80300A90: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x80300A94: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80300A98: sll         $t8, $t4, 4
    ctx->r24 = S32(ctx->r12 << 4);
    // 0x80300A9C: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x80300AA0: jal         0x80300130
    // 0x80300AA4: addiu       $a3, $zero, -0x14
    ctx->r7 = ADD32(0, -0X14);
    func_80300130_7117E0(rdram, ctx);
        goto after_27;
    // 0x80300AA4: addiu       $a3, $zero, -0x14
    ctx->r7 = ADD32(0, -0X14);
    after_27:
    // 0x80300AA8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80300AAC: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80300AB0: addiu       $t2, $t2, 0x552C
    ctx->r10 = ADD32(ctx->r10, 0X552C);
    // 0x80300AB4: b           L_80300ACC
    // 0x80300AB8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
        goto L_80300ACC;
    // 0x80300AB8: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
L_80300ABC:
    // 0x80300ABC: sh          $zero, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = 0;
    // 0x80300AC0: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x80300AC4: lh          $t5, 0x30A($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X30A);
    // 0x80300AC8: sh          $t5, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r13;
L_80300ACC:
    // 0x80300ACC: lh          $t9, 0x9A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X9A);
    // 0x80300AD0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80300AD4: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x80300AD8: sh          $t9, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r25;
    // 0x80300ADC: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80300AE0: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x80300AE4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80300AE8: lhu         $v0, 0x0($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X0);
    // 0x80300AEC: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80300AF0: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80300AF4: slti        $at, $v0, 0x2C
    ctx->r1 = SIGNED(ctx->r2) < 0X2C ? 1 : 0;
    // 0x80300AF8: beq         $at, $zero, L_80300B90
    if (ctx->r1 == 0) {
        // 0x80300AFC: lui         $a3, 0x803F
        ctx->r7 = S32(0X803F << 16);
            goto L_80300B90;
    }
    // 0x80300AFC: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80300B00: slti        $at, $v0, 0x29
    ctx->r1 = SIGNED(ctx->r2) < 0X29 ? 1 : 0;
    // 0x80300B04: bnel        $at, $zero, L_80300B94
    if (ctx->r1 != 0) {
        // 0x80300B08: lw          $v0, 0x0($t1)
        ctx->r2 = MEM_W(ctx->r9, 0X0);
            goto L_80300B94;
    }
    goto skip_3;
    // 0x80300B08: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    skip_3:
    // 0x80300B0C: lw          $v1, 0x0($t2)
    ctx->r3 = MEM_W(ctx->r10, 0X0);
    // 0x80300B10: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80300B14: addiu       $t0, $t0, 0x3FE0
    ctx->r8 = ADD32(ctx->r8, 0X3FE0);
    // 0x80300B18: lh          $t8, 0x30E($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B1C: lh          $t4, 0xA($t0)
    ctx->r12 = MEM_H(ctx->r8, 0XA);
    // 0x80300B20: lh          $t9, 0x9A($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X9A);
    // 0x80300B24: sll         $t7, $t8, 6
    ctx->r15 = S32(ctx->r24 << 6);
    // 0x80300B28: addu        $t5, $t4, $t7
    ctx->r13 = ADD32(ctx->r12, ctx->r15);
    // 0x80300B2C: sh          $t5, 0xA($t0)
    MEM_H(0XA, ctx->r8) = ctx->r13;
    // 0x80300B30: lh          $t6, 0x30E($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B34: lh          $t7, 0xA2($t0)
    ctx->r15 = MEM_H(ctx->r8, 0XA2);
    // 0x80300B38: sll         $t8, $t6, 6
    ctx->r24 = S32(ctx->r14 << 6);
    // 0x80300B3C: addu        $t4, $t9, $t8
    ctx->r12 = ADD32(ctx->r25, ctx->r24);
    // 0x80300B40: sh          $t4, 0x9A($t0)
    MEM_H(0X9A, ctx->r8) = ctx->r12;
    // 0x80300B44: lh          $t5, 0x30E($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B48: lh          $t8, 0xC($t0)
    ctx->r24 = MEM_H(ctx->r8, 0XC);
    // 0x80300B4C: sll         $t6, $t5, 6
    ctx->r14 = S32(ctx->r13 << 6);
    // 0x80300B50: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x80300B54: sh          $t9, 0xA2($t0)
    MEM_H(0XA2, ctx->r8) = ctx->r25;
    // 0x80300B58: lh          $t4, 0x30E($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B5C: lh          $t6, 0x9C($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X9C);
    // 0x80300B60: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x80300B64: subu        $t7, $t8, $t5
    ctx->r15 = SUB32(ctx->r24, ctx->r13);
    // 0x80300B68: sh          $t7, 0xC($t0)
    MEM_H(0XC, ctx->r8) = ctx->r15;
    // 0x80300B6C: lh          $t9, 0x30E($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B70: lh          $t5, 0xA4($t0)
    ctx->r13 = MEM_H(ctx->r8, 0XA4);
    // 0x80300B74: sll         $t4, $t9, 6
    ctx->r12 = S32(ctx->r25 << 6);
    // 0x80300B78: subu        $t8, $t6, $t4
    ctx->r24 = SUB32(ctx->r14, ctx->r12);
    // 0x80300B7C: sh          $t8, 0x9C($t0)
    MEM_H(0X9C, ctx->r8) = ctx->r24;
    // 0x80300B80: lh          $t7, 0x30E($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X30E);
    // 0x80300B84: sll         $t9, $t7, 6
    ctx->r25 = S32(ctx->r15 << 6);
    // 0x80300B88: subu        $t6, $t5, $t9
    ctx->r14 = SUB32(ctx->r13, ctx->r25);
    // 0x80300B8C: sh          $t6, 0xA4($t0)
    MEM_H(0XA4, ctx->r8) = ctx->r14;
L_80300B90:
    // 0x80300B90: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
L_80300B94:
    // 0x80300B94: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x80300B98: addiu       $t7, $zero, -0x1
    ctx->r15 = ADD32(0, -0X1);
    // 0x80300B9C: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80300BA0: sw          $t4, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r12;
    // 0x80300BA4: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80300BA8: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80300BAC: lw          $a3, 0x2EC0($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2EC0);
    // 0x80300BB0: lw          $a2, 0x2EBC($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EBC);
    // 0x80300BB4: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80300BB8: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x80300BBC: sll         $t6, $a3, 6
    ctx->r14 = S32(ctx->r7 << 6);
    // 0x80300BC0: sra         $a3, $t6, 6
    ctx->r7 = S32(SIGNED(ctx->r14) >> 6);
    // 0x80300BC4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300BC8: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80300BCC: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80300BD0: sra         $a2, $t5, 6
    ctx->r6 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80300BD4: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80300BD8: sll         $t7, $t8, 6
    ctx->r15 = S32(ctx->r24 << 6);
    // 0x80300BDC: sra         $t5, $t7, 6
    ctx->r13 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80300BE0: addiu       $t6, $t6, 0xE0
    ctx->r14 = ADD32(ctx->r14, 0XE0);
    // 0x80300BE4: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80300BE8: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80300BEC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300BF0: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80300BF4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300BF8: jal         0x802C78B0
    // 0x80300BFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_28;
    // 0x80300BFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_28:
    // 0x80300C00: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80300C04: lh          $v1, 0x5542($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X5542);
    // 0x80300C08: slti        $at, $v1, 0x78
    ctx->r1 = SIGNED(ctx->r3) < 0X78 ? 1 : 0;
    // 0x80300C0C: beq         $at, $zero, L_80300C58
    if (ctx->r1 == 0) {
        // 0x80300C10: sll         $t7, $v1, 5
        ctx->r15 = S32(ctx->r3 << 5);
            goto L_80300C58;
    }
    // 0x80300C10: sll         $t7, $v1, 5
    ctx->r15 = S32(ctx->r3 << 5);
    // 0x80300C14: andi        $t5, $t7, 0xFF
    ctx->r13 = ctx->r15 & 0XFF;
    // 0x80300C18: sll         $t9, $t5, 1
    ctx->r25 = S32(ctx->r13 << 1);
    // 0x80300C1C: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x80300C20: addu        $v0, $v0, $t9
    ctx->r2 = ADD32(ctx->r2, ctx->r25);
    // 0x80300C24: lh          $v0, 0x2C78($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2C78);
    // 0x80300C28: sra         $t6, $v0, 7
    ctx->r14 = S32(SIGNED(ctx->r2) >> 7);
    // 0x80300C2C: sll         $t4, $t6, 2
    ctx->r12 = S32(ctx->r14 << 2);
    // 0x80300C30: addu        $t4, $t4, $t6
    ctx->r12 = ADD32(ctx->r12, ctx->r14);
    // 0x80300C34: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x80300C38: subu        $t4, $t4, $t6
    ctx->r12 = SUB32(ctx->r12, ctx->r14);
    // 0x80300C3C: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x80300C40: subu        $t4, $t4, $t6
    ctx->r12 = SUB32(ctx->r12, ctx->r14);
    // 0x80300C44: sll         $t4, $t4, 1
    ctx->r12 = S32(ctx->r12 << 1);
    // 0x80300C48: sra         $t8, $t4, 8
    ctx->r24 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80300C4C: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x80300C50: b           L_80300C5C
    // 0x80300C54: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
        goto L_80300C5C;
    // 0x80300C54: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
L_80300C58:
    // 0x80300C58: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80300C5C:
    // 0x80300C5C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80300C60: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80300C64: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80300C68: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300C6C: lbu         $t6, 0x366($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X366);
    // 0x80300C70: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80300C74: beql        $t6, $at, L_80300C84
    if (ctx->r14 == ctx->r1) {
        // 0x80300C78: lh          $t4, 0xC($v1)
        ctx->r12 = MEM_H(ctx->r3, 0XC);
            goto L_80300C84;
    }
    goto skip_4;
    // 0x80300C78: lh          $t4, 0xC($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XC);
    skip_4:
    // 0x80300C7C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80300C80: lh          $t4, 0xC($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XC);
L_80300C84:
    // 0x80300C84: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80300C88: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80300C8C: addu        $t8, $t4, $v0
    ctx->r24 = ADD32(ctx->r12, ctx->r2);
    // 0x80300C90: sh          $t8, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r24;
    // 0x80300C94: lbu         $t7, 0x2EDD($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2EDD);
    // 0x80300C98: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80300C9C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80300CA0: bne         $t7, $zero, L_80300D0C
    if (ctx->r15 != 0) {
        // 0x80300CA4: lui         $a3, 0x803F
        ctx->r7 = S32(0X803F << 16);
            goto L_80300D0C;
    }
    // 0x80300CA4: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80300CA8: lw          $a3, 0x2EC0($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2EC0);
    // 0x80300CAC: lw          $a2, 0x2EBC($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EBC);
    // 0x80300CB0: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80300CB4: lw          $t8, 0x2EC4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EC4);
    // 0x80300CB8: sll         $t6, $a3, 6
    ctx->r14 = S32(ctx->r7 << 6);
    // 0x80300CBC: sra         $a3, $t6, 6
    ctx->r7 = S32(SIGNED(ctx->r14) >> 6);
    // 0x80300CC0: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300CC4: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80300CC8: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80300CCC: sra         $a2, $t5, 6
    ctx->r6 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80300CD0: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80300CD4: sll         $t7, $t8, 6
    ctx->r15 = S32(ctx->r24 << 6);
    // 0x80300CD8: sra         $t5, $t7, 6
    ctx->r13 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80300CDC: addiu       $t6, $t6, 0x900
    ctx->r14 = ADD32(ctx->r14, 0X900);
    // 0x80300CE0: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80300CE4: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80300CE8: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300CEC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80300CF0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300CF4: sh          $v0, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r2;
    // 0x80300CF8: jal         0x802C78B0
    // 0x80300CFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x80300CFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_29:
    // 0x80300D00: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300D04: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80300D08: lh          $v0, 0x8E($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X8E);
L_80300D0C:
    // 0x80300D0C: lh          $t4, 0xC($v1)
    ctx->r12 = MEM_H(ctx->r3, 0XC);
    // 0x80300D10: lh          $a2, 0x86($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X86);
    // 0x80300D14: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80300D18: subu        $t8, $t4, $v0
    ctx->r24 = SUB32(ctx->r12, ctx->r2);
    // 0x80300D1C: sh          $t8, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r24;
    // 0x80300D20: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80300D24: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80300D28: sll         $t7, $a2, 19
    ctx->r15 = S32(ctx->r6 << 19);
    // 0x80300D2C: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80300D30: addiu       $t6, $t6, 0x2D0
    ctx->r14 = ADD32(ctx->r14, 0X2D0);
    // 0x80300D34: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80300D38: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80300D3C: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80300D40: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80300D44: addiu       $a1, $zero, 0xF
    ctx->r5 = ADD32(0, 0XF);
    // 0x80300D48: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300D4C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80300D50: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300D54: jal         0x802C78B0
    // 0x80300D58: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_30;
    // 0x80300D58: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_30:
    // 0x80300D5C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80300D60: lh          $t4, 0x2ED0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2ED0);
    // 0x80300D64: lui         $t7, 0x400
    ctx->r15 = S32(0X400 << 16);
    // 0x80300D68: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80300D6C: addiu       $t7, $t7, 0x2D0
    ctx->r15 = ADD32(ctx->r15, 0X2D0);
    // 0x80300D70: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80300D74: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x80300D78: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80300D7C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80300D80: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80300D84: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80300D88: addiu       $a1, $zero, 0x12
    ctx->r5 = ADD32(0, 0X12);
    // 0x80300D8C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300D90: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300D94: jal         0x802C78B0
    // 0x80300D98: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x80300D98: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_31:
    // 0x80300D9C: lh          $v0, 0x9A($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X9A);
    // 0x80300DA0: lui         $t9, 0x8020
    ctx->r25 = S32(0X8020 << 16);
    // 0x80300DA4: lh          $t9, 0x3FEC($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X3FEC);
    // 0x80300DA8: sll         $t5, $v0, 3
    ctx->r13 = S32(ctx->r2 << 3);
    // 0x80300DAC: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80300DB0: subu        $t6, $t9, $t5
    ctx->r14 = SUB32(ctx->r25, ctx->r13);
    // 0x80300DB4: sh          $t6, 0x3FEC($at)
    MEM_H(0X3FEC, ctx->r1) = ctx->r14;
    // 0x80300DB8: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x80300DBC: lh          $t4, 0x407C($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X407C);
    // 0x80300DC0: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80300DC4: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80300DC8: subu        $t8, $t4, $t5
    ctx->r24 = SUB32(ctx->r12, ctx->r13);
    // 0x80300DCC: sh          $t8, 0x407C($at)
    MEM_H(0X407C, ctx->r1) = ctx->r24;
    // 0x80300DD0: lh          $t7, 0x4084($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4084);
    // 0x80300DD4: lui         $at, 0x8020
    ctx->r1 = S32(0X8020 << 16);
    // 0x80300DD8: addiu       $a0, $zero, 0x96
    ctx->r4 = ADD32(0, 0X96);
    // 0x80300DDC: subu        $t5, $t7, $t5
    ctx->r13 = SUB32(ctx->r15, ctx->r13);
    // 0x80300DE0: sh          $t5, 0x4084($at)
    MEM_H(0X4084, ctx->r1) = ctx->r13;
    // 0x80300DE4: jal         0x802C6FF4
    // 0x80300DE8: addiu       $a1, $zero, 0x258
    ctx->r5 = ADD32(0, 0X258);
    func_802C6FF4_6D86A4(rdram, ctx);
        goto after_32;
    // 0x80300DE8: addiu       $a1, $zero, 0x258
    ctx->r5 = ADD32(0, 0X258);
    after_32:
    // 0x80300DEC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80300DF0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80300DF4: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80300DF8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80300DFC: lh          $v0, 0x316($t9)
    ctx->r2 = MEM_H(ctx->r25, 0X316);
    // 0x80300E00: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300E04: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x80300E08: beq         $v0, $zero, L_80300EC0
    if (ctx->r2 == 0) {
        // 0x80300E0C: nop
    
            goto L_80300EC0;
    }
    // 0x80300E0C: nop

    // 0x80300E10: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80300E14: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    // 0x80300E18: mtc1        $zero, $f0
    ctx->f0.u32l = 0;
    // 0x80300E1C: addu        $t6, $t6, $v1
    ctx->r14 = ADD32(ctx->r14, ctx->r3);
    // 0x80300E20: lw          $t6, -0x76E8($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76E8);
    // 0x80300E24: cvt.s.w     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80300E28: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x80300E2C: sll         $t4, $t6, 6
    ctx->r12 = S32(ctx->r14 << 6);
    // 0x80300E30: addu        $a0, $v1, $t4
    ctx->r4 = ADD32(ctx->r3, ctx->r12);
    // 0x80300E34: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80300E38: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80300E3C: mtc1        $at, $f16
    ctx->f16.u32l = ctx->r1;
    // 0x80300E40: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x80300E44: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x80300E48: jal         0x8013FB74
    // 0x80300E4C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    guRotate(rdram, ctx);
        goto after_33;
    // 0x80300E4C: swc1        $f16, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f16.u32l;
    after_33:
    // 0x80300E50: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80300E54: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80300E58: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80300E5C: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x80300E60: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80300E64: sw          $t8, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r24;
    // 0x80300E68: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x80300E6C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300E70: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80300E74: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80300E78: lui         $t5, 0x4
    ctx->r13 = S32(0X4 << 16);
    // 0x80300E7C: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80300E80: addu        $t5, $t5, $v1
    ctx->r13 = ADD32(ctx->r13, ctx->r3);
    // 0x80300E84: lw          $t5, -0x76E8($t5)
    ctx->r13 = MEM_W(ctx->r13, -0X76E8);
    // 0x80300E88: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80300E8C: lui         $t8, 0x4
    ctx->r24 = S32(0X4 << 16);
    // 0x80300E90: sll         $t9, $t5, 6
    ctx->r25 = S32(ctx->r13 << 6);
    // 0x80300E94: addu        $t6, $v1, $t9
    ctx->r14 = ADD32(ctx->r3, ctx->r25);
    // 0x80300E98: addu        $t4, $t6, $at
    ctx->r12 = ADD32(ctx->r14, ctx->r1);
    // 0x80300E9C: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80300EA0: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80300EA4: lw          $v1, 0x4278($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4278);
    // 0x80300EA8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80300EAC: addu        $t8, $t8, $v1
    ctx->r24 = ADD32(ctx->r24, ctx->r3);
    // 0x80300EB0: lw          $t8, -0x76E8($t8)
    ctx->r24 = MEM_W(ctx->r24, -0X76E8);
    // 0x80300EB4: addu        $at, $at, $v1
    ctx->r1 = ADD32(ctx->r1, ctx->r3);
    // 0x80300EB8: addiu       $t7, $t8, 0x1
    ctx->r15 = ADD32(ctx->r24, 0X1);
    // 0x80300EBC: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
L_80300EC0:
    // 0x80300EC0: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80300EC4: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80300EC8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80300ECC: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80300ED0: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80300ED4: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80300ED8: sra         $a3, $t5, 6
    ctx->r7 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80300EDC: addiu       $t4, $t4, 0x5A0
    ctx->r12 = ADD32(ctx->r12, 0X5A0);
    // 0x80300EE0: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80300EE4: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80300EE8: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80300EEC: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80300EF0: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80300EF4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300EF8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80300EFC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300F00: jal         0x802C78B0
    // 0x80300F04: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_34;
    // 0x80300F04: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_34:
    // 0x80300F08: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300F0C: lbu         $v0, 0x2EDD($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2EDD);
    // 0x80300F10: addiu       $a0, $zero, 0x1A
    ctx->r4 = ADD32(0, 0X1A);
    // 0x80300F14: addiu       $a1, $zero, 0x1B
    ctx->r5 = ADD32(0, 0X1B);
    // 0x80300F18: bne         $v0, $zero, L_80300F64
    if (ctx->r2 != 0) {
        // 0x80300F1C: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_80300F64;
    }
    // 0x80300F1C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80300F20: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80300F24: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80300F28: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x80300F2C: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80300F30: sll         $t8, $a2, 6
    ctx->r24 = S32(ctx->r6 << 6);
    // 0x80300F34: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80300F38: addiu       $t9, $t9, 0x1F0
    ctx->r25 = ADD32(ctx->r25, 0X1F0);
    // 0x80300F3C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80300F40: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80300F44: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80300F48: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300F4C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80300F50: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300F54: jal         0x802C78B0
    // 0x80300F58: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_35;
    // 0x80300F58: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_35:
    // 0x80300F5C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300F60: lbu         $v0, 0x2EDD($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2EDD);
L_80300F64:
    // 0x80300F64: bne         $v0, $zero, L_80300FBC
    if (ctx->r2 != 0) {
        // 0x80300F68: addiu       $a0, $zero, 0x1C
        ctx->r4 = ADD32(0, 0X1C);
            goto L_80300FBC;
    }
    // 0x80300F68: addiu       $a0, $zero, 0x1C
    ctx->r4 = ADD32(0, 0X1C);
    // 0x80300F6C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80300F70: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80300F74: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80300F78: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80300F7C: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x80300F80: sll         $t6, $a2, 6
    ctx->r14 = S32(ctx->r6 << 6);
    // 0x80300F84: sra         $a3, $t6, 6
    ctx->r7 = S32(SIGNED(ctx->r14) >> 6);
    // 0x80300F88: addiu       $t5, $t5, 0x1F0
    ctx->r13 = ADD32(ctx->r13, 0X1F0);
    // 0x80300F8C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80300F90: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80300F94: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80300F98: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80300F9C: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80300FA0: addiu       $a1, $zero, 0x1D
    ctx->r5 = ADD32(0, 0X1D);
    // 0x80300FA4: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80300FA8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80300FAC: jal         0x802C78B0
    // 0x80300FB0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_36;
    // 0x80300FB0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_36:
    // 0x80300FB4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80300FB8: lbu         $v0, 0x2EDD($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2EDD);
L_80300FBC:
    // 0x80300FBC: bne         $v0, $zero, L_80301104
    if (ctx->r2 != 0) {
        // 0x80300FC0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_80301104;
    }
    // 0x80300FC0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80300FC4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80300FC8: addiu       $a1, $sp, 0x8C
    ctx->r5 = ADD32(ctx->r29, 0X8C);
    // 0x80300FCC: addiu       $a2, $sp, 0x8A
    ctx->r6 = ADD32(ctx->r29, 0X8A);
    // 0x80300FD0: lh          $a0, 0x326($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X326);
    // 0x80300FD4: addiu       $t9, $a0, 0x1
    ctx->r25 = ADD32(ctx->r4, 0X1);
    // 0x80300FD8: jal         0x8031A150
    // 0x80300FDC: sh          $t9, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r25;
    func_8031A150_72B800(rdram, ctx);
        goto after_37;
    // 0x80300FDC: sh          $t9, 0x326($v1)
    MEM_H(0X326, ctx->r3) = ctx->r25;
    after_37:
    // 0x80300FE0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80300FE4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80300FE8: addiu       $a1, $sp, 0x8C
    ctx->r5 = ADD32(ctx->r29, 0X8C);
    // 0x80300FEC: addiu       $a2, $sp, 0x8A
    ctx->r6 = ADD32(ctx->r29, 0X8A);
    // 0x80300FF0: jal         0x8031A278
    // 0x80300FF4: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_38;
    // 0x80300FF4: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_38:
    // 0x80300FF8: lh          $a2, 0x8C($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8C);
    // 0x80300FFC: lh          $t4, 0x8A($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X8A);
    // 0x80301000: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x80301004: sll         $t6, $a2, 1
    ctx->r14 = S32(ctx->r6 << 1);
    // 0x80301008: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x8030100C: sll         $t8, $t4, 1
    ctx->r24 = S32(ctx->r12 << 1);
    // 0x80301010: addu        $t7, $t7, $t8
    ctx->r15 = ADD32(ctx->r15, ctx->r24);
    // 0x80301014: addu        $a2, $a2, $t6
    ctx->r6 = ADD32(ctx->r6, ctx->r14);
    // 0x80301018: lh          $a2, -0x2A9C($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2A9C);
    // 0x8030101C: lh          $t7, -0x29E4($t7)
    ctx->r15 = MEM_H(ctx->r15, -0X29E4);
    // 0x80301020: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80301024: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80301028: addiu       $a1, $a1, 0xD20
    ctx->r5 = ADD32(ctx->r5, 0XD20);
    // 0x8030102C: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x80301030: sh          $a2, 0x8C($sp)
    MEM_H(0X8C, ctx->r29) = ctx->r6;
    // 0x80301034: jal         0x80356BD8
    // 0x80301038: sh          $t7, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r15;
    func_80356BD8_768288(rdram, ctx);
        goto after_39;
    // 0x80301038: sh          $t7, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r15;
    after_39:
    // 0x8030103C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301040: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80301044: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80301048: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x8030104C: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80301050: sll         $t5, $a2, 6
    ctx->r13 = S32(ctx->r6 << 6);
    // 0x80301054: sra         $a3, $t5, 6
    ctx->r7 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80301058: addiu       $t4, $t4, 0xAE0
    ctx->r12 = ADD32(ctx->r12, 0XAE0);
    // 0x8030105C: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80301060: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80301064: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80301068: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x8030106C: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301070: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301074: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301078: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x8030107C: jal         0x802C78B0
    // 0x80301080: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_40;
    // 0x80301080: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_40:
    // 0x80301084: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80301088: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x8030108C: addiu       $a1, $a1, 0xD20
    ctx->r5 = ADD32(ctx->r5, 0XD20);
    // 0x80301090: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x80301094: jal         0x80356BD8
    // 0x80301098: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    func_80356BD8_768288(rdram, ctx);
        goto after_41;
    // 0x80301098: lh          $a2, 0x8A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X8A);
    after_41:
    // 0x8030109C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x803010A0: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x803010A4: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803010A8: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x803010AC: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x803010B0: sll         $t8, $a2, 6
    ctx->r24 = S32(ctx->r6 << 6);
    // 0x803010B4: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x803010B8: addiu       $t9, $t9, 0xB40
    ctx->r25 = ADD32(ctx->r25, 0XB40);
    // 0x803010BC: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x803010C0: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x803010C4: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x803010C8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803010CC: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x803010D0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803010D4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803010D8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803010DC: jal         0x802C78B0
    // 0x803010E0: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_42;
    // 0x803010E0: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_42:
    // 0x803010E4: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x803010E8: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x803010EC: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x803010F0: lui         $t4, 0xE700
    ctx->r12 = S32(0XE700 << 16);
    // 0x803010F4: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803010F8: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x803010FC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80301100: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
L_80301104:
    // 0x80301104: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80301108: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x8030110C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80301110: lui         $t7, 0xBD00
    ctx->r15 = S32(0XBD00 << 16);
    // 0x80301114: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80301118: sw          $t8, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r24;
    // 0x8030111C: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80301120: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
L_80301124:
    // 0x80301124: jal         0x8035D6A0
    // 0x80301128: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_43;
    // 0x80301128: nop

    after_43:
    // 0x8030112C: b           L_80301140
    // 0x80301130: lh          $v0, 0x88($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X88);
        goto L_80301140;
    // 0x80301130: lh          $v0, 0x88($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X88);
L_80301134:
    // 0x80301134: jal         0x8035D6D0
    // 0x80301138: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_44;
    // 0x80301138: nop

    after_44:
    // 0x8030113C: lh          $v0, 0x88($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X88);
L_80301140:
    // 0x80301140: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80301144: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80301148: beq         $v0, $zero, L_80301158
    if (ctx->r2 == 0) {
        // 0x8030114C: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80301158;
    }
    // 0x8030114C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80301150: bne         $v0, $at, L_803011CC
    if (ctx->r2 != ctx->r1) {
        // 0x80301154: nop
    
            goto L_803011CC;
    }
    // 0x80301154: nop

L_80301158:
    // 0x80301158: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x8030115C: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80301160: lh          $t5, 0xC($v1)
    ctx->r13 = MEM_H(ctx->r3, 0XC);
    // 0x80301164: lhu         $t6, 0xBA($t9)
    ctx->r14 = MEM_HU(ctx->r25, 0XBA);
    // 0x80301168: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x8030116C: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x80301170: lh          $a3, 0x302($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X302);
    // 0x80301174: sra         $t4, $t6, 1
    ctx->r12 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80301178: addu        $a2, $t5, $t4
    ctx->r6 = ADD32(ctx->r13, ctx->r12);
    // 0x8030117C: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x80301180: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80301184: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80301188: lbu         $t8, 0x5538($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X5538);
    // 0x8030118C: lui         $t9, 0x103
    ctx->r25 = S32(0X103 << 16);
    // 0x80301190: addiu       $t9, $t9, 0x3190
    ctx->r25 = ADD32(ctx->r25, 0X3190);
    // 0x80301194: addiu       $t4, $zero, 0x9B
    ctx->r12 = ADD32(0, 0X9B);
    // 0x80301198: addiu       $t5, $zero, 0xF
    ctx->r13 = ADD32(0, 0XF);
    // 0x8030119C: addiu       $t6, $zero, 0xF
    ctx->r14 = ADD32(0, 0XF);
    // 0x803011A0: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x803011A4: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x803011A8: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x803011AC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803011B0: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x803011B4: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x803011B8: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x803011BC: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803011C0: jal         0x8034BD20
    // 0x803011C4: sw          $t8, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r24;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_45;
    // 0x803011C4: sw          $t8, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r24;
    after_45:
    // 0x803011C8: lh          $v0, 0x88($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X88);
L_803011CC:
    // 0x803011CC: bne         $v0, $zero, L_80301228
    if (ctx->r2 != 0) {
        // 0x803011D0: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80301228;
    }
    // 0x803011D0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803011D4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803011D8: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x803011DC: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x803011E0: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x803011E4: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x803011E8: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x803011EC: jal         0x80303820
    // 0x803011F0: addiu       $a3, $zero, 0x177
    ctx->r7 = ADD32(0, 0X177);
    func_80303820_714ED0(rdram, ctx);
        goto after_46;
    // 0x803011F0: addiu       $a3, $zero, 0x177
    ctx->r7 = ADD32(0, 0X177);
    after_46:
    // 0x803011F4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803011F8: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x803011FC: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301200: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    // 0x80301204: addiu       $a3, $zero, 0x14C
    ctx->r7 = ADD32(0, 0X14C);
    // 0x80301208: jal         0x80303820
    // 0x8030120C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_47;
    // 0x8030120C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_47:
    // 0x80301210: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301214: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80301218: jal         0x80303D50
    // 0x8030121C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    func_80303D50_715400(rdram, ctx);
        goto after_48;
    // 0x8030121C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    after_48:
    // 0x80301220: b           L_8030123C
    // 0x80301224: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
        goto L_8030123C;
    // 0x80301224: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80301228:
    // 0x80301228: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x8030122C: addiu       $a1, $zero, 0x465
    ctx->r5 = ADD32(0, 0X465);
    // 0x80301230: jal         0x80303D00
    // 0x80301234: addiu       $a2, $zero, 0x177
    ctx->r6 = ADD32(0, 0X177);
    func_80303D00_7153B0(rdram, ctx);
        goto after_49;
    // 0x80301234: addiu       $a2, $zero, 0x177
    ctx->r6 = ADD32(0, 0X177);
    after_49:
    // 0x80301238: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_8030123C:
    // 0x8030123C: addiu       $sp, $sp, 0xA0
    ctx->r29 = ADD32(ctx->r29, 0XA0);
    // 0x80301240: jr          $ra
    // 0x80301244: nop

    return;
    // 0x80301244: nop

;}
RECOMP_FUNC void func_80301248_7128F8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80301248: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030124C: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80301250: addiu       $sp, $sp, -0xA8
    ctx->r29 = ADD32(ctx->r29, -0XA8);
    // 0x80301254: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80301258: beq         $t6, $zero, L_803012B0
    if (ctx->r14 == 0) {
        // 0x8030125C: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_803012B0;
    }
    // 0x8030125C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80301260: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x80301264: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80301268: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x8030126C: lh          $v0, 0xD6($t7)
    ctx->r2 = MEM_H(ctx->r15, 0XD6);
    // 0x80301270: beq         $v1, $v0, L_80301290
    if (ctx->r3 == ctx->r2) {
        // 0x80301274: nop
    
            goto L_80301290;
    }
    // 0x80301274: nop

    // 0x80301278: bne         $v0, $zero, L_80301298
    if (ctx->r2 != 0) {
        // 0x8030127C: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80301298;
    }
    // 0x8030127C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80301280: beq         $v1, $at, L_80301290
    if (ctx->r3 == ctx->r1) {
        // 0x80301284: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80301290;
    }
    // 0x80301284: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80301288: bnel        $v1, $at, L_8030129C
    if (ctx->r3 != ctx->r1) {
        // 0x8030128C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_8030129C;
    }
    goto skip_0;
    // 0x8030128C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
L_80301290:
    // 0x80301290: b           L_8030129C
    // 0x80301294: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_8030129C;
    // 0x80301294: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80301298:
    // 0x80301298: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8030129C:
    // 0x8030129C: beq         $v0, $zero, L_803012B0
    if (ctx->r2 == 0) {
        // 0x803012A0: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_803012B0;
    }
    // 0x803012A0: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x803012A4: sh          $zero, 0x84($sp)
    MEM_H(0X84, ctx->r29) = 0;
    // 0x803012A8: b           L_80301348
    // 0x803012AC: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_80301348;
    // 0x803012AC: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_803012B0:
    // 0x803012B0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803012B4: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x803012B8: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x803012BC: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x803012C0: lh          $v0, 0xD6($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XD6);
    // 0x803012C4: addiu       $a3, $zero, 0x900
    ctx->r7 = ADD32(0, 0X900);
    // 0x803012C8: addiu       $t5, $zero, 0x6
    ctx->r13 = ADD32(0, 0X6);
    // 0x803012CC: beq         $v1, $v0, L_803012EC
    if (ctx->r3 == ctx->r2) {
        // 0x803012D0: addiu       $t6, $zero, 0x9B
        ctx->r14 = ADD32(0, 0X9B);
            goto L_803012EC;
    }
    // 0x803012D0: addiu       $t6, $zero, 0x9B
    ctx->r14 = ADD32(0, 0X9B);
    // 0x803012D4: bne         $v0, $zero, L_803012F4
    if (ctx->r2 != 0) {
        // 0x803012D8: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803012F4;
    }
    // 0x803012D8: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x803012DC: beq         $v1, $at, L_803012EC
    if (ctx->r3 == ctx->r1) {
        // 0x803012E0: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803012EC;
    }
    // 0x803012E0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803012E4: bnel        $v1, $at, L_803012F8
    if (ctx->r3 != ctx->r1) {
        // 0x803012E8: or          $v1, $zero, $zero
        ctx->r3 = 0 | 0;
            goto L_803012F8;
    }
    goto skip_1;
    // 0x803012E8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    skip_1:
L_803012EC:
    // 0x803012EC: b           L_803012F8
    // 0x803012F0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_803012F8;
    // 0x803012F0: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_803012F4:
    // 0x803012F4: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_803012F8:
    // 0x803012F8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803012FC: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80301300: lhu         $t9, 0xBA($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0XBA);
    // 0x80301304: addiu       $t7, $zero, 0x9B
    ctx->r15 = ADD32(0, 0X9B);
    // 0x80301308: lw          $t8, 0xC($v0)
    ctx->r24 = MEM_W(ctx->r2, 0XC);
    // 0x8030130C: lw          $a0, 0x4($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X4);
    // 0x80301310: lw          $a1, 0x8($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X8);
    // 0x80301314: sll         $t4, $t9, 15
    ctx->r12 = S32(ctx->r25 << 15);
    // 0x80301318: addu        $a2, $t8, $t4
    ctx->r6 = ADD32(ctx->r24, ctx->r12);
    // 0x8030131C: sltiu       $t4, $v1, 0x1
    ctx->r12 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x80301320: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80301324: addiu       $t9, $zero, 0x9B
    ctx->r25 = ADD32(0, 0X9B);
    // 0x80301328: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8030132C: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80301330: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80301334: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80301338: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8030133C: jal         0x802E89F0
    // 0x80301340: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_0;
    // 0x80301340: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_0:
    // 0x80301344: sh          $v0, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r2;
L_80301348:
    // 0x80301348: lh          $t5, 0x84($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X84);
    // 0x8030134C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80301350: beq         $t5, $at, L_803014D0
    if (ctx->r13 == ctx->r1) {
        // 0x80301354: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803014D0;
    }
    // 0x80301354: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80301358: beq         $t5, $at, L_803014D0
    if (ctx->r13 == ctx->r1) {
        // 0x8030135C: lui         $v0, 0x803D
        ctx->r2 = S32(0X803D << 16);
            goto L_803014D0;
    }
    // 0x8030135C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80301360: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80301364: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80301368: lbu         $v1, 0x366($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X366);
    // 0x8030136C: beq         $v1, $at, L_80301384
    if (ctx->r3 == ctx->r1) {
        // 0x80301370: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80301384;
    }
    // 0x80301370: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80301374: beq         $v1, $at, L_80301384
    if (ctx->r3 == ctx->r1) {
        // 0x80301378: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80301384;
    }
    // 0x80301378: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8030137C: bnel        $v1, $at, L_803014D4
    if (ctx->r3 != ctx->r1) {
        // 0x80301380: lh          $t5, 0x84($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X84);
            goto L_803014D4;
    }
    goto skip_2;
    // 0x80301380: lh          $t5, 0x84($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X84);
    skip_2:
L_80301384:
    // 0x80301384: lh          $t6, 0x30E($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X30E);
    // 0x80301388: lui         $at, 0x4059
    ctx->r1 = S32(0X4059 << 16);
    // 0x8030138C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80301390: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80301394: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80301398: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8030139C: cvt.d.w     $f6, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    ctx->f6.d = CVT_D_W(ctx->f4.u32l);
    // 0x803013A0: ldc1        $f18, -0x3058($at)
    CHECK_FR(ctx, 18);
    ctx->f18.u64 = LD(ctx->r1, -0X3058);
    // 0x803013A4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803013A8: div.d       $f10, $f6, $f8
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f8.d); 
    ctx->f10.d = DIV_D(ctx->f6.d, ctx->f8.d);
    // 0x803013AC: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x803013B0: mtc1        $zero, $f9
    ctx->f_odd[(9 - 1) * 2] = 0;
    // 0x803013B4: cvt.s.d     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    NAN_CHECK(ctx->f10.d); 
    ctx->f16.fl = CVT_S_D(ctx->f10.d);
    // 0x803013B8: cvt.d.s     $f0, $f16
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f16.fl); 
    ctx->f0.d = CVT_D_S(ctx->f16.fl);
    // 0x803013BC: c.lt.d      $f0, $f18
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    c1cs = ctx->f0.d < ctx->f18.d;
    // 0x803013C0: nop

    // 0x803013C4: bc1fl       L_803013E4
    if (!c1cs) {
        // 0x803013C8: mtc1        $at, $f2
        ctx->f2.u32l = ctx->r1;
            goto L_803013E4;
    }
    goto skip_3;
    // 0x803013C8: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
    skip_3:
    // 0x803013CC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803013D0: ldc1        $f4, -0x3050($at)
    CHECK_FR(ctx, 4);
    ctx->f4.u64 = LD(ctx->r1, -0X3050);
    // 0x803013D4: mul.d       $f6, $f0, $f4
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f4.d); 
    ctx->f6.d = MUL_D(ctx->f0.d, ctx->f4.d);
    // 0x803013D8: b           L_803013E8
    // 0x803013DC: cvt.s.d     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f2.fl = CVT_S_D(ctx->f6.d);
        goto L_803013E8;
    // 0x803013DC: cvt.s.d     $f2, $f6
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 6);
    NAN_CHECK(ctx->f6.d); 
    ctx->f2.fl = CVT_S_D(ctx->f6.d);
    // 0x803013E0: mtc1        $at, $f2
    ctx->f2.u32l = ctx->r1;
L_803013E4:
    // 0x803013E4: nop

L_803013E8:
    // 0x803013E8: cvt.d.s     $f10, $f2
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f2.fl); 
    ctx->f10.d = CVT_D_S(ctx->f2.fl);
    // 0x803013EC: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x803013F0: c.lt.d      $f8, $f10
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 10);
    c1cs = ctx->f8.d < ctx->f10.d;
    // 0x803013F4: nop

    // 0x803013F8: bc1fl       L_803014D4
    if (!c1cs) {
        // 0x803013FC: lh          $t5, 0x84($sp)
        ctx->r13 = MEM_H(ctx->r29, 0X84);
            goto L_803014D4;
    }
    goto skip_4;
    // 0x803013FC: lh          $t5, 0x84($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X84);
    skip_4:
    // 0x80301400: ldc1        $f18, -0x3048($at)
    CHECK_FR(ctx, 18);
    ctx->f18.u64 = LD(ctx->r1, -0X3048);
    // 0x80301404: lui         $at, 0x46A0
    ctx->r1 = S32(0X46A0 << 16);
    // 0x80301408: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x8030140C: mul.d       $f4, $f0, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f0.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f0.d, ctx->f18.d);
    // 0x80301410: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80301414: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80301418: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x8030141C: lui         $at, 0x3FE0
    ctx->r1 = S32(0X3FE0 << 16);
    // 0x80301420: mul.s       $f14, $f6, $f2
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f6.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f14.fl = MUL_S(ctx->f6.fl, ctx->f2.fl);
    // 0x80301424: sub.d       $f10, $f8, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f8.d); NAN_CHECK(ctx->f0.d); 
    ctx->f10.d = ctx->f8.d - ctx->f0.d;
    // 0x80301428: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x8030142C: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x80301430: mtc1        $zero, $f6
    ctx->f6.u32l = 0;
    // 0x80301434: mtc1        $at, $f7
    ctx->f_odd[(7 - 1) * 2] = ctx->r1;
    // 0x80301438: cvt.s.d     $f12, $f4
    CHECK_FR(ctx, 12);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f12.fl = CVT_S_D(ctx->f4.d);
    // 0x8030143C: mul.d       $f4, $f10, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f10.d, ctx->f18.d);
    // 0x80301440: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301444: cvt.d.s     $f10, $f14
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 14);
    NAN_CHECK(ctx->f14.fl); 
    ctx->f10.d = CVT_D_S(ctx->f14.fl);
    // 0x80301448: mfc1        $a3, $f12
    ctx->r7 = (int32_t)ctx->f12.u32l;
    // 0x8030144C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80301450: swc1        $f12, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->f12.u32l;
    // 0x80301454: swc1        $f14, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->f14.u32l;
    // 0x80301458: addiu       $a1, $zero, 0x1F
    ctx->r5 = ADD32(0, 0X1F);
    // 0x8030145C: add.d       $f8, $f6, $f4
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f6.d); NAN_CHECK(ctx->f4.d); 
    ctx->f8.d = ctx->f6.d + ctx->f4.d;
    // 0x80301460: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    // 0x80301464: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80301468: swc1        $f16, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->f16.u32l;
    // 0x8030146C: mul.d       $f18, $f10, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f8.d); 
    ctx->f18.d = MUL_D(ctx->f10.d, ctx->f8.d);
    // 0x80301470: trunc.w.d   $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x80301474: mfc1        $t9, $f6
    ctx->r25 = (int32_t)ctx->f6.u32l;
    // 0x80301478: jal         0x8013328C
    // 0x8030147C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_8013328C(rdram, ctx);
        goto after_1;
    // 0x8030147C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_1:
    // 0x80301480: lwc1        $f14, 0x54($sp)
    ctx->f14.u32l = MEM_W(ctx->r29, 0X54);
    // 0x80301484: lwc1        $f16, 0x7C($sp)
    ctx->f16.u32l = MEM_W(ctx->r29, 0X7C);
    // 0x80301488: lui         $at, 0x4008
    ctx->r1 = S32(0X4008 << 16);
    // 0x8030148C: mtc1        $at, $f9
    ctx->f_odd[(9 - 1) * 2] = ctx->r1;
    // 0x80301490: mul.s       $f4, $f14, $f16
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 14);
    CHECK_FR(ctx, 16);
    NAN_CHECK(ctx->f14.fl); NAN_CHECK(ctx->f16.fl); 
    ctx->f4.fl = MUL_S(ctx->f14.fl, ctx->f16.fl);
    // 0x80301494: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80301498: lwc1        $f12, 0x58($sp)
    ctx->f12.u32l = MEM_W(ctx->r29, 0X58);
    // 0x8030149C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x803014A0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x803014A4: mfc1        $a3, $f12
    ctx->r7 = (int32_t)ctx->f12.u32l;
    // 0x803014A8: addiu       $a1, $zero, 0x1C
    ctx->r5 = ADD32(0, 0X1C);
    // 0x803014AC: cvt.d.s     $f10, $f4
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.fl); 
    ctx->f10.d = CVT_D_S(ctx->f4.fl);
    // 0x803014B0: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
    // 0x803014B4: div.d       $f18, $f10, $f8
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 8);
    NAN_CHECK(ctx->f10.d); NAN_CHECK(ctx->f8.d); 
    ctx->f18.d = DIV_D(ctx->f10.d, ctx->f8.d);
    // 0x803014B8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803014BC: addiu       $a0, $a0, 0x2
    ctx->r4 = ADD32(ctx->r4, 0X2);
    // 0x803014C0: trunc.w.d   $f6, $f18
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 18);
    ctx->f6.u32l = TRUNC_W_D(ctx->f18.d);
    // 0x803014C4: mfc1        $t4, $f6
    ctx->r12 = (int32_t)ctx->f6.u32l;
    // 0x803014C8: jal         0x8013328C
    // 0x803014CC: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    func_8013328C(rdram, ctx);
        goto after_2;
    // 0x803014CC: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    after_2:
L_803014D0:
    // 0x803014D0: lh          $t5, 0x84($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X84);
L_803014D4:
    // 0x803014D4: bne         $t5, $zero, L_80301F04
    if (ctx->r13 != 0) {
        // 0x803014D8: nop
    
            goto L_80301F04;
    }
    // 0x803014D8: nop

    // 0x803014DC: jal         0x8034B298
    // 0x803014E0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_3;
    // 0x803014E0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_3:
    // 0x803014E4: jal         0x8035D120
    // 0x803014E8: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_4;
    // 0x803014E8: nop

    after_4:
    // 0x803014EC: jal         0x8035DA60
    // 0x803014F0: nop

    func_8035DA60_76F110(rdram, ctx);
        goto after_5;
    // 0x803014F0: nop

    after_5:
    // 0x803014F4: addiu       $a0, $zero, 0xE
    ctx->r4 = ADD32(0, 0XE);
    // 0x803014F8: addiu       $a1, $zero, 0xF
    ctx->r5 = ADD32(0, 0XF);
    // 0x803014FC: jal         0x8034B64C
    // 0x80301500: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    func_8034B64C_75CCFC(rdram, ctx);
        goto after_6;
    // 0x80301500: addiu       $a2, $zero, 0xA
    ctx->r6 = ADD32(0, 0XA);
    after_6:
    // 0x80301504: jal         0x8035D734
    // 0x80301508: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_7;
    // 0x80301508: nop

    after_7:
    // 0x8030150C: jal         0x8034BB38
    // 0x80301510: addiu       $a0, $zero, 0xC8
    ctx->r4 = ADD32(0, 0XC8);
    func_8034BB38_75D1E8(rdram, ctx);
        goto after_8;
    // 0x80301510: addiu       $a0, $zero, 0xC8
    ctx->r4 = ADD32(0, 0XC8);
    after_8:
    // 0x80301514: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80301518: lhu         $t6, 0x2ECE($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X2ECE);
    // 0x8030151C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80301520: addiu       $a0, $sp, 0x8C
    ctx->r4 = ADD32(ctx->r29, 0X8C);
    // 0x80301524: beq         $t6, $zero, L_80301538
    if (ctx->r14 == 0) {
        // 0x80301528: addiu       $a1, $zero, 0x177
        ctx->r5 = ADD32(0, 0X177);
            goto L_80301538;
    }
    // 0x80301528: addiu       $a1, $zero, 0x177
    ctx->r5 = ADD32(0, 0X177);
    // 0x8030152C: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
    // 0x80301530: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x80301534: beq         $at, $zero, L_80301564
    if (ctx->r1 == 0) {
        // 0x80301538: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_80301564;
    }
L_80301538:
    // 0x80301538: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8030153C: jal         0x802B96D0
    // 0x80301540: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B96D0_6CAD80(rdram, ctx);
        goto after_9;
    // 0x80301540: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_9:
    // 0x80301544: addiu       $a0, $zero, 0x339
    ctx->r4 = ADD32(0, 0X339);
    // 0x80301548: jal         0x802C1A88
    // 0x8030154C: addiu       $a1, $sp, 0x8C
    ctx->r5 = ADD32(ctx->r29, 0X8C);
    func_802C1A88_6D3138(rdram, ctx);
        goto after_10;
    // 0x8030154C: addiu       $a1, $sp, 0x8C
    ctx->r5 = ADD32(ctx->r29, 0X8C);
    after_10:
    // 0x80301550: addiu       $a0, $zero, 0x1C2
    ctx->r4 = ADD32(0, 0X1C2);
    // 0x80301554: jal         0x802C5EF4
    // 0x80301558: addiu       $a1, $zero, 0x12C
    ctx->r5 = ADD32(0, 0X12C);
    func_802C5EF4_6D75A4(rdram, ctx);
        goto after_11;
    // 0x80301558: addiu       $a1, $zero, 0x12C
    ctx->r5 = ADD32(0, 0X12C);
    after_11:
    // 0x8030155C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80301560: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_80301564:
    // 0x80301564: beq         $v0, $zero, L_803015E4
    if (ctx->r2 == 0) {
        // 0x80301568: nop
    
            goto L_803015E4;
    }
    // 0x80301568: nop

    // 0x8030156C: jal         0x802DB8DC
    // 0x80301570: nop

    backup_joint_positions(rdram, ctx);
        goto after_12;
    // 0x80301570: nop

    after_12:
    // 0x80301574: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80301578: lhu         $v0, 0x2ECE($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECE);
    // 0x8030157C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80301580: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x80301584: beq         $v0, $at, L_803015A0
    if (ctx->r2 == ctx->r1) {
        // 0x80301588: addiu       $a0, $a0, 0x53C4
        ctx->r4 = ADD32(ctx->r4, 0X53C4);
            goto L_803015A0;
    }
    // 0x80301588: addiu       $a0, $a0, 0x53C4
    ctx->r4 = ADD32(ctx->r4, 0X53C4);
    // 0x8030158C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80301590: beq         $v0, $at, L_803015C4
    if (ctx->r2 == ctx->r1) {
        // 0x80301594: lui         $a0, 0x803A
        ctx->r4 = S32(0X803A << 16);
            goto L_803015C4;
    }
    // 0x80301594: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x80301598: b           L_803015E4
    // 0x8030159C: nop

        goto L_803015E4;
    // 0x8030159C: nop

L_803015A0:
    // 0x803015A0: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x803015A4: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x803015A8: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x803015AC: addiu       $a3, $a3, 0x53E0
    ctx->r7 = ADD32(ctx->r7, 0X53E0);
    // 0x803015B0: addiu       $a2, $a2, 0x53D4
    ctx->r6 = ADD32(ctx->r6, 0X53D4);
    // 0x803015B4: jal         0x802DB670
    // 0x803015B8: addiu       $a1, $a1, 0x53CC
    ctx->r5 = ADD32(ctx->r5, 0X53CC);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_13;
    // 0x803015B8: addiu       $a1, $a1, 0x53CC
    ctx->r5 = ADD32(ctx->r5, 0X53CC);
    after_13:
    // 0x803015BC: b           L_803015E4
    // 0x803015C0: nop

        goto L_803015E4;
    // 0x803015C0: nop

L_803015C4:
    // 0x803015C4: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x803015C8: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x803015CC: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x803015D0: addiu       $a3, $a3, 0x53FC
    ctx->r7 = ADD32(ctx->r7, 0X53FC);
    // 0x803015D4: addiu       $a2, $a2, 0x53D4
    ctx->r6 = ADD32(ctx->r6, 0X53D4);
    // 0x803015D8: addiu       $a1, $a1, 0x53CC
    ctx->r5 = ADD32(ctx->r5, 0X53CC);
    // 0x803015DC: jal         0x802DB670
    // 0x803015E0: addiu       $a0, $a0, 0x53C4
    ctx->r4 = ADD32(ctx->r4, 0X53C4);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_14;
    // 0x803015E0: addiu       $a0, $a0, 0x53C4
    ctx->r4 = ADD32(ctx->r4, 0X53C4);
    after_14:
L_803015E4:
    // 0x803015E4: jal         0x8038064C
    // 0x803015E8: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_15;
    // 0x803015E8: nop

    after_15:
    // 0x803015EC: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x803015F0: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x803015F4: lui         $t1, 0x4
    ctx->r9 = S32(0X4 << 16);
    // 0x803015F8: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x803015FC: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x80301600: lw          $t1, -0x76E8($t1)
    ctx->r9 = MEM_W(ctx->r9, -0X76E8);
    // 0x80301604: addiu       $t7, $t1, 0x1E
    ctx->r15 = ADD32(ctx->r9, 0X1E);
    // 0x80301608: slti        $at, $t7, 0xFA
    ctx->r1 = SIGNED(ctx->r15) < 0XFA ? 1 : 0;
    // 0x8030160C: beq         $at, $zero, L_80301EF4
    if (ctx->r1 == 0) {
        // 0x80301610: nop
    
            goto L_80301EF4;
    }
    // 0x80301610: nop

    // 0x80301614: lbu         $t9, 0x2EDA($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2EDA);
    // 0x80301618: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030161C: beq         $t9, $zero, L_80301EF4
    if (ctx->r25 == 0) {
        // 0x80301620: nop
    
            goto L_80301EF4;
    }
    // 0x80301620: nop

    // 0x80301624: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80301628: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8030162C: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80301630: bne         $a0, $zero, L_80301668
    if (ctx->r4 != 0) {
        // 0x80301634: nop
    
            goto L_80301668;
    }
    // 0x80301634: nop

    // 0x80301638: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x8030163C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80301640: beq         $v0, $zero, L_80301668
    if (ctx->r2 == 0) {
        // 0x80301644: nop
    
            goto L_80301668;
    }
    // 0x80301644: nop

    // 0x80301648: beq         $v0, $at, L_80301668
    if (ctx->r2 == ctx->r1) {
        // 0x8030164C: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80301668;
    }
    // 0x8030164C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80301650: bne         $v0, $at, L_80301EF4
    if (ctx->r2 != ctx->r1) {
        // 0x80301654: lui         $t8, 0x803F
        ctx->r24 = S32(0X803F << 16);
            goto L_80301EF4;
    }
    // 0x80301654: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80301658: lbu         $t8, 0x2AA3($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X2AA3);
    // 0x8030165C: slti        $at, $t8, 0xB
    ctx->r1 = SIGNED(ctx->r24) < 0XB ? 1 : 0;
    // 0x80301660: bne         $at, $zero, L_80301EF4
    if (ctx->r1 != 0) {
        // 0x80301664: nop
    
            goto L_80301EF4;
    }
    // 0x80301664: nop

L_80301668:
    // 0x80301668: lh          $t4, 0x2C18($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C18);
    // 0x8030166C: sll         $t8, $t1, 6
    ctx->r24 = S32(ctx->r9 << 6);
    // 0x80301670: bne         $t4, $zero, L_803016C8
    if (ctx->r12 != 0) {
        // 0x80301674: nop
    
            goto L_803016C8;
    }
    // 0x80301674: nop

    // 0x80301678: beq         $a0, $zero, L_803016C8
    if (ctx->r4 == 0) {
        // 0x8030167C: lui         $t5, 0x803F
        ctx->r13 = S32(0X803F << 16);
            goto L_803016C8;
    }
    // 0x8030167C: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80301680: lh          $t5, 0x2A98($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2A98);
    // 0x80301684: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80301688: addiu       $t7, $t7, 0x28E0
    ctx->r15 = ADD32(ctx->r15, 0X28E0);
    // 0x8030168C: sll         $t6, $t5, 3
    ctx->r14 = S32(ctx->r13 << 3);
    // 0x80301690: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x80301694: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80301698: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x8030169C: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x803016A0: addu        $v0, $t6, $t7
    ctx->r2 = ADD32(ctx->r14, ctx->r15);
    // 0x803016A4: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x803016A8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803016AC: beq         $v1, $at, L_803016BC
    if (ctx->r3 == ctx->r1) {
        // 0x803016B0: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_803016BC;
    }
    // 0x803016B0: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x803016B4: bne         $v1, $at, L_803016C8
    if (ctx->r3 != ctx->r1) {
        // 0x803016B8: nop
    
            goto L_803016C8;
    }
    // 0x803016B8: nop

L_803016BC:
    // 0x803016BC: lb          $t9, 0x64($v0)
    ctx->r25 = MEM_B(ctx->r2, 0X64);
    // 0x803016C0: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x803016C4: beq         $t9, $at, L_80301EF4
    if (ctx->r25 == ctx->r1) {
        // 0x803016C8: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_80301EF4;
    }
L_803016C8:
    // 0x803016C8: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x803016CC: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x803016D0: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803016D4: lw          $t7, 0x2EB0($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EB0);
    // 0x803016D8: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x803016DC: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803016E0: addu        $a0, $t0, $t8
    ctx->r4 = ADD32(ctx->r8, ctx->r24);
    // 0x803016E4: lh          $t5, 0x302($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X302);
    // 0x803016E8: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x803016EC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803016F0: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x803016F4: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803016F8: lw          $t8, 0x2EB4($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X2EB4);
    // 0x803016FC: negu        $t6, $t5
    ctx->r14 = SUB32(0, ctx->r13);
    // 0x80301700: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80301704: lw          $a1, 0x4($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X4);
    // 0x80301708: lw          $a2, 0x8($v1)
    ctx->r6 = MEM_W(ctx->r3, 0X8);
    // 0x8030170C: lw          $a3, 0xC($v1)
    ctx->r7 = MEM_W(ctx->r3, 0XC);
    // 0x80301710: lw          $t5, 0x2EB8($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EB8);
    // 0x80301714: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80301718: bgez        $t7, L_80301728
    if (SIGNED(ctx->r15) >= 0) {
        // 0x8030171C: sra         $t9, $t7, 2
        ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
            goto L_80301728;
    }
    // 0x8030171C: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80301720: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x80301724: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_80301728:
    // 0x80301728: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    // 0x8030172C: bgez        $t8, L_8030173C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80301730: sra         $t4, $t8, 2
        ctx->r12 = S32(SIGNED(ctx->r24) >> 2);
            goto L_8030173C;
    }
    // 0x80301730: sra         $t4, $t8, 2
    ctx->r12 = S32(SIGNED(ctx->r24) >> 2);
    // 0x80301734: addiu       $at, $t8, 0x3
    ctx->r1 = ADD32(ctx->r24, 0X3);
    // 0x80301738: sra         $t4, $at, 2
    ctx->r12 = S32(SIGNED(ctx->r1) >> 2);
L_8030173C:
    // 0x8030173C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80301740: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80301744: lh          $t7, 0x2ED2($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED2);
    // 0x80301748: lw          $t9, 0x2ED4($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X2ED4);
    // 0x8030174C: sw          $t4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r12;
    // 0x80301750: bgez        $t5, L_80301760
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80301754: sra         $t6, $t5, 2
        ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
            goto L_80301760;
    }
    // 0x80301754: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80301758: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x8030175C: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_80301760:
    // 0x80301760: sw          $t6, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r14;
    // 0x80301764: sw          $t7, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r15;
    // 0x80301768: jal         0x80127640
    // 0x8030176C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    func_80127640(rdram, ctx);
        goto after_16;
    // 0x8030176C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    after_16:
    // 0x80301770: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x80301774: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x80301778: lw          $v0, 0x0($t1)
    ctx->r2 = MEM_W(ctx->r9, 0X0);
    // 0x8030177C: lui         $t4, 0x104
    ctx->r12 = S32(0X104 << 16);
    // 0x80301780: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80301784: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80301788: sw          $t8, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r24;
    // 0x8030178C: ori         $t4, $t4, 0x40
    ctx->r12 = ctx->r12 | 0X40;
    // 0x80301790: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x80301794: sw          $t4, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r12;
    // 0x80301798: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x8030179C: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x803017A0: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x803017A4: addu        $t5, $t0, $t3
    ctx->r13 = ADD32(ctx->r8, ctx->r11);
    // 0x803017A8: lw          $t6, 0x918($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X918);
    // 0x803017AC: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803017B0: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803017B4: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x803017B8: addu        $t9, $t0, $t7
    ctx->r25 = ADD32(ctx->r8, ctx->r15);
    // 0x803017BC: addu        $t8, $t9, $at
    ctx->r24 = ADD32(ctx->r25, ctx->r1);
    // 0x803017C0: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x803017C4: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x803017C8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803017CC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x803017D0: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x803017D4: lw          $t5, 0x918($t4)
    ctx->r13 = MEM_W(ctx->r12, 0X918);
    // 0x803017D8: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x803017DC: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803017E0: addiu       $t6, $t5, 0x1
    ctx->r14 = ADD32(ctx->r13, 0X1);
    // 0x803017E4: sw          $t6, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r14;
    // 0x803017E8: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x803017EC: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803017F0: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x803017F4: lhu         $a0, 0xBA($t7)
    ctx->r4 = MEM_HU(ctx->r15, 0XBA);
    // 0x803017F8: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x803017FC: sll         $t9, $a0, 3
    ctx->r25 = S32(ctx->r4 << 3);
    // 0x80301800: div         $zero, $t9, $at
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r1)));
    // 0x80301804: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80301808: lwc1        $f4, -0x3040($at)
    ctx->f4.u32l = MEM_W(ctx->r1, -0X3040);
    // 0x8030180C: mflo        $t8
    ctx->r24 = lo;
    // 0x80301810: sll         $t4, $t8, 16
    ctx->r12 = S32(ctx->r24 << 16);
    // 0x80301814: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80301818: jal         0x8038C230
    // 0x8030181C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_17;
    // 0x8030181C: swc1        $f4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f4.u32l;
    after_17:
    // 0x80301820: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80301824: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x80301828: addiu       $at, $zero, 0x7A
    ctx->r1 = ADD32(0, 0X7A);
    // 0x8030182C: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x80301830: beq         $v0, $at, L_8030183C
    if (ctx->r2 == ctx->r1) {
        // 0x80301834: addiu       $at, $zero, 0x7B
        ctx->r1 = ADD32(0, 0X7B);
            goto L_8030183C;
    }
    // 0x80301834: addiu       $at, $zero, 0x7B
    ctx->r1 = ADD32(0, 0X7B);
    // 0x80301838: bne         $v0, $at, L_80301A08
    if (ctx->r2 != ctx->r1) {
        // 0x8030183C: lui         $t6, 0x803D
        ctx->r14 = S32(0X803D << 16);
            goto L_80301A08;
    }
L_8030183C:
    // 0x8030183C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80301840: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80301844: lw          $v0, 0x20($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X20);
    // 0x80301848: lw          $t1, 0x1C($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X1C);
    // 0x8030184C: lh          $t7, 0x302($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X302);
    // 0x80301850: sll         $t9, $t7, 2
    ctx->r25 = S32(ctx->r15 << 2);
    // 0x80301854: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x80301858: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x8030185C: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x80301860: sll         $t9, $t9, 2
    ctx->r25 = S32(ctx->r25 << 2);
    // 0x80301864: addu        $t9, $t9, $t7
    ctx->r25 = ADD32(ctx->r25, ctx->r15);
    // 0x80301868: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x8030186C: negu        $t8, $t9
    ctx->r24 = SUB32(0, ctx->r25);
    // 0x80301870: bgez        $t8, L_80301880
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80301874: sra         $t4, $t8, 8
        ctx->r12 = S32(SIGNED(ctx->r24) >> 8);
            goto L_80301880;
    }
    // 0x80301874: sra         $t4, $t8, 8
    ctx->r12 = S32(SIGNED(ctx->r24) >> 8);
    // 0x80301878: addiu       $at, $t8, 0xFF
    ctx->r1 = ADD32(ctx->r24, 0XFF);
    // 0x8030187C: sra         $t4, $at, 8
    ctx->r12 = S32(SIGNED(ctx->r1) >> 8);
L_80301880:
    // 0x80301880: sll         $t5, $t4, 16
    ctx->r13 = S32(ctx->r12 << 16);
    // 0x80301884: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80301888: lui         $t9, 0x8015
    ctx->r25 = S32(0X8015 << 16);
    // 0x8030188C: addiu       $t9, $t9, 0x2350
    ctx->r25 = ADD32(ctx->r25, 0X2350);
    // 0x80301890: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80301894: addu        $a0, $t7, $t9
    ctx->r4 = ADD32(ctx->r15, ctx->r25);
    // 0x80301898: lh          $a1, 0x2D0($a0)
    ctx->r5 = MEM_H(ctx->r4, 0X2D0);
    // 0x8030189C: lh          $a2, 0x384($a0)
    ctx->r6 = MEM_H(ctx->r4, 0X384);
    // 0x803018A0: multu       $a1, $v0
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803018A4: mflo        $t8
    ctx->r24 = lo;
    // 0x803018A8: nop

    // 0x803018AC: nop

    // 0x803018B0: multu       $t1, $a2
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803018B4: mflo        $t4
    ctx->r12 = lo;
    // 0x803018B8: addu        $t0, $t8, $t4
    ctx->r8 = ADD32(ctx->r24, ctx->r12);
    // 0x803018BC: bgez        $t0, L_803018CC
    if (SIGNED(ctx->r8) >= 0) {
        // 0x803018C0: sra         $t5, $t0, 8
        ctx->r13 = S32(SIGNED(ctx->r8) >> 8);
            goto L_803018CC;
    }
    // 0x803018C0: sra         $t5, $t0, 8
    ctx->r13 = S32(SIGNED(ctx->r8) >> 8);
    // 0x803018C4: addiu       $at, $t0, 0xFF
    ctx->r1 = ADD32(ctx->r8, 0XFF);
    // 0x803018C8: sra         $t5, $at, 8
    ctx->r13 = S32(SIGNED(ctx->r1) >> 8);
L_803018CC:
    // 0x803018CC: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803018D0: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x803018D4: sra         $a3, $t0, 14
    ctx->r7 = S32(SIGNED(ctx->r8) >> 14);
    // 0x803018D8: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x803018DC: mflo        $t6
    ctx->r14 = lo;
    // 0x803018E0: nop

    // 0x803018E4: nop

    // 0x803018E8: multu       $a1, $t1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803018EC: negu        $t1, $a3
    ctx->r9 = SUB32(0, ctx->r7);
    // 0x803018F0: mflo        $t7
    ctx->r15 = lo;
    // 0x803018F4: subu        $v0, $t6, $t7
    ctx->r2 = SUB32(ctx->r14, ctx->r15);
    // 0x803018F8: bgez        $v0, L_80301908
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803018FC: sra         $t9, $v0, 8
        ctx->r25 = S32(SIGNED(ctx->r2) >> 8);
            goto L_80301908;
    }
    // 0x803018FC: sra         $t9, $v0, 8
    ctx->r25 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80301900: addiu       $at, $v0, 0xFF
    ctx->r1 = ADD32(ctx->r2, 0XFF);
    // 0x80301904: sra         $t9, $at, 8
    ctx->r25 = S32(SIGNED(ctx->r1) >> 8);
L_80301908:
    // 0x80301908: sra         $t8, $t9, 14
    ctx->r24 = S32(SIGNED(ctx->r25) >> 14);
    // 0x8030190C: slti        $at, $t1, 0x1F
    ctx->r1 = SIGNED(ctx->r9) < 0X1F ? 1 : 0;
    // 0x80301910: bne         $at, $zero, L_8030191C
    if (ctx->r1 != 0) {
        // 0x80301914: negu        $v0, $t8
        ctx->r2 = SUB32(0, ctx->r24);
            goto L_8030191C;
    }
    // 0x80301914: negu        $v0, $t8
    ctx->r2 = SUB32(0, ctx->r24);
    // 0x80301918: addiu       $t1, $zero, 0x1E
    ctx->r9 = ADD32(0, 0X1E);
L_8030191C:
    // 0x8030191C: slti        $at, $t1, -0x1E
    ctx->r1 = SIGNED(ctx->r9) < -0X1E ? 1 : 0;
    // 0x80301920: beql        $at, $zero, L_80301930
    if (ctx->r1 == 0) {
        // 0x80301924: slti        $at, $v0, 0x1F
        ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
            goto L_80301930;
    }
    goto skip_5;
    // 0x80301924: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    skip_5:
    // 0x80301928: addiu       $t1, $zero, -0x1E
    ctx->r9 = ADD32(0, -0X1E);
    // 0x8030192C: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
L_80301930:
    // 0x80301930: bnel        $at, $zero, L_80301940
    if (ctx->r1 != 0) {
        // 0x80301934: slti        $at, $v0, -0x1E
        ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
            goto L_80301940;
    }
    goto skip_6;
    // 0x80301934: slti        $at, $v0, -0x1E
    ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
    skip_6:
    // 0x80301938: addiu       $v0, $zero, 0x1E
    ctx->r2 = ADD32(0, 0X1E);
    // 0x8030193C: slti        $at, $v0, -0x1E
    ctx->r1 = SIGNED(ctx->r2) < -0X1E ? 1 : 0;
L_80301940:
    // 0x80301940: beql        $at, $zero, L_80301950
    if (ctx->r1 == 0) {
        // 0x80301944: mtc1        $v0, $f10
        ctx->f10.u32l = ctx->r2;
            goto L_80301950;
    }
    goto skip_7;
    // 0x80301944: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
    skip_7:
    // 0x80301948: addiu       $v0, $zero, -0x1E
    ctx->r2 = ADD32(0, -0X1E);
    // 0x8030194C: mtc1        $v0, $f10
    ctx->f10.u32l = ctx->r2;
L_80301950:
    // 0x80301950: mtc1        $t1, $f8
    ctx->f8.u32l = ctx->r9;
    // 0x80301954: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x80301958: cvt.s.w     $f10, $f10
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 10);
    ctx->f10.fl = CVT_S_W(ctx->f10.u32l);
    // 0x8030195C: lui         $t4, 0x4
    ctx->r12 = S32(0X4 << 16);
    // 0x80301960: addu        $t4, $t4, $t0
    ctx->r12 = ADD32(ctx->r12, ctx->r8);
    // 0x80301964: lw          $t4, -0x76E8($t4)
    ctx->r12 = MEM_W(ctx->r12, -0X76E8);
    // 0x80301968: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8030196C: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80301970: sll         $t5, $t4, 6
    ctx->r13 = S32(ctx->r12 << 6);
    // 0x80301974: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80301978: mfc1        $a1, $f10
    ctx->r5 = (int32_t)ctx->f10.u32l;
    // 0x8030197C: addu        $a0, $t0, $t5
    ctx->r4 = ADD32(ctx->r8, ctx->r13);
    // 0x80301980: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80301984: mfc1        $a2, $f8
    ctx->r6 = (int32_t)ctx->f8.u32l;
    // 0x80301988: jal         0x8013FD1C
    // 0x8030198C: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    guRotateRPY(rdram, ctx);
        goto after_18;
    // 0x8030198C: addiu       $a3, $zero, 0x0
    ctx->r7 = ADD32(0, 0X0);
    after_18:
    // 0x80301990: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80301994: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80301998: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x8030199C: lui         $t7, 0x100
    ctx->r15 = S32(0X100 << 16);
    // 0x803019A0: addiu       $t6, $v0, 0x8
    ctx->r14 = ADD32(ctx->r2, 0X8);
    // 0x803019A4: sw          $t6, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r14;
    // 0x803019A8: ori         $t7, $t7, 0x40
    ctx->r15 = ctx->r15 | 0X40;
    // 0x803019AC: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x803019B0: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x803019B4: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x803019B8: lui         $t9, 0x4
    ctx->r25 = S32(0X4 << 16);
    // 0x803019BC: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x803019C0: addu        $t9, $t9, $t0
    ctx->r25 = ADD32(ctx->r25, ctx->r8);
    // 0x803019C4: lw          $t9, -0x76E8($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X76E8);
    // 0x803019C8: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x803019CC: lui         $t6, 0x4
    ctx->r14 = S32(0X4 << 16);
    // 0x803019D0: sll         $t8, $t9, 6
    ctx->r24 = S32(ctx->r25 << 6);
    // 0x803019D4: addu        $t4, $t0, $t8
    ctx->r12 = ADD32(ctx->r8, ctx->r24);
    // 0x803019D8: addu        $t5, $t4, $at
    ctx->r13 = ADD32(ctx->r12, ctx->r1);
    // 0x803019DC: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x803019E0: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x803019E4: lw          $t0, 0x4278($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X4278);
    // 0x803019E8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x803019EC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803019F0: addu        $t6, $t6, $t0
    ctx->r14 = ADD32(ctx->r14, ctx->r8);
    // 0x803019F4: lw          $t6, -0x76E8($t6)
    ctx->r14 = MEM_W(ctx->r14, -0X76E8);
    // 0x803019F8: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x803019FC: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80301A00: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x80301A04: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
L_80301A08:
    // 0x80301A08: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80301A0C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80301A10: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80301A14: lh          $t5, 0x24($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X24);
    // 0x80301A18: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80301A1C: lh          $t9, 0x308($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X308);
    // 0x80301A20: lh          $t8, 0x30A($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X30A);
    // 0x80301A24: sll         $t6, $t5, 4
    ctx->r14 = S32(ctx->r13 << 4);
    // 0x80301A28: addu        $t4, $t9, $t8
    ctx->r12 = ADD32(ctx->r25, ctx->r24);
    // 0x80301A2C: subu        $t7, $t4, $t6
    ctx->r15 = SUB32(ctx->r12, ctx->r14);
    // 0x80301A30: sh          $t7, 0x96($sp)
    MEM_H(0X96, ctx->r29) = ctx->r15;
    // 0x80301A34: lbu         $t9, 0x366($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X366);
    // 0x80301A38: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80301A3C: beql        $t9, $at, L_80301A9C
    if (ctx->r25 == ctx->r1) {
        // 0x80301A40: sh          $zero, 0x30A($v0)
        MEM_H(0X30A, ctx->r2) = 0;
            goto L_80301A9C;
    }
    goto skip_8;
    // 0x80301A40: sh          $zero, 0x30A($v0)
    MEM_H(0X30A, ctx->r2) = 0;
    skip_8:
    // 0x80301A44: lb          $t8, 0x2D10($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X2D10);
    // 0x80301A48: addiu       $a0, $sp, 0x96
    ctx->r4 = ADD32(ctx->r29, 0X96);
    // 0x80301A4C: addiu       $a1, $v0, 0x30A
    ctx->r5 = ADD32(ctx->r2, 0X30A);
    // 0x80301A50: bne         $t8, $zero, L_80301A98
    if (ctx->r24 != 0) {
        // 0x80301A54: addiu       $a2, $zero, 0x14
        ctx->r6 = ADD32(0, 0X14);
            goto L_80301A98;
    }
    // 0x80301A54: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    // 0x80301A58: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x80301A5C: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x80301A60: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x80301A64: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80301A68: lh          $t6, 0x24($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X24);
    // 0x80301A6C: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x80301A70: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x80301A74: sll         $t7, $t6, 4
    ctx->r15 = S32(ctx->r14 << 4);
    // 0x80301A78: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80301A7C: jal         0x80300130
    // 0x80301A80: addiu       $a3, $zero, -0x14
    ctx->r7 = ADD32(0, -0X14);
    func_80300130_7117E0(rdram, ctx);
        goto after_19;
    // 0x80301A80: addiu       $a3, $zero, -0x14
    ctx->r7 = ADD32(0, -0X14);
    after_19:
    // 0x80301A84: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80301A88: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80301A8C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80301A90: b           L_80301AA8
    // 0x80301A94: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_80301AA8;
    // 0x80301A94: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_80301A98:
    // 0x80301A98: sh          $zero, 0x30A($v0)
    MEM_H(0X30A, ctx->r2) = 0;
L_80301A9C:
    // 0x80301A9C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80301AA0: lh          $t8, 0x30A($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X30A);
    // 0x80301AA4: sh          $t8, 0x96($sp)
    MEM_H(0X96, ctx->r29) = ctx->r24;
L_80301AA8:
    // 0x80301AA8: lh          $t5, 0x96($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X96);
    // 0x80301AAC: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80301AB0: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80301AB4: sh          $t5, 0x308($v0)
    MEM_H(0X308, ctx->r2) = ctx->r13;
    // 0x80301AB8: lh          $t4, 0x2ED0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2ED0);
    // 0x80301ABC: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x80301AC0: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80301AC4: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    // 0x80301AC8: lh          $t7, 0x30C($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X30C);
    // 0x80301ACC: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80301AD0: addiu       $t9, $t9, 0x840
    ctx->r25 = ADD32(ctx->r25, 0X840);
    // 0x80301AD4: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80301AD8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301ADC: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301AE0: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80301AE4: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301AE8: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80301AEC: jal         0x802C78B0
    // 0x80301AF0: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_20;
    // 0x80301AF0: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    after_20:
    // 0x80301AF4: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80301AF8: lw          $a3, 0x2EC0($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2EC0);
    // 0x80301AFC: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301B00: lw          $a2, 0x2EBC($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EBC);
    // 0x80301B04: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80301B08: lw          $t7, 0x2EC4($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EC4);
    // 0x80301B0C: sll         $t4, $a3, 6
    ctx->r12 = S32(ctx->r7 << 6);
    // 0x80301B10: sra         $a3, $t4, 6
    ctx->r7 = S32(SIGNED(ctx->r12) >> 6);
    // 0x80301B14: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80301B18: sll         $t8, $a2, 6
    ctx->r24 = S32(ctx->r6 << 6);
    // 0x80301B1C: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x80301B20: sra         $a2, $t8, 6
    ctx->r6 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80301B24: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80301B28: sll         $t9, $t7, 6
    ctx->r25 = S32(ctx->r15 << 6);
    // 0x80301B2C: sra         $t8, $t9, 6
    ctx->r24 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80301B30: addiu       $t4, $t4, 0xE0
    ctx->r12 = ADD32(ctx->r12, 0XE0);
    // 0x80301B34: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80301B38: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80301B3C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301B40: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80301B44: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301B48: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301B4C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301B50: jal         0x802C78B0
    // 0x80301B54: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_21;
    // 0x80301B54: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_21:
    // 0x80301B58: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80301B5C: lh          $v0, 0x5542($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5542);
    // 0x80301B60: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80301B64: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
    // 0x80301B68: slti        $at, $v0, 0x78
    ctx->r1 = SIGNED(ctx->r2) < 0X78 ? 1 : 0;
    // 0x80301B6C: beq         $at, $zero, L_80301BBC
    if (ctx->r1 == 0) {
        // 0x80301B70: addiu       $v1, $v1, 0x3FE0
        ctx->r3 = ADD32(ctx->r3, 0X3FE0);
            goto L_80301BBC;
    }
    // 0x80301B70: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80301B74: sll         $t9, $v0, 5
    ctx->r25 = S32(ctx->r2 << 5);
    // 0x80301B78: andi        $t8, $t9, 0xFF
    ctx->r24 = ctx->r25 & 0XFF;
    // 0x80301B7C: sll         $t5, $t8, 1
    ctx->r13 = S32(ctx->r24 << 1);
    // 0x80301B80: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80301B84: addu        $t0, $t0, $t5
    ctx->r8 = ADD32(ctx->r8, ctx->r13);
    // 0x80301B88: lh          $t0, 0x2C78($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X2C78);
    // 0x80301B8C: sra         $t4, $t0, 7
    ctx->r12 = S32(SIGNED(ctx->r8) >> 7);
    // 0x80301B90: sll         $t6, $t4, 2
    ctx->r14 = S32(ctx->r12 << 2);
    // 0x80301B94: addu        $t6, $t6, $t4
    ctx->r14 = ADD32(ctx->r14, ctx->r12);
    // 0x80301B98: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80301B9C: subu        $t6, $t6, $t4
    ctx->r14 = SUB32(ctx->r14, ctx->r12);
    // 0x80301BA0: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80301BA4: subu        $t6, $t6, $t4
    ctx->r14 = SUB32(ctx->r14, ctx->r12);
    // 0x80301BA8: sll         $t6, $t6, 1
    ctx->r14 = S32(ctx->r14 << 1);
    // 0x80301BAC: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x80301BB0: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80301BB4: b           L_80301BBC
    // 0x80301BB8: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
        goto L_80301BBC;
    // 0x80301BB8: sra         $t0, $t9, 16
    ctx->r8 = S32(SIGNED(ctx->r25) >> 16);
L_80301BBC:
    // 0x80301BBC: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80301BC0: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80301BC4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80301BC8: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80301BCC: lbu         $t4, 0x366($t5)
    ctx->r12 = MEM_BU(ctx->r13, 0X366);
    // 0x80301BD0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301BD4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80301BD8: beq         $t4, $at, L_80301BE4
    if (ctx->r12 == ctx->r1) {
        // 0x80301BDC: lui         $a2, 0x803F
        ctx->r6 = S32(0X803F << 16);
            goto L_80301BE4;
    }
    // 0x80301BDC: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301BE0: or          $t0, $zero, $zero
    ctx->r8 = 0 | 0;
L_80301BE4:
    // 0x80301BE4: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x80301BE8: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80301BEC: lui         $t8, 0xFA00
    ctx->r24 = S32(0XFA00 << 16);
    // 0x80301BF0: addu        $t7, $t6, $t0
    ctx->r15 = ADD32(ctx->r14, ctx->r8);
    // 0x80301BF4: sh          $t7, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r15;
    // 0x80301BF8: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80301BFC: addiu       $t5, $zero, -0x1
    ctx->r13 = ADD32(0, -0X1);
    // 0x80301C00: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80301C04: addiu       $t9, $v0, 0x8
    ctx->r25 = ADD32(ctx->r2, 0X8);
    // 0x80301C08: sw          $t9, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r25;
    // 0x80301C0C: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80301C10: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80301C14: lbu         $t4, 0x2EDD($t4)
    ctx->r12 = MEM_BU(ctx->r12, 0X2EDD);
    // 0x80301C18: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80301C1C: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80301C20: bne         $t4, $zero, L_80301C84
    if (ctx->r12 != 0) {
        // 0x80301C24: lui         $a3, 0x803F
        ctx->r7 = S32(0X803F << 16);
            goto L_80301C84;
    }
    // 0x80301C24: lui         $a3, 0x803F
    ctx->r7 = S32(0X803F << 16);
    // 0x80301C28: lw          $a3, 0x2EC0($a3)
    ctx->r7 = MEM_W(ctx->r7, 0X2EC0);
    // 0x80301C2C: lw          $a2, 0x2EBC($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EBC);
    // 0x80301C30: lw          $t5, 0x2EC4($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EC4);
    // 0x80301C34: sll         $t9, $a3, 6
    ctx->r25 = S32(ctx->r7 << 6);
    // 0x80301C38: sra         $a3, $t9, 6
    ctx->r7 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80301C3C: sll         $t6, $a2, 6
    ctx->r14 = S32(ctx->r6 << 6);
    // 0x80301C40: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80301C44: sra         $a2, $t6, 6
    ctx->r6 = S32(SIGNED(ctx->r14) >> 6);
    // 0x80301C48: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80301C4C: sll         $t4, $t5, 6
    ctx->r12 = S32(ctx->r13 << 6);
    // 0x80301C50: sra         $t6, $t4, 6
    ctx->r14 = S32(SIGNED(ctx->r12) >> 6);
    // 0x80301C54: addiu       $t9, $t9, 0x900
    ctx->r25 = ADD32(ctx->r25, 0X900);
    // 0x80301C58: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80301C5C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80301C60: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301C64: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301C68: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301C6C: sh          $t0, 0x8A($sp)
    MEM_H(0X8A, ctx->r29) = ctx->r8;
    // 0x80301C70: jal         0x802C78B0
    // 0x80301C74: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_22;
    // 0x80301C74: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    after_22:
    // 0x80301C78: lui         $v1, 0x8020
    ctx->r3 = S32(0X8020 << 16);
    // 0x80301C7C: addiu       $v1, $v1, 0x3FE0
    ctx->r3 = ADD32(ctx->r3, 0X3FE0);
    // 0x80301C80: lh          $t0, 0x8A($sp)
    ctx->r8 = MEM_H(ctx->r29, 0X8A);
L_80301C84:
    // 0x80301C84: lh          $t8, 0xC($v1)
    ctx->r24 = MEM_H(ctx->r3, 0XC);
    // 0x80301C88: lh          $v0, 0x96($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X96);
    // 0x80301C8C: lh          $t9, 0x9C($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X9C);
    // 0x80301C90: subu        $t5, $t8, $t0
    ctx->r13 = SUB32(ctx->r24, ctx->r8);
    // 0x80301C94: sh          $t5, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r13;
    // 0x80301C98: lh          $t6, 0xC($v1)
    ctx->r14 = MEM_H(ctx->r3, 0XC);
    // 0x80301C9C: lh          $t5, 0xA4($v1)
    ctx->r13 = MEM_H(ctx->r3, 0XA4);
    // 0x80301CA0: sll         $t4, $v0, 2
    ctx->r12 = S32(ctx->r2 << 2);
    // 0x80301CA4: subu        $t8, $t9, $t4
    ctx->r24 = SUB32(ctx->r25, ctx->r12);
    // 0x80301CA8: subu        $t7, $t6, $t4
    ctx->r15 = SUB32(ctx->r14, ctx->r12);
    // 0x80301CAC: subu        $t4, $t5, $t4
    ctx->r12 = SUB32(ctx->r13, ctx->r12);
    // 0x80301CB0: sh          $t7, 0xC($v1)
    MEM_H(0XC, ctx->r3) = ctx->r15;
    // 0x80301CB4: sh          $t8, 0x9C($v1)
    MEM_H(0X9C, ctx->r3) = ctx->r24;
    // 0x80301CB8: sh          $t4, 0xA4($v1)
    MEM_H(0XA4, ctx->r3) = ctx->r12;
    // 0x80301CBC: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301CC0: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80301CC4: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80301CC8: lh          $t9, 0x2ED0($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2ED0);
    // 0x80301CCC: lui         $t8, 0x400
    ctx->r24 = S32(0X400 << 16);
    // 0x80301CD0: sll         $t6, $a2, 6
    ctx->r14 = S32(ctx->r6 << 6);
    // 0x80301CD4: sra         $a3, $t6, 6
    ctx->r7 = S32(SIGNED(ctx->r14) >> 6);
    // 0x80301CD8: addiu       $t8, $t8, 0x5A0
    ctx->r24 = ADD32(ctx->r24, 0X5A0);
    // 0x80301CDC: sw          $t8, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r24;
    // 0x80301CE0: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80301CE4: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80301CE8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301CEC: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301CF0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301CF4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301CF8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301CFC: jal         0x802C78B0
    // 0x80301D00: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_23;
    // 0x80301D00: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_23:
    // 0x80301D04: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80301D08: lh          $t5, 0x2ED0($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED0);
    // 0x80301D0C: lui         $t4, 0x400
    ctx->r12 = S32(0X400 << 16);
    // 0x80301D10: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80301D14: addiu       $t4, $t4, 0x2D0
    ctx->r12 = ADD32(ctx->r12, 0X2D0);
    // 0x80301D18: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80301D1C: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80301D20: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80301D24: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80301D28: addiu       $a1, $zero, 0xF
    ctx->r5 = ADD32(0, 0XF);
    // 0x80301D2C: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301D30: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301D34: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301D38: jal         0x802C78B0
    // 0x80301D3C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_24;
    // 0x80301D3C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_24:
    // 0x80301D40: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80301D44: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80301D48: lui         $t9, 0x400
    ctx->r25 = S32(0X400 << 16);
    // 0x80301D4C: lui         $a2, 0x1
    ctx->r6 = S32(0X1 << 16);
    // 0x80301D50: addiu       $t9, $t9, 0x2D0
    ctx->r25 = ADD32(ctx->r25, 0X2D0);
    // 0x80301D54: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80301D58: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80301D5C: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80301D60: or          $a3, $a2, $zero
    ctx->r7 = ctx->r6 | 0;
    // 0x80301D64: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80301D68: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80301D6C: addiu       $a1, $zero, 0x12
    ctx->r5 = ADD32(0, 0X12);
    // 0x80301D70: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301D74: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301D78: jal         0x802C78B0
    // 0x80301D7C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_25;
    // 0x80301D7C: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_25:
    // 0x80301D80: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80301D84: lbu         $t8, 0x2EDD($t8)
    ctx->r24 = MEM_BU(ctx->r24, 0X2EDD);
    // 0x80301D88: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80301D8C: bne         $t8, $zero, L_80301ED4
    if (ctx->r24 != 0) {
        // 0x80301D90: nop
    
            goto L_80301ED4;
    }
    // 0x80301D90: nop

    // 0x80301D94: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80301D98: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x80301D9C: addiu       $a2, $sp, 0x86
    ctx->r6 = ADD32(ctx->r29, 0X86);
    // 0x80301DA0: lh          $a0, 0x326($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X326);
    // 0x80301DA4: addiu       $t5, $a0, 0x1
    ctx->r13 = ADD32(ctx->r4, 0X1);
    // 0x80301DA8: jal         0x8031A150
    // 0x80301DAC: sh          $t5, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r13;
    func_8031A150_72B800(rdram, ctx);
        goto after_26;
    // 0x80301DAC: sh          $t5, 0x326($v0)
    MEM_H(0X326, ctx->r2) = ctx->r13;
    after_26:
    // 0x80301DB0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301DB4: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80301DB8: addiu       $a1, $sp, 0x88
    ctx->r5 = ADD32(ctx->r29, 0X88);
    // 0x80301DBC: addiu       $a2, $sp, 0x86
    ctx->r6 = ADD32(ctx->r29, 0X86);
    // 0x80301DC0: jal         0x8031A278
    // 0x80301DC4: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    func_8031A278_72B928(rdram, ctx);
        goto after_27;
    // 0x80301DC4: addiu       $a0, $a0, 0x326
    ctx->r4 = ADD32(ctx->r4, 0X326);
    after_27:
    // 0x80301DC8: lh          $a2, 0x88($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X88);
    // 0x80301DCC: lh          $t6, 0x86($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X86);
    // 0x80301DD0: lui         $t9, 0x803C
    ctx->r25 = S32(0X803C << 16);
    // 0x80301DD4: sll         $t4, $a2, 1
    ctx->r12 = S32(ctx->r6 << 1);
    // 0x80301DD8: lui         $a2, 0x803C
    ctx->r6 = S32(0X803C << 16);
    // 0x80301DDC: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80301DE0: addu        $t9, $t9, $t7
    ctx->r25 = ADD32(ctx->r25, ctx->r15);
    // 0x80301DE4: addu        $a2, $a2, $t4
    ctx->r6 = ADD32(ctx->r6, ctx->r12);
    // 0x80301DE8: lh          $a2, -0x2A9C($a2)
    ctx->r6 = MEM_H(ctx->r6, -0X2A9C);
    // 0x80301DEC: lh          $t9, -0x29E4($t9)
    ctx->r25 = MEM_H(ctx->r25, -0X29E4);
    // 0x80301DF0: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80301DF4: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80301DF8: addiu       $a1, $a1, 0xD20
    ctx->r5 = ADD32(ctx->r5, 0XD20);
    // 0x80301DFC: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x80301E00: sh          $a2, 0x88($sp)
    MEM_H(0X88, ctx->r29) = ctx->r6;
    // 0x80301E04: jal         0x80356BD8
    // 0x80301E08: sh          $t9, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r25;
    func_80356BD8_768288(rdram, ctx);
        goto after_28;
    // 0x80301E08: sh          $t9, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r25;
    after_28:
    // 0x80301E0C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301E10: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80301E14: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80301E18: lh          $t4, 0x2ED0($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2ED0);
    // 0x80301E1C: lui         $t6, 0x400
    ctx->r14 = S32(0X400 << 16);
    // 0x80301E20: sll         $t8, $a2, 6
    ctx->r24 = S32(ctx->r6 << 6);
    // 0x80301E24: sra         $a3, $t8, 6
    ctx->r7 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80301E28: addiu       $t6, $t6, 0xAE0
    ctx->r14 = ADD32(ctx->r14, 0XAE0);
    // 0x80301E2C: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80301E30: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80301E34: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80301E38: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301E3C: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301E40: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301E44: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301E48: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301E4C: jal         0x802C78B0
    // 0x80301E50: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_29;
    // 0x80301E50: sw          $t4, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r12;
    after_29:
    // 0x80301E54: lui         $a0, 0x100
    ctx->r4 = S32(0X100 << 16);
    // 0x80301E58: lui         $a1, 0x100
    ctx->r5 = S32(0X100 << 16);
    // 0x80301E5C: addiu       $a1, $a1, 0xD20
    ctx->r5 = ADD32(ctx->r5, 0XD20);
    // 0x80301E60: addiu       $a0, $a0, 0xD00
    ctx->r4 = ADD32(ctx->r4, 0XD00);
    // 0x80301E64: jal         0x80356BD8
    // 0x80301E68: lh          $a2, 0x86($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X86);
    func_80356BD8_768288(rdram, ctx);
        goto after_30;
    // 0x80301E68: lh          $a2, 0x86($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X86);
    after_30:
    // 0x80301E6C: lui         $a2, 0x803F
    ctx->r6 = S32(0X803F << 16);
    // 0x80301E70: lw          $a2, 0x2EC8($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X2EC8);
    // 0x80301E74: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80301E78: lh          $t8, 0x2ED0($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2ED0);
    // 0x80301E7C: lui         $t5, 0x400
    ctx->r13 = S32(0X400 << 16);
    // 0x80301E80: sll         $t7, $a2, 6
    ctx->r15 = S32(ctx->r6 << 6);
    // 0x80301E84: sra         $a3, $t7, 6
    ctx->r7 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80301E88: addiu       $t5, $t5, 0xB40
    ctx->r13 = ADD32(ctx->r13, 0XB40);
    // 0x80301E8C: sw          $t5, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r13;
    // 0x80301E90: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80301E94: sw          $a3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r7;
    // 0x80301E98: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80301E9C: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301EA0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80301EA4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80301EA8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301EAC: jal         0x802C78B0
    // 0x80301EB0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_31;
    // 0x80301EB0: sw          $t8, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r24;
    after_31:
    // 0x80301EB4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80301EB8: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80301EBC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80301EC0: lui         $t6, 0xE700
    ctx->r14 = S32(0XE700 << 16);
    // 0x80301EC4: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80301EC8: sw          $t4, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r12;
    // 0x80301ECC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80301ED0: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
L_80301ED4:
    // 0x80301ED4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x80301ED8: lw          $v0, -0x6178($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X6178);
    // 0x80301EDC: lui         $at, 0x801E
    ctx->r1 = S32(0X801E << 16);
    // 0x80301EE0: lui         $t9, 0xBD00
    ctx->r25 = S32(0XBD00 << 16);
    // 0x80301EE4: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80301EE8: sw          $t7, -0x6178($at)
    MEM_W(-0X6178, ctx->r1) = ctx->r15;
    // 0x80301EEC: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80301EF0: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
L_80301EF4:
    // 0x80301EF4: jal         0x8035D6A0
    // 0x80301EF8: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_32;
    // 0x80301EF8: nop

    after_32:
    // 0x80301EFC: b           L_80301F10
    // 0x80301F00: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
        goto L_80301F10;
    // 0x80301F00: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
L_80301F04:
    // 0x80301F04: jal         0x8035D6D0
    // 0x80301F08: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_33;
    // 0x80301F08: nop

    after_33:
    // 0x80301F0C: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
L_80301F10:
    // 0x80301F10: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80301F14: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80301F18: beq         $t8, $zero, L_80301F28
    if (ctx->r24 == 0) {
        // 0x80301F1C: lui         $t4, 0x803D
        ctx->r12 = S32(0X803D << 16);
            goto L_80301F28;
    }
    // 0x80301F1C: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x80301F20: bnel        $t8, $at, L_80301F9C
    if (ctx->r24 != ctx->r1) {
        // 0x80301F24: lh          $t8, 0x84($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X84);
            goto L_80301F9C;
    }
    goto skip_9;
    // 0x80301F24: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
    skip_9:
L_80301F28:
    // 0x80301F28: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80301F2C: lw          $t4, 0x5524($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X5524);
    // 0x80301F30: lh          $t5, 0xC($v0)
    ctx->r13 = MEM_H(ctx->r2, 0XC);
    // 0x80301F34: lhu         $t6, 0xBA($t4)
    ctx->r14 = MEM_HU(ctx->r12, 0XBA);
    // 0x80301F38: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x80301F3C: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x80301F40: lh          $a3, 0x302($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X302);
    // 0x80301F44: sra         $t7, $t6, 1
    ctx->r15 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80301F48: addu        $a2, $t5, $t7
    ctx->r6 = ADD32(ctx->r13, ctx->r15);
    // 0x80301F4C: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x80301F50: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80301F54: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80301F58: lbu         $t9, 0x5538($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X5538);
    // 0x80301F5C: lui         $t4, 0x103
    ctx->r12 = S32(0X103 << 16);
    // 0x80301F60: addiu       $t4, $t4, 0x3190
    ctx->r12 = ADD32(ctx->r12, 0X3190);
    // 0x80301F64: addiu       $t7, $zero, 0x9B
    ctx->r15 = ADD32(0, 0X9B);
    // 0x80301F68: addiu       $t5, $zero, 0xF
    ctx->r13 = ADD32(0, 0XF);
    // 0x80301F6C: addiu       $t6, $zero, 0xF
    ctx->r14 = ADD32(0, 0XF);
    // 0x80301F70: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80301F74: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x80301F78: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80301F7C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80301F80: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80301F84: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80301F88: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80301F8C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80301F90: jal         0x8034BD20
    // 0x80301F94: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_34;
    // 0x80301F94: sw          $t9, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r25;
    after_34:
    // 0x80301F98: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
L_80301F9C:
    // 0x80301F9C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301FA0: addiu       $a1, $zero, 0x465
    ctx->r5 = ADD32(0, 0X465);
    // 0x80301FA4: bne         $t8, $zero, L_80302000
    if (ctx->r24 != 0) {
        // 0x80301FA8: addiu       $a2, $zero, 0x177
        ctx->r6 = ADD32(0, 0X177);
            goto L_80302000;
    }
    // 0x80301FA8: addiu       $a2, $zero, 0x177
    ctx->r6 = ADD32(0, 0X177);
    // 0x80301FAC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301FB0: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x80301FB4: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80301FB8: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80301FBC: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80301FC0: addiu       $a2, $zero, 0x1
    ctx->r6 = ADD32(0, 0X1);
    // 0x80301FC4: jal         0x80303820
    // 0x80301FC8: addiu       $a3, $zero, 0x177
    ctx->r7 = ADD32(0, 0X177);
    func_80303820_714ED0(rdram, ctx);
        goto after_35;
    // 0x80301FC8: addiu       $a3, $zero, 0x177
    ctx->r7 = ADD32(0, 0X177);
    after_35:
    // 0x80301FCC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301FD0: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80301FD4: addiu       $a1, $zero, 0x13
    ctx->r5 = ADD32(0, 0X13);
    // 0x80301FD8: addiu       $a2, $zero, 0x14
    ctx->r6 = ADD32(0, 0X14);
    // 0x80301FDC: addiu       $a3, $zero, 0x14C
    ctx->r7 = ADD32(0, 0X14C);
    // 0x80301FE0: jal         0x80303820
    // 0x80301FE4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_36;
    // 0x80301FE4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_36:
    // 0x80301FE8: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80301FEC: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80301FF0: jal         0x80303D50
    // 0x80301FF4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    func_80303D50_715400(rdram, ctx);
        goto after_37;
    // 0x80301FF4: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    after_37:
    // 0x80301FF8: b           L_8030200C
    // 0x80301FFC: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
        goto L_8030200C;
    // 0x80301FFC: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80302000:
    // 0x80302000: jal         0x80303D00
    // 0x80302004: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    func_80303D00_7153B0(rdram, ctx);
        goto after_38;
    // 0x80302004: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    after_38:
    // 0x80302008: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_8030200C:
    // 0x8030200C: addiu       $sp, $sp, 0xA8
    ctx->r29 = ADD32(ctx->r29, 0XA8);
    // 0x80302010: jr          $ra
    // 0x80302014: nop

    return;
    // 0x80302014: nop

;}
RECOMP_FUNC void func_80302018_7136C8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302018: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030201C: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80302020: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80302024: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80302028: lbu         $t7, 0x162($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X162);
    // 0x8030202C: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80302030: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302034: bne         $t7, $at, L_80302068
    if (ctx->r15 != ctx->r1) {
        // 0x80302038: addiu       $v1, $v1, 0x552C
        ctx->r3 = ADD32(ctx->r3, 0X552C);
            goto L_80302068;
    }
    // 0x80302038: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x8030203C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80302040: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80302044: lbu         $t8, 0x365($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X365);
    // 0x80302048: bne         $t8, $zero, L_80302068
    if (ctx->r24 != 0) {
        // 0x8030204C: nop
    
            goto L_80302068;
    }
    // 0x8030204C: nop

    // 0x80302050: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x80302054: addiu       $t0, $zero, 0x1D
    ctx->r8 = ADD32(0, 0X1D);
    // 0x80302058: sh          $t9, 0x32A($v0)
    MEM_H(0X32A, ctx->r2) = ctx->r25;
    // 0x8030205C: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x80302060: b           L_80302070
    // 0x80302064: sb          $t0, 0x365($t1)
    MEM_B(0X365, ctx->r9) = ctx->r8;
        goto L_80302070;
    // 0x80302064: sb          $t0, 0x365($t1)
    MEM_B(0X365, ctx->r9) = ctx->r8;
L_80302068:
    // 0x80302068: jal         0x8035E3E8
    // 0x8030206C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    recharge_skill(rdram, ctx);
        goto after_0;
    // 0x8030206C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_0:
L_80302070:
    // 0x80302070: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80302074: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80302078: jr          $ra
    // 0x8030207C: nop

    return;
    // 0x8030207C: nop

;}
RECOMP_FUNC void func_80302080_713730(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302080: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80302084: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80302088: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x8030208C: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80302090: lbu         $t7, 0x162($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X162);
    // 0x80302094: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80302098: addiu       $a0, $zero, 0x11
    ctx->r4 = ADD32(0, 0X11);
    // 0x8030209C: beq         $t7, $at, L_80302108
    if (ctx->r15 == ctx->r1) {
        // 0x803020A0: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_80302108;
    }
    // 0x803020A0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803020A4: addiu       $t8, $zero, -0x9
    ctx->r24 = ADD32(0, -0X9);
    // 0x803020A8: addiu       $t9, $zero, 0x18
    ctx->r25 = ADD32(0, 0X18);
    // 0x803020AC: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x803020B0: sw          $t8, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r24;
    // 0x803020B4: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803020B8: addiu       $a3, $zero, -0x1E
    ctx->r7 = ADD32(0, -0X1E);
    // 0x803020BC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x803020C0: jal         0x80321E60
    // 0x803020C4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    fire_cannonball_1(rdram, ctx);
        goto after_0;
    // 0x803020C4: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    after_0:
    // 0x803020C8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803020CC: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x803020D0: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x803020D4: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x803020D8: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x803020DC: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x803020E0: addiu       $a0, $zero, 0x7C
    ctx->r4 = ADD32(0, 0X7C);
    // 0x803020E4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x803020E8: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x803020EC: addiu       $a1, $zero, 0x4000
    ctx->r5 = ADD32(0, 0X4000);
    // 0x803020F0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803020F4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x803020F8: jal         0x8032C360
    // 0x803020FC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x803020FC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_1:
    // 0x80302100: b           L_80302114
    // 0x80302104: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
        goto L_80302114;
    // 0x80302104: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80302108:
    // 0x80302108: jal         0x8035E3E8
    // 0x8030210C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    recharge_skill(rdram, ctx);
        goto after_2;
    // 0x8030210C: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_2:
    // 0x80302110: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
L_80302114:
    // 0x80302114: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80302118: jr          $ra
    // 0x8030211C: nop

    return;
    // 0x8030211C: nop

;}
